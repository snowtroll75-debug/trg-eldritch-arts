# Changelog


## 0.12.1 — 12 November 2026 (needs TRG Prime 3.687.1)

0.12.0 as live-tested, renumbered. Since the second live test: a failed cast's Save DC is TRG Prime's (10 + the PP cast + the casting ability), for Storm of Unmaking's fumble storm and Veilfracture's collapse — both had used the sheet's Spellcraft DC. See `docs/RELEASE_NOTES_0.12.1.md` and `docs/LIVE_TEST_0.12.1.md`.

## 0.12.0 — 12 Nov 2026 (Block 8b: the rituals and Chapter 7's High Magic spells)

Needs **TRG Prime 3.687.0** (H13–H16). See `docs/RELEASE_NOTES_0.12.0.md`. Built from `docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md` as Graham answered it on 8 November (17:22, "As recommended": Q170–Q182, H13–H16).

- **The 17 Block 8b spells,** every one uncommon: Army of the Grave, Call of the Ancestors, Concord of Stone, Elemental Convergence, Essence Reforging, Eternal Invocation, Rite of Binding Oath, Rite of Echoed Shadows, Sun’s Benediction and Veil Severing; Alter Corpse, Chaos Shield, Leyline Anchor, Mimic Spell, Soul Confluence, Storm of Unmaking and Veilfracture. Grades: 1 A, 10 B, 5 C, 1 D, each at its audit grade. The whole Grimoire (87) is built.
- **The ritual model:**
  - who takes part, ticked (Q173);
  - the Cost checked before the roll and taken whatever the degree (Q174);
  - the printed rung (m42, M45);
  - the Partial casts with no PP lost (H13, Q171);
  - three may be performed alone (H14, Q172);
  - a failure's damage goes to every caster at its own level DC (C3);
  - a rung that leaves nothing ends the cast.
- **The memberships:** Concord's +2 DB to allies inside, Convergence's element (asked of each owner), Echoed Shadows' Stealth and first-entry penalty, Eternal Invocation's aligned rest rates and advantages (H15), Leyline Anchor's +1. Each comes with its Region and goes with it.
- **Chaos Shield** in Block 2's Wild Surge roll (nullify, two rolls, halved damage, DC −2); **Leyline Anchor**'s discount and its gate on Tap and Channel; **Mimic Spell** as a cast reaction with an imprint, PP below 0 at 5 Soul Drain each, and no imprint above the cap (M48); **Soul Confluence**'s shared pool (a damage share) and its Soul Drain; **Storm of Unmaking** as the core's storm, and its fumble's storm following you (H16).
- **One writer per GM account:** the module's automatic writers ask TRG Prime's connection election (`module/writer.mjs`), and a GM's button may be pressed in any of the account's tabs.
- **The extractor reads "Cost"** (the ten rituals' only change in the cut). **Riserune** aims at no creature.
- **The independent review's fixes:** Soul Drain passed as the increment (Mimic Spell, Soul Confluence: it was doubled); a player's ritual zone gets its members (`createRegion`); syncs one at a time per Region; Soul Confluence takes nothing on a refused write; a creature's own choice asked of its player, else any GM tab (`answersFor`), once; Army of the Grave's full Control Levels and released entries; Convergence's resistance and rider as two effects, the rider staying off if its owner turned it off; the Oath's Partial chosen on a GM card; Sun's condition chosen by its owner (the socket's "reduce" request removed); the fumble storm's DC with the PP; a dismissed cast's Regions removed at once (`updateActor`); a Partial's span over the permanent warp (Army, Concord).
- **The live test's fixes:** Mimic Spell's check (and Block 7's Argent Reversal) carries the sheet's Spellcraft (it rolled +0); Mimic is not offered for a Ritual spell or one above the reactor's cap; Rite of Binding Oath swears the rite's participants (it could not be cast: no range, read as "self"); Soul Confluence asks the core for no creature; the fumble storm's DC is the sheet's again (the review's reading reverted).
- **The packs are compiled** (the first zip shipped the 8 November spells pack); `tools/verify-packs-compiled.mjs` checks them against `packs-source/`, and `build-zip` runs it first.
- **New harness pair:** `tools/verify-block8b.mjs` / `tools/mutate-block8b.mjs`. `verify-block2b`, `verify-block6-lead`, `verify-block7`, `verify-block8a`, `verify-book-extract` and `verify-fixes-0101` re-pinned.

## 0.11.2 — 9 Nov 2026 (the 0.11.1 live recheck: Harmonic Rift's real cause)

Needs **TRG Prime 3.686.0**. See `docs/RELEASE_NOTES_0.11.2.md`.

- **Every move check reads where the move ends** (the hook's `change`): in V14's `updateToken` the token document still holds the old position. Fixes the rift sending a token that walked out, and not sending one that walked in; Riserune's 10 ft, the curse's 60 ft hour and the glow read the end position too.
- **An occupied far opening:** the passage checks that it really moved; if not, the card says so and nothing is rolled or carded.
- **A paused move** reads V14's `_movement` record as well as `movement`.
- **The older movement handlers were already right:** they read the token's stored `_source`, which holds the move's end in V14's hook. The two helpers now state that order (`_source`, the document, the placeable). Only Block 8a, which read the lagging `doc.x`, changed. A registry of move ends tried in review was removed.
- **A rift passage counts only if the update returned and the token's stored position is the far opening.**
- The release notes list TRG Prime's own stale `updateToken` reads for Graham. The core was not changed.
- The harness drives every move as V14 does (document old, `change` new). `verify-block8a` and `mutate-block8a` cover each case; version anchors re-pointed at 0.11.2.

## 0.11.1 — 9 Nov 2026 (the 0.11.0 live test's Harmonic Rift findings)

Needs **TRG Prime 3.686.0**. See `docs/RELEASE_NOTES_0.11.1.md`.

- **A token walking out of a rift opening is no longer sent through.** Whether a move ends in an opening is read from the token's new position only; Foundry V14's `doc.regions` still holds the regions from before the move.
- **The rift's sonic save line shows as formatted text,** not escaped HTML.
- **A move paused partway inside an opening** no longer passes: the rift waits for the update with no waypoints left (found in review).
- `verify-block8a` and `mutate-block8a` cover both; the version anchors are re-pointed at 0.11.1.

## 0.11.0 — 8 Nov 2026 (Block 8a: the Grimoire's second half, first part)

Needs **TRG Prime 3.686.0**. See `docs/RELEASE_NOTES_0.11.0.md`. Built from `docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md` as Graham answered it on 8 November (17:22, "As recommended": Q167–Q184 as each row recommends, H12–H18 approved; H12, H17, H18 in TRG Prime 3.686.0, H13–H16 with Block 8b).

- **The 22 Block 8a spells:** the eight Bindings, Symbols of Insanity, Pain and Weakness, and eleven utility spells, every one uncommon. Grades: 0 A, 12 B, 6 C, 4 D, each at its audit grade.
- **The Binding model** (Q168–Q170): the GM places or selects the creature; its trait, level and range are checked; its Will save at the cast's Save DC (circle, Ward Twine and true name in) decides hostile, free, bound or loyal; a bound creature is on the caster's control register as "Bound" (H12); "Until dismissed" locks the PP (Q170); breaking free over the Control Levels ends the spell.
- **The Symbol model** (Q183): a hidden Region where it is carved; the GM's flash targets every token with line of sight; Insanity marks core Insanity's d10 table (H18); Pain's injured and Weakness's weakened are held by a curse within 60 ft and for an hour after (H17), and only Remove Curse ends them sooner.
- **The utilities:** Arcane Pouch, Archway of Ants, Argent Mark, Blood Biography, Harmonic Rift, Riserune and Wall of Sand automated as far as their grades say; Farsight, Phase Door, Rippling Gaze and Traveller's Charm are cards. Arcane Pouch and Harmonic Rift are registered as later teleports, so the Spatial Awareness card comes only with a real passage.
- **Changed in earlier blocks (Q184):** Symbol of Death and Symbol of Fear rebuilt on the Symbol model (D → B); Versatile Binder hands its creature to the binding, which binds it by its own save (C → B); Ley Line Effects 25–27 reach the creatures the control register holds as Bound or Conjured; Block 2b's true-name hostility shared with the Bindings; Block 7's GM relay may delete the "Bound to you" effect.
- **New harness pair:** `tools/verify-block8a.mjs` / `tools/mutate-block8a.mjs`. `verify-block2`, `verify-block6d`, `verify-block6-lead`, `verify-block7`, `verify-book-extract` and `verify-fixes-0101` updated; the version and packs anchors re-pointed.
- **Fixed in review before release (twelve findings):**
  - Symbol of Death's critical carries the symbol's DC.
  - A dismissed Symbol of Death loses its Region on any scene, and its Flash is refused.
  - Wall of Sand offers its length-or-height warp as both choices (TRG Prime's `wallHeight`).
  - The curse's hour and a rift's passage read the token's document.
  - The glow and the areas' expiry sweep every scene.
  - Only the acting GM binds a creature, claimed before the save.
  - The notes' touch button and "living creatures only" were wrong and are corrected.
  - In TRG Prime 3.686.0: Remove Curse on an unowned creature goes through the GM; Insanity keeps its own books for conditions already standing (the general condition path is 3.685.3's, unchanged) and ends outside combat; three relief paths and the fatigue card respect the curse's hold.
- **Fixed after the re-review:**
  - The rift lands on its scene's own grid.
  - A stale binding claim can be taken over by the acting GM.
  - In TRG Prime 3.686.0:
    - Insanity never touches a standing condition's cast id, clock or duration. It raises a valued one's value only, takes the rise back at the next roll or the marker's end, and leaves an unvalued one alone.
    - Insanity's clock is its counted turns while the creature is itself a combatant in a started combat, and the world clock otherwise. A combatant removed from the tracker, or its combat deleted, is clocked.
    - The general condition path is reverted to 3.685.3's. Its pre-existing re-stamping of a standing condition is left for Graham.
    - The turn table takes back a roll's rise by the condition's own stacking rule (slowed left at 4 when a Slow spell raised it past the roll).
    - A creature joining a started combat, or whose combat starts, loses a marker's world clock.
    - Deleting one combatant of a linked actor leaves its second counted.
- **Not in this release:** the extractor's Cost line (no 8a spell prints one; Block 8b's rituals do).

## 0.10.1 — 7 Nov 2026 (the 0.10.0 live test's findings)

Needs **TRG Prime 3.685.1**. See `docs/RELEASE_NOTES_0.10.1.md`. Asked for by Graham before Block 8.

- **The Spatial Awareness card comes with the teleport.** Panic Transposition and Dimensional Assault register their teleports as later than their casts (TRG Prime 3.685.1), so the core cards nothing at the cast; the card and the turn's record come after a successful move, a vetoed move or a click on your own square posts nothing, and Panic is not offered when a second teleport this turn would fail. Dimensional Assault's +5 to Spatial Awareness is laid only once the hop has happened. Mirror Reprise's warp and Dimensional Step did not have the problem.
- **Spirit Arrow's cast card:** "your next ranged Strike deals 6d6 piercing in place of its damage, with nothing added" (the core's rider line).
- **Spirit Arrow, Decoherence and Freshmark ask for no creature target** (`targetsObject`). Re-add a copy made before 0.10.1.
- **Distracted is one effect per spell and caster**, named "Distracted", with all six −1 changes; a caster's second from the same spell replaces their first (created before the old one goes), another spell's or caster's stands beside it, and the penalty stays −1. Animate Moustache and Bubble Buffet copies made before 0.10.1 still lay six rows until re-added.
- **The landing prompt is permanent** until the click, Escape or a canvas teardown, and names the spell, the range and Escape. Every teleport in the module uses it.
- **Review fixes before release** (all of the above marked so in the release notes), and stale targets kept out of a `targetsObject` cast by TRG Prime.
- **New harness pair:** `tools/verify-fixes-0101.mjs` / `tools/mutate-fixes-0101.mjs`. `verify-block7` and `verify-block6-lead` updated; the version anchors re-pointed.

## 0.10.0 — 7 Nov 2026 (Block 7: the Grimoire, first half)

Needs **TRG Prime 3.685.0**. See `docs/RELEASE_NOTES_0.10.0.md`. Built from `docs/ELDRITCH_ARTS_BLOCK7_AUDIT.md` §5.2 as Graham answered it on 7 November (Q150 changed, Q151–Q166 as proposed, H1–H11 approved), with his 07:53 rulings on Dragon Wings ("Max +50, four warps") and Spirit Arrow ("Flat 6d6").

- **The 42 Block 7 spells:** ten cantrips, eighteen attack, save and area spells, fourteen wards, buffs and reactions, every one uncommon. Grades: 17 A, 17 B, 6 C, 2 D. The Elemental Strike ability for Elemental Strike's minute.
- **Distracted** (Q157): −1 status to attack checks, skill checks, saves and casting checks, as the spell engine's own rows (Animate Moustache, Bubble Buffet).
- **Module automations** (`module/block7-automations.mjs`): the type chosen when Dragon's Breath or Elemental Strike is learned; Arcane Feedback cast inside the enemy's casting gate; Argent Reversal and Spectral Aegis as cast reactions (H5); Mirror Reprise and Panic Transposition as check reactions (H6); Arcane Bastion's critical (H7); Invoke True Name's flat-footed, save penalty and weakness; Planar Anchor's refusal; Zone Disruption (H8); Primal Snap's turn-start fog (H11); Metamagic Resonance's lent metamagic (H9); Spirit Arrow's later arrows and its dread.
- **Block 6's Pacts grant their spells:** the Draconic and Elemental Pacts' Uses add Dragon's Breath and Elemental Strike of the chosen type; Pact Boon (Draconic) adds Dragon Wings. The "arrives with the Grimoire" text is gone.
- **Review fixes before release:** Arcane Bastion's and Mirror Reprise's ends delete their effects (unregistered casts); Metamagic Resonance keyed on its active-spell entry, its lend timed; Panic Transposition's teleport delivered to the bearer's owner once the attack is resolved (the book's timing), cleared when the attack is over, its save at its own settled DC; writes on another's creature through the GM (module socket) or kept on the caster; Chronoweave's live membership; Primal Snap's Partial; Arcane Feedback's injury at the reactor's DC; Argent Reversal's redirect within range; Elemental Strike's Strike count by hand.
- **Second review fixes before release:** the GM relay checks each write against the creature's current state (cast ids from its own state, flag writes only a counter down by one or Mirror Reprise armed, no PP relayed); Argent Reversal's refund on the bearer's client, capped at its PP maximum; Arcane Bastion's lowered severity kept when the bearer is not the client's; the aura sync serialised and deduplicated, a re-cast refreshing it, a deleted caster token removing it; Panic Transposition matched on the attacker, purged only after ten minutes; a dismissed Mirror Reprise swept and inert; Elemental Strike's chat card by hand.
- **New harness pair:** `tools/verify-block7.mjs` / `tools/mutate-block7.mjs`. Earlier verifies updated for the new content and for TRG Prime 3.685.0's cast-reaction shape (`verify-block6b2` G17).

Also in this release, from before Block 7 (Block 7 audit §6; Graham's Q166 "as proposed"):

- **The book extract keeps every field.** `extract-book.mjs` now reads "Target" (16 lines in v1.6) and "Requirement" (Rippling Gaze), keeps a Tradition set with a bold comma whole (EA-m127: Call of the Ancestors, Undead Binding, Veil Severing), and reads Steelbinding's "+2**; Requirements**" (m45). `book-text.json` is cut again from v1.6. Each entry records its field lines' bold labels.
- **Paradox Weave** prints "**Target** 1 willing creature" and targets "1 willing creature". This line was lost in 0.5.0.
- **The six built Grimoire spells are uncommon** (`system.availability`, ruling m84): Orb of Water, Dark Whispers, Message Rune, Observe the Weave, Symbol of Death, Symbol of Fear. TRG Prime warns when one is taken with a level-up pick.
- **No other shipped text changed.** The new extract also changes Steelbinding's raw fields, but Steelbinding already had a repair that wrote the same text, so its card is unchanged. All the other entries that changed are Block 7–8 spells, which are not built yet.
- **New harness pair:** `tools/verify-book-extract.mjs` / `tools/mutate-book-extract.mjs`. It checks that every bold label reaches `fields`, and checks the lines §6 names. When the v1.6 source is on disk (set `EA_BOOK_MD`), it also cuts the book again and compares that with `book-text.json`.

## 0.9.2 — 5 Nov 2026 (the 3.684.4 live test's finding)

Needs **TRG Prime 3.684.1**. See `docs/RELEASE_NOTES_0.9.2.md`.

- **Lightning Rod's splash posts its card.** The splash's damage was applied, but its card was lost to an error when the mark ended.

## 0.9.1 — 4 Nov 2026 (Graham's answers after 0.9.0)

Needs **TRG Prime 3.684.1**. See `docs/RELEASE_NOTES_0.9.1.md`.

- **Every Witch spell is High Magic.** Re-add the Witch class to get it.
- **Wellspring Conduit** counts the PP the spell is cast at.
- **Spell images:** each uses a V14 icon for its school.

## 0.9.0 — 4 Nov 2026 (Block 6: archetypes, class feats, metamagic)

Needs **TRG Prime 3.684.0**. See `docs/RELEASE_NOTES_0.9.0.md`. Q89–Q149 as answered on 4 November (`docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md`; Q89: one release).

- **The 23 archetypes and 97 class feats:** each archetype is registered, so its class feats gate. Progression is read as levels since taken (Q90, Q91).
- **Module metamagic** in the Warp? dialog (TRG Prime's G1), which finishes Echo of the Ancestors, Resonant Pulse, Resonant Harmony, Spell Surge and Piercing Insight.
- **The Warlock's Charisma pool** (Q97): the Bonded Soul's choice writes the sheet's tradition when it is blank.
- **Grades of the 120:** 39 fully automated, 70 with a choice, 11 partly, none cards only.
- **Changed in earlier blocks:**
  - Storing Rune stores in the spell (with TRG Prime 3.684.0's fix).
  - Tap Ley Line asks Leyline Weaver's ladder first, and lays Ley-Etched Symbol's marker for its owner.
  - Draconic Infusion adds its claw damage.
  - Resonant Pulse's card no longer claims item casts (Q94).
  - Spell Surge has the Focus trait: re-add a copy made earlier.

## 0.8.0 — 4 Nov 2026 (Block 5: racial and general feats)

Needs **TRG Prime 3.683.0**. See `docs/RELEASE_NOTES_0.8.0.md`. Q57–Q88 as answered on 3 November (`docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md`).

- **The racial feats (74):** Aetherial, Emberkin, Nyrinn and Scaelyn, and those for the Elf, Human, Gnome, Kornargon and Ascendan, with the Quiliesh Heritage.
- **The general feats:** 34 new; nine came with earlier blocks.
- **Grades of the 108 new:** 44 fully automated, 43 with a choice, 10 partly, 11 cards only. The catalyst and metamagic feats wait for Blocks 9 and 6.
- **Changed in earlier blocks:** Esoteric Insight reaches Spell Recognition; Null Aura reads Silent Veil's +5 ft; Disrupting Magic names its caster; Battle Mage's card names the maneuver spells.

## 0.7.1 — 3 Nov 2026 (the 0.7.0 live test's fixes)

Needs **TRG Prime 3.682.1**. See `docs/RELEASE_NOTES_0.7.1.md` and `docs/LIVE_TESTING_REPORT_0.7.0.md`.

- **Battle Mage** now applies to the core's attack spells (the fix is in TRG Prime 3.682.1).
- **Shooting Star, Shielding Strike, Spinning Weapon and Thunderous Strike** have the range "see text", so a targeted creature no longer has them refused as "self". Copies already on actors need dragging in again.
- **AP** is charged only to an actor in the running combat (Blocks 1, 3 and 4), and an unlinked token counts as in it only as itself.

## 0.7.0 — 3 Nov 2026 (Block 4: the Spellblade and the Warlock)

Needs **TRG Prime 3.682.0**. See `docs/RELEASE_NOTES_0.7.0.md`. Q36–Q52 per `docs/ELDRITCH_ARTS_BLOCK4_AUDIT.md`.

- **The Spellblade:** its four paths, the Book of Infusions (level + 1 memorised), Battle Mage, Infuse Weapon and learned runes, the four special abilities, the five Spellblade spells.
- **The Warlock:** Xithra, the eight bonded souls (their +1 level and daily powers), innate Focus spells, cantrips and a hex.
- **Sidebar 16:** the core feats each of Chapter 3's classes gains.

## 0.6.1 — 3 Nov 2026 (the 0.6.0 live test's fixes)

Needs **TRG Prime 3.681.0** (unchanged). See `docs/RELEASE_NOTES_0.6.1.md` and `docs/LIVE_TESTING_REPORT_0.6.0.md`.

- **Prophetic Warning** is cast at the Witch's own token, not at whatever her user has targeted.
- **Disrupting Magic** is offered only to a creature that could roll the Dispel: one with Power Manipulation or an untrained exemption, and not Fixated.

## 0.6.0 — 3 Nov 2026 (Block 3b: the reactions)

Needs **TRG Prime 3.681.0**. See `docs/RELEASE_NOTES_0.6.0.md`. Q26–Q35 built as proposed.

- **Missed Chance and Second Chance:** a Witch in reach is asked when an enemy succeeds or an ally fails. The reroll uses fresh dice, loses the first roll's Conviction die, and its result is locked. Each gives an hour's immunity.
- **Prophetic Warning:** offered before the Witch's own checks with a DC, for advantage. A client setting turns the offer off, and a cast from the sheet then arms the advantage for her next check.
- **Phase Familiar and Resist Magic:** asked before damage meets the defences, and held for that blow or that cast.
- **Disrupting Magic:** asked when a non-allied creature's cast succeeds. It rolls the system's Dispel at no AP, and on a Success or better the spell is stopped.
- **Eternity Resilience:** a Conviction point (one a round) for disadvantage on a critical roll. Not offered on a minor critical.
- **Found in review, before release:** ten defects fixed, here and in TRG Prime 3.681.0. See the release notes.

## 0.5.1 — 2 Nov 2026 (the 0.5.0 live test's fixes)

Needs **TRG Prime 3.680.0** (unchanged). See `docs/RELEASE_NOTES_0.5.1.md` and `docs/LIVE_TESTING_REPORT_0.5.0.md`.

- **Hexes** takes every hex owed in one Use.
- **The Soulbound spell adder** holds only while the living soulbound familiar holds the bond.
- **Ranges** are read from where a moving token stands (V14), not one move behind.
- **A severed bond fatigues** (fatigued 2), once however many ways the death is reported, and a renewed bond takes the 2 off and says so.
- **A familiar killed while dying** severs the bond.
- **Gale Step** spends nothing on a teleport the system refuses.

## 0.5.0 — 2 Nov 2026 (Block 3a: the Archmage, the Sorcerer and its birthrights, the Witch)

Needs **TRG Prime 3.680.0**. See `docs/RELEASE_NOTES_0.5.0.md`. Q15–Q25 built as proposed.

- **Three classes:** the Archmage, the Sorcerer and the Witch, with their tables, class magic, bonus feats and Chapter 6's class wealth.
- **The seven birthrights** with their special abilities, specialist spells, Specialist Spell lists and additional spells.
- **The Witch's Soulbound Familiar, Verdant Communion and Hexes.**
- **34 specialist spells and hexes, and five Grimoire spells.**
- **Block 1 fix (in the system):** the four races' Power Points per level now reach the character.

## 0.4.0 — 2 Nov 2026 (Block 2b: rituals, summoning circles, true names, Spell Trickery, Borrow Spell)

Needs **TRG Prime 3.679.0**. See `docs/RELEASE_NOTES_0.4.0.md`. Q9–Q14 built as proposed (listed there).

- **Mundane ritual casting:** the ritual variant (a primary trained in the spell's tradition skill, the level DC Very Hard) with its vital, material and communal sacrifices, paid for the PP the degree spends. The cap per cast stands.
- **Ritual goods and feats:** Ritual Censor, Ritualist weapons, Runestone Chalkboard, Bloodscribe's Bowl and Ritual Expert in the Magic Ritual dialog.
- **Ritual spells (Q8, M30):** an Eldritch Arts Ritual spell is refused outside a ritual and is not capped at Success inside one.
- **The ritual meets Chapter 7's areas:** antimagic refuses it before its dialog, and suppression's −level reaches its check (0.3.0's gap).
- **Summoning circles:** Inscribe Summoning Circle with the printed modifiers; the circle's ±circumstance on Summons spells, a Critical's binding, Ward Twine (Q12) and Void Chalk.
- **True names:** +4 Save DC on a Summons spell; a creature that saves anyway is permanently hostile.
- **Spell Trickery** (+2 casting DC) and **See Through Spell Trickery** against the caster's Deception DC.
- **Borrow Spell** (m14): Easy against the DC to learn the spell; borrowed until the next daily preparation.
- **Fixed:** a table card no longer repeats its title as its first line (0.3.0 live test).
- **Review fixes before release:** payment checked before the roll (purse, secondaries' PP and ownership, ticks), no double payment (rod, refunds), Ritual Experts capped by the secondaries entered, Borrow Spell only from a book caster's book entries, specialist spells offered a variant, the Ritual Censor's incense taken.
- **Harness:** `verify-block2b` 91 checks, `mutate-block2b` 81 mutations, all caught; `verify-block1` 882 and `mutate-block1` 86; `verify-block2` 131 and `mutate-block2` 75.

## 0.3.0 — 1 Nov 2026 (Block 2a: High Magic and Chapter 7's areas)

Needs **TRG Prime 3.678.0**. See `docs/RELEASE_NOTES_0.3.0.md` and `docs/ELDRITCH_ARTS_BLOCK2_AUDIT.md`.

- **High Magic** casts as Chapter 7 prints it, run by TRG Prime 3.678.0. Eldritch Arts declares that its High Magic supersedes the Fiends & Fables creature guideline (M4, Q1).
- **Chapter 7's areas** are Region Behaviours: Ley Line, Wild Magic Area, Magic Suppression Area. Each has a level; a Suppression area may have backlash, and is antimagic at level 20 or more.
- **Tap Ley Line, Channel Ley Line, Tap Magical Energy**: their DC from the line's level or the item's (C3), every printed degree, lockouts.
- **The three d100 tables** (Ley Line Effects, Wild Surge, Suppression Backlash), each row's printed text, and what is applied: 38 of 70 ley line results, 17 of 34 surges, 7 of 8 backlashes. The rest is posted for the table.
- **Wild Magic areas** surge on a casting check of Partial or worse, or chaos (Q7: scrolls, wands and rituals too). **Suppression areas**: −level on the casting check, Partial/Failure/Fumble read as Failure and Blunder as Fumble, no Resonance, backlash on a failed casting where the area has it. **Antimagic**: every casting refused (Q6), and the effects of magic items and spells switched off while inside.
- **Ley Line Connection** (Scaelyn): −1 to a High Magic casting DC.
- **Harness:** `verify-block2` 131 checks, `mutate-block2` 75 mutations, all caught; `verify-block1` 881, `mutate-block1` 86.

## 0.2.0 — 1 Nov 2026 (Block 1 on book v1.6, with Graham's rulings)

Needs **TRG Prime 3.677.0**. See `docs/RELEASE_NOTES_0.2.0.md` and `docs/ELDRITCH_ARTS_RULINGS_2026-11-01.md`.

- **Rebuilt from book v1.6.** Every Block 1 item's printed text is v1.6's (the book extract, `tools/content/book-text.json`, is cut from the v1.6 docx; its 34 text boxes by the new `tools/content/extract-sidebars.py`).
- **Null Aura's Will save (C1):** a beneficial spell another caster casts on a Nyrinn asks for a Will save against that caster's spell save DC; on a failure it has no effect on them. TRG Prime rolls it (3.677.0, C14); the 0.1.x GM reminder is gone.
- **Esoteric Insight (v1.6):** rerolls a Failure as well as a Fumble on Arcana and Occultism (TRG Prime 3.677.0, C12).
- **Racial weapons (m64):** one category easier for their race. Every Block 1 racial weapon is exotic, so martial, as before; the rule is now the system's (3.677.0, C13).
- **Umbryth** resists cold (m4). **Glyphweave**'s cantrip is innate (m5) and kept until chosen again. **Spirit Binder**'s wealth is the book's 0 (m58). **Ord ua na Tuama** is Large (R6). The **Nyrinn** spelling is the book's (m2).
- **Text as printed in v1.6:** Hypnotism ("Indifferent or worse"), Quickbind, the Claidheamh Dubh, the Bogha Tuama, Gilded Censor Chains, Ritual Censor, Ward Twine, Leybraid Rope, Spellbinder's Cord, Twilight Prism, Cabal Exile.
- **Harness:** `verify-block1` 881 checks; `mutate-block1` 86 mutations, all caught.

## 0.1.1 — 29 Oct 2026 (one fix from the 0.1.0 live test)

Needs **TRG Prime 3.675.0** (runs on 3.675.1). See `docs/RELEASE_NOTES_0.1.1.md` and `docs/LIVE_TESTING_REPORT_0.1.0.md`.

- **The compendiums sit in one "Eldritch Arts" folder:** `module.json` declares a `packFolders` entry, as Inner Tempest 1.0.4 and Pillars of Faith do. No rules or content change.
- **Harness:** `verify-block1` 870 checks; `mutate-block1` 75 mutations, all caught.

## 0.1.0 — 28 Oct 2026 (Block 1: races, backgrounds, Chapter 4 actions, exotic weapons, goods)

Needs **TRG Prime 3.675.0**. See `docs/RELEASE_NOTES_0.1.0.md`. Built as proposed in `docs/ELDRITCH_ARTS_BLOCK1_AUDIT.md`; questions B1-1 to B1-22 are open for Graham.

- **Races:** Aetherial, Emberkin, Nyrinn, Scaelyn, with their 12 racial abilities and 18 heritages. Power Points +1 / +1 / −1 / +1 per level. The Nyrinn (Tiny) and Scaelyn (Small) carry only what the size table does not add, so the sheet shows the printed line. Wyrmdral sets Medium and replaces the Scaelyn's line.
- **Backgrounds:** twelve, with Chapter 6's wealth (Spirit Binder 0 until ruled, B1-14), and the nine Eldritch Arts feats they grant.
- **The core racial feats** Chapter 5 opens to each race.
- **Chapter 4:** Ley Sense (Focused Ley Sense's ladder), Appraise Magic, Hypnotism (Implant Suggestion and Memory Recall), Mysterious Script, Quickbind, and Magic Drain as an action. Lingual Casting is a way to read a scroll.
- **Abilities with a Use:** Ethereal Form, Elemental Symbiosis, Innate Magic, Glyphweave, Wyrmdral, Elemental Affinity, Wanderer's Instinct, Magic Drain, Vir-ellian Release.
- **On the map:** Null Aura's penalty on Spellcraft checks within 5 ft (10 for a Vel-tharis), and Zhal-vryn's extra PP.
- **Orb of Water**, the Tidemarked's cantrip, with its secondary cold packet.
- **Chapter 6:** 18 exotic weapons (Adept is Simple for an Adept class; racial and heritage traits make a weapon martial) and 31 goods (their bonuses offered as ticks while carried).
- **Audit Part F:** five Majors and four Minors found while building (EA-M113 to EA-M117, EA-m226 to EA-m229).
- **Review fixes before release:** Null Aura on the casting DC only; Ley Sense's Partial reads as its Failure; Magic Drain's choices made before the roll, its DB bonus racial, its minutes per PP drained, another's item left to the GM; Quickbind keeps Invest Item's rules; Wanderer's Instinct offered, not pre-ticked; a world-clock backstop for "until the end of your next turn"; Vir-ellian Release keeps its energy if the blast fails.
- **Harness:** `verify-block1` 866 checks; `mutate-block1` 73 mutations, all caught.

## 0.0.1 — 28 Oct 2026 (scaffold)

Needs **TRG Prime 3.674.2**.

- **Scaffold:** module manifest, entry script, sourcebook registration ("Eldritch Arts"), build tooling, and the book extractor for Chapter 5.
- **Preliminary documents for review:**
  - the implementation matrix (707 features)
  - the automation report
  - the rules audit (Critical 8, Major 112, Minor 225, Recommendation 24; all excerpts checked against the book)
  - core dependencies D1–D18
  - the architecture and block plan
  - the progress note with the rulings needed
- **Extractor:** now also reads the 36 docx sidebars.
- **Content:** none yet.
