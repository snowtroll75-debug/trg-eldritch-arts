/**
 * Eldritch Arts Block 2b (0.4.0) — Chapter 7's mundane rituals, summoning
 * circles and true names; Chapter 4's Spell Trickery and Borrow Spell.
 *
 *   THE RITUAL VARIANT (TRG Prime 3.679.0, D13): a primary "trained in Arcana
 *     (Arcane), Religion (Divine), Occultism (Ethereal), or Nature (Verdant)"
 *     may lead, "even with 0 Caster Level/PP". The check is that skill at
 *     "Very Hard (DC +5) level-based DC equal to the wielder's level", the
 *     core's ritual modifiers still moving it (Q5). The PP the degree spends
 *     (Q11) are paid as a VITAL (1d8 essence per PP on the primary, 1d4 on
 *     each secondary, basic Fortitude, nothing reduces it), MATERIAL (the
 *     table's gp, from the primary's purse) or COMMUNAL (+50%, split among
 *     the secondaries) sacrifice. The cap per cast stands (Q9); a non-caster
 *     need not have prepared the spell, a caster must (Q10).
 *   RITUAL SPELLS (Q8, M30): an Eldritch Arts spell with the Ritual trait "may
 *     only be attempted as part of such a ritual" and "ignore[s] the core cap
 *     that limits a ritual's result to Success". The core's own Ritual spells
 *     (Clone) are unchanged.
 *   THE GOODS AND FEATS: Ritual Censor (−1 DC, 5 gp of incense), a Ritualist
 *     weapon (−1 DC), Runestone Chalkboard (+1), Bloodscribe's Bowl (+1 with
 *     blood offered); Ritual Expert counts as two casters (Q13).
 *   SUMMONING CIRCLES: Inscribe Summoning Circle, a skill action against the
 *     creature's level DC with the table's modifiers; the circle is an effect
 *     on the caster for 1 hour per caster level (24 hours in Void Chalk),
 *     giving Summons spells +4 / +2 / −2 circumstance on the casting check
 *     and, on a Critical, −2 to the creature's resistance (as +2 Save DC; Ward
 *     Twine another +1, Q12). A Fumble's circle: the creature arrives hostile
 *     and unbound.
 *   TRUE NAMES: a casting option on a Summons spell, +4 Save DC; a creature
 *     that saves anyway "becomes permanently hostile towards you".
 *   SPELL TRICKERY: a casting option, +2 to the casting DC; observers see
 *     through it with a skill action against the caster's Deception DC.
 *   BORROW SPELL (m14): Easy, against the DC to learn the spell; the spell is
 *     copied into the borrower's book for the day and leaves it at the next
 *     daily preparation; a failure bars that spell until then.
 */
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, now, levelOf, owned, tokenOf, printedDegree } from "./block1-automations.mjs";
import { SKILL_ACTIONS } from "./block2b-actions.mjs";

export const RULES_KEY = MODULE_ID;
const PLAN_FLAG = "block2bPlan";
const RITUAL_FLAG = "ritualPlan";
const BORROW_FLAG = "borrowLocks";

/* ------------------------------------------------------------------ */
/* Pure decisions                                                       */
/* ------------------------------------------------------------------ */

/** "Arcana (Arcane), Religion (Divine), Occultism (Ethereal), or Nature (Verdant)". */
export const RITUAL_SKILLS = Object.freeze({ arcane: "arcana", divinity: "religion", divine: "religion", ethereal: "occultism", verdant: "nature" });
export const SKILL_LABELS = Object.freeze({ arcana: "Arcana", religion: "Religion", occultism: "Occultism", nature: "Nature" });

/** The tradition skills "appropriate to the spell": its traditions', or all four for a Highmagic spell (M27). */
export function ritualSkillsFor(spellData = {}, { highMagicSpell = false } = {}) {
  if (highMagicSpell) return ["arcana", "religion", "occultism", "nature"];
  const keys = String(spellData?.tradition ?? "").split(/[,/]/).map(norm).map((t) => RITUAL_SKILLS[t]).filter(Boolean);
  return [...new Set(keys)];
}

/** The appropriate skill the primary is trained in and best at, or null. */
export function bestTrainedSkill(skills = {}, keys = []) {
  const trained = keys.filter((k) => int(skills?.[k]?.ranks) > 0);
  if (!trained.length) return null;
  return trained.reduce((a, b) => (int(skills[b]?.total) > int(skills[a]?.total) ? b : a));
}

/** RITUAL MATERIAL SACRIFICE COSTS, as printed (1 to 20 PP). */
export const MATERIAL_COSTS = Object.freeze([0, 30, 60, 100, 150, 250, 400, 600, 900, 1300, 1800, 2500, 3500, 5000, 7500, 11000, 16000, 25000, 40000, 65000, 110000]);
/** The gp for a number of PP, or null beyond the table. */
export const materialCost = (pp) => { const n = int(pp); return n < 0 || n >= MATERIAL_COSTS.length ? null : MATERIAL_COSTS[n]; };

/** "The total PP cost of the ritual is increased by 50%, and this cost is then split amongst the secondary casters." */
export function communalShares(pp, count) {
  const n = Math.max(0, int(count));
  if (!n) return [];
  const total = Math.ceil(Math.max(0, int(pp)) * 1.5);
  const base = Math.floor(total / n);
  return Array.from({ length: n }, (_, i) => base + (i < total % n ? 1 : 0));
}

const traitsOf = (spellData) => String(spellData?.traits ?? "").split(",").map(norm).filter(Boolean);
export const hasTrait = (spellData, trait) => traitsOf(spellData).includes(norm(trait));

/** An Eldritch Arts spell: from this module's compendium, or flagged as ours (Q8). */
export function isEldritchArtsSpell(item) {
  if (!item) return false;
  if (item.flags?.[MODULE_ID]?.spell === true) return true;
  return String(item._stats?.compendiumSource ?? item.sourceId ?? "").startsWith(`Compendium.${MODULE_ID}.`);
}

/** A summoning circle's bonus to Summons casting checks, by its degree. */
export const CIRCLE_CHECK = Object.freeze({ critical: 4, success: 2, failure: -2, fumble: 0 });

/** SUMMONING CIRCLE MODIFIERS, from the dialog's answers. */
export function circleDCRows(form = {}) {
  const rows = [];
  const push = (label, value) => { if (int(value)) rows.push({ label, value: int(value) }); };
  const rare = Math.min(10, Math.max(0, int(form.rare)));
  if (rare) push("Rare or consecrated materials", -Math.max(2, rare));
  const poor = Math.min(5, Math.max(0, int(form.poor)));
  if (poor) push("Improvised or poor materials", Math.max(2, poor));
  if (form.ground === "aligned") push("Ground aligned with the creature's tradition", -4);
  if (form.ground === "opposed") push("Ground opposed to the creature's tradition", 4);
  if (form.trueName) push("You know its True Name", -5);
  if (form.care === "haste") push("Prepared in haste", 5);
  if (form.care === "meticulous") push("Prepared with meticulous care", -2);
  push("Secondary casters assisting", -Math.min(4, Math.max(0, int(form.assistants))));
  if (form.blood === "animal") push("Blood sacrifice (animal)", -2);
  if (form.blood === "intelligent") push("Blood sacrifice (intelligent)", -4);
  if (form.disrupted) push("Circle disrupted or damaged", 10);
  return rows;
}

/** "10 minutes × the level of the creature", doubled with meticulous care; haste is less (the GM's). */
export function circleMinutes(level, care = "") {
  const base = 10 * Math.max(1, int(level));
  return care === "meticulous" ? base * 2 : base;
}

/** "Circles last 1 hour per caster level"; Void Chalk's "intact for 24 hours". */
export const circleSeconds = (casterLevel, voidChalk = false) => Math.max(3600 * Math.max(1, int(casterLevel)), voidChalk ? 86400 : 0);

/* ------------------------------------------------------------------ */
/* Foundry side: small steps                                            */
/* ------------------------------------------------------------------ */

const FDE = () => foundry.applications?.ux?.FormDataExtended ?? globalThis.FormDataExtended;
const carried = (actor, name) => Array.from(actor?.items ?? []).find((i) => norm(i.name) === norm(name) && !["feat", "ability", "spell", "race", "heritage", "background", "class"].includes(i.type)) ?? null;
const ritualistWeapon = (actor) => Array.from(actor?.items ?? []).find((i) => i.type === "weapon" && /\britualist\b/i.test(String(i.system?.traits ?? ""))) ?? null;
const ownLevelDC = (actor) => h().levelDC(levelOf(actor));
const casterLevelOf = (actor) => int(actor?.system?.magic?.casterLevelValue ?? actor?.system?.magic?.casterLevel);
const plan = (actor, flag = PLAN_FLAG) => actor?.getFlag?.(MODULE_ID, flag) ?? null;
const setPlan = (actor, value, flag = PLAN_FLAG) => actor.setFlag(MODULE_ID, flag, value);
const clearPlan = (actor, flag = PLAN_FLAG) => actor.unsetFlag(MODULE_ID, flag);
const highmagicSpell = (spellData) => hasTrait(spellData, "highmagic") || hasTrait(spellData, "high magic");

/** The other creatures on the scene who could take part. */
function participants(actor) {
  const seen = new Set([actor?.id]);
  const out = [];
  for (const t of globalThis.canvas?.tokens?.placeables ?? []) {
    const a = t.actor;
    if (!a || seen.has(a.id)) continue;
    seen.add(a.id);
    out.push(a);
  }
  return out;
}
const actorByRef = (ref) => {
  if (!ref) return null;
  try { return globalThis.fromUuidSync?.(ref) ?? globalThis.game?.actors?.get(ref) ?? null; } catch { return globalThis.game?.actors?.get(ref) ?? null; }
};

/* ------------------------------------------------------------------ */
/* The ritual (TRG Prime 3.679.0's ritual rules)                        */
/* ------------------------------------------------------------------ */

export const VARIANTS = Object.freeze([
  Object.freeze({ key: "vital", label: "Vital sacrifice (tradition skill, Very Hard)", hint: "The primary takes 1d8 essence per PP substituted, each secondary 1d4 (basic Fort); nothing reduces it." }),
  Object.freeze({ key: "material", label: "Material sacrifice (tradition skill, Very Hard)", hint: "The table's gold, from the primary's purse." }),
  Object.freeze({ key: "communal", label: "Communal offering (tradition skill, Very Hard)", hint: "The secondaries pay the PP, +50%, split between them." })
]);

/** The variants this primary may use: trained in a skill appropriate to the spell. */
/** The spell's traditions, or the caster's for a specialist spell, which inherits it (review). */
const ritualTraditionData = (actor, spellData) => (String(spellData?.tradition ?? "").trim() ? spellData : { ...spellData, tradition: actor?.system?.magic?.tradition ?? "" });

export async function ritualVariants({ actor, spellData } = {}) {
  const skill = bestTrainedSkill(actor?.system?.skills, ritualSkillsFor(ritualTraditionData(actor, spellData), { highMagicSpell: highmagicSpell(spellData) }));
  return skill ? VARIANTS.map((v) => ({ ...v })) : [];
}

/** The ritual dialog's own fields. */
export async function ritualFields({ actor, spellData } = {}) {
  const parts = [];
  const tick = (name, label) => `<div class="form-group"><label><input type="checkbox" name="${name}"> ${label}</label></div>`;
  const variants = await ritualVariants({ actor, spellData });
  if (variants.length) {
    const others = participants(actor);
    parts.push(`<p class="hint">Eldritch Arts — for a vital sacrifice or a communal offering, tick the secondary casters taking part:</p>`
      + (others.length ? others.map((a) => tick(`eaSecondary-${a.id}`, esc(a.name))).join("") : `<p class="hint"><em>No other creature is on the scene.</em></p>`));
  }
  const goods = [];
  if (carried(actor, "Ritual Censor")) goods.push(tick("eaCensor", "Ritual Censor, with 5 gp of incense consumed (−1 DC)"));
  const weapon = ritualistWeapon(actor);
  if (weapon) goods.push(tick("eaRitualist", `${esc(weapon.name)} (Ritualist) wielded or at the centre (−1 DC)`));
  if (carried(actor, "Runestone Chalkboard")) goods.push(tick("eaChalkboard", "Runestone Chalkboard used in the preparation (+1)"));
  if (carried(actor, "Bloodscribe’s Bowl")) goods.push(tick("eaBowl", "Bloodscribe’s Bowl, with blood offered (+1)"));
  if (goods.length) parts.push(`<p class="hint">Eldritch Arts — ritual goods you carry:</p>${goods.join("")}`);
  parts.push(`<div class="form-group"><label for="ea-ritual-experts">Secondary casters with Ritual Expert (each counts as two casters)</label><input id="ea-ritual-experts" type="number" name="eaRitualExperts" value="0" min="0" max="6"></div>`);
  return `<hr>${parts.join("")}`;
}

/** Ritual Expert, or Rune-Binder's Precision (Graham's M21: they do not stack). */
export const countsAsTwo = (actor) => Boolean(owned(actor, "Ritual Expert", ["feat"]) || owned(actor, "Rune-Binder’s Precision", ["feat"]) || owned(actor, "Rune-Binder's Precision", ["feat"]));

/** What the ritual becomes once its dialog is answered. */
export async function prepareRitual({ actor, spell, spellData, form = {}, variant = "", basePP = 0, ppOver = 0, secondaryCount = 0 } = {}) {
  const out = { dcRows: [], modifiers: [], seats: 0, lines: [] };
  // THE INCENSE IS PAID (review): 5 gp, or no −1.
  if (form.eaCensor && carried(actor, "Ritual Censor")) {
    if (int(await h().goldOf(actor)) < 5) return { ...out, refused: "the Ritual Censor's incense costs 5 gp, and the purse is short: untick it" };
    out.dcRows.push({ label: "Ritual Censor", value: -1 });
  }
  const weapon = ritualistWeapon(actor);
  if (form.eaRitualist && weapon) out.dcRows.push({ label: `${weapon.name} (Ritualist)`, value: -1 });
  if (form.eaChalkboard && carried(actor, "Runestone Chalkboard")) out.modifiers.push({ label: "Runestone Chalkboard", value: 1, type: "untyped" });
  if (form.eaBowl && carried(actor, "Bloodscribe’s Bowl")) out.modifiers.push({ label: "Bloodscribe’s Bowl (blood offered)", value: 1, type: "untyped" });
  // Taken last, once nothing below can refuse the ritual.
  const payIncense = async () => {
    if (!out.dcRows.some((r) => r.label === "Ritual Censor")) return;
    await h().deductGold(actor, 5);
    out.lines.push("Ritual Censor: 5 gp of incense is consumed in the rite (taken from the purse).");
  };
  // NO MORE EXPERTS THAN SECONDARIES ENTERED (review): an expert is one of them.
  const experts = Math.max(0, Math.min(int(secondaryCount), int(form.eaRitualExperts)));
  const primaryExpert = countsAsTwo(actor) ? 1 : 0;
  out.seats = experts + primaryExpert;
  if (out.seats) out.lines.push(`Ritual Expert: ${out.seats} more caster${out.seats === 1 ? "" : "s"} counted (${[primaryExpert ? "the primary" : "", experts ? `${experts} secondar${experts === 1 ? "y" : "ies"}` : ""].filter(Boolean).join(" and ")}).`);

  if (!variant) { await clearPlan(actor, RITUAL_FLAG); await payIncense(); return out; }
  if (!VARIANTS.some((v) => v.key === variant)) return { ...out, refused: `no such way of paying (${variant})` };
  const keys = ritualSkillsFor(ritualTraditionData(actor, spellData), { highMagicSpell: highmagicSpell(spellData) });
  const skill = bestTrainedSkill(actor?.system?.skills, keys);
  if (!skill) return { ...out, refused: `the primary caster must be trained in ${keys.map((k) => SKILL_LABELS[k]).join(" or ") || "the spell's tradition skill"}` };
  const secondaries = participants(actor).filter((a) => form[`eaSecondary-${a.id}`]);
  const pp = int(basePP) + int(ppOver);
  if (variant === "material" && materialCost(pp) === null) return { ...out, refused: `the material sacrifice table stops at 20 PP (this ritual is ${pp})` };
  if (variant === "communal" && !secondaries.length) return { ...out, refused: "tick the secondary casters who pay the communal offering" };
  // PAID FOR BEFORE THE ROLL, NOT AFTER IT (review): the secondaries ticked are
  // the ones entered; the gold and the PP are there; a communal secondary is
  // one whose PP this user may take.
  if ((variant === "vital" || variant === "communal") && secondaries.length !== int(secondaryCount)) {
    return { ...out, refused: `tick each secondary caster taking part (${int(secondaryCount)} entered, ${secondaries.length} ticked)` };
  }
  if (variant === "material") {
    const need = materialCost(pp);
    const have = Number(await h().goldOf(actor)) || 0;
    if (have < need) return { ...out, refused: `the material sacrifice for ${pp} PP is ${need} gp, and ${actor.name} has ${have} gp` };
  }
  if (variant === "communal") {
    const notMine = secondaries.filter((a) => !a.isOwner);
    if (notMine.length) return { ...out, refused: `${notMine.map((a) => a.name).join(", ")}: not yours to take PP from (the GM may lead it)` };
    const need = Math.ceil(pp * 1.5);
    const have = secondaries.reduce((sum, a) => sum + int(a.system?.resources?.pp?.value), 0);
    if (have < need) return { ...out, refused: `the communal offering for ${pp} PP is ${need} PP, and the secondaries hold ${have}` };
  }
  const L = levelOf(actor);
  out.dc = { value: h().levelDC(L) + 5, label: `Level DC (level ${L}), Very Hard +5` };
  out.skill = { key: skill, label: SKILL_LABELS[skill] ?? skill };
  const how = {
    vital: `Vital sacrifice: for each PP the degree spends, ${esc(actor.name)} takes 1d8 essence and each named secondary 1d4 (basic Fortitude); nothing reduces it.${secondaries.length ? "" : " <em>No secondary named: the GM applies theirs.</em>"}`,
    material: `Material sacrifice: the table's gold for the PP the degree spends (a Success: ${materialCost(pp)} gp), from ${esc(actor.name)}'s purse.`,
    communal: `Communal offering: the PP the degree spends, +50%, split among ${secondaries.map((a) => esc(a.name)).join(", ")}.`
  }[variant];
  out.lines.push(how);
  await setPlan(actor, { variant, secondaries: secondaries.map((a) => a.uuid), spell: spell?.uuid ?? "", at: now() }, RITUAL_FLAG);
  await payIncense();
  return out;
}

/** M30 and Q8: an Eldritch Arts Ritual spell is not capped at Success. */
export const ritualLiftsCap = ({ spell } = {}) => isEldritchArtsSpell(spell) && hasTrait(spell?.system, "ritual");

/** Q8: "never as a standard casting action". */
export function ritualSpellRefusal({ spell, ritual } = {}) {
  if (ritual || !isEldritchArtsSpell(spell) || !hasTrait(spell?.system, "ritual")) return null;
  return `${spell.name} has the Ritual trait: it may only be attempted as part of a ritual (Magic Ritual on the spell), never as a standard casting action.`;
}

/** The substituted PP, paid once the casting is settled (Q11). */
async function paySubstitute(actor, ctx) {
  const p = plan(actor, RITUAL_FLAG);
  await clearPlan(actor, RITUAL_FLAG);
  const variant = String(ctx.ritualVariant).split(":").pop();
  const pp = Math.max(0, int(ctx.ppSubstituted));
  const title = `${ctx.spell?.name ?? "Ritual"} — ${VARIANTS.find((v) => v.key === variant)?.label.replace(/ \(.*$/, "") ?? "Ritual variant"}`;
  if (!pp) return card(actor, title, [line("The degree spent no PP: nothing to substitute.")]);
  const secondaries = (p?.secondaries ?? []).map(actorByRef).filter(Boolean);
  const lines = [line(`<strong>${pp} PP</strong> substituted.`)];
  if (variant === "vital") {
    const hit = async (who, die) => {
      const out = await h().basicSaveHit({ caster: actor, target: who, save: "fortitude", dc: ownLevelDC(who), label: `${ctx.spell?.name ?? "Ritual"}: vital sacrifice (${pp}${die})`, formula: `${pp}${die}`, type: "essence", ignoreDefences: true });
      lines.push(out?.line ?? line(`${esc(who.name)}: vital sacrifice (${pp}${die}).`));
    };
    await hit(actor, "d8");
    for (const s of secondaries) await hit(s, "d4");
    if (!secondaries.length) lines.push(line("<em>Each secondary caster takes " + `${pp}d4 essence (basic Fortitude), nothing reducing it — the GM applies it.</em>`));
  } else if (variant === "material") {
    const gp = materialCost(pp);
    if (gp === null) lines.push(line(`<em>${pp} PP is beyond the table (20): the GM sets the cost.</em>`));
    else {
      const paid = await h().deductGold(actor, gp);
      lines.push(line(paid.paid ? `${esc(actor.name)} offers <strong>${gp} gp</strong> of materials.` : `<strong>${gp} gp</strong> of materials is owed — the purse is short by ${paid.shortfallGP} gp. Nothing was deducted; the GM settles it.`));
    }
  } else if (variant === "communal") {
    const shares = communalShares(pp, secondaries.length);
    if (!secondaries.length) lines.push(line(`<em>${Math.ceil(pp * 1.5)} PP is owed by the secondary casters — none was named; the GM takes it.</em>`));
    for (let i = 0; i < secondaries.length; i += 1) {
      const s = secondaries[i];
      const have = int(s.system?.resources?.pp?.value);
      const take = Math.min(have, shares[i]);
      if (s.isOwner) {
        await s.update({ "system.resources.pp.value": have - take });
        lines.push(line(`${esc(s.name)} pays <strong>${take} PP</strong>${take < shares[i] ? ` of ${shares[i]} (short by ${shares[i] - take})` : ""}.`));
      } else {
        lines.push(line(`${esc(s.name)} owes <strong>${shares[i]} PP</strong> — not yours to take; the GM takes it.`));
      }
    }
  }
  return card(actor, title, lines);
}

/* ------------------------------------------------------------------ */
/* Summoning circles                                                    */
/* ------------------------------------------------------------------ */

const circleEffect = (actor) => Array.from(actor?.effects ?? []).find((e) => e.getFlag?.(MODULE_ID, "circle") && !e.disabled) ?? null;
/** The degree of the summoning circle the caster stands in, or "" (0.11.0: the Bindings read it after the cast). */
export const circleDegreeOf = (actor) => String(circleEffect(actor)?.getFlag?.(MODULE_ID, "circle")?.degree ?? "");

/** Inscribe Summoning Circle's DC: the creature's level DC, the table's modifiers. */
export async function resolveCircleDC({ actor } = {}) {
  const twine = carried(actor, "Ward Twine");
  const chalk = carried(actor, "Void Chalk");
  const sel = (name, opts) => `<select name="${name}">${opts.map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select>`;
  const row = (label, field) => `<div class="form-group"><label>${label}</label>${field}</div>`;
  const content = `<div class="trg-prime trg-check-dialog">
    ${row("The creature's level", `<input type="number" name="level" value="1" min="1">`)}
    <p class="hint">Summoning Circle Modifiers (the DC's):</p>
    ${row("Rare or consecrated materials (−2 to −10, GM)", `<input type="number" name="rare" value="0" min="0" max="10">`)}
    ${row("Improvised or poor materials (+2 to +5)", `<input type="number" name="poor" value="0" min="0" max="5">`)}
    ${row("The ground", sel("ground", [["", "Neither"], ["aligned", "Aligned with its tradition (−4)"], ["opposed", "Opposed to its tradition (+4)"]]))}
    ${row("Its True Name", `<input type="checkbox" name="trueName"> You know it (−5)`)}
    ${row("Time taken", sel("care", [["", "10 minutes × its level"], ["haste", "In haste, less than that (+5)"], ["meticulous", "Meticulous care, double (−2)"]]))}
    ${row("Secondary casters assisting (−1 each, max −4)", `<input type="number" name="assistants" value="0" min="0" max="4">`)}
    ${row("Blood sacrifice", sel("blood", [["", "None"], ["animal", "Animal (−2)"], ["intelligent", "Intelligent (−4)"]]))}
    ${row("Disrupted or damaged during the rite", `<input type="checkbox" name="disrupted"> (+10)`)}
    ${twine ? row("Ward Twine", `<input type="checkbox" name="wardTwine" checked> Outline it with Ward Twine (+1 to its effective DC: the Save DC of Summons spells cast from it, Q12)`) : ""}
    ${chalk ? row("Void Chalk", `<input type="checkbox" name="voidChalk" checked> Draw it in Void Chalk (intact for 24 hours)`) : ""}
  </div>`;
  const form = await foundry.applications.api.DialogV2.prompt({
    window: { title: "Inscribe Summoning Circle" }, content,
    ok: { label: "Continue", callback: (event, button) => new (FDE())(button.form).object },
    rejectClose: false
  }).catch(() => null);
  if (!form) return { refused: "no circle drawn." };
  const level = Math.max(1, int(form.level));
  const rows = circleDCRows(form);
  const dc = h().levelDC(level) + rows.reduce((s, r) => s + r.value, 0);
  await setPlan(actor, { action: "inscribeSummoningCircle", level, care: form.care ?? "", wardTwine: Boolean(form.wardTwine && twine), voidChalk: Boolean(form.voidChalk && chalk), rows, at: now() });
  return { dc, label: `Creature level ${level} DC${rows.length ? `, ${rows.map((r) => `${r.label} ${r.value > 0 ? "+" : ""}${r.value}`).join(", ")}` : ""}` };
}

async function circleResolved(actor, p, k) {
  const title = `Summoning circle (creature level ${p.level})`;
  const minutes = circleMinutes(p.level, p.care);
  const cl = casterLevelOf(actor);
  const seconds = circleSeconds(cl, p.voidChalk);
  for (const old of Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, "circle"))) await old.delete();
  const say = {
    critical: "+4 circumstance on casting checks to summon and bind the creature; it takes −2 to resist binding and escaping the circle.",
    success: "+2 circumstance on casting checks to summon and bind the creature.",
    failure: "The circle is flawed: −2 circumstance on the summoning attempt.",
    fumble: "The circle destabilises: if the summoning succeeds, the creature arrives hostile and unbound."
  }[k] ?? "No circle.";
  if (!(k in CIRCLE_CHECK)) return card(actor, title, [line(say)]);
  await h().createEffectsOn(actor, [effectData("summoningCircle", {
    name: `${title}: ${k}`, img: "icons/magic/symbols/circled-gem-pink.webp",
    description: say, module: { circle: { degree: k, level: p.level, wardTwine: Boolean(p.wardTwine), voidChalk: Boolean(p.voidChalk) } },
    expiry: forSeconds(seconds)
  })]);
  return card(actor, title, [line(say),
    line(`It took <strong>${p.care === "haste" ? "less than " : ""}${minutes} minutes</strong> to draw, and lasts <strong>${seconds >= 86400 && p.voidChalk ? "24 hours (Void Chalk)" : `${Math.round(seconds / 3600)} hour${seconds === 3600 ? "" : "s"} (1 per caster level)`}</strong>.`),
    ...(p.wardTwine ? [line("Ward Twine outlines it: +1 to the Save DC of Summons spells cast from it.")] : [])]);
}

/** Spell-check gate: a circle's bonus on a Summons spell's casting check. */
export async function summoningCircleGate({ actor, spellData } = {}) {
  if (!hasTrait(spellData, "summons")) return null;
  const e = circleEffect(actor);
  const c = e?.getFlag?.(MODULE_ID, "circle");
  if (!c) return null;
  const value = CIRCLE_CHECK[c.degree] ?? 0;
  const lines = c.degree === "fumble" ? ["The summoning circle is destabilised: if this summoning succeeds, the creature arrives hostile and unbound."] : [];
  return { modifiers: value ? [{ label: `Summoning circle (${c.degree})`, value, type: "circumstance" }] : [], lines };
}

/** Casting option (required): a Critical circle's −2 to resist binding, Ward Twine's +1 (Q12). */
export const circleBindingOption = {
  offer: ({ actor, spellData, innate, itemCast } = {}) => {
    if (innate || itemCast || !hasTrait(spellData, "summons")) return null;
    const c = circleEffect(actor)?.getFlag?.(MODULE_ID, "circle");
    const dc = (c?.degree === "critical" ? 2 : 0) + (c?.wardTwine ? 1 : 0);
    if (!dc) return null;
    return { label: `Summoning circle: +${dc} Save DC`, hint: [c.degree === "critical" ? "the creature takes −2 to resist binding" : "", c.wardTwine ? "Ward Twine +1" : ""].filter(Boolean).join("; "), required: true };
  },
  apply: ({ actor } = {}) => {
    const c = circleEffect(actor)?.getFlag?.(MODULE_ID, "circle");
    const dc = (c?.degree === "critical" ? 2 : 0) + (c?.wardTwine ? 1 : 0);
    return { saveDC: dc, label: "Summoning circle", lines: dc ? [`Summoning circle: +${dc} to this spell's Save DC (the creature resisting binding).`] : [] };
  }
};

/* ------------------------------------------------------------------ */
/* True names and Spell Trickery (casting options)                      */
/* ------------------------------------------------------------------ */

export const trueNameOption = {
  offer: ({ spellData, innate, itemCast } = {}) => (innate || itemCast || !hasTrait(spellData, "summons") ? null
    : { label: "Invoke the creature's true name (+4 Save DC)", hint: "if it succeeds on its save anyway, it is permanently hostile to you" }),
  apply: () => ({ saveDC: 4, label: "True name", lines: ["True name invoked: +4 to this spell's Save DC. A creature that succeeds on its save anyway becomes permanently hostile to you."] })
};

export const spellTrickeryOption = {
  offer: ({ ritual, innate, itemCast } = {}) => (ritual || innate || itemCast ? null
    : { label: "Spell Trickery (+2 to the casting DC)", hint: "observers identify it against your Deception DC" }),
  apply: ({ actor } = {}) => {
    const dc = int(actor?.system?.skills?.deception?.dc);
    return { castingDC: 2, label: "Spell Trickery", lines: [`<strong>Spell Trickery:</strong> anyone identifying this spell rolls Sense Motive or their tradition skill against ${esc(actor?.name)}'s Deception DC <strong>${dc}</strong> (the See Through Spell Trickery action, targeting ${esc(actor?.name)}).`] };
  }
};

/**
 * A true name invoked, and the creature saved anyway: "it becomes permanently
 * hostile towards you". The effect and the card line, for one creature —
 * fed the core's cast save below, and (0.11.0) a Binding's own save, rolled
 * after the cast (Block 8 audit §5).
 */
export async function trueNameHostile(actor, target, degree) {
  await h().createEffectsOn(target, [effectData("trueNameHostility", {
    name: `Permanently hostile to ${actor.name}`, img: "icons/magic/control/fear-fright-monster-grin-red.webp",
    description: `Its true name was invoked by ${actor.name}, and it saved (${degree}): "it becomes permanently hostile towards you". Powerful beings may also mark, curse or retaliate (the GM's).`,
    module: { hostileTo: actor.uuid }
  })]);
  return line(`${esc(target.name)} saved (${esc(degree)}) against its invoked true name: it is now <strong>permanently hostile</strong> to ${esc(actor.name)}.`);
}
export const TRUE_NAME_TAIL = "<em>Powerful beings may also mark, curse, or retaliate against those who misuse their name — the GM's.</em>";

async function trueNameHostility(actor, ctx) {
  const saved = (ctx.saveResults ?? []).filter((r) => r.saved && r.target);
  if (!saved.length) return;
  const lines = [];
  for (const r of saved) lines.push(await trueNameHostile(actor, r.target, r.degree));
  lines.push(line(TRUE_NAME_TAIL));
  await card(actor, "True name", lines);
}

/* ------------------------------------------------------------------ */
/* Borrow Spell                                                         */
/* ------------------------------------------------------------------ */

const borrowLocks = (actor) => [...(actor?.getFlag?.(MODULE_ID, BORROW_FLAG) ?? [])];
const isBorrowed = (item) => Boolean(item?.getFlag?.(MODULE_ID, "borrowed") ?? item?.flags?.[MODULE_ID]?.borrowed);

/** Borrow Spell's DC: the spell's DC to learn (the Easy step is the action's). */
export async function resolveBorrowDC({ actor } = {}) {
  if (!(await h().keepsSpellbook(actor))) return { refused: "only a spellcaster who prepares spells from a spellbook may borrow one." };
  const known = new Set(Array.from(actor.items ?? []).filter((i) => i.type === "spell").map((i) => norm(i.name)));
  const locks = new Set(borrowLocks(actor).map(norm));
  // "ANOTHER CASTER'S SPELLBOOK" (review): a book caster's book entries, not a
  // monster's spell-likes nor a spell an item grants.
  const lendable = (i) => i.type === "spell" && !isBorrowed(i) && !i.system?.innate && !i.flags?.[SYSTEM_ID]?.itemCast && !known.has(norm(i.name)) && !locks.has(norm(i.name));
  const lenders = [];
  for (const a of Array.from(globalThis.game?.actors ?? [])) {
    if (a.id === actor.id || !Array.from(a.items ?? []).some(lendable)) continue;
    if (await h().keepsSpellbook(a)) lenders.push(a);
  }
  if (!lenders.length) return { refused: "no other caster's spellbook holds a spell you do not already know (or one you may try again today)." };
  const lenderId = lenders.length === 1 ? lenders[0].id : await h().chooseFromList("Borrow Spell", "Whose spellbook?", lenders.map((a) => [a.id, a.name]));
  const lender = lenders.find((a) => a.id === lenderId);
  if (!lender) return { refused: "no spellbook chosen." };
  const spells = Array.from(lender.items).filter(lendable)
    .sort((a, b) => a.name.localeCompare(b.name));
  const spellId = await h().chooseFromList("Borrow Spell", `Which of ${lender.name}'s spells?`, spells.map((s) => [s.id, `${s.name} (${int(s.system?.ppCost)} PP)`]));
  const spell = spells.find((s) => s.id === spellId);
  if (!spell) return { refused: "no spell chosen." };
  const dc = await h().learnSpellDC(spell);
  await setPlan(actor, { action: "borrowSpell", lender: lender.uuid, spell: spell.uuid, name: spell.name, at: now() });
  return { dc, label: `the DC to learn ${spell.name} (${int(spell.system?.ppCost)} PP)` };
}

async function borrowResolved(actor, p, k) {
  const title = `Borrow Spell — ${p.name}`;
  if (k === "success") {
    const source = actorByRef(p.spell) ?? (await globalThis.fromUuid?.(p.spell).catch(() => null));
    if (!source) return card(actor, title, [line("<em>The spell is gone.</em>")]);
    const data = source.toObject();
    delete data._id;
    data.system = { ...data.system, prepared: false, innate: false };
    // THE LENDER'S OWN MARKS STAY WITH THE LENDER (review): their signature,
    // a rune on their copy, who granted it to them.
    const own = { ...(data.flags?.[SYSTEM_ID] ?? {}) };
    for (const k of ["signatureSpell", "spellEffectRune", "grantedBy", "itemCast", "bookOfNotationsPick"]) delete own[k];
    data.flags = {
      ...data.flags,
      [SYSTEM_ID]: { ...own, spellBookPick: true, learnedExtra: true, grantedBy: { sourceId: null, sourceName: "Borrow Spell", requested: source.name } },
      [MODULE_ID]: { ...data.flags?.[MODULE_ID], borrowed: { from: p.lender, at: now() } }
    };
    await actor.createEmbeddedDocuments("Item", [data]);
    return card(actor, title, [line(`<strong>${esc(source.name)}</strong> is copied into your spellbook, borrowed: prepare it on the Magic tab as part of today's preparation.`), line("It leaves your book at your next daily preparation.")]);
  }
  const locks = borrowLocks(actor);
  if (!locks.map(norm).includes(norm(p.name))) locks.push(p.name);
  await actor.setFlag(MODULE_ID, BORROW_FLAG, locks);
  return card(actor, title, [line("You are unable to prepare the borrowed spell; the memorisation remains available for a different spell."), line(`You cannot try to borrow <strong>${esc(p.name)}</strong> again until you next prepare spells.`)]);
}

/* ------------------------------------------------------------------ */
/* Hooks                                                                */
/* ------------------------------------------------------------------ */

/** trgPrimeActionResolved. */
export async function onActionResolvedB2b(ctx = {}) {
  const { actor, action, degree } = ctx;
  const own = SKILL_ACTIONS.find((a) => a.key === action?.key);
  if (!own || !actor || !degree || !actor.isOwner || !own.outcomesApplied) return;
  const p = plan(actor);
  if (!p || p.action !== own.key) return;
  await clearPlan(actor);
  const k = printedDegree(own, degree);
  if (own.key === "inscribeSummoningCircle") return circleResolved(actor, p, k);
  if (own.key === "borrowSpell") return borrowResolved(actor, p, k);
}

/** trgPrimeSpellSettled: the ritual's substitute, a true name's hostility, a Fumble circle's summoning. */
export async function onSpellSettledB2b(ctx = {}) {
  const { actor } = ctx;
  if (!actor?.isOwner) return;
  if (String(ctx.ritualVariant ?? "").startsWith(`${RULES_KEY}:`)) {
    // A REFUNDED CAST PAYS NOTHING (review), its plan cleared all the same.
    if (ctx.refunded) await clearPlan(actor, RITUAL_FLAG);
    else await paySubstitute(actor, ctx);
  }
  if ((ctx.castOptions ?? []).includes("truename")) await trueNameHostility(actor, ctx);
  // NOT FOR AN ELDRITCH ARTS BINDING (0.11.0): its own card says it, once the creature is there.
  const binding = /Binding$/.test(String(ctx.spell?.flags?.[SYSTEM_ID]?.eaGrimoire ?? ""));
  if (ctx.cast && !ctx.refunded && !binding && hasTrait(ctx.spellData, "summons") && circleEffect(actor)?.getFlag?.(MODULE_ID, "circle")?.degree === "fumble") {
    await card(actor, "Summoning circle", [line("The circle was destabilised: the creature arrives <strong>hostile and unbound</strong>.")]);
  }
}

/** trgPrimeDailyPreparation: borrowed spells leave the book; the day's refusals lift. */
export async function onDailyPreparationB2b({ actor } = {}) {
  if (!actor?.isOwner) return;
  const borrowed = Array.from(actor.items ?? []).filter((i) => i.type === "spell" && isBorrowed(i));
  if (borrowed.length) await actor.deleteEmbeddedDocuments("Item", borrowed.map((i) => i.id));
  if (borrowLocks(actor).length) await actor.unsetFlag(MODULE_ID, BORROW_FLAG);
  if (borrowed.length) await card(actor, "Borrow Spell", [line(`A new day: ${borrowed.map((i) => `<strong>${esc(i.name)}</strong>`).join(", ")} ${borrowed.length === 1 ? "leaves" : "leave"} your spellbook. Borrow again after preparing, if you wish.`)]);
}

export { tokenOf, warn };
