/**
 * TRG Prime: Eldritch Arts — module entry point.
 *
 * Content is DATA in the module's compendium packs, each declaring in
 * module.json the system pack it extends (`flags.trg-prime.extends`), so
 * TRG Prime federates it into its own pickers and grants. Everything the
 * module registers with the system goes through module/registration.mjs
 * inside the system's "trgPrime.registerContent" hook, so the harness can
 * hand registration a fake API. Per-block automations attach their hooks
 * from here.
 */
import { registerContent } from "../module/registration.mjs";
import { loadCoreElection } from "../module/writer.mjs";
import { onTurnEnded, onCombatDeleted } from "../module/effects-clock.mjs";
import { registerAreaTypes } from "../module/areas.mjs";
import {
  onActionAttemptB2, onActionResolvedB2, onEffectDeletedB2, onReleaseRolledB2, onSpellSettledB2, refreshAntimagic
} from "../module/block2-automations.mjs";
import {
  onActionAttemptB1, onActionResolvedB1, onDailyPreparationB1, onEffectDeletedB1
} from "../module/block1-automations.mjs";
import { onActionResolvedB2b, onSpellSettledB2b, onDailyPreparationB2b } from "../module/block2b-automations.mjs";
import { onSpellSettledB3b, registerBlock3bSettings, registerBlock3bSocket } from "../module/block3b-automations.mjs";
import { onSpellSettledB4, onStrikeResolvedB4, onDailyPreparationB4, onItemCreatedB4, onTurnEndedB4 } from "../module/block4-automations.mjs";
import { onSpellSettledB5A, onTokenMovedB5A, onActionResolvedB5A, onDailyPreparationB5A, onDamageAppliedB5A, onItemCreatedB5A, onItemDeletedB5A, onReadyB5A, onEffectCreatedB5A, onEffectDeletedB5A, onActorUpdatedB5A } from "../module/block5a-automations.mjs";
import { onDamageAppliedB5B, onSpellSettledB5B, onItemCreatedB5B, onActorUpdatedB5B, onDailyPreparationB5B, onEffectCreatedB5B, onEffectDeletedB5B, onTokenUpdatedB5B, onTurnEndedB5B, refreshAllB5B } from "../module/block5b-automations.mjs";
import { onItemCreatedB5C, onDamageAppliedB5C, onStrikeRolledB5C, onSpellCastB5C, onTurnEndedB5C, onWorldTimeB5C, onDailyPreparationB5C } from "../module/block5c-automations.mjs";
import { onActionResolvedB5D, onSpellSettledB5D, onEffectCreatedB5D, onItemCreatedB5D } from "../module/block5d-automations.mjs";
import { onSpellSettledB6A, onItemCreatedB6A, onItemUpdatedB6A, onItemDeletedB6A, onEffectChangedB6A, onEffectDeletedB6A } from "../module/block6a-automations.mjs";
import { onSpellSettledB6B1, onTurnEndedB6B1, onTokenMovedB6B1, onDeathGuardHeldB6B1, onEffectDeletedB6B1, onEffectCreatedB6B1, onActionResolvedB6B1, onActorUpdatedB6B1, onItemCreatedB6B1 } from "../module/block6b1-automations.mjs";
import { onSpellSettledB6B2, onStrikeResolvedB6B2, onCombatTurnB6B2, onItemCreatedB6B2, onDailyPreparationB6B2 } from "../module/block6b2-automations.mjs";
import { onSpellSettledB6C, onDailyPreparationB6C, onActorUpdatedB6C, onItemUpdatedB6C, onItemCreatedB6C, onCombatDeletedB6C } from "../module/block6c-automations.mjs";
import { onSpellSettledB6D, onEffectDeletedB6D, onActionResolvedB6D, onDailyPreparationB6D } from "../module/block6d-automations.mjs";
import { onSpellSettledB6E, onDamageAppliedB6E, onDailyPreparationB6E, onItemCreatedB6E, onItemDeletedB6E, onEffectCreatedB6E, onTokenMovedB6E, onDeathGuardHeldB6E, refreshFamiliarsB6E } from "../module/block6e-automations.mjs";
import { onSpellSettledB7, onItemCreatedB7, onCombatTurnB7, onCombatSyncB7, onDeathGuardHeldB7, onStrikeResolvedB7, onEffectDeletedB7, onEffectCreatedB7, onTokenMovedB7, onTokenDeletedB7, registerBlock7Socket } from "../module/block7-automations.mjs";
import { onSpellSettledB3, onDailyPreparationB3, onActorUpdatedB3, onFamiliarMaybeDiedB3, onActorDeletedB3, onTokenMovedB3, refreshAllB3, onItemCreatedB3 } from "../module/block3-automations.mjs";
import { onSpellSettledB8a, onEffectDeletedB8a, onControlReleasedB8a, onTokenMovedB8a, onWorldTimeB8a, onActorUpdatedB8a, registerBlock8aCards } from "../module/block8a-automations.mjs";
import { onSpellSettledB8b, onTokenMovedB8b, onWorldTimeB8b, onRegionDeletedB8b, onRegionCreatedB8b, onActorUpdatedB8b, onEffectDeletedB8b, registerBlock8bCards, registerBlock8bSocket } from "../module/block8b-automations.mjs";

export const MODULE_ID = "trg-eldritch-arts";
export const REQUIRED_SYSTEM = "3.687.1";

Hooks.on("trgPrime.registerContent", (api) => registerContent(api, MODULE_ID));

// BLOCK 1 (0.1.0 on TRG Prime 3.675.0; 0.2.0, book v1.6, on 3.677.0). Chapter 4's actions: refusals
// before anything is spent (ranks, lockouts, Magic Drain's Focus use), then
// what each degree does. Elemental Symbiosis's weakness follows its
// immunity; Innate Magic's daily pick. (Null Aura's beneficial-spell save is
// the system's own since 3.677.0: the ability declares it.)
Hooks.on("trgPrimeActionAttempt", (ctx) => onActionAttemptB1(ctx));
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB1(ctx).catch((err) => console.warn("Eldritch Arts | skill action", err)); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB1(ctx).catch((err) => console.warn("Eldritch Arts | daily preparation", err)); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB1(effect).catch((err) => console.warn("Eldritch Arts | effect ended", err)); });
// The endings the system's own sweeps do not cover ("until the end of your next turn").
Hooks.on("trgPrimeTurnEnded", (ctx) => { onTurnEnded(ctx).catch((err) => console.warn("Eldritch Arts | turn end", err)); });
Hooks.on("deleteCombat", (combat) => { onCombatDeleted(combat).catch((err) => console.warn("Eldritch Arts | combat end", err)); });

// BLOCK 2 (0.3.0, on TRG Prime 3.678.0): Chapter 7's areas are Region
// Behaviours; Tap and Channel Ley Line and Tap Magical Energy; a casting in a
// Wild Magic area surges, in a Suppression area with backlash it may lash
// back; antimagic follows who stands in it.
Hooks.once("init", () => { registerAreaTypes(); registerBlock3bSettings(); });
// ONE WRITER PER GM ACCOUNT (0.12.0): the core's own election, read from its file.
Hooks.once("init", () => { loadCoreElection(); });
Hooks.on("trgPrimeActionAttempt", (ctx) => onActionAttemptB2(ctx));
// From 0.8.0 the degree after a feat's upgrade (TRG Prime 3.683.0, C10): Channel Siphoner's Partial read as a Success.
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB2({ ...ctx, degree: ctx?.resolvedDegree ?? ctx?.degree }).catch((err) => console.warn("Eldritch Arts | Block 2 action", err)); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB2(effect).catch((err) => console.warn("Eldritch Arts | siphoned essence", err)); });
Hooks.on("trgPrimeReleaseRolled", (ctx) => { onReleaseRolledB2(ctx).catch((err) => console.warn("Eldritch Arts | wild surge", err)); });
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB2(ctx).catch((err) => console.warn("Eldritch Arts | wild surge or backlash", err)); });
const antimagicSweep = () => { refreshAntimagic().catch((err) => console.warn("Eldritch Arts | antimagic", err)); };
// BLOCK 2b (0.4.0, on TRG Prime 3.679.0): the circle and Borrow Spell resolved;
// a ritual's substitute paid, a true name's hostility and a Fumble circle's
// summoning once the casting is settled; borrowed spells leave at a new day.
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB2b(ctx).catch((err) => console.warn("Eldritch Arts | Block 2b action", err)); });
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB2b(ctx).catch((err) => console.warn("Eldritch Arts | ritual, true name or circle", err)); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB2b(ctx).catch((err) => console.warn("Eldritch Arts | borrowed spells", err)); });

// BLOCK 3a (0.5.0, fixed in 0.5.1, on TRG Prime 3.680.0): Wild Power's surge and daily spell;
// the Soulbound Familiar's daily bonus, its range and its severed bond; Ley
// Tap's range; Umbral Affinity's Darkness cast as a specialist spell.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB3(ctx).catch((err) => console.warn("Eldritch Arts | Wild Power", err)); });
// BLOCK 3b (0.6.0): Prophetic Warning cast from the sheet arms the next check.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB3b(ctx).catch((err) => console.warn("Eldritch Arts | Prophetic Warning", err)); });
// …and a hex's hour of immunity on a creature the Witch's client does not own, written by the GM.
Hooks.once("ready", () => registerBlock3bSocket());
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB3(ctx).catch((err) => console.warn("Eldritch Arts | Block 3 daily preparation", err)); });
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB3(actor, change).catch((err) => console.warn("Eldritch Arts | Soulbound Familiar", err)); });
// A familiar's death by Dying is an effect, not an HP change (0.5.1).
const effectOwner = (effect) => (effect?.parent?.documentName === "Actor" ? effect.parent : effect?.parent?.parent ?? null);
for (const hook of ["createActiveEffect", "updateActiveEffect"]) {
  Hooks.on(hook, (effect) => { onFamiliarMaybeDiedB3(effectOwner(effect)).catch((err) => console.warn("Eldritch Arts | Soulbound Familiar", err)); });
}
Hooks.on("trgPrimeCreatureSlain", (ctx) => { onFamiliarMaybeDiedB3(ctx?.victim).catch((err) => console.warn("Eldritch Arts | Soulbound Familiar", err)); });
Hooks.on("deleteActor", (actor) => { onActorDeletedB3(actor).catch((err) => console.warn("Eldritch Arts | Soulbound Familiar", err)); });
Hooks.on("createItem", (item) => { onItemCreatedB3(item).catch((err) => console.warn("Eldritch Arts | Umbral Affinity", err)); });
Hooks.on("updateToken", (doc, change) => { if ("x" in change || "y" in change) onTokenMovedB3(doc).catch((err) => console.warn("Eldritch Arts | Ley Tap or familiar range", err)); });
Hooks.on("canvasReady", () => { refreshAllB3().catch((err) => console.warn("Eldritch Arts | Block 3 ranges", err)); });

// BLOCK 4 (0.7.0, on TRG Prime 3.682.0): the Spellblade's spells, paths and
// Infuse Weapon; the Warlock's Xithra, bonded soul and picks.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB4(ctx).catch((err) => console.warn("Eldritch Arts | Block 4 spell", err)); });
Hooks.on("trgPrimeStrikeResolved", (ctx) => { onStrikeResolvedB4(ctx).catch((err) => console.warn("Eldritch Arts | Sacred Channel or Arcane Echo", err)); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB4(ctx).catch((err) => console.warn("Eldritch Arts | Block 4 daily preparation", err)); });
Hooks.on("createItem", (item) => { onItemCreatedB4(item).catch((err) => console.warn("Eldritch Arts | Xithra or hex", err)); });
Hooks.on("trgPrimeTurnEnded", (ctx) => { onTurnEndedB4(ctx).catch((err) => console.warn("Eldritch Arts | Shooting Star's trail", err)); });

// BLOCK 5 (0.8.0, on TRG Prime 3.683.0): Chapter 5's racial and general feats.
const warnB5 = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);
// 5A: Aetherial, and the racial feats of the other races.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB5A(ctx).catch(warnB5("Aetherial feat (spell)")); });
Hooks.on("updateToken", (doc, change, options, userId) => { onTokenMovedB5A(doc, change, options, userId).catch(warnB5("Aetherial feat (token)")); });
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB5A(ctx).catch(warnB5("Aetherial feat (action)")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB5A(ctx).catch(warnB5("Racial feat (daily preparation)")); });
Hooks.on("trgPrimeDamageApplied", (payload) => { onDamageAppliedB5A(payload).catch(warnB5("Racial feat (damage)")); });
Hooks.on("createItem", (item) => { onItemCreatedB5A(item).catch(warnB5("Racial feat (item)")); });
Hooks.on("deleteItem", (item) => { onItemDeletedB5A(item).catch(warnB5("Racial feat (item removed)")); });
Hooks.once("ready", () => { onReadyB5A().catch(warnB5("Racial feats (ready)")); });
Hooks.on("createActiveEffect", (effect) => { onEffectCreatedB5A(effect).catch(warnB5("Racial feat (effect)")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB5A(effect).catch(warnB5("Racial feat (effect ended)")); });
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB5A(actor, change).catch(warnB5("Racial feat (actor)")); });
// 5B: Emberkin and Nyrinn.
Hooks.on("trgPrimeDamageApplied", (ctx) => { onDamageAppliedB5B(ctx).catch(warnB5("Emberkin/Nyrinn feat (damage)")); });
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB5B(ctx).catch(warnB5("Emberkin/Nyrinn feat (spell)")); });
Hooks.on("createItem", (item) => { onItemCreatedB5B(item).catch(warnB5("Emberkin/Nyrinn feat (item)")); });
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB5B(actor, change).catch(warnB5("Emberkin/Nyrinn feat (actor)")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB5B(ctx).catch(warnB5("Emberkin/Nyrinn feat (daily preparation)")); });
Hooks.on("createActiveEffect", (effect) => { onEffectCreatedB5B(effect).catch(warnB5("Emberkin/Nyrinn feat (effect)")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB5B(effect).catch(warnB5("Emberkin/Nyrinn feat (effect ended)")); });
Hooks.on("updateToken", (doc, change) => { onTokenUpdatedB5B(doc, change).catch(warnB5("Emberkin/Nyrinn feat (token)")); });
Hooks.on("trgPrimeTurnEnded", (ctx) => { onTurnEndedB5B(ctx).catch(warnB5("Emberkin/Nyrinn feat (turn end)")); });
Hooks.on("canvasReady", () => { refreshAllB5B().catch(warnB5("Shadow Initiate's light")); });
const refreshB5B = () => { refreshAllB5B().catch(warnB5("Shadow Initiate's light")); };
for (const hook of ["createAmbientLight", "updateAmbientLight", "deleteAmbientLight", "createRegion", "updateRegion", "deleteRegion"]) Hooks.on(hook, refreshB5B);
// 5C: Scaelyn.
Hooks.on("createItem", (item) => { onItemCreatedB5C(item).catch(warnB5("Scaelyn feat (item)")); });
Hooks.on("trgPrimeDamageApplied", (ctx) => { onDamageAppliedB5C(ctx).catch(warnB5("Ember Handed")); });
Hooks.on("trgPrimeStrikeRolled", (ctx) => { onStrikeRolledB5C(ctx).catch(warnB5("Ghostscale")); });
Hooks.on("trgPrimeSpellCast", (ctx) => { onSpellCastB5C(ctx).catch(warnB5("Ghostscale")); });
Hooks.on("trgPrimeTurnEnded", (ctx) => { onTurnEndedB5C(ctx).catch(warnB5("Ghostscale")); });
Hooks.on("updateWorldTime", (worldTime) => { onWorldTimeB5C(worldTime).catch(warnB5("Ghostscale")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB5C(ctx).catch(warnB5("Ghostscale")); });
// 5D: General feats. Its action handler is wired after Block 2b's (above): it
// reads Block 2b's plan synchronously, before Block 2b's awaits clear it.
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB5D(ctx).catch(warnB5("General feat (action)")); });
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB5D(ctx).catch(warnB5("General feat (spell)")); });
Hooks.on("createActiveEffect", (effect, options, userId) => { onEffectCreatedB5D(effect, options, userId).catch(warnB5("General feat (effect)")); });
Hooks.on("createItem", (item, options, userId) => { onItemCreatedB5D(item, options, userId).catch(warnB5("General feat (item)")); });

// BLOCK 6 (0.9.0, on TRG Prime 3.684.0): Chapter 5's archetypes and class
// feats, and the module's metamagic. After Block 4's createItem (6E writes
// Xithra's damage-type offer after Block 4 does) and after Block 2b's
// action handler (6B1 reads Block 2's plan synchronously, as 5D does).
const warnB6 = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);
// 6A: the Pacts, Hex Weaver, Bloodmage, High Mage, Birthrager, Blood of the Wyrm.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB6A(ctx).catch(warnB6("Archetype (spell)")); });
Hooks.on("createItem", (item) => { onItemCreatedB6A(item).catch(warnB6("Archetype (item)")); });
Hooks.on("updateItem", (item, change) => { onItemUpdatedB6A(item, change).catch(warnB6("Archetype (item changed)")); });
Hooks.on("deleteItem", (item) => { onItemDeletedB6A(item).catch(warnB6("Archetype (item removed)")); });
for (const hook of ["createActiveEffect", "updateActiveEffect"]) Hooks.on(hook, (effect) => { onEffectChangedB6A(effect).catch(warnB6("Archetype (effect)")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB6A(effect).catch(warnB6("Archetype (effect ended)")); });
// 6B1: Eternal Vigil, Fatespinner, Ferromancer, Leyline Weaver, Runeblade.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB6B1(ctx).catch(warnB6("Archetype feat (spell)")); });
Hooks.on("trgPrimeTurnEnded", (ctx) => { onTurnEndedB6B1(ctx).catch(warnB6("Archetype feat (turn end)")); });
Hooks.on("updateToken", (doc, change) => { onTokenMovedB6B1(doc, change).catch(warnB6("Shard Cloud")); });
Hooks.on("trgPrimeDeathGuardHeld", (ctx) => { onDeathGuardHeldB6B1(ctx).catch(warnB6("Eternal Vigil")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB6B1(effect).catch(warnB6("Archetype feat (effect ended)")); });
Hooks.on("createActiveEffect", (effect) => { onEffectCreatedB6B1(effect).catch(warnB6("Archetype feat (effect)")); });
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB6B1(ctx).catch(warnB6("Archetype feat (action)")); });
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB6B1(actor, change).catch(warnB6("Archetype feat (actor)")); });
Hooks.on("createItem", (item) => { onItemCreatedB6B1(item).catch(warnB6("Archetype feat (item)")); });
// 6B2: Runebreaker, Shade Master, Spellwarden, Spell Duellist, Spell Weaver, Stormcaller.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB6B2(ctx).catch(warnB6("Archetype feat (spell)")); });
Hooks.on("trgPrimeStrikeResolved", (ctx) => { onStrikeResolvedB6B2(ctx).catch(warnB6("Spell Duellist")); });
Hooks.on("updateCombat", (combat, change) => { onCombatTurnB6B2(combat, change).catch(warnB6("Eye of the Storm")); });
Hooks.on("createItem", (item) => { onItemCreatedB6B2(item).catch(warnB6("Archetype feat (item)")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB6B2(ctx).catch(warnB6("Archetype feat (daily preparation)")); });
// 6C: the Runemage's, Sorcerer's and Spellblade's class feats.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB6C(ctx).catch(warnB6("Class feat (spell)")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB6C(ctx).catch(warnB6("Class feat (daily preparation)")); });
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB6C(actor, change).catch(warnB6("Class feat (actor)")); });
Hooks.on("updateItem", (item, change) => { onItemUpdatedB6C(item, change).catch(warnB6("Bonded Infusion")); });
Hooks.on("createItem", (item) => { onItemCreatedB6C(item).catch(warnB6("Class feat (item)")); });
Hooks.on("deleteCombat", (combat) => { onCombatDeletedB6C(combat).catch(warnB6("Class feat (combat end)")); });
// 6D: metamagic and Adept feats.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB6D(ctx).catch(warnB6("Metamagic (spell)")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB6D(effect).catch(warnB6("Lightning Rod")); });
Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB6D(ctx).catch(warnB6("Piercing Insight")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB6D(ctx).catch(warnB6("Resonant Conduit")); });
// 6E: the Warlock's and Witch's class feats.
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB6E(ctx).catch(warnB6("Warlock/Witch feat (spell)")); });
Hooks.on("trgPrimeDamageApplied", (payload) => { onDamageAppliedB6E(payload).catch(warnB6("Warlock/Witch feat (damage)")); });
Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB6E(ctx).catch(warnB6("Warlock/Witch feat (daily preparation)")); });
Hooks.on("createItem", (item) => { onItemCreatedB6E(item).catch(warnB6("Warlock/Witch feat (item)")); });
Hooks.on("deleteItem", (item) => { onItemDeletedB6E(item).catch(warnB6("Warlock/Witch feat (item removed)")); });
Hooks.on("createActiveEffect", (effect) => { onEffectCreatedB6E(effect).catch(warnB6("Warlock/Witch feat (effect)")); });
Hooks.on("updateToken", (doc, change) => { onTokenMovedB6E(doc, change).catch(warnB6("Symbiotic Witch")); });
Hooks.on("trgPrimeDeathGuardHeld", (ctx) => { onDeathGuardHeldB6E(ctx).catch(warnB6("Pact Ascendant")); });
// Only the familiar's range (Extra Bond, Ethereal Insight): Xithra and Pact Ascendant are written on item events and Uses, never at load.
Hooks.once("ready", () => { refreshFamiliarsB6E().catch(warnB6("Familiar range (ready)")); });
Hooks.on("canvasReady", () => { refreshFamiliarsB6E().catch(warnB6("Familiar range")); });

// BLOCK 7 (0.10.0, on TRG Prime 3.685.0): the first half of the Grimoire.
const warnB7 = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB7(ctx).catch(warnB7("Grimoire spell (settled)")); });
Hooks.on("createItem", (item) => { onItemCreatedB7(item).catch(warnB7("Grimoire spell (its type)")); });
Hooks.on("updateCombat", (combat, change) => { onCombatTurnB7(combat, change).catch(warnB7("Primal Snap")); });
Hooks.on("trgPrimeDeathGuardHeld", (ctx) => { onDeathGuardHeldB7(ctx).catch(warnB7("Arcane Bastion")); });
Hooks.on("trgPrimeStrikeResolved", (ctx) => { onStrikeResolvedB7(ctx).catch(warnB7("Spirit Arrow or Panic Transposition")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB7(effect).catch(warnB7("Spirit Arrow")); });
Hooks.on("createActiveEffect", (effect) => { onEffectCreatedB7(effect).catch(warnB7("Zone Disruption")); });
Hooks.on("updateToken", (doc, change) => { onTokenMovedB7(doc, change).catch(warnB7("Metamagic Resonance or Chronoweave")); });
Hooks.on("updateCombat", (combat, change) => { onCombatSyncB7(combat, change).catch(warnB7("Metamagic Resonance or Chronoweave")); });
Hooks.on("deleteToken", (doc) => { onTokenDeletedB7(doc).catch(warnB7("Metamagic Resonance or Chronoweave")); });
// Writes on a creature this client does not own, and work for a creature's owner (a teleport's click).
Hooks.once("ready", () => registerBlock7Socket());

// BLOCK 8a (0.11.0, on TRG Prime 3.686.0): the Bindings, the Symbols and the utilities.
const warnB8a = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB8a(ctx).catch(warnB8a("Grimoire spell (Block 8a)")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB8a(effect).catch(warnB8a("a Binding's end")); });
Hooks.on("trgPrimeControlReleased", (payload) => { onControlReleasedB8a(payload).catch(warnB8a("a bound creature breaking free")); });
Hooks.on("updateToken", (doc, change, options) => { onTokenMovedB8a(doc, change, options).catch(warnB8a("a rift, a rune or a symbol")); });
Hooks.on("updateWorldTime", () => { onWorldTimeB8a().catch(warnB8a("the Block 8a areas")); });
// A dismissed symbol's Region goes with its cast (the core fires no spell-end hook; its registry is a flag).
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB8a(actor, change).catch(warnB8a("a dismissed symbol")); });
// The GM's and the caster's buttons on the Block 8a cards.
Hooks.once("ready", () => registerBlock8aCards());
// BLOCK 8b (0.12.0, on TRG Prime 3.687.0): the rituals and Chapter 7's High Magic spells.
const warnB8b = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);
Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB8b(ctx).catch(warnB8b("Grimoire spell (Block 8b)")); });
Hooks.on("updateToken", (doc, change) => { onTokenMovedB8b(doc, change).catch(warnB8b("a ritual's zone")); });
Hooks.on("updateWorldTime", () => { onWorldTimeB8b().catch(warnB8b("the Block 8b areas")); });
Hooks.on("createRegion", (region) => { onRegionCreatedB8b(region).catch(warnB8b("a ritual's zone's first members")); });
Hooks.on("updateActor", (actor, change) => { onActorUpdatedB8b(actor, change).catch(warnB8b("a cast-bound zone whose cast ended")); });
Hooks.on("deleteRegion", (region) => { onRegionDeletedB8b(region).catch(warnB8b("a ritual's zone ending")); });
Hooks.on("deleteActiveEffect", (effect) => { onEffectDeletedB8b(effect).catch(warnB8b("Soul Confluence, a mimic's imprint or a raised undead")); });
Hooks.once("ready", () => { registerBlock8bCards(); registerBlock8bSocket(); });

Hooks.on("canvasReady", () => { refreshAntimagic({ announce: false }).catch((err) => console.warn("Eldritch Arts | antimagic", err)); });
Hooks.on("updateToken", (doc, change) => { if ("x" in change || "y" in change || "elevation" in change) antimagicSweep(); });
for (const hook of ["createToken", "deleteToken", "createRegion", "updateRegion", "deleteRegion", "createRegionBehavior", "updateRegionBehavior", "deleteRegionBehavior"]) Hooks.on(hook, antimagicSweep);

Hooks.once("ready", () => {
  if (game.system?.id !== "trg-prime") {
    console.warn("Eldritch Arts | this module needs the TRG Prime system.");
    return;
  }
  if (!game.trgPrime?.modules) {
    ui.notifications?.error("Eldritch Arts needs TRG Prime with its companion-module API.");
    return;
  }
  if (foundry.utils.isNewerVersion(REQUIRED_SYSTEM, game.system.version)) {
    ui.notifications?.warn(`Eldritch Arts expects TRG Prime ${REQUIRED_SYSTEM} or later (installed: ${game.system.version}). Its automation needs that version's module API.`);
  }
});
