#!/usr/bin/env node
/**
 * mutate-block5d — the mutation half of verify-block5d. Each mutation breaks
 * one printed number, one reading or one wire of Block 5 group D;
 * verify-block5d must fail on every one. Files are restored after each run,
 * and on any exit.
 *
 * IT REWRITES FILES IN PLACE: run it on a copy of the module tree, never in a
 * shared one.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block5d.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block5-d.mjs"), A = f("module", "block5d-automations.mjs"), B1 = f("tools", "content", "block1.mjs");

const MUTATIONS = [
  // A — the feats
  { name: "a Catalyst card claims automation", file: C, from: "const BLOCK9 = (what) => `*Not yet automated:* catalysts", to: "const BLOCK9 = (what) => `*Automated (0.8.0):* catalysts" },
  { name: "Spell Thief is graded B", file: C, from: "\"Spell Thief\": { level: \"C\"", to: "\"Spell Thief\": { level: \"B\"" },
  { name: "Dispel Power loses its Focus trait", file: C, from: "doc.system.traits = doc.system.traits ? `${doc.system.traits}, Focus` : \"Focus\";", to: "doc.system.traits = doc.system.traits;" },
  { name: "Dispel Power arrives spent", file: C, from: "  doc.system.usesValue = 1;", to: "  doc.system.usesValue = 0;" },
  { name: "Threadcutter is not repeatable", file: C, from: "generalFeat(\"THREADCUTTER\", {\n    repeatable: true,", to: "generalFeat(\"THREADCUTTER\", {" },
  { name: "Ley Channeler's reroll is not once a day", file: C, from: "generalFeat(\"LEY CHANNELER\", {\n    usesPerDay: \"1\",", to: "generalFeat(\"LEY CHANNELER\", {" },
  { name: "Expert's extra reroll is unlimited", file: C, from: "generalFeat(\"ESOTERIC INSIGHT EXPERT\", {\n    usesPerDay: \"1\",", to: "generalFeat(\"ESOTERIC INSIGHT EXPERT\", {" },
  { name: "Q81 undone: Master's reroll once a day", file: C, from: "generalFeat(\"ESOTERIC INSIGHT MASTER\", {", to: "generalFeat(\"ESOTERIC INSIGHT MASTER\", {\n    usesPerDay: \"1\"," },
  // B — the declarations
  { name: "the Esoteric rerolls are reactions", file: C, from: "checkTypes: [\"skill\"], reaction: false, subjects: [\"arcana\", \"occultism\"]", to: "checkTypes: [\"skill\"], reaction: true, subjects: [\"arcana\", \"occultism\"]" },
  { name: "Expert's +2 meets Fire, not Emotion", file: C, from: "traits: [\"shadow\", \"emotion\"]", to: "traits: [\"shadow\", \"fire\"]" },
  { name: "Ley Scholar's +2 reaches Ley Sense", file: C, from: "auto: true, when: { actions: [\"tapLeyLine\", \"channelLeyLine\"] } })", to: "auto: true, when: { actions: [\"tapLeyLine\", \"channelLeyLine\", \"leySense\"] } })" },
  { name: "Lorekeeper's tick is on every skill", file: C, from: "when: { checkTypes: [\"specialist\"] }", to: "when: { checkTypes: [\"skill\"] }" },
  { name: "Magic Sense is halved as a special sense", file: C, from: "sense: { category: \"tertiary\", name: \"Magic Sense\",", to: "sense: { category: \"tertiary\", special: true, name: \"Magic Sense\"," },
  { name: "Master Binder adds 1 control level", file: C, from: "controlLevelBonus: 2,", to: "controlLevelBonus: 1," },
  { name: "Silent Spellstrike declares nothing", file: C, from: "flags: { spellSniping: true },", to: "flags: {}," },
  { name: "Runespeaker's tick misses Identify Power", file: C, from: "when: { actions: [\"decipherWriting\", \"identifyPower\"] }", to: "when: { actions: [\"decipherWriting\"] }" },
  { name: "Wanderer’s Sense's aura reaches 30 ft", file: C, from: "auras: [{ kind: \"ally\", radius: 10,", to: "auras: [{ kind: \"ally\", radius: 30," },
  { name: "Wanderer’s Sense's +2 is not the owner's", file: C, from: "        conditional({ ...WANDERERS_SENSE_SAVE })\n", to: "" },
  { name: "Esoteric Insight's tick back on Identify Power (C11)", file: B1, from: "auto: false, when: { actions: [\"spellRecognition\"] } })", to: "auto: false, when: { actions: [\"identifyPower\"] } })" },
  // C — the rules
  { name: "Channel Siphoner upgrades a Failure", file: A, from: "from: \"partial\", to: \"success\" })])", to: "from: \"failure\", to: \"success\" })])" },
  { name: "Spirit Resources forgets Request", file: A, from: "[\"gatherInformation\", \"makeAnImpression\", \"request\"]", to: "[\"gatherInformation\", \"makeAnImpression\"]" },
  { name: "Threadcutter substitutes the wrong action", file: A, from: "Object.freeze([Object.freeze({ action: \"dispel\", skill })])", to: "Object.freeze([Object.freeze({ action: \"counteract\", skill })])" },
  { name: "Magus Appraiser's ten minutes give +0", file: A, from: "{ key: \"tenMinutes\", label: \"10 minutes\", modifier: 2, apCost: \"10 minutes\" }", to: "{ key: \"tenMinutes\", label: \"10 minutes\", modifier: 0, apCost: \"10 minutes\" }" },
  { name: "Rapid Binder keeps the −5", file: A, from: "label: \"Outside daily preparation (Rapid Binder: no penalty)\", modifier: 0,", to: "label: \"Outside daily preparation (Rapid Binder: no penalty)\", modifier: -5," },
  { name: "n5 undone: Success lasts the spell's 1 minute", file: A, from: "  if (k === \"success\") return 660;", to: "  if (k === \"success\") return 60;" },
  { name: "the Critical stays 30 minutes", file: A, from: "  if (k === \"critical\") return 3600;", to: "  if (k === \"critical\") return 1800;" },
  { name: "every subject is a spellcaster", file: A, from: "?? actor?.system?.magic?.casterLevel) >= 1;", to: "?? actor?.system?.magic?.casterLevel) >= 0;" },
  { name: "Ley Channeler's Critical is 1d4", file: A, from: "if (k === \"critical\" || k === \"heroic\") return \"2d4\";", to: "if (k === \"critical\" || k === \"heroic\") return \"1d4\";" },
  { name: "Q83 undone: a Partial is rerolled", file: A, from: "[\"failure\", \"fumble\", \"blunder\"].includes(norm(degree));", to: "[\"partial\", \"failure\", \"fumble\", \"blunder\"].includes(norm(degree));" },
  { name: "the reservoir forgets what it holds", file: A, from: "const room = Math.max(0, int(ranks) - Math.max(0, int(held)));", to: "const room = Math.max(0, int(ranks));" },
  { name: "Circle Adept does not halve", file: A, from: "Math.ceil(circleMinutes(level, care) / 2)", to: "circleMinutes(level, care)" },
  { name: "Dispel Power's results are retyped", file: A, from: "success: \"You suppress the effect for 1 minute, after which", to: "success: \"You suppress the effect for 10 minutes, after which" },
  { name: "Q84 undone: Dispel Power spends PP", file: A, from: "    ppReplace: cl,\n", to: "" },
  { name: "Dispel Power is Hard", file: A, from: "    difficulty: \"veryHard\",", to: "    difficulty: \"hard\"," },
  { name: "Dispel Power spends no Focus use", file: A, from: "    focus: true,\n    itemId: item.id", to: "    focus: false,\n    itemId: item.id" },
  { name: "Dispel Power is always applied", file: A, from: "hint: \"this feat's results replace Dispel's; its Focus use is spent when you roll\",\n    optional: true,", to: "hint: \"this feat's results replace Dispel's; its Focus use is spent when you roll\",\n    optional: false," },
  { name: "Mirrored Rebuke is offered on any Dispel", file: A, from: "if (!isCounterSpellDispel(ctx) || !hasFeat(ctx.actor, FEATS.mirroredRebuke)) return null;", to: "if (!hasFeat(ctx.actor, FEATS.mirroredRebuke)) return null;" },
  { name: "review undone: Mirrored Rebuke rides Disrupting Magic's counter", file: A, from: "(ctx.presetDispel ? ctx.presetDispel.eaCounterSpell === true : true)", to: "true" },
  { name: "the step's counter is not marked Counter Spell's", file: A, from: "counterSpell: true, eaCounterSpell: true }", to: "counterSpell: true }" },
  { name: "review undone: a Disrupting Magic reactor is asked twice", file: A, from: "    if (await askedByDisruptingMagic(reactor, reactorToken, casterToken)) continue;\n", to: "" },
  { name: "Disrupting Magic's reach is forgotten", file: A, from: "if (d === null || d > 120) return false;", to: "if (d === null) return false;" },
  { name: "the rune is offered on any cast", file: A, from: "offer: (ctx = {}) => (ctx.highMagic && hasFeat(ctx.actor, FEATS.runicStabiliser)", to: "offer: (ctx = {}) => (hasFeat(ctx.actor, FEATS.runicStabiliser)" },
  { name: "the rune costs no AP", file: A, from: "apply: () => ({ ap: 1,", to: "apply: () => ({ ap: 0," },
  { name: "the remap needs no rune", file: A, from: "if (!taken || !ctx.highMagic || norm(ctx.degree) !== \"partial\") return null;", to: "if (!ctx.highMagic || norm(ctx.degree) !== \"partial\") return null;" },
  { name: "Masked Caster keeps the +2", file: A, from: "return { ...o, castingDC: 1, label: \"Spell Trickery (Masked Caster)\"", to: "return { ...o, castingDC: 2, label: \"Spell Trickery (Masked Caster)\"" },
  { name: "Q82 undone: Archsage adds no seat", file: A, from: "    out.seats = 1;", to: "    out.seats = 0;" },
  { name: "Lorekeeper's ritual bonus is +1", file: A, from: "out.modifiers.push({ label: FEATS.lorekeeper, value: 2, type: \"class\" });", to: "out.modifiers.push({ label: FEATS.lorekeeper, value: 1, type: \"class\" });" },
  { name: "n1 undone: Archsage's advantage is automatic", file: A, from: "auto: false, oneShot: true, when: { checkTypes: [\"save\"] } }];", to: "auto: true, oneShot: true, when: { checkTypes: [\"save\"] } }];" },
  { name: "Master's +2 is against anyone", file: A, from: "when: casterUuid ? { checkTypes: [\"save\"], sourceUuids: [casterUuid] } : { checkTypes: [\"save\"] }", to: "when: { checkTypes: [\"save\"] }" },
  { name: "the journey's bonus is circumstance", file: A, from: "type: \"luck\", label: FEATS.wanderersMastery, scope: \"Saving throws against magical effects (a spell's)\"", to: "type: \"circumstance\", label: FEATS.wanderersMastery, scope: \"Saving throws against magical effects (a spell's)\"" },
  // E — the Foundry side
  { name: "the journey is not once a week", file: A, from: "    if (until > now()) return warn(", to: "    if (false) return warn(" },
  { name: "the journey leaves the companions out", file: A, from: "    const who = [actor, ...companions];", to: "    const who = [actor];" },
  { name: "Wanderer’s Sense is not once a day", file: A, from: "if (!(usesLeft(item) > 0)) return warn(\"Wanderer’s Sense:", to: "if (false) return warn(\"Wanderer’s Sense:" },
  { name: "two Threadcutter copies take one skill", file: A, from: "    const open = THREADCUTTER_SKILLS.filter(([k]) => !taken.has(k));", to: "    const open = THREADCUTTER_SKILLS;" },
  { name: "Threadcutter keeps the old ability", file: A, from: "    if (old.length) await actor.deleteEmbeddedDocuments(\"Item\", old);", to: "" },
  { name: "Ley Channeler rerolls any action", file: A, from: "if (!actor?.isOwner || ctx.check?.actionKey !== \"tapLeyLine\" || !leyChannelerRerolls(ctx.degree)) return null;", to: "if (!actor?.isOwner || !leyChannelerRerolls(ctx.degree)) return null;" },
  { name: "Ley Channeler's reroll spends no use", file: A, from: "    if (!(await spendUse(feat))) return null;\n    return { reroll: true, label: FEATS.leyChanneler", to: "    return { reroll: true, label: FEATS.leyChanneler" },
  { name: "Ley Channeler's PP are uncapped", file: A, from: "const after = Math.min(max, value + int(roll.total));\n      await actor.update({ \"system.resources.pp.value\": after });\n      await card(actor, \"Ley Channeler\"", to: "const after = value + int(roll.total);\n      await actor.update({ \"system.resources.pp.value\": after });\n      await card(actor, \"Ley Channeler\"" },
  { name: "Master's +2 follows a plain Success", file: A, from: "if (hasFeat(actor, FEATS.master) && CRITICALS.includes(norm(ctx.degree))) {", to: "if (hasFeat(actor, FEATS.master) && SUCCESSES.includes(norm(ctx.degree))) {" },
  { name: "Expert's tradition line is lost", file: A, from: "if (hasFeat(actor, FEATS.expert)) said.push(", to: "if (false) said.push(" },
  { name: "Archsage answers any skill", file: A, from: "norm(ctx.subject) !== \"arcana\" || ", to: "" },
  { name: "Archsage answers any cast", file: A, from: "if (!actor?.isOwner || !ctx.ritual || !CRITICALS", to: "if (!actor?.isOwner || !CRITICALS" },
  { name: "Archsage's hour is ten minutes", file: A, from: "    expiry: forSeconds(3600)\n  });\n  return `<strong>Archsage Command</strong>", to: "    expiry: forSeconds(600)\n  });\n  return `<strong>Archsage Command</strong>" },
  { name: "a fresh effect doubles the old", file: A, from: "  if (old.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", old).catch(() => {});", to: "" },
  { name: "Memory Recall's PP on a Partial", file: A, from: "if (!hasFeat(actor, FEATS.savant) || !SUCCESSES.includes(raw) || !targetActor", to: "if (!hasFeat(actor, FEATS.savant) || !targetActor" },
  { name: "Memory Recall's PP to a non-caster", file: A, from: "|| !targetActor || !isSpellcaster(targetActor)) return;", to: "|| !targetActor) return;" },
  { name: "Hypnotic Savant's card without the feat", file: A, from: "const seconds = hasFeat(actor, FEATS.savant) ? savantSuggestionSeconds(raw) : null;", to: "const seconds = savantSuggestionSeconds(raw);" },
  { name: "Circle Adept forgets Block 2b's plan", file: A, from: "const circlePlan = key === \"inscribeSummoningCircle\" ? actor.getFlag?.(MODULE_ID, B2B_PLAN_FLAG) ?? null : null;", to: "const circlePlan = null;" },
  { name: "Magus Appraiser's Critical is public", file: A, from: "await gmCard(actor, \"Magus Appraiser\"", to: "await card(actor, \"Magus Appraiser\"" },
  { name: "Magus Appraiser answers a Success", file: A, from: "if (!CRITICALS.includes(raw) || !hasFeat(actor, FEATS.magusAppraiser)) return;", to: "if (!SUCCESSES.includes(raw) || !hasFeat(actor, FEATS.magusAppraiser)) return;" },
  { name: "Rapid Binder answers a Failure", file: A, from: "if (!SUCCESSES.includes(raw) || !hasFeat(actor, FEATS.rapidBinder)) return;", to: "if (!hasFeat(actor, FEATS.rapidBinder)) return;" },
  { name: "Masked Caster answers a Fumble", file: A, from: "key === \"seeThroughSpellTrickery\" && raw === \"blunder\"", to: "key === \"seeThroughSpellTrickery\" && raw !== \"success\"" },
  { name: "Spell Thief's free copy on a Success", file: A, from: "if (key === \"borrowSpell\" && actor.isOwner && CRITICALS.includes(raw)", to: "if (key === \"borrowSpell\" && actor.isOwner && SUCCESSES.includes(raw)" },
  { name: "Spell Thief keeps two free copies", file: A, from: "    await old.update({ [`flags.${SYSTEM_ID}.memorisationFree`]: false, \"system.prepared\": false });", to: "" },
  { name: "Spell Thief's free copy is not prepared", file: A, from: "await item.update({ [`flags.${SYSTEM_ID}.memorisationFree`]: true, \"system.prepared\": true });", to: "await item.update({ [`flags.${SYSTEM_ID}.memorisationFree`]: true, \"system.prepared\": false });" },
  { name: "the reservoir holds for a round", file: A, from: "  const minute = forSeconds(60);", to: "  const minute = forSeconds(6);" },
  { name: "the reservoir's excess vanishes", file: A, from: "    await actor.createEmbeddedDocuments(\"ActiveEffect\", [data]);", to: "" },
  { name: "the excess counts from the old pool", file: A, from: "siphon: excess, before: before + stored,", to: "siphon: excess, before," },
  { name: "every client rewrites the essence", file: A, from: "  if (userId && globalThis.game?.user?.id && userId !== game.user.id) return;\n  const actor = effect.parent;", to: "  const actor = effect.parent;" },
  { name: "the excess is taken in again", file: A, from: "if (effect.getFlag(MODULE_ID, \"eaReservoir\") || effect.getFlag(MODULE_ID, \"eaReservoirExcess\")) return;", to: "if (effect.getFlag(MODULE_ID, \"eaReservoir\")) return;" },
  { name: "an ally is asked to counter", file: A, from: "    if (allies(side(reactorToken), side(casterToken))) continue;", to: "" },
  { name: "the counter is not Counter Spell's", file: A, from: "{ ...dispel, name: \"Counter Spell (free Dispel)\", apCost: \"0\", counterSpell: true }", to: "{ ...dispel, name: \"Counter Spell (free Dispel)\", apCost: \"0\", counterSpell: false }" },
  { name: "a failed counter stops the spell", file: A, from: "    if (q.result.countered) return { stop: true,", to: "    if (q.result.rolled) return { stop: true," },
  { name: "the reflection is not aimed at the caster", file: A, from: "withTargets([casterToken.id], () => h().releaseItemSpell(", to: "withTargets([], () => h().releaseItemSpell(" },
  { name: "the reflection forgets the cast's PP", file: A, from: "int(ctx.dispel?.effectValue ?? ctx.presetDispel?.effectValue ?? spell?.system?.ppCost)", to: "int(spell?.system?.ppCost)" },
  { name: "a Fumble's rebound is not said", file: A, from: "  if ([\"fumble\", \"blunder\"].includes(degree)) {\n    return { lines: [\"<strong>Mirrored Rebuke (Fumble):", to: "  if (false) {\n    return { lines: [\"<strong>Mirrored Rebuke (Fumble):" },
  { name: "Dispel Power's Fumble rolls no Resonance", file: A, from: "    await h().rollResonanceEvent(ctx.actor, { reason: \"Dispel Power (Fumble)\" });", to: "" },
  // D — registration
  { name: "the Uses are not registered", file: A, from: "  for (const [name, entry] of Object.entries(AUTOMATIONS_B5D)) api.registerFeatAutomation(name, entry, moduleId);", to: "" },
  { name: "Channel Siphoner's upgrade is not registered", file: A, from: "  for (const [name, entries] of Object.entries(DEGREE_UPGRADES_B5D)) api.registerDegreeUpgrades?.(name, entries.map((e) => ({ ...e })), moduleId);", to: "" },
  { name: "the substitutions are not registered", file: A, from: "  for (const [name, entries] of Object.entries(SKILL_SUBSTITUTIONS_B5D)) api.registerSkillSubstitution?.(name, entries.map((e) => ({ ...e })), moduleId);", to: "" },
  { name: "the ritual rules are not registered", file: A, from: "  api.registerRitualRules?.(RITUAL_RULES_KEY_B5D, { prepare: prepareRitualB5D }, moduleId);", to: "" },
  { name: "Dispel Power is not registered", file: A, from: "  api.registerDispelModifier?.(\"dispelPower\", { offer: dispelPowerOffer, onResult: dispelPowerResult }, moduleId);", to: "" },
  { name: "Mirrored Rebuke's rider is not registered", file: A, from: "  api.registerDispelModifier?.(\"mirroredRebuke\", { offer: mirroredRebukeOffer, onResult: mirroredRebukeResult }, moduleId);", to: "" },
  { name: "the remap is not registered", file: A, from: "  api.registerCastDegreeRemap?.(RUNIC_KEY, runicStabiliserRemap, moduleId);", to: "" },
  { name: "Masked Caster's Spell Trickery is not registered", file: A, from: "  api.registerCastOption?.(\"spellTrickery\", maskedSpellTrickery, moduleId);", to: "" },
  { name: "Ley Channeler's reroll is not registered", file: A, from: "  api.registerCheckReaction?.(\"leyChanneler\", leyChannelerReaction, moduleId);", to: "" },
  { name: "the counter is not offered", file: A, from: "  api.registerCastReaction?.(\"mirroredRebuke\", mirroredRebukeReaction, moduleId);", to: "" },
  { name: "the counter's step is not registered", file: A, from: "  api.registerReactionStep?.(MIRROR_STEP, mirroredRebukeStep, moduleId);", to: "" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block5d.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block5d: verify-block5d already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block5d: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block5d: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
