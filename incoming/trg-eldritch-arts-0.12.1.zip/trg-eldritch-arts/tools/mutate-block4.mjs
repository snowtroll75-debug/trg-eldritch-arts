#!/usr/bin/env node
/**
 * mutate-block4 — the mutation half of verify-block4. Each mutation breaks
 * one printed number, one reading or one wire of Block 4; verify-block4 must
 * fail on every one. Files are restored after each run, and on any exit.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block4.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block4.mjs"), S = f("tools", "content", "block4-spells.mjs"), A = f("module", "block4-automations.mjs"),
  REG = f("module", "registration.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), MANIFEST = f("module.json");

const MUTATIONS = [
  // A — the classes
  { name: "the Spellblade memorises 2 + 2L", file: C, from: "flags: { classMagic: { bookPerLevel: 1, memorisedPerDay: \"L+1\" } }", to: "flags: { classMagic: { bookPerLevel: 1 } }" },
  { name: "the Spellblade's book takes six first picks", file: C, from: "  spellBookFirstPicks: 4, wealth: String(CLASS_WEALTH.Spellblade),", to: "  spellBookFirstPicks: 6, wealth: String(CLASS_WEALTH.Spellblade)," },
  { name: "Transcend Armour is not granted", file: C, from: "  grantedFeats: \"1: Transcend Armour\",", to: "  grantedFeats: \"\"," },
  { name: "the table's CL column is the PP column", file: C, from: "col(row, \"caster level\") ?? 0, col(row, \"pp\") ?? 0,", to: "col(row, \"pp\") ?? 0, col(row, \"pp\") ?? 0," },
  { name: "the Warlock's spells are not High Magic", file: C, from: "  flags: { highMagicCaster: true, grantInnate: true }", to: "  flags: { grantInnate: true }" },
  { name: "Xithra arrives as a learned spell", file: C, from: "  flags: { highMagicCaster: true, grantInnate: true }", to: "  flags: { highMagicCaster: true }" },
  { name: "the Warlock casts off Intelligence", file: C, from: "magicalTradition: \"\", magicalAbility: \"charisma\", casterStyle: \"\",", to: "magicalTradition: \"\", magicalAbility: \"intelligence\", casterStyle: \"\"," },
  // B — the paths and souls
  { name: "the Divine Arm casts off Charisma", file: C, from: "{ heading: \"PATH OF THE DIVINE ARM\", ability: \"wisdom\", tradition: \"divinity\",", to: "{ heading: \"PATH OF THE DIVINE ARM\", ability: \"charisma\", tradition: \"divinity\"," },
  { name: "the Warden's path spell is Shooting Star", file: C, from: "special: \"NATURAL RESILIENCE\", spell: \"Thunderous Strike\" }", to: "special: \"NATURAL RESILIENCE\", spell: \"Shooting Star\" }" },
  { name: "Q43 undone: Natural Resilience resists poison only", file: C, from: "value: \", poison, disease\", priority: 20 }], \"Natural Resilience: poison damage", to: "value: \", poison\", priority: 20 }], \"Natural Resilience: poison damage" },
  { name: "Battle Mage declares nothing", file: C, from: "  flags: { spellAttackBase: \"bab\" }", to: "  flags: {}" },
  { name: "the Emberlord's +1 forgets Healing", file: C, from: "traditions: [\"arcane\", \"divinity\"], levelTraits: [\"fire\", \"healing\"],", to: "traditions: [\"arcane\", \"divinity\"], levelTraits: [\"fire\"]," },
  { name: "the Void Seer's spells are Divinity's", file: C, from: "special: \"VOID GAZE\", damageType: \"force\", traditions: [\"arcane\", \"ethereal\"]", to: "special: \"VOID GAZE\", damageType: \"force\", traditions: [\"arcane\", \"divinity\"]" },
  { name: "the Pale Reaper's rider waits for no hit", file: C, from: "rider: { kind: \"cast\", spell: \"Fear\", onHit: true } }", to: "rider: { kind: \"cast\", spell: \"Fear\", onHit: false } }" },
  { name: "a soul's skills are not class skills", file: C, from: "      classSkills: [skills[1], skills[2]],\n      eaBondedSoul:", to: "      eaBondedSoul:" },
  // C — the spells
  { name: "Shielding Strike's warp buys nothing", file: S, from: "warpMods: [{ bonusValue: 1, bonusMax: 5 }],", to: "warpMods: [{}]," },
  { name: "Spinning Weapon's force and sonic option is lost", file: S, from: "warpMods: [{ damageDice: \"1d6\" }, { unlocks: [\"eaForceSonic\"] }],", to: "warpMods: [{ damageDice: \"1d6\" }, {}]," },
  { name: "Thunderous Strike's cone is a Reflex save", file: S, from: "    defence: \"basic Fortitude\",", to: "    defence: \"basic Reflex\"," },
  { name: "Xithra adds no Charisma", file: S, from: "damage: { formula: \"1d6\", type: \"mental\", persistent: \"\", addAbility: \"charisma\" },", to: "damage: { formula: \"1d6\", type: \"mental\", persistent: \"\" }," },
  { name: "Xithra's dice climb every 5", file: S, from: "XITHRA.system.casterLevelMods = [{ threshold: 4,", to: "XITHRA.system.casterLevelMods = [{ threshold: 5," },
  { name: "Xithra is not Focus", file: S, from: "  traits: \"Attack, Focus, Magical, Mental\",", to: "  traits: \"Attack, Magical, Mental\"," },
  // D — the rules
  { name: "M14 undone: runes at 1st", file: A, from: "export const infusionBudget = (level) => (int(level) >= 2 ? int(level) : 0);", to: "export const infusionBudget = (level) => int(level);" },
  { name: "Sacred Channel climbs every 4", file: A, from: "`${1 + Math.floor(Math.max(0, int(level)) / 5)}d8`", to: "`${1 + Math.floor(Math.max(0, int(level)) / 4)}d8`" },
  { name: "Q51 undone: no 10 ft minimum", file: A, from: "Math.max(10, 10 * Math.floor(Math.max(0, int(level)) / 2))", to: "10 * Math.floor(Math.max(0, int(level)) / 2)" },
  { name: "Shielding Strike has no cap", file: A, from: "Math.min(5, 2 + Math.max(0, int(warpMods?.bonusValue)))", to: "2 + Math.max(0, int(warpMods?.bonusValue))" },
  { name: "Spinning Weapon has no 4d6 cap", file: A, from: "return `${Math.min(4, 1 + (extra ? int(extra[1]) : 0))}d6`;", to: "return `${1 + (extra ? int(extra[1]) : 0)}d6`;" },
  { name: "the Warlock's spells come every 2", file: A, from: "(int(level) >= 1 ? 1 + Math.floor(int(level) / 3) : 0)", to: "(int(level) >= 1 ? 1 + Math.floor(int(level) / 2) : 0)" },
  { name: "sidebar 8 undone: PP up to the level only", file: A, from: "  const cap = int(level) + 1;", to: "  const cap = int(level);" },
  { name: "a spell outside the soul's traditions is offered", file: A, from: "  if (!soul?.traditions?.some((t) => trads.includes(t))) return false;", to: "" },
  { name: "the soul's +1 does not widen the pick", file: A, from: "  return pp <= cap + soulLevelBonus(soul, { traits: traitList(sys.traits) });", to: "  return pp <= cap;" },
  { name: "Q37 undone: the copy is not Focus", file: A, from: "    traits: traitList(traits).includes(\"focus\") ? traits : (traits ? `${traits}, Focus` : \"Focus\"),", to: "    traits," },
  { name: "the copy casts off the class's ability", file: A, from: "castingAbilityOverride: \"charisma\", innatePPAllowance: 1, grantedBy:", to: "innatePPAllowance: 1, grantedBy:" },
  { name: "the copy keeps the plain innate limit", file: A, from: "castingAbilityOverride: \"charisma\", innatePPAllowance: 1, grantedBy:", to: "castingAbilityOverride: \"charisma\", grantedBy:" },
  { name: "Xithra's choice row is added again", file: A, from: "const rest = (Array.isArray(effects) ? effects : []).filter((e) => norm(e?.kind) !== \"damagetypechoice\");", to: "const rest = Array.isArray(effects) ? effects : [];" },
  { name: "a rider on a hit fires on a miss", file: A, from: "  if (rider.onHit) return { due: Boolean(hit), target: hit };", to: "  if (rider.onHit) return { due: true, target: hit };" },
  { name: "the cone is 180°", file: A, from: "export const THUNDER_CONE = Object.freeze({ feet: 15, angle: 90 });", to: "export const THUNDER_CONE = Object.freeze({ feet: 15, angle: 180 });" },
  { name: "the cone keeps the target", file: A, from: "    if (!p || p.id === target.id || p.id === caster.id) return false;", to: "    if (!p || p.id === caster.id) return false;" },
  { name: "Arcane Echo reaches ranged attacks", file: A, from: "label: \"Arcane Echo\", scope: \"your next melee attack, before the start of your next turn\", auto: true, when: { checkTypes: [\"attack\"], attackModes: [\"melee\"] } },", to: "label: \"Arcane Echo\", scope: \"your next melee attack, before the start of your next turn\", auto: true, when: { checkTypes: [\"attack\"] } }," },
  { name: "every class reaches the hexes", file: A, from: "  return className(actor) === \"warlock\" && Boolean(spell?.flags?.[SYSTEM_ID]?.eaHex);", to: "  return Boolean(spell?.flags?.[SYSTEM_ID]?.eaHex);" },
  // G — the Foundry side
  { name: "Infuse Weapon ignores the level budget", file: A, from: "const pool = known.filter((r) => !picked.some((p) => p.key === r.key) && int(r.level) <= left);", to: "const pool = known.filter((r) => !picked.some((p) => p.key === r.key));" },
  { name: "the infusion is not magical", file: A, from: "{ weaponId: weapon.id, runes, magical: true }", to: "{ weaponId: weapon.id, runes, magical: false }" },
  { name: "Learn a rune skips the check", file: A, from: "  const learned = Boolean(outcome?.learned);", to: "  const learned = true;" },
  { name: "Learn a rune always charges the full price (review)", file: A, from: "  const cost = outcome?.materialsConsumed === \"full\" ? terms.gp : outcome?.materialsConsumed === \"half\" ? Math.floor(terms.gp / 2) : 0;", to: "  const cost = terms.gp;" },
  { name: "Learn a rune is tried without the materials", file: A, from: "  if (purse < terms.gp) return warn(", to: "  if (false) return warn(" },
  { name: "Arcane Echo's rows are one-shot again (review)", file: A, from: "scope: \"that attack's damage\", auto: true, when:", to: "scope: \"that attack's damage\", auto: true, oneShot: true, when:" },
  { name: "the trail has no world-clock backstop (review)", file: A, from: "...(expiry.system ?? {}), spellEffect: true, spellEffectEnd: Math.trunc(Number(game.time?.worldTime ?? 0)) + 12 },", to: "...(expiry.system ?? {}) }," },
  { name: "Misty Step is cast at Xithra's target (review)", file: A, from: "  else if (r.self) await withTargets([], () => h().castSpell(actor, temp, { apPaid: true }));\n", to: "" },
  { name: "a cancelled Thunderous Strike's Strike is free (review)", file: A, from: "    await spendAPIn(actor, \"Thunderous Strike\", 1);\n", to: "" },
  { name: "Thunderous Strike strikes without the PP (review)", file: A, from: "  if (int(actor.system?.resources?.pp?.value) < int(spell.system?.ppCost)) { warn(", to: "  if (false) { warn(" },
  { name: "Learn a rune uses the wrong skill", file: A, from: "export const TRADITION_SKILL = Object.freeze({ arcane: \"arcana\", divinity: \"religion\", ethereal: \"occultism\", verdant: \"nature\" });", to: "export const TRADITION_SKILL = Object.freeze({ arcane: \"arcana\", divinity: \"religion\", ethereal: \"occultism\", verdant: \"survival\" });" },
  { name: "the soul's Use takes no cantrips", file: A, from: "    if (picksOf(actor, \"cantrip\").length < WARLOCK_CANTRIPS) await pickWarlockSpells(actor, item, \"cantrip\", WARLOCK_CANTRIPS, \"Warlock cantrips\");\n", to: "" },
  { name: "the Warlock's Hexes are the Witch's", file: A, from: "=== \"warlock\" ? warlockHexes.use(actor, item) : witchHexes.use(actor, item);", to: "=== \"never\" ? warlockHexes.use(actor, item) : witchHexes.use(actor, item);" },
  { name: "Xithra is not told the soul's type", file: A, from: "  if ((item.type === \"ability\" && item.flags?.[SYSTEM_ID]?.eaBondedSoul) || (item.type === \"spell\" && item.flags?.[SYSTEM_ID]?.eaXithra)) await syncXithra(actor);", to: "" },
  { name: "the rider is not once a day", file: A, from: "  if (soul.item.getFlag(MODULE_ID, \"riderUsed\")) return;", to: "" },
  { name: "daily preparation does not restore the rider", file: A, from: "  if (soul?.item?.getFlag(MODULE_ID, \"riderUsed\")) await soul.item.unsetFlag(MODULE_ID, \"riderUsed\");", to: "" },
  { name: "Arcane Echo spends no use", file: A, from: "  if (usesLeft(echo) <= 0) return;\n  await spendUse(echo);", to: "  if (usesLeft(echo) <= 0) return;" },
  { name: "Arcane Echo lingers after the attack", file: A, from: "    const ids = Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, \"source\") === \"arcaneEcho\").map((e) => e.id);", to: "    const ids = [];" },
  { name: "Sacred Channel costs no PP", file: A, from: "  await actor.update({ \"system.resources.pp.value\": int(actor.system.resources.pp.value) - 1 });\n  await spendUse(channel);", to: "  await spendUse(channel);" },
  { name: "Sacred Channel is not once until Refocus", file: A, from: "  if (!channel || usesLeft(channel) <= 0) return;", to: "  if (!channel) return;" },
  { name: "Q47 undone: the Strike follows a failed cast", file: A, from: "  if (AFTER_CAST[key] && ctx.cast && !ctx.refunded) await AFTER_CAST[key](ctx);", to: "  if (AFTER_CAST[key]) await AFTER_CAST[key](ctx);" },
  { name: "the Strike costs AP again", file: A, from: "    check = await h().rollWeaponAttack(actor, weapon, { apPaid: true, ...options });", to: "    check = await h().rollWeaponAttack(actor, weapon, { ...options });" },
  { name: "Shooting Star's melee reach is the weapon's", file: A, from: "melee ? { reachOverrideFeet: SHOOTING_STAR_REACH } : {}", to: "{}" },
  { name: "Shooting Star's edge does not step cover", file: A, from: "const edge = { ignoreConcealment: true, reduceCover: 1, label: \"Shooting Star\" };", to: "const edge = { ignoreConcealment: true, label: \"Shooting Star\" };" },
  { name: "the edge outlives the Strike", file: A, from: "    if (made) await made.delete().catch(() => {});", to: "" },
  { name: "the trail follows a miss", file: A, from: "  if (!out.hit || !out.target) return;\n  // THE TRAIL", to: "  if (!out.target) return;\n  // THE TRAIL" },
  { name: "the trail is not for that creature only", file: A, from: "strikeEdge: { ...edge, targetUuid: out.target.uuid, label: \"Shooting Star's trail\" }", to: "strikeEdge: { ...edge, label: \"Shooting Star's trail\" }" },
  { name: "the trail never ends", file: A, from: "&& e.getFlag(MODULE_ID, \"trailOf\") === next.id).map((e) => e.id);", to: "&& false).map((e) => e.id);" },
  { name: "Spinning Weapon's rider reaches ranged Strikes", file: A, from: "strikeRider: { label: \"Spinning Weapon\", dice, damageType: type, scope: \"melee\", once: true }", to: "strikeRider: { label: \"Spinning Weapon\", dice, damageType: type, scope: \"any\", once: true }" },
  { name: "Shielding Strike's bonus is circumstance", file: A, from: "changes: [{ key: \"system.combat.defence.status\", mode: 2, value: String(bonus), priority: 20 }]", to: "changes: [{ key: \"system.combat.defence.circumstance\", mode: 2, value: String(bonus), priority: 20 }]" },
  { name: "Q48 undone: the cast rolls its own check", file: A, from: "h().castSpell(actor, spell, { strikeCheck: out.check, presetTargets: true })", to: "h().castSpell(actor, spell, { presetTargets: true })" },
  { name: "a creature outside the combat pays AP (live test)", file: A, from: "const fighting = (actor) => Boolean(combatFor(actor));", to: "const fighting = (actor) => Boolean(globalThis.game?.combat?.started);" },
  { name: "Thunderous Strike's range is self again (live test)", file: S, from: "    range: \"see text\",\n    damage: { formula: \"1d6\", type: \"sonic\" },", to: "    damage: { formula: \"1d6\", type: \"sonic\" }," },
  { name: "Shooting Star's range is self again (live test)", file: S, from: "    range: \"see text\",\n    category: \"utility\",\n    effects: [{ kind: \"note\", text: \"On a Success or better, the Strike is made with your wielded weapon", to: "    category: \"utility\",\n    effects: [{ kind: \"note\", text: \"On a Success or better, the Strike is made with your wielded weapon" },
  { name: "every unlinked token of a combatant's base actor is in the combat (review)", file: f("module", "effects-clock.mjs"), from: "(c.actorId === actor?.id && actor?.isToken !== true)", to: "c.actorId === actor?.id" },
  { name: "Blocks 1 and 3 charge any actor while a combat runs (live test)", file: f("module", "block1-automations.mjs"), from: "const inCombat = (actor = null) => (actor ? Boolean(combatFor(actor)) : Boolean(globalThis.game?.combat?.started));", to: "const inCombat = (actor = null) => Boolean(globalThis.game?.combat?.started);" },
  { name: "Thunderous Strike's prelude takes any spell", file: A, from: "  if (spellbladeSpell(spell) !== \"thunderousStrike\") return null;", to: "" },
  // E — registration
  { name: "the Warlock's wealth is 2", file: REG, from: "[\"Warlock\", 1, [\"Simple\"], [], [\"Light\"]]", to: "[\"Warlock\", 2, [\"Simple\"], [], [\"Light\"]]" },
  { name: "the Spellblade is not proficient with martial weapons", file: REG, from: "[\"Spellblade\", 2, [\"Simple\", \"Martial\"], [], [\"Light\"]]", to: "[\"Spellblade\", 2, [\"Simple\"], [], [\"Light\"]]" },
  { name: "Block 4 is not registered", file: REG, from: "  registerBlock4(api, moduleId);", to: "" },
  { name: "sidebar 16 is not registered", file: A, from: "  for (const [cls, feats] of Object.entries(EXISTING_CLASS_FEATS)) api.registerFeatAccess?.(\"class\", cls, [...feats], moduleId);", to: "" },
  { name: "Natural Resilience's HP go to PP", file: A, from: "types: [\"ability\"], stat: \"hp\" }, moduleId);", to: "types: [\"ability\"] }, moduleId);" },
  { name: "the souls' +1 is not registered", file: A, from: "  api.registerInnateLevelBonus?.(\"bondedSoul\", (ctx) => soulLevelBonus(soulOf(ctx.actor), ctx), moduleId);", to: "" },
  { name: "Hexes stays the Witch's", file: A, from: "  api.registerFeatAutomation(\"Hexes\", hexesDispatch, moduleId);", to: "" },
  // H — the hooks and versions
  { name: "the settled hook is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB4(ctx)", to: "Hooks.on(\"trgPrimeSpellSettledX\", (ctx) => { onSpellSettledB4(ctx)" },
  { name: "the system version is not required", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.687.1\";", to: "export const REQUIRED_SYSTEM = \"3.681.0\";" },
  { name: "the module version is not raised", file: MANIFEST, from: "\"version\": \"0.12.1\"", to: "\"version\": \"0.6.1\"" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block4.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block4: verify-block4 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block4: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block4: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
