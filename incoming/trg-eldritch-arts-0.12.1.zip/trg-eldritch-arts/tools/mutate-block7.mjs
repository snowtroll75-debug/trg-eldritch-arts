#!/usr/bin/env node
/**
 * mutate-block7 — the mutation half of verify-block7. Each mutation breaks
 * one printed number, one reading, one ruling or one wire of Block 7 (the
 * first half of the Grimoire, 0.10.0); verify-block7 must fail on every one.
 * Files are restored after each run, and on any exit. It rewrites files in
 * place: run it on a copy of the tree.
 *
 * verify-block7 is run with EA_MUTATING=1, which skips its packs-source parity
 * check, so a content mutation is caught by a check of its own meaning and not
 * by the stale pack alone.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block7.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block7-spells.mjs"), R = f("module", "block7-rules.mjs"), A = f("module", "block7-automations.mjs");
const D = f("module", "distracted.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), B6A = f("module", "block6a-automations.mjs"), MANIFEST = f("module.json");

const MUTATIONS = [
  // Graham's 07:53 rulings
  { name: "Dragon Wings' cap is +50 from the warps (land + 60)", file: R, from: "export const DRAGON_WINGS_FLY_CAP = 50;", to: "export const DRAGON_WINGS_FLY_CAP = 60;" },
  { name: "Dragon Wings' warp adds 5 feet", file: R, from: "export const DRAGON_WINGS_STEP_FEET = 10;", to: "export const DRAGON_WINGS_STEP_FEET = 5;" },
  { name: "Spirit Arrow's 6d6 is no longer flat", file: R, from: "export const SPIRIT_ARROW_FLAT = true;", to: "export const SPIRIT_ARROW_FLAT = false;" },
  { name: "Spirit Arrow adds a packet instead of replacing", file: R, from: "export const SPIRIT_ARROW_REPLACES = true;", to: "export const SPIRIT_ARROW_REPLACES = false;" },
  { name: "the rulings are called open readings again", file: R, from: " * GRAHAM'S TWO RULINGS OF 7 NOVEMBER 2026 (07:53), each one constant here:", to: " * TWO READINGS ARE OPEN FOR GRAHAM, each one constant here:" },
  // Q157, Q161, Q164 and the rest of the rules
  { name: "Distracted is −2", file: D, from: "export const DISTRACTED_VALUE = -1;", to: "export const DISTRACTED_VALUE = -2;" },
  { name: "Distracted reaches DB", file: D, from: "[\"attack\", \"allSkills\", \"fortitude\", \"reflex\", \"will\", \"spellcraft\"]", to: "[\"attack\", \"allSkills\", \"fortitude\", \"reflex\", \"will\", \"spellcraft\", \"defence\"]" },
  { name: "Distracted forgets the casting check", file: D, from: "[\"attack\", \"allSkills\", \"fortitude\", \"reflex\", \"will\", \"spellcraft\"]", to: "[\"attack\", \"allSkills\", \"fortitude\", \"reflex\", \"will\"]" },
  { name: "Distracted is circumstance", file: D, from: "export const DISTRACTED_TYPE = \"status\";", to: "export const DISTRACTED_TYPE = \"circumstance\";" },
  { name: "Spirit Arrow's fear has no minimum", file: R, from: "  return Math.max(1, Math.floor(failedBy / 2));", to: "  return Math.floor(failedBy / 2);" },
  { name: "Spirit Arrow's fear rounds up", file: R, from: "  return Math.max(1, Math.floor(failedBy / 2));", to: "  return Math.max(1, Math.ceil(failedBy / 2));" },
  { name: "Invoke True Name is −4 from CL 4", file: R, from: "export const trueNamePenalty = (casterLevel) => (int(casterLevel) >= 8 ? -4 : -2);", to: "export const trueNamePenalty = (casterLevel) => (int(casterLevel) >= 4 ? -4 : -2);" },
  { name: "flat-footed forgets dodge", file: R, from: " + Math.max(0, Number(defence?.breakdown?.byType?.dodge) || 0);", to: ";" },
  { name: "Dragon's Breath: fire breathes a line", file: R, from: "[\"acid\", \"electricity\"].includes(norm(type)) ? \"line\" : \"cone\"", to: "[\"acid\", \"electricity\", \"fire\"].includes(norm(type)) ? \"line\" : \"cone\"" },
  { name: "Dragon's Breath's line maxes at 100", file: R, from: "line: Object.freeze({ area: \"30-foot line\", step: 10, max: 120 }),", to: "line: Object.freeze({ area: \"30-foot line\", step: 10, max: 100 })," },
  { name: "Dragon's Breath takes sonic", file: R, from: "export const BREATH_TYPES = Object.freeze([\"acid\", \"cold\", \"electricity\", \"fire\", \"poison\"]);", to: "export const BREATH_TYPES = Object.freeze([\"acid\", \"cold\", \"electricity\", \"fire\", \"poison\", \"sonic\"]);" },
  { name: "air maps to cold", file: R, from: "air: \"electricity\", earth: \"acid\"", to: "air: \"cold\", earth: \"acid\"" },
  { name: "Elemental Strike's warp dice are lost", file: R, from: "  return `${1 + (extra ? int(extra[1]) : 0)}d6`;\n}\nexport const elementalStrikeFormula", to: "  return \"1d6\";\n}\nexport const elementalStrikeFormula" },
  { name: "Planar Anchor counters every Translocation spell", file: R, from: "  if (list.includes(\"teleportation\")) return \"teleportation\";", to: "  if (list.includes(\"teleportation\") || list.includes(\"translocation\")) return \"teleportation\";" },
  { name: "the veil warp is always on", file: R, from: "  if (veil && (list.includes(\"invisibility\")", to: "  if ((list.includes(\"invisibility\")" },
  { name: "Arcane Feedback's Failure critical is Serious", file: R, from: "FEEDBACK_CRITICAL = Object.freeze({ failure: \"minor\"", to: "FEEDBACK_CRITICAL = Object.freeze({ failure: \"serious\"" },
  { name: "Arcane Feedback's step has no Deadly cap", file: R, from: "  return SEVERITIES[Math.min(SEVERITIES.length - 1, SEVERITIES.indexOf(base) + Math.max(0, int(steps)))];", to: "  return SEVERITIES[SEVERITIES.indexOf(base) + Math.max(0, int(steps))] ?? null;" },
  { name: "Arcane Feedback penalises an innate cast with no check", file: R, from: "(rollsCheck && int(taken) > 0 ? -int(taken) : 0)", to: "(int(taken) > 0 ? -int(taken) : 0)" },
  { name: "Arcane Bastion's steps uncapped", file: R, from: "export const bastionSteps = (warpBought = 0) => Math.min(BASTION_MAX_STEPS, 1 + Math.max(0, int(warpBought)));", to: "export const bastionSteps = (warpBought = 0) => 1 + Math.max(0, int(warpBought));" },
  { name: "Arcane Bastion counts Stunned as incapacitating", file: R, from: "|helpless|incapacitat\\w*)\\b/i;", to: "|helpless|stunned|incapacitat\\w*)\\b/i;" },
  { name: "Arcane Bastion misses Unconscious", file: R, from: "slain|unconscious|paraly", to: "slain|paraly" },
  { name: "Argent Reversal's Partial turns the spell", file: R, from: "  if (d === \"success\") return { turn: true, choose: false, backlash: \"\" };", to: "  if (d === \"success\" || d === \"partial\") return { turn: true, choose: false, backlash: \"\" };" },
  { name: "Argent Reversal's Blunder is 4d10", file: R, from: "  if (d === \"blunder\") return { turn: false, choose: false, backlash: \"8d10\" };", to: "  if (d === \"blunder\") return { turn: false, choose: false, backlash: \"4d10\" };" },
  { name: "Argent Reversal's absorb rounds up", file: R, from: "export const argentAbsorbPP = (pp) => Math.floor(Math.max(0, int(pp)) / 2);", to: "export const argentAbsorbPP = (pp) => Math.ceil(Math.max(0, int(pp)) / 2);" },
  { name: "Argent Reversal reaches a spell one PP above the cap", file: R, from: "export const argentReaches = (incomingPP, casterLevel) => int(incomingPP) <= maxPPPerCast(casterLevel);", to: "export const argentReaches = (incomingPP, casterLevel) => int(incomingPP) <= maxPPPerCast(casterLevel) + 1;" },
  { name: "Spectral Aegis absorbs PP 11", file: R, from: "export const AEGIS_PP_LIMIT = 10;", to: "export const AEGIS_PP_LIMIT = 11;" },
  { name: "Mirror Reprise needs 25+ with three", file: R, from: "MIRROR_THRESHOLD = Object.freeze({ 3: 26, 2: 34, 1: 51 });", to: "MIRROR_THRESHOLD = Object.freeze({ 3: 25, 2: 34, 1: 51 });" },
  { name: "Mirror Reprise needs 50+ with one", file: R, from: "MIRROR_THRESHOLD = Object.freeze({ 3: 26, 2: 34, 1: 51 });", to: "MIRROR_THRESHOLD = Object.freeze({ 3: 26, 2: 34, 1: 50 });" },
  { name: "m114 undone: the +3 PP half beats the +6 PP none", file: R, from: "  if (u.includes(RESONANCE_FREE_UNLOCK)) return 0;\n  if (u.includes(RESONANCE_HALF_UNLOCK)) return 0.5;", to: "  if (u.includes(RESONANCE_HALF_UNLOCK)) return 0.5;\n  if (u.includes(RESONANCE_FREE_UNLOCK)) return 0;" },
  { name: "Chronoweave's Partial is unaffected", file: R, from: "  if (d === \"failure\" || d === \"partial\") return 1;", to: "  if (d === \"failure\") return 1;" },
  { name: "Primal Snap is 5d8", file: R, from: "  return `${6 + (extra ? int(extra[1]) : 0)}d8`;", to: "  return `${5 + (extra ? int(extra[1]) : 0)}d8`;" },
  { name: "Panic Transposition's far warp is 50 ft", file: R, from: "export const PANIC_FAR_FEET = 60;", to: "export const PANIC_FAR_FEET = 50;" },
  { name: "max PP per cast is the caster level", file: R, from: "export const maxPPPerCast = (casterLevel) => Math.max(0, int(casterLevel)) + 1;", to: "export const maxPPPerCast = (casterLevel) => Math.max(0, int(casterLevel));" },
  // The content
  { name: "Grimoire spells are common again", file: R, from: "export const GRIMOIRE_AVAILABILITY = \"uncommon\";", to: "export const GRIMOIRE_AVAILABILITY = \"common\";" },
  { name: "tradition all stays \"all\"", file: C, from: "  if (/^all$/i.test(String(entry.fields.Tradition ?? \"\").trim())) sys.tradition = ALL_TRADITIONS;\n", to: "" },
  { name: "Brittleskin's thorns at the defender's Level DC", file: C, from: "label: \"Brittleskin\", damage: \"1d4\", damageType: \"piercing\", save: { key: \"fortitude\", dc: \"spell\" }", to: "label: \"Brittleskin\", damage: \"1d4\", damageType: \"piercing\", save: { key: \"fortitude\" }" },
  { name: "Brittleskin's CL step forgets the DR", file: C, from: "rows: [{ match: { kind: \"bonus\", slot: \"dr\" }, add: { value: 1 } }, { match: { kind: \"thorns\" }, add: { damage: \"1d4\" } }]", to: "rows: [{ match: { kind: \"thorns\" }, add: { damage: \"1d4\" } }]" },
  { name: "Glyph of Retribution's level bonus is uncapped (max 20)", file: C, from: "casterLevelBonus: { max: 15 }", to: "casterLevelBonus: { max: 20 }" },
  { name: "Eldritch Mantle's warp does not grow the thorns", file: C, from: "reachFeet: ANY_MELEE_FEET, warpStep: { damage: \"1d6\" } }", to: "reachFeet: ANY_MELEE_FEET }" },
  { name: "thorns reach only adjacent attackers", file: R, from: "export const ANY_MELEE_FEET = 100;", to: "export const ANY_MELEE_FEET = 5;" },
  { name: "Prismatic Guard's Fumble blinds for a round", file: C, from: "fumble: [cond(\"blinded\", { duration: \"permanent\" })]", to: "fumble: [cond(\"blinded\", { duration: \"1 round\" })]" },
  { name: "Prismatic Guard's resistance forgets force (M53)", file: C, from: "value: \"acid, cold, electricity, fire, sonic, essence, force\"", to: "value: \"acid, cold, electricity, fire, sonic, essence\"" },
  { name: "Prismatic Guard follows its caster (an emanation)", file: C, from: "    area: \"10-foot radius\",\n    effects: [\n      { kind: \"defence\", target: \"targets\", field: \"resistance\"", to: "    effects: [\n      { kind: \"defence\", target: \"targets\", field: \"resistance\"" },
  { name: "Bubble Buffet replaces a worse result with a better", file: C, from: "atCast: true, replace: \"worse\", stopAt: \"failure\"", to: "atCast: true, replace: \"always\", stopAt: \"failure\"" },
  { name: "Bubble Buffet's failures keep rolling (m100)", file: C, from: "atCast: true, replace: \"worse\", stopAt: \"failure\"", to: "atCast: true, replace: \"worse\"" },
  { name: "Bubble Buffet is not rolled at the cast", file: C, from: "on: \"casterTurnStart\", atCast: true,", to: "on: \"casterTurnStart\"," },
  { name: "Bubble Buffet's Fumble forgets slowed", file: C, from: "fumble: { rows: [cond(\"fixated\"), cond(\"slowed\", { value: 1 })] }", to: "fumble: { rows: [cond(\"fixated\")] }" },
  { name: "Flesh to Blossom's Critical does not end it", file: C, from: "heroic: { endsSpell: true }, critical: { endsSpell: true },\n          success: { dice: \"1d12\"", to: "heroic: { unaffected: true }, critical: { unaffected: true },\n          success: { dice: \"1d12\"" },
  { name: "Flesh to Blossom's later Failure is 1d12", file: C, from: "failure: { dice: \"2d12\", rows: [cond(\"immobilised\")] },", to: "failure: { dice: \"1d12\", rows: [cond(\"immobilised\")] }," },
  { name: "Arcane Mycelium is not asked at a turn's start", file: C, from: "label: \"Arcane Mycelium\", save: \"reflex\", atTurnStart: true,", to: "label: \"Arcane Mycelium\", save: \"reflex\"," },
  { name: "Arcane Mycelium's Fumble is slowed 1", file: C, from: "fumble: { text: \"is slowed 2 until the end of its next turn\", rows: [cond(\"slowed\", { value: 2,", to: "fumble: { text: \"is slowed 2 until the end of its next turn\", rows: [cond(\"slowed\", { value: 1," },
  { name: "Animate Moustache distracts on a Success", file: C, from: "effects: distractedRows({ onSave: [\"failure\", \"fumble\"] }),", to: "effects: distractedRows({ onSave: [\"success\", \"failure\", \"fumble\"] })," },
  { name: "Eaog Balls' coldfire is always on", file: C, from: "formula: \"2d8\", damageType: \"coldfire\", unlockedBy: EAOG_COLDFIRE_UNLOCK }", to: "formula: \"2d8\", damageType: \"coldfire\" }" },
  { name: "Eaog Balls' coldfire is fire (Q150's second type lost)", file: C, from: "formula: \"2d8\", damageType: \"coldfire\", unlockedBy", to: "formula: \"2d8\", damageType: \"force\", unlockedBy" },
  { name: "Eaog Balls' Failure is 1d6 recurring", file: C, from: "cond(\"recurring\", { onSave: [\"failure\"], formula: \"2d6\", damageType: \"force\" }),", to: "cond(\"recurring\", { onSave: [\"failure\"], formula: \"1d6\", damageType: \"force\" })," },
  { name: "Word of Pain's Fumble is weakened 3", file: C, from: "cond(\"weakened\", { onSave: [\"fumble\"], value: 4, duration: \"1 hour\" })", to: "cond(\"weakened\", { onSave: [\"fumble\"], value: 3, duration: \"1 hour\" })" },
  { name: "Memory Eclipse's Fumble forgets frightened 2", file: C, from: "      cond(\"frightened\", { onSave: [\"fumble\"], value: 2 }),\n", to: "" },
  { name: "Leyline Burst pushes on a Success", file: C, from: "feet: 10, direction: \"away\", onSave: [\"failure\", \"fumble\"] }", to: "feet: 10, direction: \"away\", onSave: [\"success\", \"failure\", \"fumble\"] }" },
  { name: "Planar Anchor's Partial lasts 1 hour", file: C, from: "mark(ANCHOR_MARK, \"Planar Anchor\", { onSave: [\"partial\"], duration: \"10 minutes\" }),", to: "mark(ANCHOR_MARK, \"Planar Anchor\", { onSave: [\"partial\"], duration: \"1 hour\" })," },
  { name: "Mana Surge's free PP do not raise the Save DC (Q162)", file: C, from: "trait: \"*\", value: 1, raisesSaveDC: true }", to: "trait: \"*\", value: 1 }" },
  { name: "Decoherence's bonus is status", file: C, from: "label: \"Decoherence\", value: 1, bonusType: \"circumstance\"", to: "label: \"Decoherence\", value: 1, bonusType: \"status\"" },
  { name: "Invoke True Name's step recurs (Q164)", file: C, from: "casterLevelMods: [cl(8, \"The penalty increases to -4.\", {}, false)],", to: "casterLevelMods: [cl(8, \"The penalty increases to -4.\", {})]," },
  { name: "Feltwarp's CL step is +2 hours", file: C, from: "duration: { amount: 1, unit: \"hours\" }", to: "duration: { amount: 2, unit: \"hours\" }" },
  { name: "Dreadmote's CL step is lost", file: C, from: "casterLevelMods: [cl(4, \"the damage increases by 1d4.\", { damageDice: \"1d4\" })],", to: "casterLevelMods: []," },
  { name: "Orb of Dusk's secondary is sonic", file: C, from: "damage: { formula: \"1d4\", type: \"essence\" }, secondary: { formula: \"1\", type: \"cold\" },", to: "damage: { formula: \"1d4\", type: \"essence\" }, secondary: { formula: \"1\", type: \"sonic\" }," },
  { name: "Acidic Burst's warp grows 10 ft", file: C, from: "warpMods: [{ areaGrowth: 5 }],\n    what: \"basic Reflex against 3d6 acid", to: "warpMods: [{ areaGrowth: 10 }],\n    what: \"basic Reflex against 3d6 acid" },
  { name: "Spectral Aegis's resistance is physical only", file: C, from: "effects: [{ kind: \"defence\", target: \"targets\", field: \"resistance\", value: \"all damage\" }],", to: "effects: [{ kind: \"defence\", target: \"targets\", field: \"resistance\", value: \"physical\" }]," },
  { name: "Arcane Bastion's guard is not once", file: C, from: "deathGuard: { label: \"Arcane Bastion\", auto: true, once: true }", to: "deathGuard: { label: \"Arcane Bastion\", auto: true }" },
  { name: "a C card claims to be automated (Drearlight)", file: C, from: "key: \"drearlight\", grade: \"C\",", to: "key: \"drearlight\", grade: \"A\"," },
  { name: "Glyph's card hides the by-hand type change", file: C, from: "fixed at the cast (H1). +4 PP: 1 hour. *By hand:* the +4 PP option's", to: "fixed at the cast (H1). +4 PP: 1 hour. The +4 PP option's" },
  { name: "Air Bubble is cast for 2 AP", file: C, from: "key: \"airBubble\", grade: \"B\", category: \"utility\", castAP: \"Reaction\",", to: "key: \"airBubble\", grade: \"B\", category: \"utility\", castAP: 2," },
  { name: "Flesh To Blossom keeps the capital To", file: C, from: "  if (named !== doc.name) { doc.name = named; doc._id = stableId(`spells:${named}`); }\n", to: "" },
  // The Foundry side
  { name: "a Pact's grant is asked its type anyway", file: A, from: "  if (fromPact) { await setSpellType(item, fromPact); return; }\n", to: "" },
  { name: "the type refusal lets an untyped spell through", file: A, from: "  return `${spell.name}: choose its damage type first (it is chosen once, when you learn the spell).`;", to: "  return null;" },
  { name: "a Pact's grant is duplicated on a new type", file: A, from: "  if (have) { await setSpellType(have, type); return have; }\n", to: "" },
  { name: "Elemental Strike ignores the weapon's reach", file: A, from: "    if (!within(me, target, reach)) return warn(`Elemental Strike: ${target.name} is beyond your weapon's reach (${reach} ft).`);\n", to: "" },
  { name: "Elemental Strike forgets the casting ability", file: A, from: "const formula = R.elementalStrikeFormula(stamp.dice, castingAbilityOf(actor));", to: "const formula = R.elementalStrikeFormula(stamp.dice, 0);" },
  { name: "Elemental Strike's Base Damage is lost from the critical", file: A, from: "type: stamp.type, baseDamage: R.ELEMENTAL_STRIKE_BASE });", to: "type: stamp.type });" },
  { name: "Arcane Feedback answers an ally's cast", file: A, from: "    if (reactor === caster || !R.enemiesBySide(side(t), side(casterToken))) continue;\n    const spell = spellByKey(reactor, \"arcaneFeedback\");", to: "    if (reactor === caster) continue;\n    const spell = spellByKey(reactor, \"arcaneFeedback\");" },
  { name: "Arcane Feedback's penalty reaches an attack spell's attack", file: A, from: "value: penalty, type: \"untyped\", castingOnly: true }]", to: "value: penalty, type: \"untyped\" }]" },
  { name: "Arcane Feedback's critical ignores the warp", file: A, from: "const severity = R.feedbackSeverity(degree, int(result?.warpMods?.bonusValue));", to: "const severity = R.feedbackSeverity(degree, 0);" },
  { name: "Arcane Feedback's damage watch is never let go", file: A, from: "    if (watch !== undefined) globalThis.Hooks?.off?.(\"trgPrimeDamageApplied\", watch);\n", to: "" },
  { name: "the mycelium leeches without its warp", file: A, from: "    if (!rec.unlocks.includes(R.MYCELIUM_REACTIVE_UNLOCK) || !(await inside(region, token))) continue;", to: "    if (!(await inside(region, token))) continue;" },
  { name: "Zone Disruption forgets the innate check", file: A, from: "    disadvantage: true, innateCheck: ctx.innate === true,", to: "    disadvantage: true, innateCheck: false," },
  { name: "Zone Disruption's exempt creature is still penalised", file: A, from: "    if (!exempt) return region;", to: "    return region;" },
  { name: "Zone Disruption's fumble warp is always on", file: A, from: "  if (!region?.flags?.[MODULE_ID]?.[REGION_FLAG]?.unlocks?.includes(R.ZONE_FUMBLE_UNLOCK)) return null;\n", to: "" },
  { name: "a second Zone Disruption result is kept", file: A, from: "  if (earlier.length) { await actor.deleteEmbeddedDocuments(\"ActiveEffect\", [effect.id]); return; }\n", to: "" },
  { name: "the zone's Concentration rise names no exempt creature", file: A, from: "  await region.setFlag(SYSTEM_ID, \"castingZone\", { concentrationDC: R.ZONE_CONCENTRATION_RISE, label: \"Zone Disruption\", exempt });", to: "  await region.setFlag(SYSTEM_ID, \"castingZone\", { concentrationDC: R.ZONE_CONCENTRATION_RISE, label: \"Zone Disruption\", exempt: [] });" },
  { name: "Primal Snap's speed penalty on any result", file: A, from: "    if (R.basicSaveFailed(hit?.degree) && !ownEffects(actor, \"primalSnapSpeed\").length) {", to: "    if (!ownEffects(actor, \"primalSnapSpeed\").length) {" },
  { name: "Primal Snap's penalty stacks with itself", file: A, from: "    if (R.basicSaveFailed(hit?.degree) && !ownEffects(actor, \"primalSnapSpeed\").length) {", to: "    if (R.basicSaveFailed(hit?.degree)) {" },
  { name: "Primal Snap's penalty does not end on healing (H11)", file: A, from: "    system: { endsOnHeal: true }\n  });", to: "    system: {}\n  });" },
  { name: "Primal Snap's warp dice are lost", file: A, from: "    const dice = R.snapDice(rec.damageDice);", to: "    const dice = R.snapDice(\"\");" },
  { name: "Invoke True Name's flat-footed reaches another caster's attack", file: A, from: "    if (!trueNameOn(target, ctx.actor) || target?.hasCondition?.(\"flatFooted\")) continue;", to: "    if (!target || target?.hasCondition?.(\"flatFooted\")) continue;" },
  { name: "Invoke True Name's flat-footed reaches the casting check", file: A, from: "value: loss, type: \"untyped\", attackOnly: true });", to: "value: loss, type: \"untyped\" });" },
  { name: "Invoke True Name's save penalty is status", file: A, from: "return { modifiers: [{ label: \"Invoke True Name\", value, type: \"circumstance\" }]", to: "return { modifiers: [{ label: \"Invoke True Name\", value, type: \"status\" }]" },
  { name: "Invoke True Name's weakness every time", file: A, from: "  if (spent.includes(key)) return null;\n", to: "" },
  { name: "Planar Anchor ignores a spell cast at it", file: A, from: "  const involved = [ctx.actor, ...Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor)].filter(Boolean);", to: "  const involved = [ctx.actor].filter(Boolean);" },
  { name: "the veil warp is never recorded", file: A, from: "        if (castIds.length) await actor.setFlag(MODULE_ID, ANCHOR_VEIL_FLAG,", to: "        if (false) await actor.setFlag(MODULE_ID, ANCHOR_VEIL_FLAG," },
  { name: "Arcane Bastion lowers without ending the spell", file: A, from: "  try { await endBastion(target, record.castId); } catch", to: "  try { void 0; } catch" },
  { name: "Arcane Bastion lowers a minor scratch", file: A, from: "  if (!record?.castId || !R.injuryIncapacitates(ctx.row)) return null;", to: "  if (!record?.castId) return null;" },
  { name: "the 0 HP guard leaves the spell running", file: A, from: "  if (record?.castId) await endBastion(ctx.actor, record.castId);\n  await card(ctx.actor, \"Arcane Bastion\"", to: "  await card(ctx.actor, \"Arcane Bastion\"" },
  { name: "Arcane Bastion's warp steps are lost", file: A, from: "steps: R.bastionSteps(ctx.warpMods?.bonusValue) });", to: "steps: R.bastionSteps(0) });" },
  { name: "Argent Reversal rolls against the bearer's own DC", file: A, from: "      data: { dc: int(ctx.saveDC), effectId: charge.id,", to: "      data: { dc: int(rec.saveDC), effectId: charge.id," },
  { name: "Argent Reversal turns back at the caster's DC", file: A, from: "return { turnBack: { checkTotal: int(q.result.total), saveDC: int(rec.saveDC),", to: "return { turnBack: { checkTotal: int(q.result.total), saveDC: int(ctx.saveDC)," },
  { name: "Argent Reversal spends no attempt", file: A, from: "    const left = int(rec.attempts) - 1;\n    if (left <= 0) await charge.delete?.();", to: "    const left = int(rec.attempts);\n    if (left <= 0) await charge.delete?.();" },
  { name: "Argent Reversal spends no reaction", file: A, from: "  if (!(await h().spendReaction?.(actor, \"Argent Reversal\", { traits: \"Utility, Warding\" }))) return { rolled: false };\n", to: "" },
  { name: "Argent Reversal's absorb restores nothing", file: A, from: "    if (regained > 0) await actor.update(", to: "    if (false) await actor.update(" },
  { name: "Argent Reversal reaches any PP", file: A, from: "    if (!canSee(bearer, casterToken) || !R.argentReaches(ctx.castPP ?? ctx.pp, casterLevelOf(bearer))) continue;", to: "    if (!canSee(bearer, casterToken)) continue;" },
  { name: "Spectral Aegis absorbs a beneficial spell", file: A, from: "  if (!caster || !casterToken || ctx.spellData?.category === \"utility\") return null;\n  const area", to: "  if (!caster || !casterToken) return null;\n  const area" },
  { name: "Spectral Aegis keeps its resistance after the last absorb", file: A, from: "  await writeOn(warded, { kind: \"deleteEffects\", ids: [...new Set([fx.id, ...resist])] });", to: "  await writeOn(warded, { kind: \"deleteEffects\", ids: [fx.id] });" },
  { name: "Spectral Aegis's absorbs are not counted", file: A, from: "    else await writeOn(warded, { kind: \"effectFlag\", effectId: fx.id, key: AEGIS_FLAG, value: { ...state, absorbs: left } });\n", to: "" },
  { name: "Mirror Reprise is armed by any spell", file: A, from: "  const hostileSpell = ctx.kind === \"spell\" && m.rec.spellTriggers && !sameCreature(ctx.sourceUuid, ctx.target);", to: "  const hostileSpell = ctx.kind === \"spell\";" },
  { name: "Mirror Reprise's images are not spent", file: A, from: "  } else await writeOn(ctx.target, { kind: \"effectFlag\", effectId: m.fx.id, key: MIRROR_FLAG, value: { ...m.rec, images: left } });", to: "  }" },
  { name: "Mirror Reprise never ends", file: A, from: "  if (left <= 0) {\n    await writeOn(ctx.target, { kind: \"deleteEffects\", ids: [m.fx.id] });", to: "  if (left < 0) {\n    await writeOn(ctx.target, { kind: \"deleteEffects\", ids: [m.fx.id] });" },
  { name: "Panic Transposition is cast at the attacker", file: A, from: "  const own = tokenOf(actor)?.id;\n  const result = await h().castAsReaction(actor, spell, own ? [own] : []);", to: "  const result = await h().castAsReaction(actor, spell, []);" },
  { name: "Panic Transposition's resistance without the warp", file: A, from: "  if (!rec.unlocks?.includes(R.PANIC_RESIST_UNLOCK) || !sameCreature", to: "  if (!sameCreature" },
  { name: "Spirit Arrow's later arrows are lost", file: A, from: "    await archer.createEmbeddedDocuments(\"ActiveEffect\", [again]);\n", to: "" },
  { name: "Spirit Arrow's Will is at DC 0", file: A, from: "    const dc = int(rec?.dc);", to: "    const dc = 0;" },
  { name: "Spirit Arrow fires on a melee Strike", file: A, from: "  if (!fired || Date.now() - fired.at > 10000 || ctx.melee) return;", to: "  if (!fired || Date.now() - fired.at > 10000) return;" },
  { name: "Spirit Arrow's settled cast counts no extra arrows", file: A, from: "left: Math.min(R.SPIRIT_ARROW_MAX_ARROWS - 1, int(ctx.warpMods?.bonusValue)) });", to: "left: 0 });" },
  { name: "Bouncy Body's hour warp is ignored", file: A, from: "seconds: /hour/i.test(String(ctx.warpMods?.durationText ?? \"\")) ? 3600 : 600,", to: "seconds: 600," },
  { name: "Chronoweave's warp slows allies too", file: A, from: "      if (t.actor === actor || allies(side(t), side(me)) || !within(me, t, R.CHRONO_FEET)) continue;", to: "      if (t.actor === actor || !within(me, t, R.CHRONO_FEET)) continue;" },
  { name: "Chronoweave's enemies are not made immune", file: A, from: "      await h().grantTemporaryImmunity?.(t.actor, \"Chronoweave\", durationSeconds(warpedDuration(ctx)) || 60);\n", to: "" },
  { name: "Metamagic Resonance lends to enemies", file: A, from: "    if (t.actor === caster || !allies(side(t), side(me)) || !within(me, t, rec.feet)) return null;", to: "    if (t.actor === caster || !within(me, t, rec.feet)) return null;" },
  { name: "Metamagic Resonance's lend outlives the aura", file: A, from: "  const live = auraLive(caster, rec);\n", to: "  const live = true;\n" },
  { name: "Metamagic Resonance lends a core feat by its option id", file: A, from: "export const lentKeyOf = (entry) => (entry?.source === \"core\" ? norm(String(entry.label ?? \"\").split(\" — \")[0]) : String(entry?.key ?? \"\"));", to: "export const lentKeyOf = (entry) => String(entry?.key ?? \"\");" },
  { name: "Flesh to Blossom's prelude does not write the type", file: A, from: "  if (ctx.spell.system?.damage?.type !== pick) await ctx.spell.update({ \"system.damage.type\": pick });\n", to: "" },
  { name: "Eaog's Dispel tick is forced on", file: A, from: "hint: \"\\\"Any attempts to dispel this spell are made at disadvantage.\\\" Tick it when the Dispel is aimed at Eaog Balls.\", optional: true, bias: \"disadvantage\" };", to: "hint: \"\\\"Any attempts to dispel this spell are made at disadvantage.\\\" Tick it when the Dispel is aimed at Eaog Balls.\", bias: \"disadvantage\" };" },
  { name: "Eaog's Dispel bias is offered against anyone", file: A, from: "    if (!target || !effects(target).some((e) => norm(e.name).startsWith(\"eaog balls\"))) return null;", to: "    if (!target) return null;" },
  // The review's fixes (7 November)
  { name: "Arcane Bastion's effects are left when the cast was never registered", file: A, from: "  if (ids.length) await writeOn(actor, { kind: \"deleteEffects\", ids });\n", to: "" },
  { name: "Mirror Reprise's last duplicate leaves the waiting effect", file: A, from: "    await writeOn(ctx.target, { kind: \"deleteEffects\", ids: [m.fx.id] });\n", to: "" },
  { name: "Mirror Reprise forgets its cast's entry", file: A, from: "module: { [MIRROR_FLAG]: { images: 0, castId: activeEntryFor(actor, ctx.spell?.name)?.id ?? \"\",", to: "module: { [MIRROR_FLAG]: { images: 0, castId: \"\"," },
  { name: "Metamagic Resonance is keyed on the spell's id", file: A, from: "  const castId = activeEntryFor(actor, ctx.spell?.name)?.id ?? \"\";\n  const rec = { key: lentKeyOf(chosen)", to: "  const castId = String(ctx.spell?.id ?? \"\");\n  const rec = { key: lentKeyOf(chosen)" },
  { name: "an aura outlives its cast in the registry", file: A, from: "worldNow() < Number(rec.until ?? 0) && (!rec.castId || castRunning(caster, rec.castId));", to: "worldNow() < Number(rec.until ?? 0);" },
  { name: "an aura outlives its duration", file: A, from: "const auraLive = (caster, rec) => Boolean(rec) && worldNow() < Number(rec.until ?? 0) &&", to: "const auraLive = (caster, rec) => Boolean(rec) &&" },
  { name: "a lent effect carries no duration", file: A, from: "    }), duration: { seconds: Math.max(6, Number(rec.until) - worldNow()), startTime: worldNow() } };\n  };\n}\n\nfunction chronoWants", to: "    }) };\n  };\n}\n\nfunction chronoWants" },
  { name: "an aura's effects stay when the creature leaves", file: A, from: "    if (drop.length) await writeOn(who, { kind: \"deleteEffects\", ids: drop.map((e) => e.id) });\n", to: "" },
  { name: "Chronoweave's slowed loses its value", file: A, from: "statuses: [\"slowed\"], system: { value: slowed },", to: "statuses: [\"slowed\"]," },
  { name: "Chronoweave quickens enemies", file: A, from: "    if (t.actor === caster || allies(side(t), side(me))) {\n      return { ...effectData(CHRONO_FLAG, { name: \"Chronoweave: quickened\"", to: "    if (true) {\n      return { ...effectData(CHRONO_FLAG, { name: \"Chronoweave: quickened\"" },
  { name: "Chronoweave reaches 40 ft", file: R, from: "export const CHRONO_FEET = 20;", to: "export const CHRONO_FEET = 40;" },
  { name: "Chronoweave's immunity is a minute whatever the duration", file: A, from: "      await h().grantTemporaryImmunity?.(t.actor, \"Chronoweave\", durationSeconds(warpedDuration(ctx)) || 60);", to: "      await h().grantTemporaryImmunity?.(t.actor, \"Chronoweave\", 600);" },
  { name: "Chronoweave keeps its condition row (lands only at the cast)", file: C, from: "    effects: [{ kind: \"note\", text: \"You and willing allies inside the 20-ft emanation are quickened while inside (kept by the module as creatures move).\" }],", to: "    effects: [cond(\"quickened\")]," },
  { name: "Panic Transposition's teleport moved back to the hit", file: A, from: "  panicPending.set(bearer.uuid, { attackerUuid: ctx.actor?.uuid ?? \"\", bearerUuid: bearer.uuid, bearer, unlocks, dc: int(q.result.saveDC), at: Date.now() });\n", to: "  panicPending.set(bearer.uuid, { attackerUuid: ctx.actor?.uuid ?? \"\", bearerUuid: bearer.uuid, bearer, unlocks, dc: int(q.result.saveDC), at: Date.now() });\n  await forOwner(bearer, \"panicTeleport\", { unlocks, dc: int(q.result.saveDC) });\n" },
  { name: "Panic Transposition's teleport is never sent", file: A, from: "    await forOwner(bearer, \"panicTeleport\", { unlocks: rec.unlocks, dc: rec.dc });\n", to: "" },
  { name: "Panic Transposition's teleport runs on the attacker's client", file: A, from: "    await forOwner(bearer, \"panicTeleport\", { unlocks: rec.unlocks, dc: rec.dc });\n", to: "    await ownerTasks.panicTeleport(bearer, { unlocks: rec.unlocks, dc: rec.dc });\n" },
  { name: "Panic Transposition's teleport at the Panic cast's DC lost", file: A, from: "{ unlocks: rec.unlocks, dc: rec.dc }", to: "{ unlocks: rec.unlocks, dc: 0 }" },
  { name: "a spell attack's settled cast leaves Panic pending", file: A, from: "  await clearPanicFor(actor, { resolved: Boolean(ctx.cast) && !ctx.refunded });\n", to: "" },
  { name: "a spell attack's settled cast sends no teleport", file: A, from: "  await clearPanicFor(actor, { resolved: Boolean(ctx.cast) && !ctx.refunded });", to: "  await clearPanicFor(actor, { resolved: false });" },
  { name: "a refunded cast still teleports", file: A, from: "  await clearPanicFor(actor, { resolved: Boolean(ctx.cast) && !ctx.refunded });", to: "  await clearPanicFor(actor, { resolved: true });" },
  { name: "a resolved Strike leaves Panic pending", file: A, from: "  await clearPanicFor(ctx.attacker, { resolved: Boolean(ctx.resolved) });\n", to: "" },
  { name: "a Strike never resolved still teleports", file: A, from: "  await clearPanicFor(ctx.attacker, { resolved: Boolean(ctx.resolved) });", to: "  await clearPanicFor(ctx.attacker, { resolved: true });" },
  { name: "a downed bearer still teleports", file: A, from: "    if (panicBearerDown(bearer)) continue;\n", to: "" },
  { name: "Panic Transposition's card says the teleport is at the hit", file: C, from: "once the attack has been resolved (its damage dealt), your player's client asks you", to: "at once, at the hit, your player's client asks you" },
  { name: "Panic Transposition's occupied save at DC 0", file: A, from: "  return { cast: Boolean(result?.cast), unlocks: unlocksOf(result?.warpMods), saveDC: settledSaveDC(actor, \"panicTransposition\") };", to: "  return { cast: Boolean(result?.cast), unlocks: unlocksOf(result?.warpMods), saveDC: int(result?.saveDC) };" },
  { name: "the settled Save DC is not recorded", file: A, from: "  if (key && actor?.uuid) settledDC.set(`${actor.uuid}:${key}`, int(ctx.saveDC));\n", to: "" },
  { name: "Arcane Feedback's injury at DC 0", file: A, from: "  const saveDC = settledSaveDC(actor, \"arcaneFeedback\");", to: "  const saveDC = 0;" },
  { name: "Primal Snap's speed penalty on a Partial", file: A, from: "    if (R.basicSaveFailed(hit?.degree) && !ownEffects(actor, \"primalSnapSpeed\").length) {", to: "    if (R.failedOrWorse(hit?.degree) && !ownEffects(actor, \"primalSnapSpeed\").length) {" },
  { name: "a write on an unowned creature is tried directly", file: A, from: "  if (actor.isOwner) return applyWrite(actor, op);", to: "  if (true) return applyWrite(actor, op);" },
  { name: "the GM side writes anything", file: A, from: "export function writeRefusal(op = {}, effectsOfActor = [], actor = null) {\n", to: "export function writeRefusal(op = {}, effectsOfActor = [], actor = null) {\n  return \"\";\n" },
  { name: "work for the owner is never sent", file: A, from: "  globalThis.game?.socket?.emit?.(SOCKET, { action: B7_ACTION, kind: \"owner\", actorUuid: actor.uuid, task, data });", to: "" },
  { name: "Mirror Reprise's teleport runs on the attacker's client", file: A, from: "  if (m.rec.teleport) await forOwner(ctx.target, \"mirrorStep\", {});", to: "  if (m.rec.teleport) await ownerTasks.mirrorStep(ctx.target, {});" },
  { name: "the veil is written on the anchored creature's mark", file: A, from: "    const veil = Array.from(sourceActor(rec?.casterUuid)?.flags?.[MODULE_ID]?.[ANCHOR_VEIL_FLAG] ?? []).includes(rec?.castId);", to: "    const veil = Boolean(rec?.veil);" },
  { name: "Invoke True Name's spent record is written on the mark", file: A, from: "  await caster.setFlag?.(MODULE_ID, TRUE_NAME_SPENT, [...spent.slice(-19), key]);", to: "  await on.effect.setFlag?.(MODULE_ID, TRUE_NAME_SPENT, true);" },
  { name: "Argent Reversal's refund is written directly (on the caster's client)", file: A, from: "      const regain = int(q.result.regained);", to: "      const regain = R.argentAbsorbPP(ctx.castPP ?? ctx.pp);\n      if (regain) await bearer.update({ \"system.resources.pp.value\": int(bearer.system?.resources?.pp?.value) + regain });" },
  { name: "Spectral Aegis's end is written directly", file: A, from: "  await writeOn(warded, { kind: \"deleteEffects\", ids: [...new Set([fx.id, ...resist])] });", to: "  await warded.deleteEmbeddedDocuments(\"ActiveEffect\", [...new Set([fx.id, ...resist])]);" },
  { name: "Elemental Strike's card claims Strikes are counted", file: C, from: "*By hand:* that each counts as a Strike for rules that count Strikes (Q155) — the Use fires no Strike and no Strike count.", to: "Each counts as a Strike for rules that count Strikes (Q155)." },
  // The harness gaps (7 November)
  { name: "Argent Reversal: any caster, seen or not (Q153)", file: A, from: "    if (!canSee(bearer, casterToken) || !R.argentReaches(ctx.castPP ?? ctx.pp, casterLevelOf(bearer))) continue;", to: "    if (!R.argentReaches(ctx.castPP ?? ctx.pp, casterLevelOf(bearer))) continue;" },
  { name: "Argent Reversal: a hidden caster is seen", file: A, from: "export const canSee = (bearer, casterToken) => !bearer?.hasCondition?.(\"blinded\") && !casterToken?.document?.hidden &&", to: "export const canSee = (bearer, casterToken) => !bearer?.hasCondition?.(\"blinded\") &&" },
  { name: "Argent Reversal's Critical may pick any creature, in range or not", file: A, from: "tokens().filter((t) => t.actor !== actor && t !== casterToken && within(casterToken, t, rangeFeet))", to: "tokens().filter((t) => t.actor !== actor && t !== casterToken)" },
  { name: "Spectral Aegis absorbs an ally's spell (Q152)", file: A, from: "    if (warded === caster || allies(side(t), side(casterToken))) continue;\n    const fx = ownEffects(warded, AEGIS_FLAG)[0];", to: "    if (warded === caster) continue;\n    const fx = ownEffects(warded, AEGIS_FLAG)[0];" },
  { name: "Elemental Strike without a melee weapon (Q155)", file: A, from: "    if (!weapon) return warn(\"Elemental Strike: wield a melee weapon (Q155).\");\n", to: "" },
  { name: "the teleports have no distance cap", file: A, from: "  if (dist > feet) { warn(`${label}: that is ${Math.round(dist)} feet away; you may go up to ${feet} feet.`); return null; }\n", to: "" },
  { name: "Mirror Reprise's step is 30 ft", file: R, from: "export const MIRROR_TELEPORT_FEET = 10;", to: "export const MIRROR_TELEPORT_FEET = 30;" },
  { name: "Panic Transposition's base is 40 ft", file: R, from: "export const PANIC_FEET = 30;", to: "export const PANIC_FEET = 40;" },
  // The second review's findings (7 November)
  { name: "the GM relay accepts a forged cast id", file: A, from: "      return Boolean(c) && casts.has(String(c));", to: "      return Boolean(c) && (casts.has(String(c)) || c === op.castId);" },
  { name: "the GM relay deletes any cast-stamped effect", file: A, from: "      return Boolean(c) && casts.has(String(c));", to: "      return Boolean(c);" },
  { name: "the GM relay takes the Aegis's cast id from any effect", file: A, from: "    if (src !== AEGIS_FLAG && src !== MIRROR_FLAG) continue;\n", to: "" },
  { name: "a flag write under another module key", file: A, from: "    if (!e || !FLAG_KEYS.includes(op.key) || src !== op.key) return \"not this module's flag\";", to: "    if (!e || !FLAG_KEYS.includes(op.key) || !OWN_SOURCES.includes(src)) return \"not this module's flag\";" },
  { name: "the GM relay accepts a forged flag value", file: A, from: "    return flagChangeAllowed(op.key, e.flags?.[MODULE_ID]?.[op.key], op.value) ? \"\" : \"not a change the module makes\";", to: "    return \"\";" },
  { name: "a flag write may change fields beside the counter", file: A, from: "  for (const k of keys) if (k !== field && !sameJSON(prev[k], next[k])) return false;\n", to: "" },
  { name: "a counter may drop by more than one", file: A, from: "  if (now === was - 1 && now >= 0) return true;", to: "  if (now < was && now >= 0) return true;" },
  { name: "Mirror Reprise may be re-armed at any count", file: A, from: "  return key === \"mirrorReprise\" && was === 0 && now === R.MIRROR_IMAGES;", to: "  return key === \"mirrorReprise\" && now === R.MIRROR_IMAGES;" },
  { name: "the relay writes PP again (uncapped)", file: A, from: "  return \"unknown write\";\n}\n\n/** Do the write (on a creature this client owns, or as the GM). */\nexport async function applyWrite(actor, op) {\n  if (!actor) return false;\n  const list = effects(actor);\n  if (writeRefusal(op, list, actor)) return false;\n", to: "  if (op.kind === \"addPP\") return \"\";\n  return \"unknown write\";\n}\n\n/** Do the write (on a creature this client owns, or as the GM). */\nexport async function applyWrite(actor, op) {\n  if (!actor) return false;\n  const list = effects(actor);\n  if (writeRefusal(op, list, actor)) return false;\n  if (op.kind === \"addPP\") { await actor.update({ \"system.resources.pp.value\": int(actor.system?.resources?.pp?.value) + int(op.amount) }); return true; }\n" },
  { name: "Argent Reversal's refund relayed again", file: A, from: "      const regain = int(q.result.regained);", to: "      const regain = R.argentAbsorbPP(ctx.castPP ?? ctx.pp);\n      if (regain) await writeOn(bearer, { kind: \"addPP\", amount: regain });" },
  { name: "Argent Reversal's refund uncapped by the PP maximum", file: A, from: "    regained = Math.min(R.argentAbsorbPP(data?.castPP), room);", to: "    regained = R.argentAbsorbPP(data?.castPP);" },
  { name: "Arcane Bastion's record unset on an unowned bearer", file: A, from: "  if (actor?.isOwner && actor?.flags?.[MODULE_ID]?.[BASTION_FLAG]?.castId === castId) await actor.unsetFlag?.(MODULE_ID, BASTION_FLAG);", to: "  if (actor?.flags?.[MODULE_ID]?.[BASTION_FLAG]?.castId === castId) await actor.unsetFlag?.(MODULE_ID, BASTION_FLAG);" },
  { name: "the GM leaves the Bastion's record", file: A, from: "    if (bastion && !effects(actor).some((e) => castIdOf(e) === bastion)) await actor.unsetFlag?.(MODULE_ID, BASTION_FLAG);\n", to: "" },
  { name: "the aura sync is not serialised", file: A, from: "  if (syncRunning) { syncDirty = true; return syncRunning; }\n", to: "" },
  { name: "a sync asked during a run is dropped", file: A, from: "      } while (syncDirty || syncForced.size);", to: "      } while (false);" },
  { name: "a duplicate aura effect is kept", file: A, from: "    const drop = has.filter((e) => e !== keep);", to: "    const drop = keep ? [] : has;" },
  { name: "a re-cast keeps the old duration", file: A, from: "JSON.stringify({ until: Number(rec?.until ?? 0), castId", to: "JSON.stringify({ castId" },
  { name: "syncAll loses its actsFor guard", file: A, from: "    if (!caster || done.has(caster) || !caster.isOwner || !actsFor(caster)) continue;", to: "    if (!caster || done.has(caster) || !caster.isOwner) continue;" },
  { name: "a caster's token deleted leaves its aura", file: A, from: "  await syncAll({ force: caster, noToken: true });\n", to: "" },
  { name: "Panic Transposition's resistance drops after 30 s", file: A, from: "  if (!rec) return null;\n  if (!rec.unlocks?.includes(R.PANIC_RESIST_UNLOCK)", to: "  if (!rec || Date.now() - rec.at > 30000) return null;\n  if (!rec.unlocks?.includes(R.PANIC_RESIST_UNLOCK)" },
  { name: "Panic Transposition's teleport drops after 30 s", file: A, from: "    if (resolved && mine) due.push(rec);", to: "    if (resolved && mine && Date.now() - rec.at <= 30000) due.push(rec);" },
  { name: "clearPanicFor loses its attacker filter", file: A, from: "    if (!mine && Date.now() - rec.at <= PANIC_PURGE_MS) continue;\n", to: "" },
  { name: "a stale Panic record is never purged", file: A, from: "    if (!mine && Date.now() - rec.at <= PANIC_PURGE_MS) continue;", to: "    if (!mine) continue;" },
  { name: "Mirror Reprise's waiting effect carries no core cast id", file: A, from: "        system: mirrorCastStamp(activeEntryFor(actor, ctx.spell?.name)?.id),\n", to: "" },
  { name: "Mirror Reprise survives its end", file: A, from: "const mirrorLive = (actor, fx) => { const rec = fx?.flags?.[MODULE_ID]?.[MIRROR_FLAG]; return Boolean(rec) && (!rec.castId || castRunning(actor, rec.castId)); };", to: "const mirrorLive = (actor, fx) => Boolean(fx?.flags?.[MODULE_ID]?.[MIRROR_FLAG]);" },
  { name: "Elemental Strike's chat card claims the Strike count", file: A, from: "line(\"<em>No multiple attack penalty is taken or added (Q155). By hand: that it counts as a Strike for rules that count Strikes \u2014 this Use fires no Strike and no Strike count.</em>\")", to: "line(\"<em>A Strike for rules that count them; no multiple attack penalty is taken or added (Q155).</em>\")" },
  { name: "the socket listener is not registered at ready", file: SCRIPT, from: "Hooks.once(\"ready\", () => registerBlock7Socket());", to: "" },
  { name: "module.json asks for no socket", file: MANIFEST, from: "  \"socket\": true,\n", to: "" },
  { name: "every GM applies a relayed write", file: A, from: "    if (!isActingGM()) return false;\n    return applyWrite(actor, data.op ?? {});", to: "    if (!game?.user?.isGM) return false;\n    return applyWrite(actor, data.op ?? {});" },
  { name: "a player's client applies relayed writes", file: A, from: "    if (!isActingGM()) return false;\n    return applyWrite(actor, data.op ?? {});", to: "    return applyWrite(actor, data.op ?? {});" },
  { name: "onCombatSyncB7 is not wired to updateCombat", file: SCRIPT, from: "Hooks.on(\"updateCombat\", (combat, change) => { onCombatSyncB7(combat, change).catch(warnB7(\"Metamagic Resonance or Chronoweave\")); });\n", to: "" },
  { name: "onTokenDeletedB7 is not wired to deleteToken", file: SCRIPT, from: "Hooks.on(\"deleteToken\", (doc) => { onTokenDeletedB7(doc).catch(warnB7(\"Metamagic Resonance or Chronoweave\")); });\n", to: "" },
  // The wiring
  { name: "the settled cast is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB7(ctx)", to: "Hooks.on(\"trgPrimeSpellCast\", (ctx) => { onSpellSettledB7(ctx)" },
  { name: "Primal Snap's turn is not wired", file: SCRIPT, from: "Hooks.on(\"updateCombat\", (combat, change) => { onCombatTurnB7(combat, change)", to: "Hooks.on(\"updateCombatant\", (combat, change) => { onCombatTurnB7(combat, change)" },
  { name: "Block 7 is not registered", file: REG, from: "  registerBlock7(api, moduleId);\n", to: "" },
  { name: "the Draconic Pact grants no Dragon's Breath", file: B6A, from: "const breath = await grantPactSpellB7(actor, item, \"dragonsBreath\", await spellDataFor(\"Dragon’s Breath\"));", to: "const breath = null;" },
  { name: "the module asks for 3.684.1 again", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.687.1\";", to: "export const REQUIRED_SYSTEM = \"3.684.1\";" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block7.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block7: verify-block7 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block7: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block7: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
