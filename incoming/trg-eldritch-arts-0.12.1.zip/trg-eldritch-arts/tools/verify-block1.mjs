#!/usr/bin/env node
/**
 * verify-block1 — Eldritch Arts Block 1 (0.1.0; 0.1.1; 0.2.0, book v1.6): Chapter 2's races,
 * heritages, racial abilities and backgrounds, the nine background feats,
 * Orb of Water, Chapter 4's actions, Chapter 6's exotic weapons and goods.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block1.mjs
 *
 * Needs TRG Prime 3.677.0 at TRG_PRIME_ROOT.
 *
 *   A  The book (tools/content/book-text.json, cut from the v1.4 docx by
 *      extract-book.mjs): every printed line in the item that carries it;
 *      race + size table = the printed attribute line; the numbers of every
 *      weapon and good
 *   B  The system reads the declarations, each through its own reader
 *   C  Resolution: every name a grant points at exists (this module's packs
 *      or the system's)
 *   D  Registration, against the system's own registry, and the decisions
 *   E  Wiring: the hooks, versions, packs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }

const B1 = await import("./content/block1.mjs");
const { PACKS } = await import("./content/packs.mjs");
const { md } = await import("./content/markdown.mjs");
const { parseAbilityModifiers } = await import("./content/builders.mjs");
const reg = await import("../module/registration.mjs");
const auto = await import("../module/block1-automations.mjs");
const actions = await import("../module/block1-actions.mjs");
const clock = await import("../module/effects-clock.mjs");
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));

const api = await import(sys("module", "module-api.mjs"));
const cond = await import(sys("module", "conditionals.mjs"));
const { BONUS_TYPES } = await import(sys("module", "dice", "resolution.mjs"));
const { SIZE_TABLE } = await import(sys("module", "config.mjs"));
const car = await import(sys("module", "creature-ability-rules.mjs"));
const dcBonus = await import(sys("module", "magic", "spell-dc-bonus.mjs"));
const dmgBonus = await import(sys("module", "magic", "spell-damage-bonus.mjs"));
const fumble = await import(sys("module", "fumble-reroll.mjs"));
const gso = await import(sys("module", "general-skill-options.mjs"));
const prof = await import(sys("module", "proficiency-rules.mjs"));
const goods = await import(sys("module", "goods.mjs"));
const surcharge = await import(sys("module", "magic", "cast-surcharge.mjs"));
const gates = await import(sys("module", "magic", "spell-check-gates.mjs"));
const clm = await import(sys("module", "magic", "caster-level-mods.mjs"));
const langs = await import(sys("module", "languages.mjs"));
const bsave = await import(sys("module", "magic", "beneficial-save.mjs"));
const systemJson = JSON.parse(fs.readFileSync(path.join(SYSTEM_ROOT, "system.json"), "utf8"));
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "module.json"), "utf8"));

const strip = (html) => String(html).replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
const has = (doc, line) => strip(doc.system.description).includes(strip(md(line)));
const missingLines = (doc, lines) => (lines ?? []).filter((l) => !has(doc, l));
const F = (doc) => doc?.flags?.["trg-prime"] ?? {};
const effectFlags = (doc) => (doc?.effects ?? []).map((e) => e.flags?.["trg-prime"] ?? {});
const changes = (doc) => (doc?.effects ?? []).flatMap((e) => e.changes ?? []);
const list = (s) => String(s ?? "").split(",").map((x) => x.trim()).filter(Boolean);
const byName = (docs) => Object.fromEntries(docs.map((d) => [d.name, d]));
const races = byName(B1.RACES), heritages = byName(B1.HERITAGES), abilities = byName(B1.ABILITIES);
const feats = byName(B1.BACKGROUND_FEATS), weapons = byName(B1.WEAPONS), goodsBy = byName(B1.GOODS);
// Block 5 (0.8.0) adds 108 feats to these packs; verify-block5a–d hold them.
const B5_IDS = new Set((await Promise.all(["a", "b", "c", "d"].map((g) => import(new URL(`./content/block5-${g}.mjs`, import.meta.url)))))
  .flatMap((m) => Object.entries(m).filter(([k, v]) => /^(FEATS|ABILITIES)_B5_/.test(k) && Array.isArray(v)).flatMap(([, v]) => v)).map((d) => d._id));
// …and Block 6 (0.9.0) its archetypes, class feats, abilities and spells; verify-block6a–e hold them.
for (const id of (await Promise.all(["a", "b1", "b2", "c", "d", "e"].map((g) => import(new URL(`./content/block6-${g}.mjs`, import.meta.url)))))
  .flatMap((m) => Object.entries(m).filter(([k, v]) => /^(FEATS|ABILITIES|SPELLS)_B6_/.test(k) && Array.isArray(v)).flatMap(([, v]) => v)).map((d) => d._id)) B5_IDS.add(id);
const ALL = PACKS.flatMap((p) => p.docs).filter((d) => !B5_IDS.has(d._id));

/* ------------------------------------------------------------------ *
 * A. The book
 * ------------------------------------------------------------------ */

const ATTR = { str: "strength", dex: "dexterity", con: "constitution", int: "intelligence", wis: "wisdom", cha: "charisma" };
/** "Str -3, Con -1, Dex +4, Cha +2" (and the book's "Int +1 Cha +1") → {strength: -3, …}. */
function printedMods(text) {
  const out = {};
  for (const m of String(text).matchAll(/\b(Str|Dex|Con|Int|Wis|Cha)\s*([+-]\d+)/g)) out[ATTR[m[1].toLowerCase()]] = Number(m[2]);
  return out;
}
const statLine = (lines) => (lines ?? []).find((l) => /\*\*Ability Modifiers\*\*/.test(l)) ?? "";
const field = (line, name) => (new RegExp(`\\*\\*${name}:?\\*\\*:?\\s*([^;*]+)`).exec(line)?.[1] ?? "").trim();
/** What the sheet shows: the item's racial changes plus the size table's Str/Dex. */
function sheetMods(docs, size) {
  const out = {};
  for (const c of docs.flatMap(changes)) {
    const m = /^system\.attributes\.(\w+)\.racial$/.exec(c.key);
    if (m) out[m[1]] = (out[m[1]] ?? 0) + Number(c.value);
  }
  const s = SIZE_TABLE[size];
  if (s?.strMod) out.strength = (out.strength ?? 0) + s.strMod;
  if (s?.dexMod) out.dexterity = (out.dexterity ?? 0) + s.dexMod;
  return Object.fromEntries(Object.entries(out).filter(([, v]) => v !== 0).sort());
}
const sorted = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== 0).sort());
const sizeOf = (docs) => {
  const rows = docs.flatMap(changes).filter((c) => c.key === "system.identity.size").sort((a, b) => a.priority - b.priority);
  return rows.at(-1)?.value ?? "medium";
};

equal("A the four races, in the book's order", B1.RACES.map((r) => r.name.toUpperCase()), Object.keys(book.chapter2.races));
for (const [key, entry] of Object.entries(book.chapter2.races)) {
  const r = races[B1.RACE_NAME[key]];
  ok(`A ${key} exists`, Boolean(r)); if (!r) continue;
  const line = statLine(entry.text);
  ok(`A ${key}: the stat line was found`, Boolean(line));
  equal(`A ${key}: the printed attribute line is the field the sheet shows`, sorted(printedMods(r.system.abilityModifiers)), sorted(printedMods(field(line, "Ability Modifiers"))));
  const size = field(line, "Size").toLowerCase();
  equal(`A ${key}: race effect + the size table's row = the printed line`, sheetMods([r], sizeOf([r])), sorted(printedMods(field(line, "Ability Modifiers"))));
  equal(`A ${key}: size and Speed as printed`, [sizeOf([r]), changes(r).find((c) => c.key === "system.combat.movement.land")?.value], [size, String(Number.parseInt(field(line, "Speed"), 10))]);
  equal(`A ${key}: Power Points per level as printed, registered`, reg.RACIAL_PP[r.name], Number(field(line, "Power Points").replace("+", "")));
  const langLine = entry.text.find((l) => /Core Languages/.test(l)) ?? "";
  const core = /\*\*Core Languages:\*\*\s*([^;]+);/.exec(langLine)?.[1].split(/&|,/).map((s) => s.trim()).filter(Boolean) ?? [];
  equal(`A ${key}: core languages as printed`, list(r.system.coreLanguages), key === "EMBERKIN" ? core.filter((l) => l !== "Elemental Language") : core);
  equal(`A ${key}: the racial abilities are the book's`, list(r.system.racialAbilities), Object.keys(entry.abilities));
  const spec = (entry.text.find((l) => /^You gain .* as a specialist skill/.test(l)) ?? "").replace(/^You gain (.*) as a specialist skill\.?$/, "$1").split("&").map((s) => s.trim());
  equal(`A ${key}: specialist skills as printed`, list(r.system.specialistSkills), spec);
  equal(`A ${key}: every printed paragraph is in the race's description`, missingLines(r, entry.text), []);
}
// Every core language the races and heritages name is the system's.
for (const doc of [...B1.RACES, ...B1.HERITAGES]) for (const l of list(doc.system.coreLanguages)) ok(`A ${doc.name}: ${l} is a language the system knows`, Object.keys(langs.CORE_LANGUAGES ?? langs.LANGUAGES ?? {}).length === 0 || Object.hasOwn(langs.CORE_LANGUAGES ?? langs.LANGUAGES ?? {}, l));
equal("A Emberkin: each heritage's elemental tongue (B1-1)", ["Stonevein", "Galeborne", "Cinderblood", "Tidemarked"].map((n) => heritages[n].system.coreLanguages), ["Gaian", "Aeolian", "Ignic", "Aqualis"]);

equal("A eighteen heritages, in the book's order", B1.HERITAGES.map((h) => h.name), Object.keys(book.chapter2.heritages).map((k) => B1.HERITAGE_NAME[k]));
for (const [key, entry] of Object.entries(book.chapter2.heritages)) {
  const h = heritages[B1.HERITAGE_NAME[key]];
  ok(`A ${key} exists`, Boolean(h)); if (!h) continue;
  equal(`A ${key}: of the race the book files it under`, h.system.sourceRace, B1.RACE_NAME[entry.race]);
  equal(`A ${key}: every printed paragraph is in its description`, missingLines(h, entry.text), []);
}
// Each heritage's printed mechanics, as the item carries them.
const resists = (doc) => changes(doc).filter((c) => c.key === "system.combat.resistances").map((c) => c.value.replace(/^,\s*/, ""));
const HERITAGE_RULES = {
  Aeralis: ["electricity", "Gust", true], Astryn: ["force", "Guiding Bolt", true], Caelari: ["essence", "Shield", true],
  Nerathis: [null, "Anticipate Attack", true], Umbryth: ["cold", "Cloak of Greying", true],
  Stonevein: ["acid", "Orb of Acid", false], Galeborne: ["electricity", "Orb of Lightning", false], Cinderblood: ["fire", "Orb of Fire", false], Tidemarked: ["cold", "Orb of Water", false],
  "Vel-tharis": [null, "Silence", true], "Vir-ellian": [null, "", false], "Zhal-vryn": [null, "Cancel Magic", true],
  Sparktail: ["fire", "Orb of Fire", true], Glyphweave: [null, "Scribers Chant", true], Dustscale: [null, "", false],
  Ironmuk: ["poison", "Purify", true], Wisperfin: [null, "Cloak of Greying", true], Wyrmdral: [null, "", false]
};
for (const [name, [resist, spell, innate]] of Object.entries(HERITAGE_RULES)) {
  const h = heritages[name];
  equal(`A ${name}: resistance, granted spell, innate — as printed`, [resists(h), h.system.grantedSpells, Boolean(F(h).grantInnate)], [resist ? [resist] : [], spell, innate]);
  const text = book.chapter2.heritages[Object.keys(B1.HERITAGE_NAME).find((k) => B1.HERITAGE_NAME[k] === name)].text.join(" ");
  if (resist) ok(`A ${name}: the book prints resistance to ${resist}`, new RegExp(`resistance to ${resist}|${resist} resistance`, "i").test(text));
  if (spell) ok(`A ${name}: the book names ${spell}`, text.toLowerCase().includes(spell.toLowerCase()));
  if (innate) ok(`A ${name}: the book says innate`, /innate spell/i.test(text));
  if (spell && !innate) ok(`A ${name}: the book does not say innate`, !/innate spell/i.test(text));
}
equal("A Emberkin: the element Elemental Symbiosis reads is the heritage's resistance", ["Stonevein", "Galeborne", "Cinderblood", "Tidemarked"].map((n) => F(heritages[n]).eaElement), ["Stonevein", "Galeborne", "Cinderblood", "Tidemarked"].map((n) => resists(heritages[n])[0]));
equal("A Vel-tharis's aura is 10 ft; Zhal-vryn's surcharge 1 PP; Vir-ellian drains its class bonus more", [F(heritages["Vel-tharis"]).eaNullAuraFeet, F(heritages["Zhal-vryn"]).eaCastSurcharge, F(heritages["Vir-ellian"]).eaMagicDrainBonus], [10, 1, "classBonus"]);
ok("A …as printed", /10-foot radius/.test(book.chapter2.heritages["VEL-THARIS"].text.join(" ")) && /additional PP/.test(book.chapter2.heritages["ZHAL-VRYN"].text.join(" ")) && /class bonus/i.test(book.chapter2.heritages["VIR-ELLIAN"].text.join(" ")));
equal("A Dustscale: burrow 10 ft; Wisperfin: +2 racial Stealth; Ironmuk: breath ×2", [changes(heritages.Dustscale).find((c) => c.key === "system.combat.movement.burrow.base")?.value, changes(heritages.Wisperfin).find((c) => c.key === "system.skills.stealth.racial")?.value, F(heritages.Ironmuk).creatureAbility?.derives?.breathMultiplier], ["10", "2", 2]);
ok("A …as printed", /burrow speed of 10/i.test(book.chapter2.heritages.DUSTSCALE.text.join(" ")) && /\+2 racial bonus to stealth/i.test(book.chapter2.heritages.WISPERFIN.text.join(" ")) && /twice the normal time/i.test(book.chapter2.heritages.IRONMUK.text.join(" ")));
equal("A Natural Armour: base DR 1, as printed", [changes(abilities["Natural Armour"]).find((c) => c.key === "system.combat.naturalArmourBase.natural")?.value, /base DR of 1|DR 1/i.test(book.chapter2.races.SCAELYN.abilities["Natural Armour"])], ["1", true]);
equal("A Orb of Water's secondary packet: 1 cold", B1.SPELLS[0].system.secondaryDamage, { formula: "1", type: "cold" });
ok("A …as printed", /1 (secondary )?cold/i.test(book.grimoire.find((x) => x.name === "ORB OF WATER").lines.join(" ")));
equal("A Sparktail's +2 racial on Create and disarming; Dustscale's advantage on Hide and Sneak", [F(heritages.Sparktail).conditionals.map((c) => [c.value, c.type]), F(heritages.Dustscale).conditionals.map((c) => c.when.actions)], [[[2, "race"], [2, "race"]], [["hide", "sneak"]]]);
// Wyrmdral: "uses the following racial mechanics instead of those provided above".
{
  const line = statLine(book.chapter2.heritages.WYRMDRAL.text);
  const both = [races.Scaelyn, heritages.Wyrmdral];
  equal("A Wyrmdral: Scaelyn + Wyrmdral, at the size they set, = the Wyrmdral's printed line", sheetMods(both, sizeOf(both)), sorted(printedMods(field(line, "Ability Modifiers"))));
  equal("A Wyrmdral: Medium, as printed", sizeOf(both), field(line, "Size").toLowerCase());
  equal("A Wyrmdral: the printed field is the line itself", sorted(printedMods(heritages.Wyrmdral.system.abilityModifiers)), sorted(printedMods(field(line, "Ability Modifiers"))));
  equal("A Wyrmdral's Power Points are the Scaelyn's (+1), no heritage PP registered", [Number(field(line, "Power Points").replace("+", "")), reg.RACIAL_PP.Wyrmdral], [reg.RACIAL_PP.Scaelyn, undefined]);
}
// Heritages that print a stat adjustment carry exactly it.
for (const [key, entry] of Object.entries(book.chapter2.heritages)) {
  if (key === "WYRMDRAL") continue;
  const h = heritages[B1.HERITAGE_NAME[key]];
  // "Your Wisdom increases by 1, and your Intelligence decreases by 1."
  const prose = {};
  for (const m of entry.text.join(" ").matchAll(/\b(Strength|Dexterity|Constitution|Intelligence|Wisdom|Charisma) (increases|decreases) by (\d+)/g)) prose[m[1].toLowerCase()] = (m[2] === "increases" ? 1 : -1) * Number(m[3]);
  if (!Object.keys(prose).length) { equal(`A ${key}: no adjustment printed, none carried`, [h.system.abilityModifiers, sheetMods([h], "medium")], ["", {}]); continue; }
  equal(`A ${key}: the printed adjustment, carried`, sheetMods([h], "medium"), sorted(prose));
  equal(`A ${key}: …and shown`, sorted(printedMods(h.system.abilityModifiers)), sorted(prose));
}

// Racial abilities: each one's printed text.
for (const [key, entry] of Object.entries(book.chapter2.races)) {
  for (const [name, text] of Object.entries(entry.abilities)) {
    const a = abilities[name];
    if (["Darkvision", "Nightvision"].includes(name)) { ok(`A ${name} is the core's ability (not shipped)`, !a); continue; }
    ok(`A ${name} exists`, Boolean(a)); if (!a) continue;
    ok(`A ${name}: its printed text`, has(a, `**${name}:** ${text}`));
    equal(`A ${name}: of the race`, a.system.sourceRace, B1.RACE_NAME[key]);
  }
}
const sidebar = book.sidebars.find((s) => s.title === "MAGIC DRAIN");
ok("A the Magic Drain sidebar was found", Boolean(sidebar));
equal("A Magic Drain: the sidebar's printed lines", missingLines(abilities["Magic Drain"], sidebar?.lines.slice(1)), []);
ok("A Vir-ellian Release: the heritage's release paragraph", has(abilities["Vir-ellian Release"], book.chapter2.heritages["VIR-ELLIAN"].text.at(-1)));

// Backgrounds.
equal("A twelve backgrounds, in the book's order; wealth for every one", [B1.BACKGROUNDS.length, Object.keys(B1.BACKGROUND_WEALTH).length], [12, 12]);
for (const b of Object.values(book.chapter2.backgrounds)) {
  const doc = B1.BACKGROUNDS.find((d) => d.name.toUpperCase() === b.name);
  ok(`A ${b.name} exists`, Boolean(doc)); if (!doc) continue;
  equal(`A ${b.name}: feat, skills, specialist as printed`, [doc.system.grantedFeats.replace(/’/g, "'"), doc.system.skillBonuses, doc.system.specialistSkill], [b.feat.replace(/’/g, "'"), b.skills, b.specialist]);
  equal(`A ${b.name}: its description`, missingLines(doc, b.description), []);
}
// Chapter 6's Background Wealth table (L4746), typed from the book (v1.6).
const WEALTH_TABLE = ["Arcane Investigator", 1, "Arcane Wayfarer", 2, "Cabal Exile", -1, "Elemental Adept", 0, "Enigmatic Scholar", 1, "Leyline Tracker", 0, "Magical Artisan", 1, "Ritualist Initiate", 0, "Shadowed Seer", -1, "Spirit Binder", 0, "Voidborn Outsider", -1, "Wild Mage Survivor", -1];
for (let i = 0; i < WEALTH_TABLE.length; i += 2) equal(`A ${WEALTH_TABLE[i]}: wealth ${WEALTH_TABLE[i + 1]}`, B1.BACKGROUNDS.find((d) => d.name === WEALTH_TABLE[i])?.system.wealth, String(WEALTH_TABLE[i + 1]));
// Book v1.6 prints Spirit Binder's row (B1-14 closed).
equal("A Spirit Binder: the row v1.6 prints, and no note that it is missing", [Boolean(B1.BACKGROUNDS.find((d) => d.name === "Spirit Binder")), has(B1.BACKGROUNDS.find((d) => d.name === "Spirit Binder"), "the Background Wealth table has no row for it")], [true, false]);
equal("A every background's wealth is the book's", B1.WEALTH_NOT_PRINTED, []);

// The background feats: every feat a background grants, each printed whole.
const CORE_BACKGROUND_FEATS = ["Improved Initiative", "Magical Crafting", "Scribe Scroll"];
equal("A the backgrounds grant the nine Eldritch Arts feats shipped here, and three of the core's", [...new Set(B1.BACKGROUND_FEATS.map((f) => f.name).concat(CORE_BACKGROUND_FEATS))].sort(), [...new Set(B1.BACKGROUND_FEATS.length ? B1.BACKGROUNDS.map((b) => b.system.grantedFeats) : [])].sort());
for (const f of B1.BACKGROUND_FEATS) {
  const src = book.sections.generalFeats.find((g) => g.name.replace(/’/g, "'") === f.name.toUpperCase().replace(/’/g, "'"));
  ok(`A ${f.name}: in Chapter 5's General feats`, Boolean(src)); if (!src) continue;
  equal(`A ${f.name}: every printed line`, missingLines(f, src.lines), []);
  equal(`A ${f.name}: prerequisites as printed`, f.system.prerequisites, src.fields.Prerequisites ?? "");
}

// Orb of Water.
{
  const orb = book.grimoire.find((s) => s.name === "ORB OF WATER");
  const s = B1.SPELLS[0];
  equal("A Orb of Water: every printed line", missingLines(s, orb.lines), []);
  equal("A Orb of Water: PP, traits", [s.system.ppCost, s.system.traits.split(", ").map((t) => t.toUpperCase()).sort()], [Number(orb.pp ?? 0), orb.traits.map((t) => t.toUpperCase()).sort()]);
}

// Chapter 4's actions: every outcome row and description is the book's.
const CH4 = book.chapter4;
const rowsOf = (lines) => Object.fromEntries((lines ?? []).map((l) => /^\*\*(Heroic|Critical|Success|Partial|Failure|Fumble|Blunder)\*\*\s*(.*)$/.exec(l)).filter(Boolean).map((m) => [m[1].toLowerCase(), m[2].trim()]));
const ACTION_SOURCE = { leySense: "LEY SENSE", appraiseMagic: "APPRAISE MAGIC", hypnotismSuggestion: "HYPNOTISM", hypnotismMemory: "HYPNOTISM", mysteriousScript: "MYSTERIOUS SCRIPT", quickbind: "QUICKBIND" };
for (const a of actions.SKILL_ACTIONS) {
  const src = ACTION_SOURCE[a.key];
  if (!src) continue;
  const printed = rowsOf(CH4[src]?.lines);
  ok(`A ${a.name}: the book's section was found`, Object.keys(printed).length > 0);
  for (const [k, text] of Object.entries(printed)) equal(`A ${a.name}: ${k} as printed`, a.outcomes[k], text);
  for (const [k, text] of Object.entries(a.outcomes)) if (text) ok(`A ${a.name}: ${k} is printed`, printed[k] === text);
}
{
  const printed = rowsOf(sidebar?.lines);
  const md_ = actions.SKILL_ACTIONS.find((a) => a.key === "magicDrain");
  for (const [k, text] of Object.entries(printed)) equal(`A Magic Drain: ${k} as printed`, md_.outcomes[k], text);
}
// The time ladders: "10 minutes (+0), 1 minute (-2), 1 round (-5), 1 AP (-10)" and Focused Ley Sense's five.
const ladderText = (l) => l.options.map((o) => `${o.label} (${o.modifier > 0 ? "+" : o.modifier === 0 ? "+" : ""}${o.modifier})`).join(", ");
ok("A Ley Sense's ladder is the printed one", CH4["LEY SENSE"].lines.join(" ").includes(ladderText(actions.TIME_LADDER)), ladderText(actions.TIME_LADDER));
ok("A Appraise Magic's ladder is the printed one", CH4["APPRAISE MAGIC"].lines.join(" ").includes(ladderText(actions.TIME_LADDER)));
const focused = book.sections.generalFeats.find((g) => g.name === "FOCUSED LEY SENSE");
ok("A Focused Ley Sense's ladder is the printed one", focused.lines.join(" ").replace(/\(\+0\)/g, "(+0)").includes(ladderText(actions.FOCUSED_TIME_LADDER)), ladderText(actions.FOCUSED_TIME_LADDER));
equal("A the module's ladder tables agree with the feat's item notes", [actions.TIME_LADDER.options.map((o) => o.modifier), actions.FOCUSED_TIME_LADDER.options.map((o) => o.modifier)], [B1.LEY_SENSE_LADDER.options.map((o) => o.modifier), B1.FOCUSED_LEY_SENSE_LADDER.options.map((o) => o.modifier)]);
equal("A minimum ranks as printed (Appraise Magic 5, Quickbind 5)", actions.SKILL_ACTIONS.filter((a) => a.minRanks).map((a) => [a.key, a.minRanks]), [["appraiseMagic", 5], ["quickbind", 5]]);
ok("A Appraise Magic and Quickbind print their ranks", /\*\*Ranks\*\* 5/.test(CH4["APPRAISE MAGIC"].lines.join("\n") + CH4["APPRAISE MAGIC"].heading) || CH4["APPRAISE MAGIC"].lines.some((l) => /Ranks\*\* 5/.test(l)));

// Weapons: every number in the table; every description.
const WEAPON_ROWS = [...book.sections.meleeWeapons.rows.slice(2), ...book.sections.rangedWeapons.rows.slice(2)];
equal("A eighteen exotic weapons, in the tables' order", B1.WEAPONS.map((w) => w.name), WEAPON_ROWS.map((r) => r.cells[0]));
for (const row of WEAPON_ROWS) {
  const [name, price, level, damage, size, fdc, weight, group, traits] = row.cells;
  const w = weapons[name];
  if (!w) { ok(`A ${name} exists`, false); continue; }
  const s = w.system;
  equal(`A ${name}: price, level, damage, size, FDC, weight, group`, [s.price, s.itemLevel, `${s.damage} ${s.damageType[0].toUpperCase()}`, s.size[0].toUpperCase(), s.fumbleDC, s.weight, s.group, s.category],
    [Number(price.replace(/[^\d.]/g, "")), Number(level), damage, size, Number(fdc), weight.trim() === "-" ? 0 : Number(weight.replace(/[^\d.]/g, "")), group, "Exotic"]);
  const printedTraits = traits.replace(/\.\s+/g, ", ").split(",").map((t) => t.trim()).filter(Boolean);
  const kept = printedTraits.filter((t) => t !== "Brace").map((t) => (t === "Nyrrin" ? "Nyrinn" : /^Reach \d+ ft$/.test(t) ? "Reach" : t));
  equal(`A ${name}: the printed traits (Brace held back, B1-12; Nyrrin → Nyrinn, B1-13), and Exotic`, list(s.traits), kept.includes("Exotic") ? kept : [...kept, "Exotic"]);
  ok(`A ${name}: the printed trait line is quoted`, has(w, `*Traits as printed:* ${traits}.`));
  const entry = book.sections.weaponEntries.find((e) => e.name.replace(/\s*\(.*\)$/, "").toLowerCase() === name.toLowerCase());
  ok(`A ${name}: its description entry`, Boolean(entry) && missingLines(w, entry.lines).length === 0);
  const range = /Range (\d+)/.exec(traits)?.[1];
  equal(`A ${name}: range increment`, s.rangeIncrement, range ? Number(range) : 0);
}

// Goods: every number in the table; every description.
const GOODS_ROWS = book.sections.goods.rows.slice(2);
equal("A thirty-one goods, in the table's order", B1.GOODS.map((g) => g.name), GOODS_ROWS.map((r) => r.cells[0]));
for (const row of GOODS_ROWS) {
  const [name, cost, size, level, weight, effect] = row.cells;
  const g = goodsBy[name];
  if (!g) { ok(`A ${name} exists`, false); continue; }
  equal(`A ${name}: price, level`, [g.system.price, g.system.itemLevel], [Number(cost.replace(/\(.*\)/, "").replace(/[^\d.]/g, "")), Number(level)]);
  ok(`A ${name}: the table's effect is quoted`, has(g, effect));
  ok(`A ${name}: it has a word on its automation`, /\*(Offered while carried|Not yet automated|Not automated|Automated \(0\.4\.0)/.test(B1.GOODS_AUTOMATION[name]?.note ?? ""));
}

/* ------------------------------------------------------------------ *
 * B. Declarations, normalised by the system's own code
 * ------------------------------------------------------------------ */

let condCount = 0;
for (const doc of ALL) {
  for (const flags of [F(doc), ...effectFlags(doc)]) {
    for (const [i, raw] of (Array.isArray(flags.conditionals) ? flags.conditionals : []).entries()) {
      condCount += 1;
      const entry = cond.normaliseConditional(raw, { id: doc._id, name: doc.name }, i);
      ok(`B ${doc.name}: conditionals[${i}] normalises`, entry !== null, JSON.stringify(raw));
      if (entry?.kind === "modifier") ok(`B ${doc.name}: conditionals[${i}] has a type the system knows`, Object.hasOwn(BONUS_TYPES, entry.type), entry.type);
    }
  }
}
equal("B every item conditional the block declares was read (Nerathis 2, Sparktail 2, Dustscale 1, Disrupt Magic 1, Esoteric Insight 2, Wanderer’s Instinct 3)", condCount, 11);
const goodsRows = goods.goodsConditionals(B1.GOODS.map((g) => ({ ...g, system: { ...g.system, equipped: true } })));
equal("B every goods row is read by the system's goods reader", goodsRows.length, B1.GOODS.reduce((n, g) => n + (F(g).goodsConditionals?.length ?? 0), 0));
for (const row of goodsRows) {
  const entry = cond.normaliseConditional(row, { id: "g", name: row.label }, 0);
  ok(`B goods ${row.label}: normalises as a conditional`, entry !== null, JSON.stringify(row));
}

// Aetherial Resonance: +1 race to every spell's save DC, innate included.
const resonance = abilities["Aetherial Resonance"].effects.map((e) => ({ ...e, disabled: false }));
equal("B Aetherial Resonance: +1 on a spell's DC, and an innate spell's", [dcBonus.declaredSpellDCBonuses(resonance, ["Fire"]).map((r) => r.value), dcBonus.declaredSpellDCBonuses(resonance, [], { innate: true }).map((r) => r.value)], [[1], [1]]);
// Elemental Surge: + Charisma to spell damage.
const surge = abilities["Elemental Surge"].effects.map((e) => ({ ...e, disabled: false }));
const surgeRows = dmgBonus.declaredSpellDamageBonuses(surge, { traits: ["Fire"], attributes: { charisma: { total: 3 } } });
equal("B Elemental Surge: Charisma (3) on the damage roll, as a racial bonus", surgeRows.map((r) => [r.value, r.type]), [[3, "race"]]);
equal("B …added to the formula once", dmgBonus.withSpellDamageBonus("1d6", surgeRows).formula.replace(/\s/g, ""), "1d6+3");
// Null Aura: the class bonus to saves and DB against spells, under its own name.
const nyrinn = { items: [abilities["Null Aura"]], system: { identity: { classBonus: 3 } } };
equal("B Null Aura: class bonus vs spells, named Null Aura", car.spellResilienceModifiers(nyrinn).map((r) => [r.label, r.value]), [["Null Aura", 3]]);
const penetrating = { items: [feats["Spell Penetration"]], appliedEffects: [] };
equal("B Spell Penetration lowers Spell Resilience by 2, never Null Aura", [
  car.spellResilienceModifiers(nyrinn, penetrating).map((r) => r.value),
  car.spellResilienceModifiers({ items: [{ type: "ability", name: "Spell Resilience", flags: { "trg-prime": { creatureAbility: { derives: { spellResilience: true } } } }, system: {} }], system: { identity: { classBonus: 3 } } }, penetrating).map((r) => r.value)
], [[3], [1]]);
// Ironmuk: twice the breath.
equal("B Ironmuk holds its breath twice as long", car.abilityBreathMultiplier([heritages.Ironmuk]), 2);
// Esoteric Insight (book v1.6): "a failure or fumble" on Arcana and Occultism only, not a reaction.
const ei = [feats["Esoteric Insight"]];
equal("B Esoteric Insight: a failure reroll too, but not a partial success", ["failure", "fumble", "blunder", "partial"].map((d) => fumble.fumbleRerollRows(ei, "skill", "arcana", d).length), [1, 1, 1, 0]);
equal("B …and the system offers it on a failed Arcana check", fumble.rerollAnswers(ei, "skill", "arcana", "failure"), true);
equal("B Esoteric Insight: a fumble reroll on Arcana and Occultism, not on Stealth", [fumble.fumbleRerollRows(ei, "skill", "arcana").length, fumble.fumbleRerollRows(ei, "skill", "occultism").length, fumble.fumbleRerollRows(ei, "skill", "stealth").length], [1, 1, 0]);
equal("B …not a reaction", fumble.fumbleRerollRows(ei, "skill", "arcana")[0]?.reaction, false);
// Focused Ley Sense swaps the ladder.
const ley = actions.SKILL_ACTIONS.find((a) => a.key === "leySense");
equal("B Focused Ley Sense: its five rungs instead of the four", [gso.featTimeLadder(ley, ["Focused Ley Sense"])?.options.map((o) => o.modifier), gso.featTimeLadder(ley, []) ?? null], [[2, 0, -2, -5, -10], null]);
equal("B Ley Sense's own ladder is the declared one", gso.declaredTimeLadder(ley)?.options.map((o) => o.modifier), [0, -2, -5, -10]);
// Orb of Water: the secondary packet and its caster-level step.
const orbMods = clm.applyCasterLevelMods(B1.SPELLS[0].system.casterLevelMods, 8);
equal("B Orb of Water at CL 8: +2d6 and +2 secondary; nothing at CL 3", [orbMods.damageDice, orbMods.secondary, clm.applyCasterLevelMods(B1.SPELLS[0].system.casterLevelMods, 3).steps], ["2d6", 2, 0]);
// Wyrmdral's and Elemental Affinity's rows (made by their Use).
for (const [label, flags] of [["Wyrmdral", auto.wyrmdralFlags("fire")], ["Elemental Affinity", auto.affinityFlags("cold")]]) {
  const el = label === "Wyrmdral" ? "fire" : "cold";
  const fx = [{ name: label, flags: { "trg-prime": flags } }];
  equal(`B ${label}: +1 on the Spellcraft check of a ${el} spell, nothing on another`, [
    cond.automaticSelections(cond.collectConditionals([], fx), { checkType: "spellcraft", traits: `Attack, ${el[0].toUpperCase()}${el.slice(1)}` }).modifiers.map((m) => m.value),
    cond.automaticSelections(cond.collectConditionals([], fx), { checkType: "spellcraft", traits: "Attack, Sonic" }).modifiers.length
  ], [[1], 0]);
  equal(`B ${label}: +1 on a ${el} spell's DC, nothing on another`, [dcBonus.declaredSpellDCBonuses(fx, [el]).map((r) => r.value), dcBonus.declaredSpellDCBonuses(fx, ["sonic"]).length], [[1], 0]);
}
// Every CUSTOM-mode change names a bonus slot the system pools.
const bonusRegistry = await import(sys("module", "bonuses", "registry.mjs")).catch(() => null);
for (const doc of ALL) for (const c of changes(doc)) if (c.mode === 0) ok(`B ${doc.name}: ${c.key} is a pooled bonus key`, Boolean(bonusRegistry?.parseBonusKey(c.key)));

/* ------------------------------------------------------------------ *
 * C. Resolution — every name a grant points at exists
 * ------------------------------------------------------------------ */

async function packNames(pack) {
  const { ClassicLevel } = await import("classic-level");
  const dir = path.join(SYSTEM_ROOT, "packs", pack);
  if (!fs.existsSync(dir)) return null;
  const db = new ClassicLevel(dir, { valueEncoding: "json" });
  const names = new Set();
  try { for await (const [k, v] of db.iterator()) if (k.split("!")[1] && !k.split("!")[1].includes(".")) names.add(String(v.name).toLowerCase()); }
  finally { await db.close(); }
  return names;
}
const core = {};
for (const p of ["abilities", "spells", "feats", "weapons", "gear", "races", "heritages", "backgrounds"]) core[p] = await packNames(p);
ok("C the system's packs were read", Object.values(core).every(Boolean));
const names = (docs, more) => new Set([...docs.map((d) => d.name.toLowerCase()), ...(more ?? [])]);
const abilityNames = names(B1.ABILITIES, core.abilities), spellNames = names(B1.SPELLS, core.spells), featNames = names(B1.BACKGROUND_FEATS, core.feats);
for (const doc of [...B1.RACES, ...B1.HERITAGES]) {
  for (const n of list(doc.system.racialAbilities)) ok(`C ${doc.name} → ability ${n}`, abilityNames.has(n.toLowerCase()));
  for (const n of list(doc.system.grantedSpells)) ok(`C ${doc.name} → spell ${n}`, spellNames.has(n.toLowerCase()));
  for (const n of list(doc.system.grantedFeats)) ok(`C ${doc.name} → feat ${n}`, featNames.has(n.toLowerCase()));
}
for (const b of B1.BACKGROUNDS) ok(`C ${b.name} → feat ${b.system.grantedFeats}`, featNames.has(b.system.grantedFeats.toLowerCase()));
for (const [race, list_] of Object.entries(reg.EXISTING_RACIAL_FEATS)) for (const f of list_) ok(`C ${race} may take the core's ${f}`, Boolean(core.feats?.has(f.toLowerCase())));
ok("C every racial ability is granted by a race or heritage", B1.ABILITIES.every((a) => [...B1.RACES, ...B1.HERITAGES].some((d) => list(d.system.racialAbilities).includes(a.name))));
for (const [p, docs] of [["abilities", B1.ABILITIES], ["feats", B1.BACKGROUND_FEATS], ["spells", B1.SPELLS], ["weapons", B1.WEAPONS], ["gear", B1.GOODS], ["races", B1.RACES], ["heritages", B1.HERITAGES], ["backgrounds", B1.BACKGROUNDS]]) {
  const clash = docs.filter((d) => core[p]?.has(d.name.toLowerCase())).map((d) => d.name);
  equal(`C no ${p} item clashes with a core one of the same name`, clash, []);
}
// Action keys named by conditionals exist in the system or in this module.
const actionsSrc = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "data", "skill-actions.mjs"), "utf8") + fs.readFileSync(path.join(SYSTEM_ROOT, "module", "data", "basic-actions.mjs"), "utf8");
// …or a feat's own roll that names itself (TRG Prime 3.683.0, C11: Spell Recognition's `actionKey: "spellRecognition"`, which Esoteric Insight's tick is scoped to since 0.8.0).
const featRollsSrc = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "feats-workflow.mjs"), "utf8");
const actionKeys = new Set([...[...actionsSrc.matchAll(/key: "([A-Za-z]+)"/g)].map((m) => m[1].toLowerCase()), ...[...featRollsSrc.matchAll(/actionKey: "([A-Za-z]+)"/g)].map((m) => m[1].toLowerCase()), ...actions.SKILL_ACTION_KEYS.map((k) => k.toLowerCase())]);
const named = new Set();
for (const doc of ALL) for (const flags of [F(doc), ...effectFlags(doc)]) for (const c of [...(flags.conditionals ?? []), ...(flags.goodsConditionals ?? [])]) for (const a of [...(c.when?.actions ?? []), ...(c.when?.not?.actions ?? [])]) named.add(a);
for (const a of named) ok(`C action "${a}" exists`, actionKeys.has(a.toLowerCase()));
const skillKeys = new Set(Object.keys(JSON.parse(fs.readFileSync(path.join(SYSTEM_ROOT, "template.json"), "utf8")).Actor.templates.creature.skills));
for (const a of actions.SKILL_ACTIONS) for (const s of a.skills) ok(`C ${a.name}: skill ${s} is the system's`, skillKeys.has(s));
ok("C no module action reuses a core action's key", actions.SKILL_ACTION_KEYS.every((k) => ![...actionsSrc.matchAll(/key: "([A-Za-z]+)"/g)].some((m) => m[1] === k)));

/* ------------------------------------------------------------------ *
 * D. Registration (the system's own registry) and the decisions
 * ------------------------------------------------------------------ */

api.resetModuleRegistry();
const real = {
  registerSourcebook: api.registerSourcebook, registerRacialPP: api.registerRacialPP, registerFeatAccess: api.registerFeatAccess,
  registerTraits: api.registerTraits, registerWeaponTraitRule: api.registerWeaponTraitRule, registerSkillActions: api.queueSkillActions,
  registerFeatAutomation: api.queueFeatAutomation, registerSpellCheckGate: api.registerSpellCheckGate,
  registerCastSurcharge: api.registerCastSurcharge, registerReleasePath: api.registerReleasePath
};
reg.registerContent(real, "trg-eldritch-arts");
equal("D the system's registry took everything without a problem", api.registrationProblems(), []);
equal("D the sourcebook is named", api.registeredSourcebook("trg-eldritch-arts"), "Eldritch Arts");
equal("D four races' Power Points", ["Aetherial", "Emberkin", "Nyrinn", "Scaelyn", "Wyrmdral"].map((n) => api.registeredRacialPP(n)), [1, 1, -1, 1, null]);
equal("D the core racial feats each race may take, and not another's", [
  api.hasRegisteredFeatAccess("race", "Aetherial", "Aura of Power"), api.hasRegisteredFeatAccess("race", "Nyrinn", "Shadow Magi"),
  api.hasRegisteredFeatAccess("race", "Scaelyn", "Sure Footed", "Wyrmdral"), api.hasRegisteredFeatAccess("race", "Emberkin", "Dracoris")
], [true, true, true, false]);
equal("D the Adept rule: Simple for the Adept class type", api.registeredWeaponTraitRules(), [{ trait: "adept", categoryAs: "Simple", classTypes: ["adept"] }]);
equal("D traits registered", api.registeredTraits().sort(), ["adept", "ritualist"]);
// Block 2 (0.3.0) queues three more after these; verify-block2 holds them.
equal("D seven actions queued, in the system's required shape", api.queuedSkillActions().map((a) => a.key).slice(0, 7), actions.SKILL_ACTION_KEYS);
const autos = api.queuedFeatAutomation();
// Block 3a (0.5.0) queues its own after these; verify-block3 holds them.
// …and Block 4 (0.7.0) its own; verify-block4 holds them.
const B3_AUTOMATIONS = [...Object.keys((await import(new URL("../module/block3-automations.mjs", import.meta.url))).AUTOMATIONS), ...Object.keys((await import(new URL("../module/block4-automations.mjs", import.meta.url))).AUTOMATIONS_B4)].map((n) => n.toLowerCase());
// …and Block 5 (0.8.0) its feats'; verify-block5a–d hold them.
// …and Block 7 (0.10.0) the Elemental Strike ability's Use; verify-block7 holds it.
const B7_NAMES = new Set(["elemental strike (strike)"]);
const B5_NAMES = new Set(PACKS.flatMap((p) => p.docs).filter((d) => B5_IDS.has(d._id)).map((d) => d.name.toLowerCase()));
equal("D the automations", [...autos.keys()].filter((n) => !B3_AUTOMATIONS.includes(n) && !B5_NAMES.has(n) && !B7_NAMES.has(n)).sort(), Object.keys(auto.AUTOMATIONS).map((n) => n.toLowerCase()).sort());
ok("D every automation names an item this module ships", [...autos.keys()].every((n) => ALL.some((d) => d.name.toLowerCase() === n) || B5_NAMES.has(n)));
ok("D every item flagged for an automation has one", ALL.filter((d) => F(d).eaAutomation).every((d) => autos.has(d.name.toLowerCase())), ALL.filter((d) => F(d).eaAutomation && !autos.has(d.name.toLowerCase())).map((d) => d.name).join(", "));
ok("D every automation has a hint and a use()", [...autos.values()].every((e) => typeof e.use === "function" && e.hint));
equal("D Focus-traited abilities own their Focus use", B1.ABILITIES.filter((a) => /focus/i.test(a.system.traits)).map((a) => [a.name, autos.get(a.name.toLowerCase())?.ownsFocusUse]), [["Magic Drain", true], ["Vir-ellian Release", true]]);
// Block 1's are registered first (Block 2's gates and surcharge follow; verify-block2).
equal("D Block 1's gate, surcharge and release path, registered first", [api.registeredSpellCheckGates()[0] === auto.nullAuraGate, api.registeredCastSurcharges()[0] === auto.zhalVrynSurcharge, api.registeredReleasePaths().length], [true, true, 1]);

// The proficiency rule, through the system's own profile reader.
const profileOf = (items) => prof.proficiencyProfile({ items, system: { identity: {} } });
const adeptClass = { type: "class", name: "Sorcerer", system: { classType: "Adept" } };
const martialClass = { type: "class", name: "Fighter", system: { classType: "Martial" } };
equal("D Bachall Fáistine (Adept): Simple for an Adept, Exotic for a Martial", [prof.effectiveWeaponCategory(profileOf([adeptClass]), weapons["Bachall Fáistine"]), prof.effectiveWeaponCategory(profileOf([martialClass]), weapons["Bachall Fáistine"])], ["Simple", "Exotic"]);
equal("D Brikail Naomhtha (Adept, Emberkin): Simple for an Adept Emberkin, Martial for a Martial one", [prof.effectiveWeaponCategory(profileOf([adeptClass, { type: "race", name: "Emberkin" }]), weapons["Brikail Naomhtha"]), prof.effectiveWeaponCategory(profileOf([martialClass, { type: "race", name: "Emberkin" }]), weapons["Brikail Naomhtha"])], ["Simple", "Martial"]);
const nyrinnWeapon = B1.WEAPONS.find((w) => list(w.system.traits).includes("Nyrinn"));
const wyrmWeapon = B1.WEAPONS.find((w) => list(w.system.traits).includes("Wyrmdral"));
ok("D a Nyrinn weapon and a Wyrmdral weapon exist", Boolean(nyrinnWeapon && wyrmWeapon));
// Every weapon whose trait line names a race or heritage says what that does for it (m64).
const RACES_IN_TRAITS = ["Aetherial", "Emberkin", "Nyrinn", "Scaelyn", "Wyrmdral"];
const racialWeapons = B1.WEAPONS.filter((w) => list(w.system.traits).some((t) => RACES_IN_TRAITS.includes(t)));
equal("D every racial weapon carries its racial note", racialWeapons.filter((w) => !has(w, "one category easier for a")).map((w) => w.name), []);
ok("D …including the Nyrinn's Scáthfán (v1.6's spelling)", has(B1.WEAPONS.find((w) => w.name === "Scáthfán"), "one category easier for a Nyrinn, so martial"));
ok("D no weapon still carries the v1.4 spelling", B1.WEAPONS.every((w) => !list(w.system.traits).includes("Nyrrin")));
equal("D the racial clause: a Nyrinn's weapon, a Wyrmdral heritage's weapon", [
  prof.effectiveWeaponCategory(profileOf([martialClass, { type: "race", name: "Nyrinn" }]), nyrinnWeapon),
  prof.effectiveWeaponCategory(profileOf([martialClass, { type: "race", name: "Scaelyn" }, { type: "heritage", name: "Wyrmdral" }]), wyrmWeapon),
  prof.effectiveWeaponCategory(profileOf([martialClass, { type: "race", name: "Scaelyn" }, { type: "heritage", name: "Sparktail" }]), wyrmWeapon)
], ["Martial", "Martial", "Exotic"]);

// The pure decisions.
const ab = (name, extra = {}) => ({ type: "ability", name, ...extra });
const her = (name, flags) => ({ type: "heritage", name, flags: { "trg-prime": flags } });
equal("D Null Aura: 5 ft, 10 for a Vel-tharis, 0 without the ability", [auto.nullAuraFeet([ab("Null Aura")]), auto.nullAuraFeet([ab("Null Aura"), her("Vel-tharis", F(heritages["Vel-tharis"]))]), auto.nullAuraFeet([her("Vel-tharis", F(heritages["Vel-tharis"]))])], [5, 10, 0]);
equal("D Zhal-vryn surcharges 1 PP; another Nyrinn none", [auto.auraSurcharge([ab("Null Aura"), her("Zhal-vryn", F(heritages["Zhal-vryn"]))]), auto.auraSurcharge([ab("Null Aura"), her("Vel-tharis", F(heritages["Vel-tharis"]))])], [1, 0]);
equal("D Magic Drain energy: Critical all (capped at level × 2), Success half (down), Failure none", [
  auto.magicDrainEnergy({ degree: "critical", drained: 7, level: 3 }), auto.magicDrainEnergy({ degree: "success", drained: 5, level: 3 }),
  auto.magicDrainEnergy({ degree: "heroic", drained: 3, level: 3 }), auto.magicDrainEnergy({ degree: "failure", drained: 5, level: 3 }),
  auto.magicDrainEnergy({ degree: "success", drained: 3, level: 5, extra: 2 })
], [{ drained: 7, energy: 6 }, { drained: 5, energy: 2 }, { drained: 3, energy: 3 }, { drained: 0, energy: 0 }, { drained: 5, energy: 2 }]);
equal("D Memory Recall: Heroic +8, Critical and Success +4, Partial +2, below nothing", ["heroic", "critical", "success", "partial", "failure", "fumble"].map(auto.memoryRecallBonus), [8, 4, 4, 2, 0, 0]);
equal("D Suggestion: 1 hour, 30 minutes, the spell's, 5 minutes", ["heroic", "critical", "success", "partial", "failure"].map(auto.suggestionSeconds), [3600, 1800, null, 300, null]);
equal("D Quickbind: 1, 5, 10 minutes, or not invested", ["critical", "success", "failure", "fumble"].map(auto.quickbindMinutes), [1, 5, 10, null]);
const lc = (o) => auto.lingualCastingOption({ spellPPCost: 3, spellTradition: "arcane", ...o });
equal("D Lingual Casting: Very Hard, Linguistics", [lc({}).difficulty, lc({}).dcAdjustment, lc({}).skill], ["veryHard", 5, "linguistics"]);
equal("D Lingual Casting: tradition ranks ≥ PP and Linguistics ≥ PP + 2", [
  lc({ skillRanks: { arcana: 3, linguistics: 5 } }).available, lc({ skillRanks: { arcana: 2, linguistics: 5 } }).available,
  lc({ skillRanks: { arcana: 3, linguistics: 4 } }).available, lc({ spellTradition: "arcane, verdant", skillRanks: { nature: 3, linguistics: 5 } }).available
], [true, false, false, true]);
equal("D …High Magic needs all four", [lc({ highMagic: true, skillRanks: { arcana: 3, religion: 3, occultism: 3, nature: 3, linguistics: 5 } }).available, lc({ highMagic: true, skillRanks: { arcana: 3, religion: 3, occultism: 3, linguistics: 5 } }).available], [true, false]);
ok("D …a scroll whose spell names no tradition is the GM's call, and says so", !lc({ spellTradition: "", skillRanks: { linguistics: 9 } }).available && /GM/.test(lc({ spellTradition: "", skillRanks: { linguistics: 9 } }).reason));
equal("D Lingual Casting is offered for scrolls only", [Boolean(await auto.lingualCastingPath({ kind: "scroll", spellPPCost: 1, spellTradition: "arcane", skillRanks: {} })), await auto.lingualCastingPath({ kind: "wand" })], [true, null]);
equal("D lockouts: in force until their time, by world time", [auto.lockedUntil({ until: 100 }, 99), auto.lockedUntil({ until: 100 }, 100), auto.lockedUntil(null, 0)], [true, false, false]);
equal("D a day is world time's", [auto.dayOf(0), auto.dayOf(86399), auto.dayOf(86400)], [0, 0, 1]);
equal("D the gate stays silent for an innate spell, an item's, or no roll", [await auto.nullAuraGate({ rollsCheck: true, innate: true }), await auto.nullAuraGate({ rollsCheck: true, itemCast: true }), await auto.nullAuraGate({ rollsCheck: false })], [null, null, null]);
equal("D the system's normaliser reads the surcharge's answer", surcharge.normaliseSurcharge({ pp: 1, label: "Zhal-vryn (X)" }), { pp: 1, label: "Zhal-vryn (X)", lines: [] });
ok("D the system's gate reader takes the gate's answer", (() => { const n = gates.normaliseGateAnswer?.({ modifiers: [{ label: "Null Aura (X)", value: -3, type: "untyped" }], lines: ["x"] }); return !gates.normaliseGateAnswer || (n.modifiers.length === 1 && n.modifiers[0].value === -3); })());

// The action refusals (synchronous; no world time, no lockouts).
globalThis.ui = { notifications: { warn: () => {} } };
const actorWith = (skills = {}, items = []) => ({ system: { skills: Object.fromEntries(Object.entries(skills).map(([k, v]) => [k, { ranks: v }])) }, items, getFlag: () => ({}) });
const qb = actions.SKILL_ACTIONS.find((a) => a.key === "quickbind");
equal("D Quickbind is refused below 5 ranks, allowed at 5", [auto.onActionAttemptB1({ actor: actorWith({ powerManipulation: 4 }), action: qb }), auto.onActionAttemptB1({ actor: actorWith({ powerManipulation: 5 }), action: qb })], [false, true]);
equal("D a core action is never refused", auto.onActionAttemptB1({ actor: actorWith(), action: { key: "dispel" } }), true);
equal("D Magic Drain is refused without the ability", auto.onActionAttemptB1({ actor: actorWith(), action: actions.SKILL_ACTIONS.find((a) => a.key === "magicDrain") }), false);

// The clock.
equal("D an effect for 60 seconds ends by world time", clock.expiryFlags({ seconds: 60 }, { worldTime: 100 }), { system: { spellEffect: true, spellEffectEnd: 160 }, module: {} });
equal("D \"until the end of your next turn\" in combat waits for that turn, with a two-round backstop on the world clock", [clock.expiryFlags("endOfNextTurn", { inCombat: true, combatId: "c", nextRound: 3, worldTime: 100 }).module.endsAfterTurn, clock.expiryFlags("endOfNextTurn", { inCombat: true, combatId: "c", nextRound: 3, worldTime: 100 }).system.spellEffectEnd], [{ combatId: "c", round: 3 }, 112]);
equal("D the printed ladder answers: a Ley Sense Partial is its Failure, a Blunder its Fumble, a Heroic its Critical; a printed rung is itself", [
  auto.printedDegree(actions.SKILL_ACTIONS.find((a) => a.key === "leySense"), "partial"), auto.printedDegree(actions.SKILL_ACTIONS.find((a) => a.key === "leySense"), "blunder"),
  auto.printedDegree(actions.SKILL_ACTIONS.find((a) => a.key === "magicDrain"), "heroic"), auto.printedDegree(actions.SKILL_ACTIONS.find((a) => a.key === "hypnotismMemory"), "partial")
], ["failure", "fumble", "critical", "partial"]);

/* ------------------------------------------------------------------ *
 * D2. The Foundry half, driven with stand-ins
 * ------------------------------------------------------------------ */

const cards = [];
const answers = [];
const calls = { resolveAction: [], runAreaEffect: [], chooseSpell: [], spendReaction: 0 };
let worldTime = 1000;
const effectsOf = (doc) => Array.from(doc.effects ?? []);
function makeEffect(parent, data) {
  const e = { id: `e${Math.random().toString(36).slice(2, 8)}`, parent, ...structuredClone(data) };
  e.getFlag = (scope, key) => e.flags?.[scope]?.[key];
  return e;
}
function makeItem(parent, src) {
  const item = { ...structuredClone(src), id: src._id, parent, uuid: `Item.${src._id}` };
  item.getFlag = (scope, key) => item.flags?.[scope]?.[key];
  item.setFlag = async (scope, key, value) => { item.flags ??= {}; item.flags[scope] ??= {}; item.flags[scope][key] = value; };
  item.update = async (diff) => { for (const [k, v] of Object.entries(diff)) { const keys = k.split("."); let o = item; while (keys.length > 1) { const kk = keys.shift(); o[kk] ??= {}; o = o[kk]; } o[keys[0]] = v; } };
  return item;
}
const deletedHooks = [];
function makeActor(name, sources, system = {}) {
  const actor = { name, uuid: `Actor.${name}`, id: name, isOwner: true, flags: {}, effects: [], system: { identity: { level: 3, classBonus: 2 }, resources: { ap: { value: 3 }, pp: { value: 4 } }, skills: {}, ...system } };
  actor.items = sources.map((s) => makeItem(actor, s));
  actor.items.get = (id) => actor.items.find((i) => i.id === id);
  actor.getFlag = (scope, key) => actor.flags?.[scope]?.[key];
  actor.setFlag = async (scope, key, value) => { actor.flags[scope] ??= {}; actor.flags[scope][key] = value; };
  actor.unsetFlag = async (scope, key) => { delete actor.flags?.[scope]?.[key]; };
  actor.update = async (diff) => { for (const [k, v] of Object.entries(diff)) { const keys = k.split("."); let o = actor; while (keys.length > 1) { const kk = keys.shift(); o[kk] ??= {}; o = o[kk]; } o[keys[0]] = v; } };
  actor.createEmbeddedDocuments = async (_t, list) => list.map((d) => { const e = makeEffect(actor, d); actor.effects.push(e); return e; });
  actor.deleteEmbeddedDocuments = async (_t, ids) => { const gone = actor.effects.filter((e) => ids.includes(e.id)); actor.effects = actor.effects.filter((e) => !ids.includes(e.id)); for (const e of gone) deletedHooks.push(e); return gone; };
  actor.getActiveTokens = () => [];
  return actor;
}
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  replaceFeatEffect: async (actor, item, data) => { actor.effects = actor.effects.filter((e) => e.flags?.["trg-prime"]?.featSource !== item.id); data.flags ??= {}; data.flags["trg-prime"] = { ...(data.flags["trg-prime"] ?? {}), featSource: item.id }; return (await actor.createEmbeddedDocuments("ActiveEffect", [data]))[0]; },
  chooseFromList: async () => answers.shift() ?? null,
  chooseSpell: async (actor, item, spec) => { calls.chooseSpell.push([item.name, spec]); return true; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  resolveAction: async (actor, action) => { calls.resolveAction.push(action.key); return { degree: "success" }; },
  runAreaEffect: async (actor, spec, opts) => { calls.runAreaEffect.push({ spec, targets: (opts.targets ?? []).map((t) => t.name) }); return ["area lines"]; },
  levelDC: (level) => 10 + Math.floor(Number(level) * 1.5),
  itemUsesMax: (item) => (Number(item.system?.usesPerDay) > 0 ? Number(item.system.usesPerDay) : null),
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  spendReaction: async () => { calls.spendReaction += 1; return true; },
  // The system's own Invest Item rules (3.675.0).
  investRefusal: async (actor, item) => (await import(sys("module", "magic-items-workflow.mjs"))).investRefusal(actor, item)
};
globalThis.game = { trgPrime: { modules: { helpers } }, time: { get worldTime() { return worldTime; } }, combat: null, user: { isGM: true }, users: { activeGM: null, [Symbol.iterator]: function* () { yield { isGM: true, id: "gm" }; } } };
globalThis.canvas = { tokens: { placeables: [] }, dimensions: { distance: 5 }, grid: { measurePath: () => ({ distance: 0 }) } };
const whispers = [];
globalThis.ChatMessage = { create: async (data) => { whispers.push(data); } };
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { this.total = 3; return this; } };

// Ethereal Form: the use spent, incorporeal for a minute.
{
  const a = makeActor("Aeth", [abilities["Ethereal Form"]]);
  await auto.AUTOMATIONS["Ethereal Form"].use(a, a.items[0]);
  const e = a.effects[0];
  equal("D2 Ethereal Form: incorporeal, for 60 seconds, the use spent", [e?.flags?.["trg-prime"]?.grantedTraits, e?.flags?.["trg-prime"]?.spellEffectEnd - worldTime, a.items[0].system.usesValue], [["incorporeal"], 60, 0]);
  await auto.AUTOMATIONS["Ethereal Form"].use(a, a.items[0]);
  equal("D2 …and refused when spent", a.effects.length, 1);
}
// Elemental Symbiosis: immunity, then weakness when it ends, then refused until that ends.
{
  const a = makeActor("Ember", [abilities["Elemental Symbiosis"], heritages.Cinderblood]);
  await auto.AUTOMATIONS["Elemental Symbiosis"].use(a, a.items[0]);
  const imm = a.effects[0];
  equal("D2 Elemental Symbiosis: immunity to the heritage's element (fire)", imm?.changes?.map((c) => [c.key, c.value]), [["system.combat.immunities", ", fire"]]);
  await auto.AUTOMATIONS["Elemental Symbiosis"].use(a, a.items[0]);
  equal("D2 …not twice while it is up", a.effects.length, 1);
  await a.deleteEmbeddedDocuments("ActiveEffect", [imm.id]);
  await auto.onEffectDeletedB1(deletedHooks.at(-1));
  equal("D2 …its end lays weakness to fire for 1 minute", a.effects.map((e) => [e.changes?.[0]?.key, e.changes?.[0]?.value, e.flags?.["trg-prime"]?.spellEffectEnd - worldTime]), [["system.combat.weaknesses", ", fire", 60]]);
  await auto.AUTOMATIONS["Elemental Symbiosis"].use(a, a.items[0]);
  equal("D2 …and it is refused until the weakness ends", a.effects.length, 1);
  const none = makeActor("NoHeritage", [abilities["Elemental Symbiosis"]]);
  await auto.AUTOMATIONS["Elemental Symbiosis"].use(none, none.items[0]);
  equal("D2 …refused with no Emberkin heritage", none.effects.length, 0);
}
// Wyrmdral and Elemental Affinity.
{
  const a = makeActor("Wyrm", [heritages.Wyrmdral]);
  answers.push("acid");
  await auto.AUTOMATIONS.Wyrmdral.use(a, a.items[0]);
  equal("D2 Wyrmdral: resistance to the chosen element and its rows", [a.effects[0]?.changes?.[0]?.value, a.effects[0]?.flags?.["trg-prime"]?.spellDCBonus?.traits, a.items[0].flags["trg-prime"].eaElement], [", acid", ["acid"], "acid"]);
  answers.push("cold");
  await auto.AUTOMATIONS.Wyrmdral.use(a, a.items[0]);
  equal("D2 …choosing again replaces it", [a.effects.length, a.effects[0]?.changes?.[0]?.value], [1, ", cold"]);
  answers.push("sonic");
  await auto.AUTOMATIONS.Wyrmdral.use(a, a.items[0]);
  equal("D2 …a choice not on its list does nothing", a.effects[0]?.changes?.[0]?.value, ", cold");
  const b = makeActor("Affine", [{ ...feats["Elemental Affinity"], _id: "aff1" }, { ...feats["Elemental Affinity"], _id: "aff2" }]);
  answers.push("fire");
  await auto.AUTOMATIONS["Elemental Affinity"].use(b, b.items[0]);
  answers.push("fire");
  await auto.AUTOMATIONS["Elemental Affinity"].use(b, b.items[1]);
  equal("D2 Elemental Affinity: a second copy cannot take the first's element", [b.items[0].flags["trg-prime"].eaElement, b.items[1].flags?.["trg-prime"]?.eaElement ?? null], ["fire", null]);
}
// Innate Magic and Glyphweave: the cantrip chooser.
{
  const a = makeActor("Scale", [abilities["Innate Magic"], heritages.Glyphweave]);
  await auto.AUTOMATIONS["Innate Magic"].use(a, a.items[0]);
  await auto.AUTOMATIONS.Glyphweave.use(a, a.items[1]);
  // Book v1.6: Glyphweave's is "an additional innate cantrip"; Innate Magic's a daily-chosen PP 0 spell.
  equal("D2 Innate Magic: a PP 0 pick, not innate; Glyphweave: an innate cantrip", calls.chooseSpell.map(([n, spec]) => [n, spec.ppCost, Boolean(spec.innate)]), [["Innate Magic", 0, false], ["Glyphweave", 0, true]]);
  cards.length = 0;
  await auto.onDailyPreparationB1({ actor: a });
  ok("D2 daily preparation invites a new Innate Magic pick, not Glyphweave's", cards.length === 1 && !/Glyphweave/.test(cards[0].lines.join(" ")));
  cards.length = 0;
  await auto.onDailyPreparationB1({ actor: makeActor("Glyph only", [heritages.Glyphweave]) });
  equal("D2 …a Glyphweave without Innate Magic: no card", cards.length, 0);
}
// Wanderer's Instinct: once a day, advantage on the next Survival check.
{
  const a = makeActor("Wander", [feats["Wanderer’s Instinct"]]);
  await auto.AUTOMATIONS["Wanderer’s Instinct"].use(a, a.items[0]);
  const c = a.effects[0]?.flags?.["trg-prime"]?.conditionals?.[0];
  equal("D2 Wanderer's Instinct: a one-shot advantage on Survival, offered (not pre-ticked on every Survival check), the day's use spent", [c?.kind, c?.oneShot, c?.auto, c?.when?.subjects, a.items[0].system.usesValue], ["advantage", true, false, ["survival"], 0]);
  ok("D2 …which the system reads", cond.normaliseConditional(c, { id: "x", name: "x" }, 0)?.oneShot === true);
}
// Magic Drain: the action, then the energy.
{
  const charged = { _id: "wand1", name: "Wand of Sparks", type: "gear", system: { uses: 5 }, flags: { "trg-prime": { chargedItem: { kind: "wand" } } } };
  const a = makeActor("Nyr", [abilities["Magic Drain"], heritages["Vir-ellian"], abilities["Vir-ellian Release"]]);
  const holder = makeActor("Holder", [charged]);
  answers.push("item", null);
  await auto.AUTOMATIONS["Magic Drain"].use(a, a.items[0]);
  equal("D2 Magic Drain: the Use asks what and where before the roll; a cancel rolls nothing", [calls.resolveAction, a.flags["trg-eldritch-arts"]?.drainPlan ?? null], [[], null]);
  answers.push("item", "save");
  await auto.AUTOMATIONS["Magic Drain"].use(a, a.items[0]);
  equal("D2 …then rolls the action, the plan kept for the result", [calls.resolveAction, a.flags["trg-eldritch-arts"]?.drainPlan], [["magicDrain"], { what: "item", to: "save" }]);
  answers.push("wand1");
  await auto.onActionResolvedB1({ actor: a, action: { key: "magicDrain" }, degree: "critical", targetActor: holder });
  const energyFx = clock.ownEffects(a, "magicDrainEnergy")[0];
  equal("D2 …a Critical on a charged item: 1d4 (3) + the Vir-ellian's class bonus (2) off it; that much energy, 1 minute per PP", [holder.items[0].system.uses, energyFx?.flags?.["trg-eldritch-arts"]?.energy, energyFx?.flags?.["trg-prime"]?.spellEffectEnd - worldTime, a.items[0].system.usesValue], [0, 5, 300, 0]);
  equal("D2 …the plan is used once and cleared", a.flags["trg-eldritch-arts"]?.drainPlan, undefined);
  equal("D2 …its +1 racial on the chosen roll", energyFx?.flags?.["trg-prime"]?.conditionals?.map((c) => [c.value, c.type, c.when.checkTypes]), [[1, "race", ["save"]]]);
  // Vir-ellian Release spends it: 5d4 force, basic Will at the Level DC.
  canvas.tokens.placeables = [];
  await auto.AUTOMATIONS["Vir-ellian Release"].use(a, a.items[2]);
  equal("D2 Vir-ellian Release: the energy is spent and its Focus use", [clock.ownEffects(a, "magicDrainEnergy").length, a.items[2].system.usesValue], [0, 0]);
  ok("D2 …5d4 force, basic Will, against the Level DC", cards.at(-1)?.lines.some((l) => /5d4 force/.test(l) && /DC 14/.test(l)));
  await auto.AUTOMATIONS["Vir-ellian Release"].use(a, a.items[2]);
  ok("D2 …refused with no energy", !/Vir-ellian Release/.test(cards.at(-1)?.title) || cards.filter((c) => c.title === "Vir-ellian Release").length === 1);
  const b = makeActor("Nyr2", [abilities["Magic Drain"]]);
  answers.push("effect");
  globalThis.foundry = { applications: { api: { DialogV2: { prompt: async () => ({ pp: 4 }) } } } };
  await auto.onActionResolvedB1({ actor: b, action: { key: "magicDrain" }, degree: "success" });
  ok("D2 a Success on a 4 PP effect: 2 energy offered (the choice declined here, so none placed)", clock.ownEffects(b, "magicDrainEnergy").length === 0);
  answers.push("effect", "defence");
  const c2 = makeActor("Nyr3", [abilities["Magic Drain"]]);
  await auto.onActionResolvedB1({ actor: c2, action: { key: "magicDrain" }, degree: "success" });
  const def = clock.ownEffects(c2, "magicDrainEnergy")[0];
  equal("D2 …on DB: +1 racial in the defence pool; 2 energy (half of 4) for 4 minutes (1 per PP drained)", [def?.changes?.[0]?.key, def?.changes?.[0]?.mode, def?.flags?.["trg-eldritch-arts"]?.energy, def?.flags?.["trg-prime"]?.spellEffectEnd - worldTime], ["system.combat.defence.racial", 0, 2, 240]);
  ok("D2 …which the system pools as a racial bonus", bonusRegistry?.parseBonusKey(def?.changes?.[0]?.key)?.type === "race");
  // Another's item this client cannot change: said, for the GM.
  const e = makeActor("Nyr5", [abilities["Magic Drain"]]);
  const foreign = makeActor("Foreign", [{ _id: "rod1", name: "Rod of Fire", type: "gear", system: { uses: 6 }, flags: { "trg-prime": { chargedItem: { kind: "rod" } } } }]);
  foreign.items[0].isOwner = false;
  answers.push("item", "skill", "rod1");
  await auto.AUTOMATIONS["Magic Drain"].use(e, e.items[0]);
  await auto.onActionResolvedB1({ actor: e, action: { key: "magicDrain" }, degree: "success", targetActor: foreign });
  equal("D2 …a drain on an item not this client's: the item untouched, the GM told, the energy still gained", [foreign.items[0].system.uses, /the GM takes it off/.test(cards.at(-1).lines.join(" ")), clock.ownEffects(e, "magicDrainEnergy")[0]?.flags?.["trg-eldritch-arts"]?.energy], [6, true, 1]);
  const d = makeActor("Nyr4", [abilities["Magic Drain"]]);
  await auto.onActionResolvedB1({ actor: d, action: { key: "magicDrain" }, degree: "failure" });
  equal("D2 a Failure drains nothing but spends the use", [clock.ownEffects(d, "magicDrainEnergy").length, d.items[0].system.usesValue], [0, 0]);
  equal("D2 a spent Magic Drain is refused before the roll", auto.onActionAttemptB1({ actor: d, action: { key: "magicDrain" } }), false);
}
// The lockouts.
{
  const a = makeActor("Seer", []);
  const leyS = { key: "leySense" };
  await auto.onActionResolvedB1({ actor: a, action: leyS, degree: "partial" });
  equal("D2 Ley Sense: a Partial is the printed Failure, and locks it", auto.onActionAttemptB1({ actor: a, action: leyS }), false);
  worldTime += 600;
  await auto.onActionResolvedB1({ actor: a, action: leyS, degree: "failure" });
  equal("D2 Ley Sense: a Failure locks it for 10 minutes", [auto.onActionAttemptB1({ actor: a, action: leyS }), (worldTime += 600, auto.onActionAttemptB1({ actor: a, action: leyS }))], [false, true]);
  await auto.onActionResolvedB1({ actor: a, action: leyS, degree: "fumble" });
  equal("D2 …a Fumble: 1 PP lost and 1 hour", [a.system.resources.pp.value, auto.onActionAttemptB1({ actor: a, action: leyS }), (worldTime += 3599, auto.onActionAttemptB1({ actor: a, action: leyS })), (worldTime += 1, auto.onActionAttemptB1({ actor: a, action: leyS }))], [3, false, false, true]);
  await auto.onActionResolvedB1({ actor: a, action: { key: "mysteriousScript" }, degree: "success" });
  equal("D2 Mysterious Script: once per week", [auto.onActionAttemptB1({ actor: a, action: { key: "mysteriousScript" } }), (worldTime += 6 * 86400, auto.onActionAttemptB1({ actor: a, action: { key: "mysteriousScript" } })), (worldTime += 86400, auto.onActionAttemptB1({ actor: a, action: { key: "mysteriousScript" } }))], [false, false, true]);
  const subject = makeActor("Subject", []);
  const other = makeActor("Other", []);
  await auto.onActionResolvedB1({ actor: a, action: { key: "hypnotismSuggestion" }, degree: "failure", targetActor: subject });
  equal("D2 Hypnotism: a Failure — not that subject again until the next day; another subject at once", [auto.onActionAttemptB1({ actor: a, action: { key: "hypnotismMemory" }, targetActor: subject }), auto.onActionAttemptB1({ actor: a, action: { key: "hypnotismSuggestion" }, targetActor: other }), (worldTime += 86400, auto.onActionAttemptB1({ actor: a, action: { key: "hypnotismSuggestion" }, targetActor: subject }))], [false, true, true]);
  await auto.onActionResolvedB1({ actor: a, action: { key: "hypnotismMemory" }, degree: "heroic", targetActor: subject });
  const mem = clock.ownEffects(subject, "memoryRecall")[0]?.flags?.["trg-prime"]?.conditionals?.[0];
  equal("D2 Memory Recall Heroic: +8 circumstance, once, on Recall Knowledge", [mem?.value, mem?.type, mem?.oneShot, mem?.when?.actions], [8, "circumstance", true, ["recallKnowledge"]]);
}
// Quickbind: invested, once per item per day.
{
  const ring = { _id: "ring1", name: "Ring of Warding", type: "gear", system: { invested: false, traits: "Invested, Magical" }, flags: {} };
  const a = makeActor("Binder", [ring], { skills: { powerManipulation: { ranks: 5 } } });
  answers.push("ring1");
  await auto.onActionResolvedB1({ actor: a, action: { key: "quickbind" }, degree: "success" });
  equal("D2 Quickbind: the item is invested, in 5 minutes", [a.items[0].system.invested, /5 minutes/.test(cards.at(-1).lines.join(" "))], [true, true]);
  a.items[0].system.invested = false;
  answers.push("ring1");
  await auto.onActionResolvedB1({ actor: a, action: { key: "quickbind" }, degree: "critical" });
  equal("D2 …a second Quickbind on it the same day is refused", a.items[0].system.invested, false);
  await auto.onActionResolvedB1({ actor: a, action: { key: "quickbind" }, degree: "fumble" });
  ok("D2 …a Fumble invests nothing", /fail to invest/.test(cards.at(-1).lines.join(" ")));
  const staffs = makeActor("Staves", [{ _id: "st1", name: "Staff of Ash", type: "gear", system: { invested: true, traits: "Staff, Invested" }, flags: {} }, { _id: "st2", name: "Staff of Oak", type: "gear", system: { invested: false, traits: "Staff, Invested" }, flags: {} }], { skills: { powerManipulation: { ranks: 5 } }, magic: { investmentSlots: 3 } });
  answers.push("st2");
  await auto.onActionResolvedB1({ actor: staffs, action: { key: "quickbind" }, degree: "critical" });
  equal("D2 …Invest Item's rules hold: a second Staff is refused, and its day is not used", [staffs.items[1].system.invested, staffs.items[1].flags?.["trg-eldritch-arts"]?.quickbindDay ?? null, /Staff/.test(cards.at(-1).lines.join(" "))], [false, null, true]);
}
// The aura on the map: the gate and the surcharge.
{
  const tok = (actor, x) => { const t = { actor, center: { x, y: 0 }, document: { width: 1 } }; actor.getActiveTokens = () => [t]; return t; };
  canvas.grid.measurePath = ([a, b]) => ({ distance: Math.abs(a.x - b.x) });
  const caster = makeActor("Caster", []);
  const plain = makeActor("Plain", [abilities["Null Aura"]], { identity: { level: 3, classBonus: 3 } });
  const vel = makeActor("Vel", [abilities["Null Aura"], heritages["Vel-tharis"]], { identity: { level: 5, classBonus: 4 } });
  const zhal = makeActor("Zhal", [abilities["Null Aura"], heritages["Zhal-vryn"]], { identity: { level: 1, classBonus: 2 } });
  const tc = tok(caster, 0);
  const place = (...pairs) => { canvas.tokens.placeables = [tc, ...pairs.map(([a, x]) => tok(a, x))]; };
  const gate = async () => (await auto.nullAuraGate({ actor: caster, rollsCheck: true }))?.modifiers?.map((m) => [m.label, m.value]) ?? null;
  place([plain, 5]);
  equal("D2 Null Aura: a Spellcraft check within 5 ft takes the class bonus as a penalty", await gate(), [["Null Aura (Plain)", -3]]);
  equal("D2 …on the casting DC only: the system leaves it out of a spell attack against DB", (await auto.nullAuraGate({ actor: caster, rollsCheck: true }))?.modifiers?.map((m) => m.castingOnly), [true]);
  equal("D2 …which the system's gate reader keeps", gates.normaliseGateAnswer((await auto.nullAuraGate({ actor: caster, rollsCheck: true }))).modifiers.map((m) => m.castingOnly), [true]);
  place([plain, 10]);
  equal("D2 …not at 10 ft", await gate(), null);
  place([vel, 10]);
  equal("D2 …a Vel-tharis reaches 10 ft", await gate(), [["Null Aura (Vel)", -4]]);
  place([vel, 10], [plain, 5]);
  equal("D2 …overlapping auras: the largest only", await gate(), [["Null Aura (Vel)", -4]]);
  equal("D2 …an innate spell's roll and an item's are not Spellcraft checks", [await auto.nullAuraGate({ actor: caster, rollsCheck: true, innate: true }), await auto.nullAuraGate({ actor: caster, rollsCheck: true, itemCast: true })], [null, null]);
  canvas.tokens.placeables = [tok(plain, 0)];
  equal("D2 …the Nyrinn's own casting too", (await auto.nullAuraGate({ actor: plain, rollsCheck: true }))?.modifiers?.map((m) => m.value), [-3]);
  place([zhal, 5]);
  equal("D2 Zhal-vryn: 1 PP more within 5 ft; nothing beyond, nothing from another Nyrinn", [await auto.zhalVrynSurcharge({ actor: caster }), (place([zhal, 10]), await auto.zhalVrynSurcharge({ actor: caster })), (place([vel, 5]), await auto.zhalVrynSurcharge({ actor: caster }))], [{ pp: 1, label: "Zhal-vryn (Zhal)" }, null, null]);
  // Vir-ellian Release: every creature within 30 ft, allies included, not beyond.
  const vir = makeActor("Vir", [abilities["Vir-ellian Release"]]);
  await vir.createEmbeddedDocuments("ActiveEffect", [{ name: "energy", flags: { "trg-eldritch-arts": { source: "magicDrainEnergy", energy: 2 } } }]);
  const near = makeActor("Near", []), far = makeActor("Far", []);
  canvas.tokens.placeables = [tok(vir, 0), tok(near, 30), tok(far, 35)];
  await auto.AUTOMATIONS["Vir-ellian Release"].use(vir, vir.items[0]);
  equal("D2 Vir-ellian Release: 2d4 force to the creatures within 30 ft, basic Will", [calls.runAreaEffect.at(-1)?.targets, calls.runAreaEffect.at(-1)?.spec.damage, calls.runAreaEffect.at(-1)?.spec.save, calls.runAreaEffect.at(-1)?.spec.basic], [["Near"], { formula: "2d4", type: "force" }, "will", true]);
  canvas.tokens.placeables = [];
}
// Null Aura's beneficial-spell Will save (book v1.6, Graham's C1): the system rolls it.
{
  const caster = makeActor("Caster", []);
  const target = makeActor("Nyrinn", [abilities["Null Aura"]]);
  const bless = { areaTargeting: "allies", effects: [{ kind: "bonus" }] };
  const harm = { defence: "Fortitude", damage: { formula: "2d6" } };
  equal("D2 Null Aura declares a beneficial-spell save, other casters only", bsave.declaredBeneficialSaves(target), [{ label: "Null Aura", otherCastersOnly: true }]);
  equal("D2 …a helping spell from another caster asks for it; the Nyrinn's own does not; a harmful one does not", [
    bsave.beneficialSaveRequired(target, bless, caster).required, bsave.beneficialSaveRequired(target, bless, caster).source,
    bsave.beneficialSaveRequired(target, bless, target).required, bsave.beneficialSaveRequired(target, harm, caster).required
  ], [true, "Null Aura", false, false]);
  equal("D2 …and nobody else rolls it", bsave.beneficialSaveRequired(caster, bless, target).required, false);
  ok("D2 the module no longer reminds the GM itself", !("onSpellCastB1" in auto));
}

/* ------------------------------------------------------------------ *
 * E. Wiring
 * ------------------------------------------------------------------ */

const script = fs.readFileSync(path.join(ROOT, "scripts", "eldritch-arts.mjs"), "utf8");
// Block 1's own handlers (Block 2 listens to some of the same hooks).
for (const [hook, handler] of [["trgPrimeActionAttempt", "onActionAttemptB1"], ["trgPrimeActionResolved", "onActionResolvedB1"], ["trgPrimeDailyPreparation", "onDailyPreparationB1"], ["deleteActiveEffect", "onEffectDeletedB1"], ["trgPrimeTurnEnded", "onTurnEnded"], ["deleteCombat", "onCombatDeleted"]]) ok(`E the script listens for ${hook} with ${handler}`, new RegExp(`Hooks\\.on\\("${hook}", \\([a-z]+\\) => \\{? ?${handler}\\(`).test(script));
ok("E the 0.1.x Null Aura reminder is gone (the system rolls Null Aura's save)", !script.includes("onSpellCastB1"));
ok("E the script registers through registerContent", /registerContent\(api, MODULE_ID\)/.test(script));
const atLeast = (v, min) => { const a = String(v).split(".").map(Number), b = String(min).split(".").map(Number); for (let i = 0; i < 3; i++) { if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0); } return true; };
// Block 1 needs 0.2.0 on 3.677.0 or later; the exact pins are verify-block2's.
ok("E versions: module 0.2.0 or later, needs TRG Prime 3.677.0 or later", atLeast(manifest.version, "0.2.0") && atLeast(/REQUIRED_SYSTEM = "([\d.]+)"/.exec(script)?.[1], "3.677.0") && atLeast(manifest.relationships.systems[0].compatibility.minimum, "3.677.0"));
ok("E the system at TRG_PRIME_ROOT is 3.677.0 or later", atLeast(systemJson.version, "3.677.0"), systemJson.version);
ok("E the download names the version", manifest.download.includes(`v${manifest.version}/`));
// 0.1.1 (found live, 29 Oct): the compendiums sit in one "Eldritch Arts" folder.
equal("E one \"Eldritch Arts\" pack folder", (manifest.packFolders ?? []).map((f) => f.name), ["Eldritch Arts"]);
equal("E every pack in it exactly once, in book order", manifest.packFolders?.[0]?.packs, ["ea-races", "ea-heritages", "ea-backgrounds", "ea-classes", "ea-abilities", "ea-feats", "ea-spells", "ea-weapons", "ea-gear"]);
ok("E …and every declared pack is in it", manifest.packs.every((p) => manifest.packFolders?.[0]?.packs?.includes(p.name)));
equal("E every pack is declared in module.json with its extends", PACKS.map((p) => [p.name, manifest.packs.find((m) => m.name === p.name)?.flags?.["trg-prime"]?.extends]), PACKS.map((p) => [p.name, p.extends]));
equal("E the eight Block 1 packs ship, and Block 3's classes", PACKS.map((p) => p.name), ["ea-races", "ea-heritages", "ea-abilities", "ea-backgrounds", "ea-feats", "ea-spells", "ea-weapons", "ea-gear", "ea-classes"]);
for (const [label, docs] of [["races", B1.RACES], ["heritages", B1.HERITAGES], ["abilities", B1.ABILITIES], ["backgrounds", B1.BACKGROUNDS], ["feats", B1.BACKGROUND_FEATS], ["spells", B1.SPELLS], ["weapons", B1.WEAPONS], ["goods", B1.GOODS]]) ok(`E every one of Block 1's ${label} is in a pack`, docs.every((d) => ALL.includes(d)));
ok("E every pack extends a pack the system has", PACKS.every((p) => systemJson.packs.some((s) => s.name === p.extends)));
ok("E ids are unique across the module", new Set(ALL.map((d) => d._id)).size === ALL.length);
for (const p of PACKS) ok(`E ${p.name} is built (packs-source matches)`, fs.existsSync(path.join(ROOT, "packs-source", p.name)) && fs.readdirSync(path.join(ROOT, "packs-source", p.name)).length === p.docs.length);
const STATUS = /\b(Automated|Partly automated|Not automated|Not yet automated|Waits for Block 3b|Granted|Granted when the race is added|Applied automatically|Offered while carried|Traits as printed)\b[^:]*:/;
ok("E every item says what is automated", ALL.every((d) => STATUS.test(strip(d.system.description))), ALL.filter((d) => !STATUS.test(strip(d.system.description))).map((d) => d.name).join(", "));
ok("E no placeholder text", ALL.every((d) => !/\b(TODO|TBD|placeholder|lorem)\b/i.test(d.system.description)));

equal("D2 every scripted answer was used", answers.length, 0);

console.log(`verify-block1: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
