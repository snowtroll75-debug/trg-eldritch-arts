/**
 * Eldritch Arts — Block 3a (0.5.0): Chapter 3's three High Magic classes, the
 * Archmage, the Sorcerer with its seven birthrights, and the Witch with her
 * Soulbound Familiar, on TRG Prime 3.680.0. Their specialist spells and the
 * five Grimoire spells the birthrights grant are in block3-spells.mjs.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.classes`, cut from v1.6 by extract-book.mjs), never retyped. Each
 * item's description is that text followed by what TRG Prime does with it.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK3_AUDIT.md, answered by Graham on
 * 2 November 2026 ("your proposals all work"): Q15 (Storm's 0 PP spell is Orb
 * of Lightning), Q16 (specialist spells and hexes are High Magic too), Q17
 * (Life Boost through the Specialist Spell feat), Q18 ("Birthright Any" open
 * to every Sorcerer through the feat), Q19–Q20 and Q24 (the Wild birthright),
 * Q21 (the Bloodmage hexes open to every Witch), Q25 (Severed Bond).
 *
 * FLAGS under the system's scope are TRG Prime's declarations (3.680.0's
 * `classMagic`, `highMagicCaster`, `highMagicFocus`, `repertoire`,
 * `abilityChoices`, `classSkills`); the module's own keys there are prefixed
 * `ea`.
 */
import fs from "node:fs";
import { classItem, classAbility, changesEffect, conditional } from "./builders.mjs";
import { md } from "./markdown.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const CLASSES = BOOK.classes;

const printed = (lines) => md((lines ?? []).join("\n\n"));
const note = (text) => md(text);
const title = (caps) => caps.toLowerCase().replace(/(^|[\s(-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()).replace(/\bOf\b/g, "of").replace(/\bThe\b(?!$)/g, (m, o) => (o === 0 ? m : "the"));

/** A class's section by heading (the nth of that name). */
export function section(cls, name, nth = 0) {
  const found = CLASSES[cls].sections.filter((s) => s.name === name)[nth];
  if (!found) throw new Error(`Block 3: no "${name}" (#${nth + 1}) in the ${cls}`);
  return found;
}
const one = (cls, name, nth = 0) => section(cls, name, nth).lines.join(" ");
/** "**HEADING**" then the section's printed lines. */
const block = (s) => md(`**${s.name}**`) + "\n" + printed(s.lines);

/** The class table, as builders.classItem takes it: [bab, bdb, fort, ref, will, bonusFeats, CL, PP, BSB]. */
export function classTable(cls) {
  const tbl = CLASSES[cls].sections.flatMap((s) => s.tables).find((t) => /TABLE$/.test(t.rows[0]?.cells?.[0] ?? ""));
  const heads = tbl.rows[1].cells.map((c) => c.toLowerCase());
  const col = (row, ...names) => {
    const i = heads.findIndex((h) => names.includes(h));
    if (i < 0) throw new Error(`Block 3: the ${cls} table has no ${names.join("/")} column`);
    return Number(row.cells[i]);
  };
  return tbl.rows.slice(2).map((row) => [
    col(row, "bab", "bab/bdb"), col(row, "bdb", "bab/bdb"), col(row, "fort"), col(row, "ref"), col(row, "will"),
    col(row, "bonus feats"), col(row, "caster level"), col(row, "pp"), col(row, "bsb")
  ]);
}

/** "4 + Con per level" → 4. */
const leading = (text) => {
  const n = Number(/^(\d+)/.exec(String(text).trim())?.[1]);
  if (!Number.isFinite(n)) throw new Error(`Block 3: no number in "${text}"`);
  return n;
};

/** Chapter 6's Class Wealth table (L4754). */
export const CLASS_WEALTH = (() => {
  const out = {};
  const rows = BOOK.sections.classWealth?.rows ?? [];
  for (const r of rows.slice(2)) for (let i = 0; i + 1 < r.cells.length; i += 2) if (r.cells[i]) out[r.cells[i]] = Number(r.cells[i + 1]);
  return out;
})();

/* ------------------------------------------------------------------ */
/* The three classes                                                    */
/* ------------------------------------------------------------------ */

const PROFICIENCY = {
  Archmage: { weaponCategories: [], weaponNames: ["Club", "Staff"] },
  Sorcerer: { weaponCategories: ["Simple"], weaponNames: [] },
  Witch: { weaponCategories: ["Simple"], weaponNames: [] }
};

/** registerClass specs: proficiency as printed, and Chapter 6's class wealth. */
export const CLASS_REGISTRATIONS = Object.fromEntries(["Archmage", "Sorcerer", "Witch"].map((name) => [name, {
  wealth: CLASS_WEALTH[name],
  proficiency: {
    label: name,
    armourCategories: [], armourNames: [], otherTiers: [], armourExclude: [],
    shieldCategories: [], shieldNames: [],
    ...PROFICIENCY[name],
    weaponRules: [],
    deityWeapons: false
  }
}]));

function classSections(cls, names) {
  return names.map((n) => block(section(cls, n))).join("\n");
}

const ARCHMAGE_NOTE = [
  "*Automated (TRG Prime 3.680.0):*",
  "**a learned High Magic caster of every tradition.** Every spell it casts is High Magic (Hard, armour DR × 4, the High Magic fumble), and it may use a casting focus. Its Spell Book takes spells of any tradition: six at PP 2 at 1st, then one a level that it can cast; memorise 2 + (level × 2) (M16). Six cantrips of any tradition go in the book on the Cantrips card, and three are memorised each day. Intelligence is its magical ability.",
  "The table's caster level, PP and BSB, the class skills and the bonus feats (Scribe Scroll at 1st; a class feat at 5th, 10th, 15th and 20th) are the class item's. Chapter 6's class wealth is 1.",
  "*For the system's bookkeeping* the class names Arcane as its tradition (Intelligence's): the PP ability bonus, and a specialist spell's tradition, as Chapter 8 says (\"always based upon your primary tradition\"). It learns from every tradition alike.",
  "*Specialist spells:* through the Specialist Spell feat, any class's (the GM decides what is \"applicable\")."
].join(" ");

const SORCERER_NOTE = [
  "*Automated (TRG Prime 3.680.0):*",
  "**an instinctive High Magic caster of every tradition.** Press Use on **Birthright** to choose yours: it sets your magical ability (its first key ability), your tradition, two class skills, your specialist spell and its source list, and the additional spells, added at the printed levels.",
  "The Repertoire card holds two schedules: one spell of any tradition at 1st and every two levels from 3rd, and one of your birthright's tradition at 2nd and every two levels after. The Cantrips card takes the birthright's cantrip first, then one of any tradition.",
  "Every spell you cast is High Magic. **Raw Power** lets a warped High Magic spell cost 1 PP over your cap. Component Mastery and Empower Spell are granted at 1st; a class feat at 5th, 10th, 15th and 20th. Chapter 6's class wealth is 0.",
  "*Not printed, so not given:* repertoire swaps (the book gives these classes none)."
].join(" ");

const WITCH_NOTE = [
  "*Automated (TRG Prime 3.680.0):*",
  "**an instinctive High Magic caster of the Ethereal and Verdant traditions.** Two spells of either at 1st, one more a level from 2nd; two cantrips of either. Every spell you cast is High Magic, whatever its tradition (Graham's ruling, 4 November 2026): your hexes, and the spells feats and Pacts add outside your picks, too. Charisma is your magical ability.",
  "**Hexes** (the class ability): one at 1st, one more at 3rd and every three levels, chosen with its Use; they cast as specialist spells. The Bloodmage hexes are open to you (Q21).",
  "A class feat at 1st (M15), 5th, 10th, 15th and 20th. Chapter 6's class wealth is 1.",
  "*For the system's bookkeeping* the class names Ethereal as its tradition (Charisma's), for the PP ability bonus and a hex's tradition. It learns Verdant spells alike.",
  "*Not printed, so not given:* repertoire swaps."
].join(" ");

export const ARCHMAGE = classItem({
  name: "Archmage", classType: one("archmage", "CLASS TYPE"),
  description: `${printed(section("archmage", "DESCRIPTION").lines)}\n${classSections("archmage", ["BONUS FEATS", "MAGICAL TRADITION", "CANTRIPS", "MAGICAL ABILITY SCORE", "SPECIALIST SPELLS"])}\n${note(ARCHMAGE_NOTE)}`,
  keyAbilityScores: one("archmage", "KEY ABILITY SCORES"), classSkills: one("archmage", "CLASS SKILLS"),
  proficiencies: one("archmage", "PROFICIENCIES"), hitPoints: leading(one("archmage", "HIT POINTS")), skillPoints: leading(one("archmage", "SKILL POINTS")),
  grantedFeats: "1: Scribe Scroll", classAbilities: "1: Ley Bond, 1: Ley Tap",
  magicalTradition: "arcane", magicalAbility: "intelligence", casterStyle: "learned", memorisationStyle: "book",
  cantripsPerDay: 3, cantripsKnown: 6, spellBookFirstPicks: 6, wealth: String(CLASS_WEALTH.Archmage),
  table: classTable("archmage"),
  flags: { highMagicCaster: true, highMagicFocus: true, classMagic: { traditions: "any", bookPerLevel: 1, cantripBook: true } }
});

export const SORCERER = classItem({
  name: "Sorcerer", classType: one("sorcerer", "CLASS TYPE"),
  description: `${printed(section("sorcerer", "DESCRIPTION").lines)}\n${classSections("sorcerer", ["BONUS FEATS", "MAGICAL TRADITION", "HIGH MAGIC SPELLS", "SPECIALIST SPELL", "CANTRIPS", "MAGICAL ABILITY SCORE"])}\n${note(SORCERER_NOTE)}`,
  keyAbilityScores: one("sorcerer", "KEY ABILITY SCORES"), classSkills: one("sorcerer", "CLASS SKILLS"),
  proficiencies: one("sorcerer", "PROFICIENCIES"), hitPoints: leading(one("sorcerer", "HIT POINTS")), skillPoints: leading(one("sorcerer", "SKILL POINTS")),
  grantedFeats: "1: Component Mastery, 1: Empower Spell", classAbilities: "1: Birthright, 1: Raw Power",
  // The birthright supplies both (TRG Prime 3.680.0, D4e); until then the
  // class does not cast.
  magicalTradition: "", magicalAbility: "", casterStyle: "instinctive",
  cantripsKnown: 2, wealth: String(CLASS_WEALTH.Sorcerer),
  table: classTable("sorcerer"),
  flags: {
    highMagicCaster: true,
    repertoire: { firstPicks: 1, firstPickExact: false, pickFrom: 3, pickStep: 2, swapFrom: 99 },
    classMagic: {
      traditions: "any",
      tracks: [{ key: "birthright", label: "Birthright", firstPicks: 0, pickFrom: 2, pickStep: 2, traditions: "track" }],
      cantrips: [{ label: "birthright cantrip", track: "birthright" }, { label: "cantrip of any tradition", traditions: "any" }]
    }
  }
});

export const WITCH = classItem({
  name: "Witch", classType: one("witch", "CLASS TYPE"),
  description: `${printed(section("witch", "DESCRIPTION").lines)}\n${classSections("witch", ["BONUS FEATS", "MAGICAL TRADITION", "HIGH MAGIC SPELLS", "HEXES", "CANTRIPS", "MAGICAL ABILITY SCORE"])}\n${note(WITCH_NOTE)}`,
  keyAbilityScores: one("witch", "KEY ABILITY SCORES"), classSkills: one("witch", "CLASS SKILLS"),
  proficiencies: one("witch", "PROFICIENCIES"), hitPoints: leading(one("witch", "HIT POINTS")), skillPoints: leading(one("witch", "SKILL POINTS")),
  classAbilities: "1: Soulbound Familiar, 1: Verdant Communion, 1: Hexes",
  magicalTradition: "ethereal", magicalAbility: "charisma", casterStyle: "instinctive",
  cantripsKnown: 2, wealth: String(CLASS_WEALTH.Witch),
  table: classTable("witch"),
  flags: {
    // EVERY SPELL SHE CASTS (Graham, 4 November 2026: "All Witch spells are
    // considered to be High Magic"), as the Sorcerer and Archmage declare.
    // Block 3a's D4a list (Ethereal and Verdant only) is superseded.
    highMagicCaster: true,
    repertoire: { firstPicks: 2, firstPickExact: false, pickFrom: 2, pickStep: 1, swapFrom: 99 },
    classMagic: { traditions: ["ethereal", "verdant"] }
  }
});

export const CLASS_ITEMS = [ARCHMAGE, SORCERER, WITCH];

/* ------------------------------------------------------------------ */
/* Class abilities                                                      */
/* ------------------------------------------------------------------ */

const ability = (cls, name, heading, automation, extra = {}) => classAbility({
  name, sourceClass: cls, level: 1,
  description: `${md(section(cls.toLowerCase(), heading).traits.length ? `**${section(cls.toLowerCase(), heading).traits.join(" ")}**` : "")}\n${printed(section(cls.toLowerCase(), heading).lines)}\n${note(automation)}`.trim(),
  traits: section(cls.toLowerCase(), heading).traits.map((t) => t[0] + t.slice(1).toLowerCase()).join(", "),
  ...extra
});

/** Sidebar 5, LEY LINE RANGE (after L703), printed with Ley Tap. */
const LEY_RANGE = BOOK.sidebars.find((s) => s.title === "LEY LINE RANGE");
const RESIST_MAGIC = BOOK.sidebars.find((s) => s.title === "RESIST MAGIC");

export const LEY_BOND = ability("Archmage", "Ley Bond", "LEY BOND",
  "*Automated (0.5.0):* a High Magic casting's DC is 1 lower (as Ley Line Connection's, the two do not stack — one bond); press Use to sense the Ley Line areas within 100 ft per level of your token, with their level and direction.",
  { flags: { eaLeyBond: true } });

export const LEY_TAP = classAbility({
  name: "Ley Tap", sourceClass: "Archmage", level: 1,
  description: `${printed(section("archmage", "LEY TAP").lines)}\n${md(`**${LEY_RANGE.title}**`)}\n${printed(LEY_RANGE.lines.slice(1))}\n${note("*Automated (0.5.0):* while a Ley Line area lies within 100 ft per level of your token (sidebar 5), your Power Recovery (Meditation) checks have advantage — an effect named \"Ley Tap: in range\" says so, switched on and off as you move. Off the map, the effect stays as it was last found.")}`
});

export const BIRTHRIGHT_NAMES = Object.freeze(["Arcanum", "Dragon", "Eternity", "Rune", "Storm", "Umbral", "Wild"]);

export const BIRTHRIGHT = classAbility({
  name: "Birthright", sourceClass: "Sorcerer", level: 1,
  description: `${printed(section("sorcerer", "BIRTHRIGHT", 0).lines)}\n${printed(section("sorcerer", "BIRTHRIGHT", 1).lines)}\n${["KEY ABILITY SCORE", "BONUS SKILLS", "SPECIAL ABILITY", "BIRTHRIGHT SPELL", "TRADITION SPELLS", "ADDITIONAL SPELLS"].map((n) => block(section("sorcerer", n, 0))).join("\n")}\n${note("*Automated:* press Use to choose Arcanum, Dragon, Eternity, Rune, Storm, Umbral or Wild. The birthright is added to your sheet with everything it grants. It is a one-off choice; to change it, delete the birthright.")}`,
  flags: { abilityChoices: [...BIRTHRIGHT_NAMES] }
});

export const RAW_POWER = ability("Sorcerer", "Raw Power", "RAW POWER",
  "*Automated (TRG Prime 3.680.0):* when a High Magic spell you cast is warped above its base PP, your cap for that casting is 1 higher; the over-the-cap prompt (Overcasting by Sacrifice) waits until you are past even that.");

export const SOULBOUND_FAMILIAR = ability("Witch", "Soulbound Familiar", "SOULBOUND FAMILIAR", [
  "*Automated (0.5.0, TRG Prime 3.680.0):* press Use to make your familiar (the core's Familiar, as the Familiar feat makes it, with its abilities and Empathic Link). It gains Base DR 2, HP equal to your level and your Charisma as a class bonus to its saves; it is a +1 spell adder (one free casting a day) while it lives and the bond holds.",
  "**The daily bonus:** chosen at daily preparation (or with Use once bonded), applied to you while your familiar's token is within 30 feet of yours (both on the map); off the map it stays as it was.",
  "**Severed Bond:** when your familiar is killed you are fatigued 2, and a new bond can only be made at a daily preparation (offered then); the new bond ends the fatigue. *Not automated:* the mile-and-24-hours separation — tick it with Use (Q25)."
].join(" "));

export const VERDANT_COMMUNION = ability("Witch", "Verdant Communion", "VERDANT COMMUNION",
  "*Automated (0.5.0):* press Use once a day: the core's Power Recovery (Meditation) check is rolled and its bonus PP regained, and you gain a +2 class bonus to Nature and Survival for an hour.",
  { usesPerDay: "1", traits: "Concentrate, Mental" });

export const HEXES = classAbility({
  name: "Hexes", sourceClass: "Witch", level: 1,
  description: `${printed(section("witch", "HEXES").lines)}\n${note("*Automated (0.5.0):* press Use to choose a hex you are owed — one at 1st, one more at 3rd and every three levels (1 + level ÷ 3, rounded down). Each is added as a specialist spell: its cap is your level, its casting Very Easy, and as a Witch's spell it is High Magic (Q16).")}`
});

/* ------------------------------------------------------------------ */
/* The birthrights                                                      */
/* ------------------------------------------------------------------ */

/** The sections from one birthright's heading to the next. */
function birthrightSections(name) {
  const all = CLASSES.sorcerer.sections;
  const start = all.findIndex((s) => s.name === name.toUpperCase());
  const next = all.findIndex((s, i) => i > start && BIRTHRIGHT_NAMES.map((b) => b.toUpperCase()).includes(s.name));
  return all.slice(start, next < 0 ? undefined : next);
}
const bsec = (name, heading) => {
  const s = birthrightSections(name).find((x) => x.name === heading);
  if (!s) throw new Error(`Block 3: ${name} has no ${heading}`);
  return s;
};

const ABILITY_KEY = { Intelligence: "intelligence", Wisdom: "wisdom", Charisma: "charisma", Constitution: "constitution", Dexterity: "dexterity", Strength: "strength" };
const TRADITION_KEY = { Arcane: "arcane", Divinity: "divinity", Ethereal: "ethereal", Verdant: "verdant" };

/** Q15: Storm's "Shock Bolt (0)" is Orb of Lightning, the core's lightning cantrip. */
export const SPELL_SUBSTITUTES = Object.freeze({ "Shock Bolt (0)": "Orb Of Lightning" });

/** "1st | Read Aura (0), Magic Missile (2)" rows → [{level, name, pp}]. */
export function additionalSpells(name) {
  const tbl = bsec(name, "ADDITIONAL SPELLS").tables[0];
  const out = [];
  for (const row of tbl.rows.slice(1)) {
    const level = Number(/^(\d+)/.exec(row.cells[0])?.[1]);
    for (const raw of row.cells[1].split(/,\s*/)) {
      const m = /^(.+?)\s*\((\d+)\)\\?\*?$/.exec(raw.replace(/\\\*/g, "*").replace(/\*$/, "").trim());
      if (!m) throw new Error(`Block 3: ${name} additional spell "${raw}"`);
      const printedName = `${m[1].trim()} (${m[2]})`;
      out.push({ level, name: SPELL_SUBSTITUTES[printedName] ?? m[1].trim(), pp: Number(m[2]), printed: m[1].trim(), substituted: Boolean(SPELL_SUBSTITUTES[printedName]) });
    }
  }
  return out;
}

const SPECIAL = {
  Arcanum: "SORCEROUS BOND", Dragon: "DRAGON CLAWS", Eternity: "ETERNITY RESILIENCE", Rune: "RUNIC RESILIENCE",
  Storm: "GALE STEP", Umbral: "UMBRAL AFFINITY", Wild: "WILD POWER"
};
const SPECIALIST_OF = { Arcanum: "Disrupting Magic", Dragon: "Draconic Infusion", Eternity: "Touch of Healing", Rune: "Storing Rune", Storm: "Storm Bolt", Umbral: "Shadow Shift", Wild: "" };
/** What "You may select additional specialist spells from …" opens (registered in block3-automations). */
export const BIRTHRIGHT_ACCESS = Object.freeze({ Arcanum: { classes: ["Wizard"] }, Dragon: { classes: ["Wizard"] }, Eternity: { classes: ["Cleric"] }, Rune: { classes: ["Cleric"] }, Storm: { classes: ["Druid"] }, Umbral: { traits: ["shadow"] }, Wild: {} });

function birthrightOf(name) {
  const keyLine = bsec(name, "KEY ABILITY SCORE").lines[0];
  const first = /^(\w+)/.exec(keyLine)[1];
  const skillsLine = bsec(name, "BONUS SKILLS").lines[0];
  const skills = /are ([A-Z][\w ]+?) and ([A-Z][\w ]+?)\./.exec(skillsLine);
  if (!skills) throw new Error(`Block 3: ${name}'s bonus skills`);
  const tradLine = bsec(name, "TRADITION SPELLS").lines[0];
  const trad = /from the (\w+) tradition|from any tradition/.exec(tradLine);
  const tradition = trad?.[1] ? TRADITION_KEY[trad[1]] : (/any tradition/.test(tradLine) ? "any" : null);
  if (!tradition) throw new Error(`Block 3: ${name}'s tradition`);
  const spells = name === "Wild" ? [] : additionalSpells(name);
  const specialist = SPECIALIST_OF[name];
  const granted = [...(specialist ? [`1: ${specialist}`] : []), ...spells.map((s) => `${s.level}: ${s.name}`)].join(", ");
  const sections = birthrightSections(name);
  const substituted = spells.filter((s) => s.substituted);
  const automation = [
    "*Automated (0.5.0, TRG Prime 3.680.0):*",
    `${title(first)} is your magical ability; ${tradition === "any" ? "your birthright spells may be of any tradition, and you have no single tradition of your own" : `${trad[1]} is your tradition and the tradition of your birthright spells and cantrip`}. ${skills[1]} and ${skills[2]} are class skills.`,
    specialist ? `**${specialist}** is granted at 1st;` : "",
    name === "Wild" ? "Your additional spells and your daily specialist spell are rolled for you (see Wild Power)." : `the additional spells are added at the printed Sorcerer level${spells.length ? ` (${spells.map((s) => `${s.level}: ${s.name}`).join(", ")})` : ""}, outside your picks.`,
    BIRTHRIGHT_ACCESS[name].classes ? `The Specialist Spell feat also offers you the ${BIRTHRIGHT_ACCESS[name].classes.join(" and ")} list.` : BIRTHRIGHT_ACCESS[name].traits ? "The Specialist Spell feat also offers you every specialist spell with the shadow trait." : "",
    substituted.length ? `*As ruled (Q15):* the printed ${substituted.map((s) => `"${s.printed} (${s.pp})"`).join(", ")} is ${substituted.map((s) => s.name).join(", ")}: the core's ${substituted[0].printed} costs 4 PP, too much to cast at 1st.` : ""
  ].filter(Boolean).join(" ");
  return classAbility({
    name, sourceClass: "Sorcerer", level: 1,
    description: `${printed(sections[0].lines)}\n${sections.slice(1).map((s) => `${md(`**${s.name}**${s.traits.length ? ` ${s.traits.join(" ")}` : ""}`)}\n${printed(s.lines)}${s.tables.map((t) => md(t.rows.map((r) => r.cells.join(" — ")).join("\n\n"))).join("\n")}`).join("\n")}\n${note(automation)}`,
    grantedAbilities: title(SPECIAL[name]).replace(/^Gale Step$/, "Gale Step"),
    grantedSpells: granted,
    flags: {
      classMagic: { ability: ABILITY_KEY[first], tradition: tradition === "any" ? "" : tradition, tracks: { birthright: tradition } },
      classSkills: [skills[1], skills[2]],
      eaBirthright: name,
      ...(name === "Arcanum" ? { highMagicFocus: true } : {})
    }
  });
}

export const BIRTHRIGHTS = BIRTHRIGHT_NAMES.map(birthrightOf);

/** The birthrights' special abilities (granted by the birthright). */
const special = (birthright, automation, extra = {}) => {
  const s = bsec(birthright, SPECIAL[birthright]);
  return classAbility({
    name: title(SPECIAL[birthright]), sourceClass: "Sorcerer", level: 1,
    description: `${s.traits.length ? md(`**${s.traits.join(" ")}**`) + "\n" : ""}${printed(s.lines)}\n${note(automation)}`,
    traits: s.traits.map((t) => t[0] + t.slice(1).toLowerCase()).join(", "),
    ...extra,
    flags: { eaBirthright: birthright, ...(extra.flags ?? {}) }
  });
};

export const SORCEROUS_BOND = special("Arcanum",
  "*Automated (0.5.0):* you are granted the core's **Arcane Bond** (its daily choice of item and its spell adder), and you may use a casting focus with High Magic (Chapter 7: \"unless you possess the Arcanum birthright\"). *Not automated:* the system's casting focus is the sheet's Focus checkbox — tick it while you hold the bonded item.",
  { grantedAbilities: "Arcane Bond", flags: { highMagicFocus: true } });

export const DRAGON_CLAWS = classAbility({
  name: "Dragon Claws", sourceClass: "Sorcerer", level: 1,
  description: `${printed(bsec("Dragon", "DRAGON CLAWS").lines)}\n${md("**DRAGON TYPE**")}\n${printed(bsec("Dragon", "DRAGON TYPE").lines)}\n${note("*Automated (0.5.0, TRG Prime 3.680.0):* press Use (1 AP, concentrate) to grow your claws — a natural weapon, 1d6 piercing, agile and finesse, whose attack uses your BSB in place of your BAB when that is higher. Use again to retract them. The first Use asks your dragon type, kept for Draconic Infusion.")}`,
  traits: "Concentrate",
  flags: { eaBirthright: "Dragon" }
});

export const DRAGON_TYPES = Object.freeze({ cave: "acid", cold: "cold", fire: "fire", forest: "poison", light: "electricity", sea: "sonic" });

export const ETERNITY_RESILIENCE = special("Eternity",
  "*Automated (0.5.0):* +2 to your Death State. *Automated (0.6.0, TRG Prime 3.681.0):* when a creature deals you a critical hit, weapon or spell, you are asked before the critical roll (your player, else the GM): spend a Conviction point for disadvantage on it, which cancels a deadly critical's advantage. Not offered on a minor critical, whose roll is at disadvantage already. The core's one Conviction point a round applies (Q35).",
  { effects: [(id, n) => changesEffect(id, `${n}: Death State +2`, [{ key: "system.combat.deathState", mode: 2, value: "2", priority: 20 }], "Eternity Resilience: +2 to Death State.")] });

export const RUNIC_RESILIENCE = special("Rune",
  "*Automated (0.5.0):* you are granted **Resist Magic**.",
  { grantedAbilities: "Resist Magic" });

export const RESIST_MAGIC_ABILITY = classAbility({
  name: "Resist Magic", sourceClass: "Sorcerer", level: 1,
  description: `${md(`**${RESIST_MAGIC.lines[1]}**`)}\n${printed(RESIST_MAGIC.lines.slice(2))}\n${note("*Automated (0.6.0, TRG Prime 3.681.0):* when a spell (cast from anything) or damage the system marks magical is about to reach you, you are asked (your player, else the GM). Yes spends your reaction, and you resist that spell's damage, every type it deals and every instance, until it has been resolved (Q32); other magical damage, its types for that blow. Not a weapon's own damage. Damage a spell goes on dealing on a later turn (a wall, a storm, an emanation, a hazard) is asked about too, and resisted for that blow.")}`,
  traits: "Warding",
  flags: { eaBirthright: "Rune" }
});

export const GALE_STEP = special("Storm",
  "*Automated (0.5.0):* press Use (1 AP; it is a Focus ability, so it spends a Focus use if your sheet keeps them) and click where you teleport: up to 15 feet from your token, in any direction.");

export const UMBRAL_AFFINITY = special("Umbral",
  "*Automated (0.5.0):* you are granted the core's **Darkvision**; at 5th level **Darkness** is added, cast as a specialist spell (its cap your level, its casting Very Easy).",
  { grantedAbilities: "Darkvision", grantedSpells: "5: Darkness", flags: { eaSpecialistGrants: ["Darkness"] } });

export const WILD_POWER = special("Wild", [
  "*Automated (0.5.0, TRG Prime 3.680.0):* +1 PP a level.",
  "**Surges:** a spell of PP 2 or more whose Spellcraft d20 shows an unmodified 13 rolls the Wild Surge table — at the spell's PP as the level (Q20), or in a Wild Magic area at the area's level with disadvantage (the GM is shown both rolls; L5752).",
  "**Your specialist spell:** at each daily preparation a random PP 1 specialist spell of any class replaces the last (Q24).",
  "**Your additional spells:** press Use to roll those owed — two at 1st (a cantrip and a PP 2), then one at 3rd, 5th … 15th at PP 4, 6 … 16 (Q19). Each rolls the d20 for its tradition, then a random spell of that tradition and PP you do not know; whoever presses Use (the GM, usually) may keep it or choose another from the list."
].join(" "), { flags: { eaWild: true } });

export const CLASS_ABILITIES = [LEY_BOND, LEY_TAP, BIRTHRIGHT, RAW_POWER, SOULBOUND_FAMILIAR, VERDANT_COMMUNION, HEXES];
export const BIRTHRIGHT_ABILITIES = [SORCEROUS_BOND, DRAGON_CLAWS, ETERNITY_RESILIENCE, RUNIC_RESILIENCE, RESIST_MAGIC_ABILITY, GALE_STEP, UMBRAL_AFFINITY, WILD_POWER];

/** The Wild birthright's additional spells: [level, PP] (Q19 — the other birthrights' levels and PP). */
export const WILD_SPELL_LADDER = Object.freeze([[1, 0], [1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12], [13, 14], [15, 16]]);
/** The d20 → tradition table, as printed. */
export const WILD_TRADITIONS = (() => {
  const tbl = bsec("Wild", "ADDITIONAL SPELLS").tables.find((t) => /D20/i.test(t.rows[0]?.cells?.[0] ?? ""));
  return tbl.rows.slice(1).map((r) => {
    const [lo, hi] = r.cells[0].split(/[-–]/).map(Number);
    return { min: lo, max: hi, tradition: TRADITION_KEY[r.cells[1]] };
  });
})();

/** The eight Soulbound Familiar bonuses, as printed, each with what it does. */
export const SOULBOUND_BONUSES = (() => {
  const lines = section("witch", "SOULBOUND FAMILIAR").lines.filter((l) => l.startsWith("- ")).map((l) => l.slice(2));
  if (lines.length !== 8) throw new Error(`Block 3: ${lines.length} Soulbound Familiar bonuses, expected 8`);
  return lines;
})();

export { conditional };
