# Eldritch Arts module — Progress

**Module:** `trg-eldritch-arts` 0.12.1 (Blocks 1–8) · **System:** TRG Prime 3.687.1 · **Foundry:** V14
**Book:** *TRG Prime: Eldritch Arts* v1.6 (docx), with its 34 text-box sidebars recovered (Block 1 was first built from v1.4)
**Rulings:** *Responses to Audit Eldritch Arts*, 1 November 2026 (`ELDRITCH_ARTS_RULINGS_2026-11-01.md`); each block's questions in its own audit — Q1–Q14 (Block 2), Q15–Q35 (Block 3), Q36–Q56 (Block 4), Q57–Q88 (Block 5), Q89–Q149 (Block 6), Q150–Q166 and the 07:53 rulings of 7 November (Block 7), Q167–Q184 of 8 November (Block 8, "As recommended")
**Date:** 12 November 2026 (brought up from 0.11.2)

## Where things stand

| Phase | State |
|---|---|
| 1. Examine the system | Done. Core API, packs, magic code and the Inner Tempest module pattern are mapped. |
| 2. Implementation matrix | Done. 707 features: A 369 · B 256 · C 42 · D 40 (target, with the core dependencies; recounted on v1.6). Implemented 106 (Block 1); 0.1.0 tested live on 3.675.1. |
| 3. Rules audit | Done, with Part F from Block 1. Critical 8 · Major 117 · Minor 229 · Recommendation 24. Every excerpt has been checked word for word by script. Parts A–E answered by Graham on 1 November. |
| Architecture and core dependencies | Drafted: D1–D18, each to be prepared separately for your approval. Block 1's own seams: C1–C11 in TRG Prime 3.675.0, C12–C14 in 3.677.0. Block 2a's: D1, D1b, D7, A1 and parts of D6 and D14 in 3.678.0. Block 2b's: D13 (ritual rules) and casting options in 3.679.0. |
| Block 1 (0.2.0) | **Rebuilt on v1.6 with the rulings; tested live** on 3.677.0 and 3.677.1 (`LIVE_TESTING_REPORT_0.2.0.md`). Races, heritages, racial abilities, backgrounds, the background feats, the core racial feats opened, Chapter 4's actions, Orb of Water, exotic weapons, goods. 105 items in 8 packs. Ten questions settled; twelve still open, with two new ones (`ELDRITCH_ARTS_BLOCK1_AUDIT.md`). |
| Block 2a (0.3.0) | **Built, tested by harness, and tested live** on 3.678.0 (`LIVE_TESTING_REPORT_0.3.0.md`: 16 tests passed, one cosmetic finding). High Magic; Ley Line, Wild Magic and Magic Suppression areas as Region Behaviours; antimagic; Tap Ley Line, Channel Ley Line, Tap Magical Energy; Ley Sense on the map; the three Chapter 7 tables (`RELEASE_NOTES_0.3.0.md`). |
| Block 2b (0.4.0) | **Built, tested by harness, and tested live** on 3.679.0 (`LIVE_TESTING_REPORT_0.4.0.md`: 18 tests passed, one cosmetic finding in the core). Mundane ritual casting (the variant and its three sacrifices, Ritual spells, the ritual goods and Ritual Expert), summoning circles, true names, Spell Trickery, Borrow Spell (`RELEASE_NOTES_0.4.0.md`). Q9–Q14 built as proposed, awaiting Graham. |
| Block 3a (0.5.0, 0.5.1) | **Built, tested by harness, and tested live** on 3.680.0 (`LIVE_TESTING_REPORT_0.5.0.md`: 34 tests; 7 findings, all fixed in 0.5.1, and 0.5.1 tested live with TRG Prime 3.680.1's teleport fix: 20 tests passed, no findings, `LIVE_TESTING_REPORT_0.5.1.md`). The Archmage, the Sorcerer and its seven birthrights, the Witch, the Soulbound Familiar, 34 specialist spells and hexes, five Grimoire spells. Q15–Q25 answered as proposed. Fixed: the four races' racial PP (a core defect found by the audit). |
| Block 3b (0.6.0, 0.6.1) | **Built, tested by harness, and tested live** on 3.681.0 (`LIVE_TESTING_REPORT_0.6.0.md`: 25 tests, including two clients; 2 findings, both fixed in 0.6.1, which awaits Graham's install). Two older system defects were seen (a Death critical always kills; a touch attack always misses). Both are fixed in TRG Prime 3.681.1, at Graham's go-ahead. The seven reactions: Missed Chance, Second Chance, Prophetic Warning, Phase Familiar, Resist Magic, Disrupting Magic, Eternity Resilience (`RELEASE_NOTES_0.6.0.md`). Q26–Q35 answered as proposed (`ELDRITCH_ARTS_BLOCK3B_AUDIT.md`). The system's reaction seams are in TRG Prime 3.681.0. Not offered: damage from an ongoing effect after its spell has resolved. |
| Block 4 (0.7.0, 0.7.1) | **Built, tested by harness, and tested live** on TRG Prime 3.682.0, built on Graham's 3.681.2 (`LIVE_TESTING_REPORT_0.7.0.md`: 25 tests; 3 findings, all fixed in 0.7.1 and TRG Prime 3.682.1, and retested live: 7 tests passed, no new findings, `LIVE_TESTING_REPORT_0.7.1.md`). The Spellblade and its four paths, Infuse Weapon and the Book of Infusions' runes, the five Spellblade spells; the Warlock, Xithra, the eight bonded souls and their daily powers and +1 level, its innate Focus spells, hex and cantrips; sidebar 16's feats for all four classes (`RELEASE_NOTES_0.7.0.md`, `RELEASE_NOTES_0.7.1.md`). Q36–Q52 per `ELDRITCH_ARTS_BLOCK4_AUDIT.md`. `verify-block4` 108 checks; `mutate-block4` 86 of 86 caught. Q53 (Battle Mage covers the maneuver spells) is in TRG Prime 3.682.2; Battle Mage's card says so from 0.8.0. Q54: Spiritual Weapon is left as is. |
| Block 5 (0.8.0) | **Built and tested by harness** on TRG Prime 3.683.0 (`RELEASE_NOTES_0.8.0.md`): the 74 racial and 43 general feats (108 new; 44 A, 43 B, 10 C, 11 D), on the core's seams C1–C19. Q57–Q88 per `ELDRITCH_ARTS_BLOCK5_AUDIT.md` (as proposed; Q58 and Q59 changed). Independent reviews of both releases, findings fixed. `verify-block5a`–`5d`: 295, 251, 135, 349 checks; 99, 120, 86, 98 mutations caught. Tested live on 4 November (`LIVE_TESTING_REPORT_0.8.0.md`): 14 tests passed, no findings. |
| Block 6 (0.9.0) | **Built and tested by harness** on TRG Prime 3.684.0 (`RELEASE_NOTES_0.9.0.md`): the 23 archetypes and 97 class feats (39 A, 70 B, 11 C, 0 D), the module's metamagic (G1), and Block 5's five deferred feats (4 B, 1 C). Q89–Q149 per `ELDRITCH_ARTS_BLOCK6_AUDIT.md` (as proposed; Q89: one release). Independent reviews of both releases (two each); findings fixed. Harnesses: `verify-block6a`, `6b1`, `6b2`, `6c`, `6d`, `6e` and `6-lead`, each with its mutation pair. Live-tested 4 November without a map (`LIVE_TESTING_REPORT_0.9.0.md`): 9 of 9 pass; the token-based tests wait for a visible browser. |
| Block 6, 0.9.1 | Graham's answers after 0.9.0 (4 November, 18:43 and 18:49), on TRG Prime 3.684.1: every Witch spell is High Magic; Wellspring Conduit reads the PP cast; the spell images fixed; and, in the core, same-type DB bonuses don't stack, two-skill prerequisites are checked, and Economic and Signature Spell lower what is paid. |
| Block 6, 0.9.2 | The 3.684.4 live test's finding: Lightning Rod's splash posts its card (`RELEASE_NOTES_0.9.2.md`, `LIVE_TESTING_REPORT_0.9.2.md`). |
| Block 7 (0.10.0) | **Built and tested by harness** on TRG Prime 3.685.0 (`RELEASE_NOTES_0.10.0.md`): the first half of Chapter 8's Grimoire, 42 spells (17 A, 17 B, 6 C, 2 D), the Elemental Strike ability, Distracted (Q157), every Grimoire spell uncommon (m84, Q166), Paradox Weave's target restored, the extractor's lost fields (Target, Requirement, bold commas). Q150 changed (recurring damage stacks by type, a core rule), Q151–Q166 as proposed, H1–H11 in TRG Prime 3.685.0; Dragon Wings and Spirit Arrow ruled at 07:53. Block 6's Pacts now grant Dragon's Breath, Elemental Strike and Dragon Wings. Three spells wait on a core change to reach the audit's grade (Arcane Mycelium's light, Glyph of Retribution's type change, Spirit Arrow's manoeuvre). Harnesses: `verify-block7` / `mutate-block7`. Not yet live-tested: it needs tokens on a map (thorns, Regions, reactions, teleports). |
| Block 7, 0.10.1 | The 0.10.0 live test's findings, on TRG Prime 3.685.1: the Spatial Awareness card comes with the teleport; Spirit Arrow's card; object targets (`targetsObject`); Distracted as one effect (`RELEASE_NOTES_0.10.1.md`). |
| Block 8 | **Audited** (`ELDRITCH_ARTS_BLOCK8_AUDIT.md`, 8 November 2026): the 39 remaining Grimoire spells, in two releases (Q167). Graham answered at 17:22: "As recommended" (Q167–Q184 as each row recommends, H12–H18 approved). |
| Block 8a (0.11.0) | **Built and tested by harness** on TRG Prime 3.686.0 (`RELEASE_NOTES_0.11.0.md`): the eight Bindings, Symbols of Insanity, Pain and Weakness, and eleven utilities (22 spells: 0 A, 12 B, 6 C, 4 D, each at its audit grade); Symbol of Death and Fear rebuilt (D → B), Versatile Binder (C → B), Ley Line Effects 25–27 (Q184). Seams H12 (the control register), H17 (held conditions; core Remove Curse counteracts curses) and H18 (core Insanity's d10 each turn) in TRG Prime 3.686.0, with Q170's "until dismissed" lock (a core reader change outside the approved seams, flagged). An independent review found twelve issues, all fixed before release (`RELEASE_NOTES_0.11.0.md`, "Fixed in review"). Harnesses: `verify-block8a` / `mutate-block8a`. Not yet live-tested: it needs tokens on a map (Regions, line of sight, the control register's turn-start save). |
| Block 8a, 0.11.1 | Live-tested in Graham's world (Foundry 14.367, TRG Prime 3.686.0): two Harmonic Rift findings fixed. A token walking out of an opening was sent through (V14's `doc.regions` is stale in `updateToken`), and the sonic save's line was escaped (`RELEASE_NOTES_0.11.1.md`). |
| Block 8a, 0.11.2 | The 0.11.1 live recheck: Harmonic Rift still misfired. The real cause: in V14's `updateToken` the token document holds the OLD position, and the new one is in `change`. Every move check now reads the end position. An occupied far opening no longer reports a passage. The harness now models V14 (`RELEASE_NOTES_0.11.2.md`). |
| Block 8b (0.12.0, 0.12.1) | **Built, harness-tested and live-tested twice** on TRG Prime 3.687.0–3.687.1 (`RELEASE_NOTES_0.12.0.md`, `RELEASE_NOTES_0.12.1.md`, `LIVE_TEST_0.12.0.md`, `LIVE_TEST_0.12.1.md`): the ten rituals and seven Chapter 7 High Magic spells (17: 1 A, 10 B, 5 C, 1 D, each at its audit grade). Seams H13 (a ritual's Partial casts), H14 (a ritual by its primary alone), H15 (rest rates) and H16 (a rolled, turn-start, following storm) in TRG Prime 3.687.0. With it: one writer per GM account (TRG Prime 3.686.1's election), the extractor's Cost field, Riserune's object target. Harnesses: `verify-block8b` / `mutate-block8b`. Not yet live-tested: rituals with ticked participants and world-time durations, a Wild Magic area under Chaos Shield, an anchored ley line, Mimic Spell against a second client, Storm of Unmaking's turn strikes. |
| Blocks 9–10 | Not started. |
| Tests | 8 November 2026, on TRG Prime 3.686.0: every module `verify-*` passes (21 files, 5,333 checks; `verify-block8a` 338), and every `mutate-*` was run in a scratch copy (21 files, 2,137 mutations, all caught; `mutate-block8a` 137), after the independent review's twelve findings and the re-review's six were fixed. The core's own harnesses for Block 8a's seams are `verify-control-register-api`, `verify-held-conditions` and `verify-turn-table`, each with its mutation pair (TRG Prime 3.686.0). |
| Publishing | Nothing pushed or published. The GitHub repo `snowtroll75-debug/trg-eldritch-arts` does not exist yet. The core's changes are local and uncommitted (3.677.0, 3.677.1, 3.678.0 and 3.679.0 are staged on 3.676.1 as you delivered it). |

## Counts checked against the book

- Feats: 237 (racial 74, archetype 23, class 97, general 43). Extracted by script from the headings.
- Grimoire spells: 87 in v1.6 (Dragon Wings added, M2); all 87 built (Block 8b's 17, Block 8a's 22, Block 7's 42 and six earlier). Specialist spells: 41, all built. Both cross-checked against every "NAME PP n" heading: no missing names, no extra names.
- Invested items (runes, armour, orbs, rods, staves, weapons, relics): every INVESTED heading has a matrix row.
- Gear: exotic weapons 18 (14 melee, 4 ranged), goods 31, catalysts 24, special materials 10.

## Rulings needed — the ones that change play most

**Criticals (cannot be built as printed):**
1. **EA-C1 Null Aura.** The save to benefit from allies' spells has no type or DC.
2. **EA-C2 Warlock PP feats.** Warlock's Hex and Pact Channeler spend PP a Warlock does not have. Options (a), (b) and (c) are in the entry.
3. **EA-C3 Tap Magical Energy.** No DC is printed. The proposal is the item's level DC.
4. **EA-C4 Soul Confluence.** The fixed 10-minute duration makes the backlash 50d6 Soul Drain, which is always lethal.
5. **EA-C5 Veil Severing.** Its outcome ladder and warps are copied from Rite of Binding Oath.
6. **EA-C6 Catalyst rune.** Its tier table is copied from Binding Sigils; it gives no number of catalysts and no use rule.
7. **EA-C7 Leywalk.** The feat grants a Leywalker spell that does not exist anywhere.
8. **EA-C8 Veilshroud.** Flaming I, a weapon-only rune, is on a cloak.

**Majors that decide whole subsystems:**
- **EA-M4 High Magic vs the core's High Magic mode.** The core has its own High Magic (save DC +2, free Heighten, fumble +50). This book's version is different: no tradition or school, casting DC +2, armour DR ×4, and its own fumble and resonance rules. You need to rule which applies, or how the two combine. Block 2 waits on this. Related: **EA-M27**, where the Appendix trait contradicts Chapter 7, and **EA-M29**, where six High Magic spells print a school trait.
- **EA-M30 Rituals.** The core caps a ritual's result at Success (Core L20135), so every ritual "Critical" result printed here can never happen. Lift the cap for Eldritch Arts rituals, or not?
- **EA-M40, EA-M76, EA-M91 "Persistent" damage.** The core term is "recurring". Proposal: read persistent as recurring throughout.
- **EA-M23 Birthrager.** "Low PP and a low spellcraft bonus" is not defined anywhere.
- **EA-M28 Warlock hexes.** The Warlock gets one hex, ever. Confirm, or give it the Witch's schedule.
- **EA-M26 Spellstrike.** It is still undefined after the sidebars.
- **EA-M61 Wild birthright.** It grants a "random PP 2 specialist spell", but there are no PP 2 specialist spells.
- **EA-M100 Relics have no item level,** so relic innate-spell DCs cannot be set. Also **EA-M97**: "gradually" awakening has no rate.
- **EA-M111 Ego DC.** The formula is not printed. Dawnshield implies 10 + Ego.
- **Missing spells:** Leyline Surge (**EA-M85**), Flame Bolt (**EA-M88**).
- **Orbs:** it is unclear whether High Magic's +2 stacks with the orb's +2, and the tradition-skill path cannot work for High Magic (**EA-M80**, **EA-M81**). The Resonant Flare size is also undefined (**EA-M82**, **EA-M83**).

**System questions (not book defects):**
- **Casting DC rounding.** The brief writes ceil(1.5 × PP). The system has rounded down since 3.549.0, following the Core default on p10. The module follows the core. A change would be a core ruling.
- **High Magic formula.** The brief's "Save DC = 10 + PP + casting ability + modifiers" and "Max PP per cast = CL + 1" match the core. Specialists are capped at character level.

## Plan

The book is built in 10 blocks; the list is in `ELDRITCH_ARTS_ARCHITECTURE.md`. Each block follows the same steps: build, harness, sweep, zip, you install, live test.

- **Block 1 (0.2.0, on TRG Prime 3.677.0): rebuilt on v1.6.** Install TRG Prime 3.677.0, then the module, and test live (`RELEASE_NOTES_0.2.0.md`). The open Block 1 questions are listed in `ELDRITCH_ARTS_RULINGS_2026-11-01.md`.
- **Block 2: High Magic, ley lines, wild magic, suppression, rituals and circles.** Built from v1.6 with your rulings (M4–M10, M25, M27, M30, M45, C5, m90, R14); needs core D1, D6, D7 and D13.

Core changes (D1–D18) are prepared on a separate branch of the core repo and sent to you for approval. They are never pushed to main.

## Before anything can be published

- Create the GitHub repo `snowtroll75-debug/trg-eldritch-arts` (or tell me the name you want).
- Approve each core dependency before it is merged.
