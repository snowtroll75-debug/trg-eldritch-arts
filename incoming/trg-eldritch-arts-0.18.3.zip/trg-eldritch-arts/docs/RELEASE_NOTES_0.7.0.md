# Eldritch Arts 0.7.0

3 November 2026. **Block 4:** Chapter 3's last two classes, the Spellblade with its four paths and the Warlock with its eight bonded souls, with Xithra and the Spellblade's five specialist spells. Built from `ELDRITCH_ARTS_BLOCK4_AUDIT.md`, as Graham answered it on 3 November 2026:
- **Q36, Q45, Q46 and Q48** as proposed.
- **Q37 as he changed it:** every Warlock spell is innate and Focus, the cantrips too.
- **Q43 as he ruled it:** half damage from poison and from a disease.
- **Q38–Q42, Q44, Q47 and Q49–Q52** as proposed, since they were not answered. Each is easy to change.

- **Install TRG Prime 3.682.0 first, then this over 0.6.1.** Block 4 needs that version's seams. On anything older the module warns.
- **No migration and no new settings.**

## The Spellblade

- **The class:**
  - Martial; HP 10 + Con; 4 + Int skill points. Light armour, simple and martial weapons. Class wealth 2.
  - The printed table: BAB/BDB = level; Fort and Will 5 + level; Ref 2 + level; CL ⌈level ÷ 2⌉; PP = level; BSB ⌊level ÷ 2⌋.
  - **Transcend Armour** and a class feat at 1st, then a class feat at 5th and every 5.
- **Spellblade Path** (Use): choose the Arcane Duellist (Intelligence, Arcane), the Divine Arm (Wisdom, Divinity), the Ethereal Strider (Charisma, Ethereal) or the Verdant Warden (Constitution, Verdant). The path sets:
  - your magical ability and tradition (Spellcraft, the PP's static bonus, your book);
  - two class skills;
  - its special ability and its path spell, a specialist spell that is always ready.
- **The Book of Infusions** is the core's spell book:
  - four PP 2 spells of your tradition at 1st, then one a level that you can cast;
  - you memorise **level + 1** each day (TRG Prime 3.682.0's `memorisedPerDay`);
  - no cantrips.
- **Battle Mage:** a spell attack with the Attack trait uses your BAB in place of your BSB when that is higher. The casting check is untouched.
- **Infuse Weapon:**
  - **At each daily preparation** you are asked which melee weapon you infuse (or use Infuse Weapon's Use). For the day, it is magical for overcoming resistances and DR while you wield it (Q44).
  - **From 2nd level,** you also choose runes from your book, their total level no more than your level (M14). They work only on your own Strikes, outside the weapon's allowance and potency rule (Q45).
  - **Learn a rune** (Use): a weapon rune and tier, learned as a spell is (Q46). It takes the rune's level as the PP for Learn a Spell's hours, price and DC, and a check with your tradition's skill.
    - The materials must be in hand.
    - A Success or better writes it into your book.
    - The materials consumed are Learn a Spell's for that degree: all on a Success, half on a Critical, none on a Partial or Failure.
    - Runes that take a parameter (Aligned, Bane, Energy Resistance) and Spell Effect are not offered.
- **The four special abilities:**
  - **Arcane Echo (Focus):** after any spell cast successfully (cantrips too), your next melee attack before the start of your next turn has +1 circumstance to the attack and +1 to its damage (Q50). It is spent on that attack, hit or miss.
  - **Sacred Channel (Focus):** on a weapon hit, you are asked whether to spend 1 PP and the use to heal 1d8 (+1d8 at 5th and every 5).
  - **Dimensional Step (Focus, 1 AP):** click where you teleport, up to 10 ft per 2 levels, at least 10 (Q51). No Spatial Awareness check.
  - **Natural Resilience:** poison damage and any damage from a disease are halved (Q43; the core's disease trait on a disease's stage damage, TRG Prime 3.682.0). You also gain +1 maximum HP a level, trued up as you level.
  - Focus abilities have one use each, restored by Refocus or daily preparation (Q36).

## The five Spellblade spells

- **The order (Q47):** the path spells cast first; on a Success or better the Strike is made as part of the spell, at no further AP, counting for the multiple attack penalty as a Strike does.
- **Shooting Star:**
  - With a melee weapon, the Strike reaches any creature within 30 ft.
  - It ignores concealment and steps the target's cover down a degree.
  - On a hit, every ally's attacks against that creature gain the same until the start of your next turn (Q49). The trail ends as your turn starts.
- **Shielding Strike:** a melee Strike, then +2 status DB until the start of your next turn, whatever the Strike did (+1 a warp, max +5).
- **Dimensional Assault:**
  - Click a square within half your land speed and teleport there, then make a 0 AP melee Strike.
  - Spatial Awareness is on its own card, to roll after the attack. The +1 PP option gives +5 to it.
  - Anything you had targeted is set aside for the cast, so the core's Teleportation rule moves you, not them.
- **Thunderous Strike (Q48):**
  - Press Cast and the Strike comes first. Its roll is also your casting check: the same die and modifiers, read against the casting DC.
  - On a Success or better, each creature in the 15-ft cone behind the target (90°, away from you, the target not in it) saves basic Fortitude against 1d6 sonic (+1d6 a warp).
- **Spinning Weapon:** choose the type (force and sonic with the warp). Your next melee Strike this turn deals 1d6 secondary damage of it (+1d6 a warp, max 4d6), as the core's strike rider.

## The Warlock

- **The class:**
  - Adept, Expert; HP 8 + Con; 6 + Int skill points. Light armour, simple weapons. Class wealth 1.
  - The printed table: BAB/BDB ¾ level; every save 2 + level; no CL, PP or BSB.
  - A class feat at 3rd and every 3.
- **No Spellcraft:** every spell is innate with the Focus trait, one use until Refocus or daily preparation (Q37).
  - **Charisma:** innate attack Charisma + level, DC 10 + Charisma + level.
  - **High Magic:** every cast, with nothing about a casting check applying (Q40).
- **Xithra** (granted at 1st):
  - An innate Focus attack, 1d6 + Charisma mental, +1d6 at 4th and every 4 (Q42).
  - Once your soul is chosen, you pick at each use: mental or the soul's type.
- **Bonded Soul** (Use): one of the eight. It sets:
  - two class skills;
  - Xithra's other type;
  - your traditions;
  - its **+1 level** on spells with its traits or school, through the core's innate level bonus. It raises attack, DC, warp budget and PP limit.
- **Your soul's Use:** choose the spells you are owed and your two cantrips, each made an innate Focus copy cast with Charisma.
  - **Spells:** one at 1st and one at 3rd and every 3, from the soul's traditions, base PP up to level + 1 (sidebar 8; one more where the soul's +1 applies).
  - **Cantrips:** any tradition.
- **Hexes** (Use): one hex at 1st, innate and Focus.
  - More come through the core's Specialist Spell feat (M28 withdrawn). A hex taken that way becomes innate and Focus as it lands.
- **The souls' daily powers (Q41):** once a day, reset at daily preparation, you are asked after Xithra.
  - **On a hit:** Blindness (Crystal Archon), Idiocy (Infernal Tempter), Fear (Pale Reaper) or Slow (Verdant Spirit Walker) on the target, or 1d6 recurring fire (Emberlord).
  - **On any use:** Cure on a target within 30 ft (Celestial Sentinel) or Misty Step (Whispered Sage).
  - **How each spell is cast:** at 0 AP, at its base PP, as an innate spell at your level and DC. The innate level limit does not refuse it.
- **Sidebar 16:** the core feats each class gains, for all four of Chapter 3's classes (Block 3 had not done the Archmage's and the Witch's):
  - Spellblade: Assess Target, Combat Awareness, Disrupting Stance.
  - Archmage: Familiar, Versatile Familiar.
  - Warlock and Witch: Familiar, Injury Relief, Versatile Familiar.

## Found in review (independent, before release)

- **Arcane Echo's +1 damage never applied.** The core spends a one-shot row by deleting its whole effect, so the attack took the damage row with it. The rows are not one-shot now, and the effect goes once that melee Strike has resolved. Nor does an item's spell (a scroll) trigger it.
- **Shooting Star's trail could outlive a combat** that ended before your next turn. It has a two-round world-clock backstop now.
- **Learn a rune charged the full price whatever the check.** It charges Learn a Spell's for the degree now.
- **The Whispered Sage's Misty Step treated Xithra's target as the one teleported.** It is cast with nothing targeted now.
- **Thunderous Strike: a cast cancelled after its Strike** left a free Strike. The Strike now costs 1 AP, as a Strike, and there is no Strike at all without the PP to cast it.
- **Minor:** an empty spell list no longer stops the Warlock's cantrip picks. The Xithra and hex updates run on one client.
- **For Graham:** the Wild birthright's daily random specialist spell (Q24, "any class") can now roll one of the Spellblade's five, which want a wielded weapon.

## Not automated, and said on the cards

- **The Celestial Sentinel's good damage** is the core's aligned type, and its +1 counts any Aligned spell. The alignment is not read.
- **The Verdant Spirit Walker's +1** counts spells with the Animal or Plant trait. Others that "directly affect" animals or plants are the GM's call.
- **Dimensional Assault's square** "within reach of a creature" is not checked.
- **Thunderous Strike's 5d6 and Spinning Weapon's 4d6 maxima** are printed. The warp chooser does not stop you buying past them.
- **Nyrrin Warlocks** (sidebar 9) is description.
- **Infuse Weapon's Use** can re-infuse at any time; the book says daily preparation, and the card says so.
- **Shadowed Grimoire, the Warlock's PP (C2/Q52), the class feats and the archetypes** are Block 6.

## Harness

- **New pair: `verify-block4` (103 checks) and `mutate-block4` (81 mutations, all caught).**
  - The classes and tables row by row against the book; the paths and souls; the five spells and Xithra.
  - Every rule run: budgets, dice, feet, picks, copies, the cone, riders.
  - Registration.
  - The core run with the content: the L + 1 budget, the soul's +1 at the innate cast, the edges, the rider, the conditionals, the warps, the damage choice, an innate Focus copy, Natural Resilience's halving and its HP.
  - The Foundry side with fakes.
- **`verify-block1`, `2`, `2b`, `3` and `3b`:** green on TRG Prime 3.682.0. Their registration checks now read their own block's slice, and their version checks are "or later". The mutation version pins moved to 0.7.0 and 3.682.0.
- **`extract-book.mjs`** now cuts the Spellblade and the Warlock, and reads their trait lines (Focus Invocation, Attack Focus Magical Mental). The other three classes' text is unchanged byte for byte.
