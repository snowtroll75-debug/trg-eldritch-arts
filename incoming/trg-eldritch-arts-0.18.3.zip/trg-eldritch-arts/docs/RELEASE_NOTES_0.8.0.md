# Eldritch Arts 0.8.0

4 November 2026. **Block 5:** Chapter 5's 74 racial feats and 43 general feats. Nine general feats came with earlier blocks, so 108 are new. Built from `ELDRITCH_ARTS_BLOCK5_AUDIT.md`, as Graham answered it on 3 November:
- **"As proposed", except Q58 and Q59.**
- **Q58:** an Ascendan suffers Forbidden Magic's penalties against High Magic, "as it combines all magic".
- **Q59:** Unbound removes them.

- **Install TRG Prime 3.683.0 first, then this over 0.7.1.** Block 5 needs that version's seams (C1–C19). On anything older the module warns.
- **No migration and no new settings.**
- **The feats are in "Eldritch Arts: Feats".** Racial feats are offered to their race by the Racial Feat picker, and general feats to everyone.
- **Prerequisites are gated by the core from 3.683.0** (Q57): heritages ("Wyrmdral Heritage"), "Level 1 only", feat chains and the rest.

## How much is automated

A: full · B: automated, with a normal choice or prompt · C: partly, one clause left to the GM and said on the card · D: the item and its card only.

| | A | B | C | D |
|---|---|---|---|---|
| Aetherial and other races (27) | 14 | 10 | 1 | 2 |
| Emberkin and Nyrinn (28) | 11 | 12 | 4 | 1 |
| Scaelyn (19) | 12 | 7 | 0 | 0 |
| General, new (34) | 7 | 14 | 5 | 8 |
| **All 108 new** | **44** | **43** | **10** | **11** |

**The eleven D items:**
- **Catalysts:** the four Catalyst feats wait for Block 9. Their items ship now, so Catalyst Affinity → Mastery is gated.
- **Metamagic:** Resonant Pulse, Resonant Harmony, Echo of the Ancestors and Piercing Insight wait for Block 6's module metamagic (Q66, Q75).
- **Nothing for the system to do:** Mnemonic Grasp (Learn a Spell already takes any source), Spell Feedback (the cast card already shows each save) and Spell Transcription (Create doesn't gate on the spell). Their cards say so.

## The racial feats

- **Aetherial (18):**
  - **Concord:** an ally's +2 after you cast.
  - **Scholar.**
  - **Astral Crossing:** incorporeal; you pass occupied squares (C18).
  - **Astral Drift:** magical terrain eased (C16), and a free Step after 3 AP of movement (C17).
  - **Astral Step:** 1 AP, Q62.
  - **Chronal Awareness:** +20 initiative.
  - **Chronal Echo:** the attacker rerolls.
  - **Radiant Presence and Bulwark:** your light and its aura.
  - **Resonant Ascendance:** a reaction Dispel at half the PP (Q63, C9).
  - **Skyborne Agility:** +2 DB after 15 ft of movement.
  - **Skyborne Waltz and Veil of Dusk:** Feather Fall and Darkness, innate.
  - **Starseer's Intuition and Sight.**
  - **Veil of Silence:** +2 Stealth and Reflex in light 5 or less (C4, Q61).
  - **Resonant Pulse and Harmony:** Block 6.
- **Other races (9):**
  - **Ancestral Reverie** (Elf): a daily skill.
  - **Endless Adaptation** (Human): Q65.
  - **Feyblood Glamour** (Gnome).
  - **Moonlight Precision** (Elf): light 5–6.
  - **Quiliesh:** a Human Heritage (Q60), which opens the Ascendan feats.
  - **Relentless Will** (Human): no fatigue from the day's first Dying (C8).
  - **Shadow's Discipline** (Kornargon): its Hide clause is a card.
  - **Unbound** (Ascendan): Q59.
  - **Veil of Honour** (Kornargon): Shadow Stance as a reaction (C19), and Daze.
- **Emberkin (14):**
  - **Elemental Apotheosis:** a minute of immunity, and +1 a die.
  - **Elemental Bulwark and Elemental Reprisal:** offered when the heritage's element hurts you.
  - **Elemental Step:** a teleport.
  - **Emberborn Fury:** +1 a fire die (C6, Q70).
  - **Ember Eyed:** Darkvision, Level 1 only.
  - **The two Scholars.**
  - **Mantle of Essence:** DB after a cast.
  - **Stonebound Bastion.**
  - **Stormrunner's Zeal:** flight after electricity damage, and a fall if it ends aloft (C5).
  - **Tideweaver's Resilience:** +1 underwater, and the daily 0 HP guard at level + Wisdom (C7, Q71).
  - **Vein of Power:** a Spell Adder that grows with level.
  - **Echo of the Ancestors:** Block 6.
- **Nyrinn (14):**
  - **Anchor in Nothing:** a Will save declared a Success (C2).
  - **Crystal Pulse:** Q69.
  - **Eclipsed Form:** Q68, the printed effects only.
  - **Mindshroud:** a reroll.
  - **Night's Embrace:** Invisibility.
  - **Nyrinn Scholar:** Q74.
  - **Shadow Initiate:** speed in the dark.
  - **Silent Veil:** Null Aura +5 ft.
  - **Threadbreaker's Precision:** +2 on Dispels, and a countered caster is Dazed (Q67, C9).
  - **Veilstride:** Q72.
  - **Voidborn Wings and Voidborn Grace:** flight, and the glide.
  - **Voidbound Resolve:** +2 and a backlash (Q73).
  - **Whispers of the Void:** Fear.
- **Scaelyn (19):**
  - **Alchemical Purifier:** at 5th, Q76.
  - **Ancestral Awakening:** an element for a minute.
  - **Claws of the Wyrm:** the core's sized Claws.
  - **Desert Wraith and Sandstrider:** as printed, Q78.
  - **Draconic Immunity and Draconic Wings.**
  - **Elemental Breath:** the heritage's element, Q77.
  - **Ember Handed.**
  - **Ghostscale:** concealment in the dark, broken by attacking or casting.
  - **Glyph Unleashed:** +2 to saves and DB against a spell, areas included (Q80, C2, C3).
  - **Pyrotechnic Flair and Silence Unbound:** Burning Hands and Silence.
  - **Runic Aptitude:** a Spellcraft cantrip, Q79.
  - **The Scholars and Wyrm's Cunning.**
  - **Scaled Focus:** +1 PP a level.
  - **Scaled Trickster.**
  - **Sludge Blooded.**

## The general feats (34 new)

- **Rituals:**
  - **Archsage Command:** a seat on top.
  - **Rune-Binder's Precision:** counts as two; it doesn't stack with Ritual Expert (Q82).
  - **Lorekeeper's Insight:** +2 class on the ritual check.
  - **Circle Adept.**
- **Dispel** (C9, Q84, Q85):
  - **Dispel Power:** no PP, caster level as the value, Very Hard, its own ladder.
  - **Mirrored Rebuke:** offered only on Counter Spell's Dispel; a Success reflects the spell, cast from you with no check and no PP.
  - **Threadcutter:** its tradition-skill Dispel.
- **Ley lines:**
  - **Ley Channeler:** +1d4 or 2d4 PP, and a daily reroll of a Failure or Fumble (Q83).
  - **Ley Scholar.**
  - **Channel Siphoner:** Partial read as Success (C10).
  - **Essence Reservoir.**
- **Casting:**
  - **Masked Caster:** Spell Trickery at +1.
  - **Runic Stabiliser:** 1 AP on a High Magic cast (C14).
  - **Silent Spellstrike:** Sniping on a spell critical (C15, Q86).
  - **Spell Thief:** a free prepared copy (C13).
  - **Master Binder:** control levels +2 (C12).
- **Insight:**
  - **Esoteric Insight Expert.**
  - **Esoteric Insight Master:** the unlimited reroll (Q81).
  - **Magic Sense.**
  - **Magus Appraiser:** Appraise Magic's own time ladder.
  - **Hypnotic Savant.**
  - **Runespeaker.**
- **Travel:**
  - **Wanderer's Sense.**
  - **Wanderer's Mastery.**
  - **Rapid Binder:** Quickbind's own ladder.
  - **Spirit Resources.**
- **Items with cards only:** Catalyst ×4 (Block 9), Piercing Insight (Block 6), Mnemonic Grasp, Spell Feedback, Spell Transcription.

## Changed in earlier blocks

- **Esoteric Insight** (0.1.0): its advantage on Spell Recognition never reached the roll. Now it does, through the roll's new action key (TRG Prime 3.683.0, C11).
- **Null Aura** (0.1.0) adds any feat's `eaNullAuraBonus` (Silent Veil's +5 ft).
- **Disrupting Magic** (0.6.0) names the caster and the spell to its Dispel. So a Dispel modifier (Threadbreaker's Precision) can reach the caster.
- **Block 2's Tap Magical Energy reads the upgraded degree** (C10), so Channel Siphoner's Success is what is paid.
- **Battle Mage's card** says it covers the maneuver spells (Q53, TRG Prime 3.682.2).

## Not automated, and said on the cards

- **Shadow's Discipline's Hide from Lesser Cover:** the core refuses that Hide, and nothing lets a feat lift it.
- **Spell Thief's scroll and magical-text lenders:** Borrow Spell lists spellbooks only.
- **Channel Siphoner's half damage on a Fumble:** needs a change to Block 2's Tap resolver.
- **Runespeaker's rank reduction:** a scroll's reading path is not told who reads it. Its heightening is the GM's.
- **Eclipsed Form against magical ammunition or a declared magical attack:** the core tells a damage reaction "non-magical" for weapon blows. It judges magic by the attacker's wielded weapon.
- **The GM's clauses on the C feats:**
  - Night's Embrace: no tracks or scent.
  - Silent Veil: hiding while observed.
  - Voidborn Grace: other interruptions of the glide.
  - Magic Sense: its secret check.
  - Wanderer's Mastery: its immunity and die floor.
- **A Critical reached by a reroll:** Archsage Command and Esoteric Insight Master don't see it, because the core asks no after-reaction once a check is rerolled. The GM grants it.

## Found in review (independent, before release)

- **Voidborn Grace's glide never came down, and Voidborn Wings' turn count didn't run, for a connected player's character.** The turn-end hook acted for the owner, but it fires only on the GM's client. It runs on the acting GM now.
- **Voidbound Resolve's backlash was lost** when Mindshroud rerolled the save and the +2 made the reroll succeed. The reroll's result is judged now.
- **Mirrored Rebuke was offered on every counter** (Disrupting Magic's, Resonant Ascendance's). It is offered only on Counter Spell's own Dispel now. A reactor already asked by Disrupting Magic isn't asked again.
- **Resonant Ascendance:**
  - It discarded a rolled Dispel if the reaction couldn't then be spent; the result stands now.
  - Its Dispel now names the caster.
- **Vein of Power didn't follow a level gained through XP.** It does now.
- **Found in integration:**
  - Feat names keep small words in lower case, as the core's feats are named ("Claws of the Wyrm").
  - Silent Veil's +5 ft reaches the Null Aura.

## For Graham

- **Q58's reach** (TRG Prime 3.683.0): an Ascendan without Unbound makes the Will save against its own beneficial High Magic spell cast on itself.
- **The per-die bonus counts a critical's extra dice.**
- **Charismatic Caster** ("Level 1 only", a core feat) is now gated by the core.

## Harness

| Harness | Checks | Mutations caught |
|---|---|---|
| `verify-block5a` (Aetherial, other races) | 295 | 99 of 99 |
| `verify-block5b` (Emberkin, Nyrinn) | 251 | 120 of 120 |
| `verify-block5c` (Scaelyn) | 135 | 86 of 86 |
| `verify-block5d` (general) | 349 | 98 of 98 |
| `verify-block1` | 884 | 86 of 86 |
| `verify-block2` | 131 | 75 of 75 |
| `verify-block2b` | 91 | 81 of 81 |
| `verify-block3` | 302 | 83 of 83 |
| `verify-block3b` | 87 | 83 of 83 |
| `verify-block4` | 108 | 86 of 86 |

- **Each feat is checked against the book:** name, race, traits, prerequisites and uses. Every rule is run with fakes, including the core's own reaction and dispel code where it can be imported.
- **The earlier blocks' registration checks** now read their own blocks' slice, as Block 4's did. `verify-block4`'s version check is "or later".
- **One Block 2b mutation retired:** "Spell Trickery is not registered". Masked Caster re-registers that key, wrapping Block 2b's option, so Block 2b's line alone can't remove it. A replacement checks that Block 2b registers it under its own key.
