## Part A — Chapters 1 to 7 (races to summoning circles)

### Critical

#### EA-C1 — Nyrinn Null Aura: the save to benefit from allied spells has no type or DC
- **Where:** Nyrinn, Null Aura (L255).
- **Printed:** "Your aura also disrupts beneficial spells cast upon you by other casters, and you must make a successful saving throw to benefit from them"
- **Problem:** No saving throw type or DC. The sentence also lacks its full stop.
- **Core:** Core spells use the caster's Save DC. A beneficial spell has no reason to carry one, and the target would normally want to fail it.
- **Proposed:** Specify the save (e.g. "a Will save against the caster's Spell Save DC; on a failure the spell has no effect on you").
- **Interim build:** The aura's other two clauses ship (class bonus to saves and DB against magical effects; Spellcraft DC raised by the same amount within the aura). The beneficial-spell clause is posted as a reminder card for the GM.

#### EA-C2 — Warlock feats that spend PP the Warlock does not have
- **Where:**
  - Warlock's Hex (L4264): "you may spend 1 PP to mark them". Its only class trait is WARLOCK.
  - Pact Channeler (L3892): "you may spend +1 PP". Traits WARLOCK WITCH.
  - Grasping Shadows' "spend 1 PP" is fine for a Sorcerer.
- **Problem:** The Warlock text says "you do not possess a pool of PP" (L1450). A Warlock can never pay the cost, so Warlock's Hex is unusable by the only class it is for, and Pact Channeler is Witch-only in practice.
- **Proposed:** Graham picks one of:
  - (a) for a Warlock, the cost is paid by expending the spell's Focus use (or one Xithra use);
  - (b) the Warlock gains a small PP pool for these feats;
  - (c) the feats drop the PP cost for Warlocks.
- **Interim build:** Witch paths of Pact Channeler ship. The Warlock paths of both feats wait.

#### EA-C3 — Tap Magical Energy has no DC
- **Where:** Ch4 Power Manipulation, Tap Magical Energy (L2046).
- **Problem:** Every other action prints its DC basis; this one has none. The degree ladder cannot be resolved. The second "Fumble" (L2066) is evidently Blunder.
- **Core:** Core charged items have a level (Rod, Staff and Wand formulas). A level-based DC is the natural basis.
- **Proposed:** "a check against the item's level-based DC" (the same basis as Channel Ley Line), with the second Fumble read as Blunder.
- **Interim build:** Built with the item's level DC, flagged in the card until ruled.

### Major

#### EA-M1 — Arcanum and Dragon birthright spell tables print half the PP
- **Where:** L875 and L922: "Spells (weave)", with values 0 to 8.
- **Problem:** Every listed core spell's PP is exactly double the printed number:
  - Magic Missile 2 (printed 1)
  - Eldritch Shield 4 (2)
  - Eldritch Bolt 6 (3)
  - Dimension Door 8 (4)
  - Eldritch Ball 10 (5)
  - Eldritch Disruption 12 (6)
  - Magesword 14 (7)
  - Shield 2 (1)
  - Resist Energy 4 (2)
  - Haste 6 (3)
  - Spell Immunity 8 (4)
  - Elemental Shield 10 (5)
  - Visage of Horror 14 (7)
  - Scintillating Pattern 16 (8)

  The other five birthrights print PP 0, 2, 4, …, 16.
- **Core:** Spell PP from the core spells pack.
- **Proposed:** Head both tables "Spells (PP)" and double the values. The intent is clear from the level progression.
- **Interim build:** Granted by name; the PP comes from the spell itself, so nothing depends on the printed number.

#### EA-M2 — Out-of-date spell names in birthright and pact grants
- **Problem:** Several grants use names that do not match the core spells:
  - "Wyrm Form" (Dragon, L929) = core Shape of the Wyrm (PP 12).
  - "Eternal Form" (Eternity, L970) = Shape of the Eternal (PP 12).
  - "Elemental Form" (Storm, L1055) = Shape of the Elemental (PP 10).
  - "Shape of the Dragon" (Pact Ascendant, L3848) = Shape of the Wyrm.
  - "Neutralize Poison" (Alchemical Purifier, L2158) = Neutralise Poison.
  - "timestop" (Wild Surge 97–98, L5794) = Time Stop.
  - "Self-Healing" (Wild Surge 03–05) = Self Healing.
  - "Stormbolt" (Stormcaller, L3190) = the birthright's Storm Bolt.
- **Additional problems:**
  - Eternity's "Shield of Faith (4)" (L966): the core spell is PP 2.
  - "Dragon Wings" (Pact Boon, L3872) is not in the core. It is listed in Part B if the Grimoire has it.
  - Celestial Sentinel's "innate cure spell" (L1496) names no spell.
- **Proposed:** Use the core names. Confirm Shield of Faith's level slot and name the cure spell (e.g. Self Healing or a Divinity healing spell).
- **Interim build:** Grants use the core names.

#### EA-M3 — Archetypes with no progression requirement block every later archetype
- **Where:**
  - Eternal Vigil: "cannot progress" (L3000).
  - Runebreaker (L3112), Shade Master (L3124) and Stormcaller (L3182): no Progression Requirements line.
- **Problem:** Core rule (Ch5, repeated at L2894): "you must complete its progression requirements before you can select another." These four never complete, so a character who takes one can never take a second archetype.
- **Core:** `archetype-progression.mjs` fails open on an unparseable line but has no "cannot progress" case. Graham ruled the Pillars of Faith Priestly Path progression waived (7 Oct).
- **Proposed:** Either print requirements (e.g. "Birthright skill +10 ranks", matching High Mage) or rule that these archetypes are complete on selection.
- **Interim build:** Treated as never complete, as printed. The picker explains why another archetype is refused.

#### EA-M4 — High Magic here differs from the High Magic the system already has
- **Where:** Ch7, High Magic casting (L5590–5625).
- **What the book says:**
  - A Spellcraft check at Hard (+2 DC).
  - Fumble/Blunder auto-fail and roll top open-ended d100 +60, +5 per PP, +20 on a blunder.
  - Resonance rolled with disadvantage.
  - Armour DR ×4.
  - No focus unless Arcanum or Archmage.
  - No tradition or school.
- **Core:** `module/magic/high-magic.mjs`, from Fiends & Fables p4 (your ruling R12, 11 Oct), reads the creature guideline "All casting DCs are increased by 2" (Fiends & Fables text, quoted in that file) as a **spell save DC** +2. It also gives free Heighten and a Spell Fumble +50 on top of the usual modifiers.
- **Problems:**
  - (a) Both books say "casting DC", and Eldritch Arts spells it out as the Spellcraft check. The core's save-DC reading may be a misreading of the F&F line.
  - (b) For a PC caster, Eldritch Arts adds no save DC step and no free Heighten.
  - (c) The fumble modifier is +60 here and +50 there.
  - (d) Eldritch Arts' table lists only High Magic, PP and blunder. It is unclear whether the core tradition and ritual fumble modifiers still apply.
- **Proposed:** One ruling covering both books. The two options are:
  - **(i)** PC High Magic follows Eldritch Arts (casting DC +2, fumble +60, no save step, no free Heighten), and F&F creature High Magic stays as built.
  - **(ii)** The core's creature reading is corrected to casting DC +2.

  Also confirm whether the High Magic fumble table replaces or adds to the tradition modifier.
- **Interim build:** Not built until ruled. This is a core change (D1).

#### EA-M5 — Ley line DCs: Chapter 4 says the GM sets them; Chapter 7 tabulates them
- **Where:** Ley Sense (L1814) says "The DC of the check is set by the GM". Ch7 (L5655) gives Sense DCs 30/25/20/18/15 by ley line level. Channel and Tap use a "DC check based upon the ley lines level" (L2010, L2034) while naming bands (Minor to Legendary) rather than levels.
- **Problem:** Three different DC bases. Is the Ch7 table the default, which the GM may override? Is Tap/Channel the level-based DC for the line's numeric level?
- **Proposed:**
  - Ley Sense: the Ch7 table by default, GM may adjust.
  - Tap and Channel: level-based DC for the ley line's level, plus the printed difficulty.
  - Channel's PP bands map Minor 1–4, Lesser 5–8, Greater 9–12, Prime 13–16, Legendary 17+.
- **Interim build:** As proposed. Ley lines are scene regions carrying a level.

#### EA-M6 — Ley Line Effects: when and for how long
- **Where:** Ch7 Ley Line Effects table (L5683).
- **Problem:** Tap Ley Line grants "its benefits" until the end of this turn or the next. Ch7 says a d100 is rolled "when a creature successfully taps into a ley line", with an Effect or a Backlash. It is not said:
  - which column a successful tap uses (Effect) versus a Fumble (Backlash);
  - how long effects such as "All spells gain the extend spell metamagic feat" last (until the tap's benefit ends?);
  - whether Channel Ley Line's Heroic/Critical "benefits" also roll on this table.
- **Proposed:**
  - Success or better: roll the Effect column, lasting as long as the tap's benefit.
  - Tap's Fumble: roll the Backlash column.
  - Channel's Heroic/Critical: the same as a Tap.
  - "Next spell" effects end with the benefit if unused.
- **Interim build:** As proposed.

#### EA-M7 — Wild Surge damage and radius undefined on several rows
- **Where:** Wild Surge table (L5760).
- **Problems:**
  - Rows 48–52 and 53–57 deal "mental damage (basic Will)" with no amount.
  - Row 02 and others use "the radius" without saying it is the area-level range.
  - Row 71–74 ends "for." with no duration.
  - Row 12–15 is garbled ("of you're the areas level").
  - The Wild Mage text (L5758) calls the Wild birthright a "bloodline" and its trigger "UM 13" (unmodified 13 on the d20).
- **Proposed:** Rows apply the scaling rules: damage 1d8 × area level; radius 5 ft × area level; duration 1 round × area level.
- **Interim build:** As proposed.

#### EA-M8 — Magic Suppression: the backlash table has no trigger; level 20 is in two bands
- **Where:** L5826–5852.
- **Problems:**
  - "Some areas also apply suppression backlash", but when the table is rolled (each cast? each failure?) is not stated.
  - Levels "16-20" are dead zones and "20+" are antimagic, so level 20 is both.
- **Proposed:**
  - Areas flagged "backlash" roll the table whenever a casting check in them fails.
  - Dead zones are 16–19; antimagic is 20+.
- **Interim build:** As proposed. The scene region carries a "backlash" switch.

#### EA-M9 — Summoning circle: blood sacrifice modifier sign
- **Where:** L5975.
- **Printed:** "Circle inscribed with blood sacrifice (animal = +2, intelligent = +4, ethically damning) | varies".
- **Problem:** The table is a DC modifier, where a plus makes the circle harder. A sacrifice should make it easier, like the other favourable rows (−2, −4, −5).
- **Proposed:** −2 (animal) and −4 (intelligent).
- **Interim build:** −2 and −4, flagged.

#### EA-M10 — Catalysts: Dragonbone Dust
- **Where:** L5312 and L5497.
- **Problems:**
  - (a) "+1 damage die per PP of the spell" is far stronger than every other damage catalyst. Cinders adds one step; Glimmercoal adds 1d6 per 2 PP. It is also cheap (75 gp, level 1).
  - (b) Its backlash fires only "On a fumble or blunder", contradicting the general rule (L5232: Failure, Fumble or Blunder).
- **Proposed:** Confirm both. For (a) a likely intent is "+1 damage die" or "+1 die per 2 PP".
- **Interim build:** As printed for (a). For (b), the entry's own text wins (specific over general), flagged.

#### EA-M11 — Racial ability of Elemental Breath: "per level" costs and redundant clause
- **Where:** L2340–2342.
- **Problems:**
  - 1d6 per level of damage for 1 PP per level makes a 10th-level Wyrmdral pay 10 PP for 10d6. The cost scales with the PC's level, not with a chosen amount. Is the PP spent chosen ("up to 1 PP per level")?
  - "Be aware that if you have the Wyrmdral heritage, you must select your elemental type" repeats the prerequisite.
- **Proposed:** "Spend up to 1 PP per level; the breath deals 1d6 per PP spent". Otherwise confirm as printed.
- **Interim build:** As printed (full level), flagged.

#### EA-M12 — Tideweaver's Resilience: the trigger does not match the effects
- **Where:** L2752.
- **Printed:** "Action 0 AP: Trigger you take cold damage". The effects, however, are a constant +1 when submerged and a 1/day heal "when reduced to less than 0 HP".
- **Proposed:** Drop the cold trigger, or state what it does.
- **Interim build:** The two printed effects ship. The cold trigger is ignored, flagged.

#### EA-M13 — Spellblade: "arcane" spells for every path
- **Where:** L1240.
- **Printed:** "Each time you gain a level you automatically add one new arcane spell to your book of infusions."
- **Problem:** The Spellblade Path may be Divinity, Ethereal or Verdant.
- **Proposed:** "one new spell of your tradition".
- **Interim build:** As proposed.

#### EA-M14 — Spellblade rune limit: Spellblade level or character level?
- **Where:** Infuse Weapon (L1218): "may not exceed your Spellblade level". Runeblade (L3100): "equal in total levels to your character level".
- **Proposed:** Spellblade level (the class ability governs).
- **Interim build:** Spellblade level.

#### EA-M15 — Witch table gives a bonus feat at 1st the text does not
- **Where:** Witch table (L1751) shows 1 at 1st. The text (L1718) says "At 5th level and then every 5 levels thereafter". The Spellblade's table also shows 1 at 1st, but its text grants one ("any one class feat"). The Archmage's table shows 0.
- **Proposed:** Witch table 0 at 1st (1, 2, 3, 4 from 5th), or confirm the extra pick.
- **Interim build:** The text governs.

#### EA-M16 — Archmage memorises level × 2; the core learned budget is 2 + 2 × level
- **Where:** L689.
- **Printed:** "an amount of spells … equal to your level x2".
- **Core:** `memorisation.mjs` budget is 2 + 2·L (Cleric, Druid, Wizard). Spellblade is level + 1 (L1238).
- **Problem:** The book prints its own counts, so this is consistent with the text. It is noted because both need a per-class budget in the core (D4).
- **Interim build:** As printed.

#### EA-M17 — Classes' feat trait "Warrior" versus class type Martial
- **Where:** Spellblade bonus feats (L1230): "(Spellblade or Warrior)". The Ch5 class-feat intro (L3210) says "(Adept, Expert or Warrior)".
- **Core:** The same intro sentence appears in the core (L8380). Class types are Adept, Expert and Martial (core L2424). "Warrior" is also a core archetype.
- **Proposed:** "Martial". Confirm that a Spellblade may take Martial-trait class feats with its bonus picks.
- **Interim build:** Read as Martial.

#### EA-M18 — Catalysts and the spell attack: "a basic saving throw of a type appropriate to the spell cast"
- **Where:** L5226.
- **Printed:** "Any damage effects caused by catalysts require a basic saving throw of a type appropriate to the spell cast."
- **Problem:** Attack spells have no save. Does a catalyst's extra damage on an attack spell ride the attack (hit and degree), or force a separate basic save?
- **Proposed:**
  - Attack spells: the extra damage rides the attack.
  - Save spells: it uses the spell's save.
  - Other spells: basic Reflex.
- **Interim build:** As proposed.

#### EA-M19 — Unused Magic Discovery and the High Magic archetype set
- **Where:** Warlock (L1456): "cannot take the Magic Discovery feat from the CRB". Ch7 (L5576): "Members of other classes can only learn high magic spells by selecting a High Magic Archetype feat."
- **Problem:**
  - Magic Discovery is not in the core.
  - "High Magic Archetype feat" is not a defined set. Hex Weaver, High Mage and Birthrager each grant High Magic spells.
- **Proposed:**
  - Remove the Magic Discovery sentence, or name the core feat meant.
  - Define the set as Birthrager, Hex Weaver and High Mage.
- **Interim build:** The set as proposed.

#### EA-M20 — Spell Surge prerequisite and "disadvantage" on d100 tables
- **Where:** Spell Surge (L4630), High Magic Resonance (L5621), Ley Line Effects 66 and Wild Mage.
- **Problems:**
  - "Prerequisites High Magic Caster" is not a defined status. Read it as: a class whose spells are High Magic, or the High Magic archetype set.
  - Disadvantage on the Spell Fumble or Resonance d100 means "roll twice, take the higher (worse)". This is stated for Resonance (L5623) but not for Spell Surge's fumble roll.
- **Proposed:** As stated.
- **Interim build:** As proposed.

#### EA-M21 — Ritual Expert and Rune-Binder's Precision give the same benefit
- **Where:** L4574 and L4582.
- **Printed:** Both: "you count as two casters instead of one" / "you are always considered to be two casters".
- **Problem:** Do they stack (three casters)? Archsage Command (whose prerequisite is Rune-Binder's Precision) adds "an additional caster beyond those present".
- **Proposed:** They do not stack (two at most from either). Archsage Command adds one more.
- **Interim build:** As proposed.

#### EA-M22 — Racial Null Aura and Zhal-vryn affect the Nyrinn's own allies' casting with no exemption
- **Where:** L255 and L279.
- **Problem:** "all Spellcraft checks made within this aura (including your own) have their casting DC increased", and Zhal-vryn makes "All creatures within your Null Aura" pay +1 PP. That includes allies, with no way to suppress the aura.
- **Proposed:** Confirm. Many races would let the aura be suppressed as a free action.
- **Interim build:** As printed: an always-on 5 ft aura. The casting gate applies to every caster in it.

#### EA-M23 — Birthrager: "low PP and a low spellcraft bonus" are not defined
- **Where:** Birthrager archetype (L2914); BERSERKER trait (Appendix, L10675).
- **Printed:** "You become an instinctive caster and gain a caster level equal to half your level (round up), low PP and a low spellcraft bonus."
- **Problem:** Neither the core nor Eldritch Arts defines a "low" PP or spellcraft track. Core PP is "Race Bonus + Class Bonus + Other Modifiers" (Core L930), and BSB comes from each class table's own column. Without a table, a Birthrager's PP and BSB at each level cannot be set. The archetype is reachable: the BERSERKER trait requires the Frenzy feat (core Martial, Invoke/Revoke Rage). The flavour text says "bloodragers" and "Like Magi", which do not match the archetype's name.
- **Core:** Core class tables give PP and BSB per level per class. There is no named low tier to borrow.
- **Proposed:** Print the Birthrager's PP and BSB by level, or name a core class whose columns it uses at half rate.
- **Interim build:** These parts ship: the birthright's specialist spell (cast with the innate rules), Sorcerer feat access, and casting while raging. The PP pool and BSB wait for your ruling.

#### EA-M24 — Magic Drain: what the "temporary magical energy" is, and the Vir-ellian "aura"
- **Where:** Sidebar after L253 (Magic Drain); Vir-ellian (L273); Crystal Pulse (L2262).
- **Printed:** "You gain temporary magical energy equal to the drained PP (max your level × 2)." … "The absorbed energy grants you a +1 racial bonus to AB, DB, saving throws or skill checks for 1 minute per PP drained." Vir-ellian: "release the energy … to all creatures within your Magic Drain aura".
- **Problem:** (a) whether the temporary energy can be spent as PP (as Tap Magical Energy's PP can) or only fuels the +1 bonus; (b) which of AB/DB/saves/skills the +1 goes to (a choice?); (c) Magic Drain is a 30-ft targeted action, not an aura, so "within your Magic Drain aura" has no area; (d) Success has no Failure/Fumble rows.
- **Proposed:** (a) the energy is a pool of temporary PP that also grants the bonus while held; (b) the drainer chooses one; (c) "within 30 feet"; (d) Failure and worse: nothing drained.
- **Interim build:** as proposed, flagged.

#### EA-M25 — Leyline Power stacks with Leyline Weaver's own Critical and Ley Channeler
- **Where:** Sidebar after L3088 (Leyline Power); Leyline Weaver replacement ladder (L3082); Ley Channeler (L4470); Confluence Master (L3338).
- **Problem:** on a Critical Tap a Leyline Weaver already "regain[s] 1d8 PP" from the replaced ladder; Leyline Power (a reaction to the same Tap) adds 2d8; Ley Channeler adds 2d4; Confluence Master adds 1d8. Four PP sources from one 1-AP action. Is Leyline Power meant to replace the ladder's 1d8?
- **Proposed:** confirm stacking, or read Leyline Power's PP as the ladder's (one source).
- **Interim build:** stacking as printed, flagged.

#### EA-M26 — Spellstrike is still undefined
- **Where:** Sidebar after L3158 (Spellstrike Riposte): "you may also channel a cantrip through it as if using Spellstrike"; Spellblade's Mark (L4112): "Your Spellstrike against your Mark deals an additional +1d6".
- **Problem:** the riposte itself is now defined, but the Spellstrike it refers to is not printed in v1.4 (body or sidebars) or the core.
- **Proposed:** supply Spellstrike, or define the channel ("the cantrip's effect resolves against the struck target without a casting check").
- **Interim build:** the riposte and the Mark's other benefits ship; the cantrip channel and the Mark's +1d6 wait.

#### EA-M27 — The Appendix's Highmagic trait contradicts Chapter 7 twice
- **Where:** Appendix, HIGHMAGIC (L10677–10689) vs Ch7 High Magic (L5566, L5576).
- **Printed:** Appendix: "Highmagic spells count as belonging to all traditions simultaneously" and "Characters without the High Magic class feature may still attempt to learn and cast Highmagic spells … a skill check against a Very Hard DC (+5)". Ch7: "high magic spells belong to no tradition or school of magic" and "Members of other classes can only learn high magic spells by selecting a High Magic Archetype feat."
- **Problem:** (a) no tradition vs all traditions — opposite answers for tradition gates (Forbidden Magic, armour by tradition), counters "targeting any tradition", and tradition-keyed bonuses; (b) archetype only vs anyone with a Very Hard learning check; (c) "High Magic class feature" is not a named feature (the classes say "you treat all traditions as high magic"). (d) The Very Hard (+5) learning check names no skill (Arcana is the natural reading). The Part E read found the same two contradictions independently; they are recorded here only.
- **Core:** core tradition gates read a spell's `tradition`; an empty tradition passes gates that a tradition list would fail.
- **Proposed:** keep Ch7 for casting by High Magic casters (no tradition: gates, school and tradition bonuses skip), and the Appendix for others (learn at Very Hard, cast at Hard); "counted as all traditions" only for effects that counter or resist by tradition.
- **Interim build:** waits — part of the High Magic ruling (EA-M4, D1).

#### EA-M28 — Hexes: the Warlock gets one, ever
- **Where:** Warlock, Hexes (L1462).
- **Printed:** "At 1st level you may select any one hex for which you meet the requirements."
- **Problem:** There is no progression, unlike the Witch (hex at 1st, 3rd and every three levels, L1736), and no feat grants a Warlock more hexes. Whether this is intended matters to the class's whole design.
- **Proposed:** Confirm one hex only, or give the Witch's schedule.
- **Interim build:** One hex at 1st, as printed.

### Minor (editorial and clarity)

| ID | Where | Printed / issue | Proposed |
|---|---|---|---|
| EA-m1 | L119 | "Racial feats … can be found … in Chapter 6" — they are in Chapter 5 | Chapter 5 |
| EA-m2 | L117, 227, 249, 259 vs 229 onward | Race spelled both "Nyrinn" and "Nyrrin" | One spelling (the trait is NYRINN) |
| EA-m3 | L217, L225 | Galeborne and Tidemarked both print "Dexterity increases by 1, and your Strength decreases by 1" | Confirm Tidemarked (e.g. Wis +1, Str −1) |
| EA-m4 | L165, L173 | Caelari and Umbryth both "resistance to essence damage" | Confirm Umbryth (cold?) |
| EA-m5 | L323 | Glyphweave "an additional bonus cantrip" — one more permanent cantrip, or a second daily pick for Innate Magic? | One more daily pick |
| EA-m6 | L345 | Wyrmdral "+1 … when casting spells of their type" — "type" = damage type of their element | As proposed |
| EA-m7 | L1121, L5756 | Wild birthright: "Wild Surge table (see chapter 6)" — it is Ch7; heading "WILD MAGIC AEAS" | Ch7 |
| EA-m8 | L943, L1027, L1115 | "feint white light" | faint |
| EA-m9 | L1035 | Gale Step "15 meters" (system uses feet); no frequency (FOCUS trait implies once per Refocus) | 50 ft; Focus |
| EA-m10 | L1368 | Dimensional Step: no frequency | Focus default |
| EA-m11 | L1598 vs L1600 | Warlock Bonded Soul heading "THE WHISPERED SAGE"; text "Whispered Shade" (×2) | One name |
| EA-m12 | L1592 | Void Seer has no once-per-day Xithra rider; the other seven do | Confirm |
| EA-m13 | L1500, L1516 … | "treated as one level higher" — for innate spells this is the innate level (DC, warp budget, PP limit) | As proposed |
| EA-m14 | L1854 | Borrow Spell: "the spell slot remains available" — no slots | "the memorisation remains available" |
| EA-m15 | L1984 | Power Manipulation intro lists "Dispel, Recharge Item, Sense Magic and Sigil" as added; the added actions are Quickbind, Channel/Tap Ley Line, Tap Magical Energy | Update list |
| EA-m16 | L1996 | Quickbind Failure: "The is invested" | "The item is invested" |
| EA-m17 | L1926 | Hypnotism unwilling creature "(Indifferent or Better Attitude)" — contradictory label | "(Indifferent or worse)"? |
| EA-m18 | L2074–2082 | Chapter 5 introduction is the Inner Tempest monk/mystic/chi text (Wu Jin) | Replace |
| EA-m19 | L2282 | Draconic Immunity "certain affects" | effects |
| EA-m20 | L2486 | Moonlight Precision "Wen in Dim Light" | When |
| EA-m21 | L2542 | Radiant Presence "Allies with the aura" | within |
| EA-m22 | L2560 | Resonant Ascendance "with 30 feet" | within |
| EA-m23 | L2586 | Runic Aptitude's flavour line duplicates Pyrotechnic Flair's | New line |
| EA-m24 | L2608 | Scaelyn Scholar "+1 … to Arcane & Crafting" | Arcana |
| EA-m25 | L2716 | Stonebound Bastion (Stonevein, earth/acid) carries the ELECTRICITY trait — copied from Stormrunner's Zeal | Drop or EARTH |
| EA-m26 | L2748 | Tideweaver's flavour names "the Thalassyn" | Tidemarked |
| EA-m27 | L2862 | Whispers of the Void "Intimidation" | Intimidate |
| EA-m28 | L2878 | Existing feats list ends with a stray comma | — |
| EA-m29 | L2910 | Birthrager name versus "bloodragers" (see EA-M23) | — |
| EA-m30 | L2980 | Elemental Pact resistance mapping "(air -electricity, earth – acid, fire or water – cold)" | air → electricity, earth → acid, fire → fire, water → cold |
| EA-m31 | L3084–3086 | Leyline Weaver "gaining is benefits" (×2) | its |
| EA-m32 | L3136, L3122 | "costs your 2 PP less" | costs you |
| EA-m33 | L3010 | Fatespinner "grants increases your maximum" | — |
| EA-m34 | L3190 | Stormcaller "Stormbolt" | Storm Bolt |
| EA-m35 | L3434, L3968 | "Spellblades Mark", "Duellists Focus" (heading DUELLISTS FOCUS) | Apostrophes |
| EA-m36 | L3678 | Last Horizon prerequisite "Temporal Retrieve" — the feat is Temporal Reprieve; "do need not to"; "the dying conditions acts" | — |
| EA-m37 | L3396–3404, L900 | Two different "Draconic Claws": birthright ability (1 AP concentrate, 1d6 piercing, BSB optional) and class feat (natural weapon, 1d6 slashing, BSB always) | Rename the feat or align the stats |
| EA-m38 | L3454, L3462, L4306–4322 | Warlock feats call the ability "Xithra Blast"; Xithra Spear says "eldritch blast" | Xithra |
| EA-m39 | L3468, L4294 | Stray backtick at the end of two flavour lines | — |
| EA-m40 | L3502 | Extra Cantrip "an additional casting slot" | additional cantrip memorised |
| EA-m41 | L3540 | Fate's Favour "The first time each day that use … check;" | — |
| EA-m42 | L3588 | Grasping Shadows' ladder has no Fumble row and uses "per 2 Sorcerer levels" | Add Fumble (as Failure) |
| EA-m43 | L3980 | Ritual of Borrowed Power repeats its flavour sentence as rules text | — |
| EA-m44 | L4134–4146 | Spellthread Mastery and Unbound share identical flavour | — |
| EA-m45 | L4156 | Steelbinding "PP Cost +2**; Requirements**" formatting | — |
| EA-m46 | L4200 | Temporal Reprieve "you immediately regain heal yourself of 1d8 HP per PP expended" — no PP cost or cap printed | "spend up to X PP" |
| EA-m47 | L3844–3856 | Pact Ascendant: Fey and Void both "immunity to all effects with the mental trait" | Confirm Void |
| EA-m48 | L3904 | Pact Channeler Grave "essence damage.." | — |
| EA-m49 | L4386 | Dispel Power: "You replace your caster level When making a check in this way replace…" — broken sentence | "When making a check in this way, replace the usual Dispel results with …" |
| EA-m50 | L4334 | Archsage Command "an Arcana or Ritual check" — Ritual is not a skill | Arcana or tradition-skill ritual check |
| EA-m51 | L4376 | Circle Adept prerequisite "Arcane" | Arcana |
| EA-m52 | L4430 | Esoteric Insight Expert "reroll on a critical failure" vs the base feat "when you fumble" | fumble |
| EA-m53 | L4446 | Essence Reservoir "Tap Magical Energies" | Energy |
| EA-m54 | L4566 | Rapid Binder "in 1 round without penalty (instead of –5)" — Quickbind has no time ladder | Clarify |
| EA-m55 | L4590 | Runespeaker "Linguistic ranks" | Linguistics |
| EA-m56 | L4624 | **Withdrawn (28 Oct, Block 1 audit).** Spell Resilience is a core creature ability ("a racial bonus equal to its class bonus to all saving throws and DB against magical attacks", `creature-ability-rules.mjs`). Spell Penetration is buildable; it needs a core hook to lower it (Block 1 C2). | — |
| EA-m57 | L4558 | Piercing Insight "Sense Power (Power Manipulation) actions" — core action name check | — |
| EA-m58 | L4746 | Background wealth table omits Spirit Binder (12 backgrounds, 11 rows) | Add Spirit Binder |
| EA-m59 | L4813 | Bloodwood "+1-item bonus to Spellcasting checks" | Spellcraft |
| EA-m60 | L4835 | Graveiron "Smith's note" | Smiths note |
| EA-m61 | L4857–4869 | Starion is called "star-iron" in its own bullets | One name |
| EA-m62 | L4975 | Claidheamh Dubh's description is the Claíomh Draíochta paragraph (a curved serrated blade; names the other weapon) | New description |
| EA-m63 | L4954 | Bogha Tuama traits "Piercing. Range 120" | Piercing is not a weapon trait; comma |
| EA-m64 | L4934–4955 | Race names used as weapon traits (Emberkin, Wyrmdral, Scaelyn, Aetherial, Nyrrin) with no rule for what they do | Rule: members of that race are trained with the weapon |
| EA-m65 | L5107 vs L5190 | Gilded "Censor" Chains (text) vs "Censer" (table) | Censer |
| EA-m66 | L5127 vs L5195 | Ritual Censer: text "reduces the ritual's DC by 1"; table "+1 to ritual Spellcraft check" | Pick one (the text) |
| EA-m67 | L5115 vs L5192 | Leybraid Rope: text "advantage on Climb checks"; table "… in magical areas" | Pick one |
| EA-m68 | L5161 vs L5205 | Ward Twine / Ward-Twine | One spelling |
| EA-m69 | L5326, L5446 | Catalyst headings "FROZEN MARRROW SHARD", "STORMGLASSS PHIAL" | — |
| EA-m70 | L5344, L5434, L5464 | Glimmercoal "per spell 2 PP"; Spell Incense "foe 1 minute"; Verdant Sap "as the sap their mind" | — |
| EA-m71 | L5274 vs L5493 | Blood-Etched Vellum backlash max 10 in text, not in table | Add to table |
| EA-m72 | L5139, L5147 | Spellbinder's Cord / Twilight Prism "Concentration checks" — the core check is Spell Concentration | — |
| EA-m73 | L5568 | "another spell that effects a specific school" | affects |
| EA-m74 | L5884–5886 | Mundane ritual: the Eligibility paragraph is printed twice | — |
| EA-m75 | L5964 | "SUMMMONING"; "(GM Discretion" missing bracket | — |
| EA-m76 | L5986 | "Invoking a true name during a summoning grants increases the Save DC" | increases |
| EA-m77 | L3880, Pact Boon | "Dragon Wings" spell — see EA-M2 | — |
| EA-m78 | L1442 vs L1478 | Warlock text alternates "Bonded Soul" (ability) and "Bonded Soul" (choice list) — fine; "Pact" archetypes are separate from Bonded Souls, and nothing says whether a Warlock's pact must match its Bonded Soul | Confirm independent |
| EA-m79 | Sidebar after L3146 (Counter Channel) | "Trigger A creature 30 feet casts a spell" (missing "within"); a spell with no Save DC uses which DC?; "The spell double all of its variables" | "within 30 feet"; the caster's Spell Save DC for that PP; "doubles" |
| EA-m80 | Sidebar after L990 (Resist Magic) | Reaction with no frequency (WARDING only, no FOCUS) — usable on every hit while reactions remain | Confirm |
| EA-m81 | Sidebar after L3132 (Fade Step) + Eclipse Step (L3444) | Fade Step has the FOCUS trait (one use per Refocus), but Eclipse Step lets it be used "as a Free action once per round" | Eclipse Step lifts the Focus limit while in shadow, or only changes the action cost |
| EA-m82 | Sidebar after L8937 (Catalyst rune tiers) | Catalyst I–IV print "The penalty is -2/-4/-6/-6" (copied from Binding Sigils), and IV repeats III's level and price; the rune text says the tiers set how many catalysts can be imbedded | Tiers give catalyst count 1/2/3/4; IV level/price |
| EA-m83 | Sidebar after L703 (Ley Line Range) | Ley Tap and Archmage abilities use the Ley Bond range (100 ft per level), while Tap/Channel Ley Line use 30 ft | As printed (the sidebar says ranges differ by class) |
| EA-m79 | Sidebar after L3146 (Counter Channel) | "Trigger A creature 30 feet casts a spell" (missing "within"); a spell with no Save DC uses which DC?; "The spell double all of its variables" | "within 30 feet"; the caster's Spell Save DC for that PP; "doubles" |
| EA-m80 | Sidebar after L990 (Resist Magic) | Reaction with no frequency (WARDING only, no FOCUS) — usable on every hit while reactions remain | Confirm |
| EA-m81 | Sidebar after L3132 (Fade Step) + Eclipse Step (L3444) | Fade Step has the FOCUS trait (one use per Refocus), but Eclipse Step lets it be used "as a Free action once per round" | Eclipse Step lifts the Focus limit while in shadow, or only changes the action cost |
| EA-m82 | Sidebar after L8937 (Catalyst rune tiers) | Catalyst I–IV print "The penalty is -2/-4/-6/-6" (copied from Binding Sigils), and IV repeats III's level and price; the rune text says the tiers set how many catalysts can be imbedded | Tiers give catalyst count 1/2/3/4; IV level/price |
| EA-m83 | Sidebar after L703 (Ley Line Range) | Ley Tap and Archmage abilities use the Ley Bond range (100 ft per level), while Tap/Channel Ley Line use 30 ft | As printed (the sidebar says ranges differ by class) |

### Recommendations (balance and design; not errors)

- **EA-R1:** Eye of the Storm deals 1d6 electricity per character level to every enemy in 30 ft at the start of each turn for 3 rounds, and grants electricity immunity. At 14+ ranks this is 14d6 or more per round. Compare Elemental Exhalation (1d6 per 2 levels).
- **EA-R2:** Catalyst Affinity reduces backlash damage "by 2 per character level". At level 10 that is −20, which negates almost every printed backlash.
- **EA-R3:** Ashen Lotus Bloom (Soul Drain 1 per PP on a failure) and Void Ash (1d4 Soul Drain per 2 PP) are far harsher than the other catalysts' backlashes at similar prices.
- **EA-R4:** Unfettered Mastery quickens every High Magic spell at no PP cost. The core Quicken Spell costs +8 PP.
- **EA-R5:** Absolute Denial: enemy spells of PP 8 or lower simply fail within 20 ft, with no check.
- **EA-R6:** The Ord ua na Tuama (L4943) is level 0, 50 gp, 1d12 B, Mighty +2. That is higher damage than most martial two-handers, while the table gives it no Two-Handed trait.
- **EA-R7:** Vein of Power's spell adder (+1, +1 per 5 levels) stacks with the Witch's familiar adder and Bonded Infusion. Confirm stacking (spell adders from different sources).
