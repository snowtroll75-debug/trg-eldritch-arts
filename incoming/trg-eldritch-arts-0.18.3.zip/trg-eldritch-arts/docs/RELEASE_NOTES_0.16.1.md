# Eldritch Arts 0.16.1: Arcane Mycelium's Region, and Graham's two answers

15 November 2026. **Needs TRG Prime 3.692.0** (unchanged). Found in the live test of 0.16.0. Graham's answers of 15 November 2026: "Go with your recommendation for the 2 questions".

## Found live, and fixed

- **Arcane Mycelium's Region was never found.** TRG Prime names a placed area "<spell> Area", but it renames one that is difficult terrain to "<spell> (difficult terrain)". The module looked only for the first name.
  - So Mycelium's Region was never stamped in play. That lost its +2 PP reactive threads (2d6 essence on a cast inside) and, in 0.16.0, its dim light. The harness built its test Region under the first name, so it never saw this.
  - The module now finds the spell's Region by either name.
  - TRG Prime's own part works. With an `emitsLight` Region in place, a token inside read Dim Light (5) in a Pitch Black scene, 8 in bright light, and 1 in Abyssal Darkness.

## Graham's two answers

1. **Spirit Arrow's Fumble: kept as built.** A Fumble at the attack total lands the action's own fumble on the archer (prone for a Shove or Trip, flat-footed for a Feint). This follows the Tanglefoot ruling that the action's rules come with it.
2. **Runestone Chalkboard and Bloodscribe's Bowl are dropped on a mundane ritual**, as the catalysts are. Each adds to "the primary caster's Spellcraft check". On a ritual rolled with a tradition skill (any of the three variants), they add nothing, and the card says why. A ritual paid in PP keeps their +1.

## The harness

- `verify-block7` 598 checks, `mutate-block7` 236 mutations, all caught.
- `verify-block2b` 98 checks, `mutate-block2b` 91 mutations, all caught.
- Manifest pins raised to 0.16.1 on TRG Prime 3.692.0.
- **All 27 module verifiers** pass on TRG Prime 3.692.0, and **all 26 mutation files** catch every mutation.
