# Eldritch Arts Block 8: audit (Grimoire spells, second half)

8 November 2026. Block 8 is the rest of Chapter 8's Grimoire: the **39 spells** listed in Block 7's audit §3. This audit confirms the count, proposes a split into two releases (8a and 8b), and audits the 39 spells one by one, with one model for each family.

It was read against:
- ***TRG Prime: Eldritch Arts* v1.6** (`/home/claude/ea-src/v16/ea.md`; line numbers below are that file's, and `tools/content/book-text.json` `book.grimoire` carries the same lines);
- **the rules audit, Part B** (`ELDRITCH_ARTS_RULES_AUDIT.md`), **Graham's answers to it** (*Responses to Audit Eldritch Arts*, 1 November 2026, `/home/claude/ea-src/responses/responses.md`, summarised in `ELDRITCH_ARTS_RULINGS_2026-11-01.md`), and his answers Q1–Q166;
- **the Block 2 / 2b audit and code** (`ELDRITCH_ARTS_BLOCK2_AUDIT.md`; `module/block2-automations.mjs`, `module/block2b-automations.mjs`, `module/areas.mjs`, `module/chapter7-tables.mjs`), Block 3a's two Symbols (`tools/content/block3-spells.mjs`), Block 6's Versatile Binder (`module/block6d-automations.mjs`);
- **TRG Prime 3.685.3**, surveyed in its source (`/home/claude/core-3676/trg-prime/module/…`), its rulebook text (`tools/source/rulebook-core-3.7.txt`), and the core pack dumps (`/home/claude/ea-tools/core-dump/`).

**Nothing is built.** Every rule below is quoted from the book or from a ruling. Where the book is silent and the answer would change play, the point is asked in §8 rather than decided here.

**Status: answered.** Graham, 8 November 2026, 17:22: "As recommended". Q167–Q184 are ruled as each row's recommendation below, and seams H12–H18 are approved as proposed, including H17's Remove Curse half and H18 (both change core spells in every world). Block 8a is next: TRG Prime 3.686.0 (H12, H17, H18) and Eldritch Arts 0.11.0.

## 1. The count

### 1.1 39, confirmed

The v1.6 Grimoire was cross-checked by script against every "**NAME PP n**" heading between "# CHAPTER 8 - GRIMOIRE" (L5984) and "SPECIALIST SPELLS" (L8077): **87 headings**, 87 entries in `book.grimoire`, no missing or extra names. Against the 91 documents in `packs-source/ea-spells` (48 Grimoire spells and 43 specialist spells and hexes): **39 Grimoire spells are unbuilt**, and they are exactly the 39 in Block 7 §3. No Grimoire spell outside that list is unbuilt. All 41 specialist spells are built (Blocks 3a and 4).

| | Spells |
|---|---|
| Grimoire, v1.6 | 87 |
| Built (Blocks 1, 3a, 7) | 48 |
| **Block 8** | **39** |
| Proposed **8a** | **22**: the Summons (8), the Symbols (3), exploration and utility (11) |
| Proposed **8b** | **17**: the rituals (10), the High Magic spells tied to Chapter 7 (7) |

### 1.2 The 39

"Matrix" is the target grade in `ELDRITCH_ARTS_IMPLEMENTATION_MATRIX.md` (cut from v1.4); "Grade" is this audit's (§3.2).

| # | Spell | PP | Line | Tradition (as printed) | Family | Matrix | Grade | Sub-block |
|---|---|---|---|---|---|---|---|---|
| 1 | Alter Corpse | 2 | 6058 | High Magic | High Magic | D | D | 8b |
| 2 | Animal Binding | 4 | 6076 | arcane, verdant | Summons | B | B | 8a |
| 3 | Arcane Pouch | 2 | 6194 | arcane | Utility | B | C | 8a |
| 4 | Archway of Ants | 4 | 6214 | verdant | Utility | C | C | 8a |
| 5 | Argent Mark | 2 | 6232 | all | Utility | D | C | 8a |
| 6 | Army of the Grave | 20 | 6290 | arcane, divinity | Ritual | C | B | 8b |
| 7 | Blood Biography | 6 | 6328 | all | Utility | D | C | 8a |
| 8 | Call of the Ancestors | 6 | 6416 | divinity, ethereal | Ritual | D | C | 8b |
| 9 | Chaos Shield | 6 | 6446 | High Magic | High Magic | C | B | 8b |
| 10 | Concord of Stone | 8 | 6486 | verdant | Ritual | C | C | 8b |
| 11 | Elemental Binding | 6 | 6694 | arcane, verdant | Summons | B | B | 8a |
| 12 | Elemental Convergence | 14 | 6720 | arcane, verdant | Ritual | B | B | 8b |
| 13 | Entity Binding | 12 | 6772 | ethereal | Summons | B | B | 8a |
| 14 | Essence Reforging | 14 | 6798 | High Magic | Ritual, High Magic | C | C | 8b |
| 15 | Eternal Binding | 10 | 6818 | divinity | Summons | B | B | 8a |
| 16 | Eternal Invocation | 20 | 6844 | divinity | Ritual | B | B | 8b |
| 17 | Farsight | 8 | 6884 | all | Utility | D | D | 8a |
| 18 | Fey Binding | 6 | 6918 | ethereal, verdant | Summons | B | B | 8a |
| 19 | Harmonic Rift | 12 | 7012 | arcane, ethereal | Utility | B | B | 8a |
| 20 | Leyline Anchor | 10 | 7052 | High Magic | High Magic | C | B | 8b |
| 21 | Mimic Spell | 8 | 7184 | High Magic | High Magic | C | B | 8b |
| 22 | Phase Door | 14 | 7334 | arcane | Utility | D | D | 8a |
| 23 | Plant Binding | 6 | 7388 | verdant | Summons | B | B | 8a |
| 24 | Rippling Gaze | 10 | 7510 | arcane, verdant | Utility | D | D | 8a |
| 25 | Riserune | 2 | 7528 | arcane, divinity, ethereal | Utility | D | C | 8a |
| 26 | Rite of Binding Oath | 6 | 7544 | divinity, ethereal | Ritual | C | B | 8b |
| 27 | Rite of Echoed Shadows | 8 | 7578 | ethereal | Ritual | C | B | 8b |
| 28 | Soul Confluence | 10 | 7662 | High Magic | High Magic | C | B | 8b |
| 29 | Storm of Unmaking | 20 | 7678 | High Magic | High Magic | A | A | 8b |
| 30 | Sun’s Benediction | 4 | 7703 | divinity | Ritual | B | B | 8b |
| 31 | Symbol of Insanity | 16 | 7791 | arcane, divinity | Symbol | C | C | 8a |
| 32 | Symbol of Pain | 12 | 7807 | arcane, divinity | Symbol | C | B | 8a |
| 33 | Symbol of Weakness | 14 | 7831 | arcane, divinity | Symbol | C | B | 8a |
| 34 | Traveller’s Charm | 8 | 7859 | arcane, verdant | Utility | D | D | 8a |
| 35 | Undead Binding | 8 | 7877 | arcane, divinity, ethereal | Summons | B | B | 8a |
| 36 | Veilfracture | 10 | 7903 | High Magic | High Magic | D | C | 8b |
| 37 | Veil Severing | 18 | 7937 | arcane, ethereal | Ritual | D | C | 8b |
| 38 | Wall of Sand | 8 | 7975 | verdant | Utility | C | C | 8a |
| 39 | Wyrm Binding | 12 | 8021 | arcane | Summons | B | B | 8a |

The three Tradition lines that 0.9.x's extractor cut at a bold comma (Call of the Ancestors, Undead Binding, Veil Severing; EA-m127) now read whole in `book-text.json` (fixed in 0.10.0). Every Block 8 Target and Requirement line reaches `fields` (Leyline Anchor, Mimic Spell, Riserune, Soul Confluence, Traveller’s Charm, Rippling Gaze; checked).

### 1.3 Nothing else in the Grimoire; what remains outside it

Nothing else in Chapter 8 is unbuilt. Outside Chapter 8, the book still has these sections unbuilt. None is in Block 8's scope, but the brief asks that none be dropped, so they are listed in full. Each is already in the block plan (`ELDRITCH_ARTS_ARCHITECTURE.md` §4) except the last two.

| Section (v1.6) | What is unbuilt | Where it belongs |
|---|---|---|
| **Chapter 6, Catalysts** (L5208 onward) | The 24 catalysts and the catalyst rules (declared at the cast, one per spell, consumed, backlash on Failure or worse; matrix GEAR-09, CAT-*) | Block 9 (core D2, D3; EA-M10, EA-M18) |
| **Chapter 6, Special materials** | The 10 special materials (Block 1 audit: "They need the module-materials hook (D18) and go with the magic items") | Block 9 |
| **Chapter 9, Magic Items** (L8827–10060) | Armour and shield runes, weapon runes, specific armour and weapons, orbs (D12), rods, staves, wondrous items, charged items (matrix: 16 runes, 5 orbs, 9 rods, 6 staves, 4 specific weapons, 7 tables, 34 rules rows) | Block 9 (Parts C and D rulings: C6 Catalyst rune, M80–M96, m174) |
| **Chapter 9, Relics** (L10061–10691) | The nature and rules of relics, creating relics, the Relic Bonding Ritual, relics and investment, sentience and investment, the specific relics (Veilshroud C8) | Block 10 (Part E rulings; EA-M97, M100, M111) |
| **Appendix, new traits** (L10718–10750) | ORB, RELIC and SENTIENT ("Only one item with the … trait may be invested by you at any one time") | Blocks 9–10, with their items |
| **Appendix, Planes of Existence** (L10752–10905) | **New in v1.6** (Graham's m110), so it is **not in the matrix**, which was cut from v1.4. It is descriptive. Its "PLANAR LANGUAGES" list (12 languages, Arboran to Aesirian) is already in TRG Prime's language list, so there is nothing to register. | A rules journal (below), D |
| **The rules reference journal** (`ea-rules`) | Planned in the architecture (§1: "High Magic, ley lines, wild magic, suppression, rituals, summoning, relics, and the Wild Surge, Ley Line Effects and Suppression Backlash tables") and never built. No JournalEntry pack ships. | Not scheduled. Proposed: with Block 10, or with 8b for the Chapter 7 half. |

Also outstanding but not unbuilt content: the Block 1 questions B1-1 to B1-22 are built as proposed and still await Graham (`ELDRITCH_ARTS_RULINGS_2026-11-01.md`, last section). Three Block 7 spells wait on a core change to reach their audit grade (Arcane Mycelium's light, Glyph of Retribution's type change, Spirit Arrow's manoeuvre; `PROGRESS.md`).

### 1.4 The split, and why

| Sub-block | Spells | Core seams | Why together |
|---|---|---|---|
| **8a** (EA 0.11.0 on TRG Prime 3.686.0) | **Summons (8)**; **Symbols (3)**, with the two shipped Symbols rebuilt on the same model; **exploration and utility (11)** | H12 (the control register for modules), H17, H18 | The Summons share one model and one seam. The Symbols share one GM-triggered line-of-sight model. The utilities are mostly C and D cards and small Regions, and they balance the Summons' design load. |
| **8b** (EA 0.12.0 on TRG Prime 3.687.0) | **Rituals (10)**; **High Magic tied to Chapter 7 (7)** | H13, H14, H15, H16 | The rituals share Block 2b's D13 and need the ritual seams. The High Magic spells reach into Block 2's wild magic, ley line and High Magic code. Essence Reforging is both a ritual and High Magic. Army of the Grave uses 8a's control register, so 8b must follow 8a. |

Why not one release: Block 7 shipped 42 spells, and 35 of them ran on the core's ordinary spell model. Block 8 has fewer spells but four new models: bound creatures, ritual outcomes by degree, GM-triggered symbols, and the Chapter 7 hooks. It also needs seven core seams. Two releases give each model its own harness pair, sweep, review and live test (Summons and Symbols need tokens on a map; rituals need long world-time durations). The split is Q167.

## 2. What TRG Prime 3.685.3 already has

| Need | The core today (file, function) | Gap |
|---|---|---|
| **Conjured creature level** | `magic/conjured-creature.mjs` `conjuredLevelMaxTimes`, `conjuredCreatureLevel`, `conjuredCreatureNote`: warp mods `{conjuredLevel, conjuredBase}`, clamped "to a maximum of your caster level". `cast-workflow.mjs` ~L4309–4319 posts the note and calls `offerConjuredControl` **at the cast**. | The Bindings print no caster-level ceiling ("**+1 PP:** increase the level of the creature by 1"), and they bind only on the creature's failed save, after the cast. So they must **not** use `conjuredLevel`/`conjuredBase`. `bonusValue: 1` gives the same count box with no ceiling (`spell-warp.mjs` `warpScalesWithRepeats` L53; Resurrection's warp already does this). |
| **Control Levels** | `magic/control-register.mjs` (`controlOverflow`, `CONTROL_RELEASE_DC` 20, `CONTROL_SOURCES`), `magic/control-register-workflow.mjs` (`controlledOf` L19, `recordControlled` L46, `releaseControlled` L60, `sweepControlOverflow` L91, `offerConjuredControl` L157). The sweep runs at the controller's turn start (`documents/combat.mjs` L973). Core p242 (rulebook L20089): "the highest-level creature … can make a DC 20 Will saving throw every round to release itself". | **No module can reach it.** None of these is on `helpers` (`module-api-workflow.mjs` L256), and a release by the sweep tells nobody. Seam **H12**. |
| **Minion, Conjured** | Rulebook L31320 (MINION): "for a minion that’s a spell or magic item effect, like a summoned minion, you Sustain a Spell …; if not otherwise specified, you issue a verbal command, a single action with the auditory and concentrate traits." L31251 (CONJURED): "A creature called by a conjuration spell … can't conjure other creatures, create things of value, or cast spells that require a cost." | The Bindings are not sustained, and they "summon a creature", not a facsimile (Q168, Q169). |
| **Creature types** | `creature-types` pack (12: Aberration, Animal, Beast, Construct, Elemental, Eternal, Fey, Humanoid, Ooze, Plant, Undead, Wyrm); `creature-type-rules.mjs` `ownedCreatureType` L33. The Creature Codex builds an NPC from a type, a creature class (16) and a level. | None: the module can check a creature's type and level. |
| **Stat blocks** | **None.** The core's actor packs are empty (`actors`, `bestiary` and `monsters` dump to `[]`). Only `vehicles` holds actors. Fiends & Fables' creatures are a separate book; its 3.0 abilities sit in the Creature Abilities pack, but no creatures do. | The book prints no stat blocks either. See §4.1. |
| **Ritual** | `magic/cast-workflow.mjs` `rollMagicRitual` L8998: the dialog, up to six secondary degree rows, the Ritual Mods, the cap at Success. `magic/ritual-rules.mjs` (D13, 3.679.0): `ritualVariantsFor`, `ritualFieldsFor`, `prepareRitual`, `ritualCapLifted`, `ritualCasts`. The module's `ritualLiftsCap` and `ritualSpellRefusal` (`block2b-automations.mjs` L264–271: M30, Q8). `trgPrimeSpellSettled` carries `ritual`, `degree`, `saveDC`, `warpMods`. | **A ritual's Partial never casts:** "The spell fails, but no PP is lost and no participant faces consequences" (`rollMagicRitual`, ~L9268), and `castSpell` is called only for success or better, or for failure or worse. **A ritual needs a secondary:** "A magic ritual needs at least one secondary caster." Seams **H13**, **H14**. |
| **Rest rates** | `rest/rest-workflow.mjs`: natural healing L167, PP recovery L132 and L216–220. Quick Recovery is a hard-coded ×2 by feat name (L161–166), multiplied with Healing Trance. | **No effect can double or halve a rest's HP or PP** (Eternal Invocation). Seam **H15**. |
| **Storms** | `magic/storm.mjs` (`normaliseStorm` L64, Storm of Vengeance's five modes), `magic/storm-workflow.mjs` (`castStorm` L164, `stormOnSustain` L180): a Region that strikes on the cast and on the first Sustain each round, by chosen mode. | **No rolled mode, no strike at the caster's turn start, no storm that follows its caster** (Storm of Unmaking and its fumble). Seam **H16**. |
| **Walls** | `magic/wall-spell.mjs` `normaliseWall` L53: line or ring, "border" snap, Foundry Walls blocking move, sight, light and sound by level, sections' DB, Hardness and HP ("HP IS TRACKED BY HAND (R9)"). | Wall of Sand's crossing cost and reforming are not shapes the row has (card lines). |
| **Regions and areas** | The module's Region behaviours (Block 2: Ley Line, Wild Magic, Suppression; `module/areas.mjs` `registerAreaTypes` L182, `areasAt` L232, `leyLinesWithin` L247, `strongestAreaAt` L263). Core `zone`, `entryCheck`, `hazard`, `light`, `difficultTerrain`; `emanation-workflow.mjs` (an emanation that follows its caster); `distance-trigger-workflow.mjs` (a condition that waits until its bearer walks too far from the caster). | A distance trigger measured from a **point** (a symbol), not the caster: module-side (§5). |
| **Wild surge** | The module's `wildSurgeFor` (`block2-automations.mjs` L662) and `rollTable` (L344, with `forcedTotal` from Block 3a's Wild Power); `WILD_SURGE` (`chapter7-tables.mjs` L53). | None: Chaos Shield is module-side (§4.4). |
| **Ley line actions** | Tap and Channel Ley Line (`block2-actions.mjs`); `onActionAttemptB2` (`block2-automations.mjs` L471) runs before the check. | None: Leyline Anchor's gate is module-side. |
| **Cast reactions and stores** | `registerCastReaction` (`module-api.mjs` L1645; ctx `castPP`, `saveDC`); `helpers.storeForeignSpell` (`magic/spell-storing-workflow.mjs` L182; Runebreaker absorbs a spell into a Storing Rune with it, `block6b2-automations.mjs` L538). | None for Mimic Spell (§4.4). |
| **Paying PP** | `registerCastPPSource` (L2223: a draw counts in the availability test; `settle` after the cast); `registerCastCostModifier` (L2283: "Payment only. The DC, the cap and the save DC read the PP as cast", Graham's Q93). The cap per cast: `cast-workflow.mjs` L1427. Negative PP (rulebook L6511): "you instead take 5 Soul Drain for every PP that you would fall below 0". | None: Mimic Spell's PP below 0 and Leyline Anchor's discount use these two. |
| **Shared damage** | `registerDamageShare` (L1137): "asked, after temporary HP and Sacrificing Shield and before the dying machinery". | None for Soul Confluence (order to confirm, §6). |
| **Teleportation** | Rulebook L31374: "if you are the target of a teleportation effect, you must make a Spatial Awareness check … If you are subject to an additional teleportation effect in a turn, it automatically fails." `registerDeferredTeleport` (L1248), `helpers.teleportationArrives`, `helpers.teleportationFails` (3.685.1). | None (Harmonic Rift; Arcane Pouch and Veil Severing carry the trait but teleport nobody at the cast). |
| **Objects as targets** | `flags.trg-prime.targetsObject` (3.685.1). | None (Alter Corpse, Arcane Pouch, Riserune, Traveller’s Charm, Argent Mark on an object). |
| **PP locked by a long duration** | `magic/active-spells.mjs` `ppLockCondition` L68: "daily prep" locks to the next preparation; `/unlimited|permanent/` locks "until dismissed". Rulebook L20022: "If a spell has a duration of unlimited, you cannot regain the PP until the spell is dismissed." | "**Until dismissed**" (all eight Bindings) matches neither pattern; "Permanent" already locks (Symbol of Death since 0.5.0). Q170. |
| **Resurrection, counteract, Remove Curse** | The `resurrect` kind (`magic/resurrection.mjs`); `counteract` rows (`counteract-row.mjs` `counteractCandidates` L97). Core Remove Curse has **no effect rows** (dump: `effects: []`). | Remove Curse cannot end anything automatically, so "can only be removed with a Remove Curse spell" has nothing to gate on. Seam **H17**. |
| **Insanity** | Core Insanity (PP 4) is a `note` row: "roll d10 each turn: 2-4 stunned 1d3, 5-7 slowed 1d3, 8-10 confused." | Symbol of Insanity inherits a note. Seam **H18** (optional). |
| **Aligned traits** | `aligned.mjs` `alignedTraitsOf` L99, `sharedAlignedTraits` L170; `creature-traits.mjs` `ALIGNMENT_OPPOSITES`. | None (Eternal Invocation). |
| **Critical injuries, conditions, healing** | `helpers.rollCriticalInjury`, `helpers.applyConditionTags`, `conditionRelief`, `heal`, `grantTempHP`, `basicSaveHit`, `deductGold`, `goldOf`. Injured, weakened, frightened, fleeing, confused, stunned, slowed, soulDrain are core conditions. | None. |

## 3. The spells

### 3.1 As printed (v1.6)

S somatic, V verbal, M material, F focus, SC secondary casters. "—" means the line is not printed. Ladders are quoted in short form, with the line of each rung's heading.

#### Summons (8)

All eight print the same body. Animal Binding (L6076–6100), as rewritten by Graham (m90):

> "**Cast** 10 minutes (material, somatic, verbal) / **Range** 30 feet; **Duration** Until dismissed / **Saving Throw** Will / You summon a creature with the animal trait, binding it to your service. The animal must be level 1 or lower. The outcome of the binding is based upon the results of the creatures saving throw: **Critical** The animal arrives enraged and hostile, the duration ends. **Success** The animal appears but resists, acting freely. **Failure** The animal is bound and serves as a minion. **Fumble** The animal is unusually loyal, gaining +2 circumstance bonus to all checks while serving you. WARPING OPTIONS **+1 PP:** increase the level of the creature by 1."

| Spell (line) | PP | Traits | Tradition | Creature (trait, max level) | Duration | Fumble's +2 to |
|---|---|---|---|---|---|---|
| **Animal Binding** (6076) | 4 | SAVE SUMMONS TRANSLOCATION | arcane, verdant | animal, 1 (L6088) | "Until dismissed" | "all checks" (L6096) |
| **Elemental Binding** (6694) | 6 | SAVE SUMMONS TRANSLOCATION | arcane, verdant | elemental, 2 (L6706, "You tear open a fragment of planar boundary") | "Until dismissed or broken" | "all actions" (L6714) |
| **Entity Binding** (6772) | 12 | SAVE SUMMONS TRANSLOCATION | ethereal | aberration, 8 (L6784) | "Until dismissed or broken" | "all actions" |
| **Eternal Binding** (6818) | 10 | SAVE SUMMONS TRANSLOCATION | divinity | eternal, 6 (L6830) | "Until dismissed or broken" | "all actions" |
| **Fey Binding** (6918) | 6 | SAVE SUMMONS TRANSLOCATION | ethereal, verdant | fey, 1 (L6930) | "Until dismissed or broken" | "all actions" |
| **Plant Binding** (7388) | 6 | SAVE SUMMONS TRANSLOCATION | verdant | plant, 2 (L7400) | "Until dismissed" | "all actions" |
| **Undead Binding** (7877) | 8 | SAVE **SOUL** SUMMONS (no TRANSLOCATION) | arcane, divinity, ethereal | undead, 4 (L7889) | "Until dismissed" | "all actions" |
| **Wyrm Binding** (8021) | 12 | SAVE SUMMONS TRANSLOCATION | arcane | wyrm, 6 (L8033) | "Until dismissed" | "all actions" |

Each: Cast 10 minutes (M, S, V); Range 30 feet; no Target line; Saving Throw Will; no Heroic, Partial or Blunder rung; one warp, "**+1 PP:** increase the level of the creature by 1", with no ceiling. Appendix SUMMONS (L10748): "Summoned creatures are bound by the spell’s duration and conditions but may resist or break free if the magic falters. Casters may employ summoning circles or invoke true names to gain bonuses or ensure control when casting a Summons spell."

#### Rituals (10)

| Spell (line) | Traits · tradition | PP · cast | Area / targets · duration | Cost (line) | Effect | Degrees | Warps |
|---|---|---|---|---|---|---|---|
| **Army of the Grave** (6290) | EVIL RITUAL SOUL UTILITY · arcane, divinity | 20 · 8 hours (M, S, V, SC) | 300‑ft radius · varies | "provide one intact corpse per 2 PP spent; these are consumed." (6302) | "The total combined levels of undead created cannot exceed the number of PP expended on the spell. Skeletons and zombies may be raised freely … all other forms of undead must be studied targets" (6304); "under the control of the primary caster, limited by normal Control Level rules" (6306); "may be commanded with a single sustain action to perform the same action" (6320) | Critical "All undead rise under control; duration is 1 month" (6308); Success 1 week (6310); Partial "Half rise under control for 1 day; half are uncontrolled. This result replaces the normal partial result." (6312); Failure "All rise uncontrolled and attack. All casters suffer 2d10 Essence Damage (basic Fort)." (6314); Fumble 4d10 (6316); Blunder 8d10 (6318) | +4 PP: levels count as half for the maximum (6324); +6 PP: "Duration is permanent, but the ritual site gains the Evil aligned trait and becomes tainted by the Shadescape" (6326) |
| **Call of the Ancestors** (6416) | RITUAL SOUL UTILITY · divinity, ethereal | 6 · 1 hour (M, V, SC) | 30‑ft radius · — | "an ancestral token or offering of personal significance (worth 200 gp), consumed." (6426) | "Summon ancestral shades to answer up to 3 questions. Answers are truthful but may be cryptic." (6428) | Critical clear answers, and "one participant gains advantage on a single check within 24 hours" (6430); Success symbolic (6432); Partial "one answer is misleading" (6434); Failure "all casters suffer 1d6 Mental Damage (basic Fort)" (6436); Fumble 2d6 (6438); Blunder 4d6 and "a hostile spirit possesses one participant" (6440) | +2 PP: one more question (max 10) (6444) |
| **Concord of Stone** (6486) | ALTERATION EARTH RITUAL UTILITY · verdant | 8 · 4 hours (M, V, SC) | 120-ft radius around ritual site · 1 month | "rare minerals and offerings worth 100 gp per PP, buried in the ground." (6498) | "Structures gain DR 5. Allies defending within the zone gain +2 circumstance bonus to DB." (6500) | Critical DR 10, 6 months (6502); Partial "DR only 2; duration 1 week" (6504); Failure "primary casters take 2d6 essence damage (basic Fort)" (6506); Blunder 8d6 (6508). No Success, no Fumble. | +4 PP: double the radius; +6 PP: permanent (6512–6514) |
| **Elemental Convergence** (6720) | ELEMENTAL INVOCATION RITUAL UTILITY · arcane, verdant | 14 · 1 hour (M, S, V; **no SC**) | 500-foot emanation · 24 hours | "Offerings from each element (a flame, fresh water, rich soil, a breath of air), and an altar dedicated to elemental forces." (6732) | "Creatures within the zone gain resistance to an element of their choice (fire, cold, electricity, or acid) and can choose to inflict an additional 1d6 secondary elemental damage of the same type with weapon or unarmed attacks. However, natural weather … (GM discretion)." (6734) | Critical 2d6 (6736); Failure "all casters suffer 2d6 elemental damage (basic Reflex)" (6738); Fumble 4d6; Blunder 8d6. No Success, no Partial. | +4 PP: 1-mile emanation; +4 PP: 1 week (6746–6748) |
| **Essence Reforging** (6798) | HIGHMAGIC RITUAL UTILITY · — | 14 · 1 hour (M, S, V; **no SC**) | Range 30 feet; Targets one creature · — | "Gemstones worth 200 gp x the targets level." (6806) | "Remove a permanent curse or transformation (automatically counteract equal or lower PP/level). / Change a creature’s race. / Restore life to a recently slain creature (as Resurrection)." (6810–6814) | "If you fumble or blunder the casting of this spell, as well as the normal rules for ritual failure, you and the target take 1d8 force damage for each of their levels." (6816). No ladder. | — |
| **Eternal Invocation** (6844) | ALIGNED ELEMENTAL INVOCATION RITUAL UTILITY · divinity | 20 · 12 hours (M, S, V; **no SC**) | 1 mile emanation · "permanent until dispelled" | "A brazier made of radiant gold or fade iron, a fuel offering of rare alchemical substances (worth 10,000 gp), and a vial of holy or unholy water" (6856) | A 10-ft eternal flame, "cannot be extinguished by natural or magical means … a source of heat and light" (6858). Sharing your aligned traits: "Double natural HP recovery / Double PP recovery / Advantage on crafting checks / Advantage on spellcraft checks / Advantage on all saving throws made against creatures with an opposed aligned trait" (6862–6870). "any of an opposed aligned trait": half, half, disadvantage, disadvantage, disadvantage (6872–6882). | No ladder. | — |
| **Rite of Binding Oath** (7544) | ENCHANTMENT ORDER RITUAL UTILITY · divinity, ethereal | 6 · 2 hours (M, V, SC) | Targets up to 10 willing creatures · varies | "an oath circle drawn with blessed chalk or silver-mixed blood worth 250 gp, consumed." (7556) | "Breaking the oath inflicts 2d6 essence damage (basic Fort) and disadvantage on all rolls for 24 hours." (7558) | Critical 1 year, "oath breakers also take double damage" (7560); Success 1 month (7562); Partial "Only half the participants are bound (GM chooses who) for 1 month" (7564); Failure "The ritual collapses; all casters suffer 2d6 essence damage (basic Fort)" (7566); Fumble 4d6; Blunder 8d6 | +1 PP: one more creature; +1 PP: the oath's damage +1d6 "(double on a critical)" (7574–7576) |
| **Rite of Echoed Shadows** (7578) | RITUAL SHADOW UTILITY · ethereal | 8 · 2 hours (M, V, SC) | 60-ft radius · 1 day | "a cracked mirror placed under moonlight, 50 gp." (7590) | "Participants gain advantage on Stealth checks within the area. An enemy that enters the radius of the spell for the first time takes a -2-circumstance penalty to attack checks for 1 minute." (7592) | Critical 300 ft, −4 (7594); Partial 30 ft, 1 hour (7596); Failure "one Shadow appears for every ritual caster and attack" (7598); Blunder "a tear opens in the shadescape, summoning a powerful entity (PP cost of ritual +4 in level) and attempts to kill the ritual casters" (7600). No Success, no Fumble. | +4 PP: 1 week; +6 PP: "participants become invisible while within the zone but take 4d6 essence damage (basic Fort) if they leave the zone" (7604–7606) |
| **Sun’s Benediction** (7703) | HEALING LIGHT RITUAL SOUL UTILITY · divinity | 4 · 1 hour (M, S, V, SC) | 30‑ft radius centred on the ritual focus · varies | "a sacred flame kindled at dawn and blessed oils worth 250 gp, consumed." (7715) | "Up to 6 participants regain 2d8+3 HP and reduce one of the following conditions by 1: dazed, fatigued, sickened or weakened. For 1 hour, they gain a +2-status bonus to saving throws against fear." (7717) | Critical 4d8+6, 24 hours (7719); Success as written (7721); Partial "Half healing only" (7723); Failure no healing, "all casters suffer 1d6 Essence Damage (basic Fort)" (7725); Fumble 2d6; Blunder 4d6 | +4 PP: +1d8+1 and the condition 1 more; +4 PP: injured added; +6 PP: up to 20 creatures; +6 PP: 1 week (1 month on a critical) (7733–7739) |
| **Veil Severing** (7937) | RITUAL TELEPORTATION TRANSLOCATION UTILITY · arcane, ethereal | 18 · 10 hours (M, S, V, SC) | 30-ft radius around ritual focus · varies | "gems worth 2,000 gp, shattered." (7949) | "a two-way portal to another plane or a known Luminex within 500 miles … any creature of up to a large size" (7951); "A Luminex is defined as a permanent portal." (7967) | Heroic 1 year (7953); Critical 1 month; Success 1 week; Partial 1 day; Failure 4d6 essence to all casters (basic Fort); Fumble 8d6; Blunder 12d6 "and a hostile planar entity (at least EL 18) comes through" (7965) | +2 PP: larger creatures; +2 PP: permanent / 1 year / 1 month / 1 week (7971–7973) |

Chapter 7 (L5926): "All spells with the Ritual trait will have additional effects which are determined by the Ritual (Spellcraft or Tradition skill) check. These additional effects are in addition to any results gained from the base check unless stated otherwise in the individual spell description."

#### High Magic tied to Chapter 7 (7)

| Spell (line) | Traits | PP · cast | Range · area · target | Duration | Save | Text (quoted) | Warps |
|---|---|---|---|---|---|---|---|
| **Alter Corpse** (6058) | HIGHMAGIC UTILITY | 2 · 2 AP (S, V) | touch · 1 corpse | — | — | "one of which must be selected when the spell is first cast. DECOMPOSE … a single corpse of size Huge or smaller, leaving behind a perfectly cleaned skeleton. RESTORE … grow flesh on a decomposed or skeletonized corpse of a Medium or smaller creature." (6066–6074) | — |
| **Chaos Shield** (6446) | HIGHMAGIC UTILITY WARDING | 6 · 2 AP (S, V) | 30-foot emanation | 1 minute (S) | — | "Allies gain resistance to wild surge backlash effects and roll twice, taking the preferred result, on any wild magic effect table." (6458) "Area effects caused by wild magic (including hostile spell warp effects) suffer a –2 penalty to DC’s." (6460) "Once per round, if a surge would occur within the aura, you may expend 2 PP as a reaction to nullify it entirely." (6462) | +2 PP: 60 ft (6466) |
| **Leyline Anchor** (7052) | HIGHMAGIC UTILITY | 10 · 3 AP (M, S, V) | 1 mile · "1 Leyline that you are aware of" | 10 minutes | — | "The Leyline becomes fixed in its current state" (7062). "All casters within 300 ft of the caster gain a +1-circumstance bonus to Power Recovery (Meditation) and Spellcraft checks." (7066) "All high magic spells cast within the radius are treated as one PP lower." (7068) "Any other caster that attempts to tap the ley line must make a Power Manipulation check vs your Spell Save DC + 5 before they make their check." (7070) | +2 PP: 1 hour; +6 PP: 24 hours (7074–7076) |
| **Mimic Spell** (7184) | HIGHMAGIC UTILITY | 8 · R (V); "Trigger A spellcaster you can see within 60 feet begins casting a spell." | 60 feet · "1 spell being cast" | — | — (Spellcraft vs "the Spells Casting DC") | Critical "imprint the spell perfectly. You may cast it at any time within the next 1 minute (the imprint is lost once cast or when the minute expires). When you do, you may also choose new targets and adjust the metamagic if you know them." (7194) Success "only weakly. You may cast it on your next turn only." (7196) Failure no effect (7198). Fumble "1d6 essence damage (basic Will) per PP of the spell you tried to mimic." (7200) "You use your own PP to cast the spell. If this pushes your PP below 0, the spell is still cast, but you take 5 Soul Drain for every PP you fall below 0" (7204) | +2 PP: 10 minutes on a critical, 1 minute on a success (7208) |
| **Soul Confluence** (7662) | HIGHMAGIC UTILITY | 10 · 1 minute (S, V) | 30-foot emanation · willing allies | 10 minutes (D) | — | "All participants share HP equal to the sum of their Constitution modifiers × 5. Damage is subtracted from this shared pool first. While linked, allies gain +2 status bonus to Will saves." (7672–7674) "**Backlash** At the end of the spell, all participants suffer 1d6 Soul Drain per 2 rounds the spell lasted." (7676) | — |
| **Storm of Unmaking** (7678) | HIGHMAGIC SAVE | 20 · 3 AP (M, S, V) | 200 feet · 60-foot radius | 1 minute | "Basic (varies)"; Base Damage "varies" | "When you initially cast the spell and then at the beginning of each of your turns, roll 1d6": 1 fire 20d6 Reflex; 2 electricity 10d12 Reflex; 3 cold 30d4 Reflex; 4 acid 15d8 Reflex; 5 bludgeoning 20d8 Fortitude; 6 force 12d10 Fortitude (7690–7699). "If you fumble or blunder the casting of this spell, as well as the normal rules for spell failure, storm appears above you and follows you wherever you go." (7701) | — |
| **Veilfracture** (7903) | HIGHMAGIC UTILITY | 10 · 2 AP (S, V) | 30 feet · "portal 10 ft wide per 2 CL" | Sustained (1 minute) | — | "The rift links the Material Plane to a nearby coterminous plane (GM’s choice: Shadescape, Elemental Plane, or Abyss)." (7913) Fumble or blunder: "the rift collapses violently; caster and 1d4 creatures nearby are pulled into the plane (Reflex save vs your Spell Save DC to resist; Fumble: lost there)." (7915) | — |

#### Symbols (3, and the two built in 0.5.0)

All five: Tradition arcane, divinity; Cast 10 minutes (M, S, V); Range touch. All print: "You carve a magical symbol into a surface, which is activated if any character moves within line of sight and the GM determines that it looks in its direction. When activated, the symbol flashes and each character with line of sight to it must make a … save." and "The active symbol continues to glow until the spell ends or no characters remain with line of sight to it for 10 minutes."

| Spell (line) | PP · traits | Duration · save | Ladder (as printed) | Also |
|---|---|---|---|---|
| Symbol of Death (7741), built 0.5.0 | 16 · ESSENCE RUNE SAVE SOUL | Permanent · Fortitude | Success unaffected; Failure "a deadly essence critical"; Fumble "The target dies." | "After any creature dies from the symbol, it fades and the spell ends." (7763) |
| Symbol of Fear (7767), built 0.5.0 | 12 · EMOTION ENCHANTMENT FEAR RUNE SAVE | varies · Will | Success unaffected; Partial frightened 2; Failure "frightened 4 and fleeing for 1 round"; Fumble frightened 6 and fleeing for 1 round | — |
| **Symbol of Insanity** (7791) | 16 · EMOTION ENCHANTMENT RUNE SAVE | varies · Will | "each character with line of sight is targeted with an Insanity spell using this symbol's Spell Save DC." (7803) | Core Insanity (PP 4, Will): "insane for 1 round per 2 failure", a d10 behaviour each turn |
| **Symbol of Pain** (7807) | 12 · CURSE ESSENCE RUNE SAVE SOUL | varies · Fortitude | Success unaffected (7821); Failure injured 2 (7823); Fumble injured 4 (7825) | "These effects last for 1 hour after the creature moves farther than 60 feet from the symbol and can only be removed with a Remove Curse spell." (7827) |
| **Symbol of Weakness** (7831) | 14 · CURSE ESSENCE RUNE SAVE SOUL | varies · Fortitude | Critical unaffected (7845); Success weakened 1; Partial weakened 2; Failure weakened 4; Fumble weakened 6 (7847–7853) | As Pain (7855) |

#### Exploration and utility (11)

| Spell (line) | Traits · tradition | PP · cast | Range · area · targets | Duration | Text (quoted, short) | Warps |
|---|---|---|---|---|---|---|
| **Arcane Pouch** (6194) | TELEPORTATION TRANSLOCATION UTILITY · arcane | 2 · 2 AP (F, S, V) | touch · one non-magical pouch | 8 hours | "acts as a Never-Ending Stash Sack I, except it can hold only 50 pounds. Regardless of what is placed into the pocket, it weighs 3 pounds." "+1-circumstance bonus on Conceal an Object checks"; ends "if it leaves your possession, the duration expires, or you create a new arcane pouch." (6206–6208) | +2 PP: to the next daily preparation |
| **Archway of Ants** (6214) | TRANSLOCATION UTILITY · verdant | 4 · 1 minute (M, S, V) | 30 feet · 6 × 5’ squares | 10 minutes | "a bridge, wall, or even a ladder or stairs … may be moved, but it cannot change shape once built. The archway supports only 10× your weight allowance; if a single pound more is taken onto the bridge, it crumbles. The archway has DB 10 and the same amount of HP as you." (6226) | +2 PP: one more square |
| **Argent Mark** (6232) | INSIGHT UTILITY · all | 2 · 1 AP (V) | touch · one object or creature | 1 week | "visible only under moonlight or to you. You always know the marked target’s direction and distance while on the same plane." (6244) | +1 PP: 1 month; +2 PP: 1 year; +4 PP: permanent |
| **Blood Biography** (6328) | INSIGHT REVELATION SAVE · all | 6 · 1 minute (M, S, V) | touch | — | "living or undead creatures are entitled to a Will Saving Throw to resist the spell (success or higher blocks the spell)." Four answers (name; gender, race, role; how; when) "appear in a language you can read" (6338–6348) | — |
| **Farsight** (6884) | INSIGHT UTILITY · all | 8 · 1 minute (S, V) | — | 10 minutes | "see details clearly at a distance of up to 1 mile … obstructions such as walls and dense foliage still block your vision." (6894) | +2 PP: 1 hour |
| **Harmonic Rift** (7012) | SONIC TELEPORTATION TRANSLOCATION UTILITY · arcane, ethereal | 12 · 2 AP (S, V) | 500 feet · "two 5-ft openings within range that you can see" | 1 minute | "any creature can step through this rift as if walking through an open door … any enemies who pass through it to make a basic Fortitude save to avoid 3d8 sonic damage." (7026) | +1 PP: +1d8; +2 PP: 10 minutes |
| **Phase Door** (7334) | TRANSLOCATION UTILITY · arcane | 14 · 2 AP (S, V) | touch | 1 hour | "8 ft. by 5 ft. by 30 ft deep ethereal passage through wooden, plaster, or stone walls … invisible and inaccessible to all creatures except you … take one other creature (Medium or smaller) … subject to dispel." (7346–7348) | +1 PP: another creature; +1 PP: +10 ft; +2 PP: any material |
| **Rippling Gaze** (7510) | INSIGHT SCRYING UTILITY WATER · arcane, verdant | 10 · 2 AP (S, V) | 500 feet; Requirement "you are touching a body of water" | 1 hour | See and hear through one flowing water source; "You may sustain the spell to shift your viewpoint"; a Search (Perception) "against your spell DC" sees your face; ends if the water stops flowing (7522–7526) | — |
| **Riserune** (7528) | INSIGHT RUNE SCRYING UTILITY · arcane, divinity, ethereal | 2 · 2 AP (S, V) | touch · one surface | 1 hour | "activates when a Small or larger creature passes within 10 ft … stores a brief image and sound echo … up to 3 triggers … disarmed with a successful Spellcraft or Thievery check against your Spell Save DC." (7540–7542) | — |
| **Traveller’s Charm** (7859) | ENCHANTMENT UTILITY · arcane, verdant | 8 · 2 AP (F, S, V) | touch · one mundane, wearable item | until next daily preparation | "the creature wearing the item can travel at twice their normal speed for long-distance journeys without suffering from fatigue … go without food or water" (7871) | +2 PP: another charm |
| **Wall of Sand** (7975) | EARTH TRANSLOCATION UTILITY · verdant | 8 · 3 AP (M, S, V) | 50 feet | 10 minutes | 20 ft long, 10 ft high, 1 inch thick, border sections; "blocks line of effect but can be passed through by creatures, though doing so costs double movement and obscures vision … Concealment for those behind it and blocks mundane projectiles … DB of 0, Hardness of 5, and 20 HP … immune to critical hits and precision damage … reforms at the beginning of your next turn." (7987) | +2 PP: +5 HP a section; +2 PP: +10 ft long or +5 ft high |

### 3.2 The build

Grades are the matrix's and Block 7's: **A** full, **B** interactive (automated with a normal player or GM choice), **C** partial (one clause or more left to the table, said on the card), **D** descriptive. Each grade assumes the seams in its row; without them the row drops to C, and the missing part is a card line. Every spell is `system.availability: "uncommon"` (m84; the seven High Magic spells also by M27).

#### Summons (8) — one model, §4.1

| Spell | Build | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Animal Binding** | The Binding model (§4.1): creature type Animal, level ≤ 1 + warps. Fumble's +2 "to all checks". | **B** | H12 | M31 (leave), m90 (as rewritten); Q168–Q170 |
| **Elemental Binding** | Type Elemental, ≤ 2. "Until dismissed or broken". | **B** | H12 | M31; Q168–Q170 |
| **Entity Binding** | Type Aberration, ≤ 8. | **B** | H12 | M31; Q168–Q170 |
| **Eternal Binding** | Type Eternal, ≤ 6. | **B** | H12 | M31; Q168–Q170 |
| **Fey Binding** | Type Fey, ≤ 1. | **B** | H12 | M31; Q168–Q170 |
| **Plant Binding** | Type Plant, ≤ 2. | **B** | H12 | Q168–Q170 |
| **Undead Binding** | Type Undead, ≤ 4. SOUL, and no TRANSLOCATION trait, as printed: a Dimensional Lock-type refusal keyed on Translocation does not stop it. | **B** | H12 | Q168–Q170 |
| **Wyrm Binding** | Type Wyrm, ≤ 6. | **B** | H12 | Q168–Q170 |

#### Rituals (10) — one model, §4.2

| Spell | Build | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Army of the Grave** | A ritual (§4.2). Cost: the corpses are counted on the dialog ("one intact corpse per 2 PP spent") and a card names them consumed. At the cast the GM places or selects the undead: the module totals their levels against the PP expended (halved by the +4 PP warp), refuses a total over it, and records each against the primary's control levels (H12, source "undead", the core's own key). Duration effect by degree (1 month / 1 week / 1 day; permanent with +6 PP, which also writes the Evil aligned trait on a marker Region for the site). Partial: the GM ticks which half is controlled (Q175). Failure or worse: none recorded, each marked hostile, and every caster takes the printed damage (basic Fortitude at their own Level DC, C3). Command: Q175. | **B** | H12, H13 | M30; m98 (amended); EA-m42; Q170, Q171, Q173–Q175 |
| **Call of the Ancestors** | The answers are the GM's (a card with the number of questions: 3, +1 per warp, max 10). Critical: one participant chosen gets a held advantage on one check within 24 hours (the core's `heldBonus` shape, advantage). Partial: the card says one answer is misleading. Failure, Fumble, Blunder: 1d6 / 2d6 / 4d6 mental to every caster, basic Fortitude as printed; the Blunder's possession is a card for the GM. | **C** | H13 | M30; m101 (leave: basic Fort stays); Q171, Q173, Q174 |
| **Concord of Stone** | A Region (120 ft; ×2 with the warp) on the ritual site, lasting 1 month (Critical 6 months, Partial 1 week, permanent with +6 PP). The casters' allies inside get +2 circumstance to DB (a Region conditional; "defending" is not a further test). "Structures gain DR 5" (10 on a Critical, 2 on a Partial) is a card line and a label on the Region: the core gives objects no DR row. Failure: 2d6 essence to the primary (basic Fortitude); Fumble as Failure (m42; Graham's M38: "do not change this spell"); Blunder 8d6. Cost: 100 gp × the PP as cast. | **C** | H13 | M30, M38; Q171, Q174 |
| **Elemental Convergence** | A 500-ft emanation Region (1 mile with the warp), 24 hours (1 week with the warp). Each creature inside, on first entering or at the cast, is asked its element (fire, cold, electricity, acid): resistance to it, and a toggle to add 1d6 secondary damage of that type to weapon and unarmed attacks (2d6 on a Critical). The weather is the GM's. Failure, Fumble, Blunder: 2d6 / 4d6 / 8d6 basic Reflex to every caster, of the element **that caster** chose (Graham's M42). A Partial is a Failure here (m42: no Partial is printed). | **B** | H13, H14 | M30, M42; Q171–Q174 |
| **Essence Reforging** | A ritual on one creature within 30 ft (willing: M43, "a spell with the utility trait only affects willing targets"). The primary picks one of three uses. **Remove**: counteract a permanent curse or transformation of equal or lower PP or level, automatically (a list of the target's effects to pick from; no check, as printed). **Restore life**: the core's `resurrect` row, as Resurrection (Q176). **Race**: a card (the GM rebuilds the character). Cost: 200 gp × the target's level. Fumble or Blunder: 1d8 force per target level to the caster and the target, after the normal ritual failure. High Magic (D1), Hard in the ritual too (Q14). No ladder: Success works, Failure does not (M45). | **C** | H14 | M29, M30, M43, M45; Q171, Q172, Q174, Q176 |
| **Eternal Invocation** | The flame: a `light` source on a 10-ft marker Region. A 1-mile emanation Region, "permanent until dispelled" (PP: Q170). Creatures sharing an aligned trait with the caster: rest HP ×2 and PP ×2 (H15), advantage on crafting checks and on Spellcraft checks (Q177), advantage on saves against creatures with an aligned trait opposed to theirs. Creatures with an opposed trait: ×½, ×½ and three disadvantages. No ladder: Success works, Failure does not (M45). Cost: 10,000 gp; the brazier and holy water are a card. | **B** | H14, H15 | m107 (amended); M45; Q170, Q172, Q174, Q177 |
| **Rite of Binding Oath** | Up to 10 willing targets (+1 per warp). An "Oath" effect on each bound target, with a GM button **Oath broken**: 2d6 essence (+1d6 per warp; doubled on a Critical ritual), basic Fortitude at the caster's Save DC, and disadvantage on all rolls for 24 hours. Durations by degree. Partial: the GM ticks the bound half. Failure or worse: damage to every caster. The oath's words are the table's. | **B** | H13 | m126 (as proposed); Q171, Q173 |
| **Rite of Echoed Shadows** | A 60-ft Region (300 ft Critical, 30 ft Partial), 1 day (1 hour Partial; 1 week with the warp). Participants inside: advantage on Stealth. An enemy's first entry: −2 circumstance to attacks for 1 minute (−4 Critical) (`entryCheck` with no check, the effect on entry). The +6 PP warp: participants invisible inside, 4d6 essence (basic Fortitude) on leaving. Failure (and Fumble, m42): "one Shadow appears for every ritual caster": a card naming the count, the creature being Fiends & Fables' (M54). Blunder: a card naming an entity of level PP + 4. | **B** | H13 | M54; Q171, Q173 |
| **Sun’s Benediction** | Up to 6 participants in the 30-ft radius (20 with the warp): `heal` 2d8+3 (Critical 4d8+6; Partial half; +1d8+1 per warp), `conditionRelief` on one condition each chooses (dazed, fatigued, sickened, weakened; injured with the warp), 1 more per warp; +2 status to saves against fear (`conditional`, Fear trait) for 1 hour (24 hours Critical; 1 week or 1 month with the warp). Failure: no healing, damage to every caster. | **B** | H13 | m130 (amended); Q171, Q173 |
| **Veil Severing** | A portal marker Region (30-ft radius around the focus) with the degree's duration (Heroic 1 year … Partial 1 day; the warp's longer set). Travel through it is the table's (a card: the plane or Luminex, the size allowed). Arrives with no teleport of its own (registered deferred, so the cast posts no Spatial Awareness card). Failure, Fumble, Blunder: 4d6 / 8d6 / 12d6 essence to every caster; the Blunder's entity is a card. | **C** | H13 | C5 (rewritten), m138; Q171, Q173 |

#### High Magic tied to Chapter 7 (7) — §4.4

| Spell | Build | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Alter Corpse** | Card: the use (Decompose or Restore) chosen at the cast. `targetsObject`. | **D** | — | R9 (amended) |
| **Chaos Shield** | A 30-ft emanation (60 ft warped), sustained. Read by the module's wild-surge path (`wildSurgeFor`, `rollTable`): a surge by you or an ally inside first offers you the 2 PP reaction to nullify it (once per round); if not nullified, the table is rolled twice and the surging creature picks (Wild Power's `forcedTotal`); its damage rows are halved for you and your allies inside (Q178); its save DCs are 2 lower. Also reaches the Wild birthright's surges (Block 3a). | **B** | — | M36 ("corrected", but v1.6 keeps "resistance to wild surge backlash effects"); Q178 |
| **Leyline Anchor** | Targets a Ley Line Region within 1 mile (Block 2's areas; one you have sensed, or the GM's say). It is flagged anchored for the duration. An emanation of 300 ft on the caster gives casters inside +1 circumstance to Spellcraft checks and Power Recovery (Meditation) (a conditional; Q177). A cost modifier takes 1 PP off Highmagic casts inside (Q179). Before another caster's Tap Ley Line on it (`onActionAttemptB2`), Power Manipulation against your Save DC + 5; a failure stops the attempt (M45: "Success it works and failure it does not"). | **B** | — | M45 (rewritten); Q177, Q179 |
| **Mimic Spell** | A cast reaction (Runebreaker's shape, §4.4). Spellcraft against the observed cast's casting DC (10 + ⌊1.5 × its PP as cast⌋). Critical or Success: an imprint (a copy of the spell, flagged, with an expiry of 1 minute or the end of your next turn; 10 minutes or 1 minute warped). Casting the imprint: your own cast, your PP; a shortfall is drawn below 0 through a PP source whose settle lays 5 Soul Drain per PP. Fumble: 1d6 essence per PP, basic Will at your own Level DC (C3). | **B** | — | M48, M49, m115 (as proposed); Q180 |
| **Soul Confluence** | Willing allies in the 30-ft emanation at the cast, and you, are linked. A pool on the caster = Σ(Con mod) × 5. A damage share (`registerDamageShare`) moves a participant's HP damage to the pool until it is empty; +2 status to Will saves while linked. On the spell's end (10 minutes, or dismissed, C4): each participant gets 1d6 Soul Drain per 2 rounds it lasted (rounded down, m128). | **B** | — | C4 (D added); Q181 |
| **Storm of Unmaking** | The core's `storm` row with six modes (the table), rolled on 1d6 at the cast and at the start of each of your turns (H16), basic saves at the Save DC. Fumble or Blunder: after the failure's normal rules, the storm is raised centred on you and follows you (H16; Q182). | **A** | H16 | M56 (leave), m129 (amended); Q182 |
| **Veilfracture** | A portal marker Region (10 ft wide per 2 CL), sustained. The plane is the GM's (a card). Fumble or Blunder: you and 1d4 nearby creatures (the GM picks them; the count is rolled) save Reflex against your Save DC; a failure is a card ("pulled into the plane"), and a Fumble's card says "lost there". | **C** | — | m137 (as proposed) |

#### Symbols (3) — one model, §4.3

| Spell | Build | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Symbol of Insanity** | The Symbol model. Each creature with line of sight is the target of core Insanity at the symbol's Save DC: its Will save is rolled, and a failure applies Insanity's result. Today that is the core's note (the d10 each turn by hand); with H18 the d10 is rolled each turn. | **C** (B with H18) | H18 | m134 (as proposed); M57 |
| **Symbol of Pain** | The Symbol model. Fortitude: Success unaffected; Failure injured 2; Fumble injured 4 (Partial → Failure, Blunder → Fumble, Heroic and Critical → Success: m42, m131). The condition is held while the creature is within 60 ft of the symbol and for 1 hour after it moves farther (m135); only Remove Curse ends it sooner (H17; Q183). | **B** (C without H17) | H17 | m131, m135; M57; Q183 |
| **Symbol of Weakness** | As Pain: Critical unaffected; Success weakened 1; Partial 2; Failure 4; Fumble 6. | **B** (C without H17) | H17 | m135; M57; Q183 |

The two built in 0.5.0, if Q184 says yes: **Symbol of Death** (Failure a deadly essence critical through `rollCriticalInjury`; Fumble death; a death ends the spell) and **Symbol of Fear** (frightened 2 / 4 and fleeing 1 round / 6 and fleeing 1 round). Both go from D to B.

#### Exploration and utility (11)

| Spell | Build | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Arcane Pouch** | `targetsObject` on the pouch; a marker effect on the caster naming the pouch. A conditional +1 circumstance to Conceal an Object (Stealth) for its contents. The 50 lb limit and the 3 lb weight are card lines: the core's inventory has no containers. The spell's three endings are card lines, and a new casting ends the last. Registered as a deferred teleport (it moves nobody). | **C** | — | m94 (amended) |
| **Archway of Ants** | A Region of 6 squares (+1 per warp) drawn by the caster in range, labelled with DB 10, HP equal to the caster's maximum HP at the cast, and the weight limit (10 × your Weight Allowance). It crumbles by a GM button. Moving it and the load are the table's. | **C** | — | m95 (amended) |
| **Argent Mark** | A `moduleMark` on the target (an object via `targetsObject`) for 1 week (1 month, 1 year or permanent by warp: one duration warp is taken, m96). Willing creatures only (M43, m96). A button on the caster's marker gives the mark's direction (the module's `compass`) and distance when it is on the same scene; otherwise the card says "on the same plane" is the GM's. | **C** | — | m96 ("a Utility spell so no unwilling targets"); Q170 (the permanent warp) |
| **Blood Biography** | When the GM names the creature whose blood it is, and it is living or undead, its Will save is rolled against your Save DC; Success or better blocks the spell. The four answers are the GM's (a card with the four questions). | **C** | — | M35 (corrected) |
| **Farsight** | Card. | **D** | — | — |
| **Harmonic Rift** | Two 5-ft Regions within 500 ft that you can see, linked by Foundry's own Teleport Token behaviour, for 1 minute (10 with the warp). Each passage is a teleportation effect on whoever passes (the core's Spatial Awareness card; a second in a turn fails: `teleportationArrives`, the cast registered deferred). A creature hostile to the caster rolls a basic Fortitude for 3d8 sonic (+1d8 per warp) on each passage. | **B** | — | m110 (the Grey is in the appendix) |
| **Phase Door** | Card. The passage may be drawn as a GM-hidden Region for reference; moving through walls is the GM's. | **D** | — | R12 (amended) |
| **Rippling Gaze** | Card. The Requirement is shown on the cast. | **D** | — | m125 (amended) |
| **Riserune** | A hidden marker Region (10-ft radius) on the surface. A token of Small or larger size moving into it records its name, image and the time (up to 3), whispered to the caster; touching the rune (a button) replays the three. Disarming is the GM's (Spellcraft or Thievery against your Save DC). | **C** | — | — |
| **Traveller’s Charm** | Card (the core has no overland travel). `targetsObject`. One charm per warp. | **D** | — | m136 (as proposed) |
| **Wall of Sand** | The core's `wall` row: 20 × 10 ft (warps `wallLength`, `wallHp`), border snap, sight limited (concealment behind it), sections DB 0, Hardness 5, HP 20, `unobstructed`. Card lines: crossing costs double movement, it blocks line of effect and mundane projectiles, and a destroyed section reforms at the start of your next turn (HP is tracked by hand, R9). | **C** | — | m139 (amended) |

## 4. One model per family

### 4.1 Summons

**The cast.** A Binding is authored as a utility spell with no defence at the cast. It prints no Target line, so the core opens no picker. Its Will save is rolled by the module after the cast, on the creature (as Symbol of Death and Fear were authored in 0.5.0, so that the core's save step never rolls against whoever happens to be targeted). The core's casting check, 10-minute cast, High Magic rules and PP all apply. Block 2b's pieces apply as built:
- the summoning circle's +4 / +2 / −2 circumstance on the casting check (`summoningCircleGate`, L378);
- the Critical circle's +2 and Ward Twine's +1 to the Save DC (`circleBindingOption`, L389; Q12);
- the true name's +4 to the Save DC (`trueNameOption`, L408).

The warp is `bonusValue: 1`, a count box with no ceiling. It is bounded by the maximum PP per cast (caster level + 1), which the core enforces: Animal Binding's best is a level CL − 2 animal. The core's `conjuredLevel`/`conjuredBase` are **not** used: they clamp to caster level (not printed) and offer control at the cast, before any save.

**The creature.** The book prints no stat blocks, and TRG Prime ships no creature actors (its `actors`, `bestiary` and `monsters` packs are empty). Its creature types and classes let the GM build one in the Creature Codex, and Fiends & Fables holds most of the creatures the eight types name. **The module ships no creature actors.** Any it made would be invented stat blocks, which the brief forbids ("Do not invent rules", "Do not use placeholder spells or feats"). Once the cast settles (`trgPrimeSpellSettled`, `cast` true, a Summons-trait Eldritch Arts spell), a GM card asks for the creature:
- the GM places a token and selects it, or selects one already within 30 ft;
- the module checks its creature type (`ownedCreatureType`: Animal, Elemental, Aberration, Eternal, Fey, Plant, Undead, Wyrm), that its level is no more than the printed maximum + warps, and that it is within 30 ft;
- with Versatile Binder, the creature is the one chosen at the cast, and the same checks apply (Q169).

**The save and the ladder.** The creature rolls Will against the cast's `saveDC` (every option in), through the owner query when the caster's client does not own it. Missing rungs follow m42:

| Rolled | Outcome (as printed) | Built |
|---|---|---|
| Heroic, Critical | "arrives enraged and hostile, the duration ends" | The active spell entry ends; the creature is marked hostile to the caster; nothing recorded |
| Success | "appears but resists, acting freely" | Not recorded against control levels; acts as the GM runs it; what the spell then does is Q168 |
| Partial, Failure | "bound and serves as a minion" | Recorded against the caster's control levels (H12, source "bound"); a "Bound to [caster]" effect with the minion trait, carrying the cast's id |
| Fumble, Blunder | "unusually loyal, gaining +2 circumstance bonus to all checks while serving you" | As Failure, plus +2 circumstance to its checks while bound (Q169 for "all actions") |

A true name invoked and a Success or better: Block 2b's "permanently hostile" effect, fed this save (its `trueNameHostility` reads only the core's save results today, §5). A circle that fumbled: the creature "arrives hostile and unbound" whatever its save (Block 2b's line), so it takes the Critical row.

**Control and ending.** Control Levels are the core's (p242). While over the cap, the highest-level creature rolls DC 20 Will at the controller's turn start (`sweepControlOverflow`). A release there fires H12's hook, and the binding ends ("broken", Q169). Dismiss (1 AP, Concentrate; core `dismiss.mjs`) ends the spell, releases the entry and asks the GM to remove the creature or leave it (Q168). The PP lock is Q170. Commanding is Q169.

**Versatile Binder** (Block 6, 0.9.0) is unblocked. Its `binderAfter` (`block6d-automations.mjs` ~L765) today rolls its own save and says "its control is the GM's". From 8a it rolls nothing: it marks the cast, and the Binding model above uses the chosen creature, with one save (Q133: "the spell's own save against your Spell DC. On a failure it is bound as a summoned creature would be"). Its grade rises from C to B.

**Chapter 7 tables that name summons** become automatable once the register exists. Ley Line Effects 25–27 ("Your summoned creatures gain +1 AB." / "Summons are Stunned 1.", `chapter7-tables.mjs` L24, `manual` today) read the caster's "bound" and "conjured" entries. Wild Surge 12–15 (an elemental "acts randomly") stays a card: it is no one's minion.

### 4.2 Rituals

**What exists (D13, Block 2b).** The core's Magic Ritual: the primary's Spellcraft, secondaries' degrees as circumstance, the Ritual Mods, overcasting room of 2 PP a secondary. Then the module's parts:
- the variant (tradition skill, Very Hard against the primary's level DC; vital, material and communal payment; Q5, Q9–Q11);
- the cap at Success lifted for Eldritch Arts Ritual spells (M30, `ritualLiftsCap`), so Heroic and Critical lines are reachable;
- Ritual-trait spells refused outside a ritual (Q8);
- High Magic's Hard in a ritual (Q14); Ritual Expert (Q13).

**The ritual's outcome lines.** Chapter 7 (L5926): "additional effects which are determined by the Ritual … check … in addition to any results gained from the base check unless stated otherwise". So each ritual spell carries its printed rungs as data. The module applies them on `trgPrimeSpellSettled` with `ritual` true, by the ritual's `degree`, on top of the core's base result (PP spent by degree, the fumble table at +20 for a ritual). Missing rungs follow m42 (Heroic → Critical; Critical → Success; Partial → Failure; Fumble → Failure; Blunder → Fumble). A ritual with no ladder at all (Essence Reforging, Eternal Invocation) follows M45: "Success it works and failure it does not".

**The Partial.** The core never casts a ritual's Partial. Seven of the ten print a Partial effect, and Army of the Grave says "This result replaces the normal partial result". Seam H13 lets a Ritual spell's Partial cast; Q171 asks what it costs and does.

**Who takes part.** "All casters" is the primary and the secondaries. The core's secondaries are degree rows with no actor, so the module's ritual fields (`ritualFields`, `participants`, Block 2b) are extended to tick each one, for every Ritual spell rather than only for the vital and communal variants. "Participants" (Sun’s Benediction, Echoed Shadows, Call of the Ancestors, Rite of Binding Oath) is Q173.

**The lone primary.** Three rituals print no "secondary casters" on their Cast line (Elemental Convergence, Essence Reforging, Eternal Invocation). The core refuses any ritual without one. Seam H14; Q172.

**Cost lines.** All ten print a Cost. `extract-book.mjs` keeps it as a line, not a field (§5). The module reads it into the ritual spec: a gp amount where one is printed (Call 200; Concord 100 × PP; Essence Reforging 200 × target's level; Eternal Invocation 10,000; Binding Oath 250; Echoed Shadows 50; Sun’s Benediction 250; Veil Severing 2,000), taken with `deductGold` and refused before the roll when the purse is short (Block 2b's Ritual Censor pattern). Corpses and the non-gp offerings are counted or named on the card. When it is paid is Q174. A material sacrifice (the variant) is a separate payment in place of PP.

**Durations and areas.** Ritual durations run on world time (1 day to 1 year), as effects and as Regions with the module's flag `{kind: "ritual", spell, castId, until}`, created like Block 2's areas. Permanent warps and Eternal Invocation meet the core's PP lock (Q170). PP 20 rituals exceed most casters' cap; the core's overcasting room (2 PP a secondary) is the way, and the cap otherwise stands (Q9). Ritual Partial and Failure damage "to all casters" is `basicSaveHit` on each ticked caster, at that caster's own Level DC (C3: no DC printed).

### 4.3 Symbols (with the two built)

One model for all five, so Death and Fear are rebuilt on it (Q184).

- **The cast** (10 minutes, touch) places a small Region on the surface. It is hidden from players and carries `{kind: "symbol", spell, saveDC, casterUuid, castId}`, with the Save DC stamped at the cast. It holds no PP lock beyond the core's (Death is "Permanent": Q170).
- **Activation is the GM's:** "activated if any character moves within line of sight and the GM determines that it looks in its direction". A GM button on the Region's card, **The symbol flashes**, finds every token with line of sight to the symbol's point (Foundry's sight collision test, which respects walls and darkness) and rolls each one's save against the stamped DC. This is B, not A, by the book's own wording: the GM decides that it looks.
- **Every flash is a new save.** There is no immunity and no range limit beyond line of sight (Graham's M57: "Leave it alone").
- **The ladders** follow m42 and m131 ("no partial, see my earlier notes"). Death's and Pain's Partial is their Failure; Weakness prints all five. A later, worse result replaces a better one; an equal or better one leaves it (the core keeps the higher value of a condition).
- **Glowing.** After a flash the Region shows as glowing (a dim `light`) until no token has line of sight for 10 minutes of world time, checked on token movement and on the world clock.
- **Pain and Weakness's hold (m135):** the condition stays while the creature is within 60 ft of the symbol, and for 1 hour after it moves farther. A token-movement hook starts the hour once the distance first exceeds 60 ft (the core's distance trigger measures from the caster, not from a point, so this is the module's). "can only be removed with a Remove Curse spell": H17 and Q183.
- **Insanity:** core Insanity at the symbol's DC on each creature (§3.2).
- **Death:** the deadly essence critical via `rollCriticalInjury`; on any death from it, the symbol fades and the spell ends (m132).

### 4.4 Chapter 7 High Magic

**High Magic casting (D1, Block 2a).** All seven are cast through D1, built in 3.678.0: casting DC Hard (+2), armour DR × 4 (Q3), the focus set aside unless Arcanum or Archmage (Q2), fumble +60, Resonance with disadvantage, no tradition and no school (M29), all traditions (M27). M27 also applies: uncommon; a non-High-Magic caster learns at Very Hard and casts at Hard.

**Wild surge (Chaos Shield).** The surge is the module's (`wildSurgeFor` → `rollTable`). Chaos Shield adds four steps there and needs no core seam:
1. The 2 PP reaction to nullify, offered to the shield's caster once per round, before the d100 (`askReactor`).
2. "roll twice, taking the preferred result": two rows rolled, the surging creature chooses (Wild Power's `forcedTotal`).
3. Halved damage on damage rows for creatures in the aura (Q178's reading of "resistance").
4. −2 to the DCs of rows with saves.

It reaches every caller of the table: Wild Magic areas, the Wild birthright, Wild Power.

**Ley line regions (Leyline Anchor).** A Ley Line is Block 2's Region behaviour `{level}`. Leyline Anchor adds a flag `{anchoredBy, until, saveDC}` to that Region. A 300-ft emanation on the caster (the core's emanation follows its caster) carries the +1 conditionals. A `registerCastCostModifier` takes 1 PP off a Highmagic cast by a creature inside (Q179). `onActionAttemptB2` asks another caster's Power Manipulation against the anchoring caster's Save DC + 5 before Tap (and Channel, Q179). "Fixed in its current state" has no mechanical state to fix: Block 2's ley lines have a level and nothing else, so it is a card line.

**Mimic Spell and other spells.** Mimic is a cast reaction, registered like Runebreaker (`registerCastReaction`, ctx `castPP`):
- It is offered to a creature that knows Mimic Spell, within 60 ft and able to see the caster, with a reaction and 8 PP. It answers `null`, so the observed cast goes on: it never stops, scales or turns a cast.
- It therefore **composes with every other cast reaction** on the same cast: Argent Reversal, Spectral Aegis's absorb, Arcane Feedback, Runebreaker, Counter Channel, Reflective Warding. Each answers its own way; Mimic copies the pattern whatever they do.
- **The imprint** is a copy of the spell (the core's `foreignSpellCopyData`, as `storeForeignSpell` uses), flagged and given an expiry. On a Critical you choose new targets and add or drop metamagic you know in the Warp? dialog; on a Success, Q180.
- **Casting the imprint** is your own cast (your casting check, Save DC and cap). It cannot be cast above your maximum PP per cast (M48: "You cannot mimic a spell whose PP exceeds your maximum PP per cast"; v1.6 omits the sentence, §5), so the brief's "Do not bypass maximum PP per cast" holds. A Ritual-trait spell's imprint is refused outside a ritual (Q8). A specialist spell's imprint is Q180.
- **PP below 0:** a `registerCastPPSource` "Mimic: below 0" offers the shortfall. Its `settle` lays 5 Soul Drain per PP drawn (Negative PP, core L6511).

**Soul Confluence and Storm of Unmaking.** Soul Confluence is a damage share (§3.2). Storm of Unmaking is the core's storm with H16.

## 5. Module-side findings (no ruling needed unless noted)

- **The extractor keeps "Cost" as a line, not a field.** All ten rituals print "**Cost** …"; `extract-book.mjs` `LABELS` (L40) has "PP Cost" but not "Cost", so it lands in `lines`. Nothing is lost from the card, but the builder cannot read it. **Fix:** add "Cost" to `LABELS`, re-cut, re-verify Blocks 1–7 (no built entry prints a bare Cost line).
- **Binding and Symbol saves must not be the core's cast save.** A SAVE spell with "Saving Throw Will" is authored by `build()` as `category: "save"` (`block3-spells.mjs` L409). That would roll at the cast against whoever is targeted, before any creature exists or any symbol flashes. All eight Bindings and the three Symbols are authored `category: "utility"`, `defence: ""`, as Death and Fear were. Blood Biography likewise (its creature may be absent).
- **Block 2b's true-name hostility reads only the core's save results** (`trueNameHostility`, L423: `ctx.saveResults`). A Binding's save is the module's, after the cast, so the Summons model calls it with its own result.
- **Versatile Binder's `binderAfter`** rolls a second, separate save and leaves control to the GM. It must hand over to the Summons model (§4.1). Owned copies keep working; the change is in code, not in the item.
- **Teleportation without a teleport.** Arcane Pouch and Veil Severing carry TELEPORTATION, so the core would post "Teleported — Spatial Awareness" at their cast for whoever is targeted. Both are registered with `registerDeferredTeleport` (3.685.1). Harmonic Rift calls `teleportationArrives` on each passage.
- **v1.6 text that a ruling said was fixed, but is not** (built as v1.6 prints, with the ruling's reading; listed for the book):
  - M36 "corrected": Chaos Shield now says "preferred" but keeps "resistance to wild surge backlash effects" and "(including hostile spell warp effects)" (Q178);
  - M48 "As proposed": the cap sentence is not in Mimic Spell (built per M48);
  - m98 "amended": Army of the Grave still says "a single sustain action" on a non-sustained spell (Q175);
  - m107 "amended": Eternal Invocation still says "any of an opposed aligned trait" (no "creature") and both "cannot be extinguished by natural or magical means" and "permanent until dispelled";
  - m125 "amended": Rippling Gaze still says "sustain the spell" on a 1-hour spell (read as a 1 AP Concentrate action, as m125 proposed);
  - m90 "amended": "Until dismissed or broken" is still undefined and four Bindings say only "Until dismissed" (Q169).
- **Wording, for the book only:** Storm of Unmaking "storm appears above you" (m129 asked for "the"); Rite of Echoed Shadows' Blunder "(PP cost of ritual +4 in level)"; Veil Severing "the damage is12d6"; Concord of Stone "primary casters" (plural; built as the primary, per M38's "do not change"); Elemental Binding … Wyrm Binding "acting freely" with no full stop.
- **Undead Binding's traits** are SAVE SOUL SUMMONS: no TRANSLOCATION, unlike the other seven. Built as printed.
- **Tradition "all"** (Argent Mark, Blood Biography, Farsight) is authored as the four traditions, as Block 7 did.
- **Uncommon:** all 39 get `system.availability: "uncommon"` (m84), as Block 7's did.
- **No placeholders.** No creature actor, no Shadow, no planar entity and no possessing spirit is shipped. Each is a card that names the GM (and, for the Shadow, Fiends & Fables: M54).

## 6. Proposed core seams (TRG Prime, for Graham's approval)

Block 7's were H1–H11 (TRG Prime 3.685.0). 3.685.1 added three unnamed seams for 0.10.1's fixes (`registerDeferredTeleport`, `targetsObject`, the bonus group). 3.685.2 and 3.685.3 added none. So these continue at **H12**. As before, each is prepared separately, additive and default-off (a spell, row or module that does not use it behaves exactly as now), with its own `verify`/`mutate` pair.

| # | Seam | Core file / function | Used by | Sub-block |
|---|---|---|---|---|
| **H12** | **The control register for modules.** `helpers.recordControlled`, `helpers.releaseControlled`, `helpers.controlledOf`; a `CONTROL_SOURCES.bound` ("Bound"); and a hook, `trgPrimeControlReleased({ controller, entry, creature, degree, reason })`, fired when the overflow save frees a creature and on any release. | `magic/control-register.mjs` `CONTROL_SOURCES`; `magic/control-register-workflow.mjs` L46, L60, L91; `module-api-workflow.mjs` helpers (L256) | The 8 Summons, Army of the Grave, Versatile Binder, Ley Line Effects 25–27 | 8a |
| **H13** | **A Ritual spell's Partial casts.** `registerRitualRules` gains `partialCasts(ctx) → true`. `rollMagicRitual` then calls `castSpell` with `ritual.degree: "partial"`, which spends what a Partial spends and applies no ritual consequences. `castSpell` lets that degree through (today `ritualFailed` and `ritualCasts` exclude it). | `magic/ritual-rules.mjs` `ritualCasts`; `magic/cast-workflow.mjs` `rollMagicRitual` (Partial branch ~L9268), L2687 | The seven rituals with a Partial line, and m42's mapped Partials | 8b (Q171) |
| **H14** | **A Ritual spell performed by its primary alone.** `registerRitualRules` gains `minSecondaries(ctx) → 0`; the "needs at least one secondary caster" refusal asks it. The overcasting room stays 2 PP a secondary (0 when alone), so the cap is not bypassed. | `magic/cast-workflow.mjs` `rollMagicRitual` (~L9154); `magic/ritual-rules.mjs` | Elemental Convergence, Essence Reforging, Eternal Invocation | 8b (Q172) |
| **H15** | **Rest rates from an effect.** An effect row `restRate { hp, pp }` (a multiplier: 2 or ½) read by the rest's natural healing and its PP recovery. Rates multiply, as Quick Recovery and Healing Trance already do. | `rest/rest-workflow.mjs` L132–220 (Quick Recovery hard-coded, L161–166) | Eternal Invocation | 8b |
| **H16** | **A storm whose strike is rolled, at the caster's turn start, and that may follow its caster.** A `storm` row may say `pick: "roll"` (a die over its modes, repeats allowed), `strikes: "turnStart"` (at the cast and the start of each of the caster's turns, no Sustain) and `follow: true` (the Region moves with the caster). And `helpers.placeStorm(actor, row, { centre, follow, dc, castId, seconds })`, so a module can raise one after a failed cast. | `magic/storm.mjs` `normaliseStorm` L64, `stormModesOffered`; `magic/storm-workflow.mjs` `castStorm` L164, `stormOnSustain` L180; the turn start in `documents/combat.mjs`; `magic/emanation-workflow.mjs` (follow) | Storm of Unmaking and its fumble | 8b (Q182) |
| **H17** | **Conditions held by a curse.** An effect row `heldConditions { keys, until }`: condition relief, rest and recovery leave the named conditions alone while the effect stands. And core **Remove Curse** gains a `counteract` row against effects from Curse-trait spells. **The second half changes a core spell in every world**, so it is Graham's call apart from the first. | `magic/condition-relief.mjs`, `rest/rest-workflow.mjs` (fatigue and condition recovery); `magic/counteract-row.mjs`; the Remove Curse entry (`tools/data-fixes.json`) | Symbol of Pain, Symbol of Weakness; also Flesh to Blossom's "until removed with Remove Curse" (a card line since Q156) | 8a (Q183) |
| **H18** | **Core Insanity's table, rolled each turn** (optional). A `turnTable` row: a d10 at the start of each of the target's turns, for 1 round per 2 points the save failed by (4 PP warp: per 1), applying stunned 1d3, slowed 1d3 or confused. **It automates the core spell in every world.** | `magic/turn-options.mjs` / `turn-ladder.mjs` (the turn-start pattern); the Insanity entry | Symbol of Insanity (C → B); core Insanity itself | 8a |

**To be confirmed in the build** (seams only if the check fails):
- the rest's Power Recovery check reads a Meditation conditional (Leyline Anchor);
- a damage share can come before temporary HP, or "first" means before the participant's own HP only (Soul Confluence; `registerDamageShare` runs after temporary HP);
- `weaponDamageBonus` can add typed secondary dice chosen per creature (Elemental Convergence);
- a module-created Region can carry Foundry V14's Teleport Token behaviour (Harmonic Rift);
- `createEffectsOn` relays to the GM for an NPC the caster's client does not own (the Fumble's +2, the bound marker);
- `registerCastPPSource` can draw a shortfall when the pool is 0 (Mimic Spell).

## 7. Rulings that already settle Block 8 points

| Ruling | Settles |
|---|---|
| **M30** (cap lifted), **Q8** (Ritual spells only in a ritual) | Every ritual's Heroic and Critical lines are reachable; built in 0.4.0 |
| **Q5, Q9, Q10, Q11, Q13, Q14** | The ritual variant, its cap, preparation, what is substituted, Ritual Expert, High Magic's Hard in a ritual (Essence Reforging) |
| **Q12** (Ward Twine: +1 Save DC), Block 2b's circle (+2 Save DC on a Critical) | The circle's bonuses on a Binding's save |
| **Q133** (Versatile Binder: "the spell's own save against your Spell DC. On a failure it is bound as a summoned creature would be") | The existing creature's save |
| **M31** "leave this alone" | The Bindings' prices and levels |
| **m90** (Animal Binding as rewritten; the other seven printed the same way in v1.6) | The Binding ladder's wording |
| **m42** (the missing-results table) | Every missing rung: Heroic → Critical, Critical → Success, Partial → Failure, Fumble → Failure, Blunder → Fumble (or Failure). Applies to the Bindings, Concord, Convergence, Echoed Shadows and the Symbols |
| **M38** "do not change this spell" | Concord of Stone: Fumble is the Failure (2d6); no Success line means the base effect |
| **M42** | Elemental Convergence's Failure damage is of the element the caster chose |
| **M43** (Essence Reforging's lines; "a spell with the utility trait only affects willing targets"), **M51**, **m96** | Essence Reforging, Argent Mark and every Utility spell here: willing targets only |
| **M45** ("If no results … Success it works and failure it does not", and Leyline Anchor as rewritten) | Leyline Anchor's tap check; Essence Reforging and Eternal Invocation (no ladder) |
| **M35** "corrected" | Blood Biography's save ("success or higher blocks the spell") |
| **M48, M49, m115** "as proposed" | Mimic Spell: the casting DC; no imprint above your maximum PP per cast; Negative PP; "the imprint is lost once cast or when the minute expires" |
| **M54** "A shadow is defined in Fiends & Fables" | Echoed Shadows' Failure: a card |
| **M56** "leave it alone" | Storm of Unmaking: full dice, 1 minute, not sustained |
| **M57** "Leave it alone" | The Symbols: no immunity and no range beyond line of sight |
| **C4** "(D)" | Soul Confluence is dismissible, so the backlash is not always 50d6 |
| **C5** (Veil Severing rewritten) | Its ladder and warps |
| **m131** ("no partial"), **m132**, **m133**, **m134**, **m135** | The Symbol ladders; Death's ending; Insanity at the symbol's DC; Pain and Weakness's 60-ft hold |
| **m94, m95, m98, m107, m108, m110, m125, m126, m129, m130, m136, m137, m138, m139; R9, R12** | Each spell's v1.6 text, as in §3 (m101 and R16: leave) |
| **C3** (no DC printed: the target's Level DC, or the caster's own) | Ritual damage to casters; Mimic's Fumble |
| **m128** (round down unless stated) | Soul Confluence's rounds; Army's halves |
| **M4, M27, M29, Q2–Q4** | High Magic casting for the seven |
| **Q6, Q7** | Antimagic refuses every cast; wild surges from rituals too (Chaos Shield) |
| **Q93** ("Payment only. The DC, the cap and the save DC read the PP as cast") | The precedent proposed for Leyline Anchor (Q179) |
| **m84** | Uncommon |

## 8. Rulings needed

Ordered by subsystem; each quotes v1.6. Only points that change play are asked.

| # | Question | Proposed |
|---|---|---|
| **Q167** | **One release or two.** Block 8 is 39 spells, four new models and seven core seams (§1.4). | **Two:** 8a, the Summons, Symbols and utilities (22; TRG Prime 3.686.0, EA 0.11.0); then 8b, the rituals and Chapter 7 High Magic (17; 3.687.0, EA 0.12.0). Each has its own harness, sweep, review and live test. |
| **Q168** | **What a summoned creature does, and what the spell's end does.** "**Critical** The animal arrives enraged and hostile, the duration ends." "**Success** The animal appears but resists, acting freely." "**Failure** … serves as a minion." Duration "Until dismissed". The Appendix: "Spells with this trait always create or bring forth an independent being … bound by the spell’s duration". Nothing says whether a Critical or Success creature stays, or what dismissal does to a bound one. | **Critical:** the creature is here and hostile; the spell ends; it stays (the GM runs it). **Success:** it is here and free, not under control and not counted against control levels; the spell lasts until dismissed, and dismissing sends it back. **Bound:** when the spell ends (dismissed or broken), it returns to where it was summoned from. Versatile Binder's existing creature is released where it stands. A bound creature has the minion trait but **not** the core's Conjured trait (it is summoned, not a facsimile). |
| **Q169** | **"Broken", commanding, the Fumble's bonus, and the level limit.** Four Bindings last "Until dismissed or broken", four "Until dismissed"; "broken" is defined nowhere. The spells are not sustained, but the core's minion trait says a summoned minion is commanded by Sustain a Spell. Animal Binding's Fumble gives +2 "to all checks", the other seven "to all actions". "**+1 PP:** increase the level of the creature by 1" has no ceiling (core conjures: "to a maximum of your caster level"). And Versatile Binder binds "a creature that already exists". | **All eight alike:** "broken" means released by the Control Levels save (DC 20 Will, core p242), or the spell counteracted or dispelled. **Commanding:** the minion trait's default, "a verbal command, a single action with the auditory and concentrate traits" (1 AP), since there is no Sustain. **Fumble:** +2 circumstance to all checks, for all eight. **Level:** no ceiling but the maximum PP per cast. **Versatile Binder:** the spell's creature trait and maximum level still apply to the existing creature. |
| **Q170** | **Which long durations lock PP.** Core: "If a spell has a duration of unlimited, you cannot regain the PP until the spell is dismissed." TRG Prime reads "unlimited" and "permanent" as that lock (so Symbol of Death's "Permanent" has locked 16 PP since 0.5.0). "Until dismissed" (all eight Bindings) is not matched. Affected: the Bindings; Symbol of Death; Eternal Invocation ("permanent until dispelled"); the permanent warps of Army of the Grave, Concord of Stone, Argent Mark and Veil Severing. | **"Until dismissed" and "Permanent" are both "unlimited"**: the PP stays locked until the spell ends (dismissed, dispelled, broken, or the symbol fades). Fixed long durations (1 week, 1 month, 1 year) lock nothing. A ritual paid by a sacrifice locks no PP, since none was paid. |
| **Q171** | **A Ritual spell's Partial.** Core casting: "**Partial** The spell fails but you lose no PP"; the core casts nothing on a ritual's Partial. Chapter 7: ritual effects are "in addition to any results gained from the base check unless stated otherwise". Seven rituals print a Partial effect (e.g. Sun’s Benediction "Half healing only"; Veil Severing "The portal lasts for 1 day"); Army of the Grave says "This result replaces the normal partial result". Where none is printed, m42 makes it the Failure line (Elemental Convergence: 2d6 to every caster). | **A Ritual spell's printed Partial takes effect, and no PP is lost** (the base Partial), Army of the Grave's included. Where no Partial is printed, the Failure line applies as m42 says, and still no PP is lost. Built with H13. |
| **Q172** | **A ritual with no secondary casters.** Elemental Convergence, Essence Reforging and Eternal Invocation print no "secondary casters" on their Cast line (M42 asked; the answer covered only the damage type). The core refuses any ritual without one. The Appendix: "They require extended time, multiple participants, or costly materials". | **The primary may perform those three alone** (with no overcasting room). Secondaries may still join, for the core's bonuses and room. The other seven need at least one. Built with H14. |
| **Q173** | **"Participants" and "all casters".** Sun’s Benediction: "Up to 6 participants regain 2d8+3 HP" (+6 PP: "affect up to 20 creatures", more than a ritual's seven casters). Echoed Shadows: "Participants gain advantage on Stealth checks". Call of the Ancestors: "one participant gains advantage". Rite of Binding Oath: "Participants swear a binding oath" (Targets: up to 10 willing creatures). Failure lines: "all casters suffer …". | **"All casters"** = the primary and every secondary. **"Participants"** = the casters plus any willing creatures taking part in the rite inside its area, ticked in the ritual dialog, up to the printed number (Sun’s Benediction 6, or 20). For Rite of Binding Oath, the participants are its targets. |
| **Q174** | **When a Cost is paid.** "**Cost** … worth 250 gp, consumed." (Sun’s Benediction); "worth 100 gp per PP, buried in the ground" (Concord); "Gemstones worth 200 gp x the targets level" (Essence Reforging). Is it spent on every attempt, or only when the ritual succeeds? | **On every attempt, when the ritual check is rolled, whatever its degree** (the rite consumes its offering), as Block 2b's Ritual Censor incense is. The ritual is refused before the roll if the purse is short. Concord's 100 gp is per PP as cast, warps included. |
| **Q175** | **Army of the Grave's undead.** "The total combined levels of undead created cannot exceed the number of PP expended"; "Skeletons and zombies may be raised freely" (core Animate Dead: "a 0-level Skeleton or Zombie"); "one intact corpse per 2 PP spent"; "commanded with a single sustain action" (the spell is not sustained; m98 "amended", text unchanged); Partial "Half rise under control … half are uncontrolled". | **One undead per corpse**, so at most PP ÷ 2 of them. Their levels total no more than the PP (halved per creature with the +4 PP warp). Level 0 counts 0 toward that total and toward control levels. **Command:** one 1 AP command (auditory, concentrate) gives all of them the same action. **Partial:** half, rounded down, are controlled (m128); the GM picks which. |
| **Q176** | **Essence Reforging's resurrection and race change.** "Restore life to a recently slain creature (as Resurrection)." Core Resurrection targets "1 dead creature of 12th level or lower", dead "no longer than 7 days", and leaves it with 1 HP, 0 PP, injured 2 for a week, and its Death State 1 lower. "Change a creature’s race" has no procedure. | **"As Resurrection" carries its effects and limits,** except the 12th-level limit and its own Cost: dead no longer than 7 days; 1 HP, 0 PP; injured 2 for a week; Death State −1; a failed attempt cannot be retried. **Race change:** a card; the GM rebuilds the race (ability modifiers, racial abilities and racial feats) as for a new character of that race. |
| **Q177** | **"Spellcraft checks" — does that include casting checks?** Eternal Invocation: "Advantage on spellcraft checks" (and disadvantage for the opposed). Leyline Anchor: "+1-circumstance bonus to Power Recovery (Meditation) and Spellcraft checks." The core's casting check is a Spellcraft check ("you must make a Cast a Spell (Spellcraft) action"). | **Yes: casting checks and every other Spellcraft check**, rituals included. Advantage over a 1-mile area is strong, so this is asked rather than assumed. |
| **Q178** | **Chaos Shield.** "Allies gain resistance to wild surge backlash effects and roll twice, taking the preferred result, on any wild magic effect table." "Area effects caused by wild magic (including hostile spell warp effects) suffer a –2 penalty to DC’s." "Once per round, if a surge would occur within the aura, you may expend 2 PP as a reaction to nullify it entirely." The Wild Surge table has no backlash column. M36 was "corrected", but only "preferred" changed. | **"Allies" includes you.** "Resistance to wild surge backlash" = damage dealt by a Wild Surge row to a creature in the aura is halved. "Preferred" = the surging creature picks one of the two rows. The −2 applies to every save a Wild Surge row calls for. "Hostile spell warp effects" has no rule to point to, so nothing more is built for it. The nullify works on any surge that would happen inside, yours included, before the d100. |
| **Q179** | **Leyline Anchor.** "All high magic spells cast within the radius are treated as one PP lower." "The radius" (the 300 ft "of the caster"?). "Any other caster that attempts to tap the ley line" (Tap Ley Line only, or Channel too?). | **Payment only**, as Graham's Q93 ruled for discounts: the cast pays 1 PP less (minimum 1), and the casting DC, Save DC and cap read the PP as cast. **The radius** is the 300 ft around the caster, moving with them. **Tap and Channel Ley Line** both need the Power Manipulation check; a failure stops the attempt and spends its action. |
| **Q180** | **Mimic Spell's imprint.** "**Critical** … When you do, you may also choose new targets and adjust the metamagic if you know them." "**Success** … You may cast it on your next turn only." Nothing says whether the imprint keeps the original's warps and metamagic, or whose targets a Success uses. A specialist spell is cast at Very Easy with a cap of character level, by its owner. | **The imprint is the spell as cast**, at its PP (warps and metamagic included), paid from your PP. **Success:** the original targets, or those of them still in range. **Critical:** any targets, and add or drop metamagic you know. You cast it as an ordinary spell, with your casting check, Save DC and cap. A **specialist spell** is cast as a non-specialist spell (Moderate, cap caster level + 1). A Ritual-trait spell cannot be cast from an imprint. |
| **Q181** | **Soul Confluence.** "All participants share HP equal to the sum of their Constitution modifiers × 5. Damage is subtracted from this shared pool first." "At the end of the spell, all participants suffer 1d6 Soul Drain per 2 rounds the spell lasted." Area: 30-foot emanation; Target: willing allies. | **The participants are you and the willing allies in the emanation at the cast.** The link holds for the spell, wherever they go. The pool is made once and does not refill. Damage to any participant comes off it before that participant's own HP, until it is empty. A negative modifier lowers the pool (minimum 0). Each participant takes the backlash for the rounds the spell lasted, rounded down. |
| **Q182** | **Storm of Unmaking's fumble.** "If you fumble or blunder the casting of this spell, as well as the normal rules for spell failure, storm appears above you and follows you wherever you go." For how long, does it strike you, and at what DC? | **The storm, as if cast:** a 60-ft radius centred on you, moving with you, for the spell's 1 minute, striking at once and at the start of each of your turns. Everyone in it saves against your Save DC, you included, after the failure's PP loss and fumble roll. Built with H16. |
| **Q183** | **"Can only be removed with a Remove Curse spell"** (Symbols of Pain and Weakness). Does that stop other relief of the same injured or weakened value (Sun’s Benediction's reduction, rest, recovery)? Core Remove Curse "attempt[s] to counteract one curse", but has no effect rows today. | **Yes: while the hold lasts, nothing but Remove Curse reduces or ends it.** Remove Curse counteracts it against the symbol's PP (as for any curse). Each new flash's worse result replaces a better one. Built with H17 (the hold, and core Remove Curse counteracting Curse-trait effects in every world). Without H17, it is a card line. |
| **Q184** | **Shipped content.** May Block 8 also (a) rebuild Symbol of Death and Symbol of Fear (0.5.0, the Rune birthright's) on the Symbol model, D to B; (b) move Versatile Binder (0.9.0) onto the Summons model, C to B; and (c) automate Ley Line Effects rows 25–27 from the control register? | **Yes, all three,** listed in the release notes. Copies already on sheets keep their old text until re-added from the pack. Nothing rewrites an owned item. |

## 9. Summary

**Grades (39 spells), with the seams:**

| Family | A | B | C | D |
|---|---|---|---|---|
| Summons (8) | 0 | 8 | 0 | 0 |
| Rituals (10) | 0 | 6 | 4 | 0 |
| High Magic tied to Chapter 7 (7) | 1 | 4 | 1 | 1 |
| Symbols (3) | 0 | 2 | 1 | 0 |
| Exploration and utility (11) | 0 | 1 | 6 | 4 |
| **Total** | **1** | **21** | **12** | **5** |

Without the seams: the Summons and Army of the Grave become C (control recorded by hand); the seven rituals with Partial lines lose their Partial (a card); the three lone-primary rituals need a stand-in secondary; Eternal Invocation's rest rates and Storm of Unmaking's turn strikes become card lines; Pain and Weakness become C. With Q184, the two shipped Symbols go from D to B and Versatile Binder from C to B.

The honest part: **five spells are descriptive** (Alter Corpse, Farsight, Phase Door, Rippling Gaze, Traveller’s Charm). The utilities' C grades are cards with one mechanical piece each (a conditional, a mark, a save, a Region). Nothing is shipped as automated that only posts text.

**Core seams for approval (7):** H12 the control register for modules; H13 a Ritual spell's Partial casts; H14 a ritual by its primary alone; H15 rest rates from an effect; H16 a rolled, turn-start, following storm; H17 conditions held by a curse, with core Remove Curse counteracting Curse effects; H18 core Insanity's turn table (optional).

**Questions (18, Q167–Q184).** The ones that change play most: **Q168** what a summoned creature does and what ending does; **Q170** which long durations lock PP; **Q171** a ritual's Partial; **Q169** "broken", commanding and the level limit; **Q177** whether "Spellcraft checks" include casting checks; then Q175 Army of the Grave, Q176 Essence Reforging, Q180 Mimic Spell.

**Module findings:** the extractor keeps "Cost" as a line; Bindings and Symbols must not take the core's cast-time save; true-name hostility and Versatile Binder must read the binding's own save; two spells carry TELEPORTATION but teleport no one; six v1.6 passages are still as they were before a "corrected" or "amended" ruling.

**Outside the Grimoire, still unbuilt:** Chapter 6's catalysts and special materials; Chapter 9's magic items; the relics and their bonding ritual; the Orb, Relic and Sentient traits (Blocks 9–10, as planned). Also the v1.6 Planes of Existence appendix (descriptive, missing from the v1.4 matrix; its languages are already in the core) and the planned `ea-rules` journal, which was never scheduled.

## 10. Plan

1. **Graham answers Q167–Q184** and approves H12–H18 (or a subset). H17's Remove Curse half and H18 change core spells in every world, so they are asked separately.
2. **Extractor:** add "Cost" to `LABELS`, re-cut `book-text.json`, re-verify Blocks 1–7.
3. **8a.**
   - TRG Prime 3.686.0: H12, H17, H18 with their harness pairs, the full sweep and an independent review.
   - Eldritch Arts 0.11.0: the 8 Summons, the 3 Symbols (and Q184's rebuilds), the 11 utilities; `verify-block8a` / `mutate-block8a`; the review.
   - Live test with tokens on a map: placing and binding creatures, control overflow, line of sight to a symbol, Harmonic Rift's passages.
4. **8b.**
   - TRG Prime 3.687.0: H13–H16, the same way.
   - Eldritch Arts 0.12.0: the 10 rituals and the 7 High Magic spells; `verify-block8b` / `mutate-block8b`; the review.
   - Live test: rituals with ticked participants and world-time durations; a Wild Magic area under Chaos Shield; an anchored ley line; Mimic Spell against a second client's cast; Storm of Unmaking's turn strikes.
5. **Then Block 9** (catalysts, special materials, magic items) and **Block 10** (relics). The `ea-rules` journal (with the Planes of Existence appendix) is to be scheduled, proposed with Block 10.
