# Eldritch Arts 0.11.1

9 November 2026. Two Harmonic Rift fixes from the live test of 0.11.0 in Graham's world (Foundry 14.367, TRG Prime 3.686.0). Install over 0.11.0. TRG Prime stays 3.686.0. No migration, no new settings, and no change to any pack.

## 1. A token walking out of an opening was sent through the rift

**What happened:** a foe ended a move in opening 2 and stepped out of opening 1, which was correct. On its next move it walked from opening 1 to a square well outside both openings, and was teleported to opening 2 again: a second Spatial Awareness card and a second 3d8 sonic save. In the same turn, moving out of an opening also posted "steps into the rift, but a second teleport this turn fails", twice.

**Why:** the passage asked whether the token was in an opening by reading `doc.regions`. In Foundry V14's `updateToken` hook, that set still lists the regions the token was in *before* the move.

**Now:** whether a move ends in an opening is decided only from the token's new position: its centre tested against the opening. Leaving an opening does nothing, and a token that ends its move in one still passes.

**A move paused partway** (found in review): Foundry V14 can split one move into several updates when something pauses it. The rift now waits for the update with no waypoints left to go (the same `movement.pending.waypoints` field TRG Prime reads), so a pause inside an opening no longer teleports the token mid-route.

**The other movement checks** (the curse's hour, Riserune's record, the symbols' glow) were checked. They measure distance from the token's new position and never read `doc.regions`, so they did not have the bug.

## 2. The rift's save line showed escaped HTML

**What happened:** the card printed "&lt;strong&gt;Failure&lt;/strong&gt;" instead of a bold **Failure**.

**Why:** the line TRG Prime builds for a basic save is already HTML, and the module escaped it a second time.

**Now:** it is used as built, as Blocks 2, 5b and 6b1 already do. No other core-built line in Block 8a was escaped; a check now guards that.

## Tests

- `verify-block8a` (345 checks) has these new checks:
  - A token that starts in an opening and moves out, with `doc.regions` still holding the opening, is not moved, gets no card and rolls no save (also when a teleport was already made that turn).
  - A token that moves into an opening still passes.
  - An update ending inside an opening with waypoints still pending does not pass; the final update does.
  - The save line on the card is the core's HTML, unescaped.
  - No `esc()` round a core-built line, and no `doc.regions` test, in Block 8a.
- `mutate-block8a` has three new mutations: the stale `doc.regions` test put back, the escape put back, and the pending-waypoints guard removed. All are caught.
- Run (9 November, on TRG Prime 3.686.0):
  - Every module `verify-*`, 21 files, 5,338 checks, 0 failures; every `mutate-*` in a scratch copy, 21 files, 2,139 mutations, all caught.
  - After the review's pending-waypoints guard: every module `verify-*` again, 21 files, 5,340 checks, 0 failures; `mutate-block8a` in a scratch copy, 140 mutations, all caught (one older anchor next to the guard re-pointed).
  - The core packs were restored with the usual routine after each run (`verify-pack-ids` green).
