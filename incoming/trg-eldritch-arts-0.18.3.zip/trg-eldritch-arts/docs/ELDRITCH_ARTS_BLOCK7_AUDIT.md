# Eldritch Arts Block 7: audit (Grimoire spells, first half)

7 November 2026. Block 7 is the first half of Chapter 8's Grimoire. This audit lists every Grimoire spell, proposes the Block 7 / Block 8 split, and audits the **42 Block 7 spells** one by one.

It was read against:
- ***TRG Prime: Eldritch Arts* v1.6** (`tools/content/book-text.json` `book.grimoire`, cut from `/home/claude/ea-src/v16/ea.md`; line numbers below are that file's);
- **the rules audit, Part B** (`ELDRITCH_ARTS_RULES_AUDIT.md`), and **Graham's answers to it** (*Responses to Audit Eldritch Arts*, 1 November 2026, `/home/claude/ea-src/responses/responses.md`, summarised in `ELDRITCH_ARTS_RULINGS_2026-11-01.md`), and his answers Q1–Q149;
- **TRG Prime 3.684.9**, surveyed in its source (`/home/claude/core-3676/trg-prime/module/magic/*`), and the core spells pack (dump in `/home/claude/ea-tools/core-dump/spells.json`) for the nearest core spell of each shape.

Nothing is built. Every rule below is quoted from the book or from a ruling.

**Status: answered and built.** Graham's answers of 7 November (04:38, below §8) and his 07:53 rulings on Dragon Wings and Spirit Arrow; built in Eldritch Arts 0.10.0 on TRG Prime 3.685.0 (`RELEASE_NOTES_0.10.0.md`).

## 1. The count: 87, not 86

`PROGRESS.md` says 86 Grimoire spells. That was v1.4. **v1.6 holds 87**: Graham added Dragon Wings (PP 6) in his M2 answer. The count was cross-checked against every "**NAME PP n**" heading between Chapter 8 and Specialist Spells in v1.6's `ea.md`: 87 headings, 87 entries in `book.grimoire`, no missing or extra names.

| | Spells |
|---|---|
| Grimoire, v1.6 | **87** |
| Already built | **6**: Orb of Water (0.2.0, the Tidemarked's cantrip); Dark Whispers, Message Rune, Observe the Weave, Symbol of Death, Symbol of Fear (0.5.0, for the birthrights) |
| Remaining | **81** |
| Proposed Block 7 | **42** |
| Proposed Block 8 | **39** |

**Specialist spells:** all 41 are built (Blocks 3a and 4, Ley Walker included). Block 8 has no specialist spells left to build. Its "remaining specialist spells" line in the architecture plan can be dropped.

## 2. All 87 Grimoire spells

"Family" marks the spells that share a subsystem. Tradition is as printed ("High Magic" where the spell prints none and carries HIGHMAGIC).

| # | Spell | PP | Line | Tradition | Family | Status |
|---|---|---|---|---|---|---|
| 1 | Acidic Burst | 4 | 6022 | arcane, verdant |  | **Block 7** |
| 2 | Air Bubble | 2 | 6042 | arcane, divinity |  | **Block 7** |
| 3 | Alter Corpse | 2 | 6058 | High Magic | High Magic | Block 8 |
| 4 | Animal Binding | 4 | 6076 | arcane, verdant | Summons | Block 8 |
| 5 | Animate Moustache | 2 | 6102 | arcane |  | **Block 7** |
| 6 | Arcane Bastion | 14 | 6118 | arcane |  | **Block 7** |
| 7 | Arcane Feedback | 14 | 6134 | arcane |  | **Block 7** |
| 8 | Arcane Mycelium | 6 | 6166 | arcane, verdant |  | **Block 7** |
| 9 | Arcane Pouch | 2 | 6194 | arcane |  | Block 8 |
| 10 | Archway of Ants | 4 | 6214 | verdant |  | Block 8 |
| 11 | Argent Mark | 2 | 6232 | all |  | Block 8 |
| 12 | Argent Reversal | 10 | 6254 | arcane, ethereal |  | **Block 7** |
| 13 | Army of the Grave | 20 | 6290 | arcane, divinity | Ritual | Block 8 |
| 14 | Blood Biography | 6 | 6328 | all |  | Block 8 |
| 15 | Bouncy Body | 2 | 6350 | arcane |  | **Block 7** |
| 16 | Brittleskin | 0 | 6368 | verdant | Cantrip | **Block 7** |
| 17 | Bubble Buffet | 4 | 6386 | arcane, ethereal |  | **Block 7** |
| 18 | Call of the Ancestors | 6 | 6416 | divinity, ethereal (see §6) | Ritual | Block 8 |
| 19 | Chaos Shield | 6 | 6446 | High Magic | High Magic | Block 8 |
| 20 | Chronoweave | 12 | 6468 | High Magic | High Magic | **Block 7** |
| 21 | Concord of Stone | 8 | 6486 | verdant | Ritual | Block 8 |
| 22 | Dark Whispers | 4 | 6516 | divinity, ethereal |  | Built, 0.5.0 (Block 3a, Umbral) |
| 23 | Decoherence | 0 | 6538 | arcane, ethereal | Cantrip | **Block 7** |
| 24 | Dragon Wings | 6 | 6554 | arcane, verdant |  | **Block 7** |
| 25 | Dragon’s Breath | 2 | 6580 | arcane, verdant |  | **Block 7** |
| 26 | Dreadmote | 0 | 6608 | divinity, ethereal | Cantrip | **Block 7** |
| 27 | Drearlight | 0 | 6626 | arcane, ethereal | Cantrip | **Block 7** |
| 28 | Eaog Balls | 18 | 6644 | arcane, verdant |  | **Block 7** |
| 29 | Eldritch Mantle | 10 | 6674 | arcane |  | **Block 7** |
| 30 | Elemental Binding | 6 | 6694 | arcane, verdant | Summons | Block 8 |
| 31 | Elemental Convergence | 14 | 6720 | arcane, verdant | Ritual | Block 8 |
| 32 | Elemental Strike | 2 | 6750 | arcane, verdant |  | **Block 7** |
| 33 | Entity Binding | 12 | 6772 | ethereal | Summons | Block 8 |
| 34 | Essence Reforging | 14 | 6798 | High Magic | Ritual, High Magic | Block 8 |
| 35 | Eternal Binding | 10 | 6818 | divinity | Summons | Block 8 |
| 36 | Eternal Invocation | 20 | 6844 | divinity | Ritual | Block 8 |
| 37 | Farsight | 8 | 6884 | all |  | Block 8 |
| 38 | Feltwarp | 0 | 6900 | arcane, verdant | Cantrip | **Block 7** |
| 39 | Fey Binding | 6 | 6918 | ethereal, verdant | Summons | Block 8 |
| 40 | Flesh to Blossom | 10 | 6944 | verdant |  | **Block 7** |
| 41 | Freshmark | 0 | 6974 | all | Cantrip | **Block 7** |
| 42 | Glyph of Retribution | 8 | 6990 | arcane, divinity |  | **Block 7** |
| 43 | Harmonic Rift | 12 | 7012 | arcane, ethereal |  | Block 8 |
| 44 | Invoke True Name | 0 | 7034 | all | Cantrip | **Block 7** |
| 45 | Leyline Anchor | 10 | 7052 | High Magic | High Magic | Block 8 |
| 46 | Leyline Burst | 4 | 7078 | High Magic | High Magic | **Block 7** |
| 47 | Mana Surge | 12 | 7098 | arcane |  | **Block 7** |
| 48 | Memory Eclipse | 8 | 7118 | High Magic | High Magic | **Block 7** |
| 49 | Message Rune | 2 | 7142 | arcane |  | Built, 0.5.0 (Block 3a, Rune) |
| 50 | Metamagic Resonance | 8 | 7156 | arcane |  | **Block 7** |
| 51 | Mimic Spell | 8 | 7184 | High Magic | High Magic | Block 8 |
| 52 | Mirror Reprise | 10 | 7210 | arcane |  | **Block 7** |
| 53 | Necrotic Whisper | 0 | 7234 | divinity, ethereal | Cantrip | **Block 7** |
| 54 | Observe the Weave | 16 | 7252 | arcane |  | Built, 0.5.0 (Block 3a, Arcanum) |
| 55 | Orb of Dusk | 0 | 7278 | arcane, ethereal | Cantrip | **Block 7** |
| 56 | Orb of Water | 0 | 7296 | arcane, verdant | Cantrip | Built, 0.2.0 (Block 1, Tidemarked) |
| 57 | Panic Transposition | 8 | 7314 | arcane, ethereal |  | **Block 7** |
| 58 | Phase Door | 14 | 7334 | arcane |  | Block 8 |
| 59 | Planar Anchor | 8 | 7358 | arcane, divinity |  | **Block 7** |
| 60 | Plant Binding | 6 | 7388 | verdant | Summons | Block 8 |
| 61 | Pledgeshroud | 2 | 7414 | arcane |  | **Block 7** |
| 62 | Primal Snap | 12 | 7432 | verdant |  | **Block 7** |
| 63 | Prismatic Guard | 18 | 7456 | arcane |  | **Block 7** |
| 64 | Reckoning Glance | 0 | 7490 | all | Cantrip | **Block 7** |
| 65 | Rippling Gaze | 10 | 7510 | arcane, verdant |  | Block 8 |
| 66 | Riserune | 2 | 7528 | arcane, divinity, ethereal |  | Block 8 |
| 67 | Rite of Binding Oath | 6 | 7544 | divinity, ethereal | Ritual | Block 8 |
| 68 | Rite of Echoed Shadows | 8 | 7578 | ethereal | Ritual | Block 8 |
| 69 | Spectral Aegis | 16 | 7610 | divinity, ethereal |  | **Block 7** |
| 70 | Spirit Arrow | 12 | 7634 | ethereal, verdant |  | **Block 7** |
| 71 | Soul Confluence | 10 | 7662 | High Magic | High Magic | Block 8 |
| 72 | Storm of Unmaking | 20 | 7678 | High Magic | High Magic | Block 8 |
| 73 | Sun’s Benediction | 4 | 7703 | divinity | Ritual | Block 8 |
| 74 | Symbol of Death | 16 | 7741 | arcane, divinity | Symbol | Built, 0.5.0 (Block 3a, Rune) |
| 75 | Symbol of Fear | 12 | 7767 | arcane, divinity | Symbol | Built, 0.5.0 (Block 3a, Rune) |
| 76 | Symbol of Insanity | 16 | 7791 | arcane, divinity | Symbol | Block 8 |
| 77 | Symbol of Pain | 12 | 7807 | arcane, divinity | Symbol | Block 8 |
| 78 | Symbol of Weakness | 14 | 7831 | arcane, divinity | Symbol | Block 8 |
| 79 | Traveller’s Charm | 8 | 7859 | arcane, verdant |  | Block 8 |
| 80 | Undead Binding | 8 | 7877 | arcane, divinity, ethereal (see §6) | Summons | Block 8 |
| 81 | Veilfracture | 10 | 7903 | High Magic | High Magic | Block 8 |
| 82 | Veil of Mist | 8 | 7917 | arcane, verdant |  | **Block 7** |
| 83 | Veil Severing | 18 | 7937 | arcane, ethereal (see §6) | Ritual | Block 8 |
| 84 | Wall of Sand | 8 | 7975 | verdant |  | Block 8 |
| 85 | Word of Pain | 10 | 7995 | arcane, ethereal |  | **Block 7** |
| 86 | Wyrm Binding | 12 | 8021 | arcane | Summons | Block 8 |
| 87 | Zone Disruption | 14 | 8047 | arcane, ethereal |  | **Block 7** |

## 3. The split, and why

**Block 7 (42): the spells that run on the core's ordinary spell model.** Cantrips, attack and save spells, area spells, wards, buffs and reaction spells. They need the spell item's own fields, the effect kinds the core already has, and a handful of small seams (§5). None needs a new subsystem.

| Group | Spells |
|---|---|
| **Cantrips (10)** | Brittleskin, Decoherence, Dreadmote, Drearlight, Feltwarp, Freshmark, Invoke True Name, Necrotic Whisper, Orb of Dusk, Reckoning Glance |
| **Attack, save and area spells (18)** | Acidic Burst, Animate Moustache, Arcane Feedback, Arcane Mycelium, Bubble Buffet, Dragon’s Breath, Eaog Balls, Elemental Strike, Flesh to Blossom, Glyph of Retribution, Leyline Burst, Memory Eclipse, Planar Anchor, Primal Snap, Prismatic Guard, Spirit Arrow, Word of Pain, Zone Disruption |
| **Wards, buffs and reactions (14)** | Air Bubble, Arcane Bastion, Argent Reversal, Bouncy Body, Chronoweave, Dragon Wings, Eldritch Mantle, Mana Surge, Metamagic Resonance, Mirror Reprise, Panic Transposition, Pledgeshroud, Spectral Aegis, Veil of Mist |

**Block 8 (39): the subsystem families, and the exploration spells.**

| Group | Spells | Shared need |
|---|---|---|
| **Summons (8)** | Animal, Elemental, Entity, Eternal, Fey, Plant, Undead and Wyrm Binding | Conjured creatures, Control Levels, Block 2b's summoning circles and true names; unblocks Block 6's Versatile Binder |
| **Rituals (10)** | Army of the Grave, Call of the Ancestors, Concord of Stone, Elemental Convergence, Essence Reforging, Eternal Invocation, Rite of Binding Oath, Rite of Echoed Shadows, Sun’s Benediction, Veil Severing | Block 2b's ritual rules (D13); M30: the Success cap lifted; the Cost line |
| **High Magic tied to Chapter 7 (7)** | Alter Corpse, Chaos Shield (Wild Surge table), Leyline Anchor (ley line regions), Mimic Spell, Soul Confluence, Storm of Unmaking, Veilfracture | Block 2's High Magic, ley line and wild magic code |
| **Symbols (3)** | Symbol of Insanity, Pain, Weakness | The two Symbols built in 0.5.0; one model for the family (M57, m131–m135) |
| **Exploration and utility (11)** | Arcane Pouch, Archway of Ants, Argent Mark, Blood Biography, Farsight, Harmonic Rift, Phase Door, Rippling Gaze, Riserune, Traveller’s Charm, Wall of Sand | Mostly cards (C/D); they balance Block 8's heavy families |

Why this way:
- **Each family lands in one block.** The Summons, the rituals and the Symbols each share one model, so each is designed and tested once.
- **Block 7 unblocks shipped content.** Dragon’s Breath, Elemental Strike and Dragon Wings are granted by Block 6's Draconic and Elemental Pacts and Pact Boon, and by the Dragon birthright (M2). Their cards say "the spell arrives with the Grimoire" today.
- **Three High Magic spells stay in Block 7** (Leyline Burst, Memory Eclipse, Chronoweave). They are ordinary damage, save and buff spells. Block 2's High Magic (D1) already casts any spell with the HIGHMAGIC trait correctly. The other seven need Chapter 7's machinery.
- **Size.** 42 and 39. Block 8 has fewer spells but more design; Block 7 has more spells, most of them A or B.

## 4. What TRG Prime 3.684.9 already has for these spells

| Need | The core today | Gap |
|---|---|---|
| **The spell item** | `tools/content/builders.mjs` `spell()`: `ppCost`, `castAP`, `range`, `area`, `targets`, `duration`, `defence`, `baseDamage`, `damage {formula, type, persistent}`, `casterLevelMods`, `effects[]`, `warps[{ppCost, text, mods}]`, `sustained`, `areaTargeting`, `components`, `traits`. Block 3a's `build()` (`tools/content/block3-spells.mjs`) reads the book entry into it. | None. |
| **Uncommon** | `system.availability` "common/uncommon/rare" (`magic/repertoire.mjs` `spellAvailabilityTier`, L343): a warning on an automatic level-up pick, and the learning DC +2 (`learn-spell-workflow.mjs` L178). | **The builder never sets it**, and the six built Grimoire spells are "common". EA-m84 was answered "as proposed": every Chapter 8 spell is uncommon (§6, Q166). |
| **Cantrip scaling** | `magic/caster-level-mods.mjs`: "CL N+" recurs every N levels. A step adds damage dice, Save DC, attack, and (C9) secondary damage. | **A step cannot reach an effect row**: a DR, a bonus, a thorns die, a duration or an area (H2). |
| **Attack cantrips with a second type** | `secondaryDamage` and the CL step's `secondary` (C9, built for Orb of Water). | None. |
| **Areas and the caster** | Templates, `areaGrowth`/`areaOverride` warps (`warp-area.mjs`), `caster-in-area.mjs`, frozen membership, emanations that follow the caster (`emanation.mjs`). | None. |
| **Save ladders** | `saveLadder` (`save-ladder.mjs`): damage per rung, `criticalOn`, recurring rungs; condition rows by `onSave`. Missing rungs clamp to the harsher named rung, which is ruling m42. | None at the cast. |
| **Saves on a turn boundary** | `recurringLadder` (damage rungs only, for creatures in an area); `entryCheck` (a skill or save on entering or moving); `turnSave` (sustained areas); `conditionSave`; `lingering-damage`. | **No condition rungs on a turn-start area save, no turn-start entry check, no single-target ladder re-rolled each turn** (H3). |
| **Recurring damage** | The `recurring` condition: one value and type, dealt in the end phase until a flat check; a new rider replaces the old (`cast-workflow.mjs` ~L7213, ~L7884, `recurringAfterHit`). | One recurring condition at a time (Q150). |
| **Coldfire** | A core damage type (`combat/damage.mjs` `coldfireDefences`, 3.642.0): resisted only with both, weak to either. | None. **M40 is already the core's rule.** |
| **Conditions** | Fixated, slowed, dazed, weakened, quickened, immobilised, petrified, stunned, blinded, dazzled, frightened, concealed, flat-footed, suffocating (`conditions/registry.mjs`). | **Distracted** (sidebar 34, after L10708) is not a core condition, and no module can register one (Q157). |
| **Thorns** | `thorns` (`magic/thorns.mjs`): damage to a melee attacker that hits. A save may be printed (card) or rolled at a printed DC (`saveRoll`, 3.640.0). | **A spell's thorns cannot roll at the caster's Save DC**: with no printed DC the roll uses the defender's Level DC (`thorns-workflow.mjs` L77). No damage + caster level, no condition ladder (H1). |
| **Defences** | `defence` rows: resistance, immunity, weakness, `valueChoices`, the `defenceField` warp (resistance → immunity). | None. |
| **0 HP** | Death guards (`combat/death-guard.mjs`, 3.627.0): "drop to 1 HP instead", by a `declare` row. | None. |
| **Critical injuries** | `registerCriticalReaction` (before the injury roll: disadvantage only). | **No lowered severity** (H7). |
| **Free warps** | `warpFreeSchool {school, value}`, with `school: "*"` for every spell (G25); `applyFreeWarp` waives the warp PP. | Whether the waived PP still raise the Save DC is to be confirmed (H9). |
| **Metamagic** | The core table (`magic/metamagic.mjs`) and module metamagic (G1, `module-metamagic.mjs`), grantable by an effect or a rod. | **No effect that lends one of the caster's metamagic options to another creature** (H9). |
| **Speeds and falls** | `speedGrant` (`feet`, `orLand`, `landFraction`); `fallReduction` rows (`focus-declarations.mjs` L319). | **No "land Speed + 10"** (H4). |
| **Regions** | `zone` (concealed, `obscuresOutward`), `difficultTerrain`, `hazard`, `light`, `entryCheck`; the module's own Region behaviours (Block 2: Ley Line, Wild Magic, Suppression areas, `module/areas.mjs`). | See H3, H8. |
| **Reactions** | `registerCastReaction` (after a cast's check: stop, scale, retarget the caster at its own DC; no Save DC in ctx yet, module-api L1574); `registerCheckReaction` (before/after a check; Missed Chance, Prophetic Warning); `registerDamageReaction` (Resist Magic, Phase Familiar); `registerSpellCheckGate` (rows on a casting check, before it is rolled; Inner Tempest's Spiritual Distraction). | **No "spare one target", no "turn it back at my DC"** (H5); **no "this hit is a miss"** (H6); **a gate cannot give disadvantage or force a check on an innate cast** (H8). |
| **Refusing a cast** | `registerCastRefusal`. | None (Planar Anchor). |
| **Strike riders** | `strikeRider` (Arrow of the Wild Hunt: once, ranged, dice added). | **A rider cannot replace the weapon's damage** (H10). |
| **A module's mark** | `moduleMark` (3.672.0) on a spell's target. | None (Invoke True Name, Planar Anchor). |
| **Choices** | `damageTypeChoice` at the cast; Block 6 stores a Pact's chosen type on the feat. | None (a choice "when you first select this spell" is the module's, at item creation). |
| **Tradition "all"** | No core spell prints it, and no core code reads it. | Authored as the four traditions, "all" kept on the card (§6). |

## 5. The Block 7 spells

### 5.1 As printed (v1.6)

Abbreviations: S somatic, V verbal, M material, F focus. "(lost)" marks a Target line the extractor drops (§6).

#### Cantrips

| Spell (line) | Tradition · traits | PP · cast | Range · area · targets | Defence · damage | Duration | Warps / CL |
|---|---|---|---|---|---|---|
| **Brittleskin** (6368) | verdant · Cantrip Warding Utility | 0 · 1 AP (V) | self | basic Fort (prose) · 1d4 piercing to a melee striker; base 1d4 | 1 round ("until the start of your next turn") | CL 4+: DR +1, +1d4 |
| **Decoherence** (6538) | arcane, ethereal · Cantrip Insight Utility | 0 · 2 AP (S, V) | 30 ft · 1 unattended object or magical aura | — | to the end of your next turn | CL 4+: +1 |
| **Dreadmote** (6608) | divinity, ethereal · Attack Cantrip Fear Soul | 0 · 1 AP (S) | 20 ft · 1 creature | spell attack · 1d4 essence; base 1d4 | — | CL 4+: +1d4 |
| **Drearlight** (6626) | arcane, ethereal · Cantrip Shadow Utility | 0 · 1 AP (V) | 20 ft · one object or 5-ft square | — | 1 minute | CL 4+: suppresses PP 4; CL 8 and every 4: +2 |
| **Feltwarp** (6900) | arcane, verdant · Alteration Cantrip Polymorph Utility | 0 · 2 AP (S, V) | touch · one object of fabric, leather or hide | — · +1 item to Sneak (Stealth) | 1 hour | CL 4+: +1 hour |
| **Freshmark** (6974) | all · Alteration Cantrip Utility | 0 · 2 AP (S, V) | touch · one object or 5-ft square | — | — | CL 4+: another object or area |
| **Invoke True Name** (7034) | all · Cantrip Enchantment Utility | 0 · 1 AP (V) | 30 ft · 1 creature whose true name you know | — | until the end of your turn | CL 8+: −4 |
| **Necrotic Whisper** (7234) | divinity, ethereal · Attack Auditory Cantrip Soul | 0 · 2 AP (S, V) | 30 ft · 1 living creature | spell attack · 1d4 essence + 1 secondary sonic | — | CL 4+: +1d4, +1 |
| **Orb of Dusk** (7278) | arcane, ethereal · Attack Cantrip Soul | 0 · 2 AP (S, V) | 60 ft · 1 creature | spell attack · 1d4 essence + 1 secondary cold | — | CL 4+: +1d4, +1 |
| **Reckoning Glance** (7490) | all · Cantrip Insight Utility | 0 · 2 AP (S, V) | 20-ft emanation | — | — | CL 4+: +20 ft |

#### Attack, save and area spells

| Spell (line) | Tradition · traits | PP · cast | Range · area · targets | Defence · damage | Duration | Warps |
|---|---|---|---|---|---|---|
| **Acidic Burst** (6022) | arcane, verdant · Acid Invocation Save | 4 · 2 AP (S, V) | 5-ft radius around you; "all creatures other than you" | basic Reflex · 3d6 acid; base 1d6 | — | +2 PP: +5 ft radius |
| **Animate Moustache** (6102) | arcane · Enchantment Save | 2 · 2 AP (S) | 30 ft · one moustache or eyebrow | Will · Distracted on a Failure | 1 minute | — |
| **Arcane Feedback** (6134) | arcane · Force Save Warding | 14 · R (V); trigger "an enemy within range declares a cast a spell action" | 30 ft | Will ladder · 2d8 / 4d8 / 4d8 + Minor / 8d8 + Serious force; base 1d8 | — | +2 PP: the critical one step worse (max deadly) |
| **Arcane Mycelium** (6166) | arcane, verdant · Alteration Save | 6 · 2 AP (F, S, V) | 60 ft · 10-ft radius | Reflex on entering or starting a turn · slowed 1 / slowed 2 | 1 minute | +2 PP: a creature in it that casts takes 2d6 essence (basic Fort) |
| **Bubble Buffet** (6386) | arcane, ethereal · Olfactory Save Shadow | 4 · 2 AP (S, V) | 30 ft · 10-ft radius | Will, at the cast and each of your turns · distracted / fixated / + slowed 1 | 1 minute | +4 PP: 10 minutes |
| **Dragon’s Breath** (6580) | arcane, verdant · Elemental Save Uncommon | 2 · 2 AP (S, V) | 30-ft line (acid, electricity) or 15-ft cone (cold, fire, poison) | basic Reflex · 2d6 of the chosen type; base 1d6 | — | +1 PP: +1d6; +1 PP: line +10 ft (max 120) or cone +5 ft (max 60) |
| **Eaog Balls** (6644) | arcane, verdant · Alteration Force Save | 18 · 2 AP (S, V) | 60 ft · 1 creature | Fort ladder · speed, disadvantage, stunned 3, recurring force 1d6/2d6/3d6 | 1 minute (S) | +2 PP: 2d8 recurring coldfire "at the start of each of its turns" |
| **Elemental Strike** (6750) | arcane, verdant · Elemental Invocation Save Uncommon | 2 · 2 AP (S, V) | your weapon's reach, per Strike | basic Reflex · 1d6 + casting attribute, chosen type; base 1d6 | 1 minute | +4 PP: +1d6 |
| **Flesh to Blossom** (6944) | verdant · Acid Alteration Curse Poison Save | 10 · 2 AP (S, V) | 60 ft · 1 creature (lost) | Fort ladder, again each turn · 1d12 / 2d12 + immobilised / 4d12 + petrified; base 1d12 | Sustained (1 minute) | +2 PP: one more target within 30 ft |
| **Glyph of Retribution** (6990) | arcane, divinity · Rune Save Warding | 8 · 1 minute (M, S, V) | self | basic Fort · 1d6 sonic + 1 per CL (max +15) to a melee attacker that hits; base 1d6 | 10 minutes | +4 PP: 1 hour; +4 PP: acid, cold, electricity or fire "each time you are struck" |
| **Leyline Burst** (7078) | High Magic · Force Highmagic Save | 4 · 1 AP (S) | 30 ft · 1 creature or object (lost) | basic Reflex · 4d6 force, pushed 10 ft on a failure; base 1d6 | — | +1 PP: +1d6; +3 PP: a 10-ft burst on the target |
| **Memory Eclipse** (7118) | High Magic · Highmagic Mental Save | 8 · 2 AP (S, V) | 60 ft · 1 creature (lost) | Will (prose) · dazed 1 / dazed 2 / + frightened 2 | 10 minutes | +2 PP: one more target within 10 ft |
| **Planar Anchor** (7358) | arcane, divinity · Save Warding | 8 · 2 AP (S, V) | 60 ft · one creature (lost) | Will ladder · lasts 1 min / 10 min / 1 h; Fumble + slowed 1 | varies | +2 PP: a 20-ft burst; +4 PP: also invisible and incorporeal |
| **Primal Snap** (7432) | verdant · Air Cold Save Translocation Water | 12 · 2 AP (M, S) | 120 ft · 20-ft radius | basic Fort at turn start · 6d8 cold, −10 status to speed on a failure; base 1d8 | 1 minute | +1 PP: +1d8 |
| **Prismatic Guard** (7456) | arcane · Light Save Visual Warding | 18 · 2 AP (S, V) | 10-ft emanation; creatures in it at the cast | Fort ladder on an attacker · dazzled / blinded / permanently blinded | 10 minutes (D) | +1 PP: 1 hour; +2 PP: to the next daily preparation |
| **Spirit Arrow** (7634) | ethereal, verdant · Attack Fear Shadow | 12 · 2 AP (S, V) | touch · one arrow or bolt | the weapon's attack; Will vs your spell DC · 6d6 piercing "in place of" the arrow's; base 1d6 | 1 minute (until dispersed) | +2 PP: 10 minutes; +2 PP: one more arrow (max 5) |
| **Word of Pain** (7995) | arcane, ethereal · Auditory Mental Save Soul Word | 10 · 1 AP (V) | 30 ft · 1 creature | Fort ladder · weakened 1 (1 round) / 1 (1 min) / 2 (10 min) / 4 (1 h) | varies | +4 PP: a 20-ft radius |
| **Zone Disruption** (8047) | arcane, ethereal · Save Warding | 14 · 2 AP (S, V) | 60 ft · 20-ft radius | Will on first entering (a Critical ignores it) | 10 minutes | +2 PP: 40-ft radius; +2 PP: fumble table twice, the higher |

#### Wards, buffs and reactions

| Spell (line) | Tradition · traits | PP · cast | Range · area · targets | Defence · damage | Duration | Warps |
|---|---|---|---|---|---|---|
| **Air Bubble** (6042) | arcane, divinity · Air Translocation Utility | 2 · R (V); trigger "enters an environment where it can't breathe" | 60 ft · the triggering creature | — | 1 minute | — |
| **Arcane Bastion** (6118) | arcane · Force Utility Warding | 14 · 2 AP (S, V) | self | — · resistance to all damage | 10 minutes | +2 PP: the critical a further step lower (max 3) |
| **Argent Reversal** (6254) | arcane, ethereal · Utility Warding | 10 · 2 AP (S, V), then a reaction | self | Spellcraft vs the caster's Spell Save DC · Fumble 4d10, Blunder 8d10 essence (basic Fort) | 1 hour or until discharged | +2 PP: one more redirect (max 5); +2 PP: absorb it, regaining half its PP |
| **Bouncy Body** (6350) | arcane · Alteration Utility | 2 · 2 AP (S, V) | touch · 1 creature (lost) | — | 10 minutes | +2 PP: 1 hour |
| **Chronoweave** (6468) | High Magic · Highmagic Utility | 12 · 2 AP (S, V) | 20-ft emanation · willing allies (lost) | — · quickened | 1 minute | +2 PP: 10 minutes; +2 PP: enemies Fort, slowed 1 / 2, then immune |
| **Dragon Wings** (6554) | arcane, verdant · Alteration Morph Utility | 6 · 2 AP (S, V) | self | — · fly Speed = land Speed + 10 ft | 10 minutes | +2 PP: +10 ft (max +50); +2 PP: 1 hour; +6 PP: to the next daily preparation |
| **Eldritch Mantle** (6674) | arcane · Force Utility Warding | 10 · 2 AP (S, V) | self | basic Fort · 1d6 force to a melee striker; physical resistance | 1 minute | +2 PP: +1d6; +2 PP: 10 minutes; +10 PP: physical immunity |
| **Mana Surge** (7098) | arcane · Alteration Force Utility | 12 · 2 AP (S, V) | touch · 1 creature (lost), willing | — · its spells warped 1 PP free | 1 minute | +2 PP: 10 minutes; +4 PP: 2 PP |
| **Metamagic Resonance** (7156) | arcane · Alteration Aura Utility | 8 · 2 AP (S, V) | 30-ft emanation · willing allies (lost) | — | 1 minute (S) | five: see Q163 |
| **Mirror Reprise** (7210) | arcane · Shadow Utility Visual | 10 · 2 AP (S, V) | self | — · three duplicates after the first hit | 1 hour (D) | +2 PP: spell damage triggers it too; +2 PP: teleport 10 ft when a duplicate is destroyed |
| **Panic Transposition** (7314) | arcane, ethereal · Teleportation Translocation Utility | 8 · R (V); trigger "you are hit by a melee or ranged attack" | self · 30 ft | — | — | +2 PP: an unseen space (2d6 essence, basic Fort, if occupied); +4 PP: resistance to the attack; +4 PP: 60 ft |
| **Pledgeshroud** (7414) | arcane · Enchantment Mental Utility | 2 · 2 AP (S, V) | touch · one creature (lost) | — · −2 Deception when implying it | 1 hour | +2 PP: one more piece of information |
| **Spectral Aegis** (7610) | divinity, ethereal · Utility Warding | 16 · 2 AP (S, V) | 30 ft · one creature (lost) | — · resistance to all damage; absorbs 1 spell of 10 PP or lower | 1 hour (D) | +1 PP: one more spell; +1 PP: the PP limit +1; +1 PP: one more creature; +2 PP: to the next daily preparation |
| **Veil of Mist** (7917) | arcane, verdant · Air Translocation Utility Water | 8 · 3 AP (M, S, V) | 20-ft emanation on you | — · concealment, seeing out clearly | 1 minute (D) | +2 PP: 10 minutes; +4 PP: 1 hour |

### 5.2 The build

Grades are the matrix's: **A** full, **B** interactive (automated with a normal player or GM choice), **C** partial (one clause left to the table, said on the card), **D** descriptive. Each grade assumes the seams named in its row.

#### Cantrips

| Spell | Core model | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Brittleskin** | Self. `bonus` slot `dr` +1, until the start of your next turn. `thorns` 1d4 piercing on a melee hit, basic Fortitude at your Save DC. The CL step reaches both rows. | **A** | H1, H2 | EA-m99 (Base Damage added; the Saving Throw line is still missing, so the prose is read) |
| **Decoherence** | `heldBonus` (Guidance's shape): +1 circumstance, one-shot, offered as a tick on the next check to interact with, identify or suppress that object or aura (Identify Power, Recall Knowledge, Dispel, Disable Device); it lapses at the end of your next turn. CL step on the value. | **B** | H2 | EA-m103 settled |
| **Dreadmote** | Orb of Force's shape: `category: "attack"`, 1d4 essence, CL step 1d4 recurring. The 1 AP cast takes the multiple attack penalty (Graham, M39). FEAR adds no effect, as printed. | **A** | — | EA-M39 settled |
| **Drearlight** | `light` (dim, 10 ft) on the object or square. The suppression threshold by CL (2, 4, 6 at CL 8, +2 every 4 CL) is a card line: the core's own Darkness places no darkness (no effect rows), so there is nothing to suppress automatically. | **C** | — | EA-m105 settled |
| **Feltwarp** | A conditional: +1 item to Sneak (Stealth) "involving worn soft gear", a tick, on the creature wearing the item, for 1 hour (+1 hour per CL step). The look of the item is the table's. | **B** | H2 | Q165 |
| **Freshmark** | Card only. | **D** | — | EA-m109 |
| **Invoke True Name** | Offered only on a creature in the caster's true-name record (Block 2b). A `moduleMark` to the end of the turn. The module then answers: your spell attacks treat it as flat-footed (check reaction, `before`); −2 circumstance on its saves against your spells (check reaction, `before`, by `sourceUuid`); weakness to the first damage it takes from your spells this turn (damage reaction; to be confirmed that an answer may add a weakness). CL 8: −4. | **B** | H2 | EA-m111 settled (Duration line added); Q164 |
| **Necrotic Whisper** | Orb of Water's shape (C9): attack, 1d4 essence, `secondaryDamage` 1 sonic, CL step {1d4, secondary 1}. "Living" is a card line. | **A** | — | EA-R11 settled (AUDITORY) |
| **Orb of Dusk** | As Necrotic Whisper: 1d4 essence, 1 secondary cold, 60 ft. | **A** | — | EA-m119 settled |
| **Reckoning Glance** | Card only. | **D** | — | EA-m124 |

#### Attack, save and area spells

| Spell | Core model | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Acidic Burst** | Burning Hands' shape: `category: "save"`, basic Reflex, 3d6 acid, area a 5-ft emanation on you; the caster is not caught (`caster-in-area.mjs`); warp `areaGrowth` 5 ft. | **A** | — | EA-M32 (tradition added), EA-R8 (3d6 and the warp) settled |
| **Animate Moustache** | Will; Distracted for 1 minute on a Failure or worse (Partial clamps to Failure, m42). Distracted as in Q157. | **A** | — | EA-m92; Q157 |
| **Arcane Feedback** | A module spell-check gate (Inner Tempest's Spiritual Distraction): when an enemy casts within 30 ft of a creature who knows the spell, its player is asked (`askReactor`). On yes it is cast as a reaction at the caster: `saveLadder` force with `criticalOn` (Failure Minor, Fumble Serious); the warp steps the critical. The gate's row is the damage dealt, as a penalty to the casting check (`castingOnly`). | **B** | — (to confirm: a gate may await the reactor's cast) | EA-m93; Q158 |
| **Arcane Mycelium** | `difficultTerrain`; `light` (dim); `entryCheck` with a Reflex save: Failure slowed 1, Fumble slowed 2, to the end of the creature's next turn; the same save at the start of a turn in it (H3). The warp: the module's spell-check gate in the Region rolls a basic Fortitude for 2d6 essence. The colour is a card line. | **A** | H3 | EA-M34 settled (Partial now clamps to Failure, m42) |
| **Bubble Buffet** | A Region. The ladder is rolled at the cast and at the start of each of your turns for everyone in it (H3): Success distracted to the end of its next turn; Partial distracted for the duration; Failure fixated; Fumble fixated and slowed 1. m100 "as proposed": a creature that failed does not save again; a later worse result replaces a better one. | **A** | H3 | EA-m100 settled; Q157 |
| **Dragon’s Breath** | The type is chosen when the spell is learned (module, on the item's creation); a Draconic Pact grant takes the Pact's stored type. The choice writes `damage.type`, the area (line or cone) and the type's trait (m104). Warps `damageDice` 1d6 and `areaGrowth` with its maximum. Blood of the Wyrm's G15 warp still applies. | **A** | — | EA-m104 settled; EA-m84 |
| **Eaog Balls** | `saveLadder`: Critical speed halved to the end of its next turn; Success speed halved and disadvantage on attacks until the spell ends; Failure speed 0 and disadvantage on attacks and skill checks; Fumble stunned 3 and immobilised. Recurring force per rung (the core's ladder rows). Coldfire is the core's type. "Automatically fail any Strength or Dexterity based checks", the cracking ground and dispelling at disadvantage (`registerDispelModifier`, to be checked) are card lines. | **C** | — | EA-M40 settled; **Q150** |
| **Elemental Strike** | The type is chosen when learned (an Elemental Pact grant: air → electricity, earth → acid, fire → fire, water → cold, as Block 6). The cast grants an "Elemental Strike" ability for 1 minute (`grantAbility`). Its Use (1 AP) picks a creature in your weapon's reach and rolls its basic Reflex at the Save DC stamped at the cast (`basicSaveHit`): 1d6 + casting ability (+1d6 per warp), no multiple attack penalty. | **B** | — | EA-M41 rewritten; **Q155** |
| **Flesh to Blossom** | `damageTypeChoice` (acid, poison) at the cast; `saveLadder` 1d12 / 2d12 + immobilised / 4d12 + petrified; the save again at the start of each of the target's turns while sustained (H3); warp `extraTargets`. Remove Curse ends it (a card line: the core's Remove Curse counteracts curses). | **B** | H3 | EA-M44 rewritten; **Q156** |
| **Glyph of Retribution** | `bonus` defence +2 status; `thorns` 1d6 + caster level (max +15) sonic on any melee hit, basic Fortitude at your Save DC. The type warp: you are asked the type each time you are struck (a damage reaction). | **B** | H1 | — |
| **Leyline Burst** | `category: "save"`, basic Reflex, 4d6 force; `forcedMove` 10 ft away on Failure and Fumble (Gust's row); warps `damageDice` and `areaOverride` (a 10-ft burst on the target). High Magic through D1. | **A** | — | EA-m112 settled |
| **Memory Eclipse** | Slow's shape: condition rows by rung (dazed 1 for 1 round; dazed 2 for 10 minutes; plus frightened 2); warp `extraTargets`. "Forgets the last minute" and "treats all creatures as potential threats" are card lines. Will is read from the prose. | **A** | — | EA-M29, EA-M46 settled |
| **Planar Anchor** | A `moduleMark` for the rung's duration (1 minute / 10 minutes / 1 hour; Fumble also slowed 1 for 1 minute). `registerCastRefusal` refuses a Teleportation-trait or planar-travel spell cast by or on the anchored creature: "automatically counteracted" (m121 as proposed). The +4 PP warp refuses Invisibility-type and incorporeal spells the same way. Abilities that teleport: card. | **B** | — | EA-m121 (the broken sentence is still in v1.6; built as proposed) |
| **Primal Snap** | Solid Fog's `zone` (concealed both ways); a turn-start basic Fortitude for 6d8 cold in the Region (`hazard` / `area-save-workflow`); on a Failure or worse, −10 status to Speeds until it regains HP (H11). Moving the fog: the Region is moved on a Sustain, as Solid Fog's note. | **B** | H11 | EA-M52 settled; EA-m123; **Q160** |
| **Prismatic Guard** | Membership frozen at the cast. `defence` resistance to acid, cold, electricity, fire, sonic, essence and force (M53), immunity to blinded and dazzled. Retaliation: `thorns` with a condition ladder, Fortitude at your Save DC (H1). Warps `durationText`. | **A** | H1 | EA-M53 settled; EA-R14 left |
| **Spirit Arrow** | `strikeRider`, ranged, once per arrow (Arrow of the Wild Hunt's shape), replacing the ammunition's damage with 6d6 piercing (H10). After the hit the module asks the attacker for Feint, Grapple (1 round), Shove or Trip, resolved at the attack total, and rolls the target's Will at your spell DC: frightened half the margin, rounded down (m128). | **B** | H10 | EA-m128; Q161 |
| **Word of Pain** | Word of Fatigue's shape: four `condition` rows (weakened) with their durations; warp `areaOverride` 20-ft radius. "Effects" for "affects" is left as printed. | **A** | — | EA-M58 settled |
| **Zone Disruption** | A module Region (as Block 2's Suppression areas), with a Will save on a creature's first entry; a Critical exempts it. For the others: Spellcraft at disadvantage (H8), +2 to Spell Concentration and Sustain DCs (H8), innate spells need a Spellcraft check (H8). The fumble warp: `registerFumbleModifier` bias "disadvantage" (G5: the higher roll). | **B** (C without H8) | H8 | EA-M59, EA-R15 settled; EA-m140; **Q154** |

#### Wards, buffs and reactions

| Spell | Core model | Grade | Seam | Audit · Q |
|---|---|---|---|---|
| **Air Bubble** | Cast from the sheet as a reaction when the table says the trigger happened. A "breathes normally" marker (Water Breathing's shape) and suffocating removed (`conditionRemove`). Ending early on breathable air: by hand. | **B** | — | — |
| **Arcane Bastion** | `defence` resistance to all damage; a `declare` death guard: "drop to 1 HP instead", then the spell ends; the critical step (H7), a further step per warp (max 3). | **B** | H7 | EA-M33 ("corrected", but the clause is unchanged in v1.6); **Q151** |
| **Argent Reversal** | The cast leaves a charge (1 hour). A module cast reaction offers it on a spell the bearer can see, of PP no greater than the bearer's maximum PP per cast. Spellcraft against that cast's Save DC (H5 supplies it). Critical or Success: turned back on its source, or on a Critical on another creature in its range, at the bearer's check and Save DC (H5). Fumble and Blunder: basic Fortitude, 4d10 / 8d10 essence. The absorb warp spares the bearer (H5) and restores half the spell's PP (module). Magical abilities: card. | **B** | H5 | EA-m97 left; **Q153** |
| **Bouncy Body** | A conditional +2 circumstance on Escape and grapple checks (auto); a `fallReduction` row of 20 ft on the effect (to check that a spell effect is a carrier). The bounce (Acrobatics, DC = feet fallen + 10, up half the fall): card. | **B** | — | — |
| **Chronoweave** | An emanation: you and willing allies in it are quickened, the extra AP unrestricted (Graham, M37). The warp: each enemy saves once (Fortitude; Failure slowed 1, Fumble slowed 2), then is immune to that casting (`tempImmunity`). | **A** | — | EA-M29, EA-M37 settled; Q159 |
| **Dragon Wings** | `speedGrant` fly = land Speed + 10 ft (H4); warp `bonusValue` 10 (max 50); `durationText`. On its end while airborne the card says you fall (`rollFalling`, C5). | **A** | H4 | M2 (added); unblocks Block 6's cards |
| **Eldritch Mantle** | Stoneskin's `defence` resistance physical, with the warp `defenceField: "immunity"`; `thorns` 1d6 force, basic Fortitude at your Save DC, a die per warp; `durationText`. | **A** | H1 | EA-m106 |
| **Mana Surge** | `warpFreeSchool {school: "*", value: 1}` (2 with the warp) on the willing target (G25). No casting DC; the Save DC rises "as normal" (H9 to confirm). Cantrips cannot be warped (core). | **A** | H9 (confirm) | EA-m113; Q162 |
| **Metamagic Resonance** | At the cast, choose one metamagic you have. Willing allies in the emanation may apply it to one spell a round (H9), at full, half or no extra PP by the warps. The +2 PP duration warp removes "sustained" (Graham, M47). +6 PP replaces +3 PP (m114). | **B** (C without H9) | H9 | EA-M47, EA-m114; Q163 |
| **Mirror Reprise** | Armed at the cast. The first damage from an attack (damage reaction; with the warp, from a hostile spell too) makes three images. Each later attack on you rolls d100: 26+, 34+ or 51+ for 3, 2 or 1 images turns the hit into a miss and destroys an image (H6). The teleport warp uses the module's point pick (Gale Step). | **B** (C without H6) | H6 | EA-m116 |
| **Panic Transposition** | A module check reaction `after` the hit (Missed Chance's seam). The resistance warp is a damage reaction on that attack (Resist Magic's shape). The teleport follows the damage (Gale Step's point pick; 30 or 60 ft); an occupied unseen square: nearest safe square, basic Fortitude 2d6 essence. | **B** | — | EA-M50 settled |
| **Pledgeshroud** | Card; a conditional −2 to Deception when hinting at the secret (a tick). Willing only (M43, M51). | **C** | — | EA-M51, EA-m122 |
| **Spectral Aegis** | `defence` resistance to all damage on the target. The absorb: a module cast reaction on a hostile spell of 10 PP or lower (+1 per warp) that includes the target: a single-target spell is stopped; an area spell spares the target (H5). Then the Aegis and its resistance end. Warps: absorbs, PP limit, `extraTargets`, `durationText`. | **B** | H5 | EA-M55 left; **Q152** |
| **Veil of Mist** | An emanation that follows you, with `zone` concealed and `obscuresOutward: false` (they see out clearly); `durationText`. | **A** | — | — |

## 6. Module-side findings (no ruling needed unless noted)

- **The extractor drops "Target".** `extract-book.mjs`'s `LABELS` lists "Targets" but not "Target". A field line such as "**Range** 60 feet; **Target** 1 creature" keeps the Range and loses the Target text. It is in neither `fields` nor `lines`, so it would be missing from the card. 16 lines in v1.6 are affected:
  - Block 7 (10): Bouncy Body (L6358), Chronoweave (L6474), Flesh to Blossom (L6952), Leyline Burst (L7084), Mana Surge (L7106), Memory Eclipse (L7124), Metamagic Resonance (L7164), Planar Anchor (L7366), Pledgeshroud (L7422), Spectral Aegis (L7618).
  - Block 8 (5): Leyline Anchor (L7058), Mimic Spell (L7190), Riserune (L7536), Soul Confluence (L7668), Traveller’s Charm (L7867).
  - **Already shipped (1): Paradox Weave** (L8525, "**Target** 1 willing creature"), built in 0.5.0. Its card lacks that line, and its spec sets "1 creature".
  - **Fix:** add "Target" (and "Requirement", lost from Rippling Gaze, L7518) to `LABELS`, re-cut `book-text.json`, and have `verify` check that every bold label in an entry reaches `fields` or `lines`.
- **The bold-comma Tradition lines (EA-m127, still in v1.6)** cut the tradition at the comma. Call of the Ancestors (L6420) reads "divinity", not "divinity, ethereal"; Undead Binding (L7881) reads "arcane", not "arcane, divinity, ethereal"; Veil Severing (L7941) reads "arcane", not "arcane, ethereal". All three are Block 8, and the same extractor fix covers them.
- **Uncommon.** EA-m84 was answered "as proposed": the module flags every Chapter 8 spell. The core field is `system.availability: "uncommon"`. The six built Grimoire spells carry nothing (Q166).
- **Tradition "all"** (Argent Mark, Blood Biography, Farsight, Freshmark, Invoke True Name, Reckoning Glance) is authored as "arcane, divinity, ethereal, verdant", and the card prints "all". No core code reads "all".
- **High Magic spells** carry no tradition and no school (M29, now in v1.6). D1 casts them (casting DC +2, armour DR ×4, the book's fumble and Resonance), and M27 lets a non-High-Magic caster learn one at Very Hard and cast it at Hard.
- **Missing rungs** fall back as ruling m42 says, which is how the core's ladders already clamp: Arcane Mycelium, Animate Moustache and Argent Reversal print no Partial, so a Partial is a Failure there.
- **Defaults from the rulings:** M43 and M51 mean a Utility spell affects willing targets only (Bouncy Body, Mana Surge, Pledgeshroud, Chronoweave). m128 means round down unless stated. C3 gives the default DC where none is printed.

## 7. Proposed seams (TRG Prime, for Graham's approval)

As before, each is prepared separately, additive and default-off, with its own `verify`/`mutate` pair.

| # | Seam | Core file / function | Used by |
|---|---|---|---|
| **H1** | **Spell thorns at the caster's Save DC.** A `thorns` row may say `save: {key, dc: "spell"}`; the cast stamps its Save DC on the effect. Also: damage "+ caster level, max N", and a condition ladder in place of damage. | `magic/thorns.mjs` `normaliseThorns`; `magic/thorns-workflow.mjs` (L73–88: the DC falls back to the defender's Level DC); `magic/spell-effects.mjs` case `"thorns"` (L3381) | Brittleskin, Eldritch Mantle, Glyph of Retribution, Prismatic Guard |
| **H2** | **Caster-level steps on effect rows.** A `casterLevelMods` entry may name a row and add to its value, dice, duration or area, once per step. | `magic/caster-level-mods.mjs` (today: damage dice, Save DC, attack, secondary); `magic/spell-effects.mjs` | Brittleskin, Decoherence, Feltwarp, Invoke True Name |
| **H3** | **Saves on a turn boundary:** (a) an `entryCheck` that also asks at the start of a turn in the area; (b) an area ladder with condition rungs, rolled at the start of each of the caster's turns for everyone in it; (c) a single target's ladder rolled again at the start of each of its turns while the spell is sustained, the new rung replacing the old. | `magic/entry-check.mjs` `normaliseEntryCheck`, `entry-check-workflow.mjs`; `magic/save-ladder.mjs` `normaliseRecurringLadder` (damage rungs only, L374–413), `recurring-ladder-workflow.mjs`; `magic/condition-save.mjs` / `turn-save.mjs` | Arcane Mycelium, Bubble Buffet, Flesh to Blossom |
| **H4** | **A fly Speed of "land Speed + N"**, grown by a bonus warp. | `magic/spell-effects.mjs` `speedGrant` / `normaliseGrantedSpeed` (`feet`, `orLand`, `landFraction` only) | Dragon Wings |
| **H5** | **Cast-reaction shapes:** `exclude: [targetUuid]` (the cast lands on everyone else); `turnBack: {checkTotal, saveDC, target}` (the spell resolves against its source, or another creature in range, at the reactor's result and DC); and the cast's Save DC in the reaction's ctx. | `magic/cast-reaction-shape.mjs`; `magic/cast-workflow.mjs`; `module-api.mjs` `registerCastReaction` (L1570: "no Save DC exists yet when the reactions are asked") | Spectral Aegis, Argent Reversal |
| **H6** | **A hit made a miss by a check reaction:** an `after` answer `{miss: true, line}` on an attack check. It would also let the core's own Mirror Image, a note today, be automated. | `module-api.mjs` `registerCheckReaction`; the attack path in `combat/attack-workflow.mjs` | Mirror Reprise |
| **H7** | **A lowered critical severity:** a critical reaction after the injury roll may answer `{severitySteps: -n}`. The same d100 is read one table lower, and below Minor there is no injury. | `module-api.mjs` `registerCriticalReaction` (L1601: before the roll, disadvantage only); `combat/critical-*.mjs` | Arcane Bastion |
| **H8** | **Zone casting rules:** a spell-check gate may answer `disadvantage: true`; a gate may make an innate cast roll a Spellcraft check against 10 + ⌊1.5 × PP⌋; a Region may add +2 to Spell Concentration and Sustain DCs. | `magic/spell-check-gates.mjs` (rows and lines only); `magic/cast-workflow.mjs` (`rollsCheck` false for innate casts); `magic/casting-dc.mjs`; `magic/sustain.mjs`, `magic/defensive-casting.mjs` | Zone Disruption |
| **H9** | **Lent metamagic, and the free warp's Save DC:** an effect that names one of the caster's metamagic options (core table or G1) which its bearer may apply once a round, at a cost factor of 1, ½ or 0. Confirm, and if needed make, waived free-warp PP still raise the Save DC. | `magic/metamagic.mjs`, `magic/module-metamagic.mjs`; `magic/granted-warps.mjs`, `magic/spell-warp.mjs` `applyFreeWarp` | Metamagic Resonance; Mana Surge |
| **H10** | **A strike rider that replaces the weapon's damage** (`replacesDamage: true`). | `magic/strike-riders.mjs` | Spirit Arrow |
| **H11** | **An effect that ends when its bearer regains HP.** Module-side instead if the core's healing path emits a hook the module can read. | `magic/effect-duration.mjs`; the healing path | Primal Snap |

**To be confirmed in the build** (seams only if the check fails): a spell-check gate may await a reactor's cast (Arcane Feedback); a damage reaction may add a weakness (Invoke True Name); `registerDispelModifier` may bias the dispel check (Eaog Balls); a spell effect is a `fallReduction` carrier (Bouncy Body).

## 8. Rulings that already settle Block 7 points

| Ruling | Settles |
|---|---|
| **M29** school traits removed from High Magic spells | Chronoweave and Memory Eclipse print no school in v1.6 |
| **M32**, **R8** | Acidic Burst: Tradition arcane, verdant; 3d6; +2 PP for +5 ft |
| **M34** "corrected" | Arcane Mycelium: "until the end of their next turn"; the SAVE trait |
| **M37** "this spell allows the AP to be used for anything" | Chronoweave's quickened is unrestricted |
| **M39** 1 AP, Base Damage 1d4, 20 ft | Dreadmote; the multiple attack penalty applies |
| **M40** persistent = recurring; coldfire per Fiends & Fables, else both fire and cold | Eaog Balls; the core's coldfire already follows it |
| **M41**, **M44** rewritten | Elemental Strike, Flesh to Blossom (v1.6 prints the rewrites) |
| **M43**, **M51** a Utility spell affects willing targets only | Bouncy Body, Mana Surge, Pledgeshroud, Chronoweave |
| **M46**, **M58**, **M59**, **R15** as proposed | Memory Eclipse's ladder; Word of Pain's durations; Zone Disruption's entry save; "the higher result" |
| **M47** the +2 PP option removes "sustained" | Metamagic Resonance |
| **M50** the trigger is being hit | Panic Transposition |
| **M52** | Primal Snap: AIR COLD SAVE TRANSLOCATION WATER |
| **M53** energy = acid, cold, electricity, fire, sonic, essence and force | Prismatic Guard |
| **M55**, **R14** leave | Spectral Aegis's power; Prismatic Guard's warp prices |
| **m42** missing rungs | Heroic → Critical, Partial → Failure, Fumble → Failure, Blunder → Fumble |
| **m84** as proposed | Every Grimoire spell is uncommon |
| **m100**, **m112**, **m113**, **m114**, **m121**, **m123**, **m128** | As in each row above |
| **M30** (rituals' Success cap lifted), **M31**, **M45**, **C4**, **C5**, **M54**, **M56**, **M57** | Block 8, not this block |

## Graham's answers (7 November 2026, 04:38)

- **Q150 (changed):** "recurring damage stacks with a flat check made for totals of the same damage type. Bleed is different for the flat check (only up to 4) but still stacks (or at least it should do)." So: recurring damage of the same type adds to one total, with one flat check for that type's total; each damage type is its own total with its own flat check; bleed stacks too, with its own flat-check rule. Eaog Balls' force and coldfire are two recurring damages of different types, each with its own flat check. This is a core rule (TRG Prime), applied everywhere recurring damage is dealt.
- **Q151–Q166:** "All the rest as proposed."
- **H1–H11:** approved (asked together with the questions; no exceptions given).

## 9. Rulings needed

Ordered by how much they change play. Each quotes v1.6.

| # | Question | Proposed |
|---|---|---|
| **Q150** | **Eaog Balls' recurring damage** (L6644). "**Success** … The target also takes 1d6 recurring force damage." "**+2 PP:** … the target suffers an additional 2d8 recurring coldfire damage at the start of each of its turns." The core's recurring damage is one condition, "dealt in its end phase until a flat check ends it", and a new rider replaces the old. So the coldfire would overwrite the force, it would land in the end phase rather than "at the start of each of its turns", and either could outlast the sustained spell. | **The force rung is the core's recurring damage** (end phase, flat check), and it also ends when the spell ends. **The coldfire is a separate packet** at the start of each of the target's turns while the spell lasts, not a recurring condition, so neither replaces the other; none on a Critical. |
| **Q151** | **Arcane Bastion's critical** (L6118). "If the effect of a critical injury grants you the dying condition or incapacitates you, the shield also shatters but lowers the severity of the critical by one step (negating a minor)." Whether it is dying or incapacitating is known only after the injury roll. You answered M33 "corrected", but the clause is unchanged in v1.6. | **After the roll:** if the injury would leave you dying or incapacitated, the same d100 is read one severity lower (Minor → no injury), and the spell ends. Each +2 PP lowers it a further step (max 3 in all). The 0 HP clause also ends the spell. Built with H7. |
| **Q152** | **Spectral Aegis: "the shield absorbs 1 spell cast at the target (of 10 PP or lower)"** (L7610). Do area spells count, or only spells that target it? Beneficial spells? You left its power alone (M55); this is only what counts. | **The first hostile spell of that PP or lower whose targets or area include the target.** A single-target spell is negated; an area spell spares only the target (H5). Beneficial spells pass. Then the Aegis, and its resistance, end. |
| **Q153** | **Argent Reversal's reach and DC** (L6254). "When a creature casts a spell or uses a magical ability that you are aware of (GM Discretion)" — no range is printed. "Make a Spellcraft check against the original caster's Spell Save DC." "you may only use Argent Reversal on spells or effects of equal or lower PP cost than the highest-level spell you can cast" (m97: leave). | **Any spell whose caster you can see; magical abilities by hand.** "Highest-level spell you can cast" = your maximum PP per cast. The DC is that cast's Save DC. A turned spell uses your check result and your Save DC, as printed. Partial is a Failure (m42). |
| **Q154** | **Zone Disruption's innate spells** (L8047). "Innate spells (including monster abilities) require a Spellcraft check using the innate ability modifier + level against the spell's normal casting DC." m140 asked whether the Warlock's innate spells count; v1.6 does not say. Nor does it say what a failed check does. | **Every innate spell cast inside, the Warlock's included.** Monster abilities count when they are innate spells; others by hand. The DC is 10 + ⌊1.5 × PP⌋. A failed check is a failed casting: the use is spent, nothing happens, and a Fumble rolls on the fumble table. |
| **Q155** | **Elemental Strike's strikes** (L6750). "As a 1 AP Strike against a creature within your weapon's reach, the target instead makes a basic Reflex save against 1d6 + casting attribute damage … (no weapon damage; does not count toward your multiple attack penalty)". For 1 minute: how many, and is it a Strike for other rules? | **Any number, 1 AP each, for the minute.** Each is a Strike for rules that count Strikes, but takes and adds no multiple attack penalty. The Save DC is fixed at the cast (warps included). Base Damage 1d6 adds to the critical. A melee weapon must be wielded. |
| **Q156** | **Flesh to Blossom's later saves** (L6944). "**Success** The target takes 1d12 damage and must make a new saving throw at the beginning of each of their turns if the spell is still active." "**Failure** … At the beginning of each of their turns, the target must make a new saving throw." What do the later results do? | **Each later save is a new result that replaces the last:** Critical ends the spell; Success 1d12 and immobilised ends; Failure 2d12 and immobilised; Fumble 4d12 and petrified. Petrified (Plant Form) is the core's petrified, and it ends with the spell or Remove Curse. Built with H3. |
| **Q157** | **Distracted** (sidebar 34, after L10708): "Whilst you have the condition, you take a -1 penalty to all actions." Which rolls, and what type? It is not a core condition, and a module cannot register one. | **−1 status to attack checks, skill checks, saving throws and casting checks;** not DB or damage. The module applies it as an effect named "Distracted" with those rows. Animate Moustache and Bubble Buffet use it. |
| **Q158** | **Arcane Feedback's rungs** (L6134). "**Success** The target takes 2d8 force damage which is immediately applied as a penalty to their casting check." "**Fumble** The target takes 8d8 force damage and a Serious Force critical." Does the Fumble's damage also count as the penalty? No Blunder is printed. And the trigger, "declares a cast a spell action", meets innate spells, which roll no check. | **Every damaging rung is a penalty of its damage.** Blunder is the Fumble (m42). An innate spell takes the damage, and no check means no penalty. Cantrips count. |
| **Q159** | **Chronoweave** (L6468). "You and all allies with the spells effect gain the Quickened condition." (Target: willing allies.) Is that the allies inside at the cast, or whoever is inside? The warp's slowed has no duration. | **Whoever is inside**, while inside, for the duration. **The warp:** slowed for the spell's duration while inside, one save per enemy per casting. |
| **Q160** | **Primal Snap's fog** (L7432). "a failed saving throw imposes a -10 status penalty to speed (until healed)." "You may Sustain this spell to move the fog". The Duration is "1 minute", not sustained. m123 offered two readings and you said "as proposed". | **It lasts 1 minute either way;** a Sustain (1 AP) moves it 10 ft. "Until healed" = until it regains any HP (H11). "Failed" = Failure or worse. The penalty does not stack with itself. |
| **Q161** | **Spirit Arrow's fear** (L7634). "become Frightened with a value equal to half the amount they failed the save by." Rounded down (m128), a margin of 1 gives 0. | **Minimum 1 on any failed save.** The 6d6 replaces the arrow's damage and doubles on a critical as weapon damage does. The attacker chooses the manoeuvre. Each arrow is spent when fired. |
| **Q162** | **Mana Surge** (L7098). "All spells that the target casts … are warped by 1 PP for free, without increasing the casting DC. The Save DC of the spell is increased as normal." Do the free PP count against the target's maximum PP per cast? | **The Save DC rises by the free PP; the cap does not count them.** Only the spell's own warps, not metamagic (as Resonance Surge, Q148). Cantrips cannot be warped. |
| **Q163** | **Metamagic Resonance** (L7156). "Choose one metamagic feat you possess … All willing allies within 30 feet may apply the chosen feat to one spell they cast per round". Must an ally meet the feat's own requirements? How is "half the extra PP" rounded? | **No requirements but the caster's;** the ally pays from its own pool; half rounds down (m128), minimum 0. Core and Eldritch Arts metamagic both count. |
| **Q164** | **Invoke True Name** (L7034). "**CL 8+:** The penalty increases to -4". Core cantrip steps recur, so this would be −6 at CL 16. And "flat-footed against your spells": spell attacks only? | **Once, at CL 8: −4.** Flat-footed applies to your spell attacks; the −2 (or −4) covers its saves. |
| **Q165** | **Feltwarp's bonus** (L6900): "granting +1 item bonus to Sneak (Stealth) checks involving worn soft gear". The target is the item. | **The creature wearing the item gets it, while worn.** |
| **Q166** | **Shipped content.** May Block 7's release also (a) mark the six built Grimoire spells uncommon (m84), and (b) restore Paradox Weave's lost "**Target** 1 willing creature" (§6)? | **Yes, both,** listed in the release notes. |

## 10. Summary

**Grades (42 spells):**

| Group | A | B | C | D |
|---|---|---|---|---|
| Cantrips (10) | 4 | 3 | 1 | 2 |
| Attack, save and area (18) | 9 | 8 | 1 | 0 |
| Wards, buffs and reactions (14) | 5 | 8 | 1 | 0 |
| **Total** | **18** | **19** | **3** | **2** |

The grades assume the seams. Without them, the spells that name a seam become C: the missing part is a card line.

**Core seams for approval:** H1 spell thorns at the Save DC; H2 caster-level steps on effect rows; H3 saves on a turn boundary; H4 fly = land + N; H5 cast-reaction exclude and turn-back; H6 a hit made a miss; H7 a lowered critical severity; H8 zone casting rules; H9 lent metamagic and the free warp's Save DC; H10 a rider that replaces weapon damage; H11 an effect that ends on healing.

**Questions:** 17 (Q150–Q166). Those that change play most: **Q150** Eaog Balls' recurring damage, **Q151** Arcane Bastion's critical, **Q152** what Spectral Aegis absorbs, **Q153** Argent Reversal's reach and DC, **Q154** Zone Disruption's innate spells; then Q155 Elemental Strike and Q156 Flesh to Blossom.

**Module findings:** the extractor drops "Target" on 16 lines, one of them in a shipped spell; three Tradition lines are cut at a bold comma; no Grimoire spell is flagged uncommon yet.

## 11. Plan

1. **Graham answers Q150–Q166** and approves H1–H11 (or a subset).
2. **Extractor fix** (Target, Requirement, bold commas), re-cut `book-text.json`, re-verify Blocks 1–6.
3. **TRG Prime** (next minor): the approved seams, each with its harness pair, the full sweep and an independent review.
4. **Eldritch Arts 0.10.0**: the 42 spells, the Distracted effect, the uncommon back-fill; `verify-block7` and `mutate-block7`; the review.
5. **Live test**, with tokens on a map (thorns, Regions, reactions and teleports all need one).
6. **Block 8** audit: Summons, rituals, Chapter 7 High Magic, the Symbols, the utilities.
