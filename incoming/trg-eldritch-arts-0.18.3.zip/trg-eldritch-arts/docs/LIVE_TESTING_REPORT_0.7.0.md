# Eldritch Arts 0.7.0 and TRG Prime 3.682.0 — Live Testing Report

3 November 2026. Tested in Foundry V14, world "TRG V14", as Gamemaster in Chrome, after Graham installed Eldritch Arts 0.7.0 on TRG Prime 3.682.0.

**Throwaway material, all deleted afterwards:**
- **A scene** for the test, with 5 ft squares.
- **"ZZ EA …" actors:** Spellblades on each path, a Warlock with several bonded souls, allies and targets.
- **Character levels:** set through XP (level × 10 000), and the classes were added from the module's class pack.

**What was changed, and put back:**
- **None of Graham's actors or settings was touched.** His running combat (five combatants) was left as it was.
- **Dice:** where a result had to be forced, `CONFIG.Dice.randomUniform` was set for that roll, then restored.
- **Removed:** the 120 test chat cards, the actors and the scene. The test's dialog, notice and Conviction hooks came off.
- **The view** went back to Oldwatch Approach.

## The Spellblade

| # | Test | Result |
|---|---|---|
| 1 | The class table at 5th | **Pass.** BAB, saves, CL ⌈L ÷ 2⌉ and BSB as printed. |
| 2 | Spellblade Path: the Verdant Warden | **Pass.** CL 3; Constitution; the Verdant tradition; Natural Resilience's +5 HP at 5th; the resistances; the two class skills. |
| 3 | The Book of Infusions | **Pass.** Book allowance 8 at 5th; the first picks were "any PP 2 verdant"; six memorised at 5th (level + 1). |
| 4 | Battle Mage, Orb of Force | **Fail.** Attack 15, with no BAB row. The core's attack spells mark the Attack trait as their category, "attack", and print no Attack trait, so the seam found none. **Finding 1.** |
| 5 | Thunderous Strike: the Strike as the casting check | **Pass** (with its range patched on the live item, finding 2). 19 against DC 11, a Critical. Only the creature behind the target saved. |
| 6 | Thunderous Strike cancelled for range | **Pass.** The Strike's 1 AP was charged; nothing else. |
| 7 | Infuse Weapon: Learn a rune, Failure | **Pass.** Nothing learned; the materials kept. |
| 8 | Learn a rune, Heroic | **Pass.** Learned; half the materials consumed. DC 24 at PP 5. |
| 9 | Infuse: Acidic I | **Pass.** Applied with no potency problem; the Acidic Command action was offered. |
| 10 | The infused weapon strikes | **Pass.** The acid rider dealt its damage, and the strike was magical against a "mundane" resistance. |
| 11 | The infusion cleared | **Pass.** The rider and the magical strike both went. |
| 12 | Shooting Star | **Pass** (range patched). A dagger struck in melee at 25 ft; the cover stepped down (−2 DB); the concealment line on the roll; Arcane Echo's +1 attack and +1 damage. |
| 13 | Shooting Star's trail | **Pass.** Laid on two allies; an ally's attack then used it. |
| 14 | Shielding Strike | **Pass** (range patched). +3 status DB with one warp. |
| 15 | Sacred Channel | **Pass.** 1 PP and the use spent; 6 healed. |
| 16 | Dimensional Step | **Pass**, but it charged 1 AP outside the combat. **Finding 3.** 10 ft teleport. |
| 17 | Dimensional Assault | **Pass.** The teleport, then the Strike; the +1 PP option's +5 status applied and spent. The Spatial Awareness card went to the caster, not the target. |
| 18 | Spinning Weapon | **Pass** (range patched). Force and sonic unlocked by the warp; a 1d6 sonic rider, spent on the Strike. |
| 19 | Daily preparation | **Pass.** The Infuse Weapon prompt; the soul's power reset. |
| 20 | Natural Resilience: damage with the disease trait | **Pass.** Halved. |

## The Warlock

| # | Test | Result |
|---|---|---|
| 21 | Xithra, the Emberlord | **Pass.** Mental or fire offered; 2d6 at 4th. |
| 22 | The soul's spells and cantrips | **Pass.** Picks limited to PP 5, or 6 with the Fire or Healing trait; the cantrips; the hex PP 5 or less. Each copy innate, Focus, Charisma. |
| 23 | The soul's +1 level | **Pass.** Cure cast at level 5. |
| 24 | The Emberlord's daily power | **Pass.** Recurring fire 5; once a day; reset at daily preparation. |
| 25 | The Crystal Archon's daily power | **Pass.** Blindness cast at 0 AP, DC 14; the target Blinded. |

## Findings

1. **Battle Mage never applied to the core's attack spells.** TRG Prime 3.682.0's `spellAttackBaseRow` read only the spell's traits for "Attack". The core's spells carry it as their category, `"attack"`, and none prints it among its traits. So it applied only to Eldritch Arts' own spells, such as Xithra (and Xithra is innate, which Battle Mage doesn't cover). **Fixed in TRG Prime 3.682.1:** the category counts as the Attack trait.
2. **Four path spells were refused whenever a creature was targeted.** Shooting Star, Shielding Strike, Spinning Weapon and Thunderous Strike print no range. A blank range is read as "self", so the core refused the cast ("beyond … range of self") when anything was targeted. **Fixed in 0.7.1:** their range is "see text", which the core doesn't gate. Dimensional Assault keeps its printed "half your land speed".
3. **AP was charged to a creature outside the combat.** The module's AP helpers asked only whether some combat had started, not whether the actor was in it. Graham's combat was running, so the test Spellblade, who was not in it, paid AP. **Fixed in 0.7.1:** AP is charged only to an actor in a started combat. This covers Block 4's Dimensional Step and Thunderous Strike, Block 1's AP helper and Elemental Symbiosis, and Block 3's Dragon Claws and Gale Step.

**Cosmetic, not changed:**
- The Spellblade's memorisation panel shows "Cantrips 0/4". The class has no cantrips; The 4 is the core's default, shown when a class sets no daily cantrips.
