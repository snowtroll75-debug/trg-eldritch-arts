# Eldritch Arts 0.13.1 — Graham's rulings on Block 9a, and the live test

13 November 2026. **Needs TRG Prime 3.688.1.** No migration.

## Catalysts in rituals (Q186)

Graham: "Catalysts should be offered for rituals."

- **When:** a ritual's primary is asked which catalyst to use before the ritual check, on the same prompt as an ordinary cast (TRG Prime 3.688.1).
- **What's offered:** the catalysts that fit the spell, by the same rules as an ordinary cast. A ritual has no spell attack, so the Chained Obsidian Bead is never offered there.
- **Where its effects go:**
  - its check bonus or advantage goes to the ritual check;
  - the rest reaches the cast;
  - its backlash follows the ritual check's degree.
- **When it's used up:** whether or not the spell is cast.
- **Blood-etched Vellum** is now one of these catalysts, offered only to a ritual's primary: +2 item to the ritual check, with its Bleeding backlash on a Failure or worse.
  - It replaces 0.13.0's tick in the Magic Ritual dialog, and the module no longer registers ritual rules of its own.
  - A plan flag a 0.13.0 ritual left on an actor is harmless and is no longer read.

**Two exceptions, found in review:**
- A ritual variant whose PP are substituted (Chapter 7's mundane ritual) is not offered Resonant Crystal Shard: no discount can reach those PP.
- A ritual claiming "Duration unaltered" (−10 DC) is not offered Starpetal Oil's duration stretch, only its range, where the range scales.

**Two questions for Graham** (also in TRG Prime 3.688.1's notes):
1. Should any caster releasing any specialist spell from an item read it as their own tradition?
2. On a mundane ritual, whose check is a tradition skill, should a catalyst that says "Spellcraft check" still apply?

## Illusion is Shadow; charm is Enchantment

Graham: "Illusion should be Shadow and Charm, Enchantment."

- **Moonveil Dust** is offered on a Shadow or Enchantment spell with a save, and is graded A again.
- **Sunbronze armour's +1 Will** now applies by itself against Fear and Enchantment effects. The charm tick is gone.
- **For Graham to amend in the book (v1.6):**
  - Chapter 6, Special Materials, Sunbronze: "fear and charm effects";
  - Chapter 6, Catalysts, Moonveil Dust's Effect line: "illusion or enchantment trait";
  - the Catalysts table's Moonveil Dust row: "Illusion/Enchantment".

## Found in the live test of 0.13.0

**Sunbronze shield light.** It drew a 5 ft bright ring inside its 10 ft dim light. The book says "sheds dim light", so it is now dim only (`brightFeet: 0`).

**Run in Graham's world on TRG Prime 3.688.0, all as intended:**
- the catalyst prompt and its offers (Sands not offered out of combat);
- the effects of Glimmercoal, Leydust, Arcanite Powder and Resonant Crystal Shard;
- backlash on a Failure and none on a Partial: Cinders with Catalyst Affinity's cut; Frozen Marrow's cold damage and Slowed;
- Catalyst Conservation's flat check;
- the Sunbronze shield light, on and off, and the material note on the sheet;
- Bloodglass shattering when destroyed (not at 0 HP), once, against both creatures within 5 ft.

**The world was left as it was found.**

## The harness

- **`verify-block9a`** (207 checks) and **`mutate-block9a`** (89 mutations, all caught) are rewritten for the ritual path, Shadow and Enchantment, and the dim-only light.
- **Re-pinned** to 0.13.1 / 3.688.1.
- **Every module verifier passes, and every module mutation file catches all its mutations.**
