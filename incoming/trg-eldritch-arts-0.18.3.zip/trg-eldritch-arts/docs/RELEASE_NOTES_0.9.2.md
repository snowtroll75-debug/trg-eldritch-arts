# Eldritch Arts 0.9.2

5 November 2026. One fix from the live test on TRG Prime 3.684.4.

- **Install over 0.9.1.** It needs TRG Prime 3.684.1 or later. No migration, and loading a world changes nothing on any sheet.

## Fixed

- **Lightning Rod's splash now posts its card.**
  - **Before:** the next electricity spell after a Lightning Rod mark dealt the splash damage to the enemies within 10 ft of the marked creature, and both mark effects ended. But no card said so. The console showed "Eldritch Arts | Metamagic (spell) Error: ActiveEffect … does not exist!"
  - **Why:** ending the mark deleted the caster's effect first. That deletion makes the module also delete the marked creature's effect. The mark-ending code then deleted that same effect again, and the second delete threw before the card was posted.
  - **Now:** the marked creature's effect is deleted first. An effect that is already gone is skipped, so the card is posted: "Lightning Rod: … conducts — N electricity (half the dice, no save) to each enemy within 10 feet."

## Harnesses

- **`verify-block6d`:**
  - The test effects now behave as Foundry's do: a second delete throws, and a delete can fire the module's deletion hook.
  - Two new checks:
    - the splash card is posted with that hook live, and both effects end;
    - ending a mark whose marked effect is already gone does not throw.
- **`mutate-block6d`:** two new mutations, one that puts back the old order and one that rethrows the error. Both are caught. One mutation is re-pointed.
