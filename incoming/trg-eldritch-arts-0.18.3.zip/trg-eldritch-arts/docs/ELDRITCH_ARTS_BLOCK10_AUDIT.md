# Eldritch Arts Block 10: audit (relics and sentient items)

15 November 2026. Block 10 is the last content block. It covers Chapter 9's **relics** and **sentient items**, and the **Relic Bonding Ritual** (Chapter 4's general skill actions). It also covers the Appendix's **RELIC** and **SENTIENT** traits, and the **rules reference journal** that was deferred to this block (Block 8 audit §1).

It was read against:
- ***TRG Prime: Eldritch Arts* v1.6**, cut as before into `/home/claude/ea-src/v16/ea.md`. Line numbers are that file's.
- **The rules audit, Part E** (`ELDRITCH_ARTS_RULES_AUDIT.md`, L2101–2474), and **Graham's answers** (`ELDRITCH_ARTS_RULINGS_2026-11-01.md`, "Blocks 4–10").
- **TRG Prime 3.692.0**, in its source.

**Answered, 15 November 2026:** Graham took every recommendation ("Go with your recommendations"): Q211–Q221 as in §7, and both seams, H27 and H28. Block 10a is built as Eldritch Arts 0.17.0 on TRG Prime 3.693.0 (`RELEASE_NOTES_0.17.0.md`). Block 10b is built as 0.17.1 on TRG Prime 3.694.0 (`RELEASE_NOTES_0.17.1.md`).

**As audited, nothing was built.** Every rule below is quoted from the book or from a ruling. Where the book is silent and the answer would change play, the point is asked in §7.

## 1. The count

The implementation matrix has **37 rows** under "Ch9 Relics", plus SA-02 (the Relic Bonding Ritual skill action) and SYS-12 (the new traits).

| Family | Where (v1.6) | Rows | State |
|---|---|---|---|
| **Relic Bonding Ritual** | L1828–1856 | SA-02, RR-015 | To build: a skill action |
| **Relic rules** (tiers, bonding, investment) | L10061–10109 | RR-018, RR-020, TB-001, TB-003 | To build |
| **The four relics** | L10111–10345 | RL-001–004 | To build |
| **Sentient item rules** (traits, Ego, Influence, level, investment) | L10347–10450 | RR-022, RR-025–027, RR-029 | To build |
| **Dawnshield** (the one sentient item) | L10591–10652 | WO-001 | To build |
| **Sentient item tables** (type, personality, motivation, ethics, communication, senses, mental arrays, powers, aligned trait, quirks) | L10452–10589 | TB-004–006 | To build as roll tables |
| **Guidance only** (Wondrous Items, Nature of Relics, Creating Relics, Tier Benefits, GM Balance Notes, Determining Sentience, Special Abilities, Hidden Powers, Growth & Advancement) | L10051–10109, L10347–10450 | RR-016, RR-017, RR-019, TB-002, RR-021, RR-023, RR-024, RR-028, RR-030 | Journal (D) |
| **RELIC and SENTIENT traits** | L10736, L10744 | RR-035, RR-037 | To build (one-invested, TRG Prime's H25) |
| **The rest of the Appendix** | L10656–10760 | RR-031–034, RR-036, RR-038, TB-007, RR-039, SYS-12 | **Already built:** Distracted (Block 7), Berserker (6a), Highmagic (3/6), Orb (9c), Ritual (2b/8b), Summons (2b). The index and the licence have no mechanics. |

**Veilshroud is no longer blocked.** EA-C8 is ruled ("C8: Veilshroud now carries Veil I"), and v1.6 prints "Gains the Veil I rune" (L10321).

## 2. What v1.6 settled from Part E

Graham's answers left M99, M101–M103, M112 and m215 onward "as printed". The rest are read from v1.6, which now prints them:

| Part E | v1.6 now says |
|---|---|
| **M97** (advancement) | "After bonding, the Relic advances one tier at each daily preparation until its tier matches the wielder's level." (L1852) |
| **M98** (investment) | (a) active tier = the highest whose slot cost you can pay, or a lower one by choice; (b) bonding before investing, and nobody else may invest a bonded relic; (c) this replaces the one-slot rule for multiple invested traits. (L10077–10079) |
| **M104** | Renewal I is removed from the Aegis. |
| **M105** | "Once per day, you may invoke the Shield of Dawn (2 AP, concentrate): for 1 minute, you and allies within 30 ft…" (L10224) |
| **M106–M109** | The Veilshroud's printed fixes: Track at disadvantage; Perfect Darkvision; the shadow step (2 AP, move, teleportation, light level 2 or lower); "you ignore it and instead regain HP equal to half the amount". |
| **M111** | Ego DC = 10 + Ego (L10397). |
| **m205, m206, m208–m213** | The second table is retitled RELIC INVESTMENT; the resistances now name a number of types; the Aegis is a light steel shield; its aura works vs fear and curse; TRANSCENDENT is spelt that way; the weights are 4 and 1 lb; the Codex bonds normally for an unaligned character; and its −1 penalty is a status penalty vs divinity-tradition spells. |

**Not settled by v1.6, so asked in §7:** M100 (a relic's item level), m203 (the bonding check's DC, and its Partial and Blunder), and M110, which needs a closer look. Its proposed sentence ("A Relic that awakens sentience uses its tier slots only…") now stands as the Veilshroud's first Legendary bullet (L10339), where it reads as a general rule rather than a power of the cloak.

Built as printed:
- **M101** (focus-trait innate spells, Meteor Swarm included).
- **M102 and M103** (Undead Binding at Awakened; Gate at 17th level). The module declares the core's innate PP allowance on those copies (`innatePPAllowance`), so TRG Prime's innate level gate lets them through.
- **M112** (Dawnshield's three replaced degrees; the others use the general Influence ladder).
- **m214** (Ego 24) and **m219** (Dawnshield's printed statistics).

## 3. What TRG Prime 3.692.0 already has

| Need | Core | Gap |
|---|---|---|
| Invest Item, slot count | `magic-items-workflow.mjs` `investItem`, `investRefusal`; `investmentSlots` = 3 + magical ability + ⌊level/5⌋ | **Every invested item costs one slot.** A relic costs one per tier and a sentient item two. Seam **H27**. |
| One invested per trait | H25 (3.690.0): `registerOneInvestedTraits` (the Orb) | None: RELIC and SENTIENT register the same way |
| A module's own refusal to invest | — | A bonded relic may not be invested by anyone else, and the Codex refuses Good characters. Seam **H27** (`registerInvestRefusal`). |
| A new day | `trgPrimeDailyPreparation` (3.666.0) | None: the relic advances a tier there |
| Innate spells from an item | `item-innate-level.mjs` `innateCastLevel` (the item's `itemLevel`, else the character's level); `innatePPAllowance`; the focus trait and Refocus | None (see Q213) |
| Runes and quality on an item | `system.runes`, `system.quality`, the rune registry | None: the module rewrites the relic's own item at each tier |
| Auras with ally conditionals; conditionals by source type, tradition and traits | `auras`, `conditionals` (`sourceTypes`, `traditions`, `traits`) | None: the Aegis's fear-and-curse aura, Shield of Dawn's advantage vs aberrations, eternals and undead, the Codex's −1 vs divinity |
| Resistance, immunity, senses | ActiveEffect defences; senses from items | None |
| "When you would be dealt essence damage, you ignore it and instead regain HP equal to half the amount" (Veilshroud, Legendary) | `registerDamageReaction` answers `{ immune }` before defences, without the amount | **Healing by half.** Seam **H28**. |
| A skill action with a level-based check | `registerSkillActions` (Block 1 used it for Chapter 4's actions) | None |
| Roll tables | Foundry RollTable documents | None: a module pack |

## 4. The relics

### 4.1 The model (one for all four)

- **The relic item** is the printed item (a shield, a broadsword, a book, a cloak) with `flags.trg-eldritch-arts.relic`: its key, the bonded wielder's UUID, its **awakened tier** (0–4, Dormant to Legendary) and its **invested tier**.
- **Bonding** (§4.2) records the wielder. Only the wielder may invest it (H27 refusal).
- **The awakened tier** starts at Dormant. At each of the wielder's daily preparations it advances one tier, until it reaches the tier of the wielder's level (L1852). A Critical bonding advances it at once, if the wielder qualifies (L1844).
- **Investing it** asks which tier to invest at: any tier up to its awakened tier whose slot cost (1–5) fits the free slots (M98 (a)). The relic then counts that many slots (H27). Ending investment frees them.
- **Its statistics follow the tier it is invested at.** The module rewrites the item's quality, runes and traits, grants the tier's innate spells (focus trait, the core's allowance where needed), and lays the tier's effects. An unbonded or uninvested relic is the plain Dormant item without its powers (Q215).
- **RELIC is one-invested** (L10736), through H25.

### 4.2 The Relic Bonding Ritual (SA-02, L1828)

A general skill action: trained in Arcana, Nature, Occultism or Religion; 1 hour (ritual); costs 1 PP and 250 gp of incense (consumed). The performer may be the wielder or another character bonding it to the wielder (L1854). It rolls a level-based check (Q211):
- **Critical:** bonded, and awakens one tier at once if the wielder qualifies;
- **Success:** bonded;
- **Failure:** rejected, no retry for 24 hours;
- **Fumble:** 1d6 essence per character level (basic Fort), no retry for a week.

The relic's own requirements are checked first: the Codex refuses Good characters and asks for its sacrifice (a tick). "The Relic must willingly accept the bond", and any narrative conditions, are the GM's tick.

### 4.3 Each relic, as printed (v1.6) and as it would be built

| Relic | What each tier does | Built as | Grade |
|---|---|---|---|
| **The Aegis of Valtea** (RL-001; HEALING INVESTED RELIC SOUL WARDING; held shield) | **D:** expert lightweight light steel shield, Potency I, Light (focus). **A:** Cure (focus); the Benevolent rune; allies within 10 ft +1 item to saves vs fear and curse. **E:** essence resistance; Restoration (focus); Potency II. **T:** Potency III; Forbiddance (focus). **L:** essence immunity; Heal (focus); Shield of Dawn 1/day (2 AP, concentrate): 1 minute, you and allies within 30 ft Fast Healing 10 and advantage on saves against aberrations, eternals and undead; Evil-aligned enemies get no concealment or invisibility in the aura. | The shield rewritten per tier. The aura with an ally conditional. The innate spells. Shield of Dawn as a 1/day Use: Fast Healing and the advantage by aura conditionals. | **B**: Shield of Dawn's denial of concealment and invisibility to Evil enemies is by hand (the core has no "cannot benefit from concealment" row). Q214 asks whether the 10-ft aura includes you. |
| **Emberfang** (RL-002; INVESTED MAGICAL RELIC; held weapon) | **D:** expert balanced broadsword, Potency I, Light (focus). **A:** Potency II, Flaming I, Burning Hands (focus). **E:** master; Potency III; Flaming II; fire resistance. **T:** Potency IV, Flaming III, Fireball (focus). **L:** legendary; Potency V; fire immunity; Meteor Swarm (focus). | The weapon rewritten per tier; resistance and immunity as effects; the innate spells (Meteor Swarm, PP 18 at level 17, with the core's allowance of 1). | **A** |
| **Obsidian Codex** (RL-003; EVIL INVESTED RELIC SOUL TRANSLOCATION; held book) | **Bonding:** a blood sacrifice or the extinguishing of a living soul; never a Good character; Balance or Order suffer Dissonance (disadvantage on Will saves while bound); unaligned bonds normally. **D:** +1 item to Spellcraft for Soul-trait spells; Detect Undead constant; Chill Touch (focus). **A:** advantage on saves vs fear; −1 status to saves vs divinity-tradition spells; Animate Dead and Undead Binding (focus); "whispering voices…" (flavour). **E:** essence resistance; Vampiric Touch (focus); undead you create gain +2 HP per level. **T:** undead under your control have advantage on attack rolls vs living creatures; Create Undead (focus). **L:** Hand of the Reaper (focus); essence immunity; "recognised as its chosen Necrolord" (flavour). | Conditionals for the Spellcraft bonus, the fear advantage, the divinity penalty and Dissonance. The innate spells (Undead Binding with an allowance of 3). Detect Undead as a constant effect. | **B**: the +2 HP per level and the attack advantage of "your" undead depend on which undead count (Q217). |
| **The Veilshroud** (RL-004; INVESTED RELIC SHADOW TRANSLOCATION; worn cloak) | **D:** +1 item Stealth; Track against you at disadvantage; Cloak of Greying (focus). **A:** Darkvision (Perfect Darkvision if you have it); the Veil I rune; Misty Step (focus); ripples near planar anomalies (flavour). **E:** essence resistance; Invisibility, self (focus); the shadow step 1/day (2 AP, move, teleportation; up to 60 ft between spaces of light level 2 or lower you can see). **T:** essence immunity; Dimension Door (focus); a native disguise in the Shadescape unless you act aggressively. **L:** [the sentience rule, Q216]; essence that you ignore and are healed by half; Gate 1/day (with the core's allowance of 3). | Stealth and Darkvision as effects. Veil I as Block 9b's Veil rune on the cloak. The innate spells. The shadow step as a 1/day Use, reading TRG Prime's `lightLevelAt` at both ends. The Legendary absorption through H28. | **B**: Track at disadvantage is the tracker's roll, with no target to hang it on, so it goes on the card. The planar ripples and the Shadescape disguise are the GM's. |

## 5. Sentient items

### 5.1 The rules

- **Traits** (L10354–10364): senses, communication, Int/Wis/Cha, ethics and aligned trait, influence. Recorded on the item (`flags.trg-eldritch-arts.sentient`) and shown on its sheet card.
- **Ego** = item level + highest mental modifier + number of special powers (L10395). **Ego DC** = 10 + Ego. Computed, unless printed: Dawnshield prints Ego 24 (m214, as printed).
- **Influence** (L10399–10415): the wielder rolls Will against the Ego DC. Critical: suppressed for 24 hours. Success: resists. Partial: minor penalties (GM). Failure: the item refuses powers, imposes penalties or compels a minor act. Fumble: overrides one decision a turn; retry after 1 hour. Blunder: the item dominates for 1 hour.
  - Built as a **GM button on the item** (Q218): the save is rolled, and the degree printed with its text.
  - Two degrees are tracked: the 24-hour suppression (Critical), which refuses a further roll; and the Fumble's 1-hour wait before a new check.
  - What the item does is the GM's, as printed ("The GM adjudicates exact influence").
- **Level** = base item level + 2. Always Rare, never bought on purpose (L10419–10423). Recorded; the price is the GM's.
- **Investment:** two slots (L10441, H27). **SENTIENT is one-invested** (L10744, H25).
- **Hidden powers and growth** are the GM's (journal).

### 5.2 Dawnshield (WO-001; INVESTED LIGHT SENTIENT WARDING; Level 15; 38,500 gp)

| What | Built as | Grade |
|---|---|---|
| The shield: ACP 0, DR 3, DB +4, HP 110; Dragonhide, Organic, Master, Potency II, +2 DB vs Fire, constant Light (m219, as printed) | The shield item with the printed numbers. Potency II through the core's rune. +2 DB vs fire as a conditional. Light as a constant effect. | A |
| Sentience: Balanced and Good; telepathy; Darkvision 70 ft, Life Sense 50 ft, Aberration/Undead Sense 50 ft; INT +3, WIS +4, CHA +6; its personality | On the item's card. The senses are the item's own, not the wielder's, so they are not granted to the wielder. | — |
| You and allies within 10 ft: +2 to saves vs fear | An aura with an ally conditional (Q214 asks about "you") | A |
| 1/day it casts Cure on its own | A 1/day Use that casts Cure at the item's level (15) | A |
| While raised, its light reveals invisible undead and shadow creatures in the 30-ft bright radius | A card line ("raised" is the core's Raise a Shield; revealing is the GM's) | C |
| 1/day flare that dispels magical darkness of PP 6 or less in its bright radius | A 1/day Use that ends magical darkness effects of PP 6 or less within 30 ft, by the core's dispel by PP | B |
| Ego 24, DC 34; conflict triggers; its own Success, Failure and Fumble | The Influence button, with Dawnshield's three in place of the general three (M112, as printed). Failure "dims" it: its powers and superior-trait benefits stop until atonement (a GM toggle on the item). | B |

### 5.3 The tables (TB-004–006)

Ten roll tables, cut apart from the merged grid (m216, "m215 onward, as printed", so their content is as printed): item type (d10), personality (d12), motivation (d12), ethics (d100), communication (d8), senses (printed "d6" over eight entries, rolled as d8: Q219), mental arrays (d8), special powers (d8), aligned trait (d8) and quirks (d20, printed under a second "ALIGNED TRAIT" header). Shipped as RollTables in a new pack, `ea-tables`, with a "Design a Sentient Item" macro-less journal page that links them.

## 6. Proposed core seams (TRG Prime 3.693.0, for Graham's approval)

**H27: an item's investment cost, and a module's refusal.**
- `registerInvestCost(key, fn(item, actor))` returns the slots an item takes: a relic's invested tier (1–5), a sentient item's 2, a sentient relic's tier only. An item with no answer costs 1.
- The core's invested count, the slot check in `investItem` and `investRefusal`, and the sheet's "invested n / N" use the summed cost.
- `registerInvestRefusal(key, fn(item, actor))` returns a reason or "", asked beside the Staff and one-invested-trait refusals: a bonded relic and another creature; the Codex and a Good character.
- Investing a module's item can ask its tier first. `registerInvestCost`'s answer may be a promise, so the module asks there.

**H28: damage absorbed as healing.** A damage reaction (`registerDamageReaction`) may answer `heal: 0.5` beside `immune: ["essence"]`. The core then heals the creature by that fraction of the amount it ignored, before defences, and says so on the card. For the Veilshroud's "you ignore it and instead regain HP equal to half the amount".

Nothing else needs the core: the rest is the module's items, effects, conditionals, auras, Uses and the daily-preparation hook.

## 7. Rulings needed

| Q | Point | Recommendation |
|---|---|---|
| **Q211** | **The bonding check** (m203). "A level-based check": whose level, which skill, and what of Partial, Blunder and the Fumble's save? | The performer's trained Arcana, Nature, Occultism or Religion, against the Level DC of the **wielder's** level. Partial reads as Failure, Blunder as Fumble (m42). The Fumble's 1d6 per level uses the performer's level, with a basic Fortitude save at the same DC. |
| **Q212** | **Who pays.** 1 PP and 250 gp "(wielder or ritualist)". | The performer pays both, from their own pool and purse. |
| **Q213** | **A relic's item level** (M100). No relic prints one, and the core reads an item-granted innate spell's DC and attack from the item's level. | None: the core falls back to the wielder's level when an item has no level, which is what M100 proposed. The relic's level is the wielder's level. |
| **Q214** | **"Allies within 10 ft"** (the Aegis's fear-and-curse aura) and Dawnshield's "Wielder and allies". | The Aegis's aura includes you, as Shield of Dawn now says "you and allies". |
| **Q215** | **A relic invested below its awakened tier, or not at all.** | Its statistics follow the tier it is invested at: quality, runes, spells and powers. Uninvested, it is the plain Dormant item without powers (the INVESTED trait). |
| **Q216** | **The Veilshroud's first Legendary bullet** is M110's proposed rule sentence: "A Relic that awakens sentience uses its tier slots only and gains Ego as a sentient item of level = wielder level; 'semi-sentient' grants communication only, without Ego." v1.5 printed "The cloak becomes a semi-sentient guardian" there. | Read it as the general rule for sentient relics (H27 costs a sentient relic its tier slots only). At Legendary the Veilshroud becomes semi-sentient: communication only, no Ego and no Influence. |
| **Q217** | **The Codex's undead.** "+2 HP per level" (Empowered) and "undead under your control" (Transcendent). | "Per level" is the undead's level. Both apply to undead you create or bind (Animate Dead, Create Undead, Undead Binding) and that are under your control. |
| **Q218** | **Influence: when it is rolled.** | Only when the GM presses the item's Influence button. The book leaves when the wielder opposes the item to the GM, and the module rolls nothing on its own. |
| **Q219** | **Senses table:** printed d6 over eight entries. | Roll it as d8. |
| **Q220** | **Dissonance** (Codex): "disadvantage to Will saves while bound". | While bonded, invested or not. |
| **Q221** | **The rules reference journal** (`ea-rules`), deferred to this block: the relic and sentient rules, Creating Relics, Tier Benefits, the GM notes, Hidden Powers, Growth, and Chapter 7's High Magic, ley line, wild magic, suppression and ritual rules, with the Planes appendix. | Ship it with Block 10b, as one journal of short pages, each quoting the book. |

## 8. Plan

- **Block 10a:** TRG Prime 3.693.0 (H27, H28) and Eldritch Arts 0.17.0:
  - the Relic Bonding Ritual, and the relic model (bonding, daily awakening, tiered investment);
  - the four relics;
  - RELIC and SENTIENT as one-invested traits;
  - the sentient item model (Ego, Influence) and Dawnshield.

  Harness: `verify-block10` / `mutate-block10`, and the core pair for H27 and H28.
- **Block 10b:** Eldritch Arts 0.17.1, the roll tables (`ea-tables`) and the rules reference journal (`ea-rules`), if Q221 is yes.
- Each with the usual release checks, notes and a live test.

**Grades, by the plan:** Emberfang A; the Aegis, the Codex, the Veilshroud and Dawnshield B. The bonding ritual A, apart from the GM's ticks for "willingly accepts" and narrative conditions. The relic and sentient rules A/B. The guidance rows D (the journal).
