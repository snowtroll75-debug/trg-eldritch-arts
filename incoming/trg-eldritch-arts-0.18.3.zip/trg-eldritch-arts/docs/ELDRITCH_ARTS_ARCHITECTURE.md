# Eldritch Arts — Proposed Module Architecture

Eldritch Arts is built the same way as Inner Tempest, which reached 1.0.3 on TRG Prime 3.674.2. It is an independent companion module, `trg-eldritch-arts`. It extends the system only through the system's companion-module API, plus a small set of core additions (`ELDRITCH_ARTS_CORE_DEPENDENCIES.md`), each approved and released separately. No core rules are copied into the module. There is no alternative character sheet.

## 1. How the content reaches the system

- **Compendium federation.** Each pack declares `flags.trg-prime.extends` with the system's logical pack name, so the system's pickers, grant resolution and compendium refresh read it as part of that pack:

  | Pack | Extends | Holds |
  |---|---|---|
  | `ea-races` | `races` | Aetherial, Emberkin, Nyrinn, Scaelyn |
  | `ea-heritages` | `heritages` | 18 heritages |
  | `ea-backgrounds` | `backgrounds` | 12 |
  | `ea-abilities` | `abilities` | racial and class abilities, birthrights, paths, bonded souls, Xithra, Soulbound Familiar … |
  | `ea-classes` | `classes` | Archmage, Sorcerer, Spellblade, Warlock, Witch |
  | `ea-feats` | `feats` | 237 feats |
  | `ea-spells` | `spells` | the Grimoire and the specialist spells/hexes |
  | `ea-weapons` | `weapons` | 18 exotic weapons |
  | `ea-gear` | `gear` | goods & tools |
  | `ea-consumables` | `consumables` | 24 catalysts |
  | `ea-runes` | `runes` | armour and weapon runes, browsing only; the runes become inscribable through `registerRunes` |
  | `ea-specific-items` | `specific-items` | specific armour and weapons |
  | `ea-charged-items` | `charged-items` | orbs, rods, staves |
  | `ea-wondrous` | `wondrous` | wondrous items |
  | `ea-relics` | `wondrous`, or none if relics need their own picker | relics (decided in the relic block) |
  | `ea-rules` (JournalEntry) | none | the rules reference: High Magic, ley lines, wild magic, suppression, rituals, summoning, relics, and the Wild Surge, Ley Line Effects and Suppression Backlash tables |

  The final list follows what the book actually contains. A pack is added only when its block is built.
- **Sourcebook.** `module.json` carries `flags.trg-prime.sourcebook: "Eldritch Arts"`, and the module calls `registerSourcebook`. Every picker's Sourcebook menu then lists Eldritch Arts beside the Core Rulebook, Fiends & Fables, Pillars of Faith and Inner Tempest.
- **Deterministic ids.** Every document is authored in `tools/content/*.mjs` through `builders.mjs`, which is shared with Inner Tempest. Each gets a 16-character id from `sha256(pack + name)`, so a rebuild never changes an id a world already holds. `build-packs.mjs` writes reviewable JSON to `packs-source/` and compiles LevelDB with the Foundry CLI.
- **Book text is cut, never retyped.** `tools/content/extract-book.mjs` cuts `ea.md` into `book-text.json`, recording every entry's line. The verify harnesses check each pack document's description against it, both verbatim and complete.

## 2. How the mechanics run

| Layer | Used for | Mechanism |
|---|---|---|
| Data | Static bonuses, resistances, speeds, senses, natural armour, PP per level, spell adders | Transferred Active Effects with typed bonus keys (the core's bonus pool), `flags.trg-prime.spellAdder`, declared rows |
| Conditionals | Situational bonuses and advantage (vs mental, in dim light, when submerged …) | `flags.trg-prime.conditionals`, offered as tickboxes in the roll dialog; pre-ticked where the check settles the scope |
| Registrations | Classes, archetypes, feat access and gates, languages, racial PP, skill actions and substitutions, degree upgrades, spell warps, runes, defence offers, light sources, create routes | `module/registration.mjs`, inside the `trgPrime.registerContent` hook |
| Automations | Activated feats and abilities (Use button), reactions, item uses | `registerFeatAutomation` / `registerItemAutomation` handlers in `module/<block>-automations.mjs`, using the system helpers (`castInnateOnce`, `runAreaEffect`, `basicSaveHit`, `healActor`, `rollCheck`, `postCard` …) |
| Hooks | Riders after a spell or strike, damage reactions, daily preparation picks, turn-start area damage | `trgPrimeSpellCast`, `trgPrimeSpellSettled`, `trgPrimeStrikeResolved`, `trgPrimeDamageApplied`, `trgPrimeDailyPreparation`, `trgPrimeTurnEnded`, `combatTurn` |
| Cast-time options | Metamagic, catalysts, cast modifiers, High Magic | Core D1, D2, D3, D5, D6, D7: registries the cast workflow consults, so the Warp? dialog, the costs, the DC and the chat card all show the change |
| Scene regions | Ley lines, wild magic areas, suppression areas, summoning circles | Foundry Regions with `flags.trg-prime-eldritch` `{kind, level, …}`, placed with a GM tool. The casting gate reads them, and the actions and tables use them |
| State | Familiar bonds, reservoir charges, marks, sigils, relic stages, anchored ley lines | Persistent actor/item flags and effects (`moduleMark`, timed effects), never sheet-only state, so they survive reloads |

The rules sit in pure files (`x.mjs`) and the Foundry half in `x-workflow.mjs`, as in Inner Tempest, so the harness can test the rules without Foundry.

## 3. Testing

Each block has a `tools/verify-blockN.mjs` and `tools/mutate-blockN.mjs` pair, run with `TRG_PRIME_ROOT` pointing at the core.

`verify` checks:
- the packs against the book text: every entry present, verbatim, complete;
- the system's own readers against the declarations (bonus totals, grants, progression rows, picker eligibility);
- the automations driven with stand-ins;
- registration against a fake API;
- the wiring: hook names, manifest version and links, required system version.

`mutate` breaks each rule in turn and confirms that `verify` fails.

Core dependencies get their own `verify/mutate-blockN-core` pair in the core tree, and the full core sweep (`npm run verify`, 650+ harnesses) runs on a staged copy before every zip.

Every block is then live-tested in your TRG V14 world (Chrome, GM and a player client). Live testing is reported separately from harness results, and only features actually exercised there are marked "tested live".

## 4. Block plan

Each block runs in this order: audit and rulings, then build, then harness, then sweep, then zip, then you install, then a live test. The next block starts only after that.

| Block | Content | Core needs | Waits on |
|---|---|---|---|
| 1 | Races, heritages, racial abilities, backgrounds, languages, existing feats opened; Chapter 4 actions that need no core (Ley Sense, Appraise Magic, Quickbind, Hypnotism, Mysterious Script, Lingual Casting); exotic weapons and goods | D18 (materials and traits) | EA-C1 (Null Aura) for one clause only |
| 2 | High Magic (D1) and Chapter 7: ley lines (regions, Tap/Channel, effects table), wild magic and Wild Surge, suppression and backlash, antimagic, summoning circles, true names, mundane rituals | D1, D6, D7, D13, D14 | **EA-M4**, EA-M5…M9 |
| 3 | Archmage, Sorcerer and the seven birthrights, Witch, Soulbound Familiar, hexes; their specialist spells | D4, D5, D8 | EA-M1, EA-M2, EA-M15, EA-M16 |
| 4 | Spellblade and its paths, Infuse Weapon and Book of Infusions; Warlock, bonded souls, Xithra; their specialist spells | D9, D17 | EA-C2, EA-M28, EA-M13, EA-M14 |
| 5 | Racial feats and general feats | D10, D13 | — |
| 6 | Archetypes and class feats, the metamagic wave | D2, D3, D5, D12 | EA-M3, EA-M23, EA-M25, EA-M26 |
| 7 | Grimoire spells, first half | as the audit of Part B shows | Part B rulings (rituals capped at Success) |
| 8 | Grimoire spells, second half; remaining specialist spells | | |
| 9 | Catalysts (D3) and magic items: runes, specific armour, orbs (D12), rods, staves, weapon runes, specific weapons, wondrous | D3, D12 | Part C and D rulings (Catalyst rune, Orb level and cost) |
| 10 | Relics, the relic bonding ritual, sentience and investment | | Part E rulings (Veilshroud) |

Items that are blocked are built to the point the audit allows and listed as blocked in the matrix. Nothing is shipped as "automated" if it only posts text.

## 5. Publishing

- **Repository.** A separate repository, `snowtroll75-debug/trg-eldritch-arts`, as you did for Inner Tempest. It does not exist yet, and you create it.
- **Release workflow.** `.github/workflows/release.yml` is copied from Inner Tempest. A push to `main` that raises the version builds the zip and publishes release `v<version>`.
- **What waits for your approval.** Nothing is pushed, released, or installed into your production world without your approval. Core changes go to the core repository only as their own approved releases, never folded into the module.
