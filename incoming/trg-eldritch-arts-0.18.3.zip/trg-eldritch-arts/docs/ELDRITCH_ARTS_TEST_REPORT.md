# Eldritch Arts — Test Report

## 0.6.1 on TRG Prime 3.681.0 (3 November 2026)

| What | Result |
|---|---|
| `verify-block3b` / `mutate-block3b` | **87 checks pass; 83 of 83 caught.** Adds the live test's two fixes and the review's two. |
| `verify-block1` / `2` / `2b` / `3` and their mutations | 883, 131, 91, 302 pass; 86, 75, 81, 83 caught (version pins moved to 0.6.1). |
| Core | Unchanged at 3.681.0. Its 667-harness sweep stands. |
| Live test of 0.6.0 | 25 tests, including two clients (`LIVE_TESTING_REPORT_0.6.0.md`). Two findings, fixed here. |
| Independent review | Two low findings, both fixed: Prophetic Warning's token is now found on the casting client, and a Fixated creature isn't offered Disrupting Magic. Otherwise sound. |

## 0.6.0 on TRG Prime 3.681.0 (3 November 2026)

Every figure here comes from a run in this session.

| What | Result |
|---|---|
| `verify-block3b` / `mutate-block3b` | **80 checks pass; 75 of 75 mutations caught.** Covers the readings, the seven reactions run against fakes of the system's helpers, the four steps, the hour's immunity through the GM, registration, the cards and the versions. |
| `verify-block1` / `2` / `2b` / `3` and their mutations | 883, 131, 91, 302 pass; 86, 75, 81, 83 caught. |
| Core `verify-ea-block3b-core` / `mutate-ea-block3b-core` | **110 checks pass; 103 of 103 caught.** |
| Full core sweep (667 harnesses, two shards, copies checked identical) | **All pass.** 660 passed as they stood. Four older pairs were re-anchored and pass (see the TRG Prime release notes). |
| Inner Tempest 1.0.4 on 3.681.0 | Blocks 1–4, 6–10 and the weapons all green. Block 5 can't run here: its book text isn't in this workspace. |
| Independent review (two rounds) | **First round:** twelve findings. Ten were fixed. One, the shared scope stack, was narrowed in the second round. The last, the Wild Magic surge on a disrupted cast, is left for Graham. **Second round:** six findings, all fixed. The main one: no granted defence would have worked live, because Foundry's real creature data has no link back to the creature, and the harness's fakes did. TRG Prime now adds the link. |
| Live test | Done: 25 tests (`LIVE_TESTING_REPORT_0.6.0.md`). A granted resistance halved real damage (3 → 1), and every reaction ran, across two clients too. 2 findings, fixed in 0.6.1. |

## 0.5.1 on TRG Prime 3.680.0 (2 November 2026)

| What | Result |
|---|---|
| `verify-block3` / `mutate-block3` | **302 checks pass; 83 of 83 mutations caught.** The live test's seven fixes and the review's three, each with checks and mutations. The fakes now take the system's real condition and death shapes and a delayed flag write. |
| `verify-block1` / `2` / `2b` and their mutations | 883, 131, 91 pass; 86, 75, 81 caught (version pins moved to 0.5.1). |
| Core | Unchanged at 3.680.0. Its 663-harness sweep stands. |
| Independent review | Three material findings, all fixed: one death severing the bond several times; a new bond wiping fatigue gained since; the adder following any familiar. A fourth, that the system refused a teleport across a creature, was tested on a throwaway scene and was true only of a Blink drag with waypoints: fixed in TRG Prime 3.680.1. |
| Live test | Done on TRG Prime 3.680.1: 20 tests passed, no findings (`LIVE_TESTING_REPORT_0.5.1.md`), including 3.680.1's teleport movement. |

## 0.5.0 on TRG Prime 3.680.0 (2 November 2026)

| What | Result |
|---|---|
| `verify-block3` / `mutate-block3` | **275 checks pass; 61 of 61 mutations caught.** Classes against the book (every table row, all nine columns), birthrights, the 39 spells' printed text, the rules run, registration, the core run with the content, the Foundry side with fakes, hooks and versions. |
| `verify-block1` / `2` / `2b` and their mutations | 883, 131, 91 pass; 86, 75, 81 caught (version pins moved to 0.5.0 / 3.680.0). |
| Core `verify-ea-block3a-core` / `mutate-ea-block3a-core` | **85 checks pass; 66 of 66 caught.** |
| Full core sweep (the 663 harnesses `tools/verify.mjs` runs, in two shards on copies checked identical to the source) | **All 663 pass**, after the review's fixes. Fourteen mutation files' version pins and six moved anchors were re-pinned first (see the TRG Prime release notes). |
| Inner Tempest 1.0.4 on 3.680.0 | Blocks 1–4, 6–10 and the weapons all green. |
| Independent review | Six findings, all fixed with a check and a mutation each: Wild Power's die read from a field the check lacks (also Shadow Walk's resonance, a core defect); the Specialist Spell feat opening ordinary spells; Raw Power's PP still charged as overcast; the severed bond's fatigue never removed and a dead familiar rebonded; two clients acting at once; Wild Power's rows counted, not matched. |
| Live test | Done: 34 tests (`LIVE_TESTING_REPORT_0.5.0.md`); 7 findings, fixed in 0.5.1. |

## 0.4.0 on TRG Prime 3.679.0 (2 November 2026)

Every figure in this section comes from a run in this session. 0.4.0 was tested live on 2 November (`LIVE_TESTING_REPORT_0.4.0.md`).

| Harness | Result |
|---|---|
| `verify-block2b` (against 3.679.0) | **91 checks, 0 failures.** |
| `mutate-block2b` | **81 mutations, all caught**, tree restored |
| `verify-block2` / `mutate-block2` | **131 checks / 75 mutations, all caught** |
| `verify-block1` / `mutate-block1` | **882 checks / 86 mutations, all caught** |
| `verify-ea-block2b-core` / `mutate-ea-block2b-core` | **52 checks / 60 mutations, all caught** |
| Inner Tempest 1.0.4 on 3.679.0 | Blocks 1–4, 6–10 and the weapons all green (392, 205, 1040, 1360, 183, 228, 123, 84, 118, 117). |
| Full core sweep (`tools/verify.mjs`, 661 harnesses) | **All 661 pass**, on a copy checked identical to the source, after the review's fixes. Eleven older harnesses had been re-anchored first to lines 3.679.0 moved (see the TRG Prime release notes). |

**Independent review before release:** eight Major and five Minor defects, all fixed with a check and a mutation each (`RELEASE_NOTES_0.4.0.md`, "Found in review"). One pre-existing core behaviour, Sacrifice offered to a standard ritual after its roll, was left as it is on Graham's ruling.

---

## 0.3.0 on TRG Prime 3.678.0 (1 November 2026)

Every figure in this section comes from a run in this session. 0.3.0 was tested live on 2 November (`LIVE_TESTING_REPORT_0.3.0.md`).

| Harness | Result |
|---|---|
| `verify-block2` (against 3.678.0) | **131 checks, 0 failures.** |
| `mutate-block2` | **75 mutations, all caught**, tree restored |
| `verify-block1` | **881 checks, 0 failures** (adapted to Block 2's hooks and the ≥ version checks) |
| `mutate-block1` | **86 mutations, all caught** |
| `verify-ea-block2-core` | **53 checks, all green** (D1, D1b, D6, D7, D7b, D14, A1, helpers) |
| `mutate-ea-block2-core` | **50 mutations, all caught** |
| Inner Tempest 1.0.4 on 3.678.0 | Blocks 1–4, 6–10 and the weapons all green (392, 205, 1040, 1360, 183, 228, 123, 84, 118, 117). Block 5 needs the Inner Tempest book's markdown, not in this workspace. |
| Full core sweep (`tools/verify.mjs`, 659 harnesses) | **651 passed; 8 failed** on pins 3.678.0 moved: verify/mutate-block8-core (the settled hook), mutate-casting-dc (the armour part's label), mutate-chapter9-241-250 (the fumble's `ritual`), verify/mutate-mutation-anchors and verify/mutate-percentile-bias (the Resonance roll's second draw). All were re-anchored and re-run green. |

**Found by an independent review before release (all fixed, each with a mutation, REVIEW 1–11 in `mutate-block2`):**
- Tap Magical Energy read the sheet's manual caster level, not the resolved one;
- antimagic was keyed by actor id, which an unlinked token shares with its base actor: now by uuid;
- antimagic switched off any timed effect (the system's `spellEffect` marker is also on poisons and perils), and treated an affliction as a magic item;
- the wild surge raced the spell's own PP payment: it now waits for `trgPrimeSpellSettled`, and a scroll's or wand's release check surges through the new `trgPrimeReleaseRolled` (Q7);
- conviction was written to the wrong path;
- a row's condition never expired;
- the next-spell surcharge was never spent;
- the DB row landed on a raw field;
- Ley Sense ignored the map (its DC was lost when Block 1's actions were cloned);
- dissipating essence had no single writer (now the acting GM, or the owner when no GM is on), and asking for the surcharge must not spend it (a casting refused afterwards costs nothing). The second has a check; the first is a multi-client race the harness cannot stage, so the live test is where it shows.

---

## 0.2.0 on TRG Prime 3.677.0 (1 November 2026)

Every figure in this section comes from a run in this session. 0.2.0 has not been tested live yet.

| Harness | Result |
|---|---|
| `verify-block1` (against 3.677.0) | **881 checks, 0 failures.** The book extract is v1.6's. |
| `mutate-block1` | **86 mutations, all caught**, tree restored |
| `verify-ea-block1-core` | **89 checks, all green** (C1–C14) |
| `mutate-ea-block1-core` | **66 mutations, all caught** |
| Inner Tempest 1.0.3 on 3.677.0 | Blocks 1–4, 6–10 and the weapons all green (392, 205, 1040, 1360, 183, 228, 123, 84, 118, 117). Block 5 needs the Inner Tempest book's markdown, not in this workspace. |
| Full core sweep (`tools/verify.mjs`, 657 harnesses) | **651 passed; 6 failed** on pins that C12 and C13 moved: verify/mutate-block5-core, verify/mutate-fixes-3669-1, mutate-fixes-3669-2 and mutate-chapter6-gear-151-160. All were re-anchored and re-run green. |

**Found by the harness while rebuilding:** the Scáthfán had lost its racial note after v1.6 corrected "Nyrrin". Fixed before release; see `RELEASE_NOTES_0.2.0.md`.

---

The rest of this report is 0.1.0's, kept as written.


**Release:** Eldritch Arts 0.1.0 (Block 1) on TRG Prime 3.675.0 · **Date:** 28 October 2026

Every figure here comes from a run in this session. Nothing has been tested live yet; live testing is yours, after you install.

## The module

| Harness | Result | What it holds |
|---|---|---|
| `tools/verify-block1.mjs` | **866 checks, 0 failures** | **A** The book: every printed paragraph of the races, heritages, abilities, backgrounds, feats, actions, weapons and goods is in its item, read from the extract, never retyped. Each race's item plus the size table gives the printed attribute line, Wyrmdral's included. Every weapon's and good's table numbers match. Every heritage's resistance and spell is checked against its text. **B** The system's own readers take every declaration: conditionals, goods rows, spell DC and damage bonuses, Spell Resilience and its reduction, the fumble reroll, the feat's time ladder, the caster-level secondary step and pooled bonus keys. **C** Every granted name exists, in this module's packs or the system's, and no name clashes with a core item. **D** Registration against the system's real registry, with no problems reported. The proficiency rules run through the system's own profile. The pure decisions are checked. **D2** The Uses and hooks are driven with Foundry stand-ins: tokens on a grid for the aura, the surcharge and the 30-ft release; world time for the lockouts; and the system's own Invest Item rules. **E** The wiring, versions, packs and status lines. |
| `tools/mutate-block1.mjs` | **73 mutations, all caught**, tree restored | Each breaks one printed number, one proposal, one row the system reads, one decision, or one wire. |

## The system (TRG Prime 3.675.0)

| Harness | Result |
|---|---|
| `verify-ea-block1-core` | **71 checks, all green** (C1–C11) |
| `mutate-ea-block1-core` | **53 mutations, all caught** |
| The full sweep (`tools/verify.mjs`, 655 harnesses) | **All 655 pass**: undefined names, the uncalled-export ratchet, every per-rule verify with its mutation file. (As the sweep itself says, chapters with no file of their own are uncovered.) |

**Older checks re-anchored.** Twelve older harnesses pinned a source line that Block 1's seams moved. Each was re-pinned to the new line, so it still catches what it was written to catch:
- verify/mutate-block2-core, -block5-core, -block8-core, -block34 and -block36b;
- verify/mutate-fixes-3669-2;
- verify/mutate-spell-storing;
- verify/mutate-spell-attack-bonus;
- verify/mutate-chapter6-gear-151-160 and -181-190;
- mutate-release-links;
- verify-ff30-codex.

**Uncalled-exports ratchet.** Five keeps were added, each with its reason.

## Inner Tempest on TRG Prime 3.675.0

Inner Tempest 1.0.3's harnesses were run against 3.675.0, unchanged. Blocks 1–4 and 6–10 and the weapons are all green (392, 205, 1040, 1360, 183, 228, 123, 84, 118 and 117 checks). Block 5 could not run here: it reads the Inner Tempest book's markdown, which is not in this workspace. That is not a failure of the code.

## Independent review

A separate reviewer read the runtime code against the system's APIs. It found ten problems, all fixed before release, with checks and mutations added for each:
- Null Aura's penalty also lowered spell attacks against DB.
- A Ley Sense Partial locked nothing.
- Magic Drain's choices could open on the GM's screen.
- Draining another creature's item failed on a player's client.
- Magic Drain's DB bonus was untyped.
- Magic Drain's energy lasted 1 minute per point of energy, not per PP drained.
- Quickbind skipped Invest Item's rules.
- Wanderer's Instinct was pre-ticked on every Survival check.
- "Until the end of your next turn" had no backstop.
- Vir-ellian Release dropped its energy if the blast failed.

Two points it raised are your rulings: B1-21 and B1-22.

## Not tested

- **Live, in Foundry.** The checklist is in `RELEASE_NOTES_0.1.0.md`.
- **Socket relays** between a player and the GM. These are the system's own, and are exercised only live.
