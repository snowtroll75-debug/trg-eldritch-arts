# Eldritch Arts 0.7.1 and TRG Prime 3.682.1 — Live Retest

3 November 2026. This retest covers the three findings from `LIVE_TESTING_REPORT_0.7.0.md`. It ran after Graham installed TRG Prime 3.682.1 and Eldritch Arts 0.7.1, in Foundry V14, world "TRG V14", as Gamemaster in Chrome.

**Throwaway material, all deleted afterwards:**
- the scene "ZZ EA Retest 0.7.1" (5 ft squares);
- "ZZ EA Spellblade": 5th level, Path of the Arcane Duellist, with a Broadsword. Its spells came fresh from 0.7.1's compendium, plus the core's Orb of Force and the Dimensional Step ability;
- "ZZ EA Target" and "ZZ EA Behind".

**What was changed, and put back:**
- **None of Graham's actors was touched.** Graham's combat was running throughout (five combatants) and was not touched; the Spellblade was not in it.
- **Dice:** `CONFIG.Dice.randomUniform` was set at 0.3 (a 14) for the tests, then restored.
- **Removed:** the test chat cards, the scene and the actors. The Conviction hook came off.
- **The view** went back to Oldwatch Approach.
- **No console errors.**

## Results

| # | Test | Result |
|---|---|---|
| 1 | Battle Mage on the core's Orb of Force (finding 1) | **Pass.** The card reads "BAB 5 in place of BSB 2: +3 untyped to the attack". The attack was 19 (14 + 2 + 3) against DB 10. The casting check was untouched (16, BSB and tradition ability only). |
| 2 | Thunderous Strike, with a creature targeted (finding 2) | **Pass.** It was not refused. The Strike's 20 was the casting check (a Critical against DC 11). The creature behind the target saved: a Partial at DC 15, 5 sonic. Arcane Echo's +1 attack and +1 damage rode on the Strike. |
| 3 | Shooting Star, with a creature at 25 ft targeted (finding 2) | **Pass.** It was not refused. The Broadsword struck in melee at 25 ft: 19, "sees through concealment". The trail was laid on the target. |
| 4 | Shielding Strike, with a creature targeted (finding 2) | **Pass.** It was not refused. The Strike hit, and the caster gained +2 status DB. |
| 5 | Spinning Weapon, with a creature targeted (finding 2) | **Pass.** It was not refused. Cold was chosen, giving the "Spinning Weapon (1d6 cold)" rider. |
| 6 | AP outside the combat (finding 3) | **Pass.** With Graham's combat running, Dimensional Step teleported the Spellblade 15 ft at no AP (3 before, 3 after), with no "1 AP spent" line. Thunderous Strike, Shooting Star, Shielding Strike and Spinning Weapon cost no AP either. |
| 7 | Who counts as in the combat (the module's AP gate, read only) | **Pass.** The Spellblade counts as out of it. All five of Graham's combatants count as in it, including the three unlinked tokens. |

**Not retested live:** that a combatant still pays the module's AP. That would have meant starting a combat beside Graham's. The harness covers it: `verify-block4`'s G checks and `mutate-block4`'s three gate mutations.

No new findings.
