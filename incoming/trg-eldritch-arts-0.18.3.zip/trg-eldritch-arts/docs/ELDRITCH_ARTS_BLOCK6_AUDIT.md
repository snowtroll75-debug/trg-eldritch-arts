# Eldritch Arts Block 6: audit (archetypes, class feats, metamagic)

4 November 2026. Block 6 covers Chapter 5's **23 archetypes** (L2892–3192) and **97 class feats** (L3210–4310). It also takes in the five Block 5 feats that waited for the module's metamagic: Echo of the Ancestors, Resonant Pulse, Resonant Harmony, Spell Surge and Piercing Insight.

It was read against:
- ***TRG Prime: Eldritch Arts* v1.6** (`book-text.json`, `ea.md`);
- **Graham's rulings** of 1 November and his answers Q1–Q88;
- **TRG Prime 3.683.0**, surveyed in its source.

Six reviewers read a part each. This document merges them, and their full tables are the appendices.

**Status: answered by Graham, 4 November 2026, 03:11: "proposed except Q89: One release".**
- **Q89, changed:** **one release.** All of Block 6 ships together: TRG Prime **3.684.0** with every seam G1–G26, and Eldritch Arts **0.9.0** with all 125 feats, under one sweep, one review and one live test.
- **Every other question (Q90–Q149):** as proposed. The alternatives offered were not taken, so:
  - **Q90:** the core's Archer ("+8 levels") stays unparsed; G8 is opt-in for the Eldritch Arts archetypes.
  - **Q98:** the Nyrinn penalty applies to a Warlock's pool as printed, floored at 0.
  - **Q110:** Fate's Favour is read literally; Inner Tempest's B5-3 is unchanged.
  - **Q117:** "Defending I" is left off Runeblade, and its card says so, until Graham names the rune.
- **Graham's answers after the release** (4 November, 18:43), for TRG Prime 3.684.1 and Eldritch Arts 0.9.1:
  - **DB on spell attacks:** "Every DB bonus should apply to spell attacks (unless specified otherwise)". This confirms G20 as built.
  - **Stacking:** "Status bonuses to DB should NOT stack". Defence rows stack by type on every attack path.
  - **The Witch:** "All Witch spells are considered to be High Magic". This supersedes D4a's Ethereal and Verdant only, and Q99's reading.
  - **Wellspring Conduit:** "should count the PP cast for that spell", as Q101 reads the Pacts.
  - **Two-skill prerequisites** (18:49): "Yes for the skill rank prerequisites". The core checks clauses like "Occultism or Religion 1 rank" for every feat.
  - **Economic and Signature Spell** (18:49): "Yes". Their reduction lowers the PP actually paid.
- **Built** (4 November): TRG Prime 3.684.0 and Eldritch Arts 0.9.0. See `RELEASE_NOTES_0.9.0.md` and the core's `release-notes-3.684.0.md`.

## Scope

| Part | Feats | Graded (A / B / C / D) | Appendix |
|---|---|---|---|
| **Archetypes, part 1:** the seven Pacts, Hex Weaver, Bloodmage, High Mage, Birthrager, Blood of the Wyrm, and their class feats (Sanguine Channel, Crimson Rite, Draconic Claws, Elemental Exhalation, Wyrm Ascendant) | 17 | 7 / 10 / 0 / 0 | A |
| **Archetypes, part 2:** Eternal Vigil, Fatespinner, Ferromancer, Leyline Weaver, Runeblade, Runebreaker, Shade Master, Spellwarden, Spell Duellist, Spell Weaver, Stormcaller, and their 35 class feats | 46 | 14 / 29 / 3 / 0 | B |
| **Runemage class feats** (the core's own archetype): Prepared Sigil, Runic Reservoir, Living Script, Combat Inscription, Ley-Etched Symbol | 5 | 3 / 2 / 0 / 0 | C |
| **Metamagic (13) and Adept (7) class feats,** the five deferred from Block 5, and **the metamagic seam's design** | 25 | 4 / 16 / 5 / 0 | D |
| **Warlock and Witch class feats,** and **the Warlock's Charisma PP pool** (EA-C2, Q52) | 21 | 6 / 15 / 0 / 0 | E |
| **Sorcerer and Spellblade class feats** (and Considered Attack; none prints Archmage) | 14 | 6 / 7 / 1 / 0 | F |

Three metamagic feats (Steelbinding, Lightning Rod, Thunderclap Aura) also carry an archetype's trait, so two parts list them. The grades assume the seams below.

**The C feats** each leave one clause to the GM:
- Absolute Denial, Eye of the Storm and Reflective Warding (part 2);
- Spellthread, Spellthread Mastery, Spellthread Unbound and Versatile Binder (the last also waits for the Grimoire's Summons spells);
- Piercing Insight;
- Magical Retribution, whose "whilst casting" the system models only for extra casting time.

**Waits on later blocks:**
- **Dragon's Breath, Elemental Strike and Dragon Wings** are Grimoire spells, Blocks 7–8. The Draconic and Elemental Pacts and the Draconic Pact Boon ship now; their cards say the spell arrives with the Grimoire.
- **Versatile Binder** waits on the Summons spells (Blocks 7–8).
- **The Orb kind** and the Rods of Focused Spell are Block 9.

## What the reviewers found that matters most

- **Archetype class-feat traits are hyphenated in the book** (ETERNAL-VIGIL, BLOOD-OF-THE-WYRM). Built that way, those feats would be open to every character. They are authored with spaces, and each archetype is registered, so they gate. No core change is needed.
- **Most archetypes print "+10 levels" as their progression requirement.** The core deliberately leaves it unparsed (it fails open), so no Eldritch Arts archetype ever blocks a second one. Q90 asks how to read it; seam G8 builds it.
- **No module can add metamagic today.** It is a hard-coded table, and item casts get none at all. The design is G1, below. Part D found that on an innate cast a marked spell's metamagic is paid from the free innate warp budget, which would make Pact Channeler and Echo free and leave the Warlock's pool unspent (Q95).
- **The Warlock's Charisma pool exists in the core already,** but only once the sheet's tradition is set, and the Warlock class names none. So a blank sheet has 0 PP (Q97).
- **A core gap:** a ward's DB bonus (Forbidding Ward) doesn't apply against spell attacks. Spellblade's Mark needs it too (G20).
- **Storing Rune** (Block 3a) probably answers "no bonded item" for a Rune Sorcerer, because the core stores spells only in an Arcane Bond. To be checked live; G16 fixes it.
- **Five feats belong to the core's Runemage archetype**, not to any Eldritch Arts one. They are audited in Appendix C.
- **Book text:**
  - Steelbinding's "Requirements" clause was lost in extraction (a bold-format slip in the book, m45); it will be restored.
  - "Defending I" (one of Runeblade's runes) exists nowhere (Q117).
  - Temporal Reprieve still prints no cost (m46; Q125).

## Proposed seams (TRG Prime 3.684.0, or two releases: Q89)

Prepared separately for approval, as before. All are additive and default-off, except where a row says "fix".

| # | Seam | Used by |
|---|---|---|
| **G1** | **`registerMetamagic` (D2):** module options in the Warp? dialog beside the core's, in the same totals (PP raise the DC, count against the cap, refunded by degree). An entry may:<br>• be gated and spend a Focus use;<br>• pay in PP, AP or another resource;<br>• add riders after the cast;<br>• be granted by an effect or a rod.<br>It reaches innate casts, and item casts through G6; it can be preset by `castSpell`; and a threaded second spell can resolve under the first spell's check (Spellthread). New effects: advantage on the check, added traits, a new typed damage pool, typed Save DC rows, a second target at half damage (Echo), a recipient for a self-only spell (Harmony), ×1.5 range, duration or area, a die step, fumble and Resonance disadvantage, Spellthread's step. The cast hooks report which metamagic was taken, and `helpers.metamagicCatalogue` lists it. Design: Appendix D, S-M1, S-M3, S-M4, S-M11. | the 13 metamagic feats; Echo, Pulse, Harmony, Spell Surge, Piercing Insight; Spell Weaver, Overflow Casting, Wellspring Conduit; Ley-Etched Symbol; Resonance Surge; Sanguine Channel |
| **G2** | **`registerCastPPSource`:** another way to pay a cast's PP (the rod draw, generalised), counted in the availability test and split by degree. | Bloodmage's Bleed |
| **G3** | **`registerMetamagicPayment`:** an option's PP paid in AP instead, while the Casting DC counts them as if paid. | Metamagic Adept |
| **G4** | **`registerCastCostModifier` (D5's discount half):** PP off what is paid, with a floor. | Hex Mastery, Stormcaller's Storm Bolt, Spell Weaver (Q93) |
| **G5** | **`registerFumbleModifier`, `registerResonanceModifier` (D6):** bias, a single roll for High Magic, forced Resonance. | Mana Bound, Spell Surge, Spellthread, High Magic Resonance, Resonance Surge |
| **G6** | **`registerChargedItemRule` (D12, the feat half):** one spend path for every charged-item cast. Rules may set the wield limit, a cost cut, own-PP payment, metamagic on an item cast, and an after-release step. | Conduit Mastery, Dual Channel, Metamagic Conduit, Resonant Conduit, Weave Infusion |
| **G7** | **The 0 HP moment:**<br>• an "about to fall unconscious" offer;<br>• a death guard that leaves half HP and announces it held;<br>• a waived Dying check;<br>• (optional) a guard that casts on yourself. | Subconscious Casting, Pact Ascendant (Demonic), Last Horizon, Eternal Vigil |
| **G8** | **Archetype progression:** "+N levels" read as levels gained since taking the archetype (the level stamped on the feat), and "cannot progress". **Opt-in per archetype:** the core's Archer ("+8 levels") stays unparsed unless you say otherwise. | most archetypes (Q90, Q91) |
| **G9** | **Prerequisites:**<br>• "A or B N ranks";<br>• `registerFeatEligibility(name, actor => reason)` for what the parser can't read ("Arcanum Birthright", "cannot take with Wild"). | Elemental Exhalation, Wyrm Ascendant; Arcane Study, Resonance Surge, High Magic Resonance, Blood of the Wyrm, Eternal Vigil, Runebreaker, Shade Master, Stormcaller |
| **G10** | **Casting while raging.** | Birthrager |
| **G11** | **A BSB floor of half your level, rounded up.** | Birthrager |
| **G12** | **Spell riders per PP spent;** a spell damage bonus valued at the spell's PP. | Angelic and Demonic Pacts; Dangerous Sorcery |
| **G13** | **A sense range bonus.** | Void Pact |
| **G14** | **A cast option's attack-only bonus and one-target Save DC;** a spell-check gate row that is attack-only. | Sanguine Channel; Spellblade's Mark |
| **G15** | **A warp that changes the damage type.** | Blood of the Wyrm |
| **G16** | **A spell store held by a rune** (not only an Arcane Bond), a foreign stored spell, and a marker for a stored release. Fixes Storing Rune. | Storing Rune, Runebreaker, Rune Rend, Runic Overload |
| **G17** | **A cast reaction that scales the spell** (halve or double) or turns it on its caster. | Counter Channel and its chain, Reflective Warding |
| **G18** | **Conviction refund on saves and skills, once a day.** | Fate's Favour |
| **G19** | **Rune damage that bypasses resistance.** | Runeforge Mastery |
| **G20** | **Defender DB rows against spell attacks.** A fix: wards (Forbidding Ward) now apply too. | Shadowmantle, Spellblade's Mark |
| **G21** | **Declared extra daily uses** (beside the core's fixed table). | Extra Communion, Deep Weave, Extra Reservoir |
| **G22** | **A free somatic component by tradition.** | Ferromancer |
| **G23** | **Spell damage names its caster** on `trgPrimeDamageApplied`. | Warlock's Hex, Hex Binders Curse |
| **G24** | **A spell cast with range measured from another token,** and **a spell sustained by another creature.** | Symbiotic Witch |
| **G25** | **Small helpers and fields:**<br>• the innate save DC (optional);<br>• the weapon on an attack's reaction context;<br>• declared bonus cantrips;<br>• declared melee abilities (Int to attack and damage);<br>• target-scoped strike and spell riders;<br>• `warpFreeSchool: "*"`;<br>• a prepared-sigil cast option;<br>• Combat Inscription's DC part;<br>• `helpers.spellCastable`. | Xithra Cone, Malevolent Blast; Arcane Fencer; Extra Cantrip; Clever Strike, Clever Damage; Spellblade's Mark; Resonance Surge; Prepared Sigil, Combat Inscription |
| **G26** | **(optional)** A step before a pending cast's interruption settles. | Magical Retribution |

## Rulings needed

The detail behind each question is in its appendix (the mapping is at the end).

### Across the block

| # | Question | Proposed |
|---|---|---|
| **Q89** | **One release or two?** Block 6 is the largest: 120 feats and about 25 seams. | **Two halves, each with its own core release, review and live test.**<br>• **6a:** the metamagic family (G1–G6), the Metamagic, Adept, Warlock, Witch, Sorcerer and Spellblade class feats, the Warlock's pool and Block 5's five deferred feats.<br>• **6b:** the 23 archetypes with their class feats, and the Runemage feats. |
| **Q90** | **"+10 levels"** (the Pacts, Hex Weaver, Bloodmage, Blood of the Wyrm, Runeblade, Spell Duellist): ten levels since taking the archetype, or character level 10? Today it never blocks. | **Levels gained since taking it**, the reading the core's own comment gives the Archer's "+8 levels". The core leaves that line unparsed ("a delta this system has nowhere to store"); G8 adds the store. Characters made before the stamp pass open. The Archer stays as it is unless you want it gated too. |
| **Q91** | **Archetypes with no progression line** (Runebreaker, Shade Master, Stormcaller), and Leyline Weaver's "Tradition skill +10 ranks". | **The first three: no later archetype**, as Eternal Vigil's "cannot progress" (M3). **Leyline Weaver:** any one tradition skill at +10 ranks. |
| **Q92** | **More than one Pact?** Pact Channeler, Pact Boon and Pact Ascendant read "your patron", in the singular. | **One Pact ever.** |
| **Q93** | **Do cheaper spells lower the casting DC?** Storm Bolt "costs 1 less PP"; Spell Weaver −2; Hex Mastery −1. | **Payment only.** The DC, the cap and the save DC read the PP as cast. |
| **Q94** | **Which casts take module metamagic?** | **Learned and innate casts.** Charged items only through Metamagic Conduit. Never scrolls, potions or stored spells. Cantrips no, as the core. Block 5's Pulse card is corrected. |
| **Q95** | **Who pays a metamagic's PP on an innate cast?** From the free innate budget, Pact Channeler and Echo would be free. | **The PP pool** (the Warlock's Charisma pool). No Casting DC is raised, as no check is rolled. |
| **Q96** | **When is a Focus metamagic's use spent?** | **When the cast pays its PP:** Success or better, Failure, Fumble or Blunder. Not on a Partial, nor on a refunded cast. On an innate cast, when the spell is cast. |
| **Q97** | **The Warlock's pool (C2, Q52):** the core already gives PP = Charisma once a tradition is set, but the Warlock names none. | **The Bonded Soul's choice writes one of the soul's two traditions** when the sheet's is blank. The pool is spent only by Warlock's Hex, Pact Channeler and what any character may pay PP for (Dispel); spells never spend it. |
| **Q98** | **A Nyrinn Warlock:** the racial −1 PP a level empties the Charisma pool by 3rd or 4th, though sidebar 9 recommends the pairing. | **As printed** (floored at 0). Your C2 wording, "always has at least 2 PP", would instead suggest **a floor of 2**; or the penalty could spare a Warlock's pool entirely. |
| **Q99** | **Spells a Witch gains outside Ethereal and Verdant** (Forbidden Lore, Pact Boon, Pact Ascendant). | **High Magic,** as M27 says for High Magic classes. |
| **Q100** | **Birthrights through High Mage and Birthrager:** Wild has no fixed spell; does the pick satisfy "Dragon/Arcanum/Wild Birthright"; Dragon Claws; the Birthrager's ability and tradition. | **Wild not offered.** The pick counts for those prerequisites and the bar. No Dragon Claws; Draconic Infusion works on any natural Claw. The birthright's first key ability and its tradition. |

### Archetypes

| # | Archetype or feat | Question → Proposed |
|---|---|---|
| **Q101** | Angelic and Demonic Pacts | **"Per PP expended":** a Warlock pays no PP. → **The PP the spell is cast at** (base + warps and metamagic), the innate spell's own PP for a Warlock. Not reduced by a Partial's refund. Cantrips 0. |
| **Q102** | Elemental Pact | **"A spell of your element type":** → **either** the element's trait, or damage of the mapped energy type. +1 a die (C6). |
| **Q103** | Hex Weaver | **Hexes opened or granted, and its one spell:** → hexes **opened** through Specialist Spell. The spell is new, known permanently, base PP ≤ level + 1, cast with Spellcraft as High Magic. |
| **Q104** | Birthrager | **"Concentrate actions" while raging:** → casting and the concentrate actions **part of casting or sustaining**. Others stay barred. |
| **Q105** | Bloodmage | **Its fumble's extra Bleed:** → **only on a cast that used the Bleed,** at the PP it was cast at, per 2 PP rounded down. |
| **Q106** | Blood of the Wyrm | **"Any spell that has an elemental trait":** → any damaging spell with the Elemental trait, or an element or energy trait. All of its damage becomes the dragon type. Once a cast. |
| **Q107** | Draconic Claws, Elemental Exhalation | **Unprinted numbers:** → Claws +**1d6** secondary of the dragon type. Exhalation as Dragon's Breath: acid and electricity a 60-ft line; cold, fire, poison and sonic a 30-ft cone. |
| **Q108** | Eternal Vigil's warp | **"Fast healing 5 for rounds = PP":** → **the spell's targets;** rounds = PP spent on the cast less these 2. |
| **Q109** | Eternal Vigil at 0 HP | → **Once a day** at 0 HP (not against an outright kill): no Dying. Touch of Healing heals from 0 (G7). |
| **Q110** | Fate's Favour | **"Only expend the conviction if the result is a success or greater":** read literally, it is refunded on Partial or worse. Inner Tempest's identical sentence (B5-3) was ruled the other way. → **Literal**, on saves and skills, once a day. Say whether B5-3 should be revisited. |
| **Q111** | Damaging Gambit | **"Advantage on the attack element":** a spell attack's check is its attack. → **The one roll has advantage.** |
| **Q112** | Ferromancer | **Metal shards replace material and somatic components** for arcane spells: → **yes**, a free hand isn't needed; a pouch use each arcane cast; the Arcane tradition only. |
| **Q113** | Leyline Weaver | **A Critical's "benefits ×2":** → every number in the rolled effect doubles. An effect with no number lasts to the end of your next turn. |
| **Q114** | Instinctive Counter Channel, Duellist's Supremacy, Leyline Anchor, Destiny's Embrace | **"Once per round" on a Focus ability:** → **the Focus use is still spent** (m81's reading of Eclipse Step). The feat changes only the action, PP or trigger. |
| **Q115** | Runebreaker | **What it absorbs:** → only a spell whose **sole target is you.** You pay Storing Rune's PP and your reaction. The Will save is against the caster's Spell DC. On release you are its caster. |
| **Q116** | Runic Overload | **"Effective PP +2":** → counts 2 PP higher for every number that reads PP; buys no warp. |
| **Q117** | Runeblade | **"Defending I"** exists nowhere. → **Name the intended rune;** until then it is left off, and the card says so. |
| **Q118** | Counter Channel | **"Variables" halved or doubled:** → area (rounded down to 5 ft), duration, number of targets (min 1) and the number of damage dice (min 1). On any creature's spell; the module asks only for non-allies unless turned on. |
| **Q119** | Absolute Denial | **"Spells of PP 8 or lower":** → **the PP as cast** (warps included); enemy spells only. |
| **Q120** | Eclipse Step | **"Only if you end your turn in dim light":** → the free Fade Step must **land** in light 5 or less. |
| **Q121** | Grasping Shadows | **"Within 10 ft of your destination square"** from a spell: → **within 10 ft of you;** of the landing square for Fade Step. |
| **Q122** | Temporal Reprieve | **"1d8 HP per PP expended"**, with no cost or cap printed: → **any number of PP up to your level,** per use (Focus). |
| **Q123** | Prepared Sigil | **Does a sigil lift the Symbol's free-hand rule?** → **Yes**; a somatic spell still needs a hand, a focus or an implement. |
| **Q124** | Prepared Sigil | **With Quicken:** → **they stack** (the sigil isn't metamagic); never below 1 AP. |
| **Q125** | Ley-Etched Symbol | **"Gaining the benefits of a ley line":** → a benefit from **Tap or Channel Ley Line** (or Leyline Weaver's), for its duration; standing in a ley area doesn't count. The backlash is the Ley Line table's at that line's level, to the end of your next turn. |

### Metamagic and Adept

| # | Feat | Question → Proposed |
|---|---|---|
| **Q126** | Spellthread (and Mastery, Unbound) | **Action, cap and cost:** → **one casting** of the woven spells' longer casting time, one check at DC(total), the total counted against the cap. Other metamagic and warps add to the total. |
| **Q127** | Lightning Rod | **"Hit", the splash, the −2:** → it took electricity damage from the spell. Splash: half the dice count, electricity, **no save**. −2 on the marked creature's save against the triggering spell; "holding metal" is a tick for the GM. |
| **Q128** | Subconscious Casting | **"When you would fall unconscious":** → damage (lethal or subdual) taking you to 0, not sleep. A normal cast (check, PP + 6, Focus). Above 0 HP after it: no fall and no Dying. |
| **Q129** | Thunderclap Aura | **"1d6 per 2 PP of the cast spell":** → the cast's **total PP** (this feat's +2 included); everyone within 10 ft but you; on success only. |
| **Q130** | Metamagic Conduit | **"Double the item's normal maximum":** → double the PP the item **releases that spell at**; the wielder pays the excess from the pool. |
| **Q131** | Weave Infusion | **Payment and "disadvantage" on Item Depletion:** → your PP charged by degree, the item untouched. On that table low is worse, so disadvantage keeps the **lower** d100. |
| **Q132** | Spell Surge | **"(which has the focus trait)":** → **one surge, one effect,** one Focus use until Refocus. |
| **Q133** | Versatile Binder | **How an existing creature resists:** → the spell's own save against your Spell DC. On a failure it is bound as a summoned creature would be. |

### Warlock and Witch

| # | Feat | Question → Proposed |
|---|---|---|
| **Q134** | Warlock's Hex | **Focus and 1 PP:** → **both are paid.** Offered after a spell's or Xithra's damage; Xithra's saves count. "Charisma modifier" rounds is Charisma, min 1. |
| **Q135** | Hex Binders Curse | **No duration or frequency printed:** → **until you curse another, it dies, or the next daily preparation.** Extra dice once per Strike or spell, of the triggering damage's type; not recurring damage. |
| **Q136** | Malevolent Blast, Xithra Cone | **The save DC:** → **the Warlock's innate save DC** (10 + Charisma + level, with the soul's +1 where it applies). Malevolent: a failed save gives Stunned 1, or 2 if the hit was critical. |
| **Q137** | Symbiotic Witch | → Conduit: base PP ≤ 4 and the total ≤ 4, range from the familiar, once a day. Sustain: one spell; damage to the **familiar** asks the check; the Witch may recover PP meanwhile. |
| **Q138** | Soul-Bound Grimoire | **The stored spells when the familiar dies:** → **lost**; nothing imprints while the bond is severed; no limit stored; "erase" is a Use. |
| **Q139** | Warding Sigil | **No action printed:** → **1 AP**, Focus. |
| **Q140** | Ethereal Insight | **"The familiar gains the benefit":** → Darkvision within 30 ft; the Witch's daily See Invisible covers it too, from the one casting. |
| **Q141** | Pact Ascendant (Demonic) | **The burst:** → your **Level DC**; one fire packet with the Evil trait; 20 ft round you, allies included; you rise at half HP; once a day. |

### Sorcerer and Spellblade

| # | Feat | Question → Proposed |
|---|---|---|
| **Q142** | Arcane Study | **The book, the day, "all warping costs":** → the book **starts empty** (spells scribed with Learn a Spell); the pick lasts **to the next daily preparation**; the discount is −1 off the spell's **total** warp (min 1). |
| **Q143** | Bespell Weapon | **When, and sustaining:** → on the turn you cast; sustaining is **1 AP** (Concentrate), as Sustain a Spell. |
| **Q144** | Bonded Infusion | **A Spellblade who isn't a focus caster:** → **+2 item on casting checks** while wielding the infused weapon, either way; it also stands in for somatic. |
| **Q145** | Considered Attack | **How much:** → **once a Strike, 1 extra AP for +2,** untyped. |
| **Q146** | Dangerous Sorcery | **"Its PP cost":** → **the printed PP** (a cantrip adds 0); "without a duration" means no Duration entry. |
| **Q147** | High Magic Resonance | **"The first spell fumble each day":** → the first **Fumble** degree each day becomes a Failure, automatically; a Blunder isn't eased. |
| **Q148** | Resonance Surge | **What the 2 PP buys:** → up to 2 PP of the spell's own warps; not metamagic. The forced Resonance is rolled as a High Magic Resonance of that cast. |
| **Q149** | Magical Retribution | **"Whilst casting":** → automated in the extra-casting-time window (G26). Elsewhere a reaction button for the table's ruling. |

## Plan

1. **Graham answers Q89–Q149.**
2. **TRG Prime 3.684.0** (and 3.685.0 if Q89 is two halves): the approved seams, each with its harness pair, the sweep and an independent review.
3. **Eldritch Arts 0.9.0** (and 0.10.0): the feats, registrations and automations; `verify-block6*` and `mutate-block6*`; the review.
4. **Live test** of each.

## Appendices: the reviewers' reports

The question numbers in the appendices are each reviewer's own. They map to this audit as follows.
- **A (archetypes, part 1):** Q?-1 → Q90; Q?-2 → Q92; Q?-3 → Q101; Q?-4 → Q102; Q?-5 → Q103; Q?-6 → Q100; Q?-7 → Q104; Q?-8 → Q105; Q?-9 → Q106; Q?-10 → Q107.
- **B (archetypes, part 2):** Q?-1 → Q90/Q91; Q?-2 → Q108; Q?-3 → Q109; Q?-4 → Q110; Q?-5 → Q111; Q?-6 → Q112; Q?-7 → Q113; Q?-8 → Q114; Q?-9 → Q117; Q?-10 → Q115; Q?-11 → Q116; Q?-12 → Q118; Q?-13 → Q93; Q?-14 → Q119; Q?-15 → Q120; Q?-16 → Q121; Q?-17 → Q122.
- **C (Runemage):** Q?-1 → Q123; Q?-2 → Q124; Q?-3 → Q125.
- **D (metamagic and Adept):** Q?-1 → Q94; Q?-2 → Q95; Q?-3 → Q96; Q?-4 → Q126; Q?-5 → Q127; Q?-6 → Q128; Q?-7 → Q129; Q?-8 → Q130; Q?-9 → Q131; Q?-10 → Q132; Q?-11 → Q133.
- **E (Warlock and Witch):** Q?-1 → Q97; Q?-2 → Q98; Q?-3 → Q134; Q?-4 → Q135; Q?-5 → Q136; Q?-6 → Q93; Q?-7 → Q99; Q?-8 → Q137; Q?-9 → Q138; Q?-10 → Q139; Q?-11 → Q140; Q?-12 → Q141.
- **F (Sorcerer and Spellblade):** Q?-1 → Q142; Q?-2 → Q100; Q?-3 → Q143; Q?-4 → Q144; Q?-5 → Q145; Q?-6 → Q146; Q?-7 → Q147; Q?-8 → Q148; Q?-9 → Q149.

The appendices' seam numbers (S-…) map to G1–G26 by the "Used by" column above.

### Appendix A. Archetypes, part 1

#### Archetypes, part 1: the Pacts, Hex Weaver, Bloodmage, High Mage, Birthrager, Blood of the Wyrm

Read against *Eldritch Arts* v1.6 (`book-text.json` `sections.archetypeFeats` / `classFeats`; `ea.md` L2888–3204 and L3204–4318), Graham's rulings of 1 November 2026 and Q1–Q88, and **TRG Prime 3.683.0** source (`/home/claude/core-3676/trg-prime/module`). The core spells and feats were read from the pack dump (`/home/claude/ea-tools/core-dump/*.json`).

**Scope.** 12 archetype feats and the 5 class feats whose traits name one of them. The trait scan of all 97 class feats found only **BLOODMAGE** (Crimson Rite, Sanguine Channel) and **BLOOD-OF-THE-WYRM** (Draconic Claws, Elemental Exhalation, Wyrm Ascendant). No class feat carries a Pact, Hex Weaver, High Mage or Birthrager trait. **Pact Channeler** (and through it Pact Boon and Pact Ascendant) instead requires "Pact Archetype feat". Those three are WARLOCK/WITCH class feats and belong to another reviewer; how the Pacts gate them is covered in note 21.

##### What TRG Prime has, and what it lacks (for these archetypes)

| Need | The core today | Gap |
|---|---|---|
| **Offering an archetype feat** | The `archetypeFeat` slot keeps `category "Archetype"`. Its class traits (core list plus `registeredClassNames()`) and tier traits (Martial/Expert/Adept) gate any-of against the effective classes and tiers (`picker-filters.mjs` `buildPickerFilter` case `archetypeFeat`, L969). "Non-X" is checked by `meetsClassPrerequisite` (L63). | None. WARLOCK/WITCH gate by class, since both classes are registered (Blocks 3–4). ADEPT gates by tier. BERSERKER is no class or tier, so its gate needs a feat gate (below). |
| **One archetype at a time** | `withArchetypeProgressionGate` / `blockingArchetype` (L753–816). Its parse is `archetype-progression.mjs` `parseProgressionClause` (L107), which reads "+N ranks", BAB/BSB/ability/Level, "Level +N" and "Gained class skill +N ranks". | **"+10 levels" is not parsed.** It is the Archer's shape, deliberately left unparsed (L64–68, L120: "levels gained SINCE taking … nowhere to store"), so it **fails open**. Ten of these twelve archetypes print "+10 levels", so each would allow a second archetype at once (seam S-1, Q?-1). "Birthright skill +10 ranks" (High Mage) does not parse either (note 11). |
| **Opening another class's feats** | `registerArchetype(name, {classGrants, tierGrants, countsAs})` (`module-api.mjs` L504). It is read by `effectiveClasses` / `effectiveTiers` / `effectiveArchetypes` (`feats.mjs` L975–1040) and passed to the picker (`sheets/actor-sheet.mjs` ~L2768). By Graham's 13 Aug 2026 ruling, "feats available to the X (Tier) class" opens both the list and the tier (`ARCHETYPE_TIER_GRANTS`, `feats.mjs` L931). | None. High Mage and Birthrager use `{classGrants: ["Sorcerer"], tierGrants: ["Adept"]}`. |
| **Class feats traited with an archetype** | The `classFeat` slot (L903) treats a trait as an archetype gate when it is a core archetype name or a `registeredArchetypeNames()` key (lower-cased **name**, `registryKey`). It matches against the owned archetype feats' names (`effectiveArchetypes`). | A hyphenated trait ("Blood-of-the-Wyrm") is not the registered name ("blood of the wyrm"). It would be **no gate at all**: the feat would be open to everyone (`if (!classGates.length && !archetypeGates.length && !tierGates.length) return true`). **Fix with no core change:** store the trait with spaces ("Blood of the Wyrm"), as Inner Tempest does ("Zen Archer", "Steel Disciple"), keep the printed hyphen on the card, and `registerArchetype` each name. |
| **A trait that needs a feat** | `registerFeatGate(trait, featNames)` (`module-api.mjs` L628), applied by `withFeatGates` (`picker-filters.mjs` L801) to all four feat slots. | None. `registerFeatGate("Berserker", ["Frenzy"])` (Appendix L10716: "you must have the Frenzy feat"). The core Frenzy is a Class/Martial feat. |
| **One of a group** | `registerExclusiveFeats(group, names)` (L671): hidden in the picker and refused in `TRGItem._preCreate`. | None, if Q?-2 is answered "one Pact". |
| **Prerequisites** | `prerequisites.mjs` `parsePrerequisiteClause` (L78). Named feats/abilities are gated through `knownPrerequisiteNames` (`picker-workflow.mjs` L45: the federated feats and abilities packs). | "**Con 2+**" (Bloodmage) does not match `^(str|…)\s*\+(\d+)$` and passes open. **"Dragon Birthright"** names no item: the birthright ability is named "Dragon", so it passes open. **"Arcana or Nature 8 ranks"** (Elemental Exhalation, Wyrm Ascendant) is compound and passes open by design (L140 comment). The first two can be fixed in the module by storing the parseable form, with the printed text on the card (Inner Tempest's `printedAs` convention). The third needs seam S-3. |
| **Spell grants** | `grantedSpells` on a feat. `flags.grantInnate` makes the grant innate (`grants-workflow.mjs` L430), but per item, not per class. The module's `warlockHexArrives` / `warlockCopy` (`module/block4-automations.mjs` L129–150, L695) already turn a spell a Warlock receives into an innate Focus copy (Q37). | None. Pact spells go through the same item-created hook: a Warlock gets an innate Focus copy, a Witch a repertoire spell outside her picks. |
| **Pact spells in the packs** | Core: **Sanctuary** (PP 2, divinity, Warding), **Burning Hands** (2, arcane/verdant, Fire Invocation), **Charm Kind** (2, arcane/ethereal, Emotion Enchantment), **Dead Tongue** (2, arcane/divinity, Insight Language), **Dark Tendrils** (2, arcane/ethereal, Essence Soul). | **Dragon's Breath** (L6580) and **Elemental Strike** (L6750) are Grimoire spells, Block 7–8. |
| **A spell cast as High Magic** | `high-magic.mjs` `spellIsHighmagic` (L124): the Highmagic trait on the spell makes any cast High Magic. `highMagicCaster` (true or a tradition list) makes a caster one. | None. A granted copy carrying the Highmagic trait is "treated as a High Magic spell" (High Mage, Hex Weaver). |
| **A caster archetype's BSB** | `archetypeBSBDue` (`magic/archetype-casting.mjs` L442) gives a **floor** of ⌊level/2⌋ (Graham, 20 Aug 2026). It applies only to the four core names (`feats-workflow.mjs` ~L1225). `registerPPGrant` (`module-api.mjs` L1404) owes only PP or HP, per level. | **Birthrager: "BSB equal to half your level (round up)"** has no module route (seam S-5). |
| **Casting while raging** | Refused outright: `castRefusalReason` (`magic/cast-workflow.mjs` L501) and `castSpellResolved` (L572), both `isRaging`. `rageBlocksAction` (`combat/rage.mjs` L311) bars Concentrate actions without the Rage trait (`combat/action-workflow.mjs` L1624). | **No exemption** (seam S-4). |
| **Spell save DC by trait** | `flags.trg-prime.spellDCBonus {value, type, traits}` (`magic/spell-dc-bonus.mjs`), read for the caster's own and innate casts (`cast-workflow.mjs` ~L3730). | None (Fey, Grave). |
| **Per-die spell damage** | C6: `spellDamageBonus {perDie, damageTypes?, traits?, type}` (`magic/spell-damage-bonus.mjs` L153). | None (Elemental Pact, Crimson Rite). |
| **Spell damage or healing per PP spent** | `spellDamageRider` rolls **dice** of its own type only (`magic/caster-damage-riders.mjs`: `DICE` required). Healing takes a flat bonus only from a warp's `healBonus` (`magic/caster-level-mods.mjs` `warpedHealFormula`). `trgPrimeSpellSettled` reports `ppSpent` after the damage has landed (`cast-workflow.mjs` L5503). | **"+1 secondary fire per PP" and "+1 HP healed per PP"** cannot be declared (seam S-6). |
| **Saves by the source's traits** | Conditionals have a `traits` axis: "the traits of whatever PROVOKED the check" (`conditionals.mjs` L78). | None (Angelic, Grave). |
| **Cast results** | `trgPrimeSpellSettled`: `degree`, `saveResults[{target, degree}]`, `spellHits[{target, critical}]`, `ppSpent`, `innate`, `warpMods`, `castOptions` (L5503–5540). | None (Void, Draconic Pact, Crimson Rite, Bloodmage's fumble). |
| **Darkvision range** | `senses.mjs` `senseRangeFeet` (L104): category base + Wisdom, or a fixed figure. | **No "+30 ft" bonus** to a sense (seam S-7). |
| **Paying part of a cast another way** | The **rod draw** (`cast-workflow.mjs` L1792–1822): prompted, counted in the availability check (L1837), split after the spend (`rodDrawSplit`, L3150–3155). The ritual variant's `ppSubstituted` (D13) also exists, for rituals only. | **Bloodmage's Bleed-for-PP** has no route (seam S-8). D5's cost half and D2 are not built. |
| **Cast options** | `registerCastOption` (`module-api.mjs` L1272): `castingDC`, `saveDC` (whole spell), `ap`, `lines`. Not offered for innate, item or no-check casts (`cast-workflow.mjs` L2224). | **No "+1 attack only"** and **no one-target DC** (Sanguine Channel; seam S-9). |
| **Changing a spell's damage type by warp** | Only the spell's own `damageTypeChoice` row (`cast-workflow.mjs` ~L4463–4497). `registerSpellWarps` (`module-api.mjs` L772) takes static `mods`. No warp mod changes a type. | **Blood of the Wyrm's warp** cannot be said (seam S-10). |
| **Bleed** | The condition `bleeding` (valued, cumulative: `condition-rules.mjs` L387). The Phase 3 tick reads raw effect values (`documents/combat.mjs` L1751) less a `flags.trg-prime.bleedReduction` lever, which reduces the damage and not the wound (L1769–1792). | None. Crimson Rite's suppression is a 1-round effect with a large `bleedReduction`. `conditionSuppression` would **not** stop the tick. |
| **Secondary damage on claws** | Strike riders (`magic/strike-riders.mjs`, `flags.trg-prime.strikeRider`, scoped by `weaponId` or "unarmed"). | None. **Draconic Infusion's own claw rider was never automated** (`tools/content/block3-spells.mjs` L142: `level: "not"`), and Blood of the Wyrm and Draconic Claws build on it (note 15). |
| **Familiar** | The core Familiar feat (Class, Wizard trait); `helpers.createFamiliarFor` (`module-api-workflow.mjs` L336). | None. |
| **Specialist access** | `registerSpecialistAccess(key, allows(actor, spell))` (`module-api.mjs` L1363). | None (Hex Weaver's hexes, Bloodmage's two hexes: Q21). |
| **Fly speed for a duration** | An ability item with `creatureAbility.derives.movement {key:"fly", orLand}` (the `speedGrant` shape, `magic/spell-effects.mjs` L5959). Falling via `helpers.rollFalling` (C5). | None. |
| **`sourceArchetype`** | A field in `template.json` (L1027), read by no code. | Display only. The gate is the trait. |

##### The table

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| **Angelic Pact** | 2892 | WARLOCK WITCH · — · Prog "+10 levels" | Sanctuary to repertoire; +2 circ saves vs Fear or Soul effects; Healing-trait spell heals "1 HP per PP expended" | FA-01, A | Class gate; conditional `traits` axis; Sanctuary (core, PP 2) | **A.** Grant Sanctuary (Warlock: innate Focus copy, Witch: repertoire; n.1). Conditional +2 circ, saves, traits fear/soul, auto. Heal rider per PP (S-6). Exclusive Pact group (Q?-2). Progression gate (S-1). | S-1, S-6 | Q?-1, Q?-2, Q?-3 |
| **Demonic Pact** | 2950 | WARLOCK WITCH · — · "+10 levels" | Burning Hands; +2 class Intimidate; spell damage to a target "+1 secondary fire per PP expended" | FA-05, A | Burning Hands (core); skill AE | **A.** Grant (n.1). AE +2 class Intimidate. Per-PP secondary fire rider on each target the spell damages (S-6). | S-1, S-6 | Q?-1–3 |
| **Draconic Pact** | 2960 | WARLOCK WITCH · — · "+10 levels" | Choose acid/cold/electricity/fire/poison; Dragon's Breath (that type); resistance; "critical result or greater when casting a spell with the attack trait" → roar: advantage on next Demoralise before end of next turn | FA-06, B | `resistanceEffect`; one-shot conditionals; `spellHits` | **B.** The Use chooses the energy (kept on the feat). Resistance AE. Roar: on `trgPrimeSpellSettled` with a critical hit, the caster is asked "roar?" and gets a one-shot advantage conditional on Demoralise, expiring at the end of their next turn (n.2). **Dragon's Breath waits for Block 7–8**; the choice is stored now. | S-1 | Q?-1, Q?-2 |
| **Elemental Pact** | 2970 | WARLOCK WITCH · — · "+10 levels" | Choose air/earth/fire/water; Elemental Strike (your element); resistance air→electricity, earth→acid, fire→fire, water→cold; "+1 damage per die" on damaging spells "of your element type" | FA-07, B; EA-m30 (fixed in v1.6) | C6 per-die; resistance | **B.** The Use chooses the element. Resistance to the mapped type. C6 row `perDie: 1` (n.3). **Elemental Strike waits for Block 7–8**; its type is the mapped energy type (Elemental Strike offers only acid/cold/electricity/fire). | S-1 | Q?-1, Q?-2, Q?-4 |
| **Fey Pact** | 3022 | WARLOCK WITCH · — · "+10 levels" | Charm Kind; +2 class Deception and Diplomacy; Mental-trait spells' Save DC +1 | FA-11, A | `spellDCBonus` (innate too); Charm Kind (core) | **A.** Grant (n.1). AE +2 class on both skills. `spellDCBonus {value:1, traits:["mental"]}` (untyped). | S-1 | Q?-1, Q?-2 |
| **Grave Pact** | 3032 | WARLOCK WITCH · — · "+10 levels" | Dead Tongue; +2 class saves vs Soul effects; Soul-trait spells' Save DC +1 | FA-12, A | As Fey; Dead Tongue (core) | **A.** Grant. Conditional +2 class, saves, traits soul. `spellDCBonus` on soul. | S-1 | Q?-1, Q?-2 |
| **Void Pact** | 3192 | WARLOCK WITCH · — · "+10 levels" | Dark Tendrils; Darkvision (+30 ft if you have it); a creature gets Critical+ against your spell → +2 circ DB until the start of your next turn | FA-23, A | Darkvision ability; `saveResults` | **A with S-7** (C without it: the +30 ft would be a card). Grant Dark Tendrils and the core Darkvision. The `senseRangeBonus` effect applies when Darkvision comes from elsewhere (n.4). On a save result of Critical or Heroic by any target: an AE of +2 circ DB, ended at the start of the caster's turn. | S-1, S-7 | Q?-1, Q?-2 |
| **Hex Weaver** | 3042 | ADEPT · — · "+10 levels." | Familiar; "access to Witch Specialist Spells (… hexes)"; one Ethereal or Verdant spell "cast … as High Magic" | FA-13, B; EA-M19 | Familiar feat; `registerSpecialistAccess`; Highmagic trait | **B.** `grantedFeats: "Familiar"` (the core feat and its Use). `registerSpecialistAccess("hexWeaver")` opens `eaHex` spells to the Specialist Spell feat. The Use chooses one Ethereal/Verdant spell (`helpers.chooseSpell`), granted as a known copy with the Highmagic trait (n.5). | S-1 | Q?-1, Q?-5 |
| **Bloodmage** | 2934 | ADEPT · Con 2+, Level 2 · "+10 levels" | Pay any of a cast's PP as Bleed (1 Bleed per PP), min 1 PP, cap unchanged; fumble +1 Bleed per 2 PP of the spell, blunder +1 per PP | FA-04, B (via D2) | `bleeding`; rod-draw model; `trgPrimeSpellSettled` | **B.** S-8: a "PP paid as Bleed" field on the cast (0 to total − 1). Settle adds `bleeding` +paid. Fumble/Blunder rider on settle (Q?-8). Prerequisite stored as "Con +2, Level 2" (printed on the card). `registerSpecialistAccess` for the BLOODMAGE hexes (Q21). `registerArchetype("Bloodmage")` gates its two class feats. | S-1, S-8 | Q?-1, Q?-8 |
| **High Mage** | 3052 | ADEPT · BSB +4, Non-Sorcerer · "Birthright skill +10 ranks" | One birthright whose minimum you meet; its specialist spell added "as a High Magic spell"; one of its class skills; "feats which are available only to the Sorcerer (Adept) class" | FA-14, B | `registerArchetype`; `registerClassSkillGrant` + `useClassSkillGrant`; "Gained class skill" progression | **B.** The Use chooses the birthright (minimum: the first key ability, +2) and grants the specialist spell copy + Highmagic trait. Then one of that birthright's two skills is chosen through the class-skill grant (n.6). `registerArchetype("High Mage", {classGrants:["Sorcerer"], tierGrants:["Adept"]})`. Progression stored as "Gained class skill +10 ranks" (note 11). | (S-2 optional) | Q?-6 |
| **Birthrager** | 2902 | BERSERKER · Arcana skill 2 ranks · "Arcana +10 ranks" | Instinctive caster; BSB = ⌈level/2⌉; one Sorcerer birthright: its specialist spell and PP 0 cantrip; Sorcerer (Adept) feats; while raging, cast "ignoring any usual restrictions … and using concentrate actions" | FA-02, B; **EA-M23 ruled** (as rewritten: v1.6 text) | Feat gate; `registerArchetype`; `archetypeBSBDue` (floor, round down) | **B.** `registerFeatGate("Berserker", ["Frenzy"])`. The Use chooses the birthright and grants the specialist spell (cast as a specialist spell, PP from the C2 pool) and the cantrip at will (Storm: Orb of Lightning, Q15). BSB floor ⌈level/2⌉ (S-5). Rage exemption (S-4). `registerArchetype` as High Mage. Progression parses ("Arcana +10 ranks"). | S-4, S-5 | Q?-6, Q?-7 |
| **Blood of the Wyrm** | 2916 | SORCERER · Dragon Birthright, Intimidate 2 ranks · "+10 levels" | Resistance to your dragon type's energy; Draconic Infusion +1 die; warp "+2 PP: the spells damage type changes to that of your dragon type" on "any spell that has an elemental trait" | FA-03, A | `dragonTypeOf` (Block 3); strike riders; `registerSpellWarps` | **B.** Resistance AE from the stored dragon type (asked if unset). Draconic Infusion's rider is built now (n.15) with +1 die. Warp through S-10, offered in the Warp dialog. Prerequisite stored as "Dragon, Intimidate 2 ranks" (the birthright ability's name; printed on the card). `registerArchetype("Blood of the Wyrm")`. | S-1, S-10 | Q?-1, Q?-6, Q?-9 |
| **Crimson Rite** | 3344 | BLOODMAGE · Level 10, Sanguine Channel | While Bleeding: +1 circ per die on spell damage; a critical spell attack → your Bleed +1 and the creature gains Bleed 1; spend 1 PP: suppress your Bleed for 1 round, losing the bonus | FC-14, A | C6; `spellHits.critical`; `bleedReduction` | **B.** The C6 row (`perDie:1, type:"circumstance"`) sits on an effect the module enables while the caster has `bleeding` and no suppression (n.7). Settle hook: for each critical hit, the target gains Bleeding 1 and the caster +1. Use: 1 PP, then a 1-round effect with `bleedReduction: 999` and the bonus off. | — | — |
| **Sanguine Channel** | 4022 | BLOODMAGE · Level 6 | When the cast gains Bleed through Bloodmage, +1 more Bleed for +1 to the spell's attack roll or save DC (one target if several) | FC-73, B (D2) | Cast options (no attack-only or one-target DC) | **B.** A cast option, offered only with Bloodmage's field. Choose attack or DC, and the target for the DC. Apply: `attack: 1` or `saveDCTarget` (S-9), with +1 Bleed at settle. Not metamagic (no METAMAGIC trait), so no D2. | S-9 | — |
| **Draconic Claws** | 3392 | BLOOD-OF-THE-WYRM · Intimidate 6 ranks | "Your Dragon Claws … now inflict secondary elemental damage of your selected dragon type"; stacks with Draconic Infusion | FC-19 (stale, v1.4 text), A; EA-m37 / **EA-M66 ruled "as rewritten"** | Strike riders by `weaponId`; `clawsOf` | **A.** A permanent strike rider on the grown claws (Dragon Claws' Use, `module/block3-automations.mjs` L252, stamps it when the feat is owned). The type is the dragon type's. **Dice not printed** (Q?-10). | — | Q?-10 |
| **Elemental Exhalation** | 3460 | BLOOD-OF-THE-WYRM FOCUS INVOCATION · Arcana or Nature 8 ranks · 2 AP, PP 2 | Breath, 30-ft cone or 60-ft line "based upon your dragon type", 1d6 per two levels, basic Reflex | FC-26, A | `runAreaEffect`, `levelDC`, C6 helper | **B.** Use: 2 AP, 2 PP, Focus use (Q36). The player targets the creatures in the area (the Block 5 breath convention). Damage ⌊level/2⌋d6 (m128) of the dragon type. Basic Reflex against the Level DC (C3). `helpers.spellDamagePerDieBonus` adds C6 rows (Q70). Shape by dragon type: Q?-10. | S-3 | Q?-10 |
| **Wyrm Ascendant** | 4284 | BLOOD-OF-THE-WYRM FOCUS INVOCATION · Arcana or Nature 12 ranks | Wings: fly speed = land speed for 10 minutes | FC-94, A | `derives.movement` (`orLand`); timers; `rollFalling` | **A.** Use (1 AP, minor note), Focus use: a fly-speed ability item (`orLand`, feet 0), removed after 10 minutes of world time. If the creature is aloft then, it falls (`helpers.rollFalling`). | S-3 | — |

**Levels:** A 7 (Angelic, Demonic, Fey, Grave, Void, Draconic Claws, Wyrm Ascendant). B 10 (Draconic Pact, Elemental Pact, Hex Weaver, Bloodmage, High Mage, Birthrager, Blood of the Wyrm, Crimson Rite, Sanguine Channel, Elemental Exhalation). C 0. D 0. These grades assume the seams. Without S-7, Void is C. Without S-6, Angelic and Demonic are C (the per-PP clause on a card). Without S-4, S-5, S-8 or S-10, Birthrager, Bloodmage and Blood of the Wyrm lose that clause to a card.

##### Notes

1. **The Pacts' spell, by class.** "You may add X to your spell repertoire." **Warlock:** "any spells that you have are classed as innate spells with the focus trait" (L1452). The granted spell becomes an innate Focus copy, cast with Charisma, through the module's existing `warlockCopy` / item-created hook (`module/block4-automations.mjs` L129, L695). It is extended to spells whose `grantedBy.sourceName` is a Pact. It counts as High Magic (Warlock: "All of your selected spells are considered to be High Magic"). **Witch:** a repertoire spell outside her picks (the birthright's `grantedSpells` pattern, Block 3). Sanctuary (divinity) and Dead Tongue (arcane/divinity) fall outside her `highMagicCaster: ["ethereal","verdant"]`, so they are cast as ordinary magic (Minor). "May": granted on taking. The player may delete it.
2. **"A spell with the attack trait"**: no core spell carries an Attack trait (0 of 692). Read as a spell that makes a spell attack. "Critical result or greater": in TRG Prime the spell attack *is* the casting check (`cast-workflow.mjs` ~L4545). The trigger is therefore a Critical-or-better hit on any target (`spellHits[].critical`), which also covers a Warlock's innate attack, where no casting check is rolled. "May let out a roar": asked, at no AP (part of the cast).
3. **Elemental Pact's "+1 per die"** uses C6, scoped as Q?-4 decides: `damageTypes: [mapped]` and/or `traits: [element]`. It applies to every matching pool the cast rolls (Q70), not to recurring damage.
4. **Void Pact's Darkvision.** The core Darkvision ability is granted. If the actor already has a Darkvision sense from another item, the feat's effect `senseRangeBonus {sense:"darkvision", feet:30}` adds 30 ft (S-7). The core Darkvision copy is then not added again (a granted copy is skipped as "held").
5. **Hex Weaver's spell.** Core cast rules: Spellcraft, PP, the Highmagic trait's Hard (+2) step and High Magic fumble/Resonance (M27: "a non-High-Magic caster learns one Very Hard and casts it Hard"). The learn check is not rolled: the feat grants the spell. Limits per Q?-5.
6. **High Mage's class skill.** The chosen skill must be one of the birthright's two. Register one `registerClassSkillGrant({name:"high mage", options:[union of the seven birthrights' skills]})`. The Use chooses the birthright first, then asks for the skill from that birthright's two, either through S-2 (`useClassSkillGrant` with an options override) or by writing the grant's own record (`flags.trg-prime.<flag>.skill`, read by `class-skills.mjs` and by "Gained class skill" progression). S-2 avoids writing the core's internal record shape.
7. **Crimson Rite's bonus window.** "While suffering from Bleed": the module watches the actor's `bleeding` effect (create, update, delete) and toggles a feat-owned effect carrying the C6 row. The suppression effect turns the row off. The +1 per die is circumstance, so it does not stack with another circumstance per-die row (C6 stacking rules).
8. **Bloodmage's cap.** "Cannot expend more PP on a single casting (including bleed) than your usual maximum": the cap test is on `totalPP` (unchanged by S-8). "Cannot reduce a spell's cost below 1 PP": the field's maximum is total − 1, so a 1 PP spell cannot use it and a cantrip is not offered. Not offered for innate or item casts (no PP is paid).
9. **Birthrager's casting.** Per M23 as ruled: an instinctive caster with BSB ⌈level/2⌉ and a birthright's specialist spell and cantrip. The specialist spell casts as the core's specialist (cap: the character's level; check Very Easy) from the C2 tradition pool ("every character has a PP pool from their magical tradition"). The tradition and ability are those of the birthright (Q?-6). "Instinctive": no memorisation; the cantrip is at will. The specialist spell is **not** High Magic: the archetype does not say so, unlike High Mage. The Birthrager still counts in the High Magic archetype set for "High Magic Caster" prerequisites (M19 interim, M20 as proposed).
10. **Birthrager's trait gate.** BERSERKER is not a class or tier, so the `archetypeFeat` branch passes it to all. `registerFeatGate("Berserker", ["Frenzy"])` then hides it from anyone without Frenzy (`withFeatGates`). Its tier grant (Adept) also opens ADEPT-traited archetypes (Hex Weaver, Bloodmage) once the Birthrager's progression is met. That follows the core's 13 Aug ruling.
11. **High Mage's progression line** "Birthright skill +10 ranks" means the class skill High Mage granted. That is exactly the core's "Gained class skill +N ranks" (`archetype-progression.mjs` L127), which reads the grant's chosen skill through `archetypeGrantContext` (`picker-filters.mjs` L768). With no core change, store `system.progressionRequirements: "Gained class skill +10 ranks"` and print the book's words on the card. The refusal message (`archetypeProgressionBlockReason`) then quotes the stored form, not the printed one. S-2 lets a registered archetype declare `progressionAs` and keep the printed field.
12. **Prerequisite chains.** Sanguine Channel (Level 6) leads to Crimson Rite (Level 10, Sanguine Channel): the named-feat gate reads "Sanguine Channel" from the module's feats pack. Blood of the Wyrm opens Draconic Claws, Elemental Exhalation and Wyrm Ascendant by trait only; they have no feat-to-feat chain. Pact Channeler, Pact Boon and Pact Ascendant chain from the Pacts (note 21).
13. **Racial traits** (ELF and the rest): none of these 17 feats carries a race trait.
14. **The trait strings.** Store "Blood of the Wyrm" and "Bloodmage" in `system.traits` (spaces, not hyphens) and keep the printed "BLOOD-OF-THE-WYRM" on the card. `registerArchetype` each of the 12 (the Pacts too, harmlessly). The class-feat gate then works with no feat gate. A feat gate would also work, but it is all-of across gated traits, and Glyph Shatter's "RUNEBREAKER RUNEMAGE" needs any-of. The archetype route is the core's own.
15. **Draconic Infusion is built in this block.** Block 3 left its claw rider by hand (`block3-spells.mjs` L142–146). Two of these feats add to it, so it is built now: on the cast's settle, a strike rider of 1d6 of the dragon type is added (+1d6 per "+2 PP" warp, max 5d6; +1 die with Blood of the Wyrm) on the caster's claw weapons (`clawsOf`) for 1 minute (10 with the warp). It is re-stamped if the claws are regrown. "Your Claw attacks": the Dragon Claws weapon, plus any natural attack named Claw(s) (Q?-6c). The "+4 PP weapon trait" warp stays by hand.
16. **Blood of the Wyrm's +1 die and the 5d6 maximum.** Proposed: the die is added after the cap (6d6 at most). Minor.
17. **Elemental Exhalation's DC and dice.** No DC is printed, so the Level DC applies (C3, the module's breath convention: Elemental Breath, Block 5). 1d6 per two levels is rounded down (m128). It is not a spell: spell DC bonuses do not reach it, but C6 rows do, through `helpers.spellDamagePerDieBonus` (Q70: "your magical abilities' damage"). The PP comes from the Sorcerer's pool. The Focus use is restored by Refocus (Q36).
18. **The Pacts' third clauses by class.** Fey and Grave's `spellDCBonus` reaches innate casts (`declaredSpellDCBonuses` with `innate`), so the Warlock benefits. Cast options would not: they are not offered for innate casts.
19. **Healing "the target"**: every creature the Healing-trait spell heals receives the extra.
20. **Exclusivity and progression.** With S-1 and Q?-1, a Warlock who took Angelic Pact at 1st may take another archetype at 11th. Q?-2 decides whether that may be a second Pact.
21. **For the Warlock/Witch class-feat reviewer.** Pact Channeler's "Pact Archetype feat" names no item and passes open today, so it is offered to every Warlock or Witch at 6th. Options: (a) a module trait "Pact" on Pact Channeler, Pact Boon and Pact Ascendant, plus `registerFeatGate("Pact", [the seven])` (a trait not printed); (b) a core `registerPrerequisiteClause`. The channel effect is read "by pact" from whichever Pact the actor owns, which Q?-2 makes unique.

##### Proposed core seams

| # | Seam | Why | Where | Used by |
|---|---|---|---|---|
| **S-1** | **"+N levels" archetype progression.** An Archetype feat records the character level when it is created: `flags.trg-prime.takenAtLevel`, stamped in `TRGItem._preCreate` for `category "Archetype"`. `parseProgressionClause` gains `^\+(\d+)\s+levels?$` → `{type:"levelsSince", min}`. `meetsProgressionRequirement` passes when level − takenAt ≥ N. A feat with no stamp (an older actor) fails open, as today. The Archer's two-clause line stays unparsed. | Ten archetypes here, and most of Eldritch Arts' 23, print "+10 levels". Today they never block a second archetype. | `archetype-progression.mjs` L107/L195; `picker-filters.mjs` `blockingArchetype` L753 (pass `takenAt`); `documents/item.mjs` `_preCreate` | All seven Pacts, Hex Weaver, Bloodmage, Blood of the Wyrm, and every other Eldritch Arts archetype that prints "+10 levels" |
| **S-2** *(optional)* | **`registerArchetype` `progressionAs`** (a parseable line read in place of the printed field), and **`useClassSkillGrant(actor, item, {options})`**, which narrows the chooser for one use. | High Mage's "Birthright skill +10 ranks" and its chosen birthright's two skills. Without it, the module stores the parseable line and writes the grant record itself (notes 6, 11). | `picker-filters.mjs` `blockingArchetype`; `feats-workflow.mjs` L1684 | High Mage |
| **S-3** | **Compound skill prerequisite** "A or B N ranks" → any-of (and "A and B N ranks" → all-of), as `parseProgressionClause` already does for progression. | The two feats' prerequisites pass open today. | `prerequisites.mjs` `parsePrerequisiteClause` (skill branch, ~L140) | Elemental Exhalation, Wyrm Ascendant (and other Block 6 "or" lines) |
| **S-4** | **Casting while raging.** An item declaring `flags.trg-prime.castsWhileRaging: true` lifts the two `isRaging` refusals. `rageBlocksAction`'s Concentrate clause skips actions that are part of casting or sustaining a spell (scope per Q?-7); the Defence clause stays. | Birthrager. Today every cast is refused while raging. | `magic/cast-workflow.mjs` L501, L572; `combat/rage.mjs` L311 / `combat/action-workflow.mjs` L1624 | Birthrager |
| **S-5** | **A half-level BSB floor by name.** `registerPPGrant(name, {stat:"bsb", halfLevel:"up"})`, computed by `archetypeBSBDue` with a rounding parameter (the floor rule kept: Graham, 20 Aug 2026). | "A BSB equal to half your level (round up)". The core's four are hard-coded and round down. | `module-api.mjs` L1404; `feats-workflow.mjs` ~L1225 and the registered-grant loop ~L1365; `magic/archetype-casting.mjs` L442 | Birthrager |
| **S-6** | **Per-PP spell riders.** (a) `spellDamageRider` may declare `perPP: 1` in place of `dice`: flat secondary damage of `damageType` equal to perPP × the cast's PP, on each target the cast damages. (b) A `spellHealBonus {perPP, traits}` declaration, added to each heal row of the caster's matching spells, beside `healBonus`. "The cast's PP" is passed to both sites as Q?-3 rules. | "1 HP per PP expended", "+1 secondary fire per PP expended". | `magic/caster-damage-riders.mjs` `declaredSpellDamageRiders` and its call site; `magic/spell-effects.mjs` heal rows (`warpedHealFormula`, `caster-level-mods.mjs` L146) | Angelic Pact, Demonic Pact |
| **S-7** | **Sense range bonus.** `flags.trg-prime.senseRangeBonus {sense, feet}` on an item, added in `sensesOf` to a sense of that name (after the Wisdom range, before any doubling). | "If you already have Darkvision, its range is increased by 30-ft." | `senses.mjs` `sensesOf` L157 | Void Pact |
| **S-8** | **A module PP source for a cast** (the rod draw, generalised): `registerCastPPSource(key, {offer(ctx) → {label, hint, max}, settle(ctx, {paid})})`. Asked where the rod is (`cast-workflow.mjs` L1797–1822). Counted in the availability check (L1837). Split after the spend as `rodDrawSplit` (L3150–3155), so a Partial's smaller spend substitutes less. `settle` and `trgPrimeSpellSettled.ppSources` say what each source paid. The cap and `totalPP` are unchanged. Not asked for innate, item, stored or cantrip casts. | Bloodmage's Bleed-for-PP. It is also the shape D2 planned for "payment variants: bleed". | `magic/cast-workflow.mjs` (above); `module-api.mjs` | Bloodmage; read by Sanguine Channel |
| **S-9** | **Cast option answers `attack`** (added to the spell attack's total against DB only, not to the casting check) **and `saveDCTarget {uuid, value}`** (one target's Save DC). | "+1 to the spell's attack roll or save DC … only one target benefits". | `magic/cast-options.mjs` `appliedCastOptions`; `cast-workflow.mjs` `resolveSpellVolley` and the per-target save | Sanguine Channel |
| **S-10** | **A warp that changes the damage type.** Warp mod `damageType` replaces the cast's damage type as `damageChoice` does (`cast-workflow.mjs` ~L4494, `damageForCast`). `registerSpellWarps` entries may carry `when(actor)`, offered only to that actor (six entries, one per dragon type). | Blood of the Wyrm's "+2 PP: the spells damage type changes to that of your dragon type". | `magic/cast-workflow.mjs` ~L4494; `module-api.mjs` L772; `magic/granted-warps.mjs` | Blood of the Wyrm |

D2, D5 (cost half), D6 and D12 are **not needed** by these 17 feats. D10 (`registerDispelModifier`) is not used here.

##### Questions

**Q?-1. "+10 levels" (all seven Pacts, Hex Weaver, Bloodmage, Blood of the Wyrm).**
- **The issue:** "Progression Requirements +10 levels". This could mean ten levels gained since taking the archetype, or character level 10. Your ruling B7-2 read "Level +10" (Inner Tempest) as the total, but this is the other shape, the core Archer's "+8 levels", which the core reads as levels since taking.
- **Why it matters:** today the line is not parsed and fails open, so none of the ten blocks a second archetype. A Warlock who takes a Pact at 1st could take Hex Weaver at 2nd.
- **Proposed:** **ten levels gained since taking it** (seam S-1: the level is stamped when the feat is added). Characters made before the stamp exists pass open, as now.

**Q?-2. One Pact or several (the seven Pacts).**
- **The issue:** nothing says a Warlock or Witch may hold only one Pact. After "+10 levels" a second is reachable. Pact Channeler, Pact Boon and Pact Ascendant read "your patron's channel effect", in the singular, by pact.
- **Proposed:** **one Pact ever** (`registerExclusiveFeats("Pact", …)`). Say if a second patron is intended. Pact Channeler would then need a choice of which patron each cast.

**Q?-3. "Per PP expended" (Angelic: "healed of 1 HP per PP expended"; Demonic: "an additional point of secondary fire damage per PP expended").**
- **The issue:** a Warlock's spells are innate and spend no PP (Q37, Q52), and a Partial or a rod changes what the caster pays.
- **Why it matters:** read literally, both clauses do nothing for the Warlock, one of the two classes the Pacts are for.
- **Proposed:** **the PP the spell is cast at** (base + warps and metamagic): spent by the caster, drawn from a rod or Bleed, or the innate spell's own PP for a Warlock. Not reduced by a Partial's refund. Cantrips: 0.

**Q?-4. Elemental Pact: "a spell of your element type".**
- **The issue:** the element is air, earth, fire or water. Spells carry Air/Earth/Fire/Water traits (23, 25, 28 and 8 core spells), and the Pact maps each element to an energy (air → electricity, and so on), the type of its own Elemental Strike.
- **Proposed:** **either counts:** a spell carrying the element's trait, or damage of the mapped energy type. Each damage die of such a spell gets +1 (C6, Q70). Say if only one was meant.

**Q?-5. Hex Weaver.**
- **The issues:** (a) "gain access to Witch Specialist Spells (hexes)": a hex granted, or hexes only opened? (b) "select any one spell from either the Ethereal or Verdant traditions and cast it as High Magic": a new spell, or one already known? At what PP?
- **Proposed:** (a) **Opened only:** hexes become choosable through the core's Specialist Spell feat, cast as specialist spells (not High Magic). (b) **A new spell, known permanently outside picks and memorisation,** with base PP no higher than your level + 1 (sidebar 8's rule, as Q38), cast with Spellcraft and the Highmagic trait (Hard). Hex Weaver does not make the character's other spells High Magic.

**Q?-6. Birthrager and High Mage: the borrowed birthright.**
- **The issues:**
  - (a) **Wild** has no fixed specialist spell and no fixed cantrip (they are rolled daily or at levels).
  - (b) Does the chosen birthright satisfy "Dragon Birthright" (Blood of the Wyrm), "Arcanum Birthright" (Arcane Study) and "Wild Birthright" (Resonance Surge)? Both archetypes open Sorcerer feats, archetypes included.
  - (c) Draconic Infusion buffs "your Claw attacks", but neither archetype grants Dragon Claws.
  - (d) The Birthrager's magical ability and tradition are not printed.
- **Proposed:**
  - (a) **Wild is not offered** to either.
  - (b) **Yes:** the archetype records "<Name> Birthright" and the prerequisite reads it. It grants only what the archetype lists.
  - (c) **No Dragon Claws.** Draconic Infusion applies to any natural Claw attack the caster has (a Scaelyn's claws, a shapechange).
  - (d) **The birthright's first key ability, and its tradition** (they coincide for all six).

**Q?-7. Birthrager while raging: "cast spells ignoring any usual restrictions for casting spells whilst raging and using concentrate actions".**
- **The issue:** this could mean every Concentrate action is allowed while raging, or only the concentrate actions that casting needs.
- **Proposed:** **casting, and the concentrate actions that are part of casting or sustaining a spell.** Other Concentrate actions (any skill action or ability with the Concentrate trait) stay barred while raging, as the core's rage does.

**Q?-8. Bloodmage: "If the spell fumbles, you immediately increase your Bleed by +1 per 2 PP of the spell. A blunder increases the Bleed by 1 per PP of the spell."**
- **The issue:** does this apply to every spell the Bloodmage fumbles, or only to casts paid partly in Bleed? And what is "PP of the spell"?
- **Proposed:** **only a cast that used the substitution; the PP it was cast at** (base + warps); per 2 PP rounded down (m128). Note that a Bloodmage gains nothing from a fumble on a spell paid entirely in PP.

**Q?-9. Blood of the Wyrm's warp: "may be applied to any spell that has an elemental trait".**
- **The issue:** the Elemental trait (3 core spells; the Grimoire's breath and strike spells), or any element or energy trait?
- **Proposed:** **any spell that deals damage and carries Elemental or an element or energy trait** (Air, Earth, Fire, Water, Acid, Cold, Electricity, Sonic, Poison). All of the spell's damage becomes the dragon type. Once per cast.

**Q?-10. The rewritten Blood-of-the-Wyrm feats leave numbers unprinted.**
- **Draconic Claws:** "now inflict secondary elemental damage of your selected dragon type". No dice (v1.4 said 1d6).
- **Elemental Exhalation:** "a 30-ft cone or 60-ft line (based upon your dragon type)". No mapping, and no damage type.
- **Proposed:**
  - Claws: **1d6 secondary**, always on, stacking with Draconic Infusion.
  - Exhalation, as Dragon's Breath: cave (acid) and light (electricity) a **60-ft line**; cold, fire, forest (poison) and sea (sonic) a **30-ft cone**. Damage of the dragon type.

##### Waits on other blocks
- **Dragon's Breath** (Draconic Pact) and **Elemental Strike** (Elemental Pact) are Grimoire spells (Block 7–8). Ship both Pacts now with their choice stored. The card says the spell arrives with the Grimoire, and the grant is applied then from the stored choice.
- **Pact Channeler, Pact Boon and Pact Ascendant** (another reviewer; D2 for Pact Channeler) read the Pact a character owns (note 21).
- **D2 metamagic:** S-8's PP source must also cover a metamagic's PP once D2 exists (it is part of `totalPP`). Nothing here waits for it.
- **Nothing waits for Block 9 or 10.** Draconic Infusion's rider (Block 3) is built here, not deferred (note 15).

##### Minor
- **Stale matrix rows (v1.4):** FC-19 Draconic Claws describes a natural weapon (1d6 slashing, BSB); v1.6 builds on the birthright's Dragon Claws. FA-02 Birthrager still says "low PP" (ruled away, M23). FA-04 says "persistent bleed"; the book's "Bleed" is the core `bleeding` condition.
- **Stray backticks** after the flavour of Elemental Exhalation (L3464) and Wyrm Ascendant (L4288) are still in v1.6 (m39).
- **Birthrager's flavour** still says "Like Magi" (EA-m29), though "birthragers" is now correct.
- **"Con 2+"** (Bloodmage): read as Con +2. Stored parseable; the printed form stays on the card.
- **"Dragon Birthright"**: stored as "Dragon" (the birthright ability's item name), so the core's named-feat gate enforces it.
- **Blood of the Wyrm's "(acid, fire, electricity, etc.)"** is read as the six dragon types: acid, cold, fire, poison, electricity, sonic.
- **Fey Pact's own Charm Kind** carries Emotion and Enchantment, not Mental, so its +1 DC never reaches it. Built as printed.
- **Different bonus types** (Angelic +2-circumstance to saves; Grave +2-class): built as printed, so the two do not overlap by type.
- **Void Pact's +30 ft** also applies when Darkvision is gained later from another source.
- **Wyrm Ascendant prints no action:** 1 AP, as Q62 (Astral Step) ruled for an unprinted action.
- **Crimson Rite's suppression prints no action:** a free action on your turn, lasting until the start of your next turn. The Bleed's value and its flat check are kept; only its damage is skipped (`bleedReduction`).
- **Sanguine Channel's "attack roll":** in TRG Prime the spell attack is the casting check. The +1 counts against DB only, not against the casting DC (S-9).
- **The Witch's pact spell outside her traditions** (Sanctuary, Dead Tongue) is cast as ordinary magic under her D4a rule. Say if the patron's gift should be High Magic for her.
- **The Hex Weaver progression line** ends in a full stop ("+10 levels."). The parser strips it.
- **The module's `feat()` builder has no `progressionRequirements` parameter** (`tools/content/builders.mjs` L309). Block 6 must add one: every archetype needs `system.progressionRequirements`.
- **`sourceArchetype`** (builder and template) is read by nothing in the core. Set it for display, but the trait is the gate.

### Appendix B. Archetypes, part 2

Scope: 11 archetype feats (`sections.archetypeFeats`) and the 35 class feats (`sections.classFeats`) whose traits name one of them, found by trait, not by guess. 46 entries. Book lines are v1.6 `ea.md`; sidebars are `ea-sidebars.md`. Core is TRG Prime 3.683.0 (`/home/claude/core-3676/trg-prime/module/`); the module is Eldritch Arts 0.8.0.

**Not mine by trait (for the lead).** Prepared Sigil (3906), Runic Reservoir (4010), Living Script (3738), Combat Inscription (3302) and Ley-Etched Symbol (3682) carry only **RUNEMAGE**, the core's own Runemage archetype (`picker-filters.mjs` L929 `ARCHETYPE_NAMES`). They are not Runeblade or Runebreaker feats, so they are not audited here. Glyph Shatter (RUNEBREAKER, RUNEMAGE) is mine. If no other reviewer has the RUNEMAGE five, they are unassigned. "Steelbinding?" in the brief is confirmed (FERROMANCER, METAMAGIC).

#### Archetypes, part 2

##### What TRG Prime has for archetypes, and what it lacks

- **The slot.** An archetype is a `feat` item with `system.category: "Archetype"`, offered in the `archetypeFeat` picker slot (`picker-filters.mjs` L969). The slot reads three things:
  - Class-name and tier traits as an any-of gate (L1000–1033). Module classes count through `registeredClassNames()`, so SORCERER, ARCHMAGE and SPELLBLADE gate, and ADEPT gates as a tier.
  - `meetsClassPrerequisite` ("Non-X").
  - The one-at-a-time progression gate: `withArchetypeProgressionGate` (L812) → `blockingArchetype` (L753) → `meetsProgressionRequirement` (`archetype-progression.mjs` L195).
- **Opening class feats.** `registerArchetype(name, {classGrants, tierGrants, countsAs})` (`module-api.mjs` L504) puts the name in `registeredArchetypeNames()`. The `classFeat` branch (`picker-filters.mjs` L903–959) reads that list to recognise a trait as an archetype gate (L937). It is passed only by an owner of that archetype (`effectiveArchetypes`, `feats.mjs` L1004; sheet context `actor-sheet.mjs` L2802), as any-of with the class and tier gates. Nothing else is needed for an archetype to open its feats.
- **Grants.** An archetype hands out its abilities and spells through the feat's own `grantedSpells` / `grantedAbilities` / `grantedFeats` (`grants-workflow.mjs` `GRANT_FIELDS.feat`, ~L540). Each grant carries a `grantedBy` stamp, which makes the spell castable and lets it be cleaned up on removal. `flags.trg-prime.grantInnate` makes a granted spell innate.
- **`sourceArchetype` is inert.** No core file reads it (grep: 0 hits). The module's `feat()` builder writes it, but it gates nothing.
- **Lacks 1 — hyphenated traits never gate (alarming).** The book prints the class-feat traits as `ETERNAL-VIGIL`, `SPELL-WEAVER`, `SHADE-MASTER` and so on. `registryKey` only lowercases (`module-api.mjs` L47), so "eternal-vigil" never equals the registered "eternal vigil". Built as printed, each such feat has no recognised gate, and the `classFeat` filter returns true for everyone (L944). That would open, for example, Chronostasis, Rune Rend, Twinflare Rune and the Spellwarden chain to every character.
  - **Fix (module only):** author the traits with spaces ("Eternal Vigil, Focus, Healing"), as Inner Tempest wrote "Zen Archer" (`trg-inner-tempest/tools/content/block6.mjs` L85). Then register all 11 names with `registerArchetype`.
- **Lacks 2 — most of my progression lines never block.** `parseProgressionClause` (`archetype-progression.mjs` L112–150) parses "Arcana +10 ranks", "Sense Motive +10 ranks" and "Arcana & Crafting +10 ranks" (as AND). It does not parse these, and an unparsed line passes, so a second archetype is offered at once:
  - "+10 levels." (Runeblade, Spell Duellist). It is deliberately unparsed (L64–70: "levels gained SINCE taking the archetype … nowhere to store").
  - "Tradition skill +10 ranks" (Leyline Weaver).
  - "cannot progress" (Eternal Vigil; EA-M3 ruled it means no later archetype, ever).
  - No line at all (Runebreaker, Shade Master, Stormcaller).
  - → S-2 and Q?-1.
- **Lacks 3 — the module's `feat()` builder has no `progressionRequirements` field** (`tools/content/builders.mjs` L309). It must be added for Block 6, or every EA archetype ships with a blank line (and passes).
- **Prerequisites that pass open, by the core's design** (`prerequisites.mjs` L26–37). The picker does not check these; the player does:
  - "Eternity / Rune / Umbral / Storm Birthright". No item has that name: the birthright is the class ability "Eternity" and so on (`tools/content/block3.mjs` L271).
  - "Metal Lore Specialty skill".
  - "any one tradition skill 2 ranks" and "Tradition skill N ranks".
  - "Arcana or Survival 10 ranks".
  - **Module fix for the birthrights:** write `prerequisites: "Eternity, Medicine 2 ranks"`, keeping the printed text in the description. Inner Tempest's `printedAs` set this precedent. "Eternity" is then a known ability name, and the core's named-clause check (`prerequisites.mjs` L285) gates it.

##### Each archetype's grant structure, and how the core carries it

| Archetype | Gate (traits) | Grants (items the feat hands out) | Registrations the module makes | Opens (class feats by trait) | Progression, printed → as built |
|---|---|---|---|---|---|
| Eternal Vigil | Sorcerer | — (passive AE: Death State +2) | `registerArchetype`; `registerSpellWarps` (Healing trait); death-guard effect on the feat | Chronostasis → Temporal Reprieve → Last Horizon | "cannot progress" → S-2 `never` (EA-M3) |
| Fatespinner | Adept, Sorcerer, Witch ("Diviner" is no class, so harmless) | ability **Foreseen Danger** (sidebar 10) | AE conviction max +1; `registerCheckReaction` ×2 (reroll; Foreseen) | Fate's Favour, Destiny's Embrace, Damaging Gambit | "Sense Motive +10 ranks" (parses) |
| Ferromancer | Sorcerer, Spellblade, Wizard | spell **Shard Cloud** (specialist, L8723; build now) | component flag (S-11 / Q?-6) | Iron Ward → Steelbinding → Living Iron | "Arcana & Crafting +10 ranks" (parses, AND) |
| Leyline Weaver | Adept | ability **Leyline Power** (sidebar 11) | conditional +2 circ on `leySense`/`tapLeyLine`; branch in the module's own Tap resolver | Leyline Anchor → Confluence Master → Leywalk | "Tradition skill +10 ranks" → authored as "Arcana, Nature, Occultism or Religion +10 ranks" (Q?-1) |
| Runeblade | Spellblade | — (extends the Block 4 Infuse Weapon) | on add: Weapon Potency I + one listed rune into the Book of Infusions | Twinflare Rune → Living Sigil → Runeforge Mastery | "+10 levels." → Q?-1 / S-2 |
| Runebreaker | Sorcerer | — (extends Storing Rune; Dispel discount) | `registerCastReaction` (absorb); `registerDispelModifier` (ppReduction 2) | Rune Rend → Glyph Shatter → Runic Overload | none → Q?-1 |
| Shade Master | Sorcerer | ability **Fade Step** (sidebar 12); spell **Dark Whispers** (built, block3-spells L371), light-gated | `registerSpellWarps` (Shadow Shift hidden at +3); `registerCastRefusal` for the gated copy | Shadowmantle → Grasping Shadows → Eclipse Step | none → Q?-1 |
| Spellwarden | Archmage | ability **Counter Channel** (sidebar 13) | `registerCheckReaction` (saves vs magic +2 class); `registerCastReaction` (Counter Channel) | Improved → Instinctive → Reflective Warding → Absolute Denial | "Arcana +10 ranks" (parses) |
| Spell Duellist | Spellblade | ability **Spellstrike Riposte** (sidebar 14, M26 text) | conditional `when.actions: ["spellRecognition"]` +2 class; `trgPrimeStrikeResolved` listener | Duellist's Focus → Rippling Counter → Duellist's Supremacy | "+10 levels." → Q?-1 / S-2 |
| Spell Weaver | Archmage, Wizard | ability **Magical Reservoir** (uses "intelligence", min 1) | D2 metamagic options paid in charges | Deep Weave → Overflow Casting → Wellspring Conduit; Extra Reservoir | "Arcana +10 ranks" (parses) |
| Stormcaller | Sorcerer | spell variant **Storm Bolt (burst)** (N11) | Gale Step's AP read by the module (Block 3 code); S-1 discount on Storm Bolt | Thunderclap Aura → Lightning Rod → Eye of the Storm | none → Q?-1 |

Every archetype also needs its name registered with `registerTraits` so the trait glossary shows it, and its class feats authored with the spaced trait (Lacks 1).

##### Feats

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| **Eternal Vigil** | 2980 | SORCERER / Eternity Birthright, Medicine 2 | "additional +2 bonus to your Death State"; 1/day "when reduced to 0 HP, you can cast Touch of Healing on yourself as a free action, provided you have PP remaining"; warp +2 PP on Healing spells: "fast healing 5 for a number of rounds equal to the PP of the spell cast (before applying this option)"; cannot progress | FA-08 B; EA-M3 ruled | AE on `system.combat.deathState` (Eternity Resilience does it, block3.mjs L341); death guard (`combat/death-guard.mjs`, offer/daily/notOutright); `registerSpellWarps` (module-api L772) + `warpMods.unlocks` on `trgPrimeSpellSettled` (cast-workflow L5529); `healingRate` kind (Life Boost) | **B.** AE +2 (stacks with Eternity Resilience: +4) (A). Touch of Healing guard N1 (B). Warp: match traits ["healing"], +2 PP, `unlocks: ["eaVigil"]`; on settled, fast healing 5 for (ppSpent − 2) rounds (A) | S-2, S-7 opt | Q?-1, Q?-2, Q?-3 |
| **Fatespinner** | 2998 | ADEPT DIVINER SORCERER WITCH / Sense Motive 4 | conviction max +1; "use a conviction point to reroll a failed skill check as long as it is not either a blunder result or an unmodified 1"; Foreseen Danger | FA-09 B | conviction max via AE (`conviction.mjs` L75 note; `bardic-conviction.mjs` L178 writes the key); `registerCheckReaction.after` → `{reroll}` (module-api L1441); `helpers.spendConviction`/`convictionState` (1 per round) | **B.** AE max +1 (A). Reroll: after-reaction on `type: "skill"`, failed, degree ≠ blunder, natural ≠ 1 → ask, spend a point, reroll; the second stands (B). Foreseen Danger N2 (B) | — | — |
| ↳ Foreseen Danger | sidebar 10 | FOCUS INSIGHT / — | R: an ally within 30 ft "makes a d20 check that you are aware of": "an additional d6 … rolled before the outcome of the check is determined" | (in FA-09) | `registerCheckReaction.before` → `{modifiers}` (C2) | see N2 | — | — |
| **Ferromancer** | 3010 | SORCERER SPELLBLADE WIZARD / Arcana 2, Crafting 2, Metal Lore Specialty | "replace material and somatic components when casting arcane spells with various shards of metal" kept in a pouch; Shard Cloud specialist spell | FA-10 B | `component-gate.mjs`: somatic needs a free hand unless `freeSomatic` (L39, actor-wide); material needs a pouch with uses (L50); emanation turn damage (`turn-save-workflow.mjs`) | **B.** Arcane casts: the pouch satisfies both components and is spent as the material is (N3). Shard Cloud built now from `book.specialist` (block3-spells `build()`): 5-ft emanation on you, 1d6 slashing basic Reflex at turn start or on entering; warps +1d6 and +5 ft (max 30) (B) | S-11 | Q?-6 |
| **Leyline Weaver** | 3068 | ADEPT / BSB +2, any one tradition skill 2 | +2 circ to Ley Sense and Tap Ley Line; replaced ladder: Critical "benefits x2 until the end of your next turn" + 1d8 PP, Success to end of next turn, Partial to end of current turn; Leyline Power | FA-15 B; EA-M25 ruled **stack** | conditional `when.actions` (`conditionals.mjs` L290); the Tap resolver is the module's own (`block2-automations.mjs` L502) | **B.** Conditional +2 circ on both actions (A). The Tap branch reads the archetype: Critical → `leyBenefits` with doubled numbers (Q?-7) + 1d8 PP; Success → endOfNextTurn; Partial → endOfTurn; Failure/Fumble unchanged (A). Leyline Power N4 (B) | — | Q?-1, Q?-7 |
| ↳ Leyline Power | sidebar 11 | CONCENTRATE FOCUS MAGICAL / — | R: on a Tap Success or better: regain 1d8 PP (2d8 on a Critical) | (in FA-15) | `trgPrimeActionResolved` + `resolvedDegree` (C10) | asked after the Tap card; spends reaction + Focus; PP capped at max | — | — |
| **Runeblade** | 3088 | SPELLBLADE / Level 2 | one extra Runeblade Rune each daily prep, outside the rune maximum, from *Acidic I, Bane, Defending I, Flaming I, Frost I, Returning, Shock I, Thundering I*; add one of them and Weapon Potency I to the book | FA-16 B; EA-M14 ruled (Spellblade level; v1.6 agrees) | core weapon runes `potency`, `bane`, `returning`, `acidic`/`flaming`/`frost`/`shock`/`thundering` (`weapon-rune-data.mjs` L46–180); **no "Defending"** anywhere; Block 4 `infuse()` (`block4-automations.mjs` L340) | **B.** After the budgeted picks, `infuse()` asks for N Runeblade runes (1, 2 with Twinflare, 3 with Living Sigil) from the list. They are not drawn from the book and do not count against the budget, and are written to the same `runesToField` (Bane asks its creature kind). On add, Potency I + a chosen one go into `BOOK_RUNES_FLAG` | — | Q?-1, Q?-9 |
| **Runebreaker** | 3108 | SORCERER / Rune Birthright, Linguistics 2 | Storing Rune "as a reaction triggered by you being targeted by an incoming spell. You make a Will saving throw and if successful, you absorb the incoming spell"; Dispel "costs you 2 PP less (min 1)" | FA-17 B; EA-M3 | `registerDispelModifier` `ppReduction` (module-api L1322, "Runebreaker" named); `registerCastReaction` `{stop}` (L1484; runner `reactions-workflow.mjs` L289); spell storing needs an **Arcane Bond item** (`spell-storing-workflow.mjs` L30) | **B (with S-3).** Dispel: offer `{ppReduction: 2}` (A, now). Absorb: cast reaction on a spell targeting you (Q?-10) → ask; pay Storing Rune's PP and reaction; Will vs the caster's Spell Save DC; Success+ → `{stop}`, and the spell is copied to you and stored (S-3) | S-3 | Q?-1, Q?-10 |
| **Shade Master** | 3120 | SORCERER / Umbral Birthright, Survival 2 | Fade Step; "while in darkness or dim light, you may cast Dark Whispers as a specialist spell"; Shadow Shift's hidden warp "costs your 2 PP less" | FA-18 B; EA-M3 | `helpers.lightLevelAt(token)` (C4); `registerCastRefusal` (L1140); `registerCastCapModifier` (L1343); `registerSpellWarps` | **B.** Fade Step N5 (B). Dark Whispers: granted, cast refused while your light > 5; cap raised to character level (specialist) (A). Shadow Shift: a +3 PP "(Shade Master) hidden instead" warp, `unlocks`, which applies Hidden on settled (A); the spell's own +5 stays | — | Q?-1 |
| ↳ Fade Step | sidebar 12 | FOCUS SHADOW TELEPORTATION / — | 1 AP: "from one area of shadow to another within 30 feet" | (in FA-18) | Gale Step's click-teleport (`block3-automations.mjs` L290); `lightLevelAt` | see N5 | — | — |
| **Spellwarden** | 3134 | ARCHMAGE / Arcana 2 | "+2-class bonus to all saving throws against magic"; Counter Channel | FA-19 B | `registerCheckReaction.before` `{modifiers}`, with `saveSource`/`sourceUuid` set by spell saves (`cast-workflow.mjs` L6833, `area-save-workflow.mjs` L46); Eaog's ticked "vs magic" conditional (`item-quality.mjs` L818) | **B.** Before-reaction on a save forced by a spell (non-empty `saveSource`, `sourceUuid` ≠ self) adds +2 class (A). A ticked conditional (Eaog's shape) covers other magic (B). Counter Channel N6 | S-4 | Q?-12 |
| ↳ Counter Channel | sidebar 13 | FOCUS WARDING / — | R: a creature within 30 ft casts a spell: 1 PP, Power Manipulation vs "the spells Save DC": Critical negated; Success "variables are halved (area, duration, targets, damage die)", else targets' saves with advantage; Failure normal; Fumble doubled, else disadvantage | (in FA-19) | `registerCastReaction` stops only (Disrupting Magic's pattern, block3b) | see N6 | S-4 | Q?-12 |
| **Spell Duellist** | 3146 | SPELLBLADE / Level 2 | "+2-class bonus to rolls made to Identify Spells cast that you are aware of"; Spellstrike Riposte | FA-20 B; EA-M26 ruled (riposte rewritten; v1.6 sidebar has it) | Spell Recognition's roll carries `actionKey: "spellRecognition"` (C11); `trgPrimeStrikeResolved` `{melee, missed, noReactions}` (`attack-workflow.mjs` L3769); `helpers.rollWeaponAttack`, `spendReaction`, `askReactor` | **B.** Conditional `when.actions: ["spellRecognition"]` +2 class (A). Riposte N7 (B) | — | Q?-1, Q?-8 |
| ↳ Spellstrike Riposte | sidebar 14 | FOCUS INVOCATION / — | R: a creature in your reach "makes a melee attack against you and misses": 1 PP, a melee Strike ignoring MAP; on a hit, channel a cantrip "adding any damage as secondary" | (in FA-20) | as above | see N7 | — | — |
| **Spell Weaver** | 3158 | ARCHMAGE WIZARD / Arcana 2 | Magical Reservoir: charges = Int (min 1), daily; on a cast spend 1 to: −2 PP (min 0); damage/healing dice +1 step; duration, range or area +50% | FA-21 B (D2, D5) | uses formula "intelligence" (`uses.mjs` L36); `registerCastOption` returns only castingDC/saveDC/ap (module-api L1272), so it cannot change PP or dice; die-step only as a row's own `upgrade` (`damage-die-upgrade.mjs`) | **B (waits D2).** Ability "Magical Reservoir" (uses "intelligence"; floor 1 by the module). Three D2 options paid in one charge: `ppCost: −2` (S-1/D2), a new `dieStep: 1` mod, new `scale: 1.5` mods (N8) | D2, S-1 | Q?-13 |
| **Stormcaller** | 3178 | SORCERER / Storm Birthright, Survival 2 | Gale Step as 0 AP; Storm Bolt "costs 1 less PP"; warp +2 PP on Storm Bolt: "gains the Save trait and now affects all creatures in a 10’ radius … basic Reflex" | FA-22 A; EA-M3, EA-m34 (corrected) | Gale Step is module code (`block3-automations.mjs` L298, 1 AP hard-coded); Storm Bolt (block3-spells L164); no cost discount in core; no warp mod turns an attack into a save | **B.** Gale Step's AP 0 for owners (A). −1 PP via S-1 (A once built). Burst: a granted variant spell "Storm Bolt (burst)" (N9) (B) | S-1 | Q?-1, Q?-13 |
| Absolute Denial | 3210 | SPELLWARDEN / Level 18, Reflective Warding | "Enemy spells of PP 8 or lower automatically fail when cast into or from within this aura" (20 ft, while conscious); 0 AP toggle at start of turn | FC-01 A; EA-R5 ruled **leave** | `registerCastReaction` `{stop}`: "resolves as a failure", with ctx `pp` (L1484) | **C.** Toggle ability (A). Cast reaction: an enemy caster inside 20 ft, or a target inside, and ctx `pp` ≤ 8 → stop (A). An area placed into the aura from outside is a GM card, because ctx has no template | — | Q?-14 |
| Chronostasis | 3276 | ETERNAL-VIGIL / Medicine 6 | 1/day, instead of Dying: stay at 1 HP, "cannot be reduced below 1 HP", resistance to all damage, until your next turn; then Dying "as normal (unless healed)" | FC-07 A | death guard offer, frequency daily, notOutright (death-guard.mjs); auto guard on an effect; `registerDamageReaction` `{resist: "all"}` (L1464) | **B.** Offered guard (1 HP). Then an effect carrying an `auto` guard + the damage reaction until your turn starts. At turn start, if not healed, set 0 HP and Dying via `applyConditionTags` | — | — |
| Confluence Master | 3326 | LEYLINE-WEAVER / Tradition skill 10, Leyline Anchor | where lines overlap, tap both: advantage on Tap; on a success +1d8 PP "from Leyline Power" | FC-12 B; EA-M25 stack | `helpers.regionContains`; module Tap (block2 L409 picks one line) | **B.** The Tap picker finds 2+ ley regions at your token → "tap both?" → advantage; Leyline Power then adds 1d8 | — | — |
| Damaging Gambit | 3362 | FATESPINNER / Sense Motive 10 | casting an Attack-trait spell: a conviction point for "advantage on the attack element of the check" | FC-16 B | core conviction advantage covers saves and skills only (`conviction.mjs` CONVICTION_SPENDS L32–35); a spell attack's cast check is asked as "attack" (`cast-workflow.mjs` L2829) | **B.** Before-reaction on `type: "attack"` from a cast: ask → `spendConviction` → `{advantage}` | — | Q?-5 |
| Deep Weave | 3372 | SPELL-WEAVER / Level 5 | Reservoir +1 a day; regain 1 charge on a critical spell attack or a critical save against a spell (1/round) | FC-17 A | `extra-uses.mjs` table is core-only (L58); `checkReactionsAfter` sees spell-attack and save degrees | **A.** +1 use (S-10, or the module writes `bonusUses`). Regain: after-reaction on your critical spell attack / save with `saveSource` → `usesValue + 1` (capped), once a round | S-10 | — |
| Destiny’s Embrace | 3382 | FATESPINNER / Sense Motive 6 | use Foreseen "to force an enemy to reroll an attack check against one of your allies" | FC-18 B | after-reaction `{reroll}` with `target` (reactions-workflow L182) | **B.** On an enemy's attack at an ally within 30 ft: ask the Fatespinner (reaction + Foreseen Danger's Focus use) → reroll; the second stands | — | Q?-8 |
| Duellist’s Focus | 3412 | SPELL-DUELLIST / level 5 | riposte +1 circ, +2 "if the triggering attack was a spell attack" | FC-21 A | — | **A.** The riposte reads it | — | — |
| Duellist’s Supremacy | 3422 | SPELL-DUELLIST / level 15, Rippling Counter | riposte once a round with no PP (still a reaction); advantage if the attacker is your Mark | FC-22 A | — | **A.** The riposte reads it; the Mark is read from Spellblade's Mark's own state (another list, Block 6) | — | Q?-8 |
| Eclipse Step | 3432 | SHADE-MASTER SHADOW / Survival 14, Grasping Shadows | Fade Step "as a Free action once per round, but only if you end your turn in dim light or darkness"; 1/day a 120-ft shadow-to-shadow Fade Step, then Concealed until your next turn | FC-23 B; m81 ruled (Focus not lifted) | as Fade Step | **B.** Fade Step offers "free (Eclipse Step)" once a round, still spending Focus (m81); 1/day 120 ft + Concealed | — | Q?-8, Q?-15 |
| Extra Reservoir | 3510 | SPELL-WEAVER / Level 4 | Reservoir +2 a day | FC-31 A | as Deep Weave | **A.** +2 uses | S-10 | — |
| Eye of the Storm | 3518 | AIR ELECTRICITY STORMCALLER / Survival 14, Lightning Rod | with ≥ 1 PP, a 10-ft aura that enemies treat as difficult terrain; 1/day expand to 30 ft for 3 rounds: enemies 1d6 electricity per level at the start of each of your turns (basic Reflex), you immune to electricity | FC-32 B; EA-R1 ruled **leave** | `runAreaEffect`; immunity AE; no moving terrain region | **C.** Expansion: Use (daily) → AE immunity + turn-start `runAreaEffect` for 3 rounds (A). The 10-ft difficult terrain is a card: the core has no region that follows a token | — | — |
| Fate’s Favour | 3528 | FATESPINNER / Sense Motive 6 | first time each day you spend conviction for advantage: "you only expend the conviction if the result of the check is a success or greater" | FC-33 A; EA-m41 corrected | `flags.trg-prime.convictionRefund` (`conviction-refund.mjs` L33): skill checks only, no daily limit | **A (with S-5).** Declared refund on save + skill, daily | S-5 | Q?-4 |
| Glyph Shatter | 3554 | RUNEBREAKER RUNEMAGE / Linguistics 10, Rune Rend | after a successful Dispel, optionally fracture: creatures within 10 ft take 1d6 force per 2 PP of the dispelled effect (basic Reflex); a dispelled ward or barrier gives +1 circ to your next Dispel within 1 minute | FC-36 B | `registerDispelModifier.onResult` ctx `{countered, target, effect, dispel.effectValue}` (L1322) | **B.** `onResult` on Success+ → ask → `runAreaEffect` 10 ft around the target's token. If it was Warding-trait or a wall, a 1-minute flag makes the next `offer` add `modifiers: [+1 circ]`. Core Runemage owners qualify too (any-of) | — | — |
| Grasping Shadows | 3566 | SHADE-MASTER SHADOW / Survival 10, Shadowmantle | after a Shadow-trait spell or a Fade Step: 1 PP, one creature within 10 ft "of your destination square" makes Reflex vs your spell DC: Crit none / Success Slowed 1 / Failure Immobilised / Blunder + 1d6 essence per 2 character levels (basic Fort) | FC-37 B; m42 ruled (Fumble → Failure; character levels) | `trgPrimeSpellSettled` traits; `helpers.rollCheck`, `applyConditionTags` | **B.** Offered on settled (Shadow trait) and after Fade Step: pick the creature, the save, then the ladder (Partial/Fumble → Failure) | — | Q?-16 |
| Improved Counter Channel | 3636 | SPELLWARDEN / Level 5 | range 60 ft | FC-43 A | — | **A.** Counter Channel reads it | — | — |
| Instinctive Counter Channel | 3646 | SPELLWARDEN / Level 10, Improved CC | "as a free action, but only once per round" | FC-44 A | — | **A.** Asked without a reaction, once a round; Focus still spent (Q?-8) | — | Q?-8 |
| Iron Ward | 3656 | FOCUS FERROMANCER MANIPULATE / Arcana 6; 1 AP | +2 circ DB until the start of your next turn | FC-45 A | feat automation + timed AE (Block 5 pattern) | **A.** | — | — |
| Last Horizon | 3668 | ETERNAL-VIGIL FOCUS HEALING / Medicine 12, Temporal Reprieve; 0 AP; trigger: you gain Dying; once per minute | "act normally and do not need to make a dying check"; Dying as normal if not healed before your next turn | FC-46 A; m36 corrected | `consciousWhileDying` (`elixirs.mjs` L391) withholds Unconscious; the dying check is always rolled (`documents/combat.mjs` `#processDyingCheck` ~L1370) | **B (with S-6).** Asked when Dying is applied; sets `consciousWhileDying` and the S-6 waiver for that Dying until your next turn's start, then clears both | S-6 | — |
| Leyline Anchor | 3696 | LEYLINE-WEAVER / Tradition skill 6 | 1/day after a successful Tap: anchor for 1 minute; "always considered to be within 30 ft" and "may use Leyline Power once per round without re-tapping" | FC-48 B; M45 ruled (Success works) | module Tap state | **B.** A 1-minute anchor flag; Leyline Power gets a Use (1d8) usable once a round while anchored; Focus still spent (Q?-8) | — | Q?-8 |
| Leywalk | 3706 | LEYLINE-WEAVER / Tradition skill 12, Confluence Master | Ley Walker specialist spell; +2 status to Cast a Spell checks for it | FC-49 A (said the spell was missing); EA-C7 ruled: **Ley Walker added** (L8437) | `registerSpellCheckGate` `{modifiers}` (L1083) | **B.** Build Ley Walker now from `book.specialist`. Its requirement (within 30 ft of a perceived line) is checked; the travel, 10 mi/CL, is a card. Gate +2 status (A) | — | — |
| Lightning Rod | 3716 | METAMAGIC STORMCALLER / Arcana or Survival 10, Thunderclap Aura; +2 PP | on an electricity hit, mark the creature; your next electricity spell before the end of your next turn splashes "half the spell’s damage dice" on enemies within 10 ft of it; metal: −2 on its initial save | FC-50 B (D2) | `moduleMark`; `runAreaEffect` | **B (waits D2).** onSettled marks; the next electricity cast splashes (N10) | D2 | — |
| Living Iron | 3728 | FERROMANCER WARDING / Arcana 12, Steelbinding | with ≥ 2 PP: resistance to slashing and piercing | FC-51 A | `registerDamageReaction` `{resist}` (L1464) | **A.** Answers while PP ≥ 2 | — | — |
| Living Sigil | 3752 | RUNEBLADE / Level 12, Twinflare Rune | three Runeblade Runes | FC-53 A | — | **A.** | — | — |
| Overflow Casting | 3820 | FOCUS SPELL-WEAVER / Level 10, Deep Weave | spend charges you lack: 2d6 per excess "(ignores resistances)"; at 0 HP or less, 5 Soul Drain | FC-59 B | `applyTypedDamage`; Soul Drain exists (`combat/death-state.mjs`) | **B (waits D2).** The charge payment allows going below 0 with this feat; the damage ignores defences; Soul Drain 5 at ≤ 0 HP | D2 | — |
| Reflective Warding | 3928 | SPELLWARDEN / Level 14, Instinctive CC | on a Counter Channel Critical, "redirect the spell back at its caster (as though they had cast it on themselves, using their own save DC)" | FC-64 C | stop only | **C.** With S-4 `retargetCaster`, a targeted spell lands on its caster (A); an area spell is a GM card | S-4 | — |
| Rippling Counter | 3958 | SPELL-DUELLIST / level 10, Duellist’s Focus | a riposte critical: take a Step and another melee Strike that "cannot channel a spell" | FC-67 B | `helpers.armMove` (Step), `rollWeaponAttack` | **B.** After a critical riposte: click a 5-ft Step, then a Strike (runes and traits as normal, no cantrip) | — | — |
| Runeforge Mastery | 3978 | RUNEBLADE / Level 18, Living Sigil | Runeblade Runes "ignore any resistance to their damage type. Furthermore, immunity is treated as resistance" | FC-69 A | resistance bypass is cast-scoped only (`damage-workflow.mjs` L43–57) | **A (with S-8).** The infusion records which runes are Runeblade ones; S-8 applies to their packets | S-8 | — |
| Rune Rend | 3988 | RUNEBREAKER / Linguistics 6 | on an absorb, 1 PP: the caster takes 1d6 force per 2 PP of the spell (basic Will) | FC-70 B | `basicSaveHit` | **B.** Asked after the absorb; basic Will against your Spell Save DC | S-3 | — |
| Runic Overload | 3998 | FOCUS FORCE RUNEBREAKER SAVE / Linguistics 14, Glyph Shatter | releasing a stored spell: "effective PP by +2" and +1d6 force per 2 PP to all targets hit (basic Will); then you take 1d6 per 2 PP backlash (basic Fort) | FC-71 B | release reuses `castSpell(…, {stored})` (`spell-storing-workflow.mjs` L115); nothing marks a stored release | **B (with S-3c).** A cast option on a stored release → riders on settled | S-3 | Q?-11 |
| Shadowmantle | 4066 | SHADE-MASTER / Survival 6 | in light 5 or less: +1 circ DB and saves against spells; 1/day, Fade Step also grants Hidden until your next turn | FC-76 B | C4 light; before-reaction for saves; spell-attack DB has no defender rows except Dragonhide/Spell Resilience (`cast-workflow.mjs` ~L6010) | **B.** Saves: before-reaction (spell `saveSource`, light ≤ 5) +1 circ (A). DB: S-9 row with `lightLevels {max: 5}` (A). Hidden rider on Fade Step, daily (A) | S-9 | — |
| Steelbinding | 4142 | FERROMANCER METAMAGIC / Iron Ward; +2 PP; Requirements (L4150, lost in book-text.json) "your spell targets a creature wearing metal armour who is within 30-ft" | target Fortitude vs Spell DC: Crit none / Success Slowed 1 / Failure Immobilised (to the end of your next turn) / Blunder + drops a held metal weapon | FC-82 B (D2); m45 rewrite suggested | — | **B (waits D2).** `applies`: a target within 30 ft wearing metal armour (asked when the armour's material is not known); onSettled: save + ladder (Partial/Fumble → Failure) | D2 | — |
| Temporal Reprieve | 4184 | ETERNAL-VIGIL FLOURISH FOCUS HEALING OPEN / Medicine 8, Chronostasis; 0 AP | "heal yourself of 1d8 HP per PP expended. This does not provoke reactions" | FC-85 B; m46 "corrected", but v1.6 still prints no amount | `helpers.healActor`; Flourish/Open trait gates | **B.** Use: ask the PP (bounded per Q?-17), spend it, heal | — | Q?-17 |
| Thunderclap Aura | 4196 | METAMAGIC STORMCALLER / Survival 6; +2 PP | air or electricity spells: "all creatures within 10-ft take 1d6 electricity damage per 2 PP of the cast spell (basic Fort)" | FC-86 A (D2) | `runAreaEffect` | **A (waits D2).** onSettled: 10 ft around you, everyone but you | D2 | — |
| Twinflare Rune | 4208 | RUNEBLADE / Level 6 | two Runeblade Runes | FC-87 A | — | **A.** | — | — |
| Wellspring Conduit | 4274 | FOCUS SPELL-WEAVER / Level 15, Overflow Casting | at 0 charges, damaging spells +1d6 per 2 PP expended; healing spells heal +1d6 per 2 PP instead | FC-93 A | — | **A (waits D2).** A required, 0-cost D2 option while charges are 0, with mods computed from the cast's PP (`damageDice` / `healDice`) | D2 | — |

##### Notes

1. **Eternal Vigil, Touch of Healing at 0 HP.**
   - Built as a death guard on the feat: `{ label: "Eternal Vigil", offer: true, askOwner: true, frequency: "daily", notOutright: true }`. It is offered only while PP ≥ 1 (the module's `requires`).
   - When it is taken, the guard holds the creature at 1 HP (today's shape). The module then calls `helpers.castSpell(actor, Touch of Healing, …)` on self as a free action. Its PP and warps are paid normally, so Eternal Vigil's own fast-healing warp can be bought.
   - The printed result is 0 HP + healing, so this ends 1 HP high. S-7 would make it exact. Otherwise the card says so (Q?-3).
2. **Foreseen Danger.**
   - A `before` check reaction on an attack, save or skill check of an ally within 30 ft of an owner who has a reaction and an unspent Focus use.
   - The module asks the owner (`askReactor`, 30 s). On yes, it rolls 1d6 itself, so it is "rolled before the outcome", and answers `modifiers: [{ label: "Foreseen Danger", value: n, type: "untyped" }]`.
   - Casting checks of non-attack spells are not asked: `reactionCheckType` is attack/save/skill (`reactions/reactions.mjs` L29). That is a limitation, and the card says so.
   - It is asked on every eligible ally check, as the book's trigger implies. A per-actor "offer Foreseen Danger" toggle stops the asking.
3. **Ferromancer.**
   - For an arcane-tradition cast, the pouch stands in for both components: no free hand is needed for somatic, and the pouch is required and spent as the material is. This needs per-tradition `freeSomatic` (S-11); the core flag is actor-wide.
   - A Sorcerer whose birthright tradition is not arcane gains nothing on those casts (Q?-6).
   - Shard Cloud's "(metal)" component is satisfied by the same pouch.
   - "Topped up" is the pouch's own uses and purchase.
4. **Leyline Power.**
   - Offered from the module's Tap branch after the outcome card (Success or better), to an owner with a reaction and an unspent Focus use.
   - 1d8 PP, or 2d8 on a Critical, capped at max, then the reaction and the Focus use are spent.
   - It stacks with the ladder's 1d8, Ley Channeler and Confluence Master (EA-M25 ruled **stack**).
   - While anchored (Leyline Anchor), a Use rolls 1d8 once a round.
5. **Fade Step.**
   - Gale Step's click-to-land code with a 30-ft limit, 1 AP and Focus.
   - The origin must be in light 5 or less (`lightLevelAt(token)`). "Shadow" is defined in Fiends & Fables (M54), and is read as light 5 or less (Q61's ambient level).
   - **The destination is checked after landing.** If its light is above 5, the token is moved back and nothing is spent. This avoids a "light at a point" seam.
   - Eclipse Step's free use and 120-ft daily use, Shadowmantle's Hidden and Grasping Shadows' offer hang off its card.
6. **Counter Channel.**
   - A `registerCastReaction` offer, as Disrupting Magic is built (block3b). It is asked of each owner within 30 ft (60 with Improved) when a non-ally casts.
   - The owner needs a reaction (none with Instinctive, once a round), a Focus use and 1 PP.
   - `helpers.rollCheck` Power Manipulation vs the spell's Save DC. With no save, the caster's Spell Save DC (m79).
   - Critical → `{stop: true}` (A today). Success/Fumble need S-4 (halve or double, else save advantage or disadvantage). Failure: nothing.
   - Reflective Warding rides on the Critical.
7. **Spellstrike Riposte.**
   - On `trgPrimeStrikeResolved` with `melee && missed && !noReactions` and a target owning it (melee reach).
   - A melee spell attack's miss is caught by an `after` check reaction (`type: "attack"`, failed, `target`), since spell attacks do not fire the Strike hook.
   - Asks the owner, then spends the reaction, the Focus use and 1 PP (none once a round with Duellist's Supremacy).
   - `rollWeaponAttack` with MAP ignored and Duellist's Focus' +1/+2 circ.
   - On a hit the owner picks a known damaging cantrip. Its damage formula is rolled and applied as secondary damage of its type, and the cantrip is not cast (M26 "adding any damage as secondary").
8. **Spell Weaver options.**
   - (a) −2 PP, min 0.
   - (b) "one step" on every damage and healing die of the cast: d4→d6→d8→d10→d12, a d12 staying d12 unless ruled.
   - (c) one of duration, range or area ×1.5, chosen. Duration or range are read from spellData, and an area's radius or length is ×1.5 rounded down to 5 ft (m128).
   - None is expressible today: a cast option cannot return mods or PP, and a warp's `rangeOverride`/`areaOverride` are fixed strings. It belongs to D2, with charges as the payment, a negative cost and two new mods.
9. **Stormcaller's burst.**
   - The warp turns an attack into a basic-save area, and no warp mod does that.
   - Module-only build: the archetype grants a variant spell item, "Storm Bolt (burst)": category save, Basic Reflex, 10-ft radius at a point within 30 ft, 1d12 of the chosen type, PP 3 (1 + 2), less Stormcaller's 1 = 2 PP.
   - It is flagged `eaVariantOf: "Storm Bolt"` and does not count as a separate spell known.
   - A seam (a `saveOverride` warp mod) would be cleaner. It is not proposed, because the variant does the job.
10. **Lightning Rod.**
    - "Half the spell’s damage dice": half the second spell's dice count, rounded down, min 1, of the same type.
    - The splash is not a save unless the spell had one. The metal −2 applies to the marked creature's first save against that second spell.
    - The module's mark is a `moduleMark` effect that expires at the end of your next turn.

##### Proposed core seams

- **S-1 — Cast cost discount (D5's discount half).**
  - *What:* `registerCastCostModifier(key, ctx => ({ pp, label }) | null)`, ctx as `registerCastSurcharge`'s (`{ actor, spell, spellData, innate, cantrip, itemCast, basePP, totalPP }`). The PP is taken off what is paid, after warps and surcharges, never below 0. Per Q?-13's proposal, the casting DC and the per-cast cap still read the undiscounted PP.
  - *Where:* `magic/cast-workflow.mjs` at the PP payment, beside `magic/cast-surcharge.mjs` (C3).
  - *Users:* Stormcaller (Storm Bolt −1); Spell Weaver's −2, if D2 does not carry negative costs.
- **S-2 — Progression shapes the book prints.**
  - *What:* `parseProgressionClause` (`archetype-progression.mjs` L112) learns:
    - `cannot progress` → `{type: "never"}` (never met; `archetypeProgressionBlockReason` says "this archetype cannot progress");
    - if Q?-1 rules a delta: `+N levels` → met when level ≥ the level the archetype was taken at + N. That level is stamped on the feat as `flags.trg-prime.archetypeTakenAt` when it is added (the picker's add path).
  - *Users:* Eternal Vigil; Runeblade, Spell Duellist; also the Pacts, Hex Weaver, Bloodmage and Blood of the Wyrm in other lists.
- **S-3 — Spell store host, a foreign spell, and a stored-release marker.**
  - *What:*
    - (a) `bondedItemFor` (`spell-storing-workflow.mjs` L30) also accepts an item flagged `flags.trg-prime.spellStore: true`, so the Rune birthright's runes can hold the spell.
    - (b) `storeSpell` (L79) accepts a spell copied onto the storer for this purpose (flagged `storedForeign`), deleted when it is released or the store is cleared.
    - (c) `stored: true` on the cast-option ctx and on `trgPrimeSpellSettled` (`cast-workflow.mjs` L5503).
  - *Why:* without (a), **Storing Rune as built in Block 3a probably answers "no bonded item"** for a Rune Sorcerer (`spell-effects.mjs` L4605). Check live.
  - *Users:* Storing Rune, Runebreaker, Rune Rend, Runic Overload.
- **S-4 — A cast reaction that shapes the cast.**
  - *What:* `castReactionsFor` (`reactions/reactions-workflow.mjs` L289; called at `cast-workflow.mjs` L3103) accepts an answer `{ scale: 0.5 | 2, saveBias: "advantage" | "disadvantage", retargetCaster: true, line }`. `scale` multiplies area, duration, number of targets and the dice count of the cast's damage, rounding down with min 1. `saveBias` applies to every target's save when nothing scales. `retargetCaster` makes the caster the sole target, at their own DC.
  - *Users:* Counter Channel (with Improved and Instinctive), Reflective Warding.
- **S-5 — Conviction refund scope.**
  - *What:* `convictionRefund` (`conviction-refund.mjs` L33) takes `checkTypes` (default `["skill"]`) and `frequency: "daily"`. A daily refund is marked on the actor and cleared at daily preparation, as `declaredUsedToday` is. Callers: `dice/check.mjs` L1434 and `dice/check-card-interactions.mjs` L156.
  - *Users:* Fate's Favour.
- **S-6 — Dying check waived.**
  - *What:* `#processDyingCheck` (`documents/combat.mjs` ~L1370) skips the roll while `flags.trg-prime.dyingCheckWaived` names the live Dying effect. This is the shape of `consciousWhileDying` (`elixirs.mjs` L391), and the card says why.
  - *Users:* Last Horizon.
- **S-7 (optional) — A death guard that casts on yourself.**
  - *What:* `deathGuard.castSelf: "Touch of Healing"`. The guard leaves 0 HP with no Dying, then casts that spell on the creature as a free action from its own PP. It is not offered when the PP is short.
  - *Users:* Eternal Vigil. The interim build (N1) is 1 HP high.
- **S-8 — Rune damage that bypasses resistance.**
  - *What:* an attacker flagged `flags.trg-prime.runeDamageBypass: { runes: [keys], immunityAsResistance: true }` makes those runes' damage packets skip resistance, and meet immunity as resistance. Read where `activeResistanceBypass` is (`combat/damage-workflow.mjs` L56–57, ~L160), for the rune secondary packets.
  - *Users:* Runeforge Mastery.
- **S-9 — Defender rows on a spell attack.**
  - *What:* the target's items and effects may declare `flags.trg-prime.spellAttackDB: { value, type, label, lightLevels }`. These are added to `defendedDB` (`magic/cast-workflow.mjs` ~L6015) with typed stacking, `lightLevels` read at the target's token.
  - *Users:* Shadowmantle.
- **S-10 (small) — Declared extra uses.**
  - *What:* `extraUsesBonus` (`extra-uses.mjs` L76) also reads `flags.trg-prime.extraUses: { ability, perCopy }` on owned feats, beside the frozen table (L58).
  - *Users:* Deep Weave, Extra Reservoir (and the other lists' "Extra …" feats). Interim: the module writes `bonusUses` when the feats change.
- **S-11 (small) — Free somatic by tradition.**
  - *What:* `freeSomatic` (`magic/component-gate.mjs` L39) may be `{ traditions: ["arcane"], needsPouch: true }`.
  - *Users:* Ferromancer, if Q?-6 is answered as proposed.
- **D2 — what my feats need from `registerMetamagic`.**
  - The standard option (+PP, `applies`, `onSettled`): Steelbinding, Lightning Rod, Thunderclap Aura.
  - Payment in a named ability's uses: Spell Weaver, Overflow Casting. Overflow Casting may also overspend, with the module's damage.
  - A **negative** `ppCost` floored at 0 (Spell Weaver).
  - New mods `dieStep` and `scale: { range | area | duration: 1.5 }`.
  - A `required` 0-cost option whose mods are computed from the cast's PP (Wellspring Conduit).
- **Considered, not proposed:**
  - Light at a point: Fade Step checks after landing (N5).
  - Attack → save warp: the variant spell (N9).
  - Check reactions on casting checks: Foreseen Danger's limitation (N2).
  - A moving terrain region: Eye of the Storm's card.

##### Questions

- **Q?-1 — Progression lines (Runebreaker, Shade Master, Stormcaller, Runeblade, Spell Duellist, Leyline Weaver).**
  - *Issue:*
    - (a) Runebreaker, Shade Master and Stormcaller print no Progression Requirements. M3 answered "cannot progress" only.
    - (b) Runeblade and Spell Duellist print "+10 levels." The core reads "+N levels" as levels gained *since* taking the archetype, and leaves it unparsed (`archetype-progression.mjs` L64–70), so today it never blocks.
    - (c) Leyline Weaver: "Tradition skill +10 ranks" — which skill?
  - *Why:* each decides when a second archetype may be taken.
  - *Proposed:*
    - (a) As Eternal Vigil: no later archetype (they are birthright capstones like it). Else print a line.
    - (b) Levels gained since: Runeblade (taken at 2) completes at 12 (S-2).
    - (c) Any one of Arcana, Nature, Occultism or Religion at +10 ranks, matching the prerequisite's "any one tradition skill" (parseable today).
- **Q?-2 — Eternal Vigil's warp.**
  - *Issue:* "+2 PP: gain fast healing 5 for a number of rounds equal to the PP of the spell cast (before applying this option)". Who gains it — the caster, or the healing spell's targets? And is the PP the base or the total less this option?
  - *Proposed:* the spell's targets (it is a warp on the spell, as Life Boost's fast healing is); rounds = PP spent on the cast less these 2.
- **Q?-3 — Eternal Vigil at 0 HP.**
  - *Issue:* "when reduced to 0 HP, you can cast Touch of Healing on yourself as a free action". Does it prevent Dying, and where does HP land?
  - *Proposed:* offered once a day when damage would take you to 0 (not against an outright kill); no Dying; HP = Touch of Healing's healing from 0. That needs S-7; interim 1 + the healing, said on the card.
- **Q?-4 — Fate's Favour direction.**
  - *Issue:* "you only expend the conviction if the result of the check is a success or greater". Read literally, the point is refunded on Partial or worse. Inner Tempest's identical sentence (Adaptive Mind, B5-3) was ruled the other way: refunded **on** a Success or better.
  - *Why:* opposite behaviour from the same words.
  - *Proposed:* the literal reading (refund on Partial, Failure, Fumble, Blunder), on saves and skills (the checks conviction advantage applies to), the first time each day; and say whether B5-3 should be revisited.
- **Q?-5 — Damaging Gambit.**
  - *Issue:* "advantage on the attack element of the check". A spell attack's casting check *is* its attack roll (one die; `cast-workflow.mjs` L2829).
  - *Proposed:* the one roll has advantage, so it helps the casting degree too.
- **Q?-6 — Ferromancer's components.**
  - *Issue:* "You replace material and somatic components when casting arcane spells with various shards of metal … kept in a component pouch". Does it free the hand somatic needs, and must the pouch have a use for every arcane cast? Does "arcane" mean the Arcane tradition only?
  - *Proposed:* yes, yes, and yes. A Sorcerer's non-arcane birthright casts are unchanged.
- **Q?-7 — Leyline Weaver's Critical "benefits x2".**
  - *Issue:* many ley effects have no number (advantage, True Seeing).
  - *Proposed:* every number in the rolled effect doubles (bonus, temporary HP, PP, dice). An effect with no number is gained once, lasting until the end of your next turn.
- **Q?-8 — Focus abilities a later feat lets you use "once per round".**
  - *Issue:* Instinctive Counter Channel, Duellist's Supremacy and Leyline Anchor (and Destiny's Embrace spending Foreseen). m81 ruled Eclipse Step "does not lift the focus limit as you are still using the base ability".
  - *Proposed:* the same for all four: the Focus use is still spent (Refocus is 1 AP), and the feat changes only the action, PP or trigger.
- **Q?-9 — Runeblade's "Defending I".**
  - *Issue:* no Defending rune exists in the core (`weapon-rune-data.mjs`) or in Eldritch Arts. Bane and Returning have no tier I either, which is harmless.
  - *Proposed:* name the intended rune. Until then it is left off the list, and the card says why.
- **Q?-10 — What Runebreaker can absorb, and how it is released.**
  - *Issue:* "triggered by you being targeted by an incoming spell … absorb the incoming spell and may then release it as if it had been cast into your Storing Rune".
  - *Proposed:*
    - Only a spell whose sole target is you (not areas or multi-target spells).
    - You pay Storing Rune's PP (and any of its warps) and your reaction.
    - The Will save is against the caster's Spell Save DC. On a Success or better the spell is stopped and stored at the PP its caster paid.
    - On release, you are its caster (your checks and DC), as Storing Rune's release is.
- **Q?-11 — Runic Overload's "effective PP by +2".**
  - *Proposed:* the released spell counts as 2 PP higher for every number that reads its PP (this feat's 1d6 per 2 PP riders, a counteract value), and buys no warp or extra dice of its own.
- **Q?-12 — Counter Channel's "variables".**
  - *Proposed:*
    - Halved or doubled: area (radius or length, rounded down to 5 ft), duration, number of targets (min 1), and the number of damage dice (rounded down, min 1). "Damage die" means the dice count, not the die size.
    - "If the spell has no such variables" means none of the four applies.
    - It may be used against any creature's spell, allies included, as printed. The module asks only for non-allies unless the owner turns allies on.
- **Q?-13 — Do cheaper spells lower the casting DC?**
  - *Issue:* Storm Bolt "costs 1 less PP" (Stormcaller); Spell Weaver "Reduce its PP cost by 2". The casting DC is 10 + 1.5 × PP.
  - *Proposed:* payment only. The DC and the per-cast cap read the printed and warped PP, as Runebreaker's Dispel reduction leaves the counteract value alone.
- **Q?-14 — Absolute Denial's "spells of PP 8 or lower".**
  - *Proposed:* the PP the spell is cast at (warps included), so warping above 8 gets through. It applies to enemy spells only, and nothing when you are unconscious.
- **Q?-15 — Eclipse Step's "only if you end your turn in dim light or darkness".**
  - *Proposed:* the free Fade Step must land in light 5 or less (checked on landing, N5). Ending the turn elsewhere afterwards is the GM's to police.
- **Q?-16 — Grasping Shadows from a spell.**
  - *Issue:* "One creature within 10 ft of your destination square" — a Shadow spell has no destination.
  - *Proposed:* within 10 ft of you for a spell; of the landing square for Fade Step (and Eclipse Step).
- **Q?-17 — Temporal Reprieve's PP.**
  - *Issue:* "heal yourself of 1d8 HP per PP expended". m46 was marked corrected, but v1.6 L4192 still prints no cost or cap.
  - *Proposed:* spend any number of PP up to your level, per use (it is Focus: once per Refocus).

##### Waits on other blocks

- **D2 (Block 6's own core release):** Steelbinding, Lightning Rod, Thunderclap Aura, Spell Weaver's three options, Overflow Casting, Wellspring Conduit. They ship as items with the D2 note until it lands.
- **Spellblade's Mark** (SPELLBLADE class feat, another Block 6 list): Duellist's Supremacy's advantage reads its mark.
- **S-3:** Runebreaker's absorb, Rune Rend and Runic Overload. Runebreaker's Dispel discount ships now. Storing Rune's own Block 3a behaviour should be checked live.
- **Q?-9:** the Defending I rune.
- **Nothing waits on Blocks 7–10.** Every granted spell exists or is built now:
  - Touch of Healing, Storm Bolt, Storing Rune, Shadow Shift and Dark Whispers are built (`block3-spells.mjs`).
  - Shard Cloud (L8723) and Ley Walker (L8437) are in `book.specialist` and are built in Block 6.
  - Gale Step is built (Block 3).
  - No catalyst, orb or Grimoire spell is needed.

##### Minor

- `book-text.json` drops Steelbinding's Requirements: the bold `**; Requirements**` (m45) splits it away. Read it from ea.md L4150 (metal armour, within 30 ft).
- The matrix is stale here:
  - FC-49 says Ley Walker is missing (now L8437, EA-C7).
  - FA-16 quotes v1.4's "character level" (v1.6: Spellblade level).
  - FC-50 to FC-86's "Offered in the Warp? dialog" depends on D2.
- Typos still in v1.6:
  - Leyline Weaver "when use the Tap Ley Line action", "gaining is benefits" ×2 (m31 marked corrected; L3076–3082 unchanged).
  - Shade Master "costs your 2 PP less".
  - Stormcaller "you gain following warping option which may be applied the Storm Bolt spell".
  - Counter Channel "The spells variables", "The spell double" (m79 marked corrected).
  - Last Horizon "the dying conditions acts" (m36).
  - Fate's Favour "check;".
  - Iron Ward "a shield of metal shards around that grants" (around you).
  - Grasping Shadows "per 2-character levels".
- Fatespinner's DIVINER trait names no class. The picker ignores unknown traits, and Adept already covers Wizards. Drop it, or say what it means.
- The Spellwarden's "against magic" and Shadowmantle's "against spells" are different scopes. Both are built on spell-forced saves; Spellwarden alone also gets the ticked "other magic" row.
- Thunderclap Aura: "all creatures within 10-ft" is read as of you, everyone but you, including allies; "per 2 PP of the cast spell" includes this feat's +2.
- Glyph Shatter is any-of RUNEBREAKER or the core's RUNEMAGE: a core Runemage qualifies.
- Absolute Denial (EA-R5) and Eye of the Storm (EA-R1) were ruled **leave as printed**.
- `sourceArchetype` on module feats is inert in the core; harmless. Set it anyway for the sheet's provenance text.
- Shade Master's Dark Whispers: the Umbral birthright already grants it at Sorcerer 3rd, unrestricted. Once that copy arrives, the archetype's light-gated copy is redundant (the grant reports it "held"). Before 3rd, the gated copy is the only one.
- Eternal Vigil's Death State bonus stacks with Eternity Resilience's (+4 in all), as "additional" says.

### Appendix C. Runemage class feats

Scope: the five class feats in `sections.classFeats` whose only trait is **RUNEMAGE**, the core's own archetype. They are Prepared Sigil (3906), Runic Reservoir (4010), Living Script (3738), Combat Inscription (3302) and Ley-Etched Symbol (3682). Book lines are v1.6 `ea.md`. The core is TRG Prime 3.683.0 (`/home/claude/core-3676/trg-prime/module/`). The module is Eldritch Arts 0.8.0.

Related entries reviewed elsewhere, and kept consistent here:
- **Glyph Shatter** (RUNEBREAKER RUNEMAGE) is in `b6-audit-arch2.md`. It is any-of, so a core Runemage qualifies.
- **The Runeblade and Runebreaker chains** are also in `b6-audit-arch2.md`.
- **Ley-Etched Symbol's −1 PP** is in `b6-audit-meta.md`, in the D5 table: "S-M1 option with `ppDelta`, or D5".

#### Runemage class feats

##### What TRG Prime has for the Runemage, and what it lacks

- **The archetype gate already works. No registration is needed.**
  - "runemage" is in the core's own `ARCHETYPE_NAMES` (`picker-filters.mjs` L926–929).
  - A class feat traited `Runemage` is therefore offered only to an owner of the core **Runemage** archetype feat. That archetype is traited DRUID WIZARD, with Prerequisites Linguistics 2 ranks and Progression Linguistics +10 ranks (rulebook-core-3.7 L8332–8342).
  - The trait has no hyphen, so arch2's "Lacks 1" does not apply. Author the trait as `Runemage`. Do **not** `registerArchetype("Runemage")`, because that would duplicate the core's own gate.
- **Symbol is built** (`magic/runemage.mjs`, since 3.546.0):
  - `isRunemage(featNames)` (L68) is the one detector.
  - `symbolComponents` (L86) replaces verbal, material and focus with `symbol`.
  - `needsFreeHandFor` (L111): Symbol needs a free hand on every spell (Graham, 10 Sep 2026).
  - `focusSatisfiesHand` (L126): a held focus does **not** satisfy a Symbol.
  - `symbolRoomLine` (L131): "room to draw" is a **card line**. The core says outright that the table decides it.
  - The gate is `componentGate` (`component-gate.mjs` L82). It is called at `cast-workflow.mjs` L863–871, before any prompt or dialog.
- **The DC arithmetic is built:**
  - `assembledCastingDC` (`casting-dc.mjs` L107; Runemage part L174–183) has one part, "Runemage" −1, or "Runemage, defensive" +1, meaning −1 plus 2.
  - The save DC is +1 (L358).
  - Under a *declared* defensive casting (Faultless Casting), the caller passes `defensive: false` (`cast-workflow.mjs` L2480). The Runemage +2 is then not applied.
- **The +2 to identify runic symbols** is a queued one-shot pending modifier (`feats-workflow.mjs` L5262).
- **Seams the five feats can use today:**
  - `trgPrimeDailyPreparation` (`uses-workflow.mjs` L747).
  - `registerCastPrelude` (`module-api.mjs` L1544). It is awaited before `castSpellResolved`, so before the component gate (`cast-workflow.mjs` L538–553). Thunderous Strike uses it.
  - `trgPrimeSpellSettled` (L5503), with `degree` and `castOptions`.
  - `registerCastOption` (L1272).
  - Block 2's ley-line tables: `rollTable`, and `LEY_LINE_EFFECTS` column "b" (`block2-automations.mjs` L345, L512).
- **What is missing:**
  - **(a) No way to make a cast cheaper in AP, except core Quicken.** `registerCastOption`'s `ap` must be positive ("an option is not a way to make a cast cheaper", `cast-options.mjs` L80). Only the core metamagic aggregate's `apDelta` (`metamagic.mjs` L382) reaches `totalCastTime` (`cast-time.mjs` L287, minimum 1).
  - **(b) No way to lift Symbol's hand requirement for one cast.** The gate runs before any module is asked anything except a prelude, and a prelude can only pass the core's fixed `castSpell` options.
  - **(c) No way to cancel the Runemage's defensive +2.** The cast-option ctx has no `defensive` (L2216), and the core computes the part itself.
  - **(d) No PP discount on a spell's own cost.** `registerCastSurcharge` is ≥ 0 (`cast-surcharge.mjs` L24). `warpDiscount` covers warps only (`cast-workflow.mjs` L1603). This is D5's missing cost half.
  - **(e) No module marker for "gaining the benefits of a ley line".** Block 2's `leyBenefits` (L487) rolls a row. Some rows are instant (PP, damage), and they leave no effect behind to test.
  - **(f) No helper that answers "can this spell be cast today?"** It is `spellAvailability(...).castable` / `spellCastBlocked` (`spell-availability.mjs` L118, L189). Neither is on `helpers`. `helpers.castRefusal` (L555) does not include it (`cast-workflow.mjs` L499–511).

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| **Prepared Sigil** | 3906 | RUNEMAGE / Linguistics 4 ranks | At daily preparation, inscribe the Symbol of one spell "that you are able to cast that day". Once before the next preparation, cast it via the sigil: "You do not require room to draw the Symbol"; "Reduce the spell's casting time by 1 AP (minimum 1 AP)"; PP as usual; "Any Somatic component is unaffected". Then it fades until the next preparation. | FC-63 A ("AUTO at daily prep + AP reduction") | Daily-prep hook; prelude; Symbol gate; `totalCastTime` floor 1; nothing to reduce AP or lift the Symbol hand | **B.** The feat's Use button inscribes the sigil once per day (N1). A prelude asks "Activate your Prepared Sigil?" on a cast of that spell (N2), then calls `castSpell(…, { preparedSymbol })` (S-R1). Spent on settle. Passive; no AP of its own | S-R1, S-R3 | Q?-1, Q?-2 |
| **Runic Reservoir** | 4010 | RUNEMAGE / Linguistics 8 ranks, Prepared Sigil | Three Prepared Sigils a day, "Each … must contain a different spell". "You may activate only one Prepared Sigil per round, regardless of how many you have available." | FC-72 A | — (prereq feat by name: `prerequisites.mjs` named clause) | **A** on Prepared Sigil's build. The count is 3, with three distinct spells, and the prelude refuses a second activation in the same round (N3) | (S-R1) | — |
| **Living Script** | 3738 | RUNEMAGE / Linguistics 14 ranks, Runic Reservoir | Sigils "no longer disappear permanently": after activation, unusable for 1 minute, then reform. "If you gain a Heroic result when casting a spell through a Prepared Sigil, that sigil immediately reforms." Still one per round. | FC-52 A | `trgPrimeSpellSettled.degree` | **A.** On settle with `preparedSymbol`, the sigil goes to "reforming" until +1 minute (10 rounds in combat, 60 s out of it; N4). On Heroic, it stays ready (N3's per-round lock still holds) | (S-R1) | — |
| **Combat Inscription** | 3302 | RUNEMAGE / Linguistics 6 ranks | "When using Defensive Casting, you ignore the +2 increase to Defensive Casting DC normally imposed by the Runemage archetype." A hand-sized space suffices to trace the rune. "This does not remove Somatic components…" | FC-10 A ("declared casting DC −2 when defensive and Runemage") | The +2 is inside the core's single "Runemage, defensive" part (`casting-dc.mjs` L182) and cannot be reached | **A** (the DC). The feat declares `flags.trg-prime.runemage.defensiveIncrease: 0` (S-R2), so the part reads "Runemage, defensive (Combat Inscription) −1". The hand-sized space relaxes a rule the core itself leaves to the table, so it becomes the room line's wording (S-R2 `roomNote`). The free hand is still required (N5) | S-R2 | — |
| **Ley-Etched Symbol** | 3682 | RUNEMAGE / Linguistics 8 ranks, Power Manipulation 4 ranks; **Req** "You are currently gaining the benefits of a ley line." | On a cast "using a Symbol component", "Once per round, you may reduce the PP cost of one such spell by 1 PP (minimum 1 PP)". On "a Fumble or worse result" for that spell, you also suffer "the ley line's normal backlash effect". | FC-47 A (D5, "cost modifier gated on tap state + backlash"); meta D5 table | No cost discount (d); Block 2 backlash table; no benefit marker (e) | **B (waits on D2/D5).** An S-M1 entry `ppDelta: −1, minPP: 1`, offered once a round in the Warp? dialog while the ley-benefit marker (N6) is on and the cast has a Symbol. On a settled Fumble or Blunder with its key taken, roll `LEY_LINE_EFFECTS` column "b" at the marker's level, lasting to the end of your next turn (N7) | S-M1 (+ctx `symbol`), or D5; Block 2 marker | Q?-3 |

**Levels:** A 3 (Runic Reservoir, Living Script, Combat Inscription) · B 2 (Prepared Sigil, Ley-Etched Symbol) · C 0 · D 0.

**Prerequisite chain:** Prepared Sigil (Linguistics 4) → Runic Reservoir (Linguistics 8) → Living Script (Linguistics 14). Combat Inscription (Linguistics 6) and Ley-Etched Symbol (Linguistics 8, Power Manipulation 4) stand alone. Linguistics and Power Manipulation are core skills (`config.mjs` L403; `skills.powerManipulation`). All five sit behind the core archetype gate. None grants a spell. None has a racial or heritage prerequisite.

##### Notes

1. **Inscribing the sigils (Prepared Sigil, Runic Reservoir).**
   - **Why it is not done in the daily-preparation hook.** `trgPrimeDailyPreparation` fires as the day turns over (`uses-workflow.mjs` L744–747). A book caster then prepares spells on the Magic tab, so a pick made in the hook would see yesterday's prepared spells. The matrix's "AUTO at daily prep" therefore becomes B.
   - **What the hook does.** It clears the feat's `sigils` flag and posts "Inscribe today's sigil(s): use Prepared Sigil".
   - **What the feat's Use does.** It is allowed once per day, using a day stamp in the house pattern `dayOf`. It lists the spells the actor can cast now:
     - castable today (S-R3);
     - not innate (an innate spell has no components, so no Symbol: `symbolComponents` L97);
     - with at least one component that Symbol replaces.
   - **Storage.** One spell is stored, or three distinct spells with Runic Reservoir, as `flags.trg-eldritch-arts.sigils: [{ spellId, name, state: "ready" }]`.
   - **Cantrips** are allowed (see Minor).
   - **Item cards.** Each pick posts a card naming where the sigil is inscribed (skin, focus, book…). That choice is flavour only.
2. **Activating a sigil (prelude).**
   - **When the prelude asks.** `registerCastPrelude("preparedSigil", …)` answers null unless the spell is a `ready` sigil and the round's lock is free (N3). Otherwise it asks "Activate your Prepared Sigil? (−1 AP, no room to draw)".
   - **On No:** it returns null, and the ordinary cast goes on.
   - **On Yes:** it returns `{ handled: true, result: await h().castSpell(actor, spell, { preparedSymbol: { label: "Prepared Sigil" } }) }`.
   - **When the sigil is spent.** On `trgPrimeSpellSettled` with `preparedSymbol: true`, Fumble included: "Once activated, the Prepared Sigil fades". A cast that is cancelled or refused before it settles does not spend it.
   - **Where it does not reach.** A prelude is asked only for a cast with none of the core's options (`castPreludeOwed`, L533), so a sigil cannot be used on a reaction, ritual or Strike-carried cast. Reaction casts have no AP to reduce anyway. This goes on the feat's card.
   - **Ordering with another prelude.** Thunderous Strike and Dimensional Assault are Spellblade spells, so the two cannot both claim one spell unless a Runemage is also a Spellblade. If one is, the sigil prelude should run first and pass `preparedSymbol` through the Thunderous call. That is a small module-side merge, with no core change.
3. **One per round (Runic Reservoir, Living Script).**
   - **In combat:** a `{ combatId, round }` stamp on the feat.
   - **Out of combat:** a 6-second world-time window.
   - **With a single sigil,** without Runic Reservoir, the lock is moot.
4. **Reforming in 1 minute (Living Script).** World time is not known to advance per round in combat: the core has no `advanceTime` call, and the module's `expiryFlags` keeps a 12-second backstop for this reason. The reform therefore stores both of these, and the sigil is ready when either has passed:
   - `reformRound = round + 10` for the same combat;
   - `reformAt = worldTime + 60`.
5. **Combat Inscription's hand.** "Provided that you are physically capable of making the necessary movements" and "does not remove Somatic components" mean the free-hand rule (Graham, 10 Sep 2026) stands. Only the *space* is relaxed, and the core does not enforce space. So no gate changes, and the card's room sentence reads "a hand-sized space suffices (Combat Inscription)".
6. **Ley-benefit marker (a Block 2 module change, no core).**
   - `leyBenefits` (`block2-automations.mjs` L487) also creates an effect on the actor, `source: "leyLineBenefit"`, with `{ level, name }` and the same expiry as the benefits it grants. Block 2's Channel Heroic gives 1 minute, for example.
   - The marker exists whatever row was rolled, including an instant row.
   - Leyline Weaver's replacement Tap results (L3078–3082) and its Leyline Power action, both in arch2's list, must create the same marker. Without it, Ley-Etched Symbol can never be used after them. Cross-referenced to arch2.
   - "Requirements" is a use-time condition, not a picker prerequisite. The printed line stays in the description, and the option's `applies` tests the marker.
7. **The Ley-Etched discount route.**
   - **Follows meta.** `b6-audit-meta.md` says optional, chosen-at-cast discounts are S-M1 entries with `ppDelta`/`minPP`. Ley-Etched is optional ("you may"), and a Fumble on an enhanced spell brings a backlash, so it must be a choice and not a passive D5 discount. This agrees with meta, and arch2's passive S-1 is not the right fit here.
   - **One addition to S-M1's ctx:** `components`, the effective components after `symbolComponents`, so that `applies` can test "using a Symbol component" without re-deriving the core's rule.
   - **The casting DC and the cap.** Whether they read the discounted PP follows arch2's Q?-13. Do not rule it separately.
   - **What counts as enhanced.** The Fumble test reads the settled `degree` (`fumble`, `blunder`), with the S-M1 key in the settled `metamagic` list.
   - **Prepared Sigil casts** use a Symbol too, so both feats may apply to one cast.

##### Proposed core seams

Numbered S-R1… for the lead to renumber.

- **S-R1 — A prepared-Symbol cast** (Prepared Sigil; used by Runic Reservoir and Living Script).
  - *What:* a `castSpell` option, `preparedSymbol: { label }`, passed by a module prelude. On that cast:
    - **(1) The hand.** `componentGate` treats `symbol` as needing no hand. Somatic still needs a hand, a focus or an implement as today. A third gate argument, `{ symbolPrepared: true }`, is read where `needsFreeHandFor` is called (`component-gate.mjs` L146).
    - **(2) The AP.** `apDelta −1` joins `mm.apDelta` in `totalCastTime` (`cast-workflow.mjs` L2241, L3278; floor 1 already at `cast-time.mjs` L290). The early pool test (L1146) asks for the reduced cost.
    - **(3) The card.** `symbolRoomLine` is replaced by "Prepared Sigil: the Symbol was inscribed in advance, so no room to draw is needed" (`cast-workflow.mjs` L3608–3612). The Runemage DCs still apply: "The spell otherwise functions normally".
    - **(4) Reporting.** `preparedSymbol: true` is added to `trgPrimeSpellCast` and `trgPrimeSpellSettled` (L5503).
    - **(5) No second prelude.** `castPreludeOwed` (L533) treats it as a core option.
  - *Why not D2/S-M1:* the warp dialog opens after the component gate, so an S-M1 entry could cut the AP but could not lift the hand.
  - *Why not an actor flag* in the shape of `componentSwapNext`: a flag would need clearing on every exit. A cast option dies with the cast.
- **S-R2 — Declared Runemage adjustments** (Combat Inscription).
  - *What:* an owned feat may declare `flags.trg-prime.runemage: { defensiveIncrease: n, roomNote: "…" }`.
  - `cast-workflow.mjs` (at L2442, beside `isRunemage`) reads the lowest `defensiveIncrease`, defaulting to 2, and passes it to `assembledCastingDC`. The `defensive ? 2 : 0` at `casting-dc.mjs` L182 becomes `defensive ? runemageDefensive : 0`. The label gains the feat's name when it is not 2.
  - `symbolRoomLine` takes the `roomNote`.
  - *Why:* the +2 lives inside one core part. A module cast option cannot see `defensive` (its ctx is built at L2216), and a `required` option would sit on every cast prompt. A declared flag is the house pattern, as with `consciousWhileDying` and `warpDiscount`.
  - *Smaller alternative:* add `defensive` and `declaredDefensive` to the cast-option `apply` ctx, and register a `required` option answering `castingDC: −2` when defensive. This costs one line, but it puts a permanent row on the prompt.
- **S-R3 (small) — `helpers.spellCastable(item)`** (Prepared Sigil's pick).
  - *What:* it returns `spellAvailability(item).castable && !spellCastBlocked(item)` (`spell-availability.mjs` L118, L189).
  - *Why:* "a spell that you are able to cast that day" is exactly the core's availability. Re-deriving it in the module (book pool, `prepared`, feat slots, the Arcanist's book) would duplicate the core.
- **Not new, needed:** **S-M1** (`registerMetamagic`, meta) with `ppDelta`/`minPP`, plus the `components` ctx field (N7). The alternative is D5's cost half (arch2 S-1) with an optional tick. Used by Ley-Etched Symbol.
- **Not needed:** D6, D10 and D12. No Runemage feat here dispels, changes fumble odds or touches charged items. Glyph Shatter's D10 use is arch2's.

##### Questions

**Q?-1 — Prepared Sigil: does an activated sigil lift Symbol's free-hand requirement?**
- *Issue:* "You do not require room to draw the Symbol." The core reads "room to draw the rune" as **a free hand on every spell**, and a focus does not stand in for it (Graham, 10 Sep 2026, `runemage.mjs` header). The sigil is already drawn.
- *Why it matters:* it decides whether a Runemage with sword and shield can cast the sigil's spell.
- *Proposed answer:* **yes.** The Symbol needs no hand on a sigil cast. "Any Somatic component is unaffected", so a somatic spell still needs a hand, a casting focus or an implement, as for anyone. Built by S-R1 (1).

**Q?-2 — Prepared Sigil with Quicken Spell (and Unfettered Mastery).**
- *Issue:* "Reduce the spell's casting time by 1 AP (minimum 1 AP)." The core allows one Quicken per cast (`metamagic.mjs` L381), and nothing says whether the sigil's −1 is a Quicken.
- *Why it matters:* together they bring a 3-AP spell down to 1 AP.
- *Proposed answer:* **they stack.** The sigil is not metamagic. The total is never below 1 AP (`totalCastTime`'s floor).

**Q?-3 — Ley-Etched Symbol: what is "gaining the benefits of a ley line", and which backlash?**
- *Issue:* the requirement is "You are currently gaining the benefits of a ley line". The flavour says "When standing within the current of a ley line"; the effect says "allow the nearby ley line". The book uses "gain the benefits of the ley line" only for the results of Tap or Channel Ley Line (L2014–2036, L3078–3082).
- *Why it matters:* if standing in a ley-line Region were enough, the discount would be permanent wherever a line runs. Tying it to the actions makes it short and earned.
- *Proposed answer:*
  - **The requirement:** a benefit from Tap Ley Line, Channel Ley Line or Leyline Weaver's Tap or Leyline Power, for that result's printed duration, tracked by the N6 marker. Standing in a ley-line area alone does not count.
  - **The backlash** is the Backlash column of the Ley Line Effects table at that line's level, lasting to the end of your next turn. That is Block 2's rule for a backlash with no printed duration (`block2-automations.mjs` header).
  - **The Tap lock-out does not follow from it.** "cannot Tap … again for 24 hours" belongs to the Tap's own Fumble, not to the backlash.

##### Waits on other blocks

- **Ley-Etched Symbol** waits on the core's D2 (S-M1) or D5 cost half, both of which are prepared within Block 6. It does not wait on Blocks 7–10. Until the seam lands it ships as a card.
  - It also needs the Block 2 module marker (N6), which is Block 6 work in a Block 2 file.
- **Nothing here needs Blocks 7–10.** No Grimoire spell, catalyst, item or relic is involved.
- **Prepared Sigil, Runic Reservoir and Living Script** wait only on S-R1 (and S-R3) within Block 6.
- **Combat Inscription** waits only on S-R2. Its interim build is the card text, since the +2 cannot be cancelled without S-R2.

##### Minor

- **Prepared Sigil, "a spell that you are able to cast that day".** Read as any non-innate spell castable today, **cantrips included**. Innate spells have no Symbol to inscribe.
- **"Once before your next daily preparation" with Runic Reservoir.** This is once per sigil; each of the three is spent separately.
- **The early AP pool test** (`cast-workflow.mjs` L1146) charges the unreduced cost before the warp dialog, for Quicken as well. A Quickened 3-AP cast with 2 AP left gets a "Not Enough AP — proceed anyway?" prompt today. S-R1 avoids this for the sigil. The same gap for core Quicken is a core note, not this block's.
- **Combat Inscription under Faultless Casting** (Pillars of Faith). The core already omits the Runemage +2 when defensive casting is *declared* (`cast-workflow.mjs` L2480), so Combat Inscription changes nothing there. Whether a declared defensive casting should carry Runemage's +2 at all is a core and Pillars of Faith matter, flagged only.
- **The Runemage archetype is traited DRUID WIZARD.** EA's own casters (Sorcerer, Archmage, Spellblade, Warlock) cannot take it unless an access registration opens it, so these five feats are Druid and Wizard only as printed. Glyph Shatter, through RUNEBREAKER, is the one way in for others. No change is proposed.
- **Wording:**
  - Ley-Etched Symbol's "Fumble or worse result" reads as Fumble or Blunder.
  - Prepared Sigil's "draw its Symbol normally" assumes the caster is a Runemage, which the trait gate guarantees.
  - Combat Inscription reads "Defensive Casting DC" where the core says "Spell Casting DC … Very Hard (DC +5)". The meaning is the same.
- **The prior matrix** marked all five "Full / A". Prepared Sigil drops to B because the pick has to wait for the day's memorisation (N1). Ley-Etched Symbol drops to B because it is an optional per-cast choice, and it waits on D2/D5.

### Appendix D. Metamagic and Adept

#### Metamagic and Adept class feats; the metamagic seam

Scope: the 13 METAMAGIC class feats, the 7 ADEPT class feats, and the five Block 5 feats deferred to here (Echo of the Ancestors, Resonant Pulse, Resonant Harmony, Spell Surge, Piercing Insight). This section also designs **D2 (`registerMetamagic`)** for the whole block, the half of **D5** that covers cost and discounts, and the parts of **D6** and **D12** that these feats need.

Sources:
- book v1.6 (`book-text.json` `sections.classFeats`, `racialFeats`, `generalFeats`, read against `ea.md`, with sidebar 15 "Spellthread Risks");
- TRG Prime 3.683.0 at `/home/claude/core-3676/trg-prime/module/`;
- module 0.8.0.

**Levels.** A metamagic option is chosen with a tick in the cast's own Warp? dialog. It is rated **B** (interactive), as Block 5 rated Resonant Pulse and Harmony. **A** is kept for passive rules.

##### What TRG Prime has, and what it lacks

**Core metamagic is a hard-coded table.** `buildMetamagicOptions` (`magic/metamagic.mjs:61`) matches lower-cased owned feat names against 21 core feats and the held metamagic rods. It returns `{id, label, ppCost, max, kind, note}`.
- `buildMetamagicChooser` (:314) adds a "Metamagic Feats" section under the spell's warps in the **Warp?** dialog.
- `aggregateMetamagicSelection` (:337) folds the choices into one `mm` object: `{ppSpent, ppDelta, dcDelta, apDelta, componentsOff, extend, temporalSteps, heightenSave, elementalType, extraDamageDice, notes, rodSpends}`.
- Only the `kind`s in its `switch` do anything. Reach, Widen, Selective, Split, Aligned, Distant and Component Mastery are **notes only**.
- There is no registry: nothing in `module-api.mjs` registers metamagic.

**How the cast uses it** (`magic/cast-workflow.mjs`):
- Options are built at :1449–1468. There are none for a cantrip, and none for an innate cast unless the spell is flagged `innateMetamagic` (3.670.0). Innate metamagic PP are then **spent from the free innate warp budget**, not the pool (:1527–1537, :1752).
- The dialog opens only when `!isCantrip && !isItemCast && !stored && (!isInnate || innateBudget > 0)` (:1493). So an **item cast** (scroll, potion, wand, staff) and a stored spell get **no metamagic at all**. The comment at :855–858 gives the reason: "no warp chooser … and no metamagic".
- Metamagic PP join `totalPP` (:1752–1770). That raises the Casting DC (`assembledCastingDC`, :2484, which also takes `metamagicDelta`), counts against the cap (:2065) and is refunded by degree (`castingOutcome`, `magic/casting.mjs:198`).
- The cast-time effects: dice and duration fold into `warpMods` (:1638–1647); AP through `totalCastTime` (:3278); components (:3216); Heighten (:3659); the card line (:3591).
- The rods pay through `mm.rodSpends` → `spendFromRod` (:3343). Their 0 PP adds no DC: "This does not increase the casting DC … or cost you any PP" (R12, `metamagic.mjs:286–293`).
- The hooks (`trgPrimeSpellCast` :3127, `trgPrimeSpellSettled` :5503) and the degree remap ctx carry `castOptions` but **not which metamagic was taken**.

**No core metamagic feat carries the Focus trait** (core feats pack: 25 METAMAGIC feats, none FOCUS). So "a Focus metamagic" has no precedent. The nearest is Dispel's `focus/itemId` (C9): offered only while the item has a use, and spent with the PP after the roll (`combat/action-workflow.mjs:4434–4446`, `itemUsesRemaining`/`usesPoolItem`). A FOCUS feat gets one use by default (`focusDefaultUses`, `uses.mjs:150`).

**Cast options (`registerCastOption`, 3.679.0/3.683.0) are not metamagic.**
- They are offered on the *Casting Conditions* prompt, after the Warp? dialog and **after** the PP and cap tests.
- They are skipped for item, innate and no-check casts: `castOptionOffers = (isItemCast || isInnate || noCheckCantrip || ritualFailed) ? [] : …` (:2224–2227).
- `apply` may answer only `castingDC`, `saveDC`, `ap` and `lines` (`magic/cast-options.mjs:88`). It cannot carry PP, warp mods or riders, and it is not a feat a list can name. Metamagic Conduit, Piercing Insight and Metamagic Resonance all need such a list.

**The warp-mod vocabulary already covers much of what is needed** (`emptyWarpMods`, `magic/spell-warp.mjs:237`):
- `damageDice`, `secondaryDice` (adds to an existing secondary pool only), `healDice`/`healBonus`, `saveDC` (a plain number), `extraTargets` (+N targets, `target-count.mjs:178`), `rangeOverride` (`spell-range.mjs:219`), `durationText`, `areaGrowth`/`areaOverride`, and `shareSelfRows` (`spell-degrees.mjs:338`, `selfRowRecipients`).
- It lacks: a casting-check bias, traits added to a cast, a new typed damage pool, an added target at a damage factor, an added recipient for a self-only spell, ×1.5 range/duration/area, typed Save DC rows, and fumble/Resonance bias.

**Charged items** (`charged-items-workflow.mjs`):
- `castFromChargedItem` (:388) picks the spell. `chooseItemWarp` (:346) offers the spell's own warps only, never metamagic. `rollReleaseCheck` (:205) rolls the release; a fumble rolls `rollSpellFumble` (:283), and the hook `trgPrimeReleaseRolled` (:298) carries `itemName`, not the item.
- The item's PP are written at **:569**, after the check. A listener on the hook that changed `system.uses` would be overwritten there.
- `spendFromRod` (:698) is the rods' path.
- The limit of one wielded charged item is only **reported** (`chargedItemWarnings`, `charged-items.mjs:360`; Graham R21).
- `rollItemDepletion` (`magic-items-workflow.mjs:136`) rolls 1d100 on `ITEM_DEPLETION_TABLE` (`magic-items.mjs:27`). On that table **low is worse** (1–10 explode).

**Fumble and Resonance** (`cast-workflow.mjs`):
- `rollSpellFumble` (:7404) adds every effect's `spellFumbleModifier` flag, **Blunders included**, and has **no bias**.
- `rollResonanceEvent` (:7505) has `disadvantage`, which a High Magic `resonanceContext` sets (:4426–4435). Nothing per-cast or per-feat can set it or lift it.

**Strikes.** Check reactions (C2, `reactions/reactions-workflow.mjs:86`) may answer `modifiers` before an attack's dice. The ctx has `attackMode` but **not the weapon** (the attack config, `combat/attack-workflow.mjs:2638`, carries no weapon id).

**Falling unconscious.** Death guards (`combat/death-guard-workflow.mjs:36` `tryDeathGuards`) are declarations: a save, an offer, an automatic answer, or a spell applied to self. None can run a module's own cast, and the subdual knock-out is not asked ("after subdual", `death-guard.mjs` header).

**Cantrips.** "Cantrips are never bonused" (`memorisation.mjs:181` `memorisationState`). `knownCantripCount` reads the class only (`known-cantrips.mjs:49`).

###### Metamagic class feats (13)

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Arcane Fencer | 3220 | Metamagic Spellblade / Weapon Focus, BAB +2 | Free; trigger: a melee Strike with a one-handed weapon. "burn … PP up to … your caster level"; +1 status to attack per PP | FC-02, B | C2 `before` may add `modifiers`; Weapon Focus exists in the core pack; prerequisites parse BAB and named feats (`prerequisites.mjs:85`, named-feat rejoin) | Check reaction `before` on a melee weapon attack with a one-handed weapon: asks 0…min(CL, pool) PP, answers `{modifiers:[{label, value:n, type:"status"}]}`, spends the PP (hit or miss). Unlimited, 0 AP. Not a spell option: never in Warp? (n1) **B** | **S-M8** | — |
| Focused Spell | 3538 | Adept Metamagic / — | PP +3: "advantage on your spellcraft check" | FC-34, A; D2+D3 | The cast's bias exists (`castContext.bias`, :2826); no option can set it | D2 option +3 PP, `checkBias:"advantage"` (resolved with other biases by `resolveBias`). Offered only when a Spellcraft check is rolled (not innate, no-check or item casts); a spell attack's casting check is its attack, so advantage applies there too (n2) **B** | S-M1 | — |
| Lightning Rod | 3716 | Metamagic Stormcaller / Arcana or Survival 10 ranks, Thunderclap Aura | PP +2: on hitting with an electricity-damage spell, mark the creature; "the next time you cast a spell with the electricity trait before the end of your next turn, all enemies within 10 ft of the marked creature take splash damage equal to half the spell's damage dice"; marked metal wearer/holder "–2 penalty on their initial save" | FC-50, B | `moduleMark` effect rows; `trgPrimeSpellSettled` has `spellHits`, `saveResults`, `warpMods` | D2 option +2 PP on a spell that deals electricity (printed type or Elemental Spell's). `onSettled`: pick one creature it damaged → mark until the end of your next turn. On your next cast with the electricity trait (hook): enemies within 10 ft of the mark take ⌊dice/2⌋ of that spell's dice as electricity; mark ends. −2 per Q?-5 (n3) **B** | S-M1 | Q?-5 |
| Pact Channeler | 3880 | Metamagic Warlock Witch / Level 6, Pact Archetype feat | +1 PP: patron channel: Angelic Healing trait/+2d6 healing; Demonic Fire/+2d6 fire; Draconic and Elemental the chosen type/+2d6 of it; Fey Enchantment/targets −1 Will save; Grave Essence/+2d6 essence; Void Mental/Will save or Flat-Footed to the start of your next turn; L14: +4d6 or −2 | FC-62, B; EA-C2 → C2 ruled (every character has a PP pool), Q52 (the Warlock's Charisma pool; "Block 6's feats will" spend it) | None of trait-add, typed added pool or rider save in the vocabulary. The Warlock's spells are innate Focus copies without `innateMetamagic` (`block4-automations.mjs:133` `warlockCopy`), so they take no metamagic today | D2 option +1 PP, offered when you own a pact archetype (the patron is read from it; Draconic/Elemental read the archetype's chosen type). `apply`: `addTraits`; `healDice` (heals) or `addedDamage` of the type (deals damage); Fey `saveDC` +1/+2 when the defence is Will; Void `onSettled` Will save vs your Spell DC → Flat-Footed AE. On a Warlock's innate cast it reaches through S-M3 and is paid from the Charisma pool (Q?-2) (n4) **B** | S-M1, S-M3 | Q?-2 |
| Sensory Spell | 4032 | Adept Metamagic Shadow / — | +1 PP: cosmetic visual/auditory/olfactory/ambient changes, "no mechanical impact"; "+2 bonus" to a Deception, Intimidate or Perform check "made as part of or immediately after the casting" | FC-74, B | One-shot conditionals; `trgPrimeSpellSettled` | D2 option +1 PP with a free-text "what changes" field put on the card. `onSettled`: a one-shot +2 (untyped) conditional on your next Deception, Intimidate or Perform check, until the end of your turn. The cosmetic part is the table's **B** | S-M1 | — |
| Spellthread | 4110 | Adept Metamagic / BSB +6 | "thread two individual spells into a single weave"; same tradition; "resolve simultaneously, but you choose the order"; same creatures may be affected; "counts as a single spell for concentration and counterspell purposes"; PP = both +2. Sidebar 15: Heroic saves half **base** PP; Critical saves none; Partial→Failure; Failure→Fumble; fumble and Resonance at disadvantage | FC-79, C | `castSpell` takes a supplied check (`strikeCheck`, `itemCheck`); `registerCastDegreeRemap` exists (its ctx lacks metamagic); `castingOutcome` has `waiveCritical`/`waiveSaving` (casting.mjs:198), not "one rung less" | D2 option on the first spell: pick the second (same tradition; a Highmagic spell counts as every tradition, M27). Its base PP joins the **base** and +2 joins metamagic, so the one check is at DC(sum+2) and the cap applies to it. Remap Partial→Failure, Failure→Fumble; `savingStep:1`; fumble/Resonance disadvantage. On Success+ the second spell resolves through `castSpell` option `thread` (same degree, no PP/AP/check/fumble, same targets offered), in the order chosen. A cast reaction that stops the first stops both. One concentration check for both is the GM's (n5) **C** | S-M1, S-M6, **S-M11** | Q?-4 |
| Spellthread Mastery | 4122 | Adept Metamagic / BSB +12, Spellthread | three spells instead of two | FC-80, C | as above | Spellthread's picker allows two more spells **C** | as Spellthread | Q?-4 |
| Spellthread Unbound | 4132 | Adept Metamagic / BSB +12, Spellthread | spells of different traditions | FC-81, C | as above | Spellthread's tradition test lifted **C** | as Spellthread | — |
| Steelbinding | 4142 | Ferromancer Metamagic / Iron Ward | PP +2; "Requirements your spell targets a creature wearing metal armour who is within 30-ft" (**lost from book-text.json**, see Minor); Fort vs Spell DC: Critical none; Success Slowed 1 to end of its next turn; Failure Immobilised to end of your next turn; Blunder Immobilised and drops a held metal weapon of your choice | FC-82, B; EA-m45 (rewrite suggested, not applied in v1.6) | `wearsMetalArmour(items)` (`magic/attack-riders.mjs:71`: equipped armour with the Metal trait); conditions by AE | D2 option +2 PP, offered when one chosen target within 30 ft wears metal armour (test as the core's). `onSettled` (Success+ cast): its Fortitude save vs your Spell DC; rungs per m42 (Heroic→Critical, Partial→Failure, Fumble→Failure). Slowed 1 / Immobilised AEs with their expiries; on a Blunder, pick a held metal weapon → dropped (core drop) **B** | S-M1 | — |
| Subconscious Casting | 4162 | Adept Focus Metamagic / BSB +8 | PP +6; "When you would fall unconscious, you may immediately attempt to cast a prepared spell or known spell with a casting time of 1 AP as a 0 AP action"; Self or Touch range | FC-83, B | `castSpell(..., {apPaid:true})` (module-api-workflow.mjs:554); death guards cannot run a cast | When HP would reach 0 (lethal or subdual, Q?-6), ask the owner (`askReactor`) while the Focus use is ready: list prepared/known 1-AP Self/Touch spells; cast through `castSpell` with `apPaid` and **preset** metamagic "Subconscious Casting" (+6 PP, normal check and costs). Then HP is read again (Q?-6). Focus spent **B** | S-M1, **S-M4**, **S-M5** | Q?-6 |
| Thunderclap Aura | 4196 | Metamagic Stormcaller / Survival 6 ranks | PP +2 on an air- or electricity-trait spell: "all creatures within 10-ft take 1d6 electricity damage per 2 PP of the cast spell (basic Fort)" | FC-86, A | `helpers.runAreaEffect`, `basicSaveHit` | D2 option +2 PP, offered for printed Air/Electricity traits. `onSettled` on Success+: `runAreaEffect` 10 ft around you (caster excluded), ⌊PP/2⌋d6 electricity, basic Fort vs your Spell DC; PP per Q?-7 **B** | S-M1 | Q?-7 |
| Unfettered Mastery | 4218 | Archmage Focus Metamagic Sorcerer / BSB +10 | "cast any High Magic spell as if you were using the Quicken Spell feat (1 AP less to cast)" | FC-88, A; EA-R4 → "R1–R5 leave as printed" (no PP) | Core Quicken: `kind:"quicken"`, one Quicken a cast (metamagic.mjs:380), offered for castAP > 1 | D2 option, 0 PP, `kind:"quicken"` (so it never stacks with Quicken Spell or a Quicken rod), offered when the cast is High Magic (`hmCast.highMagic`) and castAP > 1, Focus spent **B** | S-M1 | — |
| Versatile Binder | 4228 | Adept Metamagic / "Ability to cast at least one spell with the Summons trait" | +1 PP: a Summons spell may "bind a creature that already exists in the world rather than summoning a new one" | FC-89, C | No core spell has a Summons trait (core pack: 0; ea.md: 8 Grimoire spells, all "SAVE SUMMONS …"); control levels (C12); summoning circles' binding (Block 2b cast option) | D2 option +1 PP on a Summons spell: pick an existing creature in range in place of the summoned one; it saves against the spell (Q?-11); on failure, a control-register entry as the summoned creature would have, for the spell's duration. Prerequisite unparsed (passes; the option checks at cast) **C** | S-M1 | Q?-11 |

###### Adept class feats (7)

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Conduit Mastery | 3316 | Adept / Level 16, Dual Channel | wield up to three charged items; "whenever you activate a charged item, you may reduce its charge cost by 1 (minimum 1)" | FC-11, A; D12 | The one-item limit is a warning (charged-items.mjs:360); spends at :569 and `spendFromRod` :698 | D12 rule: `wieldLimit` 3; `cost` −1 (min 1) on every activation (Cast from Item, a rod's activation, a metamagic rod's spend), applied automatically (always to your benefit) (n6) **A** | **S-M7** | — |
| Dual Channel | 3402 | Adept / level 6 | wield two charged items; separate activations; "If you fumble an activation check with one of the items, both items immediately lose 1 additional PP" | FC-20, A | As above; `rollReleaseCheck` fumble (:283) | D12 rule: `wieldLimit` 2; `onRelease` at Fumble or Blunder (Minor): −1 PP on each wielded charged item after the item's own spend (overspend → depletion as the core does) **A** | S-M7 | — |
| Extra Cantrip | 3492 | Adept / Level 4 | learn one more cantrip "from your available spell list (based on your class and magical tradition)"; a memorised caster gains "an additional memorised cantrip"; repeatable, "no more than once every four levels" | FC-29, B; EA-m40 (settled by v1.6) | `chooseSpell`; `cantripsPerDay`/`cantripsKnown` from the class only | Use: `chooseSpell` from the class tradition's cantrips (PP 0, not specialist) → owned (repertoire/known; a memorised caster's book). Declared `cantripBonus: 1` per copy raises the memorised (or known) cantrip allowance. The Use refuses a copy beyond ⌊level/4⌋; the picker does not gate the spacing (Minor) **B** | **S-M9** | — |
| Mana Bound | 3782 | Adept / BSB +4 | Fumble on a Spellcraft check: "−20-circumstance modifier to the Fumble result roll"; "does not affect Blunders or Chaos results" | FC-56, A via the `spellFumbleModifier` flag | The flag is summed for **every** fumble roll, Blunders and tradition-skill releases included (`cast-workflow.mjs:7428–7436`) — the flag alone is wrong | D6 fumble modifier: −20 when `!blunder` and the check is Spellcraft (a cast, a ritual, a Spellcraft release; not a tradition-skill release). Chaos is a Resonance roll, untouched; UM specials key off the face (n7) **A** | **S-M6** | — |
| Metamagic Conduit | 3808 | Adept / "at least any one metamagic feat", BSB +8 | metamagic on spells cast from charged items, "even if … beyond the item's normal charge value … spend your own PP equal to the difference"; total "no more than double the item's normal maximum" | FC-58, B; D2+D12 | `chooseItemWarp` offers spell warps only; an item cast is `innate` and folds `itemCast.warp` (:1432) but never metamagic | D12 rule `metamagic`: Cast from Item's warp step adds the Metamagic section (core and module options). The item pays its normal value, and you pay the excess from your pool (refunded by degree as the item's PP are). The release check and the spell use the modified PP. The choice rides `itemCast.metamagic` into the cast (no second dialog); cap per Q?-8 **B** | S-M7, S-M1, S-M3 | Q?-8 |
| Resonant Conduit | 3948 | Adept / Level 10, Dual Channel | "While wielding two or more charged items, the first activation you make each day does not consume a charge" | FC-66, A | — | D12 rule `cost`: free when ≥ 2 charged items are wielded and the daily stamp is unset; stamped by `onRelease`; cleared at daily preparation (the core sweep) **A** | S-M7 | — |
| Weave Infusion | 4262 | Adept / BSB +6 | "you may spend your own PP instead of expending those of the item"; an item with no charges may be used so, then "roll on the Item Depletion table after the spell has been cast with disadvantage" | FC-92, B | Depletion table: low is worse | D12 rule `payment`: a tick in Cast from Item, "pay from your own PP". Cost by degree (`castingOutcome`), item untouched; at 0 charges allowed, then `rollItemDepletion` with disadvantage (lower of two kept) after the cast **B** | S-M7 | Q?-9 |

###### The five deferred from Block 5

All five already ship as cards: Echo `block5-b.mjs:46`; Pulse and Harmony `block5-a.mjs:91–96`; Spell Surge `block1.mjs:383`; Piercing Insight `block5-d.mjs:245`.

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Echo of the Ancestors | 2292 | Elemental Emberkin Focus Metamagic / — | "PP Cost +2" (in the text, not a field); a spell with "an elemental damage type matching your heritage" may be duplicated "at half damage targeting a second creature within range" | FR-17, B; **Q75 ruled**: one casting, one check, +2 PP; the second creature saves (or is compared with the same attack roll) for half damage rounded down and takes the other effects; one Focus use; heritage element only | `extraTargets` adds a target at full effect; nothing halves one target | D2 option +2 PP, Focus. Offered when the cast's effective damage type (printed or Elemental Spell's) is the heritage's `eaElement` (Stonevein acid, Galeborne electricity, Cinderblood fire, Tidemarked cold; `block5b-automations.mjs:60`). Pick one creature in range not already affected → `targets.extra [{damageFactor:0.5}]`. Card replaced. Innate per Q?-1/Q?-2 **B** | S-M1 | Q?-1, Q?-2 |
| Resonant Harmony | 2560 | Aetherial Focus Metamagic / Level 5, Resonant Pulse | a spell "that targets yourself" may also target "one adjacent ally with the same effect (if valid)" | FR-44, B; **Q66 ruled** (D2, Focus, no PP); Block 5 S-8 folded into D2 | `shareSelfRows` + `selfRowRecipients` share self rows with the cast's *reached* list, which is empty for a self-only spell | D2 option, 0 PP, Focus, offered for a self-only spell: pick an adjacent ally → `targets.share`. The core adds it to the self rows' recipients. Rows that cannot be shared (form, movement or teleport rows, notes) are said on the card **B** | S-M1 (`targets.share` = S-8) | Q?-1 |
| Resonant Pulse | 2570 | Aetherial Focus Metamagic / — | "When you cast a spell, you may increase its Spell Save DC by +1" | FR-45, B; **Q66 ruled** | `saveDC` mod (a number) | D2 option, 0 PP, Focus, offered when the spell has a save: `saveDC [{value:1, type:"untyped"}]`. Innate yes; item casts per Q?-1 **B** | S-M1 | Q?-1 |
| Spell Surge | 4620 | — / High Magic Caster | +1 PP surge, one of four options "(which has the focus trait)": range +50%, duration +50%, "+2-class bonus" to Save DC, "+1 die of damage"; that cast's Spell Fumble or Resonance "at disadvantage" | FG-35, B; EA-M20 ruled as proposed (High Magic caster = class or archetype High Magic; d100 disadvantage = higher kept) | `highMagicCaster` flag (D1); Resonance `disadvantage`; fumble has no bias | D2 option +1 PP, a select of the four (range/duration only when numeric and parseable: `rangeFactor`/`durationFactor` 1.5; `saveDC [{value:2, type:"class"}]`; one die of the spell's first damage term → `damageDice`), `fumbleBias`+`resonanceBias` "disadvantage", Focus (n8) **B** | S-M1, S-M6 | Q?-10 |
| Piercing Insight | 4546 | — / Power Manipulation 1 rank | "apply any metamagic feats that you have when using either of the Sense Magic (Power Manipulation) actions. You must expend PP normally but need to make no additional check" | FG-26, C; EA-m57 settled by v1.6 (`senseMagicBroad`/`Focused`, `sense-power.mjs:82`) | Sense Magic is a GM-adjudicated detection; core metamagic is cast-only | A "Metamagic" step on both Sense Magic actions (skill-action hook): lists your owned metamagic through `helpers.metamagicCatalogue` (S-M1), core and module, minus options that need a spell (Arcane Fencer, Spellthread, Subconscious, Echo, Harmony), spends their PP, and puts on the card what each changes (Reach: range ×2, Widen: area ×2, Extend: duration ×2…). The GM applies the effect **C** | S-M1 (catalogue) | — |

**Notes**
1. **Arcane Fencer.**
   - "One-handed": a melee weapon without Two-Handed, not wielded two-handed. The core's two-hand test is `twoHandedStrengthApplies` (`held-items.mjs:94`), so a Hand & a Half weapon held in two hands does not qualify.
   - The PP are burned before the roll, so they are spent hit or miss.
   - It is a METAMAGIC feat that modifies a Strike. It is therefore never offered in the Warp? dialog. It still counts as "a metamagic feat" for Metamagic Conduit's (unparsed) prerequisite, and Piercing Insight's list leaves it out.
   - Weapon Focus and BAB +2 are both parsed and enforced.
2. **Focused Spell.**
   - On an innate cast there is no Spellcraft check, so the option is not offered. The innate attack is the only roll there (Minor).
   - Block 9's Rods of Focused Spell (`ea.md` L9471: "expend 2 PP from the rod … does not increase the casting DC … or cost you any PP") need the rod's `chargedItem.metamagic.kind` to name this registered option (S-M1, rods).
3. **Lightning Rod.**
   - "Hit": a creature the spell damaged, whether by a spell attack that hit (`spellHits`) or by a save spell where it took damage (`saveResults`).
   - One mark at a time. A new mark replaces the old.
   - The triggering cast may be any spell with the Electricity **trait**. If it deals no damage, there is no splash.
   - The splash is half the dice count, rounded down (6d6 → 3d6), of that spell's primary pool. It is electricity damage with no save (Q?-5).
   - The marked creature is not splashed by its own mark.
4. **Pact Channeler.**
   - "Gains the X trait" is added to the cast's traits for the rest of that cast, so trait-scoped rules see it: conditionals, saves' trait context, the hooks (`addTraits`).
   - The +2d6 rules:
     - "If it already heals" adds `healDice`.
     - "Already deals that damage type" adds the dice to the pool of that type: `damageDice` if it is the primary pool, `secondaryDice` if the secondary.
     - Demonic and Grave say "If it already deals damage", which adds a **new typed pool** (`addedDamage [{dice, type}]`), saved and halved with the primary.
   - At level 14 the dice become 4d6 and Fey's penalty −2. Void has no number, so it is unchanged.
   - The Warlock's path needs the Charisma pool (Q52), which another reviewer's part of Block 6 builds.
5. **Spellthread.**
   - The PP savings come from sidebar 15's "half the base PP" and "do not save any PP". With `savingStep: 1`, a Heroic is paid as `castingOutcome`'s Critical and a Critical as its Success.
   - "Both spells resolve simultaneously, but you choose the order": the module asks for the order and resolves the second spell straight after the first.
   - "Counts as a single spell … for counterspell": a cast reaction or counter against the first stops the weave. Nothing is cast twice for concentration, but one concentration check for both sustained spells is the GM's, said on the card. That part is why it is rated C.
6. **Charged-item "activation".** These are Cast from Item (the release) and a rod's own printed activation, metamagic rods included. Drawing your own spell's PP from a PP-source rod (Rod of the Magi) is not an activation (Minor).
7. **Mana Bound.** "A Fumble on a Spellcraft check" — on a ritual the primary's Spellcraft check counts. The release check counts on its Spellcraft path only: `rollReleaseCheck`'s option has `skill: ""` for Spellcraft.
8. **Spell Surge.**
   - The item built in 0.1.0 carries no traits, so `focusDefaultUses` gives it no use.
   - Block 6 rebuilds it with traits "Focus", matching "which has the focus trait". A ready-time migration adds the trait to owned copies; this is a data change only.
   - The +2 is a **class** bonus to the Save DC, so it does not stack with another class bonus to it. Hence the typed `saveDC` rows.

##### Proposed core seams

Numbered S-M1… for the lead to renumber.
- S-M1 to S-M5 are D2 and its edges.
- S-M6 is the D6 part.
- S-M7 is the D12 part.
- S-M8 to S-M11 are small.
- D5's cost half follows, then the other Block 6 feats the seams must serve.

**S-M1 `registerMetamagic(key, spec, moduleId)` — module metamagic (D2).**
- *What an entry declares:*
  ```
  spec = {
    feat: "Resonant Pulse" | [names],  // the owned feat(s) that open it; omitted → only through grants (below)
    label, hint,
    ppCost: n | (ctx) => n,            // per application, default 0
    max: 1,                            // >1 → the number box, as Selective/Split
    choices: [{value, label, ppCost?}] | (ctx) => [...],   // a select, as Imposing Will (Spell Surge's four)
    focus: true,                       // spends one Focus use of the opening feat item (below)
    kind: "quicken" | null,            // a core kind it IS, so the core's one-Quicken rule holds (Unfettered Mastery)
    castingDC: true,                   // false: its PP neither raise the Casting DC nor count against the cap (rod-like)
    scope: { innate: false, cantrip: false, item: "conduit" },   // defaults; see "where it appears"
    preset: false,                     // true: never offered; applied only when named by castSpell (S-M4)
    payment: "pp",                     // or { ap: n, dcAsIfPP: true } or { resource: { label, offer(ctx), pay(ctx) } }
    applies(ctx) → boolean,            // offer it for this cast?
    apply(ctx) → result | { cancel: true },   // awaited once it is taken, before the cost is tested; may ask (a token picker)
    onSettled(ctx) → { lines }         // awaited after the cast settles, only if taken
  }
  ```
- *The ctx for `applies` and `apply`:* `{ actor, item, spell, spellData, basePP, casterLevel, tradition, traits, damageTypes, defence, range, duration, area, castAP, attack, rollsCheck, innate, itemCast, chargedItem, cantrip, ritual, reaction, highMagic, times, choice, taken }`.
  - `item` is the opening feat.
  - `damageTypes` are *effective*, after Elemental Spell.
  - `taken` is the other keys chosen, in `apply` only.
- *What `apply` may answer.* Each answer folds into the same `mm` aggregate and `warpMods` the core options fold into, at `cast-workflow.mjs:1515` and `:1638`.
  - Already in the vocabulary: `mods: {damageDice, secondaryDice, healDice, healBonus, extraTargets, areaGrowth, durationText, rangeOverride, shareSelfRows, …}`.
  - The aggregate's own fields: `dcDelta`, `apDelta`, `ppDelta` and `minPP` (a discount; minimum 0 or 1, for Spell Weaver), and `note` and `lines`.
  - **New keys:**
    - `checkBias: "advantage" | "disadvantage"` — joins `castContext.bias` through `resolveBias` (:2826). Focused Spell.
    - `addTraits: [..]` — added to the cast's traits for that cast: the check's `castContext.traits`, saves, hooks. Pact Channeler.
    - `addedDamage: [{dice, type}]` — a new typed pool rolled with the primary, saved and halved with it, critical dice excluded. Pact Channeler's Demonic and Grave.
    - `saveDC: [{value, type, label}]` — typed rows. Untyped ones add; typed ones keep the highest per type (the system's stacking), plus the existing number. Pulse, Surge, Fey, Sanguine Channel.
    - `targets: { extra: [{tokenUuid, damageFactor, label}], share: [{tokenUuid}] }`.
      - `extra`: an added recipient that saves on its own, or is compared with the same attack roll, and takes ⌊damage × factor⌋ and the other effects. Echo.
      - `share`: added to the recipients of the cast's self rows (`selfRowRecipients`). This is Block 5's S-8. Resonant Harmony.
    - `rangeFactor`, `durationFactor`, `areaFactor` — applied by the core to a parseable printed value, with the result written into the existing `rangeOverride`, `durationText` and `areaGrowth`. Spell Surge; Spell Weaver.
    - `fumbleBias`, `resonanceBias: "disadvantage"` — carried into `rollSpellFumble` (S-M6) and `resonanceContext.disadvantage`. Spell Surge, Spellthread.
    - `savingStep: 1` — `castingOutcome` (casting.mjs:198) pays a Heroic as a Critical and a Critical as a Success. Spellthread.
    - `basePPAdd: n` — PP counted as **base** rather than as metamagic, so a Critical's "half base" reads it. Spellthread's second spell.
- *Focus.*
  - Offered only while the opening item has a use (`itemUsesRemaining`).
  - Spent when the cast pays its PP, after the check, from the uses pool (`usesPoolItem`), as Dispel's C9 does (`combat/action-workflow.mjs:4437`).
  - It is not spent on a cast refunded or abandoned before the check. Whether a Partial spends it is Q?-3.
- *Where it appears:*
  1. **A learned cast:** the Warp? dialog's Metamagic section, after the core options, each labelled with its feat (`buildMetamagicChooser`, :314). This covers reaction casts, ritual casts and Strike-carried casts wherever the core's own metamagic appears today.
  2. **An innate cast** (`scope.innate`): offered whether or not the spell is flagged `innateMetamagic`. The dialog's gate (:1493) opens when any module option is offered, even with no free budget. It is paid per Q?-2 (proposed: from the PP pool, no Casting DC as no check is rolled). This is the "known gap" that `registerCastOption` (:2224) has.
  3. **A charged-item cast:** only through Metamagic Conduit's D12 rule (S-M7), in `chooseItemWarp` (:346). It rides `itemCast.metamagic` as `itemCast.warp` already does (:1432), and is folded without a second dialog.
  4. **Never** on a scroll, potion or released stored spell (Ch11: "You cannot warp a spell cast from a scroll"; stored warps were paid at storage). Never on a cantrip unless `scope.cantrip`, which matches the core (Q?-1).
  5. **Granted:**
     - An applied effect may declare `flags.trg-prime.grantedMetamagic: [{key | coreId, label, source}]`. The option is offered as if its feat were owned, at its normal cost. This serves Metamagic Resonance (Grimoire L7168, "All willing allies … may apply the chosen feat … increases the PP cost … as normal") and the Wild Magic rows "All spells gain the X metamagic feat" (L5698–5712).
     - A held rod's `chargedItem.metamagic.kind` may name a registered key, so that `metamagicRodsOf` (`rod-powers.mjs:66`) offers it rod-paid: 0 PP, no DC, `rodSpends`. This serves Block 9's Rods of Focused Spell.
- *How it stacks with core metamagic.* It is one section and one aggregate.
  - PP add to `totalPP`, so the DC, the cap and the refund by degree are as the core's options. `castingDC:false` options (rod-paid) are excluded from DC and cap.
  - `kind:"quicken"` gives one Quicken across the feat, a rod and Unfettered Mastery.
  - Dice add.
  - Duration changes do not stack: the longest applies. This matches Temporal Extension's printed "doesn't stack with other duration modifiers", and replaces today's first-`durationText`-wins (:1642–1646).
  - An option's `applies` sees the **printed** spell plus Elemental Spell's type. Traits that another option adds in the same dialog do not open an option (Pact Channeler's air trait does not open Thunderclap Aura).
- *Reported:* `trgPrimeSpellCast`, `trgPrimeSpellSettled` and the `registerCastDegreeRemap`/`registerCastRefusal` ctx carry `metamagic: [{key, times, choice}]`, core ids included ("quicken", "empower"…), and `metamagicPP`.
- *Helper:* `helpers.metamagicCatalogue(actor, {spell?})` returns every owned or granted option, core and module, as `{key, label, ppCost, focus, needsSpell}`. Piercing Insight uses it, and so does Metamagic Resonance's "choose one metamagic feat you possess".
- *Where:* `magic/metamagic.mjs` (`buildMetamagicOptions`, `aggregateMetamagicSelection` take the registered entries beside the table), `magic/cast-workflow.mjs:1449–1520`, `:1638–1647`, `:1752–1770`, `:2484`, `:2826`, `:3127`, `:3591`, `:5503`, `magic/casting.mjs:198`, `rod-powers.mjs:66`, `module-api.mjs` (registry), `module-api-workflow.mjs` (helper).
- *Used by:*
  - Focused Spell, Lightning Rod, Pact Channeler, Sensory Spell, Spellthread ×3, Steelbinding, Subconscious Casting, Thunderclap Aura, Unfettered Mastery, Versatile Binder;
  - Metamagic Conduit (through S-M7), Echo, Resonant Pulse, Resonant Harmony, Spell Surge, Piercing Insight (catalogue);
  - the other Block 6 feats in the table below, plus Metamagic Resonance (Block 7–8) and the Rods of Focused Spell (Block 9).

**S-M2 metamagic payment on core options (part of D2).** `registerMetamagicPayment(key, { applies(ctx), options: ["extend","reach","silent","still"], ap: 1, dcAsIfPP: true, max: 1 })`.
- It is a second way to pay for a named option (core or module). The option's PP move to `apDelta` and are **not spent**, while the Casting DC still counts them.
- Metamagic Adept: "the DC to cast the spell is still increased … (as if the additional PP had been expended)", for casts of 1–2 AP, one option a spell.
- Shown as a choice on the option's row. *Where:* `aggregateMetamagicSelection`; `assembledCastingDC` takes the phantom PP.
- *Used by:* Metamagic Adept (another reviewer). None of mine.

**S-M3 innate and item reach (part of D2 and D12).**
- The dialog gate (:1493) opens for any offered module option.
- Innate payment follows Q?-2 (proposed: the PP pool; no budget; no DC).
- An item cast carries `itemCast.metamagic`, and the cast folds it like `itemCast.warp` (:1432).
- *Used by:* Echo, Pulse, Harmony, Pact Channeler (the Warlock is all-innate), Metamagic Conduit.

**S-M4 preset metamagic on `castSpell`.**
- `castSpell(actor, spell, { apPaid: true, metamagic: { preset: [{key, choice}] } })` applies those options without a tick, and the dialog still offers the rest.
- A `preset:true` entry is never offered otherwise.
- *Where:* `castSpellResolved`'s options (`cast-workflow.mjs:564`).
- *Used by:* Subconscious Casting, and Spellthread's second spell (with S-M11).

**S-M5 "you would fall unconscious".**
- `registerUnconsciousOffer(key, async ctx => ({ lines }) | null)` is awaited with `{ actor, damageTypes, subdual, hpBefore }`:
  - in `tryDeathGuards` (`combat/death-guard-workflow.mjs:36`) before the declared guards;
  - and on the subdual knock-out, which guards are not asked today.
- HP is read again after the offers. Above 0, the creature neither falls nor gains Dying.
- *Used by:* Subconscious Casting (Q?-6).

**S-M6 fumble and Resonance modifiers (D6, the half these feats need).**
- `registerFumbleModifier(key, ctx => ({ modifier, bias, label }) | null)` with ctx `{ actor, blunder, pp, tradition, highMagic, check: {type: "spellcraft"|"skill", skill}, ritual, release, metamagic, castOptions }`. `rollSpellFumble` (:7404) gets a `bias`: disadvantage keeps the higher first percentile, and the open-ended continuation is rolled once, as Resonance does (EA-M20). Its callers pass the check's kind:
  - the cast, :5404;
  - concentration, :7721;
  - the release, `charged-items-workflow.mjs:283`, with `option.skill`.
- `registerResonanceModifier(key, ctx => ({ bias, single, modifier, force, label }) | null)` with ctx `{ actor, reason, highMagic, metamagic, castOptions }`.
  - `single: true` cancels High Magic's disadvantage. That is High Magic Resonance's "only roll on the resonance table once".
  - `force` is used by Resonance Surge, and is asked after the spell.
  - Read in `rollResonanceEvent` (:7505).
- An option's `fumbleBias`/`resonanceBias` (S-M1) rides the same channel.
- The flat `spellFumbleModifier` flag stays as it is (Urloch).
- *Used by:* Mana Bound, Spell Surge, Spellthread; also High Magic Resonance, Resonance Surge and the Wild Mage's 13 (other reviewers).

**S-M7 `registerChargedItemRule(key, spec)` (D12, the feat half; the Orb kind stays Block 9).** All the item's PP changes go through **one spend path**, `chargedItemSpend(actor, item, pp, {reason})`. It is used by `castFromChargedItem` (:569) and `spendFromRod` (:698, which already carries the metamagic rods' `rodSpends`, `cast-workflow.mjs:3343`). It asks each rule:
  - `wieldLimit(ctx {actor})` → n. The highest answer is read by `chargedItemWarnings` and the sheet warning. Dual Channel 2, Conduit Mastery 3.
  - `cost(ctx {actor, item, pp, kind, reason, wielded})` → `{ reduction, minimum, free, label }`. Conduit Mastery −1 (min 1); Resonant Conduit free.
  - `payment(ctx)` → `{ ownPP: true, allowEmpty: true, depletionBias: "disadvantage", label }`. It is offered as a tick on Cast from Item. The wielder's PP are charged by degree, and depletion is rolled after the cast. `rollItemDepletion` gets a `bias` ("disadvantage" keeps the **lower** roll, since low is worse on that table; Q?-9). Weave Infusion.
  - `metamagic(ctx)` → `{ allowed: true, ceiling, label }`. `chooseItemWarp` (:346) adds the S-M1 section. The item pays its normal value, and the wielder pays the excess from the pool. Metamagic Conduit.
  - `onRelease(ctx {actor, item, degree, ppSpent, wielded})` → `{ lines }`, awaited **after** the spend at :569. Today a hook listener's change would be overwritten there. Dual Channel's fumble; Resonant Conduit's daily stamp.
  - `trgPrimeReleaseRolled` (:298) also gains `itemUuid`.
- *Used by:* Conduit Mastery, Dual Channel, Metamagic Conduit, Resonant Conduit, Weave Infusion; later the Orb kind and Tap Magical Energy (Block 9).

**S-M8 the weapon on an attack check's reaction ctx.**
- `checkReactionsBefore`'s ctx (`reactions/reactions-workflow.mjs:107–116`) adds `weaponUuid` and `twoHanded` (the grip actually used). They are set on the attack config (`combat/attack-workflow.mjs:2638`).
- *Used by:* Arcane Fencer. Also useful for any "with a one-handed weapon" rule.

**S-M9 declared bonus cantrips.**
- `flags.trg-prime.cantripBonus: n` on feats, summed:
  - for a memorised caster, it adds to the cantrip allowance in `memorisationState` (`magic/memorisation.mjs:181`; today "Cantrips are never bonused");
  - for a known-cantrip class, to `knownCantripCount` (`known-cantrips.mjs:49`).
- *Used by:* Extra Cantrip.

**S-M10** — folded into S-M1 (grants and catalogue).

**S-M11 a threaded cast.**
- `castSpell(actor, spell, { thread: { check, degree, primaryUuid } })` resolves a spell under a check already rolled, at that degree. It spends no PP or AP, rolls no fumble, Resonance or cast reaction of its own, and offers the primary's targets.
- *Where:* `castSpellResolved` (:564), beside `itemCheck`/`strikeCheck`.
- *Used by:* Spellthread, Mastery and Unbound.

**D5, the cost and discount half (for the other reviewers' feats; none of mine needs it for spell PP).**
- `registerCastCostModifier(key, ctx => ({ ppDelta, minPP, freeWarpPP, warpDiscount, label, lines }) | null)` is passive. It is asked after the Warp? dialog and before the cap, the pool test and the DC (`cast-workflow.mjs:1767`).
  - `freeWarpPP` goes through the existing `applyFreeWarp` (`spell-warp.mjs:967`) without needing a trait.
  - Optional discounts that are chosen as the cast is made — Spell Weaver's charge, Resonance Surge's tick, Ley-Etched Symbol's once a round — are S-M1 entries with `ppDelta`/`freeWarp`, so that they appear in the Warp? dialog.
- **Not a seam:** Arcane Study's and Soul-Bound Grimoire's "lower all warping costs (min 1 PP) for that spell by 1" is exactly the existing spell flag `flags.trg-prime.warpDiscount` (`cast-workflow.mjs:1603`, minimum 1, warps only). The module sets it on the day's spell and clears it at daily preparation.

**Other Block 6 feats these seams must serve** (so the other reviewers' builds fit):

| Feat (owner) | Needs | Seam |
|---|---|---|
| Bloodmage (archetype) | Bleed in place of PP, "cannot reduce a spell's cost below 1 PP", the cap counts the Bleed; extra Bleed on Fumble (+1 per 2 PP) and Blunder (+1 per PP) | S-M1 `payment.resource` (offer, pay); `onSettled` degree |
| Sanguine Channel | +1 Bleed → +1 to the spell's attack or to the Save DC for one target only | S-M1 `checkBias`-like `attack` row; `saveDC` scoped to one `tokenUuid` (an extension of the typed rows) |
| Spell Weaver, Extra Reservoir, Deep Weave, Overflow Casting, Wellspring Conduit | A charge: −2 PP (min 0), dice one step up, or +50% duration, range or area; spending charges you lack costs 2d6 each (ignores resistances), and 5 Soul Drain at 0 HP; regain a charge on a critical | S-M1 `payment.resource`, `ppDelta`/`minPP:0`, `rangeFactor`/`durationFactor`/`areaFactor`, a `dieStep` mod; `onSettled` |
| Metamagic Adept | Extend/Reach/Silent/Still paid in AP, the DC as if paid in PP; 1–2 AP casts | S-M2 |
| Metamagic Conduit (mine) | metamagic on item casts | S-M7 + S-M1 + S-M3 |
| Hex Mastery | hex PP −1 (min 1) | D5 cost modifier |
| Ley-Etched Symbol | −1 PP once a round (min 1) with a Symbol component | S-M1 option with `ppDelta`, or D5 |
| Arcane Study, Soul-Bound Grimoire | warp −1 (min 1) on the day's spell | existing `warpDiscount` flag |
| Resonance Surge | Focus: a 2 PP warp with no PP and no DC; forced Resonance after the spell | S-M1 option `freeWarpPP: 2`; S-M6 `force` |
| High Magic Resonance | one Resonance roll for High Magic; the first fumble each day becomes a failure | S-M6 `single`; existing `registerCastDegreeRemap` (D7) — the release check is not remapped today (Minor) |
| Raw Power | +1 over the cap when warping High Magic | existing `registerCastCapModifier` |
| Spell Trickery | Casting DC +2 | existing `registerCastOption` (unchanged) |
| Metamagic Resonance (Grimoire, Blocks 7–8) | allies apply your chosen metamagic | S-M1 `grantedMetamagic`, catalogue |
| Rods of Focused Spell I–III (Block 9) | rod-paid Focused Spell | S-M1 rods |

##### Questions

**Q?-1 — Which casts take module metamagic?** (Echo, Pulse, Harmony, and every D2 option.)
- The core gives metamagic to learned casts only. A marked innate spell (Mystic) also gets it. Item casts, stored spells and cantrips get none ("no warp chooser … and no metamagic", `cast-workflow.mjs:855`).
- Block 5's cards say Pulse "reaches innate and item casts too" (Q66).
- **Why it matters:** it decides whether a racial metamagic works on heritage innate spells and wands, and whether Metamagic Conduit means anything (it exists "to apply metamagic feats to spells cast from charged items").
- **Proposed:**
  - **innate casts: yes**, for every D2 option that declares it (all of Eldritch Arts' options except Focused Spell, which needs a Spellcraft check);
  - **charged items: only through Metamagic Conduit**;
  - **scrolls, potions and stored spells: never**;
  - **cantrips: no**, as the core.
  - The two Block 5 cards are corrected to say so.

**Q?-2 — Who pays a metamagic's PP on an innate cast?** (Echo +2, Pact Channeler +1, Spell Surge +1.)
- The core spends a marked innate spell's metamagic from its *free* innate warp budget (3.670.0).
- Q52 says the Warlock's Charisma pool exists for "Block 6's feats".
- **Why it matters:** from the budget, Pact Channeler and Echo are free on every innate spell, and the Warlock's pool is never spent.
- **Proposed:** a module option on an innate cast is paid **from the PP pool** (the Warlock's Charisma pool). No Casting DC is raised, because no check is rolled. A Focus-only option (0 PP) costs only its use.

**Q?-3 — When is a Focus metamagic's use spent?** (Echo, Pulse, Harmony, Subconscious, Unfettered, Spell Surge.)
- The book never says. A Partial spends no PP ("the spell does not go off").
- **Proposed:** spent exactly when the cast pays its PP: Success or better, Failure, Fumble, Blunder. Not on a Partial, and not on a refunded or abandoned cast. On an innate cast with no check it is spent when the spell is cast.

**Q?-4 — Spellthread's action, cap and costs.**
- "The total PP cost of the spell is the total of both spells +2", and "counts as a single spell for concentration and counterspell purposes". It prints no casting time.
- **Why it matters:** the AP it takes, and whether a level 5 caster (cap 6) can thread two 3 PP spells (8 PP) at all.
- **Proposed:**
  - one casting, taking the **longer** of the woven spells' casting times;
  - one check at DC(total);
  - the total counts against the per-cast cap (overcast by Sacrifice as normal);
  - the sidebar's "base PP" is the woven spells' base PP together;
  - other metamagic (and warps) may be applied to each woven spell and are added to the total;
  - Mastery's third spell is the same.

**Q?-5 — Lightning Rod's "hit", splash and "initial save".**
- Printed: "When you hit a creature with a spell that deals electricity damage … all enemies within 10 ft of the marked creature take splash damage equal to half the spell's damage dice. If the marked creature is wearing or holding metal, they take a –2 penalty on their initial save."
- **Why it matters:** whom the −2 applies to, and whether the splash is saved.
- **Proposed:**
  - "hit" means it took electricity damage from the spell, by attack or by save;
  - the splash is half the triggering spell's dice count, rounded down, as electricity, with **no save**;
  - the −2 is the **marked creature's** save against the **triggering** electricity spell, when that spell asks it for one;
  - "holding metal" is a tick for the GM, as the core tests only armour.

**Q?-6 — Subconscious Casting's trigger and result.**
- "When you would fall unconscious, you may immediately attempt to cast …". Self or Touch range.
- **Why it matters:** whether subdual knock-outs and sleep effects trigger it, and whether a self-heal keeps you conscious.
- **Proposed:**
  - it triggers when damage (lethal or subdual) would reduce you to 0 HP, not on sleep or other conditions;
  - the cast is a normal attempt (check, PP + 6, its Focus use);
  - if the spell leaves you above 0 HP you do not fall unconscious or gain Dying; otherwise you fall as normal.

**Q?-7 — Thunderclap Aura's damage and who it hits.**
- "All creatures within 10-ft take 1d6 electricity damage per 2 PP of the cast spell."
- **Proposed:**
  - the **total PP the cast cost** (base + warps + metamagic, this feat's +2 included), rounded down per 2;
  - centred on you, you excluded, allies included ("all creatures");
  - only when the cast succeeds.

**Q?-8 — Metamagic Conduit's ceiling.**
- "You cannot increase the total modified PP cost to more than double the item's normal maximum."
- **Why it matters:** "maximum" can be read as the item's PP capacity or as the spell's normal charge value. A wand's capacity is often far above its spell's cost.
- **Proposed:**
  - **double the PP the item normally releases that spell at** (its charge value, or a staff's warp ceiling);
  - the release check is rolled at the modified PP;
  - the wielder's share is refunded by degree, as the item's is.

**Q?-9 — Weave Infusion's payment and its "disadvantage".**
- "Spend your own PP instead of … the item"; on an empty item, "roll on the Item Depletion table after the spell has been cast with disadvantage".
- **Why it matters:** on that table low results are worse (1–10 explode), the opposite of the fumble and Resonance tables.
- **Proposed:**
  - your PP are charged by the degree, as a cast's are;
  - the item is untouched;
  - disadvantage on the depletion roll keeps the **lower** of two d100.

**Q?-10 — Spell Surge's Focus.**
- "Choose one of the following effects (which has the focus trait)" (flagged in Block 5's Minor).
- **Proposed:** one surge a cast, with one effect chosen. The feat has **one Focus use**, so it is one surge until Refocus, not one use per effect.

**Q?-11 — Versatile Binder: what does the existing creature resist with?** (For Blocks 7–8, but it decides the option's shape.)
- "You may instead attempt to bind a creature that already exists in the world." The Summons spells all print SAVE.
- **Proposed:**
  - the chosen creature (within the spell's range, of a kind the spell could summon, of no higher level than the spell allows) makes the spell's own save against your Spell DC;
  - on a failure it is bound exactly as the summoned creature would be, for the spell's duration, with the usual control rules;
  - on a success the spell is spent with no effect.

##### Waits on other blocks

- **Versatile Binder:** the Summons spells (Grimoire, Blocks 7–8). The item and option can ship now, but they are offered on nothing until then.
- **Pact Channeler, the Warlock's path:** the Charisma PP pool (C2/Q52, Block 6's Warlock work). The pact archetypes and their chosen types (Draconic, Elemental) come from Block 6's archetype work. The Witch path can ship with them.
- **Steelbinding:** Iron Ward (Ferromancer, Block 6). **Lightning Rod and Thunderclap Aura:** the Stormcaller archetype (Block 6). Same block; their prerequisites resolve once those items exist.
- **Focused Spell from a rod; the Orb kind for every Adept charged-item feat:** Block 9. The feats work now on the core's wands, staffs and rods.
- **Metamagic Resonance (Grimoire):** reads S-M1's grants and catalogue (Blocks 7–8).
- Everything in this section waits on **S-M1 (D2)**. The charged-item feats wait on **S-M7**, Mana Bound on **S-M6**, Subconscious on **S-M4/S-M5**, Arcane Fencer on **S-M8**, Extra Cantrip on **S-M9**, and Spellthread on **S-M11**.

##### Minor

- **Steelbinding's requirement is lost in `book-text.json`.**
  - `ea.md` L4150 prints `**PP Cost** +2**; Requirements** your spell targets a creature wearing metal armour who is within 30-ft.` The extractor read only "+2", so the card would omit the requirement.
  - The bold error is EA-m45; Graham's suggested rewrite is not applied in v1.6.
  - Build the card's fields from ea.md, or fix `extract-book.mjs` for a bold run that ends mid-field.
- **Echo of the Ancestors** prints `**PP Cost +2**` as one bold run, so it is in `lines`, not `fields`. Same for the card.
- **Pact Channeler** repeats its flavour as the first text sentence. Grave's "essence damage.." (EA-m48) is still in v1.6.
- **Focused Spell's** flavour line is extracted as text (no italic). It also has no effect on an innate attack, which rolls no Spellcraft check.
- **Unfettered Mastery:** EA-R4 ruled "leave as printed", so it is free. The core's Quicken Spell has the Flourish trait and this feat does not; read as not Flourish.
- **Mana Bound:** "Chaos results" are Resonance rolls, which the modifier never touches. The −20 is "circumstance", so it does not stack with another circumstance modifier on that roll (none exists today).
- **Dual Channel:** "fumble an activation check" is read as Fumble or Blunder.
- **Echo of the Ancestors:** the second creature must not already be affected by the spell. For an area spell it is a creature outside the area, within range.
- **Charged-item activation:** drawing your own spell's PP from a PP-source rod (Rod of the Magi) is not an "activation" for Conduit Mastery or Resonant Conduit.
- **High Magic Resonance's** "first spell fumble … as a spell fail": today `registerCastDegreeRemap` is asked for casts only, not for a release check's fumble.
- **Extra Cantrip:** "no more than once every four levels" has no picker gate. The Use refuses a copy beyond ⌊level/4⌋ and says why.
- **Prerequisites the core cannot read, which pass open:** "Pact Archetype feat", "at least any one metamagic feat", "Ability to cast at least one spell with the Summons trait", "Arcana or Survival 10 ranks". Each option tests what it needs at cast time.
- **Sensory Spell** carries the SHADOW trait, which only matters for feat qualification (ADEPT already admits it). Its four sensory choices are cosmetic and go on the card.
- **Spellthread Mastery and Unbound** no longer share a flavour line in v1.6, so EA-m44 is settled by the book.
- **Arcane Fencer:** "burn" is read as spend. The bonus is status, so it does not stack with another status bonus to attack (Bless and similar).

### Appendix E. Warlock and Witch

#### Warlock and Witch class feats

21 class feats with the WARLOCK or WITCH trait (book v1.6, `book-text.json` `sections.classFeats`). Read against TRG Prime 3.683.0 (`/home/claude/core-3676/trg-prime/module`) and Eldritch Arts 0.8.0 (Block 3's Witch in `module/block3-automations.mjs` and `tools/content/block3.mjs`; Block 4's Warlock in `module/block4-automations.mjs`, `tools/content/block4.mjs` and `block4-spells.mjs`).

**Picker access works for all 21 as printed.** The core's `classFeat` slot gates on the feat's traits: class names, registered module classes, and the tier words Martial, Expert and Adept (`picker-filters.mjs:903–960`). Block 4 registered Warlock and Witch, so WARLOCK and WITCH traits gate. Hex Mastery's ADEPT trait opens it to every Adept class; the Warlock is Adept and Expert, the Witch Adept. The prerequisites "Level N" and "BSB +N" parse (`prerequisites.mjs:88`, `:94`), and feat-name prerequisites (Pact Channeler, Pact Boon) match by exact name. No race traits are involved, so there are no heritage or core-race questions.

**The "no more than once every N levels" cadence** (Extra Bond, High Sorcery, Shadowed Grimoire) is printed only. The core enforces no feat cadence (`magic/magical-discovery.mjs:21–27`). The feats ship `repeatable: true`.

**Prerequisite chains:**
- Pact (archetype) → Pact Channeler (L6, metamagic, another reviewer) → **Pact Boon** (L10) → **Pact Ascendant** (L16).
- Nothing else in this list chains.

##### The Warlock's Charisma PP pool (EA-C2, Q52)

**What is ruled.**
- **EA-C2 (rulings of 1 Nov):** "every character has a PP pool from their magical tradition, casters or not. A Warlock needs Charisma 2 or more, so always has at least 2 PP."
- **Q52 (Block 4, built as proposed):** "A pool of Charisma PP only, as C2 says. Spells never spend it; Block 6's feats will." Sidebar 9 is read as describing the absence of a class PP column.

**What the core already does.** The Warlock already has the pool, provided the actor has a tradition set. No seam is needed.
- `pp.max = base + class table PP + powerPointAbilityBonus(...)` (`documents/actor.mjs:1938–1946`, `class-progression.mjs:248`, `:296`).
- The ability bonus is the resolved casting ability's total whenever **a tradition is set** (Graham's ruling of 16 Sep 2026: "Magical Tradition should always add the appropriate ability score to PP").
- The Warlock class item declares `magicalAbility: "charisma"`, which overrides the tradition's own ability (`actor.mjs:1853–1855`). Its table PP column is 0 (`tools/content/block4.mjs:51–54`).
- So a Warlock with any tradition on the sheet reads **PP = Charisma** (plus PP base grants, racial PP, a held Power Crystal).
- **The gap:** the Warlock class names no tradition (`magicalTradition: ""`), so `system.magic.tradition` is the player's own sheet select (`templates/actor/actor-sheet.hbs:2809`). If it is left blank, the pool is 0.

**Proposed build (no core seam).**
1. **Building the pool.** When the Bonded Soul is chosen (Block 4's `abilityChoices` Use), and the actor's `system.magic.tradition` is blank, ask which of the soul's two traditions is the Warlock's own, and write it. That is the same stored field a Fighter or Rogue fills at 1st level. The pool then derives as Charisma through the existing code.
   - This follows Block 3's precedent: the Witch's class names Ethereal "for the system's bookkeeping … for the PP ability bonus" (`tools/content/block3.mjs:122`).
   - It changes nothing else for a Warlock:
     - it has no Spellcraft;
     - its innate casts are High Magic (`highMagicCaster: true`), so they count as every tradition;
     - Block 4's own picker already filters spells by the soul, not by this field.
   - The Warlock class card's line "no PP pool" is reworded to "a pool of Charisma PP that your spells never spend (C2)".
2. **Restoring the pool.** As every pool: daily preparation and Power Recovery, through the core.
3. **Spending the pool.** Spells never spend it: every Warlock spell is innate, and innate casts pay no PP. These spend it:
   - **Warlock's Hex:** 1 PP, written by the module as Verdant Communion writes the pool (`block3-automations.mjs:567`).
   - **Pact Channeler:** +1 PP through D2, on an innate cast (see the seams below).
   - **Whatever any character may spend PP on:** for example the Dispel action's declared PP. Under C2 that is open to every character. It is stated, not blocked.
4. **The harness** checks four Warlocks: Cha +3 with the tradition written (PP 3); with the tradition blank (0, and the soul's Use writes it); a Nyrinn (see Q?-2); and Warlock's Hex refused at 0 PP.

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Elemental Blast | 3446 | WARLOCK / — | Daily prep: pick acid, cold, electricity, fire or sonic; Xithra "may … inflict the chosen damage type instead of mental" | FC-24, B | Spell `damageTypeChoice` effect row; Block 4's `syncXithra` writes Xithra's choice (mental + soul) | Daily-prep prompt; choice on the feat's flag; Xithra's offer becomes mental + soul + element (note 1). **B** | none | — |
| Enhanced Blast | 3452 | WARLOCK / L2 | Xithra "uses a d8 for damage instead of a d6" | FC-25, A | Xithra's `damage.formula` and `casterLevelMods` dice (`block4-spells.mjs:113–134`) | Sync rewrites base 1d8 and each +die to 1d8 (all of Xithra's dice; crit dice follow); the cone too. **A** | none | — |
| Ethereal Insight | 3472 | WITCH / BSB +10 | Darkvision; See Invisible innate 1/day; familiar within 30 ft "also gains the benefit of this feat" | FC-27, B | Core Darkvision ability; core See Invisible (PP 4, self, 10 min); `grantInnate`; Block 3's 30-ft range sync (`refreshSoulboundRange`) | `grantedAbilities: Darkvision`, See Invisible innate, `usesPerDay 1`. The Soulbound familiar carries Darkvision while within 30 ft (same sync); the Witch's See Invisible is laid on the familiar too when within 30 ft (note 2). **B** | none | Q?-11 |
| Extra Bond | 3482 | WITCH / L4; repeatable /4 lvls | "Your familiar grants you an additional ability each day" | FC-28, A | Block 3 `chooseDailyBonus` (one of eight, replaces yesterday's) | Daily choice asks 1 + copies, distinct entries; each its own effect under the same range switch. **B** | none | — (Minor 6) |
| Extra Communion | 3502 | WITCH / L8 | Verdant Communion "an additional time per day" | FC-30, A | `itemUsesMax` adds `bonusUses` + `extraUsesBonus` (`uses-workflow.mjs:92`); the extra-uses table is a core literal (`extra-uses.mjs:58`) | +1 use of Verdant Communion per copy, through S-3 (fallback: the module keeps `bonusUses` in step on create/delete). Block 3's Use already reads the remaining uses. **A** | S-3 | — |
| Forbidden Lore | 3546 | WITCH / BSB +10 | "learn and develop a single spell from either the Arcane or Divinity tradition and add it to your repertoire" | FC-35, B | Repertoire picks filtered to E/V (`classMagic.traditions`); Block 3 `addSpell` | Feat Use: pick one arcane- or divinity-tradition spell (not specialist), base PP ≤ CL + 1, added outside the schedule (not a `repertoirePick`); High Magic per Q?-7. **B** | none | Q?-7 |
| Hex Binders Curse | 3586 | CONCENTRATE WARLOCK WITCH / L5; 1 AP | Curse one seen enemy within 30 ft; "If you damage a cursed enemy, you deal 1d6 additional damage"; one at a time; +1d6 at 10th and every 5 | FC-38, A | `trgPrimeDamageApplied` with `sourceUuid` for a weapon Strike (`attack-workflow.mjs:6132`); **spell damage carries no source** (`damage-workflow.mjs:383`); `applyTypedDamage` helper; `traitGate` (Concentrate) | 1 AP Use on the targeted token (`traitGate`, AP): a marker effect on the target with your uuid, the old one removed. On damage you deal to it, roll the extra dice (1d6, 2d6 at 10th …) and apply them (note 3). **B** | S-1 | Q?-4 |
| Hex Mastery | 3600 | ADEPT WITCH / — | "Reduce the PP cost of your hex spells by 1 (min 1)" | FC-39, A (D5) | `registerCastSurcharge` floors at 0 (`cast-surcharge.mjs:23`), so it cannot discount; `warpDiscount` is warp-only (`cast-workflow.mjs:1603`) | A cost modifier on casts of `eaHex` spells: −1 PP paid, minimum 1 (S-2). A Warlock's hexes are innate and cost nothing: the card says so. **A** (once S-2 exists) | S-2 (D5) | Q?-6 |
| High Sorcery | 3626 | SORCERER WITCH / BSB +4; repeatable /4 | "learn an additional high magic spell and add it to your repertoire" | FC-42, B | Magical Discovery's bonus pick is name-matched (`magical-discovery.mjs:57`); `addSpell` | Feat Use per copy: one spell the class could pick (Witch E/V; Sorcerer any; PP ≤ CL + 1), added outside the schedule, as Forbidden Lore. **B** | none | — |
| Malevolent Blast | 3772 | FOCUS WARLOCK / — | Xithra hit: "the target must make a Will save or be Stunned 1"; critical hit: Stunned 2 | FC-55, B | `trgPrimeSpellSettled.spellHits` with `critical` (`cast-workflow.mjs:518`, `:5522`); Focus use default 1 (`uses.mjs:150`); `rollCheck`; core Stunned (valued) | Offered after a Xithra hit while the Focus use is left (Mantle of Essence pattern): spend the use, roll the target's Will; failure or worse → Stunned 1, or 2 if the hit was critical. Not on Xithra Cone (no attack). **B** | S-6 (or inline formula) | Q?-5 |
| Pact Ascendant | 3830 | WARLOCK WITCH / L16, Pact Boon | By pact: Angelic aura; Demonic fire immunity and death burst; Draconic wings and spell; Elemental immunity and spell; Fey and Void mental immunity and spell; Grave essence immunity and spell | FC-60, B | Ally aura (`ally-aura-effects.mjs`; any item's `auras`, `creature-auras.mjs:388`); `combat.immunities` text and trait immunity (`traits.mjs:328`); fly speed `combat.movement.fly.base`; death guard (`combat/death-guard.mjs`) | Per pact (note 4): passive effects **A**; spells added as Pact Boon's; Demonic burst via S-5. **B** overall (C parts: note 4) | S-5 | Q?-7, Q?-12 |
| Pact Boon | 3854 | WARLOCK WITCH / L10, Pact Channeler | Add a spell to your repertoire by pact: Restoration, Fireball, Dragon Wings, Conjure Elemental (your element), Confusion, Create Undead, Long Sense | FC-61, A | All but Dragon Wings are core spells (note 5); Block 4's `warlockCopy`; Block 3's `addSpell` | On create, by the owned pact archetype: a **Warlock** gets an innate Focus High Magic Charisma copy (`warlockCopy`); a **Witch** gets a repertoire spell outside the schedule (Q?-7). Draconic waits for Dragon Wings. **B** | none | Q?-7 |
| Ritual of Borrowed Power | 3968 | WITCH / BSB +8 | Daily prep: one spell "from any magical tradition … cast … as if it were a High Magic spell from your repertoire" until the next prep | FC-68, B | Daily-prep hook; `addSpell`; Highmagic trait makes a cast High Magic (`high-magic.mjs:167`) | Daily-prep prompt: any non-specialist spell, base PP ≤ CL + 1; a copy flagged for the day, with the Highmagic trait if it isn't E/V; deleted at the next prep. **B** | none | — (Minor 7) |
| Shadowed Grimoire | 4052 | WARLOCK / L3; repeatable /3 | "learn an additional spell which may be selected from usual magical traditions"; may swap it at each level | FC-75, B | Block 4 `pickWarlockSpells` / `warlockMayTake` / `warlockCopy` | Feat Use: one pick per copy, by the soul's traditions, PP ≤ level + 1, innate Focus Charisma; level recorded; at a higher level the Use offers the swap. **B** | none | — (Minor 5) |
| Soul-Bound Grimoire | 4078 | WITCH / BSB +4 | Scribe E/V scrolls into the familiar at daily prep (scrolls consumed; stored outside the repertoire); each day imprint one, castable as if in the repertoire; if already known, "–1 PP reduction to its warping cost (minimum 1)" | FC-77, B | Scroll consumables (`consumable-use.mjs:164`); per-spell `warpDiscount` flag, minimum 1 (`cast-workflow.mjs:1603`) | Daily prep: (1) offer the owned E/V scrolls: each chosen one is deleted and its spell recorded on the feat; (2) choose one stored spell: a copy for the day, or `warpDiscount +1` on the owned spell for the day. **B** | none | Q?-9 |
| Symbiotic Witch | 4174 | WITCH / BSB +4 | 1/day cast any spell of ≤ 4 PP through the familiar, "even if your familiar is out of sight"; the familiar "can sustain any one spell you cast without needing you to concentrate" | FC-84, C | Range measured from the caster's token (`cast-workflow.mjs:1905`); sustain lapse at 2 rounds (`active-spells.mjs:350`, `:580`); damage interrupt (`sustain-workflow.mjs:370`); `hasSustained` blocks PP recovery (`:336`) | Conduit: a 1/day Use; pick a spell ≤ 4 PP; `castSpell` with range from the familiar's token (S-4). Sustain: Use on a sustained entry → sustained by the familiar (S-7). **B** with S-4 and S-7 (without them, **C**: GM measures; the module re-stamps the sustain each turn) | S-4, S-7 | Q?-8 |
| Warding Sigil | 4240 | FOCUS WARLOCK / L6 | "Until the end of your next turn, you gain resistance to any damage type that your Xithra Blast is capable of inflicting" | FC-90, A | Focus use; `combat.resistances` text effect; `expiryFor("endOfNextTurn")` (Block 5 pattern) | Use: spend AP and Focus; resistance to Xithra's offered types (mental + soul's + Elemental Blast's), until the end of your next turn. **A** | none | Q?-10 |
| Warlock’s Hex | 4250 | FOCUS WARLOCK / L2 | On damaging a creature with a spell or Xithra, "you may spend 1 PP to mark them": −1 circumstance to saves against your spells for Cha rounds; −2 at 10+ | FC-91, B (blocked by EA-C2) | `sourceUuids` conditional axis, filled on spell saves (`cast-workflow.mjs:6875`) and on `basicSaveHit` (`area-save-workflow.mjs:52`); pool as above; `askReactor` | Offered when you damage a creature with a spell (S-1) or Xithra (`spellHits`): spend the Focus use and 1 PP; the target gets an effect with `{save, sourceUuids:[you], −1/−2 circumstance}` for Cha rounds. **B** | S-1 | Q?-1, Q?-3 |
| Xithra Cone | 4294 | WARLOCK / L10 | "release your Xithra Blast as a 30-foot cone … basic Reflex save" | FC-95, A | `registerCastPrelude` (Block 4, Thunderous Strike); `runAreaEffect` with `targets` (Elemental Breath pattern, `block5c-automations.mjs:271`) | Xithra's prelude asks "bolt or cone". The cone spends Xithra's AP and Focus use, takes the targeted tokens, and makes a basic Reflex against the innate DC for Xithra's damage and type (note 6). **B** | S-6 (or inline formula) | Q?-5 |
| Xithra Recovery | 4302 | WARLOCK / L4 | "use your Xithra Blast twice before having to use the Focus action to restore it" | FC-96, A | `focusExtraUses` declaration, added in `itemUsesMax`, with `restoresAll` (`focus-declarations.mjs:12`, `uses-workflow.mjs:99`) | Feat effect `focusExtraUses: [{value:1, names:["Xithra"], restoresAll:true}]`. **A** | none | — |
| Xithra Spear | 4310 | WARLOCK / L5 | "The range of your Xithra Blast increases to 60 feet" | FC-97, A | Spell range is read by the cast's range test (`spell-range.mjs`) | The sync writes Xithra's range as 60 feet. **A** | none | — |

**Notes**
1. **Xithra's sync.** Block 4's `syncXithra` (`block4-automations.mjs:651`) becomes the single writer of Xithra's range (Spear), die size (Enhanced Blast) and damage-type offer (soul and Elemental Blast). It runs on feat create and delete, on the soul's choice, and at daily preparation. Warding Sigil and Xithra Cone read the same offer (`xithraTypes`).
2. **Ethereal Insight's familiar.** Darkvision is the core ability item, created on the Soulbound familiar while it is within 30 ft and removed outside it, through Block 3's `refreshSoulboundRange`. See Q?-11 for See Invisible.
3. **Hex Binders Curse.**
   - **The curse:** an effect on the target that carries the curser's uuid (one at a time: the curser's earlier one is deleted).
   - **The damage:** on `trgPrimeDamageApplied` with `sourceUuid` = the curser and the target cursed, roll the dice and apply them through `applyTypedDamage`, in the triggering blow's type. The module's own extra application is flagged so it cannot retrigger.
   - **Coverage today:** weapon Strikes work now. Spell damage needs S-1.
   - **Recurring damage** is excluded (Q?-4).
   - **The dice:** 1d6 at 5th, +1d6 at 10th, 15th and 20th.
4. **Pact Ascendant, by the pact archetype owned.**
   - **Angelic:** an ally aura of 10 ft laying `advantage` on saves with the `fear` trait (A). Resurrection added (core, PP 12, Rare).
   - **Demonic:** "fire" in `combat.immunities` (A). The once-a-day burst is a death guard leaving half HP and then a burst, through S-5: 10d6 basic Reflex, 20 ft (Q?-12).
   - **Draconic:** fly 40 through `combat.movement.fly.base` (A). The spell is **Shape Of The Wyrm**, the core spell, under ruling M2 (Minor 1).
   - **Elemental:** immunity to the pact's chosen element's damage type, as the Elemental Pact maps it (air: electricity; earth: acid; fire: fire; water: cold) (A). Conjure Elemental is added, with "(your element only)" as a card note (C).
   - **Fey and Void:** "mental" in `combat.immunities`, which `immuneToEffect` reads as trait immunity for every effect (A). Dominate and Maze are added (core).
   - **Grave:** "essence" damage immunity (A). Damage of another type from an Essence-trait effect is a GM call (C), because a trait immunity would also refuse Essence-trait healing. Hand Of The Reaper is added (core).
5. **Spells named, and where they are.**
   - **Core spells pack (read from a copy of `packs/spells`):**
     - See Invisible 4
     - Restoration 2
     - Fireball 6
     - Conjure Elemental 4
     - Confusion 8
     - Create Undead 4
     - Long Sense 6
     - Resurrection 12
     - Dominate 14
     - "Hand Of The Reaper" 14
     - Maze 16
     - "Shape Of The Wyrm" (12)
   - **Dragon Wings (PP 6):** the Eldritch Arts Grimoire (ea.md L6554), so Blocks 7–8.
   - **PP limits:** every listed spell is within a Warlock's level + 1 and a Witch's CL + 1 at the feat's level (Maze 16 at 16th is within 17).
6. **Xithra Cone.**
   - **Damage:** Xithra's damage: dice by level (d6, or d8 with Enhanced Blast), + Charisma, and the type chosen.
   - **DC:** the innate save DC: 10 + Charisma + level, + the soul's +1 where its traits apply (none of the souls lists Mental). Through S-6, or the printed formula inline.
   - **On-hit effects do not apply** (no attack is rolled): the soul's on-hit riders and Malevolent Blast. The on-use riders (Cure, Misty Step) and Warlock's Hex (it is damage) do.

##### Proposed core seams

- **S-1 Spell damage names its caster.**
  - **What:** `applyTypedDamage` takes `sourceUuid` and passes it, with `context: { kind: spellName ? "spell" : "other", spellName }`, to `applyDamageAndCheckDying`. The cast's damage sites and `basicSaveHit` pass the caster's uuid. `basicSaveHit` already gives that uuid to the save's check (`area-save-workflow.mjs:52`) but not to the damage.
  - **Why:** `trgPrimeDamageApplied` names the source only for a weapon Strike (`attack-workflow.mjs:6132`). Spell damage arrives with `sourceName` alone (`combat/damage-workflow.mjs:383`), so "when you damage a creature with a spell" can't be seen.
  - **Where:** `combat/damage-workflow.mjs` `applyTypedDamage`; its callers in `magic/spell-effects.mjs` and `magic/area-save-workflow.mjs`.
  - **Used by:** Warlock's Hex and Hex Binders Curse.
- **S-2 Cast cost discount (D5's discount half).**
  - **What:** `registerCastCostModifier(key, ctx => ({ ppDelta, floor, label }) | null)`. The ctx is the surcharge's (`actor, spell, spellData, innate, cantrip, itemCast, basePP, totalPP`). It is asked before the PP-availability test. A negative `ppDelta` lowers the PP paid, never below `floor` (default 1), and the card names it.
  - **Why:** `registerCastSurcharge` floors at 0 (`cast-surcharge.mjs:23`), and `warpDiscount` discounts warps only.
  - **Where:** `magic/cast-workflow.mjs`, beside `runCastSurcharges`.
  - **Used by:** Hex Mastery. Shared with Spell Weaver and Resonant Crystal Shard (other reviewers), so the lead should merge the shape. Whether the DC follows is Q?-6.
- **S-3 Declared extra daily uses.**
  - **What:** `registerExtraUses(featName, { ability, perCopy })`, merged into `EXTRA_USES_FEATS`, read by `extraUsesBonus`.
  - **Why:** the core's Extra Channels, Mercy and Wildshape are a hard-coded literal (`extra-uses.mjs:58`). Writing `bonusUses` from the module is the fallback; it needs its own reconcile on delete.
  - **Where:** `extra-uses.mjs`, `module-api.mjs`.
  - **Used by:** Extra Communion.
- **S-4 Cast from another's position.**
  - **What:** a `castSpell` option `rangeFrom: <token uuid>`. The range test and the area template's origin measure from that token, not from the caster's.
  - **Where:** `magic/cast-workflow.mjs:1905` (range), and the template origin in `magic/spell-template.mjs`.
  - **Used by:** Symbiotic Witch (conduit).
- **S-5 A zero-HP death guard that leaves half HP, and says it held.**
  - **What:** `heal: "half"` accepted when `trigger` is the default zero-HP trigger (today only for `trigger: "death"`, `combat/death-guard.mjs:86`), and `Hooks.callAll("trgPrimeDeathGuardHeld", { actor, label })` after a guard holds.
  - **Why:** "when you would gain the dying condition, you instead explode … You then rise with HP equal to half your maximum."
  - **Used by:** Pact Ascendant (Demonic). The module runs the burst on the hook (`runAreaEffect`, creatures within 20 ft).
- **S-6 The innate save DC as a helper (optional).**
  - **What:** `helpers.innateSaveDCFor(actor, spell)`: the DC an innate cast of that spell would use, `innateSaveDC` (`magic/casting.mjs:88`) plus `innateLevelBonusFor` (`magic/innate-level-bonus.mjs:34`).
  - **Why:** without it, the module repeats the two-term formula and its own soul bonus.
  - **Used by:** Xithra Cone and Malevolent Blast.
- **S-7 A spell sustained by another.**
  - **What:** an active-spell entry `sustainedBy: { uuid, label }`, effects as follows:
    - `sustainedLapses` treats it as sustained each round while that creature lives;
    - `registerSustainInterruptHooks` watches the sustainer's HP, not the caster's;
    - `hasSustained` (no PP recovery while sustaining) skips it;
    - per-round sustain dues are charged as Q?-8 rules.
  - **Where:** `magic/active-spells.mjs:336`, `:350`, `:580`; `magic/sustain-workflow.mjs:370`.
  - **Used by:** Symbiotic Witch.

**For D2 (the metamagic seam, another reviewer).** No feat in this list is metamagic. The Warlock pool gives one requirement: Pact Channeler's "+1 PP" must be payable **on an innate cast**, from the pool. Innate casts pay no PP today, and their warp budget is free. So `registerMetamagic`'s PP cost must be charged to `resources.pp` even when the cast is innate, and refused when the pool can't pay.

##### Questions

1. **Q?-1 — Warlock's PP pool (EA-C2, Q52): how it is built and spent.**
   - **Issue:** C2: "every character has a PP pool from their magical tradition … at least 2 PP". The book: "you do not possess a pool of PP" (L1450). The Warlock names no tradition, so with the sheet's tradition blank the core gives 0.
   - **Why it matters:** Warlock's Hex and Pact Channeler can't be paid.
   - **Proposed:**
     - The Bonded Soul's choice writes one of the soul's two traditions into the actor's tradition when it is blank, so the pool is **Charisma** (plus any PP grants, racial PP or crystals).
     - It is restored as any pool.
     - It is spent only by Warlock's Hex, Pact Channeler and actions any character may pay PP for (Dispel). Never by spells.
2. **Q?-2 — A Nyrinn Warlock's pool.**
   - **Issue:** the Nyrinn prints "Power Points: −1" (L241), built as −1 a level (`registerRacialPP`). Sidebar 9 says Nyrinn "excel as Warlocks".
   - **Why it matters:** under C2 a Nyrinn Warlock's Charisma pool is gone by level 3 or 4, so Warlock's Hex is unusable for exactly the pairing the book recommends.
   - **Proposed:** as printed: the racial −1 a level applies, floored at 0. Alternatively, say it does not reduce a Warlock's Charisma pool.
3. **Q?-3 — Warlock's Hex: the Focus use and the PP.**
   - **Issue:** the feat has the FOCUS trait and also says "you may spend 1 PP".
   - **Proposed:** both are paid:
     - one hex per Refocus (or daily preparation), and 1 PP from the pool;
     - it is offered after any spell or Xithra damage to a creature (not recurring damage);
     - "saves against your spells" includes saves Xithra forces (Malevolent Blast, Xithra Cone), since Xithra "is considered to be an innate spell";
     - "Charisma modifier" rounds is your Charisma score (TRG's scores are the modifiers), minimum 1.
4. **Q?-4 — Hex Binders Curse: duration, frequency, damage type.**
   - **Issue:** no duration is printed (only "one creature … at a time"). "If you damage a cursed enemy, you deal 1d6 additional damage" names no type or frequency.
   - **Why it matters:** read literally, it is permanent and adds dice to every blow.
   - **Proposed:**
     - **Duration:** until you curse another creature, it dies, or your next daily preparation. No save.
     - **Frequency:** the extra dice once per Strike or per spell that damages it; not on recurring damage.
     - **Type:** the triggering damage's type, meeting the same defences.
5. **Q?-5 — The DC of Xithra's saves (Malevolent Blast, Xithra Cone).**
   - **Issue:** no DC is printed. Ruling C3's default is "the Level DC of the target (if something is targeted)".
   - **Why it matters:** C3 would set the target's own Level DC against Malevolent Blast. Xithra is "considered to be an innate spell for casting purposes", and Q41 cast the soul riders "at the Warlock's innate level and DC".
   - **Proposed:**
     - **DC:** the Warlock's innate save DC, 10 + Charisma + level (with the soul's +1 where it applies), for both feats.
     - **Malevolent Blast's degrees:** a failed save (or worse) gives Stunned 1, or Stunned 2 when the Xithra hit was critical. A Success or better gives nothing.
6. **Q?-6 — Hex Mastery: cost or DC.**
   - **Issue:** "Reduce the PP cost of your hex spells by 1 (min 1)".
   - **Why it matters:** casting and save DCs derive from PP.
   - **Proposed:** the PP paid falls by 1 (minimum 1); the casting DC, the save DC and the cap are those of the spell's PP as cast. Warlocks' hexes are innate and cost nothing, so the feat does nothing for them (the card says so). The same answer should serve Spell Weaver and Resonant Crystal Shard.
7. **Q?-7 — Are spells a Witch gains outside Ethereal and Verdant cast as High Magic?**
   - **Issue:** the Witch treats "the Ethereal and Verdant traditions as high magic" (built `highMagicCaster: ["ethereal","verdant"]`). But her "HIGH MAGIC SPELLS" section says "you may also gain additional spells by purchasing the Forbidden Lore and High Sorcery feats". M27 says High Magic classes treat every spell they cast as High Magic.
   - **Affected feats:** Forbidden Lore (arcane or divinity); Ritual of Borrowed Power ("as if it were a High Magic spell" — already explicit); Pact Boon and Pact Ascendant spells (e.g. Resurrection, divinity only; Maze, arcane).
   - **Proposed:** yes: every spell these feats add to a Witch is High Magic. The module adds the Highmagic trait to its copy. Her own picks stay as built.
8. **Q?-8 — Symbiotic Witch.**
   - **Issue:** "any spell of 4 PP or less"; "your familiar can sustain any one spell you cast without needing you to concentrate".
   - **Why it matters:** the PP limit, who pays a spell's per-round sustain dues, whether damage to the Witch still interrupts, and whether she may recover PP meanwhile.
   - **Proposed:**
     - **The conduit:** base PP ≤ 4, warps allowed only while the total stays ≤ 4. Range and area measured from the familiar. Once per day.
     - **Sustaining:** one spell at a time. The Witch pays any PP dues. Damage to the familiar (not to the Witch) asks the Spell Concentration check. The Witch may recover PP while only the familiar sustains. The familiar's death ends it.
9. **Q?-9 — Soul-Bound Grimoire's stored spells.**
   - **Issue:** spells are "permanently stored (until erased or replaced)" in the familiar.
   - **Why it matters:** familiars die, and bonds sever.
   - **Proposed:**
     - while the bond is severed, nothing can be imprinted;
     - a familiar's death loses its stored spells (a new bond is a new creature);
     - no limit on the number stored;
     - the imprinted spell is cast at the Witch's normal PP cap (CL + 1);
     - "Erased or replaced" is a Use: remove a stored spell.
10. **Q?-10 — Warding Sigil's action.**
    - **Issue:** no Action field is printed (Hex Binders Curse prints "1 AP").
    - **Proposed:** 1 AP, Focus (one use until Refocus).
11. **Q?-11 — Ethereal Insight's familiar.**
    - **Issue:** "it also gains the benefit of this feat".
    - **Proposed:** the familiar has Darkvision while within 30 ft. When the Witch casts her daily See Invisible, the familiar within 30 ft benefits too, from the one casting (not a second daily use of its own).
12. **Q?-12 — Pact Ascendant (Demonic)'s burst.**
    - **Issue:** "10d6 Fire & Evil damage in a 20-ft burst (basic Reflex)": no DC printed; "Fire & Evil" is two words.
    - **Proposed:**
      - **DC:** your Level DC (C3: nothing is targeted), as Elemental Breath (Q77).
      - **Damage:** one fire packet carrying the Evil trait, so evil-trait resistances and weaknesses read it.
      - **Area:** a burst centred on you, catching everyone within 20 ft, allies included.
      - **Recovery and limits:** you rise at half your maximum HP with no Dying; not against a blow that kills outright; once a day.

##### Waits on other blocks

- **Pact Boon and Pact Ascendant:**
  - **They need the seven Pact archetype feats** (Block 6, another reviewer) to know the pact. Elemental and Draconic also need the archetype's stored choice (element; dragon energy). They should ship in the same release as the Pacts.
  - **They need Pact Channeler** (metamagic, D2) as the prerequisite.
- **Pact Boon, Draconic:** Dragon Wings is a Grimoire spell (Blocks 7–8). Ship the other six pacts now; the Draconic branch posts a card until the spell exists.
- **Hex Mastery:** waits on S-2 (D5's discount half). A reminder card meanwhile, or hold the feat for that release.
- **Forbidden Lore, High Sorcery, Ritual of Borrowed Power, Shadowed Grimoire, Soul-Bound Grimoire:** no wait. They read the spell index, so Grimoire spells become choosable when Blocks 7–8 add them.
- **Warlock's Hex and Hex Binders Curse:** the weapon-Strike half works now. The spell half waits on S-1 (same core release).

##### Minor

1. **Pact Ascendant's "Shape of the Dragon"** (L3844) is still printed in v1.6. Ruling M2 ("spell names as proposed") makes it the core **Shape Of The Wyrm**. It is built so, and the card says so.
2. **EA-m47:** Fey and Void Pact Ascendant both print "immunity to all effects with the mental trait". Not ruled; built as printed.
3. **"HEX BINDERS CURSE"** has no apostrophe ("Hex Binder's Curse"). The printed name is kept, so prerequisite matching stays exact.
4. **EA-m38 is settled in v1.6:** Xithra Spear now says "Xithra Blast". The feats still call Xithra "Xithra Blast" and "Xithra attack"; both are read as Xithra.
5. **Shadowed Grimoire's** last line has no full stop. "Usual magical traditions" is read as the bonded soul's traditions, as Block 4's picks are.
6. **Extra Bond's** extra abilities are read as different entries from the eight; two of the same bonus type would not stack.
7. **Ritual of Borrowed Power:** EA-m43 (the flavour repeated as rules text) is fixed in v1.6. "Once per day, during your daily preparation" is the same occasion said twice. The pick excludes specialist spells, and its PP is within the Witch's cast cap.
8. **Malevolent Blast's flavour** is in the italic line; its rules lines are clean. It applies to the bolt only (no hit in a cone).
9. **Pact Ascendant** writes "10-ft" and "20-ft", where the book elsewhere writes "10 feet".
10. **Hex Mastery's ADEPT trait** opens it to every Adept class. Only Witches (and others with hexes through Specialist Spell, the Bloodmage hexes, Q21) have a PP-costing hex to reduce.

### Appendix F. Sorcerer and Spellblade

#### Sorcerer, Archmage and Spellblade class feats

14 feats, v1.6 L3230–4092 (`book-text.json` `sections.classFeats`). They break down as follows:
- **Sorcerer (6):** Arcane Study, Dangerous Sorcery, High Mage's Focus, High Magic Resonance, Metamagic Adept, Resonance Surge.
- **Spellblade (7):** Bespell Weapon, Bonded Infusion, Call Bonded Weapon (also Crusader), Clever Damage, Clever Strike, Magical Retribution, Spellblade's Mark.
- **Martial (1):** Considered Attack.

No feat in this list carries the ARCHMAGE trait.

**Who can take them.** The core class-feat picker (`picker-filters.mjs` `buildPickerFilter` "classFeat", L914–968) gates on traits:
- SORCERER and SPELLBLADE are registered class names. CRUSADER is a core class.
- MARTIAL is a tier gate, so Considered Attack is open to every Martial class, core and module alike (Fighter, Ranger, Crusader, Spellblade, …).
- MAGICAL, FOCUS, FLOURISH, CONCENTRATE, INVOCATION and CLASS gate nothing.
- High Mage and Birthrager ("feats which are available only to the Sorcerer (Adept) class", v1.6 L3062, L2908) open the Sorcerer feats. Spellblade-feat access through archetypes belongs to the archetype reviewer.

**Prerequisites as the core reads them** (`prerequisites.mjs` `meetsParseablePrerequisites`):

| Clause | Feats | Today |
|---|---|---|
| BSB, BAB, Int and Level clauses | all of them | Gated. |
| Weapon Focus | Call Bonded Weapon | Gated: a core General feat (feats pack, "BAB +1"). |
| "Arcanum Birthright" | Arcane Study | **Passes open.** The birthright ability is named "Arcanum" (`tools/content/block3.mjs` `BIRTHRIGHTS`), so the clause names nothing that exists. |
| "Wild Birthright" | Resonance Surge | **Passes open**, for the same reason. |
| "A Sorcerer with the Wild Birthright cannot take this feat" (printed as text, not a prerequisite) | High Magic Resonance | **Not enforced.** |
| "Blade Ally or Infuse Weapon" | Call Bonded Weapon | Passes open: an "or" clause is never parsed. |
| "Ability to cast spells" | Bespell Weapon | Passes open. Harmless: every Spellblade casts. |

Three of these feats need seam S6s-1. The archetype reviewer's five "<X> Birthright" archetypes need the same seam: Blood of the Wyrm, Eternal Vigil, Runebreaker, Shade Master and Stormcaller.

**Prerequisite chains.** None between these 14 feats.

**Spells granted.** None. Arcane Study scribes core arcane spells, which are in the core spells pack.

**Already in the module.** These are what the feats build on:
- the Sorcerer's birthright abilities (`eaBirthright` flag, `module/block3-automations.mjs` `birthrightOf` L69);
- Raw Power (`rawPowerRaise`, L72, through `registerCastCapModifier`);
- Wild Power's daily specialist spell (`wildDailySpecialist`, L347), the pattern for a spell kept for one day;
- Infuse Weapon (`module/block4-automations.mjs` `infuse` L340). It writes the system flag `flags.trg-prime.infusedRunes = {weaponId, runes, day}`, cleared at daily preparation (L749);
- the rune-learning flow (`learnRune` L364, through `helpers.learnSpellTerms` / `learnSpellOutcome` / `rollCheck` / `deductGold`).

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Arcane Study | 3230 | SORCERER / Arcanum Birthright, BSB +4 | "a spellbook similar to that of a wizard that you may scribe arcane spells into". At daily preparation, add one book spell to the repertoire; or, if already known, "lower all warping costs (min 1 PP) for that spell by 1" | FC-03 B, D5; no EA entry | Learn a Spell is closed to an instinctive caster (`learn-spell-workflow.mjs` `routeFor`: class book or Arcanist only). Per-spell `warpDiscount` flag, on the warp total, min 1 (`cast-workflow.mjs` L1603, `spell-warp.mjs` `applyWarpDiscount`). Helpers `learnSpellTerms`, `learnSpellOutcome`, `deductGold` | **B.** A "Scribe a spell" Use, as Block 4's `learnRune`. The book is a list of compendium uuids on the feat, not spell items, so nothing in it is castable (n1). Daily preparation: choose one, created for the day as Wild Power's spell is, or set `warpDiscount` +1 on the known spell until the next preparation | S6s-1 (prerequisite); S6s-8 only if Q?-1(c) is "each option" | Q?-1, Q?-2 |
| Bespell Weapon | 3238 | MAGICAL SPELLBLADE / Ability to cast spells, level 5 | Free action: "siphon the residual energy from the last spell you cast" into a wielded weapon. 1d6 secondary damage until end of turn, its type by school (Alteration/Translocation a physical type; Enchantment/Insight/Shadow mental; Invocation the spell's type or force; Soul essence; Warding force). "You may sustain this feat each round" | FC-04 B | `strikeRider` effect: typed secondary packet, `weaponId`, `scope` (`magic/strike-riders.mjs`). `trgPrimeSpellSettled` carries `spell`/`spellData`/`cast`. `trgPrimeTurnEnded`. The eight schools (`magic/casting.mjs` L320) are exactly the book's eight | **B.** A spell that settles (`cast`) is remembered with its school and damage types for the turn. 0 AP Use: choose a wielded weapon, and a type where the school gives a choice. Writes a `strikeRider {dice:"1d6", damageType, weaponId, scope:"any"}` effect, removed at turn end. Sustain button (n2) | none | Q?-3 |
| Bonded Infusion | 3260 | SPELLBLADE / — | Infused weapon "becomes a casting focus item which grants a +2 bonus instead of the usual +1"; also "a +1-spell adder" | FC-05 A; EA-R7 (adders stack) | Focus +1 item is fixed (`magic/casting.mjs` `focusCheckModifier` L296). Item bonuses stack highest-only (`dice/resolution.mjs` `applyStacking` L269, `item: highest`). Spell adder read off any item's `flags.trg-prime.spellAdder` (`magic/spell-adder.mjs` `spellAdderSources` L60). Gate rows reach the casting check and the attack (`cast-workflow.mjs` L2767–2785) | **A.** (1) A `registerSpellCheckGate` row `{type:"item", value:2, label:"Bonded Infusion"}` while the infused weapon (`infusedRunes.weaponId`) is equipped. Not for innate or item casts. It supersedes the core +1 (highest-only), so the total is +2 (n3). (2) The feat item carries `spellAdder: 1` while today's infusion exists; the module toggles it at Infuse Weapon and at daily preparation | none | Q?-4 |
| Call Bonded Weapon | 3266 | CRUSADER SPELLBLADE / Blade Ally or Infuse Weapon, Weapon Focus, BAB +8; 1 AP (manipulate) | Blade Ally or infused weapon "teleports into your hand regardless of range" | FC-06 A | The Blade Ally weapon is on the ally item's `bladeAlly.weaponId` (`feats-workflow.mjs` L4046). The infused weapon is `infusedRunes.weaponId`. The core's Called rune is a card only ("this system does not track where a dropped weapon has got to", `rune-actions-workflow.mjs` L159). `traitGate` / `recordTraitUsage` helpers | **A.** 1 AP Use (manipulate gate): equips the bonded weapon if it is on the sheet and unequipped. Asks which, if both. If another creature holds it, a card line, and the GM moves the item. No save is printed, unlike the Called rune (n4) | none | — |
| Clever Damage | 3286 | SPELLBLADE / Int +3, BAB +4 | Melee weapon damage: "may use your Intelligence … instead of Strength" | FC-08 A | Weapon Finesse's Dex for damage is hard-coded by feat name (`combat/attack-workflow.mjs` L5497–5520). Nothing is declared | **A** with S6s-2. The better of Str, finesse Dex and Int ("may"). Hand-and-a-half ×1.5 applies to whichever is used, as it does to Dex (n5) | S6s-2 | — |
| Clever Strike | 3294 | SPELLBLADE / Int +3, BAB +2 | "When taking the Strike action with a melee weapon", Int instead of Str for the attack | FC-09 A | `finesseAdjustment` (`combat/attack.mjs` L126) adds Dex − current ability, if positive (`attack-workflow.mjs` L1630). Nothing is declared | **A** with S6s-2. Best of Str, finesse Dex and Int, so Finesse and Clever Strike never both add. Strike only: not the maneuvers (`weaponManeuverModifiers` L581) | S6s-2 | — |
| Considered Attack | 3336 | CLASS MARTIAL / Int +2, BAB +6 | "increase the amount of AP you use when making a Strike action to increase your attack bonus by +2" | FC-13 B | `helpers.rollWeaponAttack` with `apPaid` and `extraModifiers`. Power Attack is the core's queued one-shot (`attack-workflow.mjs` L1546). No module Strike-option seam | **B.** Use "Considered Strike": choose weapon and target, pay the Strike's AP + 1, then `rollWeaponAttack({apPaid, extraModifiers:[{label, value:2, type:"untyped"}]})` | none | Q?-5 |
| Dangerous Sorcery | 3354 | SORCERER / — | "a damage-dealing spell without a duration … a status bonus to damage equivalent to its PP cost" | FC-15 A | C1 `spellDamageBonus` flat row: `value`/`valueFrom` an ability, `traits`, `type`, once per cast on the primary pool (`magic/spell-damage-bonus.mjs`, read at `cast-workflow.mjs` L5771 and the save path) | **A** with S6s-3. A status row whose value is the spell's PP, only for a spell with no Duration entry | S6s-3 | Q?-6 |
| High Mage's Focus | 3608 | SORCERER / — | One known High Magic spell: "reduce its casting DC by 2 permanently"; another at BSB +10 | FC-40 B, D1 | Spell-check gate rows with `castingOnly` (`spell-check-gates.mjs` `normaliseGateAnswer`). Ctx `highMagic`. Ley Line Connection is the precedent | **B.** Choice on taking, kept on the feat (`spellUuids`). Second pick offered when BSB first reads +10 (actor update) or from the Use button. Gate: `{value:+2, type:"untyped", castingOnly:true}` when `ctx.highMagic` and the spell is a pick. Under B1-5, a DC change is a check modifier, so an attack spell's attack is unchanged | none | — |
| High Magic Resonance | 3616 | SORCERER / — ("cannot take" with Wild) | High Magic Resonance: "you only roll on the resonance table once". "you may treat the first spell fumble that you make each day as a spell fail" | FC-41 A, D6; EA-M20 (disadvantage = roll twice, take higher; as proposed) | High Magic Resonance with disadvantage (`cast-workflow.mjs` `rollResonanceEvent` L7536: `worse = disadvantage \|\| modifiers.highMagic`). Nothing can lift it. `registerCastDegreeRemap` (D7) runs before the fumble roll and PP | **A.** (1) S6s-4: cancel the High Magic disadvantage for its owner. (2) A remap Fumble → Failure on the first casting Fumble each day (stamp on the feat, cleared at daily preparation), with a card line. (3) The Wild bar through S6s-1 | S6s-4 (D6), S6s-1 | Q?-2, Q?-7 |
| Magical Retribution | 3762 | SPELLBLADE / BAB +6; Reaction; Trigger: "a creature within melee strikes you and inflicts HP damage whilst you are casting a spell" | AoO against the attacker, "resolved before any potential spell fumbles are rolled" | FC-54 B | The only automated "whilst casting" is extra casting time (`magic/pending-cast.mjs`, page 238). Its interruption fires from `preUpdateActor` on a `setTimeout` and settles at once (`pending-cast-workflow.mjs` L310–325). An ordinary cast's provoked reactions are table-adjudicated ("a cast's provoke is adjudicated at the table", `cast-workflow.mjs` L3518). Helpers `spendReaction`, `reactionRefusal`, `rollWeaponAttack` | **C.** Inside an extra-casting-time window, offered (`askReactor`) when an adjacent creature's Strike damages you (`trgPrimeDamageApplied` with `sourceUuid`). AoO via `rollWeaponAttack` after `spendReaction`. Its ordering before the interruption's Failure/Fumble needs S6s-7. Otherwise (a provoked AoO on an ordinary cast): a reaction Use button against the targeted attacker. The cast's failure is the table's call, as the core's is (n6) | S6s-7 (optional) | Q?-9 |
| Metamagic Adept | 3794 | FLOURISH SORCERER / BSB +4; Req: "Must have the feat that you are emulating" | Extend, Reach, Silent or Still "by expending an additional AP instead of increasing PP cost", one spell; only 1–2 AP casting times; "the DC to cast the spell is still increased … (as if the additional PP had been expended)" | FC-57 B, D2 | Core options are a hard-coded table keyed by feat name (`magic/metamagic.mjs` `buildMetamagicOptions` L61; extend L185, reach L233, silent L247, still L263, each 2 PP). A rod option is 0 PP and adds no DC (L294). The casting DC is read from `totalPP` (`cast-workflow.mjs` L1767, L2473 `assembledCastingDC`). `apDelta` exists (L378) | **B** with D2: per owned feat, an "Adept" variant of the core option (n7) | D2 (n7) | — |
| Resonance Surge | 3938 | FOCUS SORCERER / BSB +3, Wild Birthright | "automatically warp a spell … by 2 PP without expending the additional PP or increasing the casting DC". "automatically trigger a Resonance Event (which is resolved after the effects of the spell you cast)" | FC-65 A, D5+D6 | A free-warp credit exists only scoped by trait (`warpFreeSchool`, `cast-workflow.mjs` L1582–1600, `applyFreeWarp`). Being outside the paid PP, it is outside the DC too. `helpers.rollResonanceEvent` honours suppressors. Focus: one use, Refocus | **B.** Focus Use "arm for the next spell": a one-cast effect `warpFreeSchool {school:"*", value:2}` (S6s-5). The module removes it when the next levelled cast settles. Then `rollResonanceEvent(actor, {reason:"Resonance Surge", modifiers:{pp, highMagic}})` after the spell's card | S6s-5 | Q?-2, Q?-8 |
| Spellblade's Mark | 4092 | CONCENTRATE FOCUS INVOCATION SPELLBLADE / Level 6; 1 AP | One enemy within 60 ft, until end of encounter or a new Mark. Against it: +1 circumstance to "melee Strikes and spell attacks"; "Your attacks against your Mark deal 1d6 secondary force damage"; +1 circumstance DB against its attacks | FC-78 A (moduleMark + COND; Spellstrike part waited); EA-M26 ruled: "Spellblade's Mark becomes 1d6 secondary force" (v1.6 prints it) | Conditional `targetUuids` on weapon attacks (`conditionals.mjs` SCOPE_AXES; filled at `attack-workflow.mjs` L1463). Ward DB by attacker uuid on weapon attacks (`magic/ward.mjs` `wardFlagData`, read at `attack-workflow.mjs` L2446). `strikeDamageRider` has `targetUuids` but adds dice **in the weapon's type** (`combat/damage-riders.mjs` header). `strikeRider` is typed but has no target axis. `spellDamageRider` has no target axis. A spell attack's check carries no `targetUuid` (`castContext` L1400), and its DB reads no ward (`resolveSpellAttack` L5834–6020) | **B** with S6s-6 (n8): 1 AP Focus Use, the targeted enemy within 60 ft (`distanceBetween`), Concentrate gate. One effect carries four parts: (1) melee attack conditional; (2) spell-attack row; (3) typed force rider on Strikes and spell attacks; (4) ward DB. Removed at combat end or on a new Mark | S6s-6 | — |

##### Notes

1. **Arcane Study's book.** It cannot be the core's: `learnSpellRoute` (`magic/arcanist-book.mjs` L266) knows only the class book and the Arcanist's archetype book, and the archetype-casting table is hard-coded (`archetype-casting.mjs` `archetypeCastingSources`). So:
   - the book is a module flag holding compendium uuids;
   - "Scribe a spell" uses Learn a Spell's time, price, check (Arcana) and degree outcome, as Block 4's runes do (Q46);
   - it is limited to the arcane tradition and to a PP the caster could cast (`bookAdditionEligible`'s rule, re-stated);
   - the day's pick is created as Wild Power's spell is (`grantedBy` the feat, so it is not counted against the repertoire schedule) and deleted at the next daily preparation;
   - the warp discount is +1 on the known spell's `warpDiscount`, recorded and taken off at the next preparation, so a Menora discount on the same spell is kept.
2. **Bespell Weapon's sustain.** The core's Sustain a Spell sees only active spells (`data/special-actions.mjs` L62). So the feat's effect gets its own Sustain button: 1 AP, Concentrate, on your turn while the effect lasts. It extends the effect to the end of the turn and keeps the type. "Alternative physical damage type" is read as bludgeoning, piercing or slashing other than the weapon's own. A spell with no school trait (a Grimoire High Magic spell, M29) gives no type; it is refused with a card line.
3. **Bonded Infusion's focus** is answered as a spell-check gate rather than a seam, because item bonuses stack highest-only: the core's +1 and the gate's +2 give +2. High Magic sets a focus aside (`highMagicFocusSetAside`), and the gate does the same when `ctx.highMagic` is set and no `highMagicFocus` item is owned. "Equipped" is the core's held state.
4. **Call Bonded Weapon.** Equipping goes through the item update, so the core's hand checks (`held-items-workflow.mjs` `canEquip`) still apply. A weapon on another creature's sheet is a GM's move; the card says so. Counted as A: that case is rare and has no rule to automate.
5. **Clever Damage.** Proper Hardman's ×1.5 stays Strength-only, as the core's comment for Dex says (L5502). Rage's +2 to Strength-based damage (`isStrengthBasedAttack`) is not added when Int is used.
6. **Magical Retribution, why C.** For an ordinary cast, the system has no moment "whilst you are casting": the cast resolves in one flow, and its provoked reactions are adjudicated at the table. Extra casting time is the only window the core models, and only its interruption knows the cast was struck.
7. **Metamagic Adept: what it needs from D2.** For each of Extend, Reach, Silent and Still that the caster owns, an option that:
   - (a) has the core option's effect (`kind`: extend, componentOff, the reach note);
   - (b) costs 0 PP and `apDelta +1`;
   - (c) adds the feat's PP (2) to the PP the **casting DC** is read from only: a "dcPP" that is neither paid, nor capped, nor in the save DC. Under 10 + ⌊1.5 × PP⌋, a fixed `dcDelta` would be wrong by 1 on half the spells;
   - (d) appears only when the spell's casting time, after its own warps and before this AP, is 1 or 2 AP;
   - (e) is exclusive with the core option of the same feat, and allows only one Adept variant per cast ("any one … to any one spell");
   - (f) is refused once a Flourish has been used this turn (`helpers.traitCheck`), and records the Flourish when the cast settles (`recordTraitUsage`), in combat only.

   So D2 needs an `applies(ctx)` (actor, spell data, cast AP, combat state), a `dcPP` field beside `ppCost`/`apDelta`/`dcDelta`, an exclusivity group, and an `onSettled`. The variant is built off the core's own option, so it needs either a handle on the core option of that id or the option's `kind`.
8. **Spellblade's Mark, without S6s-6.** Parts 1 and 4 work against weapon attacks today. Part 2 would be a tick-box, and part 3 would deal its die in the weapon's type, which is not what M26 ruled. That would grade C. "An encounter" is read as the combat the Mark was made in. A Mark made outside combat lasts until the next combat that includes you ends, or until you Mark again.

##### Proposed core seams

- **S6s-1 — a module's answer to a feat's eligibility.**
  - **What:** `registerFeatEligibility(featName, (actor) => null | reason)`. A reason hides the feat in the picker (`picker-filters.mjs` `withFeatGates` L801) and refuses its creation (`TRGItem._preCreate`, beside `exclusiveFeatRefusal`, `module-api.mjs` L705).
  - **Why:** the prerequisite parser fails open by design, and "<X> Birthright" names an ability called "<X>". The module knows which item is a birthright (`eaBirthright`) and how High Mage and Birthrager record their pick.
  - **Users:**
    - Arcane Study (Arcanum);
    - Resonance Surge (Wild);
    - High Magic Resonance ("cannot take" with Wild);
    - Block 6's Blood of the Wyrm, Eternal Vigil, Runebreaker, Shade Master and Stormcaller.
  - **Without it:** the module refuses through its own `preCreateItem` hook, but the picker still offers the feat.
- **S6s-2 — declared melee abilities.**
  - **What:** `flags.trg-prime.meleeAbility = { attack: ["intelligence"], damage: ["intelligence"] }` on a feat, ability or effect. Read beside Finesse: the Strike's attack row takes the best of the current ability, finesse Dex and the declared ones (`attack-workflow.mjs` L1630 `finesseAdjustment`). The damage step's `strengthMod` takes the best of the same (L5497–5508).
  - **Users:** Clever Strike, Clever Damage.
  - **Without it:** a dynamic module row would stack with Finesse (Dex − Str plus Int − Str), so the module cannot do it correctly.
- **S6s-3 — a spell damage bonus valued at the spell's PP, for instantaneous spells.**
  - **What:** on a C1 `spellDamageBonus` row, `valueFrom: "spellPP"` and `instantOnly: true`. `declaredSpellDamageBonuses` (`magic/spell-damage-bonus.mjs`) is handed the spell's PP and whether its Duration is blank, at its two call sites (attack path L5771, save path).
  - **Users:** Dangerous Sorcery.
  - If Q?-6 answers "PP paid", the value is the cast's `totalPP` instead.
- **S6s-4 — High Magic's Resonance rolled once (the D6 part these feats need).**
  - **What:** `registerResonanceModifier(key, ctx => ({ cancelHighMagic, disadvantage, modifier, lines }))`, asked in `rollResonanceEvent` (`cast-workflow.mjs` L7505) with `{ actor, reason, modifiers }`. `cancelHighMagic` removes only the disadvantage that `modifiers.highMagic` brings. A `disadvantage` from another source (Spell Surge) still applies.
  - **Users:** High Magic Resonance; Spell Surge (general reviewer); the Wild Mage's 13.
  - **Smaller alternative:** an owner flag `flags.trg-prime.highMagicResonanceSingle` read at L7536.
- **S6s-5 — a free warp on any spell.**
  - **What:** `warpFreeSchool.school: "*"` matches every spell (`cast-workflow.mjs` L1585). Nothing else changes: `applyFreeWarp` already waives the PP, and so keeps them out of the DC.
  - **Users:** Resonance Surge; D5's ley-line "free 2-PP warp".
  - **Without it:** the PP could be refunded after the cast, but the DC would then have counted them.
- **S6s-6 — the Mark's four target-scoped parts.**
  - (a) `strikeRider.targetUuids`, resolved by `riderPacketsFor` (`magic/strike-riders.mjs` L570) from the strike's target. It is the typed secondary packet already used for Talon Strike.
  - (b) `spellDamageRider.when.targetUuids` and `when.attackOnly` (`magic/caster-damage-riders.mjs`). "Your attacks" means no save spells.
  - (c) A spell-check gate row may say `attackOnly: true`: left out of the casting check, and added to the spell attack's stacked pool (`resolveSpellAttack`'s `extraAttackRows`, L5897). The gate ctx gains the targeted uuids.
  - (d) A spell attack's DB reads the target's ward rows against the caster's uuid (`defenceDCBonus(target, "defence", …, caster.uuid)`), as `attack-workflow.mjs` L2446 does for weapons. This is a core gap in its own right: Forbidding Ward does not apply against spell attacks today.
  - **Users:** Spellblade's Mark; (d) also the core's own wards.
- **S6s-7 (optional) — a step before a pending cast's interruption settles.**
  - **What:** `interruptPendingCast` (`pending-cast-workflow.mjs` L258) awaits registered steps (`{ actor, record, sourceUuid }`) before `settle`. The damage path hands the source when it knows it.
  - **Users:** Magical Retribution ("resolved before any potential spell fumbles are rolled").
  - **Without it:** the AoO is offered after the interruption's Failure or Fumble card.
- **S6s-8 (only if Q?-1(c) is "each option") — a per-option warp discount.**
  - **What:** a spell's `warpOptionDiscount: n` lowers each chosen warping option's PP by n, min 1 each, in `aggregateWarpSelection` (`magic/spell-warp.mjs` L642).
  - **Users:** Arcane Study.
- **D2** (another reviewer's design): Metamagic Adept's requirements are n7 (a)–(f). The one field D2's proposed shape lacks is a **DC-only PP** (`dcPP`), because the casting DC is read from PP, not stepped.
- **Not needed:**
  - D5's cost/discount half: Arcane Study uses the existing per-spell `warpDiscount`, unless S6s-8 is chosen.
  - D10 and D12.

##### Questions

- **Q?-1 — Arcane Study: the book, the day, and "all warping costs".**
  - **The book:** "You gain a spellbook similar to that of a wizard that you may scribe arcane spells into. During your daily preparation, you may select any one of these spells and add it to your spell repertoire … you may instead lower all warping costs (min 1 PP) for that spell by 1."
  - **Why it matters:** the Wizard's book starts full and grows free each level, so the feat's value turns on what the book starts with. The pick's duration and the discount's size both change play.
  - **Proposed:**
    - (a) The book starts empty. Spells go in only by scribing, at Learn a Spell's time, price and check (Arcana), arcane spells of a PP you could cast.
    - (b) The pick (or the discount) lasts until your next daily preparation.
    - (c) The discount comes off the spell's total warp, min 1: the core's reading of Menora's "costs one less PP to Warp", with no core change. The alternative is that each warping option chosen costs 1 less, min 1 each: stronger, and it needs S6s-8.
- **Q?-2 — Birthright prerequisites for High Mage and Birthrager.**
  - **The book:** Arcane Study needs "Arcanum Birthright" and Resonance Surge "Wild Birthright". High Magic Resonance: "a Sorcerer with the Wild Birthright cannot take this feat". High Mage and Birthrager each "select any one Sorcerer birthright" and may take Sorcerer feats.
  - **Why it matters:** it decides whether a High Mage or Birthrager can take Arcane Study, and whether one who chose Wild is barred from High Magic Resonance.
  - **Proposed:** an archetype's birthright pick counts as having that birthright for these prerequisites and for the bar. A High Mage who picked Arcanum may take Arcane Study.
- **Q?-3 — Bespell Weapon: when, and what sustaining costs.**
  - **The book:** "As a free action, you siphon the residual energy from the last spell you cast … Until the end of your turn … You may sustain this feat each round to continue inflicting the damage for another turn."
  - **Why it matters:** if "the last spell you cast" means any earlier turn, the feat is free 1d6 every turn after one cast. Sustain's price sets its AP economy.
  - **Proposed:**
    - Usable on the turn you cast the spell, cantrips included.
    - Sustaining is 1 AP with the Concentrate trait (as Sustain a Spell), taken on a later turn. It keeps the same type, until you stop or cast a new spell and Bespell again.
- **Q?-4 — Bonded Infusion and a Spellblade who is not a focus caster.**
  - **The book:** "Your infused weapon becomes a casting focus item which grants a +2 bonus instead of the usual +1."
  - **Why it matters:** the core's casting focus is a creation-time choice ("Caster" tick: +1 with it, −2 and +10 to fumbles without it). Read strictly, a Spellblade who did not choose focus casting gains nothing.
  - **Proposed:** while you wield the infused weapon, your casting check has +2 item, whether or not you are a focus caster. Only a focus caster suffers the −2 and +10 without it, as now. The weapon also stands in for the somatic component, as a held focus does.
- **Q?-5 — Considered Attack: how much, and what kind.**
  - **The book:** "You may increase the amount of AP you use when making a Strike action to increase your attack bonus by +2."
  - **Why it matters:** read as "+2 per extra AP", a 3-AP Strike is +4. No bonus type is printed.
  - **Proposed:** once per Strike, 1 extra AP for +2, untyped (as printed, no type).
- **Q?-6 — Dangerous Sorcery: "its PP cost".**
  - **The book:** "a status bonus to damage equivalent to its PP cost."
  - **Why it matters:** a Sorcerer warps nearly every spell (Raw Power), so the printed cost and the PP paid differ by several points.
  - **Proposed:** the spell's printed PP cost, so a cantrip adds 0. Warps and metamagic do not raise it. "Without a duration" means the spell prints no Duration entry.
- **Q?-7 — High Magic Resonance: which fumble, and "first".**
  - **The book:** "you may treat the first spell fumble that you make each day as a spell fail."
  - **Why it matters:** the casting check has a Blunder below Fumble, and "first" decides whether declining keeps the use.
  - **Proposed:**
    - The first casting check with a **Fumble** degree each day (to the next daily preparation) becomes a Failure: half PP, no fumble roll. It is applied automatically, since no one would decline it.
    - A Blunder is not eased.
    - "Only roll on the resonance table once" removes High Magic's disadvantage only. Absolute Chaos (UM 66) still rolls twice more.
- **Q?-8 — Resonance Surge: what the 2 PP may buy.**
  - **The book:** "automatically warp a spell that you are casting by 2 PP without expending the additional PP or increasing the casting DC … automatically trigger a Resonance Event."
  - **Why it matters:** it decides whether metamagic counts, whether a 1 PP warp wastes the rest, and how the forced Resonance is rolled.
  - **Proposed:**
    - The credit pays up to 2 PP of the spell's own warping options (the core's free-warp channel). Any excess is paid as usual, and an unused part is lost. Metamagic feats are not covered.
    - The Resonance is rolled after the spell's card as any High Magic Resonance of that cast: with disadvantage, and none in a suppression area (core suppressors).
    - The Focus use is spent when armed.
- **Q?-9 — Magical Retribution outside extra casting time.**
  - **The book:** "Trigger: A creature within melee strikes you and inflicts HP damage whilst you are casting a spell."
  - **Why it matters:** the system models "whilst casting" only for extra casting time (page 237's window). An ordinary cast's provoked attacks are adjudicated at the table.
  - **Proposed:** automated in the window, before the interruption resolves (S6s-7). Elsewhere it is a reaction button, an AoO against the attacker, used when the table rules that the provoked Strike landed during the casting.

##### Waits on other blocks

- **Metamagic Adept** waits for D2, which is built in this block. Until then it ships as a text item saying so, so the item exists for any chain.
- **Resonance Surge, High Magic Resonance's single roll, Spellblade's Mark's spell-attack parts, Clever Damage and Clever Strike, and Dangerous Sorcery** wait for their seams (S6s-2 to S6s-6), not for another block. The core release that carries D2 can carry them.
- Nothing here needs Block 7–10 content: no catalyst (D3), charged item (D12) or Grimoire spell.

##### Minor

- **Considered Attack** prints "CLASS MARTIAL". "Class" is the feat's category, not a trait. Proposed: built with Martial only.
- **Call Bonded Weapon's** "Blade Ally or Infuse Weapon" passes open (an "or" clause), but Weapon Focus and BAB +8 gate it. Every Crusader with BAB +8 has a Divine Ally, though not always Blade Ally; the card says when no bonded weapon exists.
- **Bonded Infusion** prints no prerequisite. A character who reaches Spellblade feats without Infuse Weapon (through an archetype) gains nothing; the item says so.
- **Spellblade's Mark's** v1.4 Spellstrike +1d6 (EA-M26) is gone in v1.6. Nothing waits on Spellstrike here.
- **"+1-spell adder"** (Bonded Infusion) has a stray hyphen. It reads "+1 spell adder".
- **Metamagic Adept:** "Spells" is capitalised mid-sentence ("only applies to Spells which have"). Also, Extend, Reach, Silent and Still are core Adept-tier class feats (traits "Adept, Metamagic"), and the Sorcerer must own the one emulated. The PP the DC is read from are not counted against the per-cast cap.
- **High Mage's Focus** says "casting DC". Under B1-5 (built as proposed), it is a +2 on the casting check, left out of the spell attack.
