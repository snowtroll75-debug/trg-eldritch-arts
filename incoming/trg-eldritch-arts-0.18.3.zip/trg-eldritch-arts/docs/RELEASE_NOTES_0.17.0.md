# Eldritch Arts 0.17.0: Block 10a, relics and sentient items

15 November 2026. **Needs TRG Prime 3.693.0.** Chapter 9's four relics and the example sentient item, Dawnshield, with Chapter 4's Relic Bonding Ritual. Graham answered the Block 10 audit's eleven questions (Q211–Q221) and approved the two core seams (H27, H28): "Go with your recommendations". Block 10b (the sentient-item roll tables and the rules journal, Q219 and Q221) follows as 0.17.1.

## The new pack: Relics & Sentient Items (`ea-relics`)

The Aegis of Valtea, Emberfang, the Obsidian Codex, the Veilshroud and Dawnshield. Each prints its book text in full, then a line saying what is automated. A relic ships as its plain Dormant item: unbonded, uninvested and without powers.

## How a relic works now

1. **Bond it.** The Relic Bonding Ritual is a general skill action (Arcana, Nature, Occultism or Religion, trained).
   - Target the wielder to bond it to them; with no target it is bonded to you. A priest can bond a holy relic to a champion.
   - **The DC** is the Level DC of the wielder's level (Q211). **The performer pays** the 1 PP and 250 gp, whatever the result (Q212).
   - **Critical** (and Heroic): bonded, and it awakens at once to Awakened if the wielder is level 5 or higher.
   - **Success:** bonded, Dormant.
   - **Failure** (and Partial): rejected; no new attempt for 24 hours.
   - **Fumble** (and Blunder): 1d6 essence per level of the performer, basic Fortitude at the same DC, on the performer; no new attempt for a week.
2. **It awakens.** At each of the wielder's daily preparations it advances one tier, until it reaches the tier of the wielder's level.
3. **Invest it.** Invest Item asks which tier to invest it at, up to its awakened tier, as the free slots pay (1 slot for Dormant up to 5 for Legendary). Only its bonded wielder may invest it, and RELIC is one-invested.
4. **The tier, applied** (Q215). Invested, the relic's quality, superior trait and runes are rewritten to that tier, through TRG Prime's own customisation (so its HP and weight follow). Its innate spells are granted with the focus trait, and its powers are granted as abilities. Ending the investment takes them all away and returns the plain Dormant item.
5. **Its level is the wielder's** (Q213). TRG Prime reads an item with no level that way for an innate spell's DC and attack.

At a daily preparation, an invested relic's tier also rises to the highest the free slots now pay for, unless you chose a lower tier when you invested it.

A relic's focus spells are one use each, and Refocus regains them, as TRG Prime's focus spells do. Their spent uses survive a change of tier and a fresh investment, until the next daily preparation.

## The relics

| Relic | Automated | By hand |
|---|---|---|
| **The Aegis of Valtea** (shield) | The shield per tier (expert lightweight light steel; Potency I → III; Benevolent from Awakened). Light, Cure, Restoration, Forbiddance and Heal. The fear-and-curse aura: you and allies within 10 ft, +1 item to saves (Q214). Essence resistance, then immunity. **Shield of Dawn** once a day (2 AP): you and allies within 30 ft gain Fast Healing 10 and advantage on saves against aberrations, eternals and undead, for 1 minute. | Shield of Dawn's denial of concealment and invisibility to Evil-aligned enemies. |
| **Emberfang** (broadsword) | The sword per tier (expert balanced, master from Empowered, legendary at Legendary; Potency I → V; Flaming I → III). Light, Burning Hands, Fireball and Meteor Swarm (TRG Prime's allowance for its PP). Fire resistance, then immunity. | — |
| **Obsidian Codex** (book) | Never a Good wielder; the blood sacrifice is asked before the ritual. **Dissonance** (disadvantage on Will saves) for a Balance- or Order-aligned wielder while bonded, invested or not (Q220). +1 item to Spellcraft for Soul spells. Detect Undead, Chill Touch, Animate Dead, Undead Binding (with TRG Prime's allowance of 3), Vampiric Touch, Create Undead and Hand of the Reaper. Advantage on saves against fear, −1 status against divinity-tradition spells. Essence resistance, then immunity. | Detect Undead's constant effect. The +2 HP per level of undead you create or bind, and their advantage on attacks against the living (Q217), are card notes. The whispering lore and the Necrolord's recognition. |
| **The Veilshroud** (cloak) | +1 item to Stealth. Darkvision, or Perfect Darkvision if you already have Darkvision. The Veil I rune (Block 9b's Veil). Cloak of Greying, Misty Step, Invisibility, Dimension Door and Gate (once a day, with TRG Prime's allowance of 3). Essence resistance, then immunity. **The shadow step** once a day (2 AP): teleport up to 60 ft between spaces of light level 2 or lower. **At Legendary**, essence is ignored and heals you by half (TRG Prime 3.693.0's H28). | Tracking you at disadvantage (the tracker's roll). The planar ripples, the Shadescape disguise, and the cloak's semi-sentience: communication only, without Ego (Q216). |

## Dawnshield

- **Investing it costs two slots** (L10441), and SENTIENT is one-invested.
- **Invested**, it grants the morale-steadying light (you and allies within 10 ft, +2 to saves against fear) and Cure once a day as an innate spell. It is cast at the wielder's level (see For Graham).
- **Its +2 DB against fire** is TRG Prime's own Dragonhide shield bonus: the pack records it as fire-dragon hide.
- **Influence** is a button on the wielder that only the GM presses (Q218). It rolls the wielder's Will save against Ego DC 34 and prints the degree, using Dawnshield's own Success, Failure and Fumble.
  - A Critical suppresses it for 24 hours, and a Fumble allows a new check after an hour.
  - **A Failure dims it:** its powers are withdrawn until the GM presses the same button to restore them after a protective act.
- **By hand:** the constant Light, the revealing light, the darkness-dispelling flare, its senses and its voice.

## Readings to know about

- **Shadow step.** TRG Prime reads the light where a token stands. So the cloak checks your space, moves you, and then reads the space you landed in. If that space is brighter than level 2, you are moved back and told so. The AP is spent, but the day's use is not.
- **Shield of Dawn** is laid on you and the allies within 30 ft when you invoke it, for the minute. An ally who arrives later is not added.
- **A relic bonded to someone who does not carry it** gains its Dissonance and powers when it reaches them. Until then it does nothing.
- **A relic handed or copied to another creature** arrives uninvested there, and it has no powers for anyone but its bonded wielder.
- **The performer must be able to write to the relic.** A player bonding a relic for another player's character holds it during the ritual and hands it over afterwards. If the relic stays with its future wielder, that player or the GM rolls. Either way the refusal comes before anything is paid.

## For Graham

- **Dawnshield's Cure is cast at the wielder's level, not the shield's 15.** The book says the shield "can independently cast" it. TRG Prime reads an item's level for a granted spell only through a Spell Effect rune's or a wondrous item's own record, and its upkeep would delete a spell granted that way here. Shall TRG Prime also read the level of the item that granted a spell (a one-line seam for 0.17.1)? Until then the GM can adjust the DC by hand.
- **The Codex's "constant" Detect Undead** is granted as a focus spell like the others, so it is one use and Refocus. Should it be at will instead ("unlimited")?

## The harness

- **New pair `verify-block10`** (116 checks) and **`mutate-block10`** (92 mutations, all caught). Writing the harness found that the Codex's Good refusal and its Dissonance looked up the relic by the wrong key. That is fixed. Each actor's relic rewrites now also run one at a time, so a hook and the write that caused it cannot both rebuild the grants.
- **Found in the independent review, and fixed:**
  - Relic spells now write the Focus trait themselves. TRG Prime already adds it when a granted innate spell is created, as the second round confirmed, so this is belt and braces.
  - A bond the performer cannot write is refused before the PP and gold are paid.
  - A GM's daily preparation of a player's character now awakens its relics.
  - A traded relic no longer keeps its powers.
  - Spent uses no longer come back when a relic is rewritten.
  - A tier chosen lower is kept.
  - A deleted relic can no longer leave grants behind.
  - A damaged relic shield keeps its damage when rewritten.
  - An unknown bonding degree reads as a Failure, not a Fumble.
  - The Veil-Drinker now answers for a whole cast, so a later essence packet is drunk too. TRG Prime 3.693.0 heals each packet at its own amount.
- Seven older mutation files were re-anchored for the new pack in the pack list.
- `verify-block1`: the new pack in the folder and pack list, and the three Uses on granted abilities.
- Manifest pins raised to 0.17.0 on TRG Prime 3.693.0.
- **All 28 module verifiers** pass on TRG Prime 3.693.0, and **all 27 mutation files** catch every mutation.
- **Independent review**, two rounds. The fixes above came from the first. The second found that clearing the kept uses with `setFlag` merged rather than cleared; it now uses `unsetFlag`, and the harness's stub merges as Foundry does.
