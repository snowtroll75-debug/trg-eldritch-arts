# Eldritch Arts 0.1.0 — Block 1

28 October 2026. Chapter 2's races, heritages, racial abilities and backgrounds; the nine Eldritch Arts feats the backgrounds grant; the core racial feats opened to the new races; Chapter 4's skill actions; Orb of Water; Chapter 6's exotic weapons and goods.

- **Install TRG Prime 3.675.0 first,** then this module. 0.1.0 warns at start-up on an older system.
- **No migration.** Nothing in an existing world changes until you add one of these items.
- **Built as proposed** in `docs/ELDRITCH_ARTS_BLOCK1_AUDIT.md`. Questions B1-1 to B1-22 are open for you; each item names the question it depends on.
- **Nothing is pushed or published.** The GitHub repo `snowtroll75-debug/trg-eldritch-arts` still has to be created.

## What is in it

| Pack | Items |
|---|---|
| Eldritch Arts: Races | Aetherial, Emberkin, Nyrinn, Scaelyn |
| Eldritch Arts: Heritages | 18 (five, four, three and six) |
| Eldritch Arts: Abilities | 12 racial abilities, including Vir-ellian Release |
| Eldritch Arts: Backgrounds | 12 |
| Eldritch Arts: Feats | the 9 the backgrounds grant |
| Eldritch Arts: Spells | Orb of Water |
| Eldritch Arts: Weapons | 18 exotic weapons |
| Eldritch Arts: Gear | 31 goods and tools |

They appear in the system's own pickers under the **Eldritch Arts** sourcebook.

## What is automated

**Races and heritages**
- Attribute lines, sizes, Speeds, languages, specialist skills and Power Points per level (+1, +1, −1, +1), as printed.
- A Tiny Nyrinn and a Small Scaelyn show the printed Str and Dex on the sheet: the race item carries only what the size table does not.
- **Wyrmdral** sets Medium and replaces the Scaelyn's line. Its **Use** chooses the element: resistance, and +1 to the Spellcraft check and save DC of that element's spells.
- **Emberkin:** each heritage's resistance, element and elemental tongue (B1-1). **Elemental Surge** adds your Charisma to every spell damage roll. **Elemental Symbiosis** (Use, a reaction): immunity to your element until the end of your next turn, then weakness for a minute.
- **Aetherial:** **Ethereal Form** (Use, once a day): incorporeal for a minute. **Aetherial Resonance:** +1 to every spell save DC.
- **Nyrinn:**
  - **Null Aura** adds your class bonus to saves and DB against spells. Any Spellcraft check within 5 ft of you (10 for a Vel-tharis), yours included, takes the class bonus as a penalty against its casting DC (B1-5). An attack spell's attack against DB is not lowered.
  - **Zhal-vryn:** a creature casting within 5 ft pays 1 PP more (B1-6).
  - **Magic Drain** (Use, 2 AP, Focus): you choose what you are draining and where the +1 racial goes, then roll; the energy lasts 1 minute per PP drained (B1-8, B1-21). A Vir-ellian drains its class bonus more, and **Vir-ellian Release** spends the energy: 1d4 force per PP within 30 ft, basic Will against your Level DC (B1-7, B1-18).
- **Scaelyn:** base DR 1. **Innate Magic** (Use): today's cantrip; daily preparation reminds you that you may change it. **Glyphweave's** Use is a second pick (B1-9). Sparktail, Dustscale, Ironmuk and Wisperfin as printed.
- Granted cantrips: innate (with the Focus trait) where the book says so, otherwise cast with Spellcraft.

**Backgrounds and feats**
- Feat, skill bonuses, specialist skill, wealth.
- **Spell Penetration** lowers Spell Resilience by 2, never a Null Aura.
- **Esoteric Insight:** once-a-day fumble reroll on Arcana and Occultism.
- **Focused Ley Sense:** Ley Sense's five-rung ladder.
- **Elemental Affinity** (Use per copy) and **Wanderer's Instinct** (Use, once a day).
- **Disrupt Magic:** +2 on Dispel.

**Chapter 4**
- **Ley Sense:** trained only. A Failure locks it for 10 minutes; a Fumble costs 1 PP and locks it for an hour.
- **Appraise Magic** and **Quickbind:** 5 ranks.
- **Hypnotism** is two actions, against the subject's Will DC:
  - **Implant Suggestion:** the unwilling rung at +10.
  - **Memory Recall:** the bonus put on the subject's next Recall Knowledge.
  - A Failure bars that subject until the next day.
- **Mysterious Script:** once a week.
- **Quickbind** invests the item and keeps "one check per item per day".
- **Lingual Casting** is a new line in a scroll's release dialog: Very Hard, with the rank requirements checked.

**Chapter 6**
- Every weapon's table numbers and traits.
- **Adept** weapons are Simple for an Adept class.
- A racial or heritage trait makes a weapon Martial for that race (the Clamhscrios for a Wyrmdral).
- Goods' bonuses are offered as a tick on the roll while carried.

## What is not automated yet, and why

- **Null Aura's beneficial-spell save** has no type or DC (EA-C1). The GM is whispered a reminder when a spell is cast at a Nyrinn.
- **Ley Line Connection, Spell Surge, Ritual Expert, the Ritualist trait and the ritual, circle and zone goods** need High Magic, ley lines and rituals (Block 2, Block 3). Their cards say so.
- **Brace** on three weapons is held out of their trait line until you rule (B1-12). The core's Brace is another book's rule.
- **What Ley Sense, Appraise Magic and Mysterious Script reveal** is the GM's to say.
- **Who sees which dialog.** When the GM sets an action's DC, its result is settled on the GM's screen. So Quickbind's "which item?" and Magic Drain's "the effect's PP" open for the GM. The GM knows the effect's PP anyway. Magic Drain's own choices are asked of the player before the roll.

## What to test live

1. Add each race to a fresh character. Check the attribute line, size, Speed, PP per level and the granted abilities, spells and skills. Then add each heritage (Wyrmdral: Medium, and its own line).
2. Nyrinn beside a caster: the penalty on the caster's card, 5 ft and 10 ft for a Vel-tharis. A Zhal-vryn beside a caster: 1 PP more.
3. Magic Drain on a wand, then Vir-ellian Release with tokens at 30 and 35 ft.
4. Elemental Symbiosis: immunity, then weakness when the turn ends.
5. Focused Ley Sense: the five rungs. Esoteric Insight: a fumbled Arcana check.
6. An Adept class with the Bachall Fáistine; a Martial Emberkin with the Brikail Naomhtha.
7. A scroll's release dialog: Lingual Casting with and without the ranks.

## Harness

- **`verify-block1`:** 866 checks: the book's text and numbers, the system's readers, grant names, registration against the system's own registry, and the Uses driven with stand-ins.
- **`mutate-block1`:** 73 mutations, all caught.
- **An independent review** of the runtime code found ten things, all fixed before release:
  - Null Aura's penalty also lowered spell attacks against DB (core C10).
  - A Ley Sense Partial locked nothing.
  - Magic Drain's choices opened on whoever settled the result.
  - A drain on another creature's item failed on a player's client.
  - Magic Drain's DB bonus was untyped.
  - Its energy lasted 1 minute per energy instead of per PP drained.
  - Quickbind skipped Invest Item's one-Staff and slot rules (core C11).
  - Wanderer's Instinct was pre-ticked on every Survival check.
  - "Until the end of your next turn" had no backstop when combat automation is off.
  - Vir-ellian Release dropped its energy if the blast failed.
  
  Two points it raised are now questions: B1-21 and B1-22.
- **TRG Prime 3.675.0** has its own pair (`verify-ea-block1-core` 71, `mutate-ea-block1-core` 53) and the sweep; see its release notes.
