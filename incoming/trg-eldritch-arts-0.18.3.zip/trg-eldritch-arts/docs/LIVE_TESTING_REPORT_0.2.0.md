# Eldritch Arts 0.2.0 on TRG Prime 3.677.0: live test

1 November 2026, world "TRG V14", Foundry 14.367, as Gamemaster.

**Setup and cleanup.**
- **Actors:** throwaway "ZZ EA …" actors on a throwaway scene, "ZZ EA Scene". The caster was a copy of Borin Slatevein; Borin himself was not touched.
- **Dice:** fixed through `CONFIG.Dice.randomUniform` where a result was needed, and restored afterwards.
- **Cleanup:** the 8 test actors, the scene and the 29 test chat cards were deleted, and the view was returned to Oldwatch Approach.
- **Console:** no errors or exceptions. Only Foundry deprecation warnings appeared (Simple Calendar, and one from the test script itself), and no Eldritch Arts warnings.

**Loaded.** TRG Prime 3.677.0, Eldritch Arts 0.2.0. The system lists the module among its companion content. All eight packs are present: 4 races, 18 heritages, 12 abilities, 12 backgrounds, 9 feats, 1 spell, 18 weapons and 31 goods. The module raised no version warning.

## Passed

**Null Aura's beneficial-spell save (C1, C14).**
- **Granting:** adding the Nyrinn race granted Null Aura carrying `beneficialSpellSave {Null Aura, other casters only}`.
- **Resistance (targeted), all dice 19:** "ZZ EA Nyrinn — Will Save, to accept Resistance — DC 17 — success lets it affect you", a Success. The result card said "accepts Resistance (Will 19 vs 17) — Null Aura disrupts beneficial magic, but this takes hold normally". The Nyrinn got +1 resistance to Will.
- **Resistance (targeted), the caster 19 and every later die 2:** "rejects Resistance (Will 2 vs 17) — Null Aura disrupts it, and the spell has no effect on them". "Resistance finds nobody to affect", and no effect was applied.
- **Null Aura's casting penalty** still applied to the caster 5 ft away: −2 on the check, left out of attacks.

**Esoteric Insight on a Failure (v1.6, C12).**
- **A failed check is offered the reroll:** an Arcana check of 8 against DC 16, a Failure, asked "You failed the skill check. Use Esoteric Insight (its use)…". Taken, the card read "Esoteric Insight: the failure is rerolled — Success (19) stands, even if worse". The use went to 0.
- **No use left, no offer:** a second failed Arcana check made no offer.
- **What the installed code answers** (Arcana Partial, Stealth Failure, Occultism Failure): no, no, yes.

**Racial weapons one category easier (m64, C13).**
- **A Dwarf Cleric:**
  - A test Martial weapon with the Dwarf trait is proficient: "simple weapon proficiency (a Dwarf weapon, simple for a Dwarf)".
  - The same weapon with the Elf trait is not proficient.
  - The core Zokarrin (Exotic, Dwarf) is now Martial for a dwarf, so a Cleric is not proficient with it, as before.
- **A Nyrinn:**
  - **Fighter:** the Scáthfán is proficient, "martial weapon proficiency (a Nyrinn weapon, martial for a Nyrinn)".
  - **Cleric:** the Scáthfán is not proficient (Martial).
- **The note:** the Scáthfán's description carries its "one category easier for a Nyrinn, so martial" note.

**Glyphweave (m5).**
- **The heritage:** a Scaelyn with Glyphweave got Scribers Chant as an innate spell.
- **The Use:** Glyphweave's Use offered "Spell to gain". Burst of Speed came as an innate PP 0 cantrip with the Focus trait.
- **Daily preparation:** it posted one card, for Innate Magic only: "A new day: you may choose a different cantrip. Press Use on Innate Magic, or keep yesterday's."

**Smaller v1.6 changes.**
- **Umbryth:** an Aetherial given the heritage had cold resistance and Cloak of Greying.
- **Hypnotism:** its unwilling option reads "Indifferent or worse (Incredibly Hard, DC +10)".
- **Spirit Binder:** wealth 0, with no "missing row" note.
- **Ord ua na Tuama:** Large.

## Found

**F1 — a beneficial *emanation* reaches a creature that rejected it (core; also affects the Ascendan).**
- **Cast:** Protective Ward (an "allies" emanation, 10 ft) with the Nyrinn and an ally inside it.
- **The card was right:** "ZZ EA Nyrinn: rejects Protective Ward (Will 2 vs 19) — Null Aura disrupts it, and the spell has no effect on them". The ally got +1 DB.
- **But the Nyrinn got +1 DB too.** The emanation's own membership refresh (`emanation-workflow.mjs`) adds its effect to every creature standing in the circle. It never asks the beneficial-spell save, and it doesn't know the cast's save rejected anyone.
- **Not new in 3.677.0:**
  - The same path already gives an Ascendan the help of a forbidden-tradition emanation (Bless, Protective Ward and the like) after their save rejected it.
  - Null Aura's save, at the cast, works as built.
  - It reaches only creatures that owe such a save: today, the Ascendan and the Nyrinn.
- **Proposed fix (core, for your approval):**
  - Record the cast's beneficial-save results on the emanation, as its `tested` map already records an entry save. A creature that rejected the spell is never added.
  - A creature with such a save walking in later rolls it once, and the result is remembered. This is the same rule as your 28 August ruling for Bane's latecomers.
  - **The ruling needed:** does a Nyrinn or Ascendan who walks into a beneficial emanation after the cast roll the save then, as Bane's latecomers do?
- **Ruled and fixed:** Graham ruled the same day that the save applies after the cast too. Fixed in TRG Prime 3.677.1: the circle remembers who refused it, and a latecomer who owes the save rolls it once. Eldritch Arts needs no change.

**F2 — cosmetic.** Glyphweave's chosen cantrip lists its trait as "focus" (lower case). Scribers Chant, granted by the heritage, lists "Focus". The trait is read the same either way; only the display differs.

## Not driven live this time

- **Quickbind, Vir-ellian Release and Magic Drain:** their behaviour has not changed since 0.1.0, which was driven live on 3.675.1. Hypnotism's and Quickbind's changes are text only; the harness checks them against v1.6.
- **A Nyrinn's own spell on itself:** checked by both harnesses. The test Nyrinn had no Power Points to cast with.
