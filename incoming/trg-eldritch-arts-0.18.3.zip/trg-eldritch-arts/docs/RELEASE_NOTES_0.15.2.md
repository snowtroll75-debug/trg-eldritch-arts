# Eldritch Arts 0.15.2: the rods and TRG Prime's one Rod a cast

14 November 2026. **Needs TRG Prime 3.691.0.** That release enforces "only one Rod may be used each round" within a single cast. This release connects the Block 9c rods to it.

## What changed

- **The Binding Seal, Soul's Echo and Wild Surges rods:**
  - They are no longer offered beside one of TRG Prime's rods already taken for the cast, such as a metamagic rod's power or a Rod of the Magi's draw. If one is applied anyway, it is refused on the card with the reason.
  - When taken, each names its rod (`rodItemId`), so TRG Prime counts it as the cast's Rod. A Rod of Accuracy is then not offered.
- **The Rod of Ley Resonance:**
  - It is no longer offered beside a core rod.
  - When it pays, it names itself, so TRG Prime counts it too.
- The module's own in-cast rule from 0.15.0 (one of its rods per cast, with Ley Resonance counting) is unchanged. It now also reads TRG Prime's `rodsThisCast`.

## The harness

- `verify-block9c` gains 5 checks (89) and `mutate-block9c` 5 mutations (98, all caught). One mutation was re-anchored.
- Manifest pins raised to 0.15.2 on TRG Prime 3.691.0.
- **All 27 module verifiers** pass on TRG Prime 3.691.0, and **all 26 mutation files** catch every mutation.
- The independent review of TRG Prime 3.691.0 also covered this module's side. It confirmed that the module's own in-cast rule still works beside the core's, and that a core rod which is the same item is not refused.
