# Eldritch Arts 0.15.0 — Block 9c: orbs, rods, staves and Spellhold's store

14 November 2026. **Needs TRG Prime 3.690.0** (H23 the Orb kind, H24 the rods' trait-scoped Save DC and helpers, H25 one invested per trait, H26 held spells). Chapter 9's five orbs, nine rods and five staves, in a new pack, **Eldritch Arts: Charged Items** (19), and the Spellhold rune's store, which 0.14.0 left as a card. From the Block 9 audit as Graham answered it (Q203, Q207–Q210, "Go with your recommendation", 13 November) and his answer on Spellhold ("Yes build it", 14 November). Every level, price, PP, recharge, weight and spell list is checked against the book's own entry as the pack is built.

## The orbs (5)

Orbs are TRG Prime charged items of a kind this module registers, **the Orb**:

- **Casting from one.** Cast from Item offers the orb's own ladder: **Spellcraft, Hard** (DC +2), whenever your caster level covers the spell's PP — "the spell need not be from your tradition" — with High Magic's own +2 on top for a High Magic spell (M81); or the spell's **tradition skill, Very Hard** (DC +5), with ranks at least the PP and Use Magic Device. A High Magic spell takes Arcana or your own tradition's skill (M80). Its spells may be warped from the orb's PP up to its level (Q210).
- **Recharging.** An orb regains nothing at daily preparation. Recharge Item costs 4 PP for one, without its requirements (they are not enforced on any item). The ley-line recharge (25 gp a PP, a minute each, no check) is the table's: the item card says so.
- **Charge Depletion.** A 41–65 is a **Resonant Flare**: a Wild Surge at the orb's level on everyone within 20 feet; the orb drops to 0 PP and is not broken. Any other row is TRG Prime's.
- **One at a time.** Only one item with the Orb trait may be invested (H25). An orb counts as your one wielded charged item, as any charged item does.
- **The ley-line bonus** (+1 to level 8, +2 to 16, +3 from 17) is an item bonus on Ley Sense, Tap Ley Line and Channel Ley Line, pre-ticked while the orb is held, whatever its PP (Q207). The Power Manipulation check against Leyline Anchor is a Dispel, which the bonus cannot tell apart: it is the table's.
- **Their abilities stop at 2 PP or less**, and the sheet says so:
  - **Emberlight**: fire resistance, and a +1 Spell Adder for fire spells only.
  - **Shifting Currents**: +1 item to Acrobatics.
  - **Whispering Veil**: +2 item to Hide.
  - **Shattered Veils**: a Critical Tap Ley Line gives See Invisible with its +4 PP warp (invisible creatures seen clearly) for 10 minutes.
  - **Verdant Heart** (level 13, as printed, Q207): a Critical Tap Ley Line gives Fast Healing 2 for 1 minute to you and each ally within 10 feet (another player's ally through the GM).

## The rods (9)

- **Focused Spell I–III**: Focused Spell (advantage on the casting check) from the rod, 2 PP, in the Warp? dialog on a spell up to 4 / 8 / 12 PP.
- **Quickening II**: Quicken from the rod, 2 PP, on a spell up to 8 PP that costs 2 AP (R12).
- **Ley Resonance**: a source of a cast's PP. Draw from the rod instead of your own pool; within 60 feet of a ley line each rod PP counts as 2 (the rod pays half, rounded up).
- **Binding Seal**: on a Summons spell, a casting option: casting DC −1, once a cast (Q208).
- **Soul's Echo**: on a spell with a save, a casting option: each undead target's Save DC +2 (read as each target saves).
- **Wild Surges**: a casting option: once the spell has resolved, a Wild Surge at the spell's PP, centred on you. A spell held in a Spellhold staff surges when it is stored, as its PP is drawn (Graham, 14 November 2026).
- **Catalyst Flow**: when a catalyst would be spent — after Catalyst Conservation's check (Q209) — you are asked whether to keep it for 2 PP from the rod, even on a Fumble or Blunder.

Each module power costs 1 PP from the rod (Catalyst Flow 2), paid once the cast has settled, or is held, through TRG Prime's one spend path: the round's Rod (one a round), Charge Depletion below 0. A refunded cast pays nothing. A rod must be held and invested to be offered.

## The staves (5)

TRG Prime staves with their printed spells, PP and recharge. **Eidothrix**: +1 item to the Spellcraft check when casting a Translocation spell. **Tesra'Anvir – Arcane**: a +4 Spell Adder for an arcane or High Magic caster of any tradition; Quicken for 8 PP from the staff on any spell of 2 AP (R18: no PP limit, as printed). **Staff of Flame**: lighting a flame is the table's.

## Spellhold (its store, from 0.14.0's card)

The staff's sheet has a **Spellhold** button. It lists what the staff holds against its room (6 / 12 / 24 / 40 PP).

- **Store a spell** opens TRG Prime's hold window. The next spell you cast this round is cast into the staff: its actions, check, PP and Save DC are paid and set then. On a Success or better it is held; a lesser degree stores nothing and spends its PP by the degree, as any cast does. A spell bigger than your cap on one cast, or than the room left, is refused before anything is spent.
- **Release** one for a Command (1 AP). It casts with the check it was stored with — its attack total, degree and natural die — and its Save DC as stored. Its targets and area are chosen now; a release called off at the picker keeps the spell.
- **Paid as any cast (Graham, 14 November 2026):** PP cost cuts and PP sources (the Rod of Ley Resonance among them) apply when a spell is stored, and its **Resonance is rolled when it is stored**: chaos on its check, a spell's named natural (Shadow Walk's 13), any Resonance a module forces on the cast. Its release rolls none.
- **Only the staff's investor**, holding it, stores or releases.
- **Stored spells fade at your next daily preparation.**

Spellhold moves from C to **A**.

## Found in the independent review, and fixed

- **Only one Rod a cast.** The rods' powers are all offered before any is taken. The first power taken now claims the round's Rod, and a power on a different rod is refused on the card ("only one Rod may be used each round").
- **A rod's power is paid only by the cast that took it,** whether that cast is held or not. A power left unpaid by a cast that was called off is dropped when the next cast's options are asked.
- **The Rod of Ley Resonance counts as the cast's Rod.** It pays as a PP source, which is asked before the options; once it has paid part of a cast, a second rod's power on that cast is refused.
- **Spellthread no longer leaves the first spell's rod power unpaid.** A woven (or held) release settles inside the first spell's cast and takes no options of its own; it no longer clears what the first spell has to pay.
- **Soul's Echo on a held spell now works at release.** Its +2 against undead is stored with the spell; this needs TRG Prime 3.690.0's fix.

## The harness

- `verify-block9c` (82 checks) and `mutate-block9c` (90 mutations, all caught).
- The extractor cuts the orbs, rods and staves (no new labels, so no other section's cut moves).
- **Re-pinned:** `verify-block1` (the item conditionals now count 19; Block 2's actions are known to the action check; the packs); `verify-block2b` (the rods' three casting options are Block 9c's); `verify-block3`/`3b` (REQUIRED_SYSTEM 3.69x); `verify-block9b` (9a's catalyst settle now asks Catalyst Flow); the manifest pins in `6-lead`, `7`, `8a`, `8b`, `9a`, `9b`; and the matching mutation anchors.
- **All 26 module verifiers** green and **all 25 mutation files** clean against core 3.690.0; the core's own full sweep (741 files) passes.
