# Eldritch Arts 0.18.3 — Scout Optics' Survival, from the 0.18.2 live test

25 November 2026. Needs **TRG Prime 3.713.1**, as 0.18.2 did. Not published.

## The fix

**Scout Optics did not make Survival a class skill.** 0.18.2 wrote Survival into the assistant's Frame, and it was saved. But the Frame is an entry of the federated `abilities` pack, so Core's Codex inheritance (`codex-inheritance.mjs`) lays the pack entry's flags over every copy each time it is prepared. Only Crafting and Perception were ever seen.

The Frame copy now also sets `flags.trg-prime.codexInherit: false`, Core's own switch for "a copy that genuinely differs". It reads the class-skill list from the stored data. Tested live by hand: Survival then shows with "Mechanised Assistant Frame" as its source, and the Frame's profile effect still applies.

## Live test of 0.18.2 on TRG Prime 3.713.1

Run in the Test world, as Testing Dude. The world was at Foundry's setup screen, so I launched it; it is still running.

| Ruling | Result |
|---|---|
| **A11-16** Multi-tradition spells | **Pass.** Fear cast at an Ascendan: by a Wizard (arcane), no Forbidden Magic −2 and no Heritage of the First Weave prompt; by a Druid (verdant), Forbidden Magic −2 and the prompt. |
| **A11-2** Integrated Modularity | **Pass.** The Short Sword took +2 attack and +1 damage. The attack row reads "Modular upgrade +2 (attack)"; damage rolled 2d6 + 1. |
| **A11-1** Advanced Design | **Pass.** The card reads "a +1 bonus to two items or a +2 bonus to a single item". |
| **A11-3** Flash of Insight | **Pass.** Traits "Artificer, Chance", no Prepared card. A fumbled Athletics became 20 + 7 = 27; a second failure the same day was not offered; its Use says it has been used today. |
| **A11-7** Rebuild cost | **Pass.** The confirmation names 1,000 gp (the Equipment Cost Table at level 6); 2,000 gp went to 1,000 gp (paid as change, 10 mp). With 500 gp it is refused ("rebuilding costs 1000 gp … has 500 gp") and the assistant is kept. |
| **A11-8** Only its own improvements | **Pass.** Evasion dropped on from Core's familiar pack is refused with a notice; nothing is added. Its Use's own items (Scout Optics' Scent and Tremorsense) are placed. |
| **A11-8** Scout Optics' Survival | **Failed in 0.18.2** (above); fixed in 0.18.3. |
| **A11-9** Triggered Sigil | **Pass.** Refused before any daily preparation. Allowed straight after preparation and inscription ("Magic Missile waits as a Triggered Sigil"). Refused after a spell is cast, and refused an hour later (clock set back afterwards). |

Clean-up: 7 actors (one an assistant), the scene, the folder and 49 messages were deleted; traces emptied; clock 90. The world is paused on Caves with 5 actors and 288 messages.

## Rulings

Graham's second answers (25 November 2026) confirm everything as built: the assistant's DB stays derived, Success or better recharges a Prepared ability, shields are armour, daily preparation is an hour (Core Rulebook p. 231), the rebuild is priced at the master's level, only the assistant's own feat may add abilities to it, and A11-13 and A11-15 stand. No Block 11 ruling remains open. See the audit's §3a.

## Tests

- `verify-block11`: 401 checks (new L5c and L5d).
- `mutate-block11`: 77 mutations caught (new: "Scout Optics' Survival hidden by Codex inheritance again").
- The rest of the suite is unchanged: every `verify-*` passes except `verify-block10`, and 27 of 30 `mutate-*` pass. All four failures predate 0.18.0.
