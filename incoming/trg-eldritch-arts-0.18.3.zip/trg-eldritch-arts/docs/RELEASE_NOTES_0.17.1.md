# Eldritch Arts 0.17.1: Block 10b, and Graham's two answers

15 November 2026. **Needs TRG Prime 3.694.0.** This release completes Block 10 and with it the module's content blocks. It holds:

- Graham's two answers from the 0.17.0 notes ("Yes to both questions");
- the three small findings of the 0.17.0 live test;
- Block 10b: the sentient-item roll tables (Q219) and the rules reference journal (Q221).

## Graham's answers

- **Dawnshield casts its Cure at its own level, 15.** The book says the shield "can independently cast" it. TRG Prime 3.694.0 lets a module's granted spell opt in to its item's level, and Dawnshield's Cure does. A relic's spells still use their wielder's level (Q213).
- **The Obsidian Codex's Detect Undead is at will.** It is the book's "(constant)". It is granted with unlimited uses and without the Focus trait. The Codex's other spells stay focus spells.

## Found in the 0.17.0 live test

- **The Aegis of Valtea ships at its Dormant figures.** That is HP 44, TRG Prime's customisation of an expert, lightweight, Potency I light steel shield. It used to ship at the plain base's 12 and only reached 44 once it had been invested.
- **The Codex's refusal no longer repeats its name.** It now reads "Obsidian Codex: it cannot be bonded by a Good-aligned character".
- **The tier question reads plainly:** "Invest it at which tier? It is awakened to Legendary, and 6 slots are free."

## Block 10b

### The roll tables (`ea-tables`, "Eldritch Arts: Sentient Item Tables")

Ten RollTables, cut apart from the book's merged grids. Every row is printed word for word at its printed range.

| Table | Die | |
|---|---|---|
| Item Type | d10 | |
| Personality | d12 | |
| Motivation | d12 | |
| Ethics | d100 | |
| Communication | d8 | |
| Senses | **d8** | Printed "d6" over eight entries; rolled as a d8 (Q219) |
| Mental Arrays | d8 | Each result gives Int, Wis and Cha and the printed note |
| Special Powers | d8 | |
| Aligned Trait | d8 | 6–8 None |
| Quirks | d20 | Printed under a second "Aligned Trait" header |

### The rules reference journal (`ea-rules`, "Eldritch Arts: Rules Reference")

One journal of twelve pages, each the book's own text (Q221):

1. **Chapter 7: Magic**
2. **High Magic**
3. **Ley Lines**, with the Ley Line Effects table
4. **Wild Magic Areas**, with the Wild Surge table
5. **Magic Suppression Areas**, with the Suppression Backlash table
6. **Mundane Ritual Casting**
7. **Summoning Circles**
8. **Wondrous Items & Relics**: the relic rules, Creating Relics, Relics & Investment and the GM Balance Notes
9. **Sentient Items**: traits, Determining Sentience, Ego & Conflict, Influence, cost and level, Hidden Powers, Sentience & Investment, Growth
10. **Design a Sentient Item**: the book's table introduction, with a link to each table
11. **New Traits** (the Appendix's, including RELIC and SENTIENT)
12. **Planes of Existence**, with the planar languages and the realms table

The relics and sentient-item pages end with a line naming what 0.17.0 automates. The specific relics and Dawnshield are in their own compendium, so they are not repeated.

## The harness

- **New pair `verify-block10b`** (36 checks) and **`mutate-block10b`** (21 mutations, all caught). Every printed table row and every printed line of every journal page is checked word for word. With the book present, the extractor re-cuts both from the book.
- **`verify-block10`** has 121 checks and **`mutate-block10`** 99 mutations. The new checks cover the Cure's level through TRG Prime's opt-in, the at-will Detect Undead and the Aegis's Dormant HP held against TRG Prime's customisation.
- **`verify-block1`:** the two new packs in the folder and the pack list, with its item checks kept to the Item packs.
- **`tools/build-packs.mjs`** keys RollTables and their results.
- **`verify-packs-compiled`** now also compares a table's results and a journal's pages, so a stale compiled table cannot ship.
- **Seven older mutation files** were re-anchored for the two new packs in the pack list.
- **All 29 module verifiers** pass on TRG Prime 3.694.0, and **all 28 mutation files** catch every mutation.
- **Independent review, and what it found (all fixed):**
  - **A world upgrading from 0.17.0 would have kept its old grants.** An invested Dawnshield's Cure would stay at the wielder's level, and the Codex's Detect Undead would stay a one-use focus spell, until the next re-investment. The grants now carry a format number, so they are rebuilt once, with spent uses kept.
  - **A table's results now weigh as many faces as they cover.** Foundry's "Normalize Results" would otherwise have evened them out: Nihilism, 99–100, would have had the same share as a seven-face ethic.
  - **The book's bullets that are set a blank line apart** were each rendered as a list of their own. They are now one list. The twelve planar languages are one list.
