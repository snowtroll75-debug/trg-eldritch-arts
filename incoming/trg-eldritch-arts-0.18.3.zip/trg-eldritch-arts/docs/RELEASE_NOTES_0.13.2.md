# TRG Prime: Eldritch Arts 0.13.2

13 November 2026. One fix, approved by Graham. Needs TRG Prime 3.688.1 or later; 3.688.4 is recommended (its own ritual fixes: the secondary rows start at "not participating", and the different-tradition count is held to the secondaries recorded).

## The Ritual Censor's incense is taken when the rite is settled

- **Before:** a Magic Ritual with the Ritual Censor ticked took its 5 gp of incense at the end of the module's ritual preparation. TRG Prime still had refusals to make after that step — "a magic ritual needs at least one secondary caster", the overcast limit, a ritual variant's PP cap or unprepared spell — and cancelling at the catalyst prompt also came after it. Each of those cost 5 gp for a rite that never happened.
- **Now** the preparation only marks the Censor as burning for that spell (the ritual card says "Ritual Censor: 5 gp of incense burns in the rite."). The 5 gp is taken once the ritual's roll is made, on the ritual's closing card: "Ritual Censor: 5 gp of incense is consumed in the rite (taken from the purse)." A ritual refused before its roll takes nothing.
- **Unchanged:** the −1 DC, and the purse check before the roll (a purse under 5 gp still refuses the tick). If the purse has emptied by the time the rite settles, nothing is deducted and the card says what is owed.
- **Once, and for that ritual only:** the mark is cleared when it is paid, by the next ritual prepared without the Censor, and by the settling of a different spell's ritual.
- **The Ritual Censor's own text** now says so: the incense is taken automatically once the ritual's roll is made (it used to say the incense was "yours to strike off", which could have had it paid twice).

## Live test (TRG Prime 3.688.4 with Eldritch Arts 0.13.1, before this fix)

- With the Censor ticked and no secondary recorded, the ritual was refused ("A magic ritual needs at least one secondary caster") and the purse went from 9 gp to 4 gp: the fault this release fixes.

## Live test (TRG Prime 3.688.4 with Eldritch Arts 0.13.2)

Run in Graham's world with a throwaway copy of Valmorius (9 gp, carrying a Ritual Censor), Mage Armour as the ritual. The world was left as found.

- **Censor ticked, no secondary recorded:** refused ("A magic ritual needs at least one secondary caster"); the purse stayed at 9 gp.
- **Censor ticked, one secondary at Success:**
  - the DC showed the Censor's −1 (DC 14);
  - the ritual card read "Ritual Censor: 5 gp of incense burns in the rite";
  - Mage Armour was cast;
  - the closing card read "Ritual Censor: 5 gp of incense is consumed in the rite (taken from the purse)";
  - the purse went from 9 gp to 4 gp, and the mark was cleared.

## The harness

- `verify-block2b` (97 checks) and `mutate-block2b` (89 mutations, all caught): the incense checks rewritten for the new timing — marked not taken (with or without a ritual variant), taken once when settled, the debt shown when the purse has emptied, a stale mark cleared, another spell's rite not taking it, and the settling registered.
- All 24 verifiers pass, and all 23 mutation files catch every mutation (2,500+ in all), on TRG Prime 3.688.4.
- **Independent review:** no blocking defects. Its test gaps (a variant with the Censor, the short-purse wording) and the Censor's stale item text were fixed before release. It noted that if the cast itself throws an error after the roll, the core skips the ritual's settling and the incense goes unpaid (in the player's favour; the next ritual clears the mark).
- Version pins raised to 0.13.2.
