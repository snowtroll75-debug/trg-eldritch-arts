# Eldritch Arts 0.4.0

2 November 2026. **Block 2b:** Chapter 7's mundane ritual casting, summoning circles and true names; Chapter 4's Spell Trickery and Borrow Spell. Built from `ELDRITCH_ARTS_BLOCK2_AUDIT.md`, Graham's Q5 and Q8, and Q9–Q14 built as proposed on 2 November 2026 (listed below). This completes Block 2.

- **Install TRG Prime 3.679.0 first, then this over 0.3.0.** The module warns on anything older: the ritual rules, the casting options and the vital sacrifice's damage are the system's seams.
- **No migration.** The compendiums are rebuilt; the notes on Ritual Expert, the Ritualist trait and the ritual and circle goods now say what is automated.
- **One fix from the 0.3.0 live test:** a table card (ley line effects, wild surges, suppression backlash) no longer repeats its title as its first line.

## Mundane ritual casting

Start a ritual as before: **Magic Ritual** on the spell. The dialog has more in it now.

**How the PP is paid.**
- **"Spellcraft, paying PP"** is the core ritual, unchanged.
- **The three variants** are offered when the primary is trained in a tradition skill appropriate to the spell: Arcana (arcane), Religion (divine), Occultism (ethereal) or Nature (verdant). All four count for a Highmagic spell. A variant changes the check and the payment:
  - **The check** is that skill, against the primary's level DC, Very Hard (+5). The core's ritual modifiers still apply (Q5): PP over, different-tradition secondaries, casting time, unaltered duration, the Ritual Focus row.
  - **Vital sacrifice:** the primary takes 1d8 essence per PP substituted, and each named secondary 1d4. Each makes a basic Fortitude save against their own level DC (C3). "This damage bypasses all DR, Resistance and Immunity."
  - **Material sacrifice:** the table's gold, from the primary's purse. The purse must hold the Success's cost before the roll, or the ritual is refused. Beyond 20 PP the table stops, and the ritual is refused.
  - **Communal offering:** the secondaries you tick pay the PP, +50% rounded up, split as evenly as it goes. Before the roll, every one of them must be yours (a GM owns all), and together they must hold the Success's share. A secondary who is short by the time it is paid pays what they have, and the card says so.
  - **Ticking the secondaries:** for a vital sacrifice or a communal offering, tick every secondary you entered in the rows above. A ritual whose ticks and rows disagree is refused before the roll.
- **How much is substituted (Q11):** exactly the PP the degree would have spent. That is all of it on a Success, half the base on a Critical, half on a Failure, all on a Fumble or Blunder, and none on a Partial. It is paid when the casting is settled.
- **The cap per cast stands (Q9):** caster level + 1, plus the ritual's 2 PP per secondary (the "PP over your normal maximum" field). A Caster Level 0 primary with three secondaries can lead up to 7 PP. It is checked **before the roll**: Overcasting by Sacrifice cannot help a ritual, because its DC rise would land on a check already rolled.
- **Preparation (Q10):** a non-caster (Caster Level 0) leading a variant need not have prepared the spell, only have it on their sheet. A caster leading one still must, and is told so **before the roll**. Spontaneous Scholar's waiver is not offered here; prepare the spell, or lead it in PP.
- **Not paid twice:** a rod is not drawn for a variant, and a refunded cast pays no sacrifice.

**The secondaries.** Tick the creatures on the scene taking part. A vital sacrifice hurts them, and a communal offering takes their PP. Their own checks are still entered as degrees in the rows above, as before.

**Ritual goods and feats** (ticks, offered only while carried):
- **Ritual Censor:** −1 to the ritual's DC, with 5 gp of incense consumed: taken from the purse once nothing can refuse the ritual. With less than 5 gp, the tick is refused.
- **A Ritualist weapon** (Bachall Fáistine, Brikail Naomhtha, Claidheamh Dubh), wielded or placed at the centre: −1 DC.
- **Runestone Chalkboard:** +1 to the primary's ritual check.
- **Bloodscribe's Bowl:** +1 when blood is offered.
- **Ritual Expert (Q13):**
  - **As the primary:** you count as two casters, automatically.
  - **As secondaries:** enter how many of them have it, at most as many as the secondaries entered.
  - **What the extra seat counts toward:** each is one more caster for the one-secondary requirement and the 2 PP headroom. A secondary's degree modifier is not doubled, and Rune-Binder's Precision does not stack with it (M21).

**High Magic (Q14):** a High Magic spell's ritual check is Hard (+2) as well, whichever way it is paid.

**Ritual spells (Q8, M30):**
- **Outside a ritual:** an Eldritch Arts spell with the Ritual trait "may only be attempted as part of such a ritual, never as a standard casting action". Casting it otherwise is refused with that reason.
- **Inside a ritual:** its result is not capped at Success, so a Critical or Heroic ritual casts on that degree.
- **The core's own Ritual spell** (Clone) is unchanged.
- **No such spells yet:** Eldritch Arts' Ritual spells arrive with the Grimoire (Blocks 7 and 8).

**Chapter 7's areas now reach the ritual:**
- **Antimagic:** an antimagic zone refuses the ritual before its dialog.
- **Suppression:** a Magic Suppression area's −level is on the ritual check itself.

This closes the gap reported in 0.3.0.

## Summoning circles

**Inscribe Summoning Circle** is a skill action: Occultism, Arcana, Nature or Religion.
- **The DC:** Moderate (+0), the creature's level DC. A dialog asks the creature's level and the Summoning Circle Modifiers:
  - rare or consecrated materials (−2 to −10, as the GM sets);
  - poor materials (+2 to +5);
  - ground aligned (−4) or opposed (+4);
  - the creature's True Name (−5);
  - haste (+5) or meticulous care (−2);
  - assistants (−1 each, at most −4);
  - blood (animal −2, intelligent −4);
  - a disrupted circle (+10; "or automatic failure" is the GM's).
- **Time:** 10 minutes × the creature's level, doubled for meticulous care. The card says it. The time is not spent for you.
- **The circle** is an effect on you for 1 hour per caster level. Drawn in **Void Chalk**, it lasts 24 hours, or longer if your caster levels make it so. A new circle replaces the old.
- **What it does on a Summons spell's casting check:**
  - **Critical:** +4 circumstance, and the creature takes −2 to resist binding. That is +2 to the spell's Save DC, applied on the Casting Conditions prompt without a tick.
  - **Success:** +2 circumstance.
  - **Failure (and a Partial, which prints none):** −2.
  - **Fumble:** the casting card warns that the circle is destabilised. When the summoning succeeds, a card says the creature arrives hostile and unbound.
- **Ward Twine (Q12):** outlining the circle with it adds +1 to the Save DC of Summons spells cast from it.

## True names

- **The option:** on a Summons spell, the Casting Conditions prompt offers "Invoke the creature's true name (+4 Save DC)".
- **After the saves:** each creature that still succeeds on its save "becomes permanently hostile towards you". It gets an effect saying so, and a card names it.
- **Left to the GM:** "Powerful beings may also mark, curse, or retaliate"; the card says so.
- **Summoning circles:** a known true name is also the circle's −5.

## Spell Trickery

- **The option:** on any cast with the prompt (not an innate, item or ritual cast), "Spell Trickery (+2 to the casting DC)". The +2 is its own part of the casting DC.
- **The card gives your Deception DC.**
- **For an observer: See Through Spell Trickery** is a skill action, Sense Motive or a tradition skill, against the trickster's Deception DC (target the caster). It prints the seven results.
  - **Their bonuses:** the Heroic's +4 and the Critical's +2 to counteract or defend against the spell are the table's to apply.
  - **The name is ours:** the book names no action for the observer, so this one is named for what it does.

## Borrow Spell (m14: a General skill action)

- **Who:** a spellcaster who prepares spells from a spellbook (the Wizard, an Arcanist), trained in Arcana, Nature, Occultism or Religion.
- **Choosing:** another book caster's book, then a spell from it you do not already know. A creature's innate spell-likes and a spell an item grants are not in a spellbook, so they are not offered.
- **The copy is yours:** not innate, and without the lender's signature mark, rune or grant.
- **The DC:** Easy (−2), against the DC to learn the spell (Learn a Spell's table, with the rarity raise).
- **Success** (Heroic and Critical read as Success): the spell is copied into your book, marked borrowed and unprepared. Prepare it on the Magic tab with one of your memorisations. It does not count against the free spells your class adds.
- **Failure** (Partial and worse read as Failure): you cannot try to borrow that spell again until your next daily preparation.
- **At your next daily preparation** the borrowed spell leaves your book and the bar lifts. Borrow after preparing, not before.

## Not automated (said on the cards)

- **The circle's time and the ritual's time** are said, not spent.
- **"+10 or automatic failure"** for a disrupted circle: the +10 is applied; the failure is the GM's.
- **Gilded Censor Chains' 20-ft radius** is the table's.
- **A failed ritual whose cast is stopped by a cancelled target or warp:** the card says its PP loss, fumble and sacrifice were not applied, for the GM.
- **Warps chosen in the cast after a material ritual's roll** can push its cost past the table's 20 PP; the card then leaves the cost to the GM.
- **Ritual spells' own extra effects by degree** ("determined by the Ritual check") arrive with those spells (Blocks 7 and 8).
- **The Relic Bonding Ritual** is Block 10.

## Questions built as proposed (2 November 2026)

| # | Question | As built |
|---|---|---|
| Q9 | A variant ritual's PP cap | The cap stays: caster level + 1, plus 2 PP per secondary. |
| Q10 | Preparation | A non-caster need not have prepared it; a caster must. |
| Q11 | How much is substituted | The PP the degree would have spent; vital, material and communal as above. |
| Q12 | Ward Twine's "effective DC" | +1 to the Save DC of Summons spells cast from the circle. |
| Q13 | Ritual Expert | One extra seat, as primary or secondary; the degree modifier is not doubled. |
| Q14 | High Magic in a ritual | Hard (+2) on the ritual check, either way of paying. |

## Found in review before release, and fixed

An independent review of the code against the book found eight Major and five Minor defects. All are fixed, each with a check and a mutation:
- **Double payment:** a rod paid as well as the sacrifice, and a refunded cast still paid.
- **Payment after the roll:** a ritual could go ahead free or part-paid because its gold or PP were checked only after the roll. The purse, the secondaries' PP, their ownership and the ticks are now checked first.
- **Free seats:** the Ritual Expert count bought seats with no secondary present.
- **Gates asked twice:** the gates were asked twice per ritual (in TRG Prime).
- **Escaping a Fumble:** a failed ritual could escape its consequences by a cancel, and a variant was refused only after a Success (in TRG Prime).
- **Borrowing spell-likes:** Borrow Spell could copy a monster's innate spell-likes.
- **Specialist spells** were never offered a variant.
- **The Ritual Censor's incense** was announced but not taken.
- **In TRG Prime:** a ritual's casting could be stored by Spell Storing, and a Null Aura row could leak into a ritual attack spell's attack.

## Core seams used (TRG Prime 3.679.0)

`registerRitualRules` (D13), `registerCastOption`, `basicSaveHit`'s `ignoreDefences`, and the helpers `deductGold`, `goldOf`, `learnSpellDC` and `keepsSpellbook`. `trgPrimeSpellSettled` now also carries `castOptions`, `ritualVariant`, `ppSubstituted` and `saveResults`. See `ELDRITCH_ARTS_CORE_DEPENDENCIES.md`.

## Harness

- **`verify-block2b`:** 91 checks, all passing. They cover:
  - the book: the three actions' rows and text, the material table and the circle modifiers, read from the extract;
  - the pure rules: the ritual skills, training, the costs, the shares, the circle's rows, time and duration;
  - the ritual on fakes: the variants and fields, the plan (Q5, Q9–Q11, Q13), Q8 and M30, and each substitute paid, a short purse and a short secondary included;
  - circles, true names, Spell Trickery and Borrow Spell on fakes;
  - the system's own registry and ritual rules, end to end with the module's answers;
  - the wiring and the versions.
- **`mutate-block2b`:** 81 mutations, all caught.
- **Blocks 1 and 2:** `verify-block1` 882 checks and `mutate-block1` 86 mutations; `verify-block2` 131 and `mutate-block2` 75. All caught; they were adapted to the newer versions and Block 2b's registrations.
- **TRG Prime 3.679.0's own pair:** `verify-ea-block2b-core` 52 checks, `mutate-ea-block2b-core` 60 mutations, all caught.
