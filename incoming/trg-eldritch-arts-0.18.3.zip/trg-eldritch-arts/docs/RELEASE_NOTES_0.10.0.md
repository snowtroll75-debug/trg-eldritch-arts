# Eldritch Arts 0.10.0

7 November 2026. **Block 7: the first half of Chapter 8's Grimoire**, 42 spells — ten cantrips, eighteen attack, save and area spells, fourteen wards, buffs and reactions. Built from `ELDRITCH_ARTS_BLOCK7_AUDIT.md` §5.2 as Graham answered it on 7 November (04:38): Q150 changed (recurring damage stacks by type — now TRG Prime's own rule), Q151–Q166 as proposed, seams H1–H11 approved. Graham's two rulings of 07:53 are built: **Dragon Wings** "Max +50, four warps" and **Spirit Arrow** "Flat 6d6".

- **Install TRG Prime 3.685.0 first, then this over 0.9.2.** Block 7 needs that version's seams (H1–H11). On anything older the module warns.
- **No migration and no new settings. Loading a world changes nothing on any sheet.**
- **The spells are in "Eldritch Arts: Spells"** (now 91); the Elemental Strike ability is in "Eldritch Arts: Abilities".
- **Every Chapter 8 spell is uncommon** (m84; Q166): `system.availability`, so TRG Prime warns when one is taken with a level-up pick and the learning DC is +2.
- **Already on a sheet:** a Draconic or Elemental Pact chosen before 0.10.0 has no spell yet. Press the feat's **Use** again: the energy or element is asked, and Dragon's Breath or Elemental Strike of it joins the repertoire. Pact Boon (Draconic) adds Dragon Wings on its Use.

## Also in this release (from the tree before Block 7)

- **The book extract keeps every field** (`extract-book.mjs`): "Target" (16 lines in v1.6), "Requirement" (Rippling Gaze), a Tradition set with a bold comma whole (EA-m127), and Steelbinding's "+2**; Requirements**" (m45). `book-text.json` is cut again from v1.6.
- **Paradox Weave** prints "**Target** 1 willing creature" and targets "1 willing creature" (the line was lost in 0.5.0; Q166).
- **The six Grimoire spells built earlier are uncommon** (Q166): Orb of Water, Dark Whispers, Message Rune, Observe the Weave, Symbol of Death, Symbol of Fear.
- **Block 6's cards no longer say the Grimoire is coming.** The Draconic and Elemental Pacts' Uses grant Dragon's Breath and Elemental Strike of the chosen type (granted by the feat, so a Warlock's copy is innate and Focus as Block 6's Pact spells are), and Pact Boon (Draconic) grants Dragon Wings.

## How it works at the table

- **Distracted** (Q157) is −1 status to attack checks, skill checks, saving throws and casting checks, not to DB or damage. It is not a core condition and a module cannot register one, so it is laid as the spell engine's own bonus rows — attack, every skill, the three saves, Spellcraft — each shown on the sheet as "*Spell* (Distracted)" and timed and removed with the spell. Animate Moustache and Bubble Buffet lay it.
- **Recurring damage** (Q150): Eaog Balls' force (1d6 / 2d6 / 3d6 by rung) and its +2 PP 2d8 coldfire are two recurring damages of two types. TRG Prime 3.685.0 keeps a total per type, each with its own flat check, dealt in the end phase. There is no separate "start of turn" packet; the coldfire is dealt in the end phase too, as Graham ruled at 08:35.
- **A type chosen when learned:** Dragon's Breath (acid, cold, electricity, fire, poison; acid and electricity a 30-ft line, the rest a 15-ft cone, its range warp +10 ft to 120 or +5 ft to 60) and Elemental Strike (acid, cold, electricity, fire) ask when they reach a sheet; a Pact's grant takes the Pact's. A closed dialog is asked again at the first cast, which is refused until a type is chosen. Flesh to Blossom asks acid or poison **as you cast** (a cast prelude), as printed.
- **Reactions are asked of the reactor's player, else the GM** (Block 3b's `askReactor`): Arcane Feedback (an enemy casts within 30 ft), Argent Reversal (a spell whose caster you can see), Spectral Aegis (a hostile spell on the warded creature), Mirror Reprise (an attack that hits you, once the images are up), Panic Transposition (an attack hits you). Air Bubble is cast from the sheet as your reaction when the table says the trigger happened.
- **Writes on a creature the client does not own go through the GM.** A reaction or a hit is often settled on the attacker's client while the mark, ward or charge sits on another player's or the GM's creature. Those writes are sent over the module socket and made by the active GM alone, who checks each against the creature as it is now, never against what the request says: a counter on one of the module's own effects down by one (Spectral Aegis's absorbs, Mirror Reprise's images, Argent Reversal's attempts) or Mirror Reprise's images armed from 0 to 3, under that effect's own key and with nothing else changed; deleting the module's own effects, and a cast's effects only when the creature's own Arcane Bastion record, or its own Spectral Aegis or Mirror Reprise effect deleted in the same write, names that cast. No PP is relayed: Argent Reversal's absorb refund is made in its step, on the bearer's own client, never above its PP maximum. What can be kept on the caster is (Invoke True Name's spent weakness, Planar Anchor's veil).
- **A teleport is the bearer's own.** Panic Transposition's teleport and Mirror Reprise's step are run on the bearer's owner's client (or the GM's), sent over the module socket, where its player clicks the square; a click beyond 30 ft (60 warped) or 10 ft is refused. Panic's is sent by the attacker's client once the attack is resolved, its damage dealt (L7324: "After resolving the triggering attack, you teleport"): after `trgPrimeStrikeResolved` for a weapon Strike, after the attacker's settled cast for a spell attack. An attack never resolved, a refunded cast, or a bearer down or gone sends nothing.
- **Regions:** Arcane Mycelium, Bubble Buffet, Primal Snap and Zone Disruption keep their Region for the spell's duration; the module stamps it with the caster, the cast's Save DC and the warps bought, and reads it on a casting (Mycelium's threads, the zone), at the start of a turn (Primal Snap) and for Spell Concentration (the zone's `castingZone`, H8).

## How much is automated

A: full · B: automated, with a normal choice or prompt · C: partly, one clause left to the GM and said on the card · D: the item and its card only.

| | A | B | C | D |
|---|---|---|---|---|
| Cantrips (10) | 4 | 3 | 1 | 2 |
| Attack, save and area spells (18) | 8 | 6 | 4 | 0 |
| Wards, buffs and reactions (14) | 5 | 8 | 1 | 0 |
| **All 42** | **17** | **17** | **6** | **2** |
| *The audit's estimate (§10)* | *18* | *19* | *3* | *2* |

**Three are a grade lower than the audit expected,** each for a part the core cannot do today (see "Core requirements (later)" below; Graham ruled at 08:35 that they stay at these grades). Each card says so:
- **Arcane Mycelium** (A → C): its dim light. The core's light shift is drawn around a creature, not on a placed area.
- **Glyph of Retribution** (B → C): the +4 PP option's change of type "each time you are struck". The core's thorns deal the type they were cast with.
- **Spirit Arrow** (B → C): the Feint, Grapple, Shove or Trip "using the attacker's attack result". It is asked and named on the card; its result is read by hand. A module cannot resolve a basic action at a given total.

**The six C spells, and the clause each leaves to the GM:** Drearlight (darkness suppression; a cast on a bare square), Arcane Mycelium (the light), Eaog Balls (the halved speeds on a Critical and a Success; the Fumble's automatic failure of Strength and Dexterity checks; the ground), Glyph of Retribution (the type change), Spirit Arrow (the manoeuvre's result), Pledgeshroud (the binding itself). **The two D spells** are Freshmark and Reckoning Glance.

## The rulings, as built

- **Dragon Wings** (Graham, 07:53: "Max +50, four warps"): a fly Speed of your land Speed + 10 (H4, read against the land Speed as it is), +10 a warp, at most land + 50 in all. The warp's `bonusMax` is the whole +50, so a fifth warp adds nothing. One constant: `DRAGON_WINGS_FLY_CAP` (`module/block7-rules.mjs`).
- **Spirit Arrow** (Graham, 07:53: "Flat 6d6"): the arrow's damage is exactly 6d6 piercing; no BAB, attribute, feat or other addition. A critical still doubles it as weapon damage. The rider says `replacesDamage: true` and `flat: true` (H10 and its addition in TRG Prime). One constant each: `SPIRIT_ARROW_REPLACES`, `SPIRIT_ARROW_FLAT`.
- **Q151 Arcane Bastion:** after the injury roll, an injury that would leave you dying or incapacitated is read a severity lower (a further step per +2 PP, max 3; Minor becomes none) and the spell ends (H7). The 0 HP clause is the core's death guard (left on 1 HP) and also ends the spell.
- **Q152 Spectral Aegis:** the first hostile spell of PP 10 or lower whose targets include the warded creature; a targeted spell is negated for it and an area spell leaves it out (H5 `exclude`). Then the Aegis and its resistance end. Beneficial (utility) spells pass.
- **Q153 Argent Reversal:** a spell whose caster you can see (not blinded; the caster not hidden or invisible), of PP up to your maximum PP per cast; Spellcraft against that cast's own Save DC (H5's ctx). A turned spell resolves at your Spellcraft total and your Save DC (H5 `turnBack`); a Critical may name another creature. Partial reads as Failure (m42).
- **Q154 Zone Disruption:** every innate spell cast inside, the Warlock's included, rolls Spellcraft (innate ability + level against 10 + ⌊1.5 × PP⌋); its degree is the casting's (H8 `innateCheck`).
- **Q155 Elemental Strike:** any number for the minute, 1 AP each, no multiple attack penalty taken or added; the Save DC fixed at the cast; Base Damage 1d6 on a critical; a melee weapon wielded. That each counts as a Strike "for rules that count Strikes" is **by hand**: the Use fires no Strike and adds to no Strike count, and the card says so.
- **Q156 Flesh to Blossom:** each later save replaces the last (H3c).
- **Q158 Arcane Feedback:** every damaging rung's damage taken is a penalty to the casting check (casting-only); Blunder as Fumble; an innate cast with no check takes the damage only; cantrips count.
- **Q159 Chronoweave:** whoever is inside is quickened, while inside. The module keeps the membership live: you and each ally within 20 ft have a quickened effect, gained on coming in and lost on leaving (token moves, turns), each lasting no longer than the spell. The warp's enemies save Fortitude once, are slowed 1 or 2 while inside for the duration, and are immune to that casting for its duration.
- **Q160 Primal Snap:** 1 minute either way; "until healed" is until any HP is regained (H11 `endsOnHeal`); Failure or worse, and on a basic save a Partial is not a failure (it takes half damage and no penalty); not stacking.
- **Q161 Spirit Arrow's fear:** half the margin, rounded down, minimum 1 on a failed save.
- **Q162 Mana Surge:** the free PP raise the Save DC (H9b `raisesSaveDC`), not the casting DC or the cap.
- **Q163 Metamagic Resonance:** no requirement but the caster's; the ally pays from its own pool; half rounds down (H9).
- **Q164 Invoke True Name:** −2, −4 from CL 8, once; flat-footed against your spell attacks.
- **Q165 Feltwarp:** the wearer gets the bonus.

## Readings to know about

Each is said on the spell's card.
- **Thorns at any reach.** "Any creature that hits you with a melee Strike" prints no contact distance, and the core's thorns default to adjacency; Brittleskin, Glyph of Retribution, Eldritch Mantle and Prismatic Guard answer every melee hit (`ANY_MELEE_FEET`).
- **Brittleskin's +1 DR** is a status bonus, as the core's Iron Body writes DR rows.
- **Prismatic Guard** is placed as a 10-foot radius around you (not the printed emanation) so that "the creatures within the area at the time of casting" keep it as they move; the card prints the book's area.
- **Bubble Buffet's Will save** is the turn ladder's (at the cast and each of your turns), so the spell rolls no save of its own.
- **Primal Snap's** basic Fortitude is rolled by the module at the start of a combatant's turn in the fog (the core's turn-start pass has no row for a damage-and-condition save); out of combat, nothing.
- **Zone Disruption:** those inside at the cast roll its Will save then; those who enter later roll on entering. Only a creature's first result counts: a later mark from the same casting is removed (a re-entry's roll still shows on the card).
- **Mirror Reprise:** the d100 is rolled for an attack that would hit (H6 answers after a hit). An attack that misses you misses the duplicates too, so nothing changes.
- **Spectral Aegis and an area spell:** the area is not placed yet when the cast reactions are asked, so the warded creature's player is asked whether it will be caught.
- **Invoke True Name:** Block 2b keeps no record of the true names a character knows, so the cast is not refused on a creature whose name you do not know.
- **Planar Anchor:** spells with the Teleportation trait; with the +4 PP option, spells that would make the creature invisible or incorporeal (by trait or name). Planar travel spells without the Teleportation trait, and abilities, are the GM's.
- **Arcane Feedback** is cast inside the enemy's casting-check gate; `castAsReaction` sets the reactor's targets for its cast and puts them back (the 3.685.0 caveat).
- **Metamagic Resonance:** allies are given the lend as they come within the aura and lose it as they leave (token moves); the "change the feat each time you sustain" option is by hand.

## Graham's rulings of 7 November 2026 (08:35)

Graham: "the six questions as you have already built". Each is a ruling, and each is built that way.
1. **Arcane Bastion:** Stunned is not "incapacitated". The shield answers an injury that would leave you unconscious, paralysed, petrified, helpless, dying or on a death row, not one that stuns (`injuryIncapacitates`).
2. **The three core additions** (Arcane Mycelium's light on a placed area, Glyph of Retribution's type chosen when struck, Spirit Arrow's manoeuvre at the attack total) are left for a later core release. The three spells stay at the grades they have now (C), each card saying what is by hand. They are listed under "Core requirements (later)".
3. **Dragon Wings:** the chooser may still offer a fifth +2 PP purchase (the core counts `bonusMax ÷ bonusValue` = 5), and it adds nothing. No core change.
4. **Eaog Balls:** the +2 PP coldfire (printed "at the start of each of its turns", L6672) is dealt in the core's end phase with the force, each its own total and flat check (Q150), as built.
5. **Flat Spirit Arrow:** the arrow's damage is exactly 6d6, but other riders and once-a-round windows are still used up by the hit.
6. **Core-side, for information:** an "until healed" critical's Bleeding and Injured still take off the condition's whole total when healed.

## For Graham

- **Zone Disruption's "sustain actions":** the core's Sustain rolls nothing but the Concentration check an interruption asks (which takes the +2), as the core's notes say.

## Core requirements (later)

Not made; left for a later core release (ruling 2 of 08:35). The spells keep their grades until then.

1. **A light step on a placed area** (Arcane Mycelium, L6166: "The affected area … emits dim light"). `lightShift` is drawn around a creature target; a placed template has no light row. Would lift Mycelium to A.
2. **A thorns row whose type is chosen when struck** (Glyph of Retribution, L6990: "+4 PP: change the damage type to either acid, cold, electricity or fire each time you are struck"). A `typeChoices` on `thorns`, asked of the defender in `thorns-workflow`. Would lift Glyph to B.
3. **A basic action resolved at a given total** (Spirit Arrow, L7634: "treated as a Feint, Grapple (1 round), Shove or Trip action using the attackers attack result"). A helper (e.g. `resolveBasicAction(actor, key, { total, target })`) over `data/basic-actions.mjs` and `basic-action-conditions.mjs`, as Tanglefoot's spell maneuver uses. Would lift Spirit Arrow to B.
4. *(Optional, card lines today)* a row that halves a Speed (Eaog Balls, L6644); a sustain hook a module can answer (Metamagic Resonance's "+2 PP: change the chosen metamagic feat each time they sustain").

## Every spell, as built

The table is generated from `SPELL_AUTOMATION_B7` (`tools/content/block7-spells.mjs`), the same record the harness checks.

### Cantrips

| Spell | PP | | What TRG Prime does |
|---|---|---|---|
| Brittleskin | 0 | A | +1 status DR to the start of your next turn; a melee hit on you costs the attacker 1d4 piercing (basic Fort at your Save DC); CL 4 and every 4: +1 DR, +1d4 |
| Decoherence | 0 | B | a held +1 circumstance (one-shot) for your next Identify Power, Recall Knowledge, Dispel or Disable a Device check, to the end of your next turn; +1 at CL 4 and every 4 |
| Dreadmote | 0 | A | spell attack (1 AP, multiple attack penalty as M39), 1d4 essence; +1d4 at CL 4 and every 4 |
| Drearlight | 0 | C | dim light (+1 illumination step) in 10 ft around the targeted object's bearer; the darkness suppression and a cast on a bare square by hand |
| Feltwarp | 0 | B | the wearer (Q165): +1 item to Sneak (Stealth) checks involving worn soft gear, a tick; +1 hour at CL 4 and every 4 |
| Freshmark | 0 | D | card only |
| Invoke True Name | 0 | B | a mark to the end of your turn: your spell attacks treat it as flat-footed, −2 circumstance (−4 at CL 8) on its saves against your spells, weakness to the first damage it takes from your spells this turn |
| Necrotic Whisper | 0 | A | spell attack, 1d4 essence + 1 secondary sonic; +1d4 and +1 at CL 4 and every 4; "living" by hand |
| Orb of Dusk | 0 | A | spell attack, 1d4 essence + 1 secondary cold, 60 ft; +1d4 and +1 at CL 4 and every 4 |
| Reckoning Glance | 0 | D | card only |

### Attack, save and area spells

| Spell | PP | | What TRG Prime does |
|---|---|---|---|
| Acidic Burst | 4 | A | basic Reflex against 3d6 acid in 5 ft around you (you are not caught); +5 ft a warp |
| Animate Moustache | 2 | A | Will; on a Failure or worse (a Partial reads Failure, m42), Distracted for 1 minute |
| Arcane Feedback | 14 | B | offered when an enemy within 30 ft casts: Will ladder 2d8/4d8/4d8 + Minor/8d8 + Serious force, the damage taken a penalty to its casting check; +1 step a warp (max deadly) |
| Arcane Mycelium | 6 | C | difficult terrain; Reflex on entering or starting a turn inside (slowed 1 / 2 to the end of its next turn); the +2 PP reactive threads (2d6 essence, basic Fort, on a cast inside); the dim light by hand |
| Bubble Buffet | 4 | A | Will at the cast and at the start of each of your turns for everyone in it: Distracted (to its next turn's end / the duration), fixated, + slowed 1; a failure rolls no more, a worse result replaces a better (m100) |
| Dragon’s Breath | 2 | A | the type chosen when learned (a Draconic Pact's is its energy): basic Reflex, 2d6, a 30-ft line (acid, electricity) or 15-ft cone; +1d6 and +10 ft line / +5 ft cone warps |
| Eaog Balls | 18 | C | Fortitude ladder: disadvantage on attacks / attacks and skills, speed 0 (immobilised), stunned 3 + immobilised; 1d6/2d6/3d6 recurring force and the warp's 2d8 coldfire, each type its own total and flat check (Q150); dispels at disadvantage (a tick); the halved speeds and auto-failed Str/Dex checks by hand |
| Elemental Strike | 2 | B | the type chosen when learned (an Elemental Pact's: its element's); for the minute, an Elemental Strike Use (1 AP, any number, no multiple attack penalty; 'a Strike' for other rules by hand): basic Reflex at the cast's Save DC against 1d6 + casting ability (+1d6 a warp) |
| Flesh to Blossom | 10 | B | acid or poison chosen at the cast; Fortitude ladder 1d12 / 2d12 + immobilised / 4d12 + petrified, saved again at the start of each of its turns while sustained, each result replacing the last; +1 target a warp |
| Glyph of Retribution | 8 | C | +2 status DB; a melee hit on you: basic Fortitude at your Save DC against 1d6 + caster level (max +15) sonic; the +4 PP type change by hand |
| Leyline Burst | 4 | A | basic Reflex against 4d6 force; pushed 10 ft away on a Failure or worse; +1d6 and a 10-ft burst on the target warps; High Magic |
| Memory Eclipse | 8 | A | Will (read from the prose): dazed 1 for 1 round / dazed 2 for 10 minutes / + frightened 2; +1 target within 10 ft a warp; High Magic |
| Planar Anchor | 8 | B | Will: anchored 1 minute / 10 minutes / 1 hour (Fumble + slowed 1 for 1 minute); a Teleportation spell cast by or on it is counteracted; the veil warp adds invisibility and incorporeality |
| Primal Snap | 12 | B | concealed both ways in the fog; a creature beginning its turn in it: basic Fortitude against 6d8 cold (+1d8 a warp), and on a Failure or worse −10 status Speeds until it regains HP (H11); moving the fog by hand |
| Prismatic Guard | 18 | A | you and everyone in 10 ft at the cast: resistance to acid, cold, electricity, fire, sonic, essence and force (M53), immune to blinded and dazzled; a melee attacker that damages one rolls Fortitude: dazzled / dazzled / blinded / permanently blinded |
| Spirit Arrow | 12 | C | your next ranged Strike's arrow deals exactly 6d6 piercing, nothing added (H10 flat; ruled "Flat 6d6"; it doubles on a critical); on a hit the target saves Will at your spell DC or is frightened half the margin (min 1, Q161); up to 5 arrows; the manoeuvre by hand |
| Word of Pain | 10 | A | Fortitude: weakened 1 for 1 round / 1 for 1 minute / 2 for 10 minutes / 4 for 1 hour; a 20-ft radius warp |
| Zone Disruption | 14 | B | Will on first entering (and for those inside at the cast); a Critical ignores it; inside: casting checks at disadvantage, Spell Concentration DC +2, innate spells roll Spellcraft (Q154); the fumble warp rolls the table twice, the higher |

### Wards, buffs and reactions

| Spell | PP | | What TRG Prime does |
|---|---|---|---|
| Air Bubble | 2 | B | cast from the sheet as your reaction: the target breathes normally (the core's water-breathing marker) and stops suffocating; ending it early on breathable air by hand |
| Arcane Bastion | 14 | B | resistance to all damage; damage that would take you to 0 HP leaves you on 1 and ends the spell; a critical injury that would leave you dying or incapacitated is read a severity lower (a further step per warp, max 3) and ends the spell |
| Argent Reversal | 10 | B | a charge for an hour: offered on a spell whose caster you can see (PP up to your maximum per cast); Spellcraft against that cast's Save DC — Critical/Success turned back at your check and Save DC (a Critical may choose another target), Fumble 4d10 / Blunder 8d10 essence (basic Fort); absorb warp; +1 attempt a warp |
| Bouncy Body | 2 | B | a willing creature (M43): +2 circumstance to Escape and grapple checks; falls count 20 ft shorter; the bounce (Acrobatics, DC feet fallen + 10) by hand |
| Chronoweave | 12 | A | you and allies inside the 20-ft emanation are quickened while inside (the module keeps who is in), the extra AP unrestricted (M37); the warp: each enemy inside saves Fortitude once (slowed 1 / 2 while inside, for the duration), then is immune to that casting |
| Dragon Wings | 6 | A | a fly Speed of your land Speed + 10 ft (H4), +10 ft a warp to land + 50 in all (ruled: four warps); 1 hour or to the next daily preparation |
| Eldritch Mantle | 10 | A | physical resistance (immunity with +10 PP); a melee attacker: basic Fortitude at your Save DC against 1d6 force, +1d6 a warp; 10 minutes |
| Mana Surge | 12 | A | a willing creature (M43): the first 1 PP (2 with +4 PP) of warping on each of its spells is free and raises the Save DC; not the casting DC, not the cap (Q162) |
| Metamagic Resonance | 8 | B | you choose a metamagic feat you have; allies within 30 ft (60 with the warp) may apply it to one spell a round from their own PP — full, half (rounded down) or none by the warps; the 1-minute warp ends sustaining (M47); changing the feat on a Sustain by hand |
| Mirror Reprise | 10 | B | the first damage from an attack (or, warped, a hostile spell) makes three images; each later attack that hits you rolls d100 (26+/34+/51+ for 3/2/1) and on a success is a miss that destroys one (H6); the teleport warp |
| Panic Transposition | 8 | B | offered when a melee or ranged attack hits you (M50): cast as your reaction; once the attack is resolved you teleport 30 ft (60 warped); resistance to that attack (warp); an occupied unseen square: 2d6 essence (basic Fort) |
| Pledgeshroud | 2 | C | a willing creature (M43, M51): −2 to Deception when implying the secret, a tick; the binding itself by hand |
| Spectral Aegis | 16 | B | resistance to all damage; absorbs the first hostile spell of PP 10 or lower (+1 a warp) whose targets or area include it — a targeted one is negated, an area spares it — then the Aegis ends; more absorbs, more targets, to the next preparation |
| Veil of Mist | 8 | A | a 20-ft emanation that follows you: everyone in it is concealed and sees out clearly |

## Found in review, fixed before release

An independent review of the build found these; each is fixed in the module and has its own checks and mutations.
1. **Arcane Bastion ended.** A plain 10-minute cast is not in TRG Prime's active-spell registry, so ending it there did nothing. The shield's end now deletes the caster's effects carrying the cast id (its resistance, its death guard), and also ends a registered cast.
2. **Mirror Reprise's last duplicate ends it.** The spell lays no effect of its own; the module's waiting effect is deleted, and a registered (D) cast is ended.
3. **Metamagic Resonance lasts.** It is keyed on its sustained cast's active-spell entry (it was keyed on the spell's id, which ended it on the first token move), and each lent effect carries the spell's duration.
4. **Panic Transposition.** The teleport keeps the book's timing, once the triggering attack is resolved, and is delivered to the bearer's owner (or the GM) over the module socket by the attacker's client; what it leaves pending is cleared when the attack is over (its Strike resolved, or a spell attack's cast settled), whatever the outcome, and nothing is sent for an attack not resolved, a refunded cast, or a bearer down or gone; the occupied-square save uses the Panic cast's own settled Save DC (`castSpell` returns none).
5. **Writes on another's creature** go through the GM (the module socket): Invoke True Name's spent weakness and Planar Anchor's veil are kept on the caster; Spectral Aegis's count and end, Mirror Reprise's images and end, Argent Reversal's charge and its absorb refund, and the auras' take-back are made by the GM when the client does not own the creature.
6. **Chronoweave's membership is live** (Q159): quickened on coming within 20 ft, not on leaving; the warp's slowed enemies are slowed while inside, with the value, for the duration.
7. **Primal Snap:** a Partial on its basic save is not a failure.
8. **Arcane Feedback's injury** rolls at the reactor's own Save DC (the settled cast's), not 0.
9. **Eaog Balls' coldfire timing** was put to Graham; he ruled it as built (08:35).
10. **Elemental Strike's card** says the Strike count is by hand.
11. **Mirror Reprise's step** is the bearer's (its owner's client); **Argent Reversal's Critical** may redirect only to a creature within the original spell's range; **Spirit Arrow's flat damage** is driven end to end against TRG Prime 3.685.0 (the rider through `strikeDamageReplacement`, the formula through `flatReplacementFormula`, and the attack workflow's `replacingFlat`).

## Found in the second review, fixed before release

A second independent review of the fixes above found these; each is fixed, with its probe kept as a regression test in `verify-block7` and a mutation in `mutate-block7`.
1. **The GM relay trusted the request** (high). A request could name any cast id and have the GM delete a core spell's effect from another creature (the probe deleted a Stoneskin), or write any value into a module flag. The GM now works out the cast ids from the creature's own state and ignores the request's; a flag write must be under the effect's own source key, and may only take a known counter down by one (or arm Mirror Reprise from 0 to 3), nothing else changed.
2. **PP through the relay** (high): uncapped and repeatable (the probe took 30/30 to 60). The relay writes no PP now. Argent Reversal's refund is made in its step on the bearer's own client, at most to its PP maximum.
3. **Arcane Bastion on a creature the client does not own** (medium): a refused write lost the lowered severity. The answer is worked out first; the record is cleared by the GM with the last of its cast's effects, and no write on the unowned creature is tried here.
4. **Two syncs at once** (medium): a group drag gave a creature two Chronoweave effects or two Metamagic Resonance lends (a lend used twice a round). The aura sync is serialised, with a "run again" mark for a move made during a run, and a duplicate found is removed.
5. **Panic Transposition's 30 seconds** (medium): prompts that took longer lost the teleport and the resistance. The record is matched on the attacker alone; only a record no attack ended in ten minutes is purged.
6. **A dismissed Mirror Reprise** (low) still diverted attacks. The waiting effect now carries the core's cast id, so the cast's end sweeps it, and a waiting effect whose cast has ended diverts nothing (nor stands in the way of a later casting's).
7. **The harness** (low): the fakes now throw on a write to a document the client does not own, as Foundry does, and a relayed write is made only on the GM side; checks for the socket listener registered at ready, `"socket": true` in the manifest, the active-GM and GM-only guards, `onCombatSyncB7` on `updateCombat`, `onTokenDeletedB7` on `deleteToken`, syncAll's `actsFor` guard, and clearPanicFor's attacker filter.
8. **Elemental Strike's chat card** says counting as a Strike is by hand, as its item card does.
9. **Chronoweave** (and Metamagic Resonance): the caster's token deleted removes the casting's effects from everyone (placed again within the duration, they are back); a re-cast refreshes the effects' duration.

## Harnesses

- **`verify-block7` (new, 580 checks):**
  - **A, the book:** the 42 are the audit's Block 7; each spell's PP, cast, traits, tradition ("all" → the four; High Magic none), uncommon, the printed text on its card, the card opening with its grade, a C card naming what is by hand, its key; the grade counts.
  - **B, the data through the core's own readers:** the thorns (H1: `normaliseThorns`, `spellThorns`, `warpedThorns`, `thornsLadderRows`, `thornsTriggered`), the caster-level steps (H2), the turn and entry ladders (H3: `normaliseTurnLadder`, `turnLadderStep`, `normaliseEntryCheck`), Dragon Wings' fly Speed through the real warp aggregator and `grantedSpeedBase` (H4: 35, 45, 75, and still 75 with a fifth warp), Spirit Arrow's rider and `damageReplacement` (H10), the held bonus, the marks, the conditions, Distracted's pools (`bonusTargetFor`), the defences as `actorDefences` reads them, the coldfire's unlock (`rowAppliesToCast`), Region claims and live zones, the death guard, the conditionals, the light shift, and that every warp mod key is read by the aggregator.
  - **C, the pure rules** of `module/block7-rules.mjs`.
  - **D, registration** into TRG Prime's real `module-api`, then **E, the Foundry side with fakes, run through the core's real collectors** (the fakes do only what the core does: `castAsReaction` returns no Save DC and the module reads the settled one; ending an unregistered cast returns null; a write to a document the client does not own throws; the module socket is delivered, when flushed, to a GM side that checks each write against the creature's current state): `runSpellCheckGates` (Arcane Feedback, Arcane Mycelium, Invoke True Name, Zone Disruption), `castReactionsFor` (Argent Reversal's `turnBack` and absorb, Spectral Aegis's `exclude`), `checkReactionsBefore` / `checkReactionsAfter` (Invoke True Name's save, Mirror Reprise's miss, Panic Transposition), `damageReactionsBefore` (the weakness, the arming, the resistance), `criticalAfterReactionsFor` (Arcane Bastion), `castRefusalFrom` and `castPreludeFrom`, `offeredDispelModifiers`, `fumbleModifiersFrom`, `lentMetamagicOf`, `effectsEndedByHealing`, `declaredFallReduction`; and the module's own hooks, Uses and steps.
  - **F, the wiring:** the entry script's eight hooks, registration, the packs, packs-source as built, Block 6's Pact grants, no card saying a Grimoire spell waits, the version pins.
- **`mutate-block7` (new): 216 mutations, all caught**, among them one for each fix of both reviews, one that moves Panic Transposition's teleport back to the hit, and the gaps the review named (Argent Reversal's can-see check removed, Spectral Aegis absorbing an ally's spell, Elemental Strike's melee-weapon check removed, the Panic Transposition and Mirror Reprise teleports' distance caps removed). It runs `verify-block7` with `EA_MUTATING=1`, which skips the packs-source parity check, so each content mutation is caught by a check of its meaning, not by a stale pack.
- **Changed for this release:** `verify-block1` (the new ability's Use is Block 7's), `verify-block4` (Flesh to Blossom's prelude is Block 7's), `verify-block6-lead` (C and G pins at 3.685.0 and 0.10.0; the spell-image counts, 59 by school and 32 the book), `verify-block6a` and `verify-block6e` (the Pacts and Pact Boon grant the spells; Pact Boon's Draconic case drives the built Dragon Wings), `verify-block6b2` (G17: TRG Prime 3.685.0 adds `exclude` and `turnBack` to every cast-reaction fold), `verify-book-extract` (the uncommon spells are the six and Block 7's 42). Every `mutate-*` version anchor points at 0.10.0 and 3.685.0; the pack and registration anchors of `mutate-block1` and `mutate-block6-lead` follow Block 7's lines.
- **Run, 7 November:** every `verify-*` in the module tree passes against TRG Prime 3.685.0 with its review fixes and `flat` — 19 files, 4,965 checks. Every `mutate-*` was run in a scratch copy — 19 files, 1,969 mutations, all caught. `build-zip` has no dry mode, so it was not run.
- **No callers check:** the module has no `uncalled-exports.json` (or other callers check); none was added.
