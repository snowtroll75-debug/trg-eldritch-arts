# Eldritch Arts Block 2: audit (High Magic and Chapter 7)

1 November 2026.

**Status:** Block 2a built as answered: Eldritch Arts 0.3.0 on TRG Prime 3.678.0 (`RELEASE_NOTES_0.3.0.md`). Two departures from the proposals above, both found while building: the API row's `regionsAt` and `rollPercentileTable` were not needed (the module reads Region Behaviours itself; the core added `regionContains` and `rollResonanceEvent` instead), and D14 is a synchronous predicate on `isSuppressed` rather than a region lookup in the core. Block 2b (rituals, circles, true names, Spell Trickery, Borrow Spell) is built as Eldritch Arts 0.4.0 on TRG Prime 3.679.0 (`RELEASE_NOTES_0.4.0.md`), with Q9–Q14 below built as proposed. Two departures from the proposals: the circle is an effect on the caster, as proposed, but its Critical's binding is a required casting option (+2 Save DC) rather than a save penalty on the creature; and Spell Trickery's observers get a skill action of their own (See Through Spell Trickery) rather than only the card's line.

**Read against:**
- **The book:** *Eldritch Arts* v1.6 (`ea.md` and its 34 sidebars):
  - Chapter 1, High Magic (L89);
  - Chapter 4's remaining actions (L1786–2068);
  - Chapter 7 in full (L5512–5983);
  - the Appendix traits HIGHMAGIC, RITUAL and SUMMONS (L10718, L10740, L10748).
- **The rulings:** Graham's of 1 November 2026, `ELDRITCH_ARTS_RULINGS_2026-11-01.md`: M4–M9, M20, M27, M29, M30, C3 and m14.
- **TRG Prime 3.677.1:** surveyed in its source. Every system claim below was read there.

## Scope

| Group | Book | What it is |
|---|---|---|
| **High Magic casting** | Ch1 L89; Ch7 L5548–5619; Appendix HIGHMAGIC | Casting DC +2 (Hard); no focus unless Arcanum or Archmage; armour DR × 4; Fumble/Blunder auto-fail with +60 on the fumble roll (on top of the tradition modifier, M4); Resonance with disadvantage; identified at Very Hard; counts as all traditions (M27) |
| **Ley lines** | Ch7 L5621–5714; Ch4 Channel, Tap (L2002–2044); sidebar 5 | Lines with a level (Sense DC table); Tap Ley Line (1 AP) and Channel Ley Line (10 min); the 1d100 Ley Line Effects table (Effect and Backlash) |
| **Tap Magical Energy** | Ch4 L2046 | Siphon PP from a charged item; DC by C3 (the item's level DC) |
| **Wild Magic areas** | Ch7 L5716–5792 | Partial or worse in an area rolls the 1d100 Wild Surge table, scaled by the area's level (M7) |
| **Magic Suppression areas** | Ch7 L5794–5862 | A penalty equal to the level; Partial/Failure/Fumble become Failure and Blunder becomes Fumble; no Resonance; a backlash table on a failed cast in areas that have it (M8); antimagic at 20+ |
| **Mundane rituals** | Ch7 L5866–5926; Appendix RITUAL | A non-caster may lead a ritual; PP replaced by vital, material or communal sacrifice; the tradition skill at Very Hard; Ritual-trait spells lift the core's Success cap (M30) |
| **Summoning circles, true names** | Ch7 L5930–5982; Appendix SUMMONS | The circle check and its modifiers; a true name gives +4 to the Save DC |
| **Spell Trickery, Borrow Spell** | Ch4 L1800, L1882 (m14 as rewritten) | The two Chapter 4 actions Block 1 did not take |
| **Block 1's goods that wait for this block** | Ch6 | Ritual Censor, Runestone Chalkboard, Ward Twine, Void Chalk, and the goods whose bonus is on ley lines or wild magic areas |

**Not in this block** (they belong to the blocks that hold their items, as the block plan says):
- The classes and archetypes that cast High Magic (Blocks 3, 4 and 6).
- The Highmagic, Ritual and Summons spells themselves (Blocks 7 and 8).
- The feats that read these rules: Leyline Weaver, Ley Channeler, Channel Siphoner, Circle Adept, High Magic Resonance, Spell Surge and the others (Blocks 5 and 6).
- The Relic Bonding Ritual (Block 10).

Block 2 builds the rules those blocks will use, and tests them on throwaway items.

## What TRG Prime has today

**High Magic** (`module/magic/high-magic.mjs`):
- A boolean actor flag, `flags.trg-prime.highMagic`, set by Fiends & Fables creatures.
- It gives spell save DC +2, free Heighten and fumble +50, read in three places in `cast-workflow.mjs`.
- It never touches the casting DC.
- Nothing knows whether Eldritch Arts is active.

**The casting check** (`castSpell`):
- **The DC:** a fixed list of named parts (`assembledCastingDC`). A module can add none of them, and a module cannot set the difficulty step (always Moderate, or Very Easy for a specialist spell).
- **Armour:** `armourCastingPenalty` is DR × 2 for armour that the caster's tradition prohibits, and 0 for Divinity.
- **Focus:** +1 with it, or −2 without it, plus +10 on the fumble roll, for a focus caster only.
- **The degree:** fixed in sequence; a module cannot remap it.
- **Refusing a cast:** the only module route is an actor effect flagged `castingRestriction`, whose card says "a critical injury".
- **Spell-check gates** add rows before the roll but cannot refuse or remap.

**Fumble and Resonance:**
- **Fumble:** `rollSpellFumble` adds the tradition modifier (one exact tradition name only, so a multi-tradition spell gets 0), +5 per PP, +20 for a Blunder, +10 without a focus, +20 for a ritual, the effect flag `spellFumbleModifier`, and High Magic +50.
- **Resonance:** `rollResonanceEvent` rolls once, with no advantage, disadvantage or suppression. It is reached from six places.

**Areas:**
- Each mechanism is a Region with its own `flags.trg-prime.<key>` and its own sweep. The ward zone (`combat/ward-zone-workflow.mjs`) is the nearest pattern: effects on whoever stands in it, resynced on token and region changes.
- No helper tells a module which areas a token is in.

**Antimagic:**
- An Antimagic Field emanation switches off every actor effect flagged `spellBuff` while you stand in it, and switches them back on when you leave.
- It does not refuse casting, and it does not touch items or creature magic.

**Rituals** (`rollMagicRitual`):
- **Who and how:** the sheet's actor is the primary, the check is Spellcraft against `castingDC(PP)` plus the ritual modifiers, and only the primary pays PP.
- **The cap:** the degree is capped at Success.
- **Hooks:** no module hook.
- **The Ritual trait:** read by no code.

**Summoning:**
- None. Conjure spells print a level note and offer control.
- There is no summoning mechanism and no hostility tracking.

**Tables:**
- No RollTable use. The d100 pattern is `rollChain` with `OPEN_ENDED.TOP` and `{min, max}` rows.

## Core seams needed (TRG Prime 3.678.0)

These are prepared for your approval, as Block 1's were.

| # | Seam | For |
|---|---|---|
| **D1a** | **A High Magic cast.** A cast is High Magic when the spell has the Highmagic trait, or when the caster is a High Magic caster (a flag a class, archetype or creature declares). A High Magic cast gets:<br>- the casting check at Hard (+2);<br>- armour as DR × 4 (Q3);<br>- the focus set aside unless Arcanum or Archmage (Q2);<br>- fumble +60 on top of the tradition modifier (M4);<br>- Resonance rolled with disadvantage;<br>- the card says "High Magic". | All High Magic |
| **D1b** | **Eldritch Arts' rules supersede the old ones (M4).** While a module declares it (`registerHighMagicRules("eldritch-arts")`), a Fiends & Fables creature's High Magic uses D1a. That means no save DC +2 and no free Heighten, and fumble +60 instead of +50. Without Eldritch Arts, nothing changes. | M4 |
| **D1c** | **"All traditions" (M27).** A Highmagic-trait spell counts as every tradition for the gates, counters and tradition bonuses. It has no school (M29). Its fumble's tradition modifier is the caster's own (Q4). | M27 |
| **D6** | **Resonance with disadvantage, and Resonance suppressed.** `rollResonanceEvent` takes `disadvantage` (two base rolls, keep the higher, open-ended once) and asks registered suppressors. A suppression area answers "none here". | High Magic, suppression areas |
| **D7** | **The casting degree remapped, and a cast refused.** A registered remap runs after the roll and before `castingOutcome` (suppression: Partial/Failure/Fumble → Failure, Blunder → Fumble). A gate may answer `refuse` with its own reason, before anything is spent (antimagic). | Suppression, antimagic |
| **D13** | **Rituals.** `rollMagicRitual` takes a variant:<br>- the primary may be a non-caster trained in the tradition skill;<br>- the check is that skill at Very Hard against the primary's level DC (Q5);<br>- the payment is PP, vital, material or communal.<br>A Ritual-trait spell lifts the Success cap (M30) and reaches its outcome lines by degree, and cannot be cast except as a ritual. | Mundane rituals, Ritual spells |
| **D14** | **Antimagic for items.** `TRGActiveEffect.isSuppressed` asks registered predicates, so an item's own effects (magic-item properties) switch off inside an antimagic zone and back on outside. | Antimagic zones |
| **API** | `regionsAt(token)` and `rollPercentileTable(rows, {disadvantage, openEnded})` on the module helpers | Areas, tables |

## Proposed builds

### Areas (module)
Each area is a Region with a module behaviour type, so the GM adds it in the Region's own config and sets its level:
- **Ley Line** `{level}`;
- **Wild Magic Area** `{level}`;
- **Magic Suppression Area** `{level, backlash}`, antimagic when the level is 20 or more.

The card shows the band names (Minor Ley Thread … Legendary Ley Nexus; Flickering … Dead zone, Antimagic).

**Ley Sense** (Block 1) reads the nearest line in range for its DC by the Chapter 7 table (M5: the default; the GM may override).

### Tap Ley Line and Channel Ley Line (module skill actions)
- **Range:** a ley line within 30 ft.
- **DC:** level-based, Hard for Tap and Very Hard for Channel. Channel's PP band comes from the line's level: Minor 1–4 … Legendary 17+.
- **Tap:**
  - **Success:** the Effect column of the Ley Line Effects table, until the end of your turn.
  - **Critical:** the same, until the end of your next turn.
  - **Failure:** 1d6 × level force damage (basic Will) and a 1-hour lockout.
  - **Fumble:** the same damage plus the Backlash column, and a 24-hour lockout (M6).
- **Channel:**
  - Rolls PP by band + tradition ability, capped at your maximum.
  - **Heroic and Critical:** also the Effect column, for 1 minute or until the end of your next turn.
  - **Failure:** take the PP as essence damage (basic Fort); doubled on a Fumble, tripled on a Blunder with a lockout until tomorrow.
  - **Backlash:** Channel never rolls it (M6).

### The Ley Line Effects table (40 rows)
- **Rows on an existing system channel are automated:**
  - AB, DB, save and skill bonuses (untyped, as printed);
  - temp HP, heal and lost HP;
  - PP gained or lost, and the next spell's PP;
  - advantage and disadvantage;
  - Save DC ±2;
  - resistance and weakness;
  - force damage with its basic save;
  - Blinded, Stunned, Slowed and Weakened;
  - Prayer;
  - range and damage dice on the next spell, where the system has a warp for them.
- **Rows that need metamagic feats** (extend, reach, split, quicken) wait for the metamagic block (D2, Block 6). Until then the card says what to apply.
- **Rows that are GM's choice** (100, a critical injury's severity) are posted as text.

### Wild Magic areas
- **Trigger:** a cast whose casting degree is Partial or worse, or a chaos result, inside the area rolls the Wild Surge table.
- **Scaling (M7):** damage 1d8 × level, range 5 ft × level, duration 1 round × level unless printed otherwise. Row 12–15 is as rewritten.
- **Automated:** the explosion, the healing, the teleport offer, the barrier DR, fast healing, PP and HP rolls, conviction, conditions, the end or doubling of effects in the area, and the regain-all.
- **Text:** the elemental, the random language, Time Stop and critical injuries.
- **The Wild Mage's own trigger** (UM 13) arrives with the Wild birthright (Block 3).

### Magic Suppression areas
- **The penalty:** a spell-check gate row equal to the level.
- **The degree:** the D7 remap.
- **Resonance:** none (D6).
- **Backlash:** in areas marked for it, a failed cast rolls the Suppression Backlash table (M8).
- **Bands:** dead zones are 16–19 and antimagic is 20+ (M8).
- **Antimagic (20+):** casting is refused (D7). While you stand inside, your spell effects switch off (the core's antimagic machinery) and your items' effects switch off (D14); all come back when you leave. Creature innate magic is "magical abilities" in the book; the core's Antimagic Field leaves it alone, so Q6 asks.

### Tap Magical Energy
- **Target:** a charged item in hand. **DC:** the item's level DC (C3).
- **Siphon:** the PP is held as a pool that must be spent by the end of your next turn (the same pool as Magic Drain's energy, Block 1); the item's charges are reduced.
- **Blunder:** rolls the core's item depletion table.

### High Magic identification
Identify Spell (Spell Recognition) against a High Magic cast is Very Hard (+5). The system's identify action has no spell in hand, so this is a tick on the check plus a line on the High Magic cast card.

### Mundane rituals, Ritual spells, summoning circles and true names
- **Mundane rituals:**
  - The ritual dialog offers the variant (D13): the tradition skill, the level DC Very Hard, and the payment.
  - **Vital:** the primary takes 1d8 essence per PP and each secondary 1d4 per PP, basic Fort, bypassing DR, resistance and immunity.
  - **Material:** the gp from the table, taken from the primary's purse.
  - **Communal:** the secondaries pay the PP +50%, split.
- **Summoning circles:**
  - **Inscribe Summoning Circle** is a module skill action (the tradition skill, the creature's level DC, Moderate, 10 min × level). The table's modifiers are ticks.
  - **Result:** the circle is an effect on the caster for 1 hour per caster level. It gives +4, +2 or −2 circumstance to the casting check of Summons-trait spells. On a Critical, the creature also takes −2 to its saves against your Summons spells. On a Fumble, the card says the creature arrives hostile and unbound.
- **True name:** a cast option on a Summons spell gives +4 to its Save DC. On the creature's success, the card says it is now permanently hostile to you.

### Spell Trickery and Borrow Spell
- **Spell Trickery:** a cast-dialog option, +2 to the casting DC. The card gives observers your Deception DC and the seven rungs.
- **Borrow Spell** (m14 as rewritten): a skill action against another caster's spellbook spell, at Easy, against the DC to learn it.
  - **Success:** the spell is copied to your spellbook marked "borrowed", to be prepared today, and removed at your next daily preparation.
  - **Failure:** you cannot try that spell again until your next preparation.

## Questions for Graham

| # | Question | Proposal |
|---|---|---|
| **Q1** | **M4 as built.** With Eldritch Arts active, Fiends & Fables creatures lose their High Magic save DC +2 and free Heighten. Their casting check becomes Hard, their fumble +60 and their Resonance disadvantaged. Is that what you intend? It changes every F&F creature flagged High Magic in a world that also runs Eldritch Arts. | Build as you ruled. Turn it off if you say so. |
| **Q2** | **Focus.** "It is impossible to use a casting focus when casting high magic spells unless…". For a focus caster, does that mean only that the +1 is lost, or also the core's −2 and +10 fumble for casting without a focus? | The +1 is lost; no −2 and no +10. The focus is set aside, not missing. |
| **Q3** | **Armour.** Does DR × 4 replace the tradition's armour rule (prohibited armour × 2; Divinity none) for a High Magic cast, and count every worn armour? | It replaces it, and counts all armour, Divinity included. |
| **Q4** | **Fumble tradition modifier for an all-traditions spell.** M4 says the +60 adds to the tradition modifier. A Highmagic-trait spell is every tradition. | The caster's own tradition's modifier. |
| **Q5** | **The mundane ritual check.** "Very Hard (DC +5) level-based DC equal to the wielder's level." | The primary's level DC +5 replaces the PP-based ritual DC. The core's ritual modifiers still apply: +2 per PP over, +2 per secondary of a different tradition, the time and duration options. |
| **Q6** | **Antimagic and creature innate magic.** "No spell or magical ability functions inside." Should a creature's innate spells and magical abilities also be refused there? | Yes for casting, including innate. Passive abilities are left as they are, as the core's Antimagic Field does. |
| **Q7** | **Wild surges from rituals and item casts.** Does a scroll, wand or ritual cast inside a Wild Magic area surge? | Yes: any casting check in the area. |
| **Q8** | **The Ritual trait.** The Appendix says such a spell "may only be attempted as part of such a ritual, never as a standard casting action". The core's own Ritual trait (Clone) has never been enforced. | Enforce it only for Eldritch Arts' Ritual spells, so that Clone is unchanged. |

## Graham's answers (1 November 2026, 19:15)

| # | Ruling | As built |
|---|---|---|
| Q1 | As proposed | With Eldritch Arts active, a Fiends & Fables High Magic creature casts under D1a: Hard, fumble +60, Resonance disadvantaged, no save DC +2, no free Heighten. |
| Q2 | As proposed. "Remember an Archmage or Sorcerer with the Arcanum Birthright can still use them." | A High Magic cast sets the focus aside (no +1, no −2, no +10), unless the caster has an item declaring `highMagicFocus` (the Archmage class; the Arcanum birthright). |
| Q3 | As proposed, "but only for High Magic classes and other casters using High Magic spells" | DR × 4 on all worn armour, replacing the tradition rule, for a cast that is High Magic because of the caster's class or archetype or the spell's Highmagic trait. A Fiends & Fables creature's flag alone does not bring it. |
| Q4 | As proposed | The caster's own tradition modifier for an all-traditions spell. |
| Q5 | As proposed | The primary's level DC +5 replaces the PP-based ritual DC; the core's ritual modifiers still apply. |
| Q6 | As proposed | Antimagic refuses every cast, innate included; passive abilities are left alone. |
| Q7 | "Yes they do" | Any casting check in a Wild Magic area can surge, scrolls, wands and rituals included. |
| Q8 | As proposed | Only Eldritch Arts' Ritual-trait spells are refused outside a ritual. |

## Block 2b questions (2 November 2026), built as proposed

Sent to Graham when Block 2b began; each is built as proposed until he rules otherwise.

| # | Question | Proposal, as built |
|---|---|---|
| **Q9** | **A variant ritual's PP cap.** The variant lets a Caster Level 0 primary lead; the brief says never bypass maximum PP per cast. | The cap stays: caster level + 1, plus the ritual's 2 PP per secondary. Overcasting by Sacrifice applies above it. |
| **Q10** | **Preparation.** Does a variant ritual need the spell prepared? | A caster leading one does, as for any cast; a non-caster (CL 0) only needs it on their sheet. |
| **Q11** | **How much is substituted.** "In place of PP expenditure". | The PP the degree would have spent (Success all, Critical half the base, Failure half, Fumble or Blunder all, Partial none). Vital 1d8/PP on the primary and 1d4/PP on each named secondary; Material the table's gp from the primary's purse; Communal +50% rounded up, split evenly among the named secondaries. |
| **Q12** | **Ward Twine:** "the circle's effective DC increases by +1". | +1 to the Save DC of Summons spells cast from the circle (harder to escape), not a harder circle to draw. |
| **Q13** | **Ritual Expert:** "count as two casters … for the purpose of caster requirements and benefits". | One extra seat, as primary or secondary, for the one-secondary requirement and the 2 PP headroom; the degree modifier is not doubled; not stacking with Rune-Binder's Precision (M21). |
| **Q14** | **High Magic in a ritual.** | Hard (+2) applies to the ritual check, standard or variant. |

**Found in review, ruled 2 November 2026:** a *standard* ritual over the caster's cap is still offered Overcasting by Sacrifice after its roll (its DC rise never reaches the rolled check). Graham: "No for standard rituals" — left as it is; only a variant is refused before its roll.

## Minor points (no ruling needed; reported for the book)

- **m73 (still in v1.6):** "another spell that effects a specific school" (L5562) should be "affects".
- **m74:** v1.6 now prints the Eligibility paragraph once. Fixed.
- **m75:** "(GM Discretion" is missing its closing bracket (L5961).
- **v1.6 L5750:** "WILD MAGES & WILD MAGIC AEAS".
- **Sense DC table:** Prime 13–16 is 18, between 20 and 15, so it is not a step of 5. Built as printed.
- **Bands:** "Level 16-20" and "Level 20+" share 20 (M8: dead zones 16–19).

## The block in two releases

The block is large, so it ships in two releases, each with its own harness, sweep and live test:

- **2a (EA 0.3.0, TRG Prime 3.678.0):**
  - High Magic (D1, D6, D7);
  - the three kinds of area and antimagic (D14);
  - Tap Ley Line, Channel Ley Line, Tap Magical Energy;
  - the Ley Line Effects, Wild Surge and Suppression Backlash tables;
  - High Magic identification;
  - the goods that read ley lines and wild magic.
- **2b (EA 0.4.0, TRG Prime 3.679.0):**
  - rituals (D13), mundane and Ritual-trait;
  - summoning circles and true names;
  - Spell Trickery and Borrow Spell;
  - the ritual and circle goods.
