# Eldritch Arts Block 3: audit (Archmage, Sorcerer, Witch)

2 November 2026.

**Status:** audited. Graham, 2 November 2026, 11:24: "your proposals all work" — Q15–Q25 are answered as proposed. Block 3a is built as Eldritch Arts 0.5.0 on TRG Prime 3.680.0 (`RELEASE_NOTES_0.5.0.md`).

**Read against:**
- **The book:** *Eldritch Arts* v1.6 (`ea.md` and its 34 sidebars).
  - Chapter 3's Archmage (L629–728), Sorcerer and its seven birthrights (L731–1168), and Witch (L1642–1770).
  - Sidebar 5, "Ley Line Range", after L703.
  - Sidebar 6, "Resist Magic", after L990.
  - The Specialist Spells chapter (L8077–8830).
  - The five Grimoire spells the birthrights name.
- **The rulings:**
  - Graham's of 1 November 2026: M1, M2, M15, M16, M23, C2, C7, R7.
  - Block 2's Q1–Q14.
- **TRG Prime 3.679.0:** surveyed in its source. Every "the core has" claim below was read there, with file and line in the survey notes. A JSON dump of the core packs was used for the items.

## Scope

| Group | Book | What it is |
|---|---|---|
| **Archmage** | L629–728 | Adept; HP 4 + Con; 4 + Int skills. Ley Bond: High Magic casting DC −1, and senses ley lines within 100 ft per level. Ley Tap: advantage on Power Recovery (Meditation) within ley line range, which sidebar 5 sets at the Ley Bond range. Scribe Scroll at 1st; a class feat at 5th and every 5. A learned High Magic caster of every tradition: six PP 2 spells at 1st, +1 a level (PP no higher than castable), memorise 2 + 2 × level (M16). Six cantrips in the book, three memorised a day. Int. Specialist spells only through the Specialist Spell feat, from any class (GM). Table: PP 5 a level, caster level and BSB equal to level. |
| **Sorcerer** | L731–1100 | Adept; HP 6 + Con. Raw Power: a High Magic warp may go 1 PP over the cap. Component Mastery and Empower Spell at 1st; a class feat at 5th and every 5. Instinctive, every spell High Magic. One spell at 1st from any tradition, another at 3rd and every two levels; one birthright-tradition spell at 2nd and every two levels. Two cantrips, one from the birthright tradition and one from any. The magical ability is the birthright's first key ability. Table: PP 6 a level. |
| **The seven birthrights** | L847–1100 | Each sets key abilities (the first is the magical ability), two bonus class skills, a special ability, a specialist spell and where more may be chosen, the tradition-spell source, and the additional spells (a cantrip and a PP 2 spell at 1st, then one at 3rd, 5th … 15th). |
| **Witch** | L1642–1770 | Adept; HP 6 + Con; simple weapons, no armour. Soulbound Familiar: Base DR 2, +HP equal to the Witch's level, the Witch's Charisma as a class bonus to its saves, a +1 spell adder, one daily-chosen bonus of eight while within 30 ft. Severed Bond: fatigued 2 until a new bond (1 hour, at daily preparation). Verdant Communion: once a day, 10 minutes, a Power Recovery (Meditation) check whose bonus PP are regained, and +2 class to Nature and Survival for an hour. A class feat at 1st (M15), 5th and every 5. Ethereal and Verdant spells as High Magic: two at 1st, one more at 2nd and every level. Hexes as specialist spells: one at 1st, one at 3rd and every three levels. Two Ethereal or Verdant cantrips, as High Magic. Cha. |
| **Their specialist spells** | L8077–8830 | 34 of the chapter's 41 (below). The other seven are the Spellblade's (Block 4) and Ley Walker (C7). |
| **Grimoire spells the birthrights need** | Grimoire | Observe the Weave (16), Message Rune (2), Symbol of Fear (12), Symbol of Death (16), Dark Whispers (4) |

**The 34 specialist spells:**
- **Archmage (3):** Arcane Singularity, Ley Sever, Paradox Weave.
- **Sorcerer, "Birthright Any" (3):** Ancient Aegis, Evershade Veil, Ley Bolt.
- **Sorcerer, one birthright each (6):**
  - Disrupting Magic (Arcanum);
  - Draconic Infusion (Dragon);
  - Touch of Healing (Eternity);
  - Storing Rune (Rune; "may also be learnt by the Runemage archetype");
  - Storm Bolt (Storm);
  - Shadow Shift (Umbral).
- **Witch (22):**
  - Life Boost: the Witch trait, not a hex.
  - The 21 hexes: Absorbent Beard, Armouring, Baneful Magic, Baneful Weapon, Bulging Eyes, Cackle, Cloak of the Deceiver, Delay Affliction, Familiar Senses, Hemocovenant, Hex Ward, Malicious Shadow, Missed Chance, Phase Familiar, Prehensile Tail, Prophetic Warning, Purity Hex, Second Chance, Siphon Vitae, Tentacle, Weakened Element.
  - Hemocovenant and Siphon Vitae also carry the Bloodmage trait.

**The birthrights' additional spells, checked against the core:**
- 47 of the 53 are core spells at the printed PP (M1's doubling is in v1.6).
- The five above are new, printed with an asterisk.
- **Storm's "Shock Bolt (0)":** the core's Shock Bolt is 4 PP (Q15).

**Not in this block:**
- The Spellblade and Warlock (Block 4).
- High Sorcery and Forbidden Lore, the feats that add spells to these classes, and the other class feats (Block 6).
- Birthrager's use of a birthright (Block 6, M23). It will reuse this block's birthright items.

## What TRG Prime has today

**A class registration** (`registerClass`):
- **What it carries:** a proficiency entry and a wealth fallback, and the Divine Aspect and Wizard School switches.
- **What it gives a module's class:** its name becomes a feat gate, by trait and by "Non-X".

**The class item** (`template.json` Item.class) carries:
- type and tier, key abilities, class skills;
- granted feats and abilities, levelled ("1: Scribe Scroll");
- HP and skill points;
- tradition, magical ability, caster style;
- memorisation style (`book` or `list`), repertoire category;
- cantrips per day and known, first spell-book picks;
- granted gear and spells;
- a 20-row progression of BAB, BDB, saves, cumulative bonus feats, caster level, PP and BSB.

Inner Tempest's `classItem()` builder and its book check are the pattern; Eldritch Arts will be the first module to check caster level, PP and BSB against a book.

**The spell book** (the Wizard's):
- **What fits the Archmage:**
  - six first picks at exactly PP 2;
  - memorise 2 + 2 × level (hard-coded, and M16's number);
  - cantrips per day.
- **What does not fit:**
  - **The ladder is fixed at +2 spells a level.** The Archmage gets +1.
  - **There is no cantrip book.** Daily cantrips are drawn from the whole tradition.

**The repertoire** (instinctive casters):
- **What it has:** one pick schedule per class (`firstPicks`, `pickFrom`, `pickStep`; swaps), filtered to the class tradition. Cantrips known come from the class tradition only.
- **What the Sorcerer needs that it lacks:**
  - a second track (the birthright tradition at 2nd, 4th …);
  - cantrips from two different filters.

**Choosing a subclass:**
- **What exists:** `abilityChoices` on a class ability. Press Use, choose, and the chosen ability is granted. It is what Inner Tempest's Monastic Path uses.
- **What the chosen ability can grant:** levelled spells (`grantedSpells`, which land prepared and outside the pick count), abilities, feats and class skills.
- **What it cannot set:** the magical ability or a tradition. The only hook is the actor flag `castingAbilityChoice`, whose cleanup belongs to Charismatic Caster.

**High Magic:**
- **How a caster is marked:** `highMagicCaster: true` on any live item makes every cast High Magic.
- **What it cannot express:** a caster whose High Magic is limited to some traditions.
- **The tradition limit:** a class must name one of the four traditions. A blank one gives no PP ability bonus, and a blank ability gives caster level 0. There is no "every tradition" class.

**Specialist spells:**
- **How they cast:** the cap is the character's level, and the check is Very Easy.
- **How they are granted:** by any grant field.
- **What no free pick offers:**
  - **No free pick offers them.** The repertoire excludes them, and `chooseSpell` has no option for them.
  - **The Specialist Spell feat** filters by the spell's `specialistClass` against the character's classes and archetype `classGrants`. An ability cannot add a class there, and there is no trait filter: the Umbral birthright's "the shadow trait" can't be expressed.

**Familiars:**
- **How one is created:** the core Familiar feat calls `createFamiliarFor`, which is not in the module API.
- **How it derives:** from a snapshot of the master: level, saves, BAB and BDB, HP and skills.
- **What it carries no master ability for:** the Witch's Charisma to its saves.
- **Where its HP comes from:** overwritten from the master's (half, plus Tough). The Witch's "+level HP" has no place to go.
- **No module hook (D8).**

**Arcane Bond and focus:**
- **Arcane Bond:** a module ability named "Arcane Bond" gets the core Use and its spell adder.
- **Casting focus:** a pair of actor checkboxes, not an item concept.
- **High Magic and the focus:** High Magic sets the focus aside unless an item declares `highMagicFocus`.
- **What Sorcerous Bond can do today:** declare `highMagicFocus`, as the Arcanum birthright needs. "The item is also a Casting Focus" has no item seam.

**Extra PP per level:**
- **The only channel:** the name-keyed `PP_GRANTS` table, not reachable by a module.
- **Found by this survey: a Block 1 defect.**
  - **The registration does nothing:** `registerRacialPP` is stored, but its only reader (`racialPPDue`) is called by nothing, and `PP_GRANTS` is built from the core's race and heritage tables alone.
  - **What this means:** Eldritch Arts' four racial PP (Aetherial +1, Emberkin +1, Nyrinn −1, Scaelyn +1 per level) are registered but reach no character.
  - **How it escaped:** `verify-block1` checked the registration, not the sheet. The core fix belongs with the PP-per-level seam below.

**Natural weapons:**
- **Granting one:** `grantedWeapons` works for a race, heritage or feat, not an ability.
- **Rolling with BSB:** not built (D17).

**Reusable as they are:**
- Darkvision, Arcane Bond, Scribe Scroll, Component Mastery, Empower Spell and Specialist Spell.
- The Death State effect (Diehard's shape).
- The spell adder flag.
- The advantage conditional on `powerRecovery`.
- The ally-aura channel, though it reaches every ally, not only the master.
- Spell Storing, for Storing Rune.
- Defence offers, for Shadow Shift.
- The multiple attack penalty, for Malicious Shadow.
- The critical roll's advantage seam (Harmony Edge), whose mirror is Eternity's.
- Spell-check gates, for Ley Bond's −1.

**Not in the core:**
- **Resist Magic** (sidebar 6), **High Sorcery** and **Forbidden Lore**.
- **A reaction that rerolls another creature's check** (Missed Chance, Second Chance). The core's Lucky Break is a name-keyed save reroll.
- **A reaction to a spell being cast nearby** (Disrupting Magic).

## Core seams needed

Too many for one release, so Block 3 is split as Block 2 was.

**Block 3a (TRG Prime 3.680.0): the classes.**

| Seam | What it does | For |
|---|---|---|
| **D4a High Magic class tradition** | A class may declare its tradition as High Magic, of every tradition or a listed few. The PP ability bonus and caster level work from its magical ability, picks and cantrips draw from the listed traditions, and its casts are High Magic. `highMagicCaster` gains an array form, so only spells of those traditions are High Magic. | Archmage (every tradition), Sorcerer (every tradition), Witch (Ethereal, Verdant) |
| **D4b Spell-book ladder** | Class `learnedPerLevel` (default 2) and the PP ceiling of those picks | Archmage (+1 a level) |
| **D4c Cantrip book** | Class `cantripBook: N`: cantrips picked into the book, with `cantripsPerDay` memorised from it | Archmage (6, memorise 3) |
| **D4d Second repertoire track** | A second schedule on the class, each track with its own tradition filter, and cantrips known with one filter per pick | Sorcerer (any, then birthright) |
| **D4e Subclass magic** | A chosen class ability may declare the magical ability and a track's tradition; both leave with the ability | Birthrights |
| **D5 (cap half)** | `registerCastModifier`'s `capDelta`, read before the PP check; a warp-only condition | Raw Power |
| **D8 Familiar modifiers** | `registerFamiliarModifier(key, (master, familiar) => changes)` in familiar derivation, after the HP overwrite. The master's abilities go in the snapshot. `createFamiliarFor` goes in the module API. | Soulbound Familiar |
| **D17 Attack base** | `attackBase: "bsb"` on a weapon, read by the attack roll; `grantedWeapons` on an ability | Dragon Claws |
| **Specialist access** | `registerSpecialistAccess(key, (actor, spell) => bool)` read by the Specialist Spell feat; an `allowSpecialist` filter on `chooseSpell` | Birthright lists, the Umbral's shadow trait, the Archmage's any class, hexes |
| **PP per level** | `registerPPGrant(name, perLevel)` in the `PP_GRANTS` reconcile; registered racial PP joins it | Wild Power; **fixes the four races** |
| **Natural roll on the settled hook** | The cast's unmodified d20 on `trgPrimeSpellSettled`, if it is not already there | Wild Power's UM 13 |

**Block 3b (TRG Prime 3.681.0): the specialist spells and hexes.**

| Seam | What it does | For |
|---|---|---|
| **Check reroll offers** | `registerCheckReaction(key, {offer, apply})`, asked after a d20 check's result (attack, save or skill) of anyone within range of the reactor | Missed Chance, Second Chance |
| **Before-check offers** | The same registry, asked before the roll, may give advantage | Prophetic Warning |
| **Damage reactions** | Asked as damage from a spell or effect lands; may grant a resistance for that spell | Resist Magic, Phase Familiar |
| **Cast reaction window** | A creature within range of a cast may react before it resolves; the reaction's result can end the cast | Disrupting Magic |
| **Critical offers** | Guarded and Harmony Edge opened to a registry, with disadvantage as well as advantage | Eternity Resilience |

## Proposed builds

### Classes (module, D4)

- **Three class items** from the book's tables, checked row by row:
  - BAB, BDB, the saves and bonus feats;
  - **first time:** caster level, PP and BSB.
- **Fields:** each carries its HP, skill points, key abilities, class skills, granted feats and abilities (levelled), and wealth.
- **Each class registered:** proficiency (Archmage club and staff; Sorcerer and Witch simple weapons; no armour), and the class name as a feat trait.
- **Archmage:**
  - book caster, six first picks at PP 2, +1 a level;
  - six cantrips in the book, three a day;
  - Int, High Magic of every tradition.
  - **Ley Bond:** a spell-check gate of −1 on a High Magic cast, plus the Ley Sense range on the map from Block 2.
  - **Ley Tap:** advantage on Power Recovery (Meditation) while a Ley Line area lies within 100 ft per level (sidebar 5).
- **Sorcerer:**
  - **the repertoire:** first track any tradition (1 at 1st, then 3rd, 5th …); second track the birthright tradition (2nd, 4th …);
  - **cantrips:** one from the birthright tradition, one from any;
  - High Magic of every tradition;
  - **Raw Power** through D5;
  - **Birthright:** a choice of seven.
- **Witch:**
  - repertoire of Ethereal and Verdant (2 at 1st, then 1 a level);
  - two cantrips of those traditions;
  - Cha;
  - High Magic for those two traditions only;
  - hexes picked by a specialist pick: 1 + floor(level / 3).

### Birthrights (module)

Seven abilities, each granted by the Birthright choice and carrying:
- its magical ability (D4e) and two class skills;
- its specialist spell;
- its specialist access (Wizard, Cleric or Druid list, shadow trait, or any);
- its tradition track;
- its additional spells (levelled `grantedSpells`, prepared, outside the pick count).

The special abilities:
- **Sorcerous Bond:** the core Arcane Bond under its own name, writing the same flag, with `highMagicFocus` and the focus checkboxes set while the bonded item is held.
- **Dragon Claws:**
  - a 1 AP Use that grants a 1d6 piercing natural weapon, agile and finesse, rolled with BSB (D17);
  - the dragon type chosen once, stored and read by Draconic Infusion.
- **Eternity Resilience:**
  - +2 Death State;
  - a critical offer: spend Conviction (once a turn) for disadvantage on the critical roll (3b).
- **Runic Resilience:** Resist Magic, built as its own reaction (3b).
- **Gale Step:** 1 AP, 15 ft teleport, with the target picked on the map as Block 2's actions do.
- **Umbral Affinity:** Darkvision; Darkness at 5th, granted as a specialist copy.
- **Wild Power:**
  - +1 PP a level (PP-per-level seam);
  - a natural 13 on a spell of PP 2 or more rolls the Wild Surge table (Q20);
  - a random PP 1 specialist spell each daily preparation, any class, replacing yesterday's;
  - random additional spells (Q19).

### Soulbound Familiar (module, D8)

- **Creating it:** the ability creates the familiar through `createFamiliarFor` the first time, and again after a severed bond, at daily preparation.
- **What it carries:**
  - Base DR 2;
  - +level HP;
  - Cha as a class bonus to its saves;
  - +1 spell adder (the flag on the ability).
- **The daily choice:** one of the eight bonuses, asked at daily preparation. It applies to the Witch while the familiar is within 30 ft, read each time the Witch is derived.
- **Severed Bond:** a slain familiar, or 24 hours over a mile apart, gives fatigued 2 until rebonded. The mile is checked on the same scene only; across scenes the GM ticks it.

### Verdant Communion (module)

A daily Use:
- the core Power Recovery (Meditation) check;
- its bonus PP added;
- a 1-hour +2 class bonus to Nature and Survival.

### Specialist spells and hexes

- **Block 3a builds the 34 spells' items:**
  - each with its traits, specialist classes and text;
  - the automations that need no 3b seam: damage, saves, heals, durations, warps and conditions.
- **The core's casting:** the specialist mode, plus High Magic per Q16.
- **Block 3b adds the reactions:**
  - Missed Chance, Second Chance and Prophetic Warning;
  - Disrupting Magic;
  - Phase Familiar;
  - Resist Magic;
  - Eternity's critical.
- **Already possible in 3a:** Shadow Shift rides the core's defence offers.
- **Touch of Healing:**
  - built here from Eldritch Arts' text;
  - Pillars of Faith's copy can then come out of Pillars of Faith 0.5.1, a change to that module for Graham's approval.

### The five Grimoire spells

Built now, from the Grimoire's text, because the birthrights grant them. Blocks 7 and 8 will skip them.

### Fix carried into 3a

The racial PP defect, in the core's PP-per-level seam. A new `verify-block1` check reads the PP on a test actor, not the registration.

## Questions for Graham

| # | Question | Proposal |
|---|---|---|
| **Q15** | Storm's 1st-level spells print "Shock Bolt (0)", but the core's Shock Bolt is 4 PP, too much to cast at 1st. | **Orb of Lightning** (0, arcane and verdant, electricity), the core's lightning cantrip. Storm's tradition is Verdant. |
| **Q16** | Are these classes' specialist spells and hexes cast as **High Magic** (Hard, armour DR × 4, fumble +60) as well as specialist (Very Easy, cap = level)? The book says specialist spells take "your primary tradition", and these classes' tradition is High Magic. | **Yes, both,** for all three classes: Very Easy (−5) and Hard (+2) both apply, a net −3. |
| **Q17** | **Life Boost** carries the Witch trait, not Hex, and nothing grants it. | **Through the Specialist Spell feat only,** which a Witch may take for it. Not a hex, and not free. |
| **Q18** | **"Birthright Any"** on Ancient Aegis, Evershade Veil and Ley Bolt. | **Open to every Sorcerer through the Specialist Spell feat,** whatever the birthright. Not granted. |
| **Q19** | **The Wild birthright at 1st:** the general rule is "a bonus cantrip and PP 2 spell"; Wild says "at 1st level and then every two levels … a random spell". And "your GM will provide a list … for you to determine which spell". | **Two at 1st** (a cantrip and a PP 2), then one at 3rd–15th at the PP the other birthrights use (4, 6 … 16). Each rolls the d20 tradition. **The module then draws one spell at random** from that tradition and PP, not already known. The GM may accept it or pick another from the list. |
| **Q20** | **Wild Power's surge** happens outside a wild magic area too. The table scales by area level. | **The spell's PP** as the level, as the Rod of Wild Surges does (L9601). In a wild magic area, the area's level, with the disadvantage L5752 gives. |
| **Q21** | **Hemocovenant and Siphon Vitae** carry Bloodmage as well as Hex. | **Open to every Witch.** The trait also lets a Bloodmage take them through Specialist Spell. |
| **Q22** | **Hemocovenant's 2 AP mode:** "You lose 1d8 + Charisma HP + and they recover the same". | Read as **"1d8 + Charisma HP"**: the stray "+" is a typo, reported for the book. |
| **Q23** | **Disrupting Magic:** "you expend an amount of PP … as determined by the Dispel check". | **The Dispel's PP replaces the spell's 1 PP.** The incoming spell is stopped before it resolves on a Dispel success, as the core's Dispel ladder says. |
| **Q24** | **Wild Power's daily specialist spell:** "a random PP 1 specialist spell (from any class)". Does it replace the previous day's? | **Yes:** it lasts until the next daily preparation. Includes this book's and the core's PP 1 specialist spells; excludes ones already known. |
| **Q25** | **Severed Bond across scenes:** the "more than a mile away for more than 24 hours" test. | **Automatic on the same scene, and a GM tick across scenes.** The familiar's death is always automatic. |

**Graham's answer (2 November 2026, 11:24):** "Yes please continue, your proposals all work". Q15–Q25 stand as proposed.

## Minor points (no ruling needed; reported for the book)

- **Witch:** "the remains in place" (L1696) should read "then remains in place".
- **Witch Severed Bond:** "a remains a distance" should read "remains at a distance".
- **Missed Chance and Second Chance:** "any other affect" should read "effect"; the bracket in "(an open-ended 20 or 1 was rolled." is unclosed.
- **Malicious Shadow:**
  - "counteract" is read as the core's Dispel;
  - "spellcasting ability modifier" as the magical ability score;
  - "Strike" as an attack.
- **Witch table:** BAB and BDB share one column, unlike the other two tables.

## Order of work

**Block 3a:**
1. Core 3.680.0 with the 3a seams and the racial PP fix, and its harness pair.
2. Eldritch Arts 0.5.0: the classes, birthrights, familiar, the 34 spell items and the five Grimoire spells, and their automations that need no 3b seam.

**Block 3b:**
1. Core 3.681.0 with the reaction seams.
2. Eldritch Arts 0.6.0 with the reactions.

Each release: harness, sweep, zip, Graham installs, live test.
