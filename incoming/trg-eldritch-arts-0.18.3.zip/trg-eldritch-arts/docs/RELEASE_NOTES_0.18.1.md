# Eldritch Arts 0.18.1 — fixes from the 0.18.0 live test

25 November 2026. Still needs **TRG Prime 3.713.0** for everything (as 0.18.0); runs on 3.712.4 with a weapon's upgrade, its overclock and Tinkerer Precision left to the GM.

0.18.0 was tested live in the **Test** world on TRG Prime 3.713.0 (Foundry 14.367), as Testing Dude, alongside Inner Tempest 1.1.1, Pillars of Faith 0.13.3, Fiends & Fables Prime 0.46.2 and Creature Codex 0.2.2. All eighteen steps of the 0.18.0 manual test plan were run. Twelve faults were found; this release fixes all twelve. Nothing else changes.

## What was fixed

| # | What went wrong in 0.18.0 | Fix |
|---|---|---|
| 1 | **Mechanised Assistant was built without its profile.** The compendium lookup asked the core's helpers for `contentPacksFor`, which lives on the module API instead. Nothing was found, so the assistant stayed a Tiny familiar: speed 25, no Frame, no Darkvision, no Slam. The card claimed it was built anyway. | The lookup reads the API. The card now says "incomplete" if anything is missing. |
| 2 | **The familiar's Nightvision and Bite (Tiny) came back.** The core re-runs grants whenever an ability is added, so deleting them never stuck. | Darkvision and the Slam are stamped as the race's grants of those two names, after the core's pending grant pass. A forced re-grant no longer brings them back. |
| 3 | **Perception never became the assistant's class skill.** A familiar's class skills are derived, so writing the field did nothing. | The Frame declares Crafting and Perception (`flags.trg-prime.classSkills`), the core's own route. Live: both read "Mechanised Assistant Frame". |
| 4 | **A tool's upgrade never asked which skill.** The list was read from `CONFIG.TRG_PRIME.skills`, which does not exist, so it was always Crafting; Thieves' Tools could not help Thievery. | The actor's own skill list. |
| 5 | **Power Sink could not see wondrous items.** The core's wondrous, charged and specific items are gear marked by a flag, and core traits are space-separated ("Invested Warding"). A worn Ring of Protection was never offered. | Both are read. |
| 6 | **"Broken" meant half HP; the core means 0 HP.** Armour kept its upgrade at half HP (the core's suppression), while a weapon would have lost it (the module's rule). | 0 HP or below, as the core. |
| 7 | **Triggered Sigil refused Shield** ("it cannot target you or a creature"). The core writes self spells with no range, target or area. | Such a spell, or a touch spell, is eligible. |
| 8 | **Perfected Arcane Memory never recorded a lasting spell's trace.** The core's spell effects carry no spell name or tradition, and "arcane, ethereal" never matched. | Read from the effect's origin spell; any listed arcane or ethereal tradition counts; one trace per cast, not per target. |
| 9 | **The trace chooser showed the spell's name to whoever used the feat.** A player would read the answer before rolling. | Names are shown to a GM only. |
| 10 | **Grand Inscription's "Save DC +2" line appeared on Magic Missile**, which has no save. | Offered only for a spell with a saving throw. |
| 11 | **Gaining Grand Inscription after a Runemage identify bonus was queued left it at +2.** | Gaining the feat raises a queued +2 to +4 (removing it already lowered it). |
| 12 | **Wording.** Prompts read "ZZ Ally failures Will save". The daily card was titled "the Artificer's day" for a Runemage. Arcane Preparation was lost silently on falling unconscious. The assistant's card didn't say to ignore the core familiar card's "pick 2 abilities" and "600 gp". | "fails"; "today's preparation"; a card when unconscious ends it; that line added. |

## Live test results (0.18.0, the 18-step plan)

| Step | Result |
|---|---|
| 1 Modular Design | **Pass.** The attack card showed "Modular upgrade +1, Item +1"; the dagger had no row. With Potency I, still +1 in all. |
| 2 Armour and shield | **Pass** after fix 6. DB 18 → unequipped 16 → re-equipped 17; dropping the armour removed its allocation. |
| 3 Tool | **Pass.** "Modular upgrade (Artisan Tools), Item +1" on the Crafting check while equipped; none when unequipped. The skill was never asked (fix 4). |
| 4 Advanced / Integrated / Quick Swap | **Pass.** The allowance is +2 with Advanced Design and +3 with Integrated Modularity. The swap is refused in combat and works out of it, once a day. Quick Swap: 2 AP; Prepared expended; a failed recharge left it expended, a success replenished it; it recharged by itself after 10 minutes (still expended at 5). |
| 5 Overclocked Weaponry | **Pass.** Plasma Edge: "3 fire damage (1d4)" as its own packet. Gyroscopic: crossbow reload 3 AP → 2 AP. Impact: 2d6 + 1. Daily preparation cleared all of them. |
| 6 Power Sink | **Pass, with fix 5.** A Will failure was offered and rerolled (15 → 26, "the second result stands"); the item was overloaded until the end of the Artificer's next turn. A Fumble without Instability Harness: not offered; with it: offered (16 → 29). A Resonance Event: "draws it into Short Sword". |
| 7 Emergency Contraption | **Pass.** The reroll showed "Emergency Contraption, Item +2" on the second roll only (3 → 12); the trap card posted. |
| 8 Flash of Insight | **Pass.** The description was asked; 20 + 7 = 27, a Success; the day's use was spent. After the Prepared state was recharged, a second failure was not offered (A11 ruling held). |
| 9 Tinkerer Precision | **Pass.** "Time read at +2 ranks and 300 of 400 gp … the materials still cost 400 gp"; 20 days → 13. |
| 10 Mechanised Assistant | **Failed in 0.18.0** (fixes 1–3); everything after the build passed with the profile applied by hand. Small, Str 0 Dex 1 Con 1 Int 0 Wis 2 Cha −2, speed 20, Initiative 15 (the printed figure), Slam (Small) 1d6. Tool Armature: Crafting 7 → 9 adjacent, 7 away. One improvement at level 6; a second refused. Storage refused 11 lb and an over-limit second item; a 4 lb item was retrieved. Cure healed 14 and was taken back. Rebuild took no gold. An ordinary familiar kept its Bite and Nightvision, no limit and its healing. |
| 11 Runic Anchor | **Pass.** "Runic Anchor (Fear), Class +2"; "another spell" gave nothing. |
| 12 Triggered Sigil | **Pass** with Magic Missile; Shield was refused (fix 7). The defence offer listed it; the reaction cast spent 2 PP and no AP; the round lock refused a second activation; Living Script reformed it as a plain sigil. |
| 13 Grand Inscription | **Pass.** Save DC 14 = Runemage +1 and Grand Inscription +1. Runemage's Use queued +4; removing the feat made it +2. |
| 14 Ley Resonance | **Pass.** Offered in the Warp? dialog at 8 ft from a ley line Region; 1 PP paid for a 2 PP spell (the core's minimum is 1 PP); Casting DC −2; Save DC unchanged; Refocus restored the use. |
| 15 Arcane Preparation | **Pass.** "Arcane Preparation, Circumstance +2" once; lost on casting another spell, and on falling unconscious. |
| 16 Heritage of the First Weave | **Pass.** +2 circumstance with Forbidden Magic's −2 still shown. See A11-16. |
| 17 Perfected Arcane Memory | **Pass** for Magic Missile's traces: DC 20 + 5 = 25; a Critical gave the spell, the tradition, "minutes ago" and "west", never the caster. Lasting spells left no trace (fix 8). |
| 18 Regression | **Pass.** A plain Artificer/Runemage: only the Runemage's lines on a cast; no Eldritch Arts card at daily preparation; Combat Inscription, Ley-Etched Symbol and Runic Reservoir as before. |

## Still open (not changed here)

- **An overloaded weapon keeps its rune bonus.** Power Sink switches off the item's effects, but Potency is read from the weapon's runes, not an effect. Stopping it needs a core seam.
- **The core labels Grand Inscription's Save DC part "Warping +1"** (a cast option's Save DC is folded into the warp total). The arithmetic is right; the label is the core's.
- **Impact Amplifier's +1 is not named on the damage card.** The core prints no enhancement labels.
- **Advanced Design's "ten minutes" does not move the clock;** the GM does.
- **A11-16** (above) and A11-1 to A11-15 still await rulings.
- Two older deprecation warnings appear in the console (Block 5a's token-move hook and the core's region test); both are older than Block 11 and stop working in Foundry v15.

## Tests

- `verify-block11`: 385 checks; a new section K covers every fix above. Among them, every `h().name` Block 11 calls is checked against the core's real helpers object, the check that would have caught fix 1.
- `mutate-block11`: 66 mutations (12 new), all caught.
- All `verify-*` pass except `verify-block10`; 27 of 30 `mutate-*` pass, all but `mutate-block10`, `mutate-block10b` and `mutate-book-extract`. All four were failing before 0.18.0.

## Clean-up after the live test

Everything temporary was deleted: 8 actors (including two familiars), the scene with its tokens and ley-line Region, the folder, the combats and 122 chat messages. The trace store was emptied and the world clock set back to 90. The world was left paused on Caves with 5 actors and 288 messages, as found.

## Retest of 0.18.1 (25 November 2026, after install)

Run in the Test world on TRG Prime 3.713.0 with 0.18.1 installed (`module.json` 0.18.1), as Testing Dude. Every fix was checked live.

| Fix | Result |
|---|---|
| 1–3 Mechanised Assistant | **Pass.** Built complete in one Use: Small, speed 20, Str 0 Dex 1 Con 1 Int 0 Wis 2 Cha −2, Initiative 15, the Frame, Darkvision and Slam (Small) 1d6 bludgeoning, with Crafting and Perception as class skills from the Frame. No Nightvision or Bite, including after an improvement and two forced re-grants. Storage was placed from the compendium (11 lb refused, 4 lb kept); Tool Armature took Crafting 7 → 9 → 7; Cure's 16 HP was taken back. Rebuild was complete, took no gold, and Scout Optics placed Tremorsense. The card notes the familiar card's picks and 600 gp do not apply. |
| 4 Tool skill | **Pass.** Thieves' Tools asked for the skill; "Modular upgrade (Thieves Tools), Item +1" on Thievery, none on Crafting. |
| 5 Power Sink | **Pass.** The worn Ring of Protection I was taken and overloaded; the save rerolled 15 → 26. |
| 6 Broken | **Pass.** At half HP the sword's row and the armour's DB +1 stand; at 0 HP both are gone. |
| 7 Triggered Sigil | **Pass.** Shield designated. On an adjacent attack the offer cast Shield as the reaction (2 PP, no AP, reaction spent); the attack then missed against DC 14 (was 13). While Flat-Footed the core offers no reaction, which is correct. |
| 8–9 Perfected Arcane Memory | **Pass.** Mage Armour ending left an arcane trace with its origin; Magic Missile one trace per cast. A Success read "Mage Armour, arcane", never the caster. To a non-GM the chooser shows "trace 1 / trace 2". |
| 10–11 Grand Inscription | **Pass.** No Save DC line on Shield; Fear still DC 14 (Runemage +1, +1). Re-gaining the feat turned the queued +2 into "— Grand Inscription +4". |
| 12 Wording | **Pass.** "fails Will save", "fails Disable Device", "fumbles Athletics"; "Eldritch Arts — today's preparation"; "You fall unconscious: the preparation of Magic Missile is lost." |
| Regression | Emergency Contraption (3 → 12 with Item +2) and Flash of Insight (20 + 6 = 26) as before. |

Clean-up: 6 actors, the scene and its ley-line Region, the folder, the combat and 52 messages deleted; traces emptied; clock 90; the world left paused on Caves with 5 actors and 288 messages.
