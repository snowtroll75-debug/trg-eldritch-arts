# Eldritch Arts — Block 11 audit: the Feat Additions (0.18.0)

25 November 2026. The source is *TRG Prime Eldritch Arts Feat Additions — Exact Format* (Graham), cut verbatim into `tools/content/feat-additions.md`. Built on Eldritch Arts **0.17.3** as installed live (`C:/FoundryData/Data/modules/trg-eldritch-arts`) and TRG Prime **3.712.4** (`fix/core-spellbook-rename`, identical to the live `system.json`).

## 0. What I had, and what I did not

- **Had:** the insertion document; the live 0.17.3 module source (staged from the install; the GitHub repo holds only the 0.17.2 zip); the TRG Prime 3.712.4 source; the module's own cut of Eldritch Arts v1.6 (`tools/content/book-text.json`).
- **Did not have:** *TRG Prime Core Rulebook 3.81*, the *Eldritch Arts V1.6* docx itself, and the *Sourcebook Changes Summary — Updated*. None were attached to this session. Where the Core rules mattered I read the Core's implementation of them, not the book. In particular, **Core Rulebook p. 171** (the mundane-item cost Mechanised Assistant's rebuild points to) could not be checked (A11-7).
- **The insertion document and the brief disagree on one feat.** The brief describes Ley Resonance as an identification bonus ("+2 racial bonus to subsequent checks … identify the same magical effect"). The document prints **ASCENDAN FOCUS**: *"Whenever you are within 60 foot of or linked to a ley line, you may reduce the casting cost of a spell by 1 PP (the casting DC is also affected). This does not affect any associated Save DC."* Perfected Arcane Memory follows the document: *"Your bonus from Ley Resonance increases to 2."* The brief names the document as authoritative, so Block 11 implements the document. If the brief's wording is the newer intent, that is a ruling (A11-14).

## 1. Existing mechanisms, and what each new feat uses

| Need | Found in | Used for |
|---|---|---|
| Artificer archetype (Crafting 2 ranks; class skill; specialty) | Core `feats` pack *Artificer*; `class-skills.mjs`; `skill-specialties.mjs` | Unchanged. The ten class feats carry the trait **Artificer**, which the Core's class-feat slot reads as that archetype's gate (as Block 6's Runemage feats carry **Runemage**). |
| Runemage archetype (Symbol, −1 casting DC, +1 save DC, +2 defensive, +2 identify) | Core `magic/runemage.mjs`, `casting-dc.mjs`, `feats-workflow.mjs` (`runemage` Use) | Unchanged. Grand Inscription adds one save-DC part on a Symbol cast and rewrites the queued identify bonus. |
| The five v1.6 Runemage class feats | Block 6 (`block6c-automations.mjs`) | Untouched; verify-block11 A13 checks each is byte-for-byte unchanged. Triggered Sigil reads their sigil list, ready state and one-a-round lock. |
| Feat eligibility | Core prerequisite parser ("Level N", "Skill N ranks", feat names); `sourceRace`; archetype trait gate | Prerequisites stored as printed; Ascendan feats carry `sourceRace: "Ascendan"`, as the Core's own Ascendan feats do. |
| Familiar | Core `familiar-workflow.mjs` (`createFamiliarFor`, master mirror), `familiar-modifiers.mjs` | The Mechanised Assistant **is** a familiar actor; the frame overrides the stat block's effect at a higher priority. |
| Item-scoped bonuses | Core typed bonus pool (`system.combat.defence.item`, `system.combat.dr.item`), item conditionals (held/worn only), `TRGActiveEffect.isSuppressed` (broken items), `registerEffectSuppressor` | Armour, shield and tool upgrades: an effect **on the item**. |
| Weapon-scoped temporary bonuses | none | **New Core seam C-EA11-1** (`registerWeaponEnhancement`). |
| Crafting time | Core `create-crafting-workflow.mjs` (`createPerDay`, `completionOf`) | **New Core seam C-EA11-2** (`registerCraftingWorkModifier`). |
| Daily preparation | `trgPrimeDailyPreparation` | Ends the day's upgrades, overclock and Prepared states. |
| Reactions | `registerCheckReaction` (before/after), `askReactor` + `registerReactionStep`, `spendReaction`, `registerDefenceOffer` | Power Sink, Harness, Contraption, Flash of Insight, First Weave, Runic Anchor, Triggered Sigil. |
| Resonance Events | `registerResonanceSuppressor` | Power Sink redirects an event; no second table or failure calculation. |
| Natural roll | `dice/open-ended.mjs` (a 20 continues the chain) | Flash of Insight sets the first face to 20 and continues the chain with real dice. |
| Focus / Refocus | per-day `usesPerDay` + Focus trait; `refocus-workflow.mjs` | Ley Resonance and Heritage of the First Weave: one use, restored by Refocus. |
| Time and duration | world clock; module `effects-clock.mjs` (`endOfNextTurn`, seconds) | Prepared's ten minutes, the overload, Arcane Preparation. Nothing rides on a JS timer. |
| Casting seams | `registerCastOption` (`saveDC`), `registerMetamagic` (`discount`, `dcDelta`, Focus), `registerSpellCheckGate`, `castSpell(…, { preparedSymbol, reaction, apPaid })` | Grand Inscription, Ley Resonance, Arcane Preparation, Spell Relay Node, Triggered Sigil. |

## 2. Duplicate and conflict audit

- **By name:** none of the 17 feats, Quick Swap, the Frame or its three improvements exists in any Core pack or any Eldritch Arts pack (checked against all 31 Core packs and all 16 module packs).
- **No archetype is recreated.** Artificer and Runemage stay the Core's.
- **By function, the overlaps that matter:**
  - **Modular Design vs potency runes and quality.** Both are item bonuses. On attack they stack as typed bonuses do (the higher counts). On damage the upgrade adds only what it beats the weapon's own item damage by (Core R3).
  - **Gyroscopic Repeater vs Quick Reload.** Both lower Load; both apply (Quick Reload first), never below 0. *Ruling invited* (A11-15).
  - **Tinkerer Precision vs Accomplished Artisan / Masterful Crafter.** Artisan's +2 ranks applies only in the specialty; Tinkerer's +2 applies to time only. Both add when both apply. *Ruling invited* (A11-15).
  - **Ley Resonance vs Ley-Etched Symbol.** Both are discounts offered in the same Warp? dialog. An Ascendan Runemage at a ley line could take both, for −2 PP (−3 with Perfected Arcane Memory), never below 1 PP. *Ruling invited* (A11-15).
  - **Heritage of the First Weave vs Forbidden Magic.** It touches no Forbidden Magic flag, so the −2 and the beneficial-magic save stand (verify-block11 I8).
  - **Mechanised Assistant vs a Familiar or Soulbound Familiar.** The Core allows one familiar a master, so a character with the Familiar feat or a Witch's Soulbound Familiar cannot also build the assistant. Its Use refuses and says why (A11-8).

## 3a. Graham's rulings, 25 November 2026 (built in 0.18.2 and TRG Prime 3.713.1)

| Item | Ruling | Built |
|---|---|---|
| A11-1 Advanced Design | A typo: "a +1 bonus to two items or a +2 bonus to a single item". | The source text is corrected; +2 in all, one bonus per item (unchanged). |
| A11-2 Integrated Modularity | "Any combination of +3 (three +1s, a +2 and a +1, or a +3). This could be split between Attack and Damage or applied as a +3 to one of them." | An item's share may be split between its two bonuses (attack and damage; DB and DR). |
| A11-3 Flash of Insight | Once per day, and **not** Prepared. | The Prepared trait, its card and its checks are removed; the day's use alone gates it. |
| A11-4 Flash of Insight's range | 30 ft. | Unchanged. |
| A11-14 Ley Resonance | A Focus ability (the Feat Additions version). | Unchanged. |
| A11-16 Multi-tradition spells | The spell matches the caster's tradition when it lists several. | TRG Prime **3.713.1**: the save is told only the caster's tradition; Forbidden Magic and Heritage of the First Weave follow. |
| A11-7 Rebuild cost | The Equipment Cost Table, Core Rulebook p. 173. | The cost at the master's level is taken from the master's purse; the rebuild is refused if they cannot pay. |
| A11-8 Assistant | Natural armour scales. Picks are restricted to what is stated for the assistant. Tracking is Survival. "No other options should grant this assistant." | Only its Use's improvements (and the core's own race grants) may be added; any other ability or feat is refused. Scout Optics adds Survival (0.18.3: on a Frame copy that opts out of the core's Codex inheritance). DB stays derived. |
| A11-5 Power Sink | Correct as read. | Unchanged. |
| A11-9 Triggered Sigil | "It clearly states during daily preparation." Daily preparation is an hour (Core Rulebook p. 231). Living Script, the shared lock and the detected triggers are as read. | Designation is open from daily preparation until the first spell cast, combat, or an hour. |
| A11-10 Emergency Contraption | Correct as read. | Unchanged. |
| A11-12 Damage typing | Correct as read. | Unchanged. |

**Settled by Graham's second set of answers (25 November 2026), built in 0.18.3:**
- **The assistant's DB:** worked out as any familiar's (10 + its Dexterity + its master's BDB), as built.
- **A11-6:** Success or better replenishes a Prepared ability, as built. The trait is defined in the Feat Additions document.
- **A11-11:** shields count as armour for Modular Design (the Quick Swap example), as built.
- **A11-9's window:** daily preparation is an hour (Core Rulebook p. 231: "Once every 24 hours, usually at the beginning of the day you spend an hour in preparation. To use daily preparation you must have fully rested (typically 8 hours)"). Designation closes an hour after it, or sooner at the first spell or combat, as built.
- **A11-7's level:** the master's level, as built.
- **A11-8, "No other options should grant this assistant":** read as nothing but its own feat adding abilities to it, as built.
- **A11-13 and A11-15:** as built. Spell Relay Node's area is placed by hand and Injector Limb's delivery is the GM's. Gyroscopic Repeater with Quick Reload, Tinkerer Precision with Accomplished Artisan and Masterful Crafter, and Ley Resonance with Ley-Etched Symbol all stack.

No Block 11 ruling remains open.

## 3. Rule ambiguities (for Graham's ruling)

Each item is implemented the narrowest way the words allow, so nothing has been silently widened. **Status** says whether the mechanic works now or waits on the ruling.

**A11-1 · Advanced Design: how many +1s?**
- **Quoted:** "you may apply either a +1 bonus to items or a +2 bonus to a single item."
- **Problem:** "items" is plural, but no number is given.
- **Effect:** read literally as "+1 to every item", a whole kit is upgraded, far above Modular Design's one.
- **Proposed clarification:** read the three feats as a budget: +1 (Modular), +2 (Advanced: +1 on each of two items, or +2 on one), +3 (Integrated: "any combination of +3").
- **Status:** implemented on that reading. It is one constant to change.

**A11-2 · Integrated Modularity: how the +3 may be split.**
- **Quoted:** "any combination of +3 amongst your bonus."
- **Problem:** is +3 on a single item allowed? Can one item take two targets (attack and damage)?
- **Proposed clarification:** up to three items; any split, +3 on one included; one target per item (Modular Design's "a bonus to one of the following").
- **Status:** implemented on that reading.

**A11-3 · Flash of Insight: "Once per day" and the Prepared trait.**
- **Quoted:** "Once per day, you may declare a flash of insight", on an ability with **PREPARED**, which "can be replenished and used again" with a Crafting action.
- **Problem:** the trait implies repeat use; the text forbids it. Also, "fails or fumbles" leaves out Blunder.
- **Proposed clarification:** the daily limit governs. The Prepared recharge restores readiness, not the day's use, so it is effectively once a day. Blunder is excluded (Power Sink and Instability Harness name Blunder separately).
- **Status:** implemented on that reading: one tracked use plus the Prepared state. It can never fire twice in a day.

**A11-4 · Flash of Insight: the missing distance.**
- **Quoted:** "an ally that you are aware of within fails or fumbles".
- **Proposed clarification:** 30 ft, the same as Power Sink and Instability Harness.
- **Status:** implemented at 30 ft pending a ruling. It is one constant.

**A11-5 · Power Sink: what "fails" and "the failed check" cover.**
- **Problem:** TRG has Partial, Failure, Fumble and Blunder. Instability Harness adds "Fumble or Blunder", which implies Power Sink alone covers Failure only. For a Resonance Event there is no "failed check" to reroll.
- **Proposed clarification:** Power Sink fires on a **Failure**; the Harness adds Fumble and Blunder; a Partial is not a failure (the Core's reactions treat it so). For a Resonance Event the event itself is redirected into the item and not rolled; there is nothing to reroll.
- **Status:** implemented on that reading.
- **Also:** "cannot be used again until the end of your next turn" is enforced as its effects being switched off. The Core has **no generic "this item may not be used" seam** for a wondrous or charged item's Use button, so those uses are not refused (Core gap, §4).

**A11-6 · The Prepared trait's success condition.**
- **Quoted:** "a 3 AP (manipulate) Crafting action (level based DC)".
- **Problem:** no degree is named.
- **Proposed clarification:** Success or better replenishes. Partial and worse do not, and the ten-minute recharge still runs, counted from the moment the ability was spent. AP is charged only in combat, as every Core action is.
- **Status:** implemented on that reading.

**A11-7 · Mechanised Assistant: the rebuild cost.**
- **Quoted:** "The GP cost is that of a mundane item (CRB 171)."
- **Problem:** I did not have the Core Rulebook, and no fixed figure is derivable from the text.
- **Status:** the 8 hours are enforced (not in combat; a confirmation states it). **No gold is deducted**; the card asks the GM to deduct it. Pending a figure or formula.

**A11-8 · Mechanised Assistant: familiar progression and the profile.**
- **The Core's familiar card** still says "pick 2 abilities"; the feat says the assistant "does not gain abilities in the same way". The module offers its own improvements (at 4th level and every 4) but cannot stop picks on the Core familiar sheet.
- **The printed profile** gives fixed Initiative +15 and DB 15 (BDB 10, Stat +3, Class +2). A familiar derives these from its master's mirror and its own scores. The module authors the scores, size, speed and DR. Initiative and DB stay **derived**, so they may differ from 15 at some master levels.
- **Hands:** the Core has no "hands" model for familiars, so it is recorded only.
- **Tracking:** "Tracking as a class skill" (Scout Optics) — the Core has no Tracking skill; it is recorded and left to the GM.
- **One familiar per master** (see §2).
- **Proposed clarification:** say whether Initiative and DB are fixed or derived; whether the Core familiar's own picks are forbidden; what Tracking maps to.
- **Status:** partially automated.

**A11-9 · Triggered Sigil.**
- **"During your daily preparation":** sigils are inscribed after daily preparation (Prepared Sigil's Use), so designation is the Triggered Sigil Use, once the sigils exist.
- **Living Script** can reform the sigil after activation. The designation is spent on activation, so the reformed sigil is an ordinary Prepared Sigil (no repeating reaction casts).
- **The one-sigil-a-round lock** is shared with Prepared Sigil.
- **The reaction** is the cast's time (`apPaid`); the PP, range, line of sight and targets are the cast's own.
- **Triggers:** "struck" and "targeted by an attack" are detected. Falling, fire and "other" are activated from the Use, with the same checks.
- **Status:** implemented on that reading.

**A11-10 · Emergency Contraption: a trap with no failed check.**
- **Quoted:** "A trap is sprung or you or an ally fail a disable device check … a reroll on the triggering check."
- **Problem:** a sprung trap may have no check to reroll. No range is given for the ally.
- **Proposed clarification:** with no check there is nothing to reroll; the GM decides what the gadget changes. The ally must be on the scene on your side.
- **Status:** the Disable Device reroll is automated. The trap case is a card for the GM; nothing is reversed.

**A11-11 · Modular Design: are shields "armour"?**
- **Basis:** Quick Swap's own example: "from armour to a shield".
- **Status:** implemented as yes (DB or DR).

**A11-12 · Damage typing.**
- **Problem:** Modular Design's "+1 to damage" is read as an **item** bonus (the sentence opens "+1 item bonus to attack rolls or …"). Impact Amplifier's "base damage +1" is read as **untyped**.
- **Effect:** on a +1 potency weapon the modular damage adds nothing; the overclock always adds.
- **Status:** implemented on that reading.

**A11-13 · Specialties the Core cannot fully perform.**
- **Spell Relay Node:** the template is placed from the assistant by hand (the card says so); range and sight are checked.
- **Injector Limb:** the delivery is the GM's.
- **Status:** partially automated.

**A11-14 · Ley Resonance's two texts.** See §0.
- **Status:** the document's version is implemented.

**A11-15 · Stacking with existing feats.** See §2.
- **Status:** all stack as described pending a ruling.

**A11-16 · Heritage of the First Weave on a spell of several traditions** (found in the 0.18.0 live test). Fear lists arcane, divinity, ethereal and verdant. Cast by a Wizard, it still offered Heritage of the First Weave, because the save carries the spell's listed traditions, not the caster's. The core's own Forbidden Magic reads it the same way (its −2 applied to the same save).
- **Status:** First Weave follows Forbidden Magic, so the two agree. If a spell should count as divine only when a divine caster casts it, both need changing; the core change would come first.

## 4. Core dependencies

| Id | What | Why module-only is not enough | Status |
|---|---|---|---|
| **C-EA11-1** | `registerWeaponEnhancement`: one weapon's attack row, damage, secondary packets and reload | Nothing in the Core can say "this weapon only". A weapon's `attackBonus` is authored data, summed with potency in `item.mjs`; an actor effect reaches every attack; conditionals have no weapon axis. Spell-runes' write-back would make an upgrade a rune (priced, counted, magical). | Built in TRG Prime **3.713.0** (branch `feature/ea-block11-seams`): `module/weapon-enhancements.mjs`, 4 call sites |
| **C-EA11-2** | `registerCraftingWorkModifier`: the ranks and value a project's **time** is read from | The Create workflow's ranks and completion value are local to `applyDegree`; Accomplished Artisan is hard-coded there | Built in **3.713.0** (`crafting-feats.mjs`, 2 call sites) |
| *(gap, not built)* | Refusing an item's use while overloaded | No generic item-use refusal; only invest and rod refusals exist | Proposed for a later Core release; Power Sink switches the item's effects off meanwhile |

On TRG Prime 3.712.4 the module still loads and works. A weapon upgrade and an overclock are recorded and printed, and the card asks the GM to apply them. Tinkerer Precision changes nothing until 3.713.0; the GM applies it by hand. Every other feat works fully.
