# Eldritch Arts 0.3.0

1 November 2026. **Block 2a:** High Magic, and Chapter 7's areas on the map. Built from `ELDRITCH_ARTS_BLOCK2_AUDIT.md` and Graham's answers to it (Q1–Q8) the same day. Rituals, summoning circles, true names, Spell Trickery and Borrow Spell are Block 2b (0.4.0).

- **Install TRG Prime 3.678.0 first, then this over 0.2.0.** The module warns on anything older: the High Magic cast, the refusal, the degree remap, the Resonance and effect suppressors and the actions' own DCs are all the system's seams.
- **No migration.** Nothing on an existing actor changes. The compendiums are rebuilt (the notes on Ley Line Connection, the Spell Surge feat and the Seer's Hourglass are updated).
- **What a world sees with no areas placed:**
  - High Magic changes for Fiends & Fables creatures flagged High Magic (Q1, below). Nothing in Eldritch Arts 0.3.0 is itself a Highmagic spell or a High Magic class yet; those arrive with Blocks 3–8.
  - Tap Ley Line, Channel Ley Line and Tap Magical Energy appear among the skill actions.
  - Everything else waits for an area on the map.

## Placing Chapter 7's areas (GM)

Each area is a **Region Behaviour**. On a scene:

1. Draw a Region (any shape: rectangle, circle, ellipse or polygon) over the line or the area.
2. Open the Region's configuration, **Behaviors** tab, and add one of:
   - **Ley Line** — its level (1+). A line is a long thin region; Tap and Channel reach it from 30 ft, Ley Sense from 500 ft (1000 on a Critical).
   - **Wild Magic Area** — its level.
   - **Magic Suppression Area** — its level, and **Suppression backlash** ticked for an area that has it. Level 20 or more is an **antimagic zone**.
3. Name the Region: the cards use its name ("the Old Road", "the Silent Vault").

A disabled behaviour is ignored. Where two areas of one kind overlap, the stronger counts. The bands are printed on every card:

| Ley line | Level | Sense DC | Channel PP |
|---|---|---|---|
| Minor Ley Thread | 1–4 | 30 | 1d6 |
| Lesser Ley Flow | 5–8 | 25 | 2d6 |
| Greater Ley Current | 9–12 | 20 | 3d6 |
| Prime Ley Line | 13–16 | 18 | 4d6 |
| Legendary Ley Nexus | 17+ | 15 | 5d6 |

| Suppression | Level |
|---|---|
| Flickering zone | 1–4 |
| Strong suppression | 5–10 |
| Heavy suppression | 11–15 |
| Dead zone | 16–19 (M8) |
| Antimagic zone | 20+ |

## High Magic (Chapter 1 and Chapter 7)

Run by TRG Prime 3.678.0 (D1). Eldritch Arts declares that its High Magic supersedes the Fiends & Fables guideline (D1b).

- **Which casts:** a spell with the Highmagic trait; any spell of a caster whose class, archetype or feat declares High Magic (M27); with this module active, a Fiends & Fables High Magic creature's spell (Q1).
- **The casting check:** Hard, "High Magic, Hard" on the DC.
- **Armour (Q3):** every worn piece's DR × 4, in place of the tradition's rule, Divinity included. This is for a High Magic class or a Highmagic spell, not a creature's flag alone.
- **Focus (Q2):** set aside. There is no +1, and no −2 or +10 fumble for being without one. An Archmage, or a Sorcerer with the Arcanum birthright, keeps theirs (their items will declare it in Block 3).
- **Fumble (M4):** +60 on top of the tradition modifier. For a Highmagic spell, which counts as every tradition, that is the caster's own tradition's modifier (Q4).
- **Resonance:** every event the cast provokes is rolled with disadvantage. The first percentile is rolled twice and the higher kept; both show on the card.
- **Identification:** the cast card says "it registers simply as magic, and identifying it is Very Hard (DC +5)".
- **Fiends & Fables creatures (Q1):** with Eldritch Arts active they lose the guideline's save DC +2 and free Heighten, and their fumble is +60, not +50. Without this module the guideline is unchanged.
- **Ley Line Connection (Scaelyn)** now works: −1 to a High Magic cast's casting DC (as +1 on the check against it; not a spell attack's attack roll).

## Ley lines

**Tap Ley Line** (1 AP, Hard) and **Channel Ley Line** (10 minutes, Very Hard).
- **The DC:** the nearest line within 30 ft, at its level's DC (TRG Prime's new `resolveDC`). With no line in reach the action is refused before anything is spent.
- **Tap:**
  - **Success:** a roll on the Effect column of the Ley Line Effects table, until the end of your turn.
  - **Critical:** the same, until the end of your next turn.
  - **Failure:** 1d6 × level force damage, basic Will save, and a 1-hour lockout.
  - **Fumble:** the damage and a roll on the Backlash column, and a 24-hour lockout (M6).
- **Channel:**
  - **Success or better:** the band's PP dice + your tradition ability, capped at your maximum.
  - **Heroic:** also the Effect column, for 1 minute.
  - **Critical:** also the Effect column, until the end of your next turn.
  - **Partial:** nothing.
  - **Failure:** the rolled PP as essence damage, basic Fortitude; doubled on a Fumble; tripled on a Blunder, and you may not manipulate that ley line again until the following day.
  - Channel never rolls the Backlash column (M6).

**Tap Magical Energy** (2 ranks): a charged item you carry (a wand, staff, rod or orb), against the item's level DC (C3).
- **Critical and Success:** 1 PP per 2 caster levels; the item loses half that on a Critical, all of it on a Success. **Partial:** 1 per 4 caster levels, and the item loses as much.
- **Failure:** nothing siphoned; the item loses 1 PP. **Fumble and Blunder:** 1d6 × the item's level force damage (basic Fortitude), and the item loses 1d4 PP. A Blunder then rolls TRG Prime's item depletion table.
- **The siphon** is held as essence that must be spent by the end of your next turn. Whatever is still above your pool from before then goes.

**Ley Sense** (Block 1) now reads the map.
- **The DC:** the easiest Sense DC among the lines within 1000 ft, or 30 when there is none, so the DC itself gives nothing away. The GM may still override it in the roll dialog (M5).
- **Success:** the nearest line within 500 ft and its direction, or "No ley line within 500 feet."
- **Critical:** every line within 1000 ft, its distance, direction and strength.

**The Ley Line Effects table** (35 rows, Effect and Backlash):
- **Applied:** 38 of the 70 results:
  - bonuses and penalties: AB, a skill, saves (yours and allies' within 10 ft), DB ±2, Save DC ±2;
  - advantage and disadvantage: the next save, all saves, spell checks, all checks;
  - temporary HP, healing (yours and an ally's), HP lost outright;
  - PP recovered or lost, and the next spell's +1 PP;
  - resistance or weakness to one damage type;
  - damage with its basic save (force, essence, the same type, to you or your allies);
  - Blinded, bleed, Stunned 1 and Slowed 2;
  - the Chaos Surge's two benefits and the Chaos Backlash's Resonance with disadvantage.
- **Posted for the table:** the other 32, as printed. They are:
  - the metamagic rows (extend, reach, split, quicken: Block 6);
  - the next spell's extra dice, range, target or reduced PP, warping and double AP;
  - True Seeing and Prayer;
  - summons;
  - a reroll of a failed skill check;
  - resistance ignored;
  - a teleport;
  - injuries;
  - half duration, range or damage;
  - the two GM's-choice rows at 100.
- **Duration:** "all effects last in line with the skill being used". A backlash with no printed duration lasts to the end of your next turn.

## Wild Magic areas (M7)

- **The trigger:** a casting check inside the area that comes out Partial, Failure, Fumble or Blunder, or rolls chaos, rolls the Wild Surge table. Scrolls, wands and rituals surge too (Q7). A scroll or wand surges on its release check.
- **Scaling:** damage 1d8 × area level (one roll, multiplied), range 5 ft × level, duration 1 round × level, unless the row prints otherwise.
- **Applied:** 17 of 34 rows:
  - the explosion and the mental damage, with their saves;
  - the random teleport's direction;
  - the barrier's +2 DR;
  - the d10 and d20 rolls for PP, HP, advantage and conviction;
  - a racial ability bonus ±1d4;
  - 66's two rolls;
  - the +1 PP per 2 area levels for a minute;
  - Confused, Quickened and Slowed 1;
  - regaining all PP.
- **Posted for the table:** the other 17, as printed. They are:
  - rolling again each turn;
  - Self-Healing and fast healing;
  - the elemental;
  - seeing invisible, or only spellbound and invisible creatures;
  - the random language;
  - floating;
  - all skills as class skills;
  - spells costing less;
  - advantage or disadvantage per check;
  - effects in the area doubled or ended;
  - the teleport each round;
  - the criticals;
  - Time Stop.
- **The surge is rolled after the cast is settled,** so a PP row never races the spell's own payment.

## Magic Suppression areas (M8)

- **The penalty:** −level on every casting check made inside (a spell-check gate).
- **The degree (D7):** Partial, Failure and Fumble read as Failure; Blunder reads as Fumble. The card shows both.
- **Resonance (D6):** none. "Magical Resonance events simply do not exist in areas of suppression"; the card says so.
- **Backlash:** in an area marked for it, a failed casting (Failure or Fumble, after the remap) rolls the Suppression Backlash table. 7 of its 8 rows are applied; row 66 (the spell triggers at twice its PP) is posted. An innate cast or a refunded one does not backlash. Its effects last 1 round × level.
- **Antimagic (20+, Q6):**
  - Every casting is refused before anything is spent, innate casts included.
  - While your token stands inside, the effects of your magic items and the effects spells placed on you are switched off (D14). They come back the moment you leave. Nothing is written to the actor, so nothing is lost.
  - Your race, class, feats, skills and afflictions are what you are, not what you carry, and are left alone. So are passive creature abilities (Q6).
  - A card is posted when a creature enters (once, by the active GM).

## Not automated (said on the cards)

- **A wondrous item's bonuses inside antimagic** that the system works out from the item itself rather than from an effect. Take them off by hand while inside; the antimagic card says so.
- **The ley table's, surges' and backlash's posted rows** (above).
- **The Spell Surge feat** (a High Magic caster's metamagic) arrives with the metamagic block (Block 6).
- **Rituals in Chapter 7's areas.** The ritual's own Spellcraft check (TRG Prime's ritual dialog) is not yet a High Magic cast, does not take a Suppression area's −level, and is rolled before an antimagic zone refuses the spell it casts. The cast that follows does take the remap, the surge and the refusal. Block 2b rebuilds rituals (D13) and closes this.
- **The goods** that read ley lines and wild magic (the Astral Lodestone's Survival bonus, the Seer's Hourglass's initiative advantage) stay as ticks the player offers, because "navigating toward" and "standing in" are read at the table. The Hourglass's note now points at the areas.

## Reading notes

- **DCs the book does not print follow C3:** a ley line's damage on you uses your own level DC; Tap Magical Energy uses the item's.
- **"× level"** is one roll multiplied ("1d8 × area level"), not level-many dice. "Per 2 levels" rounds down, so at level 1 a "per 2 levels" row has no dice; its card says "Level 1: no dice". Bleed of "half the ley line's level" at level 1 is likewise nothing.
- **A Suppression backlash** with no printed duration lasts 1 round × level (6 × level seconds).
- **Overlapping areas:** the strongest of each kind counts; a Ley Line and a Wild Magic area on the same spot both apply.

## Core seams used (TRG Prime 3.678.0)

D1 and D1b (High Magic), D6 (Resonance suppressor), D7 (cast refusal and degree remap), D14 (effect suppressor), the skill action's `resolveDC`, the `trgPrimeReleaseRolled` hook, and the `chaos`, `rollsCheck` and `highMagic` fields on `trgPrimeSpellCast` and `trgPrimeSpellSettled`. See `ELDRITCH_ARTS_CORE_DEPENDENCIES.md`.

## Harness

- **`verify-block2`:** 131 checks, all passing. They cover:
  - the bands, the Region Behaviours and the shapes' distances (rectangle with rotation, circle, ellipse, polygon);
  - the three actions' DCs and every degree, the lockouts and the siphon;
  - the tables: every row has its printed text, and every spec kind is handled; a sample of each kind applied;
  - Wild Magic: when it surges and when it does not;
  - Suppression: the gate, the remap, the Resonance suppressor and the backlash;
  - antimagic: the refusal, the effect suppressor (by actor uuid, so an unlinked token's twin is not caught), what counts as a magic item;
  - the next-spell surcharge: spent only by a cast that was not refunded;
  - Ley Sense's ranges and DC;
  - High Magic rules declared, and Ley Line Connection's gate.
- **`mutate-block2`:** 75 mutations, all caught, eleven of them for the review's findings.
- **`verify-block1`:** 881 checks; **`mutate-block1`:** 86 mutations, all caught (adapted to Block 2's hooks).
- **TRG Prime 3.678.0's own pair:** `verify-ea-block2-core` 53 checks, `mutate-ea-block2-core` 50 mutations, all caught.
