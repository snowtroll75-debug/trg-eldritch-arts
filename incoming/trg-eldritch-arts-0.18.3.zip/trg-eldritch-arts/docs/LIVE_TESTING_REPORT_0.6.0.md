# Eldritch Arts 0.6.0 and TRG Prime 3.681.0 — Live Testing Report

3 November 2026. The module and system were tested in Foundry V14 (14.367), world "TRG V14", after Graham installed both: Eldritch Arts 0.6.0 on TRG Prime 3.681.0, with Inner Tempest 1.0.4 active.
- **Gamemaster in Chrome**, for every test.
- **A second client as "Test PC 1",** in a second tab, for the tests across two clients (22–25).

**Throwaway material, all deleted afterwards:**
- **The scene** "ZZ EA Reactions 3.681.0" (5 ft squares). Its default permission was Observer, so the second client could view it.
- **Twelve actors:**
  - the casters: "ZZ EA Witch" (Witch 5th, with Missed Chance, Second Chance, Prophetic Warning and Phase Familiar), her familiar "ZZ EA Owl", "ZZ EA Arcanum" (with Disrupting Magic) and "ZZ EA Rune" (with Resist Magic);
  - three Eternity Resilience creatures: "ZZ EA Eternity", "ZZ EA Eternity Two" and "ZZ EA Eternity Three";
  - "ZZ EA Ally";
  - four hostile NPCs: "ZZ EA Foe" (a caster) and "ZZ EA Foe Two" to "ZZ EA Foe Four".

  Test PC 1 had ownership of the Witch only.

**What was changed, and put back:**
- **None of Graham's actors or settings was touched.**
- **Dice:** where a result had to be forced, `CONFIG.Dice.randomUniform` was set for that one roll, then restored.
- **Removed:** the 74 test chat cards, the twelve actors and the scene. The test's dialog and notice hooks came off.
- **The view** went back to Oldwatch Approach, and Test PC 1 is offline.
- **No error notice from TRG Prime or Eldritch Arts** appeared during the run. The console is clean since the cleanup. It wasn't captured from the start, so earlier console output wasn't seen.

## The second review's main finding, checked live first

| # | Test | Result |
|---|---|---|
| 1 | A real creature's data points back to it | **Pass.** `actor.system.parent === actor` held for a world actor and for an unlinked token's actor. The link is not enumerable, and not in the JSON. |
| 2 | Resist Magic changes the damage | **Pass.** ZZ EA Foe cast Magic Missile at ZZ EA Rune. Rune was asked and said yes. 1d4+1 rolled 3 and Rune took **1** (HP 30 → 29). The card read: "ZZ EA Rune uses Resist Magic: resistance to the spell's damage, every type and every instance, until it resolves." |
| 3 | …and ends with the cast | **Pass.** At the next cast Rune was asked again and said no, and took the full 5 (29 → 24). |

## Disrupting Magic

| # | Test | Result |
|---|---|---|
| 4 | An enemy's cast is offered to a creature in reach | **Pass.** "ZZ EA Foe casts Magic Missile (2 PP). Use Disrupting Magic (your reaction)? …" It was offered after the Foe's check succeeded and before anything landed. |
| 5 | A cast that fails anyway | **Pass.** A Partial and a Failure were not offered. |
| 6 | Yes, untrained in Power Manipulation | **Finding 2.** The system refused the Dispel: "a Trained action — you must be trained (at least 1 rank) in Power Manipulation". Nothing was spent: no reaction, no PP. But the creature was asked when it could never roll. Fixed in 0.6.1. |
| 7 | Yes, trained: the Dispel dialog | **Pass.** It opened on the incoming spell: effect PP 2, its caster's DC 15. The action cost 0 AP, and the card showed "Counteract (1 PP vs 2) −2". |
| 8 | A failed Dispel | **Pass.** 9 against DC 15 failed. The Dispel spent its 1 PP. The cast card said "ZZ EA Arcanum's Disrupting Magic (Failure) fails to stop Magic Missile", and the spell landed (3 force). |
| 9 | A successful Dispel | **Pass.** A Critical (25 against 15). The card said "Magic Missile is stopped before it resolves… The spell fails. 1 PP lost (half, rounded down)." Nothing landed and Rune's HP was unchanged. Both `trgPrimeSpellCast` and `trgPrimeSpellSettled` carried `degree: "failure", disrupted: true`. |
| 10 | Second Chance on the failed Dispel | **Pass.** The Arcanum is the Witch's ally, so its failed Dispel (a skill check with a DC) offered Second Chance, as it should. This test let the 30 seconds run out, and it counted as "no". |

## The hexes

| # | Test | Result |
|---|---|---|
| 11 | Missed Chance: an enemy's save succeeds (30 ft) | **Pass.** The Witch was asked and cast it, with a Very Easy specialist check and 3 PP (25 → 22). The Foe rerolled, and the card read "Missed Chance: rerolled (24 → 24); the second result stands and cannot be modified or rerolled." The check came back `locked`. |
| 12 | …the hour's immunity | **Pass.** The Foe's flag read `missed chance: worldTime + 3600`. Its next successful save offered nothing. |
| 13 | Second Chance: an ally fails a save | **Pass.** The ally declined its own Conviction card first. Then the Witch was asked and cast it, and the ally rerolled: "7 → 19; the second result stands". It was locked, and no Conviction was offered on the second result. Second Chance immunity was recorded. |
| 14 | Prophetic Warning: not for a check without a DC | **Pass.** A Perception check awaiting the GM's DC offered nothing. |
| 15 | Prophetic Warning with another creature targeted | **Finding 1.** The cast used the user's current target and the system refused it: "ZZ EA Rune is 10 ft away — beyond Prophetic Warning's range of self." Nothing was spent and the check rolled without advantage. Fixed in 0.6.1. |
| 16 | Prophetic Warning with nothing targeted | **Pass.** The hex was cast (3 PP), and the save rolled at advantage (15 and 7, 15 kept). The card showed "Prophetic Warning: advantage". The hour's immunity was recorded, and no second advantage was armed for later. |
| 17 | Phase Familiar: the Foe stabs the Owl | **Pass.** The Witch was asked and cast it (1 PP). Of 3 piercing, the Owl took **1**. The critical's bonus die, which is precision, became 0. The card read "ZZ EA Witch casts Phase Familiar: ZZ EA Owl resists this damage." |
| 18 | Missed Chance on a weapon attack | **Pass.** Foe Two's dagger hit the Ally. The Witch cast Missed Chance, and **the attack card itself** showed both lines: "ZZ EA Witch casts Missed Chance… Missed Chance: rerolled (12 → 12); the second result stands…". |
| 19 | Immune creatures are not asked | **Pass.** Once immune, the Foe was not asked again: at its hit on the Owl (test 17), or at its saves. |

## Eternity Resilience

| # | Test | Result |
|---|---|---|
| 20 | A minor critical | **Pass.** Not offered. A minor critical's injury roll is already at disadvantage. This happened twice, on Eternity and Eternity Two. |
| 21 | A serious critical | **Pass.** Asked; yes spent the Conviction point (1 → 0). The injury roll was at disadvantage ("Rolled 55 (serious, disadvantage)"), and the card read "Eternity Resilience: a Conviction point spent, the critical roll has disadvantage." |

## Across two clients (GM and Test PC 1)

| # | Test | Result |
|---|---|---|
| 22 | The question goes to the reactor's player | **Pass.** The GM rolled Foe Three's save, and the GM's screen said "Waiting for Test PC 1: Missed Chance — ZZ EA Witch?". The question appeared on Test PC 1's screen. |
| 23 | The player's yes runs on the player's client | **Pass.** The hex's casting check, its dialogs and its 3 PP (13 → 10) all happened on Test PC 1's client. The GM's roll waited past the 30 seconds for the accepted step, then rerolled and locked. The immunity was recorded. |
| 24 | The hour's immunity on a creature the player doesn't own | **Pass.** Test PC 1's client rolled a save for Foe Four, a GM creature it doesn't own, and cast Missed Chance. The GM's client wrote the immunity: Foe Four's flag read `missed chance: worldTime + 3600`. |
| 25 | The answerer disconnects | **Pass.** ZZ EA Rune's failed save asked Test PC 1, and the tab was closed with the question open. The GM's roll went on about 2 seconds after the disconnect, not 30, with "Test PC 1 did not answer in time — no reaction." |

## Findings

1. **Prophetic Warning was cast at the user's current target.** Its range is self, so with another creature targeted the system refused the cast and the check rolled without advantage. **Fixed in 0.6.1:** it is cast at the Witch's own token.
2. **Disrupting Magic was offered to a creature that couldn't roll the Dispel.** The Dispel is a Trained action (Power Manipulation). The system refused at once and nothing was spent, but the question was pointless. **Fixed in 0.6.1:** it is offered only to a creature with a rank in Power Manipulation, or something that lets it take Dispel untrained.
   - **For Graham:** the book says only that the Spellcraft check "is treated as a Dispel (Power Manipulation) check". If you'd rather Disrupting Magic waive the Dispel's training, that's a small change.

**Two older defects in the system, seen during the test.** Neither is in 3.681.0's changes; the same code is in 3.680.1:
3. **A Death critical always kills.** The save's total is read as `saveRoll?.total`, a property a check doesn't have; it should be `saveRoll.outcome.total`. So the save is always treated as failed. Seen twice: ZZ EA Eternity's save card read "23 Success" (DC 17), and the injury card then said "rolls — against DC 17 — failed… dies". This is `combat/attack-workflow.mjs`, around line 4225.
4. **A touch-attack spell against a mark always misses.** Found by the same search. `touchAttackOutcome(Number(touch?.total ?? 0), defence)` (`magic/cast-workflow.mjs`, about line 3310) reads the same missing property, so the touch total is always 0. Not seen live.

**Cosmetic:**
- After a disconnect, the notice says "did not answer in time". The player left; the outcome ("no reaction") is right.
- A granted resistance is labelled "mundane resistance halves" in the damage breakdown. The halving is right; only the word "mundane" is wrong.
