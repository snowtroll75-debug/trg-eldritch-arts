# TRG Prime: Eldritch Arts — Rules Audit

**Source audited:** *TRG Prime: Eldritch Arts* v1.4 (`TRG_Prime_Eldritch_Arts_1_4.docx`), read in full.
**Compared against:** TRG Prime Core Rulebook 3.7 text, the core spell list and the TRG Prime system 3.674.2 code.
**Status:** preliminary. Nothing in this audit changes the book. Each entry is a question or a proposed correction for you to rule on.

## How to read this audit

**Line references.** The docx has no fixed page numbers, so every reference is a line of `ea.md`. That is the pandoc conversion of the docx with images removed, and it is kept with the build tools. Each excerpt has been checked word for word against that text by script; there are no mismatches.

**Sidebars.** pandoc drops Word text boxes. 36 of them hold rules text, including rune tier tables, the Distracted condition, Counter Channel, Leyline Power, Fade Step, Spellstrike Riposte, Foreseen Danger, Magic Drain, Resist Magic and Spellthread Risks. They were recovered from the docx XML and are treated as book text. They are cited as "sidebar after Lnnnn", the line they follow. Seven early findings of "undefined" rules were withdrawn once the sidebars were recovered.

**Severity.**

| Severity | Meaning |
|---|---|
| **Critical** | As printed, the feature cannot be used or resolved, e.g. a missing DC, a missing spell or a cost the class cannot pay. It is not built until you rule. |
| **Major** | Playable, but the text is ambiguous or contradictory in a way that changes outcomes, or it conflicts with a core rule. It needs a ruling. Interim handling is stated per entry. |
| **Minor** | Editorial or clarity issue (typo, wrong cross-reference, inconsistent name, missing degree that has an obvious default). The build follows the print. |
| **Recommendation** | Balance or design note. Not an error. Built as printed. |

**Entry fields.** Each entry gives: where it is, the printed excerpt, the problem, the core comparison, the proposed correction and the implementation status. Part A also gives the interim build. Part A's minor issues are in a table: line, printed text or issue, proposed fix.

**Implementation status.** At the time of this audit no content had been built. The status line says how each finding will be handled when its block is built. Part F's findings were made while building Block 1 (0.1.0) and say what that release does.

**Rulings (1 November 2026).** Graham answered Parts A–E in *Responses to Audit Eldritch Arts* and revised the book to v1.6. His rulings, what each changes and the questions still open are in `ELDRITCH_ARTS_RULINGS_2026-11-01.md`. Those that reach Block 1 (C1, C3, M22, M24, m2–m6, m42, m56, m58, m64, R6) are built in 0.2.0; M28 is withdrawn. Every other finding is read from v1.6 when its block is built. The findings below are kept as written against v1.4.

## Summary

| Part | Critical | Major | Minor | Recommendation |
|---|---|---|---|---|
| Part A — Chapters 1 to 7 (races to summoning circles) | 3 | 28 | 83 | 7 |
| Part B — Chapter 8 Grimoire (L5932–8038) | 2 | 31 | 57 | 8 |
| Part C — Specialist spells and armour & shield runes (L8039–9194) | 2 | 20 | 28 | 1 |
| Part D — Orbs, rods, staves, weapon runes and specific weapons (L9195–9999) | 0 | 17 | 34 | 3 |
| Part E — Relics, sentient items and appendices (L10000–11744) | 1 | 16 | 23 | 5 |
| Part F — Found while building Block 1 | 0 | 5 | 4 | 0 |
| **Total** | **8** | **117** | **229** | **24** |

The rulings that most affect play are listed first in `docs/PROGRESS.md` and in the covering note.

## Part A — Chapters 1 to 7 (races to summoning circles)

### Critical

#### EA-C1 — Nyrinn Null Aura: the save to benefit from allied spells has no type or DC
- **Where:** Nyrinn, Null Aura (L255).
- **Printed:** "Your aura also disrupts beneficial spells cast upon you by other casters, and you must make a successful saving throw to benefit from them"
- **Problem:** No saving throw type or DC. The sentence also lacks its full stop.
- **Core:** Core spells use the caster's Save DC. A beneficial spell has no reason to carry one, and the target would normally want to fail it.
- **Proposed:** Specify the save (e.g. "a Will save against the caster's Spell Save DC; on a failure the spell has no effect on you").
- **Interim build:** The aura's other two clauses ship (class bonus to saves and DB against magical effects; Spellcraft DC raised by the same amount within the aura). The beneficial-spell clause is posted as a reminder card for the GM.

#### EA-C2 — Warlock feats that spend PP the Warlock does not have
- **Where:**
  - Warlock's Hex (L4264): "you may spend 1 PP to mark them". Its only class trait is WARLOCK.
  - Pact Channeler (L3892): "you may spend +1 PP". Traits WARLOCK WITCH.
  - Grasping Shadows' "spend 1 PP" is fine for a Sorcerer.
- **Problem:** The Warlock text says "you do not possess a pool of PP" (L1450). A Warlock can never pay the cost, so Warlock's Hex is unusable by the only class it is for, and Pact Channeler is Witch-only in practice.
- **Proposed:** Graham picks one of:
  - (a) for a Warlock, the cost is paid by expending the spell's Focus use (or one Xithra use);
  - (b) the Warlock gains a small PP pool for these feats;
  - (c) the feats drop the PP cost for Warlocks.
- **Interim build:** Witch paths of Pact Channeler ship. The Warlock paths of both feats wait.

#### EA-C3 — Tap Magical Energy has no DC
- **Where:** Ch4 Power Manipulation, Tap Magical Energy (L2046).
- **Problem:** Every other action prints its DC basis; this one has none. The degree ladder cannot be resolved. The second "Fumble" (L2066) is evidently Blunder.
- **Core:** Core charged items have a level (Rod, Staff and Wand formulas). A level-based DC is the natural basis.
- **Proposed:** "a check against the item's level-based DC" (the same basis as Channel Ley Line), with the second Fumble read as Blunder.
- **Interim build:** Built with the item's level DC, flagged in the card until ruled.

### Major

#### EA-M1 — Arcanum and Dragon birthright spell tables print half the PP
- **Where:** L875 and L922: "Spells (weave)", with values 0 to 8.
- **Problem:** Every listed core spell's PP is exactly double the printed number:
  - Magic Missile 2 (printed 1)
  - Eldritch Shield 4 (2)
  - Eldritch Bolt 6 (3)
  - Dimension Door 8 (4)
  - Eldritch Ball 10 (5)
  - Eldritch Disruption 12 (6)
  - Magesword 14 (7)
  - Shield 2 (1)
  - Resist Energy 4 (2)
  - Haste 6 (3)
  - Spell Immunity 8 (4)
  - Elemental Shield 10 (5)
  - Visage of Horror 14 (7)
  - Scintillating Pattern 16 (8)

  The other five birthrights print PP 0, 2, 4, …, 16.
- **Core:** Spell PP from the core spells pack.
- **Proposed:** Head both tables "Spells (PP)" and double the values. The intent is clear from the level progression.
- **Interim build:** Granted by name; the PP comes from the spell itself, so nothing depends on the printed number.

#### EA-M2 — Out-of-date spell names in birthright and pact grants
- **Problem:** Several grants use names that do not match the core spells:
  - "Wyrm Form" (Dragon, L929) = core Shape of the Wyrm (PP 12).
  - "Eternal Form" (Eternity, L970) = Shape of the Eternal (PP 12).
  - "Elemental Form" (Storm, L1055) = Shape of the Elemental (PP 10).
  - "Shape of the Dragon" (Pact Ascendant, L3848) = Shape of the Wyrm.
  - "Neutralize Poison" (Alchemical Purifier, L2158) = Neutralise Poison.
  - "timestop" (Wild Surge 97–98, L5794) = Time Stop.
  - "Self-Healing" (Wild Surge 03–05) = Self Healing.
  - "Stormbolt" (Stormcaller, L3190) = the birthright's Storm Bolt.
- **Additional problems:**
  - Eternity's "Shield of Faith (4)" (L966): the core spell is PP 2.
  - "Dragon Wings" (Pact Boon, L3872) is not in the core. It is listed in Part B if the Grimoire has it.
  - Celestial Sentinel's "innate cure spell" (L1496) names no spell.
- **Proposed:** Use the core names. Confirm Shield of Faith's level slot and name the cure spell (e.g. Self Healing or a Divinity healing spell).
- **Interim build:** Grants use the core names.

#### EA-M3 — Archetypes with no progression requirement block every later archetype
- **Where:**
  - Eternal Vigil: "cannot progress" (L3000).
  - Runebreaker (L3112), Shade Master (L3124) and Stormcaller (L3182): no Progression Requirements line.
- **Problem:** Core rule (Ch5, repeated at L2894): "you must complete its progression requirements before you can select another." These four never complete, so a character who takes one can never take a second archetype.
- **Core:** `archetype-progression.mjs` fails open on an unparseable line but has no "cannot progress" case. Graham ruled the Pillars of Faith Priestly Path progression waived (7 Oct).
- **Proposed:** Either print requirements (e.g. "Birthright skill +10 ranks", matching High Mage) or rule that these archetypes are complete on selection.
- **Interim build:** Treated as never complete, as printed. The picker explains why another archetype is refused.

#### EA-M4 — High Magic here differs from the High Magic the system already has
- **Where:** Ch7, High Magic casting (L5590–5625).
- **What the book says:**
  - A Spellcraft check at Hard (+2 DC).
  - Fumble/Blunder auto-fail and roll top open-ended d100 +60, +5 per PP, +20 on a blunder.
  - Resonance rolled with disadvantage.
  - Armour DR ×4.
  - No focus unless Arcanum or Archmage.
  - No tradition or school.
- **Core:** `module/magic/high-magic.mjs`, from Fiends & Fables p4 (your ruling R12, 11 Oct), reads the creature guideline "All casting DCs are increased by 2" (Fiends & Fables text, quoted in that file) as a **spell save DC** +2. It also gives free Heighten and a Spell Fumble +50 on top of the usual modifiers.
- **Problems:**
  - (a) Both books say "casting DC", and Eldritch Arts spells it out as the Spellcraft check. The core's save-DC reading may be a misreading of the F&F line.
  - (b) For a PC caster, Eldritch Arts adds no save DC step and no free Heighten.
  - (c) The fumble modifier is +60 here and +50 there.
  - (d) Eldritch Arts' table lists only High Magic, PP and blunder. It is unclear whether the core tradition and ritual fumble modifiers still apply.
- **Proposed:** One ruling covering both books. The two options are:
  - **(i)** PC High Magic follows Eldritch Arts (casting DC +2, fumble +60, no save step, no free Heighten), and F&F creature High Magic stays as built.
  - **(ii)** The core's creature reading is corrected to casting DC +2.

  Also confirm whether the High Magic fumble table replaces or adds to the tradition modifier.
- **Interim build:** Not built until ruled. This is a core change (D1).

#### EA-M5 — Ley line DCs: Chapter 4 says the GM sets them; Chapter 7 tabulates them
- **Where:** Ley Sense (L1814) says "The DC of the check is set by the GM". Ch7 (L5655) gives Sense DCs 30/25/20/18/15 by ley line level. Channel and Tap use a "DC check based upon the ley lines level" (L2010, L2034) while naming bands (Minor to Legendary) rather than levels.
- **Problem:** Three different DC bases. Is the Ch7 table the default, which the GM may override? Is Tap/Channel the level-based DC for the line's numeric level?
- **Proposed:**
  - Ley Sense: the Ch7 table by default, GM may adjust.
  - Tap and Channel: level-based DC for the ley line's level, plus the printed difficulty.
  - Channel's PP bands map Minor 1–4, Lesser 5–8, Greater 9–12, Prime 13–16, Legendary 17+.
- **Interim build:** As proposed. Ley lines are scene regions carrying a level.

#### EA-M6 — Ley Line Effects: when and for how long
- **Where:** Ch7 Ley Line Effects table (L5683).
- **Problem:** Tap Ley Line grants "its benefits" until the end of this turn or the next. Ch7 says a d100 is rolled "when a creature successfully taps into a ley line", with an Effect or a Backlash. It is not said:
  - which column a successful tap uses (Effect) versus a Fumble (Backlash);
  - how long effects such as "All spells gain the extend spell metamagic feat" last (until the tap's benefit ends?);
  - whether Channel Ley Line's Heroic/Critical "benefits" also roll on this table.
- **Proposed:**
  - Success or better: roll the Effect column, lasting as long as the tap's benefit.
  - Tap's Fumble: roll the Backlash column.
  - Channel's Heroic/Critical: the same as a Tap.
  - "Next spell" effects end with the benefit if unused.
- **Interim build:** As proposed.

#### EA-M7 — Wild Surge damage and radius undefined on several rows
- **Where:** Wild Surge table (L5760).
- **Problems:**
  - Rows 48–52 and 53–57 deal "mental damage (basic Will)" with no amount.
  - Row 02 and others use "the radius" without saying it is the area-level range.
  - Row 71–74 ends "for." with no duration.
  - Row 12–15 is garbled ("of you're the areas level").
  - The Wild Mage text (L5758) calls the Wild birthright a "bloodline" and its trigger "UM 13" (unmodified 13 on the d20).
- **Proposed:** Rows apply the scaling rules: damage 1d8 × area level; radius 5 ft × area level; duration 1 round × area level.
- **Interim build:** As proposed.

#### EA-M8 — Magic Suppression: the backlash table has no trigger; level 20 is in two bands
- **Where:** L5826–5852.
- **Problems:**
  - "Some areas also apply suppression backlash", but when the table is rolled (each cast? each failure?) is not stated.
  - Levels "16-20" are dead zones and "20+" are antimagic, so level 20 is both.
- **Proposed:**
  - Areas flagged "backlash" roll the table whenever a casting check in them fails.
  - Dead zones are 16–19; antimagic is 20+.
- **Interim build:** As proposed. The scene region carries a "backlash" switch.

#### EA-M9 — Summoning circle: blood sacrifice modifier sign
- **Where:** L5975.
- **Printed:** "Circle inscribed with blood sacrifice (animal = +2, intelligent = +4, ethically damning) | varies".
- **Problem:** The table is a DC modifier, where a plus makes the circle harder. A sacrifice should make it easier, like the other favourable rows (−2, −4, −5).
- **Proposed:** −2 (animal) and −4 (intelligent).
- **Interim build:** −2 and −4, flagged.

#### EA-M10 — Catalysts: Dragonbone Dust
- **Where:** L5312 and L5497.
- **Problems:**
  - (a) "+1 damage die per PP of the spell" is far stronger than every other damage catalyst. Cinders adds one step; Glimmercoal adds 1d6 per 2 PP. It is also cheap (75 gp, level 1).
  - (b) Its backlash fires only "On a fumble or blunder", contradicting the general rule (L5232: Failure, Fumble or Blunder).
- **Proposed:** Confirm both. For (a) a likely intent is "+1 damage die" or "+1 die per 2 PP".
- **Interim build:** As printed for (a). For (b), the entry's own text wins (specific over general), flagged.

#### EA-M11 — Racial ability of Elemental Breath: "per level" costs and redundant clause
- **Where:** L2340–2342.
- **Problems:**
  - 1d6 per level of damage for 1 PP per level makes a 10th-level Wyrmdral pay 10 PP for 10d6. The cost scales with the PC's level, not with a chosen amount. Is the PP spent chosen ("up to 1 PP per level")?
  - "Be aware that if you have the Wyrmdral heritage, you must select your elemental type" repeats the prerequisite.
- **Proposed:** "Spend up to 1 PP per level; the breath deals 1d6 per PP spent". Otherwise confirm as printed.
- **Interim build:** As printed (full level), flagged.

#### EA-M12 — Tideweaver's Resilience: the trigger does not match the effects
- **Where:** L2752.
- **Printed:** "Action 0 AP: Trigger you take cold damage". The effects, however, are a constant +1 when submerged and a 1/day heal "when reduced to less than 0 HP".
- **Proposed:** Drop the cold trigger, or state what it does.
- **Interim build:** The two printed effects ship. The cold trigger is ignored, flagged.

#### EA-M13 — Spellblade: "arcane" spells for every path
- **Where:** L1240.
- **Printed:** "Each time you gain a level you automatically add one new arcane spell to your book of infusions."
- **Problem:** The Spellblade Path may be Divinity, Ethereal or Verdant.
- **Proposed:** "one new spell of your tradition".
- **Interim build:** As proposed.

#### EA-M14 — Spellblade rune limit: Spellblade level or character level?
- **Where:** Infuse Weapon (L1218): "may not exceed your Spellblade level". Runeblade (L3100): "equal in total levels to your character level".
- **Proposed:** Spellblade level (the class ability governs).
- **Interim build:** Spellblade level.

#### EA-M15 — Witch table gives a bonus feat at 1st the text does not
- **Where:** Witch table (L1751) shows 1 at 1st. The text (L1718) says "At 5th level and then every 5 levels thereafter". The Spellblade's table also shows 1 at 1st, but its text grants one ("any one class feat"). The Archmage's table shows 0.
- **Proposed:** Witch table 0 at 1st (1, 2, 3, 4 from 5th), or confirm the extra pick.
- **Interim build:** The text governs.

#### EA-M16 — Archmage memorises level × 2; the core learned budget is 2 + 2 × level
- **Where:** L689.
- **Printed:** "an amount of spells … equal to your level x2".
- **Core:** `memorisation.mjs` budget is 2 + 2·L (Cleric, Druid, Wizard). Spellblade is level + 1 (L1238).
- **Problem:** The book prints its own counts, so this is consistent with the text. It is noted because both need a per-class budget in the core (D4).
- **Interim build:** As printed.

#### EA-M17 — Classes' feat trait "Warrior" versus class type Martial
- **Where:** Spellblade bonus feats (L1230): "(Spellblade or Warrior)". The Ch5 class-feat intro (L3210) says "(Adept, Expert or Warrior)".
- **Core:** The same intro sentence appears in the core (L8380). Class types are Adept, Expert and Martial (core L2424). "Warrior" is also a core archetype.
- **Proposed:** "Martial". Confirm that a Spellblade may take Martial-trait class feats with its bonus picks.
- **Interim build:** Read as Martial.

#### EA-M18 — Catalysts and the spell attack: "a basic saving throw of a type appropriate to the spell cast"
- **Where:** L5226.
- **Printed:** "Any damage effects caused by catalysts require a basic saving throw of a type appropriate to the spell cast."
- **Problem:** Attack spells have no save. Does a catalyst's extra damage on an attack spell ride the attack (hit and degree), or force a separate basic save?
- **Proposed:**
  - Attack spells: the extra damage rides the attack.
  - Save spells: it uses the spell's save.
  - Other spells: basic Reflex.
- **Interim build:** As proposed.

#### EA-M19 — Unused Magic Discovery and the High Magic archetype set
- **Where:** Warlock (L1456): "cannot take the Magic Discovery feat from the CRB". Ch7 (L5576): "Members of other classes can only learn high magic spells by selecting a High Magic Archetype feat."
- **Problem:**
  - Magic Discovery is not in the core.
  - "High Magic Archetype feat" is not a defined set. Hex Weaver, High Mage and Birthrager each grant High Magic spells.
- **Proposed:**
  - Remove the Magic Discovery sentence, or name the core feat meant.
  - Define the set as Birthrager, Hex Weaver and High Mage.
- **Interim build:** The set as proposed.

#### EA-M20 — Spell Surge prerequisite and "disadvantage" on d100 tables
- **Where:** Spell Surge (L4630), High Magic Resonance (L5621), Ley Line Effects 66 and Wild Mage.
- **Problems:**
  - "Prerequisites High Magic Caster" is not a defined status. Read it as: a class whose spells are High Magic, or the High Magic archetype set.
  - Disadvantage on the Spell Fumble or Resonance d100 means "roll twice, take the higher (worse)". This is stated for Resonance (L5623) but not for Spell Surge's fumble roll.
- **Proposed:** As stated.
- **Interim build:** As proposed.

#### EA-M21 — Ritual Expert and Rune-Binder's Precision give the same benefit
- **Where:** L4574 and L4582.
- **Printed:** Both: "you count as two casters instead of one" / "you are always considered to be two casters".
- **Problem:** Do they stack (three casters)? Archsage Command (whose prerequisite is Rune-Binder's Precision) adds "an additional caster beyond those present".
- **Proposed:** They do not stack (two at most from either). Archsage Command adds one more.
- **Interim build:** As proposed.

#### EA-M22 — Racial Null Aura and Zhal-vryn affect the Nyrinn's own allies' casting with no exemption
- **Where:** L255 and L279.
- **Problem:** "all Spellcraft checks made within this aura (including your own) have their casting DC increased", and Zhal-vryn makes "All creatures within your Null Aura" pay +1 PP. That includes allies, with no way to suppress the aura.
- **Proposed:** Confirm. Many races would let the aura be suppressed as a free action.
- **Interim build:** As printed: an always-on 5 ft aura. The casting gate applies to every caster in it.

#### EA-M23 — Birthrager: "low PP and a low spellcraft bonus" are not defined
- **Where:** Birthrager archetype (L2914); BERSERKER trait (Appendix, L10675).
- **Printed:** "You become an instinctive caster and gain a caster level equal to half your level (round up), low PP and a low spellcraft bonus."
- **Problem:** Neither the core nor Eldritch Arts defines a "low" PP or spellcraft track. Core PP is "Race Bonus + Class Bonus + Other Modifiers" (Core L930), and BSB comes from each class table's own column. Without a table, a Birthrager's PP and BSB at each level cannot be set. The archetype is reachable: the BERSERKER trait requires the Frenzy feat (core Martial, Invoke/Revoke Rage). The flavour text says "bloodragers" and "Like Magi", which do not match the archetype's name.
- **Core:** Core class tables give PP and BSB per level per class. There is no named low tier to borrow.
- **Proposed:** Print the Birthrager's PP and BSB by level, or name a core class whose columns it uses at half rate.
- **Interim build:** These parts ship: the birthright's specialist spell (cast with the innate rules), Sorcerer feat access, and casting while raging. The PP pool and BSB wait for your ruling.

#### EA-M24 — Magic Drain: what the "temporary magical energy" is, and the Vir-ellian "aura"
- **Where:** Sidebar after L253 (Magic Drain); Vir-ellian (L273); Crystal Pulse (L2262).
- **Printed:** "You gain temporary magical energy equal to the drained PP (max your level × 2)." … "The absorbed energy grants you a +1 racial bonus to AB, DB, saving throws or skill checks for 1 minute per PP drained." Vir-ellian: "release the energy … to all creatures within your Magic Drain aura".
- **Problem:** (a) whether the temporary energy can be spent as PP (as Tap Magical Energy's PP can) or only fuels the +1 bonus; (b) which of AB/DB/saves/skills the +1 goes to (a choice?); (c) Magic Drain is a 30-ft targeted action, not an aura, so "within your Magic Drain aura" has no area; (d) Success has no Failure/Fumble rows.
- **Proposed:** (a) the energy is a pool of temporary PP that also grants the bonus while held; (b) the drainer chooses one; (c) "within 30 feet"; (d) Failure and worse: nothing drained.
- **Interim build:** as proposed, flagged.

#### EA-M25 — Leyline Power stacks with Leyline Weaver's own Critical and Ley Channeler
- **Where:** Sidebar after L3088 (Leyline Power); Leyline Weaver replacement ladder (L3082); Ley Channeler (L4470); Confluence Master (L3338).
- **Problem:** on a Critical Tap a Leyline Weaver already "regain[s] 1d8 PP" from the replaced ladder; Leyline Power (a reaction to the same Tap) adds 2d8; Ley Channeler adds 2d4; Confluence Master adds 1d8. Four PP sources from one 1-AP action. Is Leyline Power meant to replace the ladder's 1d8?
- **Proposed:** confirm stacking, or read Leyline Power's PP as the ladder's (one source).
- **Interim build:** stacking as printed, flagged.

#### EA-M26 — Spellstrike is still undefined
- **Where:** Sidebar after L3158 (Spellstrike Riposte): "you may also channel a cantrip through it as if using Spellstrike"; Spellblade's Mark (L4112): "Your Spellstrike against your Mark deals an additional +1d6".
- **Problem:** the riposte itself is now defined, but the Spellstrike it refers to is not printed in v1.4 (body or sidebars) or the core.
- **Proposed:** supply Spellstrike, or define the channel ("the cantrip's effect resolves against the struck target without a casting check").
- **Interim build:** the riposte and the Mark's other benefits ship; the cantrip channel and the Mark's +1d6 wait.

#### EA-M27 — The Appendix's Highmagic trait contradicts Chapter 7 twice
- **Where:** Appendix, HIGHMAGIC (L10677–10689) vs Ch7 High Magic (L5566, L5576).
- **Printed:** Appendix: "Highmagic spells count as belonging to all traditions simultaneously" and "Characters without the High Magic class feature may still attempt to learn and cast Highmagic spells … a skill check against a Very Hard DC (+5)". Ch7: "high magic spells belong to no tradition or school of magic" and "Members of other classes can only learn high magic spells by selecting a High Magic Archetype feat."
- **Problem:** (a) no tradition vs all traditions — opposite answers for tradition gates (Forbidden Magic, armour by tradition), counters "targeting any tradition", and tradition-keyed bonuses; (b) archetype only vs anyone with a Very Hard learning check; (c) "High Magic class feature" is not a named feature (the classes say "you treat all traditions as high magic"). (d) The Very Hard (+5) learning check names no skill (Arcana is the natural reading). The Part E read found the same two contradictions independently; they are recorded here only.
- **Core:** core tradition gates read a spell's `tradition`; an empty tradition passes gates that a tradition list would fail.
- **Proposed:** keep Ch7 for casting by High Magic casters (no tradition: gates, school and tradition bonuses skip), and the Appendix for others (learn at Very Hard, cast at Hard); "counted as all traditions" only for effects that counter or resist by tradition.
- **Interim build:** waits — part of the High Magic ruling (EA-M4, D1).

#### EA-M28 — Hexes: the Warlock gets one, ever
- **Where:** Warlock, Hexes (L1462).
- **Printed:** "At 1st level you may select any one hex for which you meet the requirements."
- **Problem:** There is no progression, unlike the Witch (hex at 1st, 3rd and every three levels, L1736), and no feat grants a Warlock more hexes. Whether this is intended matters to the class's whole design.
- **Proposed:** Confirm one hex only, or give the Witch's schedule.
- **Interim build:** One hex at 1st, as printed.

### Minor (editorial and clarity)

| ID | Where | Printed / issue | Proposed |
|---|---|---|---|
| EA-m1 | L119 | "Racial feats … can be found … in Chapter 6" — they are in Chapter 5 | Chapter 5 |
| EA-m2 | L117, 227, 249, 259 vs 229 onward | Race spelled both "Nyrinn" and "Nyrrin" | One spelling (the trait is NYRINN) |
| EA-m3 | L217, L225 | Galeborne and Tidemarked both print "Dexterity increases by 1, and your Strength decreases by 1" | Confirm Tidemarked (e.g. Wis +1, Str −1) |
| EA-m4 | L165, L173 | Caelari and Umbryth both "resistance to essence damage" | Confirm Umbryth (cold?) |
| EA-m5 | L323 | Glyphweave "an additional bonus cantrip" — one more permanent cantrip, or a second daily pick for Innate Magic? | One more daily pick |
| EA-m6 | L345 | Wyrmdral "+1 … when casting spells of their type" — "type" = damage type of their element | As proposed |
| EA-m7 | L1121, L5756 | Wild birthright: "Wild Surge table (see chapter 6)" — it is Ch7; heading "WILD MAGIC AEAS" | Ch7 |
| EA-m8 | L943, L1027, L1115 | "feint white light" | faint |
| EA-m9 | L1035 | Gale Step "15 meters" (system uses feet); no frequency (FOCUS trait implies once per Refocus) | 50 ft; Focus |
| EA-m10 | L1368 | Dimensional Step: no frequency | Focus default |
| EA-m11 | L1598 vs L1600 | Warlock Bonded Soul heading "THE WHISPERED SAGE"; text "Whispered Shade" (×2) | One name |
| EA-m12 | L1592 | Void Seer has no once-per-day Xithra rider; the other seven do | Confirm |
| EA-m13 | L1500, L1516 … | "treated as one level higher" — for innate spells this is the innate level (DC, warp budget, PP limit) | As proposed |
| EA-m14 | L1854 | Borrow Spell: "the spell slot remains available" — no slots | "the memorisation remains available" |
| EA-m15 | L1984 | Power Manipulation intro lists "Dispel, Recharge Item, Sense Magic and Sigil" as added; the added actions are Quickbind, Channel/Tap Ley Line, Tap Magical Energy | Update list |
| EA-m16 | L1996 | Quickbind Failure: "The is invested" | "The item is invested" |
| EA-m17 | L1926 | Hypnotism unwilling creature "(Indifferent or Better Attitude)" — contradictory label | "(Indifferent or worse)"? |
| EA-m18 | L2074–2082 | Chapter 5 introduction is the Inner Tempest monk/mystic/chi text (Wu Jin) | Replace |
| EA-m19 | L2282 | Draconic Immunity "certain affects" | effects |
| EA-m20 | L2486 | Moonlight Precision "Wen in Dim Light" | When |
| EA-m21 | L2542 | Radiant Presence "Allies with the aura" | within |
| EA-m22 | L2560 | Resonant Ascendance "with 30 feet" | within |
| EA-m23 | L2586 | Runic Aptitude's flavour line duplicates Pyrotechnic Flair's | New line |
| EA-m24 | L2608 | Scaelyn Scholar "+1 … to Arcane & Crafting" | Arcana |
| EA-m25 | L2716 | Stonebound Bastion (Stonevein, earth/acid) carries the ELECTRICITY trait — copied from Stormrunner's Zeal | Drop or EARTH |
| EA-m26 | L2748 | Tideweaver's flavour names "the Thalassyn" | Tidemarked |
| EA-m27 | L2862 | Whispers of the Void "Intimidation" | Intimidate |
| EA-m28 | L2878 | Existing feats list ends with a stray comma | — |
| EA-m29 | L2910 | Birthrager name versus "bloodragers" (see EA-M23) | — |
| EA-m30 | L2980 | Elemental Pact resistance mapping "(air -electricity, earth – acid, fire or water – cold)" | air → electricity, earth → acid, fire → fire, water → cold |
| EA-m31 | L3084–3086 | Leyline Weaver "gaining is benefits" (×2) | its |
| EA-m32 | L3136, L3122 | "costs your 2 PP less" | costs you |
| EA-m33 | L3010 | Fatespinner "grants increases your maximum" | — |
| EA-m34 | L3190 | Stormcaller "Stormbolt" | Storm Bolt |
| EA-m35 | L3434, L3968 | "Spellblades Mark", "Duellists Focus" (heading DUELLISTS FOCUS) | Apostrophes |
| EA-m36 | L3678 | Last Horizon prerequisite "Temporal Retrieve" — the feat is Temporal Reprieve; "do need not to"; "the dying conditions acts" | — |
| EA-m37 | L3396–3404, L900 | Two different "Draconic Claws": birthright ability (1 AP concentrate, 1d6 piercing, BSB optional) and class feat (natural weapon, 1d6 slashing, BSB always) | Rename the feat or align the stats |
| EA-m38 | L3454, L3462, L4306–4322 | Warlock feats call the ability "Xithra Blast"; Xithra Spear says "eldritch blast" | Xithra |
| EA-m39 | L3468, L4294 | Stray backtick at the end of two flavour lines | — |
| EA-m40 | L3502 | Extra Cantrip "an additional casting slot" | additional cantrip memorised |
| EA-m41 | L3540 | Fate's Favour "The first time each day that use … check;" | — |
| EA-m42 | L3588 | Grasping Shadows' ladder has no Fumble row and uses "per 2 Sorcerer levels" | Add Fumble (as Failure) |
| EA-m43 | L3980 | Ritual of Borrowed Power repeats its flavour sentence as rules text | — |
| EA-m44 | L4134–4146 | Spellthread Mastery and Unbound share identical flavour | — |
| EA-m45 | L4156 | Steelbinding "PP Cost +2**; Requirements**" formatting | — |
| EA-m46 | L4200 | Temporal Reprieve "you immediately regain heal yourself of 1d8 HP per PP expended" — no PP cost or cap printed | "spend up to X PP" |
| EA-m47 | L3844–3856 | Pact Ascendant: Fey and Void both "immunity to all effects with the mental trait" | Confirm Void |
| EA-m48 | L3904 | Pact Channeler Grave "essence damage.." | — |
| EA-m49 | L4386 | Dispel Power: "You replace your caster level When making a check in this way replace…" — broken sentence | "When making a check in this way, replace the usual Dispel results with …" |
| EA-m50 | L4334 | Archsage Command "an Arcana or Ritual check" — Ritual is not a skill | Arcana or tradition-skill ritual check |
| EA-m51 | L4376 | Circle Adept prerequisite "Arcane" | Arcana |
| EA-m52 | L4430 | Esoteric Insight Expert "reroll on a critical failure" vs the base feat "when you fumble" | fumble |
| EA-m53 | L4446 | Essence Reservoir "Tap Magical Energies" | Energy |
| EA-m54 | L4566 | Rapid Binder "in 1 round without penalty (instead of –5)" — Quickbind has no time ladder | Clarify |
| EA-m55 | L4590 | Runespeaker "Linguistic ranks" | Linguistics |
| EA-m56 | L4624 | Spell Penetration lowers "Spell Resilience" — not a core term | Name the ability meant |
| EA-m57 | L4558 | Piercing Insight "Sense Power (Power Manipulation) actions" — core action name check | — |
| EA-m58 | L4746 | Background wealth table omits Spirit Binder (12 backgrounds, 11 rows) | Add Spirit Binder |
| EA-m59 | L4813 | Bloodwood "+1-item bonus to Spellcasting checks" | Spellcraft |
| EA-m60 | L4835 | Graveiron "Smith's note" | Smiths note |
| EA-m61 | L4857–4869 | Starion is called "star-iron" in its own bullets | One name |
| EA-m62 | L4975 | Claidheamh Dubh's description is the Claíomh Draíochta paragraph (a curved serrated blade; names the other weapon) | New description |
| EA-m63 | L4954 | Bogha Tuama traits "Piercing. Range 120" | Piercing is not a weapon trait; comma |
| EA-m64 | L4934–4955 | Race names used as weapon traits (Emberkin, Wyrmdral, Scaelyn, Aetherial, Nyrrin) with no rule for what they do | Rule: members of that race are trained with the weapon |
| EA-m65 | L5107 vs L5190 | Gilded "Censor" Chains (text) vs "Censer" (table) | Censer |
| EA-m66 | L5127 vs L5195 | Ritual Censer: text "reduces the ritual's DC by 1"; table "+1 to ritual Spellcraft check" | Pick one (the text) |
| EA-m67 | L5115 vs L5192 | Leybraid Rope: text "advantage on Climb checks"; table "… in magical areas" | Pick one |
| EA-m68 | L5161 vs L5205 | Ward Twine / Ward-Twine | One spelling |
| EA-m69 | L5326, L5446 | Catalyst headings "FROZEN MARRROW SHARD", "STORMGLASSS PHIAL" | — |
| EA-m70 | L5344, L5434, L5464 | Glimmercoal "per spell 2 PP"; Spell Incense "foe 1 minute"; Verdant Sap "as the sap their mind" | — |
| EA-m71 | L5274 vs L5493 | Blood-Etched Vellum backlash max 10 in text, not in table | Add to table |
| EA-m72 | L5139, L5147 | Spellbinder's Cord / Twilight Prism "Concentration checks" — the core check is Spell Concentration | — |
| EA-m73 | L5568 | "another spell that effects a specific school" | affects |
| EA-m74 | L5884–5886 | Mundane ritual: the Eligibility paragraph is printed twice | — |
| EA-m75 | L5964 | "SUMMMONING"; "(GM Discretion" missing bracket | — |
| EA-m76 | L5986 | "Invoking a true name during a summoning grants increases the Save DC" | increases |
| EA-m77 | L3880, Pact Boon | "Dragon Wings" spell — see EA-M2 | — |
| EA-m78 | L1442 vs L1478 | Warlock text alternates "Bonded Soul" (ability) and "Bonded Soul" (choice list) — fine; "Pact" archetypes are separate from Bonded Souls, and nothing says whether a Warlock's pact must match its Bonded Soul | Confirm independent |
| EA-m79 | Sidebar after L3146 (Counter Channel) | "Trigger A creature 30 feet casts a spell" (missing "within"); a spell with no Save DC uses which DC?; "The spell double all of its variables" | "within 30 feet"; the caster's Spell Save DC for that PP; "doubles" |
| EA-m80 | Sidebar after L990 (Resist Magic) | Reaction with no frequency (WARDING only, no FOCUS) — usable on every hit while reactions remain | Confirm |
| EA-m81 | Sidebar after L3132 (Fade Step) + Eclipse Step (L3444) | Fade Step has the FOCUS trait (one use per Refocus), but Eclipse Step lets it be used "as a Free action once per round" | Eclipse Step lifts the Focus limit while in shadow, or only changes the action cost |
| EA-m82 | Sidebar after L8937 (Catalyst rune tiers) | Catalyst I–IV print "The penalty is -2/-4/-6/-6" (copied from Binding Sigils), and IV repeats III's level and price; the rune text says the tiers set how many catalysts can be imbedded | Tiers give catalyst count 1/2/3/4; IV level/price |
| EA-m83 | Sidebar after L703 (Ley Line Range) | Ley Tap and Archmage abilities use the Ley Bond range (100 ft per level), while Tap/Channel Ley Line use 30 ft | As printed (the sidebar says ranges differ by class) |
| EA-m79 | Sidebar after L3146 (Counter Channel) | "Trigger A creature 30 feet casts a spell" (missing "within"); a spell with no Save DC uses which DC?; "The spell double all of its variables" | "within 30 feet"; the caster's Spell Save DC for that PP; "doubles" |
| EA-m80 | Sidebar after L990 (Resist Magic) | Reaction with no frequency (WARDING only, no FOCUS) — usable on every hit while reactions remain | Confirm |
| EA-m81 | Sidebar after L3132 (Fade Step) + Eclipse Step (L3444) | Fade Step has the FOCUS trait (one use per Refocus), but Eclipse Step lets it be used "as a Free action once per round" | Eclipse Step lifts the Focus limit while in shadow, or only changes the action cost |
| EA-m82 | Sidebar after L8937 (Catalyst rune tiers) | Catalyst I–IV print "The penalty is -2/-4/-6/-6" (copied from Binding Sigils), and IV repeats III's level and price; the rune text says the tiers set how many catalysts can be imbedded | Tiers give catalyst count 1/2/3/4; IV level/price |
| EA-m83 | Sidebar after L703 (Ley Line Range) | Ley Tap and Archmage abilities use the Ley Bond range (100 ft per level), while Tap/Channel Ley Line use 30 ft | As printed (the sidebar says ranges differ by class) |

### Recommendations (balance and design; not errors)

- **EA-R1:** Eye of the Storm deals 1d6 electricity per character level to every enemy in 30 ft at the start of each turn for 3 rounds, and grants electricity immunity. At 14+ ranks this is 14d6 or more per round. Compare Elemental Exhalation (1d6 per 2 levels).
- **EA-R2:** Catalyst Affinity reduces backlash damage "by 2 per character level". At level 10 that is −20, which negates almost every printed backlash.
- **EA-R3:** Ashen Lotus Bloom (Soul Drain 1 per PP on a failure) and Void Ash (1d4 Soul Drain per 2 PP) are far harsher than the other catalysts' backlashes at similar prices.
- **EA-R4:** Unfettered Mastery quickens every High Magic spell at no PP cost. The core Quicken Spell costs +8 PP.
- **EA-R5:** Absolute Denial: enemy spells of PP 8 or lower simply fail within 20 ft, with no check.
- **EA-R6:** The Ord ua na Tuama (L4943) is level 0, 50 gp, 1d12 B, Mighty +2. That is higher damage than most martial two-handers, while the table gives it no Two-Handed trait.
- **EA-R7:** Vein of Power's spell adder (+1, +1 per 5 levels) stacks with the Witch's familiar adder and Bonded Infusion. Confirm stacking (spell adders from different sources).

## Part B — Chapter 8 Grimoire (L5932–8038)

### Critical

#### EA-C4 — SOUL CONFLUENCE
- **Where:** L7640–7644
- Excerpt: "**Backlash** At the end of the spell, all participants suffer 1d6 Soul Drain per 2 rounds the spell lasted."
- Problem: the Duration is a fixed 10 minutes (100 rounds) with no (D) and no sustain. Backlash is therefore always 50d6 Soul Drain (about 175) on every participant. Soul Drain reduces maximum HP, so everyone dies. Separately, the pool ("sum of their Constitution modifiers × 5", e.g. 4 allies at +2 = 40) is tiny, and it's unclear whether it replaces or sits on top of each ally's own HP.
- Core check: SOUL DRAIN condition ("reduces your maximum hit points… If… less than 0, you die").
- Proposed correction: "**Duration** Sustained (up to 10 minutes)" and "1d6 Soul Drain per 2 rounds the spell was sustained (maximum 5d6)". State: "The pool is a buffer of temporary HP absorbed before each participant's own HP."
- **Status:** Not built. Awaiting your ruling; the feature ships only once the text can be resolved.

#### EA-C5 — VEIL SEVERING
- **Where:** L7919–7937
- Excerpt: "**Critical** Oath lasts 1 year, and oath breakers also take double damage."
- Problem: the whole outcome ladder (L7921–7931) and both warps (L7935–7937) are a verbatim copy of RITE OF BINDING OATH (L7528–7544). They refer to oaths that don't exist in this spell. The portal's duration ("varies") is therefore never defined, and the spell cannot be resolved.
- Proposed correction: rewrite, for example:
    - Critical: the portal lasts 1 hour and allows Huge creatures.
    - Success: 10 minutes.
    - Partial: 1 minute, one-way.
    - Failure: the ritual collapses; all casters take 4d6 essence (basic Fort).
    - Fumble: 8d6.
    - Blunder: 12d6, and a hostile planar entity comes through.
    - Warps: +2 PP for +10 minutes; +4 PP for 1,000 miles.
- **Status:** Not built. Awaiting your ruling; the feature ships only once the text can be resolved.

### Major

#### EA-M29 — High Magic spells carrying a school trait
- **Where:** L6470, L6772, L7084, L7630, L7646, L7871
- Excerpt (L6470): "ALTERATION HIGHMAGIC UTILITY"; (L6772): "ALTERATION HIGHMAGIC RITUAL UTILITY"; (L7086): "**ENCHANTMENT HIGHMAGIC MENTAL SAVE**"; also "HIGHMAGIC SOUL UTILITY" (L7632), "HIGHMAGIC INVOCATION SAVE" (L7648), "HIGHMAGIC TRANSLOCATION UTILITY" (L7873)
- Problem: Ch.7 L5566 says "high magic spells belong to no tradition or school of magic". Six High Magic spells print a wizard school trait: Chronoweave and Essence Reforging (Alteration), Memory Eclipse (Enchantment), Soul Confluence (Soul), Storm of Unmaking (Invocation) and Veilfracture (Translocation). School-keyed features (a wizard specialist's school benefits, effects that target a school) would then apply to them. Leyline Burst and Mimic Spell carry no school and are fine.
- Proposed correction: remove the school traits from High Magic spells, or add a Ch.7 line saying a school trait on a High Magic spell is descriptive only.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M30 — Ritual "Critical" results cannot be reached
- **Where:** L6292 / L6416 / L6486 / L6714
- Excerpt (L6310): "Critical All undead rise under control; duration is 1 month."
- Problem: Core Magic Ritual rules cap the result: "the maximum result is a success" (CORE L20135). EA's Ritual Spells text (L5932) adds effects "determined by the Ritual … check" but never lifts that cap, and grep "maximum result" on ea.md returns 0 matches. So every ritual "Critical" line in this range can never happen: ARMY OF THE GRAVE, CALL OF THE ANCESTORS, CONCORD OF STONE and ELEMENTAL CONVERGENCE.
- Core check: `grep -n "maximum result" rulebook-core-3.7.txt` returns L20135.
- Proposed correction: Add one sentence to L5932: "Spells with the Ritual trait ignore the core cap that limits a ritual's result to Success."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M31 — Binding family pricing (balance)
- **Where:** L6078 / 6646 / 6744 / 6788 / 6888
- Excerpt: "**+1 PP:** increase the level of the creature by 1."
- Problem: Base creature levels and PP do not follow the +1 PP per level warp rate:
    - Animal: level 1 at PP 4
    - Fey: level 1 at PP 6
    - Elemental: level 2 at PP 6
    - Eternal: level 6 at PP 10
    - Entity: level 8 at PP 12
    - Outside this range: Plant level 2 at PP 6 (L7356), Undead level 4 at PP 8 (L7845), Wyrm level 6 at PP 12 (L7985)
    Warping the cheap bindings beats the expensive ones. Animal Binding warped to PP 12 gives a level 9 animal, while Entity Binding at PP 12 gives level 8. Fey Binding at PP 6 gives level 1, while Animal Binding at PP 6 gives level 3.
- Proposed correction: Set the warp to +2 PP per level, or line up the base PP so that base PP = 2 + 2 × base level (or a similar single curve).
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M32 — ACIDIC BURST
- **Where:** L6030
- Excerpt: "**ACID INVOCATION SAVE**" (followed straight away by "**Cast** 2 AP")
- Problem: There is no Tradition line, so no class can be shown to learn the spell. Every core spell outside the class lists has one (compare core ACIDIC ERUPTION: "Tradition arcane, verdant"). It is not High Magic either, because it has a school (INVOCATION).
- Core check: RS["ACIDIC ERUPTION"].text has "Tradition arcane, verdant".
- Proposed correction: Add "**Tradition** arcane, verdant".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M33 — ARCANE BASTION
- **Where:** L6130
- Excerpt: "the shield again shatters, but lowers the severity of the critical by one step (negating a minor)."
- Problem:
    - "Shatters" is never tied to the spell ending. "Again" suggests it can shatter twice.
    - It does not say whether the 0-HP clause and the critical clause are both available.
    - Lowering severity after the injury result is known means re-rolling on a different severity. Core rolls Minor with disadvantage and Deadly with advantage (CORE L15418+), so the procedure is undefined.
    - The flavour text "physical and elemental attacks" conflicts with "resistance to all damage".
- Core check: CORE "CRITICAL SEVERITY" section, L16063 onward.
- Proposed correction: "When either trigger occurs the spell ends. Reduce the critical's severity before rolling the injury result."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M34 — ARCANE MYCELIUM
- **Where:** L6182–6188
- Excerpt: "**Failure** target is slowed 1 until the beginning of their next turn."
- Problem: Core slowed removes AP only in Phase 1, and gaining slowed during your turn has no immediate effect (CORE L31099). A creature that enters on its own turn loses slowed exactly when it would start to apply, so the effect does nothing. Also:
    - The sentence at L6182 has no full stop.
    - The ladder lacks Critical, Partial and Blunder.
    - Traits lack SAVE.
- Core check: CORE L31099–31102 (SLOWED).
- Proposed correction: "…slowed 1 until the end of their next turn". Add "Partial as Success" and the SAVE trait.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M35 — BLOOD BIOGRAPHY
- **Where:** L6340
- Excerpt: "living or undead creatures are entitled to a Will Saving Throw to resist the spell."
- Problem: There is no Saving Throw line and no outcome ladder, and it does not say what a successful save does. There are no Targets either.
- Proposed correction: Add "Targets a sample of blood; Saving Throw Will (living/undead source). Critical/Success: no answers; Partial: only the first two answers; Failure: all answers."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M36 — CHAOS SHIELD
- **Where:** L6458–6460
- Excerpt: "roll twice, taking the better result, on any wild magic effect table."
- Problem:
    - The Wild Surge table (L5760+) is not ordered from good to bad, so "the better result" cannot be determined.
    - "Resistance to wild surge backlash effects" is undefined, because resistance halves damage of a type.
    - "Wild magic zones" should be "Wild Magic Areas" (L5722).
    - "Hostile spell warp effects" is undefined.
- Proposed correction: "roll twice and choose which result applies"; "halve damage from Wild Surge results"; use "Wild Magic Area"; drop "(including hostile spell warp effects)" or define it.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M37 — CHRONOWEAVE
- **Where:** L6478
- Excerpt: "You and all allies with the spells effect gain the Quickened condition."
- Problem: Core Quickened requires the effect to name what the extra AP may be used for (CORE L31092). This spell names nothing, so the AP is unrestricted. "With the spells effect" is a garble of "within the spell's area". The warp's slowed has no duration. Balance: core HASTE is PP 6 for one target, restricted to Strike/Stride, at +2 PP per extra target. This is PP 12 for the whole party with no restriction.
- Core check: RS["HASTE"]; CORE L31092 (QUICKENED).
- Proposed correction: "You and willing allies within the emanation are quickened; the extra AP may be used only to Strike, Stride or Sustain a Spell." Warp: "…slowed for the spell's duration."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M38 — CONCORD OF STONE
- **Where:** L6502–6508
- Excerpt: "**Failure** primary casters take 2d6 essence damage (basic Fort)." / "**Blunder** as Failure, but the damage is 8d6."
- Problem: The ladder skips Fumble, unlike every sibling ritual, which uses 2× and 4× steps. "Primary casters" is plural, but a ritual has one primary caster. Partial gives a reduced effect without the "replaces the normal partial result" wording that ARMY OF THE GRAVE uses. "Allies defending" is undefined.
- Proposed correction: Add "Fumble as Failure, 4d6". Use "all casters". Add "This replaces the normal partial result". Use "your allies within the zone".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M39 — DREADMOTE (balance)
- **Where:** L6588–6592
- Excerpt: "**Cast** 1 AP (somatic)"
- Problem: Every core attack cantrip costs 2 AP (ORB OF FORCE: 2 AP, 1d4). At 1 AP this cantrip can be cast up to three times a turn. There is also no Base Damage line, which an attack spell needs for its critical, and the FEAR trait has no fear effect.
- Core check: I scanned RS for PP 0 cantrips with the ATTACK trait and "Cast 1 AP". None exist.
- Proposed correction: Use "Cast 2 AP", or keep 1 AP with "once per turn". Add "Base Damage 1d4". Add "On a critical hit the target is frightened 1", or drop FEAR.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M40 — EAOG BALLS
- **Where:** L6634–6644
- Excerpt: "The target also takes 1d6 persistent force damage." / "2d8 persistent coldfire damage"
- Problem: "Persistent" damage is not a core mechanic; core uses Recurring Damage (CORE L15624), and grep "persistent" in CORE returns 0. "Coldfire" is not a damage type in core or EA (grep gives 1 hit, this line). The warp grammar is broken ("causing the target suffers"), and it does not say whether the warp applies even on a Critical save.
- Core check: `grep -c "persistent"` = 0; `grep -c -i "coldfire"` = 0.
- Proposed correction: "recurring force damage (no flat check; ends when the spell ends)". "Coldfire" means "cold and fire damage (split evenly)", or pick one type. "…the target takes an additional 2d8 recurring fire damage… (not on a Critical)".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M41 — ELEMENTAL STRIKE
- **Where:** L6676–6688
- Excerpt: "you may make 1 AP attack actions with a melee weapon that you are trained in."
- Problem:
    - It does not say whether weapon damage also applies or is replaced.
    - Reach, the number of uses per turn, and the multiple attack penalty are not stated.
    - The traits lack SAVE and a school, although a Basic Reflex save is printed.
    - The warp costs +4 PP per 1d6, inconsistent with DRAGON'S BREATH's +1 PP per 1d6.
- Proposed correction: "As a 1 AP Strike against a creature within your weapon's reach, the target instead makes a basic Reflex save against 1d6 + casting attribute damage of the chosen type (no weapon damage; does not count toward your multiple attack penalty)". Add the SAVE and INVOCATION traits. Warp: +2 PP.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M42 — ELEMENTAL CONVERGENCE
- **Where:** L6720 / L6732
- Excerpt: "**Failure** all casters suffer 2d6 elemental damage (basic Reflex)."
- Problem: "Elemental" is not a damage type. Also, unlike the other rituals, the Cast line lacks "secondary casters".
- Proposed correction: "…2d6 damage of a random energy type (acid, cold, electricity, fire)". Add "secondary casters" to Cast.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M43 — ESSENCE REFORGING
- **Where:** L6774–6786
- Excerpt: "- Change a creature’s race."
- Problem:
    - There are no rules for changing race: willingness or save, how ability modifiers, feats and HP are recalculated, or reversibility.
    - The Cast line has no components and there is no Range or Cost line, unlike every other ritual.
    - The resurrection option costs PP 14 with no material cost, so it skips core RESURRECTION's "gemstones worth 200 gp x the targets level" and its "12th level or lower" limit (RS).
- Core check: RS["RESURRECTION"].
- Proposed correction: Add "Cast 1 hour (material, somatic, verbal); Range touch; Cost as the replicated spell (Resurrection: 200 gp × level)". "Race change: willing target only; rebuild ancestry choices as for a new character of that race."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M44 — FLESH TO BLOSSOM
- **Where:** L6928–6938
- Excerpt: "At the beginning of each turn, the target must make a new saving throw."
- Problem:
    - It does not say whose turn.
    - Later saves have no stated results: it is not clear whether a later Critical ends the spell, whether a later Success removes immobilised, or whether results escalate.
    - "Petrified (Plant Form)" is a variant that is not defined.
    - Petrification "for the spell's duration or until cured" makes Remove Curse moot, since the spell is sustained.
    - The Duration line has a stray semicolon.
- Proposed correction: "At the start of each of the target's turns while sustained, it saves again and the new result replaces the old." "Petrified (as a plant; object immunities as core petrified)". "On a Fumble the petrification becomes permanent until removed with Remove Curse."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M45 — LEYLINE ANCHOR
- **Where:** L7032–7036
- Excerpt: "All high magic spells cast within the radius are treated as one PP lower." / "must make a Power Manipulation check vs your Spell Save DC + 5 before they make their check."
- Problem:
    - It does not say what "one PP lower" affects: cost, casting DC, Save DC, or the max-PP cap.
    - It does not say what happens when the Power Manipulation check fails.
    - "The radius" has no source: is it 300 ft from the caster or from the leyline?
    - The traits FORCE and SAVE have no matching effect.
    - The spelling switches between "leyline" and "ley line".
- Proposed correction: "…cost 1 PP less (min 1) and use a casting DC as if 1 PP lower; Save DC unchanged. On a failed check the Tap Ley Line attempt fails and the action is lost. All effects apply within 300 ft of the anchored ley line." Remove FORCE and SAVE. Use "ley line" throughout.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M46 — MEMORY ECLIPSE
- **Where:** L7094–7102
- Excerpt: "**Success** Target is Confused for 1 round." … "**Failure** Target forgets the last minute and is Dazed 2"
- Problem: the ladder is upside down in combat terms. Confused (the creature must spend all its actions attacking a random creature, with no reactions, per core) is more severe than Dazed 2 (a −2 status penalty to mental rolls). As written, a Success can hurt the target more than a Failure. There is also no "Saving Throw" header line (Will appears only in the prose), and the Fumble's "Frightened 2" has no duration.
- Core check: CONFUSED and DAZED condition text in the conditions appendix (around L31031 onwards).
- Proposed correction: change Success to "Dazed 1 for 1 round" and Failure to "forgets the last minute, Dazed 2 for 10 minutes and Confused for 1 round". Add "**Saving Throw** Will". Give the Fumble's Frightened 2 the spell's duration.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M47 — METAMAGIC RESONANCE
- **Where:** L7142
- Excerpt: "**+2 PP:** the duration increases to 1 minute."
- Problem: the base duration is already "1 minute (S)" (L7132), so this warp does nothing.
- Proposed correction: "the duration increases to 10 minutes (S)".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M48 — MIMIC SPELL
- **Where:** L7160
- Excerpt: "Your Spellcraft check is compared to the Spells DC with the following results:"
- Problem: "Spells DC" is undefined. It could mean the observed spell's casting DC (10 + floor(1.5 × PP)) or its Spell Save DC. The text also never says:
    - whether the mimicked spell is capped by the mimic's own Max PP per cast (Caster Level + 1);
    - whether the mimic needs the spell's tradition.
- Proposed correction: write "against the casting DC of the observed spell (10 + 1.5 × its PP)". Add: "You cannot mimic a spell whose PP exceeds your maximum PP per cast."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M49 — MIMIC SPELL
- **Where:** L7172
- Excerpt: "the spell is still cast, but you immediately suffer the usual overextension consequences."
- Problem: "overextension" is not a rule in the core or in this book. Core has a NEGATIVE PP rule instead: if your PP would drop below 0, you take 5 Soul Drain per PP below 0.
- Core check: `grep -ci overextension rulebook-core-3.7.txt` returns 0. `grep -n "NEGATIVE PP"` returns L6511. In ea.md the only hit is L7172.
- Proposed correction: "…but you take 5 Soul Drain for every PP you fall below 0 (see Negative PP, Core Rulebook)".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M50 — PANIC TRANSPOSITION
- **Where:** L7292/L7298
- Excerpt: "After resolving the triggering attack, you teleport" / "**+4 PP:** you gain resistance against the triggering attack."
- Problem: the trigger is taking damage, and the teleport happens after the attack has resolved. Resistance against that attack therefore arrives too late to apply.
- Proposed correction: "+4 PP: you gain resistance to the damage of the triggering attack (apply before the teleport)". The trigger could also be changed to "you are hit by…" so the reaction fires before damage.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M51 — PLEDGESHROUD
- **Where:** L7382–7394
- Excerpt: "**Range** touch; **Duration** 1 hour"
- Problem: there is no Target line, no save, and no "willing" requirement. Touch-and-silence on an unwilling creature with no save is a missing mechanic.
- Proposed correction: "**Target** 1 willing creature". Or add "**Saving Throw** Will (unwilling: negates on Success or better)" and the SAVE trait.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M52 — PRIMAL SNAP
- **Where:** L7402
- Excerpt: "**SAVE SUMMONS TRANSLOCATION**"
- Problem: these traits appear to have been copied from PLANT BINDING. The spell summons no being, but L10709 defines Summons spells as ones that "always create or bring forth an independent being". As written, it qualifies for Summons feats (L4240, L4520). It also lacks COLD (and AIR or WATER) traits for a cold fog.
- Proposed correction: "**AIR COLD SAVE TRANSLOCATION WATER**". This mirrors core CLOUDKILL / SOLID FOG, which carry the AIR … WATER traits.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M53 — PRISMATIC GUARD
- **Where:** L7438
- Excerpt: "This light grants the targets energy resistance and immunity to being blinded or dazzled."
- Problem: "energy resistance" names no type. Core Resistance is always per damage type, and core's energy types are acid, cold, electricity, fire and sonic.
- Core check: RESISTANCE (around L15587, "When you have Resistance to a specific type of damage"). ENERGY DAMAGE: "The main types of energy damage are acid, cold, electricity, fire, and sonic."
- Proposed correction: "resistance to acid, cold, electricity, fire and sonic damage", or "resistance to one energy type chosen at casting".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M54 — RITE OF ECHOED SHADOWS
- **Where:** L7562–7568
- Excerpt: "**Failure** one Shadow appears for every ritual caster and attack."
- Problem:
    - "Shadow" (a creature) is defined nowhere in this book or the core;
    - the sentence is broken ("…and attack" should be "…and attacks");
    - the ladder lacks Success and Fumble, although Blunder is present;
    - the Blunder's "(PP cost of ritual +4 in level)" is ungrammatical and ambiguous.
- Core check: `grep -n -i "shadow" rulebook-core-3.7.txt` finds only traits, feats and school names, no Shadow creature. Same result in ea.md.
- Proposed correction: "**Success** As written." / "**Failure** One shadow (creature level equal to the ritual's PP ÷ 2) appears for every ritual caster and attacks." / "**Fumble** As failure, but two shadows per caster." / Blunder: "…summoning an entity of level equal to the ritual's PP + 4, which attempts to kill the ritual casters." Then name the creature's stat-block source.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M55 — SPECTRAL AEGIS
- **Where:** L7590
- Excerpt: "The shield grants the target Resistance (all damage)."
- Problem: balance and ambiguity.
    - Resistance to all damage for 1 hour on any creature, or all day for +2 PP, at PP 16 far exceeds core BLINK: PP 8, 1 minute, resistance to all except force.
    - "1 spell cast at the target" doesn't say whether area spells or beneficial spells count.
    - It's unclear whether the resistance ends when the shield vanishes. The text implies it does.
- Core check: rulebook-spells.json BLINK (core L21533): "resistance to all damage (except force)", Duration 1 minute.
- Proposed correction: either cut the duration to 1 minute (10 minutes with warps), or drop the resistance and keep only the spell absorption. Clarify: "the first hostile spell (including area spells) that would affect the target… When the Aegis vanishes, the resistance ends."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M56 — STORM OF UNMAKING
- **Where:** L7654–7668
- Excerpt: "When you initially cast the spell and then at the beginning of each of your turns, roll 1d6"
- Problem: balance. It deals about 65–90 average damage (20d6 = 70, 20d8 = 90) in a 60-ft radius every round for a full minute, with no sustain needed. Core PP 20 storms deal far less: CRACKLING TEMPEST is a single 10d12, and STORM OF VENGEANCE is sustained with 4d8/4d10 per round. Row 5 (20d8 = 90 average) is also well above the other rows (about 65–75).
- Core check: rulebook-spells.json CRACKLING TEMPEST (PP 20, 10d12 electricity) and STORM OF VENGEANCE (PP 20, sustained (1 minute)).
- Proposed correction: "**Duration** Sustained (1 minute)". Halve the table dice (e.g. 10d6 / 5d12 / 15d4 / 8d8 / 10d8 → 9d8 / 6d10) or keep full dice for the first round only. Bring row 5 in line, e.g. 16d8.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M57 — SYMBOL family (DEATH, FEAR, INSANITY, PAIN, WEAKNESS)
- **Where:** L7723–7805
- Excerpt: "When activated, the symbol flashes and each character with line of sight to it must make a Fortitude save."
- Problem: none of the symbols says how often a creature must save (every round? each time it looks?), and none grants immunity after a save. Core WORD spells give 10-minute temporary immunity. A Permanent PP 16 instant-death glyph (Symbol of Death) with repeated saves is very strong next to core WORD OF DEATH (PP 20, single target, immunity). There is also no range limit beyond line of sight.
- Core check: rulebook-spells.json WORD OF DEATH and WORD OF STUNNING ("Once targeted, the target is then temporarily immune for 10 minutes").
- Proposed correction: add to each symbol: "A creature that attempts the save is temporarily immune to that symbol for 24 hours. The symbol affects creatures within 60 feet."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M58 — WORD OF PAIN
- **Where:** L7973–7979
- Excerpt: "**Success** The target is weakened 1" / "**Failure** The target is weakened 2" / "**Fumble** The target is weakened 4"
- Problem: this is a direct template of core WORD OF FATIGUE (PP 10) with fatigued swapped for weakened. Fatigued has core recovery rules (Fatigue Recovery, L30978). Weakened has none, so Success, Failure and Fumble are permanent as written. L7983 also says "effects" for "affects" (copied from core).
- Core check: rulebook-spells.json WORD OF FATIGUE (identical structure). The WEAKENED condition text has no duration or recovery.
- Proposed correction: "Success weakened 1 for 1 minute; Failure weakened 2 for 10 minutes; Fumble weakened 4 for 1 hour". Write "affects".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M59 — ZONE DISRUPTION
- **Where:** L8021
- Excerpt: "**Saving Throw** Will"
- Problem: a Will save is listed, but nothing in the spell calls for one. The effects are unconditional. Either a mechanic is missing (e.g. a Will save to resist the penalties), or the line is a leftover.
- Proposed correction: delete the line. Or add "Creatures in the zone attempt a Will save when they first enter; on a Critical they ignore the penalties", plus the SAVE trait.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

### Minor

#### EA-m84 — Chapter-wide "uncommon" rule
- **Where:** L6004 / L6556 / L6674
- Excerpt: "All of the spells presented here are considered uncommon."
- Problem: Only DRAGON'S BREATH (L6556) and ELEMENTAL STRIKE (L6674) carry the UNCOMMON trait. If the trait is required, every other spell is missing it. If the chapter-wide rule is enough, these two spells repeat it.
- Core check: RS gives UNCOMMON as a printed trait on 5 core spells (I counted first-line trait words).
- Proposed correction: Keep the chapter rule and have the module add an `uncommon` flag to every Chapter 8 spell. Remove or keep the printed UNCOMMON trait on the two spells, but do it the same way for all.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m85 — Spell ordering
- **Where:** L6024 / L6014
- Excerpt: "Spells in this grimoire are divided by tradition and specialist type"
- Problem: L6024 says the spells are "presented here in alphabetical order", and they are (apart from the next item). That contradicts L6014.
- Proposed correction: Change L6014 to say the spells are alphabetical, with tradition and specialist shown on each entry.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m86 — ELDRITCH MANTLE out of order
- **Where:** L6694
- Excerpt: "ELDRITCH MANTLE PP 10"
- Problem: It sits between ELEMENTAL STRIKE and ELEMENTAL CONVERGENCE, which breaks the alphabetical order L6024 promises. It belongs before ELEMENTAL BINDING.
- Proposed correction: Move it to come after EAOG BALLS.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m87 — Intro
- **Where:** L6020
- Excerpt: "To prepare or cast a High Magic spell is to bargain with the ancient skeleton of the world’s magic itself."
- Problem: This paragraph repeats L6010 word for word.
- Proposed correction: Delete L6020.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m88 — Intro
- **Where:** L6026
- Excerpt: "All spells in this sourcebook use the same parameters."
- Problem: The sentence is truncated. It does not say the same parameters as what, and L6027–6028 are blank.
- Proposed correction: "…use the same parameters as those in the TRG Core Rulebook (Chapter 7)."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m89 — Trait spelling
- **Where:** L6062, 6448, 6470, 6772, 7020
- Excerpt: "HIGHMAGIC UTILITY"
- Problem: Stat blocks and the trait glossary (L10677) spell it "HIGHMAGIC", but the chapter prose uses "HIGH MAGIC" / "High Magic" (L6006, L5554). The spelling is consistent among the traits themselves.
- Proposed correction: None needed in print. The module should use one trait key (`highmagic`) with the label "High Magic".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m90 — Binding outcome text
- **Where:** L6078 (and the same text at 6646, 6744, 6788, 6888)
- Excerpt: "**Success** The animal appears but resists, acting freely"
- Problem:
    - The sentence has no full stop.
    - "Duration … broken" is never defined.
    - It is not stated whether a Success creature stays, leaves, or can be bound again.
    - The Fumble result gives "+2 circumstance bonus to all actions". Actions are not checks.
    - There is no Targets line.
    - It never says the minion counts against Control Levels (CORE L20069).
    - It never says whether Partial counts as Success or Failure.
- Core check: `grep -n "Control Level" rulebook-core-3.7.txt` returns L31320 and L20067–20070, so Control Levels exist in core.
- Proposed correction: Success: "…acting freely; it departs when the spell ends (1 minute)." Fumble: "…+2 circumstance bonus to all checks." Add: "A bound minion counts against your Control Levels. Partial is treated as Success."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m91 — Condition spelling
- **Where:** L6938, L6638
- Excerpt: "is Immobilized as bark and blossoms overtake them" / "stunned 3 and immobilized"
- Problem: Core calls the condition IMMOBILISED (CORE L31078; the system key is `immobilised`).
- Proposed correction: Use "immobilised".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m92 — ANIMATE MOUSTACHE
- **Where:** L6118
- Excerpt: "they gain the Distracted condition (see below) for the duration."
- Problem: Distracted is defined only in a sidebar after L10667 (–1 penalty to all actions), about 4,500 lines later, and is not a core condition. "See below" is therefore a weak pointer. The Will save also lists only a Failure result.
- Proposed correction: "(see Distracted, Chapter 8 sidebar)"; add "Critical/Success: unaffected".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m93 — ARCANE FEEDBACK
- **Where:** L6144–6156
- Excerpt: "**Trigger** an enemy within range casts a spell"
- Problem:
    - The damage is "applied as a penalty to their casting check", so the trigger must happen before that check is rolled. "Casts" reads as already resolved.
    - There is no Targets line.
    - "Base Damage 1d8" is printed but the save is not basic, so it is never used.
    - There is no Blunder result.
- Proposed correction: "Trigger an enemy within range begins to Cast a Spell; Targets the triggering creature". Drop the Base Damage line or state "Blunder as Fumble".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m94 — ARCANE POUCH
- **Where:** L6198–6210
- Excerpt: "The pocket acts as a bag of holding"
- Problem:
    - The spell is named "Pouch" but the text says "arcane pocket" three times.
    - Core has no bag of holding item; it is only mentioned inside Dimensional Lock (CORE L22574), so the reference cannot be resolved. The capacity and weight given here are enough to run the spell anyway.
- Core check: `grep -n -i "bag of holding"` returns 1 hit (L22574).
- Proposed correction: Use "arcane pouch" throughout. Replace the reference with "an extradimensional container".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m95 — ARCHWAY OF ANTS
- **Where:** L6228
- Excerpt: "The archway supports only 10× your maximum encumbrance"
- Problem: "Maximum encumbrance" is not a core term; core uses Weight Allowance = 50 + Str × 10 (CORE L11021+). "DB 50" for an object is unusual, because core objects use DR/HP. Unsure whether DR was meant.
- Proposed correction: "10× your Weight Allowance". Confirm whether DB 50 or a DR value is intended.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m96 — ARGENT MARK
- **Where:** L6250–6254
- Excerpt: "**+2 PP:** increase the duration to 1 year."
- Problem: It is unclear whether the duration warps stack or are alternatives (+1 for a month, +2 for a year, +4 for permanent). There is also no save for marking an unwilling creature.
- Proposed correction: "Choose one duration warp." Add "unwilling creatures: Will negates", or "willing creature or object only".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m97 — ARGENT REVERSAL
- **Where:** L6270–6280
- Excerpt: "Make a Spellcraft check against the original caster's Spell Save DC:"
- Problem: There is no Partial result. L6284 says "highest-level spell you can cast", which mixes level and PP language.
- Proposed correction: Add "Partial: as Failure". Use "…of PP no greater than your maximum PP per cast".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m98 — ARMY OF THE GRAVE
- **Where:** L6302 / L6314
- Excerpt: "**Partial** Half rise under control; half are uncontrolled. This result replaces the normal partial result."
- Problem:
    - No duration is given for Partial.
    - The 300-ft area has no stated use.
    - Corpse supply (1 per 2 PP) and the level cap (≤ PP) interact unclearly. Core skeletons and zombies are level 0 (RS ANIMATE DEAD), so only corpses would limit them.
    - "Commanded with a single sustain action" is used on a non-sustained 1-week spell.
- Proposed correction: "Partial: … for 1 day". "Area: corpses must lie within". "Level 0 undead count as level ½". Use "a single command action".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m99 — BRITTLESKIN
- **Where:** L6372–6380
- Excerpt: "takes 1d4 piercing damage (basic Fort)."
- Problem: A basic save is called for, but there is no Saving Throw or Base Damage header. A basic-save Failure needs base damage.
- Proposed correction: Add "**Saving Throw** Basic Fortitude; **Base Damage** 1d4".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m100 — BUBBLE BUFFET
- **Where:** L6396 / L6404–6406
- Excerpt: "**Success** The target is distracted until the end of their next turn."
- Problem: Distracted is defined in the sidebar after L10667 (–1 to all actions), so the condition itself is usable. Residual: "Duration 1 minutes" is a typo, and it does not say whether affected creatures save again each turn or whether later results replace earlier ones.
- Proposed correction: Use the shared Distracted definition and "1 minute". "A creature that fails is not required to save again; a later worse result replaces a better one."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m101 — CALL OF THE ANCESTORS
- **Where:** L6420 / L6430
- Excerpt: "**Tradition** divinity**,** ethereal" and "**Critical**, clear answers"
- Problem: Markup artefacts. Partial "one answer is misleading" contradicts "Answers are truthful". Mental damage uses basic Fort, while EA's mental backlash elsewhere uses basic Will (L5778, L5840). Blunder "a hostile spirit possesses one participant" has no rules behind it.
- Proposed correction: Fix the markup. "Answers are truthful unless stated". Use "(basic Will)". Possession: "as a controlled condition for 1 hour (Will save each hour)", or GM narrative.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m102 — DARK WHISPERS
- **Where:** L6528
- Excerpt: "The voices emerge from your own shadow only when they intend to speak to the shadow"
- Problem: The sentence is garbled. The DARKNESS trait does not fit a communication effect that changes no illumination.
- Proposed correction: "Their replies emerge from your own shadow. You hear only words spoken to the shadow, not other sounds." Remove DARKNESS.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m103 — DECOHERENCE
- **Where:** L6548
- Excerpt: "identify, or suppress it the aura or item."
- Problem: Broken phrase. There is no time limit on when the "next check" must be made.
- Proposed correction: "…identify, or suppress that aura or item before the end of your next turn."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m104 — DRAGON’S BREATH
- **Where:** L6568
- Excerpt: "acid, cold, electricity, fire or poison."
- Problem: Poison is listed as an "element type", but core energy types are acid, cold, electricity, fire and sonic (CORE L15605). Poison is a separate type, and ELEMENTAL STRIKE (L6686) excludes it. No element trait is added.
- Proposed correction: "…or poison (poison is not an energy type; the spell gains the POISON trait)". Add "The spell gains the trait of the chosen damage type".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m105 — DREARLIGHT
- **Where:** L6610–6614
- Excerpt: "**CL 4+:** PP cost of suppression increases by 2 PP."
- Problem: The wording is muddled; it means the darkness threshold rises to PP 4. It does not say whether suppression covers the whole 10-ft light or only overlapping squares. Note that core DARKNESS is PP 4 (RS), so at CL 1–3 this suppresses no core darkness spell.
- Proposed correction: "CL 4+: suppresses magical darkness of PP 4 or lower within the light's radius."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m106 — ELDRITCH MANTLE
- **Where:** L6704 / L6712
- Excerpt: "**+10 PP:** you instead gain immunity."
- Problem: "Immunity" does not name a type; read with L6704 it means physical immunity, and this should be stated. "Strikes you with a melee weapon" leaves out unarmed and natural attacks.
- Proposed correction: "…you instead gain physical immunity." "…with a melee Strike".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m107 — ETERNAL INVOCATION
- **Where:** L6824–6842
- Excerpt: "**Duration** permanent until dispelled" / "cannot be extinguished by natural or magical means."
- Problem:
    - Dispelling is a magical means, so the two lines contradict.
    - L6826 uses "10,000 gold"; use "gp".
    - L6842 "any of an opposed aligned trait" is missing "creature".
    - It does not say what happens if the caster has no aligned trait.
    - "Fade iron" and "radiant gold" are not defined anywhere (1 hit each).
    - There is no ritual outcome ladder, unlike the sibling rituals.
- Proposed correction: "…cannot be extinguished except by dispelling the spell"; "10,000 gp"; "any creature with an opposed aligned trait"; "you must have an aligned trait to cast this ritual".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m108 — FARSIGHT
- **Where:** L6856
- Excerpt: "**INSIGHT RUNE SAVE**"
- Problem: The spell has no save and inscribes no rune, so the RUNE and SAVE traits are wrong. Without the UTILITY trait the system would treat it as a save spell.
- Proposed correction: "**INSIGHT UTILITY**".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m109 — FRESHMARK
- **Where:** L6958
- Excerpt: "**CL 4+:** effect another object or area."
- Problem: Typo for "affect".
- Proposed correction: "affect one additional object or area".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m110 — HARMONIC RIFT
- **Where:** L6990–6994
- Excerpt: "The rift echoes with strange music from the Grey"
- Problem: "The Grey" is not defined in EA or core (grep gives 1 hit, this line). The size of the rift openings is not stated, nor whether they need line of sight. There is no Area or Targets line.
- Proposed correction: Define the Grey or replace it with an existing plane. Add "Area two 5-ft openings within range that you can see".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m111 — INVOKE TRUE NAME
- **Where:** L7010–7012
- Excerpt: "the target is flat-footed against your spells"
- Problem: Core flat-footed is a whole-creature condition (CORE L31061). A version that applies only against your spells needs its own effect in software. The duration ("until the end of the current turn") appears only in the prose, with no Duration line.
- Proposed correction: Add "**Duration** until the end of your turn". "…the target's Dex and dodge bonuses do not apply to DB or Reflex against your spells."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m112 — LEYLINE BURST
- **Where:** L7062
- Excerpt: "**+3 PP:** target all creatures in a 10-ft burst."
- Problem: the warp doesn't say where the burst is centred (on the target, or a point within range). The base text also says "on a failed Reflex save, the target is pushed 10 ft". For a basic save it should name the degree: Failure, or Failure and worse.
- Proposed correction: write "a 10-ft burst centred on the target" and "on a Failure or worse, each target is pushed 10 ft away".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m113 — MANA SURGE
- **Where:** L7072/L7076
- Excerpt: "All spells that the target casts for the duration of the spell are warped by 1 PP for free"
- Problem: there is no Target line ("willing creature" appears only in the prose). It is also unclear whether the free warp raises the save DC. Core L19950 says warping increases the save DC. Core L19811 says cantrips cannot be warped, so cantrips need excluding.
- Core check: `grep -n "warping a spells effect" rulebook-core-3.7.txt` returns L19950. `grep -n "cannot be warped"` returns L19811.
- Proposed correction: add "**Target** 1 willing creature". Add: "The free warp increases the save DC as normal; cantrips cannot benefit."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m114 — METAMAGIC RESONANCE
- **Where:** L7134–7138
- Excerpt: "may apply the chosen feat to one spell they cast per round" … "Each ally may only benefit from this once per round."
- Problem: the once-per-round limit is stated twice. "targets spells" is missing an apostrophe. It is also unstated whether the +3 PP and +6 PP warps stack or replace each other (the +6 PP one should replace).
- Core check: Empower Spell, Extend Spell and Quicken Spell exist (core L7176, L7180, L7304).
- Proposed correction: delete L7136. Write "targets' spells". Mark the +6 PP warp as "(replaces the +3 PP option)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m115 — MIMIC SPELL
- **Where:** L7162
- Excerpt: "You may cast it at any time within the next 1 minute (the spell then ends)."
- Problem: "the spell then ends" is ambiguous. It could mean the imprint ends once used, or the mimic ends after 1 minute.
- Proposed correction: "(the imprint is lost once cast or when the minute expires)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m116 — MIRROR REPRISE
- **Where:** L7198
- Excerpt: "**+2 PP:** the shield also triggers the first time you take damage from a hostile spell."
- Problem: the spell creates duplicates, not a shield. "shield" is a leftover word.
- Proposed correction: "the duplicates also appear the first time…".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m117 — OBSERVE THE WEAVE (but it breaks trait parsing)
- **Where:** L7222
- Excerpt: "**INGIHT SCRYING UTILITY**"
- Problem: typo for INSIGHT. An importer would create a bogus trait and lose the Insight school.
- Proposed correction: "INSIGHT SCRYING UTILITY".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m118 — OBSERVE THE WEAVE
- **Where:** L7238–7244
- Excerpt: "the target must attempt a Will save." … "**Failure** As described, and the duration is 1 hour."
- Problem:
    - there is no Saving Throw header line and no SAVE trait;
    - the ladder has no Fumble;
    - "Critical/Success/Failure" only works if a Fumble is treated as a Failure.
- Core check: 195 of 214 core spells with a Saving Throw carry the SAVE trait (scripted count over rulebook-spells.json).
- Proposed correction: add "**Saving Throw** Will (unwilling target only)" and the SAVE trait. Either add "**Fumble** As failure, and the duration is 1 day" or state that a Fumble counts as a Failure.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m119 — ORB OF DUSK
- **Where:** L7254
- Excerpt: "**Range** 60 feet"
- Problem: no Targets entry. The core orb cantrips print "Targets 1 creature".
- Core check: rulebook-spells.json ORB OF COLD: "Range 60 feet; Targets 1 creature".
- Proposed correction: "**Range** 60 feet; **Targets** 1 creature".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m120 — ORB OF WATER
- **Where:** L7272
- Excerpt: "**Range** 30 feet"
- Problem: no Targets entry, as with Orb of Dusk.
- Proposed correction: "**Range** 30 feet; **Targets** 1 creature".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m121 — PLANAR ANCHOR
- **Where:** L7338
- Excerpt: "any attempt to teleport the target or transport counteracted by the spell."
- Problem: the sentence is broken (missing words). There is no Duration header ("varies"). The traits lack SAVE even though a Will save is listed, and the counteract check level is unstated.
- Proposed correction: "any attempt to teleport the target or transport it to another plane is automatically counteracted." Add "**Duration** varies" and the SAVE trait.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m122 — PLEDGESHROUD
- **Where:** L7394
- Excerpt: "The spell is not detectable Sense Magic or other spells of less than PP 8 This spell"
- Problem: the sentence is broken, with a missing "by" and a missing full stop. Sense Magic is a Power Manipulation skill action (core L6474), not a spell.
- Core check: `grep -n "SENSE MAGIC" rulebook-core-3.7.txt` returns L6474 ("SENSE MAGIC - BROAD CONCENTRATE INSIGHT").
- Proposed correction: "The spell cannot be detected by the Sense Magic action or by spells of less than 8 PP. This spell…".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m123 — PRIMAL SNAP
- **Where:** L7416–7418
- Excerpt: "a failed saving throw imposes a -10 penalty to speed (until healed)." / "You may Sustain this spell"
- Problem:
    - the penalty type (status or circumstance) is not given;
    - "until healed" is a critical-injury persistence term (core L15658), and its meaning for a spell is unclear;
    - Sustain a Spell requires a spell with a sustained duration (core L20016), but the Duration is a plain "1 minute".
- Core check: `grep -n "Until Healed" rulebook-core-3.7.txt` returns L15658. SUSTAIN A SPELL requirements are at L20016.
- Proposed correction: "–10-foot status penalty to Speeds until the creature regains any HP". Change Duration to "Sustained (1 minute)", or say "you may spend 1 AP to move the fog".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m124 — RECKONING GLANCE
- **Where:** L7466
- Excerpt: "**Area** 20-foot emanation;"
- Problem: a stray trailing semicolon (probably a missing Target field).
- Proposed correction: remove the semicolon.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m125 — RIPPLING GAZE
- **Where:** L7490–7492
- Excerpt: "You touch the surface of a body of water" / "You may sustain the spell to shift your viewpoint"
- Problem: the need to touch water is not listed as a Requirement. Sustain also requires a sustained duration (core L20016), but the Duration is a plain "1 hour".
- Proposed correction: add "**Requirements** you are touching a body of water". Replace the sustain wording with "you may spend 1 AP (concentrate) to shift your viewpoint".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m126 — RITE OF BINDING OATH
- **Where:** L7532
- Excerpt: "**Partial** Only half the participants are bound (GM chooses who)."
- Problem: no duration is given for Partial (presumably 1 month, as Success).
- Proposed correction: "Only half the participants are bound (GM chooses who), for 1 month."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m127 — Tradition lines (formatting)
- **Where:** L7516, L7849, L7909
- Excerpt: "**Tradition** divinity**,** ethereal"
- Problem: a bold comma artefact from the docx. A text-based importer may split the field wrongly.
- Proposed correction: remove the bold from the comma.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m128 — SPIRIT ARROW
- **Where:** L7620–7622
- Excerpt: "become Frightened with a value equal to half the amount they failed the save by."
- Problem:
    - rounding is not stated;
    - there is no Saving Throw header and no SAVE trait;
    - who picks the manoeuvre is unclear;
    - it's unclear whether the 6d6 piercing replaces or adds to the weapon's own damage.
- Proposed correction: "(round down, minimum 1)". Add "**Saving Throw** Will". Write "the attacker chooses Feint, Grapple…" and "6d6 piercing damage in place of the weapon's normal damage" (or "in addition to").
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m129 — STORM OF UNMAKING
- **Where:** L7658
- Excerpt: "You call down a chaotic storm of raw essence in."
- Problem: the sentence is truncated (a stray "in"). L7669 "storm appears above you" is also missing "the".
- Proposed correction: "…raw essence in the area." / "the storm appears above you".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m130 — SUN’S BENEDICTION
- **Where:** L7685
- Excerpt: "are cured of one minor condition (dazed, fatigued, sickened, or weakened) which is reduced by 1."
- Problem: "cured" contradicts "reduced by 1". The +4 PP warp (L7701) "increase… the amount of condition by 1" is also unclear. Partial doesn't say whether the condition reduction still applies.
- Proposed correction: "reduce one of the following conditions by 1: dazed, fatigued, sickened or weakened". Warp: "+1d8+1 healing and reduce the condition by 1 more". Partial: "Half healing and condition reduction; no blessing."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m131 — SYMBOL family
- **Where:** L7723/L7747/L7771/L7787/L7811
- Excerpt: "the GM determines that they looks in its direction" / "the GM determines he looks in its direction"
- Problem: grammar ("they looks"; gendered "he"). The ladders are also inconsistent across the family:
    - Death and Pain: Success/Failure/Fumble;
    - Fear: Success/Partial/Failure/Fumble;
    - Weakness: Critical/Success/Partial/Failure/Fumble.
    It is unclear what a Partial does on Death or Pain.
- Proposed correction: "the GM determines that it looks in its direction". Give each symbol the same ladder, with Partial stated explicitly (e.g. Death: "Partial: serious essence critical"; Pain: "Partial: injured 1 for 1 hour").
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m132 — SYMBOL OF DEATH
- **Where:** L7727/L7731
- Excerpt: "After claiming one or more lives, the symbol fades and the spell ends."
- Problem: a Failure ("deadly essence critical") may not kill. It's unclear whether a non-lethal Failure counts as claiming a life. "Permanent" Duration also conflicts with the glow-ends clause (L7733).
- Core check: ESSENCE CRITICAL HIT TABLE (core L17746). Deadly severity is rolled with advantage (L16070).
- Proposed correction: "After any creature dies from the symbol, it fades…". Change Duration to "Permanent (until triggered)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m133 — SYMBOL OF FEAR
- **Where:** L7753/L7755
- Excerpt: "The target is frightened 4 and fleeing or 1 round."
- Problem: typo, "or" for "for", on both lines.
- Proposed correction: "fleeing for 1 round".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m134 — SYMBOL OF INSANITY
- **Where:** L7771
- Excerpt: "each character with line of sight is targeted with an Insanity spell."
- Problem: core INSANITY is PP 4. It's unclear whether the save DC uses PP 4 or the symbol's PP 16. The header's "Duration varies; Saving Throw Will" relies on the Insanity spell.
- Core check: rulebook-spells.json INSANITY (PP 4, Will).
- Proposed correction: "…an Insanity spell using this symbol's Spell Save DC".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m135 — SYMBOL OF PAIN / SYMBOL OF WEAKNESS
- **Where:** L7791–7795, L7823
- Excerpt: "**Failure** The creature is injured 2 for 1 hour." … "These effects last for 1 hour after the creature moves farther than 60 feet from the symbol"
- Problem: there are two contradictory duration rules (1 hour from failure, versus 1 hour after leaving 60 ft). Weakness gives no duration in its outcomes at all.
- Core check: REMOVE CURSE exists in rulebook-spells.json.
- Proposed correction: delete "for 1 hour" from Pain's outcomes. Keep: "The condition persists while within 60 feet of the symbol and for 1 hour after leaving; only Remove Curse ends it sooner."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m136 — TRAVELLER’S CHARM
- **Where:** L7839
- Excerpt: "the target can travel at twice their normal speed"
- Problem: the target is "one mundane, wearable item" (L7835), but the benefit is written as if the target were a creature.
- Proposed correction: "the creature wearing the item can travel…".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m137 — VEILFRACTURE
- **Where:** L7883
- Excerpt: "caster and 1d4 creatures nearby are dragged partially into the chosen plane."
- Problem: "dragged partially" has no mechanical effect (no condition, damage or escape check). The spell also has no Target/Area entry, and the portal's function (what can pass, and in which direction) is unstated.
- Proposed correction: "…are pulled into the plane (Reflex save vs your Spell Save DC to resist; Fumble: lost there)". Add "**Area** portal 10 ft wide per 2 CL; two-way while sustained".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m138 — VEIL SEVERING
- **Where:** L7919
- Excerpt: "a known Luminex within 500 miles"
- Problem: "Luminex" appears only as lore (L10291, L10317) and has no definition anywhere in the book or the core.
- Core check: `grep -ci luminex rulebook-core-3.7.txt` returns 0.
- Proposed correction: add a one-line gloss, e.g. "(a natural rift where the Veil is thin)", or point to the lore section that defines it.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m139 — WALL OF SAND
- **Where:** L7951
- Excerpt: "The wall blocks line of sight but can be passed through by creatures, though doing so costs double movement and obscures vision. The wall provides Concealment"
- Problem: "blocks line of sight" (no targeting through it) contradicts "provides Concealment for those behind it" (targetable with a flat check). "obscures vision" has no mechanical effect.
- Core check: CONCEALED condition (DC 17 flat check) vs line of sight (core L241).
- Proposed correction: either "blocks line of sight (creatures behind it cannot be targeted)" or "creatures behind it are concealed". Add: "a creature inside the wall is blinded until it exits".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m140 — ZONE DISRUPTION
- **Where:** L8031
- Excerpt: "must roll to cast spells using their innate modifiers against the spells normal DC."
- Problem: "innate modifiers" is undefined. Core innate spells need no casting check and only have an innate save DC (DC 10 + ability + level, core L20052). It's unclear whether Eldritch Arts warlocks (a High Magic class) cast "innate" magic.
- Core check: `grep -n "innate spell" rulebook-core-3.7.txt` returns L20052. ea.md L2796 says innate spells "require no casting checks".
- Proposed correction: "Innate spells (including monster abilities) require a Spellcraft check using the innate ability modifier + level against the spell's normal casting DC." State explicitly whether warlocks count.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

### Recommendations

#### EA-R8 — ACIDIC BURST (balance)
- **Where:** L6036–6042
- Excerpt: "**Area** 5-foot radius"
- Problem: At PP 4 this deals 2d6 in a 5-ft radius with no warps. Core BURNING HANDS deals 2d6 in a 15-ft cone for PP 2 (RS). The spell also does not say whether the caster is inside the area.
- Proposed correction: Lower it to PP 2, or raise it to 3d6 and add a warp "+2 PP: +1d6 / +5 ft radius". State: "creatures other than you".
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R9 — ALTER CORPSE
- **Where:** L6066–6076
- Excerpt: "providing it with sufficient flesh that it can be animated as a zombie rather than a skeleton."
- Problem: Core ANIMATE DEAD already lets the caster choose "Skeleton or Zombie (casters choice)" from any medium or small corpse (RS), so the Restore mode does nothing against core animation. There is also no Duration line (presumably instantaneous).
- Proposed correction: Say that zombies normally need a fleshed corpse, or give Restore a mechanical benefit, for example "the zombie gains +1 level when animated".
  Checked and found no defect: AIR BUBBLE (L6044), BOUNCY BODY (L6352), FELTWARP (L6870), GLYPH OF RETRIBUTION (L6960), ELEMENTAL/ENTITY/ETERNAL/FEY BINDING (beyond the family issues above).
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R10 — MESSAGE RUNE
- **Where:** L7110
- Excerpt: "**INSIGHT LINGUISTIC UTILITY**"
- Problem: the spell inscribes a rune but has no RUNE trait. RISERUNE (L7498) and the SYMBOL spells do have it. Rune-mage effects that key off the trait (core RUNE trait) would miss this spell.
- Proposed correction: add the RUNE trait.
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R11 — NECROTIC WHISPER
- **Where:** L7204
- Excerpt: "**ATTACK CANTRIP SOUL**"
- Problem: the effect is a whisper that deals secondary sonic damage, yet it has no AUDITORY trait, so a deafened target is not immune. ORB OF WATER, by contrast, carries its secondary type's trait (COLD).
- Proposed correction: optionally add AUDITORY (or SONIC).
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R12 — PHASE DOOR
- **Where:** L7324
- Excerpt: "**+1 PP:** phase through any material."
- Problem: 1 PP removes the main limit, wood/plaster/stone only (core PASSWALL treats even thin metal as a hard stop). Relative cost is also odd: core PASSWALL is PP 10 with a 1 hour duration, while this is PP 14 for 1 minute.
- Core check: rulebook-spells.json PASSWALL (PP 10, 1 hour).
- Proposed correction: consider +4 PP for "any material except lead". Optionally lengthen the duration or lower the PP.
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R13 — PLANT / UNDEAD / WYRM BINDING
- **Where:** L7364 (also L7853, L7993)
- Excerpt: "**Duration** Until dismissed or broken"
- Problem: "broken" is undefined for these bindings. Core Control Levels (around L20090) let an over-limit creature make a DC 20 Will save each round to break free. The spells don't mention Control Levels, which the software needs for minion tracking. This matches the earlier Bindings (L6078, L6646, L6888), so it is a book-wide pattern.
- Core check: `grep -n "control levels" rulebook-core-3.7.txt`, around L20093.
- Proposed correction: add one sentence to the Summons trait (L10709) or to each binding: "Bound creatures count against your control levels; the binding is broken if you exceed them (Core Rulebook)."
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R14 — PRISMATIC GUARD
- **Where:** L7454–7456
- Excerpt: "**+1 PP:** increase the duration to 1 hour." / "**+2 PP:** increase the duration to until next daily preparation."
- Problem: an all-day party-wide energy resistance aura with a blinding retaliation, for 20 PP, is cheap compared with its 18 PP base.
- Proposed correction: consider +2 PP for 1 hour and +4 PP until daily preparation.
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R15 — ZONE DISRUPTION
- **Where:** L8037
- Excerpt: "must roll their fumble results at disadvantage."
- Problem: on percentile fumble tables, higher is worse (ea.md L5623). "Disadvantage" should be defined as "take the higher roll".
- Proposed correction: "…roll the fumble table twice and use the higher result".
- **Status:** Not yet implemented. Balance note only; built as printed.

## Part C — Specialist spells and armour & shield runes (L8039–9194)

### Critical

#### EA-C6 — CATALYST
- **Where:** L8929–8937
- Excerpt: "You can imbed an amount of catalysts based upon the runes power level"
- Problem:
    - The docx tier table is a copy of Binding Sigils: "CATALYST I Level 4 … The penalty is -2", and so on.
    - Catalyst IV repeats Catalyst III's "Level 12; Price 16,000 gp … -6".
    - No number of catalysts is given.
    - Nothing says how an embedded catalyst is used. EA catalysts are consumed when you declare a spell (L5220–5236). Is the shield the source? Does it save an action?
    - The sentence lacks a final full stop.
- Proposed correction: set tiers to I L4 = 1 catalyst, II L8 = 2, III L12 = 3, IV L16 = 4. Add "You may draw an embedded catalyst as part of casting without an Interact action".
- **Status:** Not built. Awaiting your ruling; the feature ships only once the text can be resolved.

#### EA-C7 — LEYWALK (feat) — Leywalker spell missing
- **Where:** L3718
- Excerpt: "You gain the Leywalker specialist spell."
- Problem: there is no Leywalker spell in Eldritch Arts (body or sidebars), in the core rulebook or in the core spell list. The feat grants nothing as written.
- Core check: `grep -c -i leywalker` = 0 in core.txt and rulebook-spells.json; the only hit in ea-full.md is this line.
- Proposed correction: print the Leywalker specialist spell (presumably travel along a ley line), or name an existing spell.
  | Grant (line) | Spell | Entry in range? |
  |---|---|---|
  | Arcanum birthright (L865) | Disrupt Magic | Yes (L8253) |
  | Dragon birthright (L908); Blood of the Wyrm (L2930); Draconic Claws feat (L3404) | Draconic Infusion | Yes (L8233) |
  | Eternity birthright (L953); Eternal Vigil (L2994) | Touch of Healing | Yes (L8729) |
  | Rune birthright (L994); Runebreaker (L3120); feats L4002, L4012 | Storing Rune | Yes (L8635) |
  | Storm birthright (L1039); Stormcaller (L3190 as "Stormbolt") | Storm Bolt | Yes (L8661), but the name is inconsistent |
  | Umbral birthright (L1080); Shade Master (L3136) | Shadow Shift | Yes (L8551) |
  | Umbral Affinity (L1076) | Darkness "as a Specialist Spell" | Not in range: a core spell (rulebook-spells.json DARKNESS) used as a specialist. OK |
  | Shade Master (L3134) | Dark Whispers "as a specialist spell" | Not in range: a Grimoire spell (L6516). OK |
  | Wild birthright (L1125) | "random PP 2 specialist spell" | **No PP 2 specialist exists anywhere** (Major, above) |
  | Arcane Duellist path (L1322) | Shooting Star | Yes (L8581) |
  | Divine Arm path (L1346) | Shielding Strike | Yes (L8569) |
  | Ethereal Strider path (L1372) | Dimensional Assault | Yes (L8217) |
  | Verdant Warden path (L1394) | Thunderous Strike | Yes (L8715) |
  | Ferromancer (L3022) | Shard Cloud | Yes (L8675) |
  | **Leywalk feat (L3718)** | **Leywalker** | **MISSING.** No entry in ea.md, core.txt or rulebook-spells.json (`grep -c -i leywalker` = 0 in the core). **Critical:** the feat grants nothing. |
  | Hex Weaver (L3052); Witch (L1736); Warlock (L1464) | any Hex | 21 HEX-trait entries in range |
  | Birthrager (L2914); High Mage (L3064) | the chosen birthright's spell | Covered by the six birthright spells. Wild has none. |
  Range entries that no class feature, birthright, path, archetype or feat names, and that are reachable only through the Specialist Spell feat or a generic hex pick:
- **Ancient Aegis, Evershade Veil, Ley Bolt** ("Birthright Any").
- **Life Boost** (no owner trait at all).
- **Spinning Weapon** (SPELLBLADE, but no path grants it).
- **Arcane Singularity, Ley Sever, Paradox Weave** (ARCHMAGE; Archmage gets specialists only through the feat, L703).
- **Hemocovenant, Siphon Vitae** (BLOODMAGE trait; the Bloodmage archetype at L2938 never mentions them, so in practice they are reachable only as Hexes).
  The 19 other HEX entries are reachable through a generic hex pick.
- **Status:** Not built. Awaiting your ruling; the feature ships only once the text can be resolved.

### Major

#### EA-M60 — Ancient Aegis, Evershade Veil, Ley Bolt
- **Where:** L8065 / L8267 / L8351
- Excerpt: "**Birthright** Any"
- Problem: No birthright (L855–1127) or other feature names these three spells, so it is unclear who can learn them. Possible readings are: any Sorcerer through the Specialist Spell feat, any Sorcerer for free, or any birthright's pick list.
- Proposed correction: state "Sorcerer (any birthright), via the Specialist Spell feat" and add a SORCERER trait.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M61 — Wild birthright
- **Where:** L1125 (cross-check)
- Excerpt: "you gain a random PP 2, specialist spell (from any class) each day"
- Problem: No PP 2 specialist spell exists. This book's specialists are PP 1/3/5/7, and the core has 69 at PP 1, 36 at PP 7 and 1 at PP 13. The random pool is empty.
- Core check: `sed -n '27294,31000p' core.txt | grep -oE "^[A-Z’' -]+ PP [0-9]+" | awk '{print $NF}' | sort | uniq -c`.
- Proposed correction: change it to "a random PP 1 specialist spell", or define the pool (e.g. PP ≤ 3).
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M62 — ARMOURING (balance)
- **Where:** L8107
- Excerpt: "**+1 PP:** the bonus increases by +1 (max +10)"
- Problem: PP 3 gives +2 natural DR, and each further PP adds +1 up to +10. Core Barkskin is PP 4 for +1 DR, max +5, at +2 PP per step.
- Core check: `rulebook-spells.json["BARKSKIN"]`.
- Proposed correction: change the warp to "+2 PP … (max +5)", or state that the DR does not stack with worn armour DR. Unsure: whether natural-armour DR stacks with worn armour in core. Core L11329 treats them separately.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M63 — CACKLE (interaction)
- **Where:** L8171
- Excerpt: "**Cast** Free (verbal) … You Sustain a Spell."
- Problem: No frequency is stated. Each Cackle is a free sustain, and Malicious Shadow (L8425) makes a Strike "each time you sustain it", so 1 PP per Strike costs no AP. MAP is the only limit.
- Core check: core.txt L8640 has a similar feat ("By expending 1 PP … Sustain a Spell").
- Proposed correction: add "once per turn".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M64 — CLOAK OF THE DECEIVER
- **Where:** L8183
- Excerpt: "If you have a specific individual stored, you may use the hex to impersonate them."
- Problem: "Stored" individual is undefined. No feat or hex stores one; I grepped ea.md for "stored" in L1396–1771 and L8039–8300. Also, the duration is plain "sustained" with no cap, while every other sustained spell here gives a cap.
- Proposed correction: define it (e.g. "an individual you have studied for 1 minute"), or delete the sentence. Make the duration "sustained (up to 10 minutes)".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M65 — DELAY AFFLICTION
- **Where:** L8209
- Excerpt: "**+2 PP:** increase duration to 10 minutes."
- Problem: The base duration is already 10 minutes (L8203), so this warp does nothing. The +4 PP warp, 1 hour, follows it.
- Proposed correction: set the base duration to 1 minute.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M66 — DRACONIC INFUSION
- **Where:** L8243
- Excerpt: "your Claw attacks deal an extra 1d4 secondary elemental damage"
- Problem: Three passages contradict each other:
    - Blood-of-the-Wyrm's Draconic Claws feat (L3404) says "When using Draconic Infusion, your claws also deal 1d6 secondary damage".
    - Blood of the Wyrm (L2930) says Draconic Infusion "inflicts an additional die of damage".
    - The birthright claws (L902) are 1d6 *piercing*, while the feat claws (L3404) are 1d6 *slashing*.
- The +4 PP warp, "an appropriate weapon trait", is GM-dependent.
- Proposed correction: make 1d4 the base, have Blood of the Wyrm add +1 die, and make the L3404 text "your Draconic Infusion damage applies". Pick one claw damage type.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M67 — DISRUPT MAGIC
- **Where:** L8255–8265
- Excerpt: "**SAVE WARDING**" / "you expend an amount of PP when using this spell as determined by the Dispel check"
- Problem:
    - The SAVE trait is printed, but no saving throw exists.
    - Core Dispel has you choose the PP up front and the result decides whether half or all of it is spent. The spell does not say how that combines with its own PP 1 cost.
    - Typo: "You Spellcraft check".
    - The name collides with the general feat DISRUPT MAGIC (L4398) and the Anti-Mage background bonus feat (L525). The Dispel Power prerequisite "Disrupt Magic" (L4384) is therefore ambiguous.
- Core check: `grep -n -A8 "^DISPEL CONCENTRATE" core.txt` → L6452–6461.
- Proposed correction: remove SAVE. State "choose PP up to your specialist maximum; the Dispel result decides how much is spent (minimum 1)". Rename the spell (e.g. "Disrupting Word") or the feat.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M68 — HEMOCOVENANT
- **Where:** L8315–8323
- Excerpt: "**Duration** sustained (1 minute)" / "You transfer 1d8 + Charisma modifier HP."
- Problem:
    - The effect is instantaneous, and nothing says what sustaining does.
    - The 2 AP version does not say the caster loses the HP, or whether the 1 HP floor applies.
    - The modifier is hard-coded to Charisma, though the BLOODMAGE archetype is open to any class.
    - The 1 AP option has no base healing die listed for the warp scaling.
- Proposed correction: either remove the duration, or state "each Sustain repeats the transfer". Add "you lose the same amount (not below 1 HP)". Use "your magical ability modifier".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M69 — LEY BOLT
- **Where:** L8363
- Excerpt: "striking a target within range and dealing force damage."
- Problem: The damage amount is missing. Base Damage is 1d6, but no total is given; core Force Bolt prints "inflicts 2d6 force damage". The +4 PP stun warp lists only Partial, Failure and Fumble, and uses "stun" for stunned. The ricochet warp's "-2 per additional target" implies it can be stacked, but no maximum is given.
- Core check: `rulebook-spells.json["FORCE BOLT"]`.
- Proposed correction: change it to "dealing 2d6 force damage". Add "(Success: no effect)" and "max 3 ricochets".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M70 — LIFE BOOST
- **Where:** L8399
- Excerpt: "**HEALING UTILITY**"
- Problem: There is no owner trait, and no class, birthright, path or feat grants it. It is reachable only through the Specialist Spell feat, and only if the GM agrees it is "applicable" (L703).
- Proposed correction: add an owner (e.g. WITCH, or a Sorcerer Eternity pick) and its trait.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M71 — MISSED CHANCE
- **Where:** L8449
- Excerpt: "this hex cannot be used to force a reroll if the check was an open ended roll."
- Problem: In core, every saving throw is an open-ended roll, and most checks are too. Taken literally, the hex can never be used on a saving throw, which contradicts "attack check, saving throw or skill check" (L8445). Second Chance (L8547) has no such clause, so the pair is inconsistent. Typo: "any other affect".
- Core check: core.txt L15802 "When a Saving Throw is called for, you must make an Open-Ended Roll"; L148.
- Proposed correction: change it to "if the d20 exploded (an open-ended 20 or 1 was rolled)". Unsure: author intent. Graham to confirm.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M72 — PARADOX WEAVE (balance and missing mechanic)
- **Where:** L8461–8467
- Excerpt: "The target is Quickened on their next turn. Each round that you sustain the spell; the target receives the benefit again."
- Problem: Core quickened requires the granting effect to name the actions the extra AP may be used for, and this spell names none. At PP 1 it gives up to a minute of quickened, against Haste at PP 6 (Strike/Stride only). The end-save ladder lacks Critical and Partial.
- Core check: core.txt L31093; `rulebook-spells.json["HASTE"]` pp 6.
- Proposed correction: change it to "Quickened (Strike, Stride or Step only)". Raise PP to 5–7, or make it "next turn only; Sustain does not renew". Add "Critical/Success: no ill effect".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M73 — SHIELDING STRIKE
- **Where:** L8575
- Excerpt: "you are granted a +2 status bonus to DB."
- Problem: No duration is given for the DB bonus. It also has no weapon Requirement, which the other Spellblade strikes have.
- Proposed correction: add "until the start of your next turn" and "Requirements You're wielding a melee weapon".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M74 — SIPHON VITAE
- **Where:** L8609
- Excerpt: "The target must make a basic Fortitude save. On a failure, they take 1d8 + Charisma modifier essence damage"
- Problem: A basic save, by core definition, gives half damage on Success and full on Partial. "On a failure" contradicts that. The 2 AP option lacks the SAVE trait. The +3 PP warp, "damage inflicted become Soul Drain", does not say how damage converts to Soul Drain severity, or whether you still heal. Charisma is hard-coded.
- Core check: core.txt L270–300 (BASIC SAVING THROW: Critical unaffected, Success half, Partial full, Failure full plus extra).
- Proposed correction: change it to "basic Fortitude save; you heal the damage dealt". Add "gains the Save trait". Define the conversion, e.g. "inflicts Soul Drain equal to the damage rolled; you do not heal".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M75 — STORM BOLT
- **Where:** L8663–8673
- Excerpt: "In an arctic area you may release a bolt of cold, underground acid or fire and in a storm electricity (GM discretion)."
- Problem: No damage amount is given (Base Damage is 1d12, with no total). No default type is given for ordinary locations. The name is inconsistent: Stormcaller (L3190, L3192) calls it "Stormbolt". The spell has no warps of its own.
- Proposed correction: change it to "dealing 2d12 damage; default electricity". Standardise on "Storm Bolt".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M76 — SHARD CLOUD (balance)
- **Where:** L8679–8699
- Excerpt: "**+1 PP:** increase the damage by 1d6."
- Problem: The damage warp has no maximum and costs 1 PP per die, against 2 PP per die with a 4–5d6 cap elsewhere (Spinning Weapon, Thunderous Strike). The area is a persistent aura lasting a minute, and specialist max PP = character level, so a level 20 caster gets 20d6. Also: the component "(metal)" is non-standard (it relies on Ferromancer, L3022), and there is no FERROMANCER trait.
- Proposed correction: change it to "+2 PP: +1d6 (max 5d6)" and add a FERROMANCER trait.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M77 — NULLFLOW (balance)
- **Where:** L9003
- Excerpt: "The spell's effects are suppressed against you for one minute although other targets are still affected normally."
- Problem: The rune automatically negates any targeting spell, with no counteract check, at Level 8 once per day (docx). That includes PP 20 High Magic. It is also unclear what happens after the minute (does a lasting effect resume?).
- Proposed correction: change it to "Make a counteract check (rune level as counteract level) …; on a success the effect is suppressed against you for 1 minute, then resumes for any remaining duration".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M78 — VEIL (and Shadeskin)
- **Where:** L9073–9077 / L9173–9175
- Excerpt: "After the attack is resolved you may become incorporeal. … you may only make move actions and actions with the defend trait."
- Problem:
    - "Incorporeal" is not a core condition and has no definition here (no damage immunity, resistances or ability to pass through walls).
    - No duration or ending is given.
    - There is no "defend" trait; core has DEFENCE.
    - "Wielder" should read wearer.
- Core check: the core condition list has no incorporeal entry; `grep -n -E "^DEFENCE" core.txt` → L31263.
- Proposed correction: define it, e.g. "until the end of your next turn you gain resistance to all non-force damage and the concealed condition, may pass through solid objects…". Change "defend" to "defence" and "wielder" to "wearer".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M79 — SPELLGUARD
- **Where:** L9111–9115
- Excerpt: "Resonant Defiance I" … "The casters Spellcraft DC to cast the spell is increased by 1."
- Problem: The docx gives Resonant Defiance I as "The Spellcraft DC is increased by 2". The item block says +1, a contradiction. Also, "The armour grants the wearer" should say shield. The flavour sentence (L9105) has no main verb.
- Proposed correction: change it to "increased by 2" and "The shield grants…".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

### Minor

#### EA-m141 — SPECIALIST SPELLS rule
- **Where:** L8043
- Excerpt: "Each of the spells will have at least one trait relating to a race, class or archetype."
- Problem: 11 entries carry no race, class or archetype trait. They are Ancient Aegis, Draconic Infusion, Disrupt Magic, Evershade Veil, Ley Bolt, Life Boost, Shadow Shift, Storing Rune, Storm Bolt, Shard Cloud and Touch of Healing. Core specialists carry class traits (e.g. "FORCE BOLT … WIZARD", "ANIMAL HEALING … DRUID").
- Core check: `grep -n "^SPECIALIST SPELLS" core.txt` → L27294, which uses the same intro. The owner traits used here (HEX, ARCHMAGE, SPELLBLADE, BLOODMAGE) and FORTUNE are not core traits. A Python scan of all trait lines in rulebook-spells.json found FORTUNE, HEX, ARCHMAGE, SPELLBLADE and BLOODMAGE = absent.
- Proposed correction: add owner traits (e.g. SORCERER/ARCANUM, FERROMANCER), or drop the sentence. The module must register HEX, ARCHMAGE, SPELLBLADE, BLOODMAGE and FORTUNE as traits.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m142 — ordering
- **Where:** L8045–8766
- Excerpt: "DRACONIC INFUSION PP 1" (L8233) precedes "DISRUPT MAGIC PP 1" (L8253); "STORM BOLT" (L8661) precedes "SHARD CLOUD" (L8675)
- Problem: These entries break alphabetical order. The rune list has the same problem: CATALYST (L8929) sits between BINDING SIGILS and BOUND CIRCLE.
- Proposed correction: re-sort.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m143 — Prehensile Tail, Purity Hex, Second Chance, Weakened Element
- **Where:** L8495 / L8523 / L8541 / L8753
- Excerpt: "**PP Cost** 3"
- Problem: These four entries have a stray "PP Cost" line that repeats the PP in the heading. No other spell has one.
- Proposed correction: delete the line.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m144 — ABSORBENT BEARD
- **Where:** L8051
- Excerpt: "**Duration** until next daily preparation" / "store it for up to 24 hrs"
- Problem:
    - The two stated durations differ.
    - The +2 PP warp allows up to 3 stored liquids, but "Drinking any liquid … immediately ends the effect" would void the others.
    - The reaction has no trigger.
    - The paragraph is split mid-sentence at L8053/8055 and L8057/8059.
- Proposed correction:
    - Make the duration "24 hours or until next daily preparation".
    - Change the ending to "drinking the last stored liquid ends the effect".
    - Make the drink "a reaction (trigger: start of your turn or any time you could act)", or a 1 AP Interact.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m145 — ARCANE SINGULARITY
- **Where:** L8085
- Excerpt: "must make a basic Reflex to avoid 2d8 damage"
- Problem: No damage type is printed (the FORCE trait implies force). The "drags everything inward" flavour has no pull mechanic.
- Proposed correction: change the wording to "2d8 force damage".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m146 — BANEFUL MAGIC
- **Where:** L8119
- Excerpt: "**Range** touch; **Area** 20-foot-radius"
- Problem: The area's centre is not stated. It is probably the touched point or object, and it is unclear whether the area moves.
- Proposed correction: change it to "Area 20-foot radius centred on the touched point (stationary)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m147 — BANEFUL WEAPON
- **Where:** L8143
- Excerpt: "You grant the bane special ability to one weapon. The type of creature targeted"
- Problem: The core Bane rune picks "a specific race of creatures", not a creature type.
- Core check: `grep -n -A5 "^BANE$" core.txt` → L29706, "Level 4 … additional 2d4 damage when attacking c…".
- Proposed correction: change it to "grant the effect of the Bane weapon rune (core)" and keep the race wording.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m148 — DIMENSIONAL ASSAULT
- **Where:** L8219
- Excerpt: "**SPELLBLADE TELEPORTATION TRANSOCATION UTILITY**"
- Problem: The TRANSOCATION spelling breaks school matching (Translocation). "until after you attack has been resolved" should read "your attack". The core TELEPORTATION trait allows one teleportation action per turn, so this spell competes with the Ethereal Strider's Dimensional Step (L1366) in the same turn.
- Core check: core.txt L31375.
- Proposed correction: change it to TRANSLOCATION and fix the typo. Optionally, note the one-per-turn limit.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m149 — EVERSHADE VEIL
- **Where:** L8287
- Excerpt: "**+4 PP:** the veil gains a shattering aura; each creature within 10 feet must succeed on a Will save or be dazzled"
- Problem: The warp does not say when the save happens (on cast, each turn or on entry). "Successfully strikes" does not say whether ranged attacks count.
- Proposed correction: change it to "when the spell is cast and when you Sustain it".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m150 — FAMILIAR SENSES
- **Where:** L8297–8299
- Excerpt: "**Duration** 10 minutes (sustained)" / "use an additional sense of the targets"
- Problem: It is unclear whether this is "sustained up to 10 minutes" or a 10-minute duration that needs a sustain action to use the sense. "of the targets" is garbled. Warlocks can take hexes (L1464) but have no familiar, and the hex states no familiar prerequisite. Phase Familiar (L8473) has the same gap.
- Proposed correction: change it to "Sustained (up to 10 minutes)" and add "Requirement: you have a familiar".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m151 — LEY SEVER
- **Where:** L8385–8391
- Excerpt: "Your Spellcraft result is used as a Counteract DC"
- Problem: In core, counteract is a check against the effect's DC, modified ±2 per PP difference. Here the spellcraft result is called a DC, and the spell does not say which PP the difference uses. The ladder has Critical, Success and Failure but no Partial. Nothing says who picks the halved variable.
- Core check: `grep -n -A4 "^COUNTERACT $" core.txt` → L19545–19548.
- Proposed correction: change it to "Make a counteract check using your Spellcraft result (PP spent = counteract level)". Add "the GM chooses the variable".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m152 — MALICIOUS SHADOW
- **Where:** L8417
- Excerpt: "**HEX UTILITY**" / "The shadow's Strikes are melee spell attacks."
- Problem: The spell makes spell attacks but lacks the ATTACK trait, which the specialist attack-bonus formula depends on. See also Cackle.
- Proposed correction: add ATTACK.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m153 — PURITY HEX
- **Where:** L8529
- Excerpt: "You create a bubble of still air around which weakens or negates all poison effects."
- Problem: The sentence is broken ("around which"). The centre and whether the bubble moves are not stated. Because immunity applies to poisons with a PP or level ≤ "this hex", the duration warp (+2 PP) also raises the immunity threshold. That may not be intended.
- Proposed correction: change it to "around you (moves with you)". Base the threshold on "the PP spent, excluding duration warps", or on your level.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m154 — STORING RUNE
- **Where:** L8645–8653
- Excerpt: "**+1 PP:** increase the duration to 1 hour. **+1 PP:** increase the duration to until next daily preparation."
- Problem: Both duration warps cost the same, and it is unclear whether they must be stacked (+2 PP for "until daily prep") or not.
- Proposed correction: make the second warp "+2 PP", or state that the warps are cumulative.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m155 — THUNDEROUS STRIKE
- **Where:** L8723
- Excerpt: "Each creature in a 15-foot cone from the target of the attack must make a basic Fortitude save or take 1d6 secondary sonic damage."
- Problem: The cone's direction is unclear (away from you?), as is whether the Strike target is included. "Secondary" damage normally needs primary damage, which the cone targets do not take. The spell has ATTACK but not SAVE. "Topples" is flavour only.
- Proposed correction: change it to "15-foot cone extending away from you behind the target (target excluded) … 1d6 sonic damage (basic Fortitude)". Add SAVE.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m156 — TOUCH OF HEALING
- **Where:** L8739
- Excerpt: "You touch channels healing energy into your target."
- Problem: Broken sentence.
- Proposed correction: change it to "Your touch channels healing energy…".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m157 — WEAKENED ELEMENT (/ Recommendation)
- **Where:** L8759
- Excerpt: "You draw power from the natural forces around you weaken the creatures innate resistances"
- Problem: Broken sentence. The spell gives weakness (+50% damage) with no save at 30 ft for 1 AP. Unsure whether that is intended. Interaction with an existing resistance is not stated.
- Core check: core.txt L15594 (weakness = +50%).
- Proposed correction: change it to "…around you to weaken…". Consider a Will or Fortitude save. Add "weakness and resistance to the same type cancel".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m158 — CHAPTER 8 – MAGIC ITEMS
- **Where:** L8767
- Excerpt: "CHAPTER 8 – MAGIC ITEMS"
- Problem: The chapter number repeats "# CHAPTER 8 - GRIMOIRE" (L5990). This should be Chapter 9. The line is also not a markdown heading in ea.md (the docx style is lost), and it uses an en dash where the other chapter headings use a hyphen.
- Proposed correction: renumber it CHAPTER 9 and check later chapter numbers and cross-references.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m159 — intro
- **Where:** L8881
- Excerpt: "the fierce resilience of the Forceward rune, or the quickened fastening of a Quickbind charm"
- Problem: There is no "Forceward" rune; the rune is named FORCE WARDING (L8961). Quickbind is a rune, not a charm. Separately, "Quickbind" is also the name of an EA Arcana skill action (L1986, item investment), a name collision.
- Proposed correction: change the text to "Force Warding rune" and "Quickbind rune". Consider renaming the rune (e.g. "Swiftbuckle").
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m160 — AEGISFLOW (Unsure) — *unsure*
- **Where:** L8895
- Excerpt: "apply DR based upon the level of the rune to a location not normally covered by that armour (such as unarmoured limbs)."
- Problem: Unsure whether the core tracks hit location per attack. Core coverage is per armour piece (core.txt L11303), and hit locations show up only in specific feats (L9280). If locations are not tracked per hit, it is unclear when this rune applies. The docx tiers are I = half armour DR, II = full.
- Proposed correction: state "When you are hit and your armour lacks coverage (bracers/greaves) for a location, …", or "always apply this DR against critical injury location effects".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m161 — ASTRAL ECHOES
- **Where:** L8917
- Excerpt: "this modifier has no effect if the critical is an UM 33, 66 or 100."
- Problem: Core defines special results for UM 66 (chaos) and UM 100 but not UM 33.
- Core check: `grep -c "UM 33" core.txt` → 0; `grep -n "unmodified 66" core.txt` → L16099.
- Proposed correction: change it to "an UM 66 or 100", or define UM 33.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m162 — COMFORT
- **Where:** L8959
- Excerpt: "advantage on all fatigue checks made for sleeping in armour"
- Problem: The core check is a DC 20 Fortitude saving throw, not a "fatigue check".
- Core check: core.txt L11364–11370.
- Proposed correction: change it to "advantage on the Fortitude save for Sleeping in Armour".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m163 — QUICKBIND
- **Where:** L9015
- Excerpt: "the time is reduced to a 1 AP Interact action per category of armour (light, medium, or heavy)."
- Problem: "Per category" could mean 1/2/3 AP for light/medium/heavy, or 1 AP each. Gravemeld Shirt (L9137, chain = medium) uses 2 AP, which supports 1/2/3. Core doubles donning time for full suits (L11261), and this rune does not say what it does for full suits.
- Proposed correction: change it to "1 AP (light), 2 AP (medium) or 3 AP (heavy) Interact; full suits +1 AP".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m164 — WILDBANE
- **Where:** L9089
- Excerpt: "you gain a +2 item bonus on saving throws and DB against effects caused by Wild Magic surges."
- Problem: Armour DB from potency is already an item bonus, so this +2 DB will not stack on most armour. That may not be intended. Ley Binding and Heartstrand's "+1 bonus to DB" give no bonus type at all.
- Core check: core.txt L28711 ("the DB bonus provided by armour is an item bonus").
- Proposed correction: make it a "+2 circumstance bonus", and state a type for Ley Binding.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m165 — GRAVEMELD SHIRT
- **Where:** L9131–9137
- Excerpt: "This Grave Iron chain shirt"
- Problem: The material is spelled "GRAVEIRON" in EA Gear (L4831). Core Chain is ACP -2, Max Dex 4, Speed -5. The printed ACP -1, Max Dex 6 and CR 1 are not explained by the listed traits (Reinforced only). Speed is not printed. Unsure: the module needs Graham's derivation.
- Core check: core.txt L11440–11600 armour table: "Chain | 1 | 150 | -2 | 4 | 4 | 40 | -5 | 25 | Metal".
- Proposed correction: change it to "Graveiron". Add Lightweight (or an explanation) and Speed -5. Explain CR 1.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m166 — HEARTSTRAND HARNESS (Unsure) — *unsure*
- **Where:** L9149–9155
- Excerpt: "**ACP** -1; **MAX DEX** 6; **DR** 1; **DB** +1; **HP** 38"
- Problem: Core Reinforced Leather is Max Dex 5 and HP 30. With Potency I (+5 HP), HP should be 35 and Max Dex 5. The Expert trait slot is unused.
- Core check: core.txt armour table "Reinforced Leather | 0 | 30 | -1 | 5 | 1 | 30 | 0 | 15 | Rigid"; Potency I = +1/+5 (L28680).
- Proposed correction: confirm the stats, or list the Expert trait used (e.g. Lightweight).
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m167 — SHADESKIN (Unsure) — *unsure*
- **Where:** L9169–9171
- Excerpt: "**ACP** 0; **MAX DEX** 9; **DR** 1; **DB** +2; **HP** 46; Perception -1"
- Problem: Core Full Leather is ACP -1, Max Dex 6, HP 30. Lightweight gives ACP 0 and Max Dex 7, and Potency II brings HP to 40. Max Dex 9, HP 46 and the "Perception -1" penalty come from no listed trait. The weight of 9 lb does match: 15 × 0.75 × 0.8. The item block also omits Veil II's 2/day frequency (docx tier).
- Proposed correction: confirm the stats, explain the Perception penalty, and add "Frequency 2/day" to the Activate line.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m168 — WHISPERING HOLLOW
- **Where:** L9187–9191
- Excerpt: "This Full Scalemail has the following statistics:"
- Problem: Core has no "Full Scalemail"; it has Scale (and Full Chainmail etc.), so the base armour is unresolvable. The flavour says Ashbone, but Ashbone is missing from the Traits line, unlike Shadeskin and Gravemeld. The text block omits Comfort's Max Dex +1. Stats (ACP -2, Max Dex 7, HP 135) cannot be derived.
- Core check: `grep -n -i "full scale" core.txt` → none; armour table "Scale | 1 | 100 | -2 | 3 | 4 | 50 | 0 | 18 | Metal, Rigid".
- Proposed correction: change it to "Ashbone full scale (scale + bracers + greaves)". Add Ashbone to Traits. Add "Max Dex +1 (Comfort)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

### Recommendations

#### EA-R16 — Hexes
- **Where:** L1464 / L1736 (cross-check)
- Excerpt: "Any Hex that you learn does not follow the normal rules for specialist spells and instead is treated as an innate spell (with the focus trait)."
- Problem: Warlock hexes use innate DC (10 + ability + level) and the focus-trait limit, while Witch hexes use specialist DC and casting. The same hex therefore resolves differently by class. No hex prints "requirements", though both classes say "any one hex for which you meet the requirements".
- Proposed correction: no rule change. The module must route by class. Add requirement lines (e.g. familiar) to hexes.
- **Status:** Not yet implemented. Balance note only; built as printed.

## Part D — Orbs, rods, staves, weapon runes and specific weapons (L9195–9999)

### Major

#### EA-M80 — Using the School Tradition Skill
- **Where:** L9231
- Excerpt: "you may cast using the spell’s tradition skill (Arcana, Nature, Occultism, Religion)."
- Problem: L9213 says orbs often hold High Magic spells, and High Magic has no tradition (L5554–5626: "classified simply as high magic"). A High Magic spell therefore has no tradition skill, so this fallback path cannot be used for it.
- Core check: in `charged-items.mjs`, `castFromItemOptions` returns "the spell has no tradition recorded" (path unavailable) when the spell has no tradition.
- Proposed correction: add "For High Magic spells, use Arcana (or the skill of your own tradition)", or state that High Magic spells can only be cast through Spellcraft.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M81 — Using Spellcraft (High Magic)
- **Where:** L9227
- Excerpt: "you may Cast a Spell from the Orb using Spellcraft as a Hard check (DC +2)."
- Problem: High Magic casting is already Hard (+2) (Ch.7). The rules do not say whether the orb's +2 stacks to +4 for a High Magic spell. Unsure: Graham's intent settles it.
- Proposed correction: add "This replaces (does not stack with) the High Magic casting difficulty", or the opposite.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M82 — Charge Depletion (Resonant Flare)
- **Where:** L9249
- Excerpt: "This produces a Wild Surge that effects all creatures in a 20-foot radius."
- Problem: the Wild Surge table scales by "area level" (L5746–5754). The only substitute given outside a Wild Magic Area is for a Wild Mage ("PP expended", L5798). The flare's magnitude is undefined, and table entries written for "you" do not map cleanly onto "all creatures".
- Proposed correction: "Treat the area level as the Orb's level; the Orb's wielder is 'you'."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M83 — Charge Depletion (Resonant Flare)
- **Where:** L9249
- Excerpt: "instead of breaking, it unleashes a Resonant Flare."
- Problem: the orb's state after the flare is not given (depleted at 0 PP? still usable?).
- Core check: `ITEM_DEPLETION_TABLE` row 41–65 is `breaks: true`, and an override is needed.
- Proposed correction: add "The Orb is depleted (0 PP) but not broken."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M84 — Orb of the Whispering Veil
- **Where:** L9375
- Excerpt: "**Level** 6; **Price** 4,900 gp"
- Problem: level 6 gives 1,600 ×1.25 = 2,000 gp (2,500 gp ×1.25 = 3,000 at level 7 with the school +1). 4,900 gp is identical to Emberlight's price (a likely copy error) and is above a level-8 orb.
- Core check: `CHARGED_ITEM_COST_TABLE[5]` = 1600.
- Proposed correction: 2,000 gp.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M85 — Orb of the Shattered Veils
- **Where:** L9323
- Excerpt: "*Decoherence (0), Leyline Surge (2), See Invisible (4), Planar Anchor (8)*"
- Problem: "Leyline Surge" exists in neither the EA spells nor the core spells. The orb's level 11 (= 8 + 2 + 1) and its HIGHMAGIC trait only make sense if this spell is High Magic, because the other three are not.
- Core check: rulebook-spells.json has no key LEYLINE SURGE. ea.md has only LEYLINE BURST PP 4 (HM, L7044), LEYLINE ANCHOR PP 10 and MANA SURGE PP 12.
- Proposed correction: name the intended spell (probably Leyline Burst), and correct its PP and the orb's level if the PP changes.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M86 — Rod of Ley Resonance
- **Where:** L9457
- Excerpt: "you may spend PP from this rod as if it were doubled for the spell being cast"
- Problem: nothing grants permission to spend rod PP on spells in the first place. Core rods that allow it say so explicitly (Rod of the Magi: "expend PP from the rod instead of your own reserve"). It is also unclear whether the rod works at all away from a ley line, and odd PP costs (3 PP from 1.5 rod PP) are not handled.
- Core check: rulebook L29153–29154.
- Proposed correction: "You may expend PP from this rod instead of your own reserve. Within 60 ft of a ley line, each rod PP counts as 2 (round the cost up)."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M87 — Rod of Wild Surges
- **Where:** L9539
- Excerpt: "You may expend a PP from this rod when casting a spell to trigger a Wild Surge."
- Problem: the same as the Resonant Flare: the magnitude is undefined outside a Wild Magic Area. It is also unclear whether the spell still resolves.
- Proposed correction: "Area level = the spell's PP; the spell resolves normally."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M88 — Staff of Flame
- **Where:** L9597
- Excerpt: "*Flame Bolt (0), Burning Hands (2)*"
- Problem: no spell called Flame Bolt exists. The core has FIRE BOLT (PP 4) and ORB OF FIRE (PP 0).
- Core check: rulebook-spells.json has no FLAME BOLT key.
- Proposed correction: "Orb of Fire (0)".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M89 — The Weavers Delight
- **Where:** L9659
- Excerpt: "*Invoke True Name (0), Alter Corpse (2), Chaos Shield (6), Leyline Anchor (10), Chronoweave (12), Essence Reforging (14)*"
- Problem: staves use the core charged-item restrictions (L29169). Spellcraft needs "the spell must be from your tradition", and High Magic has none. Only High Magic casters (who "treat all traditions as high magic", L685) qualify, and nobody can use the skill path. Essence Reforging is a 1-hour ritual, and nothing says how a ritual is cast from a staff.
- Core check: `castFromItemOptions` sets `sameTradition` false for High Magic, and the skill path is unavailable.
- Proposed correction: state "High Magic spells in a staff may be cast through Spellcraft by any High Magic caster; others use Arcana with Use Magic Device", and add a ritual note.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M90 — Chrono (also Starfall L10001)
- **Where:** L9701
- Excerpt: "**Activate** Command 0 AP You gain the quickened condition"
- Problem: no duration or ending is given ("if it is already running" implies it is sustained). The core quickened condition grants its AP only at the start of the turn (L31092), so the timing of activation matters and is not stated. The drawback sentence also has a stray semicolon ("use this rune; you must").
- Core check: rulebook L31092–31094; Exhaustion check is Easy, level-based Fortitude (L15722).
- Proposed correction: "Until you end it (free action) or become fatigued; you are quickened from the start of your next turn."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M91 — Echoing, Sanguine (L9833), Bleeding Crown (L9935)
- **Where:** L9717
- Excerpt: "The target suffers persistent sonic damage"
- Problem: the core term is "recurring" damage. Grep "persistent" in rulebook-core-3.7.txt gives 0 hits, and the core condition list has `recurring`/`bleeding`. "Persistent" is used here without a definition.
- Proposed correction: "recurring sonic damage", "1d4 bleeding" (or define persistent = recurring once in the book).
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M92 — Leybound
- **Where:** L9759
- Excerpt: "the GM rolls on the Wild Magic table instead of resolving as well as resolving the fumble normally."
- Problem: the sentence contradicts itself ("instead of" and "as well as"). The table name is also wrong (the table is "Wild Surge"), and the surge magnitude is undefined.
- Proposed correction: "the GM also rolls on the Wild Surge table (area level = ley line level) in addition to resolving the fumble."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M93 — Sanguine (also Bleeding Crown L9937)
- **Where:** L9835
- Excerpt: "If you go three rounds without striking a foe, you begin to bleed for 1d6."
- Problem: there is no combat or encounter limit. Outside combat it triggers constantly, and it is unclear whether simply carrying the weapon counts. "Bleed for 1d6" is not a defined condition value.
- Proposed correction: "During an encounter, if you wield the weapon for three consecutive rounds without striking a foe, you gain bleeding 1d6."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M94 — Spellhold
- **Where:** L9837
- Excerpt: "**Activate** Command (1 AP)"
- Problem: capacity tiers (6/12/24/40 PP) are in the sidebar after L9849, but the rune never says how a stored spell is released. It is unclear whether the Command (1 AP) stores or releases, how long a stored spell lasts, and whether a stored spell keeps its stored check result when released.
- Proposed correction: "Release: Command (1 AP) releases one stored spell using the check result rolled when it was stored; stored spells fade at your next daily preparation."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M95 — Summoner’s Brand (also Ritualists Edge L9981)
- **Where:** L9861
- Excerpt: "creatures with either the Summoned or Conjured trait ... spells with either of those traits."
- Problem: no "Summoned" trait exists. EA summoning spells use SUMMONS, and core creatures use Conjured. Spells never carry Summoned or Conjured, so the caster-level clause never applies.
- Proposed correction: "creatures with the Conjured trait or summoned by a Summons spell; your caster level is +1 for spells with the Summons trait."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M96 — Bleeding Crown
- **Where:** L9931
- Excerpt: "**AB** +2; **Damage** 1d8+1 B; **Size** M; **FDC** 1**8**"
- Problem: the core Battle Axe deals 1d8 **S**. Its Sanguine rune requires "any slashing melee weapon", so B damage makes the rune illegal on it. The "1**8**" FDC also has broken bold formatting.
- Core check: rulebook L12429 "Battle Axe | 1d8 S | M | 18 | 6 lbs | AR 1, Hand & a Half, Sweep". Price check: 20 + 200 (Expert L2) + 1,400 + 4,300 = 5,920 gp (L9) ✓.
- Proposed correction: "1d8+1 S"; "FDC 18".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

### Minor

#### EA-m169 — Casting from an Orb
- **Where:** L9215
- Excerpt: "A character may only wield one Orb at a time."
- Problem: the core says one charged item of any kind at a time (rulebook L29092). As worded, this could be read as allowing an orb and a staff together.
- Core check: rulebook L29092 "may only wield one charged item at any one time"; `chargedItemWarnings`.
- Proposed correction: "An Orb counts as your one wielded charged item."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m170 — Using Spellcraft
- **Where:** L9225
- Excerpt: "The spell does not need to be in your repertoire or even be of the same tradition."
- Problem: this is listed as a bulleted "requirement", but it removes a requirement. The core lists tradition as a requirement here.
- Proposed correction: move it out of the list as a note: "Unlike other charged items, the spell need not be from your tradition."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m171 — Recharging an Orb
- **Where:** L9241
- Excerpt: "they must be recharged at a ley line or magical nexus by expending raw magical energy"
- Problem: no time, check or limit per day is given for the ley-line recharge.
- Proposed correction: add the time (for example, 10 minutes per PP) and state that no check is needed.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m172 — Recharging an Orb (Recharge Item)
- **Where:** L9243
- Excerpt: "The PP cost is 4 instead of 2, but you do not have to meet the requirements of the check."
- Problem: Recharge Item's Requirements sit on the action ("You have the spells that are contained within the item on your spell list"), not on the check. The action also scales off "natural recharging", which orbs lack. The result (PP gained per caster level) still works, but the wording is loose.
- Core check: rulebook L6462–6473.
- Proposed correction: "...but you need not meet the action's Requirements."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m173 — Charge Depletion
- **Where:** L9249
- Excerpt: "This Wild Surge is rolled on the standard Wild Magic Surge table."
- Problem: the core has no Wild Surge table (grep "Wild Surge" in rulebook-core: 0 hits), and the EA table is titled "WILD SURGE" (L5760). The same sentence has a typo: "effects" should be "affects".
- Proposed correction: "rolled on the Wild Surge table (Chapter 6)"; "affects".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m174 — Orb Level & Cost
- **Where:** L9253
- Excerpt: "take the highest PP spell contained +2 (minimum 4)."
- Problem: the rule is silent on the staff's "+1 for more than one school". The specific orbs disagree. Verdant Heart (highest 10, multi-school) is printed level 13, which needs the +1. Shifting Currents (multi-school, level 4) and Whispering Veil (multi-school, level 6) do not apply it.
- Proposed correction: state whether the school +1 applies, then fix the orbs that do not match.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m175 — Orb of Emberlight
- **Where:** L9297
- Excerpt: "while the Orb has at least 4 PP remaining"
- Problem: the general rule (L9275) switches abilities off "at 2 PP or less", which means they work from 3 PP. The other orbs use "at least 3 PP".
- Proposed correction: "at least 3 PP".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m176 — Orb of Emberlight
- **Where:** L9297
- Excerpt: "you gain resistance to fire and acts as a +1 Spell Adder key to spells with the fire trait."
- Problem: the sentence is broken (the subject changes mid-sentence, and "key" is a stray word).
- Proposed correction: "you gain fire resistance, and the Orb acts as a +1 Spell Adder for spells with the fire trait."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m177 — Orb of Emberlight
- **Where:** L9289
- Excerpt: "**Level** 8; **Price** 4,900 gp"
- Problem: level-8 staff 3,500 gp ×1.25 = 4,375 gp. Unsure: the fire resistance and Spell Adder abilities may account for the difference (L29091 "additional abilities ... may also increase the level").
- Core check: `CHARGED_ITEM_COST_TABLE[7]` = [3500, 2500].
- Proposed correction: 4,375 gp, or document the cost of the abilities.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m178 — Orb of the Verdant Heart
- **Where:** L9367
- Excerpt: "*Regenerate (10)*; **Power Points** 39"
- Problem: the Power Points field runs on the same line as the Spells field, unlike every other entry (a parser hazard).
- Proposed correction: move it onto its own line.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m179 — Rod of Focused Spell I/II/III
- **Where:** L9409
- Excerpt: "apply the focused spell Metamagic feat to the spell."
- Problem: the feat name is not capitalised. It resolves to EA FOCUSED SPELL (L3542, PP +3, advantage on Spellcraft). The core has no such feat.
- Proposed correction: "the Focused Spell metamagic feat (Chapter 4)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m180 — Rod of the Binding Seal
- **Where:** L9491
- Excerpt: "When casting a spell with the Summons or Binding trait, you may draw a PP"
- Problem: no "Binding" trait exists. EA binding spells carry SAVE SUMMONS TRANSLOCATION (L6080, 6648, 6746). It is also unclear whether several PP can be drawn for a larger reduction.
- Proposed correction: "Summons trait"; add "once per spell".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m181 — Rod of Soul’s Echo
- **Where:** L9523
- Excerpt: "increase your save DC against a creature of the undead type by 2."
- Problem: for an area spell, it is unclear whether only the undead targets get the higher DC, or how long the bonus lasts (this casting only?).
- Proposed correction: "the spell's save DC is increased by 2 for undead targets of this casting".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m182 — Staff of Flame
- **Where:** L9589
- Excerpt: "**Level** 4; **Price** 900 gp"
- Problem: a level-4 staff costs 600 gp. The core's own Animal Staff repeats the same 900 gp error, and Shock Staff is 600.
- Core check: `CHARGED_ITEM_COST_TABLE[3]` = [600, 450]; rulebook L29177 vs L29186.
- Proposed correction: 600 gp.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m183 — Staff of Heaven & Earth
- **Where:** L9615
- Excerpt: "*Gust (2), Obscuring Mist (2), Spike Stones (6), Air Walk (8), Shape Stone (8)*"
- Problem: Air Walk's base PP is 6. The core convention gives the base cost in parentheses (L29173). The level is unaffected (Shape Stone 8).
- Core check: rulebook L21153 "AIR WALK PP 6".
- Proposed correction: "Air Walk (6)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m184 — Staff of Heaven & Earth
- **Where:** L9605
- Excerpt: "**INVESTED MAGIC STAFF**"
- Problem: the trait is spelled "MAGICAL" everywhere else.
- Proposed correction: "INVESTED MAGICAL STAFF".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m185 — Tesra’ Anvir - Arcane
- **Where:** L9635
- Excerpt: "you may expend 8 PP from the rod to apply the quicken metamagic feat"
- Problem: the item is a staff, not a rod.
- Proposed correction: "from the staff".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m186 — Tesra’ Anvir - Arcane
- **Where:** L9625
- Excerpt: "**Level** 18; **Price** 180,000 gp"
- Problem: the formula gives 14 + 2 + 1 (multi-school) = 17. 180,000 gp is not on the staff ladder (L18 150,000; L19 250,000). Unsure: the added abilities may explain it.
- Proposed correction: 150,000 gp at level 18, or document the cost of the abilities.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m187 — Tesra’ Anvir - Arcane
- **Where:** L9621
- Excerpt: "TESRA’ ANVIR - ARCANE"
- Problem: the stray apostrophe and space, plus the " - ARCANE" suffix, make an unstable item name.
- Proposed correction: "TESRA'ANVIR (ARCANE)", or decide a canonical name.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m188 — The Weavers Delight
- **Where:** L9647
- Excerpt: "**INVESTED STAFF TRANSLOCATION**"
- Problem: five of its six spells are High Magic, which has no school, so the Translocation trait is unexplained. The name is also missing its apostrophe ("Weaver's").
- Proposed correction: "HIGHMAGIC INVESTED STAFF"; "THE WEAVER'S DELIGHT".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m189 — The Weavers Delight
- **Where:** L9649
- Excerpt: "**Level** 17; **Price** 102,000 gp"
- Problem: a level-17 staff costs 100,000 gp.
- Core check: `CHARGED_ITEM_COST_TABLE[16]` = 100000.
- Proposed correction: 100,000 gp, or document the cost of the +1 Spellcraft ability.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m190 — Weapons intro
- **Where:** L9671
- Excerpt: "or calling storms with a Thunderstrike sigil"
- Problem: no Thunderstrike rune exists in this section.
- Proposed correction: name an existing rune (for example Veilstorm), or add the rune.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m191 — Aetherfang (also Soulrend L9957)
- **Where:** L9687
- Excerpt: "deals 1d6 essence damage (basic Fort) per tier of the critical"
- Problem: "tier of the critical" is undefined. The core uses critical severity (Minor/Serious/Deadly...). The basic Fortitude DC is not stated, and neither is the DC for the fumble drawback.
- Core check: rulebook L12133–12146 (severity bands).
- Proposed correction: "per critical severity step (Minor 1, Serious 2, Deadly 3...)"; "(basic Fort, your level DC)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m192 — Essencebreaker
- **Where:** L9731
- Excerpt: "the target must succeed at a Will save or lose one resistance it has"
- Problem: no DC is given (Nullflare and Tether say "your level DC"). It is unclear who chooses the resistance, and the trait line lacks SAVE.
- Proposed correction: "Will save (your level DC) ... (your choice)"; add the SAVE trait.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m193 — Gravitas
- **Where:** L9743
- Excerpt: "you may make a free Trip or Shove action against the target as a Free Action."
- Problem: "free" is redundant. It is also unclear whether the multiple-attack penalty (MAP) applies.
- Proposed correction: "you may Trip or Shove the target as a free action (no MAP increase)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m194 — Leybound
- **Where:** L9757
- Excerpt: "Your Strikes gain +1 attack bonus and deal an additional die of base damage."
- Problem: the bonus type is unstated, so it is unclear whether it stacks with Potency (item).
- Proposed correction: "+1 circumstance bonus".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m195 — Mindpiercer
- **Where:** L9767
- Excerpt: "The weapon hums with planar instability, its edge cutting across the seams of reality."
- Problem: the flavour text is copied word for word from Riftcleaver (L9815) and does not fit a mind-piercing rune.
- Proposed correction: write new flavour text.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m196 — Nullflare
- **Where:** L9783
- Excerpt: "(GM’s choice, starting with the lowest PP)"
- Problem: "GM's choice" contradicts the fixed order. The ladder has no Partial or Critical degree.
- Proposed correction: "the lowest-PP effect (GM breaks ties)"; "Critical/Success/Partial: no effect".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m197 — Spellhold
- **Where:** L9849
- Excerpt: "no individual spell may exceed the normal maximum spell level you can cast."
- Problem: TRG Prime has no spell levels; it caps by PP (Caster Level + 1).
- Proposed correction: "the maximum PP you can spend on a single cast".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m198 — Veilstorm
- **Where:** L9889
- Excerpt: "**Activate** Free (0 AP); Trigger once per round after a successful strike"
- Problem: "Trigger" is not bold (a parser hazard; compare L9817, L9873). The basic Reflex DC is not stated (Pyrebrand L9803 has the same gap).
- Proposed correction: "**Trigger**"; "(basic Reflex, your level DC)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m199 — Warpflare
- **Where:** L9913
- Excerpt: "When attacking on or near a ley line, add +1 to the roll"
- Problem: "near" is undefined (Leybound uses 30 ft, Ley Resonance 60 ft).
- Proposed correction: "within 30 feet of a ley line".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m200 — Soulrend
- **Where:** L9955
- Excerpt: "**Traits** Reach, Versatile P, Master, Potency III, Aetherfang, Essencebreaker"
- Problem: the core Bardiche has Clumsy, which is silently dropped. Price check: 13 + 3,000 + 6,000 + 6,000 + 11,000 = 26,013 gp (L14) ✓.
- Core check: rulebook L12409.
- Proposed correction: add Clumsy, or state that it was removed.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m201 — Ritualists Edge
- **Where:** L9969
- Excerpt: "**Level** 11; **Price** 8,002 gp"
- Problem: dagger 2 + Expert (L2) 200 + Potency II 1,400 + Summoner's Brand 6,000 = 7,602 gp, which is level 10 (the 8,000 threshold is not reached). The name is also missing its apostrophe.
- Core check: rulebook L12297 (Dagger 2 gp); WEAPON_COST_TABLE.
- Proposed correction: 7,602 gp, level 10; "RITUALIST'S EDGE".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m202 — Starfall
- **Where:** L9997
- Excerpt: "**AB** +3; **Damage** 1d10+2 S; **Size** M; **FDC 8**"
- Problem: the core Tel'dorin is Size L. Price check: 200 + L11 (Master +8, added AR trait +1) 8,000 + 6,000 + 17,000 = 31,200 gp (L14) ✓.
- Core check: rulebook L12801–12809.
- Proposed correction: "Size L".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

### Recommendations

#### EA-R17 — Using the School Tradition Skill
- **Where:** L9233
- Excerpt: "Your skill rank must exceed the PP cost of the spell."
- Problem: this is stricter than the core ("equal to or greater", L28961) but is not flagged as one of the exceptions. It is probably intended; confirm it.
- Proposed correction: if intended, keep it; otherwise use "equal or exceed".
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R18 — Tesra’ Anvir - Arcane
- **Where:** L9635
- Excerpt: "you may expend 8 PP from the rod to apply the quicken metamagic feat to a spell."
- Problem: unlike the Rods of Quickening, there is no PP or AP limit on which spell can be quickened (any PP, any AP).
- Proposed correction: add "a spell of PP 14 or less with an AP cost of 1 or 2", or confirm that no limit is intended.
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R19 — Orbs (implementation)
- **Where:** L9207
- Excerpt: "Orbs follow the charged item rules from the Core Rulebook with the following exceptions:"
- Problem: the core has no orb kind. The staff path would mis-level orbs (school +1 instead of +1 per High Magic spell), misprice them (no ×1.25), give them daily recharge, break them on 41–65, and use Easy/Hard casting DCs.
- Core check: `charged-items.mjs` (`chargedItemLevel`, `chargedItemPrice`, `dailyRecharge`, `castFromItemOptions`), `magic-items.mjs` `ITEM_DEPLETION_TABLE`.
- Proposed correction: add an `orb` kind (or module hooks) for level, price, PP ×3, no recharge, the flare row, and the cast options (Spellcraft +2 with no tradition requirement; skill +5, rank > PP).
- **Status:** Not yet implemented. Balance note only; built as printed.

## Part E — Relics, sentient items and appendices (L10000–11744)

### Critical

#### EA-C8 — Veilshroud (Awakened)
- **Where:** L10313
- Excerpt: "Gains the Flaming I rune."
- Problem: Flaming is a weapon rune ("Usage any weapon") and cannot go on a cloak. It is almost certainly copied from Emberfang (L10197) and has no theme fit.
- Core check: core L29731–29736 FLAMING "Usage any weapon".
- Proposed correction: Replace with an armour/cloak benefit Graham chooses, e.g. EA Veil I rune (L9067) or "+2 item bonus to Stealth".
- **Status:** Not built. Awaiting your ruling; the feature ships only once the text can be resolved.

### Major

#### EA-M97 — Relic Bonding Ritual / Rules for Relics
- **Where:** L1840
- Excerpt: "Once bonded, the relic will gradually increase in power level until it matches that of the wielder."
- Problem: The book never says how fast "gradually" is. The tier rules (L10031, L10037) tie tier to wielder level, and the Critical result (L1832) only jumps one stage, which implies a lag. The software needs a rule: tier = min(level tier, awakened tier), plus an advance step (per day, per level, or per milestone).
- Proposed correction: "After bonding, the Relic advances one tier at each daily preparation until its tier matches the wielder's level" (or Graham's preferred cadence).
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M98 — Relics & Investment
- **Where:** L10034 / L10092
- Excerpt: "Only one Relic can be fully invested at a time." / "A Relic consumes one investment slot per tier of awakening."
- Problem: Several things are undefined:
  1. What happens when the wielder lacks free slots for the next tier: does the relic stay at a lower tier, or stop working?
  2. Whether "fully" means a relic can be partly invested, with tiers suppressed to save slots.
  3. How bonding relates to the core Invest Item action. Core investment ends "if another creature successfully invests the item", which conflicts with "cannot easily be claimed by another".
  4. The rule overrides the core text "if an item has multiple invested traits, you only need to use one investment slot" without saying so.
- Core check: core L28172–28179 (INVESTMENT, Invest Item); `magic-items.mjs` `investmentSlots`.
- Proposed correction: Add three lines. (a) "A Relic's active tier is the highest tier whose slot cost you can pay; you may voluntarily invest it at a lower tier." (b) "Bonding is required before the Relic can be Invested; another creature cannot Invest a bonded Relic." (c) "This replaces the one-slot rule for multiple invested traits."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M99 — Scaling Guidelines vs Emberfang / Aegis (balance)
- **Where:** L10073
- Excerpt: "always one step below a top-tier magic item of the wielder’s level"
- Problem: Both example relics run ahead of the core rune levels, not one step behind.
- Emberfang: Potency I at L1 (core level 2), II at L5 (core 6), III at L9 (core 10), IV at L13 (core 13), V at L17 (core 16); Flaming II at L9 (core 10), III at L13 (core 15).
- Aegis: shield Potency I at L1 (core 4), III at L13 (core 14).
- Core check: core L29655 weapon potency table (I 2, II 6, III 10, IV 13, V 16); L28711 shield potency (I 4, II 9, III 14, IV 19); Flaming/Acidic ranks L29700 (I 5, II 10, III 15).
- Proposed correction: Either relax the guideline ("at or slightly above") or shift the rune upgrades to the tier where the core level is reached.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M100 — all four relics
- **Where:** L10113 / L10169 / L10229 / L10285
- Excerpt: "**Usage** held shield; **Weight** 4 lbs" (no Level or Price line on any relic)
- Problem: Relics have no item level. Core says the DC and attack of an item-granted innate spell use the item's level, so every relic innate spell (and any dispel or identify check) has no level to work from.
- Core check: core "ITEMS & INNATE SPELLS": "the level used to determine the DC and attack check of the item is determined by the items level and not yours."
- Proposed correction: Add to Rules for Relics: "A Relic's item level equals its wielder's level; innate spells use that level."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M101 — relic innate spells (focus trait) (balance)
- **Where:** L10129–10341
- Excerpt: "Can cast Meteor Swarm as an innate spell with the focus trait."
- Problem: Innate spells cost no PP and are always warped to maximum. With the focus trait, one Refocus (1 AP, level-based) success brings the spell back by the next turn. That makes Meteor Swarm (PP 18), Heal (16), Hand of the Reaper (14), Fireball (6) and Vampiric Touch (8) close to free and repeatable each encounter. Core focus innate spells are cantrips or PP ≤2.
- Core check: core L20043–20046 (innate: no PP, max warp); L6349–6357 (REFOCUS ladder); core L1303/1395/1443 (focus innates are PP 0–2).
- Proposed correction: "Innate spells of PP 6 or more granted by a Relic are usable once per day instead of having the focus trait."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M102 — Obsidian Codex (Awakened)
- **Where:** L10259
- Excerpt: "Can cast Undead Binding as an innate spell with the focus trait."
- Problem: Undead Binding is PP 8 (EA L7845), granted at levels 5–8. That breaks the max-PP-per-cast cap (caster level + 1 = 6 at L5) and the book's own guideline of an innate PP 2 spell at Awakened (L10066). It also has a 10-minute cast with a material component.
- Core check: spells.json has no UNDEAD BINDING; the spell is EA L7845 (PP 8, Will save, summons a level ≤4 undead).
- Proposed correction: Move it to Empowered, or say "warped to the maximum PP you could cast".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M103 — Veilshroud (Legendary)
- **Where:** L10341
- Excerpt: "Once per day, you cast Gate as an innate spell"
- Problem: Gate is PP 20, granted from L17, where the max PP per cast is 18 (19 at L18). Gate also needs a plane stored through Study Target (Planes), which the item does not grant.
- Core check: spells.json GATE pp 20: "The plane must be stored using the Study Target (Planes) action."
- Proposed correction: "From 19th level, once per day…", or state the relic ignores the cap. Clarify the Study Target requirement.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M104 — Aegis of Valtea (Transcendent)
- **Where:** L10159
- Excerpt: "Gains the Renewal I rune."
- Problem: The EA Renewal rune (L9017–9023) has no ranks, level, price or HP table. It "regenerate[s] hit points based upon the runes level" but gives no numbers, so "Renewal I" cannot be resolved.
- Core check: core grep "RENEWAL": only spells (Moment of Renewal, Renewal's Touch), no rune.
- Proposed correction: Add a rank table to Renewal (e.g. I: regain 25% HP at daily preparation), or name the HP amount here.
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M105 — Aegis of Valtea, Shield of Dawn
- **Where:** L10167
- Excerpt: "Once day, you may invoke the Shield of Dawn: for 1 minute, allies within 30 ft gain Fast Healing 10"
- Problem: Broken phrase ("Once day"). No activation cost (AP, trait) is given. It is unclear whether "allies" includes the wielder, here and in the 10-ft aura at L10141.
- Core check: Fast Healing defined in core L15362.
- Proposed correction: "Once per day, you may invoke the Shield of Dawn (2 AP, concentrate): for 1 minute, you and allies within 30 ft…"
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M106 — Veilshroud (Dormant)
- **Where:** L10305
- Excerpt: "granting advantage on saves against being tracked by mundane means"
- Problem: Core has no save against being tracked. Tracking is the tracker's Track (Survival) check, so this cannot work as written.
- Core check: core L6609 "TRACK CONCENTRATE MOVEMENT" (Survival skill action).
- Proposed correction: "creatures attempting to Track you by mundane means have disadvantage".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M107 — Veilshroud (Awakened)
- **Where:** L10311
- Excerpt: "If you already have Darkvision, its range doubles."
- Problem: Core Darkvision has no range: it raises light level by two steps. The same problem affects Dawnshield's "Darkvision 70 ft" at L10621.
- Core check: core L19499–19501 DARKVISION; Perfect Darkvision L19502.
- Proposed correction: "If you already have Darkvision, you gain Perfect Darkvision instead."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M108 — Veilshroud (Empowered)
- **Where:** L10325
- Excerpt: "once per day, teleport up to 60 ft between two dimly lit spaces"
- Problem: No action cost or traits are given (e.g. MOVE, TELEPORTATION). "Dimly lit" does not map to the core numeric light levels.
- Proposed correction: "Once per day (2 AP, move, teleportation), teleport up to 60 ft from a space of light level 2 or lower to another such space you can see."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M109 — Veilshroud (Transcendent vs Legendary)
- **Where:** L10329 / L10339
- Excerpt: "Gain immunity to essence damage." / "When you take essence damage, you are instead healed of half the amount in HP."
- Problem: The two contradict each other. Immunity means you never "take" essence damage, so the Legendary absorption never triggers.
- Core check: core L15591 IMMUNITY: "ignore all damage".
- Proposed correction: "When you would be dealt essence damage, you ignore it and instead regain HP equal to half the amount."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M110 — relic sentience vs Sentience & Investment
- **Where:** L10337 / Step 4
- Excerpt: "The cloak becomes a semi-sentient guardian" / "A Sentient Item requires two investment slots."
- Problem: Step 4 (L10084) lets relics "Awaken Sentience", and the Veilshroud becomes "semi-sentient". The book never says whether such a relic costs tier slots, tier + 2, or gains Ego/Influence. A sentient relic would also carry both RELIC and SENTIENT one-per-character limits.
- Proposed correction: "A Relic that awakens sentience uses its tier slots only and gains Ego as a sentient item of level = wielder level; 'semi-sentient' grants communication only, without Ego."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M111 — Ego & Conflict
- **Where:** L10397 / L10403
- Excerpt: "The wielder makes a Will save against the item’s Ego DC"
- Problem: The Ego DC formula is never stated. Dawnshield (Ego 24, DC 34) implies DC = 10 + Ego.
- Proposed correction: Add "Ego DC = 10 + Ego."
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

#### EA-M112 — Dawnshield influence
- **Where:** L10643–10649
- Excerpt: "use results below in place of the core results."
- Problem: Only Success, Failure and Fumble are given. It is unclear whether Critical, Partial and Blunder fall back to the generic ladder (L10405–10415). "Superior-trait benefits" (L10647) is undefined.
- Proposed correction: "Critical, Partial and Blunder use the Influence results above." Replace "superior-trait benefits" with "Potency, dragonhide and Light benefits".
- **Status:** Not yet implemented. The build follows the printed text where it can be resolved; where it cannot, the feature waits for your ruling or ships with the proposed reading flagged on its card.

### Minor

#### EA-m203 — Relic Bonding Ritual
- **Where:** L1830
- Excerpt: "You make a level based check to determine the outcome of this action"
- Problem: The check never says whose level sets the DC. Relics have no item level (see L10113 below), so it cannot be the relic's. The fumble's "basic Fort" save also has no DC. The ladder lists only Critical/Success/Failure/Fumble, with no Partial or Blunder, which leaves the software unsure how to map those rolls.
- Core check: core L31292 / L6352: a "level-based check" elsewhere uses the actor's level.
- Proposed correction: "level-based DC equal to the wielder's level". Fumble save DC = the same level-based DC. Partial counts as Failure; Blunder counts as Fumble.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m204 — Rules for Relics (Relic-Bound)
- **Where:** L10033
- Excerpt: "using the Ritual Bonding (Tradition) action"
- Problem: The action's name is wrong. The real action is "Relic Bonding Ritual" (L1816), a trained skill action for Arcana/Nature/Occultism/Religion.
- Core check: ea.md grep "Ritual Bonding" finds only L10033; "Relic Bonding" finds L1816 and L10241.
- Proposed correction: "using the Relic Bonding Ritual skill action (Arcana, Nature, Occultism or Religion)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m205 — Relic Tiers tables
- **Where:** L10037 / L10094
- Excerpt: "| RELIC TIERS |" (both tables)
- Problem: Two different tables carry the same title.
- Proposed correction: Retitle the second table "RELIC INVESTMENT".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m206 — Tier Benefits
- **Where:** L10069
- Excerpt: "Resistance x4, immunity x2, +3d6 damage"
- Problem: "Resistance x2/x3/x4" is not a core term. Core resistance halves damage and never stacks, so it could mean either resistance to 2/3/4 damage types or stacked resistance, and the second is impossible in core.
- Core check: core L15587–15589: "you may only halve the damage once".
- Proposed correction: "Resistance (2 types)", "(3 types)", "(4 types)", "Immunity (2 types)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m207 — Scaling Guidelines
- **Where:** L10076
- Excerpt: "- " (empty bullet)
- Problem: An empty list item, which looks like a dropped fourth guideline.
- Proposed correction: Delete it, or restore the missing text.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m208 — Aegis of Valtea (Dormant)
- **Where:** L10129
- Excerpt: "Is an expert quality, lightweight light shield."
- Problem: Core has no plain "light shield", only Light Steel Shield (6 lbs) and Light Wooden Shield (5 lbs). The printed 4 lbs fits wooden −1 (Lightweight), but the lore calls it "crystallized divine essence". The shield also stays expert quality through L20 (Emberfang upgrades to master and legendary).
- Core check: core SHIELD TABLE (L11873ff); Lightweight L12017.
- Proposed correction: "expert quality light wooden shield (Lightweight)". Consider master at Empowered and legendary at Legendary, matching Emberfang.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m209 — Aegis of Valtea (Awakened)
- **Where:** L10141
- Excerpt: "saving throws vs. fear and corruption"
- Problem: "Corruption" is not a trait, condition or effect class in core or EA, so the software cannot tell which saves qualify.
- Core check: core grep -i "corruption": narrative uses only (L1252, L2253, L31453).
- Proposed correction: "vs effects with the Fear or Curse traits", or define corruption.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m210 — tier headings
- **Where:** L10151 / L10211 / L10271 / L10327
- Excerpt: "TRANSCENDANT (LEVELS 13–16)"
- Problem: Spelled "Transcendant" in all four relics but "Transcendent" in the tables (L10043, L10068, L10100).
- Proposed correction: Use "TRANSCENDENT" throughout.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m211 — Emberfang, Veilshroud weights
- **Where:** L10173 / L10289
- Excerpt: "**Usage** held weapon; **Weight** 14 lbs" / "**Usage** worn cloak; **Weight** 14 lbs"
- Problem: A core broadsword weighs 4 lbs, and a cloak weighing 14 lbs looks like a copy of Emberfang's line.
- Core check: core weapons table: "Broadsword | 10 gp | 0 | 1d8 S | M | 10 | 4 lbs".
- Proposed correction: Emberfang 4 lbs; Veilshroud 1 lb (or as intended).
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m212 — Obsidian Codex requirement
- **Where:** L10241
- Excerpt: "The Codex cannot be bonded by Good aligned characters, and those of Balance or Order suffer constant Dissonance"
- Problem: In core, most PCs have no aligned trait (it is gained only through devotion to an ethic), so unaligned, Chaos and Evil wielders are not covered. "Dissonance" is defined only inline.
- Core check: core L19345: "if you hold your ethics with unwavering dedication, you may acquire an aligned trait"; core grep "Dissonance": no rule.
- Proposed correction: Add "Characters without an aligned trait may bond it normally."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m213 — Obsidian Codex (Awakened/Empowered)
- **Where:** L10255 / L10269
- Excerpt: "suffer –1 to all saves vs. divinity magic" / "Undead you create gain +2 HP per level."
- Problem: The penalty has no type. It is unclear whether "per level" means the undead's level. It is also unclear whether undead summoned by Undead Binding count as "created" (the Transcendent line says "under your control").
- Proposed correction: "–1 status penalty to saves vs spells of the divinity tradition"; "+2 HP per level of the undead"; "created or bound".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m214 — Dawnshield Ego (Unsure) — *unsure*
- **Where:** L10629 / L10639
- Excerpt: "**Ego** 24 (Ego DC 34)."
- Problem: Level 15 + CHA +6 + 3 bulleted powers = 24, which matches only if the un-bulleted "+2 to saves vs fear" aura (L10629) is not counted. Counting it gives 25 (DC 35). This would be settled by saying whether the aura is a "special power".
- Proposed correction: Bullet the aura and set Ego 25 / DC 35, or label the aura a baseline property.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m215 — sentient text
- **Where:** L10391 / L10457
- Excerpt: "flesh a sentient item out as much they wish" / "Feel free to expand and own your own options"
- Problem: Typos.
- Proposed correction: "as much as they wish" / "create your own options".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m216 — Sentient item tables
- **Where:** L10459–10533
- Excerpt: "| **d6**            | **Senses**                              |"
- Problem:
  1. The docx-to-markdown conversion merged six roll tables into one grid, so the headers and rows are separated.
  2. Senses is labelled d6 but has 8 entries.
  3. "Life Sense" is not in core.
  4. "Sense Power" is a core skill action, not a sense.
  5. Ethics gives Nihilism 2% against 7% for every other ethic.
- Core check: core grep "Life Sense": none; core L7510/9685 SENSE POWER (feat/action); core ethics list L19330–19344 (15 ethics, matching).
- Proposed correction: Split into six tables. Senses → d8. Define Life Sense or replace it (e.g. Blindsight). Optionally rebalance the ethics bands.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m217 — Special Powers / quirks table
- **Where:** L10556
- Excerpt: "| **ALIGNED TRAIT**" (second occurrence, d20)
- Problem: The d20 table is a quirks table, but it carries the aligned-trait header twice.
- Proposed correction: Retitle it "QUIRKS (d20)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m218 — Dawnshield traits
- **Where:** L10599 / L10617
- Excerpt: "**INVESTED LIGHT SENTIENT WARDING**" / "**Aligned Traits** Balanced, Good"
- Problem: Dawnshield lacks the RARE trait that L10423 says all sentient items carry. The aligned trait is "Balance", not "Balanced", and having Balance and Good together is unusual.
- Core check: core APPENDIX 3 ALIGNED: "Balance, Chaos, Evil, Good and Order".
- Proposed correction: Add RARE; "Aligned Traits Good" (or "Balance, Good" if intended).
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m219 — Dawnshield statistics (Unsure on HP) — *unsure*
- **Where:** L10609 / L10613
- Excerpt: "**ACP** 0; **DR** 3; **DB** +4; **HP** 110; **Traits** Dragonhide, Organic, Master, Potency II"
- Problem:
  1. A heavy steel shield (ACP −2, 15 lbs, HP 20) at master quality gives DR 3 ✓ and DB 2 + 2 = 4 ✓.
  2. ACP 0 needs two Balanced traits, which are not listed.
  3. 10 lbs needs Lightweight ×2, also not listed.
  4. HP: 20 × 3 (master) × 1.5 (dragonhide) + 40 (Potency II) = 130, not 110.
  5. "Organic" is not a core shield trait.
  6. "Masterwork" in the prose conflicts with "Master".
- Core check: core SHIELD TABLE (Heavy Steel 40 gp, DB 2, ACP −2, 15 lbs, DR 1, HP 20); SUPERIOR SHIELD TABLE (Master ×3, +2 DR); DRAGONHIDE "+50% more HP"; shield potency II "+2/+40".
- Proposed correction: List the superior traits (Balanced ×2) and set HP 130, or state the base used. "Master heavy shield".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m220 — Dawnshield senses and powers
- **Where:** L10621 / L10633 / L10635
- Excerpt: "Aberration/Undead Sense 50 ft" / "dispels magical darkness of PP 6 or less in its bright radius"
- Problem: Life Sense and Aberration/Undead Sense are undefined. The "30-ft bright radius" does not match the core Light spell, which raises illumination on an object with no radius. The flare has no action cost.
- Core check: spells.json LIGHT: "increasing the illumination level by two steps"; core grep "Life Sense": none.
- Proposed correction: Define the senses as tertiary senses with ranges. State "sheds bright light in a 30-ft radius". Give the flare an action (e.g. 2 AP).
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m221 — New Traits
- **Where:** L10671
- Excerpt: "This chapter introduce some new spell traits"
- Problem: Grammar ("introduce"). Orb, Relic and Sentient are item traits and Berserker is a feat trait, not spell traits. RITUAL already exists in core (core L31343), and EA's version differs: it is stricter ("cannot be cast through normal spellcasting methods").
- Proposed correction: "This appendix introduces new traits…"; note that RITUAL replaces the core trait for EA spells.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m222 — Highmagic trait (Uncommon) (Unsure) — *unsure*
- **Where:** L10681
- Excerpt: "They cannot be taken as automatic spell picks when levelling"
- Problem: This may conflict with class text that grants High Magic spells automatically. The Sorcerer (L785ff) casts all its spells as High Magic, and Sorcerer tables grant spells by level. This would be settled by confirming whether class-granted HM spells are exempt.
- Proposed correction: "…unless granted by a class feature."
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m223 — Ritual trait
- **Where:** L10701
- Excerpt: "following the rules for Magic Rituals (see Ritual Casting)"
- Problem: No section is titled "Magic Rituals" or "Ritual Casting". The nearest are MUNDANE RITUAL CASTING (L5546/5872), RITUAL VARIANT (L5876) and RITUAL SPELLS (L5930).
- Proposed correction: "(see Ritual Spells, Chapter 7)".
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m224 — Relic and Sentient traits
- **Where:** L10697 / L10705
- Excerpt: "A magical item with this trait holds considerable power and can place great stress upon its wielder."
- Problem: The two traits share the same sentence. Neither mentions its slot cost (tier slots / 2 slots), which the software needs on the trait.
- Proposed correction: Append "It uses one investment slot per tier (see Relics & Investment)" and "It uses two investment slots" respectively.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

#### EA-m225 — Index
- **Where:** L11443 / L11683–11685
- Excerpt: "touch of healing: 99" / "weapons 109" / "weapons 60"
- Problem: A stray colon. "Weapons" appears twice with no qualifier (the 109 entry is weapon runes). "shard cloud 99" is out of alphabetical order. No Dawnshield, Aegis, Emberfang, Codex or Veilshroud entries.
- Proposed correction: "touch of healing 99"; "weapon runes 109"; reorder; add the relic and sentient item names.
- **Status:** Not yet implemented. Built as printed; the proposed correction is applied only if you accept it.

### Recommendations

#### EA-R20 — Aegis, Codex spell picks
- **Where:** L10147 / L10157 / L10267 / L10275
- Excerpt: "Can cast Restoration as an innate spell with the focus trait."
- Problem: Several spells fall well below the tier guideline (L10067–10068: Empowered PP 4–8, Transcendent PP 10–14). Restoration is PP 2 (only reduces fatigued by 1) at Empowered; Create Undead is PP 4 at Transcendent and needs hours of casting and rare materials; Forbiddance is PP 8 and Fireball PP 6 at Transcendent. It is also unclear whether Create Undead's material cost is waived when cast innately.
- Core check: spells.json RESTORATION pp 2, CREATE UNDEAD pp 4 ("Cost rare materials"), FORBIDDANCE pp 8, FIREBALL pp 6.
- Proposed correction: Keep the picks but note they are warped to maximum. State whether costs are waived.
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R21 — Emberfang traits
- **Where:** L10171
- Excerpt: "**INVESTED MAGICAL RELIC**"
- Problem: There is no FIRE trait, although the relic grants fire damage, fire resistance and fire spells. Tradition and school traits are also absent, unlike the other relics.
- Proposed correction: "FIRE INVESTED INVOCATION RELIC".
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R22 — Obsidian Codex traits (Unsure) — *unsure*
- **Where:** L10231
- Excerpt: "**EVIL INVESTED RELIC SOUL TRANSLOCATION**"
- Problem: TRANSLOCATION does not match any Codex power (all are Soul/necromancy). This would be settled by Graham confirming whether it was intended.
- Proposed correction: Replace TRANSLOCATION with nothing, or with SHADOW if a second school was meant.
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R23 — Sentient Item Cost & Level
- **Where:** L10419–10423
- Excerpt: "a sentient item’s level is equal to the base item’s level +2"
- Problem: No price rule is given. Dawnshield's 38,500 gp matches the core shield cost table at level 15, so the implied rule is price = cost table at the new level.
- Core check: core SHIELD COST TABLE: "15 | 38500".
- Proposed correction: Add "Its price is the base cost for an item of its new level."
- **Status:** Not yet implemented. Balance note only; built as printed.

#### EA-R24 — OGL section 15
- **Where:** L11731–11738
- Excerpt: "15 COPYRIGHT NOTICE"
- Problem: Section 15 lists only WotC and Paizo works, not Eldritch Arts or TRG Prime. OGL clause 6 requires adding your own title, date and holder.
- Proposed correction: Add a line, "TRG Prime: Eldritch Arts © 2026, Graham …".
  ### Relics & Investment (balance) — Recommendation
- Excerpt: "the more tiers a Relic has reached, the more of their essence it commands."
- Problem: Under the core formula, a martial character with magical ability −1 has 0 free slots at L13–19 once the relic is invested (see the maths above), and cannot hold a relic plus a sentient item at all. The GM note frames this as intended ("replacement for several items"), so it is a design check only.
- Core check: `magic-items.mjs` `investmentSlots(level, ability) = 3 + ability + floor(level/5)`; core feat Incredibly Invested (+2 slots, L9531).
- Proposed correction: Optional: "A Relic always leaves you at least one other investment slot", or keep as is.
- **Status:** Not yet implemented. Balance note only; built as printed.

## Part F — Found while building Block 1 (28 October 2026)

These were found while building Chapter 2, Chapter 4 and Chapter 6 for Eldritch Arts 0.1.0, and are not in Parts A–E (the goods' heading spellings are already EA-m65 and EA-m68). They keep the numbering above: the ids continue after Part E's. Each is also a question in `docs/ELDRITCH_ARTS_BLOCK1_AUDIT.md` (B1-1, B1-10, B1-12, B1-17 to B1-20), where the interim build is described.

### Major

#### EA-M113 — Ley Sense prints the Focus trait
- **Where:** L1800, "**LEY SENSE CONCENTRATE FOCUS**".
- **Problem:** Focus is the trait of an ability with a use that Refocus restores. Ley Sense is a skill action that anyone trained may take. There is no item to track a use on, no core skill action carries Focus, and the system spends no use for one.
- **Core check:** the core's skill and basic actions (`module/data/skill-actions.mjs`, `basic-actions.mjs`): none carries Focus.
- **Proposed correction:** drop the trait, or say what the use is ("once per Refocus").
- **Status:** Implemented in 0.1.0: the trait is carried and no use is spent (B1-17).

#### EA-M114 — Vir-ellian's release has no DC
- **Where:** L273, "release the energy as a 1 AP (concentrate, focus) action inflicting 1d4 force damage per PP to all creatures within your Magic Drain aura (basic Will)".
- **Problem:** a basic save with no DC. The area is EA-M24's.
- **Core check:** the core's racial abilities that print no DC use the Level DC.
- **Proposed correction:** "(basic Will against your Level DC)".
- **Status:** Implemented in 0.1.0 as proposed (B1-18).

#### EA-M115 — Brace is two different rules
- **Where:** L4927, "**Brace:** … If a foe moves into your reach using a Stride, Charge, or similar movement ability, you may use a Reaction to make a melee Strike with this weapon against that creature."
- **Problem:** TRG Prime already has a Brace trait (the rule Inner Tempest prints: a readied Strike against a mounted target gains +2 and a die), applied to every weapon carrying the trait. Eldritch Arts' Brace is a different reaction. A weapon carrying the trait would get the other book's rule.
- **Core check:** `module/data/appendix-traits.mjs` lists `brace`; TRG Prime 3.668.1 applies it.
- **Proposed correction:** use the existing rule, or rename Eldritch Arts' trait.
- **Status:** Held for Graham (B1-12). The three weapons (Gaoth Bhioráin, Tuagh Tairngire, Gaoth Shlánaithe) print the trait in their text, not in their trait line.

#### EA-M116 — "Elemental Language" is not a language
- **Where:** L191, "**Core Languages:** Low Tongue & Elemental Language".
- **Problem:** no language of that name exists in the core or in Eldritch Arts. There are four elemental tongues.
- **Core check:** `module/languages.mjs`: Gaian, Aeolian, Ignic, Aqualis.
- **Proposed correction:** "Low Tongue & your heritage's elemental language (Stonevein Gaian, Galeborne Aeolian, Cinderblood Ignic, Tidemarked Aqualis)".
- **Status:** Implemented in 0.1.0 as proposed, on the Tianzhi precedent (B1-1).

#### EA-M117 — Elemental Symbiosis is a reaction with no trigger
- **Where:** L201, "You may use a reaction to gain immunity to your elemental type".
- **Problem:** a reaction needs a trigger. Without one it can be used at any moment, including on another creature's turn before the damage is known.
- **Proposed correction:** "Reaction. **Trigger:** you would take damage of your elemental type."
- **Status:** Implemented in 0.1.0 with no trigger: usable as your reaction when you choose (B1-10).

### Minor

| ID | Where | Printed / issue | Proposed |
|---|---|---|---|
| EA-m226 | L1962 | Lingual Casting: "ranks … in the appropriate tradition skill" — a scroll whose spell names no tradition has none | Say which skill, or that it cannot be read this way |
| EA-m227 | L1944 | Hypnotism's Failure, "can be retried the next day": on that subject, or at all? | "…retried on that subject the next day" |
| EA-m228 | L1996 | Quickbind's Failure: "The is invested in the normal amount of time" | "The item is invested…" |
| EA-m229 | L1804 | Ley Sense: "that others would overlook.." | One full stop |
