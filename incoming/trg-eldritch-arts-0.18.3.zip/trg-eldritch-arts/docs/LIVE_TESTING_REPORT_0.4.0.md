# Eldritch Arts 0.4.0 — Live Testing Report

2 November 2026. Eldritch Arts 0.4.0 on TRG Prime 3.679.0, Foundry V14, world "TRG V14", as Gamemaster in Chrome. Inner Tempest, Pillars of Faith and Fiends & Fables were active.

**Throwaway material, all deleted afterwards:**
- the scene "ZZ EA Block 2b", with a level-4 Magic Suppression area ("ZZ Hush") and a level-20 one ("ZZ Null Vault");
- the actors "ZZ EA Primary", "ZZ EA Second" and "ZZ EA Lender", copies of Borin Slatevein (Wizard, arcane, CL 4, Arcana 4 ranks);
- on the Primary: a Ritual Censor, a Runestone Chalkboard, Ward Twine, and the spells "ZZ EA Rite" (Mage Armour with the Ritual trait, flagged as Eldritch Arts') and "ZZ EA Calling" (Sleep with the Summons trait);
- on the Lender: "ZZ EA Lent Bolt" (a Fire Bolt copy).

Dice were steered with `CONFIG.Dice.randomUniform` and restored afterwards (five d20s rolled at random after). The 47 test chat cards, the scene and the actors were deleted, and the view went back to Oldwatch Approach. Borin was not touched. There were no console errors from TRG Prime or Eldritch Arts.

## Results

| # | Test | Result |
|---|---|---|
| 1 | Load: versions, the three new actions, the ritual rules, the three casting options, the Ritual-spell refusal, the circle's gate, the four helpers | **Pass.** 3.679.0 and 0.4.0. |
| 2 | The Magic Ritual dialog | **Pass.** "How the PP is paid" with the three variants; the scene's other creatures as secondaries (not the primary); the Censor and Chalkboard, which were carried, as ticks; the Ritual Expert field. |
| 3 | A standard ritual of Sleep (2 PP) with the Censor and Chalkboard | **Pass.** DC 12 "(Ritual Censor −1)", Chalkboard +1 on the check; 5 gp of incense taken (495.4 gp left); PP 13 → 11 paid by the primary; Heroic capped to Success. |
| 4 | A vital sacrifice, one secondary ticked | **Pass.** Arcana against "Level DC (level 4), Very Hard +5" = 23; the primary's PP unchanged; Primary 2d8 = 8 and Second 2d4 = 4 essence, each a Fortitude save against their own level DC (18); the plan cleared. |
| 5 | A material sacrifice, Success (Mage Armour, 2 PP) | **Pass.** 60 gp taken; PP unchanged. |
| 6 | A communal offering | **Pass.** ZZ EA Second paid 3 PP (2 + 50%); the primary's PP unchanged. |
| 7 | A material sacrifice, Failure | **Pass.** No Casting Conditions prompt for the failed casting; half the PP (1) substituted: 30 gp. |
| 8 | Refusals before the roll | **Pass.** Each was refused with nothing rolled: "tick each secondary caster taking part (2 entered, 1 ticked)", and "the material sacrifice for 2 PP is 60 gp, and ZZ EA Primary has 10 gp". |
| 9 | Ritual Experts: 3 typed, 1 secondary row | **Pass.** Capped at 1 extra seat (2 casters counted). |
| 10 | A ritual in the level-4 Suppression area | **Pass.** "Magic Suppression (level 4) −4" on the ritual check itself; its line once, on the ritual card. 0.3.0's gap is closed. |
| 11 | A ritual in the antimagic zone | **Pass.** Refused before its dialog; nothing rolled. 0.3.0's gap is closed. |
| 12 | An Eldritch Arts Ritual spell (Q8, M30) | **Pass.** A normal cast is refused ("may only be attempted as part of a ritual"); in a ritual a natural 20 stood as Heroic ("a Ritual spell: not capped at Success") and cast as Heroic (1 PP). |
| 13 | Inscribe Summoning Circle, creature level 3, aligned ground, meticulous, Ward Twine | **Pass.** DC 11 (17 − 4 − 2); Ward Twine offered because it was carried; on a Critical, the circle effect for 4 hours (1 per caster level); "60 minutes to draw". |
| 14 | A Summons spell from the circle, with true name and Spell Trickery | **Pass.** The prompt applied the circle's "+3 Save DC" without a tick and offered the two options. The casting DC got "(Spell Trickery +2)" and the check "Summoning circle (critical) +4" circumstance. The Save DC was 24 (Sleep's 17 + 3 + 4). |
| 15 | The true name's hostility | **Pass.** ZZ EA Second saved (a natural 20) and now carries "Permanently hostile to ZZ EA Primary"; the card says so. |
| 16 | See Through Spell Trickery, the Second targeting the Primary | **Pass.** Sense Motive against "Target's deception DC" 10; the printed Success line. |
| 17 | Borrow Spell | **Pass.** Only the Lender's unknown spell was offered. The DC was the one to learn it (22), Easy (−2). On a Success, the copy is in the book: unprepared, not innate, marked borrowed, kept out of the free ladder. |
| 18 | A new day (`trgPrimeDailyPreparation`) | **Pass.** The borrowed spell left the book, with a card. |

## Findings

- **Cosmetic, TRG Prime:** a ritual variant's cast card still says "2 PP spent" (or "1 PP lost" on a Failure), though those PP were substituted and the pool was not touched. The sacrifice's own card says what was paid. To be worded in the next core release.
- **Not a defect:** the core ritual dialog defaults every secondary row to Success, so six secondaries are counted unless the empty rows are cleared (as before 3.679.0).
- **Not a defect:** a material sacrifice's or the Censor's gold is taken by the core's purse helper, which regroups the coins (500 gp became 4 mp, 9 pp, 5 gp, 4 sp), as Learn a Spell does.

## Not tested live (covered by the harnesses)

- a Blunder or Fumble ritual and its fumble roll;
- a non-caster primary (Caster Level 0) and the cap refused before the roll;
- a held rod and Spell Storing beside a variant;
- a secondary not owned by the user;
- Void Chalk;
- a Fumble circle's hostile summoning;
- Borrow Spell's Failure bar;
- several lenders.
