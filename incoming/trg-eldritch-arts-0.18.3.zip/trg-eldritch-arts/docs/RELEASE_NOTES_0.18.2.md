# Eldritch Arts 0.18.2 — Graham's rulings on Block 11

25 November 2026. Needs **TRG Prime 3.713.1** (prepared beside it) for the multi-tradition ruling. Everything else runs on 3.713.0. Not yet tested live.

## What changes

| Ruling | Before (0.18.1) | Now |
|---|---|---|
| **A11-1** Advanced Design: a typo | The card printed "+1 bonus to items". | The card reads "+1 bonus to two items or a +2 bonus to a single item". The rule was already built this way. |
| **A11-2** Integrated Modularity: any combination of +3 | One bonus per item. | An item's share may be split between its two bonuses: a weapon's attack and damage, or armour's DB and DR. For example a sword at +2 attack and +1 damage, or +3 on one bonus. Modular Design and Advanced Design stay at one bonus per item. Quick Swap and Advanced Design's swap move one bonus at a time, and may land on an item that has the other bonus. |
| **A11-3** Flash of Insight: once a day, not Prepared | Prepared, with a recharge that restored readiness but not the day's use. | Not Prepared: no trait, no Prepared card, no recharge. Asked while today's use remains. |
| **A11-7** The rebuild's cost | No gold taken; the GM deducted it. | The Equipment Cost Table (Core Rulebook p. 173) at the master's level, from the master's purse (level 6: 1,000 gp). If they cannot pay, the rebuild is refused and nothing is lost. |
| **A11-8** The assistant | Core's familiar picks could still be added on its sheet; Scout Optics' Tracking was unmapped. | It takes only the improvements its Use offers, plus Core's own grants for its race (Empathic Link). Any other ability or feat added to it is refused with a notice. Scout Optics also makes **Survival** a class skill. |
| **A11-9** Triggered Sigil: during daily preparation | Designated at any time once the sigils were inscribed. | Designated only during daily preparation: from the preparation until the first spell cast, entering combat or an hour later. The daily card says so. |
| **A11-16** Multi-tradition spells | Fear cast by a Wizard still asked Heritage of the First Weave (and took Forbidden Magic's −2). | **TRG Prime 3.713.1** tells the save only the caster's tradition, when it is one the spell lists. A Wizard's Fear is arcane: no First Weave prompt and no −2. A Druid's is verdant: both apply. |
| Power Sink's card | Claimed an overloaded item's uses were refused. | Says what happens: its effects stop counting; its own use buttons and its runes' bonuses do not (there is no Core seam for that). |

Unchanged, as ruled: A11-4 (Flash of Insight at 30 ft), A11-5 (Power Sink), A11-10 (Emergency Contraption), A11-12 (damage typing), A11-14 (Ley Resonance as a Focus ability), and natural armour scaling.

## Still open

See the audit's §3a:
- A11-6: the Prepared recharge's degree.
- A11-11: shields as armour.
- A11-13 and A11-15: not yet answered.
- The assistant's DB: derived, 17 at master level 6; the printed 15 assumes Dex +3.

## Tests

- `verify-block11`: 399 checks. The new section L covers each ruling; A2, B1–B3, B14, B31, E10, G14 and J7 were updated to the rulings.
- `mutate-block11`: 76 mutations, all caught. Ten are new; seven older anchors were moved to the rewritten code.
- All `verify-*` pass except `verify-block10`; 27 of 30 `mutate-*` pass, all but `mutate-block10`, `mutate-block10b` and `mutate-book-extract`. All four failed before 0.18.0.
- TRG Prime 3.713.1: see its release notes. Its full 404-file verify sweep is green.
