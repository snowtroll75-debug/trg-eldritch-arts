# Live test: TRG Prime 3.692.0 and Eldritch Arts 0.16.0

15 November 2026, in Graham's world on Foundry 14.367, as the GM "Testing Dude".

**Test setup:**
- Throwaway ZZ copies of Borin Slatevein (a caster and a foe), on a throwaway ZZ scene.
- Dice fixed where an outcome was needed.
- The test copies of the five spells were set to 2 PP and made componentless, so a level 5 caster could cast them without overcasting.

**Cleanup:** 52 messages, the scene, the two actors and the combat were removed. World time and the view (7PRGFQE0DAp7ThIJ) were restored, and the game was left paused. Graham's own actors were not touched.

## Results

| What | Result |
|---|---|
| **Region light (core)** | **Pass.** A Region carrying `emitsLight` level 5 was placed over a token. Inside it the token read: 8 in a bright scene, 5 in Pitch Black (outside the Region: 3), 5 in Supernatural Darkness, and 1 in Abyssal Darkness. The source was named on the result. |
| **Arcane Mycelium (EA)** | **Fail, fixed in 0.16.1.** The real cast placed its 10-ft area, and the core made it difficult terrain, renaming it "Arcane Mycelium (difficult terrain)". The module looks for "Arcane Mycelium Area", so the Region was never stamped: no light, and no reactive warp. |
| **Eaog Balls: Success** | **Pass.** The foe saved with a Success. Its land speed went from 20 to 10, through a relayed effect carrying `movementHalved` under the cast. The card said "speed is halved (1 minute (S))". Ending the spell took the effect away, and the speed returned to 20. The Critical row was not reachable with these dice (a +8 save against DC 19). |
| **Eaog Balls: Partial** | **Pass.** The foe was immobilised (m42), with no halving. |
| **Glyph of Retribution, +4 PP option** | **Pass.** One thorns row was laid, carrying the four types; the sonic row was superseded. The foe struck with a Greatsword, and its Fortitude save fumbled. The wearer was asked the type and chose Fire. Card: "ZZ Foe takes 10 fire … ZZ Caster chose fire". |
| **Glyph: question closed unanswered** | **Pass.** "10 sonic … no type chosen; the printed sonic stands." |
| **Spirit Arrow, Trip, out of combat** | **Pass.** The longbow Strike hit at 19, a minor critical, dealing 7d6 flat. The core resolved the chosen Trip at the attack total: "Trip against ZZ Foe at the attack total 19 vs DC 16: success — prone". The foe failed the Will save by 2 and was frightened 1. |
| **Spirit Arrow, Grapple (1 round), in combat** | **Pass.** "Grapple … at the attack total 19 vs DC 16: success — grabbed". The condition expires in round 2 (cast in round 1), and `grabbedBy` names the archer. |
| **Metamagic Resonance, change option** | **Pass.** The `swap` option was recorded with the cast. On the first Sustain the caster was asked and kept Economic Spell, so nothing changed. On the second the caster chose Heighten Spell: the card said "The resonance changes…", and the ally in the aura was now lent Heighten Spell. |

**Not tested live** (each covered by the harness):
- A player's cast on the GM's creature, through the relay. Only one client was available.
- Effortless Spell's Sustain.
- An innate spell not being stored.
- A mundane ritual's catalysts.

## Notes

- The test copies are Load 1 longbows: a second Strike needs a reload, as printed.
- Graham's two answers ("go with your recommendation") are in 0.16.1: Spirit Arrow's Fumble kept as built; the Chalkboard and the Bowl dropped on a tradition-skill ritual.
