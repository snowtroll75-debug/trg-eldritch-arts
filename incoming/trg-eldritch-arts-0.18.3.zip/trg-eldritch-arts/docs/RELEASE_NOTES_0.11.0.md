# Eldritch Arts 0.11.0

8 November 2026. **Block 8a: the second half of Chapter 8's Grimoire, first part.** It ships 22 spells: the eight Bindings, the three new Symbols and eleven utility spells. It also brings the shipped Symbol of Death and Symbol of Fear onto the same model, Versatile Binder onto the Bindings, and Ley Line Effects rows 25–27 onto the control register.

It was built from `ELDRITCH_ARTS_BLOCK8_AUDIT.md` as Graham answered it on 8 November (17:22, "As recommended"). Q167–Q184 are built as each row recommends, and seams H12–H18 are approved. H12, H17 and H18 are in TRG Prime 3.686.0. H13–H16 belong to Block 8b (EA 0.12.0 on TRG Prime 3.687.0), with the ten rituals and the seven Chapter 7 High Magic spells (Q167: two releases).

**Confirmed by Graham, 9 November 2026 (10:01–10:02):** the "varies" Symbol reading ("Yes") and every other reading under "Readings to know about" are kept as built ("happy with all eight as built"), with the core's eight walls left unchanged.

- **Install TRG Prime 3.686.0 first, then this over 0.10.1.** On anything older the module warns. 3.686.0 also changes two core spells in every world: Remove Curse now counteracts curses, and Insanity rolls its d10 each turn. See its release notes.
- **No migration and no new settings. Loading a world changes nothing on any sheet.**
- **The spells are in "Eldritch Arts: Spells"** (now 113). Every Grimoire spell is uncommon (m84).
- **Already on a sheet:**
  - A Symbol of Death or Symbol of Fear added before 0.11.0 keeps its old card and its note until it is re-added from the pack (nothing rewrites an owned item).
  - Versatile Binder needs nothing: its new behaviour is in the module code, and its card refreshes from the pack.

## The models

**The Bindings** (Animal, Elemental, Entity, Eternal, Fey, Plant, Undead, Wyrm; Q168, Q169).
- **No creature is invented.** TRG Prime ships no stat blocks. Once the cast is settled, a GM-only card asks for the creature. The GM places a token for a creature of the binding's trait (the Creature Codex builds one, and Fiends & Fables has many) and selects it, or selects one already there. Then the GM presses **Bind**.
- **The checks:** the creature's trait, its level (the printed maximum, +1 per warp bought; no other ceiling than your maximum PP per cast) and the 30 ft are checked first. A refusal says which check failed.
- **The save:** the creature rolls its Will save against the cast's own Save DC, with a summoning circle's and Ward Twine's bonuses and a true name's +4 in (Block 2b).
- **The results:**
  - **Critical** (and Heroic, m42): it arrives hostile and the spell ends. It stays, and the GM runs it.
  - **Success:** it acts freely, counts against no control levels, and is sent back when you dismiss the spell.
  - **Failure** (and Partial): it is bound. It is recorded on your control register as "Bound" (TRG Prime 3.686.0, H12) and carries a "Bound to you" effect.
  - **Fumble** (and Blunder): bound, and +2 circumstance to all its checks while it serves (Q169).
  - A true name invoked with a Success or better makes it permanently hostile to you (Block 2b).
  - A Fumble summoning circle brings it hostile and unbound, whatever it rolls. Block 2b's own circle card is not posted for a Binding; the binding's card says it.
- **The duration:** "Until dismissed" (or "or broken") locks the PP until the spell ends (Q170, TRG Prime 3.686.0), so Dismiss reaches it.
- **Breaking free:** over your Control Levels, the core's DC 20 Will save at the start of each of your turns breaks the highest-level creature free. That now ends its binding: TRG Prime's release hook tells the module, and the spell ends.
- **Every end alike:** breaking free, a dismissal, a dispel or a counteract ends the spell. The entry and the effect are removed, and the card says the creature returns to where it was summoned from (all eight alike, Q168, Q169).
- **By hand:** the command (1 AP, verbal, auditory and concentrate; Q169), and the GM removing a returned creature's token.

**The Symbols** (Insanity, Pain, Weakness; Death and Fear rebuilt; Q183, Q184). One model for all five:
- **Placing it:** you click where you carve it. A one-square Region, hidden from players, marks it for the symbol's duration.
- **The flash:** the GM's card **Flash** button lists every token with line of sight to it (walls block). The GM can untick a creature, for instance one that did not look. Each creature listed rolls the save at the symbol's own DC. The book's only trigger is a character moving within line of sight and looking, so the flash is the GM's button alone.
- **The glow:** after a flash the symbol glows until no character has had line of sight to it for 10 minutes of world time (for Symbol of Death, no *living* character, as printed). Every scene is swept, not only the one the GM is viewing. On a scene nobody is viewing, line of sight cannot be read (the walls are not loaded), so the glow is left as it is while any token is there, and ends once 10 minutes pass with no token there at all.
- **Insanity:** Will save. A Partial or worse is a failure. A failure marks the creature with core Insanity's own d10 table for 1 round per 2 points it failed by (TRG Prime 3.686.0, H18).
- **Pain:** Fortitude save, then unaffected, injured 2 or injured 4.
- **Weakness:** Fortitude save, then unaffected, weakened 1, 2, 4 or 6.
- **The curse's hold (Pain, Weakness):** the condition is held by a curse effect (TRG Prime 3.686.0, H17). Rest, recovery and relief cannot lower it while the creature is within 60 ft of the symbol, or within 1 hour after it leaves that range. When the hour is up the hold ends, and the value it added is taken off. Only Remove Curse ends it sooner (Q183). Remove Curse is rolled against the symbol's PP and DC.
- **A later result:** a worse result replaces a better one. Injured adds the difference, and weakened keeps the higher value. An equal or better result leaves the hold as it is.
- **Death:** Fortitude save for each character with line of sight, as printed. A Failure is a deadly essence critical, rolled with the symbol's DC as its attack bonus, as the core's own save-spell criticals are. A Fumble is death. A death ends the symbol (m132). Its "Permanent" duration locks the PP while it lasts. "Living" is printed only for the glow, and only the glow counts it.
- **Fear:** Will save, then unaffected, frightened 2, frightened 4 and fleeing 1 round, or frightened 6 and fleeing 1 round.
- **Removing it:** a GM button removes the symbol and its Region.
- **Dismissing it:** Symbol of Death is the only symbol whose duration registers a cast ("Permanent"). When that cast leaves its caster's active spells (dismissed, dispelled), the acting GM removes the symbol's Region on whichever scene it is on, and a Flash pressed afterwards is refused. Insanity, Pain, Weakness and Fear print "varies", register no cast, and cannot be dismissed; the GM's Remove button ends them.

## The utilities

- **Arcane Pouch:** an object target (no creature picker). It grants +1 circumstance to your Conceal an Object checks for the duration. A new casting ends the last one. It is registered as a later teleport, so its cast posts no Spatial Awareness card: it moves no creature.
- **Archway of Ants:** you click its six squares (+1 a warp) within 30 ft. They make a Region labelled with DB 10, HP equal to your maximum HP, and its load (10 × your Weight Allowance). It lasts 10 minutes, and a GM button crumbles it.
- **Argent Mark:** a willing creature within touch (m96) or a named object. It lasts 1 week, 1 month, 1 year or permanently (a permanent mark locks the PP, Q170). A button on your card gives the mark's direction and distance when it is on the same scene.
- **Blood Biography:** a GM card. When the blood's owner is living or undead, it rolls a Will save against your Save DC, and a Success or better blocks the spell (M35). Otherwise there is no save.
- **Harmonic Rift:** you click two 5-ft openings within 500 ft and in your line of sight. A token that ends a move in one opening steps out of the other. Each passage is a teleport: it posts the Spatial Awareness card, and a second teleport in a turn fails.
  - An enemy of yours that passes rolls a basic Fortitude save against 3d8 sonic (+1d8 a warp).
  - It lasts 1 minute (10 minutes warped).
  - The module moves the token itself; no Teleport Token Region behaviour is used.
- **Riserune:** a hidden 10-ft Region where you inscribe it, for 1 hour. A Small or larger token that ends a move in it is recorded (name, image and time), up to 3. Your card's button replays the record when you are within reach.
- **Wall of Sand:** the core's wall, 20 × 10 ft along its borders. It limits sight but does not block movement. Its sections have DB 0, Hardness 5 and HP 20 (+5 a warp). The printed "+2 PP: increase the length of the wall by 10 feet or its height by 5 feet" is offered as its two choices, each +2 PP: +10 ft long, or +5 ft high (TRG Prime 3.686.0's `wallHeight`).
- **Farsight, Phase Door, Rippling Gaze, Traveller's Charm:** card only. Farsight's 1-hour warp sets the duration, Rippling Gaze shows its Requirement on the cast, and Traveller's Charm takes an object target.

## Changed in earlier blocks (Q184)

- **Symbol of Death and Symbol of Fear** (0.5.0, the Rune birthright's): rebuilt on the Symbol model, D → B. Their save is rolled when the GM flashes the symbol, never at the cast (they print no defence).
- **Versatile Binder** (0.9.0), C → B:
  - On a Binding it rolls no save of its own. It hands the chosen creature to the binding, which binds it by its own trait, level and range checks and its own Will save (Q133, Q184). The creature is then on the control register like any bound creature, and on the end it is released where it stands.
  - Only the eight Bindings carry the Summons trait (no core spell does). A Summons spell from another module still takes the 0.9.0 path: the save on the card, control by hand.
- **Ley Line Effects 25–27** (Block 2a): "Your summoned creatures gain +1 AB" and the backlash "Summons are Stunned 1" now reach the creatures your control register holds as Bound or Conjured. An entry with no token is counted and left to the table, and an empty register says so. Before, the row was by hand.
- **Invoke True Name's hostility** (Block 2b) and the binding read the same rule (`trueNameHostile`), so a true name's binding and its permanent hostility agree.
- **The GM relay** (Block 7) may delete the module's "Bound to you" effect.

## How much is automated

A: full · B: automated, with a normal choice or prompt · C: partly, one clause left to the GM and said on the card · D: the item and its card only.

| Spell | Grade | Left to the table |
|---|---|---|
| Animal, Elemental, Entity, Eternal, Fey, Plant, Undead, Wyrm Binding (8) | **B** | The creature's token (the GM places it); the command; removing a returned creature |
| Symbol of Insanity | **B** | The GM's flash and its untick |
| Symbol of Pain | **B** | The GM's flash and its untick |
| Symbol of Weakness | **B** | The GM's flash and its untick |
| Harmonic Rift | **B** | Nothing beyond the two clicks |
| Arcane Pouch | **C** | The 50 lb and 3 lb limits |
| Archway of Ants | **C** | Moving the archway and the load |
| Argent Mark | **C** | Finding it beyond the scene; an object's mark is named, not placed |
| Blood Biography | **C** | The four answers (the GM's) |
| Riserune | **C** | Disarming it |
| Wall of Sand | **C** | The crossing cost, line of effect, projectiles and reforming (the height warp is shown on the wall's line; height has no other effect in the core) |
| Farsight, Phase Door, Rippling Gaze, Traveller's Charm | **D** | The card only |
| **The 22** | **0 A · 12 B · 6 C · 4 D** | |
| *The audit's estimate (§3.2, with H12, H17, H18)* | *0 A · 12 B · 6 C · 4 D* | *every spell at its audit grade* |
| Symbol of Death, Symbol of Fear (rebuilt) | D → **B** | The GM's flash |
| Versatile Binder (rebuilt) | C → **B** | The command, as for any bound creature |

Each card says what is automated and what is not, in the same words as this table.

## Fixed in review (before release)

An independent review of Block 8a found twelve issues; all are fixed in this release, with checks that the mutations show can fail.
1. **Remove Curse on a creature the caster does not own** (TRG Prime): the counteracted effect is now deleted through the GM (a new named relay action, whose GM side re-reads the effect's traits). Before, a player's Remove Curse on the GM's NPC failed with a permission error. This holds for every counteract row.
2. **Insanity's turn table took away another spell's condition** (TRG Prime): a creature already Confused that rolled "confused" lost its Confusion at the next roll. The turn table now keeps its own books (see below); the general condition path is left exactly as in TRG Prime 3.685.3.
3. **Symbol of Death's critical** was rolled with no attack bonus, so its Death and Fatal saves were against DC 10. It now carries the symbol's DC.
4. **Three relief paths ignored the curse's hold** (TRG Prime): Renewal's Touch's turn option, the healing rune's reduction and a `conditionRemove` row (Sunveil and its kin). Each now refuses out loud; Renewal's Touch refuses before its AP are spent, and the rune spends no use. Because the relief is refused, the hold's end takes its share off once, not twice.
5. **A dismissed Symbol of Death** kept its Region and its working Flash button. See "Dismissing it" above.
6. **Insanity never ended outside combat** (TRG Prime): its marker and each roll's condition now carry a world-clock end, as every round-based spell effect in the core does.
7. **These notes described a touch button** that does not exist; the book has no touch trigger. The line is gone.
8. **These notes said Symbol of Death affects living creatures only.** The book's "living" is the glow's; the code already read it so. Corrected above.
9. **A held fatigue's card said "reduces by 1"** while the value stayed (TRG Prime). It now says the hold and the value it stays at, and returns that value.
10. **Wall of Sand's length-or-height warp** offered only the length. Both choices are offered.
11. **Scenes and owners:** the curse's hour and a rift's passage needed the token on the acting client's canvas; they now read its document. The glow and the areas' expiry looked only at the GM's current scene; they now sweep every scene.
12. **Two GMs could bind the same creature twice.** Only the acting GM binds, and the record is claimed before the save.

A re-review confirmed ten of the twelve and found what was left:
- **Insanity still removed another spell's condition, through the world clock** (TRG Prime). A roll's 1-round clock was written onto a standing Confusion. Two attempts to fix it in the general condition path opened new problems in every world, so that path is back to 3.685.3's, byte for byte. Insanity's turn table now keeps its own books:
  - A condition the creature lacks is laid with the roll's own id, and goes at the next roll or when the marker ends.
  - A condition it already has keeps its cast id, its clock and its duration. A valued one has only its value raised, and the rise is recorded on the marker and taken back by the condition's own stacking rule. Slowed and stunned go back only while they still stand at the roll's value; an adding condition loses the roll's rise, never below what it was. An unvalued one is left as it is.
  - Insanity's marker has no world-clock end only while the creature is itself a combatant in a started combat. Any other creature gets rounds × 6 seconds. A combatant removed from the tracker, or its combat deleted, is clocked then (only the removed combatant is ignored, so a linked actor's second combatant still counts). A creature that joins a started combat, or whose combat starts, loses a clock laid before. A 1-round insanity is no longer swept before its first roll.
  - Symbol of Insanity's flash takes the same path.
- **The rift's destination** uses its scene's own grid, not the canvas's.
- **A binding stuck at "binding"** (a client dropped during the save) can be taken over by the acting GM.

## Readings to know about (for Graham)

Each is said on the spell's card.
- **A Symbol's "varies" duration:** the symbol lasts until the GM removes it, and no PP are locked. Symbol of Death's "Permanent" locks them (Q170).
- **Insanity's per-roll conditions** last that turn (TRG Prime 3.686.0's reading of "this round").
- **Riserune after 3 triggers** records no more, but stays replayable for its hour.
- **Argent Mark:** when more than one duration is bought, the longest applies, and the PP of all are charged.
- **Commanding a bound creature** is by hand. The command is 1 AP, verbal, auditory and concentrate (Q169), spent from your sheet. The module does not move or act for the creature.
- **Q170 needed a core change outside the approved seams.** TRG Prime 3.686.0 reads "until dismissed" as an unlimited lock (one line in `ppLockCondition`). No core spell prints it. Without it the Bindings lock no PP and Dismiss cannot reach them.
- **The core's own eight walls** (Wall of Stone, Fire, Ice, Force, Thorns, Blades, Light, Dispelling) print the same "length by 10 feet or its height by 5 feet" option and still offer only the length. The new `wallHeight` key would let them offer both; changing them changes every world, so they are left for your word.
- **A stale binding claim** is one whose GM is no longer connected or that is older than two minutes. The two minutes is the module's choice; the book has nothing on it.
- **An unviewed scene's glow** is left as it is while any token stands on that scene (line of sight cannot be read without its walls on the canvas).
- **The extractor's Cost line is not fixed.** No 8a spell prints a Cost; the rituals of Block 8b do, and it is fixed there.

## Multiple clients

Each world-changing step runs on one client:
- The binding's marker, end and broken handling, and the hold's hour run on the caster's or creature's acting client (`actsFor`: the player owner first, else the GM). The hour and a rift's passage read the token's document and its scene's own grid, so they work on a client that is not viewing that scene.
- The flash, the glow, the Regions' expiry, a dismissed symbol's removal and the Riserune record run on the acting GM. The glow and the expiry sweep every scene.
- **Binding the creature:** with two GMs connected, only the acting GM's press binds. The record is claimed before the Will save is rolled, with who pressed and when, so a double press rolls one save and makes one binding. If the claiming client drops during the save, the acting GM may press again and take the claim over: either the claimer is no longer connected, or the claim is older than two minutes. The card says so.
- Writes on a creature the client does not own go through TRG Prime's `createEffectsOn` relay, or Block 7's GM relay for deletes.
- Card buttons are GM-only or owner-only, as each says.

## Harnesses

- **New pair:** `tools/verify-block8a.mjs` (338 checks) and `tools/mutate-block8a.mjs` (137 mutations).
  - Each spell's card against the book, and every printed number.
  - The Binding model driven through TRG Prime's real control register: the bind, the loyal bonus, the overflow release ending the cast, a true name, a Fumble circle, Versatile Binder.
  - The Symbols driven: the flash, line of sight, the hold, a worse and an equal later result, the hour, Remove Curse's counteract against the hold, the glow.
  - The utilities, the Ley Line rows, the one-client guards and the wiring.
  - The review's findings (section G): a dismissed Symbol of Death refused and its Region swept on every scene (and a "varies" symbol left); a rift's passage and the curse's hour from a token document with no placeable; the distance to a token's edge on its scene's grid; the expiry and the glow on an unviewed scene; a second GM refused; two presses at once binding once (with the record's write deferred, as Foundry's is); Symbol of Death's critical carrying its DC; Wall of Sand's two choices through the core's wall; the re-review's: the rift's landing on a 200-px scene, the claim's user and time, a fresh claim standing, a dropped GM's claim taken over by the acting GM only.
- **Re-pinned:**
  - `verify-block2`: the `summons` row kind and the row counts.
  - `verify-block6d`: Versatile Binder is B, and the B mark accepts its 0.11.0 card.
  - `verify-block6-lead`: the versions and pack counts.
  - `verify-block7`: the version.
  - `verify-book-extract`: Block 8a's names.
  - `verify-fixes-0101`: the three new object-target spells.
- **Re-anchored mutations:** the version anchors point at 0.11.0 and 3.686.0. The packs line anchor in `mutate-block1` and `mutate-block6-lead` now includes `BLOCK8A_PACKS`.
- **Run** (8 November, on TRG Prime 3.686.0):
  - Every module `verify-*`: 21 files, 5,333 checks, 0 failures (`verify-block8a` 338).
  - Every `mutate-*`, in a scratch copy: 21 files, 2,137 mutations, all caught (`mutate-block8a` 137).
  - After the review's fixes, and again after the re-review's, the whole module set was run: these are the last counts. One equivalent mutation (a stale claim taken over by a non-acting GM, refused later anyway) was dropped with the redundant guard it tested. Six `mutate-block8a` anchors moved with the fixes and were re-pointed. Four survivors were closed: two equivalent mutations replaced, a Large token's distance added, and the double press driven with a deferred write.
  - Three anchors that the new registration and packs lines had moved were re-pointed and rerun green: `mutate-block1`, `mutate-block6-lead`, `mutate-block7`.
