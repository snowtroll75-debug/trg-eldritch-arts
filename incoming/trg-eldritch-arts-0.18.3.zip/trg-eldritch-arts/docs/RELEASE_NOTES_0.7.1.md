# Eldritch Arts 0.7.1

3 November 2026. Fixes the findings from the 0.7.0 live test (`LIVE_TESTING_REPORT_0.7.0.md`).

- **Install TRG Prime 3.682.1 first, then this over 0.7.0.** 3.682.1 carries the Battle Mage fix. On anything older the module warns.
- **No migration and no new settings.** The four spells below are fixed in the compendium. A copy already on an actor keeps its old blank range: drag the spell in again from the compendium, or set its range to "see text".

## Fixed

- **Battle Mage applies to the core's attack spells** (TRG Prime 3.682.1). The core's attack spells carry the Attack trait as their category, which 3.682.0's seam didn't read. Nothing in the module changed for this.
- **Four Spellblade spells were refused when a creature was targeted.**
  - **Which:** Shooting Star, Shielding Strike, Spinning Weapon and Thunderous Strike. None prints a range.
  - **Before:** a blank range is read by the core as "self", so the cast was refused ("beyond … range of self") whenever the caster had anything targeted.
  - **Now:** their range is "see text", which the core doesn't gate. The Strike's reach is the module's: the weapon's, or Shooting Star's 30 ft. Thunderous Strike's cone runs 15 ft past whatever its Strike hits.
  - **Dimensional Assault** keeps its printed "half your land speed".
- **AP was charged to a creature outside the combat.**
  - **Before:** the module charged AP whenever any combat had started, so a creature not in it paid as well.
  - **Now:** only an actor in a started combat pays.
  - **Where:** Block 4's Dimensional Step and Thunderous Strike; Block 1's AP charge (its actions) and Elemental Symbiosis; Block 3's Dragon Claws and Gale Step.

## Found in review (independent, before release)

- **An unlinked token counted as fighting when another token of the same creature was.** The module matched a combatant by its base actor's id, which every unlinked token shares. So if one goblin was in the combat, another goblin token outside it paid AP too. A token is now in the combat only as itself, as the core reads it. This also decides which clock an effect's "until your next turn" uses.
- **Noted, not changed:**
  - **Reach Spell** is now offered on the four spells (doubling "see text"), for 2 PP and to no effect. Dimensional Assault already had it. Don't buy it on these.
  - **A creature in a combat that isn't the one being viewed** counts as out of combat, as it does in the core.
  - **Two questions for Graham, neither changed:** should Battle Mage cover a maneuver spell's Spellcraft check (Tanglefoot, Spectral Grasp, Telekinetic Manoeuvre), and Spiritual Weapon's strikes? Neither has the Attack trait, so as written it doesn't.

## Noted, not changed

- The Spellblade's memorisation panel shows "Cantrips 0/4". The class has no cantrips; the 4 is the core's default, shown when a class sets no daily cantrips.

## Harness

- **`verify-block4`:** 108 checks pass, up from 103. New:
  - a creature outside the combat pays no AP, for Dimensional Step and Block 1's helper;
  - the four Strike spells' ranges are "see text";
  - an unlinked token is in the combat as itself only.
- **`mutate-block4`:** 86 of 86 caught, up from 81. New: the AP gate made global again (Blocks 1 and 4); Thunderous Strike's and Shooting Star's ranges removed; a combatant matched by its base actor's id. One re-anchored to the renamed AP helper.
- **The other module harnesses, still green on TRG Prime 3.682.1:**

  | Harness | Checks | Mutations caught |
  |---|---|---|
  | `verify-block1` | 883 | 86 of 86 |
  | `verify-block2` | 131 | 75 of 75 |
  | `verify-block2b` | 91 | 81 of 81 |
  | `verify-block3` | 302 | 83 of 83 |
  | `verify-block3b` | 87 | 83 of 83 |

- **Version pins** moved to 0.7.1 and 3.682.1 in `mutate-block1` to `mutate-block4`.
- **An independent review of the patch** (both trees) found the token match above, now fixed, and the notes. It confirmed the core's category "attack" is its own test for a spell attack, and that every other module spell with a blank range is one cast on the caster.
