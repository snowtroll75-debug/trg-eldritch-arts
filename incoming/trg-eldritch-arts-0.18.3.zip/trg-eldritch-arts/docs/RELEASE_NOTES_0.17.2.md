# Eldritch Arts 0.17.2: two display fixes from the 0.17.1 live test

16 November 2026. **Still needs TRG Prime 3.694.0.** No rules change.

## Fixes

- **A drawn table result shows its text once.** The sentient-item tables' results printed their text twice in chat: once as the result's name in bold, then again as its description. The text is now only the name, so the card and the table sheet show it once.
- **A rules journal page no longer repeats its heading.** Every page that opens with the book's own heading, such as "WILD MAGIC AREAS", now hides the page title above it. The page names still head the journal's contents list. "Design a Sentient Item" has no book heading, so it keeps its title.

## The harness

- `verify-block10b` gains three checks: each result's text is its name only; each page's title shows only where no book heading opens it; and every page with a hidden title does open with a heading.
- `mutate-block10b` gains four mutations: the text printed twice, every title shown, the design page's title hidden, and a `#` heading not recognised. A first version of the "no title shown" mutation could not change the outcome, and the run caught that; it was replaced.
- Version pins raised to 0.17.2.
- **All 29 module verifiers** pass on TRG Prime 3.694.0, and **all 28 mutation files** catch every mutation (`mutate-block10b`: 25).
- **Independent review:** found no defects. It confirmed:
  - the compiled tables match the source;
  - every page's title setting matches whether the book's heading opens it;
  - no mutation is left unchanged by the version raise.
