# Eldritch Arts 0.17.3: the Archmage and the Spellblade get the Spellbook

24 November 2026. Previous version: 0.17.2. Document ids are unchanged.

- **The request.** Graham, 24 November 2026: every book caster gets the core's one free Spellbook ("keeping it to one item makes things much easier in the long run"). The Spellblade is included too.
- **What changed.** The Archmage and the Spellblade now name "Spellbook" in their Granted Gear. It comes from the core gear pack the moment the class is applied. Its own sheet carries the book's growth and Add to Book, as the Wizard's does.
  - Before this, neither class was given any book item.
- **Characters you already have.** TRG Prime 3.712.4's migration gives an existing Archmage's or Spellblade's class the same grant, but only if that grant is still blank. Their Spellbook then arrives on the next grant pass.
- **Core version.** You need TRG Prime **3.712.3 or later**: that is the first core whose gear item is named "Spellbook". On an older core, the grant is reported as not found and nothing else changes. The manifest's minimum stays at 3.694.0.

## Harness

- **New: `verify-spellbook-grant`, 8 checks.**
  - Both classes grant the Spellbook, in the source and in the compiled pack.
  - Only the book casters grant gear.
  - The name resolves, through the real core grant matcher, to the core's spell book container.
- **New: `mutate-spellbook-grant`:** all 5 mutations caught.
- **Full suite against TRG Prime 3.712.4:** 29 of 30 pass.
  - `verify-block10` fails with a TypeError at its line 344 (the Aegis of Valtea relic rewrite).
  - It fails the same way on the unchanged 0.17.2 tree against TRG Prime 3.712.3, so it was already failing before this change.
- **Version pins:** re-pinned to 0.17.3.
