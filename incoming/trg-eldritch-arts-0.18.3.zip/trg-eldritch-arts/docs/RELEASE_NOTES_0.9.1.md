# Eldritch Arts 0.9.1

4 November 2026. Graham's answers after 0.9.0's release, and the live test's one finding.

- **Install TRG Prime 3.684.1 first, then this over 0.9.0.**
- **No migration, and loading a world changes nothing on any sheet.** So three changes reach existing characters only when the item is added again from the compendium: the Witch, the spell images and Shadowmantle (below). A card already on a sheet keeps its old text the same way.

## Changed

- **Every Witch spell is High Magic** (Graham: "All Witch spells are considered to be High Magic").
  - **Before:** the Witch class declared High Magic for her Ethereal and Verdant spells only (Block 3a's D4a).
  - **Now:** it is every spell she casts, her Pact spells included (Q99's reading is widened to match). The class card says so.
  - **An existing Witch:** the class item on her sheet keeps the old setting. Delete it and add "Witch" again from "Eldritch Arts: Classes" to get the new one.
- **Wellspring Conduit counts the PP the spell is cast at** (Graham: "Wellspring Conduit should count the PP cast for that spell"). Its +1d6 per 2 PP now reads base plus warps and metamagic, as Q101 reads the Pacts. This uses TRG Prime 3.684.1's `castPP`. A 3-PP spell warped and cast at 7 PP gives +3d6, not +1d6. Its grade goes from C to B.
- **Spell images** (the 0.9.0 live test's F1). The module's 49 spells used `icons/svg/holy-symbol.svg`, which Foundry V14 doesn't have. Each now uses the core's image for its school, or `icons/svg/book.svg` with no school. A spell already on a sheet keeps the broken image until it is added again.

## With TRG Prime 3.684.1 (the core's own notes have the detail)

- **Same-type bonuses to DB don't stack.** Two of this module's DB rows are typed, as the book prints them, and so stack by type: **Spellblade's Mark** (+1 circumstance against its attacks) and **Shadowmantle** (+1 circumstance against spell attacks in light 5 or less). Each was untyped in 0.9.0 and is typed circumstance in 0.9.1: under another circumstance bonus to DB only the higher applies; beside a status bonus both still add. Both cards say so. The other Block 6 DB bonuses (Void Pact, Iron Ward) were already in the DB's circumstance slot. A Mark is made fresh on each Use, so the next Mark is typed (one already standing stays untyped until it ends); Shadowmantle on a sheet keeps the untyped row until it is added again from the compendium.
- **Two-skill prerequisites are checked for every feat.** In 0.9.0 only three Eldritch Arts feats were flagged for the core to read their two-skill clause: Elemental Exhalation ("Arcana or Nature 8 ranks"), Wyrm Ascendant ("Arcana or Nature 12 ranks") and Lightning Rod ("Arcana or Survival 10 ranks"). Nine others passed open, and from TRG Prime 3.684.1 they are checked too:
  - Elemental Affinity (Nature or Planes 4 ranks);
  - Esoteric Insight (Arcana or Occultism 2 ranks);
  - Esoteric Insight Expert (Arcana or Occultism 5 ranks);
  - Esoteric Insight Master (Arcana or Occultism 8 ranks);
  - Circle Adept (Arcana, Nature, Occultism, or Religion 1 rank);
  - Ley Scholar (Arcana or Nature 1 rank);
  - Runic Stabiliser (Crafting or Linguistics 2 ranks);
  - Spell Feedback (Arcana, Nature, Occultism or Religion 1 rank);
  - Threadcutter (Arcana, Nature, Occultism or Religion 4 ranks).

  The core's own feats (Scribe Scroll and the rest) are checked too. The picker only hides a feat: one already on a sheet stays.
- **Economic Spell and Signature Spell lower what you pay.** They lower the PP the spell is cast at, so they lower Wellspring Conduit's dice too. Another PP discount (G4's) lowers only what you pay, not those dice. Wellspring Conduit's card now says so (0.9.0's said no discount lowered them).

## Harnesses

- **Verifies:** all module verifies pass on TRG Prime 3.684.1, with each mutation caught on a copy of the tree.
- **New checks:**
  - the Witch's High Magic on an arcane and a divinity spell;
  - Wellspring Conduit's dice from `castPP`;
  - Spellblade's Mark's and Shadowmantle's DB rows typed circumstance, and stacked as such (`verify-block6c`, `verify-block6b2`);
  - every spell's image: its school's picture, checked on disk in the core, or `icons/svg/book.svg` (`verify-block6-lead`);
  - every Foundry `icons/` image any pack names (four: `book.svg`, `upgrade.svg`, `aura.svg`, `mystery-man.svg`) is one the core's own code uses, and `book.svg` is the core sheet's own default spell image. There's no Foundry V14 install on the harness, so this is the closest check: it doesn't look the files up in V14 itself.
- **Re-pointed:** `verify-block6a`'s G9 check now expects an unflagged two-skill clause to be read (TRG Prime 3.684.1). Its prerequisite helper now calls the core the way the feat picker does (no `compoundSkills` option).
