# Eldritch Arts 0.15.1: the Wild Surge table, and Spellhold's refused window

14 November 2026. **Needs TRG Prime 3.690.0** (unchanged). This release fixes what the live test of Block 9c (0.15.0) found in Graham's world. The test report is `claude/eldritch-arts-live-testing-report-0.15.0.md`.

## Fixed

- **The Wild Surge table was read from the wrong file at three places.** They took `WILD_SURGE` from `block2-automations.mjs`. That file imports the table but does not export it, so the table read as `undefined` and the roll threw.
  - **The Orb's Resonant Flare** (Block 9c), on a Charge Depletion roll of 41–65. TRG Prime caught the throw, so the orb broke as an ordinary charged item does. There was no flare, and the orb was not left at 0 PP unbroken.
  - **The Rod of Wild Surges** (Block 9c). The rod paid its 1 PP, then there was no surge and no "Rod powers" card. Nothing reported the error.
  - **Warpflare's wild magic on a 6** (Block 9b, since 0.14.0), with the same failure. The 0.14.0 live test did not roll a 6.

  All three now read the table from `chapter7-tables.mjs`.
- **The flare's and the rod's surges now expire.** Every other wild surge in the module lasts 1 round per area level (`forSeconds(6 × level)`). These two passed no expiry, so their effects would never have ended. This is moot until now, since they never ran. Found by the 0.15.1 review.
- **Spellhold no longer says "cast it now" when its window is refused.** TRG Prime refuses a hold window while a Spell Storing window is open, and warns why. The staff's card then still said "Cast the spell to store now, this round", and the store reported itself armed. It now stops at the warning.

## The harness

- **New pair `verify-dynamic-imports`** (68 checks) and **`mutate-dynamic-imports`** (8 mutations, all caught).
  - The verifier checks that every name the module takes from a dynamic `await import("./…")` is one that file exports.
  - It reads three shapes: a destructured import, a property read off an import (`(await import(x)).name`), and a namespace's names (`const ns = await import(x)`, then `ns.name`). Comments are ignored, both for imports and for exports. The independent review asked for the last two shapes and for the comment rule.
  - Each block's own verifier mocked `rollTable`, so none of them could see a missing table. This check reads the files themselves, so it covers every block.
  - The same scan, run on TRG Prime 3.690.0's core, finds nothing.
- `verify-block9c` gains checks for the Spellhold card, the two surges' expiry and the table's source (84 checks); `mutate-block9c` has mutations for them (93, all caught).
- **Independent review:** nothing serious. It confirmed that the fixed sites read the same table object `rollTable` tests against, and that every TRG Prime helper the module calls exists. Its points (the expiry, the verifier's blind spots) are fixed above.
- Manifest pins raised to 0.15.1.
- **All 27 module verifiers** pass on TRG Prime 3.690.0, and **all 26 mutation files** catch every mutation. TRG Prime is unchanged from 3.690.0, so its sweep stands.
