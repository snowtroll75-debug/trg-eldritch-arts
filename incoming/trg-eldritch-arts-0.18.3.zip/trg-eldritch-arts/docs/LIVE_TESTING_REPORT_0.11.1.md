# Live recheck: Eldritch Arts 0.11.1 on TRG Prime 3.686.0

9 November 2026, in Graham's world in Chrome, on Foundry 14.367. I used throwaway actors (ZZ EA Wizard, Foe and Ally) and a throwaway scene, "ZZ EA 0111 Recheck", and cleaned everything up afterwards.

## Result: Harmonic Rift is still wrong

**What happens:**
- A token walking *out* of an opening is still sent through the rift.
- A token walking *into* an opening is not.

The 0.11.1 fix tested the token's position in the right place, but the position it read was stale.

**Root cause, logged live:** in Foundry V14's `updateToken` hook, during a normal (animated) move, the token document still holds its **old** position, and the hook's `change` holds the new one. For example, a foe standing in opening 1 at (100,500) was moved to (1000,1200). The hook saw the document at 100,500. The rift tested the old square, found it inside opening 1, and teleported the foe to opening 2.

**Why the harness and the earlier live test missed it:**
- The harness mocks put the new position on the document.
- Moves made with `animate: false` don't show the problem.

**Also found:**
- **Occupied far opening.** When the far opening is occupied, the core correctly refuses the move ("you cannot end your turn in a space another creature occupies"). But the rift's card still said the ally "steps through the rift".
- **The 0.11.1 guard reads nothing.** It checks for a move still under way by reading `options.movement`, which isn't present on the GM's client. It does no harm.

**Being fixed in 0.11.2:**
- The rift, Riserune and the curse's hour will read the move's destination from the hook's `change`.
- The harness will model V14's old-document, new-change order.
- The card will check that the token actually moved before it says so.

The save line now shows plain text ("Partial (26 vs DC 27) — 12 sonic — now 138 HP."), so that fix from 0.11.1 works.

## A note on Graham's own data

My chat-button helper clicked the newest "No" button in the chat log. Twice that was an old held conviction prompt from 6 November: Keldran Greytrail's Battle Axe attack. Its request had long expired, so the click changed nothing: the message's flags and last-modified time (6 November 12:49) are unchanged, and it is still in the log. The helper is now limited to messages created during the test.

## Cleanup

- **Deleted:** the scene, the three ZZ actors, and the 22 test chat messages. All of them were mine; the world is back to 311 messages.
- **Restored:** the dice, and the view (Oldwatch Approach).
- **Left as found:** the game is still paused, and there are no combats.
