# Eldritch Arts — Core Dependencies

These are the TRG Prime core changes the Eldritch Arts module needs. Each one is a stable, module-facing extension: a registry, a hook or a per-cast mode. None of them puts Eldritch Arts rules into the core. The pattern is the one used for Inner Tempest, from D1 to D19 and C1 to C16. Each dependency is built as a separate core release with its own `verify`/`mutate` harness pair, and goes out for your approval before anything is pushed.

The surveys behind this document read TRG Prime **3.674.2** (commit `cee4db8`, 28 Oct 2026). File references are to that tree.

**What the module can already do without the core.** Federated packs (`flags.trg-prime.extends`) and `registerSourcebook` cover classes, races, heritages, backgrounds, abilities, feats and spells. These registration hooks already exist:
- `registerClass`, `registerArchetype`, `registerFeatAccess`, `registerFeatGate`, `registerExclusiveFeats`
- `registerSkillActions`, `registerSkillSubstitution`, `registerDegreeUpgrades` (skill actions only)
- `registerSpellWarps`, `registerSpellCheckGate` (modifiers and lines only)
- `registerRunes`, `registerItemAutomation`, `registerFeatAutomation`, `registerPassiveAutomation`
- `registerDefenceOffer`, `registerCompanionKind`, `registerFeatPickBonus`, `registerLightSources`, `registerCreateRoute`, `registerDamageShare`

The module can also use:
- the `moduleMark` and `declare` effect rows;
- item `spellAdder` flags;
- the `spellFumbleModifier` effect flag;
- the data-driven repertoire schedule (`flags.trg-prime.repertoire`);
- the `trgPrimeSpellCast`, `trgPrimeSpellSettled`, `trgPrimeDamageApplied`, `trgPrimeDailyPreparation`, `trgPrimeTurnEnded` and `trgPrimeStrike*` hooks;
- the helpers on `game.trgPrime.modules.helpers` (`castInnateOnce`, `runAreaEffect`, `basicSaveHit`, `healActor`, `grantTempHP`, `chooseSpell` and others).

**Delivered in TRG Prime 3.675.0 (Block 1, 28 Oct 2026; awaiting your approval like the rest).** Nine smaller seams found by the Block 1 audit, separate from D1–D18 (`ELDRITCH_ARTS_BLOCK1_AUDIT.md`, C1–C9):
- C1 `spellDamageBonus` (Elemental Surge);
- C2 a named, typed `spellResilience` derive and `spellResilienceReduction` (Null Aura, Spell Penetration);
- C3 `registerCastSurcharge` (Zhal-vryn): the cost half of D5 for a flat surcharge; D5's cap and discount halves are still to do;
- C4 `fumbleReroll.subjects` (Esoteric Insight);
- C5 `timeLadderByFeat` (Focused Ley Sense);
- C6 `registerReleasePath` (Lingual Casting);
- C7 the heritage in the racial-weapon clause (Clamhscrios);
- C8 `registerWeaponTraitRule` (Adept);
- C9 `secondaryDamage` and the caster-level `secondary` step (Orb of Water).

**Delivered in TRG Prime 3.677.0 (Block 1 on book v1.6, 1 Nov 2026; awaiting approval).** Three more, from Graham's rulings and v1.6:
- C12 a fumble reroll's `degrees` (Esoteric Insight, "a failure or fumble result");
- C13 a racial weapon one category easier for its race (Graham's m64): Exotic → Martial, and now Martial → Simple;
- C14 `flags.trg-prime.beneficialSpellSave {label, otherCastersOnly}` (Null Aura, Graham's C1): the Ascendan's beneficial-spell Will save, declared by an ability.

**Delivered in TRG Prime 3.678.0 (Block 2a, 1 Nov 2026; awaiting approval).** From the Block 2 audit and Graham's Q1–Q8 (`ELDRITCH_ARTS_BLOCK2_AUDIT.md`):
- **D1** a High Magic cast (Highmagic trait, `flags.trg-prime.highMagicCaster`, or an F&F creature under D1b): Hard; armour DR × 4 for a class or a Highmagic spell (Q3); focus set aside unless an item declares `highMagicFocus` (Q2); fumble +60 on the tradition modifier (M4), the caster's own for an all-traditions spell (Q4); Resonance with disadvantage; all traditions (M27); the "Very Hard to identify" line. Ley Bond's declared −1 row is still to come with the Archmage (Block 3); Ley Line Connection's −1 uses the spell-check gate, which is now told `highMagic`.
- **D1b** `registerHighMagicRules(moduleId)`: Eldritch Arts' rules supersede the F&F guideline (Q1).
- **D6, in part** `registerResonanceSuppressor` and Resonance with disadvantage. The fumble and Resonance *modifiers* (Mana Bound, High Magic Resonance, Spell Surge, Resonance Surge, the Wild Mage's 13) are still to do, with Blocks 3–6.
- **D7** `registerCastRefusal` and `registerCastDegreeRemap` on the casting check. Runic Stabiliser and Absolute Denial will use them.
- **D14, in part** `registerEffectSuppressor`, read by `isSuppressed`, and conditionals that skip a suppressed effect. Sniping with spell attacks (Silent Spellstrike) is still to do.
- **A1** a registered skill action's own `resolveDC({actor, targetActor})` (Tap and Channel Ley Line, Tap Magical Energy, Ley Sense).
- **Helpers and hooks:** `rollResonanceEvent`, `chargedItemLevelOf`, `rollItemDepletion`, `regionContains`; `trgPrimeReleaseRolled`; `chaos`, `rollsCheck`, `innate`, `itemCast`, `ritual` and `highMagic` on `trgPrimeSpellCast` and `trgPrimeSpellSettled`.

**Delivered in TRG Prime 3.679.0 (Block 2b, 2 Nov 2026; awaiting approval).**
- **D13** `registerRitualRules(key, { variants, fields, prepare, liftsCap })`: a ritual's other ways to pay, its own fields, DC rows, check rows and seats, a refusal, and a lifted Success cap (M30). The ritual is refused like a casting, its check takes the casting's gates and High Magic's Hard (Q14), and a variant's PP are substituted (`ppSubstituted` on `trgPrimeSpellSettled`), not drawn; the cap per cast stands (Q9). Ritual Expert's seat rides `seats` now; Rune-Binder's Precision and Archsage Command will too, with their feats (Blocks 5–6).
- **Casting options** `registerCastOption(key, { offer, apply })`: Spell Trickery, a true name, a summoning circle's binding; `castOptions` and `saveResults` on the hooks.
- **`basicSaveHit`'s `ignoreDefences`** (vital sacrifice), and the helpers `deductGold`, `learnSpellDC`, `keepsSpellbook`.

**Delivered in TRG Prime 3.680.0 (Block 3a, 2 Nov 2026; awaiting approval).**
- **D4, in full for the three classes:** `flags.trg-prime.classMagic` — a class's traditions; a subclass's magical ability and home tradition; `bookPerLevel`; `cantripBook`; further repertoire `tracks`; per-slot `cantrips`. Also `highMagicCaster` as a list of traditions. The Spellblade's "memorise level + 1" (Block 4) is still to do.
- **D5, the cap half:** `registerCastCapModifier`, with the casting DC counting overcast from the raised cap. The cost and discount halves are still to do (Block 6).
- **D8:** `registerFamiliarModifier`, the master's ability totals in the snapshot, and `createFamiliarFor` / `familiarsOf` in the API.
- **D17:** `attackBase: "bsb"` on a weapon.
- **Smaller seams:** `registerSpecialistAccess`; `registerPPGrant`, with a module's registered racial PP finally applied (a Block 1 defect); the casting's natural die on `trgPrimeSpellSettled`; High Magic not refused by a forbidden tradition.

**Delivered in TRG Prime 3.680.1 (2 Nov 2026; asked for by Graham after the 0.5.0 live test).**
- **A teleport lands; it does not walk.** Page 198's space rules no longer sample the squares between a teleport's hops, nor treat its landings as squares passed through. The end square is still checked. Eldritch Arts does not require it: Gale Step's one-hop teleport was already allowed past creatures.

**Delivered in TRG Prime 3.681.0 (3 Nov 2026; Block 3b, approved by Graham on 2 Nov: "Go with your proposals").**
- **Reaction seams.** Four new registries: `registerCheckReaction` (before the dice, for advantage; after the result, for one locked reroll that drops the first roll's Conviction die), `registerDamageReaction` (resistance or immunity, for that blow or that cast), `registerCastReaction` (stop a successful cast before it lands) and `registerCriticalReaction` (disadvantage on the critical roll).
- **The answering client.** `registerReactionStep` and `askReactor` ask the reactor's player, or else the GM. No answer in 30 seconds counts as "no" (Q34).
- **Granted defences,** read by `actorDefences`, so every damage path honours them. Immunity to all damage is honoured.
- **`resolveAction`'s `presetDispel`**, so Disrupting Magic rolls the system's own Dispel at the incoming spell.
- **`castSpell` returns `warpPP`**, the warp the cast paid for, which Phase Familiar reads.
- **On the module API:** `castAsReaction`, `convictionState`, `spendConviction` and `castRefusal`.
- **Found in review:**
  - live system data now points back to its actor, without which no granted defence would have been read;
  - every spell-damage site asks;
  - a weapon strike is a scope;
  - a reroll keeps a reaction's advantage.
- **Eldritch Arts 0.6.0 requires it.**

**Delivered in TRG Prime 3.681.1 (3 Nov 2026; asked for by Graham after the 0.6.0 live test).**
- **A Death critical's save counts.** It reads the outcome's total, and the verdict is its degree.
- **An unwilling touch can land.**
- **A reactor who leaves is told apart** from one who timed out.
- Eldritch Arts doesn't require 3.681.1.

**Delivered in TRG Prime 3.685.1 (7 Nov 2026; asked for by Graham after the 0.10.0 live test, before Block 8).** Eldritch Arts 0.10.1 requires it.
- **A teleport later than its cast:** `registerDeferredTeleport(key, defers)`, and `helpers.teleportationArrives` / `helpers.teleportationFails` (Panic Transposition, Dimensional Assault).
- **A spell aimed at an object, not a creature:** `flags.trg-prime.targetsObject` (Spirit Arrow, Decoherence, Freshmark).
- **One effect for several bonus slots:** a `bonus` row's `slots`, `name` and `refresh` (Distracted).
- **A replacing rider's cast card** and **an unknown recurring type's effect name** (core-only wording).

**Proposed for TRG Prime 3.682.0 (Block 4; `ELDRITCH_ARTS_BLOCK4_AUDIT.md`):**
- `classMagic.memorisedPerDay` (D4, the Spellblade's level + 1);
- a spell attack base, BAB in place of BSB (D17, Battle Mage);
- `registerInnateLevelBonus` (D9, the bonded souls' "+1 level");
- wielder-only infused runes;
- `castSpell` on the API, with a Strike's roll as the casting check;
- a melee Strike at 30 ft, and cover stepped down a degree.

| ID | Need | Why (features) | Core today | Proposed shape | Ruling first? |
|---|---|---|---|---|---|
| **D1** | **High Magic casting mode for characters** | SYS-01..08, all Archmage/Sorcerer/Warlock/Witch casts, Ley Bond, Ley Line Connection, Unbound, Unfettered Mastery, High Mage's Focus, Hex Weaver, High Mage, Ritual of Borrowed Power | `magic/high-magic.mjs` declares `flags.trg-prime.highMagic` per actor for F&F creatures: save DC +2, free Heighten, fumble +50 | A per-cast High Magic mode, set by the class or archetype (or a spell flag), with a profile. The `creature` profile is the existing one. The `character` profile follows Eldritch Arts Ch7: casting DC +2 (Hard), no tradition/school (school DC rows, tradition gates and armour-by-tradition skipped), armour DR ×4, no focus unless Arcanum/Archmage, automatic failure on Fumble/Blunder, fumble +60 +5/PP +20 blunder, Resonance with disadvantage. Declared casting-DC rows for Ley Bond (−1). | **Yes — EA-M4** |
| **D2** | **Module metamagic options** | ~25 feats: Echo of the Ancestors, Resonant Pulse/Harmony, Focused Spell, Sensory Spell, Spellthread (+2), Steelbinding, Subconscious Casting, Thunderclap Aura, Lightning Rod, Pact Channeler, Versatile Binder, Spell Surge, Metamagic Adept/Conduit, Bloodmage, Sanguine Channel, Spell Weaver/Overflow, Spell Trickery | `magic/metamagic.mjs` `buildMetamagicOptions` is a hard-coded table keyed by feat name | `registerMetamagic(featName, { applies(ctx), option: {ppCost, apDelta, dcDelta, max, mods}, onSettled(ctx) })`. Options appear in the existing Warp? dialog beside the core ones. `mods` uses the existing warp-mods vocabulary (damage dice, save DC, range/area/duration, extra targets). `onSettled` gets the degree for riders and backlash. Payment variants: PP, AP (Metamagic Adept), bleed (Bloodmage), reservoir charges (Spell Weaver). | No |
| **D3** | **Cast-time item options and check bias** | Catalysts (24) and their rules, Catalyst feats, Focused Spell, Incense/advantage effects, ley-line "spell checks gain advantage" | `registerSpellCheckGate` returns modifiers only; no advantage, no item consumption | (a) Gates may return `bias: "advantage" / "disadvantage"`. (b) `registerCastItemOption(kind, {list(actor, spell), apply(ctx), onSettled(ctx)})` offers owned consumables (catalysts) in the Warp? dialog and consumes the chosen one whether or not the spell succeeds. | No |
| **D4** | **Per-class casting declarations** | Archmage (memorise 2 × level; 6 first picks; +1 High Magic spell per level; memorise 3 of 6 cantrips), Spellblade (memorise level + 1; +1 per level ≤ CL + 1), Sorcerer (second repertoire track: birthright tradition at 2, 4, 6…), Birthrager (low caster tier) | Memorisation budget fixed at 2 + 2 × L (`magic/memorisation.mjs:67`); one repertoire schedule per class; free per-level learned grants not modelled | Class fields `memorisationBudget` ("2L", "L+1") and `learnedPerLevel` (count, PP ceiling rule); a second repertoire `track` with a tradition filter | EA-M23 (Birthrager tier) |
| **D5** | **Cast cap and cost modifiers** | Raw Power (+1 over cap when warping), Resonance Surge (free 2-PP warp), Spell Weaver (−2 PP), Resonant Crystal Shard (−1), Hex Mastery, Arcane Study / Soul-Bound Grimoire (warp −1), Ley-Etched Symbol, Zhal-vryn (+1 PP to cast), ley-line effects (next spell ±1 PP, free 2-PP warp, +2/−2 save DC, ignore resistance) | Partial: `warpDiscount`, `warpFreeSchool` flags; cap is CL + 1 or the specialist's level | `registerCastModifier(key, ctx => ({capDelta, ppDelta, freeWarpPP, warpDiscount, saveDC, ignoreResistance, lines}))`, read before the PP-availability check | No |
| **D6** | **Fumble and Resonance modifiers** | High Magic (D1), Mana Bound (−20; already possible with the flag), High Magic Resonance (single roll; first daily fumble becomes a failure), Spell Surge (disadvantage), Resonance Surge (forced Resonance), suppression areas (no Resonance), Wild Mages (natural 13) | `spellFumbleModifier` effect flag only; resonance location and evil-spell modifiers are never set by the cast | `registerFumbleModifier` / `registerResonanceModifier` returning `{modifier, bias, suppress, force, degreeTo}` | No |
| **D7** | **Spell casting degree remap** | Suppression areas (Partial/Failure/Fumble → Failure; Blunder → Fumble), Runic Stabiliser (Partial → Success), Absolute Denial (cast fails) | `registerDegreeUpgrades` covers skill actions, not the casting check | Extend degree upgrades to the casting check, with a context predicate; add a module "refuse cast" gate | No |
| **D8** | **Familiar modifiers** | Witch Soulbound Familiar (+2 Base DR, +level HP, Cha class bonus to saves, a daily chosen benefit within 30 ft, severed bond), Extra Bond, Ethereal Insight, Symbiotic Witch, Soul-Bound Grimoire, Hex Weaver | Familiars mirror the master (`familiar-derive.mjs`); no module hook | `registerFamiliarModifier(key, (master, familiar) => changes)` applied in derivation, plus a flag the familiar's owner can read | No |
| **D9** | **Innate caster tier and level bonuses** | Warlock: all spells innate Focus from class picks (1 at 1st, +1 at 3rd and every 3), "treated as one level higher" for listed traits/schools, Xithra (innate attack with damage-type choice, riders, cone/range variants), Warlock hexes, Warlock cantrips | `castInnateOnce(actor, spellData, {ability, tradition, allowance})`; innate level = character level; no per-trait level bonus; no innate repertoire picks | Innate repertoire picks on the class (as the repertoire schedule), and `registerInnateLevelBonus(key, ctx => n)` read by `innateSaveDC`, the warp budget and the innate PP limit | No |
| **D10** | **Dispel action hooks** | Runebreaker (−2 PP), Resonant Ascendance (half PP), Dispel Power (0 PP, Very Hard, own ladder), Threadbreaker's Precision, Glyph Shatter, Mirrored Rebuke | Dispel PP prompt in `general-skill-options-workflow.mjs`; no module hook | `registerDispelModifier(key, {ppCost, difficulty, ladder, onResult})` | No |
| **D11** | *(reserved — folded into D3)* | | | | |
| **D12** | **Charged-item hooks and the Orb kind** | Dual Channel, Conduit Mastery, Resonant Conduit, Weave Infusion, Metamagic Conduit, Tap Magical Energy; the Orb item type (Ch8, L9203–9395) | `charged-items.mjs` knows rod/staff/wand/other. `chargedItemLevel` would treat an orb as a staff, `chargedItemPrice` has no ×1.25, `castFromItemOptions` hard-codes Easy/Hard and "rank ≥ PP", `dailyRecharge` would recharge an orb, the depletion table breaks the item on 41–65, and `chargedItemWarnings` enforces one charged item at a time | A `registerChargedKind(key, {level(item), price(level), maxPP(level), castOptions(actor, item, spell), dailyRecharge(item) → 0, rechargeCost, depletionRow(roll)})` hook, which the core consults before its own kind branches. For the Orb: level = highest PP + 2 (min 4) + 1 per High Magic spell; price = staff column ×1.25; max PP = level ×3; Spellcraft path Hard (+2) with CL covering the PP and no tradition needed; tradition-skill path Very Hard (+5) with rank **>** PP; no natural recharge (25 gp/PP at a ley line, or Recharge Item at 4 PP per step); 41–65 = Resonant Flare (Wild Surge, 20 ft) instead of breaking. Plus `registerChargedItemRule` for the feat cases (a second wielded item for Dual Channel; cost and payment source for Conduit feats) | Yes — needed by Block 7 (items) |
| **D13** | **Ritual extensions** | Mundane ritual variant (non-caster primary; tradition skill at Very Hard; vital, material and communal PP), Ritual-trait spell outcomes, Ritual Expert/Rune-Binder's Precision/Archsage Command seats, Ritualist weapons, Ritual Censer/Runestone Chalkboard/Bloodscribe's Bowl, Lorekeeper's Insight | `rollMagicRitual` (`cast-workflow.mjs:7281`): up to 6 secondaries, fixed modifiers | `registerRitualModifier(key, ctx => ({seats, dc, check, payment}))` and a `ritualOutcomes` field on spells | No |
| **D14** | **Sniping and antimagic suppression** | Silent Spellstrike (Sniping with spell attacks), antimagic zones (suppress spell effects and magic-item properties while inside) | Sniping accepts weapons only; no effect-suppression predicate | Spell attacks admitted to Sniping when a feat allows; `isSuppressed` predicate consults module regions | No |
| **D15** | *(reserved — folded into D1)* | | | | |
| **D16** | *(reserved)* | | | | |
| **D17** | **Attack-base substitution** | Battle Mage (BAB for spell attacks), Dragon birthright / Draconic Claws (BSB for a natural weapon) | Spell attacks use the casting check; weapon attacks use BAB | Declared `attackBase` on an item or ability (`bab`/`bsb`), read by both attack paths | No |
| **D18** | **Module materials and weapon traits** | 10 special materials (Ashbone … Veilglass); Adept and Ritualist weapon traits | `MATERIALS` is a frozen table (`item-quality.mjs:171`); proficiency rules are core-only | `registerMaterial(key, {level, weight, hpHardness, weapon, armour, shield})` and `registerWeaponTrait(key, {proficiency, onEquip})` | No |

**Cross-module follow-up (not a core change).** Pillars of Faith 0.5.1 carries two Eldritch Arts spells, Touch of Healing and Symbol of Pain, "until it ships" (your note of 18 Sep). Once Eldritch Arts provides them, they come out of Pillars of Faith. The core's grant resolution prefers the granting item's own package when two books share a name (`sourcebooks.mjs:111`), so the swap is safe in either order.

**Not a dependency, recorded for honesty.** The brief quotes Casting DC = 10 + **ceil**(1.5 × PP). The system rounds **down**, deliberately, since 3.549.0: the Core Rulebook prints the formula with no rounding instruction, and page 10's default is "unless otherwise stated, always round down" (`release-notes-3.549.0`). The module follows the core and does not change it. If ceil is what you intend, that is a core ruling, and it would change every odd-PP spell's DC by 1.
