# Eldritch Arts — Graham's rulings, 1 November 2026

Source: *Responses to Audit Eldritch Arts* (docx), answering the rules audit's Parts A–E, with the book revised to **v1.6** the same day. Parts A–E of the audit are answered in full. Part F (found while building Block 1) and the Block 1 questions B1-1 to B1-22 were not in that document. Those that v1.6 settles are marked below; the rest are listed at the end.

**How v1.6 was read.**
- The docx was cut with the same pandoc command as v1.4.
- Its 34 text boxes were read by `tools/content/extract-sidebars.py`, now saved in the module so the cut can be repeated. Run on v1.4, its content matches the v1.4 sidebars line for line.
- Every Block 1 source in v1.6 was compared with v1.4 (below).
- The Grimoire now holds 87 spells: Dragon Wings is added.

## Applied now: Eldritch Arts 0.2.0 and TRG Prime 3.677.0 (Block 1)

| Ruling | What it changes |
|---|---|
| **C1** Null Aura: "a successful Will saving throw against the caster's Spell Save DC" | A beneficial spell cast on a Nyrinn by another caster asks for that Will save. On a failure, the spell does not benefit the Nyrinn. Was a GM reminder. |
| **C3** No DC printed: "the Level DC of the target (if something is targeted) or the caster's own Level DC if nothing is targeted" | Vir-ellian Release already uses the releaser's own Level DC (B1-18, now ruled). It is the default for every later block. |
| **M22** "Aura cannot be suppressed" | As built: the aura works on everyone in it, allies included, with no switch (B1-4). |
| **M24** As proposed | As built: Magic Drain's energy is a pool, the +1 goes where the drainer chooses, Vir-ellian's area is 30 ft, and Failure or worse drains nothing (B1-7, B1-8). |
| **m2** Nyrinn | v1.6 spells it Nyrinn throughout, the Scáthfán's trait included (B1-13 settled by the book). |
| **m3** "this is correct" | Tidemarked keeps Galeborne's adjustment (B1-2, first half). |
| **m4** Umbryth resists cold | Was essence (B1-2, second half). |
| **m5** Glyphweave's bonus cantrip is innate | Its pick is now an innate spell with the Focus trait (B1-9, revised). |
| **m6** Wyrmdral: "of their elemental type" | As built (B1-11). |
| **m42** Missing rungs fall back: Heroic → Critical, Partial → Failure, Fumble → Failure, Blunder → Fumble (or Failure) | Matches the system's reading and the module's `printedDegree`. |
| **m56** Spell Resilience is the Fiends & Fables creature ability | Spell Penetration lowers it, as built. |
| **m58** Spirit Binder's wealth printed (0) | The B1-14 note is removed (settled by the book). |
| **m64** "A weapon with a specific race listed in its traits allows a member of that race to use it with less proficiency. So a Martial weapon would become simple and an exotic weapon martial." | **Core change (C13):** the racial clause now steps a weapon down one category for its race. It was Exotic → Martial only. This reaches every book's racial weapons. |
| **R6** The Ord ua na Tuama is a Large weapon | v1.6 prints L. |
| **v1.6, Esoteric Insight** "when you get a failure or fumble result on an Arcana or Occultism check" | **Core change (C12):** a fumble reroll may name the degrees it answers. Esoteric Insight answers Failure and Fumble. |
| **v1.6, text** Hypnotism "Indifferent or worse attitude"; Quickbind "The item is invested"; Claidheamh Dubh's own description; Bogha Tuama's "Piercing" dropped; Gilded Censor Chains, Ritual Censor and Ward Twine renamed; Ritual Censor "Reduce ritual Spellcraft DC by 1"; Leybraid Rope "in magical areas"; Spellbinder's Cord and Twilight Prism "Spell Concentration" | Built as printed. |

**Later the same day (the 0.2.0 live test, F1).** A beneficial emanation gave its bonus to a Nyrinn whose Null Aura save had just refused it. Ruling: the save applies after the cast too, as Bane's latecomers roll theirs. Built in TRG Prime 3.677.1: the circle remembers who refused it, and a latecomer who owes the save rolls it once. This covers the Ascendan as well.

## Recorded for later blocks (no Block 1 change)

**Block 2 (High Magic, ley lines, wild magic, suppression, rituals and circles):**
- M4: Eldritch Arts' High Magic supersedes all earlier High Magic rules wherever the sourcebook is used, and the High Magic modifier adds to the tradition modifier.
- M27: the Highmagic trait, as rewritten. All Highmagic spells are Uncommon; a non-High-Magic caster learns one Very Hard and casts it Hard; they count as every tradition. The classes that grant High Magic treat every spell they cast as Highmagic.
- M5: Chapter 7's table is the default DC; the GM may override.
- M6: a ley line action gains the line's effect, and its backlash only when it says so. Effects last as long as the skill being used says. Channel gains the benefit and the damage or critical, but no backlash.
- M7: unlisted damage is 1d8 × area level, anywhere within the surge's radius (GM). 12–15 is now an elemental of area level −2 (min 1) acting randomly for 1 minute. "Bloodline" becomes birthright. Wild Mage's natural 13 applies to UM 13.
- M8, M9: as proposed. M10: +1 damage die, backlash on Fumble or Blunder only. M25: they stack. M30: the ritual Critical cap is lifted, as proposed.
- C5 Veil Severing and m90 Animal Binding, as rewritten. M45 Leyline Anchor, as rewritten: no ladder printed means Success works and Failure does not.
- R14: leave as is.

**Block 3 (classes):**
- C2: every character has a PP pool from their magical tradition, casters or not. A Warlock needs Charisma 2 or more, so always has at least 2 PP.
- M1: every core spell's PP in the Arcanum and Dragon tables is doubled (corrected in the book).
- M2: spell names as proposed. Shield of Faith becomes Calm (4). Dragon Wings (PP 6) is added. Celestial Sentinel's innate spell is Cure.
- M3: "cannot progress" means no later archetype, ever.
- M11: Elemental Breath becomes a Focus ability with no PP cost.
- M12: the cold trigger is dropped.
- M13, M14, M18, M20: as proposed. M15: a bonus feat at 1st. M16: memorise 2 + (level × 2).
- M17: Martial, not Warrior. M19: Magical Discovery.
- M21: Rune-Binder's Precision will be altered by you; the item carries a note until then.
- M23: Birthrager as rewritten. It is an instinctive caster with BSB half its level (rounded up), gets a Sorcerer birthright's specialist spell and cantrip and Sorcerer feats, and casts while raging.
- M26: Spellstrike Riposte as rewritten (the cantrip's damage as secondary; ignores the multiple attack penalty). Spellblade's Mark becomes 1d6 secondary force.
- M28: **withdrawn.** You were right: the core Specialist Spell feat grants a further specialist spell, hexes included, so a Warlock gets more hexes through it.
- m14: Borrow Spell as rewritten; it is now a General skill action.
- m54: Rapid Binder as rewritten. m59: Spellcraft.
- R7: spell adders from different sources stack.
- C7: Ley Walker (PP 11) is added.
- M60–M66: as amended; M61 is a 1 PP specialist spell. M66: Draconic Claws and Draconic Infusion as rewritten.

**Blocks 4–10:**
- C4: Soul Confluence is dismissible: (D).
- C6: the Catalyst rune is amended.
- C8: Veilshroud now carries Veil I.
- M29: school traits are removed from High Magic spells.
- M31, M37, M38, M55–M57, M76, M79, M99, M101–M103, M112, R1–R5, R16, R18, m215 onward: leave as printed.
- M39: base damage 1d4, range 20 ft, 1 AP cast.
- M40: persistent means recurring. Coldfire is Fiends & Fables'; without it, it counts as both fire and cold.
- M41 Elemental Strike and M44 Flesh to Blossom, as rewritten.
- M42: the element is the one you resist.
- M43, M51: a Utility spell affects willing targets only.
- M47: the +2 PP option removes "sustained".
- M50: the trigger is being hit.
- M53: energy damage is acid, cold, electricity, fire, sonic, essence and force (Core p192).
- M54: a shadow is defined in Fiends & Fables.
- M78: incorporeal is explained in Fiends & Fables.
- M89 and m188/m189: the staff is removed. M90: the Be Aware note says how the condition ends. M104: Renewal I is removed.
- m118: the trait becomes save. m128: round down unless stated. m150: the duration is 10 minutes (S).
- m186: the staff's other abilities are costed as wondrous items. m200: clumsy was removed on purpose. m207: the scaling guidelines are there.
- Planes of existence are now an appendix.
- v1.6 renames the general feat Spirit Binder to **Spirit Resources**, so it no longer shares the background's name, and prints **Duellist's Focus** with its apostrophe (m35). The inventory reads both names from v1.6.
- Everything marked "amended", "corrected" or "as proposed" is read from v1.6 when its block is built. Those marked "ignore" or "leave" are built as printed.

## Answers to your questions

- **m28, "cannot find the comma":** v1.6 line 2874, the existing racial feats list for the Aetherial: "Aura of Power, Focused Pursuit," ends with a comma.
- **m39, "needle in a haystack":** two flavour lines end in a stray backtick after the full stop:
  - Dragon Breath's "*You manifest the iconic mark of dragonkind — a devastating breath weapon. \`*" (v1.6 L3464);
  - "*Your heritage can no longer be contained — draconic traits erupt as your mortal shell struggles to hold the wyrm within. \`*" (L4288).
- **m45, "please suggest how to rewrite":** Steelbinding (L4150) prints `**PP Cost** +2**; Requirements** your spell targets…`, with the bold on the semicolon. Suggested: "**PP Cost** +2; **Requirements** Your spell targets a creature wearing metal armour within 30 feet."
- **m70, "?":** three backlash lines, all still in v1.6:
  - Glimmercoal (L5338): "1d6 fire damage per spell 2 PP of the spell" → "per 2 PP of the spell".
  - Spell Incense (L5428): "Spellcraft checks foe 1 minute" → "for 1 minute".
  - Verdant Sap (L5458): "as the sap their mind" → "as the sap clouds their mind" (a word is missing).
- **m82, "?":** my error. m82 was printed twice and repeats C6 (the Catalyst rune tiers), which you have amended. Nothing more is needed.
- **m174, "?":** the orb level rule (L9315) is "the highest PP spell contained +2 (minimum 4)".
  - Shifting Currents (highest 2, level 4) and Whispering Veil (highest 4, level 6) follow it.
  - The Verdant Heart (highest 10, Regenerate) should be **12** by the rule, but prints **13**. Either it is 12, or the rule needs a reason for the extra level.
- **M28:** withdrawn, as above.

## Still open for you (Block 1; built as proposed until you say otherwise)

| # | Question | As built |
|---|---|---|
| B1-1 | "Elemental Language" (still in v1.6, L191) is not a language. | The heritage's elemental tongue: Stonevein Gaian, Galeborne Aeolian, Cinderblood Ignic, Tidemarked Aqualis. |
| B1-5 | "Casting DC increased": the system changes the check, not the DC. | A penalty of the same size on the casting check, left out of an attack spell's attack. |
| B1-6 | Zhal-vryn's extra PP: a surcharge on top, or PP spent on the spell? And is it paid when the spell fails? | A surcharge, paid whatever the result. It raises no DC and counts against no cap. |
| B1-10 | Elemental Symbiosis prints no trigger. | Your reaction, whenever you choose. |
| B1-12 | Brace (v1.6 L4921) is a different rule from the core's Brace. | Held out of the three weapons' trait lines and printed in their text. |
| B1-15 | Innate spells' ability: the heritages name none. | The system's default. |
| B1-16 | Ritual Expert, Ritualist and Spell Surge wait for Block 2. | Shipped with notes saying so. |
| B1-17 | Ley Sense prints the Focus trait, but it is a skill action with no use to spend. | The trait is carried; no use is spent. |
| B1-19 | Lingual Casting on a scroll whose spell names no tradition. | Offered as unavailable, with the reason. |
| B1-20 | Hypnotism's "retried the next day": that subject, or anyone? | That subject. |
| B1-21 | Magic Drain's "max level × 2": per drain, or on all the energy held? | Per drain. |
| B1-22 | Disrupt Magic's +2 "when using the Dispel action", and Magic Drain's "Dispel (Power Manipulation) check". | Not Magic Drain. |
| new | "Censor" (v1.6) means one who suppresses; a "censer" is the incense burner. | Built as printed: Gilded Censor Chains, Ritual Censor. |
| new | Glyphweave's innate cantrip: chosen once, or again each day like Innate Magic? | Chosen with its Use, and kept until you choose again. |

Part F's findings (EA-M113 to EA-M117, EA-m226 to EA-m229) are the same questions: M113 is B1-17, M114 is B1-18 (now ruled by C3), M115 is B1-12, M116 is B1-1, M117 is B1-10, m226 is B1-19 and m227 is B1-20. m228 (Quickbind) is corrected in v1.6; m229 (Ley Sense's double full stop, "would overlook..", v1.6 L1816) is still there.
