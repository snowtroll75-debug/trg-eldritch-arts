# Second live test: Block 8b's untested spells

12 November 2026, early afternoon. Graham's world in Chrome, Foundry 14.367, as Testing Dude (GM).

**Builds tested.** These were still the builds from the first live test, not the ones fixed after it (checked by reading the files on the server). The eight spells tested here have no code the morning's fixes changed, so these results stand for 0.12.1.

**Setup.**
- **Actors:** throwaway "ZZ EA" actors copied from Valmorius, never saved back: the Wizard (20), the Second (12), the Ally and the Foe (6).
- **Spells:** the 13 spells needed, taken from the compendium.
- **Scene:** a throwaway scene, "ZZ EA 0120 Live 2", with a ley line Region of level 6 for Leyline Anchor.
- **Dice:** fixed where a degree mattered, and restored afterwards.

**Graham's session.** Partway through, Graham joined as Gamemaster and prepared Valmorius: a Daily Preparation, a rest and a Recharge Item. Those cards and changes are his, recorded under his user. None of the test touched them, and they were kept at cleanup.

## Results

| Spell | Result |
|---|---|
| **Alter Corpse** | **Pass.** No target dialog (an object target). "Which use?" asked at the cast; Restore on the card. |
| **Chaos Shield** | **Pass.** A 30-ft aura while sustained, catching the three allies.<br>A wild surge for the Ally inside, through Block 2's own table roll: the shield's caster was offered the nullify and declined. The table was rolled twice (62, 58) and the Ally picked; the card names the DC −2 and the halving.<br>A second surge: nullified, for 2 PP.<br>A third in the same round: "already used to nullify a surge this round", with no PP spent. |
| **Leyline Anchor** | **Pass.** The level 6 line chosen; 10 minutes on its own clock; casters within 300 ft got +1 Spellcraft and Power Recovery.<br>Chaos Shield cast inside paid 5 PP, its DC read at 6 (Q179).<br>The Second's Tap Ley Line rolled Power Manipulation against DC 30 (the anchor's Save DC 25 + 5) and failed: "the attempt stops". |
| **Veilfracture** | **Pass, with one fault.** A 100-ft rift (caster level 20) where clicked, bound to its sustained cast; dismissing it removed the rift.<br>A Fumble: the GM's card, 1d4 = 2 creatures plus the caster, Reflex saves, a Fumble lost there. **The fault:** the DC was the sheet's 35, not the Save DC of 25; see below. |
| **Rite of Echoed Shadows** | **Pass.** A Critical: 300 ft for a day. The caster, the secondary and the ticked Ally in the echo (advantage on Stealth). The hostile Foe, inside at the rite, got −4 to attacks as a first entry. |
| **Call of the Ancestors** | **Pass.** A Critical: up to 3 questions, clear. The chosen participant (the Ally) got advantage on one check. |
| **Essence Reforging** | **Pass.** Performed alone (H14) on the targeted Ally; its Cost of 1,200 gp (200 × level 6) was taken.<br>"Remove" offered the Ally's effects of PP 14 or lower. The GM's button removed the chosen one. |
| **Veil Severing** | **Pass.** A Success: a two-way portal Region for 1 week, the Cost of 2,000 gp taken, and no Spatial Awareness card at the cast. |

## Finding

**A failed cast's Save DC (module, medium).** Veilfracture's collapse used the sheet's Spellcraft DC: 35 for this wizard, where Leyline Anchor's card showed the 10 PP Save DC as 25.
- **The rule:** TRG Prime's Save DC is 10 + the PP cast + the casting ability (+5 here).
- **The same fault** was in Storm of Unmaking's fumble storm. The first live test's revert there was right only because this wizard's BSB (20) equals that storm's PP (20).
- **Fixed in 0.12.1:** both use the core's formula, unless the cast carries its own Save DC.

**Low, not changed:** after a nullify, Chaos Shield still asks its caster again within the same round, and then refuses. Nothing is spent.

## Not tested live

- **Rite of Binding Oath's Partial (its GM card):** it cannot be cast on the installed build, the fault fixed after the first live test.
- **The first live test's fixes**, and the DC above.

All need 0.12.1 and 3.687.1 installed.

## Cleanup

- **Deleted:** the scene (with the ley line), the 4 ZZ actors, and the 59 chat messages my test user wrote.
- **Kept:** Graham's own 7 cards about Valmorius. The world has 318 messages, 311 + his 7.
- **Dice:** restored.
- **View:** Oldwatch Approach.
- **Game:** still paused, with no combats. World time is unchanged by the test.
