# Eldritch Arts 0.6.1

3 November 2026. Fixes the two findings from the 0.6.0 live test (`LIVE_TESTING_REPORT_0.6.0.md`).

- **Install over 0.6.0.** It still needs TRG Prime 3.681.0. No migration and no new settings.

## Fixed

- **Prophetic Warning is cast at the Witch herself.** Its range is self.
  - **Before:** in 0.6.0 the cast went at whatever her user had targeted. With another creature targeted, the system refused it ("… beyond Prophetic Warning's range of self") and the check rolled without advantage. Nothing was spent.
  - **Now:** the reaction cast is aimed at her own token, and her user's targets are put back afterwards, as for every reaction cast.
  - **Found in review:** her token is looked up on the client that casts the hex, which is the client that measures the range. The asking client may not have her token on its canvas at all.
- **Disrupting Magic is offered only to a creature that could roll the Dispel.** Dispel is a Trained action (Power Manipulation, at least one rank). Something the creature carries can also let it take Dispel untrained (the system's `untrainedActions`), and that counts.
  - **Before:** in 0.6.0 an untrained creature was asked. It said yes, then the system refused the Dispel. Nothing was spent, but the question was pointless.
  - **For Graham:** the book says the casting check "is treated as a Dispel (Power Manipulation) check". If you'd rather Disrupting Magic waive the Dispel's training, that's a small change.
- **Found in review: Disrupting Magic is not offered to a Fixated creature.** Dispel has the Concentrate trait, which a Fixated creature can't use, so the system would refuse it too.
- **Disrupting Magic's card** now says all of these.

## Harness

- **`verify-block3b`:** 87 checks pass, up from 80. New:
  - D1b, I4 and I5: Prophetic Warning's target;
  - G12–G15: the Dispel's training, its exemptions and Fixated.
- **`mutate-block3b`:** 83 of 83 caught, up from 75.
- **An independent review of the patch** found the two items marked "found in review" above, both now fixed. It found nothing else beyond cosmetics.
- **The other module harnesses, still green:**

  | Harness | Checks | Mutations caught |
  |---|---|---|
  | `verify-block1` | 883 | 86 |
  | `verify-block2` | 131 | 75 |
  | `verify-block2b` | 91 | 81 |
  | `verify-block3` | 302 | 83 |

  Their version pins moved to 0.6.1.
- **TRG Prime is unchanged at 3.681.0.**

## Seen in the live test, in the system, and not changed here

These two are older than 3.681.0; the same code is in 3.680.1. Both are waiting on Graham's go-ahead for a TRG Prime fix.
- **A Death critical always kills.** The save's total is read from a field the check doesn't have.
- **A touch-attack spell against a mark always misses.** The same misread.
