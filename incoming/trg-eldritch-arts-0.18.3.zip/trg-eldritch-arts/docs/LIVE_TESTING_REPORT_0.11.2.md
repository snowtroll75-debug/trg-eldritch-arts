# Live recheck: Eldritch Arts 0.11.2 on TRG Prime 3.686.0

9 November 2026. Graham's world in Chrome, on Foundry 14.367, as GM with no other users connected. I used throwaway "ZZ EA" actors (Wizard, Foe and Ally) and a throwaway scene, "ZZ EA 0112 Recheck". Every move was a normal animated `update`, the kind that exposed the bug in 0.11.1.

## Results: pass

### Harmonic Rift, out of combat

| Test | Result |
|---|---|
| Foe (hostile) moves into opening 2 | Steps out of opening 1. A basic Fortitude save is rolled; Partial, 12 sonic, HP 150 → 138. The save line reads as plain text. |
| Foe moves out of opening 1 | Stays where it was moved: no card, no save. |
| Ally (friendly) moves into opening 1 | Steps out of opening 2, with no save. |
| Foe moves into opening 1 while the ally stands in opening 2 | "reaches the rift, but the far opening is occupied … it does not pass." No save is rolled, and the foe stays in opening 1. |

### Harmonic Rift, in combat, on the foe's turn

| Test | Result |
|---|---|
| Step out of opening 1 | Stays: no card. |
| Back into opening 1 | Steps out of opening 2. The "Teleported — Spatial Awareness" card is posted, and the save is rolled (12 sonic). |
| Step out of opening 2 | Stays: no card. |
| Back into opening 2, in the same turn | "steps into the rift, but a second teleport this turn fails." The foe does not pass. |

### Riserune (recording within 10 ft)

| Test | Records |
|---|---|
| Ally moves from far to within 10 ft | [ZZ EA Ally] |
| Ally moves from near to far | Still [ZZ EA Ally]: leaving doesn't record. |
| Foe moves from far to far | Still [ZZ EA Ally]. |

### Symbol of Weakness: the curse's hour

- **The flash:** the foe rolled a Partial and got weakened 2, held by the curse.
- **Moving away:** an animated move to beyond 60 ft started the one-hour clock (world time now + 3,600 s).
- **Coming back:** moving back within 60 ft stopped the clock.

## Found: Riserune's target dialog (low, cosmetic)

Riserune targets "one surface", but its cast still opens the creature target dialog. The GM has to press Continue, then "Continue anyway" past the "No target selected" warning, before clicking the surface. Spirit Arrow, Decoherence and Freshmark were changed in 0.10.1 to skip this dialog; Riserune needs the same flag. It's queued with Block 8b, along with any other surface-target spells in the same state.

## Cleanup

- **Deleted:** the scene, the three ZZ actors, and the 33 test chat messages. All were mine; the world has 311 messages again.
- **Graham's messages:** the chat-button helper now only touches messages created during the test, and no older message was clicked.
- **Dice:** restored.
- **View:** back on Oldwatch Approach.
- **Game:** still paused, with no combats.
