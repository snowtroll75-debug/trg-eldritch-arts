# Eldritch Arts 0.2.0

1 November 2026. Block 1 rebuilt from book v1.6, with the rulings in *Responses to Audit Eldritch Arts* applied. The full list of rulings, the ones recorded for later blocks and the questions still open are in `ELDRITCH_ARTS_RULINGS_2026-11-01.md`.

- **Install TRG Prime 3.677.0 first, then this over 0.1.1.** The module warns on anything older: three of its rules are now the system's.
- **No migration.** The compendiums are rebuilt. An Eldritch Arts item already on an actor keeps its 0.1.x data, so replace it from the compendium where it matters:
  - Null Aura (on a Nyrinn), for the Will save;
  - the Umbryth heritage, for cold resistance;
  - Esoteric Insight, for the Failure reroll.

## Rules changes

**Null Aura disrupts beneficial spells (C1).**
- **The book (v1.6):** "Your aura also disrupts beneficial spells cast upon you by other casters, and you must make a successful Will saving throw against the caster's Spell Save DC to benefit from them."
- **Built:** Null Aura declares the save, and TRG Prime 3.677.0 rolls it. It is the same Will save an Ascendan makes against forbidden magic: the same spells count as beneficial, against the same DC.
  - The card says which way it runs: success lets the spell take hold.
  - On a failure the spell has no effect on the Nyrinn and still helps every other target.
  - A Nyrinn's own spell on themself asks for nothing ("by other casters").
- **Replaces** 0.1.x's whisper to the GM.

**Esoteric Insight rerolls a Failure (v1.6).** "When you get a failure or fumble result on an Arcana or Occultism check." The reroll is offered on a Failure, a Fumble and a Blunder (which fails by more than a Fumble), but not on a Partial Success. It is still not a reaction, and still only on those two skills. This needs TRG Prime 3.677.0 (C12).

**A racial weapon is one category easier for its race (m64).** Every Block 1 racial weapon is exotic, so it is martial for its race, as before. The rule is now the system's (3.677.0, C13), so a martial racial weapon from any book is now simple for its race. The weapons' notes say so.

**Smaller rulings.**
- **Umbryth** resists cold, not essence (m4).
- **Glyphweave**'s cantrip is innate (m5): "an additional innate cantrip". Use Glyphweave to choose it, and again to change it. Daily preparation now invites a new pick for Innate Magic only (see the open questions).
- **Spirit Binder**'s wealth is 0, as v1.6's table prints (m58). The note saying the row was missing is gone.
- **Ord ua na Tuama** is Large (R6).
- **Nyrinn** is spelled as v1.6 prints it everywhere, the Scáthfán's trait included (m2), so the module no longer corrects the old spelling.
- **Vir-ellian Release** uses the releaser's own Level DC, which C3 now rules (B1-18).

**Text as v1.6 prints it.**
- Hypnotism's unwilling subject: "Indifferent or worse".
- Quickbind: "The item is invested".
- The Claidheamh Dubh's own description, and the Bogha Tuama's trait line ("Volley 50 ft,Range 120", read as two traits).
- Gilded Censor Chains, Ritual Censor (and its "Reduce ritual Spellcraft DC by 1"), and Ward Twine.
- Leybraid Rope, Spellbinder's Cord and Twilight Prism.
- Cabal Exile.

## Found while rebuilding

**The Scáthfán had lost its racial note.** v1.6 corrected the trait from "Nyrrin" to "Nyrinn". The module's table of racial traits still keyed the old spelling, so the Scáthfán built without its "one category easier for a Nyrinn" note. The proficiency itself was right throughout, because the system reads the trait. The table now keys v1.6's spelling, and the harness checks that every racial weapon carries its note. This was never released.

## Harness

- **`verify-block1`:** 881 checks (was 870).
  - **New:**
    - Null Aura's declared save, driven through the system's own `beneficialSaveRequired`: another caster's helping spell asks for it, the Nyrinn's own and a harmful spell do not.
    - Esoteric Insight on each degree, and the system's `rerollAnswers` on a failed Arcana check.
    - Glyphweave's pick is innate and is not re-invited each day.
    - Spirit Binder's printed row.
    - Every racial weapon's note.
    - No weapon keeps "Nyrrin".
  - **Gone:** the GM-reminder tests.
  - **Versions:** 0.2.0 / 3.677.0.
- **`mutate-block1`:** 86 mutations, all caught (was 75).
  - **New:**
    - v1.4's Umbryth and Esoteric Insight.
    - A Partial-success reroll.
    - Null Aura undeclared, or disrupting the Nyrinn's own spells.
    - Spirit Binder's note and wealth.
    - The Nyrinn racial note.
    - Glyphweave non-innate, or re-invited daily.
    - The old spell-cast hook.
    - The 3.676.1 minimum.
  - **Gone:** "B1-13 undone", since the book settles it.
- **TRG Prime's own pair** for the three seams is `verify/mutate-ea-block1-core` in 3.677.0: 89 checks, 66 mutations.
