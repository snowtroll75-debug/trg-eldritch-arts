# Eldritch Arts — Automation Report

_Generated from `tools/inventory/inventory.txt`, `justifications.json` and `status.json`. "Target" is the class each feature is planned at. A feature that only posts its text to chat is class D, never A._

## Planned coverage

| Class | With the core dependencies | Module only (no core changes) |
|---|---|---|
| A (Full) | 369 | 304 |
| B (Interactive) | 256 | 239 |
| C (Partial) | 42 | 124 |
| D (Manual) | 40 | 40 |
| **Total** | 707 | 707 |

## By section

| Section | A | B | C | D |
|---|---|---|---|---|
| SYS: High Magic and book-wide rules (Ch1, Ch7) | 9 | 0 | 1 | 2 |
| RACES (Ch2) | 5 | 0 | 0 | 0 |
| RACIAL ABILITIES (Ch2) | 8 | 4 | 0 | 0 |
| HERITAGES (Ch2) — 18 | 14 | 4 | 0 | 0 |
| BACKGROUNDS (Ch2) — 12 | 11 | 1 | 0 | 0 |
| CLASSES (Ch3) | 24 | 7 | 0 | 0 |
| BIRTHRIGHTS (Sorcerer, Ch3) — 7 | 3 | 4 | 0 | 0 |
| SPELLBLADE PATHS (Ch3) — 4 | 3 | 1 | 0 | 0 |
| BONDED SOULS (Warlock, Ch3) — 8 | 2 | 6 | 0 | 0 |
| SKILL ACTIONS (Ch4) — 13 | 4 | 7 | 0 | 2 |
| GEAR (Ch6) | 5 | 0 | 0 | 0 |
| CHAPTER 7 SUBSYSTEMS | 5 | 7 | 1 | 0 |
| RACIAL FEATS (Ch5) — 74 | 42 | 30 | 2 | 0 |
| ARCHETYPE FEATS (Ch5) — 23 | 7 | 16 | 0 | 0 |
| CLASS FEATS (Ch5) — 97 | 51 | 40 | 6 | 0 |
| GENERAL FEATS (Ch5) — 43 | 19 | 17 | 4 | 3 |
| EXISTING CORE RACIAL FEATS OPENED (Ch5) | 7 | 0 | 0 | 0 |
| SPECIAL MATERIALS (Ch6) — 10 | 10 | 0 | 0 | 0 |
| EXOTIC WEAPONS (Ch6) — 18 | 18 | 0 | 0 | 0 |
| GOODS & TOOLS (Ch6) — 31 | 2 | 25 | 1 | 3 |
| CATALYSTS (Ch6) — 24 | 24 | 0 | 0 | 0 |
| GRIMOIRE (Ch8) — 88 | 17 | 38 | 16 | 17 |
| SPECIALIST SPELLS, HEXES AND ARMOUR (Ch8, Ch9) — 66 | 35 | 22 | 7 | 2 |
| CHARGED ITEMS, WEAPONS (Ch9) — 49 | 31 | 17 | 1 | 0 |
| RELICS, SENTIENT ITEMS, APPENDIX (Ch9) — 37 | 13 | 10 | 3 | 11 |

## Features below A/B, with the reason

- **SYS-02 High Magic always affected by school-specific counters** (C) — C — the system does not record which school a counter targets, so 'High Magic is always affected' is shown on the counteract card for the GM to apply.
- **SYS-09 "Low magic" terminology** (D) — D — terminology only.
- **SYS-10 High Magic introduction (flavour)** (D) — D — narrative introduction; no rule.
- **SA-08 Mysterious Script** (D) — D — the roll is automated, but its result is GM-given divination text (Augury/Divine Vision answers).
- **SA-13 High Magic amendments to existing actions (intro)** (D) — D — the introduction promises amended core actions that the chapter never prints; nothing to automate.
- **M7-08 Antimagic zones** (C) — C — casting is refused and spell effects suppressed inside the zone; whether a given magic item's property is 'physical form only' is resolved per item where the system models the property, the rest by the GM.
- **FR-08 Astral Drift [AETHERIAL]** (C) — C — magical difficult terrain is a scene judgement Foundry does not model; the free Step is offered at end of turn when all 3 AP were movement.
- **FR-70 Voidborn Grace [NYRINN]** (C) — C — Hover is applied while flying; the 60 ft/round glide after flight ends is a positioning rule the GM moves.
- **FC-64 Reflective Warding [SPELLWARDEN]** (C) — C — the negated spell is turned back on its caster, but re-aiming another creature's spell from its caster runs as a GM-confirmed cast.
- **FC-79 Spellthread [ADEPT METAMAGIC]** (C) — C — both spells are cast and charged as one action with the +2 PP; 'one spell for concentration and counterspell purposes' cannot be enforced against third-party counterspells, which see two casts.
- **FC-80 Spellthread Mastery [ADEPT METAMAGIC]** (C) — C — as Spellthread.
- **FC-81 Spellthread Unbound [ADEPT METAMAGIC]** (C) — C — as Spellthread.
- **FC-84 Symbiotic Witch [WITCH]** (C) — C — casting from the familiar's position and the sustain hand-off are automated; 'even if out of sight' targeting is the player's and GM's call.
- **FC-89 Versatile Binder [ADEPT METAMAGIC]** (C) — C — the binding replaces the summon in the control register; which existing creature may be bound is the GM's call.
- **FG-20 Magic Sense** (D) — D — the sense's range is never printed and the check is GM-called on GM knowledge (an aura present).
- **FG-24 Mirrored Rebuke** (C) — C — the Dispel riders are automated; re-casting the reflected spell from the caster runs through the system's stored-cast path but its re-targeting is a choice the player makes.
- **FG-25 Mnemonic Grasp** (D) — D — a learning/downtime shortcut with no roll the system can resolve.
- **FG-26 Piercing Insight** (C) — C — Sense Power is a GM-adjudicated detection; applying metamagic to it is a reminder only.
- **FG-37 Spell Transcription** (C) — C — unlocks the scroll's Create route for the identified spell; the 24-hour window is tracked, the materials are the GM's.
- **FG-39 Spirit Whisper** (D) — D — communication; nothing to calculate.
- **FG-42 Wanderer’s Mastery** (C) — C — the sense and the party saving-throw bonus are automated; 'immunity to becoming magically lost' is a narrative GM rule.
- **GD-10 Crystal Phials** (D) — D — protecting contents from magical damage is narrative; the item has no rolled effect.
- **GD-13 Etheric Ink** (D) — D — the −5 applies to a forger's check the GM calls; noted on the item.
- **GD-18 Leyline Satchel** (D) — D — shielding carried items from ley interference has no rolled effect.
- **GD-26 Umbral Lantern** (C) — C — light is automated; seeing through illusions and invisible silhouettes is revealed by the GM.
- **RR-002 High Magic Spells** (D) — D — Narrative only; rules are in Ch.7
- **S-003 Alter Corpse** (D) — D — Corpse state is narrative
- **S-010 Archway Of Ants** (C) — C — Structure placement and load are GM-adjudicated
- **S-011 Argent Mark** (D) — D — Tracking info is narrative
- **S-013 Army Of The Grave** (C) — C — Undead selection and corpse supply are GM-driven
- **S-014 Blood Biography** (D) — D — Information delivered by GM
- **S-018 Call Of The Ancestors** (D) — D — Q&A narrative; only backlash damage automatable
- **S-019 Chaos Shield** (C) — C — 'Better' surge result and backlash resistance need GM
- **S-021 Concord Of Stone** (C) — C — Zone-wide structure DR is scene-level
- **S-022 Dark Whispers** (D) — D — Communication effect
- **S-033 Essence Reforging** (C) — C — Race change and resurrection need GM/manual
- **S-036 Farsight** (D) — D — Vision range is narrative
- **S-040 Freshmark** (D) — D — Cosmetic only
- **S-044 Leyline Anchor** (C) — C — '1 PP lower' and failed-tap outcome undefined
- **S-048 Message Rune** (D) — D — trigger condition and message are narrative
- **S-050 Mimic Spell** (C) — C — stores arbitrary foreign spell; DC basis undefined
- **S-057 Phase Door** (D) — D — scene/terrain effect
- **S-060 Pledgeshroud** (D) — D — narrative restriction
- **S-063 Reckoning Glance** (D) — D — GM narration
- **S-064 Rippling Gaze** (D) — D — scrying narrative
- **S-065 Riserune** (D) — D — narrative alarm
- **S-066 Rite Of Binding Oath** (C) — C — oath-breaking is GM-judged
- **S-067 Rite Of Echoed Shadows** (C) — C — zone entry tracking; failure summons undefined
- **S-070 Soul Confluence** (C) — C — shared pool across actors; backlash lethal as written
- **S-073 Symbol Of Death** (C) — C — GM decides who looks
- **S-074 Symbol Of Fear** (C) — C — GM decides who looks
- **S-075 Symbol Of Insanity** (C) — C — GM decides who looks
- **S-076 Symbol Of Pain** (C) — C — GM decides who looks
- **S-077 Symbol Of Weakness** (C) — C — GM decides who looks
- **S-078 Traveller’s Charm** (D) — D — overland travel narrative
- **S-080 Veilfracture** (D) — D — planar portal narrative
- **S-082 Veil Severing** (D) — D — portal narrative; outcomes wrong
- **S-083 Wall Of Sand** (C) — C — wall template + section HP
- **SS-009 Cloak Of The Deceiver** (C) — C — Disguise appearance is narrative; bonus automatable.
- **SS-013 Disrupt Magic** (C) — C — Counterspell timing against an in-progress cast needs core hook.
- **SS-015 Familiar Senses** (C) — C — Sense sharing is mostly narrative.
- **SS-019 Ley Sever** (C) — C — Halving a chosen spell variable needs GM choice.
- **SS-034 Storing Rune** (C) — C — Needs core deferred-cast/stored-spell support.
- **RR-004 Chapter 8 – Magic Items** (D) — D — chapter introduction; no rule to automate (journal entry)
- **RU-005 Catalyst** (D) — D — Tier effect missing; embed use undefined.
- **RU-017 Veil** (C) — C — Incorporeal state and duration undefined.
- **AR-004 Shadeskin** (C) — C — Veil incorporeal state undefined.
- **RR-010 Charge Depletion (Orbs)** (C) — C — post-flare item state and surge magnitude undefined
- **RR-016 Wondrous Items** (D) — D — chapter introduction; no rule to automate (journal entry)
- **RR-017 The Nature Of Relics** (D) — D — flavour text; journal entry
- **RR-019 Creating Relics (Steps 1-4)** (D) — D — GM design guidance for building new relics; no runtime effect (journal entry)
- **TB-002 Tier Benefits** (D) — D — GM design guideline for new relics; the four printed relics carry their own tier data, which is automated
- **RR-021 Gm Balance Notes** (D) — D — treasure-allocation advice for the GM; no runtime effect
- **RR-022 Sentient Items / Sentient Item Traits** (D) — D — GM design baseline for sentient items; the printed sentient item (Dawnshield) carries its own data
- **RR-023 Determining Sentience** (D) — D — GM design choices; the roll tables that support them are automated (TB rows)
- **RR-024 Special Abilities** (C) — C — example menu for GM design; the printed abilities on Dawnshield are automated, new ones are the GM's
- **RR-026 Influence** (C) — C — the Will save against the Ego DC is rolled and the degree posted; suppression, refusal and domination are GM-run, and the Ego DC formula is unprinted (audit)
- **RR-028 Hidden Powers** (D) — D — powers the item uses on its own when it exerts influence; GM-run
- **RR-030 Growth & Advancement** (D) — D — story-milestone growth decided by the GM; no trigger the system can see
- **RR-038 Summons (Trait)** (C) — C — the trait marks summoned beings for circles and true names (automated); "independent being bound by duration" is applied through the core summon register where the spell uses it
- **TB-007 Index** (D) — D — book index; no mechanics
- **RR-039 Open Game License Version 1.0a** (D) — D — licence text; included in the module README and journal

## Features whose class depends on a core change

| ID | Feature | With core | Without | Dependency |
|---|---|---|---|---|
| SYS-01 | High Magic spells: no tradition or school | A | C | D1 |
| SYS-04 | High Magic casting DC Hard (+2) | A | C | D1 |
| SYS-05 | No casting focus for High Magic (Arcanum or Archmage excepted) | A | C | D1 |
| SYS-06 | High Magic armour penalty: DC + armour DR ×4 | A | C | D1 |
| SYS-07 | High Magic spell fumble | A | C | D1, D6 |
| SYS-08 | High Magic Resonance with disadvantage | A | C | D1, D6 |
| SYS-12 | New traits: Berserker, Highmagic, Orb, Relic, Ritual, Sentient, Summons | A | C | D7 |
| RA-10 | Ley Line Connection | A | C | D1 |
| H-12 | Zhal-vryn | A | C | D5 |
| CL-01 | Archmage (class) | A | C | D1, D4 |
| CL-02 | Archmage spellbook and memorisation | A | C | D4 |
| CL-03 | Archmage cantrips (6 known, memorise 3) | A | C | D4 |
| CL-04 | Ley Bond | A | C | D1 |
| CL-08 | Sorcerer (class) | A | C | D1, D4 |
| CL-09 | Raw Power | A | C | D5 |
| CL-11 | Sorcerer spell repertoire (two tracks) | B | C | D4 |
| CL-13 | Spellblade (class) | A | C | D4 |
| CL-15 | Battle Mage | A | C | D17 |
| CL-17 | Spellblade spellcasting | A | C | D4 |
| CL-18 | Warlock (class) | A | C | D1, D9 |
| CL-19 | Xithra | A | C | D9 |
| CL-20 | Warlock innate spell picks | B | C | D9 |
| CL-22 | Warlock cantrips | A | C | D9 |
| CL-24 | Witch (class) | A | C | D1, D4 |
| CL-25 | Soulbound Familiar | B | C | D8 |
| CL-27 | Witch spells | A | C | D1 |
| BR-02 | Dragon (birthright) | B | C | D17 |
| BS-01 | The Celestial Sentinel | B | C | D9 |
| BS-02 | The Crystal Archon | B | C | D9 |
| BS-03 | The Emberlord | A | C | D9 |
| BS-04 | The Infernal Tempter | B | C | D9 |
| BS-05 | The Pale Reaper | B | C | D9 |
| BS-06 | The Verdant Spirit Walker | B | C | D9 |
| BS-07 | The Void Seer | A | C | D9 |
| BS-08 | The Whispered Sage (Shade) | B | C | D9 |
| SA-05 | Spell Trickery | B | C | D2 |
| SA-12 | Tap Magical Energy | B | C | D12 |
| GEAR-03 | Weapon trait: Adept | A | C | D18 |
| GEAR-05 | Weapon trait: Ritualist | A | C | D13 |
| GEAR-09 | Using catalysts (rules) | A | C | D2, D3 |
| M7-02 | Ley Line Effects table (d100, 33 rows) | B | C | D5 |
| M7-05 | Wild Mage surges | A | C | D6 |
| M7-06 | Magic Suppression Areas | B | C | D6, D7 |
| M7-09 | Ritual variant: non-caster primary caster | B | C | D13 |
| M7-10 | PP substitution: Vital, Material, Communal | B | C | D13 |
| M7-11 | Ritual-trait spells: extra effects by ritual check | A | C | D13 |
| MAT-01 | Ashbone | A | C | D18 |
| MAT-02 | Bloodglass | A | C | D18 |
| MAT-03 | Bloodwood | A | C | D18 |
| MAT-04 | Eversmoke Cloth | A | C | D18 |
| MAT-05 | Graveiron | A | C | D18 |
| MAT-06 | Nightsteel | A | C | D18 |
| MAT-07 | Starion | A | C | D18 |
| MAT-08 | Sunbronze | A | C | D18 |
| MAT-09 | Tairneach | A | C | D18 |
| MAT-10 | Veilglass | A | C | D18 |
| GD-04 | Bloodscribe’s Bowl | B | C | D13 |
| GD-21 | Runestone Chalkboard | A | C | D13 |
| CAT-01 | Arcanite Powder | A | C | D3 |
| CAT-02 | Ashen Lotus Bloom | A | C | D3 |
| CAT-03 | Blood-etched Vellum | A | C | D3 |
| CAT-04 | Celestial Dewdrop | A | C | D3 |
| CAT-05 | Chained Obsidian Bead | A | C | D3 |
| CAT-06 | Cinders of the First Flame | A | C | D3 |
| CAT-07 | Dragonbone Dust | A | C | D3 |
| CAT-08 | Eclipse Resin | A | C | D3 |
| CAT-09 | Frozen Marrow Shard | A | C | D3 |
| CAT-10 | Glimmercoal | A | C | D3 |
| CAT-11 | Grave Soil | A | C | D3 |
| CAT-12 | Incense of Stillness | A | C | D3 |
| CAT-13 | Leydust | A | C | D3 |
| CAT-14 | Moonveil Dust | A | C | D3 |
| CAT-15 | Phoenix Feather Ash | A | C | D3 |
| CAT-16 | Resonant Crystal Shard | A | C | D3 |
| CAT-17 | Sanctified Myrrh | A | C | D3 |
| CAT-18 | Sands of the Hourglass | A | C | D3 |
| CAT-19 | Spell Incense | A | C | D3 |
| CAT-20 | Starpetal Oil | A | C | D3 |
| CAT-21 | Stormglass Phial | A | C | D3 |
| CAT-22 | Verdant Sap | A | C | D3 |
| CAT-23 | Void Ash | A | C | D3 |
| CAT-24 | Whisperglass Shard | A | C | D3 |

## Features blocked on a ruling

- **SYS-01 High Magic spells: no tradition or school** — EA-M4
- **SYS-03 Learning High Magic spells; caster style per class** — EA-M19
- **SYS-04 High Magic casting DC Hard (+2)** — EA-M4
- **SYS-07 High Magic spell fumble** — EA-M4
- **SYS-12 New traits: Berserker, Highmagic, Orb, Relic, Ritual, Sentient, Summons** — EA-M27
- **RA-07 Magic Drain** — EA-M24
- **RA-08 Null Aura** — EA-C1, EA-M22
- **H-11 Vir-ellian** — EA-M24
- **CL-02 Archmage spellbook and memorisation** — EA-M16
- **CL-14 Infuse Weapon** — EA-M14
- **CL-16 Spellblade bonus feats** — EA-M17
- **CL-17 Spellblade spellcasting** — EA-M13
- **CL-20 Warlock innate spell picks** — EA-M19
- **CL-21 Warlock hexes** — EA-M28
- **CL-30 Witch bonus feats** — EA-M15
- **BR-01 Arcanum (birthright)** — EA-M1
- **BR-02 Dragon (birthright)** — EA-M1, EA-M2
- **BR-03 Eternity (birthright)** — EA-M2
- **BR-07 Wild (birthright)** — EA-M7
- **BS-01 The Celestial Sentinel** — EA-M2
- **SA-01 Ley Sense** — EA-M5
- **SA-10 Channel Ley Line** — EA-M5, EA-M6
- **SA-11 Tap Ley Line** — EA-M5, EA-M6
- **SA-12 Tap Magical Energy** — EA-C3
- **GEAR-09 Using catalysts (rules)** — EA-M18
- **M7-01 Ley line levels and Sense DCs** — EA-M5
- **M7-02 Ley Line Effects table (d100, 33 rows)** — EA-M6
- **M7-04 Wild Surge table (d100)** — EA-M7
- **M7-06 Magic Suppression Areas** — EA-M8
- **M7-07 Suppression backlash table (d100)** — EA-M8
- **M7-12 Summoning circles** — EA-M9
- **FR-03 Alchemical Purifier [FOCUS SCAELYN]** — EA-M2
- **FR-13 Crystal Pulse [NYRINN]** — EA-M24
- **FR-20 Elemental Breath [ELEMENTAL FOCUS INVOCATION SAVE SCAELYN]** — EA-M11
- **FR-63 Tideweaver’s Resilience [EMBERKIN HEALING]** — EA-M12
- **FA-02 Birthrager [BERSERKER]** — EA-M23
- **FA-08 Eternal Vigil [SORCERER]** — EA-M3
- **FA-13 Hex Weaver [ADEPT]** — EA-M19
- **FA-15 Leyline Weaver [ADEPT]** — EA-M25
- **FA-16 Runeblade [SPELLBLADE]** — EA-M14
- **FA-17 Runebreaker [SORCERER]** — EA-M3
- **FA-18 Shade Master [SORCERER]** — EA-M3
- **FA-20 Spell Duellist [SPELLBLADE]** — EA-M26
- **FA-22 Stormcaller [SORCERER]** — EA-M3
- **FC-12 Confluence Master [LEYLINE-WEAVER]** — EA-M25
- **FC-48 Leyline Anchor [LEYLINE-WEAVER]** — EA-M25
- **FC-49 Leywalk [LEYLINE-WEAVER]** — EA-C7
- **FC-60 Pact Ascendant [WARLOCK WITCH]** — EA-M2
- **FC-61 Pact Boon [WARLOCK WITCH]** — EA-M2
- **FC-62 Pact Channeler [METAMAGIC WARLOCK WITCH]** — EA-C2
- **FC-78 Spellblade’s Mark [CONCENTRATE FOCUS INVOCATION SPELLBLADE]** — EA-M26
- **FC-91 Warlock’s Hex [FOCUS WARLOCK]** — EA-C2
- **FG-28 Ritual Expert** — EA-M21
- **FG-29 Rune-Binder’s Precision** — EA-M21
- **FG-35 Spell Surge** — EA-M20
- **CAT-07 Dragonbone Dust** — EA-M10
- **S-001 Acidic Burst** — EA-M32
- **S-004 Animal Binding** — EA-M31
- **S-006 Arcane Bastion** — EA-M33
- **S-008 Arcane Mycelium** — EA-M34
- **S-013 Army Of The Grave** — EA-M30
- **S-014 Blood Biography** — EA-M35
- **S-018 Call Of The Ancestors** — EA-M30
- **S-019 Chaos Shield** — EA-M36
- **S-020 Chronoweave** — EA-M29, EA-M37
- **S-021 Concord Of Stone** — EA-M30, EA-M38
- **S-025 Dreadmote** — EA-M39
- **S-027 Eaog Balls** — EA-M40
- **S-028 Elemental Binding** — EA-M31
- **S-029 Elemental Strike** — EA-M41
- **S-031 Elemental Convergence** — EA-M30, EA-M42
- **S-032 Entity Binding** — EA-M31
- **S-033 Essence Reforging** — EA-M29, EA-M43
- **S-034 Eternal Binding** — EA-M31
- **S-038 Fey Binding** — EA-M31
- **S-039 Flesh To Blossom** — EA-M44
- **S-044 Leyline Anchor** — EA-M45
- **S-047 Memory Eclipse** — EA-M29, EA-M46
- **S-049 Metamagic Resonance** — EA-M47
- **S-050 Mimic Spell** — EA-M48, EA-M49
- **S-056 Panic Transposition** — EA-M50
- **S-060 Pledgeshroud** — EA-M51
- **S-061 Primal Snap** — EA-M52
- **S-062 Prismatic Guard** — EA-M53
- **S-067 Rite Of Echoed Shadows** — EA-M54
- **S-068 Spectral Aegis** — EA-M55
- **S-070 Soul Confluence** — EA-M29, EA-C4
- **S-071 Storm Of Unmaking** — EA-M29, EA-M56
- **S-073 Symbol Of Death** — EA-M57
- **S-077 Symbol Of Weakness** — EA-M57
- **S-080 Veilfracture** — EA-M29
- **S-082 Veil Severing** — EA-C5
- **S-084 Word Of Pain** — EA-M58
- **S-086 Zone Disruption** — EA-M59, EA-M60, EA-M62
- **SS-002 Ancient Aegis** — EA-M60
- **SS-004 Armouring** — EA-M62
- **SS-008 Cackle** — EA-M63
- **SS-009 Cloak Of The Deceiver** — EA-M64
- **SS-010 Delay Affliction** — EA-M65
- **SS-012 Draconic Infusion** — EA-M66
- **SS-013 Disrupt Magic** — EA-M67
- **SS-014 Evershade Veil** — EA-M60
- **SS-016 Hemocovenant** — EA-M68
- **SS-018 Ley Bolt** — EA-M60, EA-M69
- **SS-020 Life Boost** — EA-M70
- **SS-022 Missed Chance** — EA-M71
- **SS-023 Paradox Weave** — EA-M72
- **SS-030 Shielding Strike** — EA-M73
- **SS-032 Siphon Vitae** — EA-M74
- **SS-035 Storm Bolt** — EA-M75
- **SS-036 Shard Cloud** — EA-M76
- **RU-005 Catalyst** — EA-C6
- **RU-011 Nullflow** — EA-M77
- **RU-017 Veil** — EA-M78
- **AR-001 Spellguard** — EA-M79
- **AR-004 Shadeskin** — EA-M78
- **AR-005 Whispering Hollow** — EA-M80, EA-M81, EA-M82, EA-M83
- **RR-007 Using Spellcraft** — EA-M81
- **RR-008 Using The School Tradition Skill** — EA-M80
- **RR-010 Charge Depletion (Orbs)** — EA-M82, EA-M83
- **OR-002 Orb Of The Shattered Veils** — EA-M85
- **OR-005 Orb Of The Whispering Veil** — EA-M84
- **RD-004 Rod Of Ley Resonance** — EA-M86
- **RD-009 Rod Of Wild Surges** — EA-M87
- **ST-003 Staff Of Flame** — EA-M88
- **ST-006 The Weavers Delight** — EA-M89
- **RU-020 Chrono** — EA-M90
- **RU-021 Echoing** — EA-M91
- **RU-024 Leybound** — EA-M92
- **RU-029 Sanguine** — EA-M93
- **RU-030 Spellhold** — EA-M94
- **RU-031 Summoner’s Brand** — EA-M95
- **SW-001 Bleeding Crown** — EA-M96
- **SW-004 Starfall** — EA-M98, EA-M99
- **RR-015 Relic Bonding Ritual** — EA-M97
- **RR-018 Rules For Relics** — EA-M98
- **TB-002 Tier Benefits** — EA-M99
- **RR-020 Relics & Investment** — EA-M98
- **RL-001 The Aegis Of Valtea** — EA-M100, EA-M101, EA-M104, EA-M105
- **RL-002 Emberfang** — EA-M100
- **RL-003 Obsidian Codex** — EA-M100, EA-M102
- **RL-004 The Veilshroud** — EA-M100, EA-M101, EA-M103, EA-M106, EA-M107, EA-C8, EA-M108, EA-M109, EA-M110
- **RR-025 Ego & Conflict** — EA-M111
- **RR-026 Influence** — EA-M111
- **WO-001 Dawnshield** — EA-M112
- **RR-032 Berserker (Trait)** — EA-M23
- **RR-033 Highmagic (Trait)** — EA-M27

