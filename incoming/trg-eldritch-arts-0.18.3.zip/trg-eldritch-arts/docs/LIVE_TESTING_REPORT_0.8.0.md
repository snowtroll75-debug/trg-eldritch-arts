# Eldritch Arts 0.8.0 and TRG Prime 3.683.0 — Live Testing Report

4 November 2026. Tested in Foundry V14 (14.367), world "TRG V14", as Gamemaster in Chrome, after Graham installed TRG Prime 3.683.0 and Eldritch Arts 0.8.0. Inner Tempest, Pillars of Faith and Fiends & Fables were active.

**Throwaway material, all deleted afterwards:**
- **The scene** "ZZ EA Block 5" (5 ft squares).
- **Eight "ZZ EA" characters:**
  - three Scaelyn: Wyrmdral, Dustscale and Glyphweave;
  - two Emberkin: Cinderblood and Tidemarked;
  - an Aetherial (Umbryth);
  - a Nyrinn;
  - an Elf, an Ascendan, and a Human Wizard ("ZZ EA Caster").
- **The feats under test** were added from the module's compendium. Two copies of Daze were made with one tradition, arcane: one plain, one carrying the Highmagic trait.

**What was changed, and put back:**
- **None of Graham's actors was touched.** His running combat was left as it was.
- **Dice:** `CONFIG.Dice.randomUniform` was set for the tests, then restored.
- **The scene's darkness** was raised for one test and lowered again; the scene was then deleted.
- **Removed:** the 59 test chat cards, the actors and the scene. The test's Conviction hook came off.
- **The view** went back to Oldwatch Approach.

**On load:**
- **Versions:** 3.683.0 and 0.8.0.
- **"Eldritch Arts: Feats"** holds 117 feats.
- **The companion API** reports no registration problems, and all six new helpers are present.
- **No errors** from TRG Prime or Eldritch Arts during the run.

## Results

| # | Test | Result |
|---|---|---|
| 1 | **Heritage prerequisites** (C1, Q57): the Racial Feat picker's filter for a Wyrmdral, a Dustscale (both Scaelyn, 5th) and an Elf (1st) | **Pass.** The Wyrmdral is offered Elemental Breath and not Sandstrider; the Dustscale the reverse. Twelve Scaelyn feats each. The Elf is offered Moonlight Precision and Ancestral Reverie (Elf feats), and not Feyblood Glamour (Gnome). |
| 2 | **Forbidden Magic against High Magic** (Q58): an arcane Daze and a Highmagic Daze at an Ascendan | **Pass.** The arcane copy: the Will save had no Forbidden Magic row. The Highmagic copy: "Forbidden Magic Race −2". (Core Daze, arcane, divinity and ethereal, takes the −2 as before.) |
| 3 | **Unbound** (Q59) | **Pass.** With the feat, the Highmagic Daze's save had no −2. |
| 4 | **Emberborn Fury** (C6): a Cinderblood's Orb of Fire | **Pass.** "Spell damage per die (fire): Emberborn Fury +1 per die × 1 die = +1", beside Elemental Surge's +1: 1d6 + 1 + 1. |
| 5 | **Anchor in Nothing and Voidbound Resolve** offered before a Nyrinn's Will save | **Pass.** Anchor was asked first; declined, Voidbound was asked ("one of 3 uses today"), and its +2 racial was on the roll before the dice. |
| 6 | **Voidbound's backlash** | **Pass.** A 6 + 3 (Null Aura) failed DC 11; the +2 made it 11. The card read "The +2 made the save", and the caster took 3d4 mental, basic Will against its own Level DC 19 (a Fumble, 12 mental and a minor critical). |
| 7 | **Anchor in Nothing** taken (C2 `declare`) | **Pass.** "Success Declared — the dice do not count" (a 9 against DC 11). Voidbound was not asked after it. Today's use was spent (0 of 1). |
| 8 | **Tideweaver's Resilience** (C7): 31 damage on a Tidemarked at 30 HP | **Pass.** Asked "stay at 6 HP?" (level 6 + Wisdom 0). Taken: 6 HP, no Dying. |
| 9 | **Dispel Power and Threadbreaker's Precision** (C9) on a 5th-level Wizard: a Dispel opened as a counter (an effect of level 2, its caster named), as Disrupting Magic opens one | **Pass.** The Dispel prompt showed Threadbreaker ("applies") and Dispel Power as a tick. Ticked: "Counteract (5 … vs 2) +6", "Threadbreaker's Precision Race +2", "Very hard (DC +5)". A Critical. PP 20 → 20, the Focus use spent, and the caster Dazed 1 until the end of its next turn. |
| 10 | **Veil of Silence** (C4): an Umbryth's Stealth, in daylight and in the dark | **Pass.** Daylight: no row (14). Darkness 1: "Veil of Silence Race +2" (16). |
| 11 | **Glyph Unleashed against a save** (C2 `modifiers`, Q80) | **Pass.** Asked "Inscribe the ward". Taken: "+2 racial against ZZ Arcane Daze" before the dice, the Focus use spent, and the ward recorded on the actor. |
| 12 | **Glyph Unleashed against a spell attack** (C3) | **Pass.** Orb of Fire at the Glyphweave: "Reaction … Glyph Unleashed — +2 racial to your DB against this spell". Taken: DB 14 (the 14 attack still hit: ties hit). |
| 13 | **Alchemical Purifier at 5th** (Q76) | **Pass.** Stinking Cloud and Neutralise Poison were granted innate and Focus, with an allowance of 1. Neutralise Poison (PP 6) was cast at level 5, not refused. |
| 14 | **Relentless Will** (C8) | **Pass.** The first Dying was marked ("Today's use is spent"). Healing out of Dying: "leaves Dying without gaining a point of Fatigued". Advantage was readied for when HP rises above 0. |

**Seen on the way, Block 1's own:** the Nyrinn's Null Aura reached a nearby caster ("casting DC +3, applied as −3"), and lent the Nyrinn its +3 on Will saves.

**Not tested live** (the harness covers them):
- **Need a connected player or a running combat of our own:** the flight and glide turn counts (Voidborn Wings and Grace), Skyborne Agility and Astral Drift's movement count, Veil of Honour's stance.
- **Mirrored Rebuke's reflection.**
- **The metamagic and catalyst feats,** which are cards until Blocks 6 and 9.

No findings.

## Graham's answers (4 November)

- **Q58's reach:** "Yes", read as confirming it as built. An Ascendan without Unbound makes the Will save against its own beneficial High Magic spell. Tradition-scoped bonuses see every tradition against High Magic.
- **The per-die bonus counts a critical's extra dice:** "Yes".
- **Charismatic Caster gated to 1st level:** "Yes", as 3.683.0 does.
