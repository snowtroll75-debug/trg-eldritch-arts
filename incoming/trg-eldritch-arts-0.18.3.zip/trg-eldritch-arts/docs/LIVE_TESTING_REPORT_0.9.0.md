# Eldritch Arts 0.9.0 and TRG Prime 3.684.0 — Live Testing Report

4 November 2026, evening. Run in Foundry V14, world "TRG V14", as Gamemaster, after Graham installed TRG Prime 3.684.0 and Eldritch Arts 0.9.0.

**Partial run: no map.** Chrome's Claude extension could not connect to this session, so the test ran in the Claude desktop app's built-in browser. That pane stayed at a 0×0 window, so Foundry could not draw its canvas.
- **What ran:** every test that needs no tokens on a map, below.
- **What didn't:** the tests that need tokens are listed under "Not tested live", for a run with a visible browser.

**Throwaway material, all deleted afterwards:**
- **Six "ZZ EA" characters:** two Warlocks, two Sorcerers (one Rune, one Bloodmage), an Eternity Sorcerer (Eternal Vigil) and a 10th-level Wizard (Spell Weaver).
- **The scene** "ZZ EA Block 6". Only the tester's own view was switched to it.

**What was changed, and put back:**
- **None of Graham's actors was touched.** His running combat (5 combatants) was left as it was.
- **Dice:** `CONFIG.Dice.randomUniform` was set for the tests, then restored.
- **Removed:** the test's dialog and chat hooks, its 51 chat cards, the actors and the scene.

**On load:**
- **Versions:** 3.684.0 and 0.9.0.
- **Packs:** "Eldritch Arts: Feats" holds 237 feats.
- **The companion API** reports no registration problems. All 23 Eldritch Arts archetypes are registered (High Mage opens the Sorcerer's Adept feats), and so are the 20 module metamagic options.
- **No errors** from TRG Prime or Eldritch Arts. The only errors were the 0×0 window's own, and one from a malformed XP value the tester typed (corrected at once).

## Results

| # | Test | Result |
|---|---|---|
| 1 | **The Warlock's pool** (Q97): a 5th-level Warlock, Charisma 3, sheet tradition blank, PP 0. The Bonded Soul's Use; the Void Seer chosen | **Pass.** The next prompt was "Your Charisma PP pool needs a magical tradition: which of your soul's two is yours? Arcane / Ethereal". Arcane was written to the sheet, and the pool became 3 PP. |
| 2 | **Archetype gating and progression** (G8, G9, Q90). The sheet's own Class Feat picker, then Void Pact taken at 5th | **Pass.** Before Void Pact, the picker offered the Warlock's and Metamagic feats and none gated on an archetype he lacks (Chronostasis, Fate's Favour, Overflow Casting, Sanguine Channel, Steelbinding), nor Arcane Study. Void Pact was stamped "taken at level 5" for this character. The core's reason reads "…met at level 15, so no other archetype feat is offered until then", and the Archetype picker opened on nothing. Pact Channeler ("Level 6, Pact Archetype feat") appeared at 6th. A Pact-less Warlock was refused it: "it needs a Pact archetype feat". |
| 3 | **One Pact** (Q92) and **High Mage's "Non-Sorcerer"** (review fix) | **Pass.** Angelic Pact on the Void Pact Warlock: refused, "a character may hold only one Pact feat". High Mage on a Sorcerer: refused, "a Sorcerer may not take it (Non-Sorcerer)". |
| 4 | **Module metamagic in the Warp? dialog** (G1): a Rune Sorcerer's Mage Armour with Focused Spell | **Pass.** Focused Spell (+3 PP) and Sensory Spell (+1 PP) were listed under "Metamagic Feats" beside the core's. Taken: "5 PP (2 base + 3 metamagic), Casting DC 19", rolled with advantage ("10 10, Advantage"). It came up a Partial: "The spell fails. No PP lost". On an earlier try the 5 PP cast was over the cap, and the core offered Overcasting by Sacrifice; declined, nothing was spent. |
| 5 | **Storing Rune** (G16's fix): the Rune Sorcerer casts Storing Rune, then Mage Armour, then releases it | **Pass.** "The next spell cast this round is stored in Storing Rune". Mage Armour was then "stored in Storing Rune — 2 PP spent now… Release it for 1 AP from your Magic tab", with the record on the Storing Rune spell itself, not an Arcane Bond. Released by its own host: cast from the store, a Partial, "2 PP returned", and the store cleared. |
| 6 | **Eternal Vigil at 0 HP** (G7, Q109): 32 slashing on an Eternity Sorcerer at 30 HP | **Pass, the cancel half.** The offer read "ZZ test blow takes ZZ EA Vigil to 0 HP. Cast Touch of Healing on yourself as a free action…". Taken, it went to target selection: the caster has no token without a map. It targets its own token when there is one. Going back cancelled the cast, so the use was kept (1 of 1), no PP was spent, and he fell as normal (Dying 1, Prone). The healed-from-0 half needs a token. |
| 7 | **Fate's Favour** (G18, Q110): a Will save against DC 30 with Conviction spent for advantage | **Pass.** The first of the day: "Fate's Favour — the conviction point spent on advantage is not expended", Conviction 2 → 2, and the day's use marked. The second that day: Conviction 2 → 1, no refund. (A +1d6 Conviction spend is not the advantage spend, and isn't refunded, as written.) |
| 8 | **Bloodmage's Bleed** (G2): Mage Armour with the +4 PP DR warp, 6 PP against a pool of 3 | **Pass.** A Bleed step after the Warp?: "costs 6 PP; you have 3… at least 1 PP stays yours (up to 5 here). The cap and the Casting DC read the spell's full PP". 3 were paid by Bleed. The card read "6 PP (2 base + 4 warp), Casting DC 21", the pool went 3 → 0, and "Bloodmage: 3 PP paid in blood — Bleeding +3". |
| 9 | **Overflow Casting** (review fix: Soul Drain added once). A 10th-level Spell Weaver: Reservoir empty, 3 HP, Soul Drain 4; Mage Armour with the −2 PP Reservoir option | **Pass.** The Reservoir's options were offered with no charges left. The cast: "Overflow Casting: 1 charge you did not have — 2d6 = 12 damage, ignoring your defences (its Focus use spent). You are at 0 HP or less: you gain 5 Soul Drain". The Soul Drain card: "Soul Drain 4 → 9" (not 13). The Reservoir stayed at 0. |

## Finding

**F1, cosmetic, from Block 1 on:** every Eldritch Arts spell (49) uses the default image `icons/svg/holy-symbol.svg`, which Foundry V14 doesn't have. So each shows a broken image and the console logs a 404. It comes from `tools/content/builders.mjs`'s default spell image. The fix is to use an image V14 ships, in the next release.

## Not tested live (no map)

The harnesses cover these. They need tokens, for targets, ranges, areas or a cast reaction, so they wait for a run with a visible browser:
- **Cast reactions:** Absolute Denial, Counter Channel and Runebreaker against an innate spell (the review's `castPP` fix).
- **Defence bonuses on spell attacks:** Forbidding Ward and Spellblade's Mark against a spell attack (G20).
- **Strikes, curses and Xithra:** Warlock's Hex and Hex Binders Curse; the Xithra feats; Spellblade's Mark; Spell Duellist; Spellstrike Riposte.
- **Ley lines:** Tap Ley Line with Leyline Weaver; Ley-Etched Symbol.
- **Second targets and areas:** Echo of the Ancestors, Lightning Rod, Thunderclap Aura, Steelbinding.
- **The Witch's familiar:** Symbiotic Witch.
- **The 0 HP spells:** Eternal Vigil's healed-from-0 half, and Subconscious Casting.
- **No class in the compendium:** Birthrager casting while raging (G10). There is no Berserker class item to build one from.
