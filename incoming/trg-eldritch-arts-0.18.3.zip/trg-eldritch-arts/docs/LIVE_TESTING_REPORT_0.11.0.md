# Live test: Eldritch Arts 0.11.0 on TRG Prime 3.686.0

9 November 2026. Graham's world in Chrome, on Foundry 14.367 with TRG Prime 3.686.0 and Eldritch Arts 0.11.0 active.

The tests used:
- throwaway actors: "ZZ EA Wizard" (level 20), "ZZ EA Foe" and "ZZ EA Ally" (both level 8 Fighters), and "ZZ EA Wolf" (level 1, Animal);
- a throwaway scene, "ZZ EA 8a Test".

Dice were fixed for each test. Everything was cleaned up afterwards.

## Results

### TRG Prime 3.686.0: all pass

**Remove Curse (H17): pass.**
- It refused a target 15 ft away (touch is 5 ft).
- On an adjacent foe held by Symbol of Pain's curse, the counteract dialog used the symbol's own figures: 12 PP and DC 26.
- The curse was counteracted, and the injured 2 it held went with it.

**The curse's hold (H17): pass.**
- A 24-hour injury rest left the held injured 2 at 2.

**Insanity's turn table (H18): pass.** The foe failed its Will save by 9, so it was insane for 4 rounds. It already had slowed 1 from another source.

| Foe's turn | d10 | Result |
|---|---|---|
| 1 | 6 | Slowed 1 → 3 "for this turn". |
| 2 | 10 | Confused for 1 round. Slowed had been raised to 4 by another source in between, and it stayed at 4: the roll didn't take back its rise. |
| 3 | 1 | Unaffected. Confused was removed. Slowed 4 was untouched. |
| 4 | 6 | "Already Slowed 4: no higher this turn". |
| 5 | — | "is itself again". The marker was gone, slowed 4 remained, and there were no console errors. |

- In combat, the marker had no world-clock end, as designed.

**Control register (H12): pass.**
- Animal Binding put the wolf on the wizard's register as "Bound" (1 of 44 Control Levels).
- Dismissing the spell emptied the register.

**The "until dismissed" lock: pass.**
- Animal Binding locked its PP ("until this spell is dismissed").
- Dismissing it released the 2 PP.

### Eldritch Arts 0.11.0

**Symbol of Pain: pass.**
- Carved by clicking an adjacent square. The card was whispered to the GM, and the Region was hidden.
- **The symbol flashes** listed all four tokens in sight. Unticking left only the foe.
- Fortitude Failure: injured 2, held by the curse.

**Symbol of Weakness: pass.**
- A Partial gave weakened 2, held.
- Moving the foe more than 60 ft away started the curse's one-hour clock.
- Coming back within 60 ft stopped it.

**Symbol of Death: pass.**
- Carved, with "16 PP locked until this spell is dismissed".
- A Partial on the flash rolled a deadly essence critical (Weakened 1, legs).
- Dismissing the spell released the PP and removed the symbol.
- A later press of **The symbol flashes** was refused with "that symbol is gone".

**Animal Binding: pass.**
- The GM card asked for the creature, and **Bind the selected creature** rolled the wolf's Will save at DC 18.
- A Fumble bound the wolf with "+2 circumstance to all its checks while it serves" and a "Bound to ZZ EA Wizard" effect.
- Dismissing the spell removed the effect and posted "returns to where it was summoned from — GM, remove its token".

**Wall of Sand: pass.**
- The warp dialog offered +10 ft long and +5 ft high as separate choices.
- With the height bought, the card read "a wall 20 ft long, 15 ft high".

**Harmonic Rift: two failures.**
- **What passed:**
  - The two openings were placed by two clicks.
  - Out of combat, the ally moving into opening 1 stepped out of opening 2, and no Spatial Awareness card was posted. That is correct: teleport cards are combat-only.
  - In combat, the hostile foe moving into opening 2 came out of opening 1, got the Spatial Awareness card, and took the basic Fortitude save against 3d8 sonic.
- **Fail 1, leaving an opening:** a token moving *out* of an opening is sent through the rift.
  - The foe stood in opening 1 and, the next round, moved well clear. It was teleported to opening 2 and took the sonic damage again.
  - In the same turn, leaving posted "a second teleport this turn fails" twice.
  - Cause: the module checks the token's regions from before the move.
- **Fail 2, the save line:** it shows escaped HTML ("lt strong gt Failure lt /strong gt").

Both are being fixed in Eldritch Arts 0.11.1. TRG Prime is unchanged.

**Noted, not an Eldritch Arts fault.** The rift's Failure rolled a minor sonic critical ("+5 damage"), but only the 3 sonic was taken off HP. The extra damage comes from the core's critical-injury card, and the same applies to every basic save in the core.

## Not tested live

- **The curse's hour running out:** this needs world time advanced, which would change Graham's world calendar and could expire effects on his own actors.
- **A bound creature breaking free at turn start:** this needs the caster to be over Control Levels.
- Also not tested: Symbol of Insanity, Symbol of Fear, Arcane Pouch, Archway of Ants, Argent Mark, Blood Biography, Riserune, Ley Line rows 25–27, Versatile Binder, and two GMs.

The harness covers all of these.

## Cleanup

- **Deleted:**
  - the scene, with its tokens and Regions;
  - the four ZZ actors;
  - the 77 test chat cards. The world has 311 chat messages again, as before the test, and no other messages were posted.
- **Dice:** restored.
- **View:** Oldwatch Approach.
- **Game:** still paused. There are no combats.
