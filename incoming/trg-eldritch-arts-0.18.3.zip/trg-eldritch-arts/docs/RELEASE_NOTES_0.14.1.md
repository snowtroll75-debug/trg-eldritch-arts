# Eldritch Arts 0.14.1 — Chrono's ending, and Graham's answers on Block 9b

13 November 2026. **Needs TRG Prime 3.689.0** (unchanged). A fix from the 0.14.0 live test; nothing else in Block 9b changes.

## Graham's answers (13 November, 22:55)

1. **Ley Binding's save half: left as printed.** The rune gives its DB bonus against a spell attack. DB is not rolled against a save spell, so nothing is added to a save: turning it into a save bonus would be a rule the book does not make.
2. **Resonant Defiance's "your shield is raised": read as equipped.** TRG Prime keeps no raised state for a shield.
3. **Spellhold: built in Block 9c**, with the staves (a multi-spell store needs its own core seam). It stays a card (C) until then.

## The fix: Chrono ends through the core's timer

Chrono "runs until you end it or become Fatigued". The press starts TRG Prime's rune timer (its day is only a backstop). The 0.14.0 live test found two ways the rune ended badly:

- **A refused press left the timer behind.** Pressed while Fatigued, the module turned the state off and warned, but the core starts its timer *after* the state is set, so a "Starfall — Chrono" timer stayed on the wielder for a day. A Chrono timer that lands while the wielder is Fatigued is now stopped as it lands.
- **The Exhaustion check that left you Fatigued did not end it.** The rune ran on into the next turn, whose start bought one more Quickened point, and ended only at that turn's end. It now ends **as the Fatigued condition lands**, whatever gave it: the rune's own check, or anything else mid-turn (the review's point: "until you … become Fatigued").

Both endings go through TRG Prime's `stopItemTimer`, whose own ending turns the state off and says so on a card; they run on one client. Being Fatigued at a turn's end still ends it, with no check.

**Left as they were (the review's notes, none new in 0.14.1):** a refused press still shows the core's "Activated" card before "switched off"; two Chrono weapons on one wielder share one Quickened effect; with no GM connected, the turn-end check is not rolled.

## The harness

- `verify-block9b` (94 checks): Chrono at a turn's end (already Fatigued; rested), the refused press's timer, and the Fatigued condition landing on a running Chrono (and not on an idle one, nor another condition), run against the automation with a stand-in core.
- `mutate-block9b` (74 mutations, all caught): nine more for the above.
- **Independent review** of the fix: no defect; its rule point (Fatigue from any source) is taken above.
- The manifest pins raised to 0.14.1.
- All 25 verifiers pass; every mutate is clean.

## The 0.14.0 live test (13 November, on TRG Prime 3.689.0 and Eldritch Arts 0.14.0)

On a copy of Valmorius and a copy as the target, in a test scene; the world was left as found.

| What | Result |
|---|---|
| Packs | Runes 68, Specific Items 9 |
| Summoner's Brand (Ritualist's Edge) | control levels 14 → 16 equipped, back to 14 unequipped |
| Comfort (Whispering Hollow) | with the printed Max Dex set to 0: DB's Dex 1 with the rune, 0 without; nothing while not worn |
| Ley Binding I (Heartstrand Harness) | +1 DB against a spell attack, 0 against a Strike, 0 unworn; labelled on the row |
| Swiftbind (Gravemeld Shirt) | 2 AP (full suit 3 AP); without the rune, 4 minutes |
| Aetherfang (Soulrend) | the Strike bypassed the target's physical resistance (9 slashing, before Mage Armour), with the card line |
| H22 hooks | a hit: resolved with natural 15, no fumble; a natural 1: the fumble hook (natural 1, the table row, melee) then resolved with fumble true |
| Essencebreaker | the target's save failed; the choice offered damage types only; piercing left its resistances, with a timed effect |
| Aetherfang's fumble | the wielder's Fortitude save, failed: an Essence-table injury |
| Chrono (Starfall) | refused while Fatigued (the leftover timer, fixed above); pressed rested: Quickened for a Strike, +1 AP at the turn's start, an Easy Exhaustion check at its end; pressed again: off, both effects gone |
| Veil (Shadeskin) | refused silently while Flat-Footed (no reaction); rested, below 25% HP: offered (2 left), taken: Incorporeal until the end of the next turn, a use spent |
| Luminous | worn: dim 20 ft, warm; unequipped: no light |

Not driven live (harness only): Catalyst's embedding, Nullflow, Resonant Defiance, Leybound, Sanguine, Renewal, Transcendent.

## The 0.14.1 live recheck (13 November, 23:40, on TRG Prime 3.689.0)

| Case | Result |
|---|---|
| Pressed rested | Quickened for a Strike, the timer and the effect on the wielder |
| Fatigued applied while it runs | ended at once: "Fatigued: the rune's effect ends", then the core's "switched off"; state off, both effects gone |
| Pressed while Fatigued | no timer left behind (0.14.0 left a day-long one); state off, no Quickened |
| In combat, the turn-end Exhaustion check fumbled (Fatigued 4) | ended as the Fatigue landed; state off, both effects gone |

One ordering note, not a defect of the fix: with the wielder the only combatant, its next turn began while the check was still held on the conviction prompt, so that turn's start counted the Quickened point before the Fatigue landed. With anyone else in the fight the check is settled long before.

No console errors. The world was left as found (messages, actors, scenes, the view, paused, world time).
