# Eldritch Arts 0.16.0: Block 7's five seams, and the fixes before Block 10

15 November 2026. **Needs TRG Prime 3.692.0.** Graham asked for these before Block 10 ("Work through the fixes before moving onto Block 10") and answered the four open questions on 15 November 2026, taking the recommendation each time.

## Graham's answers, as built

1. **A specialist spell released from an item reads as the releaser's tradition.** Kept as built; no change.
2. **On a mundane ritual, catalysts that name a "Spellcraft check" are dropped.** A mundane ritual's check is a tradition skill, so those catalysts are no longer offered there. TRG Prime 3.692.0 tells the cast items which skill the ritual rolls (`checkSkill`).
   - The eight dropped: Arcanite Powder, Blood-etched Vellum, Incense of Stillness, Leydust, Sanctified Myrrh, Spell Incense, Verdant Sap and Whisperglass Shard. A Catalyst-runed shield's embedded catalysts are dropped the same way.
   - **Blood-etched Vellum is one of them.** The book's table prints "+2 to Spellcraft checks for ritual casting" (L5487). The first draft kept it as "the ritual's own" bonus; the review caught that.
   - A ritual rolled with Spellcraft keeps them all, as before.
3. **Innate spells aren't stored.** An armed Spell Storing window no longer takes an innate cast; the innate spell takes effect. This is the Mercy of Relief case, in TRG Prime 3.692.0.
4. **All five of Block 7's deferred core seams.** They are built in TRG Prime 3.692.0 and used here:

| Spell | Was | Now | What changed |
|---|---|---|---|
| Arcane Mycelium | C | **A** | **Its dim light.** The Region carries TRG Prime's `emitsLight` at Dim Light (5). Inside it the light level is at least 5, as a light source gives: darkness is lit to 5, a brighter place is untouched, and Abyssal Darkness still devours it. The colour of your tradition is cosmetic and is not drawn. |
| Glyph of Retribution | C | **B** | **The +4 PP option's type change.** Each time you are struck, you are asked whether the glyph deals acid, cold, electricity or fire. The question goes to your own player, or the GM, through TRG Prime's new owner choice. If nobody answers, it stays sonic and the card says so. Without the option it is sonic, as printed. |
| Spirit Arrow | C | **B** | **The manoeuvre.** The chosen Feint, Grapple (1 round), Shove or Trip is resolved at the attack total by TRG Prime's `resolveBasicActionAtTotal`. It uses the action's own DC, printed difficulty (a Feint is Hard) and size penalty, and lands the action's conditions, a Shove's push and the action's clock. When the target is the GM's, this runs on the GM's client. |
| Eaog Balls | C | C | **The halved speed.** It is halved on a Critical until the end of the target's next turn, and on a Success for the spell's length (TRG Prime's `speedHalve`). The Fumble's automatic failure of Strength- and Dexterity-based checks, and the ground, are still by hand. |
| Metamagic Resonance | B | B | **The +2 PP change option.** Each time you sustain the spell, you are asked whether to keep the feat or choose another, and allies' lends follow (TRG Prime's `trgPrimeSpellSustained`). Effortless Spell's free Sustain counts too. That an ally is willing is still by hand. |

Block 7's grades are now 18 A, 19 B, 3 C, 2 D (were 17, 17, 6, 2).

## Readings to know about

- **Eaog Balls' halved speed** is each of the target's speeds, after armour and load, rounded down to 5 feet. That matches the Failure's "speed 0", which is the immobilised condition and stops every kind of movement. Two halvings don't quarter it. A 5-foot speed halves to 0, which is not the immobilised condition.
- **Spirit Arrow's Shove** pushes the target 5 feet on a Success and 10 on a Critical or Heroic, as TRG Prime's spell manoeuvres do (Tanglefoot, Spectral Grasp). The Shove action's "up to 10 feet" choice is not asked.

## For Graham

- **Spirit Arrow's Fumble.** The manoeuvre comes with the action's own rules, as you ruled for Tanglefoot on 25 August 2026. So a Fumble at the attack total lands the action's own fumble on the archer: a Shove or Trip leaves them prone, a Feint flat-footed. It can happen when an arrow hits a creature whose Fortitude or Acrobatics DC is ten or more above the attack total. Is that right for a ranged arrow, or should a Fumble simply be a failure here?
- **Runestone Chalkboard and Bloodscribe's Bowl** (gear, not catalysts) also name "the Primary Caster's Spellcraft check" in a ritual, and still apply on a mundane one. Your ruling was about catalysts. Should these two be dropped there too?

## The harness

- `verify-block7` 596 checks; `mutate-block7` 234 mutations, all caught. Two older mutations were re-anchored, on Glyph's two rows and its new card.
- `verify-block9a` 210 checks; `mutate-block9a` 94 mutations, all caught.
- Manifest pins raised to 0.16.0 on TRG Prime 3.692.0.
- **All 27 module verifiers** pass on TRG Prime 3.692.0, and **all 26 mutation files** catch every mutation.
- **The independent review** (of both releases) found the two permission problems fixed in TRG Prime 3.692.0 (a player's Eaog Balls and Spirit Arrow on the GM's creature), Blood-etched Vellum's place in the dropped list, and the Abyssal Darkness case. All are fixed. It confirmed the card texts match the book on everything this release changed.
