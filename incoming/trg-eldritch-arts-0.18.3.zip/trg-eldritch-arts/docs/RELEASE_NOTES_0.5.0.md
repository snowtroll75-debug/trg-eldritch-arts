# Eldritch Arts 0.5.0

2 November 2026. **Block 3a:** Chapter 3's three High Magic classes: the Archmage, the Sorcerer with its seven birthrights, and the Witch with her Soulbound Familiar. Also their 34 specialist spells and hexes, and the five Grimoire spells the birthrights grant. Built from `ELDRITCH_ARTS_BLOCK3_AUDIT.md`, answered by Graham on 2 November 2026: Q15–Q25 as proposed.

- **Install TRG Prime 3.680.0 first, then this over 0.4.0.** The module warns on anything older: the classes' magic, Raw Power, the familiar and the PP grants are the system's seams.
- **No migration.** A new compendium, **Eldritch Arts: Classes**, sits in the Eldritch Arts folder.
- **A Block 1 fix, in the system:** the four races' Power Points per level (Aetherial, Emberkin and Scaelyn +1, Nyrinn −1) now reach the character. They were registered but never applied. An existing character catches up at the next daily preparation.

## The Archmage

- **Class:** Adept. HP 4 + Con, 4 + Int skill points, the club and staff, the printed class skills. The table is the book's row by row, caster level, PP (5 a level) and BSB included.
- **Bonus feats:** Scribe Scroll at 1st; a class feat at 5th, 10th, 15th and 20th.
- **Chapter 6's class wealth:** 1.
- **Its magic:** a learned caster of every tradition, all of it High Magic.
  - **The Spell Book:** six PP 2 spells of any tradition at 1st, then one a level that you can cast.
  - **Memorisation:** 2 + (level × 2) a day (M16).
  - **Cantrips:** six in the book, picked on the Cantrips card; three memorised each day with Memorise Cantrip.
  - **Intelligence** is the magical ability.
  - **A casting focus:** may be used with High Magic (Chapter 7).
- **Ley Bond:** a High Magic casting's DC is 1 lower. It does not stack with Ley Line Connection; it is one bond. Press **Use** to list the ley lines within 100 ft per level of your token, with their level and direction.
- **Ley Tap:** while a Ley Line area lies within that range (sidebar 5), an effect "Ley Tap: in range" gives your Power Recovery (Meditation) checks advantage. It switches on and off as your token moves.
- **Specialist spells:** through the Specialist Spell feat, any class's (the GM decides what is "applicable").
- **Bookkeeping:** the class names Arcane as its tradition, for the PP ability bonus and a specialist spell's tradition.

## The Sorcerer

- **Class:** Adept. HP 6 + Con, simple weapons, the printed table (PP 6 a level).
- **Bonus feats:** Component Mastery and Empower Spell at 1st; a class feat at 5th and every 5.
- **Chapter 6's class wealth:** 0.
- **Birthright:** press Use to choose. The birthright brings everything its entry prints:
  - **its first key ability** as your magical ability, and its tradition;
  - **its two bonus skills** as class skills;
  - **its special ability** and its specialist spell;
  - **the Specialist Spell feat's list** it opens (the Wizard's, the Cleric's, the Druid's, or the shadow trait);
  - **the additional spells,** at the printed Sorcerer levels, outside your picks.
- **Until you choose:** the Sorcerer does not cast.
- **The Repertoire card holds two schedules:**
  - **Any tradition:** one spell at 1st, then one at 3rd and every two levels.
  - **Your birthright's tradition:** one at 2nd and every two levels.
  - **When you pick:** if both schedules owe a spell, Pick asks which.
  - **No swaps:** none are printed.
- **Cantrips:** the birthright's first, then one of any tradition.
- **Every spell you cast is High Magic.** Race restrictions on traditions do not apply to it (L839).
- **Raw Power:** a warped High Magic spell may cost 1 PP over your cap.
- **The seven birthrights:**
  - **Arcanum:** Sorcerous Bond grants the core's Arcane Bond, and lets you use a focus with High Magic. Disrupting Magic.
  - **Dragon:** Dragon Claws, Draconic Infusion.
    - **Dragon Claws:** Use (1 AP) grows them and Use again retracts them. They are 1d6 piercing, agile and finesse, and attack with your BSB in place of your BAB when that is higher.
    - **Dragon type:** asked once, at the first Use, and kept.
  - **Eternity:** +2 Death State. Touch of Healing.
  - **Rune:** Resist Magic. Storing Rune.
  - **Storm:** Gale Step (Use, 1 AP: click where you teleport, up to 15 ft). Storm Bolt. Its 1st-level cantrip is **Orb of Lightning** (Q15: the core's Shock Bolt is 4 PP).
  - **Umbral:** Darkvision; Darkness at 5th, cast as a specialist spell. Shadow Shift.
  - **Wild:** Wild Power.
    - **+1 PP a level.**
    - **Surges:** an unmodified 13 on the Spellcraft check of a PP 2+ spell rolls the Wild Surge table, at the spell's PP (Q20). In a Wild Magic area it uses the area's level, two rolls at disadvantage; the choice of roll is asked of whoever cast, and the GM should make it.
    - **The daily specialist spell:** a random PP 1 specialist spell at each daily preparation, replacing the last (Q24). It is a class's specialist spell, not a hex.
    - **The random spells:** Use rolls those owed: two at 1st, then one at 3rd–15th (Q19). Each rolls the d20 for its tradition, then a random spell of that PP you do not know. The rolled spell is shown with the list, to keep or replace.

## The Witch

- **Class:** Adept. HP 6 + Con, simple weapons, the printed table.
- **Bonus feats:** a class feat at 1st (M15), 5th, 10th, 15th and 20th.
- **Chapter 6's class wealth:** 1.
- **Her magic:** instinctive, Ethereal and Verdant only.
  - **Spells:** two at 1st, then one a level from 2nd.
  - **Cantrips:** two, of either tradition.
  - **What is High Magic:** only her Ethereal and Verdant spells, and her hexes (Q16).
  - **Charisma** is the magical ability.
  - **Bookkeeping:** Ethereal is the class's tradition.
- **Hexes:** press Use to choose those owed: one at 1st, one more at 3rd and every three levels. A hex above your level (which you could not yet cast) is not offered. Each hex is a specialist spell (its cap your level, its casting Very Easy) and High Magic.
- **Soulbound Familiar:** press Use to make your familiar, as the core's Familiar feat makes one.
  - **The familiar gains** Base DR 2, HP equal to your level and your Charisma as a class bonus to its saves.
  - **A spell adder:** the familiar is a +1 spell adder (one free casting a day).
  - **The daily bonus:** one of the eight, chosen at daily preparation. The save bonus is chosen as Fortitude, Reflex or Will. It applies while the two tokens are within 30 ft, and stays as last found when either is off the map.
  - **Severed Bond:** if the familiar is killed, you are fatigued 2 and the bond can only be remade at a daily preparation (offered then). The mile-and-24-hours separation is ticked with Use (Q25).
- **Verdant Communion:** Use once a day.
  - **The check:** the core's Power Recovery (Meditation), and its bonus PP are regained.
  - **The bonus:** +2 class to Nature and Survival for an hour.

## The spells

**34 specialist spells:** the Archmage's 3, the Sorcerer's 9 (6 birthright, 3 "Birthright Any") and the Witch's 22. Also **5 Grimoire spells**: Observe the Weave, Message Rune, Symbol of Fear, Symbol of Death and Dark Whispers. Every card prints the book's text and says, in its last paragraph, what is automated.

- **Who may take them:**
  - **Class trait:** each spell is tagged by its class trait (Archmage, Sorcerer, Witch). So the Specialist Spell feat offers Life Boost to a Witch (Q17), and the three "Birthright Any" spells to every Sorcerer (Q18).
  - **Birthright spells:** tagged by their birthright.
  - **Hexes:** chosen with the Witch's Hexes. The Bloodmage pair is open to every Witch (Q21).
- **Automated:** Arcane Singularity, Touch of Healing, Storm Bolt, Life Boost, Armouring.
- **Partly automated:** Paradox Weave, Ancient Aegis, Evershade Veil, Ley Bolt, Storing Rune, Shadow Shift, Bulging Eyes, Cloak of the Deceiver, Hemocovenant, Malicious Shadow, Prehensile Tail, Siphon Vitae.
- **Not automated (the text, with a note):** Ley Sever, Draconic Infusion, Absorbent Beard, Baneful Magic, Baneful Weapon, Cackle, Delay Affliction, Familiar Senses, Hex Ward, Purity Hex, Tentacle, Weakened Element, and the five Grimoire spells.
- **Waits for Block 3b (TRG Prime 3.681.0):**
  - **Reactions:** Disrupting Magic, Missed Chance, Second Chance, Prophetic Warning, Phase Familiar.
  - **Abilities:** Resist Magic, and Eternity Resilience's Conviction spend.
- **As ruled:** Hemocovenant's "1d8 + Charisma HP +" is read as "1d8 + Charisma HP" (Q22).

## Found in an independent review before release, and fixed

- **Wild Power would never have surged:** the system read the casting's die from a field the check does not have (fixed in TRG Prime 3.680.0; it also mended Shadow Walk's resonance on a 13).
- **The Specialist Spell feat would have offered ordinary spells** to an Archmage or an Umbral Sorcerer. Only specialist spells are opened now, and not hexes.
- **Raw Power's extra PP were still charged as overcast** (+2 DC a PP). Not any more.
- **A severed bond's fatigue** is now removed when the new bond is made.
- **A killed familiar is not rebonded as a corpse.** Delete its actor, and the new bond is offered at the next daily preparation.
- **One client acts:** the GM and the owning player no longer both sever the bond, nor both switch Ley Tap's effect.
- **Wild Power's spells are matched to their row** (level and PP). A row whose pool was empty is the one rolled next, not a later one.

## Harness

- **New pair: `verify-block3` (275 checks) and `mutate-block3` (61 mutations, all caught).** They cover:
  - A, the classes against the book: every table row, all nine columns;
  - B, the birthrights;
  - C, the spells, every printed line;
  - D, the rules run;
  - E, registration;
  - F, the core run with the content, including the racial PP;
  - G, the Foundry side with fakes: Hexes, the Soulbound bond, its bonus and its severing, Verdant Communion, Wild Power's spells and surge, Dragon Claws;
  - H, the hooks and the versions.
- **Re-anchored:** `verify-block1` counts Block 3's automations and pack apart from Block 1's, and accepts "Waits for Block 3b" as a card's status.
- **Still green:** `verify-block1` 883, `verify-block2` 131, `verify-block2b` 91; `mutate-block1` 86, `mutate-block2` 75 and `mutate-block2b` 81, all caught (their version pins moved to 0.5.0 and 3.680.0).
