# Eldritch Arts Block 1: audit (races, heritages, backgrounds and Chapter 4's simple actions)

28 October 2026. Read against:
- **The book:** *Eldritch Arts* v1.4. It is checked as `ea.md` (the docx cut) together with the sidebars recovered from the docx text boxes. The sections are Chapter 2 (L117–556), the Chapter 4 actions named below, Chapter 5's background feats and "Existing feats" (L2872), and Chapter 6's exotic weapons and goods (L4900–5210).
- **TRG Prime 3.674.2,** as released. Every system claim below was read in its source.

## Scope

| Group | Items | Inventory |
|---|---|---|
| **Races** | Aetherial, Emberkin, Nyrinn, Scaelyn | R-01 to R-04 |
| **Racial abilities** | Ethereal Form, Aetherial Magic, Aetherial Resonance, Elemental Surge, Elemental Symbiosis, Magical Instinct, Magic Drain, Null Aura, Natural Armour, Ley Line Connection, Innate Magic; Darkvision and Nightvision (core) | RA-01 to RA-12 |
| **Heritages** | 18: five Aetherial, four Emberkin, three Nyrinn, six Scaelyn | H-01 to H-18 |
| **Languages** | Low Tongue, Faechant, Nyxian, Wyrmish (all core) and "Elemental Language" | R-05 |
| **Backgrounds** | 12, with Chapter 6's wealth | BG-01 to BG-12 |
| **The feats the backgrounds grant** | Disrupt Magic, Elemental Affinity, Esoteric Insight, Focused Ley Sense, Ritual Expert, Spell Penetration, Spell Surge, Spirit Whisper, Wanderer's Instinct (Eldritch Arts); Scribe Scroll, Magical Crafting, Improved Initiative (core) | FG rows |
| **Existing racial feats** | Aura of Power, Focused Pursuit; Component Savant, Self Aware; Ethereal Trick, Shadow Magi; Dracoris, Sure Footed (all core) | FX-01 to FX-04 |
| **Chapter 4 actions** | Ley Sense, Appraise Magic, Hypnotism, Lingual Casting, Mysterious Script, Quickbind | SA rows |
| **Chapter 6** | 18 exotic weapons and the three new weapon traits; 31 goods | WPN, GD rows |

**Not in this block:**
- **Special materials (10).** They need the module-materials hook (D18) and go with the magic items (Block 9).
- **Catalysts.** They need cast-time item options (D3), as planned (Block 9).
- **Spell Surge's automation.** Its prerequisite is High Magic, and it changes fumble and resonance rolls (D1, D6). The feat item ships now with its text, automated in Block 2.
- **Ley Line Connection's two effects.** These are the permanent Ley Bond and the High Magic casting DC −1. They need Block 2's High Magic (D1) and Block 3's Ley Bond. The ability ships now and says so.
- **Ritual Expert and the Ritualist trait.** These change the ritual dialog (D13), which is Block 2's. Until then each one's card says how to enter it by hand.

## What the system already has (TRG Prime 3.674.2)

| Need | What exists | Where |
|---|---|---|
| A race's ability modifiers, size, speed | Effects on the race item. **The race carries only the remainder after the size table** (Small −1 Str / +1 Dex, Tiny −2 / +2), so `racial + size = printed` | `config.mjs:185`; 3.549.0 notes |
| Racial Power Points per level | `registerRacialPP(name, perLevel)`; race and heritage added together | `racial-pp.mjs:107` |
| Granted cantrips "cast using your Spellcraft" | A race's or heritage's `grantedSpells` (castable, not innate), as Galad-Iar's Light | `grants-workflow.mjs:510` |
| Innate spells with the Focus trait | `flags.grantInnate` on the granting item; Focus added by the core; "an innate spell cannot be cast while its PP is above the level it is cast at" | `grants-workflow.mjs:430`, `focus-declarations.mjs` |
| Resistance, immunity, weakness | `system.combat.resistances` / `immunities` / `weaknesses` (ADD ", type") | core heritages, Fearless |
| Natural armour | `system.combat.naturalArmourBase.natural` | Inner Tempest's Scaled Hide |
| Darkvision, Nightvision | Core ability items with their senses | `abilities` pack |
| Advantage and bonuses on checks | `flags.conditionals` (traits, actions, subjects, traditions…) | `conditionals.mjs` |
| A spell save DC bonus | `flags.spellDCBonus {value, type, traits}`; no traits means every spell | `magic/spell-dc-bonus.mjs` |
| **Incorporeal** | A creature trait carried by an effect's `grantedTraits`: immune to non-magical attack forms and precision damage, resistant to all but force | `codex-trait-rules.mjs`, `magic/form-traits.mjs` |
| **Spell Resilience** | A creature ability: "a racial bonus equal to its class bonus to all saving throws and DB against magical attacks", applied to spell saves and spell attacks | `creature-ability-rules.mjs:361`, `cast-workflow.mjs:5537, 6303` |
| A casting's check, asked of a module first | `registerSpellCheckGate`. It returns check modifiers and card lines. It cannot change the DC or refuse the cast | `magic/spell-check-gates.mjs` |
| Daily-prep and turn hooks | `trgPrimeDailyPreparation`, `trgPrimeTurnEnded`, `trgPrimeActionResolved` | |
| Module skill actions with time ladders | `registerSkillActions`; an action may declare its own `timeLadder` | `general-skill-options.mjs:296` |
| A reroll after your own fumble | `flags.fumbleReroll {checkTypes, reaction, label}` | `fumble-reroll.mjs` |
| Goods' bonuses while carried | `flags.goodsConditionals` | core gear (Brass Ear, Earplugs) |
| Racial exotic weapons | "If your race matches that of the weapon's racial trait, it is considered a martial weapon": the **race item's name** against the trait | `proficiency-rules.mjs:968` |
| Core feats opened to new races | `registerFeatAccess("race", …)` | 3.571.0 |

## Not in the system yet: core work for TRG Prime 3.675.0

| # | For | Gap, and what is proposed |
|---|---|---|
| C1 | Elemental Surge ("You add your Charisma ability score as a racial bonus to all spell damage rolls") | **A spell's damage roll takes no flat bonus.** Damage conditionals are read for weapon damage only (`damage-conditionals.mjs`), and the spell riders add dice of their own type. Proposed: a declared `spellDamageBonus {label, value or valueFrom, type, traits?}`. It is added to the spell's damage roll in the attack and save paths, typed-stacked, and named on the card. Healing is not damage and takes nothing. |
| C2 | Null Aura ("add your class bonus to all saving throws and DB vs magical effects"); Spell Penetration ("lower the ability by 2") | **Spell Resilience has one fixed name and nothing can lower it.** Proposed: the `spellResilience` derive may be `{label, type}`, so Null Aura reads as itself on the card. A caster's `spellResilienceReduction {value: 2, labels: ["Spell Resilience"]}` lowers matching rows (floor 0) against that caster's spells, in both the save and the attack path. |
| C3 | Zhal-vryn ("All creatures within your Null Aura must expend an additional PP to cast spells (including cantrips)") | **A module cannot add to a casting's cost.** Proposed: `registerCastSurcharge(key, ctx => ({pp, label}))`, asked when the PP is spent. The PP is paid on top: it does not raise the casting DC or count against the per-cast cap (B1-6). A caster without the PP cannot cast, as with any cost. This is the cost half of D5. |
| C4 | Esoteric Insight ("once per day, when you fumble an Arcana or Occultism check, you may reroll") | **A fumble reroll cannot be scoped to skills,** and it costs a reaction unless told otherwise. Proposed: `fumbleReroll.subjects` (skill keys). `reaction: false` already exists. The counted use (`usesPerDay: "1"`) is already spent by the workflow. |
| C5 | Focused Ley Sense (its own five-rung ladder for Ley Sense) | **A module action's time ladder cannot vary by feat.** The only feat variant is the core's Identify Power. Proposed: an action's `timeLadderByFeat: {"Focused Ley Sense": {options…}}`, read where the ladder is chosen. |
| C6 | Lingual Casting (use a scroll with Linguistics: Very Hard; ranks in the tradition skill ≥ PP, or all four for High Magic; Linguistics ranks ≥ PP + 2) | **The scroll-reading ladder is fixed** (Spellcraft, then the tradition skills). Proposed: `registerReleasePath(key, ctx => option)`, which adds a path to `castFromItemOptions` for scrolls. Its availability and reason come from the module, and it is rolled like the others. |
| C7 | Clamhscrios (trait "Wyrmdral", a Scaelyn heritage) | **The racial-weapon clause reads only the race's name.** Proposed: the heritage's name is also matched. |
| C8 | The Adept trait ("treated as a Simple weapon for any character with this class trait") | **No rule turns a weapon trait into a category for a class type.** Inner Tempest's per-class `weaponRules` cover a named class only. Proposed: `registerWeaponTraitRule("Adept", {categoryAs: "Simple", classTypes: ["Adept"]})`, read in `effectiveWeaponCategory`. |
| C9 | Orb of Water ("1d6 bludgeoning and 1 secondary cold … CL 4+: … & the secondary by 1"); found while building | **An attack spell has one damage packet.** Added: `system.secondaryDamage {formula, type}`, dealt after the main packet against the target's own defences for its type, and a `secondary` step in the caster-level modifiers. |
| C10 | Null Aura's penalty (found in review) | **A gate's row lowered an attack spell's attack against DB as well as its casting check.** Added: a gate row may be `castingOnly`; the attack total leaves it out, and an innate or item attack never takes it. |
| C11 | Quickbind (found in review) | **No module way to ask Invest Item's rules.** Added: the helper `investRefusal(actor, item)` (one Staff, the slot limit). |
| C12 | Esoteric Insight, v1.6 ("a failure or fumble result") | **A fumble reroll answered only Fumble and Blunder.** Added (3.677.0): a reroll row may name its `degrees`; the check offers a Partial or Failure reroll only to an actor whose row names it. |
| C13 | Racial weapons (Graham's m64) | **Only an Exotic weapon stepped down for its race.** Changed (3.677.0): one category easier, Exotic → Martial, Martial → Simple. No core or Inner Tempest racial weapon is Martial, so nothing existing changes. |
| C14 | Null Aura (Graham's C1; v1.6) | **The beneficial-spell save was only the Ascendan's, by tradition.** Added (3.677.0): an ability may declare `beneficialSpellSave {label, otherCastersOnly}`; the same Will save, the same spells, the same DC. |

C1–C8 each get a verify/mutate pair in the core's harness. The core version moves to 3.675.0 because Block 1 needs it, and for nothing else.

## The races

**Ability modifiers, after the size table:**

| Race | Printed | Size | The race item carries | Speed | PP per level |
|---|---|---|---|---|---|
| Aetherial | Con −1, Int +2, Wis +1 | Medium | as printed | 30 | +1 |
| Emberkin | Con +1, Cha +1 | Medium | as printed | 25 | +1 |
| Nyrinn | Str −3, Con −1, Dex +4, Cha +2 | Tiny (−2 / +2) | Str −1, Con −1, Dex +2, Cha +2 | 25 | −1 |
| Scaelyn | Str −1, Con −1, Dex +2, Int +2 | Small (−1 / +1) | Con −1, Dex +1, Int +2 | 25 | +1 |
| *Wyrmdral (heritage)* | Str +1, Dex −1, Int +1, Cha +1, **instead of** the Scaelyn line | Medium | the heritage sets Medium and adds Str +1, Dex −2, Con +1, Int −1, Cha +1, so the pair totals the printed line | 25 | +1 (the race's; the heritage adds none) |

The harness asserts `racial + heritage + size = printed` for all five lines.

**Languages and specialist skills:** as printed. **Spell Lore and Nyrinn Lore** are the Nyrinn's two (L251: "Spell Lore & Nyrinn Lore as a specialist skill").

## The racial abilities

| Ability | What the module does |
|---|---|
| **Ethereal Form** (1/day) | Use: an effect lasting 1 minute that grants the core's **incorporeal** trait. You become immune to non-magical attack forms and precision damage, and resistant to all damage but force. The day's use is spent. |
| **Aetherial Magic** | Mage Hand and Read Aura granted by the race, cast with a Spellcraft check, as Galad-Iar's Light. |
| **Aetherial Resonance** | `spellDCBonus` +1 racial on every spell (innate included). |
| **Elemental Surge** | C1: + Charisma, racial, on every spell damage roll. |
| **Elemental Symbiosis** | Use (your reaction): immunity to your heritage's element until the end of your next turn. When it ends, weakness to that element for 1 minute, and the Use is refused until the weakness ends (B1-10). The element comes from the heritage: Stonevein acid, Galeborne electricity, Cinderblood fire, Tidemarked cold. |
| **Magical Instinct** | Charismatic Caster granted by the race (core feat; a grant ignores its prerequisites, as every grant does). |
| **Magic Drain** (sidebar) | A module skill action from the ability: 2 AP, Concentrate, Focus, Warding, 30 ft, Power Manipulation. Its Focus use is the ability's. The GM sets "the DC of the effect or item". On a Critical the effect is negated, or a charged item loses 1d4 PP; you gain energy equal to the drained PP (max level × 2). A Success does the same at half. The energy (B1-8) gives +1 racial to the one you choose of AB, DB, saves or skill checks, for 1 minute per PP. The core's Dispel action is not used, because it costs PP and Magic Drain does not. |
| **Null Aura** | Your class bonus to your saves and DB against magic, as the core's Spell Resilience under its own name (C2). The casting-DC rise is a spell-check gate: any Spellcraft check within 5 ft of you, yours included, takes your class bonus as a penalty, which is the same number as a DC that much higher (B1-5). The beneficial-spell clause has no save (EA-C1); a card reminds the GM. |
| **Natural Armour** | Base natural DR 1. |
| **Ley Line Connection** | Shipped as text. Block 2 (High Magic, the −1) and Block 3 (Ley Bond) automate it. |
| **Innate Magic** | Use: choose one cantrip of any tradition, granted and cast with Spellcraft until your next daily preparation, when the Use asks again. |

## The heritages

| Heritage | What the module does |
|---|---|
| Aeralis, Astryn, Caelari, Umbryth | Resistance (electricity, force, essence, essence) and the innate spell with the Focus trait (Gust, Guiding Bolt, Shield, Cloak of Greying). Caelari and Umbryth both print essence (EA-m4). |
| Nerathis | Advantage on saves against effects with the Mental trait: automatic when the effect carries it, offered as a tick otherwise. Anticipate Attack innate. |
| Stonevein, Galeborne, Cinderblood, Tidemarked | Resistance (acid, electricity, fire, cold), the cantrip granted (Orb of Acid, Orb of Lightning, Orb of Fire, Orb of Water), the printed ability adjustment. Galeborne and Tidemarked both print Dex +1, Str −1 (EA-m3). **Orb of Water is a Grimoire spell** (L7264), so it is built in this block. |
| Vel-tharis | Null Aura radius 10 ft (the gate and the card read it). Silence innate; the card says "self only". |
| Vir-ellian | Magic Drain drains your class bonus more. The release: 1 AP (Concentrate, Focus), 1d4 force per PP of stored energy, basic Will, to all creatures within your "Magic Drain aura" (B1-7). |
| Zhal-vryn | C3: casters within your Null Aura pay +1 PP, cantrips included (EA-M22, B1-6). Cancel Magic innate. |
| Sparktail | Fire resistance; Orb of Fire innate; +2 racial offered as a tick on Create (crafting) and Disable a Device checks "when crafting or disarming mechanical traps". |
| Glyphweave | Scribers Chant innate; a second Innate Magic pick (EA-m5, B1-9). |
| Dustscale | Burrow 10 ft; advantage offered as a tick on Hide and Sneak "in natural terrain". |
| Ironmuk | Poison resistance; holding your breath lasts twice as long (the core's breath multiplier); Purify innate. |
| Wisperfin | +2 racial Stealth; Cloak of Greying innate. |
| Wyrmdral | Medium and its own ability line (above). Use: choose acid, cold, electricity, fire or poison. You gain resistance to it, +1 to Spellcraft checks for spells with that trait, and +1 to their save DC (B1-11). |

## Backgrounds and their feats

The 12 backgrounds are built as the core's: bonus feat, the three skill bonuses, the specialist skill, and Chapter 6's wealth. **Spirit Binder has no wealth row** (B1-14). The specialist skills keep their printed names: Spirits Lore, Enchantment Craft, Null Magic and Wild Magic Lore are names the core accepts as they are.

| Feat | What the module does |
|---|---|
| Disrupt Magic | +2 class on Dispel checks, automatic. |
| Elemental Affinity (repeatable) | Use: choose fire, cold, electricity, acid or sonic, each pick different. +1 to Spellcraft checks and +1 save DC for spells with that trait. |
| Esoteric Insight | +2 circumstance offered on Identify Power and Recall Knowledge checks for an uncommon or rare spell, effect or rune. The once-a-day fumble reroll needs C4. Advantage with Spell Recognition on Uncommon or Rare spells. |
| Focused Ley Sense | Ley Sense's own ladder (C5). |
| Ritual Expert | The card says to enter you twice in the ritual dialog's secondary casters. It is automated with the rituals in Block 2. |
| Spell Penetration | C2: a target's Spell Resilience −2 against your spells. |
| Spell Surge | Text only until Block 2 (see above). |
| Spirit Whisper | Telepathy with willing spirits and undead within 30 ft: a note on the sheet, as the core's telepathic abilities are. |
| Wanderer's Instinct | +2 circumstance on Survival against hazards and anomalies, and +1 on detecting magical disturbances (both offered as ticks). Use (1/day): advantage on your next Survival check to navigate or track in a magical area. |

## Chapter 4 actions

| Action | What the module does |
|---|---|
| Ley Sense | Trained in Arcana, Nature, Occultism or Religion. The core's time ladder (10 min +0, 1 min −2, 1 round −5, 1 AP −10). The GM sets the DC. A Failure locks it for 10 minutes; a Fumble costs 1 PP and locks it for 1 hour. What it finds is the GM's until ley lines exist (Block 2). |
| Appraise Magic | Crafting, 5 ranks, Secret, the same ladder, GM's DC. The result card is the GM's, because the Fumble lies to the player. |
| Hypnotism | Diplomacy against the target's Will DC, 1 minute. You choose Implant Suggestion or Memory Recall, and willing or unwilling (+10). The degrees follow the printed table; Memory Recall's bonus is offered on the reroll it allows. Suggestion follows the core Suggestion spell's text. |
| Lingual Casting | C6. |
| Mysterious Script | 1 hour, once a week (tracked), GM's DC. Critical gives Divine Vision's answer and Success gives Augury's, both from the GM. |
| Quickbind | Power Manipulation, 5 ranks, against the item's level DC; Very Hard (+5) outside daily preparation. Once per item per day. It invests the item and says how long it took. |

## Chapter 6

- **Exotic weapons:** all 18, as printed, in the core's weapon shape with the Exotic category.
  - The racial traits (Emberkin, Wyrmdral, Scaelyn, Aetherial, Nyrrin) make the weapon martial for that race, by the core's clause (C7 for Wyrmdral). The Nyrrin spelling is B1-13.
  - Adept is C8. Ritualist waits for the rituals (Block 2). Brace is B1-12.
  - The Ord ua na Tuama is EA-R6.
- **Goods:** all 31. Each bonus is a `goodsConditional`, offered while carried. Most are ticks, because the situation is the table's ("when concealing magical intent"). Bonuses on rituals, summoning circles, wild magic zones and ley lines wait for those blocks; their cards say so. The four goods rows that are D in the matrix are text only.

## 1 November 2026: ruled, and rebuilt on book v1.6 (0.2.0, TRG Prime 3.677.0)

Graham's *Responses to Audit Eldritch Arts* and book v1.6 settle these. Full record: `ELDRITCH_ARTS_RULINGS_2026-11-01.md`. The table below is kept as asked on 28 October.

| # | Now |
|---|---|
| B1-2 | **Ruled.** Tidemarked keeps Galeborne's adjustment (m3, "this is correct"); Umbryth resists **cold** (m4). |
| B1-3 | **Ruled (C1), and v1.6 prints it.** A Will save against the caster's spell save DC; TRG Prime rolls it (3.677.0, C14). |
| B1-4 | **Ruled (M22):** as built. |
| B1-7, B1-8 | **Ruled (M24):** as built. |
| B1-9 | **Ruled (m5), and v1.6 prints it:** "an additional innate cantrip". The pick is innate, chosen with Glyphweave's Use and kept until changed. |
| B1-11 | **Ruled (m6), and v1.6 prints it:** "of their elemental type". As built. |
| B1-13 | **Settled by v1.6:** the Scáthfán prints Nyrinn. |
| B1-14 | **Settled by v1.6 (m58):** Spirit Binder's wealth is 0. |
| B1-18 | **Ruled (C3):** the releaser's own Level DC, as built. |
| m64 (new) | **Ruled:** a racial weapon is one category easier for its race (3.677.0, C13). |
| Esoteric Insight (v1.6) | "a failure or fumble result": the reroll answers Failure too (3.677.0, C12). |

**Still open:** B1-1, B1-5, B1-6, B1-10, B1-12, B1-15, B1-16, B1-17, B1-19, B1-20, B1-21, B1-22; also "Censor" for "censer", and whether Glyphweave's cantrip is chosen again each day.

## Questions for Graham (28 October)

| # | Question | Proposal |
|---|---|---|
| B1-1 | **"Elemental Language"** (Emberkin core languages) is not a language in the core list. | **The heritage's elemental tongue,** as you ruled for the Tianzhi: Stonevein Gaian, Galeborne Aeolian, Cinderblood Ignic, Tidemarked Aqualis. |
| B1-2 | **Tidemarked** prints Galeborne's adjustment (EA-m3), and **Umbryth** prints Caelari's essence resistance (EA-m4). | Build as printed unless you give the intended lines. |
| B1-3 | **Null Aura's beneficial-spell save** (EA-C1). | A reminder card until ruled. A Will save against the caster's spell save DC would be the natural reading. |
| B1-4 | **Null Aura and Zhal-vryn affect the Nyrinn's allies** (EA-M22). | As printed: everyone in the aura, allies included. |
| B1-5 | **"Spellcraft checks … have their casting DC increased"**: the system lets a module change the check, not the DC. | A penalty equal to your class bonus on the check. The same number decides every degree. The card says "Null Aura: casting DC +N (applied to the check)". |
| B1-6 | **Zhal-vryn's extra PP:** a surcharge, or PP spent on the spell (raising its casting DC and counting toward the cap)? | **A surcharge.** It does not change the DC or the cap. |
| B1-7 | **Vir-ellian's "Magic Drain aura":** Magic Drain is an action with a 30 ft range, not an aura (EA-M24). | **All creatures within 30 ft of you, except you,** allies included as printed. |
| B1-8 | **"Temporary magical energy"** (EA-M24). | A pool of up to level × 2. Its +1 racial bonus (you choose AB, DB, saves or skills) lasts 1 minute per PP. Vir-ellian's release spends it. It is **not** PP you can cast with. |
| B1-9 | **Glyphweave's "additional bonus cantrip"** (EA-m5). | A second Innate Magic pick each day. |
| B1-10 | **Elemental Symbiosis** prints a reaction with no trigger. | Usable at any time as your reaction, normally when you are about to take damage of your element. |
| B1-11 | **Wyrmdral:** "+1 modifier to Spellcraft checks (including attack) and Spell Saving Throws". | +1 untyped to the Spellcraft check of a spell with the element's trait (a learned spell's attack is that check), and +1 to that spell's save DC. |
| B1-12 | **Brace means two different rules.** Inner Tempest's Brace (TRG Prime 3.668.1): a readied Strike against a mounted target gains +2 and a die. Eldritch Arts' Brace: a reaction Strike when a foe moves into your reach. The core applies Inner Tempest's rule to any weapon with the trait. | Your call. Either the trait means one rule in both books, or the Eldritch Arts weapons carry a differently named trait (e.g. "Brace (EA)") with its own reaction, offered when a foe Strides or Charges into reach. Until ruled, the three EA weapons with Brace (Gaoth Bhioráin, Tuagh Tairngire, Gaoth Shlánaithe) ship with the trait in their text only, not their trait line. |
| B1-13 | **"Nyrrin"** on the Scáthfán, against the race's name "Nyrinn" (EA-m2). The core's clause compares the two. | The trait is written **Nyrinn**, so the printed rule works for the race. |
| B1-14 | **Spirit Binder** has no row in the Background Wealth table (L4746). | Wealth 0 until you give one. |
| B1-15 | **Innate spells' ability.** The heritages never name one. | The system's default, as for the core's racial innate spells. |
| B1-16 | **Ritual Expert, Ritualist and Spell Surge** wait for Block 2. | Ship the items now with honest cards (above), rather than hold the backgrounds back. |
| B1-17 | **Ley Sense prints the Focus trait** (L1800), but it is a skill action, not an ability with a use. No core skill action carries Focus, and the system spends no Focus use for one. | **The trait is carried and no use is spent.** If a use was meant, say which item tracks it. (Found while building; EA-M113.) |
| B1-18 | **Vir-ellian's release prints "basic Will" and no DC** (L273). | **Your Level DC,** the core's DC for a racial ability that names none. (EA-M114.) |
| B1-19 | **Lingual Casting on a scroll whose spell names no tradition:** "ranks … in the appropriate tradition skill" has no skill to read. | The path is offered as unavailable, with the reason, and the GM may allow it (the release dialog's own rule). High Magic's "all 4" arrives with Block 2. (EA-m226.) |
| B1-20 | **Hypnotism's Failure, "can be retried the next day":** retried on the same subject, or at all? | **That subject:** you may hypnotise someone else at once. (EA-m227.) |
| B1-21 | **Magic Drain's "max your level × 2":** a cap on each drain's energy, or on all the energy you hold? Two drains can now be held at once, and Vir-ellian Release spends their sum. | **Each drain,** as printed. Say if the total held should be capped. |
| B1-22 | **Disrupt Magic** ("+2 class bonus … when using the Dispel action") **and Magic Drain** ("You make a Dispel (Power Manipulation) check"). | **Not Magic Drain:** it is its own action, which rolls a check like Dispel's (interpretation 5). Say if the +2 should reach it. |

## Interpretations (they stand unless Graham says otherwise)

1. **Ethereal Form's "incorporeal"** is the core's Incorporeal trait for its minute.
2. **"Cast using your Spellcraft attribute"** means a granted, non-innate spell cast with a Spellcraft check, the core's reading for its racial cantrips.
3. **Innate Magic's cantrip** is "free": it does not count against spells known, and it changes at daily preparation.
4. **Magic Drain's DC** is the GM's ("the DC of the effect or item"). The core's counteract ±2 per PP is not added, because Magic Drain is not the Dispel action.
5. **Disrupt Magic** applies to the Dispel action only, not to Magic Drain.

## Releases

- **TRG Prime 3.675.0:** C1–C11 (C9, Orb of Water's secondary packet, was found while building; C10 and C11 in review), with a verify/mutate pair, the full sweep, and the release links checked.
- **Eldritch Arts 0.1.0:** Chapter 2, the background feats, the existing feats, the six Chapter 4 actions, Orb of Water, and Chapter 6's weapons and goods. With `verify-block1` / `mutate-block1`, the sweep and the zip. Then you install and test it live.
- **TRG Prime 3.677.0:** C12 (a reroll names its degrees), C13 (racial weapons one category easier), C14 (a declared beneficial-spell save).
- **Eldritch Arts 0.2.0:** Block 1 on book v1.6 with the 1 November rulings.
