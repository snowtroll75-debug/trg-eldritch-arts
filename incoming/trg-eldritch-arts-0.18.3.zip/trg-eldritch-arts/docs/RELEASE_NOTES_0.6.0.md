# Eldritch Arts 0.6.0

3 November 2026. **Block 3b:** the seven reactions of Chapter 3 and its spells. Built from `ELDRITCH_ARTS_BLOCK3B_AUDIT.md`. Graham answered it on 2 November 2026 ("Go with your proposals"), so Q26–Q35 are built as proposed.

- **Install TRG Prime 3.681.0 first, then this over 0.5.1.** The reactions are asked at the system's new reaction seams. On anything older the module warns and the seven stay descriptive.
- **No migration.** There is one new world setting: **Prophetic Warning: offer before each check** (on by default).
- **Who is asked:** the reactor's player if one is online, otherwise the GM. No answer in 30 seconds counts as "no" (Q34). A "yes" casts the hex on the reactor's own client, with its casting check, its PP and the reaction.

## The three hexes that reroll or grant advantage

**Missed Chance** (3 PP, 30 ft, an enemy):
- **When:** an enemy *succeeds* at an attack check, save or skill check. Success means Success or better, or a hit. Partial is neither a success nor a failure (Q26).
- **Who is asked:** every Witch who knows it, with the enemy in reach, a reaction left, the PP, and not blinded (Q28). Enemies are hostile against friendly tokens.
- **The reroll:** fresh dice and the same modifiers. The first roll's Conviction die is lost.
- **The second result is locked** (Q27). Nothing can change it after this: no Conviction, Lucky Break, held bonus, Devotion downgrade, natural defence or fumble reroll.
- **Not if the d20 exploded**, as printed (Q29).
- **Afterwards** the target is immune to Missed Chance, from any Witch, for an hour of world time (Q30).
- **When the target isn't the Witch's player's** (a GM's creature, for instance), the GM's client records the immunity. With no GM connected, a notice asks for it to be noted by hand.
- **On a weapon attack,** the attack card shows the hex and the "rerolled (a → b)" line.

**Second Chance** (3 PP, 60 ft, an ally):
- The same, for an ally who *fails*: Failure or worse, or a miss.
- An exploded d20 doesn't stop it. The book prints no such line (Q29).

**Prophetic Warning** (3 PP):
- **Offered before the Witch's own** attack check, save or skill check, but only one with a DC. A check with no consequence isn't asked about (Q31).
- **Yes** casts it and the check gains advantage. The Witch is then immune to it for an hour.
- **With the setting off,** cast it from the sheet instead. Its advantage then waits for her next attack check, save or skill check.
- **The setting is the table's,** not each player's. A check is often rolled on another client, such as the GM's for a save against the GM's spell.
- **A reroll of that check keeps the advantage:** Alter the Thread, or Fortune's Reversal on a fumble.

## Damage reactions

**Phase Familiar** (1 PP, 60 ft):
- **Offered to the familiar's master** when the familiar is about to take damage.
- **Yes** gives the familiar resistance to all damage and immunity to precision damage, against that damage only.
- **Warped for +10 PP** in the cast, it gives immunity to all damage instead. The warp is read from what the cast actually paid.
- **"That damage":**
  - a weapon's is the whole strike: the weapon's own packet, and its runes, riders and typed extras;
  - a spell's is every packet of that one cast;
  - any other damage is that blow.

**Resist Magic** (the Rune birthright's Runic Resilience; a reaction):
- **Offered** when the creature is about to take damage from a spell, cast from anything (scroll, wand or item included), or from any damage the system marks magical.
- **Not offered** for a magic weapon's own damage (Q32).
- **Yes** gives resistance to all of that spell's damage, every type it deals and every instance, until the cast settles. It is asked once a cast, so a later packet of another type is covered too.
- **A spell's damage on a later turn** (a wall, a storm, an emanation) is asked about too, and resisted for that blow.
- **Other magical damage** (not a spell's) is resisted for its own types, for that blow.

**Both** are asked once per creature per cast. A creature hit by several packets of one spell keeps its first answer.

## Disrupting Magic (Arcanum birthright; 120 ft)

- **When:** another creature's cast has succeeded (Success or better) and has not yet landed. Every cast counts, innate spells and cantrips included (Q33).
- **Who is asked:** any creature that knows it and has its reaction, other than the caster's allies.
- **Not while it could not cast a spell:** a Rage, an antimagic zone or Magic Suppression area, or a critical injury's "cannot cast". It is a spell, even though it is rolled as a Dispel.
- **Yes** opens the system's own **Dispel (Power Manipulation)** check, at no AP. The check is aimed at the incoming spell: its PP and the caster's Spellcraft DC are filled in.
- **The reaction is spent once the Dispel is rolled.** A dialog closed without rolling costs nothing.
  - Disrupting Magic's own casting DC doesn't apply, and nor does its 1 PP. The Dispel spends PP as the Dispel does (Q23, Q33).
- **Success or better stops the spell.** Nothing lands, and the cast resolves as a failure.
- **If it fails,** the next creature in reach who has it may try. The card lists each attempt.

## Eternity Resilience (Eternity birthright)

- **When:** the creature takes a critical hit, from a weapon or a spell.
- **Yes** spends a Conviction point, and the critical roll has disadvantage. Against a deadly critical's advantage, the roll is normal.
- **The system's Conviction rule stands** (Q35): one Conviction point a round. If none is left this round, it isn't offered.
- **Not offered on a minor critical.** Its roll is already at disadvantage, so a point would buy nothing.

## Found in review

Two independent reviews found the following: one of the build, one of the first review's fixes. All are fixed, with checks and mutations, and each change is described in its section above.

- **The hour's immunity:** wasn't recorded on a creature the Witch's client doesn't own.
- **Resist Magic:** covered only the first packet's types of a cast.
- **Phase Familiar:** lost its cover before a strike's runes and riders.
- **Eternity Resilience:** was offered on a minor critical.
- **Prophetic Warning:**
  - its advantage was lost on a reroll;
  - its setting was read on whichever client rolled.
- **Disrupting Magic:**
  - ignored what forbids casting;
  - spent the reaction before the dialog;
  - asked only one disrupter.
- **The weapon card:** showed no reroll line, and no Prophetic Warning line.
- **The second review's main finding was in the system: no granted defence would have worked live.** The harness's fake creatures had a link from their data back to the creature, which Foundry's real ones lack. So Phase Familiar and Resist Magic would have spent the reaction and PP and changed nothing. TRG Prime 3.681.0 adds the link.
- **Spell damage on later turns is now offered too:** a wall, a storm, an emanation, a hazard and the like. Every spell-damage site in the system asks.
- **Disrupting Magic's Dispel** no longer reads whatever the reactor has targeted.
- **The rest of the system's side** is in TRG Prime 3.681.0's notes: the strike scope, the carried advantage, the card, each question tied to the cast it began in, and the disconnected answerer.

**For Graham, one open question.** A disrupted cast resolves as a failure, as ruled. So in a Wild Magic area (Block 2) it surges. The system now tells a disrupted cast apart (`disrupted`), so this can be reversed if you'd rather it didn't surge.

## Not offered

- **A turn's bleeding or burning,** and damage of no type: the system asks no reaction for them. The cards say so.
- **Awareness of the enemy** can't be read from the map. The reactor's player (or the GM) declines when they aren't aware (Q28).

## Content

- The five spell cards (Missed Chance, Second Chance, Prophetic Warning, Phase Familiar, Disrupting Magic) and the Resist Magic and Eternity Resilience texts now read "*Automated (0.6.0, TRG Prime 3.681.0):* …" in place of "Waits for Block 3b". The packs were rebuilt.

## Code

- **New: `module/block3b-automations.mjs`.**
  - **Pure decisions, driven by the harness:**
    - `immuneTo` and `withImmunity` (Q30);
    - `enemies` and `allies` (Q28);
    - `phaseAnswer`, `resistMagicApplies` (Q32) and `eternityApplies` (Q35).
  - **The seven offers**, registered with the system's `registerCheckReaction`, `registerDamageReaction`, `registerCastReaction` and `registerCriticalReaction`.
  - **The four reaction steps,** run on the reactor's client: cast a hex as a reaction, spend a reaction, roll the Dispel, and spend Conviction.
- **Changed:**
  - `registration.mjs` calls `registerBlock3b`.
  - The main script registers the setting at init, and hooks `trgPrimeSpellSettled` for a Prophetic Warning cast from the sheet.
  - `REQUIRED_SYSTEM` is now 3.681.0.
  - The GM's listener for the hour's immunity is registered at ready, on the module's socket (`module.trg-eldritch-arts`; `"socket": true` was already in module.json).

## Harness

- **New pair: `verify-block3b` (80 checks) and `mutate-block3b` (75 mutations, all caught),** with the review's fixes.
- **Still green on 3.681.0:**

  | Harness | Checks | Mutations caught |
  |---|---|---|
  | `verify-block1` | 883 | 86 |
  | `verify-block2` | 131 | 75 |
  | `verify-block2b` | 91 | 81 |
  | `verify-block3` | 302 | 83 |

  `verify-block2` F is re-anchored for the new init line.
- **The system's side** (`verify-ea-block3b-core`, 99 checks and 92 mutations) ships with TRG Prime 3.681.0; see its release notes.
