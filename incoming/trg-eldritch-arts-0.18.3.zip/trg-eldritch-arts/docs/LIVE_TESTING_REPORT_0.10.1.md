# Live recheck: Eldritch Arts 0.10.1 on TRG Prime 3.685.1

7 November 2026. This rechecks the fixes for the findings in the 0.10.0 live test, in Graham's world with both releases installed and active. Chrome's extension was not reachable, so the recheck ran in the desktop app's built-in browser.

**Setup**

- **Throwaway actors:** "ZZ EA Wizard" (level 20) and "ZZ EA Foe" (Fighter, level 8, with a Broadsword).
- **Throwaway scene:** "ZZ EA 0101 Recheck", with its own combat.
- **Dice:** fixed for each test.

## Results: all pass

| Finding | What was checked | Result |
|---|---|---|
| 1. Teleport card at the cast | The foe hit; Panic Transposition was cast (4 PP, a Critical), and the damage landed. | No "Teleported — Spatial Awareness" card at the cast. It was posted only after the landing click, followed by "You wrench space and reappear 10 feet away". The teleport record was set then. |
| 1. Escape | Escape at the landing prompt, in a later round. | No card, no move, and the teleport record still showed the earlier round. |
| 1. Second teleport in a turn | A second hit in the same turn as the teleport. | Panic Transposition was not offered, and no PP was spent. |
| 2. Spirit Arrow's cast card | Cast (6 PP, a Critical). | "your next ranged Strike deals 6d6 piercing in place of its damage, with nothing added". |
| 3. Creature target dialog | Spirit Arrow cast with the foe targeted. | No "Select Target" dialog. The foe was targeted again after the cast. |
| 4. Coldfire name | Eaog Balls with the coldfire warp; the foe fumbled its save. | "Recurring Damage 4 (Coldfire)" beside "Recurring Damage 6 (Force)". |
| 5. Distracted rows | Animate Moustache cast twice on the foe; both saves failed. | One "Distracted" effect (31 changes, 1 minute). The second cast replaced it rather than adding a row. The second save showed a single "Distracted Status -1". |
| 6. Landing prompt | The notice shown when Panic Transposition's landing is asked. | A permanent notice: "Panic Transposition: click the square where you land, up to 30 ft away. Escape cancels." It was still showing after 8 seconds, and cleared on the click and on Escape. |

**Correct, and not a fault:** in round 1 Panic Transposition was not offered, because the combat start had left the wizard Flat-Footed. Flat-Footed creatures can't use reactions, so this is right.

**Not run live:**
- Decoherence and Freshmark (the other two object-target spells).
- Two different casters' Distracted on one creature.
- Dimensional Assault.

The harness covers all three.

## Cleanup

- **Deleted:** the combat, the scene and its tokens, the two ZZ actors, and 47 test chat cards. There were no other new chat messages.
- **Dice:** restored.
- **View:** Oldwatch Approach.
- **Game:** still paused. There are no combats.
