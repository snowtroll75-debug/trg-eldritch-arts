# Eldritch Arts Block 9: audit (magic items, catalysts and special materials)

12 November 2026. Block 9 covers the gear and magic items in Chapters 6 and 9 that are still unbuilt:
- the **catalysts** and their rules;
- the **special materials**;
- Chapter 9's **armour and shield runes, specific armour, orbs, rods, staves, weapon runes and specific weapons**;
- the **four catalyst feats** that Block 5 shipped as cards;
- the **two weapons that add control levels** (Summoner's Brand and Ritualist's Edge).

The relics and the Relic Bonding Ritual are Block 10.

This audit counts the content, proposes a three-way split, and audits every item by family.

It was read against:
- ***TRG Prime: Eldritch Arts* v1.6**: the docx Graham attached on 12 November 2026, cut with the same commands as before (`pandoc -t gfm --wrap=none`, `<img>` tags stripped, sidebars by `tools/content/extract-sidebars.py`) into `/home/claude/ea-src/v16/ea.md` and `ea-sidebars.md`. Line numbers below are that file's. They match the earlier cut: the Grimoire starts at L5984 and Animal Binding at L6076.
- **The rules audit, Parts A, C and D** (`ELDRITCH_ARTS_RULES_AUDIT.md`), and **Graham's answers to it** (summarised in `ELDRITCH_ARTS_RULINGS_2026-11-01.md`). The full *Responses* document was not available this session. Where the summary is silent, what v1.6 changed is read as the answer, and anything still unsettled is asked in §8.
- **The Block 5 audit** (the catalyst feats, seam C12) and **Block 6's** (D12's feat half, G1's module metamagic rods).
- **TRG Prime 3.687.1**, surveyed in its source (`/home/claude/snowtroll75-debug/trpg-prime/module/…`), its rulebook text (`tools/source/rulebook-core-3.7.txt`) and a fresh dump of its 31 packs (`/home/claude/b9/core-dump/`).

**Nothing is built.** Every rule below is quoted from the book or from a ruling. Where the book is silent and the answer would change play, the point is asked in §8 rather than decided here.

**Status: answered.** Graham, 13 November 2026, 00:23: "Go with your recommendation for all questions and proceed". Q185–Q210 are ruled as each row's recommendation below, and seams H19–H25 are approved as proposed. Block 9a is next: TRG Prime 3.688.0 (H19, H20) and Eldritch Arts 0.13.0.

## 1. The count

### 1.1 What Block 9 holds (v1.6)

| Family | Where (v1.6) | Count | Matrix rows | Notes |
|---|---|---|---|---|
| **Catalysts** | Ch6 L5202–5508 (rules L5212–5234; table L5482) | **24**, and the catalyst rules | CAT-01–24 | All 24 entries and the table read whole |
| **Catalyst feats** (Block 5) | Ch5 L4330–4355 | **4** | FG-02–05 | Shipped in 0.8.0 as items with "arrives with Block 9" cards |
| **Special materials** | Ch6 L4761–4903 | **10** | MAT-01–10 | Ashbone … Veilglass |
| **Armour and shield runes** | Ch9 L8943–9153; tiers in sidebars 17–28 | **18** | RU-001–018 | v1.6 renames Quickbind to **Swiftbind** (m159, m163) |
| **Specific armour and shields** | L9155–9255 | **5** | AR-01–05 | Gravemeld Shirt, Heartstrand Harness, Shadeskin, Spellguard (a shield), Whispering Hollow |
| **Orbs** | L9265–9453 (rules L9269–9341) | **5**, and the orb rules | OR-01–05 | |
| **Rods** | L9455–9603 | **9** | RD-01–09 | Focused Spell I–III, Ley Resonance, Quickening II, Binding Seal, Catalyst Flow, Soul's Echo, Wild Surges |
| **Staves** | L9605–9705 | **5** | ST-01–06 | **The Weaver's Delight is gone** (M89, "the staff is removed"), so the matrix's six are now five |
| **Weapon runes** | L9715–9955; tiers in sidebars 29–32 | **16** | RU-019–034 | |
| **Specific weapons** | L9957–10049 | **4** | SW-01–04 | Bleeding Crown, Soulrend, Ritualists Edge, Starfall |
| **Wondrous items** | L10051–10059 | **0** | — | The section is an introduction that leads into Relics. v1.6 prints no wondrous item outside the relics, so no `ea-wondrous` pack is needed. |
| **Total** | | **100 items**, plus the catalyst and orb rules | | |

The two control-level weapons are **Summoner's Brand** (a weapon rune, L9893) and **Ritualists Edge** (a specific dagger that carries that rune, L10007). Both print "Whilst wielding this weapon you increase your control levels by 2" (L9903, L10023).

The Appendix's **ORB** trait (L10732) belongs here: "Only one item with the Orb trait may be invested by you at any one time." RELIC and SENTIENT are worded the same way and belong to Block 10.

**The attached docx is not quite the copy cut on 1 November.** A re-cut differs from the shipped `book-text.json` in two lines, both outside Block 9:
- the Sorcerer's birthright table now reads "Orb of Electricity (0)" for "Shock Bolt (0)";
- a specialist spell's "1d8 + Charisma HP + and" lost the stray "+".

`book-text.json` is re-cut from this copy in the build, and Blocks 1–8's verifiers are run again. Nothing in this audit depends on either line.

### 1.2 The split, and why

| Sub-block | Content | Core seams | Why together |
|---|---|---|---|
| **9a** (TRG Prime 3.688.0, EA 0.13.0) | **Catalysts (24)** and their rules; the **4 catalyst feats**; the **10 special materials** | H19 (catalysts), H20 (materials) | Both are Chapter 6 gear that plugs into existing core machinery: the cast and the item quality tables. Every later item needs them. Three specific armours are made of an EA material, the Catalyst rune holds catalysts, and the Rod of the Catalyst Flow saves one. |
| **9b** (3.689.0, EA 0.14.0) | **Armour and shield runes (18)**, **weapon runes (16)**, **specific armour (5)**, **specific weapons (4)** | H21 (rune declarations), H22 (the strike's die and fumble) | All of them are runes, or items made of runes. They share the rune registry, `declares` and a single harness. The specific items need 9a's materials and their own runes. |
| **9c** (3.690.0, EA 0.15.0) | **Orbs (5)** and the orb rules; **rods (9)**; **staves (5)** | H23 (the Orb kind), H24 (module rod powers), H25 (one invested per trait) | The charged items share the charged-item code (D12). The orb is a new kind, and four rods do things the core's rods cannot. |

Block 8 needed two releases for 39 spells. Block 9 has 100 items, seven seams and three distinct machineries (the cast, the rune registry and charged items). Each machinery gets its own harness pair, sweep, review and live test. The split is Q185.

## 2. What TRG Prime 3.687.1 already has

| Need | The core today (file, function) | Gap |
|---|---|---|
| **A cast option a module offers** | `registerCastOption` (`module-api.mjs` L1395): `offer(ctx)` puts a tick on the Casting Conditions prompt; `apply(ctx)` answers `castingDC`, `saveDC`, `lines`, `ap`, `attack`, `saveDCTarget`. `trgPrimeSpellSettled` carries `castOptions` (the keys taken), `degree`, `cast`, `ppSpent` (`magic/cast-workflow.mjs` L6359). | **No list of owned items, no consumption, no advantage** on the casting check (a gate may answer `disadvantage: true` only, L1159), **no damage, die-step, damage-type or range/duration change**, and **no "one per spell"** group. Seam **H19** (D3). |
| **PP discounts and cap raises** | `registerCastCostModifier` (payment only, Graham's Q93); `registerCastCapModifier` (L1468: a whole number added to the cap for one cast). | None for Resonant Crystal Shard (Q189), or Summoner's Brand's caster level +1 (Q204). |
| **Materials** | `item-quality.mjs` `MATERIALS` (L171), frozen: Adamantine, Cold Iron, Densewood, Dragonhide, Eaog, Mithril, Silver, Alchemical Silver. Their properties: `levelDelta`, `appliesTo`, `hpMultiplier`/`hpPercent`, `weightPercent`, `drBonus`, `armourAcpReduction`, `armourSpeedPenaltyReduction`, `armourMaxDexBonus`, `weaponExtraDie`, `weaponGrantsTrait`, `overcomesResistance`, `weaponCountsAsSilver`, `savingThrowBonusVsMagic`. Ten readers (`item-quality`, `defences`, `combat/damage-workflow`, `combat/attack`, `codex-runes` …). | **No module can add a material.** And most of the ten need properties the table lacks (§3.2.3). Seam **H20** (D18). |
| **Weapon traits** | `registerWeaponTraitRule` (C13). The core's **Serrated** trait (rulebook L12164: "Any bleed results … increased by 1") and **Keen**. | None (Bloodglass, Bloodwood). |
| **Runes** | `registerRunes` (L894): key, name, `on`, tiers, price, usage, `declares`. `rune-declarations.mjs` reads `bonuses`, `conditionals`, `sense`, `strikeRider`, `ghostTouch`, `afterStrike`, `onCritical`, `saveReroll`, `onHealed`, `soulDrainReduce`, `action` (an Activate button), `stabiliseAtZero`, `healingRider`, `criticalGuard`, `deathGuard`, `criticalAdvantage`, and `energy` (L547: the five energy runes' activation, secondary dice and secondary critical). Specific items name their runes on `flags.trg-prime.specificItem.runes`. | **Not read from a rune:** `controlLevelBonus` (C12 reads equipped items and effects only, `magic/casting.mjs` L421), a Spell Adder (`magic/spell-adder.mjs` L60 reads `flags.trg-prime.spellAdder` on items), a resistance, Max Dex, donning AP, the armour casting penalty, a critical-roll reduction, DR to an uncovered location, a daily repair, catalyst slots. Seam **H21**. |
| **Strike hooks** | `trgPrimeStrikeResolved` (`combat/attack-workflow.mjs` L3942): attacker, target, weapon, hits, `critical` (severity), melee, thrown, `damageTaken`, missed. `trgPrimeCriticalInjury`. | **No natural die and no weapon fumble** in the payload: Pyrebrand's and Sanguine's "natural 20", and the five runes' "On a fumble" drawbacks, cannot be read. Seam **H22**. |
| **Hit location** | `combat/hit-location.mjs`; armour's `coversTorso/Arms/Legs`. | None (Aegisflow). |
| **Donning** | `donning.mjs`. | Confirm in the build that a rune can shorten it (Swiftbind). |
| **Restricted AP** | `combat/restricted-ap.mjs` (a point that may be spent on certain action kinds only). | Confirm that a point can be restricted to the attack trait (Chrono). |
| **Light** | `registerLightSources` (3.669.0). | None (Luminous, Sunbronze). |
| **Counteract** | `combat/counteract-workflow.mjs`, `magic/counteract-row.mjs`; rulebook L19543 (±2 per level or PP of difference). | Nullflow's check is Q195. |
| **Incorporeal** | `data/appendix-traits.mjs` L98 (immune to non-magical attacks and precision damage, resistant to every type but force, passes through objects). | None for Veil (Q196). |
| **Charged items** | `charged-items.mjs`: kinds wand, rod, staff, other (`chargedItemLevel` L207); `chargedItemPrice` (L231; staff and rod ladders); `castFromItemOptions` (L280: Spellcraft **Easy** with your tradition; skill **Hard** with rank ≥ PP and Use Magic Device); `dailyRecharge` (L35); `chargedItemWarnings` (one wielded). The depletion table (`magic-items.mjs`) breaks the item on 41–65. `registerChargedItemRule` (D12's feat half: wieldLimit, cost, payment, metamagic, onRelease). | **No orb kind.** Orbs are Hard by Spellcraft with no tradition, Very Hard by skill, PP = level × 3, the staff price × 1.25, no natural recharge and a flare on 41–65. Seam **H23** (D12's item half). |
| **Rods** | `rod-powers.mjs`: `metamagic {kind, maxPP, cost}` (extend, quicken), `ppSource {tradition}`, `spellAttack`, `checkAdvantage`; `moduleMetamagicRodsOf` (L213, 3.684.0, G1: a rod whose `metamagic.kind` is a registered module key, **built for Block 9's Rods of Focused Spell**). | **A rod paid for something other than metamagic or a draw:** Binding Seal (−1 casting DC), Soul's Echo (+2 Save DC against undead), Wild Surges (a surge) and Catalyst Flow (keep a catalyst). And Ley Resonance's doubled draw near a ley line. Seam **H24**. |
| **One invested per trait** | `trait-rules.mjs` `staffInvestRefusal` (L223): the Staff trait only. | ORB (and Block 10's RELIC and SENTIENT). Seam **H25**. |
| **Control levels** | **C12 is built** (3.683.0): `flags.trg-prime.controlLevelBonus` on a feat, an active ability, an **equipped** item or a live effect, added after the cap. | A rune inscribed on a weapon (Summoner's Brand) puts nothing on the weapon's flags. H21 makes a rune's declaration count while its weapon is equipped and invested. Ritualists Edge can carry the flag on the item itself. |
| **Spell Adders** | `magic/spell-adder.mjs`: an item's `flags.trg-prime.spellAdder`, Arcane Bond, wondrous adders. Rulebook L30021: "Spell Adders from multiple sources can be applied". | **No scoped adder**: Emberlight's "+1 Spell Adder for spells with the fire trait"; Tesra'Anvir's "+4 Spell Adder for all arcane & high magic casters". Part of H21. |
| **Wild surges** | The module's `rollTable` (`block2-automations.mjs` L367, with `level`, `radiusFeet`, `forcedTotal`), `wildSurgeFor` (L705), Chaos Shield's halving. | None (Resonant Flare, Rod of Wild Surges, Leybound, Warpflare, Wildbane). |
| **Item pricing** | `magic-item-tables.mjs` `priceForLevel` (staff and rod ladders). | None: every orb, rod and staff price checks against it (§3.2.6). |

## 3. The items

### 3.1 Grades and packs

Grades are the matrix's: **A** full, **B** interactive (automated with a normal player or GM choice), **C** partial (one clause or more left to the table, said on the card), **D** descriptive. Each grade assumes the seams in its row. Without them the row drops to C, and the missing part is a card line.

Packs (the architecture's §1):
- `ea-consumables` extends `consumables` and holds the 24 catalysts;
- `ea-runes` extends `runes` and holds the 34 runes (browsing only; they become inscribable through `registerRunes`);
- `ea-specific-items` extends `specific-items` and holds the 9 specific items;
- `ea-charged-items` extends `charged-items` and holds the 19 orbs, rods and staves.

Materials are registered (H20), not packed, as the core's are.

### 3.2 Each family, as printed (v1.6) and as built

#### 3.2.1 Catalysts (24): the rules

Quoted:
- L5218: "A catalyst may be invoked when declaring a spell, before the Spellcraft check is rolled."
- L5220: "Any damage effects caused by catalysts require a basic saving throw of a type appropriate to the spell cast." (M18, ruled as proposed: an attack spell's catalyst damage rides the attack; a save spell's uses its save; any other spell's is basic Reflex.)
- L5222: "consumed immediately upon use, whether the spell succeeds or fails."
- L5226: "If the Spellcraft check results in a Failure, Fumble, or Blunder, the spellcaster suffers the listed backlash effect."
- L5230: "A spellcaster may use only one catalyst per spell. Catalysts do not stack with other catalysts or similar effects."
- L5210: "All bonuses and penalties gained from catalysts are item bonuses unless stated otherwise."

**The model (§4.1):** each catalyst is a consumable item with `flags.trg-prime.catalyst {key}`. H19 offers the owned catalysts that apply to this spell as one choice on the Casting Conditions prompt (none, or one). The chosen catalyst's effect is applied to the cast, the item is consumed (subject to Q186, the feats and the rod), and its backlash is applied from `trgPrimeSpellSettled` on Failure, Fumble or Blunder. A Partial is not a failure for this rule (L5226 lists the three).

| # | Catalyst (line) | Rarity · cost · level | Effect (quoted, short) | Backlash (quoted, short) | Build | Grade |
|---|---|---|---|---|---|---|
| 1 | Arcanite Powder (5240) | U · 50 · 1 | "advantage on Spellcraft checks to cast Arcane tradition spells" | "–2 penalty to Arcana checks for 1 hour" | Offered on arcane spells (High Magic too: "count as belonging to all traditions", L10726); advantage on the casting check (H19) | A |
| 2 | Ashen Lotus Bloom (5250) | R · 180 · 2 | "Spells with the essence or fire trait ignore resistance" | "Soul Drain 1 per PP" | Essence or fire spells; the cast's damage ignores resistance (H19, `ignoreResistance`); Soul Drain = PP (R3: leave) | A |
| 3 | Blood-etched Vellum (5260) | U · 35 · 0 | "+2 to Spellcraft checks for ritual casting" | "1 bleed damage per PP of the spell (max 10)" | Offered in the ritual dialog (the primary's check) only; +2 item | A (bleed: Q202) |
| 4 | Celestial Dewdrop (5270) | R · 380 · 3 | "1d6 secondary essence damage per spell PP and ignores resistance" | "Blinded for 1 minute" | Secondary essence dice on a damaging spell, per M18 | A |
| 5 | Chained Obsidian Bead (5280) | U · 40 · 0 | "+2 to attack rolls if it requires one" | "Immobilised until the end of their next turn" | Attack spells; +2 item to the spell attack (`attack`) | A |
| 6 | Cinders of the First Flame (5290) | R · 70 · 1 | "damage die by one step (d6 → d8, etc.)" | "1d6 recurring fire" | Die step on the spell's damage dice (Q188) | A |
| 7 | Dragonbone Dust (5300) | R · 75 · 1 | Text "Adds +1 damage."; table "Adds +1 damage die." | "On a fumble or blunder … Weakened 1 for 1d4 rounds per PP" | **M10: +1 damage die; backlash on Fumble or Blunder only.** One more of the spell's own damage die | A |
| 8 | Eclipse Resin (5310) | R · 120 · 1 | "Disadvantage on attempts to identify the spell" | "1d6 essence damage per 2 PP" | A flag on the cast's card; the core's identify-spell checks read it (confirm in the build; else a card line) | B |
| 9 | Frozen Marrow Shard (5320) | R · 60 · 1 | "Changes the damage type of a spell to cold and adds +1 DR to the caster until the end of their next turn" | "1d6 cold damage per 2 PP … Slowed 1 for 1 round" | Damage type → cold; a timed effect +1 DR on the caster | A |
| 10 | Glimmercoal (5330) | R · 60 · 1 | "an additional 1d6 fire damage per 2 PP" | "1d6 fire damage per spell 2 PP" (m70: typo still in v1.6) | Extra fire dice, per M18; not "secondary" as printed | A |
| 11 | Grave Soil (5340) | U · 50 · 1 | "Spells with the essence trait deal +1 damage die" | "Frightened 1 … for 1d6 rounds (–2 penalty to Spellcraft checks)" | As Dragonbone, essence spells only | A |
| 12 | Incense of Stillness (5350) | U · 100 · 2 | "advantage on Spellcraft checks" | "Disadvantage on all Spellcraft checks for 1 minute" | Advantage; backlash a timed effect, disadvantage on every Spellcraft check | A |
| 13 | Leydust (5360) | U · 25 · 0 | "+2 to the Spellcraft check" | "1d6 force damage per 2 PP" | +2 item | A |
| 14 | Moonveil Dust (5370) | R · 80 · 1 | "illusion or enchantment trait gain +2 to their Spell Save DC" | "Dazzled for 1 minute" | `saveDC` +2 | A |
| 15 | Phoenix Feather Ash (5380) | R · 250 · 3 | "Healing spells restore +1d6 HP per PP" | "1d6 essence damage per PP" | Healing-trait spells; heal dice + 1d6/PP | A |
| 16 | Resonant Crystal Shard (5390) | U · 40 · 0 | "Reduces the spell's PP cost by 1 (minimum 1)" | "1d6 piercing + 1d6 force damage per 2 PP" | A cost modifier on this cast (Q189) | A |
| 17 | Sanctified Myrrh (5400) | U · 50 · 1 | as Arcanite, Divinity | "–2 penalty to Religion checks for 1 hour" | As Arcanite | A |
| 18 | Sands of the Hourglass (5410) | U · 45 · 0 | "immediately take an additional 1 AP this turn" | "Slowed 1 for 1d4 rounds" | +1 AP this turn, in an encounter only | A |
| 19 | Spell Incense (5420) | C · 20 · 0 | "+1 bonus to Spellcraft checks for any spell" | "–1 penalty to Spellcraft checks foe 1 minute" (m70) | +1 item | A |
| 20 | Starpetal Oil (5430) | R · 55 · 1 | "Extends a spell's range or duration by 50% (choose when used)" | "applying its effect at half strength to the caster instead of the target" | Range or duration ×1.5 (the cast's warp mods); the backlash is Q190 | B (backlash C) |
| 21 | Stormglass Phial (5440) | R · 90 · 1 | "gains the Electricity trait and deals +1d6 secondary damage per 2 PP" | "Stunned 3" | Trait added; secondary electricity dice per M18 | A |
| 22 | Verdant Sap (5450) | U · 50 · 1 | as Arcanite, Verdant | "–2 penalty to Nature checks for 1 hour as the sap their mind" (m70) | As Arcanite | A |
| 23 | Void Ash (5460) | R · 50 · 1 | "Converts all damage dealt by the spell into essence damage" | "1d4 Soul Drain per 2 PP" | Damage type → essence (R3: leave) | A |
| 24 | Whisperglass Shard (5470) | R · 50 · 2 | "advantage on Ethereal Spellcraft checks" (no full stop) | "Confusion for 1d4 minutes" | As Arcanite, Ethereal | A |

The backlash's "per PP" and "per 2 PP" read the PP as cast (Q187). Damage backlash is applied to the caster with no save (none is printed), and Catalyst Affinity's reduction is applied before it.

#### 3.2.2 The four catalyst feats (Block 5, upgraded)

| Feat (line) | Text (quoted) | Build | Grade (was D) |
|---|---|---|---|
| **Catalyst Affinity** (4330) | "reduce damage taken by 2 per character level, and reduce condition durations (such as stunned, dazed, slowed) by 1 round (minimum 1)" (R2: leave as printed) | Read by the backlash step: HP damage −2 × level (minimum 0); round durations −1 (minimum 1) (Q191) | A |
| **Catalyst Conservation** (4336) | "attempt a DC 15 flat check. On success, the catalyst is not consumed … On a fumble or blunder result of the spellcasting check, the catalyst is always consumed" | Read by the consume step: a flat check rolled at the cast and shown on the card; the consumption waits for the degree | A |
| **Catalyst Crafting** (4342) | "You gain the Catalyst Item Create specialty and may make catalysts using the crafting skill … must have the relevant formula and any rare materials" | `registerCreateRoute` for the `catalyst` consumable kind (the core's Create, at the catalyst's level and price). Holding the formula and the materials is the table's. | B |
| **Catalyst Mastery** (4350) | "If you roll a failure on a Spellcraft check, you do not suffer the effects of backlash. Fumble and blunder results are unaffected." | Read by the backlash step: no backlash on Failure | A |

Rod of the Catalyst Flow (§3.2.7) and the Catalyst rune (§3.2.4) join the same consume step (Q192, Q209).

#### 3.2.3 Special materials (10)

L4767: "The following materials may be selected when crafting weapons, armour, shields, or equipment, following the same guidelines as those found in the Core Rulebook."

| Material (line) | Rarity · level | Printed (quoted, short) | Build (H20 properties) | Grade |
|---|---|---|---|---|
| **Ashbone** (4769) | U · +2 | "weigh half as much"; weapons "treated as silvered for overcoming resistances"; armour "reduces all penalties by 1 and increases the wearer's maximum Dexterity bonus by the same" | `weightPercent −50`; `overcomesResistance: "silver"`; armour ACP −1, Max Dex +1, and "all penalties" (Q193) | A |
| **Bloodglass** (4783) | U · +2 | weapons "gain the serrated trait"; armour "+1-item bonus to saving throws against effects with the essence trait"; "weigh 20% less … shatter violently when destroyed, dealing 1d6 piercing damage per 2 levels of the item to all creatures within 5 ft" | `weaponGrantsTrait: "Serrated"`; save bonus vs essence trait (new); `weightPercent −20`; shatter on the item's destruction (new; its save is Q194) | B |
| **Bloodwood** (4797) | U · +2 | "weapons and implements gain the Keen trait"; "staves, bows, and wands grant a +1-item bonus to Spellcraft checks when used as a focus for Soul or Verdant spells"; "armour & shields increase their CR by 1 against essence or poison damage" | Keen on weapons (staves are weapons); "implements" Q194; a casting-check bonus when the item is your focus for a Soul-trait or Verdant spell (new); CR +1 against essence or poison criticals (new) | B |
| **Eversmoke Cloth** (4811) | R · +3 | armour and cloaks "weigh 20% less … reduce Stealth penalties by 2"; cloaks and robes "advantage on Hide (Stealth) checks in dim light or greater darkness"; a Fumble or Blunder on Hide "automatically revealing their location" | Weight; Stealth penalty (Q193); a conditional on Hide by light level (new: `lightLevelAt`); the reveal is a card line on the check | B |
| **Graveiron** (4825) | U · +2 | weapons "silvered … +1 base damage against undead"; armour "+1-item bonus to Fortitude saves against disease, paralysis, and soul drain" | Silver; +1 damage vs the Undead type (new); save bonus by tag (new) | A |
| **Nightsteel** (4837) | R · +4 | "50% more HP and hardness than steel"; weapons "AR 2 against magical armour and magical armour effects (such as Mage Armour) and inflict an additional die of base damage"; armour "reduces Stealth penalties by 2" | `hpPercent +50`, hardness +50% (new); AR 2 vs magical armour (Q194); `weaponExtraDie`; Stealth (Q193) | B |
| **Starion** (4851) | R · +4 | HP and hardness +50%; weapons "an additional die of base damage against creatures with the eternal trait"; armour and shields "weigh 20% less … +1-item bonus to saves against effects with the Insight trait" | Extra die vs a creature type (new); saves vs trait | A |
| **Sunbronze** (4865) | R · +3 | weapons extra die vs undead; armour "+1-item bonus to Will saves against fear and charm effects"; shields "radiate dim light (10 ft.) and can use their full CR against fire effects" | Extra die vs type; saves vs trait; a light source on the shield; "full CR" Q194 | B |
| **Tairneach** (4879) | R · +3 | weapons "+1d6 secondary electricity damage on a Critical hit"; armour "+1-item bonus to saves against electricity and sonic effects" | A critical secondary (the `strikeRider` shape with `onCritical`); saves vs trait | A |
| **Veilglass** (4891) | R · +5 | "double HP and hardness"; weapons extra die "against creatures with the aberration or incorporeal traits"; armour and shields "+2-item bonus to saving throws against planar, teleportation, and possession effects" | `hpMultiplier 2`, hardness ×2; extra die vs type or trait; saves (Q194: "planar" and "possession" are not traits) | B |

v1.6 still calls Starion "star-iron" and "Stariron" in its own bullets (m61). It is registered as **Starion**, with the other two spellings as aliases.

#### 3.2.4 Armour and shield runes (18)

All 18 follow "the same rules and guidelines as those found in the TRG Core Rulebook" (L8945). The tiers are in the sidebars and checked: each tier's level and price is on the core's rune ladder, or printed as an armour/shield pair.

| Rune (line; tiers) | Traits · usage | Printed (quoted, short) | Build | Seam | Grade |
|---|---|---|---|---|---|
| **Aegisflow** (8947; I L8 4,200 "half your armours DR", II L14 36,000 "all") | INVESTED WARDING · armour | "When you are hit and your armour lacks coverage (bracers/greaves) for a location, you may apply DR based upon the level of the rune to a location not normally covered" (m160, amended) | DR on a hit to a location the armour does not cover (`hit-location.mjs`), half or all of the armour's DR | H21 | A |
| **Arcanum Seal** (8957; I L5 +1, II L10 +2, III L15 +3) | ENCHANTMENT INVESTED · armour | "the benefits of a Spell Adder, based upon its level" | A Spell Adder of the tier, while invested and worn | H21 | A |
| **Astral Echoes** (8967; I L6 −5, II L12 −10, III L18 −15) | INVESTED WARDING · armour | "reduce the result of the critical injury roll … no effect if the critical is an UM 66 or 100" (m161, amended) | A modifier on the critical injury roll against you, skipped on UM 66 or 100 | H21 | A |
| **Binding Sigils** (8979; I L4 −2, II L8 −4, III L12 −6) | ENCHANTMENT INVESTED · armour | "summoned or bound creatures under your control suffer a penalty on Will saves made to resist or escape your commands" | The penalty on the control-overflow DC 20 Will save (H12's sweep) for creatures in your control register | H21 | A |
| **Bound Circle** (8989; I L4 +1, II L10 +2, III L16 +3) | INVESTED WARDING · armour | "Your armours item bonus to DB is increased against attacks made by either conjured or summoned creatures" | A conditional on DB against an attacker with the Conjured trait or a Summons binding (Block 8's bound marker) | H21 | A |
| **Catalyst** (8999; I L4 1, II L8 2, III L12 3, IV L16 4 catalysts) | ALTERATION INVESTED · shield | "You can imbed an amount of catalysts based upon the runes power level. Once imbedded into the item, each catalyst may be used once per day." (C6, amended) | Slots on the shield; an embedded catalyst is offered by H19 once per day and not consumed (Q192) | H19, H21 | B |
| **Comfort** (9011; L5 1,250) | ALTERATION INVESTED · armour | "advantage on the Fortitude save for Sleeping in Armour … Max Dex modifier of the armour is increased by 1" (m162, amended) | Advantage on the core's Sleeping in Armour save (`items-workflow`); Max Dex +1 | H21 | A |
| **Force Warding** (9023; L10 8,000) | INVESTED WARDING · armour | "resistance to force damage" | Resistance while worn and invested | H21 | A |
| **Ley Binding** (9035; I L4 +1, II L8 +2, III L12 +3) | INVESTED WARDING · armour | "a bonus to DB against attack spells and spells with the save trait that inflict damage" | A conditional on DB against a spell attack, and against a damaging save spell. Its type is Q194. | — | A |
| **Luminous** (9045; I L4 750/550 +1 step, II L6 +2, III L8 +3) | INVESTED INVOCATION · armour or shield | "increases the light level in a 20-foot radius based upon its power level" | A registered light source (20 ft, the tier's steps) | — | A |
| **Nullflow** (9055; I L8 1/day, II L12 2/day, III L16 3/day) | INVESTED WARDING · armour | "Reaction; Trigger the wearer is targeted by a spell … Make a counteract check (rune level as counteract level); on a success the effect is suppressed against you for 1 minute, then resumes" (M77, amended) | A cast reaction offered to the targeted wearer; the counteract check is Q195; a success suppresses the spell's effects on the wearer for 1 minute | — | B |
| **Renewal** (9067; I L6 level, II L10 2×, III L14 3×) | ALTERATION INVESTED · armour or shield | "automatically regenerate hit points … at the start of each day (during daily preparation). If the armour or shield is destroyed outright, the rune unravels and is lost." | On `trgPrimeDailyPreparation`: the item's HP += tier × item level (to max). A destroyed item's rune is removed from its field. | H21 | A |
| **Resonant Defiance** (9077; I L5 +2, II L9 +4, III L13 +6) | INSIGHT INVESTED · shield | "Requirement your shield is raised. Reaction; Trigger an enemy within 30 feet casts a spell. The casters Spellcraft DC to cast the spell is increased" | A cast reaction (`registerCastReaction`) by the shield's bearer while raised: the cast's casting DC + tier | — | B |
| **Soul Warding** (9091; L8 4,200) | INVESTED WARDING · armour | "resistance to essence damage" | As Force Warding | H21 | A |
| **Swiftbind** (9103; L6 2,000) | ALTERATION INVESTED · armour | "the time is reduced to 1 AP (light), 2 AP (medium) or 3 AP (heavy) Interact; full suits +1 AP" (m163, amended; the sentence still says "the Quickbind Rune") | Donning time by category (`donning.mjs`) | H21 | A |
| **Transcendent** (9115; L8 4,200/3,000) | ALTERATION INVESTED · armour or shield | "negates the penalty for casting spells whilst wearing armour"; "Be aware that it still does not allow a Druid to wear metal armour." | The armour's casting penalty is 0 while worn (Q199 for High Magic's ×4) | H21 | A |
| **Veil** (9129; I L6 1/day, II L9 2/day, III L12 3/day) | ALTERATION INVESTED · armour | "Reaction; Trigger the wielder is reduced to less than 25% hits or takes a critical hit of serious or higher severity … you may become incorporeal … you may only make move actions and actions with the defend trait" | A reaction after the damage: an effect that gives the Incorporeal trait and restricts actions; its duration is Q196 | — | B |
| **Wildbane** (9141; L11 11,000/7,700) | INVESTED WARDING · armour or shield | "+2-circumstance bonus on saving throws and DB against effects caused by Wild Magic surges … roll a flat check (DC 15). On a success, the surge's effect is suppressed entirely for you and any adjacent allies" (m164, amended) | Read by the module's surge path, as Chaos Shield is: a DC 15 flat check per surge within 30 ft; on a success, the surge skips the bearer and the allies adjacent to them; +2 to saves and DB against a surge row | — | A |

#### 3.2.5 Specific armour and shields (5)

Each is an armour or shield item in the core's `specificItem` shape: its base, quality, material and runes; its printed statistics; and its printed text. **Statistics are built as printed** (Q206).

| Item (line) | Level · price · weight | Base and traits (as printed) | Printed stats | Text lines that repeat a rune | Grade |
|---|---|---|---|---|---|
| **Gravemeld Shirt** (9159) | 12 · 21,150 · 31 lb | "This Graveiron chain shirt"; Traits "Metal, **Grave Iron**, Lightweight, Reinforced, Master, Potency II, **Quickbind**" | ACP −1; Max Dex 6; DR 4; CR 1; DB +2; HP 63 | Graveiron's armour save; "+1 DR vs slashing"; "only requires a 2 AP interact action to don" (Swiftbind on chain = medium) | A (H20, H21) |
| **Heartstrand Harness** (9177) | 5 · 1,260 · 15 lb | "This Reinforced Leather Breastplate"; Rigid, Expert, Potency I, Ley Binding I | ACP −1; Max Dex 6; DR 1; DB +1; HP 38 | "You gain a +1 bonus to DB against attack spells and spells with the save trait that inflict damage." | A |
| **Shadeskin** (9195) | 12 · 18,230 · 9 lb | "This Eversmoke Cloth full leather armour"; Eversmoke Cloth, Master, Full, Lightweight, Potency II, Shadow II (+2 Stealth), Veil II | ACP 0; Max Dex 9; DR 1; DB +2; HP 46; **Perception −1** | Veil's activation (no "2/day" in the block: Veil II's tier says it) | B (Veil) |
| **Spellguard** (9215) | 8 · 3,320 · 6 lb | "This Light Steel Shield"; Metal, Expert, Potency I, Resonant Defiance I, Spell (Resist Energy – Fire 1/day) | ACP −1; DR 1; DB +2; HP 44 | "The casters Spellcraft DC … is increased by 1" (Resonant Defiance I's tier says +2; **M79: leave as printed**); "Command (1 AP); Frequency 1/day … Resist Energy (Fire)" (the core's Spell Effect rune) | B |
| **Whispering Hollow** (9239) | 13 · 26,200 · 19 lb | "This Scalemail"; Ashbone, Full, Metal, Rigid, Lightweight, Master, Potency III, Comfort, Soul Warding (m168, partly amended) | ACP −2; Max Dex 7; DR 4; DB +3; HP 135 | "advantage on all fatigue checks made for sleeping in armour" (the old Comfort wording) | A |

#### 3.2.6 Orbs (5) and their rules

Rules, quoted:
- L9269: "Orbs follow the charged item rules for Staves the Core Rulebook with the following exceptions".
- L9277: "An Orb counts as your one wielded charged item." (m169, amended.)
- L9289: Spellcraft "as a Hard check (DC +2), this stacks with the modifier for casting High Magic" (M81, amended), with "Your caster level meets the PP requirements" and "the spell need not be from your tradition" (m170).
- L9293–9299: tradition skill "For High Magic spells, use Arcana (or the skill of your own tradition)" (M80, amended); "rank must equal or exceed the PP cost" (R17, amended); "Use Magic Device"; "Very Hard check (DC +5)".
- L9303–9305: "cannot recharge naturally … 25 gp worth of materials per PP restored … 1 minute per PP and requires no check" (m171, amended); "Recharge Item … The PP cost is 4 instead of 2, but you do not have to meet the requirements of the check".
- L9311: "41–65 … Resonant Flare … a Wild Surge (based on the orbs level) that affects all creatures in a 20-foot radius … The Orb is depleted (0 PP) but not broken." (M82, M83, m173, amended.)
- L9315–9319: level = "highest PP spell contained +2 (minimum 4)", "+1 per High Magic spell"; price "the Staff cost progression, but with a +25% price increase".
- L9325–9331: "an item bonus to checks made when interacting with ley lines": +1 (levels 1–8), +2 (9–16), +3 (17+).
- L9337: "abilities will stop working if the Orb is reduced to 2 PP or less."
- L9341: "PP equal to their level x3".
- Appendix ORB (L10732): "Only one item with the Orb trait may be invested by you at any one time."

**Checked by script** against the core's `priceForLevel("staff")` × 1.25, staff level and PP × 3:

| Orb (line) | Traits | Spells (PP) | Level: printed / by rule | PP: printed / L×3 | Price: printed / ladder ×1.25 | Abilities |
|---|---|---|---|---|---|---|
| **Emberlight** (9347) | INVESTED MAGICAL ORB | Orb of Fire 0, Burning Hands 2, Fire Bolt 4, Fireball 6 | 8 / 8 | 24 / 24 | 4,375 / 4,375 (m177, amended) | +1 ley; ≥3 PP: fire resistance, "+1 Spell Adder for spells with the fire trait" |
| **Shattered Veils** (9369) | HIGHMAGIC INVESTED ORB | Decoherence 0, **Leyline Burst 4** (M85, amended; High Magic), See Invisible 4, Planar Anchor 8 | 11 / 11 (8 + 2 + 1) | 33 / 33 | 11,250 / 11,250 | +2 ley; a Critical Tap Ley Line gives See Invisible (+4 PP warp) for 10 minutes |
| **Shifting Currents** (9391) | INVESTED MAGICAL ORB | Orb of Water 0, Gust 2, Shield 2, Obscuring Mist 2 | 4 / 4 | 12 / 12 | 750 / 750 | +1 ley; ≥3 PP: +1 item Acrobatics |
| **Verdant Heart** (9413) | INVESTED MAGICAL ORB | Tanglefoot 0, Conjure Plant 4, Entangle 4, Wall of Thorns 6, Regenerate 10 | **13 / 12** (m174, still open) | 39 / 39 | 25,000 / 25,000 at L13 | +2 ley; a Critical Tap gives "Fast Healing 2 for 1 minute" to you and allies within 10 ft |
| **Whispering Veil** (9433) | INVESTED MAGICAL ORB | Ghost Sound 0, Face Shifting 2, Cloak of Greying 2, Invisibility 4 | 6 / 6 | 18 / 18 | 2,000 / 2,000 (M84, amended) | +1 ley; ≥3 PP: +2 item Hide (Stealth) |

Every spell named exists: in the core (Orb of Fire … Regenerate) or in `ea-spells` (Decoherence, Leyline Burst, Planar Anchor, Orb of Water).

**Build (§4.3):** the `orb` kind (H23); the ORB trait's one-invested rule (H25); the ley-line bonus as a conditional while wielded; the "at least 3 PP" abilities as conditionals gated on the orb's PP (H23); the Critical-Tap riders from the module's Tap Ley Line result (`onActionAttemptB2`'s result path). **Grade A** for all five, with H23 and H25. The flare is the module's `rollTable` at the orb's level, radius 20 ft.

#### 3.2.7 Rods (9)

All print "the same rules that are found in the Core Rulebook" (L9457), Power Points 10 and Recharge 1. Each printed price matches the rod ladder at its printed level (checked).

| Rod (line) | Level · price | Activate · effect (quoted, short) | Build | Seam | Grade |
|---|---|---|---|---|---|
| **Focused Spell I/II/III** (9459/9475/9491) | 7 · 1,800 / 11 · 7,000 / 15 · 33,000 | "You cast a spell of PP 4 [8, 12] or less … expend 2 PP from the rod to apply the focused spell Metamagic feat. This does not increase the casting DC of the spell or cost you any PP." | `chargedItem.metamagic {kind: "focusedspell", maxPP 4/8/12, cost 2}`: built in 3.684.0 for exactly this (G1, `moduleMetamagicRodsOf`). The feat is Focused Spell (Block 6, m179). | — | A |
| **Ley Resonance** (9507) | 5 · 750 | "expend PP from this rod instead of your own reserve. Within 60 ft of a ley line, each rod PP counts as 2 (round the cost up).. This doubling only applies to PP spent from the rod" (M86, amended) | A PP-source rod for any spell; near a ley line (Block 2's areas, 60 ft) it pays at 2 to 1 | H24 | A |
| **Quickening II** (9523) | 16 · 50,000 | "a spell of PP 8 or less that has an AP cost of 1 or 2 … quicken" | The core's `metamagic {kind: "quicken", maxPP: 8, cost: 2}` (R12: a 1 AP spell cannot be quickened) | — | A |
| **Binding Seal** (9541) | 7 · 1,800 | "When casting a spell with the Summons trait, you may draw a PP from this rod to reduce the casting DC by 1" (m180, partly amended) | A rod power on a Summons cast: 1 rod PP, casting DC −1 (Q208) | H24 | A |
| **Catalyst Flow** (9557) | 10 · 5,000 | "Whenever you use a catalyst whilst casting a spell, you may expend 2 PP from this rod to prevent it from being expended" | A rod power in H19's consume step (Q209) | H19, H24 | A |
| **Soul's Echo** (9573) | 6 · 1,200 | "expend a PP from this rod when casting a spell. The spell's save DC is increased by 2 for undead targets of this casting" (m181, amended) | A rod power: +2 Save DC per undead target (`saveDCTarget`, extended to several targets) | H24 | A |
| **Wild Surges** (9589) | 6 · 1,200 | "expend a PP from this rod when casting a spell to trigger a Wild Surge. Area level = the spell's PP; the spell resolves normally" (M87, amended) | A rod power: after the cast settles, the module's `rollTable` at the spell's PP | H24 | A |

#### 3.2.8 Staves (5)

"The staves here use the same rules that are found in the Core Rulebook" (L9607). Level, PP (level × 2), recharge (1 per 10 PP) and price were each checked against the core's `staffLevel`, `staffPowerPoints`, `dailyRecharge` and the staff ladder.

| Staff (line) | Traits | Spells (PP) | Level · price · PP · recharge | Checks | Abilities | Grade |
|---|---|---|---|---|---|---|
| **Darkstaff** (9609) | INSIGHT INVESTED INVOCATION STAFF | Orb of Cold 0, Darkness 4, Darkvision 4 | 7 · 2,400 · 14 · 2 | ✓ (4 + 2, two schools +1) | — | A |
| **Eidothrix** (9627) | INVESTED STAFF TRANSLOCATION | Obscuring Mist 2, Phantom Steed 4 | 6 · 1,600 · 12 · 2 | ✓ | "+1-item bonus to Spellcraft checks when casting spells of the Translocation school" | A |
| **Staff of Flame** (9647) | INVESTED INVOCATION STAFF | **Orb of Fire 0** (M88, amended), Burning Hands 2 | 4 · 600 (m182, amended) · 8 · 1 | ✓ | Interact to light a flame (card) | A |
| **Staff of Heaven & Earth** (9665) | INVESTED MAGICAL STAFF (m184) | Gust 2, Obscuring Mist 2, Spike Stones 6, **Air Walk 6** (m183), Shape Stone 8 | 11 · 9,000 · 22 · 3 | ✓ | — | A |
| **Tesra'Anvir – Arcane** (9683) | ARCANE INVESTED STAFF | Shield 2, Knock 4, Eldritch Bolt 6, Eldritch Ball 10, Spell Drain 14 | 18 · 180,000 · 36 · 4 | PP and recharge ✓. Level by rule 17, price at 18 is 150,000: **m186, "the staff's other abilities are costed as wondrous items"**, so built as printed. | "+4 Spell Adder for all arcane & high magic casters"; "expend 8 PP from the **rod** to apply the quicken metamagic feat to a spell" (m185 still "rod"; R18: no PP or AP limit, leave as printed) | A (H21's scoped adder) |

#### 3.2.9 Weapon runes (16)

| Rune (line; tiers) | Traits · usage | Printed (quoted, short) | Build | Seam | Grade |
|---|---|---|---|---|---|
| **Aetherfang** (9719; L10 6,000) | INVESTED SHADOW · piercing or slashing | "bypasses Resistance to physical damage (but not Immunity). On a critical, … 1d6 essence damage (basic Fort) per critical severity step"; "Drawback If the weapon is fumbled, the wielder takes 2d6 essence damage (basic Fort)" (m191, partly amended) | Physical resistance ignored on its hits; a basic Fortitude per severity step on a critical; the fumble drawback (H22). DCs: Q201. | H22 | A |
| **Chrono** (9733; L13 17,000) | ALTERATION INVESTED · any weapon | "Command 0 AP You gain the quickened condition which may only be used to make an action with the attack trait"; Exhaustion check each turn used, one step harder each consecutive round; "if you gain the fatigued condition you cannot activate this rune and if it is already running, its effect immediately ends" (M90, amended) | An Activate (`action` declare); the extra AP restricted to attacks (`restricted-ap.mjs`); the turn-end Exhaustion check by an escalating step; ends on fatigued. Duration and timing: Q200. | — | B |
| **Echoing** (9751; I L5 900 1, II L10 6,000 2, III L15 40,000 3) | INVESTED INVOCATION SONIC · melee | "When you critically hit … recurring sonic damage based upon the runes power level" (M91, amended); drawback "faint whispers … audible within 30 feet" | Recurring sonic (the tier's value) on a critical (`addRecurringDamage`); the drawback is a card line | — | A |
| **Essencebreaker** (9763; L12 11,000) | INVESTED SAVE WARDING · any weapon | "On a hit, the target must succeed at a Will save (your level DC) or lose one resistance it has until the end of your next turn." (m192, amended) | `afterStrike` with a Will save; on a failure, one resistance (the wielder's choice, Q201) suppressed by a timed effect | — | B |
| **Gravitas** (9775; L11 8,000) | ALTERATION INVESTED · bludgeoning | "Once per round on a successful critical, you may Trip or Shove … as a free action (no MAP increase) … use your weapon attack bonus"; drawback "double its usual weight and increases FDC by 2" (m193, amended) | Offered on a critical: Trip or Shove through `resolveAction` with the weapon's attack bonus, no MAP and no requirements; weight ×2 and FDC +2 on the weapon | — | B |
| **Leybound** (9789; L8 3,000) | INSIGHT INVESTED · any weapon | "within 30 feet of a ley line … +1 circumstance bonus and deal an additional die of base damage"; on a fumble, "the GM also rolls on the Wild Surge table (area level = ley line level)" (m194, M92, amended) | A conditional by distance to a Ley Line Region (Block 2's `leyLinesWithin`); the fumble's surge at that line's level (H22) | H22 | A |
| **Mindpiercer** (9803; I L6 1,400 1d8 … IV L18 130,000 4d8) | ENCHANTMENT INVESTED MENTAL SAVE · any weapon | "On a successful critical … mental damage (basic Will)"; drawback "–1 penalty on Perception (GM discretion)" | A basic Will on a critical for the tier's dice (DC: Q201); the drawback as a GM-tick conditional | — | A |
| **Nullflare** (9815; L12 11,000) | INVESTED SAVE WARDING · any weapon | "Will save (your level DC) or have one active magical effect nullified (the lowest-PP effect, GM breaks ties)": Failure until the beginning of your next turn; Fumble the end of your next turn; Blunder dispelled (m196, amended) | `afterStrike`, Will; the target's lowest-PP spell effect suppressed (the core's effect suppression) or ended on a Blunder; ties go to the GM | — | B |
| **Pyrebrand** (9835; I L5 900 1d4/1d8 … III L15 3d4/3d8) | FIRE INVESTED INVOCATION · melee | "Command (1 AP) … additional secondary fire damage. On a natural 20 … fire damage to all creatures adjacent to the target (basic Reflex). The wielder is immune"; drawback −2 circumstance on Hide while invested | The core's `energy` shape (activation, secondary dice); the natural-20 surge (H22) as `runAreaEffect` on the target's neighbours; the Hide conditional | H22 | A |
| **Riftcleaver** (9849; L10 6,000) | INVESTED TELEPORTATION TRANSLOCATION · melee | "once per round after a successful strike … teleport 10 feet to a space you can see … +1-circumstance bonus to your next attack against that target"; fumble "teleporting you 1d6 × 5 feet in a random direction (GM rolls secretly)" | After a hit: a point pick within 10 ft and a move; the core's teleportation rule applies (Spatial Awareness, and a second teleport in the turn fails: `teleportationArrives`); the +1 held bonus; the fumble's move is the GM's (H22 gives the trigger) | H22 | B |
| **Sanguine** (9865; L9 4,300) | INVESTED SOUL · slashing melee | "When you damage a foe … 1 bleed damage in addition to the strike. On a natural 20, this increases to 1d4 bleed damage"; drawback "During an encounter, if you wield the weapon for three consecutive rounds without striking a foe, you gain bleeding 1d6" (M93, amended) | Bleed on damage (Q202); the natural 20 (H22); a three-round counter in combat | H22 | A |
| **Spellhold** (9879; I L5 900 6 PP … IV L17 90,000 40 PP) | ALTERATION INVESTED · any staff | "Command (1 AP) releases one stored spell using the check result rolled when it was stored; stored spells fade at your next daily preparation"; "The spell check is rolled when the spell is stored … expend their PP normally"; "no individual spell may exceed the maximum PP you can spend on a single cast" (M94, m197, amended) | The core's stored-spell machinery (`magic/spell-storing-workflow.mjs`, the Storing Rune's) with a capacity in PP per tier; release by Command; cleared at daily preparation (Q203) | — | B |
| **Summoner's Brand** (9893; L10 6,000) | INVESTED TRANSLOCATION · melee | "Whilst wielding this weapon you increase your control levels by 2 … +1-item bonus to all checks made against creatures with the Conjured trait or summoned by a Summons spell; your caster level is +1 for spells with the Summons trait. Finally, your caster level is considered to be one higher when using spells with either of those traits." (M95, amended; the last sentence repeats the clause before it) | Control levels +2 (C12, through H21); the +1 item conditional against such creatures; caster level +1 on Summons spells (`registerCastCapModifier`, and read by the Bindings' level limit) (Q204) | H21 | A |
| **Tether** (9905; L12 11,000) | INVESTED SAVE WARDING · melee | "once per round after a successful strike … tether them for 1 round. While tethered, if the target attempts to teleport, shift planes, or otherwise use an effect with the translocation trait, they must succeed at a Will save (your Level DC) or the effect fails"; fumble "DC 15 flat check or become immobilised until the beginning of your next turn" | A Tethered effect for 1 round; a `registerCastRefusal`-style gate on that creature's Translocation casts and teleports (Will save first); the fumble (H22) | H22 | A |
| **Veilstorm** (9921; L8 3,000) | FORCE INVESTED INVOCATION · melee | "once per round after a successful strike … 1d6 force damage to all creatures adjacent to the target (basic Reflex, your level DC). The wielder is immune"; fumble "blinded until the end of your next turn" (m198, amended) | `runAreaEffect` on the target's neighbours, basic Reflex at your Level DC; the fumble (H22) | H22 | A |
| **Warpflare** (9937; L9 4,300) | ALTERATION INVESTED RARE · any weapon | "On a successful hit, roll a d6: 1–4 normal; 5 … 2d6 secondary force damage; 6 … wild magic (GM rolls on the Wild Surge table, treating the wielder as the source). When attacking within 30 feet of a ley line, add +1 to the roll" (m199, amended) | A d6 on each hit (+1 near a ley line); 5 secondary force; 6 a surge from the wielder (the area level is Q205) | — | A |

#### 3.2.10 Specific weapons (4)

| Weapon (line) | Level · price | Base (core) and printed stats | Traits (as printed) | Notes | Grade |
|---|---|---|---|---|---|
| **Bleeding Crown** (9961) | 9 · 5,920 (✓) | Battle Axe (core 1d8 S, AR 1, FDC 18); "AB +2; Damage 1d8+1 S (M96, amended); Size M; FDC 1**8**" | AR 2, Hand & a Half, Sweep, Expert, Potency II, Sanguine | Its own drawback still reads the old "If you go three rounds without striking a foe, you begin to bleed for 1d6", unlike the rune's v1.6 text (M93) (Q206) | A |
| **Soulrend** (9983) | 14 · 26,013 (✓) | Bardiche (core 1d12 S, L, FDC 20, **Clumsy**, Reach, Versatile P); "AB +3; 1d12+2 S; L; FDC 20" | Reach, Versatile P, Master, Potency III, Aetherfang, Essencebreaker (m200: Clumsy removed on purpose) | Its Essencebreaker line has no DC ("must succeed at a Will save"); the rune now says "your level DC" (Q206) | A |
| **Ritualists Edge** (10007) | **11** · 7,602 | Dagger (core 1d4 P, T, FDC 5); "AB +2; 1d4+1 P; T; FDC 5" | Agile, Finesse, Thrown 10 ft, Versatile S, Expert, Potency II, Summoner's Brand | **The second control-level weapon.** Its text still says "either the Summoned or Conjured trait" (M95 not applied here). m201: 7,602 gp is a level-10 price, and the level is still printed as 11. No apostrophe in the name (Q204) | A |
| **Starfall** (10027) | 14 · 31,200 (✓) | Tel'dorin (core 1d10 S, **L**, FDC 8, Deadly, Elf, Exotic, Finesse); "AB +3; 1d10+2 S; Size L (m202, amended); FDC 8" | AR 3, Deadly, Elf, Exotic, Finesse, Master, Potency III, Chrono | AR 3 from a base AR 0: no listed trait explains it. Built as printed. | B (Chrono) |

## 4. One model per family

### 4.1 Catalysts (H19)

**The item.** A catalyst is a `consumable` with `flags.trg-prime.catalyst = { key, applies, effect, backlash }`, its level, price and rarity as printed, and its own text as its description. `applies` says which casts it is offered on:
- a tradition (Arcanite, Myrrh, Sap, Whisperglass), where High Magic counts as every tradition;
- a spell trait (essence or fire; illusion or enchantment; healing);
- "damaging", "attack" or "ritual";
- any cast.

**At the cast.** H19 lists each owned catalyst whose `applies` passes as one radio choice on the Casting Conditions prompt ("No catalyst" by default; one per spell, L5230). An embedded catalyst on a wielded Catalyst-rune shield is listed too, if today's use is unspent (Q192). It is offered on any cast that rolls a Spellcraft check (Q186): an innate cast with no check, or a scroll, is not offered one.

**What it changes**, in the cast's own vocabulary:
- **the casting check:** `advantage` (Arcanite, Myrrh, Sap, Whisperglass, Incense), a modifier (+1 Spell Incense, +2 Leydust, +2 Vellum in a ritual), or the spell attack (+2 Bead);
- **the Save DC:** +2 (Moonveil);
- **the payment:** −1 PP, minimum 1 (Shard, Q189);
- **the turn:** +1 AP (Sands);
- **range or duration:** ×1.5 (Starpetal);
- **damage:**
  - +1 die of the spell's own (Dragonbone, Grave Soil);
  - one die step (Cinders, Q188);
  - extra dice per PP or per 2 PP (Dewdrop, Glimmercoal, Stormglass), resolved per M18;
  - the damage type becomes cold or essence (Marrow, Void Ash);
  - resistance ignored (Lotus, Dewdrop);
- **healing:** +1d6 per PP (Phoenix);
- **a caster effect:** Marrow's +1 DR until the end of your next turn;
- **a card flag:** Eclipse Resin's disadvantage to identify.

**Consumption.** A catalyst is spent at the cast (L5222), with three exceptions, applied in this order:
1. Catalyst Conservation's DC 15 flat check (the catalyst is kept on a success, unless the cast fumbles or blunders);
2. the Rod of the Catalyst Flow's 2 PP (Q209);
3. an embedded catalyst is not consumed, only its daily use is marked (Q192).

**Backlash.** On `trgPrimeSpellSettled`, if the casting check's degree was Failure, Fumble or Blunder (Dragonbone: Fumble or Blunder only, M10), the backlash is applied to the caster. Before it:
- Catalyst Mastery removes a Failure's backlash;
- Catalyst Affinity reduces HP damage and round durations (Q191).

Damage is typed and applied with no save. Conditions use `applyConditionTags`, and checks penalties are timed effects.

### 4.2 Materials (H20)

The core's material properties are read by the item-quality and combat code by key. H20 lets a module register a material into the same lookup. The module registers the ten with the existing properties where one fits (weight, HP multiplier or percent, ACP and Max Dex, Speed penalty, silver, extra die, granted trait). The new properties are:
- hardness ×1.5 or ×2;
- an extra die or a flat bonus against a creature type or trait (Graveiron, Starion, Sunbronze, Veilglass);
- an item bonus to saves against effects with a trait or tag (Bloodglass, Graveiron, Starion, Sunbronze, Tairneach, Veilglass);
- CR against criticals of a damage type (Bloodwood, Sunbronze);
- a secondary die on a critical (Tairneach);
- AR against magical armour (Nightsteel);
- a Spellcraft bonus as a focus (Bloodwood);
- a light (Sunbronze shields);
- a Hide conditional by light level (Eversmoke);
- the shatter on destruction (Bloodglass).

`appliesTo` gains "cloak" and "robe" for Eversmoke, and charged items for Bloodwood's "staves, bows, and wands" (Q194). The level delta is added to the item's level as the core's materials are.

### 4.3 Runes, specific items, orbs, rods and staves

- **Runes** are registered with `registerRunes` (tiers, prices, usage). What each does is either a `declares` the core already reads (`bonuses`, `conditionals`, `action`, `afterStrike`, `onCritical`, `energy`, `strikeRider`) or one H21 adds. The module handles the few that are reactions or table rolls: Nullflow, Resonant Defiance, Veil, Wildbane, Warpflare, Riftcleaver, Tether and Spellhold. A rune counts only while its item is worn or wielded and invested (all 34 are INVESTED).
- **Specific items** are core `specificItem`s: the base from the core pack, quality, material (an H20 key), runes (H21 keys), and the printed statistics and text.
- **Orbs** are `chargedItem {kind: "orb"}`, read through H23 for level, price, max PP, cast options, recharge and depletion. The ORB trait's one-invested rule is H25.
- **Rods** use the core's `metamagic` and `ppSource` where those fit (Focused Spell I–III, Quickening II). The four others declare a module rod power (H24).
- **Staves** are core staves with their printed spells, and with their abilities as conditionals.

## 5. Module-side findings (no ruling needed unless noted)

- **No `ea-wondrous` pack.** v1.6 prints no wondrous item outside the relics (L10051–10059 introduce the relics). The architecture's planned pack is dropped, and the relics' pack is Block 10's question.
- **The Weaver's Delight is gone** from v1.6 (M89, with m188 and m189), so the staves are five, not the matrix's six. The matrix row is marked removed.
- **Renamed in v1.6:** the Quickbind rune is **Swiftbind** (m159, m163). Gravemeld Shirt still lists "Quickbind" among its traits, and Swiftbind's own sentence says "the Quickbind Rune". Both are read as Swiftbind, and the old name is an alias on the rune. (The Ch4 *action* Quickbind is a different thing and keeps its name.)
- **v1.6 lines that a ruling said were fixed, or that are still as before** (built as v1.6 prints, with the ruling's reading; listed for the book):
  - Dragonbone Dust's entry says "Adds +1 damage." while its table row says "+1 damage die" (**M10: +1 damage die**);
  - Glimmercoal, Spell Incense and Verdant Sap still carry m70's three typos;
  - Blood-etched Vellum's table row has no "(max 10)" (m71);
  - Starion's bullets say "star-iron" and "Stariron" (m61);
  - Gravemeld Shirt's "Grave Iron" (m165);
  - Whispering Hollow's text still has the old Comfort wording ("fatigue checks"), and its stats omit Comfort's Max Dex +1 (m168, part);
  - Verdant Heart's "Power Points 39" still runs on the Spells line (m178);
  - Rod of Focused Spell's "focused spell Metamagic feat" (m179);
  - Tesra'Anvir's "from the rod" (m185) and its name's form (m187);
  - Ritualists Edge's level 11 at a level-10 price (m201), "Summoned or Conjured" (M95), and no apostrophe;
  - Bleeding Crown's FDC "1**8**" (M96) and its old drawback (M93);
  - Soulrend's Essencebreaker line has no DC (m192);
  - Summoner's Brand prints its caster-level clause twice;
  - "Orbs follow the charged item rules for Staves the Core Rulebook" is missing "in".
- **Orb, rod and staff prices all check** against the core's ladders (§3.2.6–3.2.8). The two exceptions are already ruled: Tesra'Anvir (m186) and Verdant Heart's level (m174, Q207).
- **Every spell an orb or staff names exists** in the core or in `ea-spells` (checked by script, 32 names).
- **Catalysts and the cast's card.** The chosen catalyst, its effect and its fate (spent, kept by Conservation, kept by the rod, or an embedded use marked) go on the cast's card, and the backlash goes on the settled card.
- **Riftcleaver teleports**, so the core's teleportation rule applies to each use: a Spatial Awareness check, and a second teleport in a turn fails (rulebook L31374; `helpers.teleportationArrives`). The rune prints the TELEPORTATION trait, so this is the rule, not a choice. Its fumble's random move teleports too.
- **The extractor.** Chapter 9's headings are plain capitals with bold trait lines. `extract-book.mjs` cuts the Grimoire and the gear, but no `book.magicItems` section exists yet. A `magicItems` cutter is added, with its own verifier, to the extractor's mutate pair (so `verify-book-extract` covers it). It records each entry's line and attaches its sidebar tiers.
- **Starfall's AR 3** has no source in its listed traits (Tel'dorin has no AR). Built as printed.
- **Spellguard's +1** (its own line) against Resonant Defiance I's +2: M79 says leave as printed, so the specific shield applies +1. An inscribed Resonant Defiance I applies +2.

## 6. Proposed core seams (TRG Prime, for Graham's approval)

Block 8's seams were H12–H18 (3.686.0 and 3.687.0), so these continue at **H19**. As before, each is prepared separately, additive and default-off: a spell, item or module that does not use it behaves exactly as now. Each has its own `verify`/`mutate` pair.

| # | Seam | Core file / function | Used by | Sub-block |
|---|---|---|---|---|
| **H19** | **Catalysts: a cast item option** (D3). `registerCastItemOption(kind, { list(ctx), apply(ctx), keep(ctx), onSettled(ctx) })`. `list` returns the owned or embedded items offered, as one exclusive group on the Casting Conditions prompt. `apply` answers what the cast's vocabulary already has (`castingDC`, `saveDC`, `attack`, `ap`) plus `advantage: true` on the casting check, `ppReduction` (payment only, Q93) and `mods` in the warp-mods vocabulary (`damageDice`, `secondaryDice` with a type, `healDice`, a die step, `damageType`, `ignoreResistance`, range or duration ×). `keep` decides consumption. `onSettled` gets the degree, for backlash. The item is consumed by the core, whatever the degree, unless `keep` says otherwise. The gate's existing `disadvantage` gains its mirror `advantage`. | `magic/cast-options.mjs`, `magic/cast-workflow.mjs` (the prompt, the check's bias, the damage and heal resolution), `module-api.mjs` | 24 catalysts, the 4 feats, Catalyst rune, Rod of the Catalyst Flow | 9a |
| **H20** | **Module materials** (D18). `registerMaterial(key, spec)` into the lookup every `MATERIALS[...]` reader uses (one accessor, `materialOf(key)`). It adds the new properties in §4.2: hardness %, damage or extra die against a type or trait, item saves against a trait or tag, CR by damage type, critical secondary, AR against magical armour, focus Spellcraft bonus, light, a Hide conditional, the destruction shatter, and `appliesTo` for cloaks, robes and charged items. Core materials are untouched and win a key clash. | `item-quality.mjs` (L171, L337–L793), `defences.mjs`, `combat/attack.mjs`, `combat/damage-workflow.mjs`, `codex-runes.mjs`, `sheets/item-sheet.mjs` | 10 materials; Gravemeld Shirt, Shadeskin, Whispering Hollow | 9a |
| **H21** | **Rune declarations, Block 9's set.** `rune-declarations.mjs` reads the following new keys, while the rune's item is worn or wielded and invested: `controlLevelBonus` (into C12's sum); `spellAdder { value, traits?, casterTraditions? }`, and the same scoped shape on an item flag (Emberlight's fire-only adder, Tesra'Anvir's), into `spellAdderSources`; `resistances [types]`; `maxDexBonus`; `donAP {light, medium, heavy, fullExtra}`; `armourCastingPenalty: 0`; `criticalRollModifier { value, exceptUM: [66, 100] }`; `uncoveredDR { share }` read by hit location; `dailyRepair { perLevel }` on daily preparation; `catalystSlots`; and a control-overflow save modifier (Binding Sigils, into H12's sweep). | `rune-declarations.mjs`, `magic/casting.mjs` (C12, L421), `magic/spell-adder.mjs` (L60), `combat/hit-location.mjs`, `donning.mjs`, `magic/casting-dc.mjs` (the armour penalty), `combat/attack-workflow.mjs` (the critical roll), `magic/control-register-workflow.mjs` | 18 armour and shield runes; Summoner's Brand; Arcanum Seal; Emberlight; Tesra'Anvir | 9b |
| **H22** | **The strike's die and fumble for modules.** `trgPrimeStrikeResolved` also carries `natural` (the unmodified d20), `fumble` (the weapon fumble's degree, or null) and `damageDealt`, so a rune can answer a natural 20 or a fumble. And a weapon-fumble hook, `trgPrimeWeaponFumble`, fired when a fumble is rolled whether or not the strike resolves. | `combat/attack-workflow.mjs` (L3005, L3942), the fumble branch | Aetherfang, Leybound, Pyrebrand, Riftcleaver, Sanguine, Tether, Veilstorm; Bleeding Crown, Soulrend, Starfall | 9b |
| **H23** | **The Orb kind** (D12's item half). `registerChargedKind(key, { level(flag), price(level), maxPP(level), castOptions(ctx), naturalRecharge: false, rechargeCost: { gpPerPP, minutesPerPP, rechargeItemPP }, depletionRow(roll) })`, consulted before the core's own kind branches. For the orb: Spellcraft Hard (+2, stacking with High Magic's, M81) with caster level covering the PP and no tradition; skill Very Hard (+5) with rank ≥ PP and Use Magic Device (High Magic: Arcana or your own tradition's skill, M80); 41–65 depletes the orb to 0 PP and calls the module (the flare) instead of breaking it. And a conditional `when.itemPPAtLeast` so an item's abilities stop at 2 PP or less. | `charged-items.mjs` (L35, L179–L360), `charged-items-workflow.mjs`, `magic-items.mjs` (the depletion table), `recharge-item.mjs`, `conditionals.mjs` | 5 orbs | 9c |
| **H24** | **Module rod powers.** `registerRodPower(key, { applies(ctx), cost, apply(ctx) })`: a held rod whose `chargedItem.rodPower.key` is registered is offered on the Casting Conditions prompt. When taken, its PP are spent through `chargedItemSpend` (so D12's cost rules and Charge Depletion apply), and `apply` answers in H19's vocabulary (`castingDC`, `saveDCTargets` for several targets) or acts after the cast. `ppSource` gains `tradition: "any"` and a `rate(ctx)` (Ley Resonance's 2 near a ley line). | `rod-powers.mjs`, `charged-items-workflow.mjs`, `magic/cast-options.mjs` | Binding Seal, Soul's Echo, Wild Surges, Catalyst Flow, Ley Resonance | 9c |
| **H25** | **One invested item per trait.** `registerTraits` may mark a trait `oneInvested: true`; `investRefusal` (`magic-items-workflow.mjs` L27) applies it as it applies the Staff trait's rule (`trait-rules.mjs` L223). | `trait-rules.mjs`, `magic-items-workflow.mjs`, `module-api.mjs` | ORB (9c); RELIC and SENTIENT (Block 10) | 9c |

**To be confirmed in the build** (seams only if the check fails):
- a cast's damage can ignore resistance (Ashen Lotus, Dewdrop, Aetherfang's physical bypass);
- `restricted-ap.mjs` can restrict a point to the attack trait (Chrono);
- `donning.mjs` reads a per-item time (Swiftbind);
- the core's identify-spell checks can read a flag on the cast (Eclipse Resin);
- the effect suppression can suppress one named spell effect on one creature for a time (Nullflare, Nullflow);
- `saveDCTarget` takes several targets (Soul's Echo), or H24 adds it;
- a resistance can be suppressed by a timed effect (Essencebreaker).

## 7. Rulings that already settle Block 9 points

| Ruling | Settles |
|---|---|
| **C6** (Catalyst rune amended) | The rune's four tiers hold 1, 2, 3 and 4 catalysts, each "used once per day" |
| **M10** | Dragonbone Dust: +1 damage die; backlash on a Fumble or Blunder only |
| **M18** (as proposed) | Catalyst damage: an attack spell's rides the attack; a save spell's uses its save; any other spell's is basic Reflex |
| **R1–R5, R18, M79** "leave as printed" | Catalyst Affinity's −2 per level (R2); Ashen Lotus and Void Ash (R3); Tesra'Anvir's quicken with no limit (R18); Spellguard's +1 (M79) |
| **M77, M80–M88, M90–M96, m159–m164, m169–m177, m180–m184, m190–m199, m202** (amended in v1.6) | Each item's v1.6 text, as in §3: Nullflow's counteract; the orb rules; Shattered Veils' Leyline Burst; Ley Resonance's rod PP; Wild Surges' area level; Staff of Flame's Orb of Fire; Chrono's ending; "recurring"; Leybound's surge; Sanguine's drawback; Spellhold's release; Summoner's Brand's wording; Bleeding Crown's S; the armour runes' wording; the orbs' prices; the rods' and staves' fixes; the weapon runes' DCs and types; Starfall's Size L |
| **M89, m188, m189** | The Weaver's Delight is removed |
| **M78** ("incorporeal is explained in Fiends & Fables") | Veil's incorporeal is the core and F&F trait (`appendix-traits.mjs`) |
| **m186** ("the staff's other abilities are costed as wondrous items") | Tesra'Anvir's level 18 and 180,000 gp |
| **m200** ("clumsy was removed on purpose") | Soulrend has no Clumsy |
| **m207** ("the scaling guidelines are there") | Rune and item scaling is as printed |
| **R17** (amended: "equal or exceed") | Orbs' skill path |
| **C3** (no DC printed: the target's Level DC, or the caster's own) | The default where an item prints no DC (Q201 asks whether weapon runes follow their siblings instead) |
| **M40** (persistent = recurring) | Any remaining "persistent" damage |
| **m42, m128** | Nullflare's missing rungs (Critical, Success and Partial: no effect); rounding down |
| **C12** (Block 5, built 3.683.0) | Control levels +2 from an equipped item |
| **G1** (Block 6, built 3.684.0) | The Rods of Focused Spell through `moduleMetamagicRodsOf` |
| **Q93** | The precedent for a PP reduction being payment only (Q189) |
| **R12** (core block 36) | Quickening: a 1 AP spell is not quickened, so Rod of Quickening II offers only 2 AP spells |
| **Appendix HIGHMAGIC** (L10726): "count as belonging to all traditions simultaneously" | Arcanite, Myrrh, Sap and Whisperglass apply to High Magic spells |

## 8. Rulings needed

Ordered by sub-block. Each quotes v1.6. Only points that change play are asked.

| # | Question | Proposed |
|---|---|---|
| **Q185** | **One release or three.** Block 9 is 100 items, seven core seams and three machineries: the cast, runes and charged items (§1.2). | **Three:** 9a catalysts, catalyst feats and materials (3.688.0, EA 0.13.0); 9b runes and specific items (3.689.0, 0.14.0); 9c orbs, rods and staves (3.690.0, 0.15.0). Each gets its own harness, sweep, review and live test. |
| **Q186** | **How a catalyst is used.** "A catalyst may be invoked when declaring a spell, before the Spellcraft check is rolled." Nothing says whether it costs an action, must be in hand, or applies to a cast with no Spellcraft check (an innate spell, a scroll, a charged item's skill path). | **No action and no hand:** an owned catalyst is chosen on the cast's prompt. It is offered on any cast that rolls a **Spellcraft** check: ordinary, ritual (the primary's) and a charged item's Spellcraft path. It is not offered on an innate spell with no check, a scroll, or a charged item's tradition-skill path. A catalyst whose effect cannot apply to the spell (Bead on a non-attack, Ashen Lotus on a spell without essence or fire) is not offered. |
| **Q187** | **"Per PP" and what counts as catalyst damage.** "1d6 secondary essence damage per spell PP" (Dewdrop); "+1d6 HP per PP" (Phoenix); backlash "per 2 PP of the spell". And L5220's "damage effects caused by catalysts" (M18). | **PP is the PP as cast** (base + warps + metamagic), as the cast's DC reads it. **Catalyst damage** under M18 is the dice a catalyst adds of its own (Dewdrop, Glimmercoal, Stormglass). Dragonbone, Grave Soil and Cinders change the spell's own dice, so they resolve with the spell's damage. Marrow and Void Ash change its type. A spell with no damage gets nothing from a damage catalyst. |
| **Q188** | **Cinders' die step at the top.** "Increases the spell's damage die by one step (d6 → d8, etc.)". What does a d12 step to, and does a flat-damage spell get anything? | **d4 → d6 → d8 → d10 → d12**; a d12 stays a d12 (no further step is printed). Every damage die of the spell steps. A spell with no damage die gets nothing. |
| **Q189** | **Resonant Crystal Shard's −1 PP.** "Reduces the spell's PP cost by 1 (minimum 1)". | **Payment only**, as Q93: you pay 1 PP less; the casting DC, Save DC and cap read the PP as cast. A 0 PP spell is not offered it. |
| **Q190** | **Starpetal Oil's backlash.** "On failure, the spell misfires, applying its effect at half strength to the caster instead of the target." A failed spell normally does nothing. | **On a Failure, Fumble or Blunder the spell takes effect on you instead:** damage and healing halved (rounded down, m128), durations halved, any save yours at the cast's Save DC. Built as a card with the halved damage rolled (C). |
| **Q191** | **Catalyst Affinity.** "reduce damage taken by 2 per character level, and reduce condition durations (such as stunned, dazed, slowed) by 1 round (minimum 1)". Stormglass's backlash is "Stunned 3", a value, not a duration. Ashen Lotus and Void Ash give Soul Drain, which is not damage. | **HP damage** from a backlash is reduced (minimum 0). Soul Drain is not. **Durations in rounds** lose 1 (minimum 1); durations in minutes or hours are unchanged. **Stunned 3 becomes Stunned 2**, the feat's own example, since stunned is counted in actions rather than rounds. |
| **Q192** | **The Catalyst rune.** "You can imbed an amount of catalysts … Once imbedded into the item, each catalyst may be used once per day." How is one embedded, can it be swapped, must the shield be raised or only wielded, and does an embedded catalyst's backlash still apply? | **Embedding** is a 10-minute Interact with the catalyst and the shield (as investing), and swapping one out destroys it. Each embedded catalyst is **offered once per day while the shield is wielded** (not necessarily raised), **is not consumed**, and its **backlash applies** as normal. Catalyst Conservation and the Rod of the Catalyst Flow do not apply to an embedded catalyst (it is not expended). |
| **Q193** | **Armour "penalties" with materials.** Ashbone armour "reduces all penalties by 1 and increases the wearer's maximum Dexterity bonus by the same". Eversmoke and Nightsteel "reduce Stealth penalties by 2 (to a minimum of 0)". The core's armour has an armour check penalty (ACP, all Dexterity- and Strength-based skills) and a Speed penalty, and no Stealth penalty of its own. | **Ashbone:** ACP −1, Speed penalty −5 (as your Dragonhide ruling: speed in fives), Max Dex +1. **Eversmoke and Nightsteel:** the ACP is reduced by 2 for **Stealth checks only** (minimum 0). |
| **Q194** | **Material and rune details the core has no term for.** Bloodwood: "weapons and implements gain the Keen trait". Sunbronze shields "can use their full CR against fire effects" (core shields have no CR). Nightsteel: "AR 2 against magical armour and magical armour effects (such as Mage Armour)". Veilglass: "+2 … against planar, teleportation, and possession effects" ("planar" and "possession" are not traits). Bloodglass: "shatter violently when destroyed, dealing 1d6 piercing damage … to all creatures within 5 ft" (no save). Ley Binding: "a bonus to DB" (no type). | **Implements:** staves and wands, but Keen applies to Strikes only (a staff struck with). **Sunbronze shields:** the wielder's armour CR (if the optional Armour Grants CR rule is on) applies in full against fire criticals. **Nightsteel:** AR 2 against an armour with a potency rune, and against a spell's DR (Mage Armour). **Veilglass:** saves against Teleportation- or Translocation-trait effects, and a GM tick for planar and possession effects. **Bloodglass:** basic Reflex at the item's Level DC (C3's sibling: no DC printed). **Ley Binding:** a circumstance bonus, as you made Wildbane's. |
| **Q195** | **Nullflow's counteract check.** "Make a counteract check (rune level as counteract level)". The core: "Use your Cast a Spell result or any other skill check which is appropriate … modified by +/-2 for each level or PP difference". Who rolls, with what? And "targeted by a spell": does an area spell target you? | **The wearer rolls Dispel (Power Manipulation)**, ±2 per difference between the rune's level and the spell's PP, against the spell's casting DC. It uses the wearer's reaction and a daily use. **Area spells count** when the wearer is inside the area. On a success, the spell's effects on the wearer are suppressed for 1 minute (damage from the cast is not taken), then any remaining duration resumes. |
| **Q196** | **Veil (and Shadeskin).** "you may become incorporeal … you may only make move actions and actions with the defend trait." No duration is printed. The core trait is DEFENCE. "Less than 25% hits". | **Until the end of your next turn**, or until you end it as a free action. "Move actions" are actions with the Move trait; "the defend trait" is **Defence**. "25% hits" is 25% of your maximum HP. The Incorporeal trait applies in full (M78). |
| **Q197** | **Bound Circle and Binding Sigils' targets.** "attacks made by either conjured or summoned creatures"; "summoned or bound creatures under your control suffer a penalty on Will saves made to resist or escape your commands". | **Conjured** = the Conjured trait; **summoned or bound** = a creature recorded in a control register (Block 8's Bindings, Army of the Grave, the core's conjures). Binding Sigils' penalty applies to the **control-overflow DC 20 Will save** (core p242) and to the Bindings' Will save when a bound creature is commanded against its nature (GM). |
| **Q198** | **Resonant Defiance's reaction.** "Requirement your shield is raised … Reaction; Trigger an enemy within 30 feet casts a spell." No frequency is printed. | **Once per trigger**, using your reaction (so at most once a round). It raises that cast's casting DC as a labelled part (so a fumble is likelier), not its Save DC. |
| **Q199** | **Transcendent and High Magic.** "This rune negates the penalty for casting spells whilst wearing armour." High Magic's armour penalty is the armour's DR × 4 (your Q3). | **It negates both**: the core's armour penalty and High Magic's DR × 4. |
| **Q200** | **Chrono (and Starfall).** "You gain the quickened condition which may only be used to make an action with the attack trait"; "At the end of each turn that you use this rune; you must make an Exhaustion check. Each consecutive round, the difficulty … increases by one step"; it ends when you are fatigued (M90). Nothing says how long it runs once activated, whether you can end it, or when its AP arrive. | **It runs until you end it (free) or become fatigued.** The core's quickened grants its extra AP at the start of your turn, so activating on your turn gives the AP from your **next** turn. The **first** check is Easy; each consecutive turn it is still running is one step harder; ending it resets the step. |
| **Q201** | **Weapon-rune DCs and choices left open.** Aetherfang's "(basic Fort)" on a critical and on a fumble, Mindpiercer's "(basic Will)" and Pyrebrand's "(basic Reflex)" print no DC. Nullflare, Tether, Essencebreaker and Veilstorm print "your level DC". C3 would give a creature's own Level DC when it is targeted. Essencebreaker: who picks the resistance? | **The wielder's Level DC** for every weapon rune, as the section's own rows say. A drawback on the wielder uses the wielder's Level DC (C3). **Essencebreaker:** the wielder picks the resistance. |
| **Q202** | **"Bleed damage".** Sanguine: "1 bleed damage in addition to the strike. On a natural 20 … 1d4 bleed damage"; its drawback "you gain bleeding 1d6". Blood-etched Vellum: "1 bleed damage per PP of the spell (max 10)". The core's bleeding is a recurring condition, which Serrated raises by 1. | **"n bleed damage" = the bleeding condition at n** (recurring, the core's), so Serrated adds 1 and the core's bleed ends it. "Bleeding 1d6" is bleeding at the rolled value. Vellum: bleeding at the PP as cast, maximum 10. |
| **Q203** | **Spellhold.** "store spells within the staff by casting them into it ahead of time … The spell check is rolled when the spell is stored"; "Command (1 AP) releases one stored spell using the check result rolled when it was stored". Usage "any staff". Who may release, are targets chosen at release, and which Save DC? | **"Any staff"** is the core Staff weapon and any charged staff. Storing takes the spell's own AP. Only the investor releases. Targets and areas are chosen **at release**. The Save DC, and the attack if any, are those of the stored check. A spell whose check failed is not stored, and its PP are spent by degree as normal. |
| **Q204** | **Summoner's Brand and Ritualists Edge.** "your caster level is +1 for spells with the Summons trait. Finally, your caster level is considered to be one higher when using spells with either of those traits." Ritualists Edge still says "the Summoned or Conjured trait", and its level is 11 at a level-10 price (7,602 gp). | **One +1, not two** (the sentence is printed twice). It raises your maximum PP per cast by 1 for a Summons spell (so one more warp) and anything else that reads caster level for it. **Ritualists Edge reads as the rune** (M95), and is **level 10** (m201) with the name **Ritualist's Edge**. The control levels are +2 whilst it is wielded (equipped) and invested; two such weapons add +2 each (C12's "summed as declared"). |
| **Q205** | **Warpflare's surge.** "6: The strike triggers wild magic (GM rolls on the Wild Surge table, treating the wielder as the source)." The table needs an area level. Rod of Wild Surges uses "the spell's PP", Leybound "ley line level", and the Resonant Flare "the orbs level". | **Area level = the rune's level (9)**, centred on the wielder, as Leybound and the flare name their source's level. |
| **Q206** | **Specific items whose text and runes disagree.** Bleeding Crown's drawback is the old "If you go three rounds without striking a foe, you begin to bleed for 1d6" against Sanguine's v1.6 "During an encounter … three consecutive rounds". Soulrend's Essencebreaker line has no DC. Whispering Hollow says "fatigue checks", and Comfort's Max Dex +1 is not in its stats. Gravemeld lists "Grave Iron" and "Quickbind". | **Each specific item's statistics are built as printed. Its rune lines use the rune's v1.6 text** (Sanguine's encounter drawback; Essencebreaker's "your level DC"; Comfort's Sleeping in Armour save and Max Dex +1; Graveiron; Swiftbind). The exception is where you ruled "leave": Spellguard's +1 (M79). |
| **Q207** | **Orb of the Verdant Heart's level, and orb abilities.** The rule (L9315) gives 10 + 2 = **12**; it prints **13** (its PP 39 and price 25,000 gp are consistent with 13). "an item bonus to checks made when interacting with ley lines (such as locating, tapping, or manipulating them)". | **Level 13, as printed**, with its PP and price: the book's three figures agree with each other, and the extra level reads as the cost of its Critical-Tap ability, as m186 ruled for a staff's abilities. If you prefer the rule, it is level 12, 36 PP and 16,250 gp. **Ley-line checks** are Ley Sense, Tap Ley Line, Channel Ley Line and the Power Manipulation check against Leyline Anchor. The bonus applies while the orb is **held**, whatever its PP. The "at least 3 PP" abilities stop at 2 PP or less. |
| **Q208** | **Rod of the Binding Seal.** "When casting a spell with the Summons trait, you may draw a PP from this rod to reduce the casting DC by 1." Once, or more PP for more? | **Once per cast:** 1 PP, −1. |
| **Q209** | **Rod of the Catalyst Flow with Catalyst Conservation.** "expend 2 PP from this rod to prevent it from being expended". Conservation: "On a fumble or blunder … the catalyst is always consumed". | **Conservation's flat check first; the rod is offered only if that fails** (or you lack the feat). The rod's 2 PP keep the catalyst **even on a Fumble or Blunder**, since the rod prints no exception. |
| **Q210** | **Orbs' tradition-skill path and "Orbs follow the charged item rules for Staves".** A staff in the core may be warped up to the item's level from its own pool. Do orbs warp? | **Yes, as staves:** a spell from an orb may be warped from the orb's PP, up to the orb's level. |

## 9. Summary

**Grades (100 items), with the seams:**

| Family | A | B | C | D |
|---|---|---|---|---|
| Catalysts (24) | 22 | 2 | 0 | 0 |
| Catalyst feats (4) | 3 | 1 | 0 | 0 |
| Special materials (10) | 4 | 6 | 0 | 0 |
| Armour and shield runes (18) | 14 | 4 | 0 | 0 |
| Specific armour (5) | 3 | 2 | 0 | 0 |
| Orbs (5) | 5 | 0 | 0 | 0 |
| Rods (9) | 9 | 0 | 0 | 0 |
| Staves (5) | 5 | 0 | 0 | 0 |
| Weapon runes (16) | 10 | 6 | 0 | 0 |
| Specific weapons (4) | 3 | 1 | 0 | 0 |
| **Total** | **78** | **22** | **0** | **0** |

Eclipse Resin is B: whether the identify checks can read it is confirmed in the build. Starpetal Oil's backlash is a card (C) inside a B item.

**Without the seams:**
- the catalysts become cards and the four feats stay D (H19);
- the materials can be named but not applied (H20);
- twelve armour runes, Summoner's Brand and the scoped Spell Adders become cards (H21);
- seven weapon runes lose their natural-20 and fumble clauses (H22);
- orbs read as staves (wrong level, price, PP, DCs and recharge) (H23);
- four rods become cards (H24);
- the ORB trait's one-invested rule is a card (H25).

The honest part:
- Nothing in Block 9 is descriptive only. The B grades are reactions, choices or table rolls that a player or the GM makes in play.
- Four clauses are cards by the book's own wording: Starpetal's misfire, Mindpiercer's "GM discretion", Echoing's whispers, Staff of Flame's lighting.
- The planar and possession half of Veilglass is a GM tick.

**Core seams for approval (7):**
- H19 catalysts as a cast item option (D3);
- H20 module materials (D18);
- H21 rune declarations, Block 9's set (with scoped Spell Adders and the control-level bonus from a rune);
- H22 the strike's natural die and fumble for modules;
- H23 the Orb kind (D12);
- H24 module rod powers;
- H25 one invested item per trait.

**Questions (26, Q185–Q210).** The ones that change play most:
- **Q186**, how a catalyst is used;
- **Q187**, "per PP" and catalyst damage;
- **Q192**, the Catalyst rune;
- **Q193** and **Q194**, the materials' terms;
- **Q195**, Nullflow;
- **Q200**, Chrono;
- **Q202**, bleed;
- **Q204**, Summoner's Brand's caster level.

**Module findings:**
- no wondrous items outside the relics;
- the Weaver's Delight is gone;
- Quickbind is Swiftbind;
- fourteen v1.6 passages are still as they were, or disagree with a sibling;
- Riftcleaver carries the core's teleportation rule;
- the extractor needs a Chapter 9 cutter;
- the attached docx differs from 1 November's in two lines outside Block 9.

## 10. Plan

1. **Graham answers Q185–Q210** and approves H19–H25 (or a subset).
2. **Extractor:**
   - add a `magicItems` cutter (runes with their sidebar tiers, specific items, orbs, rods, staves, weapons) and a `gear.catalysts` and `gear.materials` check;
   - re-cut `book-text.json` from the attached docx;
   - re-verify Blocks 1–8.
3. **9a.**
   - TRG Prime 3.688.0: H19, H20, with their harness pairs, the full sweep and an independent review.
   - Eldritch Arts 0.13.0: `ea-consumables` (24), the four feats' automations, the ten materials; `verify-block9a` / `mutate-block9a`; the review.
   - Live test: casts with each kind of catalyst (advantage, a damage rider on an attack and on a save spell, a die step, a cost cut, +1 AP), Failure and Fumble backlashes with Affinity and Mastery, Conservation's flat check, and a Graveiron and a Veilglass weapon against an undead and an aberration.
4. **9b.**
   - TRG Prime 3.689.0: H21, H22.
   - Eldritch Arts 0.14.0: `ea-runes` (34), `ea-specific-items` (9); `verify-block9b` / `mutate-block9b`; the review.
   - Live test: inscribe and invest each rune family; Aegisflow on an uncovered limb; Astral Echoes on a critical; Veil's reaction; Nullflow against a cast; Chrono across three rounds; Riftcleaver's teleport and Spatial Awareness; Summoner's Brand's control levels with a Binding; Spellhold store and release.
5. **9c.**
   - TRG Prime 3.690.0: H23, H24, H25.
   - Eldritch Arts 0.15.0: `ea-charged-items` (19); `verify-block9c` / `mutate-block9c`; the review.
   - Live test: casting from an orb by Spellcraft and by skill, a High Magic spell from Shattered Veils, a forced 41–65 depletion (the flare), recharge at a ley line, the second orb refused, each module rod power, Ley Resonance near and away from a line.
6. **Then Block 10** (relics and the Relic Bonding Ritual), with H25's RELIC and SENTIENT, and the `ea-rules` journal proposed there.
