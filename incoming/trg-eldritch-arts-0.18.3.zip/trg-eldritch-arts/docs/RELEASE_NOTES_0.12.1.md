# Eldritch Arts 0.12.1

12 November 2026. **Needs TRG Prime 3.687.1.** This is **0.12.0 as live-tested, renumbered at Graham's request**, so it installs over the 0.12.0 builds he tested. The full notes are in `RELEASE_NOTES_0.12.0.md`, including both live tests' fixes.

## Since the second live test

**A failed cast's Save DC is TRG Prime's own:** 10 + the PP cast + the casting ability (`failedCastSaveDC`), unless the cast carries a Save DC itself.
- **Where it applies:** Storm of Unmaking's fumble storm, and Veilfracture's collapsing rift.
- **The fault:** both used the sheet's Spellcraft DC (10 + BSB + ability), which is not the Save DC.
  - Veilfracture's 10 PP fumble asked for DC 35 where its Save DC is 25.
  - The first live test's "fix" added the PP to that DC and gave 55 for a 20 PP storm whose cast used 35. Its revert was right only by chance: that wizard's BSB happened to equal the PP.
- **The review's reading,** 10 + PP + ability, was right. Its first implementation was not.

## Live tests

- **The first** (`LIVE_TEST_0.12.0.md`): 6 faults, all fixed in 0.12.0.
- **The second** (`LIVE_TEST_0.12.1.md`): the eight spells not yet run. Alter Corpse, Chaos Shield, Leyline Anchor, Veilfracture, Rite of Echoed Shadows, Call of the Ancestors, Essence Reforging and Veil Severing all work; the failed-cast DC above is the one fault.
- **Still to be tested live,** needing this build installed:
  - the first live test's fixes: Mimic Spell's Spellcraft and its offer, Rite of Binding Oath with its Partial's GM card, Soul Confluence with no target dialog, and the storm's turn start;
  - this DC.

## Checks

- **`verify-block8b`:** 358 checks, all green.
- **`mutate-block8b`:** 165 mutations at the last full run. This release replaces 2 of them with 6 for the failed-cast DC, making 169.
- **All 23 verifies:** green on TRG Prime 3.687.1.
- **The version bump (0.12.0 → 0.12.1, needing 3.687.1):** it is re-pinned in `module.json`, the entry script, 5 verifies and 10 mutates; those mutates were re-run on copies of the tree (see the session report).
