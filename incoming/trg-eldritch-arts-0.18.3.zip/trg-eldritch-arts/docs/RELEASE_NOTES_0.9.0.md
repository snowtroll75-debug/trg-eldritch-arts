# Eldritch Arts 0.9.0

4 November 2026. **Block 6:** Chapter 5's 23 archetypes and 97 class feats, and the module's own metamagic. That metamagic also finishes the five Block 5 feats that waited for it: Echo of the Ancestors, Resonant Pulse, Resonant Harmony, Spell Surge and Piercing Insight. Built from `ELDRITCH_ARTS_BLOCK6_AUDIT.md`, as Graham answered it on 4 November: "proposed except Q89: One release". The alternatives offered on Q90, Q98, Q110 and Q117 were not taken.

- **Install TRG Prime 3.684.0 first, then this over 0.8.0.** Block 6 needs that version's seams (G1–G26). On anything older the module warns.
- **No migration and no new settings. Loading a world changes nothing on any sheet.**
- **Spell Surge:** a copy already on a sheet from before 0.9.0 has no Focus trait, so its surges aren't limited. Delete it and add it again from "Eldritch Arts: Feats" to get its one Focus use (Q132). The module doesn't rewrite it for you, because that would change world data.
- **The feats are in "Eldritch Arts: Feats"**, which now holds all 237 of Chapter 5's feats. The archetypes' abilities are in "Eldritch Arts: Abilities": Foreseen Danger, Leyline Power, Fade Step, Counter Channel, Spellstrike Riposte and Magical Reservoir. Their spells are in "Eldritch Arts: Spells": Shard Cloud, Ley Walker and Storm Bolt (Burst).

## How it works at the table

- **Archetypes gate their class feats.** Each of the 23 is registered with the core, so a class feat traited "Eternal Vigil" is offered only to an Eternal Vigil. The book prints these traits hyphenated (ETERNAL-VIGIL); they are stored with spaces, and the card shows the print. High Mage and Birthrager also open the Sorcerer's (Adept) feats (Q100).
- **Progression** (Q90, Q91):
  - "+10 levels" means ten levels since you took the archetype, stamped on the feat when it's added.
  - Eternal Vigil, Runebreaker, Shade Master and Stormcaller allow no later archetype.
  - Leyline Weaver needs any one tradition skill at +10 ranks.
  - Archetypes taken before 0.9.0 carry no stamp, so they pass open.
- **One Pact ever** (Q92).
- **Module metamagic** appears in the Warp? dialog beside the core's. It counts toward the Casting DC and the max PP per cast, and is refunded by degree.
  - **Where it applies** (Q94): learned and innate casts. Charged items only through Metamagic Conduit. Never cantrips, scrolls, potions or stored spells.
  - **On an innate cast** its PP come from your pool (Q95).
  - **A Focus option's use** is spent only when the cast pays its PP (Q96).
- **The Warlock's pool** (Q97, Q98):
  - When you choose your Bonded Soul and the sheet names no tradition, you pick one of the soul's two traditions, so your pool is your Charisma.
  - Your spells never spend it. Warlock's Hex, Pact Channeler and anything any character may pay PP for (Dispel) do.
  - A Nyrinn Warlock's racial −1 PP a level applies, floored at 0.
- **Storing Rune now stores** a Rune Sorcerer's spell (TRG Prime 3.684.0's fix). Runebreaker can absorb a spell aimed at you alone (Q115).

## How much is automated

A: full · B: automated, with a normal choice or prompt · C: partly, one clause left to the GM and said on the card · D: the item and its card only.

| | A | B | C | D |
|---|---|---|---|---|
| Archetypes, part 1: the Pacts, Hex Weaver, Bloodmage, High Mage, Birthrager, Blood of the Wyrm (17) | 7 | 10 | 0 | 0 |
| Eternal Vigil, Fatespinner, Ferromancer, Leyline Weaver, Runeblade (19) | 6 | 12 | 1 | 0 |
| Runebreaker, Shade Master, Spellwarden, Spell Duellist, Spell Weaver, Stormcaller (24) | 8 | 13 | 3 | 0 |
| Runemage, Sorcerer and Spellblade class feats (19) | 8 | 10 | 1 | 0 |
| Metamagic and Adept class feats (20) | 4 | 12 | 4 | 0 |
| Warlock and Witch class feats (21) | 6 | 13 | 2 | 0 |
| **All 120** | **39** | **70** | **11** | **0** |
| *Block 5's five, finished here* | *0* | *4* | *1* | *0* |

**The eleven C feats, and the clause each leaves to the GM:**
- **Leyline Anchor:** "always within 30 ft" for Tap and Channel Ley Line. Block 2's line chooser reads only the map.
- **Absolute Denial, Eye of the Storm, Reflective Warding:** as the audit graded them; each card names its clause.
- **Magical Retribution:** "whilst casting" is automated only in the extra-casting-time window (Q149). Elsewhere it is a reaction button.
- **Spellthread, Mastery and Unbound:** the woven spell resolves as printed. Its warps aren't offered, and the shared concentration check is the GM's.
- **Versatile Binder:** waits for the Summons spells (Blocks 7–8).
- **Pact Ascendant:** the Demonic burst's Evil trait, Conjure Elemental's "your element only", and Essence healing under the Grave immunity.
- **Symbiotic Witch:** Q137's "total of 4 PP with warps" is checked on the base PP; a card warns the GM when warps took it over.
- **Piercing Insight** (from Block 5): the GM applies what each metamagic changes to the detection.

**Waiting on later blocks:**
- Dragon's Breath (Draconic Pact) and Elemental Strike (Elemental Pact) are Grimoire spells, Blocks 7–8. The chosen energy or element is stored now.
- Versatile Binder waits for the Summons spells, also Blocks 7–8.

## Readings to know about

Each of these is said on the feat's card.
- **Runeblade:** "Defending I" is left off until Graham names the rune (Q117). Bane is offered for the day's runes, but not for the Book of Infusions, which stores no creature kind.
- **Fate's Favour** is read literally (Q110): the conviction is refunded on a Partial or worse, on saves and skills, once a day. Inner Tempest's B5-3 is unchanged.
- **Runic Overload** (Q116): the released spell's Save DC rises by 2 and its Casting DC by 3, and it buys no warp. **Not yet:** per-PP riders on a stored release (a Pact's healing or fire per PP) don't see the +2. The core gives a stored release no PP shift.
- **Spell Weaver:** one Reservoir option a cast.
- **Wellspring Conduit:** it reads the spell's printed PP, because it is asked before warps are totalled. It is a tick, so its Focus use is never spent unasked.
- **Stormcaller:** Storm Bolt can cost 0 PP, as no minimum is printed.
- **Eye of the Storm:** "3 rounds" is the next three turn starts.
- **Runebreaker:** an absorbed spell is stored without its caster's warps.
- **Spellstrike Riposte:** the cantrip is chosen before the Strike and adds its damage only on a hit. Nothing is spent if the Strike is refused.
- **Echo of the Ancestors and Lightning Rod** need Elemental Spell's type to be ticked as well. Taken without it, the cast goes on with a line saying why nothing happened; the PP (and Echo's Focus use) are still paid.
- **Extra Bond, High Sorcery and Shadowed Grimoire:** their "once every N levels" limit is printed, not enforced.
- **Xithra Cone** doesn't offer the bonded soul's once-a-day power.
- **Call Bonded Weapon:** equips the weapon. The two-hand limit is checked only by the sheet.
- **Bonded Infusion:** a focus caster who hasn't ticked "Focus in hand" still takes the core's −2.
- **Foreseen Danger** can't be offered on the casting check of a spell that isn't an attack. The core asks reactions only of attacks, saves and skill checks.

## Found in review (two independent reviews, before release)

- **Absolute Denial, Counter Channel and Runebreaker** read an innate spell as 0 PP. So a monster's 10-PP innate spell would have been denied automatically. They read the PP as cast now (Q119).
- **Overflow Casting added its 5 Soul Drain on top of what you had,** twice: 4 became 13. It adds 5.
- **Eternal Vigil spent its daily use** when the cast was cancelled or refused. It spends it only on a real cast.
- **Sanguine Channel** is offered only when Bleed paid part of the cast (now B). **High Mage** refuses a Sorcerer.
- **Resonance Surge's free 2 PP of warps** reached rituals and item casts, and a stored release used up the armed surge. Both fixed.
- **A cancelled cast spent the Prepared Sigil.** It doesn't now.
- **Metamagic Adept's Flourish** is recorded now.
- **Steelbinding, Thunderclap Aura, Pact Channeler (Void) and Versatile Binder** rebuilt their save DC by hand. They use the cast's own now.
- **Piercing Insight** spends a Focus option's use, and leaves out discount-only options.
- **Dual Channel** rolled Charge Depletion twice in one case. It rolls once.
- **Spellwarden and Shadowmantle** counted saves that no spell forced. They count only spell saves now.
- **Hex Binders Curse** left a stale effect on an NPC its caster didn't own. The curse now lives on the curser.
- **Nothing is written at load:** Spell Surge's copies, Bonded Infusion and Xithra are no longer touched when a world opens.
- **Iron Ward** goes through the trait checks.
- **Draconic Infusion** now adds its claw damage: 1d6 of your dragon type, +1d6 a warp to 5d6. Blood of the Wyrm's +1 die rides on it.

## For Graham

- **Q99 for the Pacts:** a Witch's Pact spell (for example, Angelic Pact's Sanctuary) is an ordinary repertoire spell for her, not High Magic. Q99 was read as covering only the feats it names (Forbidden Lore, Pact Boon, Pact Ascendant). Say if a Witch's Pact spells are High Magic too.
- **Wellspring Conduit** reads the spell's printed PP. Q101 read "PP expended" as the PP cast for the Pacts. Say if Wellspring should match.

## Every feat, as built

The table below is generated from each group's own record (`AUTOMATION_B6_*` and `DEFERRED_B6_D` in `tools/content/`), the same text the harnesses check.

### Archetypes, part 1

| Feat | | What TRG Prime does |
|---|---|---|
| Angelic Pact | A | Sanctuary granted (Warlock innate Focus copy); +2 circ saves vs Fear/Soul (auto, tick); healingRider perPP 1 on Healing spells (G12, Q101); one Pact (Q92); +10 levels since taken (G8). |
| Demonic Pact | A | Burning Hands granted; +2 class Intimidate; spellDamageRider perPP 1 fire (G12, Q101); one Pact; G8. |
| Draconic Pact | B | Use picks the energy: resistance; a Critical spell-attack hit asks for the roar (one-shot advantage on Demoralise to end of next turn). Dragon's Breath waits for Blocks 7–8; one Pact; G8. |
| Elemental Pact | B | Use picks the element: mapped resistance; +1 per die on element-trait or mapped-type pools, never twice (C6, Q102). Elemental Strike waits for Blocks 7–8; one Pact; G8. |
| Fey Pact | A | Charm Kind granted; +2 class Deception and Diplomacy; spellDCBonus +1 mental (innate too); one Pact; G8. |
| Grave Pact | A | Dead Tongue granted; +2 class saves vs Soul (auto, tick); spellDCBonus +1 soul; one Pact; G8. |
| Void Pact | A | Dark Tendrils and Darkvision granted; senseRangeBonus +30 ft synced only when Darkvision comes from elsewhere (G13); a Critical+ save vs your spell gives +2 circ DB to the start of your next turn; one Pact; G8. |
| Hex Weaver | B | Familiar granted; hexes opened to Specialist Spell (Q103); Use picks an Ethereal/Verdant spell (base PP ≤ level + 1) added with the Highmagic trait; G8. |
| Bloodmage | B | Cast PP source (G2): up to total − 1 PP paid as Bleed, Bleeding = PP it paid; Fumble +1 per 2 PP, Blunder +1 per PP on a cast that drew Bleed (Q105); Bloodmage hexes opened (Q21); prereq stored Con +2, Level 2; G8. |
| High Mage | B | Non-Sorcerer eligibility (G9); Use picks a birthright (first key ability +2, not Wild) and one of its two skills (class-skill grant); its specialist spell added with the Highmagic trait; counts as that Birthright (Q100); Sorcerer (Adept) feats opened; progression as Gained class skill +10 ranks. |
| Birthrager | B | Frenzy feat gate; instinctive (casterStyle); BSB floor ⌈level/2⌉ (G11); Use picks a birthright (not Wild): specialist spell and PP 0 cantrip, tradition set if blank (Q100); castsWhileRaging (G10, Q104); Sorcerer (Adept) feats opened. |
| Blood of the Wyrm | B | Dragon Birthright eligibility (own or borrowed, Q100); resistance to the dragon type's energy; +1 die on Draconic Infusion's claw rider (after the 5d6 cap, note 16); +2 PP warp turning the damage to the dragon type on elemental/energy-trait damaging spells (G15, Q106). |
| Sanguine Channel | B | Cast option offered only when the cast-option ctx's ppSources show a Bloodmage draw: +1 attack (G14) or +1 one target's Save DC (saveDCTarget); +1 Bleed at settle when the Bleed paid. |
| Crimson Rite | B | C6 +1 circumstance per die while Bleeding (toggled effect); a Critical spell-attack hit gives the target Bleeding 1 and you +1; Use (1 PP) suppresses Bleed (bleedReduction) and the bonus to the start of your next turn. |
| Draconic Claws | A | Permanent strike rider on Dragon Claws: 1d6 secondary of the dragon type's energy (Q107), synced with the dragon type. |
| Elemental Exhalation | B | Compound prereq (G9); Use 2 AP, 2 PP, Focus: ⌊level/2⌋d6 of the dragon type + per-die bonuses (Q70), basic Reflex vs Level DC on the targeted creatures; line or cone by type (Q107). |
| Wyrm Ascendant | A | Compound prereq (G9); Use 1 AP, Focus: fly speed = land speed for 10 minutes; falls if aloft when it ends. |

### Eternal Vigil, Fatespinner, Ferromancer, Leyline Weaver, Runeblade

| Feat | | What TRG Prime does |
|---|---|---|
| Eternal Vigil | B | Death State +2 (stacks); once a day at 0 HP Touch of Healing cast on self as a free action from 0 (G7 offer, Q109; the use spent only on a real cast); a +2 PP Healing warp: fast healing 5 for (cast PP − 2) rounds on the targets (Q108); cannot progress (G8). |
| Fatespinner | B | Conviction max +1 (convictionPool); a conviction point rerolls a failed skill check (not a Blunder, not a natural 1), asked after the roll; Foreseen Danger granted; Sense Motive +10 ranks. |
| Ferromancer | B | freeSomatic for arcane casts with the pouch spent (G22, Q112); Shard Cloud granted (C on its own card: the turn and entry bites are the module's). |
| Leyline Weaver | B | +2 circumstance Ley Sense and Tap Ley Line; the replaced Tap ladder (Critical ×2 numbers + 1d8 PP, Success to end of next turn, Partial to end of turn; Q113) through Block 2's Tap branch; Leyline Power granted; Tradition skill +10 ranks (G8). |
| Runeblade | B | Book gets Potency I + a chosen Runeblade Rune (not Bane: the book keeps no kind); 1/2/3 Runeblade Runes added to the day's infusion outside the budget (Bane asks its kind); Defending I left off (Q117); +10 levels since taken (G8). |
| Chronostasis | B | Daily offered zero-HP guard (1 HP, not outright); then an auto guard and resist-all until your next turn starts; then HP 0 and Dying 1 unless healed. |
| Confluence Master | B | Two ley lines within 30 ft: asked to tap both (overlap the GM's) → advantage on the Tap; Leyline Power +1d8 on that Tap. |
| Damaging Gambit | B | Before a spell attack's check: a conviction point for advantage on the one roll (Q111). |
| Destiny’s Embrace | B | An enemy's hit on an ally within 30 ft: reaction + Foreseen Danger's Focus use → the attacker rerolls (Q114). |
| Fate’s Favour | A | convictionRefund: Partial or worse refunds, saves and skills, the first spend each day (G18, Q110 literal). |
| Iron Ward | A | Use, 1 AP, Manipulate (traitGate), Focus: +2 circumstance DB until the start of your next turn. |
| Last Horizon | B | On gaining Dying (Focus, once a minute): conscious while Dying and the next Dying check waived, act normally (G7); Dying as normal from the end of that turn. |
| Leyline Anchor | C | 1/day on a successful Tap: a 1-minute anchor; Leyline Power's Use once a round while anchored; Ley Walker's range. The Tap's own 30-ft line chooser is not extended (the GM's). |
| Leywalk | B | Ley Walker granted (its card: Partly automated); +2 status on its casting check (spell-check gate). |
| Living Iron | A | Damage reaction: resistance to slashing and piercing while PP ≥ 2. |
| Living Sigil | A | Runeblade asks for three Runeblade Runes. |
| Runeforge Mastery | A | runeDamageBypass on the infused weapon's Runeblade Runes, immunity as resistance (G19). |
| Temporal Reprieve | B | Use, 0 AP, Flourish/Open, Focus: spend up to level PP, heal 1d8 per PP (Q122). |
| Twinflare Rune | A | Runeblade asks for two Runeblade Runes. |

### Runebreaker, Shade Master, Spellwarden, Spell Duellist, Spell Weaver, Stormcaller

| Feat | | What TRG Prime does |
|---|---|---|
| Runebreaker | B | Dispel −2 PP (min 1, registerDispelModifier); cast reaction on a spell whose sole target is you: reaction + Storing Rune's 1 PP, Will vs the caster's Spell DC, stopped and stored foreign (G16, Q115); Rune birthright gate (G9); no later archetype (Q91). |
| Shade Master | B | Fade Step and Dark Whispers granted (specialist); Dark Whispers refused in light > 5; +3 PP Shadow Shift hidden warp; Umbral gate (G9); no later archetype (Q91). |
| Spellwarden | B | +2 class on spell-forced saves (check reaction, before; the source must hold that spell); a ticked row for other magic; Counter Channel granted. |
| Spell Duellist | A | +2 class Spell Recognition (conditional on the action); Spellstrike Riposte granted; +10 levels opted in to G8 (Q90). |
| Spell Weaver | B | Magical Reservoir granted (Int uses, floor 1); three G1 options paid in a charge, one a cast: −2 PP discount (floor 0), die step, ×1.5 duration/range/area. |
| Stormcaller | B | Gale Step at 0 AP (Block 3's Use replaced for owners); Storm Bolt −1 PP paid (G4, floor 0); the burst warp as a granted variant spell; Storm gate (G9); no later archetype (Q91). |
| Absolute Denial | C | Cast reaction: an enemy's spell ≤ 8 PP as cast (Q119; ctx.castPP, so an innate spell's printed PP) with its caster or a target within 20 ft is stopped; Use toggles suppression; an area placed from outside is the GM's. |
| Deep Weave | A | +1 Reservoir use (G21); a critical spell attack hit or critical save against a spell regains 1 charge, once a round. |
| Duellist’s Focus | A | Riposte +1 circumstance, +2 against a spell attack. |
| Duellist’s Supremacy | A | Riposte without PP once a round (Focus still spent, Q114); advantage against your Spellblade's Mark. |
| Eclipse Step | B | Fade Step's free use once a round (Focus spent, Q114), landing in light ≤ 5 (Q120); 1/day 120 ft, then Concealed to the start of the next turn. |
| Extra Reservoir | A | +2 Reservoir uses (G21). |
| Eye of the Storm | C | 1/day Use: 30-ft expansion for 3 rounds, turn-start basic Reflex 1d6/level electricity on enemies, electricity immunity; the 10-ft difficult terrain is a card. |
| Glyph Shatter | B | Dispel onResult on Success+: asked; 10-ft basic Reflex, 1d6 force per 2 PP of the counteract value; ward/barrier asked → +1 circumstance to the next Dispel within 1 minute. |
| Grasping Shadows | B | After a Shadow spell or a Fade Step: 1 PP, a creature within 10 ft (Q121), Reflex ladder (Slowed 1 / Immobilised; Blunder + basic Fort 1d6 per 2 levels essence). |
| Improved Counter Channel | A | Counter Channel at 60 ft. |
| Instinctive Counter Channel | A | Counter Channel without the reaction, once a round; Focus and PP still spent (Q114). |
| Overflow Casting | B | Reservoir options offered at 0 charges while its Focus use is ready; 2d6 per missing charge ignoring defences, 5 Soul Drain at 0 HP or less. |
| Reflective Warding | C | On a Counter Channel Critical: negate or retargetCaster (G17); an area spell is the GM's. |
| Rippling Counter | B | After a critical riposte: a 5-ft Step armed and a second melee Strike asked (no cantrip). |
| Rune Rend | B | After an absorb: 1 PP, the caster's basic Will vs your Spell DC, 1d6 force per 2 PP of the spell. |
| Runic Overload | B | A cast option on a stored release (G16 ctx.stored), Focus: Save DC +2 and Casting DC +3 (Q116); on settled, basic Will 1d6 force per 2 (PP+2) on the creatures hit or saving, and the basic Fortitude backlash on you. The spell's own per-PP riders are not shifted (no core seam for a stored release). |
| Shadowmantle | A | Defence row +1 vs spell attacks in light ≤ 5 (G20); check reaction +1 circumstance on spell-forced saves in light ≤ 5; 1/day Hidden with Fade Step. |
| Wellspring Conduit | B | A G1 option at 0 charges, Focus: +1d6 per 2 printed PP (added damage pool) or healing; the printed PP is read (a reading, said on the card). |

### Runemage, Sorcerer and Spellblade

| Feat | | What TRG Prime does |
|---|---|---|
| Prepared Sigil | B | Daily-prep reset; Use inscribes one castable non-innate Symbol spell; a prelude offers the sigil cast (castSpell preparedSymbol, G25: no hand or room for the Symbol, −1 AP); spent on settle, not on a refunded cast (Q123, Q124). |
| Runic Reservoir | A | Three distinct sigils; one activation a round (combat round, or 6 s of world time). |
| Living Script | A | A sigil reforms after 10 rounds or 60 s; a Heroic keeps it ready; the round lock holds. |
| Combat Inscription | A | Declares runemage { defensiveIncrease: 0, roomNote } (G25): no defensive +2; the room line's wording. |
| Ley-Etched Symbol | B | G1 option: −1 PP paid (floor 1, Q93) on a Symbol cast while the ley-benefit marker is on, once a round; Fumble/Blunder rolls the Ley Line backlash at that level (Q125). Needs the Block 2 marker wired (layLeyBenefitMarker). |
| Arcane Study | B | Eligibility (Arcanum, Q100); Use scribes arcane spells by Learn a Spell (book on the feat); daily pick adds a day spell or a +1 warpDiscount (Q142). |
| Bespell Weapon | B | Free Use after this turn's cast: a weapon-scoped 1d6 strikeRider typed by school, to the end of the turn; Sustain 1 AP Concentrate (Q143). |
| Bonded Infusion | A | Spell-check gate +2 item while the infused weapon is held (not innate/item, set aside under High Magic); feat flags synced: spellAdder 1 while infused, freeSomatic while held (Q144). |
| Call Bonded Weapon | B | 1 AP Manipulate Use equips the Blade Ally or infused weapon; the hand budget is not checked (no core helper) and a weapon on another sheet is the GM's. |
| Clever Damage | A | Declares meleeAbility { damage: [intelligence] } (G25). |
| Clever Strike | A | Declares meleeAbility { attack: [intelligence] } (G25). |
| Considered Attack | B | Use: the core's Strike with +2 untyped, 1 extra AP (Q145). |
| Dangerous Sorcery | A | Declared spellDamageBonus { valueFrom: spellPP, instantOnly, status } (G12, Q146). |
| High Mage’s Focus | B | Use picks a known Highmagic spell (a second at BSB +10, with a reminder); gate +2 castingOnly on its casts. |
| High Magic Resonance | A | Resonance modifier single:true on High Magic (G5); daily Fumble → Failure remap (Q147); Wild barred (G9, Q100). |
| Magical Retribution | C | Pending-cast step (G26): AoO offered before the interruption settles; elsewhere a reaction Use against the targeted attacker (Q149). |
| Metamagic Adept | B | registerMetamagicPayment (G3): Extend/Reach/Silent/Still paid 1 AP, DC as if paid, 1–2 AP spells, one a cast; Flourish checked when offered, recorded on settle from the hooks' metamagicPayments. |
| Resonance Surge | B | Eligibility (Wild); Focus Use arms a marker; a required G1 metamagic answers freeWarpPP 2 on the next levelled learned cast (not ritual, item, stored, innate, threaded); that key forces the Resonance (G5, Q148) and spends the surge on settle (not refunded). |
| Spellblade’s Mark | B | 1 AP Concentrate Focus Use on a targeted enemy ≤ 60 ft: melee conditional, attack-only gate row (G14), strikeRider and spellDamageRider by uuid (G25), ward DB row (G20); ends with the combat. |

### Metamagic and Adept

| Feat | | What TRG Prime does |
|---|---|---|
| Arcane Fencer | B | Check reaction before a one-handed melee Strike (G25 weapon on the ctx): burn 0…min(caster level, pool) PP for +1 status attack each. |
| Conduit Mastery | A | Charged-item rule (G6): wield limit 3; every activation −1 PP (minimum 1), not a Rod of the Magi draw. |
| Dual Channel | A | Charged-item rule (G6): wield limit 2; a Fumble or Blunder release costs every wielded charged item 1 more PP (Charge Depletion below 0, never rolled twice for the released item). |
| Extra Cantrip | B | Declared cantripBonus 1 per copy (G25) on the memorised or known allowance; Use picks a PP 0 spell of the tradition for a class with neither; the once-every-four-levels limit checked by the Use. |
| Focused Spell | B | Module metamagic (G1): +3 PP, advantage on the casting check; learned casts only. |
| Lightning Rod | B | Module metamagic (G1): +2 PP on an electricity spell; after: mark a creature hit (to the end of your next turn); next electricity-trait cast splashes enemies within 10 ft for half the dice, no save (Q127); −2 save row on the mark (auto in metal armour, tick otherwise); G9 compound prerequisite. |
| Mana Bound | A | Fumble modifier (G5): −20 when not a Blunder and the check is Spellcraft. |
| Metamagic Conduit | B | Charged-item rule (G6) metamagic: an item cast offers the module's metamagic, the wielder paying it, ceiling double the release PP (Q130); eligibility: owns a metamagic feat (G9). |
| Pact Channeler | B | Module metamagic (G1): +1 PP, the patron's channel (traits, +2d6/4d6 healing or typed damage, Fey Save DC +1/+2, Void's Will save → Flat-Footed); innate casts paid from the pool (Q95); eligibility: a Pact archetype (G9). |
| Sensory Spell | B | Module metamagic (G1): +1 PP; after a cast that went off, a one-shot +2 on the next Deception, Intimidate or Perform check this turn. |
| Spellthread | C | Module metamagic (G1): +2 PP, a woven spell's base PP joined (basePPAdd), longer casting time, savingStep 1, Partial→Failure and Failure→Fumble remap, fumble/Resonance disadvantage; the woven spell resolved by castSpell's thread on Success+. Its warps and the shared concentration are the GM's. |
| Spellthread Mastery | C | Spellthread's picker takes a third spell. |
| Spellthread Unbound | C | Spellthread's picker offers any tradition. |
| Steelbinding | B | Module metamagic (G1): +2 PP when a target within 30 ft wears metal armour; after a cast that went off, its Fortitude save vs the cast's own Save DC (the settled facts' saveDC): Slowed 1 / Immobilised / Immobilised and a held metal weapon dropped. |
| Subconscious Casting | B | Unconscious offer (G7): at 0 HP, a 1 AP Self/Touch prepared or known spell cast at 0 AP with the preset +6 PP option (G1 preset); Focus spent when the PP are paid; HP re-read. |
| Thunderclap Aura | B | Module metamagic (G1): +2 PP on an Air/Electricity spell; on Success+, ⌊total PP / 2⌋d6 electricity to every creature within 10 ft but you, basic Fortitude vs the cast's Save DC (Q129). |
| Unfettered Mastery | B | Module metamagic (G1) of kind quicken: 0 PP, 1 AP less on a High Magic cast of 2+ AP; Focus. |
| Versatile Binder | C | Module metamagic (G1): +1 PP on a Summons spell, an existing creature chosen, its save rolled after the cast; the binding is the GM's; no Summons spell until Blocks 7–8. |
| Weave Infusion | B | Charged-item rule (G6) payment: a tick on Cast from Item to pay from your own PP; an empty item allowed, then Charge Depletion with disadvantage (lower d100, Q131). |
| Resonant Conduit | A | Charged-item rule (G6) cost: free while 2+ charged items are wielded and the day's stamp is unset; stamped on release; cleared at daily preparation. |

### Warlock and Witch

| Feat | | What TRG Prime does |
|---|---|---|
| Elemental Blast | B | Daily-preparation (or Use) element; Xithra's damage-type offer becomes mental + soul + element. |
| Enhanced Blast | A | Xithra's base and level dice written as d8 (and back on removal); the cone reads them. |
| Ethereal Insight | B | Darkvision granted; See Invisible innate 1/day; the Soulbound familiar within 30 ft carries Darkvision and the day's See Invisible sight (Q140). |
| Extra Bond | B | After each Soulbound daily bonus, one more distinct bonus per copy, range-switched as the first; Use re-asks. |
| Extra Communion | A | registerExtraUses: Verdant Communion +1 use a day (G21). |
| Forbidden Lore | B | One Use pick: an Arcane or Divinity spell, PP ≤ CL + 1, added outside the picks with the Highmagic trait (Q99). |
| Hex Binders Curse | B | 1 AP Concentrate Use on one targeted enemy within 30 ft, kept on the curser (nothing written on the target); your Strikes and spells that damage it add 1d6 (+1d6 at 10/15/20) of the blow's type, once each (G23, Q135). |
| Hex Mastery | A | registerCastCostModifier: a learned/specialist hex −1 PP paid, min 1; DC and cap unchanged (G4, Q93). |
| High Sorcery | B | One Use pick per copy: a spell the class could pick, PP ≤ CL + 1, added outside the picks as High Magic. |
| Malevolent Blast | B | After a Xithra hit, Focus: Will vs the innate DC (G25); Failure or worse Stunned 1, 2 on a critical hit (Q136). |
| Pact Ascendant | C | By the pact: aura, immunities, fly 40, the Demonic death guard at half HP with its 20-ft burst (G7, Q141), the pact's spell (Grave: Hand of the Reaper); synced on create, delete and Use only; the burst's Evil trait and Conjure Elemental's element are the GM's. |
| Pact Boon | B | By the pact, the spell added (Warlock innate Focus, Witch High Magic repertoire); Draconic's Dragon Wings waits on Blocks 7–8. |
| Ritual of Borrowed Power | B | Daily-preparation (or Use) pick of any spell, PP ≤ CL + 1, with the Highmagic trait; removed at the next preparation. |
| Shadowed Grimoire | B | One Use pick per copy, as the soul's picks (innate Focus Charisma); after a level gained, the Use offers the swap. |
| Soul-Bound Grimoire | B | Daily preparation: E/V scrolls scribed into the familiar (used up), one stored spell imprinted (a day's copy, or −1 warp PP if known); Use erases; lost with the familiar (Q138). |
| Symbiotic Witch | C | 1/day cast of a base-PP ≤ 4 spell measured from the familiar (G24 rangeFrom); a sustained spell handed to the familiar (setSpellSustainer). The warped total over 4 PP is carded, not refused. |
| Warding Sigil | A | 1 AP Focus Use (Q139): resistance to Xithra's types until the end of your next turn. |
| Warlock’s Hex | B | After your spell's damage (G23): Focus and 1 PP from the Charisma pool; −1 (−2 at 10+) circumstance to saves against your spells for Cha rounds (Q134). |
| Xithra Cone | B | Xithra's prelude asks bolt or cone; the cone spends AP and the Focus use, basic Reflex vs the innate DC for each targeted creature (G25, Q136). |
| Xithra Recovery | A | focusExtraUses on Xithra: two uses, both restored by Refocus. |
| Xithra Spear | A | Xithra's range written as 60 ft (and back on removal). |

### Block 5’s five, finished here

| Feat | | What TRG Prime does |
|---|---|---|
| Echo of the Ancestors | B | Module metamagic (G1): +2 PP, Focus, on the heritage's element; a second creature at half damage (targets.extra, Q75). |
| Resonant Pulse | B | Module metamagic (G1): 0 PP, Focus, Save DC +1 on a spell with a save; learned and innate casts (Q94). |
| Resonant Harmony | B | Module metamagic (G1): 0 PP, Focus, on a self-only spell an adjacent ally receives its self rows (targets.share). |
| Spell Surge | B | Module metamagic (G1): +1 PP, Focus (the trait added, Q132), one of range ×1.5, duration ×1.5, +2 class Save DC, +1 damage die; fumble and Resonance at disadvantage. |
| Piercing Insight | C | On Sense Magic (both actions): choose metamagic from the catalogue (G1), discount-only options left out; PP and a Focus option's use spent (Q96), no check; the card says what each changes, the GM applies it. |

### The archetypes’ abilities and spells (part 2a)

| Item | | What TRG Prime does |
|---|---|---|
| Foreseen Danger | B | Before an ally's attack, save or skill check within 30 ft: reaction + Focus → +1d6 untyped before the dice; Use toggles the asking. |
| Leyline Power | B | After a Tap Success+: reaction + Focus → 1d8 PP (2d8 Critical); anchored Use once a round. |
| Shard Cloud | C | Turn-start and entry bites (basic Reflex, 1d6 slashing, +1d6 / +5 ft warps) while sustained; entering because the caster moved is the GM's. |
| Ley Walker | C | Refused away from a ley line (30 ft or anchored); the journey is the GM's. |
