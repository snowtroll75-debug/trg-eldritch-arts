# Live test: Eldritch Arts 0.12.0 on TRG Prime 3.687.0

12 November 2026. Graham's world in Chrome, Foundry 14.367, as Testing Dude (GM), with no other users connected. Both zips were installed by Graham: 3.687.0, and the 0.12.0 rebuilt with compiled packs (130 spells).

**Setup.**
- **Actors:** throwaway "ZZ EA" actors, copied from Valmorius and the Shadow and never saved back. They were the Wizard (level 20), the Second (level 12), the Ally and the Foe (level 6), and three Undead (Shadows).
- **Spells:** the 17 were added from the compendium. My first copies lacked the compendium link, which is how the module recognises an Eldritch Arts spell; that was my rig, not the module.
- **Scene:** a throwaway scene, "ZZ EA 0120 Live".
- **Dice:** fixed where a degree mattered, through `DiceTerm.randomFace`, and restored afterwards.
- **World time:** never advanced. Turns were set directly on a throwaway combat.

## Results

| Test | Result |
|---|---|
| **H13, a ritual's Partial** (Concord of Stone, Partial at 22 vs 24) | **Pass.** "Partial: the ritual's partial result is applied. No PP is lost…"; cast for 0 PP; a 120-ft Region for 1 week; 800 gp taken. |
| Concord of Stone's members | **Pass.** The Wizard, the Second and the Ally got +2 DB (13 → 15), the hostile Foe none. Leaving the zone removed it, and coming back restored it. |
| **H14, alone** (Elemental Convergence, Success) | **Pass.** "Performed by the primary caster alone…", cast at 14 PP. |
| Convergence's elements (review fixes 3, 8, 9) | **Pass.** One prompt per creature (7), with no duplicates from the cast's sync and the new `createRegion` hook together. Each creature got two effects, resistance and a rider. A rider its owner switched off stayed off through moves. |
| **H16, the storm** (Storm of Unmaking, Success) | **Pass at the cast.** "the storm's 1d6 — 3, Cold", 30d4 at DC 35, both creatures under it saving. **Fail at the turn start:** see finding 1. |
| Storm of Unmaking's fumble | **Pass after one fix.** A storm on the caster, following him (the centre moved 1050 → 750 with the token), with its own 1-minute clock. It struck at his turn start (6, Force). Its DC was 55: finding 5. |
| Soul Confluence (review fix 1, high) | **Pass, after finding 4's workaround.** A pool of 15 for three. A 10-damage hit came off the pool; of a 12, the pool took 5 and HP took 7. At the end, with the Wizard at Soul Drain 2 and 2d6 each, he went 2 → 9 on a 7. It was not doubled. The links were undone. |
| Army of the Grave (review fixes 6, 7) | **Pass.** 3 undead raised and recorded on the control register at full level 4, totalling 12 of 20. Deleting one's raised effect released its entry. |
| **H15, rest rates** (Eternal Invocation, alone) | **Pass.** Good-aligned creatures ×2 HP and PP, the evil Foe ×½, the unaligned Second ×1 (read with the core's `restRatesOf`). The caster with no aligned trait got the card's "grants nothing". |
| Dismissing a cast-bound zone (review fix 13) | **Pass.** Ending Eternal Invocation removed its Region and every blessing at once, and released its 20 locked PP, with no clock tick. |
| Sun's Benediction (review fix 10) | **Pass.** Three healed. The Ally was asked on its owner's prompt which condition to lower; it chose weakened (2 → 1), and sickened stayed. Blessed for an hour. |
| Rite of Binding Oath, Partial (review fix 10) | **Not reached.** See finding 3. |

## Findings

1. **Storm of Unmaking, cast successfully, strikes once and never again, and never passes** (core, high). Its "1 minute" is not a duration the active-spell registry records, so the turn start found no running cast for the storm's cast id. **Fixed in 3.687.0:** the cast gives a turn-start storm its own clock.
2. **Mimic Spell is offered when it could never imprint** (module, medium). This covers a Ritual spell (Convergence, Army, Eternal, Sun) and one above the reactor's cap (Storm of Unmaking's 20 PP, to a cap of 13). Accepting cost 8 PP and the reaction. **Fixed:** it is not offered for either.
3. **Rite of Binding Oath cannot be cast** (module, high). It prints Targets "up to 10 willing creatures" but no Range, and the core reads a blank range as "self", so it refused both targeted participants. **Fixed:** the participants (casters plus those ticked in the ritual dialog) are sworn, and the spell asks the core for no creature. Graham's to confirm: the book prints no range, so every participant is sworn wherever they stand.
4. **Soul Confluence: the core's target dialog led to a refused cast** (module, medium). The core offered the allies and then refused them as beyond "self". The module asks for the allies itself after the cast. **Fixed:** the spell asks the core for no creature.
5. **The fumble storm's DC was 55** (module, my regression from the review). The review said the sheet's DC lacked the PP; it does not. A successful cast of the same storm used DC 35, the sheet's. **Reverted.**
6. **Mimic Spell's Spellcraft check rolled +0** (module, high). The core's `rollCheck` fills in a save's or a skill's modifiers, not Spellcraft's. **Fixed,** and with it **Block 7's Argent Reversal**, which had the same fault since 0.10.0 (never run live).

**Low, not changed:**
- A refused ritual leaves its plan flag on the caster; the next ritual overwrites it.
- The Cost makes change in the largest coins (the core's `deductCurrency`, as Learn a Spell); nothing is lost.
- The storm's fumble note is printed on every cast.
- Raised undead keep their token's hostile disposition.

## Not run live

Chaos Shield, Leyline Anchor, Veilfracture, Veil Severing, Rite of Echoed Shadows, Call of the Ancestors, Essence Reforging and Alter Corpse; the Oath's GM choice. The harness covers them (`verify-block8b`, 356 checks).

## Cleanup

- **Deleted:** the scene, the 7 ZZ actors and the 113 test chat messages. The world has 311 messages again.
- **Graham's documents:** Valmorius, the Shadow and Borin were read, not changed. No other message was touched.
- **Dice:** restored.
- **View:** Oldwatch Approach.
- **Game:** still paused, with no combats.
- **World time:** unchanged (11,896,844,495).
