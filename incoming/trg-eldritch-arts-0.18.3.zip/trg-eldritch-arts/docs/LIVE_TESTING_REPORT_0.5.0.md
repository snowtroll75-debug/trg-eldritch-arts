# Eldritch Arts 0.5.0 — Live Testing Report

2 November 2026. Eldritch Arts 0.5.0 on TRG Prime 3.680.0, Foundry V14 (14.367), world "TRG V14", as Gamemaster in Chrome. Inner Tempest, Pillars of Faith and Fiends & Fables were active.

**Throwaway material, all deleted afterwards:**
- the scene "ZZ EA Block 3a" (3000 × 2000 px, 5 ft squares), and on it the Region "ZZ EA Ley" (a Ley Line, level 6);
- the actors "ZZ EA Archmage" (5th), "ZZ EA Sorcerer" (Storm, 4th), "ZZ EA Witch" (3rd), "ZZ EA Wild" (Wild, 3rd), "ZZ EA Dragon" (Dragon, 5th), "ZZ EA Umbral" (Umbral, 5th) and "ZZ EA Scaelyn" (an Archmage, 4th), made from the new Classes compendium;
- the familiar "ZZ EA Witch's Cat", made by the Soulbound Familiar.

None of Graham's actors was touched. Dice were steered with `CONFIG.Dice.randomUniform` and restored afterwards. The 72 test chat cards, the actors and the scene were deleted, and the view went back to Oldwatch Approach. No console error or warning from TRG Prime or Eldritch Arts.

## Results

| # | Test | Result |
|---|---|---|
| 1 | Load | **Pass.** 3.680.0 and 0.5.0. The four new API registries and the two familiar helpers are present. The Classes pack holds three. The registered classes are the Archmage, Sorcerer and Witch (wealth 1, 0, 1), with Raw Power, the classes' access and the Soulbound modifier. The PP grants are Aetherial, Emberkin, Nyrinn, Scaelyn and Wild Power. No problems were reported. |
| 2 | Archmage, 5th: the derived numbers | **Pass.** CL 5. PP 28 (25 + Intelligence 3). Book 10 (6 + 1 a level). Memorises 12 a day and 3 cantrips. |
| 3 | Archmage: the cantrip pick | **Pass.** "Any cantrip of any tradition" offered 36, Guidance and Orb of Water among them. |
| 4 | Archmage: a picked cantrip | **Pass.** Guidance went into the book unprepared, and casting it was refused. Once memorised from the book it cast. The book's ladder stayed at 0. |
| 5 | Archmage: the book pick | **Pass.** "Any PP 2 spell of any tradition": all four traditions, PP 2 only. |
| 6 | Sorcerer, 4th, before a birthright | **Pass.** CL 0. The repertoire shows 4 owed. The birthright cantrip waits. |
| 7 | Birthright Use: Storm | **Pass.** It granted Storm, Orb of Lightning (Q15), Storm Bolt, Breeze Strike, Conjure Elemental and Gale Step. CL 4, verdant, Constitution, PP 27. Nature and Survival became class skills. The repertoire reads "any tradition; Birthright: verdant", and the cantrip slot is verdant. |
| 8 | Repertoire Pick with both schedules owed | **Pass.** Pick asked for the class or the Birthright schedule. The Birthright list was verdant only. Barkskin went in on track "birthright". |
| 9 | Witch, 3rd | **Pass.** CL 3. Ethereal, Charisma. PP 18. The repertoire shows 4 owed and 0 swaps, "ethereal or verdant". |
| 10 | Raw Power: Barkskin warped to 6 PP at CL 4 (cap 5) | **Pass.** No Sacrifice prompt. Casting DC 21 with only "High Magic, Hard +2" and no Overcast row. Success; 6 PP spent. |
| 11 | Wild birthright, 3rd | **Pass.** PP 24: 18 + Charisma 3 + Wild Power 3, stored as its own grant. No single tradition. |
| 12 | Wild Power Use | **Pass.** One Use rolled all three rows owed. d20 9 gave divinity, a cantrip (Guidance). d20 4 gave arcane, PP 2 (Fear). d20 20 gave verdant, PP 4 (Rune of Warding). Each rolled spell was shown with its list, to keep or replace. |
| 13 | Wild Power: the daily specialist spell | **Pass.** At the first daily preparation it was Inspire Defence (Bard, PP 1). At the second, Ley Bolt replaced it. Neither was a hex. |
| 14 | Wild Power: the surge on an unmodified 13 | **Pass.** Fear (PP 2) rolled a natural 13, which rolled the Wild Surge table at level 2 ("the spell's PP"). d100 63: −3 racial Intelligence for 2 rounds, applied to the caster. |
| 15 | Hexes Use, 3rd | **Partial.** 18 of the 22 hexes were offered: none above 3rd level, and the Bloodmage pair among them (Q21). Each chosen hex was added as a specialist spell. **But one Use took one hex**, though the dialog was titled "1 of 2" and the notes say "choose those owed" (finding 1). |
| 16 | Casting a hex (Armouring) | **Pass.** The DC read "High Magic, Hard +2 … Specialist Spell — Very Easy". Its three effects applied. |
| 17 | The Soulbound spell adder | **Fail.** Armouring was paid by "Spell Adder: Soulbound Familiar" before any familiar existed. Later a cast was paid the same way while the familiar was dead (finding 2). |
| 18 | Soulbound Familiar Use: the bond | **Pass.** The core's Familiar form dialog, then "ZZ EA Witch's Cat" was made. HP 27 (half the Witch's 48, + 3). Base DR 2. Saves Fort 8, Ref 8, Will 13: +3 Charisma as a class bonus each. |
| 19 | The daily bonus and its range | **Fail (timing).** +10 HP raised the Witch's maximum from 48 to 58. Moved 50 ft away, the bonus stayed on; moved back to 15 ft, it went off. Every check was one move behind (finding 3). At rest it was right: the +1 Spellcraft bonus was off at 50 ft, and on after the familiar was nudged within 30 ft (Spellcraft 6 → 7). |
| 20 | Severed Bond by Use (distance, Q25) | **Fail.** The card said "you are fatigued 2", and the bonus was removed, but no fatigue was applied (finding 4). |
| 21 | Rebond at daily preparation | **Partial.** It was offered and accepted, the severed flag cleared, and the bonus was chosen. No card said the bond was renewed (finding 6). |
| 22 | The familiar killed | **Fail.** Damage taken while the familiar was already dying raised its Dying to 6, past its Death State of 5, and it died. The bond was not severed, because 0.5.0 looked only at HP changes (finding 5). |
| 23 | Verdant Communion | **Pass.** Power Recovery (Meditation) came out Partial and regained 1 PP. +2 Nature and Survival (class) for an hour. A second Use was refused: once a day. |
| 24 | The Witch's High Magic per tradition | **Pass.** Anticipate Attack (ethereal) was High Magic. Bless (divinity) was not: its DC had no High Magic row and no identification note. |
| 25 | Dragon Claws | **Pass.** The type was asked at the first Use (fire). The claws are 1d6 piercing, agile and finesse. The attack showed "BSB 5 in place of BAB 2, +3". The damage of 2d6 + 2 (a minor crit) was untouched by it. |
| 26 | Gale Step | **Partial.** 30 ft was refused. 15 ft into a free square teleported, with a card. **15 ft into the Witch's square was refused by the core** ("cannot end your turn in a space another creature occupies"). Gale Step still carded "You teleport 15 feet", and that spent its Focus use (finding 7). |
| 27 | Ley Bond Use | **Pass.** "Within 500 ft: ZZ EA Ley — level 6, 63 ft east". |
| 28 | Ley Bond's DC | **Pass.** A High Magic Shield showed "Ley Bond (High Magic casting DC −1) +1". |
| 29 | Ley Tap | **Pass.** "Ley Tap: in range" came on with the line in range. It went off when the line's behaviour was disabled, and back on when re-enabled. |
| 30 | Racial PP (the Block 1 fix): Scaelyn Archmage, 4th | **Pass.** PP 23 → 29 with the race (+4 racial, +2 from Int +2). Back to 23 when the race was deleted. |
| 31 | Specialist Spell feat: the Archmage | **Pass.** It offered 106 specialist spells of every class, Draconic Infusion and Storm Bolt among them. No hex and no ordinary spell (Invisibility, Blur, Shield, Fear and Bless were all absent). |
| 32 | Specialist Spell feat: Umbral | **Pass.** Nine: the "Birthright Any" spells and the shadow-trait specialists. The Umbral's own Shadow Shift, already known, was left out. |
| 33 | Umbral Affinity's Darkness | **Pass.** It was granted at 5th, PP 4, marked as a specialist spell. Casting it stopped at the core's material-component check, because the throwaway actor had no pouch. That is not Eldritch Arts. |
| 34 | Console | **Pass.** No errors or warnings from either package. |

## Findings, all fixed in 0.5.1

1. **Hexes took one hex a Use** while titling the dialog "1 of 2". Now one Use takes every hex owed, one after another, as Wild Power does. Cancelling stops, and what was taken stays.
2. **The Soulbound spell adder needed no familiar.** The ability carried a printed +1 spell adder flag, so a Witch got a free casting a day with no familiar, a dead one or a severed bond. Now the ability carries the flag only while a living familiar holds the bond. A 0.5.0 Witch is trued up when the scene loads.
3. **Ranges were checked one move behind.** On Foundry V14, while a token moves, its document gives the position it is drawn at until the animation ends, even inside `updateToken`. Where it stands is in the document's source. Block 1's shared measure (the Null Aura, Block 2's ally ranges, the Soulbound Familiar's 30 ft) and Gale Step now read the source. Block 2's areas (Ley Tap included) already did.
4. **A severed bond fatigued no one.** The condition was passed as the text "fatigued 2", and the core skips anything that is not `{ key, value }`. The harness's fake accepted text, so it missed this. Both are now the core's shape. A new bond takes the 2 off again and leaves any other fatigue.
5. **A familiar that died while dying did not sever the bond.** Death in TRG Prime is Dying passing the Death State, and a creature already below 0 HP dies with no HP change. The familiar's death is now asked on any update, any change to its effects, and the core's "creature slain" hook. A familiar found dead when the scene loads severs then.
6. **A renewed bond said nothing.** It now posts a card.
7. **Gale Step carded a teleport the core had refused,** and the card spent the Focus use, and in combat the AP. Now only a token that arrived pays and is carded. (A one-hop teleport over another creature was never refused. A Blink drag with waypoints was, as if walked between its hops: fixed in TRG Prime 3.680.1.)

**Noted, not changed:**
- The core's Familiar card prints the familiar before the Soulbound additions ("DR 1, HP 24"). The Soulbound card follows with them.
- A Soulbound "+1 to Spellcraft checks" also raises the Spellcraft DC (16 → 17). That is the core's derivation of the DC from Spellcraft.
