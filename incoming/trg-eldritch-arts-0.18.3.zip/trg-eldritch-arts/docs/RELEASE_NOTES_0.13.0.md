# Eldritch Arts 0.13.0 — Block 9a: the catalysts, the catalyst feats and the special materials

13 November 2026. **Needs TRG Prime 3.688.0** (H19, H20 and the ritual rules' `settled`). Built from `docs/ELDRITCH_ARTS_BLOCK9_AUDIT.md` §3.2.1–3.2.3, as Graham answered it on 13 November (00:23, "Go with your recommendation for all questions and proceed": Q185–Q210 as each row recommends, H19–H25 approved). Block 9 is in three releases: 9a is this one; 9b (the invested runes and the specific armour, shields and weapons, on TRG Prime 3.689.0) and 9c (orbs, rods and staves, on 3.690.0) follow.

- **Install TRG Prime 3.688.0 first**, then this. No migration; no world data is touched.
- **A new pack, Eldritch Arts: Consumables**, holds the 24 catalysts. The ten materials have no documents: they join TRG Prime's own material list, so they appear wherever a material is chosen (the item sheet's customisation).

## The 24 catalysts (Chapter 6, L5208–5510)

Each is a consumable carrying its printed entry, its row of the Catalysts table, and what the module does with it. Price, level and rarity are as printed. Weight is not printed, so none is given. Grades: **20 A, 3 B, 1 C**.

### How one is used (H19; Q186–Q192)

- **When you cast,** TRG Prime asks which catalyst to use, on a prompt of its own before the cost test (one per spell; "None" first). It offers only the ones that fit the spell: an Arcane spell for Arcanite Powder, a spell attack for the Bead, a damaging Essence or Fire spell for Ashen Lotus, and so on. Holding none that fit, you are not asked.
- **Not offered** on:
  - a cast from an item;
  - a ritual (Blood-etched Vellum is the ritual's: below);
  - a stored or threaded spell;
  - an innate spell;
  - a cast whose check is a Strike's roll (Thunderous Strike);
  - a cantrip with no attack.
- **Its effect** reaches the cast through the channels the module's metamagic already uses: advantage on the Spellcraft check, an item bonus to it or to the attack, a die more or a die step, added dice, a Save DC, the range or duration, a PP off (payment only, Q189), the damage type, an ignored resistance, a trait.
- **Consumed** once the cast has settled, "whether the spell succeeds or fails". A cast called off and refunded (an area's placement cancelled) spends nothing.
- **The backlash** comes on a Failure, Fumble or Blunder of the Spellcraft check (Dragonbone Dust: on a Fumble or Blunder only, as its entry prints and M10 rules). It is applied to the caster, by the caster's client, and said on the catalyst's card:
  - damage per PP or per 2 PP of the spell as cast (Q187);
  - conditions with their clocks;
  - Soul Drain;
  - recurring damage;
  - timed check penalties as effects (−2 Arcana for an hour, disadvantage on Spellcraft for a minute).
- **Slowed bites at the start of a turn**, and TRG Prime sweeps a condition's round clock at that same moment. So a Slowed of N rounds runs one round further on the clock, and it takes its AP N times. Without that, Frozen Marrow's "Slowed 1 for 1 round" would end before it cost anything.

### The catalysts, by what they do

| Catalyst | Grade | Offered on | Effect | Backlash (Failure or worse) |
|---|---|---|---|---|
| Arcanite Powder | A | an Arcane spell | advantage | −2 Arcana, 1 hour |
| Ashen Lotus Bloom | A | a damaging Essence or Fire spell | its damage ignores resistance to its type | Soul Drain 1 per PP |
| Blood-etched Vellum | A | a ritual (the dialog's tick) | +2 item to the primary's ritual check | Bleeding = the PP, at most 10 (Q202) |
| Celestial Dewdrop | B | a damaging spell | +1d6 secondary essence per PP, scaled by each target's save; essence ignores resistance (the whole cast's) | Blinded, 1 minute |
| Chained Obsidian Bead | A | a spell attack | +2 item to the attack | Immobilised to the end of your next turn |
| Cinders of the First Flame | A | a spell with damage dice | the dice step up (a d12 stays a d12, Q188) | 1d6 recurring fire |
| Dragonbone Dust | A | a spell with damage dice | one more die of the spell's own (M10) | Weakened 1, 1d4 rounds per PP (Fumble or Blunder only) |
| Eclipse Resin | C | any | a card line: identifying the spell is at disadvantage (the identifier's roll, the GM's) | 1d6 essence per 2 PP |
| Frozen Marrow Shard | A | a damaging spell whose type no warp has changed | the damage becomes cold; +1 DR to the end of your next turn once cast | 1d6 cold per 2 PP; Slowed 1, 1 round |
| Glimmercoal | A | a damaging spell of 2 PP or more | +1d6 fire per 2 PP, scaled by each target's save | 1d6 fire per 2 PP |
| Grave Soil | A | an Essence spell with damage dice | one more die | Frightened 1 and −2 Spellcraft, 1d6 rounds (one roll) |
| Incense of Stillness | A | any | advantage | disadvantage on Spellcraft, 1 minute |
| Leydust | A | any | +2 item | 1d6 force per 2 PP |
| Moonveil Dust | B | an Enchantment spell with a save | +2 item to the Save DC | Dazzled, 1 minute |
| Phoenix Feather Ash | A | a Healing spell | +1d6 HP per PP | 1d6 essence per PP |
| Resonant Crystal Shard | A | a spell of 2 PP or more | 1 PP less paid (at least 1); the DC, cap and Save DC read the PP as cast (Q189) | 1d6 piercing and 1d6 force per 2 PP |
| Sanctified Myrrh | A | a Divinity spell | advantage | −2 Religion, 1 hour |
| Sands of the Hourglass | A | a cast in combat | +1 AP this turn, once the cast has settled | Slowed 1, 1d4 rounds |
| Spell Incense | A | any | +1 item | −1 Spellcraft, 1 minute |
| Starpetal Oil | B | a spell with a range in feet or a timed duration | range or duration ×1.5 (asked when both could be) | a card: the spell on you at half strength (Q190), the GM's |
| Stormglass Phial | A | a damaging spell | the Electricity trait; +1d6 secondary electricity per 2 PP, scaled by each target's save | Stunned 3 |
| Verdant Sap | A | a Verdant spell | advantage | −2 Nature, 1 hour |
| Void Ash | A | a damaging spell whose type no warp has changed | the damage becomes essence | Soul Drain 1d4 per 2 PP |
| Whisperglass Shard | A | an Ethereal spell | advantage | Confused, 1d4 minutes |

### Blood-etched Vellum, in the ritual

- **The tick:** the Magic Ritual dialog shows a tick for it when you hold one. Ticked, it adds +2 item to the primary's ritual check.
- **Settled once the ritual's roll is**, through TRG Prime's new ritual-rules `settled`: whatever the degree, and whether or not the spell is cast. A Partial that does not cast, and a cast stopped short, are included. It is spent there. Its backlash comes on a Failure or worse.
- **Unticked,** an older plan is cleared, so nothing is ever spent for a ritual it did not help.

## The four catalyst feats (Chapter 5, L4330–4355)

| Feat | Grade | What happens |
|---|---|---|
| **Catalyst Affinity** | A | Read by every backlash (Q191). The backlash's HP damage loses 2 per character level in all, to no less than 0; recurring damage and Bleeding count as HP damage. Soul Drain is unchanged. A duration in rounds is 1 shorter (at least 1), the check penalty that shares Grave Soil's roll included. Stunned 3 becomes Stunned 2. The card shows each cut. |
| **Catalyst Conservation** | A | Once the cast (or the Vellum's ritual) has settled: a DC 15 flat check, rolled and shown. A 15 or better keeps the catalyst. On a Fumble or Blunder it is always consumed, and no check is rolled. |
| **Catalyst Mastery** | A | No backlash on a Failure, and the card says so. A Fumble or Blunder still brings it. Its Catalyst Affinity prerequisite is checked. |
| **Catalyst Crafting** | D | A card. TRG Prime's Create has a fixed list of item types and a catalyst is not one, so make one as a Mundane Item through Crafting, at the catalyst's level and price. Holding the feat, the formula and the materials is the table's to check. **The audit planned a create route (grade B); the core's route cannot add an item type.** |

## The ten special materials (Chapter 6, L4761–4905; H20)

Registered with TRG Prime, so they are chosen as its own are. Their level, the armour and weapon properties the core already knows, Bane-style damage against a kind of creature, and the rune vocabulary per item type (`declaresByType`) are all applied. **What is left to the GM is shown under the item sheet's Material line** (TRG Prime 3.688.0's `note`).

| Material | Level | Applied | Left to the GM (the sheet's note) |
|---|---|---|---|
| Ashbone | +2 | armour and shields half weight; armour ACP −1, Max Dex +1, Speed penalty −5 (Q193); weapons overcome as silver | a weapon's half weight (the core's weapons take no material weight) |
| Bloodglass | +2 | 20% lighter (armour, shields); weapons Serrated; armour +1 item to saves against Essence effects; **it shatters when destroyed**: at a negative HP of half its maximum, once, 1d6 piercing per 2 item levels to every creature within 5 ft., basic Reflex at the item's Level DC (Q194), rolled by the acting GM | a weapon's lighter weight |
| Bloodwood | +2 | weapons Keen; staves and bows +1 Spellcraft as your focus for a Soul or Verdant spell (a tick) | armour and shield CR +1 against essence or poison criticals; wands (charged items carry no material) |
| Eversmoke Cloth | +3 | armour 20% lighter; Stealth penalties −2 (a tick) | cloaks and robes, with their Hide advantage and the whispers (the core's clothing carries no material) |
| Graveiron | +2 | weapons overcome as silver, +1 against undead; armour +1 to Fortitude saves against disease, paralysis or soul drain (a tick) | — |
| Nightsteel | +4 | armour and shield HP +50%; weapons an extra die; armour Stealth penalties −2 (a tick) | hardness; a weapon's AR 2 against magical armour (Q194); a weapon's HP |
| Starion | +4 | armour and shield HP +50% and 20% lighter; weapons a die more against the eternal; armour and shields +1 to saves against Insight effects | hardness; a weapon's HP |
| Sunbronze | +3 | weapons a die more against undead; armour +1 Will against fear (by itself) and against charm (a tick: no core trait); **shields shed dim light (10 ft.) while held** | a shield's full CR against fire criticals (Q194) |
| Tairneach | +3 | weapons +1d6 electricity on a critical; armour +1 to saves against electricity and sonic effects | — |
| Veilglass | +5 | armour and shield HP ×2; weapons a die more against aberrations and the incorporeal; armour and shields +2 to saves against Teleportation or Translocation effects (by themselves) and against a planar or possession effect (a tick) (Q194) | hardness; a weapon's HP |

## For Graham

1. **Q186, two paths not built as ruled.** You ruled catalysts are offered on a ritual (the primary's) and on a charged item's Spellcraft path. The ritual's check is rolled before TRG Prime's cast, so a cast item cannot reach it. Only Blood-etched Vellum, the ritual's own catalyst, is offered there, through the ritual dialog. The charged item's Spellcraft path waits for Block 9c. Do you want any catalyst offered in the ritual dialog too?
2. **Illusion is not a TRG Prime trait.** No core spell carries an Illusion trait, so Moonveil Dust is offered on Enchantment spells only (grade B). Which trait, if any, marks an illusion spell (Shadow?). Charm is not a trait either, so Sunbronze's charm save is a tick.
3. **A cast called off and refunded spends no catalyst.** This was decided in review; the book says only "whether the spell succeeds or fails".
4. **Slowed's clock is one round longer**, so that a Slowed of N rounds costs its AP N times. TRG Prime's own spells that apply a Slowed for N rounds have the same timing, and this release does not change them. It is the core's to decide.

## Known limitations

- **M18:** a catalyst's added damage on a spell with neither an attack nor a save lands in full, with no basic Reflex.
- **Celestial Dewdrop's** "ignores resistance" covers the whole cast's essence damage, not only its own dice.
- **Weapons:** HP and weight take nothing from their material in TRG Prime, so "all items weigh half" or "50% more HP" reaches armour and shields only. Hardness is not modelled.
- **Starpetal Oil** cannot tell a spell whose range a warp has already replaced; its ×1.5 may then do nothing.
- **The implementation matrix** (`ELDRITCH_ARTS_IMPLEMENTATION_MATRIX.md`, generated from the inventory) is not regenerated in this release.

## Fixed in review

An independent review read both releases against the book and the audit. Each finding was fixed before release or is listed above:

- Bloodglass shattered at 0 HP (broken), and again on every later hit. It now shatters when destroyed, once.
- The ritual's Vellum was never settled on a Partial that does not cast. It now settles through TRG Prime's ritual-rules `settled`.
- A refunded cast spent its catalyst and gave Sands' AP on top of the refund.
- A Strike-check cast was offered catalysts that could not reach its check.
- Eversmoke armour had the cloaks' Hide advantage.
- Veilglass lacked Translocation (Q194), and planar and possession effects had no tick.
- Catalyst Affinity missed recurring damage and Grave Soil's penalty.
- Ashen Lotus fell back to essence for a Fire spell with no damage type.
- Frozen Marrow and Void Ash were offered over a warp's type change, which wins.
- Sunbronze could make two lights.
- Starion shields were not lighter.
- The materials' notes were shown nowhere.
- The claims about Illusion and charm were overstated.

## The harness

- **New pair:** `tools/verify-block9a.mjs` (208 checks) and `tools/mutate-block9a.mjs` (88 mutations, all caught). It covers:
  - every catalyst against the book;
  - every answer through TRG Prime's own cleaning;
  - the ten materials through the real core's item quality, rune declarations and rune damage;
  - the pure rules;
  - registration against the real core;
  - the Foundry side with fakes: offers, Starpetal's choice, every backlash shape, Affinity, Mastery, Conservation, the Vellum in the ritual, Bloodglass's threshold and once, and Sunbronze's light.
- **Re-pinned** to 0.13.0 / 3.688.0: `verify-block1`, `2b`, `5d`, `6-lead`, `7`, `8a` and `8b`, and their mutation files.
- **Block 3:** the book's re-cut from v1.6 now prints Storm's cantrip as "Orb of Electricity (0)"; it is given TRG Prime's Orb of Lightning, with the reason on the card.
- **Every module verifier passes, and every mutation file catches all its mutations**, run on the final tree before the zip.
