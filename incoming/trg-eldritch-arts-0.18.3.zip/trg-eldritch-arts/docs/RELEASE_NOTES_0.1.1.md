# Eldritch Arts 0.1.1

29 October 2026. One fix found while live-testing 0.1.0.

- **Install over 0.1.0.** Needs TRG Prime 3.675.0 or later; tested live on 3.675.1.
- **No migration**, and no rules or content change.

## Fixed

**The compendiums sit in one "Eldritch Arts" folder.**
- **The fault:** the manifest declared no pack folder, so the eight Eldritch Arts compendiums appeared loose in the sidebar.
- **The fix:** `module.json` declares a `packFolders` entry named "Eldritch Arts", as Inner Tempest 1.0.4 and Pillars of Faith do. It holds all eight packs in book order: races, heritages, backgrounds, abilities, feats, spells, weapons, gear.
- **When it shows:** Foundry builds the folder when the module is installed or updated. A world that already shows the packs loose may need a reload after the update.

## Harness

- **`verify-block1`:** 870 checks. New: the one folder, every pack in it exactly once, in book order. The system-version check now reads "3.675.0 or later".
- **`mutate-block1`:** 75 mutations, all caught. New: no folder; a pack left out of it.
