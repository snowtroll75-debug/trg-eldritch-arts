# Eldritch Arts 0.10.1

7 November 2026. The findings from 0.10.0's live test (`docs/LIVE_TESTING_REPORT_0.10.0.md`), fixed before Block 8 as Graham asked. Built on 0.10.0, with TRG Prime 3.685.1.

- **Install TRG Prime 3.685.1 first, then this over 0.10.0.** 0.10.1 uses that version's new seams. On anything older the module warns.
- **No migration and no new settings. Loading a world changes nothing on any sheet.**
- **Spirit Arrow, Decoherence and Freshmark already on a sheet** keep asking for a creature target until they are re-added from "Eldritch Arts: Spells" (the mark that stops it is on the pack's copy; nothing rewrites an owned item).
- **Animate Moustache and Bubble Buffet already on a sheet** keep laying Distracted as six "(Distracted)" rows, with no refresh, until they are re-added from the pack: their rows live in the owned item's effects (`system.effects`), which nothing rewrites. Everything else in this release reaches existing sheets as it is.

## Fixed

**1. The "Teleported — Spatial Awareness" card comes with the teleport** (live finding 1: "It appears when Panic Transposition's reaction is cast, before the attack resolves and before any teleport. It also appears when no teleport happens (the bearer dropped to 0 HP). The core posts it for any spell with the Teleportation trait. For Panic it should come with the actual teleport, or not at all.")
- **Before:** TRG Prime posted the card, and stamped the creature's "teleported this turn" record, at the cast of every spell with the Teleportation trait. Panic Transposition's teleport comes after the attack is resolved, so the card came first. When the bearer dropped and never teleported, the card was still there, and the record still made any later teleport that turn fail.
- **Now:** Panic Transposition registers its teleport as later than its cast (TRG Prime 3.685.1's `registerDeferredTeleport`), so the cast posts no card and records nothing. The card and the record come in the bearer's own teleport step, after a successful move. A cancelled pick (Escape), a click too far away, a move the core refuses (the token did not move; found in review), a click on the bearer's own square ("you stay where you are; no teleport is made"; re-review), or a bearer who is down posts nothing. Dimensional Assault's hop says the same for its own square.
- **A second teleport this turn:** Panic Transposition is not offered at all when the bearer has already been teleported this turn, so no PP or reaction is spent on a teleport that would fail (found in review). Should the bearer be teleported between the hit and the attack's resolution, the teleport step still refuses before the square is asked: "a second teleportation automatically fails, and nothing moves". Before, the core's line said so at the cast and the square was still asked for later.
- **The other teleports, checked:**
  - **Dimensional Assault** (Block 4) had the same problem. The core carded it at the cast, before the hop, and also when the hop was cancelled. It is now registered the same way: the card and record come after the hop, before the Strike. A second teleport this turn means no hop and no Strike (Graham's ruling; see "For Graham"). Its +5 PP warp's +5 to the Spatial Awareness check is now laid once the hop has happened, not before the pick, so a refusal, an Escape or a click too far leaves no bonus waiting (found in review).
  - **Mirror Reprise's warp** did not have it. Mirror Reprise has no Teleportation trait, so the core never carded its cast, and its step is a reaction, not a cast. Unchanged (Graham's ruling; see "For Graham").
  - **Dimensional Step** (Block 4) did not have it. It is an ability's Use, not a cast, so the core never carded it. Unchanged.

**2. Spirit Arrow's cast card says the arrow's damage replaces the Strike's** (live finding 2: "Spirit Arrow's cast card says "+6d6 piercing on your next ranged Strike". The damage is flat 6d6 in place of the arrow's, not added to it.")
- **Before:** "ZZ EA Wizard: **+6d6 piercing** on your next ranged Strike." The wording came from TRG Prime's line for every strike rider, which did not read `replacesDamage` or `flat`.
- **Now:** "ZZ EA Wizard: your next ranged Strike deals **6d6 piercing** in place of its damage, with nothing added." The fix is in TRG Prime 3.685.1, so it holds for any replacing rider. Spirit Arrow's row is unchanged. The Strike's damage card was already right.

**3. Spirit Arrow asks for no creature target** (live finding 3: "Its target is "one arrow or bolt", but the cast opens the core's "Select Target" dialog, which warns "no creature will be affected" unless "Continue anyway" is clicked.")
- **Why:** TRG Prime opens the picker for any spell that prints a target (or is an attack), and had no way for a spell to say its target is not a creature.
- **Now:** Spirit Arrow carries TRG Prime 3.685.1's `targetsObject` mark (`flags.trg-prime.targetsObject`). The cast opens no picker, and for the length of the cast the user's targets are released and then put back (found in review), so a creature still targeted from earlier reaches nothing in the cast: not the target count, the range or trait-immunity check, the rows, the cast reactions or the cast's hooks.
- **The other 0.10.0 spells with object targets, checked:**
  - **Decoherence** ("1 unattended object or magical aura") and **Freshmark** ("one object or 5-ft square") had the same problem and carry the mark. Neither lays anything on a target: Decoherence's held bonus is the caster's, and Freshmark is a card.
  - **Drearlight** ("one object or 5-ft square") is unchanged on purpose. Its light is drawn around the token carrying the object, so it does want that token targeted.
  - **Feltwarp** targets "the creature wearing the item", and **Leyline Burst** "1 creature or object". Both still ask, as they may aim at a creature.

**4. Distracted is one effect** (live finding 6: "There is one row per penalty. It works, but the Effects tab is cluttered.")
- **Before:** Animate Moustache and Bubble Buffet laid six effects, each named "Animate Moustache (Distracted)" (or Bubble Buffet's): one for attacks, one for the skills, one for each save and one for Spellcraft.
- **Now:** one effect named **Distracted**, carrying all six −1 status changes (one per skill the creature has, for the skills), with the spell's duration and the cast's id, so it ends with the spell. This uses TRG Prime 3.685.1's bonus group (a `bonus` row's `slots`).
- **One Distracted per spell and caster.** A caster's second Distracted from the **same** spell replaces their first. One from the **other** spell, or from **another caster** of the same spell, stands beside it, as its own single effect (found in review and re-review: two casters' Animate Moustache would otherwise share one effect, and dismissing one would strip the other's minute; a shared refresh let Bubble Buffet's "until the end of its next turn" cut Animate Moustache's minute short, and dismissing one spell would end the Distracted the other still supplied). Two of them never make −2: TRG Prime's stacking rule keeps only the worst status penalty on each pool (attacks, every skill, the three saves and Spellcraft alike), so the penalty stays −1. The replacing effect is created before the old one is removed, so a failed write loses nothing. Bubble Buffet's turn ladder replaces its own result each turn, as before.
- **The roll's modifier line** now reads "Distracted Status −1" (before, "Animate Moustache (Distracted) Status −1"). The Effects tab's origin column still names the spell.
- **Example:** Animate Moustache fails its save, then Bubble Buffet's Partial lands a round later. Before: twelve rows. Now: two "Distracted" effects, one from each spell, each lasting and ending with its own spell; the penalty is −1.

**5. The landing prompt stays until you click** (live finding 7: "It is a brief notification, and the next canvas click picks the square.")
- **Before:** a notification that faded after a few seconds. A player who missed it did not know the next click on the map would pick the square.
- **Now:** a permanent notification, removed when the square is picked, when Escape cancels, or when the canvas is torn down (a scene change; found in review), which also ends the pick. It names the spell, the range in feet and the way out: "Panic Transposition: click the square where you land, up to 30 ft away. Escape cancels."
- It is the shared helper (Block 3's `pickPoint`), so it reaches every teleport in the module: Panic Transposition and Mirror Reprise (Block 7), Dimensional Step and Dimensional Assault (Block 4, whose own `teleportWithin` now uses the same sentence), Gale Step, Astral Step, Elemental Step and Fade Step.

**In TRG Prime 3.685.1 alone** (live finding 4): the coldfire condition's name now reads "Recurring Damage 16 (Coldfire)", as the force one reads "Recurring Damage 24 (Force)". Nothing changes in the module.

## Not changed

- **Live finding 5** (a self-range spell refused while a token is targeted: "ZZ EA Foe is 30 ft away — beyond Mirror Reprise's range of self") was not on the fix list. It is the core's behaviour from before this release, and it still happens for self-range spells. See "For Graham".

## For Graham

- **Found in review and fixed before release:** Distracted's refresh crossing spells and casters (now one per spell and caster, created before the old one is removed); the existing-sheet note for Animate Moustache and Bubble Buffet; a vetoed Panic move carded as a teleport; Panic offered (and paid for) when its teleport would fail; Dimensional Assault's +5 laid before the hop; a stale creature target reaching a `targetsObject` cast; the landing prompt outliving a scene change. The replacing rider's card still drops an "against …" clause; nothing combines the two today.

- **Graham's rulings, 7 November 2026** ("Happy with your suggestions for all 3"):
  - **Dimensional Assault on a second teleport this turn:** no hop and no Strike, with a card saying the teleport fails. Kept as built.
  - **Mirror Reprise's warp step** posts no Spatial Awareness card and records no teleport, since the spell has no Teleportation trait. Kept as built.
  - **Live finding 5** (a self-range spell refused while another token is targeted) stays as it is in the core.
- **The caster's own "one Teleportation action per turn"** (`traitUsage.teleportation`) is still counted at Panic Transposition's cast. Casting it is the action, so this reads as right; the record of *being* teleported is the one that waits for the move.
- **Re-adding the three object-target spells:** an owned Spirit Arrow, Decoherence or Freshmark made before 0.10.1 still opens the picker. Re-add it from the pack. Nothing rewrites an owned item at load.

## Harnesses

- **`verify-fixes-0101` (new, 30 checks)**, driven with the real TRG Prime: its deferral registry and teleport rule, fed the module's own registrations and spells; Panic's teleport step and Dimensional Assault's post-cast step run, with the core's card and `teleportedTurn` checked after the move, nothing on Escape, and a second teleport refused before the pick; Mirror Reprise and Dimensional Step confirmed as no Teleportation casts; Spirit Arrow's shipped row through the core's rider line; the object marks and the core's target rule over the six 0.10.0 object or object-or-creature spells; Distracted through the core's real spell engine (one effect, a second refreshing it); the landing prompt's permanence, its removal on a click and on Escape, and its sentence.
- **`mutate-fixes-0101` (new):** 31 mutations, all caught.
- **The review's findings, covered:** a vetoed Panic move (T6b), Panic not offered when its teleport would fail (T9), Dimensional Assault's +5 only after the hop, and none on an Escape or a click too far (T7b, T8, T8b), one Distracted per spell and a same-spell refresh (D3, D3b), the pick ended by a torn-down canvas (P2b, P2c), and, from the re-review, a click on your own square (T6c, T8c). Each has its mutation, all caught.
- **`verify-block7`:** the three Distracted checks read the one row (B), and F asks for TRG Prime 3.685.1.
- **`mutate-block7`:** "the teleports have no distance cap" re-anchored on the cap's own line (the vetoed-move check now follows it); all 216 caught.
- **Run (after the re-review's fixes):** all 20 verifies pass (4,995 checks) with `TRG_PRIME_ROOT` and `EA_BOOK_MD`; all 20 mutate files run in scratch copies, 2,000 mutations, all caught.
- **`verify-block6-lead`:** C and G pin 0.10.1 and TRG Prime 3.685.1.
- **Mutate anchors re-pointed:** the manifest's version (0.10.1) in `mutate-block1`, `-block2`, `-block2b`, `-block3`, `-block3b`, `-block4` and `-block6-lead`; `REQUIRED_SYSTEM` (3.685.1) in `mutate-block1`, `-block2`, `-block2b`, `-block6-lead` and `-block7`; the manifest's minimum in `mutate-block1`.
