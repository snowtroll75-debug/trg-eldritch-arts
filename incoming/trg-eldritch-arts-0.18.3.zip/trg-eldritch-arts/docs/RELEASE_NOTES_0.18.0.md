# Eldritch Arts 0.18.0: Block 11, the Feat Additions

25 November 2026. **Previous version: 0.17.3** (the live install). Document ids of every existing record are unchanged.

## What you need

- **TRG Prime 3.713.0** for everything. This Core release is prepared separately and not published.
  - It adds two seams: C-EA11-1 (a weapon's temporary enhancements) and C-EA11-2 (crafting time). See `docs/ELDRITCH_ARTS_BLOCK11_AUDIT.md` §4.
- **On TRG Prime 3.712.4** the module installs and runs. The differences:
  - A **weapon's** modular upgrade and an overclock are recorded and printed, but the GM applies them.
  - Tinkerer Precision changes nothing; the GM applies it by hand.
  - Everything else works.
- The manifest minimum stays **3.694.0** (verified on 3.713.0).

## The seventeen feats

The insertion document is the source of every card. Each card carries the printed text verbatim, then one paragraph saying what TRG Prime does with it.

**Artificer class feats.** Each is gated on the Core's own Artificer archetype by its trait.
- Modular Design
- Advanced Design
- Integrated Modularity
- Mechanised Assistant
- Overclocked Weaponry
- Power Sink
- Instability Harness
- Emergency Contraption
- Flash of Insight
- Tinkerer Precision

**Runemage class feats.** The five v1.6 Runemage feats are untouched.
- Runic Anchor
- Triggered Sigil
- Grand Inscription

**Ascendan racial feats.** These sit on the Core's Ascendan race (`sourceRace`).
- Ley Resonance
- Arcane Preparation
- Heritage of the First Weave
- Perfected Arcane Memory

**Supporting abilities.** These go in Abilities and are never offered as feats.
- **Quick Swap** (Manipulate, Prepared; 2 AP), granted by Integrated Modularity.
- **Mechanised Assistant Frame**, the printed companion profile, placed on the assistant.
- The assistant's three own improvements: **Reinforced Frame**, **Storage**, **Reactive Protocol**.

**The Prepared trait** is registered and defined on every card that has it.
- **Recharge:** 3 AP (in combat), a Crafting check against the level DC; Success or better replenishes.
- **Or it recharges by itself** ten minutes of world time after it was spent.
- **State:** stored on the item, so it survives reloads.

## Status of each feat

Nothing below has been live-tested in Foundry yet; see the plan at the end.

- **"Rules and seams harness-tested"** means its arithmetic and its Core seams pass `verify-block11` and `mutate-block11` against the real Core functions.
- **"GM steps"** means part of it is a card for the GM to act on.

| Feat | Status | Pending ruling |
|---|---|---|
| Modular Design | Automated (armour, shields, tools on 3.712.4; weapons need 3.713.0). Rules and seams harness-tested. | — |
| Advanced Design | Automated, one shared allowance; the 10-minute swap. Harness-tested. | A11-1 (how many +1s) |
| Integrated Modularity | Automated (+3 budget), grants Quick Swap. Harness-tested. | A11-2 |
| Quick Swap | Automated: 2 AP, Prepared, moves without duplicating. Harness-tested. | — |
| Mechanised Assistant | **Partly automated, GM steps.** Built as a linked familiar: profile, Slam, Darkvision, class skills, specialty, improvements, Storage, Tool Armature adjacency, Relay Node offer, construct healing refusal, rebuild. | A11-7 (rebuild gold), A11-8, A11-13 |
| Overclocked Weaponry | Automated on 3.713.0: Plasma Edge's packet, Gyroscopic's −1 Load, Impact's +1. Harness-tested. | A11-12 |
| Power Sink | Automated: save reroll and Resonance redirect; overload switches the item's effects off. Harness-tested (rules). | A11-5; the use-refusal gap |
| Instability Harness | Automated (adds Fumble and Blunder). | — |
| Emergency Contraption | Automated for a failed Disable Device check (+2 item on the reroll only). **GM step** for a trap with no check. | A11-10 |
| Flash of Insight | Automated with a **GM step** (the description). Natural 20 by the Core's open-ended chain; once a day. | A11-3, A11-4 |
| Tinkerer Precision | Automated on 3.713.0: time at +2 ranks and 75% value; cost and check unchanged. Harness-tested against the Core's Create maths. | — |
| Runic Anchor | Automated: asks which Symbol-cast spell; +2 class only for that. | — |
| Triggered Sigil | Automated for "struck" and "targeted"; manual activation (same checks) for other triggers. | A11-9 |
| Grand Inscription | Automated: save DC +1 → +2 on Symbol casts (one part); identify +2 → +4, restored on retraining. Harness-tested with the Core's `assembledSaveDC`. | — |
| Ley Resonance | Automated as a Focus metamagic: −1 PP (−2 with Memory), casting DC with it, Save DC untouched. Harness-tested with the Core's `castingDC`. | A11-14 (the brief's other text) |
| Arcane Preparation | Automated: +2 circumstance once; lost on another spell, Unconscious or the end of the next turn. | — |
| Heritage of the First Weave | Automated: reaction + Focus, +2 circumstance; Forbidden Magic untouched. | — |
| Perfected Arcane Memory | **Partly automated, GM steps:** traces recorded; the GM confirms the trace and sets the normal DC; +5 added; reveals by degree; never the caster. | — |

## Tests run (25 November 2026)

| Suite | Result |
|---|---|
| `verify-block11` (new) | **366 checks, all pass** |
| `mutate-block11` (new) | **54 of 54 mutations caught** |
| `verify-ea11-seams` (Core 3.713.0, new) | **26 checks, all pass** |
| The module's 31 verify harnesses | 30 pass. `verify-block10` fails with the same TypeError at line 344 it had on 0.17.3 (unchanged; noted in 0.17.3's notes) |
| The module's 30 mutate harnesses | 27 pass. Three fail exactly as before Block 11: `mutate-block10` (depends on `verify-block10`), `mutate-block10b` (the same 2 of 25 survivors as 0.17.3's baseline), and `mutate-book-extract`, which needs the v1.6 source docx (not in this workspace) |
| `verify-packs-compiled` | 675 documents in 16 packs, compiled as packs-source holds them |
| TRG Prime full sweep (`tools/verify.mjs`) on 3.713.0 | see the summary below |

**Earlier harnesses were extended, not loosened.**
- `verify-block1`, `verify-block2`, `verify-block2b` and `verify-block6-lead` pin their own blocks' registrations.
- Each now excludes Block 11's additions by name, with a comment, as earlier blocks did.
- Eight mutation files were re-anchored to the extended `PACKS` line.
- Version pins were moved to 0.18.0.

## Manual Foundry tests (not yet run)

Run these in the **Test** world, on TRG Prime 3.713.0, after Graham installs both.

1. **Modular Design.**
   - Artificer with Crafting 4: daily preparation, then Use. Pick a sword's attack.
   - Attack with the sword: "Modular upgrade +1" is an item row. Attack with a dagger: no row.
   - With Potency I on the sword: still +1 in all.
2. **Armour and shield.**
   - Put the upgrade on worn armour's DB: DB +1. Unequip the armour: the bonus is gone. Re-equip it: it is back.
   - Damage the armour to half HP: the bonus is gone.
   - Drop the item from the inventory: the upgrade leaves the actor's list.
3. **Tool.**
   - Upgrade a held tool on Crafting: the Crafting check shows the pre-ticked +1. Stow the tool: no row.
4. **Advanced Design / Integrated Modularity.**
   - +1 and +1 on two items is accepted; +2 and +1 is refused (Advanced).
   - The 10-minute swap is refused in combat and works out of combat.
   - Quick Swap in combat: AP 2 spent; Prepared expended. The Use offers the recharge; roll it.
   - Advance world time 10 minutes: Quick Swap is ready again.
5. **Overclocked Weaponry.**
   - Plasma Edge (fire) on a bow: the hit shows a 1d4 fire secondary packet against resistances.
   - Gyroscopic on a Load 2 crossbow: reload costs 1 AP.
   - Impact: damage +1.
   - Daily preparation clears all three.
6. **Power Sink.**
   - An ally within 30 ft fails a Will save against a spell: you are asked. Pick a runed or worn wondrous item.
   - The save is rerolled. The item's effects stop until the end of your next turn.
   - A Fumble without Instability Harness: not asked. With it: asked.
   - A Resonance Event in range: asked; "No Resonance event" names the item.
7. **Emergency Contraption.**
   - A failed Disable Device check: the reroll card shows "+2 item" on the second roll only.
   - The trap case: the GM card.
8. **Flash of Insight.**
   - An ally fails a skill check within 30 ft: the description prompt appears.
   - The roll becomes 20 plus the chain; the degree is recomputed.
   - A second failure the same day: not asked.
9. **Tinkerer Precision.**
   - Start a Create project for a 400 gp item at 10 ranks: the card reads "time read at +2 ranks and 300 of 400 gp; the materials still cost 400 gp".
   - Days fall; the check's DC is unchanged.
10. **Mechanised Assistant.**
    - Use: name the form, pick Tool Armature.
    - The familiar actor is Small with Str 0, Dex 1, Con 1, Int 0, Wis 2, Cha −2, speed 20, Darkvision, a Slam (Small) 1d6, Base DR 2, and Crafting and Perception as class skills.
    - Move it adjacent: the master's Crafting gains +2 item. Move it away: gone.
    - At level 4: the Use offers one improvement.
    - Storage: an 11 lb item onto it is refused.
    - Cure Light Wounds on it: the healing is taken back.
    - Rebuild: no gold is taken.
    - An ordinary familiar on another character is unchanged.
11. **Runic Anchor.**
    - Cast a verbal spell as a Runemage; take damage; roll Spell Concentration.
    - Pick that spell: +2 class. Pick "another": nothing.
12. **Triggered Sigil.**
    - Inscribe sigils; Use: designate Shield on "targeted by an attack".
    - An enemy attacks: the defence offer lists Triggered Sigil, and the reaction casts it (PP spent, no AP).
    - Once a round: a second activation is refused.
    - With Living Script it reforms as a plain sigil.
13. **Grand Inscription.**
    - Cast a save spell with Symbol: the Save DC parts show Runemage +1 and Grand Inscription +1.
    - Runemage's Use queues +4 (not +2). Delete the feat: the queue reads +2.
14. **Ley Resonance.**
    - Within 60 ft of a ley line Region: the Warp? dialog offers it. PP paid −1; Casting DC lower; Save DC unchanged.
    - Refocus restores the use.
15. **Arcane Preparation.**
    - Use (1 AP) on an arcane spell: +2 circumstance on its check.
    - Cast another spell first: lost. Fall Unconscious: lost.
16. **Heritage of the First Weave.**
    - An Ascendan saving against a Bless-type divine effect: asked. +2 circumstance; Forbidden Magic's −2 still shown.
17. **Perfected Arcane Memory.**
    - Let an arcane buff end. Use: the GM picks the trace; set DC 20; the roll is against DC 25.
    - A Critical gives "how long ago" and a direction. The caster is never named.
18. **Regression.**
    - An ordinary Artificer and Runemage (no new feats): unchanged.
    - Prepared Sigil, Combat Inscription, Ley-Etched Symbol, Runic Reservoir and Living Script: as in 0.17.3.
    - An ordinary familiar and an animal companion: unchanged.
