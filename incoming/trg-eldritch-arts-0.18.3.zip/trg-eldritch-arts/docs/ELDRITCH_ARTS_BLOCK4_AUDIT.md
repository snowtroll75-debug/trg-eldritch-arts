# Eldritch Arts Block 4: audit (Spellblade, Warlock)

3 November 2026. Block 4 covers Chapter 3's last two classes and the specialist spells only they use. It was read against:
- ***TRG Prime: Eldritch Arts* v1.6** (`ea.md` and its sidebars);
- **Graham's rulings** of 1 November 2026: C2, M13, M14, M17, M19, M26 and M28;
- **TRG Prime 3.681.1**, surveyed in its source. Each "the core has" claim below was read there.

**Status: answered by Graham, 3 November 2026, 17:14; built as Eldritch Arts 0.7.0 on TRG Prime 3.682.0 the same day (`RELEASE_NOTES_0.7.0.md`).**
- **Q36, Q45, Q46 and Q48:** as proposed ("Yes", "correct").
- **Q37, changed:** "All warlock spells are innate and focus and must be refocused per spell. Warlock cantrips also have the focus trait." The cantrips are therefore Focus too, one use each until Refocus.
- **Q43:** "half damage for any taken from poison or disease (so any damage sustained from a disease would also be halved)". So Natural Resilience is resistance to poison damage and to damage from a disease, whatever its type. Advantage on saves is not part of it.
- **Q38–Q42, Q44, Q47 and Q49–Q52:** not answered, so they are built as proposed, and each is easy to change.

Also from Graham: the unwilling touch "should always miss on a 1 and hit on a 20" (TRG Prime 3.682.0). He updated the system to 3.681.2 (the weapon damage card names the creature that took the damage), and this block builds on it.

## Scope

| Group | Book | What it is |
|---|---|---|
| **Spellblade** | L1172–1276 | Martial. Light armour; simple and martial weapons. HP 10 + Con; 4 + Int skills; seven class skills plus the path's two. Infuse Weapon, Battle Mage, Transcend Armour and a class feat at 1st, then a class feat at 5th and every 5 (M17: Spellblade or Martial). A semi-learned caster of one tradition, the path's: four PP 2 spells at 1st; memorise **level + 1** after half an hour with the Book of Infusions; one spell of the tradition a level, PP no higher than CL + 1 (M13). The path's ability adds to Spellcraft and PP. The path spell is in the book and needs no memorising. No cantrips. Table: BAB/BDB = level; Fort and Will 5 + level; Ref 2 + level; CL = ⌈level/2⌉; PP = level; BSB = ⌊level/2⌋. |
| **The four paths** | L1280–1394 | Each sets a key and magical ability (min +2), two bonus class skills, a special ability and a path spell. **Arcane Duellist** (Int; Arcana, Linguistics): Arcane Echo and Shooting Star. **Divine Arm** (Wis; Religion, Sense Motive): Sacred Channel and Shielding Strike. **Ethereal Strider** (Cha; Occultism, Stealth): Dimensional Step and Dimensional Assault. **Verdant Warden** (Con; Nature, Survival): Natural Resilience and Thunderous Strike. |
| **Infuse Weapon, Book of Infusions** | L1210–1222; sidebar 7 | At daily preparation (1 minute), one melee weapon becomes magical for overcoming resistances. From 2nd, learned runes are infused, their total level no more than the Spellblade level (M14). Runes are learned into the book "using rules for learning spells", and work only while the Spellblade wields the weapon. The book "functions like a spellbook" that also holds runes. |
| **Warlock** | L1396–1638 | Adept, Expert. Light armour; simple weapons. HP 8 + Con; 6 + Int skills; ten class skills plus the bonded soul's two. **Xithra**, the **bonded soul**, and a class feat at 3rd and every 3 (Warlock, Adept or Expert). **No PP pool**, and every spell is innate with the Focus trait: one at 1st, one more at 3rd and every 3, all High Magic. The Shadowed Grimoire feat adds more (Block 6); Magical Discovery is barred (M19). Charisma is the magical ability, with no Spellcraft. **One hex** at 1st, as an innate Focus spell; more come through the core Specialist Spell feat (M28). **Two cantrips** of any tradition, as High Magic innate spells. Table: BAB/BDB ¾; every save 2 + level; no CL, PP or BSB. |
| **Xithra** | L1430–1438 | Attack Focus Magical Mental, 1 AP. A target you can see within 30 ft: 1d6 base mental, plus Charisma as bonus damage, plus a die at 4th and every 4. "Considered to be an innate spell for casting purposes." |
| **The eight bonded souls** | L1470–1612 | Each gives two bonus class skills, a damage type Xithra may deal instead of mental, its available traditions, and a +1 level for named traits or schools. Most also give a once-a-day rider on Xithra: Cure at 0 AP (Celestial Sentinel); Blindness on a hit (Crystal Archon); 1d6 recurring fire on a hit (Emberlord); Idiocy on a hit (Infernal Tempter); Fear on a hit (Pale Reaper); Slow on a hit (Verdant Spirit Walker); innate Misty Step at 0 AP (Whispered Sage). The Void Seer has no rider. |
| **Sidebars** | 7, 8, 9, 16 | **7:** the Book of Infusions. **8:** "your Warlock level is considered to be your caster level to determine if you are able to use a specific spell". **9:** Nyrrin Warlocks. **16:** the core class feats the classes gain: Spellblade Assess Target, Combat Awareness and Disrupting Stance; Warlock and Witch Familiar, Injury Relief and Versatile Familiar; Archmage Familiar and Versatile Familiar. |
| **Specialist spells** | L8253, 8631, 8643, 8681, 8777 | **The four path spells:** Shooting Star, Shielding Strike, Dimensional Assault, Thunderous Strike. **Spinning Weapon,** the fifth Spellblade-trait spell, which the core Specialist Spell feat opens. |
| **Class wealth** | Chapter 6, L4760 | Spellblade 2, Warlock 1. |

**Not in this block:**
- The class feats that name these classes: Xithra Cone, Spear and Recovery, Warlock's Hex, Pact Channeler, Arcane Fencer and the rest. They are Block 6, where EA-C2 (the Warlock's PP) also matters.
- The archetypes: Runeblade, Spell Duellist and the Pacts (Block 6).
- Shard Cloud (Ferromancer, Block 6) and Ley Walker (EA-C7).

## What TRG Prime 3.681.1 has, and what it lacks

| Need | The core today | Gap |
|---|---|---|
| **Class tables, abilities, feats** | `registerClass`, class items with `classType`, the table columns (`class-progression.mjs:42`), `abilityChoices` for a subclass (as the birthrights), `registerFeatAccess("class", …)`. | None. Sidebar 16 needs only `registerFeatAccess`; Block 3 did not do it for the Archmage and Witch, so it is done here for all four classes. |
| **The Spellblade's book** | A learned book with `spellBookFirstPicks` (four PP 2 picks work as printed), `classMagic.bookPerLevel`, and PP ≤ CL + 1 for picks. | **Memorising level + 1 is not possible.** The budget is hard-coded at 2 + 2 × level (`memorisation.mjs:67`). |
| **The path spell without memorising** | Specialist spells are cast through `registerSpecialistAccess`, as Block 3 did. | None. |
| **Battle Mage** | `attackBase` exists only on weapons, and only to swap BAB for BSB (`attack-base.mjs:19`). Spell attacks are the casting roll. A spell-check gate row moves the casting degree too (there is `castingOnly`, but no "attack only"). | **A spell attack can't use BAB in place of BSB.** |
| **Infused runes** | A rune is text in a weapon's `system.runes`, capped by the weapon's grade (`magic-item-tables.mjs:187`), and potency comes first. Blade Ally's one-rune exemption is the only temporary rune. Spellbooks hold spells only. | **No temporary, wielder-only runes.** Nor do runes have the "learn" flow the book needs, which the module can keep itself. |
| **Warlock innate spells** | Innate attack is ability + level, and the DC 10 + ability + level (`innate-printed.mjs:38/45`). No PP; a free warp budget by level. Base PP is capped at level + `innatePPAllowance`. The Focus trait is one use, restored by Refocus or daily preparation (`uses.mjs`, `refocus-workflow.mjs`). | **No innate repertoire picked on a schedule:** `chooseSpell` replaces the earlier pick. **No "treated as one level higher" by trait or school.** |
| **Xithra** | An innate attack spell item with `casterLevelMods` scaling works today. Damage-type choice is a spell mode. On-hit riders go through `trgPrimeStrikeResolved`, and spell results through `trgPrimeSpellSettled`. | None that blocks; the module builds Xithra and its riders. |
| **Spells that make a Strike** | `rollWeaponAttack` (a helper) with `apPaid`, `extraModifiers` and `beforeDamage`; Blade-style "a Strike carries a spell" (`carried`). `strikeEdge` ignores concealment. Strike riders (`strikeRider` effects, `once`) work today. | `castSpell` is not on the module API. **Nothing uses a Strike's roll as the casting check** (Thunderous Strike). **No way to reduce cover by a degree** (Shooting Star). A melee Strike at 30 ft has no supported option. |
| **One-shot bonuses** | Conditionals with `checkTypes: ["attack"]` and `["damage"]`, `oneShot`. Strike riders. | None. |
| **Teleport** | Gale Step (Block 3) teleports through the token update. The core refuses an occupied end square. | None. |

## Proposed seams (TRG Prime 3.682.0)

1. **`classMagic.memorisedPerDay`:** `"2+2L"` (the default) or `"L+1"`, read by `memorisationState`. It is the Spellblade's (D4, finished).
2. **Spell attack base** (D17, extended):
   - `flags.trg-prime.spellAttackBase: "bab"` on a class ability. Attack-trait spells' attack totals then use BAB in place of BSB.
   - The casting check and its degree are untouched; only the attack total moves.
3. **`registerInnateLevelBonus(key, ctx => n)`** (D9). It is read by the innate attack, DC, warp budget and PP limit, with `ctx` giving the spell's traits and school. It serves the bonded souls' "+1 level".
4. **Wielder-scoped infused runes:**
   - `flags.trg-prime.infusedRunes = {weaponId, runes: "…", day}` on the actor. The rune readers (`runeBonusesFor`, `runeDamageFor`, the rune strike riders, and the magical-for-resistances test) add them when that actor attacks with that weapon.
   - They don't count against the weapon's own rune allowance or potency rule (Q45).
5. **A Strike inside a spell:** `helpers.castSpell(actor, spell, options)` on the API, and an option `strikeAsCheck` for Thunderous Strike. That option takes a Strike's total as the casting check's total.
   - **A reach override** for Shooting Star's melee arc at 30 ft.
   - **A cover-degree step** on `strikeEdge` (`reduceCover: 1`), read where the target's Take Cover level is.

## Proposed builds (Eldritch Arts 0.7.0)

- **The two classes:**
  - class items with the printed tables, proficiencies, skills and wealth;
  - **the path and the bonded soul** as `abilityChoices` subclasses, as the birthrights were;
  - sidebar 16's feat access, for all four classes.
- **Spellblade:**
  - **The book:** four PP 2 picks; one a level; the path spell always castable through specialist access; memorise level + 1.
  - **Battle Mage** through the new spell attack base.
  - **Transcend Armour** granted at 1st.
  - **Infuse Weapon:** a daily-preparation prompt to pick the weapon and runes from those in the book, within the level budget. It writes the infused runes.
  - **The Book of Infusions:** a "Learn a rune" action using Learn a Spell's time, price and check (Q46).
- **The paths:**
  - **Arcane Echo:** after a spell settles, a one-shot +1 circumstance to the next melee attack and its base damage, ending at the start of the next turn.
  - **Sacred Channel:** offered after a weapon hit: 1 PP to heal 1d8 (more at 5th and every 5).
  - **Dimensional Step:** a teleport, as Gale Step.
  - **Natural Resilience:** as Q43 rules; +1 HP a level.
- **The five spells:**
  - **Shooting Star:** the Strike, at 30 ft for a melee weapon, ignoring concealment and stepping cover down. A lingering mark lets allies do the same until the start of the caster's next turn.
  - **Shielding Strike:** the Strike, then +2 status DB until the start of the next turn (warps up to +5).
  - **Dimensional Assault:** the teleport, then a 0 AP Strike; Spatial Awareness after it (warp +5).
  - **Thunderous Strike:** the Strike as the casting check, then a 15-ft cone behind the target, basic Fortitude, 1d6 secondary sonic (warps).
  - **Spinning Weapon:** a one-shot strike rider of the chosen type (warps for dice and for force or sonic).
- **Warlock:**
  - **The innate repertoire:** one spell at 1st and one at 3rd and every 3, each made an innate Focus High Magic copy on the sheet. Spells come from the bonded soul's traditions, PP no higher than level + 1 (sidebar 8; Q38).
  - **The hex at 1st and the two cantrips,** the same way.
  - **Xithra** as an innate attack spell, with its dice by level, the bonded soul's damage type and its daily rider.
  - **"+1 level"** through the new innate level bonus.

## Rulings needed

| # | Question | Proposed |
|---|---|---|
| **Q36** | **The Focus trait on the paths' abilities:** Arcane Echo (Focus Invocation), Sacred Channel (Focus Healing Soul), Dimensional Step (Focus Teleportation). In the core, Focus is one use, restored by Refocus or daily preparation. | **As the core:** each is one use, restored by Refocus or daily preparation. So Sacred Channel heals once per Refocus, not on every hit. |
| **Q37** | **The Warlock's spells are innate Focus:** one use each until Refocus. Xithra too (Xithra Recovery's "twice before having to use the Focus action" confirms it). And the two cantrips? | **Spells, hex and Xithra:** one use each, as the core. **Cantrips:** the text says "High Magic innate", without Focus, so **at will**. |
| **Q38** | **Which spells a Warlock may pick** (sidebar 8: Warlock level is the caster level). | **Base PP no higher than Warlock level + 1,** as for any caster's CL + 1. The traditions are the bonded soul's. |
| **Q39** | **"Treated as one level higher when using spells with the X trait or of the Y school."** | **+1 to the innate level for those spells:** attack, DC, the free warp budget and the PP limit, so also which of them may be picked. The core has no such seam (seam 3). |
| **Q40** | **High Magic on an innate spell.** It has no casting check, so High Magic's casting DC +2, fumble and resonance never come up. | **The spell is tagged High Magic** (identification Very Hard; anything that reads the tag), and nothing about a casting check applies. |
| **Q41** | **The bonded soul's daily rider.** | **Once a day,** reset at daily preparation. It is **offered when Xithra hits** (Blindness, Idiocy, Fear, Slow, the 1d6 recurring fire). For **Cure** and **Misty Step,** it is offered when Xithra is used. Each spell is cast at its base PP, as an innate spell at the Warlock's innate level and DC. Cure's "within its range" is Xithra's 30 ft. |
| **Q42** | **Xithra's dice.** "An additional die of bonus damage" at 4th and every 4. | **+1d6** each time: 1d6 + Cha at 1st, up to 6d6 + Cha at 20th. The damage type is chosen at each use (the bonded soul's or mental). |
| **Q43** | **Natural Resilience: "resistance to disease and poison".** In the core, resistance halves damage, and disease is not damage. The core's own wordings for saves are bonuses or advantage (Dwarf "+2 racial against poison", "advantage on all saving throws against disease"). | **(a)** Resistance to poison damage, and nothing for disease. **(b)** Resistance to poison damage, plus advantage on saves against disease and poison. **(c)** Only advantage on those saves. **Proposed: (b),** as an interpretation for you to confirm. |
| **Q44** | **Infuse Weapon's "magical for the purpose of overcoming resistances".** | **The weapon's damage counts as magical** (against non-magical DR and resistance) while the Spellblade wields it, for that day. |
| **Q45** | **Infused runes and the weapon's own runes.** Only the level budget is printed. | Infused runes **don't count against the weapon's rune allowance and need no potency rune first.** The total level is no more than the Spellblade level. If a rune is both on the weapon and infused, the higher tier applies. |
| **Q46** | **Learning a rune "using rules for learning spells".** | **Learn a Spell's time, price and DC, with the rune's level in place of the spell's PP.** The check uses the path's tradition skill. A Spellblade starts with **no runes**; none are printed. The Runeblade archetype (Block 6) adds some. |
| **Q47** | **A path spell's Strike** (Shooting Star, Shielding Strike, Dimensional Assault). | **The casting check first.** On a Success or better the Strike is made as part of the spell, at no further AP. It counts for the multiple attack penalty as a Strike normally does. On a failed cast there is no Strike. |
| **Q48** | **Thunderous Strike: "use the result of this check as your spellcasting check".** | **One roll, the Strike.** Its total is the attack against the target's DB and also the casting check against the casting DC. The cone needs a cast of Success or better and uses the spell's save DC. The target is in the weapon's range. |
| **Q49** | **Shooting Star's lingering trail:** "all attacks made against that creature by any ally gain the same benefits". | **Allies' attacks against that creature** ignore its concealment and step its cover down one degree, until the start of the caster's next turn. |
| **Q50** | **Arcane Echo:** "after casting a spell". | **Any spell cast successfully, cantrips included.** The next melee attack before the start of your next turn gets +1 circumstance to attack and +1 to base damage. The bonus is spent on that attack, hit or miss. |
| **Q51** | **Dimensional Step's range:** "10 ft per 2 levels (minimum of 10 ft)". | **10 × ⌊Spellblade level ÷ 2⌋ ft, at least 10.** No Spatial Awareness check, as for Gale Step (it isn't a spell). |
| **Q52** | **The Warlock's PP** (your C2 ruling) against "you do not possess a pool of PP" (L1450) and sidebar 9. | **A pool of Charisma PP only,** as C2 says. Spells never spend it; Block 6's feats will. Sidebar 9 is read as describing the lack of a class PP column. |

| **Q53** | **Battle Mage and the maneuver spells** (raised by the review of 0.7.1): Tanglefoot, Spectral Grasp, Telekinetic Manoeuvre and Tangling Creepers' vine use a Spellcraft check as the maneuver; no spell attack is rolled. | **Graham, 3 November 2026: "Yes it should".** The maneuver's Spellcraft check takes BAB in place of BSB when BAB is the higher (TRG Prime 3.682.2). |
| **Q54** | **Battle Mage and Spiritual Weapon's strikes** (Spellcraft, a utility spell with no Attack trait). | **Graham, 3 November 2026: "Leave as is".** No Battle Mage. |

| **Q55** | **Battle Mage on an attack spell read from a scroll or wand** (raised by the review of 3.682.2). Its attack is the release check, and Battle Mage skips item casts. | **Graham, 3 November 2026: "leave as is".** No Battle Mage on an item cast. |
| **Q56** | **The multiple attack penalty on a maneuver spell's check** (raised by the same review). It neither took the penalty nor counted toward it. | **Graham, 3 November 2026: "It should not ignore MAP".** It takes the penalty its action would and counts toward the next attack (TRG Prime 3.682.3). One cast against several creatures uses one count for all of them, as a spell volley does. |

## Plan

1. **TRG Prime 3.682.0:** seams 1–5, with a harness pair.
2. **Eldritch Arts 0.7.0:** the classes, paths, souls, Xithra, the five spells, the book and Infuse Weapon, with a harness pair.
3. **Then the usual steps:** the sweep, an independent review, the zips, Graham's install and a live test.
