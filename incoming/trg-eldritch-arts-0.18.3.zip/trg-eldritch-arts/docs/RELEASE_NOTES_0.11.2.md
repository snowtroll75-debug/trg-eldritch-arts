# Eldritch Arts 0.11.2

9 November 2026. The Harmonic Rift fix that 0.11.1 got wrong, found by the live recheck in Graham's world (Foundry 14.367, TRG Prime 3.686.0). Install over 0.11.1. TRG Prime stays 3.686.0. No migration, no new settings, and no change to any pack.

## The real cause

Logged inside Foundry V14's `updateToken` hook during a normal animated move: **the token document still holds its OLD x and y; the hook's `change` holds the new ones.** 0.11.1 read the document's position, so it tested the square the token had left:
- A foe standing in opening 1 that moved well away was teleported to opening 2, carded and saved again.
- A token moving *into* an opening from outside did nothing.

0.11.1's harness put the new position on the document, which is why it passed.

## What changed

- **Every move check now reads where the move ends,** taken from `change` (falling back to the stored `_source`, then the document, for what `change` does not hold). That covers:
  - the rift's "ends a move in the opening";
  - Riserune's 10 ft;
  - the curse's 60 ft hour (Symbols of Pain and Weakness);
  - the symbols' glow, which reads the moving token at its end position and everyone else where they stand.
  - None of them reads the document's position or `doc.regions` in this hook any more.
- **The far opening occupied.** Live, an ally's card said "steps through the rift" while TRG Prime refused the move (another creature stood in the far opening). The passage now checks that its own move actually happened. If it did not, the card says "the far opening is occupied (or the move was refused): it does not pass", and no Spatial Awareness card is posted and no save rolled. The second-teleport check still comes first, so nothing is spent before it is known.
- **The rift's own teleport** (`eaRift`) is still never taken for a passage.
- **A passage counts only if it landed** (review): the update must return something *and* the token's stored position must now be the far opening. A refused update has been seen to return nothing on 14.367; one that resolves with the document but did not move is reported as occupied too.
- **The module's older movement handlers were already right, and are unchanged in behaviour** (review). In V14's `updateToken` only the document's getters (`doc.x`, `doc.y`, `doc.regions`) and the placeable lag; its stored `_source` already holds the move's end (Block 1's own 0.5.1 live note). The two token-centre helpers every range and area check goes through already read the stored data: Block 1's `tokenCentre` read `_source`, and `areas.mjs` read `toObject()`, which is the source. Both now say so explicitly: `_source` first, then the document, then the drawn token. So these always judged the move's end, and nothing in them changed behaviour:
  - Block 3's Ley Tap (through `areas.mjs`) and the Soulbound Familiar's range;
  - Block 6b1's Shard Cloud;
  - Block 6e's Symbiotic Witch;
  - Block 7's Chronoweave and Metamagic Resonance;
  - the antimagic sweep.
  - Block 5a reads the core's movement record, and Block 5b's Shadow Initiate asks the core's `lightLevelAt`; neither reads a position itself.
  - Block 3 still needs the token's placeable, so a client not viewing the scene skips it. That is a separate gap, not a stale position.
- **Only Block 8a changed behaviour:** it read `doc.x`/`doc.y` and `doc.regions`, the lagging getters. Its handlers now take the end from `change`, then `_source` (`endPositionOf`, in `module/token-moves.mjs`).
- *Withdrawn in review:* a registry of move ends tried for the older handlers was unnecessary (they already read `_source`). It keyed by bare token id, which duplicated scenes share, and was never pruned, so it was removed before release.
- **A move paused partway:** V14 hands the move record to this hook as `_movement` (the GM's client had no `movement`). The guard reads both, and a move with waypoints still pending does not pass. *Not confirmed live:* that `_movement[id].pending.waypoints` is filled while a split move is under way. Without it, the guard does nothing and the move counts as done.

## For Graham: TRG Prime's own updateToken consumers (read-only audit, not changed)

The core's shared `tokenCentre` (`module/creature-aura-workflow.mjs:78`) reads the document's stored data (`toObject()`). Its own comment records measuring that live as the destination, so ward zones (`combat/ward-zone-workflow.mjs:112`), emanations (`magic/emanation-workflow.mjs:582`) and ally auras (`ally-aura-effects-workflow.mjs:38`) read the end correctly. `combat/movement-workflow.mjs:547` uses the move's own destination; `sunlight-workflow.mjs:118` and `magic/sustain-workflow.mjs:440` read no position.

These read the mover's position from the document's animated x/y or the placeable, which in V14's `updateToken` is the old square. A later core release could read `change` (or `toObject()`):
- **`combat/geometry.mjs:67–68`** `tokenSquares` reads `token.document.x/y`. It is reached from `updateToken` by:
  - `magic/distance-trigger-workflow.mjs:111` (tethers: `checkTethers` → `distanceBetween`, line 77);
  - `swarm-workflow.mjs:93` (`onSwarmMoved` → `coveredActors`, line 34; its `setTimeout(0)` does not wait for the animation).
- **`creature-aura-workflow.mjs:878`** `remember` records `doc.x/y` as the mover's new place, so the next move's "from" is one move behind.
- **`magic/light-shift-workflow.mjs:175`** → `magic/light-shift.mjs:165` `tokenCentrePx` reads `doc.x/y`: a light-shift circle follows its creature a move late.
- **`magic/inscribed-rune-workflow.mjs:127`** reads `object.center`, else `tokenDoc.x/y`.
- **`combat/underwater-workflow.mjs:66`** reads `tokenDocument.center ?? object.center`.

## Tests

- The harness now models V14 as logged: every move is driven through the real `updateToken` handlers with the document's getters (`x`, `y`) and the placeable at the OLD position, and `_source` and `change` at the NEW (`moveV14`). That covers Block 8a and the older handlers' verifies (Blocks 3, 5a, 5b, 6b1, 6e, 7). Test-side writes of the new position onto the getters or the placeable were removed; a token placed at rest sets both its document and its placeable, as Foundry does.
- **`verify-block8a` (354 checks):**
  - leaving an opening does not pass, entering one does;
  - Riserune records only a token that ends its move within 10 ft (one that starts within 10 ft and leaves is not recorded);
  - the curse's hour starts only on an end beyond 60 ft, and a move from far to near starts nothing;
  - the glow sees the mover at its end;
  - an occupied far opening: the card says so, with no save and no Spatial Awareness card;
  - a paused move (`_movement`) waits;
  - an update that resolves with the document while its source stays put is "occupied";
  - `areas.mjs` and Block 1's `tokenCentre` reading `_source` before the lagging getters and the placeable; `endPositionOf`'s order (`change`, `_source`, the document).
- **`verify-block6b1`:** a move that ends outside Shard Cloud (the document still inside) does not bite.
- **`mutate-block8a`:** new mutations, all caught. Each one puts back a stale read (the rift, Riserune, the hour, the glow, the end position), makes Block 1's or `areas.mjs`'s centre read `doc.x` instead of `_source`, weakens the landed check, or drops the `_movement` read.
- **Run** (9 November, on TRG Prime 3.686.0), after the review's simplification:
  - every module `verify-*`: 21 files, 5,351 checks, 0 failures (`verify-block8a` 355);
  - every `mutate-*` in a scratch copy: 21 files, 2,152 mutations, all caught (`mutate-block8a` 152). One mutation found equivalent under V14 as logged was dropped (`change` and `_source` agree during the hook), and that file was rerun green.
  - The core packs were restored afterwards with the usual routine (`verify-pack-ids` green). The core was not touched.
