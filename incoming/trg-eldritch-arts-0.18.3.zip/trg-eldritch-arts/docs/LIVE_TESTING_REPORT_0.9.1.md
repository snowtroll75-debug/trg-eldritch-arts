# Live test: TRG Prime 3.684.2 with Eldritch Arts 0.9.1

5 November 2026. Graham's world in Chrome (localhost:30000, user Testing Dude). All tests used throwaway "ZZ EA …" actors on a throwaway scene, plus a throwaway combat that Graham approved. Everything was cleaned up afterwards.

## Agile Display (3.684.2): passes

- **The chooser lists foes within Step range:**
  - the adjacent foe and the foe 10 ft away are listed;
  - the foe 15 ft away is not;
  - "No check — just Step" is offered.
- **Cancel spends nothing:** AP is unchanged and no Step is armed.
- **With a target:**
  - the Use spends 1 AP (3 → 2) and arms the Step;
  - the check is rolled against the target (10 + Reflex), and on a Critical the target's token actor is Flat-Footed and the target is set.
- **The free Step, on the gymnast's turn in the throwaway combat:**
  - the Use with "No check" took AP from 3 to 2;
  - a 5 ft move cost 0 AP. It was charged to the Step (`action:compoundLeg`: 5 ft, 0 AP), and the notice read "5 ft for 0 AP. No reactions provoked.";
  - the next 5 ft was an ordinary Stride and cost 1 AP (2 → 1).
- **Minor finding:** Agile Display checks only that a combat has started (`game.combat?.started`), not that the actor is in it. An actor outside the combat would arm a Step it can never use. This doesn't affect play at the table.

## Not run this session

The token-based checks of Block 6:

- typed DB stacking on a spell attack (G20);
- Absolute Denial and Counter Channel against an innate spell (`castPP`);
- Warlock's Hex and Xithra;
- Eternal Vigil when healed from 0 HP;
- Spellblade's Mark;
- ley lines;
- Echo, Lightning Rod, Thunderclap and Steelbinding;
- Symbiotic Witch.

TRG Prime 3.684.3 (being built now) changes DB stacking and Economic Spell, so these will run on 3.684.3.

## Cleanup

- **Deleted:**
  - the four ZZ actors;
  - the scene ZZ EA Test;
  - the throwaway combat;
  - the 4 test chat cards.
- **Dice:** restored.
- **Graham's combat 4jUOgOEHj2DWK6M1:**
  - active again, on round 2, first turn;
  - both combatants are intact;
  - it is the tracker's current combat.
- **View:** back on Oldwatch Approach.
