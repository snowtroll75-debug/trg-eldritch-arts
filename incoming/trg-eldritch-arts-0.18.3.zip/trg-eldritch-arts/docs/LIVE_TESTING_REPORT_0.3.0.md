# Eldritch Arts 0.3.0 — Live Testing Report

2 November 2026. Eldritch Arts 0.3.0 on TRG Prime 3.678.0, Foundry V14, world "TRG V14", as Gamemaster in Chrome. Inner Tempest, Pillars of Faith and Fiends & Fables were active.

**Throwaway material, all deleted afterwards:**
- the scene "ZZ EA Block 2" (4000 × 4000 px, 5 ft squares) with four Regions:
  - ZZ Old Road: Ley Line, level 14 (Prime);
  - ZZ Wild Glade: Wild Magic Area, level 4;
  - ZZ Hush: Magic Suppression Area, level 6, with backlash;
  - ZZ Null Vault: Magic Suppression Area, level 20 (antimagic).
- the actors "ZZ EA Caster" and "ZZ EA Bystander", copies of Borin Slatevein (arcane, CL 4, Power Manipulation rank 4). Borin himself was not touched.
- on the caster: the gear "ZZ EA Ring of Warding" (+1 DB effect) and the spell "ZZ EA Highmagic Bolt" (Fire Bolt plus the Highmagic trait).

Dice were steered with `CONFIG.Dice.randomUniform` and restored afterwards (five d20s rolled at random after). The test chat cards, the scene and the actors were deleted, and the view went back to Oldwatch Approach. No console errors from TRG Prime or Eldritch Arts on load or during the run.

## Results

| # | Test | Result |
|---|---|---|
| 1 | Load: versions, the three Region Behaviour types and their labels | **Pass.** 3.678.0 and 0.3.0; "Ley Line", "Wild Magic Area" and "Magic Suppression Area" offered. |
| 2 | Tap Ley Line, 10 ft from a level-14 line: the DC | **Pass.** 28 (level DC) + Hard = 30, labelled "ZZ Old Road's level DC (level 14, Prime Ley Line)". |
| 3 | Tap, Success, d100 95 | **Pass.** Quicken metamagic row, posted for the table ("the system has no channel for this yet"). |
| 4 | Tap, Success, d100 47 | **Pass.** +2 DB applied as an untyped bonus named for the line: DB 14 → 16. |
| 5 | Tap, Failure | **Pass.** 1d6 × 14 = 42 force; the Will save is against the caster's own level DC (C3), 18; on a success, half: 21 (HP 54 → 33). "Cannot Tap the Ley Line again for 1 hour." |
| 6 | Tap again inside the hour | **Pass.** Refused before any dialog: "you cannot attempt it again for 60 more minutes." |
| 7 | Channel Ley Line, Success (Very Hard) | **Pass.** 4d6 = 12, + 4 (tradition ability) = 16; PP 13 → 20, "the excess is lost". |
| 8 | Tap Magical Energy on the wand, Critical | **Pass.** The DC is the wand's level DC (item level 3, DC 17). Siphoned 2 PP (CL 4); PP 10 → 12; the wand lost half, minimum 1 (6 → 5); "Siphoned essence (2 PP)" effect created. |
| 9 | Ley Sense from the map, Critical | **Pass.** DC 18 (Prime), labelled "Ley Sense DC (Chapter 7, from the map)", with nothing given away; the card lists "ZZ Old Road: 10 ft north, Prime Ley Line (level 14)". The Focused Ley Sense time prompt still comes first. |
| 10 | Wild Magic area, Magic Missile, casting Partial | **Pass.** The surge was rolled after the cast settled: d100 10, the barrier, +2 DR for 1d4 = 2 minutes; DR 1 → 3. |
| 11 | Suppression area (level 6, backlash), casting check | **Pass.** −6 on the check as its own row; the Partial read as a Failure (the card quotes the rule); 1 PP lost; the backlash rolled, d100 40, 1d6 × 6 = 18 force (HP 33 → 15). |
| 12 | Suppression area, a Resonance event | **Pass.** None rolled: the card quotes "Magical Resonance events simply do not exist in areas of suppression". |
| 13 | Entering an antimagic zone | **Pass.** One card on entry. Race, heritage, background, ability and feat effects were left on. |
| 14 | Casting in the antimagic zone | **Pass.** Refused before any dialog, with the zone named; no PP spent. |
| 15 | A magic item's effect in antimagic | **Pass.** The ring's +1 DB was suppressed inside (DB 16), back on outside (DB 17), and suppressed again on re-entry, with one card each entry. Nothing was written to the item. |
| 16 | A Highmagic-trait spell, outside any area | **Pass.** Casting DC "High Magic, Hard +2"; the result card says "it registers simply as magic, and identifying it is Very Hard (DC +5)". |

## Findings

- **Cosmetic:** a table card (the surge, the backlash and the ley effects) prints its title as the heading and again as the first line. It is harmless, and is to be tidied in 0.4.0.
- No defects.

## Not tested live (covered by the harnesses)

- a scroll's or wand's release check surging (Q7, `trgPrimeReleaseRolled`);
- Tap's Fumble with the Backlash column;
- a Channel failure's essence damage and the Blunder's day lockout;
- the Resonance roll with disadvantage;
- High Magic's armour ×4 and focus rules (the copy wore no armour);
- a Fiends & Fables creature under Q1;
- an unlinked token in antimagic;
- the next-spell surcharge and the siphoned essence dissipating.
