# Live test: Eldritch Arts 0.10.0 (Block 7) on TRG Prime 3.685.0

7 November 2026. Graham's world in Chrome, with 3.685.0 and 0.10.0 installed and active.

The tests used:
- throwaway "ZZ EA …" actors: a Wizard raised to level 20, a Fighter foe and a Fighter ally;
- a throwaway scene, "ZZ EA B7 Test";
- a throwaway combat on that scene.

Dice were fixed for each test. Everything was cleaned up afterwards.

## Passes

**Dragon Wings: the cap of +50 above land Speed.** Cast with four +2 PP warps (14 PP). The card read "gains a fly Speed of 80 feet", and the sheet's fly Speed was 80: land 30 + 50. A fifth warp would have taken the cast over the overcast limit at that level, so it wasn't cast live; the harness covers it.

**Eaog Balls: recurring damage stacking by type.**

| Step | Foe's recurring damage |
|---|---|
| First cast, no warp (Partial save, so the Failure rung's 2d6 force) | Recurring 12 (Force) |
| Second cast, with the +2 PP coldfire warp | Recurring 24 (Force), and a separate Recurring 16 (coldfire) |
| End of the foe's turn (Phase 3), flat checks rolled 10 | Two flat checks, "Recurring Force Damage" and "Recurring Coldfire Damage", both failed. Force dealt 24 and coldfire 16: HP 126 → 86 |

- The force added to its own total; the coldfire stood beside it.
- Each type had its own flat check and its own label, so the coldfire's card no longer reads "Fire".

**Animate Moustache: Distracted (Q157).**
- The foe's Will save was a Partial, so it was affected.
- It got −1 status to attacks, every skill check, Fortitude, Reflex and Will saves, and Spellcraft.
- The −1 then showed on its later attack rolls and saves ("Animate Moustache (Distracted) Status −1").

**Mirror Reprise.**
- Cast, it showed "Mirror Reprise (waiting)".
- The first damaging hit armed it with three duplicates.
- Later attacks:
  - With 3 duplicates, d100 70 (26+ needed): the hit became a miss, and 2 duplicates were left.
  - With 2 duplicates, d100 40 (34+ needed): a miss, and 1 duplicate was left.
  - With 1 duplicate, d100 40 (51+ needed): the hit stood.
- When an attack was diverted, Panic Transposition wasn't offered, which is correct.

**Panic Transposition: the teleport waits until the attack is resolved.**
- On a hit, the Wizard was asked "Cast Panic Transposition … and teleport once the attack has been resolved?".
- Cast, it spent 4 PP (a Critical, so the base was halved).
- The Strike's damage landed first, 8 slashing (HP 94 → 86). Only then was the landing square asked.
- The Wizard landed 20 ft away: "You wrench space and reappear 20 feet away; the movement provokes nothing."
- In an earlier test the hit put the Wizard to 0 HP, and no teleport was asked, as designed.

**Spirit Arrow: flat 6d6 (Graham's ruling).**
- The rider carried `replacesDamage` and `flat`.
- The bow hit for exactly 18 (6d6 at 3 each): "Flat damage: the rider's dice alone — no other addition". The BAB die and everything else was dropped.
- The arrow was spent.
- The manoeuvre was chosen (Trip), and the card said it is resolved by hand.
- The foe failed its Will save by 16 and was Frightened 8 (half the margin, Q161).

**Chronoweave: membership is live (Q159).**
- At the cast, the Wizard and an ally within 20 ft were quickened.
- Leaving the 20 ft removed the ally's quickened, and coming back gave it again.
- The foe got nothing once its token was hostile. A setup slip had left the foe token friendly at first: it was quickened then, and losing it on becoming hostile was correct.

**Brittleskin: caster-level steps and thorns at the Save DC (H1/H2).**
- At caster level 20 the card read "+5 dr value, +5d4 thorns damage": +6 status DR and 6d4 thorns, basic Fortitude DC 14.
- The foe's hit dealt 8, reduced to 2 by the DR.
- The thorns rolled 12. The foe succeeded on its Fortitude save, so it took 6.

## Findings (none blocks play)

1. **The core posts a "Teleported — Spatial Awareness" card at the cast.** It appears when Panic Transposition's reaction is cast, before the attack resolves and before any teleport. It also appears when no teleport happens (the bearer dropped to 0 HP). The core posts it for any spell with the Teleportation trait. For Panic it should come with the actual teleport, or not at all.
2. **Spirit Arrow's cast card says "+6d6 piercing on your next ranged Strike".** The damage is flat 6d6 in place of the arrow's, not added to it. The Strike's damage card is right; only the cast card's wording is wrong.
3. **Spirit Arrow asks for a creature target.** Its target is "one arrow or bolt", but the cast opens the core's "Select Target" dialog, which warns "no creature will be affected" unless "Continue anyway" is clicked.
4. **The coldfire condition's name has no type.** It reads "Recurring Damage 16", while force reads "Recurring Damage 24 (Force)". The flat-check cards name both types correctly. Core cosmetic: an unknown damage type gets no label in the effect name.
5. **A self-range spell is refused while a token is targeted.** Mirror Reprise was refused because the foe was still targeted: "ZZ EA Foe is 30 ft away — beyond Mirror Reprise's range of self". The core already did this before this release.
6. **Distracted shows as six effect rows.** There is one row per penalty. It works, but the Effects tab is cluttered.
7. **The Panic landing prompt is easy to miss.** It is a brief notification, and the next canvas click picks the square.

## Not run live

Arcane Bastion, Spectral Aegis, Argent Reversal, Metamagic Resonance, Primal Snap, Zone Disruption and the area spells (Dragon's Breath, Leyline Burst and Bubble Buffet). Their harness checks cover them, and they can be tested in a later session.

## Cleanup

- **Deleted:** the throwaway combat, the scene with its tokens, the three ZZ actors, and 94 test chat cards.
- **Dice:** restored.
- **View:** Oldwatch Approach.
- **The game is still paused.** No combat was active before the test, and none is now.
