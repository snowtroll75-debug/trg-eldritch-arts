# Eldritch Arts — Block 3b Audit: the reactions

2 November 2026. The seven Chapter 3 features whose cards in 0.5.1 read "Waits for Block 3b", read against *TRG Prime: Eldritch Arts* v1.6 and against TRG Prime 3.680.1 as it stands. Proposed: TRG Prime 3.681.0 (the seams) and Eldritch Arts 0.6.0 (the reactions). **Graham's answer (2 November 2026, 23:30): "Go with your proposals".** Q26–Q35 stand as proposed.

## The seven, as printed

| Feature | Where | Cast / action | Trigger | Range | PP | What it does |
|---|---|---|---|---|---|---|
| **Missed Chance** | Witch hex, L8503 | R (verbal) | an enemy succeeds at a check | 30 ft, one enemy | 3 | "When an enemy that you are aware of succeeds at an attack check, saving throw or skill check … you may invoke it to force them to reroll. The target must take the result of the 2nd check which cannot be modified further or rerolled using any other affect. After using this hex, the target is immune to its effects for 1 hour." It cannot be used if the d20 exploded. |
| **Second Chance** | Witch hex, L8599 | R (verbal) | an ally fails a check | 60 ft, one ally | 3 | The same for an ally who fails: "allow them to reroll". There is no exploded-die line. |
| **Prophetic Warning** | Witch hex, L8571 | R (verbal) | you make a check | — | 3 | "Invoke this hex as a reaction before making an attack check, saving throw or skill check. The check gains advantage. After using this hex, you are immune to its effects for 1 hour." |
| **Phase Familiar** | Witch hex, L8541 | R (somatic) | your familiar would take damage | 60 ft, your familiar | 1 | "Resistance to all damage and is immune to precision damage. This applies only against the triggering damage." Warping it for +10 PP gives immunity instead. |
| **Resist Magic** | Sidebar 6, after L990 (Rune birthright: Runic Resilience) | R | you take damage from a magical spell or effect | — | — | "You gain resistance to the spells damage type. This resistance ends as soon as the spell has been resolved." |
| **Disrupting Magic** | Arcanum birthright spell, L8269 | R (verbal) | a creature within 120 ft casts a spell | 120 ft | 1 | "Your Spellcraft check for casting this spell is treated as a Dispel (Power Manipulation) check against the incoming spell. Be aware that you expend an amount of PP when using this spell as determined by the Dispel check." (Q23, ruled: the Dispel's PP replaces the 1 PP; on a Dispel success the spell is stopped before it resolves.) |
| **Eternity Resilience** | Eternity birthright, L945 | — | you take a critical hit | — | — | "+2 bonus to Death State" (built in 0.5.0). "When you take a critical hit, you may expend Conviction to grant Disadvantage on the critical roll. Be aware that you may still only use 1 conviction per turn." |

## What TRG Prime 3.680.1 has, and what it lacks

**Every d20 check goes through one place:** `TRGCheck.roll` (`dice/check.mjs`). The order is fixed:
1. The pre-roll offers.
2. The dice.
3. The Conviction "result is held" card.
4. The post-roll offers.
5. `trgPrimeCheckResolved`.

**But no module can join either side.**
- **Before the roll:** Lucky Break, the save reactions, Unity, the rods and the rest are imported by name.
- **After the result:** the only module-facing event is the synchronous `trgPrimeCheckResolved`, after every window has closed.
- **The near-analogues are narrow.**
  - Alter the Thread is attacks only, asked of the defender.
  - The save-reroll spells (Saintly Intercession) are saves only, and asked only of casters the rolling client owns. A player's Witch is never asked when the GM rolls.
- **Weapon and spell attacks decide hit or miss after `roll` returns.** So an enemy "succeeds at an attack" is known only in the attack workflows, which have their own reroll windows.

**Asking another player exists.**
- **Shadow Shift's defence offers:** a socket ask to the right player, with a fallback to the GM.
- **Guarded and Harmony Edge:** `askOwner`.
- **But neither is a general seam.** The defence offers cover attacks only. The owner-side steps of `askOwner` are not exposed to modules.

**Damage has no reaction point before defences.**
- Spell damage goes through `resolveAgainstDefences` at about twenty sites, then `applyDamageAndCheckDying`.
- `registerDamageShare` runs after defences, and it is not told the damage is magical or which cast it came from.

**A cast can be stopped after its check, but not by a reaction.**
- `registerCastDegreeRemap` is awaited after the casting check and before PP or effects. Its context has no caster token, no targets and no cast id.
- It is skipped for innate and no-check casts.
- `trgPrimeSpellCast` is synchronous.
- There is no counterspell. The Dispel skill action and its PP ladder exist, but nothing aims them at a spell being cast.

**A critical's roll has an attacker-side advantage offer (Harmony Edge, weapons only).** It has no defender-side or disadvantage offer.

**Conviction is limited to one point a round in combat** (`convictionEligibility`). There is no per-turn limit.

## Proposed seams (TRG Prime 3.681.0)

1. **Check reactions:** `registerCheckReaction(key, { when: "before" | "after", offer, apply })`.
   - **"Before"** is asked inside `TRGCheck.roll` beside the rods and Conviction Advantage. It may give advantage, through `resolveBias`.
   - **"After"** is asked once the result is final: after the Conviction card, before `trgPrimeCheckResolved`, and for attacks at the hit/miss windows. It may reroll through the check's own `reroll()`. The context carries:
     - the roller, the type and the degree (hit or miss for an attack);
     - whether the d20 exploded;
     - the roller's token.
   - **A "locked" result** refuses every later modifier and reroll ("cannot be modified further or rerolled using any other effect"). This is a new flag that every existing offer checks.
2. **Ask the reactor, wherever they are:** the defence-offer socket made general (`askReactor`), with its 30-second timeout and its owner-then-GM answerer. The reaction's own work (a cast, a spend) runs on the reactor's client. So a player's Witch is asked when the GM rolls.
3. **Damage reactions:** `registerDamageReaction(key, offer)`, asked before damage is applied.
   - **What the offer is told:** the target, the amount and types, whether it is magical, the spell and the cast id.
   - **What it may answer:** resistance or immunity to this instance, or to every instance from that cast until it settles (Resist Magic).
   - **Where it sits:** one shared, awaited step used by `applyTypedDamage` and every spell damage site. The spell sites will pass `magical` and the cast id consistently.
4. **Cast reactions:** `registerCastReaction(key, offer)`.
   - **When it is asked:** after the incoming cast's check, and before PP is spent or anything lands.
   - **What it is told:** the caster's token, the spell, its PP and level, and the cast id.
   - **What it may answer:** stop the cast ("resolves as a failure, nothing lands"). Q33 covers whether innate and no-check casts are included.
5. **Critical reactions:** a defender-side offer beside Harmony Edge, for weapon and spell criticals alike. It may give disadvantage (a new `biasWithDisadvantage`), and advantage and disadvantage cancel.

Inner Tempest, Pillars of Faith and Fiends & Fables are unaffected unless they register. The existing core offers are unchanged.

## Proposed builds (Eldritch Arts 0.6.0)

- **Missed Chance and Second Chance:** "after" check reactions.
  - **When they are offered:** to a Witch who knows the hex, is within range, is on the right side, has a reaction and the PP, and whose target is not immune.
  - **On yes:** the hex is cast as a reaction from the Witch's client: its casting check (Very Easy, specialist), PP and the reaction spent.
  - **On a successful cast:** the check is rerolled, the second result is locked, and the target is made immune to that hex for an hour of world time.
- **Prophetic Warning:** a "before" check reaction, offered to the Witch herself on her own attack checks, saves and skill checks. A successful cast gives advantage and an hour's immunity.
- **Phase Familiar:** a damage reaction on the Witch's familiar within 60 ft.
  - **The cast:** the warp (+10 PP for immunity) is chosen in the cast.
  - **What it gives:** resistance (or immunity) to this damage only.
  - **Precision:** the precision part is ignored.
- **Resist Magic:** a damage reaction on a Rune Sorcerer hit by magical damage. Resistance to that spell's damage types lasts until the cast settles.
- **Disrupting Magic:** a cast reaction for an Arcanum Sorcerer within 120 ft.
  - **The roll:** the core's Dispel (Power Manipulation) check against the incoming spell, with its PP prompt and ladder (Q23).
  - **On a Dispel success:** the incoming cast is stopped.
- **Eternity Resilience:** a critical reaction. Spending a Conviction point gives the critical roll disadvantage.

## Rulings needed

| Q | The question | Proposal |
|---|---|---|
| **Q26** | **What "succeeds" and "fails" mean** on TRG Prime's ladder (Heroic, Critical, Success, Partial, Failure, Fumble, Blunder). | **Succeeds** is Success or better, or a hit for an attack. **Fails** is Failure or worse, or a miss. **Partial** counts as neither, so neither hex triggers on it. |
| **Q27** | **When the reroll is offered,** relative to the roller's own Conviction +1d6. Is a Conviction bonus spent on the first roll carried? | **Offered after the roller's Conviction card,** when the result is final. **The reroll is fresh dice with the same modifiers, but the first roll's Conviction die is lost,** and the second result is locked: no Conviction, Lucky Break, rods or fumble rerolls after it. |
| **Q28** | **"That you are aware of" and "enemy / ally".** Awareness can't be read from the map. | **Enemy and ally are token disposition** (hostile vs friendly). **Awareness:** offered only when the Witch can act and is not blinded. The player (or GM) declines when unaware. |
| **Q29** | **The exploded-die line** is printed on Missed Chance only. | **As printed:** Missed Chance can't be used on an exploded d20. Second Chance can. |
| **Q30** | **Immunity "for 1 hour":** to that hex only, from that Witch only? | **To that hex, from any Witch,** for an hour of world time. The target (Missed or Second Chance) or the Witch herself (Prophetic Warning) is marked. |
| **Q31** | **Prophetic Warning's prompt.** Offered before every attack, save and skill check, it would prompt constantly. | **Offered only while the Witch knows it, has a reaction and the PP, and is not immune.** It is also skipped for checks with no consequence (no DC). A module setting turns the prompt off, and then Use arms it for the next check instead. |
| **Q32** | **Resist Magic's scope:** "a magical spell or effect". What counts, and does "until the spell has been resolved" cover a spell that deals damage more than once in one casting? | **Any spell (including one cast from a scroll, wand or item) and any damage the core marks magical.** A magic weapon's own damage does not count. **The resistance covers every damage type of that cast, for every instance, until that cast settles.** |
| **Q33** | **Disrupting Magic's window:** "a creature … casts a spell". | **Offered for every cast,** innate spells and cantrips included. It comes **after the caster's own check:** a cast that fails anyway needs no disrupting. The Disrupter rolls **only the Dispel (Power Manipulation) check,** in place of the Spellcraft check, and Disrupting Magic's own casting DC (High Magic's Hard included) does not apply. |
| **Q34** | **Who answers a reaction offer, and how long it waits.** | The reactor's **player if online, else the GM,** with a **30-second timeout** that counts as "no". This is the core's defence-offer rule. |
| **Q35** | **Eternity Resilience's "1 conviction per turn"** vs the core's one per round, and which criticals count. | **The core's rule stands: one per round.** "Still" reads as pointing at the general rule. **Every critical hit taken counts,** weapon or spell. The disadvantage cancels a deadly critical's advantage to a normal roll. |

## Plan

1. **TRG Prime 3.681.0:** the five seams, each with a verify and mutate pair; the full sweep; you install it.
2. **Eldritch Arts 0.6.0:** the seven reactions, with `verify-block3b` and `mutate-block3b`; the cards' "Waits for Block 3b" become what is automated.
3. **A live test of both:** reactions asked across two clients where a second login is available, otherwise as GM.
