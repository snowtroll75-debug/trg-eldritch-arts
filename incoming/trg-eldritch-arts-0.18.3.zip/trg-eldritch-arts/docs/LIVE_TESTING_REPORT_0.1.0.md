# Live testing — Eldritch Arts 0.1.0

**29 October 2026.** Chrome, http://localhost:30000, world "TRG V14", joined as Gamemaster. TRG Prime **3.675.1**, Eldritch Arts **0.1.0**, Inner Tempest 1.0.4. Foundry 14.367.

Driven on throwaway actors named "ZZ EA …" and a throwaway scene, "ZZ EA Scene". The caster was a copy of Borin Slatevein; Borin himself was not touched. Afterwards the 7 test actors, the scene and the 37 test chat cards were deleted, and the view was returned to Oldwatch Approach.

**Result: everything driven works. One packaging fault, fixed in 0.1.1. One core wording point, reported below.**

## Load

- No errors. The only warnings are the existing Simple Calendar and `renderChatMessage` deprecations.
- The system's own report names trg-eldritch-arts among the companion modules.
- Registration problems: none. All eight packs are present (4, 18, 12, 12, 9, 1, 18, 31).
- Registered: Nyrinn's racial PP −1, the Adept rule, one gate, one surcharge, one release path, and the seven actions.

## Races and heritages, added through the system's own grants

| Character | Printed | Sheet |
|---|---|---|
| Nyrinn | Str −3, Con −1, Dex +4, Cha +2; Tiny; 25 ft | Str −3, Dex +4, Con −1, Cha +2; tiny; 25 ✓ |
| Scaelyn | Str −1, Con −1, Dex +2, Int +2; Small | the same; small ✓ |
| + Wyrmdral | Str +1, Dex −1, Int +1, Cha +1; Medium | the same; medium ✓ |
| Emberkin + Cinderblood | Con +1, Cha +1; then Str +1, Wis −1 | Str 1, Con 1, Wis −1, Cha 1 ✓ |
| Aetherial | Con −1, Int +2, Wis +1 | the same ✓ |

**Grants:**
- **Nyrinn:** Magic Drain, Null Aura and Darkvision; Spell Lore and Nyrinn Lore; Low Tongue and Nyxian on the sheet.
- **Vel-tharis:** Silence, innate.
- **Emberkin:** Charismatic Caster, its four abilities, fire resistance, Orb of Fire (cast with Spellcraft), and Ignic on the sheet.
- **Aetherial:** Mage Hand and Read Aura (cast), and Faechant.
- **Aeralis:** Gust, innate.
- **Scaelyn:** Natural Armour (base DR 1) and Innate Magic.
- **The Elemental Adept background:** grants Elemental Affinity.

## On the map (5-ft grid)

- **Null Aura:** a caster 5 ft from a level-1 Nyrinn cast Mage Armour.
  - The check carried "Null Aura (ZZ EA Nyrinn) −2", and the card named it.
  - A total of 8 against Casting DC 11 was a Partial, so the spell failed and no PP was lost.
- **Zhal-vryn:** a caster 5 ft away paid 1 PP more.
  - On a Critical Mage Armour: 1 PP (halved) plus 1, so 12 → 10.
  - On a failure the surcharge was also taken (13 → 12), as proposed in B1-6.
- **Orb of Water**, with a Zhal-vryn 5 ft away:
  - The check was 16 (Null Aura −2 included). The attack against DB was **18**, so the casting-DC row was left out of the attack, as intended.
  - Damage: 2d6 at caster level 4, plus a crit die, then **2 secondary cold** (1, +1 at CL 4).
  - The target went 30 → 19.
- **Elemental Surge** (the caster at Charisma 2): "Spell damage bonus: Elemental Surge +2 racial", on the main damage only. The secondary stayed 2.

## The Uses, through the sheet's own Use button and the system's useFeat

- **Magic Drain:**
  - The player chose "a charged item" and "DB" before the roll.
  - Against a GM-set DC 10, a total of 18 was a Success. The wand lost 4 PP (6 → 2).
  - Energy was 2 (half, capped at level × 2 = 2): +1 racial DB (14 → 15) for 4 minutes.
  - The Focus use was spent.
- **Wyrmdral:** fire chosen. Fire resistance, and +1 on a fire spell's DC (none on a cold spell's).
- **Innate Magic:** 36 cantrips offered, this module's Orb of Water among them. Daze was added, not innate.
- **Elemental Symbiosis:**
  - Immune to fire. Not twice while up.
  - When it ended: weak to fire for 60 seconds.
  - Refused until the weakness ended.
- **Ethereal Form:** incorporeal (`grantedTraits`), and the day's use spent. A second Use was refused.

## Chapter 4

- **Ley Sense:**
  - The skill chooser, then the roll dialog, then the time ladder. With Focused Ley Sense the ladder offers its five rungs (+2, +0, −2, −5, −10).
  - "1 round" put −2 circumstance on the roll.
  - A total of 10 against DC 15 is a Failure: Ley Sense is locked for 10 minutes. The retry was refused with "you cannot attempt it again for 10 more minutes".
  - An untrained character choosing Nature (0 ranks) is refused by the system's Trained gate.
- **Lingual Casting:** a Scroll of Fireball (6 PP) listed "Lingual Casting (Linguistics) — veryHard" beside Spellcraft, Arcana and Nature. It was unavailable with the right reasons: Linguistics 4 is below 8, and neither Arcana nor Nature has 6 ranks.

## Found

1. **The compendiums were loose in the sidebar** (no `packFolders`). **Fixed in 0.1.1.**
2. **Core wording, not changed:** when a Zhal-vryn surcharge is paid on a failed casting, the result card says "The spell fails. No PP lost." directly under the line saying the surcharge was paid. Both are true of the spell's own PP, but read together they disagree. A core sentence such as "No PP lost for the spell; the surcharge was paid" would settle it. This belongs with your ruling on B1-6 (whether the surcharge is paid on a failure at all).

## Not driven live

Hypnotism, Quickbind, Mysterious Script, Vir-ellian Release, Wanderer's Instinct and the goods' ticks. The harness covers them (`verify-block1` D2). They need a target or a second token, which this pass did not set up.
