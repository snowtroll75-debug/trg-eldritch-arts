# Eldritch Arts Block 5: audit (racial and general feats)

3 November 2026. Block 5 covers Chapter 5's **74 racial feats** and **43 general feats**. It was read against:
- ***TRG Prime: Eldritch Arts* v1.6** (`ea.md`: racial feats L2132–2860, general feats L4322–4700, through `book-text.json`);
- **Graham's rulings** of 1 November 2026, and his answers Q1–Q56 (Blocks 1–4);
- **TRG Prime 3.682.3**, surveyed in its source. Each "the core has" claim was read there, and the core's spells, feats, races and heritages packs were read from copies.

Four reviewers read a quarter each. This document merges their findings. Their per-feat tables are the appendices.

**Status: answered by Graham, 3 November 2026, 22:36: "As proposed except" Q58 and Q59.**
- **Q58, changed:** "Ascendan suffer penalties for High Magic (as it combines all magic)". So Forbidden Magic's −2 to saves, and its Will save against beneficial spells, apply against **any High Magic cast** aimed at an Ascendan, which counts as every tradition. Today the target's save reads only the spell's own tradition field (`resolveSpellSave`), so a High Magic cast of an arcane spell escapes it. This is a core change (TRG Prime 3.683.0). The Ascendan's own High Magic casting is unchanged: 3.680.0's bypass of the tradition gate stands.
- **Q59, changed:** "This feat removes the penalties associated with High Magic". Unbound lifts those penalties for its owner: against a High Magic cast, Forbidden Magic doesn't apply at all. A new actor flag, read at the same two places.
- **Every other question (Q57, Q60–Q88):** as proposed. That includes seam C1 (heritage and "Level N only" prerequisites gated in the core) and Q88 (D10 and D14's Sniping half built now).

## Scope

| Group | Feats | Book | Notes |
|---|---|---|---|
| **Aetherial** | 18 | L2132–2860 (all racial) | Five are gated to a heritage (Caelari, Nerathis …). |
| **Emberkin** | 14 | | Several read the heritage's element. |
| **Nyrinn** | 14 | | Build on Magic Drain and Null Aura (Block 1). |
| **Scaelyn** | 19 | | Five grant core spells as innate spells. |
| **Other races** | 9 | | **Elf** (Ancestral Reverie, Moonlight Precision), **Human** (Endless Adaptation, Relentless Will), **Gnome** (Feyblood Glamour), **Kornargon** (Shadow's Discipline, Veil of Honour), **Ascendan** (Unbound) and the **Quiliesh** Heritage feat. |
| **General** | 43 | L4322–4700 | **Nine already exist** (0.1.0–0.4.0): Disrupt Magic, Elemental Affinity, Focused Ley Sense, Spell Penetration, Spirit Whisper and Wanderer's Instinct are complete. Ritual Expert is complete. Esoteric Insight has a defect (below). Spell Surge is a text item awaiting Block 6. |

**How the proposals grade** (A full · B automated with a normal choice · C partial, the rest a card or the GM's · D descriptive):

| | A | B | C | D |
|---|---|---|---|---|
| Aetherial and other races (27) | 11 | 12 | 3 | 1 |
| Emberkin and Nyrinn (28) | 11 | 13 | 4 | 0 |
| Scaelyn (19) | 12 | 7 | 0 | 0 |
| General (43) | 15 | 19 | 5 | 4 |
| **All 117** | **49** | **51** | **12** | **5** |

These grades assume the seams below. **The C feats** leave one clause to the GM:
- Eclipsed Form's passing through objects;
- Night's Embrace's leaving no tracks;
- Silent Veil's hiding while observed;
- Voidborn Grace's interrupted glide;
- Astral Drift's free Step;
- Magic Sense, Mirrored Rebuke's Fumble, Piercing Insight, Runespeaker's heightening, and Wanderer's Mastery's "rolled a 10".

**The D feats:**
- Unbound (Q59);
- Spirit Whisper (already built);
- Mnemonic Grasp, Spell Feedback and Spell Transcription, which are downtime or GM-adjudicated.

**Not in this block** (each ships now as an item whose card says when it arrives, so prerequisite chains work):
- **Block 6** (module metamagic, D2): Echo of the Ancestors, Resonant Pulse, Resonant Harmony, Spell Surge, Piercing Insight.
- **Block 9** (catalysts, D3): Catalyst Affinity, Catalyst Conservation, Catalyst Crafting, Catalyst Mastery.

## What the core lacks

| Need | The core today | Gap |
|---|---|---|
| **A racial feat for a core race** | The Racial Feat picker matches `sourceRace` against the actor's effective races (`picker-filters.mjs`). A Half-Elf already sees Elf feats. `registerHeritageRaceGrant` opens Ascendan feats to the Quiliesh as Half-Elf opens Elf ones. | None. |
| **"X Heritage" and "Level 1 only" prerequisites** | `prerequisites.mjs` deliberately leaves both unparsed, and they pass. The core's own Fire-Like Blood ("Azgar heritage") and Tusks ("Level 1 only") behave the same. | **Eighteen heritage-gated feats would be offered to the whole race,** and two "Level 1 only" feats at any level (Q57). |
| **Spell grants** | Feats grant innate Focus spells (`flags.grantInnate`, as Injury Relief). Every spell these feats name is in the core pack: Stinking Cloud, Neutralise Poison, Pass Without Trace, Silence, Burning Hands, Feather Fall, Darkness and Daze. | None, except Alchemical Purifier's PP 6 at 5th level (Q76). |
| **Bonuses on a check reaction** | `registerCheckReaction.before` can answer only advantage. | **"+2 racial bonus to the saving throw" and "treat it as a success" can't be answered** (seam C2). |
| **Light level** | `lightLevelForToken` gives the ambient level 1–10, but only the Perception penalty and Shadowy concealment read it. | **No bonus can depend on the light** (seam C4): six feats. |
| **Spell damage per die, by type** | `spellDamageBonus` is flat, once per cast, scoped by trait. | **"+1 damage per die rolled" of fire damage can't be said** (seam C6). |
| **Dispel** | Its PP cost and degrees are fixed in `action-workflow.mjs`. | **D10** (seam C9): Resonant Ascendance, Dispel Power, Mirrored Rebuke, Threadbreaker's Precision; Block 6's Runebreaker and Glyph Shatter. |
| **Spell Recognition** | The roll passes no action key or subject (`feats-workflow.mjs` ~7351). | **Defect:** Esoteric Insight's advantage tick and reroll (Block 1) never reach the roll (seam C11). |
| **Shadow Stance** | Its effect is written with `replaceFeatEffect`, without the `featStance` flag. | **Defect:** "while in any stance" rules (Tranquil Mind, Inner Tempest's Martial Affinity) never see it. Veil of Honour needs a way in (seam C19). |

## Proposed seams (TRG Prime 3.683.0)

Prepared separately for approval, as before. **C1 changes how core feats are offered**, so it is a question (Q57). The others are additive.

| # | Seam | Where | Used by |
|---|---|---|---|
| **C1** | **"Name Heritage" and "Level N only" prerequisite clauses.** The heritage clause is gated only when Name is a known heritage. Every other clause still fails open. | `prerequisites.mjs` `parsePrerequisiteClause`; the actor's heritage name in `picker-filters.mjs` | The 18 heritage feats; Ember Eyed and Unbound. The core's Fire-Like Blood, Arctic Elf, Necrotic Resilience, Tusks and Beastman would gate too. |
| **C2** | **A check reaction's `before` may answer `modifiers` and `declare: "success"`.** Its ctx gains `isArea`, `saveSource`, `sourceUuid` and `attackMode`. | `reactions/reactions-workflow.mjs` `checkReactionsBefore`; `dice/check.mjs` (declared degree) | Voidbound Resolve, Anchor in Nothing, Glyph Unleashed, Veilstride |
| **C3** | **A defence offer for spells only** (`against: "spell"`). | `combat/defence-offer.mjs`, `combat/one-attack.mjs` | Glyph Unleashed (spell attacks against DB) |
| **C4** | **Light level:** a conditional axis `lightLevels` (the ambient level at the roller's token), and `helpers.lightLevelAt(token)`. | `conditionals.mjs` scope axes, filled in `dice/check.mjs`; `light-workflow.mjs` | Veil of Silence, Moonlight Precision, Shadow Initiate, Silent Veil, Veilstride, Ghostscale |
| **C5** | **`helpers.isUnderwater(token)` and `helpers.rollFalling(actor, {distance})`.** Today a creature whose granted flight ends stays aloft. | `combat/underwater-workflow.mjs`, `combat/falling-workflow.mjs` | Tideweaver's Resilience, Voidborn Wings, Stormrunner's Zeal, Voidborn Grace |
| **C6** | **`spellDamageBonus` gains `perDie` and `damageTypes`**, applied to every pool of that type the cast rolls, after warps. | `magic/spell-damage-bonus.mjs`; the cast's damage pools | Emberborn Fury, Elemental Apotheosis |
| **C7** | **A death guard's `healTo`** (level + an ability) in place of 1 HP. | `combat/death-guard.mjs` | Tideweaver's Resilience |
| **C8** | **`registerDyingRecoveryModifier`**, which can waive the fatigue for leaving Dying. | `combat/death-state.mjs` `applyDyingRecovery` | Relentless Will |
| **C9** | **D10, `registerDispelModifier`:** PP cost (factor or replacement), counteract value, difficulty, own outcome ladder and `onResult`. Designed for Block 6's users too. | `combat/action-workflow.mjs` Dispel prompt and PP spend | Resonant Ascendance, Dispel Power, Mirrored Rebuke, Threadbreaker's Precision |
| **C10** | **`trgPrimeActionResolved` carries the upgraded degree** beside the raw one. | `combat/action-workflow.mjs` | Channel Siphoner |
| **C11** | **Spell Recognition passes `actionKey` and `subject`.** A fix. | `feats-workflow.mjs` | Esoteric Insight (the defect), Esoteric Insight Expert and Master |
| **C12** | **A declared control-level bonus** (`flags.trg-prime.controlLevelBonus`). | `documents/actor.mjs` after `controlLevelCap` | Master Binder; Block 9's two weapons |
| **C13** | **A spell outside the memorisation count** (`memorisationFree`). | `magic/memorisation-workflow.mjs` | Spell Thief |
| **C14** | **The degree remap is told High Magic and the cast options taken, and a cast option may cost AP.** | `magic/cast-workflow.mjs` `remapCastDegree`; `magic/cast-options.mjs` | Runic Stabiliser |
| **C15** | **D14's Sniping half:** a spell attack's critical can open Sniping. | `combat/attack-workflow.mjs`, the Sniping gate | Silent Spellstrike |
| **C16** | **`ignoresDifficultTerrain: "magical"`**, honoured on terrain a spell made. | `combat/passive-feats.mjs`, movement | Astral Drift |
| **C17** | **`helpers.movementThisTurn(actor)`** (feet, AP on movement). Optional: the core's flag can be read meanwhile. | `combat/movement-workflow.mjs` | Skyborne Agility, Astral Drift, Shadow's Discipline, Veilstride |
| **C18** | **Incorporeal passage through occupied squares** (not ending there). Optional. | `combat/space.mjs` `passageThrough` | Astral Crossing, Eclipsed Form, Ethereal Form |
| **C19** | **`helpers.enterShadowStance(actor, {apCost, ignoreOpen})`**, and Shadow Stance's effect gains `featStance` (the defect). | `feats-workflow.mjs` "shadow stance" | Veil of Honour |

**For Block 6, with D2:** a metamagic option may add a recipient to a self-only spell (Resonant Harmony).

## Rulings needed

### Across the block

| # | Question | Proposed |
|---|---|---|
| **Q57** | **Heritage prerequisites.** "Prerequisites Wyrmdral Heritage" and the like (18 feats), and "Level 1 only" (Ember Eyed, Unbound), are not enforced by the core's picker. The core's own Fire-Like Blood and Tusks behave the same, on purpose: an unread clause fails open. | **Seam C1:** gate "Name Heritage" (when Name is a heritage) and "Level N only" in the core. It also gates those core feats. The alternative is the module opening each feat to its heritage through `registerFeatAccess` with a different `sourceRace`. That works with no core change, but it misuses a field the sheet shows. |
| **Q58** | **Forbidden Magic against High Magic.** A Highmagic spell "counts as belonging to all traditions" (M27). So the Ascendan's "−2 penalty to all saving throws against these traditions" and its Will save against beneficial spells now apply to **every** High Magic spell. | **They don't apply.** High Magic spells "are classed as high magic and not the tradition they hail from" (L837). This is a small core change. |
| **Q59** | **Unbound** (Ascendan): "When using High Magic, you may ignore the usual restraints applied to you from Forbidden Magic." L839 already says "these restrictions are irrelevant when it comes to high magic", and the core has skipped the tradition gate for every High Magic cast since 3.680.0. | **Say what Unbound should add.** Until then it ships as a marker whose card says the rule already applies. If L839 was meant for the Sorcerer only, Unbound becomes the general route, and 3.680.0's bypass narrows to the High Magic classes plus Unbound. |
| **Q60** | **Quiliesh** prints only HERITAGE ("mortals touched by the First Race"), no race. | **Human only**, as all four core Heritage feats are. It opens the Ascendan racial feats (`registerHeritageRaceGrant`), and its cantrip is cast with Spellcraft, chosen once. |
| **Q61** | **"Light level 5 (Dim Light) or less"** (Shadow Initiate, Silent Veil, Veilstride, Ghostscale, Veil of Silence, Moonlight Precision). An Elf's Nightvision raises the level it *perceives*. | **The ambient level where your token stands** (sources, Darkness, regions and weather included), not raised by your own Darkvision or Nightvision. Moonlight Precision reads the attacker's square. |

### Aetherial

| # | Question | Proposed |
|---|---|---|
| **Q62** | **Astral Step** prints no action (Astral Crossing prints 0 AP). | **1 AP**, as Elemental Step, Dimensional Step and Gale Step. Up to your land speed, to an unoccupied space. |
| **Q63** | **Resonant Ascendance's "half of the normal PP"** for a Dispel. Dispel already costs half on a Critical or Partial. | **Half the declared PP, rounded up, whatever the degree.** The halves don't compound. The counteract roll still uses the PP declared. |
| **Q64** | **Radiant Presence:** "You emanate light in a 10' radius", always. It spoils Hide in the dark for the Caelari and their allies. | **Always on, as printed** (as Null Aura, M22). Say if it should be switchable. |
| **Q65** | **Endless Adaptation** (Human): "treat any skill check as if it were a class skill with an additional +2 class bonus". | **Not a class skill:** the class bonus + 2. **Already a class skill:** +2. |
| **Q66** | **Resonant Pulse and Resonant Harmony** are METAMAGIC. Today's cast-option seam is not shown for innate, item or no-check casts. | **Ship the items now, and build them as D2 metamagic in Block 6.** Pulse: Save DC +1. Harmony: an extra recipient for a self-only spell. Each spends its Focus use, at no PP. |

### Emberkin and Nyrinn

| # | Question | Proposed |
|---|---|---|
| **Q67** | **Threadbreaker's Precision:** "When using Cancel Magic, you gain a +2 racial bonus to the Dispel check … if you successfully counter a spell, the caster is also Dazed 1". The core's Cancel Magic is a ward (advantage on saves against a realm) with no check, so as printed the feat does nothing. | **Read "Cancel Magic" as the Dispel action**, its counter-spell use included (Counter Spell, Disrupting Magic). +2 racial on every Dispel check, though not on Magic Drain's (B1-22). On a counter of Success or better, the caster is Dazed 1 until the end of its next turn. |
| **Q68** | **Eclipsed Form:** "becoming incorporeal … you take half damage from non-magical physical attacks". The core's Incorporeal trait gives *immunity* to non-magical attacks and precision damage. | **The printed effects only, not the trait.** Half damage from non-magical bludgeoning, piercing and slashing weapon attacks. You pass through solid objects but may not end your turn in one. |
| **Q69** | **Crystal Pulse:** "as a 1 AP (focus) action, you may increase the damage by 1d4". | **Part of the release:** +1d4, with no extra AP or use. |
| **Q70** | **Emberborn Fury and Elemental Apotheosis:** "+1 damage per die rolled" of fire (or the element). | **Your spells by any route** (cantrips, innate, item casts) and **your magical abilities' damage**: every pool of that type, the dice actually rolled. **Not weapons**, rune riders or recurring damage. They stack (+2 a fire die for a Cinderblood with both). |
| **Q71** | **Tideweaver's Resilience:** "reduced to less than 0 HP". In TRG Prime damage clamps at 0 and applies Dying. | **Once a day, offered when damage would take you to 0 HP:** you stay conscious at HP = level + Wisdom (min 1), with no Dying. Not against a blow that kills outright. |
| **Q72** | **Veilstride:** "move at least 10 ft in light level 5 or less before making a melee attack". | **10 ft or more of your own movement this turn** (a teleport is not moving), standing in light 5 or less as you attack. Advantage on the **first** melee attack after it. |
| **Q73** | **Voidbound Resolve:** "targeted by a spell that requires a Will save … +2 racial … If this causes you to succeed, the caster suffers 1d4 mental (basic Will) damage per two levels". | **"Targeted" excludes area spells**, as Gnome Resistance's same words do. The +2 is declared before the roll. "Causes you to succeed" means the +2 made the difference. The caster's basic Will is against its own Level DC (C3). |
| **Q74** | **Nyrinn Scholar's "racial specialist skill"** is singular. The Nyrinn has two (Spell Lore, Nyrinn Lore). | **Choose one**, as the core Scholar feats ask. Using the feat again moves it. |
| **Q75** | **Echo of the Ancestors** (for Block 6): "duplicate the spell at half damage targeting a second creature within range". | **One casting, one check and one PP total (+2).** The second creature within range saves (or is compared with the same attack roll) for half damage, rounded down, and takes the spell's other effects. One Focus use, only when the spell's damage type is your heritage's element. |

### Scaelyn

| # | Question | Proposed |
|---|---|---|
| **Q76** | **Alchemical Purifier** (Level 5): Stinking Cloud and Neutralise Poison as innate spells are both PP 6. Your 20 October ruling, no innate spell above your level, refuses them until 6th. | **Allow base PP up to level + 1** for the two (`innatePPAllowance: 1`), so the feat works when taken. Otherwise they wait for 6th, and the card says so. |
| **Q77** | **Elemental Breath** (Wyrmdral Heritage): "You must select either acid, cold, electricity, fire or poison." v1.6 removed v1.4's "if you have the Wyrmdral heritage, you must select your elemental type" (EA-M11). | **The heritage's own element**, with no separate pick, as the removed sentence said. A Wyrmdral who resists fire breathes fire. |
| **Q78** | **The Dustscale chain adds nothing at base speed.** Dustscale already has a 10 ft burrow and advantage on Hide in natural terrain. Sandstrider's "half your land speed" is 10 ft at 25 ft, and Desert Wraith's Hide advantage duplicates the heritage's (advantage doesn't stack). | **Build as printed** (Sandstrider grows with speed bonuses). Please confirm, or reword: for example, a burrow speed equal to your land speed. |
| **Q79** | **Runic Aptitude:** "You gain an additional cantrip (any tradition)". v1.6 made its prerequisite Glyphweave's cantrip "innate", and not this one. | **One cantrip, chosen with the feat's Use and kept until chosen again, cast with Spellcraft, not innate.** |
| **Q80** | **Glyph Unleashed:** "a reaction when targeted by a spell … +2 racial bonus to your saving throws and DB against that spell". Gnome Resistance excludes areas in its own text. This feat doesn't. | **Areas included:** any spell whose save you roll or whose attack is against your DB. The +2 lasts until the start of your next turn against that spell from that caster. It costs the reaction and the Focus use. |

### General

| # | Question | Proposed |
|---|---|---|
| **Q81** | **Esoteric Insight Master:** "You may reroll any failed Arcana or Occultism." No limit is printed; its two predecessors are 1 and 2 a day. | **As printed:** every failed Arcana or Occultism check (Failure, Fumble or Blunder) may be rerolled once, with no daily limit. Say if it should be a number a day. |
| **Q82** | **Rune-Binder's Precision** still prints Ritual Expert's benefit ("always considered to be two casters"). You said you would alter it (M21). Archsage Command adds "an additional caster beyond those present". | **Build Rune-Binder's as now:** it doesn't stack with Ritual Expert (M21, Q13). Archsage adds one seat on top, so a primary with both counts as three. |
| **Q83** | **Ley Channeler:** "if you fail a Tap Ley Line check, you may reroll". | **Failure and Fumble** (a Fumble adds Tap's backlash and lock). A Blunder falls back to Fumble (m42). |
| **Q84** | **Dispel Power:** "You replace the PP cost with your caster level". | **No PP spent;** the counteract value is your caster level, compared as Dispel compares. Disrupt Magic's +2 applies, and it may be used through Counter Spell. Focus: one use a Refocus. The rungs not printed fall back as m42. |
| **Q85** | **Mirrored Rebuke:** the reflected spell "resolves as though cast by you". | **No casting check and no PP of yours.** The spell keeps its PP and warps as cast, and uses your save DC and spell attack. A Critical reflects too. On a Fumble the spell resolves on you and on one ally within its range (the GM's choice). |
| **Q86** | **Silent Spellstrike:** Sniping needs "a critical with a ranged weapon within its first range increment". Spells have no increments. | **A critical on a spell attack within the spell's range.** The target's state stays the GM's, as for weapons. |
| **Q87** | **Runespeaker:** "reduce the rank requirement for using Lingual Casting by 1". It has two requirements (tradition-skill ranks ≥ PP; Linguistics ≥ PP + 2). | **Both reduced by 1,** minimum 1. |
| **Q88** | **Scope.** D10 (Dispel modifiers, C9) and the Sniping half of D14 (C15) were planned for later blocks. | **Build both in Block 5's core release,** designed for Block 6's users too. So Dispel Power, Mirrored Rebuke, Resonant Ascendance, Threadbreaker's Precision and Silent Spellstrike are built now. The catalyst and metamagic feats ship as items with honest cards. |

## Minor

Each appendix lists its own minor notes: typos, stale matrix rows, and untyped bonuses read as racial. Three need care:
- **Curly apostrophes.** Starseer's, Shadow's, Rune-Binder's, Lorekeeper's and Wanderer's names print ’. The prerequisite gate matches exactly, so the items keep ’ or the chains pass open.
- **Chronal Echo's reroll** is locked, as every reaction reroll in the core is. The book says only "reroll".
- **EA-m49** (Dispel Power: "…caster level When making…", a missing full stop) is still in v1.6.

## Plan

1. **Graham answers Q57–Q88** (done, 3 November).
2. **TRG Prime 3.683.0** (built, 4 November): the approved seams C1–C19, with their harness pair, the sweep and an independent review.
3. **Eldritch Arts 0.8.0** (built, 4 November; `RELEASE_NOTES_0.8.0.md`):
   - the 117 feats (108 new items; nine exist);
   - registrations: race, heritage grant and feat access;
   - automations;
   - `verify-block5` and `mutate-block5`, and the review;
   - Battle Mage's updated card text (Q53) rides along.
4. **Live test.**

## Appendices: the reviewers' tables

The question numbers in the appendices are each reviewer's own. They map to this audit as follows:
- **Aetherial and other races:** Q5-1 → Q60, Q5-2 → Q59, Q5-3 → Q58, Q5-4 → Q62, Q5-5 → Q63, Q5-6 → Q64, Q5-7 → Q65, Q5-8 → Q61, Q5-9 → Q66. Its seams: S-1 → C1, S-2 → C9, S-3 → C4, S-4 → C17, S-5 → C16, S-6 → C18, S-7 → C8, S-8 → Block 6, S-9 → C19.
- **Emberkin and Nyrinn:** Q?-1 → Q67, Q?-2 → Q68, Q?-3 → Q69, Q?-4 → Q70, Q?-5 → Q71, Q?-6 → Q72, Q?-7 → Q73, Q?-8 → Q74, Q?-9 → Q75. Its seams: S1 → C2, S2 → C6, S3 → C4 and C5, S4 → C7, S5 → C1.
- **Scaelyn:** Q5-1 → Q76, Q5-2 → Q77, Q5-3 → Q78, Q5-4 → Q79, Q5-5 → Q80. Its seams: S-1 → C1, S-2 → C2, S-3 → C3.
- **General:** Q?-1 → Q81, Q?-2 → Q82, Q?-3 → Q83, Q?-4 → Q84, Q?-5 → Q85, Q?-6 → Q86, Q?-7 → Q87. Its seams: S5-1 → C10, S5-2 → C11, S5-3 → C12, S5-4 → C13, S5-5 → C14, D10 → C9, D14 → C15.


### Appendix A. Aetherial racial feats, and racial feats for other races

Read against *Eldritch Arts* v1.6 (`ea.md` L2132–2804, via `book-text.json` `sections.racialFeats`), Graham's rulings of 1 November 2026, the Block 1–4 answers (Q1–Q56), and **TRG Prime 3.682.3** (`/home/claude/core-3676/trg-prime`, `system.json` 3.682.3), surveyed in its source. Core packs were read from a copy of the LevelDB packs (feats 439, races 8, heritages 45, spells 692, abilities 78).

#### What TRG Prime has, and what it lacks

| Need | The core today | Gap |
|---|---|---|
| **How a racial feat reaches a race** | The Racial Feat picker keeps `system.category === "Racial"` and matches `system.sourceRace` (a comma list) against the actor's **effective races** (`picker-filters.mjs` `buildPickerFilter`, case `racialFeat`). An untagged entry passes for everyone. The race lives in `sourceRace`, never in `traits`: e.g. Darkened Veil `sourceRace "Kornargon"`, traits "Shadow". Module packs that declare `extends: "feats"` are read by the same picker (`content-packs.mjs`). | None. An EA feat traited ELF, HUMAN, GNOME, KORNARGON or ASCENDAN is built with `sourceRace` set to that core race. No `registerFeatAccess` is needed: that call is only for *core* feats opened to *new* races, which Block 1 already does (`registration.mjs` `EXISTING_RACIAL_FEATS`). |
| **Core races** | Human, Elf, Gnome, Kornargon, Ascendan, Dwarf, Halfling, Orc are all core race items. Kornargon has Shadow Stance. Ascendan has Forbidden Magic (`forbiddenTraditions "divinity, verdant"`, a −2 save conditional, `beneficialTraditionSave`). | None. |
| **Effective races and Heritage feats** | `effectiveRaces(race, heritageFeatNames)` (`feats.mjs:1078`) adds every owned feat with the Heritage trait, and the races in `HERITAGE_RACE_GRANTS` (Half-Elf → Elf, Half-Elf), or a module's `registerHeritageRaceGrant(featName, races)` (`module-api.mjs:510`). So a Half-Elf already sees the new ELF feats. The **Heritage trait** limits a feat to 1st level (`withHeritageGate`, Graham 9 Sep 2026). All four core Heritage racial feats (Half-Elf, Half-Orc, Half-Ogre, Beastman) are `sourceRace "Human"`. | None for Quiliesh's "may select Ascendan racial feats": `registerHeritageRaceGrant("Quiliesh", ["Ascendan"])` is exactly the core's Half-Elf mechanism. |
| **Prerequisites** | `prerequisites.mjs` gates "Level N", ability, BAB/BSB, skill ranks and a named feat (exact, case-insensitive; curly ’ must match). "*X* Heritage" and "Level N only" are **not parsed** and pass open, for the core's own feats too (Fire-Like Blood "Azgar heritage", Tusks "Level 1 only"). | Heritage prerequisites and "Level 1 only" are not enforced in the picker (optional seam S-1). |
| **Passive bonuses** | Transferred effects with typed keys: `system.skills.<k>.racial`, `system.combat.initiative.race` (Swift Reflexes +10), `system.combat.defence.circumstance`, `system.combat.saves.reflex.*`. Conditionals by `traits` (the school is a trait: 76 spells carry Insight, 13 Fear, 77 Mental), `checkTypes` incl. `spellcraft`, `attackModes`. | None. |
| **Specialist-skill bonus** | Core Elven/Kornargon Scholar: AE for the two skills, plus a Use that writes `system.specialistSkills.<slug>.racial` through `specialistSkillBonus` (`feats-workflow.mjs:1085`). Not exposed; `replaceFeatEffect` and `chooseFromList` are. | None (the module writes the same effect). |
| **Ally auras and light** | Any token whose items carry `flags.trg-prime.auras: [{kind: "ally", radius, allyEffect}]` lays an effect on allies inside (`ally-aura-effects.mjs`, `creature-aura-workflow.mjs` `auraEmitters`). `registerLightSources({key, steps, radiusFeet})`; the light is read from **actor-owned** effects flagged `lightSource` (`light-sources.mjs` `lightSourceKeysOn` reads `actor.effects`, not item-transferred ones), with `helpers.refreshTokenLight`. | None. |
| **Light level at a roll** | `lightLevelForToken` (`light-workflow.mjs:100`) gives the ambient level 1–10 (Dim 5, Twilight 6) with regions, sources, darkness spells and weather. It feeds only the Perception penalty row and Shadowy concealment. No conditional axis reads it. | **Light-gated bonuses can only be ticks** (S-3). |
| **Movement this turn** | The movement workflow keeps per-turn pools in `flags.trg-prime.movementPools` `{pool: {movedCost, apCharged}}` (`combat/movement-workflow.mjs` `movementState`), terrain-adjusted cost, not feet; reset at turn start. Not on the API. Skill actions with the Movement trait (Sneak) spend AP outside the pools. `trgPrimeActionResolved` and `trgPrimeTurnEnded` exist. `helpers.armMove` arms a free leg (no AP). | **No supported read of feet moved or AP spent on movement this turn** (S-4). |
| **Difficult terrain** | `ignoresDifficultTerrain` eases **non-magical** terrain only (`passive-feats.mjs` `wildStrideCost(… magical)`); the movement workflow is told cost, not whether the terrain is magical. | **No "ignore magical difficult terrain"** (S-5). |
| **Incorporeal** | `grantedTraits: ["incorporeal"]` on an effect (Block 1's Ethereal Form). Passage through occupied squares is refused unless ally/size/swarm (`combat/space.mjs` `passageThrough`); walls are Foundry's. | **An incorporeal mover cannot pass enemy squares** (S-6, optional). |
| **Reactions** | `registerCheckReaction` `after` for attacks gets `target` and `succeeded` (= hit) from `attack-workflow.mjs:2897` and `cast-workflow.mjs:5954`; one reroll per check, always **locked**. `registerCastReaction` after the incoming check; `resolveAction(…, {presetDispel})` rolls the core Dispel (Disrupting Magic, Block 3b). `askReactor`, `spendReaction`, `castAsReaction(caster, spell, tokenIds)`. `trgPrimeDamageApplied` carries `context {kind: "strike", melee}` and `sourceUuid` (`combat/dying-workflow.mjs:79`). | **Dispel's PP cannot be scaled** (`action-workflow.mjs:4346`, D10; S-2). |
| **Cast-time options** | `registerCastOption` → `{castingDC, saveDC, lines}` on the Casting Conditions prompt, **not shown for innate, item or no-check casts** (`cast-workflow.mjs:2223`). Core metamagic is a hard-coded table (`magic/metamagic.mjs` `buildMetamagicOptions`); no module metamagic (D2, Block 6). `shareSelfRows` warp mod shares a self-only spell's rows with whoever the cast reached (`spell-degrees.mjs` `selfRowRecipients`), but a self-only spell reaches nobody else (`self-rows.mjs` `castOnSelfOnly`). | **No module metamagic; no way to add a recipient to a self-only spell** (D2; S-8). |
| **Pending one-shot modifiers** | `addPendingModifier(actor, {value, type, kind, checkTypes, oneShot, turns, auto})`, with `pendingTurnsFor` for "before the end of its next turn". Effect-borne conditionals with `oneShot` are spent. | None. |
| **Daily choice** | `replaceFeatEffect(actor, item, data, {dailyPrep: true})`: swept at daily preparation (`sweepFeatDailyPrep`); `trgPrimeDailyPreparation` hook. | None. |
| **Leaving Dying** | `applyDyingRecovery(actor, {noFatigue})` (`combat/death-state.mjs`) is every route out of Dying; `noFatigue` is a caller option (Death's Defiance), not something an owned feat can declare. | **A feat cannot waive the recovery fatigue** (S-7). |
| **Shadow Stance** | The Kornargon ability's Use (`feats-workflow.mjs` "shadow stance"): Open/Stance trait gate, 1 AP, Concealed to the start of next turn, an effect **named** "Shadow Stance" via `replaceFeatEffect`. It does **not** carry `featStance`, so `inAnyStance` and `stanceConditionals` never see it (Tranquil Mind etc.). The core identifies it by effect name (`attack-workflow.mjs` ~6780). | No free/reaction entry (S-9, optional). Defect noted below (Minor 9). |
| **High Magic and Forbidden Magic** | A High Magic cast skips the tradition gate (`cast-workflow.mjs:972`, from 3.680.0, citing L839). A Highmagic spell counts as every tradition (`high-magic.mjs` `highMagicTraditions`, M27). | Unbound has nothing left to do (Q5-2); Forbidden Magic's −2 now meets every High Magic spell (Q5-3). |
| **Spells granted** | Feather Fall (PP 2, Reaction), Darkness (PP 4), Daze (PP 0) are all core spells. Innate Focus grants via `flags.grantInnate` (Block 1's `innate()`). | None. |

#### Aetherial racial feats

All `sourceRace "Aetherial"`. Prerequisite chains: Astral Drift → Astral Step (L5) → Astral Crossing (L10); Chronal Awareness (Nerathis) → Chronal Echo (L5); Radiant Presence (Caelari) → Radiant Bulwark (L5); Resonant Pulse → Resonant Harmony (L5) → Resonant Ascendance (L10); Skyborne Agility (Aeralis) → Skyborne Waltz (L5); Starseer’s Intuition (Astryn) → Starseer’s Sight (L5); Veil of Silence (Umbryth) → Veil of Dusk (L5). Every heritage named exists in the module (Block 1). Matrix "Prior plan" rows are FR-xx; no EA-C/EA-M entry exists for any of these.

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Aetherial Concord | 2132 | AETHERIAL FOCUS / — | "When you successfully cast a spell", one ally within 30 ft: +2 circ to "their next saving throw or skill check before the end of their next turn" | FR-01, B | `trgPrimeSpellSettled` (`cast`, `degree`); `addPendingModifier` + `pendingTurnsFor` | On settle (Success+, Q26; cantrips and innate incl.), offer if the Focus use is ready and an ally is within 30 ft; pick ally; pending +2 circ, `checkTypes [save, skill]`, oneShot, auto, to the end of the ally's next turn. Focus spent. (**B**) [1] | — | — |
| Aetherial Scholar | 2140 | AETHERIAL / — | +1 racial Arcana, Occultism; "+2 bonus to your racial specialist skill" | FR-02, A | Elven Scholar's pattern | AE `skills.arcana/occultism.racial +1`; +2 racial on **Astral Lore** (the Aetherial's printed specialist skill), written by a one-click Use as the core's Scholar feats do. (**A**) [2] | — | — |
| Astral Crossing | 2192 | AETHERIAL FOCUS TRANSLOCATION / L10, Astral Step; 0 AP | "incorporeal for 1 round as a free action at the start of your turn … pass through objects and creatures" | FR-07, A; EA-m10 (Focus default) | `grantedTraits incorporeal` (Ethereal Form) | Use, 0 AP, refused once AP has been spent this turn (`apSpentRound`); effect with incorporeal until the start of your next turn; Focus. Passing through creatures and walls: card (the core refuses enemy squares; walls are Foundry's). (**C**; B with S-6) [3] | S-6 (opt.) | — |
| Astral Drift | 2204 | AETHERIAL / — | Ignore "difficult terrain caused by magical effects"; after using "all 3 AP … with the movement trait", "step as a free action at the end of your turn" | FR-08, C | `armMove` (free leg); movement pools; nothing for magical terrain | Step: at your turn's end, if 3 AP went on Movement actions (pools + Movement-trait skill actions seen on `trgPrimeActionResolved`), offer a free 5-ft Step via `armMove`. Terrain: card until S-5. (**C**; B with S-4, S-5) [4] | S-4, S-5 | — |
| Astral Step | 2212 | AETHERIAL FOCUS TELEPORTATION / L5, Astral Drift | "teleport a distance equal to your land speed"; no action printed | FR-09, A; EA-m10 | Block 4's `teleportWithin` (click a point; core refuses an occupied end square) | Use: teleport up to land speed; Focus; no Spatial Awareness (Q51's reading). AP per Q5-4. (**B**) | — | Q5-4 |
| Chronal Awareness | 2222 | AETHERIAL / Nerathis Heritage | +20 racial Initiative | FR-10, A | Swift Reflexes' key | AE `system.combat.initiative.race +20` (in scale: Improved Initiative is +20 circ). (**A**) | S-1 (opt.) | — |
| Chronal Echo | 2232 | AETHERIAL FOCUS INSIGHT / L5, Chronal Awareness; R; Trigger "you are struck by an attack" | Force the attacker to reroll | FR-11, B (defence offer) | `registerCheckReaction` `after`, attack, `target`, `succeeded` = hit | After-check reaction when the reactor is the target and the attack hits (weapon and spell attacks); `askReactor`; reaction + Focus spent; core reroll. (**B**) [5] | — | — |
| Radiant Bulwark | 2520 | AETHERIAL / L5, Radiant Presence | "Allies within your aura also gain a +1-circumstance bonus to DB" | FR-40, A | ally aura | Second `auras` row, 10 ft, `allyEffect` DB +1 circ (`system.combat.defence.circumstance`). (**A**) | — | — |
| Radiant Presence | 2530 | AETHERIAL / Caelari Heritage | Emanate light 10 ft (+2 steps); allies in the aura +1 circ saves vs fear | FR-41, A; EA-m21 fixed in v1.6 | `registerLightSources`; ally aura; fear-trait conditional | Light key `radiantPresence` (steps 2, 10 ft), carried by an **actor** effect the module lays when the feat is added (and lifts when removed), then `refreshTokenLight`. Aura `allyEffect` conditionals +1 circ save, `traits [fear]` auto, plus a tick for an unseen source. (**A**) [6] | S-1 (opt.) | Q5-6 |
| Resonant Ascendance | 2548 | AETHERIAL FOCUS METAMAGIC / L10, Resonant Harmony; R; Trigger "a target casts a spell that you are aware of within 30 feet" | Dispel (Power Manipulation) check against the spell; "Regardless of the outcome, you only expend half of the normal PP" | FR-43, B; D10; EA-m22 fixed | `registerCastReaction` + `presetDispel` (Disrupting Magic, Block 3b) | Disrupting Magic's build at 30 ft: offered after the incoming check (Q33), awareness per Q28, trained Dispel required (`canDispel`); Success+ stops the spell; reaction + Focus; PP halved through S-2. (**B**) [7] | **S-2** | Q5-5 |
| Resonant Harmony | 2560 | AETHERIAL FOCUS METAMAGIC / L5, Resonant Pulse | A spell "that targets yourself" may also target one adjacent ally "with the same effect (if valid)" | FR-44, B; D2 | `shareSelfRows` exists, but a self-only cast reaches nobody else | A metamagic option (D2) offering an adjacent friendly token; the cast's self rows also land on it; rows that cannot (notes) are said on the card; Focus. (**B**) [8] | D2 + **S-8** | Q5-9 |
| Resonant Pulse | 2570 | AETHERIAL FOCUS METAMAGIC / — | "When you cast a spell, you may increase its Spell Save DC by +1" | FR-45, B; D2 | `registerCastOption` gives `saveDC`, but not for innate/item casts | A metamagic option (D2): Save DC +1, offered only for a spell with a save, Focus spent. Interim on `registerCastOption` possible but misses innate casts. (**B**) [8] | D2 | Q5-9 |
| Skyborne Agility | 2660 | AETHERIAL / Aeralis Heritage | "While moving at least 15 feet on your turn", +2 circ DB until the start of your next turn | FR-55, A | movement pools (internal flag) | When your own turn's movement reaches 15 ft, an effect +2 circ DB, `startOfNextTurn`. Read through S-4 (or the core flag meanwhile). (**A**) [9] | S-4 | — |
| Skyborne Waltz | 2670 | AETHERIAL FOCUS / L5, Skyborne Agility | Feather Fall innate, focus trait | FR-56, A | core Feather Fall (PP 2, Reaction); `grantInnate` | `grantedSpells "Feather Fall"` + `grantInnate`. (**A**) | — | — |
| Starseer’s Intuition | 2690 | AETHERIAL / Astryn Heritage | +1 racial Spellcraft "to cast spells of the Insight school"; +1 racial Sense Motive | FR-58, A | conditionals `checkTypes [spellcraft]`, `traits [insight]` (Wyrmdral's shape) | Conditional, auto; AE `senseMotive.racial +1`. (**A**) | S-1 (opt.) | — |
| Starseer’s Sight | 2700 | AETHERIAL / L5, Starseer’s Intuition | Advantage on saves vs effects with the mental trait | FR-59, A | Nerathis's two rows (Block 1) | The same two conditionals (auto on a Mental-trait source, tick otherwise). (**A**) | — | — |
| Veil of Dusk | 2764 | AETHERIAL FOCUS / L5, Veil of Silence | Darkness innate, focus trait | FR-65, A | core Darkness (PP 4; innate gate PP ≤ level holds at 5) | `grantedSpells "Darkness"` + `grantInnate`. (**A**) | — | — |
| Veil of Silence | 2796 | AETHERIAL / Umbryth Heritage | "If the light level is Dim or less", +2 racial Stealth and Reflex saves | FR-68, B | `lightLevelForToken`; no conditional axis | Now: two ticks. With S-3: auto when your token's level ≤ 5. (**B**; A with S-3) | **S-3** | Q5-8 |

**Notes**
1. Pending rows are ticks in the ally's dialog; `auto: true` pre-ticks. "Before the end of their next turn": `pendingTurnsFor(isOwnTurn)`. Out of combat, an effect with a oneShot conditional and a 1-round clock. Offer only once per cast.
2. The Use finds the Astral Lore entry in `system.specialistSkills`; if the sheet has none, it says so (as the core's warning). Specialist skills from a background are not offered: the text says "your racial specialist skill".
3. "Free action at the start of your turn" is read as 0 AP, before any AP is spent that turn. Focus: one use, Refocus restores it (Q36). The module already has Ethereal Form's effect shape. The pass-through clause is the one part the core cannot do; Ethereal Form and Eclipsed Form (another list) share it.
4. "All 3 AP" is read as: the turn's AP were all spent on actions with the Movement trait (Stride, Step, Crawl, Climb, Swim, Fly, Sneak …), and there were at least 3. Offered at your turn's end (`trgPrimeTurnEnded`); the Step is armed free of AP and capped at 5 ft. Without S-4 the module must keep its own tally from the core's internal flag and `trgPrimeActionResolved`.
5. The core's after-reaction reroll is locked ("cannot be modified further"); the book does not say so (Minor 4). One reroll per check, so a Witch's Missed Chance and Chronal Echo cannot both apply.
6. A feat's transferred effect is not in `actor.effects` on V14, so the light needs an actor-owned effect. The aura excludes the emitter ("Allies"). No light cap is printed (the Light cantrip's is 8); built uncapped.
7. "A target casts" is read as any creature but you; the player declines for allies (Q28). It shares Disrupting Magic's reaction step, but at 30 ft and with the half-PP factor.
8. Both carry the METAMAGIC trait, and Eldritch Arts reads metamagic feats elsewhere: Metamagic Conduit (L3816, Block 6), the Resonance spell (L7168, Blocks 7–8). See Q5-9.
9. The core pools hold terrain-adjusted **cost**, so 10 ft of difficult ground counts as 20. S-4 gives feet. A teleport is not movement for this purpose (proposed reading).

#### Racial feats for other races

How each is offered: an EA feat with `category "Racial"` and `sourceRace` the core race appears in that race's Racial Feat picker, and in the picker of anyone whose Heritage feat opens that race (a Half-Elf sees the ELF feats; a Quiliesh sees the ASCENDAN ones). **HUMAN** → `"Human"`; **ELF** → `"Elf"`; **GNOME** → `"Gnome"`; **KORNARGON** → `"Kornargon"`; **ASCENDAN** → `"Ascendan"`. **HERITAGE** is a trait, not a race: it goes in `traits` (the core's 1st-level gate reads it), and Quiliesh's race is Q5-1.

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Ancestral Reverie | 2170 | ELF / — | "During daily preparation, you may choose any one Intelligence or Wisdom based skill. Until the next day", +2 racial | FR-05, B | `replaceFeatEffect(…, {dailyPrep: true})`, `trgPrimeDailyPreparation`, `SKILLS[k].ability` | At daily preparation the owner is asked (Use as fallback): one of the 17 Int/Wis master skills; effect `skills.<k>.racial +2`, swept at the next preparation. (**B**) [10] | — | — |
| Endless Adaptation | 2412 | HUMAN / — | "Once per day, you may treat any skill check as if it were a class skill with an additional +2 class bonus" | FR-28, B | `usesPerDay`; `addPendingModifier`; class bonuses stack by source (`dice/resolution.mjs` `BONUS_TYPES.class`) | Use (1/day): choose the skill; a pending oneShot modifier, type class, on the next skill check, labelled with the skill: class bonus + 2 if not a class skill, +2 if it is. (**B**) | — | Q5-7 |
| Feyblood Glamour | 2428 | GNOME / — | +1 racial Deception and Perform | FR-30, A | AE keys | AE. (**A**) | — | — |
| Moonlight Precision | 2476 | ELF / — | "When in Dim Light or Twilight (light levels 5 & 6)", +1 racial ranged attacks and Spellcraft checks | FR-35, B; EA-m20 fixed in v1.6 | `lightLevelForToken`; `attackModes [ranged]`; `checkTypes [spellcraft]` | Now: ticks. With S-3: auto when your token's level is 5 or 6. Spell attacks are the casting check, so they are covered. (**B**; A with S-3) | **S-3** | Q5-8 |
| Quiliesh | 2512 | HERITAGE / — | +1 racial Arcana, Occultism; one Arcane or Ethereal cantrip "cast … using your Spellcraft attribute"; "may also select racial feats which are available to the Ascendan race"; "gain the Forbidden Magic Ascendan racial trait" | FR-39, B | `registerHeritageRaceGrant`; `chooseSpell({ppCost: 0, tradition: "arcane\|ethereal"})` (non-innate); `grantedAbilities` (Half-Elf grants Nightvision this way); Heritage 1st-level gate | Traits "Heritage"; AE +1 ×2; Use: choose the cantrip (granted, Spellcraft, not innate: Block 1 interpretation 2); `registerHeritageRaceGrant("Quiliesh", ["Ascendan"])`; `grantedAbilities "Forbidden Magic"` (the core ability). Its card says a divine or verdant caster loses those spells. (**B**) [11] | — | Q5-1, Q5-3 |
| Relentless Will | 2540 | HUMAN / — | "The first time each day that you gain the dying condition, you do not gain a point of fatigued when leaving it"; advantage on the next save "within 1 minute of triggering this ability (going above 0 HP)" | FR-42, A | `applyDyingRecovery(…, {noFatigue})` (caller option only); oneShot effect conditionals | First Dying of the day marked (status hook; `usesPerDay 1`, reset at preparation); its recovery costs no fatigue through S-7. When you are next above 0 HP: effect, oneShot advantage on saves, 1 minute. (**A** with S-7; C without) [12] | **S-7** | — |
| Shadow’s Discipline | 2632 | KORNARGON / — | "While in Shadow Stance": +2 racial Reflex; after moving 10 ft on your turn in the stance, "may also roll a Stealth check to Hide even without traditional cover or concealment" | FR-52, B | Shadow Stance is the effect named "Shadow Stance"; Hide is refused only for Lesser Cover (`action-workflow.mjs:2391`) | A companion effect (Reflex `race +2`) laid and lifted with the Shadow Stance effect (create/delete hooks, one client). Hide clause: a card line on Hide while the stance is up and 10 ft has been moved; cover for Hide is the GM's in the core. (**C**) [13] | S-4 (opt.) | — |
| Unbound | 2754 | ASCENDAN / Level 1 only | "When using High Magic, you may ignore the usual restraints applied to you from Forbidden Magic" | FR-64, A; D1 | **Already done for everyone**: High Magic casts skip the tradition gate (`cast-workflow.mjs:972`, 3.680.0, L839) | As printed it changes nothing the core does not already do: shipped as a marker whose card says so, pending Q5-2. "Level 1 only" not gated (S-1). (**D**: no mechanics of its own) | S-1 (opt.) | Q5-2, Q5-3 |
| Veil of Honour | 2774 | FOCUS KORNARGON / L5; R; Trigger "you take damage from a melee attack" | Enter Shadow Stance, gaining concealed "(or if already in this stance, concealed triggers as if you had moved)"; "trigger an innate Daze spell against your attacker" | FR-66, B | `trgPrimeDamageApplied` (`context.melee`, `sourceUuid`); `askReactor`; `spendReaction`; `castAsReaction`; core Daze (PP 0, 30 ft) | On melee damage, ask the Kornargon's player; reaction + Focus; lay the "Shadow Stance" effect on the Kornargon's own ability item and Concealed to the start of the next turn (or renew it); cast a temporary innate Daze at the attacker's token with `castAsReaction`. (**B**) [14] | S-9 (opt.) | — |

**Notes**
10. Int: Arcana, Artistry, Crafting, Culture, Linguistics, Occultism, Planes, Power Manipulation. Wis: Handle Animal, Medicine, Meditation, Mental Focus, Nature, Perception, Religion, Sense Motive, Survival. Specialist (Lore) skills carry no ability in `SKILLS`, so they are left out (Minor 6).
11. The grant makes the effective races "Human, Quiliesh, Ascendan". The Ascendan feats then offered include Unbound, Eternal Scholar and the core's Dracoris, Ascendan Magic and others. The same list also opens the Ascendan **heritages** in the heritage picker, as Half-Elf opens Elf heritages; that is the core's behaviour. The Heritage trait keeps Quiliesh at 1st level.
12. Every route out of Dying runs through `applyDyingRecovery`, so one seam covers healing, recovery checks and stabilising. The fatal-injury block still wins. The advantage window opens when HP first goes above 0 after that Dying: the printed parenthesis (Minor 7).
13. "In Shadow Stance" is read by the effect's name, as the core reads it for Grasp the Unseen. `stanceConditionals` cannot be used: they are read while *any* `featStance` effect is up, and Shadow Stance carries no such flag.
14. The reaction bypasses the stance's Open trait and its 1 AP, because the feat enters it as a reaction. The module writes the same effect and condition the core's Use writes, a small duplication; S-9 would remove it. Daze is cast as part of the reaction, at no AP, with no further Focus.

##### Proposed core seams

Essential to an automated build: **S-2, S-3, S-7, S-8** (with D2). The rest are optional.

- **S-1 Heritage and "Level N only" prerequisite clauses** (optional). *What:* `parsePrerequisiteClause` recognises "*Name* Heritage" (and the core's lower-case "heritage") against the actor's heritage item name, and "Level N only" as a maximum. *Why:* the picker offers Chronal Awareness to every Aetherial, and Unbound at any level. *Where:* `prerequisites.mjs` `parsePrerequisiteClause` / `meetsParseablePrerequisites`, plus the heritage name in `picker-filters.mjs` `actorPrerequisiteStats`. *Used by:* Chronal Awareness, Radiant Presence, Skyborne Agility, Starseer’s Intuition, Veil of Silence, Unbound (and the other lists' heritage feats, Ember Eyed). It also changes core feats (Fire-Like Blood, Arctic Elf, Necrotic Resilience, Tusks, Beastman), so it needs Graham's yes; today it fails open, as the core intends.
- **S-2 Dispel PP factor** (D10's smallest piece). *What:* `presetDispel.ppFactor` (0.5), or `registerDispelModifier(key, ctx => ({ppFactor, label}))`; the PP actually paid is `ceil(paid × factor)`, the PP declared for the counteract roll is untouched. *Where:* `combat/action-workflow.mjs` ~4346 (the Dispel `ppCost` branch). *Used by:* Resonant Ascendance (also Runebreaker, Threadbreaker's Precision in other lists).
- **S-3 Light-level conditional axis.** *What:* a scope axis `lightLevels` (a list, or `{min, max}`), filled on every check from the roller's token by `lightLevelForToken` (ambient: Q5-8). *Where:* `conditionals.mjs` `SCOPE_AXES` / `AXIS_CONTEXT_KEYS`, filled in `dice/check.mjs` and `apps/check-dialog.mjs` (which already calls `lightLevelForToken`). `verify-conditionals` must see a call site fill it. *Used by:* Veil of Silence, Moonlight Precision (and Ghostscale, Silent Veil, Veilstride in other lists).
- **S-4 Movement this turn, read-only** (optional; the core flag works meanwhile). *What:* `helpers.movementThisTurn(actor)` → `{feet, apOnMovement}`: feet from the move's measured distance (not cost), AP from the pools and from Movement-trait actions. *Where:* `combat/movement-workflow.mjs` `movementState`; API in `module-api-workflow.mjs`. *Used by:* Skyborne Agility, Astral Drift, Shadow’s Discipline (Veilstride elsewhere).
- **S-5 Ease magical difficult terrain.** *What:* `ignoresDifficultTerrain: "magical"`, honoured only on a region a spell or magical effect made (the regions `magic/difficult-terrain.mjs` builds carry a cast id). *Where:* `combat/passive-feats.mjs` `terrainReliefScope` / `wildStrideCost`, and the region test in `combat/movement-workflow.mjs`. *Used by:* Astral Drift. Without it that clause stays a card.
- **S-6 Incorporeal passage** (optional). *What:* `passageThrough({incorporeal: true})` allows an occupied square (it may not end there); walls stay the GM's. *Where:* `combat/space.mjs` `passageThrough` and its caller. *Used by:* Astral Crossing (Ethereal Form, Eclipsed Form).
- **S-7 Dying recovery modifier.** *What:* `registerDyingRecoveryModifier(key, ctx => ({noFatigue, line}))`, asked inside `applyDyingRecovery` with `{actor}`; the module decides "first time today". *Where:* `combat/death-state.mjs` `applyDyingRecovery`. *Used by:* Relentless Will (Tideweaver's Resilience may use it too).
- **S-8 A metamagic or cast option adds a recipient to a self-only spell** (fold into D2). *What:* an option may answer `shareWith: [tokenUuid]`; the core sets `shareSelfRows` and adds those creatures to the cast's reached list for self rows only. *Where:* `magic/cast-options.mjs` `appliedCastOptions` (or D2's `mods`), `magic/spell-degrees.mjs` `selfRowRecipients`. *Used by:* Resonant Harmony.
- **S-9 Shadow Stance for a module** (optional). *What:* `helpers.enterShadowStance(actor, {apCost: 0, ignoreOpen: true})` running the core Use's body. The same release could give its effect the `featStance` flag, so "any stance" rules see it (Minor 9). *Where:* `feats-workflow.mjs` FEAT_AUTOMATION "shadow stance". *Used by:* Veil of Honour.
- **D2 module metamagic** (Block 6, already planned): Resonant Pulse, Resonant Harmony.

##### Questions

- **Q5-1, Quiliesh: who may take it?** It prints only HERITAGE ("mortals touched by the First Race"), no race. **Why it matters:** with no `sourceRace` it would be offered to every race, Ascendan and Nyrinn included. **Proposed:** `sourceRace "Human"`, as all four core Heritage racial feats are (Half-Elf, Half-Orc, Half-Ogre, Beastman). Say if other races may take it.
- **Q5-2, Unbound has nothing left to do.** "When using High Magic, you may ignore the usual restraints applied to you from Forbidden Magic." L839 already says "These restrictions are irrelevant when it comes to high magic", and since 3.680.0 the core skips the tradition gate for every High Magic cast (`cast-workflow.mjs:972`). A Highmagic spell also counts as every tradition, so arcane is always open to an Ascendan. **Why it matters:** a 1st-level feat pick that does nothing. **Proposed:** say what Unbound should add. Until then it ships as a marker whose card says the core already applies it. If you meant L839 for the Sorcerer's tradition spells only, Unbound would become the general route, and 3.680.0's bypass would be narrowed to the classes that grant High Magic plus Unbound.
- **Q5-3, Forbidden Magic against High Magic spells.** M27: Highmagic spells "count as belonging to all traditions". The core therefore applies Forbidden Magic's "−2 penalty to all saving throws against these traditions" and its beneficial-spell Will save to **every** High Magic spell aimed at an Ascendan or a Quiliesh (`highMagicTraditions`, the −2 conditional's `traditions [divinity, verdant]`). **Why it matters:** every Eldritch Arts class casts High Magic. **Proposed:** they do not apply, since such spells "are classed as high magic and not the tradition they hail from" (L837). This needs a small core change, and it is not something Unbound can fix ("when using", not when targeted).
- **Q5-4, Astral Step's action.** No Action line is printed (Astral Crossing prints 0 AP). **Why it matters:** a free teleport the length of your speed every Refocus. **Proposed:** 1 AP, as Elemental Step, Dimensional Step and Gale Step, to an unoccupied space (the core refuses an occupied one).
- **Q5-5, Resonant Ascendance's "half of the normal PP".** Dispel already costs half on a Critical or Partial (`action-workflow.mjs:4348`, rounded up). **Why it matters:** half again, a quarter, would make a Critical almost free. **Proposed:** half the declared PP, rounded up as the core's Dispel rounds, whatever the degree; the halves do not compound. The counteract roll still uses the PP declared.
- **Q5-6, Radiant Presence is always on?** "You emanate light in a 10’ radius". **Why it matters:** a Caelari raises the light 2 steps wherever they stand, which spoils Hide and Sneak in the dark, their own and their allies'. **Proposed:** always on as printed, as you ruled for Null Aura (M22). Say if it should be switchable (as an Active toggle).
- **Q5-7, Endless Adaptation on a skill that is already a class skill.** "Treat any skill check as if it were a class skill with an additional +2 class bonus." **Why it matters:** the bonus is the class bonus plus 2, or just 2. **Proposed:** not a class skill: class bonus + 2, both of type class (class bonuses from different sources stack); already a class skill: +2 only.
- **Q5-8, "Light level" for Veil of Silence and Moonlight Precision.** **Why it matters:** an Elf has Nightvision, which raises the level *it perceives* by one, so the same spot can read Twilight or Flickering. **Proposed:** the ambient level where your token stands (light sources, Darkness, regions and weather included), not raised by your own Darkvision or Nightvision; Moonlight Precision reads the attacker's square.
- **Q5-9, Resonant Pulse and Resonant Harmony: now or with D2?** They print METAMAGIC, and Metamagic Conduit and the Resonance spell read your metamagic feats. Today's cast-option seam is not shown for innate, item or no-check casts. **Why it matters:** built now, they miss innate spells (the heritages' and the Warlock's) and would be built twice. **Proposed:** ship both items in Block 5 with a card saying they arrive with D2. Build them as D2 metamagic options in Block 6 (Pulse: Save DC +1; Harmony: S-8's recipient), Focus spent, at no PP. Resonant Ascendance is a reaction Dispel, not a warp, and is built now.

##### Waits on other blocks

- **Resonant Pulse, Resonant Harmony:** D2 module metamagic (Block 6), with S-8 for Harmony (Q5-9). Items ship in Block 5 as text-plus-card.
- **Metamagic interactions** for all three Resonant feats: Metamagic Conduit (charged-item casts, Block 6 and D12 in Block 9), the Resonance spell (Blocks 7–8). Not needed to ship.
- Nothing else in these 27 waits. Feather Fall, Darkness and Daze are core spells; Blocks 1–4 delivered the heritages, High Magic (D1), the reaction seams and the teleport helper.

##### Minor

1. **Curly apostrophes:** Starseer’s Intuition/Sight and Shadow’s Discipline. The core's prerequisite match is exact (`prerequisiteNameKey`), so the feat names and "Starseer’s Intuition" in Starseer’s Sight's prerequisite must both keep ’.
2. **Traits:** the race traits (AETHERIAL, ELF …) go into `sourceRace`, not `traits`, as every core racial feat is built. FOCUS, METAMAGIC, INSIGHT, TELEPORTATION, TRANSLOCATION and HERITAGE stay in `traits`.
3. **EA-m20, m21, m22, m44** are fixed in v1.6: "When in Dim Light", "Allies within the aura", "within 30 feet", and Unbound's flavour is now its own.
4. **Chronal Echo:** the core's reaction reroll is always locked ("the second result stands"); the book says only "reroll". Proposed: accept the core rule.
5. **Resonant Ascendance:** METAMAGIC on a reaction Dispel is odd but harmless. Built as printed: the trait is carried, and it matters only to things that read metamagic feats.
6. **Ancestral Reverie:** the flavour line is the generic Elf race blurb ("Graceful, long-lived …"). Specialist (Lore) skills are left out of the choice because the core gives them no ability.
7. **Relentless Will:** "triggering this ability (going above 0 HP)": the window opens when HP first rises above 0 after that Dying (a recovery check alone leaves you at 0 HP). "Each day" means per daily preparation.
8. **Astral Drift:** "use all 3 AP": a character with a 4th AP (Haste) qualifies if every AP went on Movement actions (proposed).
9. **Core defect, found in passing:** the Kornargon's Shadow Stance effect has no `featStance` flag (`feats-workflow.mjs` "shadow stance" uses `replaceFeatEffect`, not `enterFeatStance`). So `inAnyStance` is false while a Kornargon is in it, and "while in any stance" rules (Tranquil Mind, Inner Tempest's Martial Affinity) never see it. Worth fixing with S-9.
10. **Radiant Bulwark:** "your aura" is Radiant Presence's 10 ft; built as its own aura row so either feat works alone if ever granted.
11. **Aetherial Concord / Arcane Echo:** both trigger on a successful cast. Proposed reading as Q50: any spell cast successfully, cantrips and innate spells included.
12. **Quiliesh cantrip:** cast with Spellcraft, so not innate (unlike the Ascendan's Arcane Knowledge, which is innate Focus). Chosen once, at 1st level.


### Appendix B. Emberkin and Nyrinn racial feats

Read against *Eldritch Arts* v1.6 (`book-text.json` `sections.racialFeats`; `ea.md` line numbers), Graham's rulings of 1 November 2026, the Block 1–4 audits, and TRG Prime **3.682.3** (`/home/claude/core-3676/trg-prime`). Each "core has" claim was read in that source. The core packs were read from copies in the scratchpad.

**Cross-cutting facts used below:**
- **Race tags.** A feat's `sourceRace` may list several races. The racial-feat picker opens it to anyone holding one of them (`picker-filters.mjs:845–867`, `matchesSource`). So "Ascendan, Emberkin" and "Kornargon, Nyrinn" need no `registerFeatAccess`: Ascendan and Kornargon are core races (core races pack).
- **Prerequisites.** Feat-name and Level clauses are gated (`prerequisites.mjs`). **"X Heritage" and "Level 1 only" fail open** (`prerequisites.mjs:12–18, 76`).
  - Heritage gating can use what exists: tag the feat's `sourceRace` with the heritage name (which no race carries), and open it with `registerFeatAccess("race", "Nyrinn", [{ name, heritages: ["Vir-ellian"] }])` (`module-api.mjs:528–575`, the heritage limit added in 3.669.0).
  - S5 below is the optional core alternative.
- **Heritage element.** Each Emberkin heritage carries `flags.trg-prime.eaElement`: Stonevein acid, Galeborne electricity, Cinderblood fire, Tidemarked cold (`tools/content/block1.mjs:72–76, 222`).
- **Null Aura's radius:** `nullAuraFeet()` (`module/block1-automations.mjs:62`), which the gate, the Zhal-vryn surcharge and `aurasReaching` all read.
- **Vir-ellian Release:** `virEllianRelease` (`block1-automations.mjs:478`). **Magic Drain:** `magicDrain` and `resolveMagicDrain` (`:461`, `:631`).
- **Focus** follows Q36: one use, restored by Refocus or daily preparation (`uses.mjs` `focusDefaultUses`).
- **No DC printed** follows C3: the target's Level DC.

**Prerequisite chains (all gated by the core's feat-name clause):**
- Elemental Bulwark → Elemental Reprisal (L5) → Elemental Apotheosis (L10).
- Mindshroud → Voidbound Resolve (L5) → Anchor in Nothing (L10).
- Silent Veil (Vel-tharis) → Veilstride (L5) → Night's Embrace (L10). This makes the whole chain Vel-tharis only.
- Voidborn Wings (L5) → Voidborn Grace (L10).

**Granted spells.** Both exist in the core spells pack (read from the pack copy):
- **Invisibility:** PP 4, Shadow, the `invisible` condition plus a note.
- **Fear:** PP 2, Enchantment Fear, frightened by degree.

Both are granted through the feat's `grantedSpells` with `grantInnate`, which the core reads on any source item (`grants-workflow.mjs:430`). Both are within the innate level limit at the feats' levels (10 and 5).

**Cancel Magic** (the Zhal-vryn's innate spell, which Threadbreaker's Precision names) is, in the core pack, **a ward:** "You make all saving throws against the specified realm with advantage" (PP 2, Chance Warding). It has **no Dispel check and counters nothing** (Q?-1).

#### Emberkin racial feats

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Echo of the Ancestors | 2292 | Elemental Emberkin Focus Metamagic / — | PP +2: a spell whose elemental damage matches your heritage is "duplicated … at half damage targeting a second creature within range" | FR-17, B via D2 | No module metamagic: `buildMetamagicOptions` is a hard-coded table (`magic/metamagic.mjs`). No `registerMetamagic` in the 3.682.3 API. `registerSpellWarps` has no "second target at half damage" mod | **B, deferred:** item now with a note; option on D2 (n1) | D2 | Q?-9 |
| Elemental Apotheosis | 2316 | Concentrate Elemental Emberkin Focus Warding / L10, Elemental Reprisal | 1 AP: immunity to heritage element 1 min; "all elemental damage that you inflict of that type inflicts an additional point of damage per die" | FR-19, A | Immunity by AE (`system.combat.immunities`, as Symbiosis). `spellDamageBonus` is flat per roll and trait-scoped, not per die or damage type (`magic/spell-damage-bonus.mjs:48–94`) | **A:** Use (1 AP, Focus); timed AE with immunity and a per-die bonus of the element (n2) | S2 | Q?-4 |
| Elemental Bulwark | 2340 | Elemental Emberkin Focus / — | 0 AP, trigger: you take damage of your heritage's element: +1 racial DB and saves until the start of your next turn | FR-21, A (cites EA-m10 in error) | `trgPrimeDamageApplied` with `damageTypes` (`combat/dying-workflow.mjs:79`); `askReactor`; racial slots `system.combat.defence.racial`, `system.combat.saves.<s>.racial` | **B:** offered to the owner on the hook when a type matches `eaElement` and damage > 0; Focus use; AE to the start of the next turn | none | — |
| Elemental Reprisal | 2350 | Elemental Emberkin Focus Invocation / L5, Elemental Bulwark | 0 AP, same trigger: 1d4 per 2 levels of your element to one adjacent target, basic Reflex | FR-22, B | As above, plus `basicSaveHit`, `levelDC` | **B:** offered on the hook; pick an adjacent token; basic Reflex against the **target's Level DC** (C3); Focus use. Asked after Bulwark, each its own use | none | — |
| Elemental Step | 2362 | Concentrate Emberkin Focus Teleportation / L5 | 1 AP: teleport up to land speed to an unoccupied space you can see; no attacks of opportunity | FR-23, A | Teleport through the token update, with an occupied end square refused (3.680.1); Teleportation trait once a turn (`traits.mjs:115`, `traitGate`/`recordTraitUsage`) | **B:** as Gale Step (`block3-automations.mjs:287`): click a point within land speed, Focus use, 1 AP. "Can see" is the player's | none | — |
| Emberborn Fury | 2374 | Emberkin Fire / Cinderblood Heritage | "Whenever you deal fire damage with a spell or effect, you add +1 damage per die rolled" | FR-24, A | Flat spell bonus only (as above) | **A:** passive per-die fire bonus on your spells; the module's own fire abilities add it themselves (n2) | S2 | Q?-4 |
| Ember Eyed | 2384 | Emberkin / Level 1 only | Darkvision | FR-25, A | Core Darkvision ability; `bestLightStep` keeps the better step (+2 over the race's Nightvision +1; `light.mjs` `LIGHT_STEPS`) | **A:** `grantedAbilities: "Darkvision"`. "Level 1 only" is not gated by the core (Minor) | none | — |
| Emberkin Scholar | 2404 | Emberkin / — | +1 racial Arcana and Nature; "+2 bonus to your racial specialist skill" | FR-27, A | Core Scholar feats: AE for the +1s plus a Use that picks the specialist slot (`feats-workflow.mjs:1085` `specialistSkillBonus`, not on helpers) | **A:** AE +1 racial (`system.skills.<k>.racial`); +2 racial on the race's **Elemental Lore** slot, found automatically (asked only if it is missing) | none | — |
| Eternal Scholar | 2420 | Ascendan Emberkin / — | +1 racial Arcana, Occultism, Linguistics | FR-29, A | Multi-race tag (above) | **A:** AE; `sourceRace "Ascendan, Emberkin"` | none | — |
| Mantle of Essence | 2458 | Concentrate Emberkin Focus Warding / — | R, trigger: you cast a spell: +1 circumstance DB until the start of your next turn; +1 at 5th and every 5 | FR-33, A | `trgPrimeSpellSettled`; `spendReaction`; `system.combat.defence.circumstance` | **B:** offered after your cast settles (n3); reaction plus Focus; +1 + ⌊level/5⌋ | none | — |
| Stonebound Bastion | 2710 | Alteration Earth Emberkin / Stonevein Heritage | +2 racial to Fortitude saves vs being shoved, tripped or otherwise moved; Critical Resistance 1 | FR-60, A; EA-m25 (settled by v1.6: EARTH) | `flags.trg-prime.defenceDC` rows (Storgar precedent, Graham 16 Aug 2026; `combat/defence-dc.mjs:1–30, 273`): Shove Attack is against `fortitudeDC`, Trip against the higher of Acrobatics or Fortitude DC (`data/basic-actions.mjs:312, 383`). CR is an AE on `system.combat.criticalResistance` (template field; derive adds to it, `documents/actor.mjs:592–621`) | **B:** defence-DC rows `+2 race` on `fortitudeDC` for `shoveAttack`, `tripAttack`; a ticked +2 on Fortitude saves to resist forced movement; CR +1 AE (n4) | none | — |
| Stormrunner's Zeal | 2720 | Alteration Electricity Emberkin / Galeborne Heritage | Whenever you take electricity damage: fly speed = land speed until the end of your next turn | FR-61, A | Speed grant by an ability item `creatureAbility.derives.movement {key:"fly", orLand:true}` (`combat/granted-speeds.mjs`, `documents/actor.mjs:1664`). **A creature whose fly speed vanishes mid-air is not dropped** (`combat/fly.mjs:201–203`: "no fly Speed") | **A:** on the hook, a temporary fly item to the end of the next turn (re-hit extends it); if it ends airborne, the module drops and rolls the fall (n5) | S3 | — |
| Tideweaver's Resilience | 2740 | Emberkin Healing / Tidemarked Heritage | 0 AP: +1 racial to any checks while submerged; 1/day when reduced to less than 0 HP, heal level + Wisdom ("prevents … the dying condition") | FR-63, B; EA-M12 (Graham: the cold trigger dropped; v1.6 drops it) | Death guards (`combat/death-guard.mjs`): `offer`, `frequency:"daily"`, `askOwner`, at the 0-HP moment before Dying. But a zero-HP guard leaves **1 HP**, with no heal amount. Underwater Regions: `tokenIsUnderwater` (`combat/underwater-workflow.mjs:60`), not on helpers | **B:** death guard offered once a day, healing to level + Wis; submerged +1 racial to all checks, toggled by the module as the token enters or leaves water (n6) | S4, S3 | Q?-5 |
| Vein of Power | 2806 | Emberkin / — | +1 Spell Adder; +1 at 5th and every 5 | FR-69, A; EA-R7 (ruled: adders from different sources stack) | `flags.trg-prime.spellAdder` on any item: N free casts a day (`magic/spell-adder.mjs:60–78`); the rating is a static number | **A:** the module writes `spellAdder = 1 + ⌊level/5⌋` on the feat at creation, level change and daily preparation | none | — |

**Notes (Emberkin)**
1. **Echo of the Ancestors**
   - D2 (Block 6) has to carry three things:
     - a Focus use spent with the option;
     - a match on "a damage type equal to your heritage element" (not a trait);
     - an "extra target at half damage" mod.
   - The 3.682.3 warp vocabulary has none of these. The feat item ships now with "Metamagic: arrives with Block 6."
2. **The per-die bonus (Fury, Apotheosis) needs S2.** The module's own fire or element damage (Reprisal, a Wyrmdral breath of fire) adds it in the module, where the formula is built.
   - Fury and Apotheosis both apply to a Cinderblood's fire. The proposal is that they stack: different sources, no type printed (Q?-4).
3. **Mantle's trigger** is read as a spell you cast that lands (Success or better), cantrips, innate spells and item casts included. See Minor.
4. **Stonebound Bastion:**
   - Trip is against the higher of the two DCs, so the +2 counts only when Fortitude is the one used. That is the honest result of Graham's Storgar ruling.
   - "Otherwise moved against your will" by a spell's save has no forced-movement axis on saves, so it is a tick (B).
5. **"You fall" when a granted fly speed ends airborne**
   - **Where the gap is.** The core lets a creature with no fly Speed stay aloft by design ("held up by a spell"), and `rollFalling` is not on the helpers.
   - **Who needs it.** Zeal, Voidborn Wings and Voidborn Grace each have to drop the token themselves: elevation to 0, then the core's Falling From Height with the distance prefilled.
   - **What fills it.** S3 exposes `rollFalling`. Without S3 this part is a card, and the GM uses the sheet's Falling button.
6. **Tideweaver's Resilience**
   - **"Submerged":** the token is in a Region the core counts as underwater (flag or name, `combat/underwater.mjs`).
   - **"Any checks":** attack checks, saves and skill checks.
   - **Without S3,** the module repeats the core's one-line Region test.
   - **Without S4,** the guard can only leave 1 HP. The module would then top up to level + Wis after the guard holds, which works but posts two cards.

#### Nyrinn racial feats

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Anchor in Nothing | 2178 | Nyrinn / L10, Voidbound Resolve | 0 AP, trigger: asked to make a Will save; 1/day: "choose to get a success result on the save before the dice are rolled" | FR-06, B ("core saveReaction flag") | `saveReaction` answers advantage only (`magic/save-reactions.mjs`). `registerCheckReaction.before` answers advantage only (`reactions/reactions-workflow.mjs:35–73`). `fateDeclare` (Prism Lotus) declares a Success but is unscoped, so it would be offered on every check, and it is effect-only (`dice/fate-declare-workflow.mjs`). `declaredDegree` machinery exists (`dice/check.mjs:211, 1439`) | **B:** a check reaction before any Will save (`subject "will"`): "Declare a Success?" Once a day; the card says the dice do not count | S1 | — |
| Crystal Pulse | 2252 | Nyrinn / Vir-ellian Heritage | Release may deal electricity or force; "as a 1 AP (focus) action, you may increase the damage by 1d4" | FR-13, B; EA-M24 (ruled: area 30 ft) | Module's `virEllianRelease` (force, `runAreaEffect`) | **B:** the release asks force or electricity, and adds +1d4 (n7) | none | Q?-3 |
| Eclipsed Form | 2304 | Concentrate Focus Nyrinn / L10 | 2 AP: incorporeal until the start of your next turn; move through solid objects (not end there); half damage from non-magical physical attacks | FR-18, A | Core **Incorporeal trait = immune to non-magical attack forms and precision damage** (`codex-trait-rules.mjs:113–117`, `combat/damage.mjs:274`), stronger than printed. `registerDamageReaction` answers resistance per blow with `kind`, `types`, `magical` (`module-api.mjs:1374–1390`) | **C:** Focus, 2 AP; a damage reaction answering resistance to bludgeoning, piercing and slashing for a non-magical weapon blow, while the effect lasts. Passing through objects is the GM's (walls) | none | Q?-2 |
| Mindshroud | 2468 | Fortune Nyrinn / — | Advantage on saves vs effects with the Emotion trait; 1/day, when you fail a Will save, reroll it | FR-34, B | Conditional `kind:"advantage"`, `when:{checkTypes:["save"], traits:["emotion"]}`: the save carries the effect's traits (`conditionals.mjs:78`; `magic/cast-workflow.mjs:6721`). `registerCheckReaction.after` gives one locked reroll (Second Chance precedent, `block3b-automations.mjs:242`) | **B:** advantage is A (auto conditional). The reroll is offered on a failed Will save once a day | none | — |
| Night's Embrace | 2484 | Nyrinn / L10, Veilstride | Invisibility innate (Focus); no tracks or scent while invisible by it | FR-36, A | Core Invisibility; innate grant | **C:** the spell is A. "No tracks or scent" is a card (tracking is the GM's) | none | — |
| Nyrinn Scholar | 2494 | Nyrinn / — | +1 racial Occultism and Planes; "+2 bonus to your racial specialist skill" | FR-37, A | As Emberkin Scholar. The Nyrinn has **two** racial specialist skills, Spell Lore and Nyrinn Lore (`block1.mjs:193`) | **B:** AE +1s; Use picks which of the two gets the +2 racial | none | Q?-8 |
| Shadow Initiate | 2624 | Flourish Kornargon Nyrinn / — | +2 racial Stealth; in light level 5 (Dim Light) or less, speed +5 ft | FR-51, B | Light at a token: `lightLevelForToken` (`light-workflow.mjs:100`), not on helpers. Movement is a pooled stat (`system.combat.movement.land.<type>`) | **A:** AE +2 racial; the module keeps a +5 ft (racial) land-speed effect on while the token's ambient light is ≤ 5, rechecked on movement, light changes and turn start. `sourceRace "Kornargon, Nyrinn"` | S3 | — |
| Silent Veil | 2650 | Nyrinn / Vel-tharis Heritage | Null Aura radius +5 ft; may Hide while observed in light ≤ 5 | FR-54, B | `nullAuraFeet` (module); the core Hide action does not refuse an observed hider (`data/skill-actions.mjs:1952`, requirements unenforced) | **C:** the radius is A (`nullAuraFeet` adds a feat flag `eaNullAuraBonus: 5`, so Vel-tharis 15 ft). Hiding while observed is a note, since the core has no refusal to lift | none | — |
| Threadbreaker's Precision | 2730 | Nyrinn / Zhal-vryn Heritage | "When using Cancel Magic, +2 racial to the Dispel check … if you successfully counter a spell, the caster is also Dazed 1 for 1 round" | FR-62, B via D10 | Core Cancel Magic is a ward, not a Dispel. Dispel action key `dispel` (`data/skill-actions.mjs:1721`); Counter Spell feat re-runs it as a free action (`feats-workflow.mjs:7733`); Disrupting Magic uses `presetDispel` (3.681.0). Conditionals scope `actions:["dispel"]`; `trgPrimeActionResolved {action, degree, targetActor}` (`action-workflow.mjs:5697`). No D10 | **B** (on Q?-1's proposal): conditional +2 racial on `dispel`, auto. On a Success or better that counters (Counter Spell's or Disrupting Magic's), the caster gets Dazed 1 for 1 round through `applyConditionTagsTo`; the caster is the targeted token, or the cast reaction's caster | none (D10 later) | Q?-1 |
| Veilstride | 2786 | Nyrinn / L5, Silent Veil | "When you move at least 10 ft in light level 5 (Dim Light) or less before making a melee attack, you have advantage on that attack" | FR-67, B | `registerCheckReaction.before` advantage on attack checks (`check.attackMode` exists, `dice/check.mjs:271`); Foundry V14 token movement history; light as above | **A:** a check reaction on your melee attack checks: advantage when you moved ≥ 10 ft this turn and stand in ambient light ≤ 5; spent on the first melee attack after that move | S3 (S1 fields) | Q?-6 |
| Voidborn Grace | 2814 | Nyrinn / L10, Voidborn Wings | Hover while using Voidborn Wings; when the flight ends, descend 60 ft per round, no damage unless interrupted (grappled, knocked prone) | FR-70, C | Hover: an ability's `derives.hover` stops the turn-end fall (`creature-ability-rules.mjs:111`, `combat/fly.mjs:205–207`) | **C:** hover is A (the wings' fly item carries `hover: true`). The descent is automated: the module lowers elevation 60 ft at each of your turn ends, and posts a card. An interruption is the GM's call (then S3's fall from the height left) | S3 | — |
| Voidbound Resolve | 2824 | Nyrinn / L5, Mindshroud | R, trigger: targeted by a spell that requires a Will save; class bonus per day: +2 racial to the save; "if this causes you to succeed", the caster takes 1d4 mental per 2 levels (basic Will) | FR-71, B | `before` answers advantage only. `usesPerDay` takes levelled steps (`uses.mjs:37–60`); class bonus is 2/3/4/5/6 at 1/5/10/15/20 (`config.mjs:218`). The check carries `isArea`, `saveSource`, `sourceUuid` (`check.mjs:264, 315–316`); `basicSaveHit` | **B:** offered before a spell's Will save that is not an area save; reaction plus a use; +2 racial. After the roll, if a Success or better would have failed by the +2, the caster takes the backlash (basic Will, caster's Level DC by C3). `usesPerDay "2, 3 at 5th, 4 at 10th, 5 at 15th, 6 at 20th"` | S1 | Q?-7 |
| Voidborn Wings | 2838 | Focus Nyrinn / L5 | Fly speed = land speed for level + Dex rounds per use (Focus); landing ends it; "if you end your turn in midair with no remaining flight rounds, you fall normally" | FR-72, A | Speed grant item, as Zeal; `trgPrimeTurnEnded` | **A:** Use (Focus): fly item `orLand`; rounds counted at your turn ends (6 s each out of combat); ends on landing (elevation 0) or at zero rounds, then the fall (n5) | S3 | — |
| Whispers of the Void | 2850 | Nyrinn / L5 | +1 racial Deception and Intimidate; Fear innate (Focus) | FR-73, A; EA-m27 (v1.6 prints "Intimidate") | Core Fear; innate grant | **A:** AE plus `grantedSpells "Fear"`, `grantInnate` | none | — |

**Notes (Nyrinn)**
7. **Crystal Pulse.**
   - The release is already 1 AP (Concentrate, Focus). The proposal is +1d4 on top of the energy's d4s, at no further AP and no further use (Q?-3).
   - The damage-type choice is offered before the area rolls.

#### Proposed core seams

**S1: what a check reaction's `before` may answer** (`reactions/reactions-workflow.mjs` `checkReactionsBefore`; `dice/check.mjs:1332`). Used by Anchor in Nothing and Voidbound Resolve; S1's ctx fields also serve Veilstride.
- **`modifiers: [{label, value, type}]`:** pushed onto the check before the dice. Voidbound Resolve's +2 racial; Tideweaver's submerged +1 could use it instead of a toggled effect.
- **`declare: "success"`:** sets `check.declaredDegree`, so the existing path at `check.mjs:1439` makes it exactly Success, says "the dice do not count", and closes Conviction, rerolls and conversions (Anchor in Nothing).
  - Once one answer declares, the loop stops asking, so Voidbound Resolve is not offered after it.
- **ctx gains `isArea`, `saveSource`, `sourceUuid` and `attackMode`.** They are on the check already; this makes them part of the contract instead of reading `ctx.check`.
- **Why:** both feats print a number or a degree, not advantage, and only `before` is asked at the right moment for every save path, spells included.

**S2: a per-die, damage-type spell damage bonus** (`magic/spell-damage-bonus.mjs` `declaredSpellDamageBonuses` / `withSpellDamageBonus`; call sites `magic/cast-workflow.mjs:5696, 6551` and the secondary pools at `:7074, :7081`). Used by Emberborn Fury and Elemental Apotheosis.
- **`spellDamageBonus` gains `perDie: 1` and `damageTypes: ["fire"]`,** matched on the pool's damage type, not the spell's traits.
- **Applied to every pool of that type the cast rolls** (primary and secondary), counting the dice actually rolled after warps. Not on recurring damage.
- **Why:** today the bonus is flat, once per cast, scoped by trait. That cannot say "per die" or "fire damage", which an Orb of Fire picked as another element shows.

**S3: three state readers on `helpers`.** Used by Shadow Initiate, Veilstride, Voidborn Grace, Voidborn Wings, Stormrunner's Zeal and Tideweaver's Resilience; Silent Veil's light clause stays a note.
- **`lightLevelAt(token)`:** `lightLevelForToken(doc).level`, `light-workflow.mjs:100`.
- **`isUnderwater(token)`:** `tokenIsUnderwater`, `combat/underwater-workflow.mjs:60`.
- **`rollFalling(actor, {distance})`:** `combat/falling-workflow.mjs` `rollFalling`, the Falling From Height card with the distance prefilled.
- **Why:** the module otherwise copies the core's light resolution and Region test, and cannot drop a creature whose granted flight ended. The core deliberately leaves such a creature aloft (`combat/fly.mjs:203`).

**S4: what a zero-HP death guard leaves you on** (`combat/death-guard.mjs` `normaliseDeathGuard`, `deathGuardHealTo`; `combat/death-guard-workflow.mjs` `tryDeathGuards`). Used by Tideweaver's Resilience.
- **`healTo: { level: true, ability: "wisdom" }`:** HP = level + Wisdom (min 1), in place of 1.
- **Why:** the guard exists, with `offer`, `frequency: "daily"`, `askOwner` and no Dying, but it can only leave 1 HP (or half, on "death" guards).

**S5 (optional): "X Heritage" as a gated prerequisite clause** (`prerequisites.mjs` `parsePrerequisiteClause`, with the picker's heritage in context).
- **Feats:** Crystal Pulse, Emberborn Fury, Silent Veil, Stonebound Bastion, Stormrunner's Zeal, Threadbreaker's Precision, Tideweaver's Resilience.
- **Not required:** the existing route is the heritage-limited `registerFeatAccess` with a heritage-name `sourceRace` (see the top).
  - S5 is cleaner, because the feat's tag stays "Nyrinn"/"Emberkin".
  - S5 reaches every book.

**Not needed now:**
- **D10.** Threadbreaker's +2 is a conditional on the `dispel` action, and its rider rides `trgPrimeActionResolved` or the module's own Disrupting Magic. When D10's `onResult` lands (Block 6), the rider can move there.
- **D2** is needed only for Echo of the Ancestors (Block 6).

#### Questions

**Q?-1: Threadbreaker's Precision and Cancel Magic.**
- **The issue.** "When using Cancel Magic, you gain a +2 racial bonus to the Dispel check. Furthermore, if you successfully counter a spell, the caster is also Dazed 1 for 1 round."
  - TRG Prime's Cancel Magic is a ward with no check: "You make all saving throws against the specified realm with advantage whilst this spell is running" (core spells pack, PP 2).
- **Why it matters.** As printed, the feat does nothing.
- **Proposed.**
  - "Cancel Magic" is read as **the Dispel (Power Manipulation) action, including its use to counter a spell** (the Counter Spell feat, Disrupting Magic).
  - **+2 racial** goes on every Dispel check. Not on Magic Drain's Dispel check, by the same line B1-22 drew.
  - **On a counter that succeeds** (Success or better), the caster is **Dazed 1 until the end of its next turn** (the round's length).

**Q?-2: Eclipsed Form's "incorporeal".**
- **The issue.** "becoming incorporeal … you take half damage from non-magical physical attacks."
  - The core's Incorporeal trait (Fiends & Fables) makes a creature *immune* to non-magical attack forms and to precision damage.
  - The module's Ethereal Form grants that trait.
- **Why it matters.** The trait gives immunity where the feat prints half damage.
- **Proposed.**
  - **The printed effects only, not the trait.** Half damage (resistance) against bludgeoning, piercing and slashing from non-magical weapon attacks.
  - **Passing through** solid objects, but not ending the turn in one.
  - Precision damage and other incorporeal rules do not apply. Your M78 note ("explained in Fiends & Fables") is read as covering the spells that say only "incorporeal".

**Q?-3: Crystal Pulse's +1d4.**
- **The issue.** "as a 1 AP (focus) action, you may increase the damage by 1d4".
- **Why it matters.** It could mean a separate 1 AP and a second Focus use, or the release itself, which is a 1 AP Focus action.
- **Proposed.** **Part of the release:** +1d4 to its damage, with no extra AP and no extra use. The damage type is chosen at each release.

**Q?-4: Emberborn Fury and Elemental Apotheosis, what the per-die bonus reaches.**
- **The issue.** "fire damage with a spell or effect … +1 damage per die rolled"; "all elemental damage that you inflict of that type".
- **Proposed.**
  - **What counts.** Your **spells** by any route (cantrips, innate, item casts) and your **magical abilities' damage** (Elemental Reprisal, a breath).
  - **Which dice.** Every pool of that damage type (primary and secondary), counting the dice actually rolled after warps. Not recurring damage.
  - **Weapons excluded.** Not weapon Strikes or their rune riders.
  - **Stacking.** Fury and Apotheosis stack for a Cinderblood, +2 per fire die.

**Q?-5: Tideweaver's Resilience, "reduced to less than 0 HP".**
- **The issue.** In TRG Prime, damage that reaches 0 HP clamps there and applies Dying (`combat/dying-workflow.mjs`), so "less than 0" never happens literally.
- **Proposed.**
  - **When.** Offered once a day when damage **would reduce you to 0 HP** (the death-guard moment).
  - **What you get.** You stay conscious at **HP = level + Wisdom** (min 1), and gain no Dying.
  - **The exception.** Not against a blow that kills outright (massive damage).

**Q?-6: Veilstride, what counts as the move.**
- **The issue.** "When you move at least 10 ft in light level 5 (Dim Light) or less before making a melee attack".
- **Proposed.**
  - **The move.** You moved 10 ft or more this turn, by your own movement. A teleport does not count as moving.
  - **The light.** You stand in ambient light 5 or less when you attack. That is the token's level, not raised by your own Darkvision.
  - **The attack.** Advantage on the **first** melee attack after that move, this turn.

**Q?-7: Voidbound Resolve.**
- **The issue.** "targeted by a spell that requires a Will save … +2 racial bonus to the saving throw. If this causes you to succeed, the caster suffers 1d4 mental (basic Will) damage per two levels".
- **Proposed.**
  - **"Targeted"** excludes area spells, as Gnome Resistance's same words do in the core (`areaExempt`).
  - **Timing.** The +2 is declared before the roll.
  - **"Causes you to succeed":** a Success or better that would have been below it without the +2.
  - **The backlash.** 1d4 per 2 of the Nyrinn's levels, the caster's basic Will against **the caster's own Level DC** (C3, the targeted creature).

**Q?-8: Nyrinn Scholar's "racial specialist skill".**
- **The issue.** It is singular, but the Nyrinn has two (Spell Lore and Nyrinn Lore).
- **Proposed.** You choose one, as the core Scholar feats ask. Using the feat again moves it.

**Q?-9 (for Block 6): Echo of the Ancestors' duplicate.**
- **The issue.** "you may duplicate the spell at half damage targeting a second creature within range".
- **Proposed.**
  - **One casting**, one check and one PP total (+2).
  - **The second creature** within the spell's range is affected as an extra target:
    - it makes its own save, or is compared with the same attack roll;
    - it takes **half the damage** (rounded down);
    - it takes the spell's other effects.
  - **Use.** One Focus use per echo.
  - **Matching.** Only when the spell's damage type is the heritage element.

#### Waits on other blocks

- **Echo of the Ancestors:** the whole option needs D2 (module metamagic), which is Block 6. The feat item can ship in Block 5 with a note. Q?-9 can be answered now.
- **Threadbreaker's Precision:** nothing waits. Its counter rider can move onto D10's `onResult` when D10 is built (Block 6). Disrupting Magic (Block 3b) is the module's own counter today.
- **Emberborn Fury and Elemental Apotheosis:** they reach the Grimoire's spells (Blocks 7–8) as those are built, with no further work, once S2 is in.

#### Minor

- **Matrix references.**
  - FR-21 (Elemental Bulwark) cites EA-m10, which is Dimensional Step's.
  - EA-m25 (Stonebound's ELECTRICITY), EA-m26 (Tideweaver's "Thalassyn") and EA-m27 ("Intimidation") are all corrected in v1.6.
  - EA-M12's cold trigger is gone from v1.6 (Graham: dropped).
- **"heritages elemental type"** (Bulwark, Reprisal): read as "heritage's".
- **"+1-circumstance bonus"** (Mantle): a stray hyphen.
- **FORTUNE (Mindshroud)** is in neither Appendix 3 nor Eldritch Arts' appendix. It is carried as printed; the reroll is locked by the core's own reaction-reroll rule anyway.
- **FLOURISH on Shadow Initiate**, a passive feat, has no effect. The core's Flourish limits actions to one a turn (`traits.mjs:206`).
- **Ember Eyed's "Level 1 only"** is not gated by the core picker ("Level N only" is deliberately unparsed). It is shown with its prerequisite text.
- **The Scholar feats' "+2 bonus"** (no type printed) is built as racial, as the core's Elven Scholar is.
- **Racial bonuses stack** (`system.skills.<k>.racial` is additive). Emberkin Scholar plus Eternal Scholar give an Emberkin +2 Arcana.
- **"wisdom ability modifier"** (Tideweaver) is read as the Wisdom total, the system's ability bonus.
- **Mindshroud's advantage** applies only where the effect carries the Emotion trait. The core Fear spell carries Fear, not Emotion.
- **Mantle of Essence's "you cast a spell"** is read as a cast that lands (Success or better), cantrips, innate spells and item casts included. Being Focus, it is once per Refocus whatever the trigger.
- **Voidborn Wings' "wait for it (or refocus)"** is read as the Focus rule: Refocus or daily preparation.
- **"Light level 5 (Dim Light) or less"** (Shadow Initiate, Silent Veil, Veilstride) is read as the ambient level at the Nyrinn's token, not as perceived through darkvision.
- **Stormrunner's Zeal** needs damage actually taken: Galeborne's resistance still lets it trigger, but Elemental Symbiosis's immunity does not.
- **Vein of Power** reaches +5 free casts a day at 20th, stacking with other adders (R7). Noted for balance only.


### Appendix C. Scaelyn racial feats

#### Scaelyn racial feats

Nineteen feats, all printed with the SCAELYN trait (book v1.6, ea.md L2148–2862). The matrix rows are FR-03 … FR-74, and their line references are v1.4. Below, "Line" is the feat's heading line in v1.6.

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Alchemical Purifier | 2148 | FOCUS SCAELYN / Level 5, Sludge Blooded | "Stinking Cloud and Neutralise Poison as innate spells with the focus trait" | FR-03 A INNATE; EA-M2 (name), fixed in v1.6 | Both spells are in the core pack (PP 6 each). Feat innate grant works (note 1) | `grantedSpells: "Stinking Cloud, Neutralise Poison"` + `grantInnate`. Each spell has its own Focus use. **A** | none | Q5-1 |
| Ancestral Awakening | 2158 | CONCENTRATE FOCUS SCAELYN WARDING / Level 10, Scaled Focus; 0 AP | Resistance to acid/cold/electricity/fire/poison for 1 min, and "all Spell Save DCs with that element gain a +1 bonus" for the same time | FR-04 B AUTO + element choice | `spellDCBonus` read from effects (spell-dc-bonus.mjs:28); default Focus use (feats-workflow.mjs:8429 `withFocusDefault`) | Use (0 AP): pick the element, then a 60 s effect with resistance plus `spellDCBonus {value 1, traits:[element]}` (Wyrmdral's own shape, block1-automations.mjs:390). **B** | none | — |
| Claws of the Wyrm | 2244 | SCAELYN / — | "a claw attack appropriate to your size" | FR-12 A "GRANT core Claw" | Companions pack: Claws (Tiny 1d4 / Small 1d5 / Medium 1d6), slashing, Agile, Finesse, Versatile (P). `grantedWeapons` on a feat (grants-workflow.mjs:556) takes **one literal name**; nothing picks by size | Module hook when the feat is added: grant `Claws (<actor size>)` from the companions pack, stamped `grantedBy` so grant-cleanup removes it with the feat (Scaelyn Small, Wyrmdral Medium). Use re-sizes it (note 2). **A** | none (optional: note 2) | — |
| Desert Wraith | 2262 | FOCUS SCAELYN / Level 5, Sandstrider | Pass Without Trace as an innate Focus spell; "advantage on all Hide (Stealth) checks when in natural terrain" | FR-14 B INNATE + COND | Pass Without Trace in the core pack (PP 2). Ticked advantage conditional (Dustscale's shape, block1.mjs:278) | Innate grant (A) + an unticked advantage conditional on `actions:["hide"]`. **B** | none | Q5-3 |
| Draconic Immunity | 2272 | SCAELYN / Level 5 | "immune to sleep and paralysis" | FR-15 A AE; EA-m19 fixed in v1.6 | `system.combat.immunities`: "sleep" is an Appendix trait, and an immunity to it blocks Sleep-trait spells (traits.mjs:328, magic/spell-trait-immunity.mjs:29). "paralysis" is an alias of `paralyzed` (defences.mjs:226), and `isImmuneToCondition` refuses it (documents/actor.mjs:2734) | AE appending `, sleep, paralysis` to immunities. **A** | none | — |
| Draconic Wings | 2282 | SCAELYN / Level 10 | "a fly speed equal to your land speed" | FR-16 A AE | Granted speed `creatureAbility.derives.movement {key:"fly", orLand:true}` (combat/granted-speeds.mjs:71,107,124), as Inner Tempest's Wings Unfurled does | That derive on the feat. **A** | none | — |
| Elemental Breath | 2328 | ELEMENTAL FOCUS INVOCATION SAVE SCAELYN / Wyrmdral Heritage; 2 AP | Choose acid/cold/electricity/fire/poison; "20-ft line … 1d6 damage per level … basic Reflex save" | FR-20 A AUTO + "1 PP per level" (v1.4); **EA-M11 ruled: Focus, no PP** (v1.6 dropped the cost) | `helpers.runAreaEffect` (module-api-workflow.mjs:486) with `scope:"targets"`, basic save, damage type; `levelDC` | Use (2 AP, Focus): targets the creatures the user has marked in the line, then `{level}d6 <element>`, basic Reflex against the user's own Level DC (C3; the area precedent of B1-18), as Inner Tempest's Celestial Breath does. Element from the Wyrmdral heritage's `eaElement` (Q5-2). **B** | none | Q5-2 |
| Ember Handed | 2394 | FIRE INVOCATION SCAELYN / Sparktail Heritage | Harmless sparks at will; "+2 racial bonus to Crafting checks related to alchemy or engineering"; after taking fire damage, "+1 to your next attack roll or skill check before the end of your next turn" | FR-26 B COND + AUTO | Ticked conditional; `trgPrimeDamageApplied` hook with `damageTypes` and `amount` taken (combat/dying-workflow.mjs:79); one-shot conditionals | Unticked +2 racial on Crafting (scope: alchemy/engineering). Hook: fire damage with amount > 0 sets a one-shot untyped +1 on `checkTypes:["attack","skill"]`, expiring at the end of next turn (`expiryFor("endOfNextTurn")`). Sparks: text only (note 3). **B** | none | — |
| Ghostscale | 2436 | SCAELYN / Wisperfin Heritage | At light level 5 (Dim) or less, "concealment until you attack or cast a spell"; once broken, "not … again until the beginning of your next turn"; may Hide "even while observed" | FR-31 B AUTO light reader | `derives.light.concealedAtOrBelow`, read at the attack (light-check.mjs:73, combat/targeting.mjs:345–355) from the target's light level (light-workflow.mjs:100) | The feat declares `concealedAtOrBelow: 5`. On `trgPrimeStrikeRolled` / `trgPrimeSpellCast` by the bearer, the module suspends it until the start of the bearer's next turn (note 4). The Hide clause is text only: the core's Hide has no "observed" gate to lift. **A** | none | — |
| Glyph Unleashed | 2446 | FOCUS RUNE SCAELYN WARDING / Level 5, Runic Aptitude; "0 AP:" Trigger targeted by a spell | "as a reaction when targeted by a spell. Until the start of your next turn, you gain +2 racial bonus to your saving throws and DB against that spell" | FR-32 B RX `registerDefenceOffer(kind spell)` | Defence offers answer "attack" or "weapon" only (combat/defence-offer.mjs:59; one-attack.mjs:37,72). Check reactions `before()` answer advantage only (reactions/reactions-workflow.mjs:35–74). `saveReaction` gives advantage only; `saveBonusReaction` needs a skill roll | Save spells: a check reaction `before()` on a save whose `saveSource` is a spell asks with `askReactor`, spends the reaction and the Focus use, and adds +2 racial; later saves against the same spell and caster before the bearer's next turn take it with no question. Spell attacks: a defence offer for spells only, with a one-attack +2 racial DB (Nimble Dodge's pattern). **B** with S-2 and S-3; **C** without (a card) | S-2, S-3 | Q5-5 |
| Pyrotechnic Flair | 2502 | FIRE FOCUS INVOCATION SCAELYN / Level 5, Ember Handed | Burning Hands as an innate Focus spell | FR-38 A INNATE | Burning Hands in the core pack (PP 2) | Innate grant. **A** | none | — |
| Runic Aptitude | 2578 | SCAELYN / Glyphweave Heritage | "an additional cantrip (any tradition)"; "+2 racial bonus to checks made when analysing magical symbols" | FR-46 B CHOICE + COND; EA-m23 (flavour) fixed in v1.6 | `helpers.chooseSpell` (Innate Magic / Glyphweave, block1-automations.mjs:373–387); ticked conditional | Use: choose any cantrip with `chooseSpell` (innate or not, per Q5-4). Unticked +2 racial on skill checks (scope: analysing magical symbols, e.g. Decipher Writing or Mysterious Script). **B** | none | Q5-4 |
| Sandstrider | 2588 | SCAELYN / Dustscale Heritage | "a burrow speed equal to half your land speed" | FR-47 A AE | `derives.movement {key:"burrow", orLand:true, landFraction:0.5}`, rounded down to 5 ft and never lowering a better speed (granted-speeds.mjs:84–95,124–131) | That derive. **A** | none | Q5-3 |
| Scaelyn Scholar | 2598 | SCAELYN / — | "+1 racial bonus to Arcana & Crafting"; "+2 bonus to your racial specialist skill" | FR-48 A AE; EA-m24 ("Arcane") fixed in v1.6 | Core Elven/Dwarven Scholar: AE on `skills.<k>.racial`, plus a Use that puts the +2 racial on a chosen specialist skill (feats-workflow.mjs:1086 `specialistSkillBonus`) | AE: Arcana and Crafting +1 racial. The +2 is racial, as the core reads the same words, and goes to Wyrm Lore (the race's specialist skill), found by label at add time (note 5). **A** | none | — |
| Scaled Focus | 2606 | SCAELYN / Level 5, Wyrm's Cunning | "an additional PP per level" | FR-49 A AE | `registerPPGrant(name,{perLevel, types})` (module-api.mjs:1332), as Wild Power uses it | `registerPPGrant("Scaled Focus",{perLevel:1, types:["feat"]})`. **A** | none | — |
| Scaled Trickster | 2616 | SCAELYN / — | "+2 racial bonus to Deception and Thievery checks" | FR-50 A AE | `racialSkillEffect` (builders.mjs:140) | AE. **A** | none | — |
| Silence Unbound | 2640 | FOCUS SCAELYN / Level 5, Ghostscale | Silence as an innate Focus spell | FR-53 A INNATE | Silence in the core pack (PP 4, touch) | Innate grant, at the core spell's range (the Vel-tharis "self only" reading does not apply). **A** | none | — |
| Sludge Blooded | 2680 | SCAELYN / Ironmuk Heritage | "+2 racial bonus on saving throws against diseases and ingested poisons"; eat spoiled food and drink stagnant water safely; "+2 racial bonus to Subsist (Culture or Survival)" in urban or subterranean areas | FR-57 B COND | Conditional `traits` axis: afflictions carry Disease / Ingested (poisons.mjs:150 `afflictionTraits`); `actions:["subsist"]` | Auto conditional: saves with `traits:["disease"]`, and with `["ingested"]`. Unticked +2 racial on Subsist (Culture/Survival), scoped to urban or subterranean areas. The spoiled-food clause is text only, because the core models no spoilage. **B** | none | — |
| Wyrm's Cunning | 2860 | SCAELYN / — | "+2 racial bonus to Wyrm Lore and Arcana checks" | FR-74 A AE | AE on skills; specialist skills keyed by slug (specialist-grants.mjs:53 `findSpecialistSkillByLabel`) | AE: Arcana +2 racial; Wyrm Lore +2 racial on its slug, found by label (note 5). **A** | none | — |

##### Notes

1. **Innate grants from a feat already work. Verified:**
   - The feat type has `grantedSpells` (grants-workflow.mjs:541–556).
   - `flags.trg-prime.grantInnate` on the granting item makes the copy innate (grants-workflow.mjs:430). Injury Relief in the core pack is built this way.
   - Feat grants run when the feat lands (grant-autorun.mjs:59–82).
   - A granted innate spell gets the Focus trait and one use (`grantedInnateTakesFocus` / `_applyGrantedFocusTrait`).
   - The innate PP limit refuses a cast while base PP is above level (magic/cast-workflow.mjs:791–809, focus-declarations.mjs:197). A copy may declare `innatePPAllowance` (focus-declarations.mjs:214).
   - **All five granted spells are in the core pack**, with the v1.6 names: Stinking Cloud (PP 6, arcane/verdant), Neutralise Poison (PP 6, divinity/verdant), Pass Without Trace (PP 2, verdant), Silence (PP 4, divinity/ethereal) and Burning Hands (PP 2, arcane/verdant).
   - Each is castable at its feat's minimum level, **except the two PP 6 spells of Alchemical Purifier (Level 5)**: Q5-1.
2. **Claws of the Wyrm.** "Appropriate to your size" names no damage. The size-stepped Claws in the companions pack are the system's natural attacks; Pillars' Hunter's Fangs and Inner Tempest's heritages already grant from that pack.
   - The current size picks the claw, with the core names unchanged.
   - A later size change (a Wyrmdral who is Medium, or a spell) is handled by pressing Use again.
   - An optional core seam was considered and is not needed: a size placeholder in `grantedWeapons`, such as `Claws (@size)`.
3. **Text-only clauses** (nothing in the system to automate, so nothing is lost):
   - Ember Handed's sparks;
   - Sludge Blooded's spoiled food;
   - Ghostscale's Hide while observed (the core's Hide action does not test whether the creature is observed; data/skill-actions.mjs:1952).

   Each is printed on the item and the card.
4. **Ghostscale's break.** `lightConcealment` reads the declaration from **items** only (light-check.mjs:73). The module therefore clears the feat's own `concealedAtOrBelow` when its bearer attacks or casts, and restores it at the start of the bearer's next turn (effects-clock's `startOfNextTurn`; out of combat, after 6 seconds of world time). This is a module write to its own item, as Wyrmdral's `eaElement` is. No seam is needed.
   - The light read is the ambient level at the token (light-workflow.mjs:100), which is what "If the light level is Dim" means.
   - A spell attack counts as casting.
5. **Wyrm Lore.** It is a specialist skill, so its key is a slug made from its label (specialist-grants.mjs:75–93). The module finds it by the label "Wyrm Lore" when the feat lands, and writes `system.specialistSkills.<slug>.racial`.
   - With no Wyrm Lore present, the card says so, the core's Elven Scholar fallback.
   - Racial bonuses from different sources stack (bonuses/registry.mjs:187, Core p62). So Wyrm's Cunning (+2 Arcana) and Scaelyn Scholar (+1 Arcana) total +3, and Wyrm Lore can reach +4.
6. **How these feats are offered.**
   - The racial-feat slot shows `category: "Racial"` items whose `sourceRace` matches the race (picker-filters.mjs:863–867). All nineteen are built with `sourceRace: "Scaelyn"`.
   - A Wyrmdral is a Scaelyn by race, so it is offered them all.
   - The SCAELYN trait is carried as printed. The core's own racial feats carry no race trait, and gating stays on `sourceRace`.
   - Dracoris and Sure Footed are already opened to the Scaelyn (FX-04, registration.mjs:43).
7. **Prerequisite chains.**
   - Wyrm's Cunning → Scaled Focus (L5) → Ancestral Awakening (L10)
   - Sludge Blooded (Ironmuk) → Alchemical Purifier (L5)
   - Sandstrider (Dustscale) → Desert Wraith (L5)
   - Ghostscale (Wisperfin) → Silence Unbound (L5)
   - Runic Aptitude (Glyphweave) → Glyph Unleashed (L5)
   - Ember Handed (Sparktail) → Pyrotechnic Flair (L5)
   - Elemental Breath (Wyrmdral) stands alone.

   The "Level N" and feat-name clauses are gated by the core (prerequisites.mjs, `knownNames`). **The six "<Heritage> Heritage" clauses are not.** They are left unparsed and pass open (prerequisites.mjs:15), so, for example, a Sparktail is offered Elemental Breath. The second-tier feats are protected only through their first-tier feat. See S-1.
8. **Elemental Breath's DC.** None is printed. Under C3 the DC is the Level DC of the target if something is targeted, else the user's own. For an area, Vir-ellian Release (B1-18) and Inner Tempest's breaths use the user's own Level DC, and this follows them.
   - "Level" is the character level (1d6 at 1st, 20d6 at 20th, once per Focus use).
   - It is not a spell, so Wyrmdral's +1 to spell DCs does not reach it.
9. **Ancestral Awakening** stacks with Wyrmdral's own +1 on the same element, because both are untyped and the core sums untyped (spell-dc-bonus.mjs). A second resistance to an element already resisted adds nothing. "0 AP" with Concentrate is read as a free action on the user's turn.
10. **Glyph Unleashed.** "0 AP:" with "as a reaction" is read as a reaction: it spends the reaction, as Elemental Symbiosis does, through `helpers.spendReaction`, and the Focus use.
    - The save half runs through the check-reaction rail Prophetic Warning uses (block3b-automations.mjs:249–272). The ctx carries `check.saveSource` (the spell's name) and `check.sourceUuid` (the caster) (dice/check.mjs:264, 316).
    - A world setting can turn the prompt off, as Prophetic Warning's can, with the sheet Use as the fallback.

##### Proposed core seams

- **S-1. A heritage prerequisite clause.** Used by Elemental Breath, Ember Handed, Ghostscale, Runic Aptitude, Sandstrider and Sludge Blooded.
  - *What:* `meetsParseablePrerequisites` recognises a clause "<Name> Heritage" (case-insensitive) when `<Name>` is a known heritage. It passes only when the actor owns a heritage of that name. Any other wording keeps failing open.
  - *Where:* prerequisites.mjs `meetsParseablePrerequisites`, with picker-filters.mjs `actorPrerequisiteStats` supplying the actor's heritage name and the known heritage names (the federated heritages index).
  - *Why:* every book has these prerequisites (Pillars, Inner Tempest and Eldritch Arts). Today they offer the feat to the whole race.
  - *Fallback with no seam:* `registerFeatAccess("race","Scaelyn",[{name, heritages:[…]}])` (module-api.mjs:543) plus a `sourceRace` that is not "Scaelyn". That misuses a field the sheet and other readers show, so it is not recommended.
- **S-2. A check reaction may answer with a modifier.** Used by Glyph Unleashed (its saves).
  - *What:* in `checkReactionsBefore`, an answer `{ modifiers: [{label, value, type}] }` is pushed onto `check.modifiers` and carried on a reroll, as `reactionAdvantages` is.
  - *Where:* reactions/reactions-workflow.mjs `checkReactionsBefore` (lines 35–74), and the contract comment at module-api.mjs:1348.
  - *Why:* the save family offers only advantage (save-reactions.mjs) or a skill-rolled bonus (save-bonus-reactions.mjs). A fixed "+2 racial … declared when targeted" has no rail.
- **S-3. A defence offer that answers spells only.** Used by Glyph Unleashed (spell attacks against DB).
  - *What:* `against: "spell"`, accepted by `registerDefenceOffer` and answered by `oneAttackUsedBy` for the event kind `"spell"` only.
  - *Where:* combat/defence-offer.mjs `registerDefenceOffer` (line 59, which today normalises to attack/weapon) and combat/one-attack.mjs (lines 37, 72).
  - *Why:* "attack" also answers weapon Strikes, and `requires(actor, item)` is not given the event, so a spell-only reaction cannot refuse a sword.

##### Questions

- **Q5-1. Alchemical Purifier: PP 6 spells from a Level 5 feat.**
  - *Book:* "Prerequisites Level 5, Sludge Blooded … cast Stinking Cloud and Neutralise Poison as innate spells". Both are PP 6 in the core.
  - *Issue:* the core's innate limit (your ruling of 20 Oct: no innate spell above your level) refuses both until 6th. A 5th-level character who takes the feat on time gets nothing for a level.
  - *Proposed:* give the two copies B3-2's allowance (`innatePPAllowance: 1`, castable at base PP ≤ level + 1), so the feat works when it is taken. Otherwise, confirm that both wait for 6th, and the item will say so.
- **Q5-2. Elemental Breath: whose element?**
  - *Book:* "Prerequisites Wyrmdral Heritage … You must select either acid, cold, electricity, fire or poison."
  - *Background:* v1.4 added "if you have the Wyrmdral heritage, you must select your elemental type". The audit called that redundant (EA-M11), and v1.6 removed it. Read now, the breath could be any of the five, apart from the element the Wyrmdral resists and casts with.
  - *Why it matters:* a Wyrmdral who resists fire could breathe acid.
  - *Proposed:* the heritage's element, read from the Wyrmdral (`eaElement`), with no separate pick. That is what the removed sentence said.
- **Q5-3. The Dustscale chain adds nothing at base Speed.**
  - *Book:* Dustscale gives "a burrow speed of 10 feet and advantage on checks to hide or move silently in natural terrain".
  - *Sandstrider:* "a burrow speed equal to half your land speed". Half of 25 ft is 10 ft by the grid and m128's round down, the Dustscale's own 10 ft.
  - *Desert Wraith:* "advantage on all Hide (Stealth) checks when in natural terrain" repeats Dustscale's advantage, and advantage does not stack.
  - *Why it matters:* every character who can take these feats is a Dustscale, so both clauses are empty unless the land Speed rises. Desert Wraith is left with Pass Without Trace only.
  - *Proposed:* build as printed (Sandstrider grows with Speed bonuses; Desert Wraith's advantage is a duplicate). Please confirm, or reword, for example a burrow speed equal to your land speed.
- **Q5-4. Runic Aptitude's cantrip: innate, and chosen once?**
  - *Book:* "You gain an additional cantrip (any tradition)."
  - *Background:* Glyphweave, its prerequisite, was reworded in v1.6 to "additional *innate* cantrip" (m5). Racial Innate Magic is "each day", cast with Spellcraft.
  - *Why it matters:* an innate cantrip takes the Focus trait (one use per Refocus). A Spellcraft cantrip can be cast at will.
  - *Proposed:* one cantrip, chosen with the feat's Use and kept until chosen again, as Glyphweave's is. It is cast with a Spellcraft check, **not innate**, because the book says "innate" where it means innate (v1.6 added it to Glyphweave and not here).
- **Q5-5. Glyph Unleashed: which spells "target" you?**
  - *Book:* "inscribe a temporary ward as a reaction when targeted by a spell … +2 racial bonus to your saving throws and DB against that spell."
  - *Background:* the core's Gnome Resistance excludes area spells in its own text, and this feat prints no exclusion.
  - *Why it matters:* most save spells are areas.
  - *Proposed:* any spell whose save you roll or whose attack is made against your DB, areas included. It costs the reaction and the Focus use. The +2 lasts until the start of your next turn against that spell, from that caster.

##### Waits on other blocks

- None of the nineteen needs to wait. Two points will widen by themselves later, with no rework:
  - Runic Aptitude's "any tradition" pick reads the federated spells pack, so the Grimoire's cantrips (Blocks 7–8) join it when they are built.
  - Ancestral Awakening's +1 reaches any later spell that carries the element's trait.

##### Minor

- **The matrix is stale here:**
  - FR-20 still has "costs 1 PP per level" (superseded by M11 and v1.6).
  - FR-04 shows "0 AP; 0 AP:" twice.
  - FR-12's "core Claw" is three sized items.
  - FR-03 (EA-M2), FR-15 (EA-m19), FR-46 (EA-m23) and FR-48 (EA-m24) are corrected in v1.6.
- **Ancestral Awakening:** the flavour line has no closing full stop ("…ancient dragons"). Proposed: add one.
- **Glyph Unleashed:** the action line reads "**Action** 0 AP: **Trigger** you are targeted by a spell." Proposed: "**Action** 0 AP (reaction); **Trigger** You are targeted by a spell." The text already says "as a reaction".
- **Scaelyn Scholar:** "Arcana & Crafting" (the ampersand). The +2 "bonus" to the specialist skill has no type, and is read as racial, as the core's Elven/Dwarven Scholar wording is.
- **Ember Handed:**
  - The +1 has no type, and is read as untyped.
  - "Whenever you take fire damage" is read as fire damage that reduced HP (`amount` > 0). A Sparktail's resistance halves fire damage, so the feat still triggers.
  - A second hit refreshes the +1 and does not stack it.
  - The FIRE and INVOCATION traits on a passive feat have no effect.
- **Sludge Blooded:** "Subsist (Culture or Survival)". The core's Subsist also allows Planes, which is not included.
- **Ghostscale:** "light level 5" matches the core's ladder (5 Dim Light).
- **Draconic Immunity:** "certain effects" (v1.6 corrected "affects").


### Appendix D. General feats

#### General feats

43 feats, v1.6 L4322–4706 (`book-text.json` `sections.generalFeats`). None of them prints a trait, so no race or class gate applies: the General slot offers them all. The core's picker gates on prerequisites (`prerequisites.mjs` `meetsParseablePrerequisites`). It enforces Level, BSB, a single named skill's ranks, and a clause that names an existing feat. Everything else passes open (the file's documented rule). Twelve of these prerequisites therefore pass open today: the compound skill clauses ("Arcana or Occultism 2 ranks", "Stealth & Power Manipulation 4 ranks"), "Tradition skill 1 rank", "High Magic Caster" and "Ability to cast a spell with the Summons trait". The named feats are gated once the items exist: Counter Spell, Scribe Scroll and Spell Recognition are core feats (`feats-workflow.mjs` automations at L7335 and L7733). The chains are:
- Lorekeeper's Insight → Rune-Binder's Precision → Archsage Command;
- Catalyst Affinity → Catalyst Mastery;
- Channel Siphoner → Essence Reservoir;
- Disrupt Magic → Dispel Power;
- Esoteric Insight → Expert → Master;
- Spell Recognition + Scribe Scroll → Spell Transcription → Mnemonic Grasp;
- Wanderer's Instinct → Sense → Mastery.

No feat in this group grants a spell.

**Already built (9 of 43).** These are the background feats from Block 1 (`tools/content/block1.mjs` `BACKGROUND_FEATS`, L351–400; `RELEASE_NOTES_0.1.0.md`):
- Disrupt Magic, Elemental Affinity, Esoteric Insight, Focused Ley Sense, Spell Penetration, Spirit Whisper and Wanderer's Instinct (0.1.0; Esoteric Insight's Failure reroll was added in 0.2.0);
- Ritual Expert's seat (0.4.0);
- Spell Surge, as a text-only item (0.1.0).

Rune-Binder's Precision is already read by the ritual code (`module/block2b-automations.mjs` `countsAsTwo`, L196), but its item is not built.

| Feat | Line | Traits / Prereq | Printed | Prior plan | Core has | Proposed build (level) | Seam | Q? |
|---|---|---|---|---|---|---|---|---|
| Archsage Command | 4322 | — / Level 10, Rune-Binder's Precision | Leading a ritual: "an additional caster beyond those present"; Critical on an Arcana check "or any check as part of a Ritual" → advantage on next save vs magic within 1 h | FG-01 B; EA-m50 (settled by v1.6 text); EA-M21 | D13 `seats` (`registerRitualRules`); `registerCheckReaction.after` | **B.** +1 seat in `prepareRitual` when the primary owns it (A). Critical: check reaction (Arcana) and `trgPrimeSpellSettled` (`ritual`, Critical+) create a 1 h effect with a one-shot advantage tick on saves "vs a magical effect" (n1) | none | Q?-2 |
| Catalyst Affinity | 4330 | — / None | Catalyst backlash: −2 damage per character level; conditions −1 round (min 1) | FG-02 A; EA-R2 ruled **leave as printed** | nothing (no catalysts) | **A** in Block 9's catalyst engine | D3 | — |
| Catalyst Conservation | 4336 | — / None | Using a catalyst: DC 15 flat check, success = not consumed; Fumble/Blunder cast always consumes | FG-03 A | nothing | **A** in the catalyst flow | D3 | — |
| Catalyst Crafting | 4342 | — / Crafting 1 rank, BSB +1 | "Catalyst Item Create specialty"; formula + rare materials | FG-04 B | `registerCreateRoute` (needs an item type Create knows) | **B**: a Create route for catalysts | D3 (catalyst item type) | — |
| Catalyst Mastery | 4350 | — / BSB +6, Catalyst Affinity | Spellcraft Failure: no backlash; Fumble/Blunder unaffected | FG-05 A | nothing | **A** in the catalyst engine | D3 | — |
| Channel Siphoner | 4358 | — / Power Manipulation 1 rank | Tap Magical Energy: "treat a Partial result as a Success"; half damage from a Fumble | FG-06 A | `registerDegreeUpgrades` (`skill-feats.mjs` L248); module Tap resolver `onActionResolvedB2` | **A.** Upgrade partial→success on `tapMagicalEnergy`; `hurt(..., half)` on Fumble (and Blunder, n2) | **S5-1** | — |
| Circle Adept | 4366 | — / Arcana, Nature, Occultism or Religion 1 rank | Inscribe a summoning circle in half the time | FG-07 A; EA-m51 settled by v1.6 | module `circleMinutes` (block2b L116) | **A**: halve `circleMinutes` | none | — |
| Dispel Power | 4374 | — / Power Manipulation 8 ranks, Disrupt Magic | Dispel "without expending PP … replace the PP cost with your caster level"; Very Hard (+5); Focus; own ladder (Crit dispel; Success suppress 1 min; Failure fail; Fumble fail + Resonance, never again on it) | FG-08 B; EA-m49 (sentence still broken in v1.6) | Dispel `promptDispel` / `action-workflow.mjs` L2099, L4346; no module hook | **B**: a Dispel variant with 0 PP, counteract value = CL, Very Hard, the printed ladder, a Focus use. Resonance via `rollResonanceEvent`. Dispelling, suppressing and "never again" stay the GM's, as the core Dispel leaves them (n3) | **D10** | Q?-4 |
| Disrupt Magic | 4392 | — / Power Manipulation 1 rank | +2 class on the Dispel action | FG-09; B1-22 (not Magic Drain) | — | **Already built in 0.1.0 (A)**: conditional on `dispel`. Nothing remains. v1.6 renamed the spell to Disrupting Magic (L8269), so Dispel Power's prerequisite is no longer ambiguous (EA-M67) | — | — |
| Elemental Affinity | 4400 | — / Nature or Planes 4 ranks | Chosen element: +1 Spellcraft and +1 Save DC; repeatable | FG-10 | — | **Already built in 0.1.0 (B)**: a Use per copy. Nothing remains | — | — |
| Esoteric Insight | 4410 | — / Arcana or Occultism 2 ranks | +2 circ to identify rare/uncommon; 1/day reroll a Failure or Fumble on Arcana/Occultism; Spell Recognition advantage on Uncommon/Rare | FG-11; v1.6 → C12 | `fumbleReroll` (`fumble-reroll.mjs`) | **Already built in 0.1.0 and 0.2.0 (B).** **Defect found (n4):** neither the advantage nor the reroll reaches the core's Spell Recognition roll | **S5-2** (fix) | — |
| Esoteric Insight Expert | 4418 | — / Arcana or Occultism 5 ranks, Esoteric Insight | +1 daily use of Esoteric Insight; +2 circ saves vs magical effects with Shadow or Emotion; Spell Recognition always learns the tradition, even on a failure | FG-12 B; EA-m52 settled by v1.6 | `fumbleReroll` rows per item; conditional `traits` axis on saves | **B.** A second `fumbleReroll` row with 1 use a day (A). Save conditional `checkTypes: save, traits: [shadow, emotion]`, auto (A). Tradition line on the Spell Recognition result via a check reaction (needs S5-2) | **S5-2** | — |
| Esoteric Insight Master | 4426 | — / Arcana or Occultism 8 ranks, Expert | "You may reroll any failed Arcana or Occultism"; Spell Recognition Critical → +2 circ next save vs that caster's spells before end of next turn; advantage to recognise Rare/Unique effects | FG-13 B (matrix says 1/day: stale, v1.6 prints no limit) | `fumbleReroll` with no counted use; `addPendingModifier` | **B.** Unlimited reroll row (A, per Q). Critical: check reaction (S5-2) creates a one-shot +2 on saves, scoped `sourceUuids` to the caster when a token is targeted, otherwise a tick. Rare/Unique advantage: tick on Identify Power and Spell Recognition | **S5-2** | Q?-1 |
| Essence Reservoir | 4434 | — / Power Manipulation 4 ranks, Channel Siphoner | Siphoned PP last up to 1 minute instead of to end of next turn; hold at most PM ranks | FG-14 A; EA-m53 settled by v1.6 | module `siphonedEssence` effect (block2 L559) | **A**: expiry `forSeconds(60)`; cap the siphon at PM ranks less what is held | none | — |
| Focused Ley Sense | 4444 | — / None | Ley Sense ladder +2/+0/−2/−5/−10 (0 AP) | FG-15 | C5 `timeLadderByFeat` | **Already built in 0.1.0 (A).** Nothing remains | — | — |
| Hypnotic Savant | 4450 | — / Diplomacy 6 ranks | Suggestion base duration +10 min; Critical 1 h instead of 30 min; Memory Recall: a spellcaster subject regains 1 PP | FG-16 A | module `suggestionSeconds` (block1 L106) | **A**: durations from the feat (n5); +1 PP to a subject with caster level ≥ 1 on Success+ | none | — |
| Ley Channeler | 4458 | — / Tradition skill 1 rank | Tap Ley Line success +1d4 PP (Critical 2d4); 1/day reroll a failed Tap | FG-17 B; EA-M25 ruled **they stack** | module Tap resolver; `registerCheckReaction.after` (ctx.check.actionKey) | **B.** PP in the Tap branch of `onActionResolvedB2`, capped at max (A). Reroll: a check reaction on `tapLeyLine`, asked, 1 use a day | none | Q?-3 |
| Ley Scholar | 4466 | — / Arcana or Nature 1 rank | +2 circ to checks "to manipulate ley lines or stabilize magical anomalies" | FG-18 A | conditionals `actions` axis | **B**: auto on `tapLeyLine` and `channelLeyLine`; a tick for stabilising an anomaly (no action exists) | none | — |
| Lorekeeper's Insight | 4474 | — / None | +2 class to "all checks relating to magic rituals and any specialist lore skill checks" | FG-19 A | D13 `prepare` modifiers; `checkTypes: specialist` | **B**: +2 class in the primary's ritual check, from `prepareRitual` (A); ticks for other ritual-related checks (a secondary's) and specialist Lore checks (n6) | none | — |
| Magic Sense | 4480 | — / Power Manipulation 4 ranks | "tertiary sense called Magic Sense"; on entering an area with an active aura in its range, "the GM may call for a Secret Sense Magic (Power Manipulation) check" | FG-20 D | `senses.mjs` tertiary (30 + Wis × 5 ft); core `senseMagicBroad` | **C**: the sense is granted and shown with its range (a `derives.sense` block). The check stays the GM's call, as printed (n7) | none | — |
| Magus Appraiser | 4488 | — / Crafting 5 ranks | Appraise Magic ladder +2/+0/−2/−5; Critical also reveals curse or unusual activation | FG-21 A | C5 `timeLadderByFeat` | **A**: `timeLadderByFeat` on `appraiseMagic`; Critical adds a line to the GM's card (what is revealed is already the GM's) | none | — |
| Masked Caster | 4500 | — / Deception 6 ranks | Spell Trickery's DC increase +1 instead of +2; an enemy's Blunder plants two false details | FG-22 A | module `spellTrickeryOption` (block2b L414) | **A**: `castingDC: 1` for the owner; a line on See Through Spell Trickery's Blunder card when the target caster owns it | none | — |
| Master Binder | 4510 | — / Ability to cast a spell with the Summons trait | Control levels +2; +2 on checks or saves to assert control over a Summons creature | FG-23 A | `controlLevels` derived (`documents/actor.mjs` L2055, after effects apply) | **B**: +2 control levels (A, with seam); +2 as a tick on control checks and saves | **S5-3** | — |
| Mirrored Rebuke | 4520 | Action Free / Counter Spell, BSB +12 | When countering with Counter Spell / Dispel: Success reflects the spell, "resolves as though cast by you" at the original caster; Fumble rebounds on you and one ally | FG-24 C | Disrupting Magic pattern: `registerCastReaction` + `presetDispel` (block3b L349, L438); `helpers.castSpell` | **C**: a cast reaction runs Counter Spell's Dispel and stops the cast on Success. The reflected spell is cast from the reactor through `castSpell` (whether the `stored` option fits is to be verified at build). The Fumble's targets are the GM's (n8) | **D10** (+ a castSpell mode if `stored` does not fit) | Q?-5 |
| Mnemonic Grasp | 4536 | — / Spell Transcription | After Spell Recognition, learn the spell straight into book or repertoire, without a scroll; Critical halves learning time | FG-25 D | Learn a Spell: source is the player's pick (`learn-spell-workflow.mjs` `promptSource`) | **D**: the core's Learn a Spell already lets the player name the source, so there is no gate to lift. The halved time is a note | none | — |
| Piercing Insight | 4546 | — / Power Manipulation 1 rank | Apply your metamagic feats to either Sense Magic (PM) action; pay PP, no extra check | FG-26 C; EA-m57 settled by v1.6 | `senseMagicBroad`/`Focused`; core metamagic is a cast-only table (`magic/metamagic.mjs`) | **C**: a Use lists owned metamagic, spends its PP, and the card says what changes (area, range, AP), which the GM applies | none (D2 for the list) | — |
| Rapid Binder | 4554 | — / Power Manipulation 6 ranks | Quickbind outside daily preparation without the penalty; on a success, activate the item that round | FG-27 B (v1.4 text; m54 rewritten in v1.6) | C5 `timeLadderByFeat` | **A**: `timeLadderByFeat` on `quickbind` with the "outside" rung at 0. The activation is a card line: the item is invested on Success | none | — |
| Ritual Expert | 4562 | — / Power Manipulation 5 ranks | Count as two casters in a ritual | FG-28; Q13; M21 | D13 seats | **Already built in 0.4.0 (A).** Nothing remains | — | — |
| Rune-Binder's Precision | 4570 | — / Level 5, Lorekeeper's Insight | "always considered to be two casters" | FG-29 A; EA-M21: Graham "will alter"; v1.6 unchanged | `countsAsTwo` already reads it (0.4.0) | **A**: build the item; the seat works at once | none | Q?-2 |
| Runespeaker | 4578 | — / Linguistics 8 ranks | Lingual Casting rank requirement −1 (min 1); Critical: scroll heightened +1 per 4 Linguistics ranks; +2 circ to decipher magical writing, glyphs or runes | FG-30 B; EA-m55 settled by v1.6 | module `lingualCastingOption` (block1 L131); C6 release path has no heighten; core `decipherWriting` | **C**: rank reduction in the module's own path (A); decipher +2 as a tick on Decipher Writing and Identify Power (B); the Critical's heighten is a card line, because a release path cannot heighten | none (optional S5-6) | Q?-7 |
| Runic Stabiliser | 4586 | — / Crafting or Linguistics 2 ranks | High Magic check: spend 1 AP on a rune → Partial counts as Success | FG-31 B | D7 `registerCastDegreeRemap` (ctx lacks `highMagic` and the cast options); `registerCastOption` (no AP) | **B**: a cast option offered when `highMagic` is set; the remap moves Partial→Success when it was taken | **S5-5** | — |
| Silent Spellstrike | 4594 | — / Stealth & Power Manipulation 4 ranks | Sniping (Stealth) with Attack-trait spells, "must still meet all normal requirements" | FG-32 B; D14 half not built | Sniping gate and critical record are weapon-only (`attack-workflow.mjs` L3815; `action-workflow.mjs` L2312) | **B**: a spell attack's critical records Sniping eligibility when the caster owns the feat | **D14 (Sniping)** | Q?-6 |
| Spell Feedback | 4602 | — / Arcana, Nature, Occultism or Religion 1 rank | Learn each target's outcome (resisted, partly, fully), not the numbers | FG-33 A | the cast card already prints each target's save degree (`cast-workflow.mjs` `resolveSpellSave` L6457, `saveLadderLine`) | **D**: the system already shows every caster the outcome; there is nothing to add. The feat matters only at a table that hides rolls | none | — |
| Spell Penetration | 4612 | — / Power Manipulation 2 ranks | Target's Spell Resilience −2 vs your spells | FG-34; m56 | C2 | **Already built in 0.1.0 (A).** Nothing remains | — | — |
| Spell Surge | 4620 | — / High Magic Caster | +1 PP surge (Focus): +50% range or duration, +2 class Save DC, or +1 damage die; that cast's Spell Fumble or Resonance at disadvantage | FG-35; EA-M20 ruled as proposed | — | **Item already built in 0.1.0 (text only).** The automation (B) is Block 6, as `RELEASE_NOTES_0.3.0.md` says | D2, D6 | — |
| Spell Thief | 4638 | — / Arcana 5 ranks | Borrow Spell on a scroll or magical text; Critical: the borrowed spell does not count against prepared slots (one at a time) | FG-36 B; m14 | module `resolveBorrowDC` (block2b L448); memorisation counts every prepared book spell (`memorisation-workflow.mjs` L139) | **B**: owned scrolls are offered as lenders, and a "magical text" is a tick for the GM; a Critical marks the copy as a free prep (one at a time) | **S5-4** | — |
| Spell Transcription | 4648 | — / Scribe Scroll, Spell Recognition | After Spell Recognition, scribe that spell's scroll within 24 h (Scribe Scroll rules); Critical halves the time | FG-37 C | Create (scrolls) checks only the Scribe Scroll feat, not the spell (`crafting-feats.mjs` L106) | **D**: Create does not ask whether you know the spell, so there is no gate to open; the 24 h and the halved time are notes | none | — |
| Spirit Resources | 4658 | — / Occultism 4 ranks | Occultism instead of Diplomacy for Gather Information, Make an Impression and Request "when dealing with spirits" | FG-38 B; renamed from Spirit Binder (v1.6) | `registerSkillSubstitution` (`feats.mjs` L776) | **B**: three substitutions under Occultism; the card says "with spirits only" (the player's call) | none | — |
| Spirit Whisper | 4666 | — / Occultism 6 ranks | Telepathy with willing spirits/undead within 30 ft | FG-39 | — | **Already built in 0.1.0 (D)**: a sheet note. Nothing remains | — | — |
| Threadcutter | 4674 | — / Arcana, Nature, Occultism or Religion 4 ranks | Use the chosen tradition's skill instead of Power Manipulation for Dispel, against that tradition's effects; repeatable | FG-40 A | `registerSkillSubstitution`; the sheet reads ability names too (`actor-sheet.mjs` L1993) | **B**: a Use per copy picks the tradition and adds an ability "Threadcutter (Arcana)" etc., each registered with `{action: "dispel", skill}`. "Within that tradition's domain" is a card line | none | — |
| Wanderer's Instinct | 4684 | — / Survival 1 rank | +2 circ vs hazards; +1 to detect disturbances; 1/day advantage | FG-41 | — | **Already built in 0.1.0 (B).** Nothing remains | — | — |
| Wanderer's Mastery | 4692 | — / Survival 10 ranks, Wanderer's Sense | Immune to magical getting lost; sense ley lines within 1 mile; allies' Survival to endure "as though they had rolled a 10 (minimum)"; 1/week ritual journey: party +2 luck saves vs magic 24 h | FG-42 C | module `leyLinesWithin(token, feet)` (areas.mjs L247); no die-floor | **C**: a Use lists the ley lines within 5280 ft (B); the weekly journey puts a 24 h effect on the chosen allies (luck +2 on saves, auto on a spell's save, a tick otherwise) (B); the immunity and the minimum 10 are card lines (n9) | none (optional S5-7) | — |
| Wanderer's Sense | 4700 | — / Survival 5 ranks, Wanderer's Instinct | Advantage on Survival vs fatigue or starvation in harsh or magic places; allies within 10 ft +2 circ saves vs environmental effects in magical areas; 1/day auto-succeed Survival to avoid getting lost | FG-43 B | conditionals; core ally auras (`creature-aura-workflow.mjs` `aurasOf`, to be checked for a PC feat) | **B**: an advantage tick on Survival; the ally +2 as an aura if `aurasOf` reads a feat, else a tick on each ally; the Use posts Sense Direction as a Success, 1 a day | none | — |

##### Notes

1. **Archsage Command.** "A magical effect" is not a single scope, so the advantage is a tick, not auto; it is spent on the first save it is ticked for, within the hour. "Critically succeed" includes Heroic. "Any check as part of a Ritual" is read as the primary's ritual check. A secondary's check is entered as a degree, so its Critical is ticked in the dialog.
2. **Channel Siphoner.** Tap's Blunder is "As fumble and the item is depleted", so its damage is the Fumble's. Read: halved too.
3. **Dispel Power.** The core Dispel does not remove anything either: it takes the effect's level and DC from the GM, spends PP and prints the result (`general-skill-options-workflow.mjs` `promptDispel`). Dispel Power is therefore as automated as Dispel. The 1-minute suppression and "you cannot attempt to dispel this effect again" are recorded on the card. A lock by effect is possible only when the target is a document, which a GM-entered effect is not.
4. **Esoteric Insight: a defect, and the reason for S5-2.** The core's Spell Recognition rolls its own check (`feats-workflow.mjs` L7335–7381: `TRGCheck.roll({actor, label, subtitle, type: "skill", dc, modifiers})`), with **no `actionKey` and no `subject`**. Three things follow:
   - The Block 1 advantage tick is scoped `actions: ["identifyPower"]`, and `conditionals.mjs` L763 drops any entry whose action does not match. So the tick is offered on Identify Power, never on Spell Recognition.
   - The `fumbleReroll`'s `subjects: ["arcana", "occultism"]` cannot match an empty subject (`fumble-reroll.mjs` `fumbleRerollRows`). So a failed Spell Recognition made with Arcana is not offered the reroll.
   - Expert's and Master's Spell Recognition riders have no result to read.

   The fix is S5-2, and Block 1's conditional then adds `spellRecognition`.
5. **Hypnotic Savant.** Success is "as the Suggestion spell", whose failed save lasts 1 minute (`data/pack-repairs.mjs` L673), so Success becomes 11 minutes. Read: +10 minutes on each rung not replaced (Partial 15 min, Success 11 min, Heroic 1 h 10 min); Critical 1 hour. "If they are a spellcaster" is read as caster level ≥ 1, because under C2 everyone has a PP pool.
6. **Lorekeeper's Insight.** Every specialist skill in the book is a "… Lore" (Astral Lore, Wyrm Lore and so on). Read: every specialist skill named "Lore". A conditional cannot match a label, so it is a tick on specialist checks. "Checks relating to magic rituals" is read as not covering Inscribe Summoning Circle, which Chapter 7 treats as its own check.
7. **Magic Sense.** No range is printed. Read: a tertiary sense's full range, 30 + Wis × 5 ft, under Graham's ruling of 25 Aug 2026 that a granted sense is not halved as a special sense (`senses.mjs` L326).
8. **Mirrored Rebuke.** "Make a counter a spell attempt using the Counter Spell feat". The core's Counter Spell is a free Dispel after Spell Recognition (`feats-workflow.mjs` L7733), with no spell in hand. Only the Disrupting Magic route (a cast reaction, Block 3b) holds the incoming spell's data, so Mirrored Rebuke uses it. Who may reflect, and what the reflection costs, is Q?-5.
9. **Wanderer's Mastery.** "Treat their Survival checks … as though they had rolled a 10 (minimum)" needs a die floor, and `dice/check.mjs` has none. It stays a card line unless S5-7 is wanted.

##### Proposed core seams

- **S5-1 — `trgPrimeActionResolved` carries the resolved degree.**
  - **What:** add `resolvedDegree: degree` beside `degree: rawDegree ?? degree`.
  - **Why:** the hook gives modules the raw degree (`combat/action-workflow.mjs` L5697). A `registerDegreeUpgrades` entry on a module's own action (`skill-feats.mjs` L248) changes the core's card but not what the module applies. With Channel Siphoner, the card would say Success while the module siphoned the Partial's PP.
  - **Users:** Channel Siphoner; any later upgrade on a module action.
  - **Without it:** the module reads the feat itself and does not register the upgrade, but the core card then prints the Partial row.
- **S5-2 — Spell Recognition names itself.**
  - **What:** in `feats-workflow.mjs` L7350, pass `actionKey: "spellRecognition"` and `subject: skillKey` to `TRGCheck.roll`.
  - **Why:** conditionals, `fumbleReroll`, and the existing `registerCheckReaction.after` (ctx.check.actionKey, degree) then reach the roll. No new hook is needed.
  - **Users:** Esoteric Insight (n4, a fix), Esoteric Insight Expert, Esoteric Insight Master.
- **S5-3 — a declared flat control-level bonus.**
  - **What:** sum `flags.trg-prime.controlLevelBonus` (number) over feats, abilities and equipped items, and add it after `controlLevelCap` (`documents/actor.mjs` L2055).
  - **Why:** an effect cannot add to `controlLevels`, because it is derived after effects apply.
  - **Users:** Master Binder; later, Block 9's two weapons that "increase your control levels by 2" (v1.6 L9903, L10023).
- **S5-4 — a prepared spell outside the memorisation count.**
  - **What:** a spell flagged `flags.trg-prime.memorisationFree` is left out of the book-spell count (`magic/memorisation-workflow.mjs` `memorisationContext`, L139).
  - **Users:** Spell Thief (Critical).
- **S5-5 — the degree remap is told the cast options and High Magic; a cast option may cost AP.**
  - **What:** `remapCastDegree` ctx (`magic/cast-workflow.mjs` L2979) gains `highMagic` and `castOptions` (the taken keys). `appliedCastOptions` (`magic/cast-options.mjs`) accepts an `ap` from `apply`, added to the cast's AP.
  - **Users:** Runic Stabiliser ("spend 1 AP inscribing a stabilizing rune").
  - **Without it:** the option and the remap share module state, and the AP is a card line.
- **D10 — `registerDispelModifier`** (already planned, `ELDRITCH_ARTS_CORE_DEPENDENCIES.md`).
  - **What:** `{ offer(ctx) → { label, ppCost, counteractValue, difficulty, outcomes, focus }, onResult(ctx) }`, read by `promptDispel` and by Dispel's PP spend (`action-workflow.mjs` L2099, L4346).
  - **Users:** Dispel Power (0 PP, CL as the value, Very Hard, own ladder) and Mirrored Rebuke (a rider on Success and Fumble).
  - **Shape:** design it now for Block 6's Runebreaker, Resonant Ascendance, Threadbreaker's Precision and Glyph Shatter too.
- **D14, the Sniping half** (already planned).
  - **What:** a spell attack's critical records `weaponIsRanged` / `withinFirstIncrement` (`combat/attack-workflow.mjs` L3815) when the caster owns a feat that allows it. The Sniping gate (`action-workflow.mjs` L2312) then accepts it.
  - **Users:** Silent Spellstrike.
- **Optional, not proposed:**
  - **S5-6** — a release path may heighten its spell on a degree (Runespeaker's Critical).
  - **S5-7** — a die-floor conditional (Wanderer's Mastery's "rolled a 10").
  - **A prerequisite-clause registry**, so a module can gate "High Magic Caster", "Tradition skill N rank" and compound skill clauses. It is core-wide, and the system fails open on purpose.

##### Questions

- **Q?-1 — Esoteric Insight Master.**
  - **The book:** "You may reroll any failed Arcana or Occultism." No limit is printed, though the feat's two predecessors are 1 and 2 a day. The matrix (v1.4) had 1/day.
  - **Why it matters:** read as printed, it is unlimited rerolls on two skills.
  - **Proposed:** as printed. Every Arcana or Occultism check that comes out Failure, Fumble or Blunder may be rerolled once, with no daily limit, and the new result stands. Esoteric Insight's daily uses then matter only for its other parts.
- **Q?-2 — Rune-Binder's Precision and Archsage Command (M21 is still open).**
  - **The book:** v1.6 still prints the same benefit as Ritual Expert: "always considered to be two casters". Graham said he would alter it. Archsage adds "an additional caster beyond those present".
  - **Proposed:**
    - Rune-Binder's Precision is built as now: it does not stack with Ritual Expert (M21, Q13).
    - Archsage Command adds one seat on top: a primary with both counts as three.
    - Archsage's own seat, like Ritual Expert's, counts for the one-secondary requirement and the 2 PP headroom.
- **Q?-3 — Ley Channeler.**
  - **The book:** "if you fail a Tap Ley Line check, you may reroll". Esoteric Insight now says "a failure or fumble result".
  - **Why it matters:** a Fumble on Tap adds the backlash and a 24 h lock.
  - **Proposed:** Failure and Fumble. Tap has no Blunder row, so a Blunder falls back to Fumble (m42).
- **Q?-4 — Dispel Power.**
  - **The book:** "You replace the PP cost with your caster level".
  - **Proposed:**
    - No PP is spent, and the counteract value is the caster level, compared with the effect's level or PP (±2 per step, as Dispel).
    - Disrupt Magic's +2 applies, since this is the Dispel action.
    - It may be used through Counter Spell (a free Dispel).
    - The Focus trait means one use per Refocus.
    - The rungs not printed fall back as m42: Heroic is Critical, Partial is Failure, Blunder is Fumble.
- **Q?-5 — Mirrored Rebuke's reflection.**
  - **The book:** "resolves as though cast by you … (range and targeting are recalculated from you as the new source)".
  - **Proposed:**
    - No casting check and no PP of yours.
    - The spell keeps its PP and warps as cast, and uses your save DC and spell attack.
    - A Critical also reflects (and pays Dispel's Critical PP).
    - Fumble: the spell resolves on you and on one ally within its range, chosen by the GM.
- **Q?-6 — Silent Spellstrike.**
  - **The book:** Sniping requires "a critical with a ranged weapon within its first range increment". Spells print one range and no increments.
  - **Proposed:** a critical on a spell attack against a target within the spell's range. The target-state half stays the GM's, as for weapons.
- **Q?-7 — Runespeaker.**
  - **The book:** "You reduce the rank requirement for using Lingual Casting by 1 (minimum 1)". Lingual Casting has two requirements: tradition-skill ranks ≥ PP, and Linguistics ranks ≥ PP + 2.
  - **Proposed:** both are reduced by 1, minimum 1.

##### Waits on other blocks

- **Block 9 (catalysts, D3):** Catalyst Affinity, Catalyst Conservation, Catalyst Crafting and Catalyst Mastery. Recommend shipping their items in Block 5 with honest "Block 9" cards, as B1-16 did for Spell Surge, so the Affinity → Mastery chain and the picker work now.
- **Block 6 (metamagic, D2; fumble and Resonance modifiers, D6):**
  - Spell Surge, already itemised with a note saying so;
  - Piercing Insight: build it once the metamagic list includes Eldritch Arts' own options (D2), with an item and note in Block 5.
- **Block 5 only if its seam is approved for this block's core release:**
  - Dispel Power and Mirrored Rebuke (D10). Recommend D10 in Block 5, designed for Block 6's four users too.
  - Silent Spellstrike (D14 Sniping).

  Otherwise they move to Block 6 with D10, and ship now as items with notes.
- **Block 9 (items), outside this group:** S5-3 also serves the two summoning weapons there.
- **Everything else (29 feats, 9 of them already built)** belongs in Block 5. The rules it needs exist: Chapter 4 actions (Block 1), ley lines and Tap (2a), rituals, circles, Spell Trickery and Borrow Spell (2b), D7 and D13.

##### Minor

- **EA-m49 (still in v1.6):** Dispel Power, "You replace the PP cost with your caster level When making a check in this way replace…". A full stop is missing, and the sentence should be "When making a check in this way, replace the usual Dispel results with the following".
- **Settled by v1.6:** m50 (Archsage), m51 (Circle Adept "Arcana"), m52 (Expert "an additional use each day"), m53 ("Tap Magical Energy"), m54 (Rapid Binder rewritten), m55 ("Linguistics"), m57 (Piercing Insight now "Sense Magic (Power Manipulation)", which is the core's `senseMagicBroad`/`Focused`) and M67's name clash (the spell is now Disrupting Magic).
- **Stale matrix rows:**
  - FG-13 (Master "1/day") and FG-27 (Rapid Binder's "1 round") predate v1.6.
  - FG-09, FG-10, FG-11, FG-15, FG-34 and FG-41 are "Implemented"; FG-28 should read Implemented (A, 0.4.0); FG-35 is "In progress", text only.
- **Typos:**
  - Channel Siphoner, "Tap Magical Energy (Power Manipulation), check": a stray comma.
  - Rapid Binder, "attunement's": should be "attunements".
  - Mirrored Rebuke, "make a counter a spell attempt": should be "a counter-spell attempt".
  - Esoteric Insight Master, "any failed Arcana or Occultism": "check" is missing.
  - Catalyst Conservation, "the spellcasting check": should be "the Spellcraft check".
  - Runic Stabiliser, "stabilizing": the US spelling, against the feat's British name.
  - Ley Scholar, "stabilize magical anomalies": the same.
- **Silent Spellstrike's prerequisite** "Stealth & Power Manipulation 4 ranks" is read as 4 ranks in each.
- **Curly apostrophes:** Rune-Binder's, Lorekeeper's and Wanderer's prerequisites print a curly apostrophe (’). The prerequisite gate matches names exactly (`prerequisiteNameKey`), so the items must keep ’ (as `titleCase` does), or the chains pass open.
- **Spell Surge:** "(which has the focus trait)" leaves open whether each of the four options is a separate Focus use. This is for Block 6.
- **Catalyst Conservation** is an exception to "consumed immediately upon use, whether the spell succeeds or fails" (L5222), which is what the feat is for. It needs no ruling.
