# Live recheck: Eldritch Arts 0.16.1 on TRG Prime 3.692.0

15 November 2026, in Graham's world, as the GM "Testing Dude". Throwaway ZZ copies of Borin Slatevein, on a ZZ scene.

**Cleanup:** 7 messages, the scene and the two actors were removed. World time and the view were restored, and the game was left paused.

| What | Result |
|---|---|
| **Arcane Mycelium's Region** (the 0.16.0 failure) | **Pass.** A real cast with the +2 PP reactive threads, placed on the map. The core renamed the Region "Arcane Mycelium (difficult terrain)", and the module stamped it: DC 21 and the reactive unlock. It also set `emitsLight` to level 5. |
| **Its dim light** | **Pass.** The foe inside read 8 in a bright scene. In Pitch Black (3) it read 5, while the caster outside read 3. |
| **Its reactive threads** | **Pass.** The foe cast Physical Boost while inside. It rolled a basic Fortitude save at DC 21 (a Success) and took 3 of the 2d6 (7) essence damage, going from 60 to 57 HP. |

The 0.16.0 report's other results stand. Block 7's five seams are done.
