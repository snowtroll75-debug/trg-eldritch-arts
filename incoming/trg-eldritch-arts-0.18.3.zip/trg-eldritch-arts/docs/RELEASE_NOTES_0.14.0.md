# Eldritch Arts 0.14.0 — Block 9b: the runes and the specific items

13 November 2026. **Needs TRG Prime 3.689.0** (H21, the runes' declarations; H22, the Strike's natural die and fumble). Built from the Block 9 audit §3.2.4, §3.2.5, §3.2.9 and §3.2.10, as Graham answered it on 13 November (00:23, "Go with your recommendation for all questions and proceed": Q192–Q206 as each row recommends, H21 and H22 approved). Block 9c (orbs, rods and staves, on TRG Prime 3.690.0) follows.

- **Install TRG Prime 3.689.0 first**, then this. No migration; no world data is touched.
- **Two new packs:**
  - **Eldritch Arts: Runes** — the 34 runes, one document per tier (68), as TRG Prime's own Runes pack holds them. Inscribe them through the core's rune picker on an armour, shield or weapon: TRG Prime knows them by name.
  - **Eldritch Arts: Specific Items** — the 9 specific armours, shields and weapons.
- **A rune counts while its item is equipped**, as every rune in TRG Prime does. The 34 print INVESTED. TRG Prime tracks investment for items with the Invested trait, not for runes inscribed on mundane armour and weapons, and its own INVESTED runes count while equipped. So do these.

## Grades

| Family | A | B | C |
|---|---|---|---|
| Armour and shield runes (18) | 12 | 6 | 0 |
| Weapon runes (16) | 10 | 5 | 1 |
| Specific armour and shields (5) | 2 | 3 | 0 |
| Specific weapons (4) | 2 | 2 | 0 |

## The armour and shield runes

**Applied by TRG Prime from what each rune declares** (H21), while the item is equipped:

- **Aegisflow I/II:** on a critical to a location the armour does not cover, it gives that location half its DR (I) or all of it (II).
- **Arcanum Seal I–III:** a +1 / +2 / +3 Spell Adder.
- **Astral Echoes I–III:** the critical injury roll against you −5 / −10 / −15, never below 1; not on an unmodified 66 or 100. Shown on the injury card.
- **Binding Sigils I–III:** −2 / −4 / −6 on the DC 20 Will save a creature over your control levels makes to break free (Q197). A bound creature commanded against its nature saves as the GM rules: apply the same penalty.
- **Bound Circle I–III:** +1 / +2 / +3 DB against a Strike or spell attack by a creature with the Conjured trait, or one somebody holds in their control register as bound or conjured (Q197).
- **Comfort:** Sleeping in Armour with advantage, and the armour's Max Dex +1.
- **Force Warding, Soul Warding:** resistance to force, to essence.
- **Swiftbind:** donned with a 1 / 2 / 3 AP Interact by category, a full suit +1 AP; the item sheet shows it. (v1.6's name for Quickbind; Gravemeld Shirt still prints the old name, read as Swiftbind.)
- **Transcendent:** the armour adds no casting penalty — the tradition's, or High Magic's DR × 4 (Q199).
- **Ley Binding I–III:** +1 / +2 / +3 circumstance DB against a spell attack (Q194).

**Run by the module:**

- **Catalyst I–IV:** a shield holding 1–4 catalysts. **Embed a Catalyst** is a button on the shield's sheet (10 minutes; replacing one destroys it). While the shield is wielded, each embedded catalyst is offered when you cast, once a day, and is not consumed; its backlash applies (Q192). Catalyst Conservation does not apply to it.
- **Luminous I–III:** while equipped, a light on the token: 20-foot radius, the light level one / two / three steps up.
- **Nullflow I–III:** when a spell's check succeeds against the wearer (targeted; or an area spell, asked "are you in it?"), the wearer is asked to react. They roll Dispel (Power Manipulation) against the spell's Casting DC, ±2 per step between the rune's level and the spell's PP (Q195). On a success the spell does not land on them. Once / twice / three times a day.
- **Renewal I–III:** at daily preparation the item regains its level × 1 / 2 / 3 HP. An item brought to 0 HP has its rune struck at the next preparation (the rune "unravels").
- **Resonant Defiance I–III:** when an enemy within 30 feet casts, the bearer is asked to react. If they do, the cast's Casting DC is raised by 2 / 4 / 6 (Q198).
- **Veil I–III:** when the wearer drops below 25% of their maximum HP, or takes a serious or deadly critical, they are asked to react. If they do, they become incorporeal (the Incorporeal trait in full) until the end of their next turn, and may take only Move and Defence actions (Q196). Once / twice / three times a day.
- **Wildbane:** whenever a wild surge occurs within 30 feet, a DC 15 flat check is rolled for the bearer, on the surge's card. On a success the card names the bearer and their adjacent allies, for the GM to leave out of its effect. Its +2 circumstance is offered on saves; its +2 to DB against a surge's attack is the GM's.

## The weapon runes

**Applied by TRG Prime from what each rune declares:**

- **Aetherfang:** its Strikes ignore the target's resistance to physical damage (not immunity).
- **Gravitas:** the weapon's Fumble DC +2.
- **Leybound:** within 30 feet of a ley line, one more die of base damage (and +1 circumstance to the Strike, from the module's check reaction).
- **Pyrebrand I–III:** an energy rune, as TRG Prime's: Command (1 AP) on, 1d4 / 2d4 / 3d4 secondary fire.
- **Summoner's Brand:** control levels +2 whilst wielded.
- **Chrono:** an Activate button on the weapon.

**Run by the module, on the Strike (H22):**

- **Aetherfang:** on a critical, 1d6 essence per severity step, basic Fortitude against your Level DC (Q201).
- **Echoing I–III:** on a critical, 1 / 2 / 3 recurring sonic on the target.
- **Essencebreaker:** on a hit, a Will save against your Level DC; on a failure, the target loses one of its resistances (you choose) until the end of your next turn.
- **Mindpiercer I–IV:** on a critical, 1d8 to 4d8 mental damage, basic Will against your Level DC.
- **Nullflare:** on a hit, a Will save against your Level DC. On a Failure, the target's lowest-PP spell effect is switched off until the beginning of your next turn; on a Fumble, until the end of it; on a Blunder, it ends. Ties are yours to break. The timing is kept on the world clock (6 / 12 seconds).
- **Pyrebrand:** on a natural 20 while active, 1d8 / 2d8 / 3d8 fire to every creature adjacent to the target but you, basic Reflex.
- **Riftcleaver:** once a round after a hit, a free teleport of up to 10 feet (the core's rule: a second teleport in a turn fails). Ending adjacent gives +1 circumstance against that target until the end of your next turn.
- **Sanguine:** when it damages a foe, Bleeding 1, or 1d4 on a natural 20 (Q202).
- **Tether:** once a round after a hit, a 1-round tether. While tethered, a Translocation spell the target casts needs a Will save against your Level DC first, or it fails.
- **Veilstorm:** once a round after a hit, 1d6 force to every creature adjacent to the target but you, basic Reflex.
- **Warpflare:** a d6 on every hit (+1 within 30 feet of a ley line): 5 is 2d6 force, 6 or more a wild surge from you at area level 9 (Q205).
- **The fumbles** (TRG Prime's new weapon-fumble hook):
  - Aetherfang: 2d6 essence to you, basic Fortitude;
  - Leybound: a wild surge at the nearest ley line's level;
  - Riftcleaver: 1d6 × 5 feet in a random direction, whispered to the GM;
  - Tether: a DC 15 flat check, or Immobilised until the beginning of your next turn;
  - Veilstorm: Blinded until the end of your next turn.
- **At a turn's end:**
  - **Chrono:** while it runs you are Quickened, its point for a Strike only. At each turn's end, an Exhaustion check, Easy, one step harder each consecutive turn (Q200). Fatigued ends it, and refuses it.
  - **Sanguine's thirst:** three consecutive rounds wielding it without hitting a foe gives you Bleeding 1d6.
- **Summoner's Brand:** caster level +1 for a Summons spell, one more PP on its cap per cast (Q204).

**Left to the table, and said so on the item:**

- **Gravitas:** on a critical, the free Trip or Shove is offered on the card (no MAP, your weapon attack bonus) but not rolled for you. The weapon's doubled weight is yours to set.
- **Spellhold (C):** TRG Prime's spell storing holds one spell per item, so the staff's 6 / 12 / 24 / 40 PP store is the table's to track. The card says the capacity and the rule (Q203).
- **Mindpiercer's** waking visions (−1 Perception, GM discretion) and **Pyrebrand's** smoking weapon (−2 Hide) are offered on the check, unticked.
- **Echoing's** whispers are said on the card.

## The specific items

Statistics as printed (Q206); each rune line reads as the rune's v1.6 text.

- **Gravemeld Shirt (A):** Graveiron; Swiftbind (the book's "Quickbind"): 2 AP to don.
- **Heartstrand Harness (B):** Ley Binding I.
- **Shadeskin (B):** Eversmoke Cloth, Shadow II, Veil II; the printed −1 Perception (an item penalty while worn).
- **Spellguard (B):** Resonant Defiance at **+1**, as it prints (M79). Its Resist Energy (Fire), Command 1/day, is a card: TRG Prime reads its Spell Effect rune on armour and weapons, not on a shield.
- **Whispering Hollow (A):** Ashbone, Comfort (Max Dex +1 on the printed 7), Soul Warding.
- **Bleeding Crown (A):** Sanguine, with the rune's v1.6 drawback (Q206).
- **Soulrend (B):** Aetherfang and Essencebreaker (Will against your Level DC); no Clumsy (m200).
- **Ritualist's Edge (A):** Summoner's Brand; level 10 (m201: its price is a level-10 price; the book prints 11); the apostrophe added (Q204).
- **Starfall (B):** Chrono; AR 3 as printed.

## For Graham

1. **Ley Binding's save half.** "A bonus to DB against attack spells and spells with the save trait that inflict damage". DB is not rolled against a save spell, so only the spell-attack half is applied. Should the save half be a bonus to the save instead, or left as printed?
2. **Resonant Defiance's "your shield is raised".** TRG Prime keeps no raised state for a shield, so it is read as equipped. Is that right, or should raising be an action?
3. **Spellhold** is a card (C): a multi-spell store needs a core seam of its own. Build it in 9c with the staves?

## The harness

- **New pair `verify-block9b`** (89 checks) and **`mutate-block9b`** (65 mutations, all caught).
- **The extractor** cuts Chapter 9's runes (with their sidebar tiers) and specific items into `book-text.json`; "Weight" and "Armour/Shield Price" are labels it now reads.
- **Re-pinned:** `verify-block1` (the two new packs; Shadeskin's conditional), `verify-block2` (Nullflare's suppressor), `verify-block3` (Summoner's Brand's cap), and the manifest and required-system pins in Blocks 1–9a's verifiers and mutations.
- **All 25 verifiers pass** against TRG Prime 3.689.0, and every mutate is clean (Blocks 1–9b; the re-pinned ones rerun).
- **TRG Prime 3.689.0's full sweep:** 739 harness files, 0 failed.
- **Independent review fixes:** Chrono now sets its state (a day's duration); Veil asks once per blow; Nullflare suppresses spell-made effects only; Essencebreaker offers damage types only; Sanguine's idle count resets per combat; Renewal's handler runs on one client; Leybound's ley-line cache expires; Nullflow skips allies for an area spell.
