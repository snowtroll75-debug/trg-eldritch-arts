# Eldritch Arts 0.12.0 — Block 8b: the rituals and Chapter 7's High Magic spells

12 November 2026. **Needs TRG Prime 3.687.0** (H13–H16). Built from `docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md` §3.2, §4.2 and §4.4, as Graham answered it on 8 November (17:22, "As recommended": Q170–Q182 as each row recommends; H13–H16 approved). With it, the whole of Chapter 8's Grimoire is built: 87 spells, plus the 41 specialist spells.

## The 17 spells

Every one is uncommon (m84). Grades, each at its audit grade (§9): rituals **6 B, 4 C**; High Magic **1 A, 4 B, 1 C, 1 D**.

### The ritual model (§4.2)

- **Performed as a Magic Ritual only** (Q8), its cap at Success lifted (M30), as Block 2b built.
- **Who takes part:** the ritual dialog ticks the secondary casters (they must match the rows entered: Q173, "all casters" share a failure) and, for Sun's Benediction, Rite of Echoed Shadows and Call of the Ancestors, the other willing creatures taking part.
- **The Cost** (Q174) is checked before the roll: a short purse refuses it. It is taken once the casting is settled, whatever the degree; a refunded casting takes nothing. Concord of Stone's is 100 gp per PP as cast, warps included. Essence Reforging's is 200 gp × its target's level, so the target is chosen first. Corpses and non-gold offerings are named on the card, by hand.
- **The rung:** the ritual's printed rung, m42's table for a missing one, M45 for the two with no ladder.
- **Its Partial casts** (H13, Q171) with no PP lost. Where none is printed (Elemental Convergence) it is the Failure line, still with no PP lost.
- **Alone** (H14, Q172): Elemental Convergence, Essence Reforging and Eternal Invocation.
- **The casters' damage** on a failing rung goes to each caster at its own level DC (C3). Concord of Stone's goes to its primary (M38).
- **A rung that leaves nothing standing ends the cast**, so no PP lock or active entry is left behind.

### The ten

| Spell | Grade | What happens |
|---|---|---|
| **Army of the Grave** | B | The GM selects the undead within 300 ft. The module checks one per corpse, their levels within the PP (halved with +4 PP) and the undead trait, then records each on the REAL control register as "undead", at its full level (the +4 PP halving counts only against the PP). When a raised undead's effect ends, its control entry is released. Critical 1 month, Success 1 week; Partial half for 1 day (even with the +6 PP option), the GM ticking which, the rest hostile. Failure or worse: hostile, and 2d10 / 4d10 / 8d10 essence to every caster. The +6 PP option is permanent (PP locked, Q170) and marks the site Evil. *By hand:* studied undead, the corpses, the command. |
| **Call of the Ancestors** | C | The card: up to 3 questions (+1 a warp, max 10) and how they come. Critical: a chosen participant's advantage on one check within 24 hours (ticked). Partial: one answer misleading. Failure or worse: 1d6 / 2d6 / 4d6 mental to every caster. *By hand:* the answers; a Blunder's possession. |
| **Concord of Stone** | C | A 120-ft Region on the site (240 with +4 PP). Allies of the caster inside: +2 circumstance to DB. DR 5 / 10 / 2 on the label, by hand. Lasts 6 months / 1 month / 1 week; with +6 PP permanent, except on a Partial, which keeps its week. Failure 2d6, Blunder 8d6 to the primary. |
| **Elemental Convergence** | B | A 500-ft emanation (1 mile), 24 hours (1 week). Each creature's owner picks fire, cold, electricity or acid, asked once on its own client: two effects, resistance and a 1d6 (Critical 2d6) strike rider it may switch off. Leaving switches both off; coming back switches on only what the zone switched off, so a rider its owner turned off stays off. Failure or worse (a Partial too): 2d6 / 4d6 / 8d6 of each caster's element, basic Reflex (M42). *By hand:* the weather. |
| **Essence Reforging** | C | Success works (M45). **Remove**: an effect of PP ≤ the casting's, picked from the target's effects and removed by the GM's button. **Restore life** and **Change race** (Q176): by hand. A Fumble or Blunder: 1d8 force per target level to you and the target. |
| **Eternal Invocation** | B | Success works (M45). You place the 10-ft flame (the core's light circle). Within a mile, creatures sharing your aligned traits get rest ×2 (H15), advantage on crafting and Spellcraft (casting checks too, Q177) and a save tick. Opposed creatures get ×½ and disadvantage on the same. Permanent until dispelled (PP locked, Q170); the reach goes when it is dispelled. |
| **Rite of Binding Oath** | B | Its participants are its targets (Q173): the casters and the creatures ticked in the ritual dialog, up to 10 (+1 a warp), with nothing to target when casting. They are sworn: Critical 1 year (double damage), Success 1 month, Partial half for 1 month (the GM chooses which, on a GM card). The GM's **Oath broken** deals 2d6 (+1d6 a warp) essence, basic Fortitude at the cast's Save DC, and disadvantage on all rolls for 24 hours. Failure or worse: 2d6 / 4d6 / 8d6 to every caster. |
| **Rite of Echoed Shadows** | B | A 60-ft Region (Critical 300 ft, Partial 30 ft), 1 day (Partial 1 hour; +4 PP a week). Participants inside have advantage on Stealth (invisible with +6 PP, and 4d6 essence on leaving). An enemy's first entry: −2 (−4) circumstance to attacks for 1 minute. Failure: a Shadow per caster (a card); a Blunder's entity of level PP + 4 (a card). |
| **Sun’s Benediction** | B | Up to 6 (20) participants within 30 ft of you. Each heals 2d8+3 (Critical 4d8+6; +1d8+1 a warp) and lowers a condition it has by 1 (+1 a warp; injured with +4 PP; one held by a curse does not lower). Which condition is the creature's own choice, asked on its owner's client. Each gets +2 status to saves against fear for 1 hour (24 hours; a week or a month with +6 PP). Partial: half healing only. Failure or worse: no healing, 1d6 / 2d6 / 4d6 to every caster. |
| **Veil Severing** | C | A 30-ft portal marker for 1 year / 1 month / 1 week / 1 day (+2 PP: permanent / 1 year / 1 month / 1 week). A deferred teleport, so no Spatial Awareness card at the cast. Failure or worse: 4d6 / 8d6 / 12d6 to every caster; a Blunder's entity (a card). *By hand:* the plane, the travel, larger creatures. |

### The seven High Magic spells

| Spell | Grade | What happens |
|---|---|---|
| **Alter Corpse** | D | A card: Decompose or Restore, chosen at the cast. An object target. |
| **Chaos Shield** | B | A 30-ft aura (60 with +2 PP) while sustained. A wild surge within it offers the shield's caster 2 PP as a reaction to nullify it, once a round. Otherwise a surging ally (you too, Q178) rolls the table twice and picks, the row's damage to allies inside is halved, and its saves are at DC −2. It reaches Wild Magic areas, the Wild birthright and Wild Power; Wild Power's area disadvantage cancels against it (one roll, the core's rule). |
| **Leyline Anchor** | B | A ley line within 1 mile, anchored 10 minutes (1 hour / 24 hours). Casters within 300 ft of you (following you): +1 circumstance to Spellcraft and to Power Recovery (Meditation). High Magic cast there pays 1 PP less (min 1; payment only, Q179). Another caster's Tap or Channel first rolls Power Manipulation against your Save DC + 5; a failure stops it and spends Tap's 1 AP. |
| **Mimic Spell** | B | A cast reaction, offered to a creature that knows it, sees the caster within 60 ft, and has 8 PP and a reaction. It is not offered for a Ritual spell (Q8) or for one above that creature's maximum PP per cast (M48). It never stops the cast. Spellcraft is rolled against the spell's casting DC. Critical: an imprint for 1 minute (10 with +2 PP), any targets. Success: your next turn (1 minute), the original targets. Fumble: 1d6 essence per PP (basic Will). The imprint is cast from your sheet with your own PP; it may go below 0 at 5 Soul Drain each. No imprint above your maximum PP per cast (M48) or of a Ritual spell. A cast from the sheet is refused. *By hand:* the original's warps and metamagic (see "For Graham"). |
| **Soul Confluence** | B | You and the willing allies within 30 ft you pick, in the module's own dialog after the cast (target nothing). A pool of their Constitution modifiers × 5 takes their damage first, after temporary HP (TRG Prime's damage share, Q181). +2 status to Will. At the end, 1d6 Soul Drain per 2 rounds each, and the links are undone. |
| **Storm of Unmaking** | A | The core's storm (H16): a 60-ft radius within 200 ft, 1 minute, rolling 1d6 at the cast and at each of your turn starts. A Fumble or Blunder raises it on you, following you, at your Save DC (Q182; `helpers.placeStorm`): the cast's own, else your sheet's (10 + Spellcraft). |
| **Veilfracture** | C | A rift marked where you click (10 ft wide per 2 caster levels) while sustained; the plane is the GM's. A Fumble or Blunder: the GM's card rolls 1d4, the GM selects the creatures, and Reflex saves against your Save DC are rolled for them and you. A failure pulls in; a Fumble is lost there. |

## Also in 0.12.0

- **One writer per GM account** (for TRG Prime 3.686.1's election). The same GM in two tabs is one user, so every one of this module's automatic writers ran in both. They now ask the core's election through `module/writer.mjs`, read from the core's own `gm-connection.mjs`, so there is one election, not two:
  - **`isActingGM`** is for the hooks, sockets and clocks;
  - **`isActiveGMAccount`** is for a button the GM presses, so any tab of the GM's account may press it (Block 8a's bind button included);
  - **thirteen sites in eleven files** were converted, and `actsFor`'s GM fallback with them.
- **The extractor reads "Cost"** as a field (the ten rituals). Nothing else in the book's cut changes.
- **Riserune aims at no creature** (`targetsObject`). Its cast no longer opens the target dialog (the 0.11.2 live test's cosmetic finding).
- **Block 2:** Chaos Shield in the Wild Surge table's roll and its damage rows; Leyline Anchor's gate in Tap and Channel Ley Line.
- **Block 3a:** Wild Power's area disadvantage cancels against an ally's Chaos Shield.
- **Block 7's GM relay** may lower Soul Confluence's pool (never raise it) and delete its links.

## The independent review

An independent reviewer read 0.12.0 and TRG Prime 3.687.0 against the audit. Every finding below is fixed, with a check and a mutation, unless it says otherwise.

1. **Soul Drain was doubled** (HIGH). The core adds a Soul Drain tag's value, but Mimic Spell's below-0 PP and Soul Confluence's end passed the new total. Both now pass the increment; the cards name the total.
2. **A player's ritual gave no zone members** (the cast's own sync runs on the acting GM only). A `createRegion` hook on the acting GM now gives a membership Region its first members.
3. **Overlapping syncs could duplicate an effect.** Syncs now run one at a time per Region and re-check before creating.
4. **Soul Confluence ignored a refused write.** A write that cannot be made (no GM to relay it) now takes nothing, and a client draws on its own last pool, not a stale one.
5. **A creature's own choice was asked only on the elected GM tab.** It is now asked of the first connected player owner, else on any tab of the active GM's account (`answersFor`); a second answer is ignored.
6. **Army of the Grave's +4 PP option halved Control Levels.** The register now holds the full level.
7. **Army of the Grave's control entries were never released.** A raised undead's effect ending now releases its entry.
8. **Elemental Convergence's "can choose" was overridden** by the zone switching the one effect back on. Split into two effects, as above.
9. **Elemental Convergence could ask again** while a relayed question was open. It now asks once, until it is answered or a minute passes.
10. **"The GM chooses" ran on the caster's client.** The Oath's Partial is chosen on a GM card. Sun's Benediction's condition is the creature's own choice, on its owner's client, which also removes the socket's "reduce" request.
11. **A turn-start storm strikes only on the viewed scene.** Not fixed: TRG Prime's `tokensInRegion` reads the canvas (see TRG Prime 3.687.0's notes).
12. **The fumble storm's DC** "used the sheet's spellcraft DC without the PP". Changed to add the PP cast, then **reverted after the live test**: the reviewer was wrong. The sheet's DC (10 + Spellcraft) is the Save DC: a successful Storm of Unmaking used DC 35, the sheet's, where the changed reading gave its fumble DC 55.
13. **A cast-bound Region outlived a dismissed cast** until the next clock tick. An `updateActor` hook now removes it at once, and a Region whose cast has ended no longer counts meanwhile.
14. (Core) The ritual Partial's card line; 16. (Core) the PP Recovery dialog's rates: see TRG Prime 3.687.0.
15. **A Partial's printed span lost to the permanent warp** for Army of the Grave and Concord of Stone. A Partial keeps its own (1 day, 1 week).
17. **Block 7's relay lets any client lower the pool to 0.** Not fixed: the relay checks only that the pool falls, as Block 7's other drains do. A player could empty a shared pool by a forged message, never fill one.

## For Graham

1. **Mimic Spell's warps and metamagic "as cast" are by hand** (Q180: "The imprint is the spell as cast, at its PP, warps and metamagic included"). TRG Prime has no way for a module to hand a cast a warp already chosen and have it paid from the caster's PP. A stored spell is paid at storage, a threaded one with its first spell, an item's at the workbench. The card names the PP it was cast at; the caster takes the same options. Automating it needs a core seam ("a preset warp, paid"), which I have not built. It is yours to approve or leave.
2. **Mimic Spell's check:** against the spell's casting DC (10 + 1.5 × its PP as cast, M48), with no High Magic Hard step. The audit's §4.4 build says that DC. If you read Mimic's check as its own High Magic casting check (Hard, +2), it is a one-line change.
3. **Sun's Benediction's Partial, "Half healing only":** read as half the healing and nothing else, so no condition is lowered and no blessing given.
4. **Chaos Shield's halving** is for allies of the shield's caster inside the aura ("Allies gain resistance"). The −2 to DCs is for every save the row calls for (Q178).
5. **Essence Reforging's "Restore life" is by hand.** The core applies Resurrection's consequences (1 HP, 0 PP, a sealed injured 2, Death State −1) only from Resurrection's own effect row, which a module cannot apply to a target after a cast. A seam would automate it.
6. **Eternal Invocation's save advantage** against creatures of an opposed aligned trait is a tick on the save. The core's conditionals cannot read the source creature's aligned traits.
7. **Rite of Binding Oath's range** (live test): the book prints none. I read "Participants swear" with Q173: every participant of the rite is sworn, wherever they stand, up to 10 (+1 a warp). If you want a range (say 30 ft of the circle), it is a one-line change.
8. **Army of the Grave's +6 PP option on a Partial:** the undead are controlled for the Partial's day, but the cast's PP stay locked (the option's lock) until the cast is ended by hand. Concord of Stone's Partial ends its cast with its Region.
9. **Two review findings left as they are:** the storm on an unviewed scene (11) and the pool relay (17), above. Block 7's mirror and panic prompts still ask on the elected GM tab only.

## Found in the live test (12 November)

Tested in your world (`claude/eldritch-arts-live-testing-report-0.12.0.md`). Fixed, each with checks and mutations:

1. **Mimic Spell's check rolled +0** (high). TRG Prime's `rollCheck` fills in a save's or a skill's modifiers, not Spellcraft's, so the reactor's Spellcraft was never added. It now carries the sheet's Spellcraft. **Block 7's Argent Reversal** had the same fault since 0.10.0 (it was never run live) and is fixed with it.
2. **Mimic Spell was offered when it could never imprint**, for a Ritual spell or one above the reactor's maximum PP per cast. The refusal came only after the reactor paid 8 PP and its reaction. It is no longer offered for either.
3. **Rite of Binding Oath could not be cast.** It prints Targets but no Range, and TRG Prime reads a blank range as "self" (your 8 September ruling), so every targeted participant refused the cast. Its sworn are now the rite's participants (Q173), the casters plus those ticked in the ritual dialog. The spell asks the core for no creature (`targetsObject`).
4. **Soul Confluence's target dialog led to a refused cast.** The core offered the allies, then refused them as beyond "self". The module already asks which allies after the cast, so the spell now asks the core for none.
5. **The fumble storm's DC** (the review's item 12): reverted, as above.
6. **The ritual plan stays on the caster after a refused cast** (low). The next ritual overwrites it. Left as it is.

Found and not changed:

- **A spell's Cost makes change in the largest coins.** 49,200 gp became 568 mp and 9 pp, as Learn a Spell already does (the core's `deductCurrency`). Nothing is lost.
- **The storm's fumble note** ("A Fumble or Blunder: the storm appears above you…") is printed on every cast, as a reminder.
- **Raised undead keep their token's disposition.** The control register holds them; Concord of Stone and Chaos Shield, which read sides, still count them as hostile until the GM changes it.

## Found at install: the zip shipped stale packs

The first 0.12.0 zip was built after `build-packs --json`, which writes `packs-source/` only. Its compiled spells pack was the 8 November one: 113 spells, none of the 17, and Riserune still asking for a creature. Every harness passed, because each reads `packs-source/` or the content modules. The zip was rebuilt from compiled packs (130 spells), and:

- **New `tools/verify-packs-compiled.mjs`:** it extracts every compiled pack and checks it document by document against `packs-source/`.
- **`tools/build-zip.mjs` runs it first** and refuses to zip stale packs.

## The harness

- **New pair:** `tools/verify-block8b.mjs` (356 checks) and `tools/mutate-block8b.mjs` (165 mutations, all caught). Each ritual is driven by degree, along with its Cost, its casters' damage, its memberships (Concord, Convergence, Echoed Shadows, Eternal Invocation, Leyline Anchor) and the GM's buttons. So are Chaos Shield in Block 2's real table roll, the anchor's discount and gate, Mimic Spell's reaction, imprint, PP below 0 and end, Soul Confluence's pool and backlash, the storm's fumble, Veilfracture and the writer. The control register is the REAL core's.
- **Re-pinned or extended:**
  - `verify-block2b` (the second ritual rules key);
  - `verify-block6-lead` (91 spells by school, 39 the book);
  - `verify-block7` and `verify-block8a` (the manifest; the spells pack's 130; Riserune's object target);
  - `verify-book-extract` (the 17 uncommon);
  - `verify-fixes-0101` (the object targets).
- **Re-anchored mutations** (to the 3.687.0 and 0.12.0 pins, and to 0.12.0's writer lines): `mutate-block1`, `2`, `2b`, `3`, `3b`, `4`, `6-lead`, `7` and `8a`.
- **All 22 verifies pass** on TRG Prime 3.687.0, and every mutate catches all its mutations (each run on a copy of the tree).
