# Eldritch Arts 0.5.1

2 November 2026. The fixes from the live test of 0.5.0 (`LIVE_TESTING_REPORT_0.5.0.md`).

- **Install over 0.5.0, on TRG Prime 3.680.0.** The system does not change.
- **No migration prompt.** An existing Witch's spell adder is trued up to her bond when a scene loads (fix 2).

## Fixed

1. **Hexes now takes every hex owed in one Use.** Before, it took one per Use, though its dialog read "1 of 2". It now asks for one after another, as Wild Power does. Cancelling stops, and what was taken stays.
2. **The Soulbound Familiar's spell adder now needs the familiar.** "It is also treated as a +1-spell adder": a Witch with no familiar, a dead one or a severed bond had a free casting a day anyway. The ability now carries the adder only while the soulbound familiar lives and holds the bond. An existing Witch is put right when the scene loads, and her daily preparation card stops promising the free casting.
3. **Ranges are no longer one move behind.** On Foundry V14 a moving token reports where it is drawn, not where it is going, until its animation ends. These ranges are now measured from where the token stands:
   - the Soulbound Familiar's 30 ft;
   - Block 1's Null Aura;
   - Block 2's ally ranges;
   - Gale Step's 15 ft.
   Ley Tap was already right.
4. **A severed bond now fatigues.** "You gain the fatigued 2 condition until you can create a new bond": 0.5.0 handed the system the condition in a form it ignores. The new bond takes the 2 off again, through the system's own condition setter, and leaves any other fatigue the Witch has. A bond severed under 0.5.0, which fatigued no one, takes nothing off.
5. **A familiar killed while dying now severs the bond.** Death comes when Dying passes the Death State, often with no change to HP, and 0.5.0 looked only at HP. The bond now notices any change to the familiar, any change to its conditions, and the system's "creature slain" event. A familiar already dead when the scene loads severs the bond then.
6. **A renewed bond says so.** At daily preparation, a card now says the bond is renewed, and what its fatigue came to ("Fatigued 3 → 1").
7. **Gale Step no longer spends itself on a refused teleport.** When the system refuses the move, nothing is paid and nothing is carded, and Gale Step says so beside the system's own notice. Before, it still printed "You teleport 15 feet" and spent its Focus use and, in combat, 1 AP.
   - **Teleporting past creatures:** Gale Step's one-hop teleport over another creature was always allowed; only ending in an occupied square is refused (page 198). The review had read the system as refusing it, and a test on a throwaway scene showed otherwise. The real defect was elsewhere in the system: a Blink drag with waypoints was checked as if walked between its hops. That is fixed in TRG Prime 3.680.1, which this release does not need.

## Found in an independent review before release, and fixed

- **One death could sever the bond two or three times.** The new death checks (the Dying update, the Dead status, the slain hook) can all arrive before the first one's flag is saved, and fatigue adds, so the Witch could reach Fatigued 4 or 6 with three cards. Fatigue 20 is death. A severing now holds the Witch until it finishes, as the system does when it reaps the dead.
- **A new bond would have wiped all fatigue gained since the sever,** by deleting the whole Fatigued effect. It now takes off only the 2.
- **The spell adder followed any familiar.** It now follows only the soulbound familiar, not one made by the core's Familiar feat.

## Harness

- **`verify-block3`:** 302 checks, up from 275.
  - **Its fakes take the system's real shapes.** A condition is `{ key, value }`, a valued condition merges into one already there, and it is set through the actor's condition setter. Death is Dying past the Death State. An item's flag is saved a moment later, as a server round trip is.
  - **New checks cover:**
    - two hexes in one Use, and a cancelled second choice;
    - the adder's life: none before the bond, one with it, none when the familiar is dead or the bond severed, back on rebonding;
    - an old Witch trued up, a familiar that died unseen, and a dead familiar the bond did not make;
    - the range read from a moving token's source;
    - a death by Dying through a non-HP update, and one death told three ways at once (one Fatigued 2, one card);
    - no second severing;
    - the 2 taken off at the new bond, with fatigue gained before and since kept;
    - a 0.5.0 severed bond renewed;
    - no adder from a familiar the bond did not make, alive or dead;
    - Gale Step refused, free and too far;
    - the shared measure;
    - the new hooks.
- **`mutate-block3`:** 83 mutations, all caught. That is 0.5.0's 61, less the static adder on the item (now gone), plus 23 new for these fixes and the review's. Two of 0.5.0's were re-pointed: "Severed Bond does not fatigue" to the new tag, and "the fatigue is the bond's own effect" to the lift by value.
- **Still green:**
  - `verify-block1` 883, `verify-block2` 131, `verify-block2b` 91;
  - `mutate-block1` 86, `mutate-block2` 75, `mutate-block2b` 81.
  - Their version pins moved to 0.5.1.
