# Live test: Eldritch Arts 0.9.2 (Block 6) on TRG Prime 3.684.8

6 November 2026. Graham's world in Chrome. All tests used throwaway "ZZ EA …" actors on a throwaway scene, plus one throwaway ley-line Region. No combat was used. Everything was cleaned up afterwards.

## Passes

**Absolute Denial.** The Denier is hostile and stands 15 ft from the friendly Wizard.

| Cast | Denier | Result |
|---|---|---|
| Shocking Grasp (2 PP) | 15 ft away | Stopped: "ZZ EA Denier's Absolute Denial: Shocking Grasp (2 PP) fails within the Denial Aura". The spell fails, and 1 PP is lost (half). |
| Shocking Grasp | Moved 30 ft from the caster and 30 ft from the target | Not stopped. The spell hit. |
| Fireball at 8 PP (6 + 2 warp), level 8 Wizard | Back in range | Stopped. 4 PP lost. |
| Fireball at 9 PP (6 + 3 warp) | In range | Not stopped (above 8 PP). It took effect and its area was placed. |

At level 6 the 9 PP Fireball was refused for being above the overcast limit of 7, which is correct.

**Counter Channel:**
- **The setup:** the reactor is hostile, 15 ft away, a Wizard with the Counter Channel ability and 10 PP.
- **The prompt:** the Wizard's Shocking Grasp raised it: "ZZ EA Wizard casts Shocking Grasp (2 PP), 15 feet from you … Power Manipulation against DC 18". Shocking Grasp has no save, so the DC is the caster's Spell DC.
- **Yes:** it rolled 22 against 18, a Success. The spell's damage dice were halved, and the reactor spent its reaction, its Focus use and 1 PP.

**Symbiotic Witch:**
- **The familiar.** A level 6 Witch (Eldritch Arts class) used Soulbound Familiar, which summoned "ZZ EA Witch's Raven", marked as soulbound.
- **Out of range when cast directly.** Acid Bolt (4 PP, 30 ft) at a foe 35 ft from the Witch was refused: "beyond Acid Bolt's range of 30 feet". Nothing was spent.
- **In range through the familiar.**
  - Symbiotic Witch's Use offered the conduit and listed Acid Bolt (PP 4) as castable.
  - Cast through the Raven (20 ft from the foe), it hit for 40.
  - 4 PP were spent, after declining the Spell Adder offer, and today's conduit was spent (1 → 0).
  - The card said "cast through ZZ EA Witch's Raven: range and area from its token".
  - The Result card also showed High Magic (0.9.1: all Witch spells).

**Tap Ley Line with Leyline Weaver:**
- **The setup:** a ley-line Region at level 5 (Lesser Ley Flow), 10 to 15 ft from a Wizard with Leyline Weaver and the Ley-Etched Symbol.
- **The check:** Power Manipulation against the line's DC 21 (Hard), with Leyline Weaver's +2 circumstance, gave a Success.
- **The ladder:** Leyline Weaver's ladder replaced the core result: "until the end of your next turn", with a d100 benefit (94: Quicken, "Apply at the table").
- **The marker:** the Ley-Etched Symbol owner got the effect "Ley line benefit — … (Leyline Weaver)".
- **Leyline Power** was offered afterwards (declined).

## Not run

**Hex and Xithra.** Xithra needs a Xithra-soul character with Elemental Blast, and the hexes need a Witch's Hexes setup. They are left for a later session. Hex Weaver's Familiar grant was covered by the 3.684.8 feat-pick fix.

## Notes

- **Cosmetic:** the Tap Ley Line check card read "vs ZZ EA FarFoe", because a token was still targeted from an earlier test. The DC was the line's own, so this is only a label. The core's skill card names the user's current target.

## Cleanup

- **Deleted:**
  - the ZZ actors, including the familiar;
  - the scene ZZ EA Test and its Region;
  - 48 test chat cards.
- **Dice and notifications:** restored.
- **Not touched:** Graham's combat (active, round 1, turn 3).
- **View:** Oldwatch Approach.
- **The game is still paused,** as it was before the test.
