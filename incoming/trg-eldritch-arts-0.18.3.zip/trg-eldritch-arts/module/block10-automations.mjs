/**
 * Eldritch Arts Block 10 (0.17.0, on TRG Prime 3.693.0) — relics and sentient
 * items, the Foundry half. The rules are module/block10-rules.mjs; the items
 * tools/content/block10.mjs.
 *
 *   Bonding      the Relic Bonding Ritual (a skill action): the relic chosen,
 *                its own refusals, the cost (the performer's 1 PP and 250 gp),
 *                the Level DC of the wielder's level; the degree as ruled
 *   Awakening    at the wielder's daily preparation, one tier, to the level's
 *   Investing    TRG Prime's H27: the tier is asked (the highest the free
 *                slots pay for), it costs that tier's slots, only the bonded
 *                wielder may invest it; RELIC and SENTIENT are one-invested
 *   The tier     the relic's quality, superior traits and runes rewritten;
 *                its innate spells granted (focus, the core's allowance where
 *                the PP is above the level); its powers granted as abilities
 *                (effects, conditionals, auras, Uses, senses)
 *   Uses         Shield of Dawn, the Veilshroud's shadow step, Influence (GM)
 *   Veil-Drinker the Veilshroud's Legendary absorption (TRG Prime's H28)
 */
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, tokenOf, tokenCentre, spendAP, feetBetween } from "./block1-automations.mjs";
import { pickPoint, spellIndex, actsFor } from "./block3-automations.mjs";
import { allies } from "./block3b-automations.mjs";
import * as R from "./block10-rules.mjs";

const items = (actor) => Array.from(actor?.items ?? []);
const now = () => Number(globalThis.game?.time?.worldTime ?? 0);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const levelOf = (actor) => Math.max(1, int(actor?.system?.identity?.level));
const core = async (path) => import(globalThis.foundry?.utils?.getRoute?.(`systems/trg-prime/${path}`) ?? `/systems/trg-prime/${path}`);
const fromUuid = async (uuid) => (uuid ? (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(uuid) ?? null : null);

/**
 * ONE SYNC AT A TIME PER ACTOR (found writing the harness): Foundry does not
 * await a hook, so a flag written by one sync and the sync its own hook starts
 * would otherwise run side by side, each deleting and recreating the grants.
 */
const QUEUES = new Map();
function serial(actor, fn) {
  const key = String(actor?.uuid ?? actor?.id ?? "");
  const prev = QUEUES.get(key) ?? Promise.resolve();
  const next = prev.catch(() => {}).then(fn);
  QUEUES.set(key, next.finally(() => { if (QUEUES.get(key) === next) QUEUES.delete(key); }));
  return next;
}
const fresh = (actor, item) => items(actor).find((i) => i.id === item?.id) ?? null;

/**
 * THE GRANTS' OWN FORMAT (0.17.1, found in review): part of each signature, so
 * a world upgrading from 0.17.0 rebuilds its grants once (Dawnshield's Cure at
 * its own level, the Codex's Detect Undead at will). Raise it whenever what a
 * grant carries changes. Spent uses survive the rebuild (recordUses).
 */
export const GRANT_FORMAT = 2;

/** The flag a relic's or a sentient item's grants carry: the granting item's id. */
export const GRANT_FLAG = "relicGrant";
/** The Codex's Dissonance effect's source. */
export const DISSONANCE_SOURCE = "codexDissonance10";
/** The bonding plan on the performer. */
export const BOND_PLAN = "relicBondPlan";

/* ------------------------------------------------------------------ */
/* Who a relic belongs to                                               */
/* ------------------------------------------------------------------ */

const isRelic = (item) => Boolean(R.relicRecord(item, MODULE_ID));
const isSentient = (item) => Boolean(R.sentientRecord(item, MODULE_ID));
const alignedOf = async (actor) => {
  try { return (await core("module/aligned.mjs")).alignedTraitsOf(actor?.system ?? {}).map((t) => norm(t)); } catch { return []; }
};

/** TRG Prime's H27 cost: a relic's invested tier, a sentient item's two. */
export function relicInvestCost(item) {
  return R.investCostOf(item, MODULE_ID);
}

/** TRG Prime's H27 refusal: bond it first; nobody else may invest a bonded relic (M98 (b)). */
export function relicInvestRefusal(item, actor) {
  const r = R.relicRecord(item, MODULE_ID);
  if (!r) return "";
  if (!r.wielderUuid) return "bond it first (the Relic Bonding Ritual)";
  if (actor?.uuid && r.wielderUuid !== actor.uuid) return `it is bonded to ${r.wielderName || "another creature"}`;
  return "";
}

/** TRG Prime's H27 step before Invest Item: the tier, from the free slots (M98 (a)). */
export async function relicInvestPrepare(item, actor, { free = 0 } = {}) {
  const r = R.relicRecord(item, MODULE_ID);
  if (!r) return null;
  const top = R.highestAffordableTier(r.awakened, free);
  if (top < 0) return { refused: `it needs ${R.slotsForTier(0)} free investment slot at least` };
  let tier = top;
  if (top > 0) {
    const options = [];
    for (let t = top; t >= 0; t -= 1) options.push([String(t), `${R.TIERS[t].label} (${R.slotsForTier(t)} slot${t ? "s" : ""})`]);
    const pick = await h().chooseFromList(item.name, `Invest it at which tier? It is awakened to ${R.TIERS[int(r.awakened)].label}, and ${free} slot${free === 1 ? " is" : "s are"} free.`, options);
    if (pick === null || pick === undefined || pick === "") return { refused: "no tier chosen" };
    tier = Math.max(0, Math.min(top, int(pick)));
  }
  await item.setFlag(MODULE_ID, "relic", { ...r, investedTier: tier, chosenBelow: tier < top });
  return null;
}

/* ------------------------------------------------------------------ */
/* The tier, written onto the item and the wielder                      */
/* ------------------------------------------------------------------ */

let spellCache = null;
async function spellData(name) {
  spellCache ??= await spellIndex();
  const entry = spellCache.find((e) => norm(e.name) === norm(name));
  if (!entry) return null;
  const doc = await entry.pack.getDocument(entry._id);
  return doc ? doc.toObject() : null;
}

/**
 * A DAY'S USES SURVIVE A REWRITE (found in review): grants are deleted and
 * recreated when the tier changes, so a spent Shield of Dawn, Gate or focus
 * spell would otherwise come back full. Matched by name and type.
 */
export const KEPT_USES = "keptUses";
/** Note on the granting item what its grants had left, before they are deleted. Cleared at the daily preparation. */
async function recordUses(item, list) {
  const kept = { ...(item.flags?.[MODULE_ID]?.[KEPT_USES] ?? {}) };
  let any = false;
  for (const i of list ?? []) {
    const left = i?.system?.usesValue;
    if (left === undefined || left === null) continue;
    kept[`${i.type}|${norm(i.name)}`] = int(left);
    any = true;
  }
  if (any) await item.setFlag(MODULE_ID, KEPT_USES, kept);
}
/** After the grants are made, give back only what was left (TRG Prime primes a Focus spell full on creation). */
async function restoreUses(actor, item, created) {
  const kept = item.flags?.[MODULE_ID]?.[KEPT_USES] ?? {};
  const fixes = [];
  for (const d of created ?? []) {
    const k = `${d.type}|${norm(d.name)}`;
    if (!(k in kept)) continue;
    const left = Math.min(int(kept[k]), int(d.system?.usesValue));
    if (left !== int(d.system?.usesValue)) fixes.push({ _id: d.id, "system.usesValue": left });
  }
  if (fixes.length) await actor.updateEmbeddedDocuments("Item", fixes);
}

/** The quality, superior traits and runes of a state, as the core's customisation reads them. */
async function itemUpdateFor(item, state) {
  const base = item.flags?.[SYSTEM_ID]?.baseCustomisation;
  const traitKeys = state.superior ? [norm(state.superior)] : [];
  const update = { "system.quality": state.quality || "standard", "system.superiorTraits": traitKeys.join(","), "system.runes": state.runes || "" };
  if (base && ["weapon", "shield", "armour"].includes(item.type)) {
    const { computeFullCustomisation } = await core("module/item-quality.mjs");
    const result = computeFullCustomisation(item.type, base, { quality: state.quality || "standard", traitKeys, runes: state.runes || "" });
    update["system.weight"] = result.weight;
    if (item.system?.hp && result.hpMax > 0) {
      update["system.hp.max"] = result.hpMax;
      // The damage it has taken is kept (found in review): its new maximum less what it had lost.
      const lost = Math.max(0, int(item.system.hp.max) - int(item.system.hp.value));
      update["system.hp.value"] = Math.max(-result.hpMax, result.hpMax - lost);
    }
  }
  return update;
}

/** One power as an ability item the wielder carries while its tier is invested. */
function powerItem(source, power, { perfectDarkvision = false } = {}) {
  const effects = [];
  if ((power.changes ?? []).length || (power.self ?? []).length) {
    effects.push({
      name: power.name, img: "icons/svg/aura.svg", transfer: true, disabled: false, description: power.text,
      changes: (power.changes ?? []).map((c) => ({ ...c })),
      flags: { [SYSTEM_ID]: { ...((power.self ?? []).length ? { conditionals: power.self.map((c) => ({ ...c })) } : {}) }, [MODULE_ID]: { [GRANT_FLAG]: source.id } }
    });
  }
  const derives = power.sight ? (perfectDarkvision ? { sense: { name: "Perfect Darkvision", category: "primary", special: true, modality: "visual" }, light: { raisesLevelBy: 3 } } : { sense: { name: "Darkvision", category: "primary", special: true, modality: "visual" }, light: { raisesLevelBy: 2 } }) : null;
  return {
    name: power.sight ? `${power.name.split(":")[0]}: ${perfectDarkvision ? "Perfect Darkvision" : "Darkvision"}` : power.name,
    type: "ability", img: "icons/svg/aura.svg",
    system: { description: `<p>${esc(power.text)}</p><p><em>Granted by ${esc(source.name)} while it is invested at this tier (Eldritch Arts 0.17.0).</em></p>`, usesPerDay: power.usesPerDay ?? "", bonusUses: 0, usesValue: power.usesPerDay ? int(power.usesPerDay) : 0, sourceRace: "", sourceClass: "", traits: "", category: "Racial" },
    effects,
    flags: {
      [SYSTEM_ID]: { ...(power.auras ? { auras: power.auras.map((a) => JSON.parse(JSON.stringify(a))) } : {}), ...(derives ? { creatureAbility: { derives } } : {}) },
      [MODULE_ID]: { [GRANT_FLAG]: source.id, relicPower: power.key, ...(power.uses ? { relicUse: power.uses } : {}), ...(power.absorb ? { relicAbsorb: power.absorb } : {}) }
    }
  };
}

/** The spell copies a state grants: innate, granted by the item, with the core's allowance where needed. */
async function spellItems(source, spec, state) {
  const out = [];
  for (const { name, tier } of state.spells) {
    const data = await spellData(name);
    if (!data) { warn(`${source.name}: no spell named ${name} in the packs.`); continue; }
    delete data._id;
    data.system = { ...data.system, innate: true, prepared: true, usesPerDay: "" };
    const once = (R.ONCE_A_DAY_SPELLS[spec.key] ?? []).includes(name);
    const atWill = (R.AT_WILL_SPELLS[spec.key] ?? []).includes(name);
    // "AS AN INNATE SPELL WITH THE FOCUS TRAIT": one use, Refocus to regain it
    // (TRG Prime would add the trait on creation; written here so it is never
    // missed). Gate is once a day instead.
    if (once) data.system = { ...data.system, usesPerDay: "1", usesValue: 1 };
    // At will: TRG Prime's "unlimited", which also keeps it from taking Focus.
    else if (atWill) data.system = { ...data.system, usesPerDay: "unlimited" };
    else if (!/\bfocus\b/i.test(String(data.system.traits ?? ""))) data.system = { ...data.system, traits: [String(data.system.traits ?? "").trim(), "Focus"].filter(Boolean).join(", "), usesValue: 1 };
    const allowance = R.innateAllowance(data.system.ppCost, tier);
    data.flags = {
      ...(data.flags ?? {}),
      [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: source.id, sourceName: source.name, requested: name }, ...(allowance ? { innatePPAllowance: allowance } : {}) },
      [MODULE_ID]: { ...(data.flags?.[MODULE_ID] ?? {}), [GRANT_FLAG]: source.id }
    };
    out.push(data);
  }
  return out;
}

/**
 * Write a relic's tier (Q215): the item's own statistics, then the wielder's
 * granted spells and powers. Whoever owns the actor writes; a second call with
 * nothing changed writes nothing.
 */
export function syncRelic(actor, item) {
  return serial(actor, () => { const now = fresh(actor, item); return now ? syncRelicNow(actor, now) : null; });
}
async function syncRelicNow(actor, item) {
  if (!actor || !item || !isRelic(item) || !actor.isOwner) return null;
  const spec = R.relicSpecOf(item, MODULE_ID);
  if (!spec) return null;
  const tier = R.activeTier(item, MODULE_ID);
  const state = R.relicStateAt(spec, tier);
  const update = await itemUpdateFor(item, state);
  const changed = Object.entries(update).some(([k, v]) => globalThis.foundry?.utils?.getProperty?.(item, k) !== v);
  if (changed) await item.update(update, { eaRelicSync: true });
  // THE GRANTS, REPLACED WHOLE: what this item granted goes, what its tier grants comes.
  const signature = JSON.stringify({ g: GRANT_FORMAT, tier, spells: state.spells.map((s) => s.name), powers: state.powers.map((p) => p.key) });
  const had = items(actor).filter((i) => i.flags?.[MODULE_ID]?.[GRANT_FLAG] === item.id);
  if (item.flags?.[MODULE_ID]?.relicSignature === signature && had.length === state.spells.length + state.powers.length) return { tier, state };
  await recordUses(item, had);
  if (had.length) await actor.deleteEmbeddedDocuments("Item", had.map((i) => i.id));
  if (tier >= 0) {
    const ownDarkvision = items(actor).some((i) => i.flags?.[MODULE_ID]?.[GRANT_FLAG] !== item.id && /^darkvision$/i.test(String(i.flags?.[SYSTEM_ID]?.creatureAbility?.derives?.sense?.name ?? i.name ?? "").trim()));
    const docs = [...await spellItems(item, spec, state), ...state.powers.map((p) => powerItem(item, p, { perfectDarkvision: ownDarkvision }))];
    if (docs.length) await restoreUses(actor, item, await actor.createEmbeddedDocuments("Item", docs));
  }
  await item.setFlag(MODULE_ID, "relicSignature", signature);
  return { tier, state };
}

/** The Codex's Dissonance (Q220): an effect while bonded to a Balance or Order wielder. */
export function syncDissonance(actor, item) {
  return serial(actor, () => { const now = fresh(actor, item); return now ? syncDissonanceNow(actor, now) : null; });
}
async function syncDissonanceNow(actor, item) {
  if (!actor?.isOwner) return;
  const r = R.relicRecord(item, MODULE_ID);
  const want = Boolean(r?.wielderUuid === actor.uuid && R.suffersDissonance(r?.key, await alignedOf(actor)));
  const have = Array.from(actor.effects ?? []).filter((e) => e.flags?.[MODULE_ID]?.source === DISSONANCE_SOURCE && e.flags?.[MODULE_ID]?.itemId === item.id);
  if (want && !have.length) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(DISSONANCE_SOURCE, {
      name: `${item.name}: Dissonance`, img: "icons/svg/daze.svg",
      description: "Disadvantage on Will saves while the Codex is bound to you (a Balance- or Order-aligned wielder).",
      system: { conditionals: [{ kind: "disadvantage", label: `${item.name}: Dissonance`, scope: "Will saves", auto: true, when: { checkTypes: ["save"], subjects: ["will"] } }] },
      module: { itemId: item.id }
    })]);
  } else if (!want && have.length) {
    await actor.deleteEmbeddedDocuments("ActiveEffect", have.map((e) => e.id));
  }
}

/* ------------------------------------------------------------------ */
/* Sentient items                                                       */
/* ------------------------------------------------------------------ */

/** The powers a sentient item grants while invested (and not dimmed): as abilities. */
export function syncSentient(actor, item) {
  return serial(actor, () => { const now = fresh(actor, item); return now ? syncSentientNow(actor, now) : null; });
}
async function syncSentientNow(actor, item) {
  if (!actor?.isOwner || !isSentient(item)) return null;
  const rec = R.sentientRecord(item, MODULE_ID);
  const active = Boolean(item.system?.invested) && !rec.dimmed;
  const want = active ? (rec.powers ?? []) : [];
  const signature = JSON.stringify({ g: GRANT_FORMAT, active, powers: want.map((p) => p.key), spells: active ? rec.spells ?? [] : [] });
  const had = items(actor).filter((i) => i.flags?.[MODULE_ID]?.[GRANT_FLAG] === item.id);
  const influence = items(actor).filter((i) => i.flags?.[MODULE_ID]?.[GRANT_FLAG] === item.id && i.flags?.[MODULE_ID]?.relicUse === "influence");
  if (item.flags?.[MODULE_ID]?.sentientSignature === signature && had.length === want.length + (active ? (rec.spells ?? []).length : 0) + (item.system?.invested ? 1 : 0)) return { active };
  const keep = item.system?.invested ? influence.map((i) => i.id) : [];
  const dropped = had.filter((i) => !keep.includes(i.id));
  await recordUses(item, dropped);
  if (dropped.length) await actor.deleteEmbeddedDocuments("Item", dropped.map((i) => i.id));
  const docs = want.map((p) => powerItem(item, p));
  if (active) {
    for (const s of rec.spells ?? []) {
      const data = await spellData(s.name);
      if (!data) continue;
      delete data._id;
      data.system = { ...data.system, innate: true, prepared: true, usesPerDay: String(s.perDay ?? 1), usesValue: int(s.perDay ?? 1) };
      // "CAN INDEPENDENTLY CAST": at the item's own level (TRG Prime 3.694.0's opt-in; Graham's yes of 15 November 2026).
      data.flags = { ...(data.flags ?? {}), [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: item.id, sourceName: item.name, requested: s.name, atItemLevel: true } }, [MODULE_ID]: { [GRANT_FLAG]: item.id } };
      docs.push(data);
    }
  }
  // INFLUENCE (Q218): the GM's button, on the wielder while the item is invested — dimmed or not.
  if (item.system?.invested && !keep.length) docs.push(powerItem(item, { key: "influence", name: `${item.name}: Influence (GM)`, text: `The GM rolls the wielder's Will save against ${item.name}'s Ego DC ${int(rec.egoDC)} when the wielder opposes its will (L10399). The GM adjudicates exact influence.`, uses: "influence" }));
  if (docs.length) await restoreUses(actor, item, await actor.createEmbeddedDocuments("Item", docs));
  await item.setFlag(MODULE_ID, "sentientSignature", signature);
  return { active };
}

/* ------------------------------------------------------------------ */
/* Uses                                                                 */
/* ------------------------------------------------------------------ */

const usesLeft = (item) => int(item?.system?.usesValue);
async function spendDaily(item) { await item.update({ "system.usesValue": Math.max(0, usesLeft(item) - 1) }); }

/** Shield of Dawn (L10224; M105): 2 AP, 1/day, you and allies within 30 ft for 1 minute. */
const shieldOfDawn = {
  hint: "2 AP, concentrate, once a day: Fast Healing 10 and advantage on saves against aberrations, eternals and undead for you and allies within 30 ft, for 1 minute.",
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Shield of Dawn: already invoked today.");
    if (!(await spendAP(actor, "Shield of Dawn", 2))) return false;
    const me = tokenOf(actor);
    const who = [actor];
    if (me) for (const t of tokens()) if (t.actor !== actor && allies(t.document?.disposition, me.document?.disposition) && (feetBetween(me, t) ?? Infinity) <= 30) who.push(t.actor);
    for (const target of who) {
      await h().createEffectsOn(target, [effectData("shieldOfDawn10", {
        name: "Shield of Dawn", img: "icons/magic/light/explosion-star-glow-yellow.webp",
        description: `Fast Healing 10 and advantage on all saving throws against aberrations, eternals and undead (${actor.name}'s Shield of Dawn).`,
        system: { fastHealing: 10, conditionals: [{ kind: "advantage", label: "Shield of Dawn", scope: "Saving throws against aberrations, eternals and undead", auto: true, when: { checkTypes: ["save"], sourceTypes: ["aberration", "eternal", "undead"] } }] },
        expiry: forSeconds(60)
      })]);
    }
    await spendDaily(item);
    await card(actor, "Shield of Dawn", [
      line(`${who.map((a) => esc(a.name)).join(", ")}: <strong>Fast Healing 10</strong> and <strong>advantage</strong> on saves against aberrations, eternals and undead, for 1 minute.`),
      line("<em>By hand: enemies with the Evil aligned trait cannot benefit from concealment or invisibility within 30 ft of you.</em>")
    ]);
    return true;
  }
};

/** The Veilshroud's shadow step (L10357; M108): 2 AP, 1/day, 60 ft between spaces of light level 2 or lower. */
const shadowStep = {
  hint: "2 AP, move, teleportation, once a day: teleport up to 60 ft from a space of light level 2 or lower to another such space you can see.",
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Shadow Step: already used today.");
    const token = tokenOf(actor);
    if (!token) return warn("Shadow Step: place your token on the map first.");
    const here = await h().lightLevelAt?.(token);
    if (here !== null && here !== undefined && int(here) > 2) return warn(`Shadow Step: your space is at light level ${here}; it needs 2 or lower.`);
    const point = await pickPoint("Shadow Step: click a space of light level 2 or lower you can see, within 60 ft. Escape cancels.");
    if (!point) return false;
    const grid = canvas.grid;
    const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x, y: point.y };
    const dist = grid.measurePath([tokenCentre(token), { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
    if (dist > 60) return warn(`Shadow Step: that is ${Math.round(dist)} feet away; up to 60.`);
    if (!(await spendAP(actor, "Shadow Step", 2))) return false;
    const src = token.document._source ?? token.document;
    const was = { x: src.x, y: src.y };
    await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
    const after = token.document._source ?? token.document;
    if (after.x === was.x && after.y === was.y) return warn("Shadow Step: the teleport was refused (see the notice).");
    const there = await h().lightLevelAt?.(token);
    if (there !== null && there !== undefined && int(there) > 2) {
      await token.document.update({ x: was.x, y: was.y }, { animate: false, teleport: true });
      return warn(`Shadow Step: that space is at light level ${there}; it needs 2 or lower. You stay where you were (no AP is returned).`);
    }
    await spendDaily(item);
    await card(actor, "The Veilshroud — Shadow Step", [line(`${esc(actor.name)} steps through the shadows, ${Math.round(dist)} feet (light level ${here ?? "?"} to ${there ?? "?"}).`)]);
    return true;
  }
};

/** Influence (L10399; Q218): the GM rolls the wielder's Will save against the item's Ego DC. */
const influence = {
  hint: "GM: the wielder opposes the item's will — roll their Will save against its Ego DC.",
  async use(actor, ability) {
    if (!globalThis.game?.user?.isGM) return warn("Influence: the GM decides when the item asserts itself (Q218).");
    const item = items(actor).find((i) => i.id === ability.flags?.[MODULE_ID]?.[GRANT_FLAG]);
    const rec = R.sentientRecord(item, MODULE_ID);
    if (!item || !rec) return warn("Influence: the sentient item is no longer here.");
    if (rec.dimmed) {
      const restore = await foundry.applications.api.DialogV2.confirm({ window: { title: `${item.name} — dimmed` }, content: `<p>${esc(item.name)} is dimmed. Has ${esc(actor.name)} atoned with a protective act? Restore its powers?</p>` });
      if (!restore) return false;
      await item.setFlag(MODULE_ID, "sentient", { ...rec, dimmed: false });
      await syncSentient(actor, items(actor).find((i) => i.id === item.id));
      await card(actor, item.name, [line(`${esc(item.name)} brightens again: its powers return.`)]);
      return true;
    }
    const blocked = R.influenceRefusal(rec, now());
    if (blocked) return warn(`Influence: ${blocked}.`);
    const dc = int(rec.egoDC);
    const check = await h().rollCheck({ actor, type: "save", subject: "will", dc, label: `${actor.name} — Will Save`, saveSource: `${item.name} (Ego ${int(rec.ego)})`, sourceUuid: item.uuid });
    const degree = norm(check?.outcome?.degree?.key ?? "failure");
    const text = R.influenceText(degree, rec.overrides ?? {});
    const next = { ...rec };
    const wait = R.INFLUENCE_WAIT[degree];
    if (wait) { next.influenceBlockedUntil = now() + wait; next.blockedBy = degree === "fumble" ? "fumble" : "critical"; }
    if (rec.dimsOnFailure && degree === "failure") next.dimmed = true;
    await item.setFlag(MODULE_ID, "sentient", next);
    if (next.dimmed) await syncSentient(actor, items(actor).find((i) => i.id === item.id));
    await card(actor, `${item.name} — Influence`, [
      line(`${esc(actor.name)}'s Will save against Ego DC ${dc}: <strong>${esc(check?.outcome?.degree?.label ?? degree)}</strong>.`),
      line(esc(text)),
      ...(next.dimmed ? [line("<em>Its powers are withdrawn until the GM restores them (this button).</em>")] : []),
      line("<em>The GM adjudicates exact influence (L10415).</em>")
    ]);
    return true;
  }
};

export const USES_10 = Object.freeze({ shieldOfDawn, shadowStep, influence });

/** Feat automations by the abilities' names (the core finds a Use by its item's name). */
function usesByName() {
  const out = {};
  for (const spec of Object.values(R.RELICS_10)) for (const row of spec.tiers) for (const p of row.powers ?? []) if (p.uses) out[p.name] = USES_10[p.uses];
  return out;
}

/* ------------------------------------------------------------------ */
/* The Veilshroud's Veil-Drinker (TRG Prime's H28)                      */
/* ------------------------------------------------------------------ */

/** A damage reaction: essence on a wearer at Legendary is ignored and heals half. */
export async function veilDrinker(ctx = {}) {
  const target = ctx.target;
  const power = items(target).find((i) => i.flags?.[MODULE_ID]?.relicAbsorb);
  const absorb = power?.flags?.[MODULE_ID]?.relicAbsorb;
  if (!absorb) return null;
  // ASKED ONCE A CAST (TRG Prime's rule), so a spell's answer is the cast's:
  // an essence packet after a fire one is drunk too, and healed at its own
  // amount (3.693.0). Outside a spell, only an essence blow is answered.
  const spell = ctx.kind === "spell";
  if (!spell && !(ctx.types ?? []).includes(absorb.type)) return null;
  return { immune: [absorb.type], heal: Number(absorb.heal) || 0.5, scope: spell ? "cast" : "instance", line: (ctx.types ?? []).includes(absorb.type) ? `${target.name}'s Veilshroud drinks the ${absorb.type}` : "" };
}

/* ------------------------------------------------------------------ */
/* Bonding (L1828)                                                      */
/* ------------------------------------------------------------------ */

/** The relics a performer may bond to a wielder: carried by either, not bonded to the wielder. */
function bondable(performer, wielder) {
  const pool = [...items(wielder), ...(performer !== wielder ? items(performer) : [])];
  return pool.filter((i) => isRelic(i) && R.relicRecord(i, MODULE_ID).wielderUuid !== wielder.uuid);
}

/** The action's DC (Q211): asks which relic, checks its refusals and the cost, records the plan. */
export async function resolveBondingDC({ actor, targetActor } = {}) {
  const wielder = targetActor ?? actor;
  const relics = bondable(actor, wielder);
  if (!relics.length) return { refused: `no unbonded relic is carried by ${wielder.name}${wielder === actor ? "" : ` or ${actor.name}`}` };
  let relic = relics[0];
  if (relics.length > 1) {
    const pick = await h().chooseFromList("Relic Bonding Ritual", `Which relic is bonded to ${esc(wielder.name)}?`, relics.map((i) => [i.uuid, i.name]));
    relic = relics.find((i) => i.uuid === pick);
    if (!relic) return { refused: "no relic chosen" };
  }
  // THE PERFORMER WRITES THE BOND (found in review): a relic on a character
  // this player does not own cannot be marked from here, so it is refused
  // before anything is paid. The priest holds the relic for the ritual, then
  // hands it to the champion.
  if (!relic.isOwner) return { refused: `${relic.name} is carried by ${relic.parent?.name ?? "someone else"}: the performer holds it during the ritual (hand it over afterwards), or its owner or the GM rolls` };
  const why = R.bondingRefusal(relic, { wielderAligned: await alignedOf(wielder), now: now(), moduleId: MODULE_ID });
  if (why) return { refused: `${relic.name}: ${why}` };
  const spec = R.relicSpecOf(relic, MODULE_ID);
  if (spec?.sacrifice) {
    const ok = await foundry.applications.api.DialogV2.confirm({ window: { title: `${relic.name} — its requirement` }, content: `<p>${esc(relic.name)}: "Bonding requires the Relic Bonding Ritual performed with a blood sacrifice or the extinguishing of a living soul." Is it made?</p>` });
    if (!ok) return { refused: `${relic.name} demands its sacrifice` };
  }
  const pp = int(actor.system?.resources?.pp?.value);
  if (pp < R.BONDING_COST.pp) return { refused: `it costs ${R.BONDING_COST.pp} PP, and ${actor.name} has ${pp}` };
  const gold = Number(await h().goldOf(actor)) || 0;
  if (gold < R.BONDING_COST.gp) return { refused: `it costs ${R.BONDING_COST.gp} gp of incense, herbs and oils, and ${actor.name} has ${gold} gp` };
  await actor.setFlag(MODULE_ID, BOND_PLAN, { relicUuid: relic.uuid, wielderUuid: wielder.uuid, wielderName: wielder.name, wielderLevel: levelOf(wielder) });
  return { dc: h().levelDC(levelOf(wielder)), label: `Level DC (${wielder.name}, level ${levelOf(wielder)})` };
}

/** trgPrimeActionResolved: the Relic Bonding Ritual's degree (Q211, Q212). */
export async function onActionResolvedB10(ctx = {}) {
  if (ctx.action?.key !== "relicBondingRitual" || !ctx.actor?.isOwner) return;
  const actor = ctx.actor;
  const plan = actor.getFlag?.(MODULE_ID, BOND_PLAN);
  if (!plan) return;
  await actor.unsetFlag(MODULE_ID, BOND_PLAN);
  const relic = await fromUuid(plan.relicUuid);
  if (!relic) return;
  // THE COST, PAID BY THE PERFORMER (Q212), whatever the degree: the incense is burnt.
  await actor.update({ "system.resources.pp.value": Math.max(0, int(actor.system?.resources?.pp?.value) - R.BONDING_COST.pp) });
  await h().deductGold(actor, R.BONDING_COST.gp);
  const degree = R.bondingDegree(ctx.resolvedDegree ?? ctx.degree);
  const r = R.relicRecord(relic, MODULE_ID);
  const lines = [line(`${esc(actor.name)} pays ${R.BONDING_COST.pp} PP and ${R.BONDING_COST.gp} gp of incense, herbs and oils.`)];
  if (degree === "critical" || degree === "success") {
    const cap = R.tierForLevel(plan.wielderLevel);
    const awakened = degree === "critical" ? Math.min(1, cap) : 0;
    await relic.setFlag(MODULE_ID, "relic", { ...r, wielderUuid: plan.wielderUuid, wielderName: plan.wielderName, awakened, investedTier: null, refusedUntil: 0 });
    lines.push(line(`<strong>${esc(relic.name)}</strong> bonds with <strong>${esc(plan.wielderName)}</strong>${degree === "critical" && awakened > 0 ? `, and awakens at once to <strong>${R.TIERS[awakened].label}</strong>` : ` (${R.TIERS[awakened].label})`}. It advances one tier at each of ${esc(plan.wielderName)}'s daily preparations until it matches their level.`));
    // Its Dissonance and tier follow from this flag, on the actor holding it (onItemUpdatedB10).
  } else if (degree === "failure") {
    await relic.setFlag(MODULE_ID, "relic", { ...r, refusedUntil: now() + R.BONDING_WAIT.failure });
    lines.push(line(`${esc(relic.name)} rejects the attempt. It may not be attempted again for 24 hours.`));
  } else {
    await relic.setFlag(MODULE_ID, "relic", { ...r, refusedUntil: now() + R.BONDING_WAIT.fumble });
    const formula = R.bondingFumbleFormula(levelOf(actor));
    const hit = await h().basicSaveHit({ caster: null, target: actor, save: "fortitude", dc: h().levelDC(int(plan.wielderLevel)), label: `${relic.name} lashes out`, formula, type: "essence" });
    lines.push(line(`${esc(relic.name)} lashes out: ${formula} essence (basic Fortitude, DC ${h().levelDC(int(plan.wielderLevel))}). ${esc(hit?.line ?? "")} It refuses further attempts for 1 week.`));
  }
  await card(actor, "Relic Bonding Ritual", lines);
}

/* ------------------------------------------------------------------ */
/* Hooks                                                                */
/* ------------------------------------------------------------------ */

/** trgPrimeDailyPreparation: each bonded relic awakens a tier, and its invested tier rises to what the slots pay for (M98 (a)). */
export async function onDailyPreparationB10({ actor } = {}) {
  // THE CLIENT THAT PREPARED (found in review): TRG Prime fires this hook only
  // there, so it is not passed to the elected owner — a GM preparing an online
  // player's character must do the awakening itself.
  if (!actor?.isOwner) return;
  // The day's uses are back: what the grants had left is forgotten.
  for (const item of items(actor).filter((i) => isRelic(i) || isSentient(i))) if (item.flags?.[MODULE_ID]?.[KEPT_USES]) await item.unsetFlag(MODULE_ID, KEPT_USES); // setFlag would merge, not clear (found in review)
  const lines = [];
  for (const item of items(actor).filter(isRelic)) {
    const r = R.relicRecord(item, MODULE_ID);
    if (r.wielderUuid !== actor.uuid) continue;
    const awakened = R.awakenedAfterDay(r.awakened, levelOf(actor));
    let investedTier = r.investedTier;
    if (item.system?.invested) {
      const { investedSlotsOf } = await core("module/magic-items-workflow.mjs");
      const free = int(actor.system?.magic?.investmentSlots) - int(await investedSlotsOf(actor, { except: item }));
      // "OR A LOWER ONE BY CHOICE" (M98 (a); found in review): a tier chosen below what the slots paid is kept.
      if (!r.chosenBelow) investedTier = Math.max(int(r.investedTier ?? 0), R.highestAffordableTier(awakened, free));
    }
    if (awakened !== int(r.awakened) || investedTier !== r.investedTier) {
      await item.setFlag(MODULE_ID, "relic", { ...r, awakened, investedTier });
      if (awakened !== int(r.awakened)) lines.push(line(`<strong>${esc(item.name)}</strong> awakens to <strong>${R.TIERS[awakened].label}</strong>.`));
      if (item.system?.invested && investedTier !== r.investedTier) lines.push(line(`${esc(item.name)} is now invested at ${R.TIERS[investedTier].label} (${R.slotsForTier(investedTier)} slots).`));
      // The flag's own hook rewrites the tier (onItemUpdatedB10).
    }
  }
  if (lines.length) await card(actor, "Relics", lines);
}

/** updateItem: investment begun or ended, or the relic record changed. */
export async function onItemUpdatedB10(item, changed, options = {}) {
  if (options?.eaRelicSync) return;
  const actor = item?.parent;
  if (!actor || actor.documentName !== "Actor" || !actor.isOwner || !actsFor(actor)) return;
  const invest = changed?.system?.invested !== undefined;
  const flags = changed?.flags?.[MODULE_ID] ?? {};
  if (isRelic(item) && (invest || flags.relic !== undefined)) {
    // Investment ended: the tier is forgotten, and that flag's own hook syncs.
    if (invest && !item.system?.invested && R.relicRecord(item, MODULE_ID)?.investedTier !== null) return item.setFlag(MODULE_ID, "relic", { ...R.relicRecord(item, MODULE_ID), investedTier: null });
    await syncRelic(actor, item);
    if (flags.relic !== undefined) await syncDissonance(actor, item);
  }
  if (isSentient(item) && (invest || flags.sentient !== undefined)) await syncSentient(actor, item);
}

/** createItem: a relic arriving on its bonded wielder brings its Dissonance and, if invested, its tier. */
export async function onItemCreatedB10(item) {
  const actor = item?.parent;
  if (!actor || actor.documentName !== "Actor" || !actor.isOwner || !actsFor(actor)) return;
  if (isRelic(item)) {
    // A RELIC TRADED OR COPIED (found in review) arrives invested by its old
    // holder: it is not this creature's investment, so it is ended here.
    const r = R.relicRecord(item, MODULE_ID);
    if (item.system?.invested && r?.wielderUuid !== actor.uuid) { await item.update({ "system.invested": false }); return; }
    await syncDissonance(actor, item);
    if (item.system?.invested) await syncRelic(actor, item);
  }
  else if (isSentient(item) && item.system?.invested) await syncSentient(actor, item);
}

/** deleteItem: a relic or sentient item gone takes its grants and its Dissonance with it. */
export async function onItemDeletedB10(item) {
  const actor = item?.parent;
  if (!actor || actor.documentName !== "Actor" || !actor.isOwner || !actsFor(actor)) return;
  if (!isRelic(item) && !isSentient(item)) return;
  // After any sync already queued for this actor (found in review), which finds the relic gone and does nothing.
  return serial(actor, () => clearGrants(actor, item));
}
async function clearGrants(actor, item) {
  const grants = items(actor).filter((i) => i.flags?.[MODULE_ID]?.[GRANT_FLAG] === item.id).map((i) => i.id);
  if (grants.length) await actor.deleteEmbeddedDocuments("Item", grants);
  const dis = Array.from(actor.effects ?? []).filter((e) => e.flags?.[MODULE_ID]?.itemId === item.id && e.flags?.[MODULE_ID]?.source === DISSONANCE_SOURCE).map((e) => e.id);
  if (dis.length) await actor.deleteEmbeddedDocuments("ActiveEffect", dis);
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export function registerBlock10(api, moduleId) {
  api.registerOneInvestedTraits?.(["relic", "sentient"], moduleId);
  api.registerInvestCost?.("eaRelicSentient", relicInvestCost, moduleId);
  api.registerInvestRefusal?.("eaRelic", relicInvestRefusal, moduleId);
  api.registerInvestPrepare?.("eaRelic", relicInvestPrepare, moduleId);
  api.registerDamageReaction?.("eaVeilDrinker", veilDrinker, moduleId);
  for (const [name, spec] of Object.entries(usesByName())) api.registerFeatAutomation?.(name, spec, moduleId);
}

/** An Influence ability's Use, by name (each sentient item's own). */
export function registerInfluenceFor(api, names, moduleId) {
  for (const n of names) api.registerFeatAutomation?.(n, influence, moduleId);
}
