/**
 * Eldritch Arts Block 9a (0.13.0, on TRG Prime 3.688.0): the catalysts, the
 * four catalyst feats and the special materials — the Foundry half. The rules
 * are in block9a-rules.mjs.
 *
 *   - CATALYSTS: one cast item kind (TRG Prime's H19, `registerCastItemOption`):
 *     offered at the cast, folded into it, settled with its backlash, Catalyst
 *     Conservation's flat check and Catalyst Affinity's and Catalyst Mastery's
 *     changes. A ritual's primary is offered them too, before the ritual check
 *     (0.13.1, TRG Prime 3.688.1; Graham, 13 November 2026), Blood-etched
 *     Vellum ("+2 to Spellcraft checks for ritual casting") among them, and
 *     only there.
 *   - MATERIALS: the ten, registered (TRG Prime's H20, `registerMaterial`).
 *     Bloodglass shatters when its item is destroyed; Sunbronze shields shed
 *     dim light.
 */
import { MODULE_ID, effectData, forSeconds, expiryFor, ownEffects } from "./effects-clock.mjs";
import { int, esc, h, line, card, levelOf, owned, tokenOf, feetBetween, inCombat } from "./block1-automations.mjs";
import { isActingGM } from "./writer.mjs";
import { actsFor } from "./block3-automations.mjs";
import * as R from "./block9a-rules.mjs";

const lower = (v) => String(v ?? "").trim().toLowerCase();

/** The catalyst key an item carries (module flag), or null. */
export function catalystKeyOf(item) {
  if (!item || item.type !== "consumable") return null;
  const key = item.getFlag?.(MODULE_ID, R.CATALYST_FLAG) ?? item.flags?.[MODULE_ID]?.[R.CATALYST_FLAG] ?? null;
  return key && R.CATALYSTS[key] ? key : null;
}

/** The caster's catalysts with one left: [{ item, key, spec }]. */
export function catalystsOf(actor) {
  return Array.from(actor?.items ?? [])
    .map((item) => ({ item, key: catalystKeyOf(item) }))
    .filter((c) => c.key && Number(c.item.system?.quantity ?? 1) > 0)
    .map((c) => ({ ...c, spec: R.CATALYSTS[c.key] }));
}

const FEET = /(\d+(?:\.\d+)?)\s*[-\s]?\s*(foot|feet|ft\.?|’|')/i;
const TIME = /(\d+)\s*(round|minute|hour|day|week)s?/i;

/** The cast's facts, widened with what the catalysts read and TRG Prime does not hand over. */
function castFacts(ctx) {
  const actor = ctx?.actor ?? null;
  const sd = ctx?.spellData ?? {};
  return {
    ...ctx,
    inCombat: Boolean(actor && inCombat(actor)),
    rangeScales: FEET.test(String(sd.range ?? "")),
    // A ritual claiming "Duration unaltered" (−10 DC) may not then stretch it (review, 0.13.1).
    durationScales: TIME.test(String(sd.duration ?? "")) && !ctx?.durationUnaltered
  };
}

/** A short hint for the prompt: what it would do on this cast. */
function hintOf(spec, facts) {
  try { return String(spec.answer({ ...facts, choice: "range" })?.lines?.[0] ?? "").replace(/<[^>]*>/g, ""); } catch { return ""; }
}

/* ------------------------------------------------------------------ */
/* The cast item (H19)                                                  */
/* ------------------------------------------------------------------ */

export async function catalystOffers(ctx = {}) {
  const facts = castFacts(ctx);
  const out = [];
  // EMBEDDED IN A CATALYST-RUNED SHIELD (0.14.0, Block 9b; Graham's Q192): each
  // offered once a day while the shield is wielded, not consumed.
  {
    const { embeddedCatalystOffers } = await import("./block9b-automations.mjs");
    out.push(...embeddedCatalystOffers(ctx.actor, (key) => {
      const spec = R.CATALYSTS[key];
      if (!spec || (spec.ritualOnly && !ctx.ritual)) return false;
      if (!R.catalystFitsCheck(key, facts)) return false;
      return Boolean(spec.applies(facts));
    }));
  }
  for (const c of catalystsOf(ctx.actor)) {
    // Blood-etched Vellum is the ritual's (TRG Prime 3.688.1 asks a ritual's primary too).
    if (c.spec.ritualOnly && !ctx.ritual) continue;
    // NOT A SPELLCRAFT-ONLY CATALYST WHEN THE RITUAL ROLLS A SKILL (0.16.0;
    // Graham, 15 November 2026): Chapter 7's mundane ritual is checked with
    // Arcana, Nature, Occultism or Religion, not Spellcraft.
    if (!R.catalystFitsCheck(c.key, facts)) continue;
    let applies = false;
    try { applies = Boolean(c.spec.applies(facts)); } catch { applies = false; }
    if (applies) out.push({ itemId: c.item.id, label: c.item.name, hint: c.spec.choice ? "Range or duration ×1.5 (choose when used)." : hintOf(c.spec, facts) });
  }
  return out;
}

async function askStarpetal(facts) {
  if (facts.rangeScales && !facts.durationScales) return "range";
  if (facts.durationScales && !facts.rangeScales) return "duration";
  const DialogV2 = foundry.applications.api.DialogV2;
  const picked = await DialogV2.wait({
    window: { title: "Starpetal Oil — range or duration" },
    classes: ["trg-prime"],
    content: `<div class="trg-prime trg-check-dialog"><p>Starpetal Oil extends a spell's range or duration by 50% (choose when used).</p></div>`,
    buttons: [{ action: "range", label: `Range (${esc(facts.spellData?.range ?? "")})`, default: true }, { action: "duration", label: `Duration (${esc(facts.spellData?.duration ?? "")})` }],
    rejectClose: false
  });
  return picked === "duration" ? "duration" : picked === "range" ? "range" : null;
}

export async function catalystApply(ctx = {}) {
  const { embeddedKey } = ctx.offer?.slot !== undefined ? await import("./block9b-automations.mjs") : {};
  const key = ctx.offer?.slot !== undefined ? embeddedKey(ctx.item, ctx.offer.slot) : catalystKeyOf(ctx.item);
  const spec = key ? R.CATALYSTS[key] : null;
  if (!spec) return { cancel: true, reason: "that item is not a catalyst" };
  const facts = castFacts(ctx);
  if (spec.choice) {
    const choice = await askStarpetal(facts);
    if (!choice) return { cancel: true, reason: "Starpetal Oil needs a choice of range or duration" };
    facts.choice = choice;
  }
  return spec.answer(facts) ?? {};
}

/** Catalyst Conservation's DC 15 flat check: kept on a 15 or better (never on a Fumble or Blunder). */
async function conservation(actor, degree, lines) {
  if (!owned(actor, "Catalyst Conservation", ["feat"])) return false;
  if (["fumble", "blunder"].includes(lower(degree))) {
    lines.push("Catalyst Conservation: a Fumble or Blunder always consumes the catalyst.");
    return false;
  }
  const roll = await new Roll("1d20").evaluate();
  const keeps = R.conservationKeeps(roll.total, degree);
  lines.push(`Catalyst Conservation: DC 15 flat check — <strong>${roll.total}</strong>, ${keeps ? "the catalyst is not consumed" : "it is consumed"}.`);
  return keeps;
}

export async function catalystSettle(ctx = {}) {
  const actor = ctx.actor;
  const slot = ctx.offer?.slot;
  const embedded = slot !== undefined ? await import("./block9b-automations.mjs") : null;
  const key = embedded ? embedded.embeddedKey(ctx.item ?? actor?.items?.get?.(ctx.offer?.itemId), slot) : (catalystKeyOf(ctx.item) ?? catalystKeyOf(actor?.items?.get?.(ctx.offer?.itemId)));
  const spec = key ? R.CATALYSTS[key] : null;
  const lines = [];
  if (!spec || !actor) return { lines };
  // WHAT IT DOES ON THE CASTER, ONCE THE CAST HAS SETTLED.
  if (spec.castEffect && ctx.cast) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("frozenMarrow9a", {
      name: spec.castEffect.label, img: "icons/svg/ice-aura.svg",
      changes: [{ key: "system.combat.dr.other", type: "custom", value: String(spec.castEffect.dr), priority: 20 }],
      expiry: expiryFor("endOfNextTurn", actor)
    })]);
    lines.push(`${esc(actor.name)} gains +${spec.castEffect.dr} DR until the end of their next turn.`);
  }
  if (spec.castAP && inCombat(actor)) {
    const ap = int(actor.system?.resources?.ap?.value);
    await actor.update({ "system.resources.ap.value": ap + spec.castAP });
    lines.push(`Sands of the Hourglass: +${spec.castAP} AP this turn (${ap} → ${ap + spec.castAP}).`);
  }
  // THE BACKLASH.
  const mastery = Boolean(owned(actor, "Catalyst Mastery", ["feat"]));
  if (R.backlashDue(spec, ctx.degree, { mastery })) {
    lines.push(...await applyBacklash(actor, spec, ctx));
  } else if (["failure", "fumble", "blunder"].includes(lower(ctx.degree))) {
    lines.push(spec.onFumbleOnly && lower(ctx.degree) === "failure"
      ? `${spec.name}: no backlash on a Failure (only a Fumble or Blunder, M10).`
      : `${spec.name}: Catalyst Mastery — no backlash on a Failure.`);
  }
  // AN EMBEDDED CATALYST IS NOT EXPENDED (Q192): its day is marked; Catalyst
  // Conservation does not apply to it.
  if (embedded) {
    const shield = ctx.item ?? actor?.items?.get?.(ctx.offer?.itemId);
    if (shield) await embedded.markEmbeddedUsed(shield, slot);
    lines.push(`${esc(spec.name)} stays embedded in ${esc(shield?.name ?? "the shield")}: used for today.`);
    return { keep: true, lines };
  }
  let keep = await conservation(actor, ctx.degree, lines);
  // THE ROD OF THE CATALYST FLOW (0.15.0, Block 9c; Q209): offered only once
  // Catalyst Conservation has not kept it, on any degree.
  if (!keep) {
    const { catalystFlowKeeps } = await import("./block9c-automations.mjs");
    keep = await catalystFlowKeeps(actor, spec.name, lines);
  }
  return { keep, lines };
}

/** Roll "1d4×PP"-style durations, "1d6", or a number. */
async function roundsOf(spec, ctx) {
  if (typeof spec === "number") return spec;
  const s = String(spec ?? "");
  const per = /^(\d+d\d+)×PP$/i.exec(s);
  const count = per ? R.castPPOf(ctx) : 1;
  const dice = per ? per[1] : s;
  if (!/^\d+d\d+$/i.test(dice)) return int(dice);
  let total = 0;
  for (let i = 0; i < Math.max(1, count); i += 1) total += (await new Roll(dice).evaluate()).total;
  return count > 0 ? total : 0;
}

/**
 * Apply a catalyst's backlash to its caster, with Catalyst Affinity's
 * reductions (Q191). Exported for Blood-etched Vellum and the harness.
 */
export async function applyBacklash(actor, spec, ctx = {}) {
  const lines = [`<strong>${esc(spec.name)} backlash</strong> (${esc(ctx.degree)}):`];
  const b = spec.backlash ?? {};
  const affinity = Boolean(owned(actor, "Catalyst Affinity", ["feat"]));
  const level = levelOf(actor);
  // DAMAGE: rolled per row, reduced as a total by Catalyst Affinity.
  let reduction = affinity ? 2 * Math.max(0, level) : 0;
  for (const row of b.damage ?? []) {
    const n = R.backlashDiceCount(row, ctx);
    if (n <= 0) { lines.push(`${row.type}: no dice (${R.castPPOf(ctx)} PP).`); continue; }
    const formula = `${n}${row.dice.replace(/^\d+/, "")}`;
    const rolled = (await new Roll(formula).evaluate()).total;
    const cut = Math.min(rolled, reduction);
    reduction -= cut;
    const amount = rolled - cut;
    if (amount > 0) await h().applyTypedDamage(actor, { amount, type: row.type, sourceName: `${spec.name} backlash` });
    lines.push(`${amount} ${row.type} damage (${formula} = ${rolled}${cut ? `, −${cut} Catalyst Affinity` : ""}).`);
  }
  if (b.soulDrain) {
    const value = b.soulDrain.dice
      ? (R.perTwo(ctx) > 0 ? (await new Roll(`${R.perTwo(ctx)}${b.soulDrain.dice.replace(/^\d+/, "")}`).evaluate()).total : 0)
      : (b.soulDrain.per === "pp" ? R.castPPOf(ctx) : R.perTwo(ctx));
    if (value > 0) await h().applyConditionTagsTo(actor, [{ key: "soulDrain", value }]);
    lines.push(`Soul Drain ${value}.`);
  }
  if (b.bleeding) {
    // Bleeding is HP damage too (Q191): Catalyst Affinity's cut is taken from it.
    const rolled = R.vellumBleeding(R.castPPOf(ctx));
    const cut = Math.min(rolled, reduction);
    reduction -= cut;
    const value = rolled - cut;
    if (value > 0) await h().applyConditionTagsTo(actor, [{ key: "bleeding", value }]);
    lines.push(`Bleeding ${value} (Q202: the PP as cast, at most 10${cut ? `; −${cut} Catalyst Affinity` : ""}).`);
  }
  if (b.recurring) {
    // Recurring damage is HP damage (Q191): Catalyst Affinity's cut is taken from it.
    const rolled = (await new Roll(b.recurring.dice).evaluate()).total;
    const cut = Math.min(rolled, reduction);
    reduction -= cut;
    const amount = rolled - cut;
    if (amount > 0) await h().addRecurringDamage(actor, amount, b.recurring.type);
    lines.push(`Recurring ${b.recurring.type} damage ${amount} (${b.recurring.dice} = ${rolled}${cut ? `, −${cut} Catalyst Affinity` : ""}).`);
  }
  const together = {};
  const fighting = inCombat(actor);
  const worldNow = Math.trunc(Number(globalThis.game?.time?.worldTime ?? 0));
  for (const raw of b.conditions ?? []) {
    const cond = affinity ? R.affinityCondition(raw) : raw;
    let clock = {};
    let said = "";
    if (cond.rounds !== undefined) {
      let rounds = raw.together && together[raw.together] !== undefined ? together[raw.together] : await roundsOf(cond.rounds, ctx);
      if (raw.together) together[raw.together] = rounds;
      const before = rounds;
      if (affinity) rounds = R.affinityRounds(rounds);
      // SLOWED BITES AT THE START OF A TURN (its AP lost as the turn's AP
      // come back), and a condition's round clock is swept at that same turn
      // start, before the AP (review): a Slowed of N rounds runs one round
      // further on the clock, so it takes its AP N times.
      const bite = cond.key === "slowed" ? 1 : 0;
      clock = { expiresTime: worldNow + 6 * (rounds + bite), ...(fighting ? { expiresRound: int(globalThis.game.combat.round) + rounds + bite } : {}) };
      said = ` for ${rounds} round${rounds === 1 ? "" : "s"}${affinity && before !== rounds ? ` (${before} − 1, Catalyst Affinity)` : ""}`;
    } else if (cond.minutes !== undefined) {
      const minutes = typeof cond.minutes === "number" ? cond.minutes : (await new Roll(String(cond.minutes)).evaluate()).total;
      clock = { expiresTime: worldNow + 60 * minutes };
      said = ` for ${minutes} minute${minutes === 1 ? "" : "s"}`;
    } else if (cond.endOfNextTurn) {
      clock = fighting ? { expiresRound: int(globalThis.game.combat.round) + 2 } : { expiresTime: worldNow + 6 };
      said = " until the end of their next turn";
    }
    const tag = { key: cond.key, label: cond.key, ...(cond.value ? { value: cond.value } : {}), ...clock };
    await h().applyConditionTagsTo(actor, [tag]);
    lines.push(`${cond.key}${cond.value ? ` ${cond.value}` : ""}${said}${affinity && raw.value !== cond.value ? ` (Stunned ${raw.value} − 1, Catalyst Affinity)` : ""}.`);
  }
  for (const eff of b.effects ?? []) {
    let seconds = eff.seconds;
    let said = "";
    if (eff.rounds !== undefined) {
      let rounds = eff.together && together[eff.together] !== undefined ? together[eff.together] : await roundsOf(eff.rounds, ctx);
      if (eff.together) together[eff.together] = rounds;
      // Catalyst Affinity: a duration in rounds loses 1, minimum 1 (Q191) — as the condition it shares a roll with.
      if (affinity) rounds = R.affinityRounds(rounds);
      seconds = 6 * rounds;
      said = ` for ${rounds} round${rounds === 1 ? "" : "s"}`;
    } else said = seconds >= 3600 ? ` for ${seconds / 3600} hour` : ` for ${seconds / 60} minute${seconds === 60 ? "" : "s"}`;
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(`catalystBacklash9a`, {
      name: eff.label, img: "icons/svg/downgrade.svg",
      system: { conditionals: [{ ...eff.conditional }] },
      expiry: forSeconds(seconds)
    })]);
    lines.push(`${esc(eff.label)}${said}.`);
  }
  if (b.card) lines.push(`<em>${esc(b.card)}</em>`);
  return lines;
}

export const CATALYST_ITEM_OPTION = Object.freeze({ label: "Catalyst", offers: catalystOffers, apply: catalystApply, settle: catalystSettle });

/* ------------------------------------------------------------------ */
/* The materials (H20)                                                  */
/* ------------------------------------------------------------------ */

/** "Sheds dim light in a 10-foot radius": a candle's step (+1, to Dim Light at most), magical; drawn with no bright ring (found live, 0.13.0: it drew bright 5). */
export const SUNBRONZE_LIGHT = Object.freeze({ key: "sunbronzeShield", label: "Sunbronze Shield", item: "Sunbronze Shield", steps: 1, cap: 5, magical: true, radiusFeet: 10, dimFeet: 10, brightFeet: 0 });

const materialKeyOf = (item) => String(item?.system?.material ?? "").trim();

const SHATTERED_FLAG = "shattered9a";

/** Hooks.on("updateItem"): a Bloodglass item destroyed shatters, once. */
export async function onItemUpdatedB9a(item, change = {}) {
  if (!isActingGM()) return;
  if (materialKeyOf(item) !== "bloodglass") return;
  const hp = change?.system?.hp?.value;
  if (hp === undefined) return;
  const actor = item.parent;
  if (!actor) return;
  // "WHEN DESTROYED" (review): not at 0 HP, which is broken, but at a negative
  // value of half its HP — once. A repaired item may shatter again.
  const destroyed = R.itemDestroyed(hp, item.system?.hp?.max);
  const shattered = Boolean(item.getFlag?.(MODULE_ID, SHATTERED_FLAG));
  if (!destroyed) { if (shattered) await item.unsetFlag?.(MODULE_ID, SHATTERED_FLAG); return; }
  if (shattered) return;
  await item.setFlag?.(MODULE_ID, SHATTERED_FLAG, true);
  const levelOfItem = int(item.system?.itemLevel ?? item.system?.level ?? 0);
  const dice = R.shatterDice(levelOfItem);
  if (!dice) return;
  const token = tokenOf(actor);
  const near = token ? Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t.actor && feetBetween(token, t) <= R.MATERIALS_9A.bloodglass.shatter.feet) : [];
  const dc = await h().levelDC(levelOfItem);
  const lines = [`<strong>${esc(item.name)} shatters</strong> (Bloodglass): ${dice} piercing to every creature within 5 feet, basic Reflex at the item's Level DC ${dc} (Q194).`];
  const amount = (await new Roll(dice).evaluate()).total;
  for (const t of near) {
    const res = await h().basicSaveHit({ caster: actor, target: t.actor, save: "reflex", dc, label: `${item.name} shatters`, amount, type: "piercing" });
    if (res?.line) lines.push(res.line);
  }
  if (!near.length) lines.push("<em>No token on the scene: the GM applies it.</em>");
  await card(actor, `${item.name} — Bloodglass`, lines.map((t) => line(t)));
}

/** A Sunbronze shield held lights its bearer (one client: the owner). */
const syncing = new Set();
export async function syncSunbronzeLight(actor) {
  if (!actor?.isOwner || !actsFor(actor)) return;
  // One at a time per actor (review): two updates in quick succession made two lights.
  const id = actor.uuid ?? actor.id;
  if (syncing.has(id)) return;
  syncing.add(id);
  try { await syncSunbronze(actor); } finally { syncing.delete(id); }
}
async function syncSunbronze(actor) {
  const wants = Array.from(actor.items ?? []).some((i) => i.type === "shield" && i.system?.equipped && materialKeyOf(i) === "sunbronze" && Number(i.system?.hp?.value ?? 1) > 0);
  const have = ownEffects(actor, "sunbronze9a");
  if (wants && !have.length) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("sunbronze9a", { name: "Sunbronze Shield: dim light (10 ft.)", img: "icons/svg/sun.svg", system: { lightSource: SUNBRONZE_LIGHT.key } })]);
  } else if (!wants && have.length) {
    await actor.deleteEmbeddedDocuments("ActiveEffect", have.map((e) => e.id));
  } else return;
  await h().refreshTokenLight?.(actor);
}

const isShield = (item) => item?.type === "shield" && item?.parent?.documentName === "Actor";

/** Hooks.on("createItem" | "deleteItem"): a Sunbronze shield arriving or leaving. */
export async function onItemAddedOrRemovedB9a(item) {
  if (!isShield(item) || (materialKeyOf(item) !== "sunbronze" && !ownEffects(item.parent, "sunbronze9a").length)) return;
  await syncSunbronzeLight(item.parent);
}

/** Hooks.on("updateItem"): Bloodglass shatters (acting GM); a shield's light follows its grip and material. */
export async function onItemChangedB9a(item, change = {}) {
  await onItemUpdatedB9a(item, change);
  if (isShield(item)) {
    const actor = item.parent;
    const lit = ownEffects(actor, "sunbronze9a").length > 0;
    if (lit || materialKeyOf(item) === "sunbronze") await syncSunbronzeLight(actor);
  }
}

/** Hooks.once("ready"): every Sunbronze shield this client acts for. */
export async function onReadyB9a() {
  for (const actor of Array.from(globalThis.game?.actors ?? [])) {
    if (!actor?.isOwner || !actsFor(actor)) continue;
    const held = Array.from(actor.items ?? []).some((i) => i.type === "shield" && materialKeyOf(i) === "sunbronze");
    if (held || ownEffects(actor, "sunbronze9a").length) await syncSunbronzeLight(actor);
  }
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export function registerBlock9a(api, moduleId) {
  api.registerCastItemOption?.("catalyst", { ...CATALYST_ITEM_OPTION }, moduleId);
  for (const key of Object.keys(R.MATERIALS_9A)) api.registerMaterial?.(key, R.materialRegistration(key), moduleId);
  api.registerLightSources?.([{ ...SUNBRONZE_LIGHT }], moduleId);
}
