/**
 * WHICH CLIENT WRITES (0.12.0, on TRG Prime 3.686.2+).
 *
 * TRG Prime 3.686.1 elects one writer per GM account: with the same GM open in
 * two tabs, both are "the active GM" (one user), and a world-changing hook ran
 * twice. The core's own writers ask its election (`isGMConnectionWriter`,
 * module/gm-connection.mjs); this module's ask it here, through the core's own
 * file, so there is one election and not two.
 *
 *   isActingGM()          automatic work a hook, a socket or the clock does:
 *                         the active GM's account AND its elected connection.
 *   isActiveGMAccount()   a GM answering a card (a button pressed): any tab of
 *                         the active GM's account — the GM pressed it there.
 *
 * Before the core has an election (3.686.0 and earlier), or in a harness with
 * no core loaded, `isActingGM` is the account test alone, as it was.
 */
let electionWriter = null;

/** For the harness, and for `loadCoreElection`. */
export function setCoreElection(fn) { electionWriter = typeof fn === "function" ? fn : null; }

/** The core's election, read from its own module (the same file, so the same instance). */
export async function loadCoreElection() {
  try {
    const path = "systems/trg-prime/module/gm-connection.mjs";
    const route = globalThis.foundry?.utils?.getRoute?.(path) ?? `/${path}`;
    const mod = await import(route);
    if (typeof mod?.isGMConnectionWriter === "function") setCoreElection(mod.isGMConnectionWriter);
  } catch (err) {
    console.warn("Eldritch Arts | TRG Prime's connection election could not be read; one writer per GM user, as before", err);
  }
}

/** Any tab of the active GM's account (a button a GM pressed). */
export function isActiveGMAccount() {
  const game = globalThis.game;
  if (!game?.user?.isGM) return false;
  const active = game.users?.activeGM;
  return !active || active === game.user || active.id === game.user.id;
}

/** The one client that does automatic world-changing work. */
export function isActingGM() {
  if (!isActiveGMAccount()) return false;
  try { return electionWriter ? electionWriter() !== false : true; } catch { return true; }
}
