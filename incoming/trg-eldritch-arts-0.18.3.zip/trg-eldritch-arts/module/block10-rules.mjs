/**
 * Eldritch Arts Block 10 (0.17.0) — the rules of relics and sentient items,
 * pure. The Foundry half is module/block10-automations.mjs; the items are
 * tools/content/block10.mjs.
 *
 * GRAHAM'S ANSWERS, 15 November 2026 ("Go with your recommendations"):
 *   Q211  the bonding check: the performer's trained Arcana, Nature,
 *         Occultism or Religion against the Level DC of the WIELDER's level;
 *         Partial reads as Failure, Blunder as Fumble; the Fumble's 1d6 per
 *         level is the performer's level, basic Fortitude at the same DC
 *   Q212  the performer pays the 1 PP and the 250 gp
 *   Q213  a relic's level is its wielder's (the core reads an item with no
 *         level as its wielder's for an innate spell's DC and attack)
 *   Q214  the Aegis's 10-ft aura includes you, as Shield of Dawn now says
 *   Q215  a relic's statistics follow the tier it is invested at;
 *         uninvested it is the plain Dormant item with no powers
 *   Q216  the Veilshroud's first Legendary bullet is the general rule for a
 *         sentient relic (its tier slots only); at Legendary the cloak is
 *         semi-sentient: communication only, no Ego
 *   Q217  the Codex's "+2 HP per level" is the undead's level; both of its
 *         undead lines reach undead you create or bind and control
 *   Q218  Influence is rolled only when the GM presses the item's button
 *   Q219  the Senses table is rolled as d8
 *   Q220  Dissonance holds while the Codex is bonded, invested or not
 *   Q221  the rules journal ships with Block 10b
 */

const int = (v) => Math.trunc(Number(v) || 0);
const norm = (v) => String(v ?? "").trim().toLowerCase();

/* ------------------------------------------------------------------ */
/* Tiers and investment                                                 */
/* ------------------------------------------------------------------ */

/** RELIC TIERS (L10081) and RELIC INVESTMENT (L10134): one slot per tier. */
export const TIERS = Object.freeze([
  Object.freeze({ key: "dormant", label: "Dormant", from: 1, to: 4, slots: 1 }),
  Object.freeze({ key: "awakened", label: "Awakened", from: 5, to: 8, slots: 2 }),
  Object.freeze({ key: "empowered", label: "Empowered", from: 9, to: 12, slots: 3 }),
  Object.freeze({ key: "transcendent", label: "Transcendent", from: 13, to: 16, slots: 4 }),
  Object.freeze({ key: "legendary", label: "Legendary", from: 17, to: 20, slots: 5 })
]);

/** The tier (0–4) a wielder's level reaches. */
export function tierForLevel(level) {
  const l = Math.max(1, int(level));
  const i = TIERS.findIndex((t) => l >= t.from && l <= t.to);
  return i < 0 ? TIERS.length - 1 : i;
}

/** The slots a tier takes (0–4 → 1–5). */
export const slotsForTier = (tier) => int(tier) + 1;

/**
 * THE DAILY AWAKENING (L1852): "After bonding, the Relic advances one tier at
 * each daily preparation until its tier matches the wielder's level." Never
 * past the level's tier, never backwards.
 */
export function awakenedAfterDay(awakened, level) {
  const cap = tierForLevel(level);
  const now = Math.max(0, int(awakened));
  return now >= cap ? now : now + 1;
}

/**
 * THE TIER IT IS INVESTED AT (M98 (a), L10077): "the highest tier whose slot
 * cost you can pay; you may voluntarily invest it at a lower tier". -1 when
 * not even the Dormant tier fits.
 */
export function highestAffordableTier(awakened, free) {
  return Math.min(Math.max(0, int(awakened)), int(free) - 1);
}

/** The relic record on an item's flags, or null. */
export function relicRecord(item, moduleId = "trg-eldritch-arts") {
  return item?.flags?.[moduleId]?.relic ?? null;
}
/** The sentient record on an item's flags, or null. */
export function sentientRecord(item, moduleId = "trg-eldritch-arts") {
  return item?.flags?.[moduleId]?.sentient ?? null;
}

/**
 * AN ITEM'S INVESTMENT COST (H27). A relic: its invested tier's slots (a
 * sentient relic too — the Veilshroud's printed rule, Q216). A sentient item:
 * two (L10441). Anything else: no answer.
 */
export function investCostOf(item, moduleId = "trg-eldritch-arts") {
  const relic = relicRecord(item, moduleId);
  if (relic) {
    const t = relic.investedTier;
    return t === null || t === undefined || int(t) < 0 ? slotsForTier(0) : slotsForTier(t);
  }
  if (sentientRecord(item, moduleId)) return 2;
  return null;
}

/** The tier a relic's powers are at now: its invested tier, or -1. */
export function activeTier(item, moduleId = "trg-eldritch-arts") {
  const r = relicRecord(item, moduleId);
  if (!r || !item?.system?.invested || !r.wielderUuid) return -1;
  // Only its bonded wielder's investment counts (found in review: a traded copy keeps the old record).
  if (item?.parent?.uuid && item.parent.uuid !== r.wielderUuid) return -1;
  const t = int(r.investedTier ?? -1);
  return t < 0 ? -1 : Math.min(t, Math.max(0, int(r.awakened)));
}

/* ------------------------------------------------------------------ */
/* Bonding (L1828)                                                      */
/* ------------------------------------------------------------------ */

export const BONDING_COST = Object.freeze({ pp: 1, gp: 250 });
export const BONDING_SKILLS = Object.freeze(["arcana", "nature", "occultism", "religion"]);
/** Retry waits, in seconds: a Failure 24 hours, a Fumble a week. */
export const BONDING_WAIT = Object.freeze({ failure: 86400, fumble: 7 * 86400 });

/** The ladder as ruled (Q211): Partial reads Failure, Blunder Fumble, Heroic Critical. */
export function bondingDegree(degree) {
  const d = norm(degree);
  if (d === "heroic" || d === "critical") return "critical";
  if (d === "success") return "success";
  if (d === "fumble" || d === "blunder") return "fumble";
  // Partial, Failure, and anything unrecognised (found in review: never a Fumble's damage by default).
  return "failure";
}

/** The Fumble's damage (Q211): 1d6 per level of the performer. */
export const bondingFumbleFormula = (level) => `${Math.max(1, int(level))}d6`;

/** Why a relic may not be bonded to this wielder now, or "". */
export function bondingRefusal(item, { wielderAligned = [], now = 0, moduleId = "trg-eldritch-arts" } = {}) {
  const r = relicRecord(item, moduleId);
  if (!r) return "it is not a relic";
  const until = Number(r.refusedUntil ?? 0);
  if (until > now) return `it refuses another attempt for ${Math.ceil((until - now) / 3600)} more hour(s)`;
  const spec = relicSpecByKey(r.key);
  const aligned = (wielderAligned ?? []).map(norm);
  if (spec?.forbiddenAligned?.some((a) => aligned.includes(a))) return `it cannot be bonded by a ${spec.forbiddenAligned.map((a) => a[0].toUpperCase() + a.slice(1)).join(" or ")}-aligned character`;
  return "";
}

/** The Codex's Dissonance (L10282; Q220): Balance or Order, while bonded. */
export function suffersDissonance(key, wielderAligned = []) {
  const spec = relicSpecByKey(key);
  const aligned = (wielderAligned ?? []).map(norm);
  return Boolean(spec?.dissonance?.some((a) => aligned.includes(a)));
}

/* ------------------------------------------------------------------ */
/* The four relics                                                      */
/* ------------------------------------------------------------------ */

const cond = (o) => Object.freeze({ auto: true, ...o });
const RESIST = (type) => Object.freeze({ key: "system.combat.resistances", type: "add", value: `, ${type}`, priority: 20 });
const IMMUNE = (type) => Object.freeze({ key: "system.combat.immunities", type: "add", value: `, ${type}`, priority: 20 });
const DARKVISION = Object.freeze({ sense: { category: "primary", special: true, modality: "visual", modalityFrom: "a form of sight; the chapter gives it a light-level step" }, light: { raisesLevelBy: 2 } });
const PERFECT_DARKVISION = Object.freeze({ sense: { category: "primary", special: true, modality: "visual", modalityFrom: "\"works in the same way as Darkvision\", in black and white and colour" }, light: { raisesLevelBy: 3 } });

/**
 * Each relic, tier by tier, as printed (v1.6, L10162–10382). Each tier ADDS to
 * the ones below it; `runes`, `quality` and `superior` REPLACE the tier
 * below's. A power is `{ key, name, text, … }`: `changes` and `conditionals`
 * are an effect the wielder carries; `auras` an aura of the core's; `uses` a
 * Use (block10-automations.mjs); `derives` a sense; `note` a card line only;
 * `replaces` the key of a lower tier's power it takes the place of.
 */
export const RELICS_10 = Object.freeze({
  "THE AEGIS OF VALTEA": {
    key: "aegisOfValtea", name: "The Aegis of Valtea", type: "shield", base: "Light Steel Shield",
    tiers: [
      { quality: "expert", superior: "Lightweight", runes: "Potency I", spells: ["Light"], powers: [] },
      { runes: "Potency I, Benevolent", spells: ["Cure"], powers: [
        { key: "aegisAura", name: "Aegis of Valtea: Warding Light", text: "You and allies within 10 ft gain a +1 item bonus to saving throws vs. fear and curse (Q214: you too).",
          self: [cond({ kind: "modifier", value: 1, type: "item", label: "Aegis of Valtea", scope: "Saving throws vs fear and curse", when: { checkTypes: ["save"], traits: ["fear", "curse"] } })],
          auras: [{ kind: "ally", radius: 10, name: "Aegis of Valtea", allyEffect: { conditionals: [cond({ kind: "modifier", value: 1, type: "item", label: "Aegis of Valtea", scope: "Saving throws vs fear and curse", when: { checkTypes: ["save"], traits: ["fear", "curse"] } })] } }] }
      ] },
      { runes: "Potency II, Benevolent", spells: ["Restoration"], powers: [
        { key: "aegisResist", name: "Aegis of Valtea: Essence Resistance", text: "Resistance to essence damage.", changes: [RESIST("essence")] }
      ] },
      { runes: "Potency III, Benevolent", spells: ["Forbiddance"], powers: [] },
      { spells: ["Heal"], powers: [
        { key: "aegisImmune", replaces: "aegisResist", name: "Aegis of Valtea: Essence Immunity", text: "Immunity to essence damage.", changes: [IMMUNE("essence")] },
        { key: "shieldOfDawn", name: "Shield of Dawn", text: "Once per day (2 AP, concentrate): for 1 minute, you and allies within 30 ft gain Fast Healing 10 and advantage on all saving throws against aberrations, eternals and undead. Enemies with the Evil aligned trait cannot benefit from concealment or invisibility within it.", uses: "shieldOfDawn", usesPerDay: "1" }
      ] }
    ]
  },
  EMBERFANG: {
    key: "emberfang", name: "Emberfang", type: "weapon", base: "Broadsword",
    tiers: [
      { quality: "expert", superior: "Balanced", runes: "Potency I", spells: ["Light"], powers: [] },
      { runes: "Potency II, Flaming I", spells: ["Burning Hands"], powers: [] },
      { quality: "master", runes: "Potency III, Flaming II", spells: [], powers: [
        { key: "emberResist", name: "Emberfang: Fire Resistance", text: "Wielder gains fire resistance.", changes: [RESIST("fire")] }
      ] },
      { runes: "Potency IV, Flaming III", spells: ["Fireball"], powers: [] },
      { quality: "legendary", runes: "Potency V, Flaming III", spells: ["Meteor Swarm"], powers: [
        { key: "emberImmune", replaces: "emberResist", name: "Emberfang: Fire Immunity", text: "Wielder gains fire immunity.", changes: [IMMUNE("fire")] }
      ] }
    ]
  },
  "OBSIDIAN CODEX": {
    key: "obsidianCodex", name: "Obsidian Codex", type: "gear", base: null,
    forbiddenAligned: ["good"], dissonance: ["balance", "order"], sacrifice: true,
    tiers: [
      { spells: ["Detect Undead", "Chill Touch"], powers: [
        { key: "codexSoul", name: "Obsidian Codex: Soul Lore", text: "+1 item bonus to Spellcraft checks when casting spells with the Soul trait. Detect Undead is constant.",
          self: [cond({ kind: "modifier", value: 1, type: "item", label: "Obsidian Codex", scope: "Spellcraft checks casting a Soul spell", when: { checkTypes: ["spellcraft"], traits: ["soul"] } })] }
      ] },
      { spells: ["Animate Dead", "Undead Binding"], powers: [
        { key: "codexFear", name: "Obsidian Codex: Whispers", text: "Advantage on saves against fear; −1 status penalty to saves vs spells of the divinity tradition. Whispering voices from the Codex provide fragments of forgotten necromantic lore.",
          self: [cond({ kind: "advantage", label: "Obsidian Codex", scope: "Saving throws against fear", when: { checkTypes: ["save"], traits: ["fear"] } }),
            cond({ kind: "modifier", value: -1, type: "status", label: "Obsidian Codex", scope: "Saving throws vs divinity-tradition spells", when: { checkTypes: ["save"], traditions: ["divinity"] } })] }
      ] },
      { spells: ["Vampiric Touch"], powers: [
        { key: "codexResist", name: "Obsidian Codex: Essence Resistance", text: "Resistance to essence damage.", changes: [RESIST("essence")] },
        { key: "codexHP", name: "Obsidian Codex: Bound Dead", text: "Undead you create or bind gain +2 HP per level of the undead (Q217).", note: true }
      ] },
      { spells: ["Create Undead"], powers: [
        { key: "codexControl", name: "Obsidian Codex: Necrotic Command", text: "Undead under your control (created or bound, Q217) gain advantage on attack rolls against living creatures.", note: true }
      ] },
      { spells: ["Hand of the Reaper"], powers: [
        { key: "codexImmune", replaces: "codexResist", name: "Obsidian Codex: Essence Immunity", text: "Immunity to essence damage. You are recognised as its chosen Necrolord.", changes: [IMMUNE("essence")] }
      ] }
    ]
  },
  "THE VEILSHROUD": {
    key: "veilshroud", name: "The Veilshroud", type: "gear", base: null,
    tiers: [
      { spells: ["Cloak of Greying"], powers: [
        { key: "veilStealth", name: "The Veilshroud: Shadowed", text: "+1 item bonus to Stealth checks. Creatures attempting to Track you by mundane means have disadvantage (the tracker's roll — by hand).",
          self: [cond({ kind: "modifier", value: 1, type: "item", label: "The Veilshroud", scope: "Stealth checks", when: { checkTypes: ["skill"], subjects: ["stealth"] } })] }
      ] },
      { runes: "Veil I", spells: ["Misty Step"], powers: [
        { key: "veilSight", name: "The Veilshroud: Darkvision", text: "Darkvision while wearing the cloak; Perfect Darkvision if you already have Darkvision. The cloak's edges ripple near planar anomalies or Luminex (the GM's).", sight: true }
      ] },
      { spells: ["Invisibility"], powers: [
        { key: "veilResist", name: "The Veilshroud: Essence Resistance", text: "Resistance to essence damage.", changes: [RESIST("essence")] },
        { key: "shadowStep", name: "The Veilshroud: Shadow Step", text: "Once per day (2 AP, move, teleportation), teleport up to 60 ft from a space of light level 2 or lower to another such space you can see. Invisibility is self only.", uses: "shadowStep", usesPerDay: "1" }
      ] },
      { spells: ["Dimension Door"], powers: [
        { key: "veilImmune", replaces: "veilResist", name: "The Veilshroud: Essence Immunity", text: "Immunity to essence damage. In the Shadescape the cloak disguises you as a native shadow-being unless you act aggressively (the GM's).", changes: [IMMUNE("essence")] }
      ] },
      { spells: ["Gate"], powers: [
        { key: "veilAbsorb", name: "The Veilshroud: Veil-Drinker", text: "When you would be dealt essence damage, you ignore it and instead regain HP equal to half the amount. The cloak is semi-sentient: it communicates, without Ego (Q216). Gate once per day; casting it risks attracting entities from beyond the Veil.", absorb: { type: "essence", heal: 0.5 } }
      ] }
    ]
  }
});

/** The innate PP allowance a relic spell needs (M102, M103 as printed): base PP over the tier's first level. */
export const innateAllowance = (pp, tier) => Math.max(0, int(pp) - TIERS[Math.max(0, Math.min(4, int(tier)))].from);

/** Spells cast once a day rather than with the focus trait. */
export const ONCE_A_DAY_SPELLS = Object.freeze({ veilshroud: ["Gate"] });

/**
 * AT WILL (0.17.1; Graham's yes of 15 November 2026): the Codex's Dormant
 * "cast Detect Undead as an innate spell (constant)" is granted without a use
 * limit and without the Focus trait.
 */
export const AT_WILL_SPELLS = Object.freeze({ obsidianCodex: ["Detect Undead"] });

/**
 * A relic's state at a tier (Q215): its quality, superior traits and runes
 * (the highest tier's that sets them), every spell up to it (with the tier it
 * came from), and every power up to it less those a higher one replaced.
 * Tier -1 is the plain Dormant item without powers.
 */
export function relicStateAt(spec, tier) {
  const t = Math.min(4, int(tier));
  const out = { tier: t, quality: "", superior: "", runes: "", spells: [], powers: [] };
  const upTo = t < 0 ? 0 : t;
  for (let i = 0; i <= upTo; i += 1) {
    const row = spec.tiers[i];
    if (row.quality) out.quality = row.quality;
    if (row.superior !== undefined) out.superior = row.superior;
    if (row.runes !== undefined) out.runes = row.runes;
    if (t < 0) break;
    for (const s of row.spells ?? []) out.spells.push({ name: s, tier: i });
    for (const p of row.powers ?? []) {
      if (p.replaces) out.powers = out.powers.filter((q) => q.key !== p.replaces);
      out.powers.push({ ...p, tier: i });
    }
  }
  return out;
}

/** The relic spec of a key (`aegisOfValtea`), or null. RELICS_10 is keyed by the book's name. */
export function relicSpecByKey(key) {
  return Object.values(RELICS_10).find((s) => s.key === key) ?? null;
}

/** The relic spec an item names (by its flag's key), or null. */
export function relicSpecOf(item, moduleId = "trg-eldritch-arts") {
  return relicSpecByKey(relicRecord(item, moduleId)?.key);
}

/* ------------------------------------------------------------------ */
/* Sentient items (L10384–10450)                                        */
/* ------------------------------------------------------------------ */

/** Ego = item level + highest mental modifier + number of special powers (L10395). */
export function egoOf({ level = 0, int: i = 0, wis = 0, cha = 0, powers = 0 } = {}) {
  return int(level) + Math.max(int(i), int(wis), int(cha)) + int(powers);
}
/** Ego DC = 10 + Ego (L10397, M111). */
export const egoDC = (ego) => 10 + int(ego);

/** The Influence ladder as printed (L10401–10413). */
export const INFLUENCE = Object.freeze({
  heroic: "The wielder not only resists but temporarily suppresses the item’s influence. For 24 hours, the item cannot attempt further control.",
  critical: "The wielder not only resists but temporarily suppresses the item’s influence. For 24 hours, the item cannot attempt further control.",
  success: "The wielder resists. The item remains resentful but does not act against the wielder.",
  partial: "The wielder resists for now, but the item nags, sulks, or distracts imposing minor penalties (GM discretion) until appeased.",
  failure: "The item asserts itself. It may refuse to use powers, impose disadvantage/penalties on its wielder, or compel a minor action aligned with its goal.",
  fumble: "The item actively seizes partial control. It may override one decision that the wielder makes each turn, for one more suited to its own ethics and purpose. The wielder may attempt a new check after 1 hour.",
  blunder: "The item dominates the wielder for 1 hour, acting as if it were in full control. During this time, the GM dictates actions according to the item’s goals."
});
/** The waits a degree sets, in seconds: a Critical's 24 hours, a Fumble's hour (L10403, L10411). */
export const INFLUENCE_WAIT = Object.freeze({ heroic: 86400, critical: 86400, fumble: 3600 });

/** The text for a degree: the item's own (Dawnshield's three, M112) or the general ladder. */
export function influenceText(degree, overrides = {}) {
  const d = norm(degree);
  return String(overrides?.[d] ?? INFLUENCE[d] ?? INFLUENCE.failure);
}

/** Why Influence may not be rolled now, or "". */
export function influenceRefusal(record, now = 0) {
  const until = Number(record?.influenceBlockedUntil ?? 0);
  return until > now ? `${record?.blockedBy === "critical" ? "its influence is suppressed" : "no new check yet"} (${Math.ceil((until - now) / 60)} more minute(s))` : "";
}

/** Dawnshield (L10636–10690), as printed. */
export const DAWNSHIELD = Object.freeze({
  key: "dawnshield", name: "Dawnshield", level: 15, price: 38500, weight: 10, base: "Heavy Steel Shield",
  stats: Object.freeze({ penalty: 0, dr: 3, db: 4, hp: 110 }), quality: "master", runes: "Potency II",
  aligned: ["Balanced", "Good"], int: 3, wis: 4, cha: 6, ego: 24, egoDC: 34,
  overrides: Object.freeze({
    success: "You resist, but Dawnshield withholds guidance (–2 circumstance to Charisma-based skill checks for 24h).",
    failure: "Dawnshield dims—you lose its special powers and superior-trait benefits until you atone with a protective act.",
    fumble: "Dawnshield compels protective/self-sacrificial actions for 1 hour (GM control)."
  })
});
