/**
 * Eldritch Arts Block 2b — three skill actions, in the shape TRG Prime's
 * SKILL_ACTIONS holds:
 *
 *   INSCRIBE SUMMONING CIRCLE (Chapter 7, CREATING A CIRCLE): "The caster
 *     must succeed on an Occultism, Arcana, Nature or Religion check
 *     (depending on tradition). The DC is Moderate (+0) for the creature's
 *     level, adjusted by conditions" — the Summoning Circle Modifiers.
 *   BORROW SPELL (Chapter 4; Graham's m14: "as rewritten; it is now a General
 *     skill action"): "an Easy (DC -2) check based upon the normal DC to learn
 *     the spell".
 *   SEE THROUGH SPELL TRICKERY (Chapter 4, Spell Trickery): "Any creatures
 *     that are attempting to identify the spell that you are casting must
 *     make either a Sense Motive or Tradition based skill check against your
 *     Deception DC". The book names no action for the observer; this is that
 *     check, its seven results printed and left to the table.
 *
 * BOOK TEXT IS VERBATIM (tools/content/book-text.json `chapter4` and
 * `chapter7.summoning`), held against the extract by verify-block2b.
 */
import { resolveCircleDC, resolveBorrowDC } from "./block2b-automations.mjs";

const ladder = (o) => ({ heroic: "", critical: "", success: "", partial: "", failure: "", fumble: "", blunder: "", ...o });

export const SKILL_ACTIONS = Object.freeze([
  {
    key: "inscribeSummoningCircle",
    name: "Inscribe Summoning Circle",
    skills: ["occultism", "arcana", "nature", "religion"],
    traits: "Concentrate",
    apCost: "Varies (10 minutes × the creature's level)",
    checkType: "skill",
    against: "none",
    difficulty: "medium",
    outcomesApplied: true,
    resolveDC: (ctx) => resolveCircleDC(ctx),
    outcomes: ladder({
      critical: "the caster gains a +4-circumstance bonus to Spellcasting checks made to summon and bind the creature. Furthermore, the creature takes a -2-circumstance penalty to all attempts to resist binding and escaping the circle.",
      success: "the caster gains +2 circumstance bonus to spellcasting checks made to summon and bind the creature.",
      failure: "the circle provides no benefit and is flawed, imposing –2 circumstance penalty to the summoning attempt.",
      fumble: "the circle destabilizes: if the ritual succeeds, the creature arrives hostile and unbound."
    }),
    description: "Crafting a summoning circle requires 10 minutes × the level of the creature being summoned. The caster must succeed on an Occultism, Arcana, Nature or Religion check (depending on tradition). The DC is Moderate (+0) for the creature’s level, adjusted by conditions (surface, precision, distractions). Circles last 1 hour per caster level unless reinforced with costly reagents (typically rare chalks, powdered gems, or sacrificial components). (Eldritch Arts, Chapter 7)"
  },
  {
    key: "borrowSpell",
    name: "Borrow Spell",
    skills: ["arcana", "nature", "occultism", "religion"],
    traits: "Concentrate",
    apCost: "Varies (part of daily preparation)",
    proficiency: "trained",
    checkType: "skill",
    against: "none",
    difficulty: "easy",
    outcomesApplied: true,
    resolveDC: (ctx) => resolveBorrowDC(ctx),
    outcomes: ladder({
      success: "You successfully prepare the borrowed spell as part of your normal daily spell preparation.",
      failure: "You are unable to prepare the borrowed spell, but the memorisation remains available for you to prepare a different spell. You cannot attempt to prepare this same spell again until the next time you prepare spells."
    }),
    description: "If you are a spellcaster who prepares spells from a spellbook, you may attempt to prepare a spell from another caster’s spellbook. This is an Easy (DC -2) check based upon the normal DC to learn the spell. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "seeThroughSpellTrickery",
    name: "See Through Spell Trickery",
    skills: ["senseMotive", "arcana", "nature", "occultism", "religion"],
    // As Identify Power, the core's own identification: Concentrate, Varies.
    traits: "Concentrate",
    apCost: "Varies",
    checkType: "skill",
    against: "skillDC:deception",
    outcomesApplied: false,
    outcomes: ladder({
      heroic: "The target instantly and flawlessly identifies the true spell, its tradition, and its intended effects. The target gains a +4-circumstance bonus to counteract or defend against it.",
      critical: "The target identifies the true spell, its tradition, and its intended effects. The target gains a +2-circumstance bonus to counteract or defend against it.",
      success: "The target identifies the true spell, its tradition, and its intended effects.",
      partial: "The target identifies the tradition of the spell.",
      failure: "The target cannot identify the spell until it manifests.",
      fumble: "The target believes the spell is harmless and of a completely different tradition.",
      blunder: "Completely fooled; target believes the spell is something entirely different of your choice, including tradition, effect, and target type."
    }),
    description: "Target the caster using Spell Trickery. Any creatures that are attempting to identify the spell that you are casting must make either a Sense Motive or Tradition based skill check against your Deception DC. (Eldritch Arts, Chapter 4, Spell Trickery)"
  }
]);
