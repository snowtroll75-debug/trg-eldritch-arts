/**
 * Eldritch Arts Block 2 (0.3.0) — Chapter 7 on the map, and the actions that
 * touch raw essence.
 *
 *   TAP LEY LINE, CHANNEL LEY LINE, TAP MAGICAL ENERGY: their DC (TRG Prime
 *     3.678.0's `resolveDC`) and each printed degree.
 *   THE LEY LINE EFFECTS TABLE (Graham's M6): a Tap's Success or better, and
 *     Channel's Heroic and Critical, roll the Effect column; a Tap's Fumble
 *     rolls the Backlash column. "All effects last in line with the skill
 *     being used": to the end of your turn (Tap Success), the end of your next
 *     turn (Tap Critical, Channel Critical), 1 minute (Channel Heroic). A
 *     backlash with no printed duration lasts to the end of your next turn.
 *   WILD MAGIC AREAS (M7): a casting check in one that comes out Partial or
 *     worse, or with chaos, rolls the Wild Surge table — scrolls, wands and
 *     rituals included (Q7). Damage 1d8 × level, range 5 ft × level, duration
 *     1 round × level, unless the row says otherwise.
 *   MAGIC SUPPRESSION AREAS (M8): a penalty equal to the level on every
 *     casting check (a spell-check gate); Partial, Failure and Fumble read as
 *     Failure and Blunder as Fumble (D7); no Resonance events (D6); in an area
 *     with backlash, a failed casting rolls the Suppression Backlash table.
 *   ANTIMAGIC (level 20+; Q6): every casting refused, innate included (D7);
 *     while you stand inside, the effects of your items and your spells are
 *     switched off, and come back when you leave (D14).
 *
 * DCs THE BOOK DOES NOT PRINT follow Graham's C3: "the Level DC of the target
 * (if something is targeted) or the casters own level DC if nothing is
 * targeted". A ley line's damage on you is against your own level DC; Tap
 * Magical Energy's check is against the item's.
 */
import { isActingGM } from "./writer.mjs";
import { SKILL_ACTIONS } from "./block2-actions.mjs";
import { LEY_LINE_EFFECTS, WILD_SURGE, SUPPRESSION_BACKLASH, rowFor } from "./chapter7-tables.mjs";
import { leyBand, suppressionBand, isAntimagic, areasAt, leyLinesWithin, strongestAreaAt, MODULE_ID, AREA_TYPES } from "./areas.mjs";
import { effectData, expiryFor, forSeconds, SYSTEM_ID } from "./effects-clock.mjs";
import {
  norm, int, esc, h, line, card, warn, now, levelOf, tokenOf, feetBetween, lockouts, lock, printedDegree, lockedUntil, dayOf
} from "./block1-automations.mjs";

const PLAN_FLAG = "block2Plan";
export const LEY_SKILLS = Object.freeze([["arcana", "Arcana"], ["nature", "Nature"], ["occultism", "Occultism"], ["religion", "Religion"]]);
export const ELEMENTS = Object.freeze([["acid", "Acid"], ["cold", "Cold"], ["electricity", "Electricity"], ["fire", "Fire"], ["sonic", "Sonic"]]);
export const DAMAGE_TYPES = Object.freeze(["acid", "bludgeoning", "cold", "electricity", "essence", "fire", "force", "mental", "piercing", "poison", "slashing", "sonic"]);
export const ABILITIES = Object.freeze(["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]);
const DIRECTIONS = Object.freeze(["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"]);

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

/** "per 2 ley line levels": the level halved, rounded down. */
export const perTwo = (level) => Math.floor(Math.max(0, int(level)) / 2);

/**
 * A row's number or dice, at a level: "level" → the level, "halfLevel" →
 * per two levels; "level d8" → (level)d8, "halfLevel d6" → (level/2)d6.
 * Returns "" for no dice at all (a level-1 "per 2 levels"). "1d8 x level" is
 * the book's "1d8 × area level": one roll, multiplied.
 */
export function scaled(value, level) {
  const l = Math.max(0, int(level));
  const s = String(value ?? "").trim();
  if (s === "level") return String(l);
  if (s === "halfLevel") return String(perTwo(l));
  const m = /^(level|halfLevel) (d\d+)$/.exec(s);
  if (m) { const n = m[1] === "level" ? l : perTwo(l); return n > 0 ? `${n}${m[2]}` : ""; }
  // "1d6 × area level": one die, multiplied — not a die per level.
  const x = /^(\d+d\d+) x level$/.exec(s);
  if (x) return l > 0 ? `(${x[1]})*${l}` : "";
  return s;
}

/** Channel Ley Line's PP dice for a line's level: Minor 1d6 … Legendary 5d6. */
export const channelDice = (level) => `${leyBand(level).channelDice}d6`;

/** Channel Ley Line's damage multiplier on a failed check. */
export const channelDamageMultiplier = (degree) => ({ failure: 1, fumble: 2, blunder: 3 })[degree] ?? 0;

/**
 * Tap Magical Energy: what is siphoned and what the item loses.
 * @returns {{siphon: number, itemLoses: number|string}}
 */
export function siphonFor(degree, casterLevel) {
  const cl = Math.max(0, int(casterLevel));
  if (degree === "critical") { const s = Math.floor(cl / 2); return { siphon: s, itemLoses: Math.max(1, Math.floor(s / 2)) }; }
  if (degree === "success") { const s = Math.floor(cl / 2); return { siphon: s, itemLoses: s }; }
  if (degree === "partial") { const s = Math.floor(cl / 4); return { siphon: s, itemLoses: s }; }
  if (degree === "failure") return { siphon: 0, itemLoses: 1 };
  if (degree === "fumble" || degree === "blunder") return { siphon: 0, itemLoses: "1d4" };
  return { siphon: 0, itemLoses: 0 };
}

/** Does a Wild Magic area surge on this casting (M7)? */
export const surges = (degree, chaos = false) => Boolean(chaos) || ["partial", "failure", "fumble", "blunder"].includes(String(degree));

/** A Magic Suppression area's reading of the casting degree. */
export const SUPPRESSED_DEGREE = Object.freeze({ partial: "failure", failure: "failure", fumble: "failure", blunder: "fumble" });

/** PP after a change, never below 0 or above the maximum. */
export const clampPP = (value, max) => Math.max(0, Math.min(Math.max(0, int(max)), int(value)));

/** The unspent siphoned PP when the essence dissipates: the siphon, or what is left above the pool before it. */
export const unspentSiphon = ({ siphon, before, current }) => Math.max(0, Math.min(int(siphon), int(current) - int(before)));

/** The conditional a "cond" row makes. */
export function rowConditional(spec, { label, skill = null } = {}) {
  const c = { kind: spec.mod.kind, label, scope: label, auto: true };
  if (spec.mod.kind === "modifier") { c.value = spec.mod.value; c.type = spec.mod.type; }
  if (spec.always) c.always = true;
  else c.when = skill ? { checkTypes: ["skill"], subjects: [skill] } : { ...(spec.when ?? {}) };
  if (spec.oneShot) c.oneShot = true;
  return c;
}

/* ------------------------------------------------------------------ */
/* Foundry side: small steps                                            */
/* ------------------------------------------------------------------ */

const ppOf = (actor) => ({ value: int(actor?.system?.resources?.pp?.value), max: int(actor?.system?.resources?.pp?.max) });
async function setPP(actor, value) { const { max } = ppOf(actor); const v = clampPP(value, max); await actor.update({ "system.resources.pp.value": v }); return v; }
const ownLevelDC = (actor) => h().levelDC(levelOf(actor));
async function rollFormula(formula) { if (!formula) return { total: 0, roll: null }; const roll = await new Roll(String(formula)).evaluate(); return { total: int(roll.total), roll }; }
const tokensOnScene = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t.actor);
const sameSide = (a, b) => Number(a?.document?.disposition ?? 0) === Number(b?.document?.disposition ?? 0);

function alliesWithin(token, feet, { includeSelf = false } = {}) {
  if (!token) return [];
  return tokensOnScene().filter((t) => (t === token ? includeSelf : sameSide(t, token) && (feetBetween(token, t) ?? Infinity) <= feet));
}
function creaturesWithin(token, feet, { includeSelf = true } = {}) {
  if (!token) return [];
  return tokensOnScene().filter((t) => (t === token ? includeSelf : (feetBetween(token, t) ?? Infinity) <= feet));
}
function shuffle(list) { const a = list.slice(); for (let i = a.length - 1; i > 0; i -= 1) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

async function chooseTokens(title, candidates, max) {
  if (!candidates.length) return [];
  const content = `<p>Choose up to ${max}.</p>${candidates.map((t, i) => `<div class="form-group"><label><input type="checkbox" name="t${i}"> ${esc(t.name)}</label></div>`).join("")}`;
  const answer = await foundry.applications.api.DialogV2.prompt({
    window: { title }, content,
    ok: { label: "Choose", callback: (event, button) => new (foundry.applications?.ux?.FormDataExtended ?? globalThis.FormDataExtended)(button.form).object },
    rejectClose: false
  }).catch(() => null);
  if (!answer) return [];
  return candidates.filter((t, i) => answer[`t${i}`]).slice(0, max);
}

/** Damage to one creature: a basic save against its own level DC (C3), or straight. */
async function hurt(source, target, { amount = null, formula = "", type, save = null, label, half = false, shield = null }) {
  if (!target) return [];
  // A CHAOS SHIELD (0.12.0, Block 8b; Q178): the row's saves at DC −2, and its
  // damage to an ally inside the aura halved ("resistance to wild surge backlash").
  const shielded = Boolean(shield?.members?.has?.(target.uuid));
  if (shielded && amount === null && formula) { amount = (await rollFormula(formula)).total; formula = ""; }
  if (shielded && amount !== null) amount = Math.floor(Math.max(0, int(amount)) / 2);
  if (save) {
    const out = await h().basicSaveHit({ caster: source, target, save, dc: ownLevelDC(target) + int(shield?.dcStep), label, ...(amount !== null ? { amount } : { formula }), type });
    return [out?.line ?? line(`${esc(target.name)}: ${label}.`), ...(shielded ? [line(`<em>${esc(target.name)}: halved within the Chaos Shield.</em>`)] : [])];
  }
  let total = amount;
  if (total === null) total = (await rollFormula(formula)).total;
  if (half) total = Math.floor(total / 2);
  const res = await h().applyTypedDamage(target, { amount: total, type, sourceName: label });
  return [line(`${esc(target.name)} takes <strong>${int(res?.applied ?? total)}</strong> ${esc(type)} (${esc(label)}).`)];
}

/** Lose HP outright: not damage, nothing reduces it. */
async function loseHP(actor, amount, label) {
  await h().applyTypedDamage(actor, { amount: int(amount), type: "untyped", ignoreDefences: true, sourceName: label });
  return [line(`${esc(actor.name)} loses <strong>${int(amount)} HP</strong> (${esc(label)}).`)];
}

/* ------------------------------------------------------------------ */
/* A table row, applied                                                 */
/* ------------------------------------------------------------------ */

/**
 * Apply one row's spec.
 * @param {Actor} actor whoever the row happens to
 * @param {object} spec the row's `e` or `b`
 * @param {{level: number, text: string, title: string, expiry: object, source: string, radiusFeet?: number}} ctx
 * @returns {Promise<string[]>} card lines
 */
export async function applyRow(actor, spec, ctx) {
  const token = tokenOf(actor);
  const L = ctx.level;
  const lines = [];
  const effect = (name, data) => effectData(ctx.source, { name, img: "icons/magic/light/explosion-star-glow-blue-purple.webp", description: `${ctx.title}: ${ctx.text}`, expiry: ctx.expiry, ...data });
  switch (spec?.kind) {
    case "cond": {
      let skill = null;
      if (spec.choose === "leySkill") {
        skill = await h().chooseFromList(ctx.title, "Which skill?", LEY_SKILLS.map(([v, l]) => [v, l]));
        if (!skill) return [line("<em>No skill chosen: apply it at the table.</em>")];
      }
      const skillLabel = LEY_SKILLS.find(([v]) => v === skill)?.[1] ?? "";
      const label = String(spec.label ?? ctx.title).replace("{skill}", skillLabel);
      const expiry = spec.seconds ? forSeconds(spec.seconds) : ctx.expiry;
      const targets = spec.allies ? alliesWithin(token, spec.allies).map((t) => t.actor) : [actor];
      for (const target of targets) {
        await h().createEffectsOn(target, [effectData(ctx.source, { name: `${ctx.title}: ${label}`, description: `${ctx.title}: ${ctx.text}`, system: { conditionals: [rowConditional(spec, { label, skill })] }, expiry })]);
      }
      lines.push(line(`${spec.allies ? `${targets.length ? targets.map((a) => esc(a.name)).join(", ") : "No ally within reach"}` : esc(actor.name)}: <strong>${esc(label)}</strong>.`));
      return lines;
    }
    case "db": {
      await h().createEffectsOn(actor, [effect(`${ctx.title}: ${spec.label}`, { changes: [{ key: "system.combat.defence.other", type: "custom", value: String(spec.value), priority: 20 }] })]);
      return [line(`<strong>${esc(spec.label)}</strong> (untyped).`)];
    }
    case "dr": {
      const minutes = (await rollFormula(spec.minutes)).total || 1;
      await h().createEffectsOn(actor, [effectData(ctx.source, { name: `${ctx.title}: +${spec.value} DR`, description: `${ctx.title}: ${ctx.text}`, changes: [{ key: "system.combat.dr.other", type: "custom", value: String(spec.value), priority: 20 }], expiry: forSeconds(60 * minutes) })]);
      return [line(`<strong>+${spec.value} DR</strong> for <strong>${minutes} minute${minutes === 1 ? "" : "s"}</strong> (${spec.minutes}).`)];
    }
    case "spellDC": {
      await h().createEffectsOn(actor, [effect(`${ctx.title}: spell save DC ${spec.value > 0 ? "+" : ""}${spec.value}`, { system: { spellDCBonus: { label: ctx.title, value: spec.value, type: "untyped" } } })]);
      return [line(`Your spells' save DC <strong>${spec.value > 0 ? "+" : ""}${spec.value}</strong> (untyped).`)];
    }
    case "defence": {
      const type = await h().chooseFromList(ctx.title, spec.list === "resistances" ? "Resistance to which damage type?" : "Weakness to which damage type?", DAMAGE_TYPES.map((t) => [t, t]));
      if (!type) return [line("<em>No damage type chosen: apply it at the table.</em>")];
      await h().createEffectsOn(actor, [effect(`${ctx.title}: ${spec.list === "resistances" ? "resistance" : "weakness"} to ${type}`, { changes: [{ key: `system.combat.${spec.list}`, type: "add", value: `, ${type}`, priority: 20 }] })]);
      return [line(`<strong>${spec.list === "resistances" ? "Resistance" : "Weakness"} to ${esc(type)}</strong>.`)];
    }
    case "tempHP": {
      const n = int(scaled(spec.amount, L));
      await h().grantTempHP(actor, n);
      return [line(`<strong>${n} temporary HP</strong>.`)];
    }
    case "heal": {
      const n = int(scaled(spec.amount, L));
      let target = actor;
      if (spec.ally) {
        const allies = alliesWithin(token, spec.ally);
        const pick = allies.length ? await h().chooseFromList(ctx.title, "Which ally?", allies.map((t) => [t.id, t.name])) : null;
        target = allies.find((t) => t.id === pick)?.actor ?? null;
        if (!target) return [line("<em>No ally within reach: nobody is healed.</em>")];
      }
      await h().healActor(target, n);
      return [line(`${esc(target.name)} is healed <strong>${n} HP</strong>.`)];
    }
    case "loseHP": return loseHP(actor, int(scaled(spec.amount, L)), ctx.title);
    case "pp": {
      const n = int(scaled(spec.amount, L)) * (spec.sign === -1 ? -1 : 1);
      const before = ppOf(actor).value;
      const after = await setPP(actor, before + n);
      return [line(`PP <strong>${before} → ${after}</strong> (${n > 0 ? "+" : ""}${n}${after - before !== n ? ", capped" : ""}).`)];
    }
    case "ppFull": { const { max } = ppOf(actor); await setPP(actor, max); return [line(`PP restored to <strong>${max}</strong>.`)]; }
    case "ppEmpty": { await setPP(actor, 0); return [line("PP <strong>0</strong>: completely drained.")]; }
    case "lostPP": return [line(`<em>The spell's PP are lost (${int(ctx.ppLost)} more PP, taken now).</em>`), ...(ctx.ppLost ? [line(`PP <strong>${ppOf(actor).value} → ${await setPP(actor, ppOf(actor).value - int(ctx.ppLost))}</strong>.`)] : [])];
    case "nextSpellPP": {
      await h().createEffectsOn(actor, [effect(`${ctx.title}: next spell +${spec.pp} PP`, { module: { nextSpellSurcharge: spec.pp } })]);
      return [line(`Your next spell costs <strong>${spec.pp} additional PP</strong>.`)];
    }
    case "surcharge": {
      const pp = perTwo(L) * spec.per2Levels;
      if (!pp) return [line("<em>Level 1: no additional PP.</em>")];
      await h().createEffectsOn(actor, [effectData(ctx.source, { name: `${ctx.title}: spells +${pp} PP`, description: `${ctx.title}: ${ctx.text}`, module: { spellSurcharge: pp }, expiry: forSeconds(spec.seconds) })]);
      return [line(`All your spells cost <strong>${pp} additional PP</strong> for 1 minute.`)];
    }
    case "condition": {
      const value = spec.tag.value === undefined ? undefined : int(scaled(spec.tag.value, L));
      // "Half the ley line's level" at level 1 is nothing (rounded down).
      if (value === 0) return [line(`<em>${esc(spec.tag.key)} 0 at level ${L}: nothing.</em>`)];
      // ITS OWN DURATION, OR THE ROW'S (found in review): a surge's 1 round per
      // area level, a backlash's to the end of your next turn.
      const seconds = spec.roundsPerLevel ? 6 * Math.max(1, L) : spec.seconds ?? null;
      const until = seconds ? now() + seconds : int(ctx.expiry?.system?.spellEffectEnd) || null;
      const tag = { key: spec.tag.key, ...(value !== undefined ? { value } : {}), ...(until ? { expiresTime: until } : {}) };
      await h().applyConditionTagsTo(actor, [tag]);
      return [line(`${esc(actor.name)}: <strong>${esc(spec.tag.key)}${value !== undefined ? ` ${value}` : ""}</strong>${until ? ` for ${Math.max(1, Math.round((until - now()) / 6))} round${until - now() <= 6 ? "" : "s"}` : ""}.`)];
    }
    case "damage": {
      const formula = spec.formula ? scaled(spec.formula, L) : "";
      const amount = spec.amount ? int(scaled(spec.amount, L)) : null;
      if (spec.formula && !formula) return [line("<em>Level 1: no dice (per 2 levels).</em>")];
      let type = spec.type;
      if (String(type).startsWith("choose:")) {
        type = await h().chooseFromList(ctx.title, "Which element?", ELEMENTS.map(([v, l]) => [v, l]));
        if (!type) return [line("<em>No element chosen: apply it at the table.</em>")];
      }
      let targets = [actor];
      const radius = ctx.radiusFeet ?? 5 * Math.max(1, L);
      if (spec.allies) targets = alliesWithin(token, spec.allies).map((t) => t.actor);
      else if (spec.ally) {
        const allies = alliesWithin(token, spec.ally);
        const pick = allies.length ? await h().chooseFromList(ctx.title, "Which ally takes it?", allies.map((t) => [t.id, t.name])) : null;
        targets = allies.filter((t) => t.id === pick).map((t) => t.actor);
      } else if (spec.choose) targets = (await chooseTokens(`${ctx.title}: within ${radius} ft`, creaturesWithin(token, radius, { includeSelf: false }), spec.choose)).map((t) => t.actor);
      else if (spec.randomAllies) targets = shuffle(alliesWithin(token, radius)).slice(0, spec.randomAllies).map((t) => t.actor);
      else if (spec.radius) targets = creaturesWithin(token, radius, { includeSelf: Boolean(spec.includeSelf) }).map((t) => t.actor);
      if (!targets.length && spec.fallbackSelfStun) {
        lines.push(line("No ally within the radius: you take it, and are stunned 1."));
        targets = [actor];
        await h().applyConditionTagsTo(actor, [{ key: "stunned", value: spec.fallbackSelfStun }]);
      }
      if (!targets.length) return [line("<em>Nobody within reach.</em>")];
      // One roll for every target, as a spell's area rolls once.
      const rolled = amount !== null ? amount : (await rollFormula(formula)).total;
      const each = spec.half ? Math.floor(rolled / 2) : rolled;
      if (spec.half) lines.push(line(`${formula} = ${rolled}, halved: <strong>${each}</strong>.`));
      for (const target of targets) lines.push(...await hurt(actor, target, { amount: each, type, save: spec.save ?? null, label: ctx.title, shield: ctx.shield ?? null }));
      return lines;
    }
    case "parity": {
      const { total } = await rollFormula(`1d${spec.die}`);
      const even = total % 2 === 0;
      lines.push(line(`1d${spec.die} = <strong>${total}</strong> (${even ? "even" : "odd"}).`));
      if (spec.what === "pp") { const before = ppOf(actor).value; const after = await setPP(actor, before + (even ? total : -total)); lines.push(line(`PP <strong>${before} → ${after}</strong>.`)); }
      if (spec.what === "hp") { if (even) { await h().healActor(actor, total); lines.push(line(`<strong>${total} HP</strong> gained.`)); } else lines.push(...await loseHP(actor, total, ctx.title)); }
      if (spec.what === "physical") {
        const label = even ? "Advantage on physical skill checks" : "Disadvantage on physical skill checks";
        await h().createEffectsOn(actor, [effectData(ctx.source, { name: `${ctx.title}: ${label}`, description: `${ctx.title}: ${ctx.text}`, system: { conditionals: [{ kind: even ? "advantage" : "disadvantage", label, scope: "A physical skill check — tick it", auto: false, when: { checkTypes: ["skill"] } }] }, expiry: forSeconds(spec.seconds) })]);
        lines.push(line(`<strong>${label}</strong> for 1 hour (offered on each skill check: tick it on a physical one).`));
      }
      if (spec.what === "conviction") {
        const conv = actor.system?.resources?.conviction ?? {};
        const to = even ? int(conv.max) : 0;
        await actor.update({ "system.resources.conviction.value": to });
        lines.push(line(`Conviction <strong>${to}</strong>${even ? " (maximum)" : " (all expended)"}.`));
      }
      return lines;
    }
    case "ability": {
      const ability = ABILITIES[Math.floor(Math.random() * ABILITIES.length)];
      const { total } = await rollFormula(spec.formula);
      const value = total * spec.sign;
      const seconds = 6 * Math.max(1, L);
      await h().createEffectsOn(actor, [effectData(ctx.source, { name: `${ctx.title}: ${ability} racial ${value > 0 ? "+" : ""}${value}`, description: `${ctx.title}: ${ctx.text}`, changes: [{ key: `system.attributes.${ability}.racial`, type: "add", value: String(value), priority: 20 }], expiry: forSeconds(seconds) })]);
      return [line(`Racial bonus to <strong>${ability}</strong> ${value > 0 ? "+" : ""}${value} (1d4 = ${total}) for ${Math.max(1, L)} round${L === 1 ? "" : "s"} (1 round per area level).`)];
    }
    case "direction": {
      const { total } = await rollFormula("1d8");
      return [line(`Teleported <strong>${5 * Math.max(1, L)} ft ${DIRECTIONS[total - 1]}</strong> (1d8 = ${total}). <em>Move the token.</em>`)];
    }
    case "resonance": {
      await h().rollResonanceEvent(actor, { reason: `${ctx.title}`, disadvantage: spec.disadvantage === true, modifiers: spec.extra ? { extra: spec.extra } : {} });
      return [line("<em>A Resonance event is rolled (its own card).</em>")];
    }
    case "summons": {
      // LEY LINE EFFECTS 25–27 (0.11.0, Block 8a; Q184): "Your summoned
      // creatures gain +1 AB." / "Summons are Stunned 1." — the creatures the
      // caster's control register holds as bound or conjured (TRG Prime
      // 3.686.0, H12). A level-only entry names no creature, and is said.
      const { isSummonedEntry } = await import("./block8a-rules.mjs");
      const entries = (await h().controlledOf?.(actor) ?? []).filter(isSummonedEntry);
      const out = [];
      let none = 0;
      for (const entry of entries) {
        const creature = await h().controlledCreature?.(entry);
        if (!creature) { none += 1; continue; }
        out.push(...await applyRow(creature, spec.row, ctx));
      }
      if (none) out.push(line(`<em>${none} summoned creature${none === 1 ? "" : "s"} recorded without a token: apply it at the table.</em>`));
      return out.length ? out : [line("<em>No summoned creature is held (the control register lists none): nothing to apply.</em>")];
    }
    case "manual":
    default:
      return [line("<em>Apply at the table: the system has no channel for this yet.</em>")];
  }
}

/**
 * Roll a table and apply its row.
 * @returns {Promise<{row: object, roll: number}>}
 */
export async function rollTable(actor, { table, column = "e", title, level, expiry, source, radiusFeet, ppLost = 0, depth = 0, forcedTotal = 0, shield = null, cancels = false }) {
  // A CHAOS SHIELD (0.12.0, Block 8b): a wild surge within one may be
  // nullified by its caster, or is rolled twice and picked by the surger; its
  // rows are softened for those inside (block8b-automations `shieldSurge`).
  // Asked once, at the top; the rerolls below carry its answer.
  const shieldLines = [];
  if (table === WILD_SURGE && depth === 0 && !shield) {
    const { shieldSurge } = await import("./block8b-automations.mjs");
    const got = await shieldSurge(actor, { title, forcedTotal, cancels });
    if (got.nullified) {
      await card(actor, title, got.lines);
      return { row: null, roll: 0, nullified: true };
    }
    forcedTotal = got.forcedTotal;
    shield = got.shield;
    shieldLines.push(...got.lines);
    // WILDBANE (0.14.0, Block 9b): "whenever a Wild Magic surge occurs within
    // 30 feet of you, roll a flat check (DC 15)" — for each bearer near its source.
    const { wildbaneLines } = await import("./block9b-automations.mjs");
    shieldLines.push(...await wildbaneLines(actor));
  }
  // A ROLL ALREADY MADE (0.5.0): Wild Power's two rolls at disadvantage in a
  // Wild Magic area, the GM having chosen one.
  const { total, roll } = forcedTotal >= 1 && forcedTotal <= 100 ? { total: forcedTotal, roll: null } : await rollFormula("1d100");
  const row = rowFor(table, total);
  const text = column === "b" ? row.backlash : row.effect;
  const spec = column === "b" ? row.b : row.e;
  const ctx = { level, text, title, expiry, source, radiusFeet, ppLost, shield };
  // THE CARD'S HEADING IS THE TITLE (0.4.0; the 0.3.0 live test): the first
  // line says the roll and the row, not the title again.
  const lines = [...shieldLines, line(`d100 <strong>${total}</strong>: ${esc(text)}`)];
  if (spec?.kind === "reroll" && depth === 0) {
    await card(actor, title, lines);
    const rolls = [];
    for (let i = 0; i < spec.times; i += 1) rolls.push(await rollTable(actor, { table, column, title, level, expiry, source, radiusFeet, depth: 1, shield }));
    // A WILD SURGE'S 66 AGAIN: "roll a Resonance event with a bonus equal to the area's level instead".
    if (spec.resonanceOn && rolls.some((r) => r.roll === spec.resonanceOn)) {
      await card(actor, title, [line(`Another <strong>66</strong>: a Resonance event at +${level}.`)]);
      await h().rollResonanceEvent(actor, { reason: `${title}: 66 again`, modifiers: { extra: level } });
    }
    return { row, roll: total };
  }
  if (spec?.kind === "reroll" && depth > 0 && spec.skip === total) {
    // Ley line Chaos Surge within a Chaos Surge: roll again for a benefit.
    return rollTable(actor, { table, column, title, level, expiry, source, radiusFeet, depth, shield });
  }
  if (spec?.kind === "reroll" && depth > 0) {
    // A wild 66 rolled as one of the two: said, then the next row is applied (the bonus Resonance is the caller's).
    await card(actor, title, lines);
    return { row, roll: total };
  }
  lines.push(...await applyRow(actor, spec, ctx));
  await card(actor, title, lines);
  if (roll) void roll;
  return { row, roll: total };
}

/* ------------------------------------------------------------------ */
/* The three actions                                                    */
/* ------------------------------------------------------------------ */

const plan = (actor) => actor?.getFlag?.(MODULE_ID, PLAN_FLAG) ?? null;
async function setPlan(actor, value) { await actor.setFlag(MODULE_ID, PLAN_FLAG, value); }
const lineLockKey = (regionId) => `leyLine:${regionId}`;

async function chooseLine(actor, action) {
  const token = tokenOf(actor);
  if (!token) return { refused: "place your token on the map first: the ley line must be within 30 feet." };
  const locks = lockouts(actor);
  const lines = (await leyLinesWithin(token, 30)).filter((l) => !(locks[lineLockKey(l.region.id)] && lockedUntil(locks[lineLockKey(l.region.id)], now())));
  if (!lines.length) return { refused: "no ley line within 30 feet that you can perceive (or one you may not manipulate again until tomorrow)." };
  let pick = lines[0];
  if (lines.length > 1) {
    const id = await h().chooseFromList(action, "Which ley line?", lines.map((l, i) => [String(i), `${l.name || "Ley line"} — level ${l.level} (${leyBand(l.level).title}), ${l.feet} ft`]));
    if (id === null || id === undefined) return { refused: "no ley line chosen." };
    pick = lines[int(id)];
  }
  return { pick };
}

/** Tap Ley Line's DC: the line's level DC, the Hard step being the action's. */
export async function resolveTapDC({ actor }) {
  const chosen = await chooseLine(actor, "Tap Ley Line");
  if (chosen.refused) return chosen;
  const l = chosen.pick;
  // AN ANCHORED LINE (0.12.0, Block 8b's Leyline Anchor; Q179): another
  // caster's check against the anchor first; a failure stops it (1 AP spent).
  { const { anchorTapGate } = await import("./block8b-automations.mjs"); const gate = await anchorTapGate(actor, l.region.id, "Tap Ley Line", 1); if (gate) return gate; }
  await setPlan(actor, { action: "tapLeyLine", regionId: l.region.id, level: l.level, name: l.name, at: now() });
  return { dc: h().levelDC(l.level), label: `${l.name || "Ley line"}'s level DC (level ${l.level}, ${leyBand(l.level).title})` };
}

/** Channel Ley Line's DC: the same, Very Hard. */
export async function resolveChannelDC({ actor }) {
  const chosen = await chooseLine(actor, "Channel Ley Line");
  if (chosen.refused) return chosen;
  const l = chosen.pick;
  { const { anchorTapGate } = await import("./block8b-automations.mjs"); const gate = await anchorTapGate(actor, l.region.id, "Channel Ley Line", 0); if (gate) return gate; }
  await setPlan(actor, { action: "channelLeyLine", regionId: l.region.id, level: l.level, name: l.name, at: now() });
  return { dc: h().levelDC(l.level), label: `${l.name || "Ley line"}'s level DC (level ${l.level}, ${leyBand(l.level).title})` };
}

/** Tap Magical Energy's DC: the charged item's level DC (C3). */
export async function resolveSiphonDC({ actor }) {
  const charged = Array.from(actor?.items ?? []).filter((i) => i.flags?.[SYSTEM_ID]?.chargedItem);
  if (!charged.length) return { refused: "you carry no charged item (a wand, staff, rod or orb) to draw from." };
  const id = charged.length === 1 ? charged[0].id : await h().chooseFromList("Tap Magical Energy", "Draw from which item?", charged.map((i) => [i.id, `${i.name} (${int(i.system?.uses)} PP)`]));
  const item = charged.find((i) => i.id === id);
  if (!item) return { refused: "no item chosen." };
  const level = Math.max(1, int(await h().chargedItemLevelOf(item)));
  await setPlan(actor, { action: "tapMagicalEnergy", itemId: item.id, level, at: now() });
  return { dc: h().levelDC(level), label: `${item.name}'s level DC (item level ${level})` };
}

/**
 * Ley Sense (Block 1's action) reads the map (Graham's M5: Chapter 7's table
 * is the default DC, the GM may override it in the roll dialog). "The more
 * powerful the ley line, the easier it is to detect": the DC is the easiest
 * Sense DC among the lines within 1000 feet (a Critical's reach), or the
 * hardest band's (30) when there is none — so the DC itself gives nothing away.
 */
export async function resolveLeySenseDC({ actor }) {
  const token = tokenOf(actor);
  if (!token) return null;
  const found = await leyLinesWithin(token, 1000);
  await setPlan(actor, { action: "leySense", lines: found.map((l) => ({ name: l.name, level: l.level, feet: l.feet, direction: l.direction })), at: now() });
  const dc = found.length ? Math.min(...found.map((l) => leyBand(l.level).senseDC)) : leyBand(1).senseDC;
  return { dc, label: "Ley Sense DC (Chapter 7, from the map)" };
}

/** What Ley Sense finds: Success, the nearest line within 500 ft and its direction; Critical, every line within 1000 ft and its strength. */
export async function leySenseFindings(actor, degree) {
  const p = plan(actor);
  if (!p || p.action !== "leySense") return;
  await actor.unsetFlag(MODULE_ID, PLAN_FLAG);
  const k = String(degree);
  if (!["heroic", "critical", "success"].includes(k)) return;
  const lines = Array.from(p.lines ?? []);
  const where = (l) => (l.feet === 0 ? "here" : `${l.feet} ft ${l.direction}`);
  if (k === "success") {
    const near = lines.filter((l) => l.feet <= 500).sort((a, b) => a.feet - b.feet)[0];
    return card(actor, "Ley Sense", [line(near ? `The nearest ley line: <strong>${esc(near.name || "a ley line")}</strong>, ${where(near)}.` : "No ley line within 500 feet."), line("<em>Arcane anomalies beyond the map's ley lines are the GM's to tell.</em>")]);
  }
  return card(actor, "Ley Sense", [
    line(lines.length ? "Every ley line within 1000 feet:" : "No ley line within 1000 feet."),
    ...lines.map((l) => line(`<strong>${esc(l.name || "A ley line")}</strong>: ${where(l)}, ${leyBand(l.level).title} (level ${l.level}).`)),
    line("<em>Arcane anomalies and disturbances are the GM's to tell.</em>")
  ]);
}

/** trgPrimeActionAttempt: ranks and lockouts, before anything is spent. */
export function onActionAttemptB2({ actor, action } = {}) {
  const own = SKILL_ACTIONS.find((a) => a.key === action?.key);
  if (!own || !actor) return true;
  if (own.minRanks) {
    const ranks = int(actor.system?.skills?.powerManipulation?.ranks);
    if (ranks < own.minRanks) return warn(`${own.name}: requires ${own.minRanks} ranks in Power Manipulation (you have ${ranks}).`);
  }
  const lockedRow = lockouts(actor)[own.key];
  if (lockedRow && lockedUntil(lockedRow, now())) {
    const minutes = Math.ceil((Number(lockedRow.until) - now()) / 60);
    return warn(`${own.name}: you cannot attempt it again for ${minutes} more minute${minutes === 1 ? "" : "s"}.`);
  }
  return true;
}

/** The ley line's benefits (M6): a roll on the Effect column, lasting as the action says. */
async function leyBenefits(actor, level, expiry, title) {
  const out = await rollTable(actor, { table: LEY_LINE_EFFECTS, column: "e", title, level, expiry, source: "leyLineEffect" });
  await markLeyBenefit(actor, { level, name: title, expiry });
  return out;
}

/**
 * LEY-ETCHED SYMBOL READS THIS (0.9.0, Block 6; Appendix C N6, Q125): "while
 * gaining the benefits of a ley line" is a benefit from Tap or Channel Ley
 * Line (or Leyline Weaver's Tap), for its duration. The marker is laid only
 * for a character who owns the feat, so nobody else's sheet gains an effect.
 * Imported lazily: block6c-automations imports this file.
 */
async function markLeyBenefit(actor, { level, name, expiry }) {
  if (!Array.from(actor?.items ?? []).some((i) => i?.type === "feat" && String(i.name ?? "").trim().toLowerCase() === "ley-etched symbol")) return;
  const { layLeyBenefitMarker } = await import("./block6c-automations.mjs");
  await layLeyBenefitMarker(actor, { level, name, expiry });
}

/** trgPrimeActionResolved: what each degree does. */
export async function onActionResolvedB2(ctx = {}) {
  const { actor, action, degree } = ctx;
  if (action?.key === "leySense" && actor?.isOwner) return leySenseFindings(actor, printedDegree({ outcomes: { critical: "x", success: "x", failure: "x", fumble: "x" } }, degree));
  const own = SKILL_ACTIONS.find((a) => a.key === action?.key);
  if (!own || !actor || !degree || !actor.isOwner) return;
  const p = plan(actor);
  if (!p || p.action !== own.key) return;
  await actor.unsetFlag(MODULE_ID, PLAN_FLAG);
  const k = printedDegree(own, degree);
  const L = int(p.level);
  if (own.key === "tapLeyLine") {
    const title = `Tap Ley Line — ${p.name || "ley line"} (level ${L})`;
    // LEYLINE WEAVER (0.9.0, Block 6; Q113): its own ladder replaces the
    // Critical, Success and Partial results. Imported lazily, as above.
    const weaver = await import("./block6b1-automations.mjs");
    if (await weaver.leylineWeaverTap(actor, { degree: k, level: L, title })) {
      const rung = weaver.leylineWeaverRung(k);
      if (rung) await markLeyBenefit(actor, { level: L, name: `${title} (Leyline Weaver)`, expiry: expiryFor(rung.expiry, actor) });
      return;
    }
    if (k === "critical") return leyBenefits(actor, L, expiryFor("endOfNextTurn", actor), `${title}: until the end of your next turn`);
    if (k === "success") return leyBenefits(actor, L, expiryFor("endOfTurn", actor), `${title}: until the end of your turn`);
    if (k === "partial") return card(actor, title, [line("No effect.")]);
    if (k === "failure" || k === "fumble") {
      const lines = await hurt(actor, actor, { formula: scaled("1d6 x level", Math.max(1, L)), type: "force", save: "will", label: `${title} — backfire (1d6 × ${L})` });
      await lock(actor, "tapLeyLine", k === "fumble" ? 86400 : 3600);
      lines.push(line(`You cannot Tap the Ley Line again for <strong>${k === "fumble" ? "24 hours" : "1 hour"}</strong>.`));
      await card(actor, title, lines);
      if (k === "fumble") await rollTable(actor, { table: LEY_LINE_EFFECTS, column: "b", title: `${title}: backlash`, level: L, expiry: expiryFor("endOfNextTurn", actor), source: "leyLineBacklash" });
    }
    return;
  }
  if (own.key === "channelLeyLine") {
    const title = `Channel Ley Line — ${p.name || "ley line"} (level ${L}, ${leyBand(L).name})`;
    const dice = channelDice(L);
    const ability = int(actor.system?.resources?.pp?.abilityBonus);
    const { total } = await rollFormula(dice);
    const amount = total + ability;
    const lines = [line(`${dice} = ${total}, + ${ability} (casting tradition ability) = <strong>${amount}</strong>.`)];
    if (["heroic", "critical", "success"].includes(k)) {
      const before = ppOf(actor).value;
      const after = await setPP(actor, before + amount);
      lines.push(line(`PP <strong>${before} → ${after}</strong>${before + amount > after ? " (the excess is lost)" : ""}.`));
      await card(actor, title, lines);
      if (k === "heroic") await leyBenefits(actor, L, forSeconds(60), `${title}: for 1 minute`);
      if (k === "critical") await leyBenefits(actor, L, expiryFor("endOfNextTurn", actor), `${title}: until the end of your next turn`);
      return;
    }
    const times = channelDamageMultiplier(k);
    if (times) {
      lines.push(...await hurt(actor, actor, { amount: amount * times, type: "essence", save: "fortitude", label: `${title} — the essence turns on you${times > 1 ? ` (×${times})` : ""}` }));
      if (k === "blunder") {
        const tomorrow = (dayOf(now()) + 1) * 86400;
        await lock(actor, lineLockKey(p.regionId), Math.max(1, tomorrow - now()));
        lines.push(line("You may not manipulate this ley line again <strong>until the following day</strong>."));
      }
    }
    return card(actor, title, lines);
  }
  if (own.key === "tapMagicalEnergy") {
    const item = actor.items.get(p.itemId);
    const title = `Tap Magical Energy — ${item?.name ?? "the item"}`;
    if (!item) return card(actor, title, [line("<em>The item is gone.</em>")]);
    const cl = int(actor.system?.magic?.casterLevelValue ?? actor.system?.magic?.casterLevel); // the resolved value (found in review)
    const { siphon, itemLoses } = siphonFor(k, cl);
    const lines = [];
    let loses = itemLoses;
    if (typeof loses === "string") { const r = await rollFormula(loses); loses = r.total; }
    if (k === "fumble" || k === "blunder") lines.push(...await hurt(actor, actor, { formula: `${L}d6`, type: "force", save: "fortitude", label: `${title} — the essence lashes out (1d6 × ${L})` }));
    if (siphon > 0) {
      const before = ppOf(actor).value;
      const after = await setPP(actor, before + siphon);
      const gained = after - before;
      lines.push(line(`You siphon <strong>${siphon} PP</strong> (${k === "partial" ? "1 per 4" : "1 per 2"} caster levels, CL ${cl}): PP ${before} → ${after}${gained < siphon ? " (capped at your maximum)" : ""}. <em>Spend it before the end of your next turn.</em>`));
      if (gained > 0) {
        await h().createEffectsOn(actor, [effectData("siphonedEssence", { name: `Siphoned essence (${gained} PP)`, img: "icons/magic/light/orb-lightbulb-gray.webp", description: "Tap Magical Energy: these PP dissipate at the end of your next turn if unspent.", module: { siphon: gained, before }, expiry: expiryFor("endOfNextTurn", actor) })]);
      }
    } else if (["critical", "success", "partial"].includes(k)) lines.push(line(`Caster level ${cl}: nothing to siphon.`));
    const had = int(item.system?.uses);
    if (loses > 0) {
      await item.update({ "system.uses": Math.max(0, had - loses) });
      lines.push(line(`${esc(item.name)} loses <strong>${loses} PP</strong>: ${Math.max(0, had - loses)} left.`));
    }
    await card(actor, title, lines);
    if (k === "blunder") await h().rollItemDepletion(actor, item);
  }
}

/** deleteActiveEffect: siphoned essence dissipates; what is left above the pool before it goes. */
export async function onEffectDeletedB2(effect) {
  if (effect?.getFlag?.(MODULE_ID, "source") !== "siphonedEssence") return;
  const actor = effect.parent;
  if (!actor || actor.documentName !== "Actor") return;
  // ONE WRITER (found in review): the acting GM, or the owner if no GM is on.
  if (!(game.user?.isGM ? isActingGM() : (actor.isOwner && !game.users?.activeGM))) return;
  const { siphon, before } = effect.getFlag(MODULE_ID) ?? {};
  const lost = unspentSiphon({ siphon, before, current: ppOf(actor).value });
  if (!lost) return;
  const after = await setPP(actor, ppOf(actor).value - lost);
  await card(actor, "Tap Magical Energy", [line(`The unspent siphoned essence dissipates: <strong>${lost} PP</strong> lost (PP ${after}).`)]);
}

/* ------------------------------------------------------------------ */
/* Casting in Chapter 7's areas                                         */
/* ------------------------------------------------------------------ */

const casterToken = (actor) => tokenOf(actor);

/** Spell-check gate: a Suppression area's penalty, equal to its level. */
export async function suppressionGate(ctx = {}) {
  if (!ctx.rollsCheck) return null;
  const area = await strongestAreaAt(casterToken(ctx.actor), "suppression");
  if (!area) return null;
  return { modifiers: [{ label: `Magic Suppression (level ${area.level})`, value: -area.level, type: "untyped" }], lines: [`<em>${esc(area.name || "A Magic Suppression area")}: ${suppressionBand(area.level).title}, −${area.level} to the casting check.</em>`] };
}

/** D7: Partial, Failure and Fumble read as Failure; Blunder as Fumble. */
export async function suppressionRemap(ctx = {}) {
  const next = SUPPRESSED_DEGREE[ctx.degree];
  if (!next) return null;
  const area = await strongestAreaAt(casterToken(ctx.actor), "suppression");
  if (!area) return null;
  return { degree: next, lines: next === ctx.degree ? [] : [`<em>Magic Suppression: the ${ctx.degree} is read as a ${next} ("magic simply does not work in these areas").</em>`] };
}

/** D6: no Resonance events in a Suppression area. */
export async function suppressionResonance(ctx = {}) {
  const area = await strongestAreaAt(casterToken(ctx.actor), "suppression");
  return area ? `${area.name || "a Magic Suppression area"} (level ${area.level}): "Magical Resonance events simply do not exist in areas of suppression"` : null;
}

/** D7: antimagic refuses every casting, innate included (Q6). */
export async function antimagicRefusal(ctx = {}) {
  const area = await strongestAreaAt(casterToken(ctx.actor), "suppression");
  if (!area || !isAntimagic(area.level)) return null;
  return `${ctx.actor?.name ?? "This creature"} is inside an antimagic zone (${area.name || "level " + area.level}): no spell or magical ability functions there.`;
}

/** A surcharge from the ley line and wild surge rows: "next spell +1 PP", "all spells +PP for 1 minute". */
export async function chapter7Surcharge(ctx = {}) {
  const effects = Array.from(ctx.actor?.effects ?? []).filter((e) => !e.disabled && e.getFlag?.(MODULE_ID, "source"));
  let pp = 0;
  for (const e of effects) pp += int(e.getFlag(MODULE_ID, "nextSpellSurcharge")) + int(e.getFlag(MODULE_ID, "spellSurcharge"));
  if (!pp) return null;
  // The "next spell" one is spent when a spell is cast (onSpellSettledB2), not
  // when it is asked: a casting refused after this costs nothing (found in review).
  return { pp, label: "Chapter 7 (ley line or wild surge)" };
}

/**
 * A Wild Magic area surges (M7): a casting check of Partial or worse, or chaos.
 * After the casting is settled, so a PP row cannot race its payment (found in
 * review); and on an item's release check (Q7), whose spell then casts with no
 * check of its own.
 */
export async function wildSurgeFor(actor, { degree, chaos = false, rollsCheck = true } = {}) {
  if (!rollsCheck || !surges(degree, chaos)) return null;
  const area = await strongestAreaAt(casterToken(actor), "wildMagic");
  if (!area) return null;
  const title = `Wild Surge — ${area.name || "Wild Magic area"} (level ${area.level})`;
  return rollTable(actor, { table: WILD_SURGE, column: "e", title, level: area.level, expiry: forSeconds(6 * area.level), source: "wildSurge", radiusFeet: 5 * area.level });
}

/** trgPrimeReleaseRolled (TRG Prime 3.678.0): a scroll's or a wand's release check. */
export async function onReleaseRolledB2(ctx = {}) {
  if (!ctx.actor?.isOwner) return;
  await wildSurgeFor(ctx.actor, { degree: ctx.degree, chaos: ctx.chaos, rollsCheck: true });
}

/** trgPrimeSpellSettled: the surge, the spent "next spell" PP, and a Suppression area's backlash. */
export async function onSpellSettledB2(ctx = {}) {
  const { actor, degree, spell, ppSpent, innate } = ctx;
  if (!actor?.isOwner) return;
  if (ctx.cast && !ctx.refunded) {
    const next = Array.from(actor.effects ?? []).filter((e) => int(e.getFlag?.(MODULE_ID, "nextSpellSurcharge")));
    if (next.length) await actor.deleteEmbeddedDocuments("ActiveEffect", next.map((e) => e.id));
  }
  await wildSurgeFor(actor, { degree, chaos: ctx.chaos, rollsCheck: ctx.rollsCheck === true });
  if (innate || ctx.refunded) return;
  if (!["failure", "fumble"].includes(String(degree))) return;
  const area = await strongestAreaAt(casterToken(actor), "suppression");
  if (!area?.backlash) return;
  const ppLost = Math.max(0, int(spell?.system?.ppCost) - int(ppSpent));
  await rollTable(actor, { table: SUPPRESSION_BACKLASH, column: "e", title: `Suppression backlash — ${area.name || "Magic Suppression area"} (level ${area.level})`, level: area.level, expiry: forSeconds(6 * area.level), source: "suppressionBacklash", ppLost });
}

/* ------------------------------------------------------------------ */
/* Antimagic: who stands inside, and what is switched off               */
/* ------------------------------------------------------------------ */

/**
 * The actors (by uuid: an unlinked token's actor is its own, found in review)
 * whose token stands in an antimagic zone. Read synchronously by the effect
 * suppressor.
 */
export const antimagicOccupants = new Set();

/** The kinds of item that are not magic items: what a creature IS or suffers, not what it carries. */
const NOT_MAGIC_ITEMS = Object.freeze(["race", "heritage", "class", "background", "feat", "ability", "archetype", "spell", "origin", "skill", "divine-aspect", "wizard-school", "affliction", "creature-type"]);

/**
 * D14: inside an antimagic zone "magic items lose all properties" and
 * "permanent magical effects are suppressed": an effect carried by an item
 * that is not part of the creature itself, and an effect a spell placed.
 */
export function antimagicSuppresses(effect) {
  const parent = effect?.parent;
  const actor = parent?.documentName === "Item" ? parent.parent : parent;
  if (!actor?.uuid || !antimagicOccupants.has(actor.uuid)) return false;
  if (parent?.documentName === "Item") return !NOT_MAGIC_ITEMS.includes(parent.type);
  // A SPELL'S, NOT ANY TIMED EFFECT'S (found in review): `spellEffect` is the
  // system's world-clock marker on poisons, perils and more.
  const f = effect?.flags?.[SYSTEM_ID] ?? {};
  return Boolean(f.spellBuff || f.castId);
}

/** Recompute who stands in antimagic, and refresh any actor whose answer changed. */
export async function refreshAntimagic({ announce = true } = {}) {
  const inside = new Set();
  const byUuid = new Map();
  for (const token of tokensOnScene()) {
    byUuid.set(token.actor.uuid, token.actor);
    const area = await strongestAreaAt(token, "suppression");
    if (area && isAntimagic(area.level)) inside.add(token.actor.uuid);
  }
  const changed = new Set([...inside].filter((id) => !antimagicOccupants.has(id)).concat([...antimagicOccupants].filter((id) => !inside.has(id))));
  antimagicOccupants.clear();
  for (const id of inside) antimagicOccupants.add(id);
  for (const id of changed) {
    const actor = byUuid.get(id) ?? globalThis.fromUuidSync?.(id) ?? null;
    if (!actor) continue;
    actor.reset?.();
    actor.sheet?.rendered && actor.sheet.render(false);
    const actingGM = isActingGM();
    if (announce && actingGM && inside.has(id)) await card(actor, "Antimagic zone", [line(`${esc(actor.name)} is inside an antimagic zone: no spell or magical ability functions, and the effects of magic items and spells are suppressed until they leave.`), line("<em>Not automated: a wondrous item's bonuses (worked out from the item, not from an effect) — take them off by hand while inside.</em>")]);
  }
  return changed;
}

export const AREA_TYPE_KEYS = Object.freeze(Object.values(AREA_TYPES));

/**
 * Ley Line Connection (Scaelyn): "When casting High Magic spells, reduce the
 * Casting DC by 1." The gate is told whether the cast is High Magic (TRG Prime
 * 3.678.0); a lower DC is the same as +1 on the check against it, and it is
 * the casting's DC only, not an attack spell's attack (B1-5, as Null Aura).
 */
export async function leyLineConnectionGate(ctx = {}) {
  if (!ctx.highMagic || !ctx.rollsCheck) return null;
  const has = Array.from(ctx.actor?.items ?? []).some((i) => i.type === "ability" && norm(i.name) === "ley line connection" && i.system?.active !== false);
  if (!has) return null;
  return { modifiers: [{ label: "Ley Line Connection (High Magic casting DC −1)", value: 1, type: "untyped", castingOnly: true }] };
}
