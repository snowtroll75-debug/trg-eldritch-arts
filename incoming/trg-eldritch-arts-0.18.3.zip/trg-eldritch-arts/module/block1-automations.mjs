/**
 * Eldritch Arts Block 1 (0.1.0) — what Chapter 2's abilities and heritages,
 * the background feats and Chapter 4's actions DO once used.
 *
 *   Uses        Ethereal Form, Elemental Symbiosis, Innate Magic, Glyphweave,
 *               Wyrmdral, Vir-ellian Release, Magic Drain, Elemental
 *               Affinity, Wanderer's Instinct
 *   Gate        Null Aura's casting-DC rise, on every Spellcraft check made
 *               within the aura (TRG Prime 3.672.0's spell-check gate)
 *   Surcharge   Zhal-vryn's extra PP (TRG Prime 3.675.0, C3)
 *   Path        Lingual Casting's way to read a scroll (3.675.0, C6)
 *   Hooks       the actions' outcomes, lockouts and lock-ins; daily
 *               preparation; Elemental Symbiosis's weakness; a reminder on
 *               spells cast at a Nyrinn
 *
 * Everything a race, heritage or feat grants unconditionally lives on the
 * pack item as data (effects, conditionals, declarations); only choices and
 * activations are here. System helpers come from
 * `game.trgPrime.modules.helpers` at call time, so the pure parts at the top
 * load in the harness without Foundry.
 */

import { isActingGM } from "./writer.mjs";
import { SKILL_ACTIONS, SKILL_ACTION_KEYS } from "./block1-actions.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";

const norm = (v) => String(v ?? "").trim().toLowerCase();
const int = (v) => Math.trunc(Number(v) || 0);
const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c]));

/* ------------------------------------------------------------------ */
/* Pure decisions                                                       */
/* ------------------------------------------------------------------ */

/** Wyrmdral's "acid, cold, electricity, fire or poison". */
export const WYRMDRAL_ELEMENTS = Object.freeze(["acid", "cold", "electricity", "fire", "poison"]);
/** Elemental Affinity's "fire, cold, electricity, acid, or sonic". */
export const AFFINITY_ELEMENTS = Object.freeze(["fire", "cold", "electricity", "acid", "sonic"]);
/** Magic Drain's "+1 racial bonus to AB, DB, saving throws or skill checks". */
export const DRAIN_TARGETS = Object.freeze([["attack", "AB (attack checks)"], ["defence", "DB"], ["save", "Saving throws"], ["skill", "Skill checks"]]);
/** "one magical effect or charged magic item". */
export const DRAIN_WHAT = Object.freeze([["effect", "A magical effect (negated)"], ["item", "A charged item (loses 1d4 PP)"]]);
/** The drainer's choices, made before the roll (Magic Drain's Use). */
export const DRAIN_PLAN_FLAG = "drainPlan";

/**
 * The degree the printed ladder answers (found in review). The system
 * falls back from a rung the action does not print — a Partial reads as the
 * Failure, a Blunder as the Fumble, a Heroic as the Critical — and so must
 * the module, or a Ley Sense Partial would show "Failure" and lock nothing.
 */
const PRINTED_FALLBACK = Object.freeze({
  heroic: ["heroic", "critical", "success"], critical: ["critical", "success"], success: ["success"],
  partial: ["partial", "failure"], failure: ["failure"], fumble: ["fumble", "failure"], blunder: ["blunder", "fumble", "failure"]
});
export function printedDegree(action, degree) {
  const k = String(degree ?? "").trim().toLowerCase();
  const chain = PRINTED_FALLBACK[k] ?? [k];
  return chain.find((d) => String(action?.outcomes?.[d] ?? "").trim()) ?? k;
}

/** The Null Aura's reach: 10 feet for a Vel-tharis, 5 for any other holder, 0 without it. */
export function nullAuraFeet(items = []) {
  const list = Array.from(items ?? []);
  const holds = list.some((i) => i?.type === "ability" && norm(i.name) === "null aura");
  if (!holds) return 0;
  const her = list.find((i) => i?.type === "heritage");
  const fromHeritage = int(her?.flags?.[SYSTEM_ID]?.eaNullAuraFeet);
  // A FEAT MAY WIDEN IT (0.8.0): Silent Veil's `eaNullAuraBonus`, counted as
  // Block 5's nullAuraBonusFeet counts it (inline, so Block 1 imports nothing).
  const bonus = list.filter((i) => i?.type === "feat").reduce((n, i) => n + Math.max(0, int(i.flags?.[SYSTEM_ID]?.eaNullAuraBonus)), 0);
  return Math.max(5, fromHeritage) + bonus;
}

/** A Zhal-vryn's surcharge (1), or 0. */
export function auraSurcharge(items = []) {
  const her = Array.from(items ?? []).find((i) => i?.type === "heritage");
  return nullAuraFeet(items) ? Math.max(0, int(her?.flags?.[SYSTEM_ID]?.eaCastSurcharge)) : 0;
}

/**
 * Magic Drain's energy. "Critical … energy equal to the drained PP (max your
 * level × 2). Success … half the drained PP." A Vir-ellian drains its class
 * bonus more. Half rounds down (the core's default).
 *
 * @returns {{drained: number, energy: number}}
 */
export function magicDrainEnergy({ degree, drained = 0, level = 0, extra = 0 } = {}) {
  const total = Math.max(0, int(drained) + Math.max(0, int(extra)));
  const cap = Math.max(0, int(level) * 2);
  const k = norm(degree);
  if (["heroic", "critical"].includes(k)) return { drained: total, energy: Math.min(cap, total) };
  if (k === "success") return { drained: total, energy: Math.min(cap, Math.floor(total / 2)) };
  return { drained: 0, energy: 0 };
}

/**
 * Hypnotism's Memory Recall bonus by degree: "+4 circumstance", Heroic "an
 * additional +4", Partial "only a +2".
 */
export function memoryRecallBonus(degree) {
  const k = norm(degree);
  if (k === "heroic") return 8;
  if (["critical", "success"].includes(k)) return 4;
  if (k === "partial") return 2;
  return 0;
}

/** Hypnotism's suggestion duration by degree, in seconds (Success: as the Suggestion spell). */
export function suggestionSeconds(degree) {
  const k = norm(degree);
  if (k === "heroic") return 3600;
  if (k === "critical") return 1800;
  if (k === "partial") return 300;
  return null;
}

/** Quickbind's time by degree; null when the item is not invested. */
export function quickbindMinutes(degree) {
  const k = norm(degree);
  if (["heroic", "critical"].includes(k)) return 1;
  if (k === "success") return 5;
  if (["partial", "failure"].includes(k)) return 10;
  return null;
}

/**
 * Lingual Casting's way to read a scroll (TRG Prime 3.675.0, C6):
 *   - Very Hard (DC +5)
 *   - ranks equal to the spell's PP in its tradition skill ("or all 4 for High Magic")
 *   - Linguistics ranks equal to the spell's PP + 2
 * Offered on every scroll; unavailable, with the reason, when a rank falls short.
 */
const TRADITION_SKILLS = Object.freeze({ arcane: "arcana", divinity: "religion", ethereal: "occultism", verdant: "nature" });
export function lingualCastingOption({ spellPPCost = 0, spellTradition = "", skillRanks = {}, highMagic = false } = {}) {
  const pp = Math.max(0, int(spellPPCost));
  const ranks = (k) => Math.max(0, int(skillRanks?.[k]));
  const traditions = String(spellTradition ?? "").split(/[,/]/).map(norm).filter((t) => TRADITION_SKILLS[t]);
  const reasons = [];
  if (ranks("linguistics") < pp + 2) reasons.push(`your Linguistics ranks (${ranks("linguistics")}) are below the spell's PP + 2 (${pp + 2})`);
  if (highMagic) {
    const short = Object.values(TRADITION_SKILLS).filter((k) => ranks(k) < pp);
    if (short.length) reasons.push(`a High Magic scroll needs ${pp} ranks in all four tradition skills (short: ${short.join(", ")})`);
  } else if (!traditions.length) {
    reasons.push("the spell names no tradition, so the appropriate tradition skill is the GM's to name");
  } else if (!traditions.some((t) => ranks(TRADITION_SKILLS[t]) >= pp)) {
    reasons.push(`no tradition skill of the spell (${traditions.map((t) => TRADITION_SKILLS[t]).join(" or ")}) has ${pp} ranks`);
  }
  return { key: "lingualCasting", label: "Lingual Casting (Linguistics)", skill: "linguistics", difficulty: "veryHard", dcAdjustment: 5, available: reasons.length === 0, reason: reasons.join("; ") };
}

/** Is a lockout still in force? `{until}` is world time in seconds. */
export function lockedUntil(record, worldTime) {
  return Boolean(record && Number(record.until ?? 0) > Number(worldTime ?? 0));
}

/** The world-time day number, for "once per item per day". */
export const dayOf = (worldTime) => Math.floor(Math.max(0, Number(worldTime) || 0) / 86400);

/* ------------------------------------------------------------------ */
/* Foundry side: small steps                                            */
/* ------------------------------------------------------------------ */

function helpers() {
  const h = globalThis.game?.trgPrime?.modules?.helpers;
  if (!h) throw new Error("Eldritch Arts: TRG Prime's module helpers are not available.");
  return h;
}
const h = () => helpers();
const line = (text) => h().line(text);
const card = (actor, title, lines) => h().postCard(actor, title, lines);
const warn = (text) => { globalThis.ui?.notifications?.warn(text); return false; };
const now = () => Number(globalThis.game?.time?.worldTime ?? 0);
const levelOf = (actor) => int(actor?.system?.identity?.level);
const classBonusOf = (actor) => Math.max(0, int(actor?.system?.identity?.classBonus));
const owned = (actor, name, types = ["feat", "ability"]) => Array.from(actor?.items ?? []).find((i) => types.includes(i.type) && norm(i.name) === norm(name)) ?? null;
const heritageOf = (actor) => Array.from(actor?.items ?? []).find((i) => i.type === "heritage") ?? null;
const tokenOf = (actor) => { try { return actor?.getActiveTokens?.()?.[0] ?? null; } catch { return null; } };
/**
 * IN THE RUNNING COMBAT (0.7.1, from the 0.7.0 live test): with an actor, only
 * when it is one of the running combat's combatants. Asked of any combat, a
 * creature outside the GM's fight was charged AP and reactions it does not have.
 */
const inCombat = (actor = null) => (actor ? Boolean(combatFor(actor)) : Boolean(globalThis.game?.combat?.started));

/** Spend AP in combat, refusing if there is not enough. */
async function spendAP(actor, label, ap = 1) {
  if (!inCombat(actor) || ap <= 0) return true;
  const have = int(actor.system?.resources?.ap?.value);
  if (have < ap) return warn(`${label}: ${ap} AP required.`);
  await actor.update({ "system.resources.ap.value": have - ap });
  return true;
}

/** Whether a tracked use remains, and spending it. */
function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item, label, refill = "daily preparation") {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return warn(`${label}: no uses remain — ${refill} restores it.`);
  await item.update({ "system.usesValue": left - 1 });
  return true;
}

/** Distance in feet between two tokens (nearest squares), or null. */
/**
 * A token's centre where it STANDS, not where it is drawn (live test, 0.5.1).
 * On Foundry V14 a moving token's document reads its animated position until
 * the animation ends, `updateToken` included; the destination is in its
 * source. So every range checked as a token moved (Ley Tap, the Soulbound
 * Familiar's 30 ft, a Null Aura) was one move behind. Block 2's areas read
 * the source already. A token without a source (the harness's) keeps `center`.
 */
function tokenCentre(t) {
  // THE STORED POSITION FIRST, then the document, then the drawn token
  // (0.11.2): in V14's updateToken the source already holds the move's end
  // while the document's getters and the placeable still lag.
  const d = t?.document;
  const s = d?._source ?? (d && Number.isFinite(Number(d.x)) && Number.isFinite(Number(d.y)) ? d : null);
  if (s && Number.isFinite(Number(s.x)) && Number.isFinite(Number(s.y))) {
    const at = { x: Number(s.x), y: Number(s.y) };
    if (typeof t.getCenterPoint === "function") {
      try { const c = t.getCenterPoint(at); if (Number.isFinite(c?.x) && Number.isFinite(c?.y)) return { x: c.x, y: c.y }; } catch { /* the fallback below */ }
    }
    const size = Number(globalThis.canvas?.grid?.size ?? globalThis.canvas?.dimensions?.size ?? 100);
    return { x: at.x + (Math.max(1, Number(s.width ?? 1)) * size) / 2, y: at.y + (Math.max(1, Number(s.height ?? 1)) * size) / 2 };
  }
  return { x: t.center.x, y: t.center.y };
}

function feetBetween(a, b) {
  try {
    const grid = Number(canvas?.dimensions?.distance ?? 5);
    const measured = canvas.grid.measurePath([tokenCentre(a), tokenCentre(b)]).distance;
    const reach = ((Math.max(1, Number(a.document?.width ?? 1)) - 1) + (Math.max(1, Number(b.document?.width ?? 1)) - 1)) / 2 * grid;
    return Math.max(0, Math.round(measured - reach));
  } catch {
    return null;
  }
}

/** Every token on the scene whose actor holds a Null Aura reaching `token`, with the aura's owner. */
function aurasReaching(token) {
  const out = [];
  if (!token || !globalThis.canvas?.tokens) return out;
  for (const other of canvas.tokens.placeables ?? []) {
    const actor = other.actor;
    if (!actor) continue;
    const feet = nullAuraFeet(actor.items);
    if (!feet) continue;
    const d = other === token ? 0 : feetBetween(other, token);
    if (d === null || d > feet) continue;
    out.push({ token: other, actor, feet, classBonus: classBonusOf(actor), surcharge: auraSurcharge(actor.items) });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Null Aura — the spell-check gate                                     */
/* ------------------------------------------------------------------ */

/**
 * "All Spellcraft checks made within this aura (including your own) have
 * their casting DC increased by the same amount." The gate can add rows to
 * the check, not change its DC; a penalty of the same size decides every
 * degree the same (B1-5). Overlapping auras do not stack: the largest
 * applies.
 */
export async function nullAuraGate(ctx = {}) {
  // An innate spell's roll is not a Spellcraft check (it is resolved from the
  // magical ability), nor is an item's release; neither is raised.
  if (!ctx.rollsCheck || ctx.itemCast || ctx.innate) return null;
  const token = tokenOf(ctx.actor);
  const auras = aurasReaching(token).filter((a) => a.classBonus > 0);
  if (!auras.length) return null;
  const best = auras.reduce((a, b) => (b.classBonus > a.classBonus ? b : a));
  return {
    // ON THE CASTING DC ONLY (TRG Prime 3.675.0; found in review): an attack
    // spell's attack against DB does not take it.
    modifiers: [{ label: `Null Aura (${best.actor.name})`, value: -best.classBonus, type: "untyped", castingOnly: true }],
    lines: [`<strong>Null Aura</strong> (${esc(best.actor.name)}): casting DC +${best.classBonus}, applied as −${best.classBonus} on the check against it (not on a spell attack against DB).`]
  };
}

/* ------------------------------------------------------------------ */
/* Zhal-vryn — the surcharge                                            */
/* ------------------------------------------------------------------ */

/**
 * "All creatures within your Null Aura must expend an additional PP to cast
 * spells (including cantrips)." One PP whatever the number of Zhal-vryn
 * auras (an aura's rule is not stacked by repeating it). An item's spell is
 * not asked (the system does not ask for one).
 */
export async function zhalVrynSurcharge(ctx = {}) {
  const token = tokenOf(ctx.actor);
  const auras = aurasReaching(token).filter((a) => a.surcharge > 0);
  if (!auras.length) return null;
  return { pp: 1, label: `Zhal-vryn (${auras[0].actor.name})` };
}

/* ------------------------------------------------------------------ */
/* Lingual Casting — the scroll path                                    */
/* ------------------------------------------------------------------ */

export async function lingualCastingPath(ctx = {}) {
  if (ctx.kind !== "scroll") return null;
  // High Magic arrives with Block 2, which will say which scrolls hold it.
  return lingualCastingOption({ ...ctx, highMagic: false });
}

/* ------------------------------------------------------------------ */
/* The Uses                                                             */
/* ------------------------------------------------------------------ */

const etherealForm = {
  hint: "1/day: become incorporeal for 1 minute.",
  ownsFocusUse: true,
  async use(actor, item) {
    if (!(await spendUse(item, "Ethereal Form"))) return;
    await h().createEffectsOn(actor, [effectData("etherealForm", {
      name: "Ethereal Form: incorporeal",
      img: "icons/svg/invisible.svg",
      description: "Ethereal Form: incorporeal for 1 minute — immune to non-magical attack forms and precision damage, resistant to all damage except force, and able to pass through solid objects.",
      system: { grantedTraits: ["incorporeal"] },
      expiry: forSeconds(60)
    })]);
    await card(actor, "Ethereal Form", [
      line("You become <strong>incorporeal</strong> for 1 minute: immune to non-magical attack forms and precision damage, resistant to all damage except force, and able to pass through solid objects."),
      line("<em>The day's use is spent; daily preparation restores it.</em>")
    ]);
  }
};

const elementalSymbiosis = {
  hint: "Reaction: immunity to your heritage's element until the end of your next turn; then weakness to it for 1 minute.",
  async use(actor, item) {
    const her = heritageOf(actor);
    const element = norm(her?.flags?.[SYSTEM_ID]?.eaElement);
    if (!element) return warn("Elemental Symbiosis: your heritage names no element (add your Emberkin heritage first).");
    if (ownEffects(actor, "symbiosisWeakness").length) return warn("Elemental Symbiosis: you cannot use it again until your weakness ends.");
    if (ownEffects(actor, "symbiosisImmunity").length) return warn("Elemental Symbiosis: your immunity is already up.");
    if (inCombat(actor) && !(await h().spendReaction(actor, "Elemental Symbiosis", { traits: String(item.system?.traits ?? "") }))) return;
    await h().createEffectsOn(actor, [effectData("symbiosisImmunity", {
      name: `Elemental Symbiosis: immune to ${element}`,
      img: "icons/svg/shield.svg",
      description: `Elemental Symbiosis: immunity to ${element} until the end of your next turn. Then weakness to ${element} for 1 minute.`,
      changes: [{ key: "system.combat.immunities", mode: 2, value: `, ${element}`, priority: 20 }],
      module: { element },
      expiry: expiryFor("endOfNextTurn", actor)
    })]);
    await card(actor, "Elemental Symbiosis", [
      line(`You are <strong>immune to ${element}</strong> until the end of your next turn.`),
      line(`<em>When it ends you have weakness to ${element} for 1 minute, and cannot use this again until the weakness ends.</em>`),
      ...(inCombat(actor) ? [line("Reaction spent.")] : [])
    ]);
  }
};

/** deleteActiveEffect: the immunity's end lays the weakness (acting GM, or the owner if no GM). */
export async function onEffectDeletedB1(effect) {
  if (effect?.getFlag?.(MODULE_ID, "source") !== "symbiosisImmunity") return;
  const actor = effect.parent;
  if (!actor || !(game.user?.isGM ? isActingGM() : (actor.isOwner && !game.users?.activeGM))) return;
  const element = norm(effect.getFlag(MODULE_ID, "element"));
  if (!element || ownEffects(actor, "symbiosisWeakness").length) return;
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("symbiosisWeakness", {
    name: `Elemental Symbiosis: weak to ${element}`,
    img: "icons/svg/downgrade.svg",
    description: `Elemental Symbiosis: weakness to ${element} for 1 minute; you cannot use Elemental Symbiosis until it ends.`,
    changes: [{ key: "system.combat.weaknesses", mode: 2, value: `, ${element}`, priority: 20 }],
    module: { element },
    expiry: forSeconds(60)
  })]);
}

const innateMagic = {
  hint: "Choose today's cantrip, from any tradition (cast with Spellcraft).",
  async use(actor, item) {
    return h().chooseSpell(actor, item, { ppCost: 0, note: "Innate Magic (Scaelyn): today's cantrip, cast with your Spellcraft. Choose again after daily preparation if you wish." });
  }
};

const glyphweave = {
  hint: "Glyphweave's additional innate cantrip: choose any cantrip, cast as an innate spell (book v1.6).",
  async use(actor, item) {
    // "AN ADDITIONAL INNATE CANTRIP" (book v1.6, Graham's m5): innate, so the
    // system adds the Focus trait and resolves it from the magical ability.
    return h().chooseSpell(actor, item, { ppCost: 0, innate: true, note: "Glyphweave: your additional innate cantrip (book v1.6). Using Glyphweave again replaces it." });
  }
};

/** Wyrmdral: the element's rows, on the heritage's own effect. */
export function wyrmdralFlags(element) {
  return {
    conditionals: [{ kind: "modifier", value: 1, type: "untyped", label: "Wyrmdral", scope: `Spellcraft checks for spells with the ${element} trait`, auto: true, when: { checkTypes: ["spellcraft"], traits: [element] } }],
    spellDCBonus: { label: "Wyrmdral", value: 1, type: "untyped", traits: [element] }
  };
}

const wyrmdral = {
  hint: "Choose your element: acid, cold, electricity, fire or poison.",
  async use(actor, item) {
    const picked = await h().chooseFromList("Wyrmdral — element", "Your element", WYRMDRAL_ELEMENTS.map((e) => [e, e[0].toUpperCase() + e.slice(1)]));
    const element = norm(picked);
    if (!WYRMDRAL_ELEMENTS.includes(element)) return;
    await h().replaceFeatEffect(actor, item, {
      name: `Wyrmdral: ${element}`,
      img: item.img,
      description: `Wyrmdral (${element}): resistance to ${element}; +1 to Spellcraft checks and to the save DC of spells with the ${element} trait.`,
      changes: [{ key: "system.combat.resistances", mode: 2, value: `, ${element}`, priority: 20 }],
      flags: { [SYSTEM_ID]: wyrmdralFlags(element) }
    });
    await item.setFlag(SYSTEM_ID, "eaElement", element);
    await card(actor, "Wyrmdral", [line(`Your element is <strong>${element}</strong>: resistance to it, and +1 to the Spellcraft check and the save DC of any spell with the ${element} trait.`)]);
  }
};

/** Elemental Affinity: each copy its own element. */
export function affinityFlags(element) {
  return {
    conditionals: [{ kind: "modifier", value: 1, type: "untyped", label: "Elemental Affinity", scope: `Spellcraft checks for spells with the ${element} trait`, auto: true, when: { checkTypes: ["spellcraft"], traits: [element] } }],
    spellDCBonus: { label: "Elemental Affinity", value: 1, type: "untyped", traits: [element] }
  };
}

const elementalAffinity = {
  hint: "Choose this copy's element: fire, cold, electricity, acid or sonic.",
  async use(actor, item) {
    const taken = new Set(Array.from(actor.items ?? [])
      .filter((i) => i.type === "feat" && norm(i.name) === "elemental affinity" && i.id !== item.id)
      .map((i) => norm(i.getFlag(SYSTEM_ID, "eaElement"))).filter(Boolean));
    const open = AFFINITY_ELEMENTS.filter((e) => !taken.has(e));
    if (!open.length) return warn("Elemental Affinity: every element is already chosen by another copy.");
    const picked = norm(await h().chooseFromList("Elemental Affinity — element", "This copy's element", open.map((e) => [e, e[0].toUpperCase() + e.slice(1)])));
    if (!open.includes(picked)) return;
    await h().replaceFeatEffect(actor, item, {
      name: `Elemental Affinity: ${picked}`,
      img: item.img,
      description: `Elemental Affinity (${picked}): +1 to Spellcraft checks and to the save DC of spells with the ${picked} trait.`,
      flags: { [SYSTEM_ID]: affinityFlags(picked) }
    });
    await item.setFlag(SYSTEM_ID, "eaElement", picked);
    await card(actor, "Elemental Affinity", [line(`<strong>${picked}</strong>: +1 to the Spellcraft check and the save DC of any spell with the ${picked} trait.`)]);
  }
};

const wanderersInstinct = {
  hint: "Once a day: advantage on your next Survival check (navigating or tracking where magic runs strong).",
  ownsFocusUse: true,
  async use(actor, item) {
    if (!(await spendUse(item, "Wanderer’s Instinct"))) return;
    await h().replaceFeatEffect(actor, item, {
      name: "Wanderer’s Instinct: advantage ready",
      img: item.img,
      description: "Advantage on your next Survival check to navigate or track in an area infused with magical energy.",
      flags: { [SYSTEM_ID]: { conditionals: [{ kind: "advantage", label: "Wanderer’s Instinct", scope: "Your next Survival check to navigate or track in an area infused with magical energy — tick it on that check", auto: false, oneShot: true, when: { checkTypes: ["skill"], subjects: ["survival"] } }] } }
    }, { dailyPrep: true });
    await card(actor, "Wanderer’s Instinct", [line("<strong>Advantage</strong> is ready for your next Survival check to navigate or track where magic runs strong: tick it on that roll, and it is spent."), line("<em>Today's use is spent.</em>")]);
  }
};

/* Magic Drain: the action, with its Focus use. */
const MAGIC_DRAIN_ACTION = SKILL_ACTIONS.find((a) => a.key === "magicDrain");
const magicDrain = {
  hint: "2 AP (Concentrate, Focus, Warding): drain a magical effect or charged item within 30 feet.",
  ownsFocusUse: true,
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Magic Drain: no uses remain — Refocus restores it.");
    // THE CHOICES ARE THE DRAINER'S (found in review): asked here, before
    // the roll, on the player's own screen. The result may be settled on the
    // GM's (who sets the DC), and reads them from the plan.
    const what = await h().chooseFromList("Magic Drain — the target", "What are you draining?", DRAIN_WHAT);
    if (!what) return;
    const to = await h().chooseFromList("Magic Drain — the energy", "If you drain it, where does the +1 racial go?", DRAIN_TARGETS.map(([v, l]) => [v, l]));
    if (!to) return;
    await actor.setFlag(MODULE_ID, DRAIN_PLAN_FLAG, { what, to });
    return h().resolveAction(actor, MAGIC_DRAIN_ACTION);
  }
};

const virEllianRelease = {
  hint: "1 AP (Concentrate, Focus): release your stored energy — 1d4 force per PP to every creature within 30 feet (basic Will).",
  ownsFocusUse: true,
  async use(actor, item) {
    const stored = ownEffects(actor, "magicDrainEnergy");
    const energy = stored.reduce((sum, e) => sum + int(e.getFlag(MODULE_ID, "energy")), 0);
    if (!energy) return warn("Vir-ellian Release: you hold no energy from Magic Drain.");
    if (usesLeft(item) <= 0) return warn("Vir-ellian Release: no uses remain — Refocus restores it.");
    if (!(await spendAP(actor, "Vir-ellian Release", 1))) return;
    if (!(await spendUse(item, "Vir-ellian Release", "Refocus"))) return;
    const me = tokenOf(actor);
    const targets = me ? (canvas.tokens.placeables ?? []).filter((t) => t !== me && t.actor && (feetBetween(me, t) ?? 99) <= 30).map((t) => t.actor) : [];
    const dc = await h().levelDC(levelOf(actor));
    const lines = targets.length
      ? await h().runAreaEffect(actor, { save: "will", basic: true, dc, damage: { formula: `${energy}d4`, type: "force" }, scope: "targets" }, { title: "Vir-ellian Release", targets })
      : [line("<em>No creature stands within 30 feet.</em>")];
    // Spent once released (found in review: not before, so a release that
    // throws keeps the energy).
    await actor.deleteEmbeddedDocuments("ActiveEffect", stored.map((e) => e.id)).catch(() => {});
    await card(actor, "Vir-ellian Release", [
      line(`You release <strong>${energy} PP</strong> of drained energy: <strong>${energy}d4 force</strong> to every creature within 30 feet, basic Will against DC ${dc}.`),
      ...(lines ?? []),
      line("<em>The energy is spent. Focus use spent — Refocus restores it.</em>")
    ]);
  }
};

export const AUTOMATIONS = Object.freeze({
  "Ethereal Form": etherealForm,
  "Elemental Symbiosis": elementalSymbiosis,
  "Innate Magic": innateMagic,
  Glyphweave: glyphweave,
  Wyrmdral: wyrmdral,
  "Elemental Affinity": elementalAffinity,
  "Wanderer’s Instinct": wanderersInstinct,
  "Magic Drain": magicDrain,
  "Vir-ellian Release": virEllianRelease
});

/* ------------------------------------------------------------------ */
/* The actions: refusals, then outcomes                                 */
/* ------------------------------------------------------------------ */

const LOCK_FLAG = "lockouts";
const lockouts = (actor) => ({ ...(actor?.getFlag?.(MODULE_ID, LOCK_FLAG) ?? {}) });
async function lock(actor, key, seconds) {
  const all = lockouts(actor);
  all[key] = { until: now() + seconds };
  await actor.setFlag(MODULE_ID, LOCK_FLAG, all);
}

/** One subject's Hypnotism lockout, kept with the hypnotist's other lockouts. */
export const hypnotismLockKey = (subject) => `hypnotism:${String(subject?.uuid ?? subject?.id ?? "")}`;

/** trgPrimeActionAttempt (synchronous): a refusal before anything is spent. */
export function onActionAttemptB1({ actor, action, targetActor } = {}) {
  const key = String(action?.key ?? "");
  if (!SKILL_ACTION_KEYS.includes(key) || !actor) return true;
  const own = SKILL_ACTIONS.find((a) => a.key === key);
  if (own?.minRanks) {
    const skill = own.skills[0];
    const ranks = int(actor.system?.skills?.[skill]?.ranks);
    if (ranks < own.minRanks) return warn(`${own.name}: requires ${own.minRanks} ranks in ${skill === "powerManipulation" ? "Power Manipulation" : skill[0].toUpperCase() + skill.slice(1)} (you have ${ranks}).`);
  }
  const lockedRow = lockouts(actor)[key];
  if (lockedRow && lockedUntil(lockedRow, now())) {
    const minutes = Math.ceil((Number(lockedRow.until) - now()) / 60);
    return warn(`${own.name}: you cannot attempt it again for ${minutes} more minute${minutes === 1 ? "" : "s"}.`);
  }
  // Hypnotism's Failure: "the attempt fails but can be retried the next day" — this subject.
  if (key.startsWith("hypnotism") && targetActor) {
    const subject = lockouts(actor)[hypnotismLockKey(targetActor)];
    if (subject && lockedUntil(subject, now())) return warn(`Hypnotism: ${targetActor.name} resisted you; you may try again the next day.`);
  }
  if (key === "magicDrain") {
    const item = owned(actor, "Magic Drain", ["ability"]);
    if (!item) return warn("Magic Drain: requires the Magic Drain ability.");
    if (usesLeft(item) <= 0) return warn("Magic Drain: no uses remain — Refocus restores it.");
  }
  return true;
}

/** trgPrimeActionResolved: what each action does with its degree. */
export async function onActionResolvedB1(ctx = {}) {
  const { actor, action, degree, targetActor } = ctx;
  const key = String(action?.key ?? "");
  if (!SKILL_ACTION_KEYS.includes(key) || !actor || !degree) return;
  if (!(actor.isOwner)) return;
  const k = printedDegree(SKILL_ACTIONS.find((a) => a.key === key), degree);
  switch (key) {
    case "leySense": {
      if (k === "failure") { await lock(actor, key, 600); await card(actor, "Ley Sense", [line("You cannot attempt Ley Sense again for <strong>10 minutes</strong>.")]); }
      if (["fumble", "blunder"].includes(k)) {
        const pp = int(actor.system?.resources?.pp?.value);
        if (pp > 0) await actor.update({ "system.resources.pp.value": pp - 1 });
        await lock(actor, key, 3600);
        await card(actor, "Ley Sense", [line(`Your magical senses are overwhelmed: <strong>1 PP lost</strong>${pp > 0 ? "" : " (you had none)"}, and no Ley Sense for <strong>1 hour</strong>.`)]);
      }
      // What is found is said by Block 2 (0.3.0), from the ley lines on the map.
      return;
    }
    case "mysteriousScript": {
      await lock(actor, key, 7 * 86400);
      await card(actor, "Mysterious Script", [line("<em>Once per week: Mysterious Script is locked for 7 days.</em>"), ...(["heroic", "critical", "success"].includes(k) ? [line(`The GM answers as ${k === "success" ? "Augury" : "Divine Vision"} would.`)] : [])]);
      return;
    }
    case "hypnotismMemory": {
      const bonus = memoryRecallBonus(k);
      if (bonus && targetActor) {
        await h().createEffectsOn(targetActor, [effectData("memoryRecall", {
          name: `Hypnotism: Memory Recall (+${bonus})`,
          img: "icons/svg/eye.svg",
          description: `Hypnotism (Memory Recall): reroll a previously failed Recall Knowledge check about something you once knew or experienced, with a +${bonus} circumstance bonus.`,
          system: { conditionals: [{ kind: "modifier", value: bonus, type: "circumstance", label: "Hypnotism", scope: "The Recall Knowledge reroll the trance allows", auto: true, oneShot: true, when: { actions: ["recallKnowledge"] } }] },
          expiry: forSeconds(3600)
        })]);
        await card(actor, "Hypnotism: Memory Recall", [line(`${esc(targetActor.name)} may reroll a failed Recall Knowledge check at <strong>+${bonus}</strong> circumstance (on its next Recall Knowledge, within the hour).`)]);
      }
      if (k === "failure" && targetActor) await lock(actor, hypnotismLockKey(targetActor), 86400);
      return;
    }
    case "hypnotismSuggestion": {
      if (k === "failure" && targetActor) await lock(actor, hypnotismLockKey(targetActor), 86400);
      const seconds = suggestionSeconds(k);
      if (["heroic", "critical", "success", "partial"].includes(k)) {
        await card(actor, "Hypnotism: Implant Suggestion", [line(`The suggestion takes hold${seconds ? ` for <strong>${seconds >= 3600 ? "1 hour" : `${seconds / 60} minutes`}</strong>` : " as the Suggestion spell's does"}. If the subject later becomes unwilling, it may make a Will save each round to end it (DC = your Diplomacy DC).`)]);
      }
      return;
    }
    case "quickbind": {
      const minutes = quickbindMinutes(k);
      const items = Array.from(actor.items ?? []).filter((i) => i.system?.invested === false && /invested/i.test(String(i.system?.traits ?? "")));
      if (minutes === null) { await card(actor, "Quickbind", [line("You fail to invest the item.")]); return; }
      if (!items.length) { await card(actor, "Quickbind", [line(`The investment takes <strong>${minutes} minute${minutes === 1 ? "" : "s"}</strong>. <em>You carry no uninvested item with the Invested trait; invest it by hand.</em>`)]); return; }
      const pick = await h().chooseFromList("Quickbind — the item", "Which item did you invest?", items.map((i) => [i.id, esc(i.name)]));
      const item = actor.items.get(pick);
      if (!item) return;
      const day = dayOf(now());
      if (int(item.getFlag(MODULE_ID, "quickbindDay")) === day + 1) { await card(actor, "Quickbind", [line(`<em>${esc(item.name)} has already had its Quickbind check today; invest it normally.</em>`)]); return; }
      // INVEST ITEM'S OWN RULES (found in review; TRG Prime 3.675.0): one
      // Staff, and the slot limit. Quickbind is that action, done faster.
      const refused = await h().investRefusal?.(actor, item);
      if (refused) { await card(actor, "Quickbind", [line(`<em>${esc(item.name)} cannot be invested: ${esc(refused)}.</em>`)]); return; }
      await item.setFlag(MODULE_ID, "quickbindDay", day + 1);
      await item.update({ "system.invested": true });
      await card(actor, "Quickbind", [line(`<strong>${esc(item.name)}</strong> is invested; it took <strong>${minutes} minute${minutes === 1 ? "" : "s"}</strong>. One Quickbind check per item per day.`)]);
      return;
    }
    case "magicDrain": return resolveMagicDrain(actor, k, targetActor);
    default:
  }
}

async function resolveMagicDrain(actor, degree, targetActor) {
  // The action was taken: its Focus use is spent whatever the degree.
  const item = owned(actor, "Magic Drain", ["ability"]);
  if (item && !(await spendUse(item, "Magic Drain", "Refocus"))) return;
  const plan = actor.getFlag?.(MODULE_ID, DRAIN_PLAN_FLAG) ?? null;
  if (plan) await actor.unsetFlag?.(MODULE_ID, DRAIN_PLAN_FLAG);
  if (!["heroic", "critical", "success"].includes(degree)) {
    await card(actor, "Magic Drain", [line("Nothing is drained."), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return;
  }
  const what = DRAIN_WHAT.some(([v]) => v === plan?.what) ? plan.what : await h().chooseFromList("Magic Drain — what did you drain?", "The target", DRAIN_WHAT);
  if (!what) { await card(actor, "Magic Drain", [line("<em>The drain succeeded; settle what it took by hand.</em>")]); return; }
  const extra = heritageOf(actor)?.flags?.[SYSTEM_ID]?.eaMagicDrainBonus === "classBonus" ? classBonusOf(actor) : 0;
  let drained = 0;
  const lines = [];
  const note = extra ? `, + ${extra} Vir-ellian` : "";
  if (what === "item") {
    const roll = await new Roll("1d4").evaluate();
    drained = roll.total;
    const holder = targetActor ?? actor;
    const charged = Array.from(holder.items ?? []).filter((i) => i.flags?.[SYSTEM_ID]?.chargedItem);
    const take = drained + extra;
    const pick = charged.length ? await h().chooseFromList("Magic Drain — the item", `Which of ${esc(holder.name)}'s items?`, charged.map((i) => [i.id, `${esc(i.name)} (${int(i.system?.uses)} PP)`])) : null;
    const target = pick ? holder.items.get(pick) : null;
    if (target?.isOwner !== false && target) {
      const before = int(target.system?.uses);
      await target.update({ "system.uses": Math.max(0, before - take) });
      lines.push(line(`<strong>${esc(target.name)}</strong> loses <strong>${take} PP</strong> (1d4 = ${drained}${note}): ${Math.max(0, before - take)} left.`));
    } else {
      // NOT THIS CLIENT'S TO CHANGE (found in review): said, for the GM.
      lines.push(line(`${target ? `<strong>${esc(target.name)}</strong>` : "The item"} loses <strong>${take} PP</strong> (1d4 = ${drained}${note}); <em>the GM takes it off the item.</em>`));
    }
  } else {
    const answer = await foundry.applications.api.DialogV2.prompt({
      window: { title: "Magic Drain — the effect" },
      content: `<div class="form-group"><label>The effect's PP</label><input type="number" name="pp" value="1" min="0"></div><p class="hint">The GM knows it; the effect is negated.</p>`,
      ok: { label: "Drain", callback: (event, button) => new (foundry.applications?.ux?.FormDataExtended ?? globalThis.FormDataExtended)(button.form).object },
      rejectClose: false
    }).catch(() => null);
    if (!answer) { await card(actor, "Magic Drain", [line("<em>The effect is negated; settle the energy by hand.</em>")]); return; }
    drained = Math.max(0, int(answer.pp));
    lines.push(line(`The effect is <strong>negated</strong> (${drained} PP${note}).`));
  }
  const result = magicDrainEnergy({ degree, drained, level: levelOf(actor), extra });
  const { energy } = result;
  if (!energy) { await card(actor, "Magic Drain", [...lines, line("You gain no energy.")]); return; }
  // "for 1 minute per PP drained" — the PP drained, not the energy kept.
  const minutes = Math.max(1, result.drained);
  const to = DRAIN_TARGETS.some(([v]) => v === plan?.to) ? plan.to : await h().chooseFromList("Magic Drain — the energy", `Where does the +1 racial go (${minutes} minute${minutes === 1 ? "" : "s"})?`, DRAIN_TARGETS.map(([v, l]) => [v, l]));
  if (!to) return;
  const label = DRAIN_TARGETS.find(([v]) => v === to)?.[1] ?? to;
  const flags = to === "defence"
    ? {}
    : { conditionals: [{ kind: "modifier", value: 1, type: "race", label: "Magic Drain", scope: label, auto: true, when: { checkTypes: [to] } }] };
  await h().createEffectsOn(actor, [effectData("magicDrainEnergy", {
    name: `Magic Drain: ${energy} energy (+1 ${label})`,
    img: "icons/svg/lightning.svg",
    description: `Magic Drain: ${energy} PP of temporary magical energy — +1 racial bonus to ${label} for ${minutes} minute${minutes === 1 ? "" : "s"} (1 per PP drained).`,
    // A RACIAL BONUS TO DB, POOLED AS ONE (found in review): the system's
    // typed slot, so it stacks as a racial bonus does.
    changes: to === "defence" ? [{ key: "system.combat.defence.racial", mode: 0, value: "1", priority: 20 }] : [],
    system: flags,
    module: { energy },
    expiry: forSeconds(60 * minutes)
  })]);
  await card(actor, "Magic Drain", [
    ...lines,
    line(`You gain <strong>${energy}</strong> temporary magical energy (max ${levelOf(actor) * 2}): <strong>+1 racial to ${label}</strong> for ${minutes} minute${minutes === 1 ? "" : "s"}.`),
    line("<em>Focus use spent — Refocus restores it.</em>")
  ]);
}

/* ------------------------------------------------------------------ */
/* Other hooks                                                          */
/* ------------------------------------------------------------------ */

/** trgPrimeDailyPreparation: Innate Magic invites a new pick. */
export async function onDailyPreparationB1({ actor } = {}) {
  if (!actor?.isOwner) return;
  // Glyphweave's innate cantrip is kept until it is chosen again (book v1.6).
  if (!owned(actor, "Innate Magic", ["ability"])) return;
  await card(actor, "Innate Magic", [line("A new day: you may choose a different cantrip. Press <strong>Use</strong> on Innate Magic, or keep yesterday's.")]);
}


/* The small steps Block 2 shares (0.3.0). */
export { norm, int, esc, h, line, card, warn, now, levelOf, owned, tokenOf, tokenCentre, inCombat, spendAP, feetBetween, lockouts, lock };
