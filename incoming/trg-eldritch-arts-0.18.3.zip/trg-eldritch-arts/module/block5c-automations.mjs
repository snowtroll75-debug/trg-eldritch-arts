/**
 * Eldritch Arts — Block 5, group C (0.8.0, on TRG Prime 3.683.0): what the
 * nineteen Scaelyn racial feats do that is not data on their items.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix C, as Graham
 * answered it on 3 November 2026 (Q76–Q80 as proposed). The pure rules are
 * exported first so the harness can run them; the Foundry side follows.
 *
 *   Uses       Alchemical Purifier (re-applies Q76's allowance), Ancestral
 *              Awakening, Claws of the Wyrm (resize), Elemental Breath (Q77),
 *              Runic Aptitude (Q79), Scaelyn Scholar and Wyrm's Cunning
 *              (Wyrm Lore), Glyph Unleashed (a pointer to its offers)
 *   Reaction   Glyph Unleashed (Q80): a check reaction before a spell's save
 *              (C2's `modifiers`) and a spell-only defence offer (C3)
 *   Grant      Scaled Focus's PP per level
 *   Hooks      a feat or spell arriving (claws, Wyrm Lore, the allowance);
 *              fire damage taken (Ember Handed); an attack or a cast and the
 *              turn's start (Ghostscale's break and return)
 *
 * Block 1's Scaelyn items are read, never edited: Elemental Breath reads the
 * Wyrmdral heritage's `flags.trg-prime.eaElement`, which its Use writes.
 * System helpers come from `game.trgPrime.modules.helpers` at call time.
 *
 * HOOKS THE LEAD WIRES (scripts/eldritch-arts.mjs):
 *   createItem               → onItemCreatedB5C(item)
 *   trgPrimeDamageApplied    → onDamageAppliedB5C(ctx)
 *   trgPrimeStrikeRolled     → onStrikeRolledB5C(ctx)
 *   trgPrimeSpellCast        → onSpellCastB5C(ctx)
 *   trgPrimeTurnEnded        → onTurnEndedB5C(ctx)
 *   updateWorldTime          → onWorldTimeB5C(worldTime)
 *   trgPrimeDailyPreparation → onDailyPreparationB5C(ctx)
 * and module/registration.mjs calls registerBlock5C(api, moduleId).
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, owned, tokenOf, spendAP, WYRMDRAL_ELEMENTS } from "./block1-automations.mjs";
import { spellIndex, actsFor } from "./block3-automations.mjs";

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

/** Ancestral Awakening's and Elemental Breath's five: Block 1's Wyrmdral list. */
export const SCAELYN_ELEMENTS = WYRMDRAL_ELEMENTS;
/** Q76: Alchemical Purifier's two PP 6 spells, castable at base PP ≤ level + 1. */
export const PURIFIER_ALLOWANCE = 1;
/** Ghostscale: "light level 5 (Dim) or less". The content declares the same. */
export const GHOSTSCALE_LIGHT = Object.freeze({ concealedAtOrBelow: 5 });
export const GHOSTSCALE_FLAG = "ghostscaleBroken";
/** Out of combat, "until the beginning of your next turn" is a round of world time. */
export const GHOSTSCALE_SECONDS = 6;
/** Glyph Unleashed's +2 racial (Q80). */
export const GLYPH_BONUS = 2;
export const GLYPH_STEP = "eldritchArts.glyphUnleashed";
export const GLYPH_WARD = "glyphWard";
export const GLYPH_DB = "glyphDB";
export const GLYPH_TRAITS = "Focus, Rune, Warding";
export const WYRM_LORE = "Wyrm Lore";

/** Claws of the Wyrm: "a claw attack appropriate to your size", the companions pack's sized Claws. */
export const CLAW_BY_SIZE = Object.freeze({ tiny: "Claws (Tiny)", small: "Claws (Small)", medium: "Claws (Medium)" });
export const clawFor = (size) => CLAW_BY_SIZE[norm(size)] ?? null;

/** Elemental Breath: "1d6 damage per level" (character level, at least 1). */
export const breathDice = (level) => `${Math.max(1, int(level))}d6`;

/** The Wyrmdral's element (Q77), off its heritage item, or "". */
export function breathElement(items = []) {
  const her = Array.from(items ?? []).find((i) => i?.type === "heritage" && norm(i.name) === "wyrmdral");
  const el = norm(her?.flags?.[SYSTEM_ID]?.eaElement);
  return SCAELYN_ELEMENTS.includes(el) ? el : "";
}

/** Ancestral Awakening's minute: resistance, and the spell DC row (Wyrmdral's own shape). */
export function ancestralEffect(element) {
  return {
    changes: [{ key: "system.combat.resistances", mode: 2, value: `, ${element}`, priority: 20 }],
    flags: { spellDCBonus: { label: "Ancestral Awakening", value: 1, type: "untyped", traits: [element] } }
  };
}

/** Ember Handed: "whenever you take fire damage" — fire that reduced HP. */
export function emberHandedTriggered(ctx = {}) {
  return Number(ctx.amount ?? 0) > 0 && Array.from(ctx.damageTypes ?? []).map(norm).includes("fire");
}
/** …"+1 to your next attack roll or skill check": one-shot, applied by itself. */
export function emberHandedConditional() {
  return { kind: "modifier", value: 1, type: "untyped", label: "Ember Handed", scope: "your next attack roll or skill check, before the end of your next turn", auto: true, oneShot: true, when: { checkTypes: ["attack", "skill"] } };
}

/** Ghostscale: an attack or a cast breaks concealment only where it conceals (a known level, 5 or lower). */
export function ghostscaleBreaks(level) {
  if (level === null || level === undefined || level === "") return false;
  const n = Number(level);
  return Number.isFinite(n) && n <= GHOSTSCALE_LIGHT.concealedAtOrBelow;
}
/** …its return out of combat: 6 seconds of world time after the break. */
export function ghostscaleReturnDue(record, { inCombat = false, worldTime = 0 } = {}) {
  if (!record || inCombat) return false;
  return Number(worldTime) >= Number(record.at ?? 0) + GHOSTSCALE_SECONDS;
}

/** Glyph Unleashed's ward: "that spell", from that caster (Q80). */
export function wardMatches(ward, spellName, sourceUuid) {
  if (!ward || !norm(spellName)) return false;
  return norm(ward.spellName) === norm(spellName) && String(ward.sourceUuid ?? "") === String(sourceUuid ?? "");
}
/** …its answer to the save (C2): +2 racial, the core's "race" type. */
export const glyphSaveModifiers = () => [{ label: "Glyph Unleashed", value: GLYPH_BONUS, type: "race" }];
/** …its DB against the spell attack (C3): +2 racial, spent by that caster's spell attack. */
export function glyphDefence(attackerUuid = "") {
  const uuid = String(attackerUuid ?? "").trim();
  return {
    changes: [{ key: "system.combat.defence.racial", mode: 0, value: String(GLYPH_BONUS), priority: 20 }],
    oneAttack: uuid ? { against: "spell", fromUuids: [uuid] } : { against: "spell" }
  };
}

/** A specialist skill's key by its label (the core's own match, specialist-grants.mjs). */
export function specialistKeyByLabel(skills = {}, label = WYRM_LORE) {
  const wanted = norm(label);
  for (const [key, skill] of Object.entries(skills ?? {})) if (norm(skill?.label) === wanted) return key;
  return null;
}
/** Wyrm Lore's +2 racial (Scaelyn Scholar, Wyrm's Cunning). */
export const wyrmLoreChange = (key, value = 2) => ({ key: `system.specialistSkills.${key}.racial`, mode: 2, value: String(value), priority: 20 });

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const now = () => Number(globalThis.game?.time?.worldTime ?? 0);
const feat = (actor, name) => owned(actor, name, ["feat"]);

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
const spentLine = () => line("<em>Focus use spent — Refocus or daily preparation restores it.</em>");

/** The system's trait rules for a module ability (Concentrate, Focus …), when the system offers them. */
async function traitsAllow(actor, item, key, label) {
  const ok = await h().traitGate?.(actor, { key, traits: String(item?.system?.traits ?? "") }, label);
  return ok !== false;
}

/* ------------------------------------------------------------------ */
/* Alchemical Purifier (Q76)                                             */
/* ------------------------------------------------------------------ */

const grantedBy = (i) => i?.flags?.[SYSTEM_ID]?.grantedBy ?? null;
const isPurifierCopy = (spell, featItem = null) => spell?.type === "spell" && (featItem
  ? grantedBy(spell)?.sourceId === featItem.id
  : norm(grantedBy(spell)?.sourceName) === "alchemical purifier");

async function givePurifierAllowance(spell) {
  if (int(spell?.flags?.[SYSTEM_ID]?.innatePPAllowance) >= PURIFIER_ALLOWANCE) return false;
  await spell.update({ [`flags.${SYSTEM_ID}.innatePPAllowance`]: PURIFIER_ALLOWANCE });
  return true;
}

const alchemicalPurifier = {
  hint: "Stinking Cloud and Neutralise Poison are your innate Focus spells; this makes sure both may be cast from 5th level (Q76).",
  // The feat's own Focus trait is printed; the spells keep their own uses.
  ownsFocusUse: true,
  async use(actor, item) {
    const copies = items(actor).filter((i) => isPurifierCopy(i, item));
    if (!copies.length) return warn("Alchemical Purifier: neither spell is on your sheet yet — apply the feat's grants first.");
    let fixed = 0;
    for (const spell of copies) if (await givePurifierAllowance(spell)) fixed += 1;
    await card(actor, "Alchemical Purifier", [line(`${copies.map((s) => `<strong>${esc(s.name)}</strong>`).join(" and ")}: innate, Focus, castable at base PP up to your level + ${PURIFIER_ALLOWANCE} (Q76).${fixed ? ` ${fixed} cop${fixed === 1 ? "y" : "ies"} updated.` : ""}`)]);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* Ancestral Awakening                                                  */
/* ------------------------------------------------------------------ */

const ancestralAwakening = {
  hint: "0 AP (Concentrate, Focus): for 1 minute, resistance to an element and +1 to its spell save DCs.",
  ownsFocusUse: true,
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Ancestral Awakening: its Focus use is spent — Refocus or daily preparation restores it.");
    const picked = norm(await h().chooseFromList("Ancestral Awakening — element", "Which element awakens?", SCAELYN_ELEMENTS.map((e) => [e, e[0].toUpperCase() + e.slice(1)])));
    if (!SCAELYN_ELEMENTS.includes(picked)) return false;
    if (!(await traitsAllow(actor, item, "ancestralAwakening", "Ancestral Awakening"))) return false;
    if (!(await spendUse(item))) return false;
    const stale = ownEffects(actor, "ancestralAwakening").map((e) => e.id);
    if (stale.length) await actor.deleteEmbeddedDocuments("ActiveEffect", stale).catch(() => {});
    const { changes, flags } = ancestralEffect(picked);
    await h().createEffectsOn(actor, [effectData("ancestralAwakening", {
      name: `Ancestral Awakening: ${picked}`, img: item.img ?? "icons/svg/fire-shield.svg",
      description: `Ancestral Awakening (1 minute): resistance to ${picked}, and +1 to the save DC of every spell you cast with the ${picked} trait.`,
      changes, system: flags, expiry: forSeconds(60)
    })]);
    await h().recordTraitUsage?.(actor, { key: "ancestralAwakening", traits: String(item.system?.traits ?? "") });
    await card(actor, "Ancestral Awakening", [
      line(`For <strong>1 minute</strong>: resistance to <strong>${picked}</strong>, and +1 to the save DC of every spell you cast with the ${picked} trait.`),
      spentLine()
    ]);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* Claws of the Wyrm                                                    */
/* ------------------------------------------------------------------ */

/** The companions packs the system federates (its own first). */
function companionPacks() {
  const api = globalThis.game?.trgPrime?.modules;
  const federated = api?.contentPacksFor?.("companions");
  if (Array.isArray(federated) && federated.length) return federated;
  return Array.from(globalThis.game?.packs ?? []).filter((p) => p.collection === "trg-prime.companions");
}
async function companionData(name) {
  for (const pack of companionPacks()) {
    const index = await pack.getIndex();
    const entry = Array.from(index.values?.() ?? index).find((e) => norm(e.name) === norm(name));
    if (!entry) continue;
    const doc = await pack.getDocument(entry._id);
    if (!doc) continue;
    const data = doc.toObject();
    delete data._id;
    return data;
  }
  return null;
}

/** Grant (or resize) the claw; true when the actor holds the right one. */
async function grantClaws(actor, item, { quiet = false } = {}) {
  const size = norm(actor.system?.identity?.size) || "medium";
  const name = clawFor(size);
  const mine = items(actor).filter((i) => i.type === "weapon" && grantedBy(i)?.sourceId === item.id);
  if (!name) {
    await card(actor, item.name, [line(`The system has no natural claw for a ${esc(size)} creature (only Tiny, Small and Medium); this claw is the GM's.`)]);
    return false;
  }
  if (mine.length === 1 && norm(mine[0].name) === norm(name)) {
    if (!quiet) await card(actor, item.name, [line(`You already have <strong>${esc(name)}</strong>, the claw for your size.`)]);
    return true;
  }
  const data = await companionData(name);
  if (!data) return warn(`${item.name}: ${name} is not in the companions compendium.`);
  if (mine.length) await actor.deleteEmbeddedDocuments("Item", mine.map((i) => i.id));
  data.flags = { ...(data.flags ?? {}), [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: item.id, sourceName: item.name, requested: name } } };
  await actor.createEmbeddedDocuments("Item", [data]);
  await card(actor, item.name, [line(`You gain <strong>${esc(name)}</strong> (${esc(data.system?.damage ?? "")} ${esc(data.system?.damageType ?? "")}), the claw for your size. It leaves with the feat; press Use if your size changes.`)]);
  return true;
}

const clawsOfTheWyrm = {
  hint: "Your claw, sized to you: press Use if your size has changed.",
  async use(actor, item) { return grantClaws(actor, item); }
};

/* ------------------------------------------------------------------ */
/* Elemental Breath (Q77)                                               */
/* ------------------------------------------------------------------ */

const elementalBreath = {
  hint: "2 AP (Focus): target the creatures in your 20-foot line — 1d6 per level of your Wyrmdral element, basic Reflex against your Level DC.",
  ownsFocusUse: true,
  async use(actor, item) {
    const element = breathElement(actor.items);
    if (!element) return warn("Elemental Breath: your Wyrmdral heritage has no element yet — choose it with the heritage's Use.");
    if (usesLeft(item) <= 0) return warn("Elemental Breath: its Focus use is spent — Refocus or daily preparation restores it.");
    const targets = Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor).filter((a) => a && a !== actor);
    if (!targets.length) return warn("Elemental Breath: target the creatures in your 20-foot line first.");
    if (!(await traitsAllow(actor, item, "elementalBreath", "Elemental Breath"))) return false;
    if (!(await spendAP(actor, "Elemental Breath", 2))) return false;
    if (!(await spendUse(item))) return false;
    const dice = breathDice(levelOf(actor));
    const lines = await h().runAreaEffect(actor, {
      save: "reflex", basic: true, scope: "targets", damage: { formula: dice, type: element },
      intro: `A 20-foot line of ${element}: ${dice}, basic Reflex against your Level DC.`
    }, { title: "Elemental Breath", targets });
    await h().recordTraitUsage?.(actor, { key: "elementalBreath", traits: String(item.system?.traits ?? "") });
    await card(actor, "Elemental Breath", [...(lines ?? []), spentLine()]);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* Runic Aptitude (Q79)                                                 */
/* ------------------------------------------------------------------ */

const runicAptitude = {
  hint: "Choose your additional cantrip, of any tradition (cast with Spellcraft); it is kept until you choose again.",
  async use(actor, item) {
    return h().chooseSpell(actor, item, { ppCost: 0, note: "Runic Aptitude: your additional cantrip, cast with your Spellcraft (Q79). Kept until you choose again." });
  }
};

/* ------------------------------------------------------------------ */
/* Scaelyn Scholar and Wyrm's Cunning: Wyrm Lore                        */
/* ------------------------------------------------------------------ */

async function giveWyrmLore(actor, item) {
  const key = specialistKeyByLabel(actor.system?.specialistSkills, WYRM_LORE);
  if (!key) {
    await card(actor, item.name, [line(`You have no <strong>${WYRM_LORE}</strong> specialist skill yet, so its +2 racial is waiting: add it on the Skills tab, then press <strong>Use</strong> on ${esc(item.name)}.`)]);
    return false;
  }
  await h().replaceFeatEffect(actor, item, {
    name: `${item.name}: ${WYRM_LORE} +2`, img: item.img,
    description: `${item.name}: +2 racial bonus to ${WYRM_LORE}.`,
    changes: [wyrmLoreChange(key)]
  });
  await card(actor, item.name, [line(`+2 racial bonus to <strong>${WYRM_LORE}</strong> (visible in its racial slot).`)]);
  return true;
}

const wyrmLore = {
  hint: "Puts the +2 racial on your Wyrm Lore (press after adding Wyrm Lore, if it was missing).",
  async use(actor, item) { return giveWyrmLore(actor, item); }
};

/* ------------------------------------------------------------------ */
/* Glyph Unleashed (Q80)                                                */
/* ------------------------------------------------------------------ */

const glyphFeat = (actor) => feat(actor, "Glyph Unleashed");
const wardsOf = (actor) => ownEffects(actor, GLYPH_WARD).map((e) => ({ spellName: e.getFlag?.(MODULE_ID, "spellName") ?? e.flags?.[MODULE_ID]?.spellName, sourceUuid: e.getFlag?.(MODULE_ID, "sourceUuid") ?? e.flags?.[MODULE_ID]?.sourceUuid ?? "" }));
const wardUp = (actor, spellName, sourceUuid) => wardsOf(actor).some((w) => wardMatches(w, spellName, sourceUuid));

/** Does `name` name a spell? The caster's own, or one in the spells compendium (an area ability's save is not). */
async function namesASpell(name, sourceUuid) {
  const wanted = norm(name);
  if (!wanted) return false;
  try {
    const source = sourceUuid ? (globalThis.fromUuidSync?.(sourceUuid) ?? await globalThis.fromUuid?.(sourceUuid)) : null;
    const caster = source?.actor ?? source;
    if (items(caster).some((i) => i.type === "spell" && norm(i.name) === wanted)) return true;
  } catch { /* the index below */ }
  return (await spellIndex()).some((e) => norm(e.name) === wanted);
}

/** May the bearer take the ward now? A reason, or "". */
async function glyphRefusal(actor, item) {
  if (!item) return "no Glyph Unleashed";
  if (usesLeft(item) <= 0) return "its Focus use is spent — Refocus restores it";
  if (combatFor(actor)) return String((await h().reactionRefusal?.(actor, GLYPH_TRAITS)) ?? "");
  return "";
}

/** Lay the ward (and, against an attack, the DB); spends the reaction and the use. True when laid. */
async function layWard(actor, item, { spellName = "", sourceUuid = "", attack = false } = {}) {
  if (await glyphRefusal(actor, item)) return false;
  if (combatFor(actor) && !(await h().spendReaction(actor, "Glyph Unleashed", { traits: GLYPH_TRAITS }))) return false;
  if (!(await spendUse(item))) return false;
  const expiry = expiryFor("startOfNextTurn", actor);
  const what = spellName ? esc(spellName) : "that spell";
  const docs = [effectData(GLYPH_WARD, {
    name: `Glyph Unleashed: warded against ${spellName || "a spell"}`, img: "icons/svg/shield.svg",
    description: `Glyph Unleashed: +2 racial to your saving throws against ${spellName || "that spell"} from that caster, until the start of your next turn.`,
    module: { spellName: String(spellName), sourceUuid: String(sourceUuid) }, expiry
  })];
  if (attack) {
    const db = glyphDefence(sourceUuid);
    docs.push(effectData(GLYPH_DB, {
      name: `Glyph Unleashed: +2 DB against ${spellName || "this spell"}`, img: "icons/svg/shield.svg",
      description: "Glyph Unleashed: +2 racial to DB against this spell's attack; the attack removes it.",
      changes: db.changes, system: { oneAttack: db.oneAttack }, expiry
    }));
  }
  await actor.createEmbeddedDocuments("ActiveEffect", docs);
  await card(actor, "Glyph Unleashed", [
    line(`A ward flares: <strong>+2 racial</strong> ${attack ? "to your DB against this attack, and " : ""}to your saving throws against <strong>${what}</strong> from that caster until the start of your next turn.`),
    line(`<em>${combatFor(actor) ? "Reaction and " : ""}Focus use spent — Refocus or daily preparation restores it.</em>`)
  ]);
  return true;
}

/** The step run on the bearer's client when the save's question is answered yes. */
export async function glyphStep(actor, answer, data = {}) {
  const item = glyphFeat(actor);
  return { warded: Boolean(await layWard(actor, item, { spellName: String(data?.spellName ?? ""), sourceUuid: String(data?.sourceUuid ?? "") })) };
}

/** C2: before a save against a spell — the ward's +2, asked once, then given for that spell and caster. */
export const glyphCheckReaction = {
  async before(ctx = {}) {
    if (ctx.type !== "save") return null;
    const actor = ctx.actor;
    const item = glyphFeat(actor);
    if (!item) return null;
    const spellName = String(ctx.saveSource ?? "").trim();
    const sourceUuid = String(ctx.sourceUuid ?? "");
    if (!spellName) return null;
    if (wardUp(actor, spellName, sourceUuid)) {
      return { modifiers: glyphSaveModifiers(), label: "Glyph Unleashed", line: `${esc(actor.name)}'s <strong>Glyph Unleashed</strong> ward: +2 racial against ${esc(spellName)}.` };
    }
    if (!(await namesASpell(spellName, sourceUuid))) return null;
    if (await glyphRefusal(actor, item)) return null;
    const q = await h().askReactor(actor, {
      title: `Glyph Unleashed — ${actor.name}`,
      content: `<p><strong>${esc(spellName)}</strong> forces <strong>${esc(actor.name)}</strong> to save.</p>`
        + `<p>Inscribe the ward (${combatFor(actor) ? "your reaction and " : ""}the Focus use)? +2 racial to this save, and to your saves against this spell from this caster until the start of your next turn.</p>`,
      buttons: [{ action: "yes", label: "Inscribe the ward" }, { action: "no", label: "No" }],
      step: GLYPH_STEP,
      data: { spellName, sourceUuid }
    });
    if (!q?.result?.warded) return null;
    return { modifiers: glyphSaveModifiers(), label: "Glyph Unleashed", line: `${esc(actor.name)} inscribes <strong>Glyph Unleashed</strong>: +2 racial against ${esc(spellName)}.` };
  }
};

/** C3: before a spell attack against the bearer's DB. */
export const glyphDefenceOffer = {
  label: "Glyph Unleashed",
  summary: "+2 racial to your DB against this spell, and to your saves against it until the start of your next turn (your reaction and the Focus use).",
  against: "spell",
  find: (actor) => glyphFeat(actor),
  requires: (actor, item) => (usesLeft(item) <= 0 ? "its Focus use is spent — Refocus restores it" : null),
  use: (actor, item, attack = {}) => layWard(actor, item, { spellName: String(attack?.what ?? ""), sourceUuid: String(attack?.attackerUuid ?? ""), attack: true })
};

const glyphUnleashed = {
  hint: "A reaction: offered when a spell forces you to save, or before a spell attack against your DB.",
  ownsFocusUse: true,
  async use() {
    return warn("Glyph Unleashed: it is offered when a spell forces you to save, or before a spell attack is rolled against your DB.");
  }
};

/* ------------------------------------------------------------------ */
/* Ghostscale                                                           */
/* ------------------------------------------------------------------ */

const ghostscale = (actor) => feat(actor, "Ghostscale");
const lightOn = (item) => Boolean(item?.flags?.[SYSTEM_ID]?.creatureAbility?.derives?.light);

async function breakGhostscale(actor, how) {
  const item = ghostscale(actor);
  if (!item || !actor?.isOwner || !lightOn(item)) return false;
  const token = tokenOf(actor);
  if (!token) return false;
  if (!ghostscaleBreaks(await h().lightLevelAt?.(token))) return false;
  await item.update({ [`flags.${SYSTEM_ID}.creatureAbility.derives.light`]: null });
  await item.setFlag(MODULE_ID, GHOSTSCALE_FLAG, { at: now(), combatId: combatFor(actor)?.id ?? "" });
  await card(actor, "Ghostscale", [line(`You ${how}: your concealment is broken until the start of your next turn${combatFor(actor) ? "" : " (6 seconds)"}.`)]);
  return true;
}

async function restoreGhostscale(item) {
  if (!item?.getFlag?.(MODULE_ID, GHOSTSCALE_FLAG)) return false;
  await item.update({ [`flags.${SYSTEM_ID}.creatureAbility.derives.light`]: { ...GHOSTSCALE_LIGHT } });
  await item.unsetFlag(MODULE_ID, GHOSTSCALE_FLAG);
  return true;
}

/** Every actor on the world and the board (an unlinked token's actor is its own). */
const allActors = () => new Set([...(globalThis.game?.actors ?? []), ...(globalThis.canvas?.tokens?.placeables ?? []).map((t) => t.actor).filter(Boolean)]);

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const AUTOMATIONS_B5_C = Object.freeze({
  "Alchemical Purifier": alchemicalPurifier,
  "Ancestral Awakening": ancestralAwakening,
  "Claws of the Wyrm": clawsOfTheWyrm,
  "Elemental Breath": elementalBreath,
  "Glyph Unleashed": glyphUnleashed,
  "Runic Aptitude": runicAptitude,
  "Scaelyn Scholar": wyrmLore,
  "Wyrm’s Cunning": wyrmLore
});

export function registerBlock5C(api = globalThis.game?.trgPrime?.modules, moduleId = MODULE_ID) {
  if (!api) return;
  for (const [name, entry] of Object.entries(AUTOMATIONS_B5_C)) api.registerFeatAutomation(name, entry, moduleId);
  api.registerPPGrant?.("Scaled Focus", { perLevel: 1, label: "Scaled Focus (+1 PP per level)", types: ["feat"] }, moduleId);
  api.registerCheckReaction?.("glyphUnleashed", glyphCheckReaction, moduleId);
  api.registerDefenceOffer?.("Glyph Unleashed", glyphDefenceOffer, moduleId);
  api.registerReactionStep?.(GLYPH_STEP, glyphStep, moduleId);
}

/* ------------------------------------------------------------------ */
/* Hooks                                                                */
/* ------------------------------------------------------------------ */

/** createItem: the claw, Wyrm Lore's +2, and Q76's allowance on Alchemical Purifier's copies (one client). */
export async function onItemCreatedB5C(item) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  if (item.type === "spell" && isPurifierCopy(item)) { await givePurifierAllowance(item); return; }
  if (item.type !== "feat") return;
  const key = norm(item.name);
  if (key === "claws of the wyrm") await grantClaws(actor, item, { quiet: true });
  else if (key === "scaelyn scholar" || key === "wyrm’s cunning") await giveWyrmLore(actor, item);
}

/** trgPrimeDamageApplied (the client that applied it): Ember Handed's +1. */
export async function onDamageAppliedB5C(ctx = {}) {
  const actor = ctx.actor;
  if (!actor || !feat(actor, "Ember Handed") || !emberHandedTriggered(ctx)) return;
  const stale = ownEffects(actor, "emberHanded");
  // REFRESHED, NOT STACKED: the owner replaces it. A client that does not own
  // the bearer cannot delete, so it lays one only when none is up.
  if (stale.length) {
    if (!actor.isOwner) return;
    await actor.deleteEmbeddedDocuments("ActiveEffect", stale.map((e) => e.id)).catch(() => {});
  }
  await h().createEffectsOn(actor, [effectData("emberHanded", {
    name: "Ember Handed: +1 (fire)", img: "icons/svg/fire.svg",
    description: "Ember Handed: +1 to your next attack roll or skill check before the end of your next turn.",
    system: { conditionals: [emberHandedConditional()] },
    expiry: expiryFor("endOfNextTurn", actor)
  })]);
  await card(actor, "Ember Handed", [line("The heat is yours: <strong>+1</strong> to your next attack roll or skill check before the end of your next turn.")]);
}

/** trgPrimeStrikeRolled (the attacker's client): Ghostscale's attack. */
export async function onStrikeRolledB5C(ctx = {}) {
  await breakGhostscale(ctx.attacker, "attack");
}

/** trgPrimeSpellCast (the caster's client): Ghostscale's cast. */
export async function onSpellCastB5C(ctx = {}) {
  await breakGhostscale(ctx.actor, "cast a spell");
}

/** trgPrimeTurnEnded (acting GM): Ghostscale returns as its bearer's turn begins. */
export async function onTurnEndedB5C(ctx = {}) {
  if (!isActingGM()) return;
  const next = (ctx.combat ?? globalThis.game?.combat)?.combatant?.actor;
  if (next) await restoreGhostscale(ghostscale(next));
}

/** updateWorldTime (acting GM): out of combat, Ghostscale returns after 6 seconds. */
export async function onWorldTimeB5C(worldTime = now()) {
  if (!isActingGM()) return;
  for (const actor of allActors()) {
    const item = ghostscale(actor);
    const record = item?.getFlag?.(MODULE_ID, GHOSTSCALE_FLAG);
    if (record && ghostscaleReturnDue(record, { inCombat: Boolean(combatFor(actor)), worldTime: Number(worldTime) })) await restoreGhostscale(item);
  }
}

/** trgPrimeDailyPreparation: a broken Ghostscale is whole again. */
export async function onDailyPreparationB5C({ actor } = {}) {
  if (!actor?.isOwner) return;
  await restoreGhostscale(ghostscale(actor));
}
