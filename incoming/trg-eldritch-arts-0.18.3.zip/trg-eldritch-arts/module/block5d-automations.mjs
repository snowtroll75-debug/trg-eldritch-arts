/**
 * Eldritch Arts — Block 5, group D (0.8.0, on TRG Prime 3.683.0): what the
 * Chapter 5 general feats do that is not data.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix D, as Graham
 * answered it on 3 November 2026 (Q81–Q88 as proposed). The pure rules come
 * first so the harness can run them; the Foundry side follows.
 *
 *   RITUAL RULES   Archsage Command's seat, Lorekeeper's Insight's +2 (D13)
 *   DISPEL         Dispel Power (C9, Q84) and Mirrored Rebuke (C9, Q85)
 *   CASTING        Runic Stabiliser's option and remap (C14); Masked
 *                  Caster's Spell Trickery (+1, Block 2b's option, wrapped)
 *   CHECKS         Ley Channeler's reroll; Esoteric Insight Expert's and
 *                  Master's Spell Recognition riders (C11); Archsage's Critical
 *   ACTIONS        Ley Channeler's PP, Hypnotic Savant, Circle Adept, Magus
 *                  Appraiser, Rapid Binder, Spell Thief's free preparation
 *                  (C13), Masked Caster's Blunder line
 *   EFFECTS        Essence Reservoir's minute (Block 2's siphoned essence)
 *   USES           Threadcutter, Wanderer's Mastery, Wanderer's Sense
 *   DATA           Channel Siphoner's degree upgrade (C10), Spirit Resources'
 *                  and Threadcutter's skill substitutions, the time ladders
 *                  Magus Appraiser and Rapid Binder give Block 1's actions
 *
 * HOOKS (wired by the lead in scripts/eldritch-arts.mjs):
 *   trgPrimeActionResolved → onActionResolvedB5D(ctx)
 *   trgPrimeSpellSettled   → onSpellSettledB5D(ctx)
 *   createActiveEffect     → onEffectCreatedB5D(effect, options, userId)
 *   createItem             → onItemCreatedB5D(item, options, userId)
 */
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, TURN_END_FLAG } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, now, owned, tokenOf, feetBetween, printedDegree } from "./block1-automations.mjs";
import { SKILL_ACTIONS as B2_ACTIONS } from "./block2-actions.mjs";
import { circleMinutes, spellTrickeryOption } from "./block2b-automations.mjs";
import { allies, canDispel } from "./block3b-automations.mjs";
import { leyLinesWithin } from "./areas.mjs";

/* ------------------------------------------------------------------ */
/* Names (the items' own, curly apostrophes kept)                       */
/* ------------------------------------------------------------------ */

export const FEATS = Object.freeze({
  archsage: "Archsage Command",
  channelSiphoner: "Channel Siphoner",
  circleAdept: "Circle Adept",
  dispelPower: "Dispel Power",
  expert: "Esoteric Insight Expert",
  master: "Esoteric Insight Master",
  reservoir: "Essence Reservoir",
  savant: "Hypnotic Savant",
  leyChanneler: "Ley Channeler",
  lorekeeper: "Lorekeeper’s Insight",
  magusAppraiser: "Magus Appraiser",
  maskedCaster: "Masked Caster",
  mirroredRebuke: "Mirrored Rebuke",
  counterSpell: "Counter Spell",
  rapidBinder: "Rapid Binder",
  runicStabiliser: "Runic Stabiliser",
  spellThief: "Spell Thief",
  spiritResources: "Spirit Resources",
  threadcutter: "Threadcutter",
  wanderersMastery: "Wanderer’s Mastery",
  wanderersSense: "Wanderer’s Sense"
});

const hasFeat = (actor, name) => owned(actor, name, ["feat"]);
const SUCCESSES = Object.freeze(["heroic", "critical", "success"]);
const CRITICALS = Object.freeze(["heroic", "critical"]);

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

/** Channel Siphoner: "treat a Partial result as a Success" (TRG Prime's degree upgrade; C10 carries it to the resolver). */
export const DEGREE_UPGRADES_B5D = Object.freeze({
  [FEATS.channelSiphoner]: Object.freeze([Object.freeze({ actionKey: "tapMagicalEnergy", from: "partial", to: "success" })])
});

/** Threadcutter's four, and the skill each names. */
export const THREADCUTTER_SKILLS = Object.freeze([["arcana", "Arcana"], ["nature", "Nature"], ["occultism", "Occultism"], ["religion", "Religion"]]);
export const threadcutterName = (skill) => `Threadcutter (${THREADCUTTER_SKILLS.find(([k]) => k === skill)?.[1] ?? skill})`;

/**
 * Skill substitutions by feat or ability name: Spirit Resources' three
 * ("Occultism in place of Diplomacy … Gather Information, Make an Impression
 * and Request"), and each Threadcutter ability's Dispel.
 */
export const SKILL_SUBSTITUTIONS_B5D = Object.freeze({
  [FEATS.spiritResources]: Object.freeze(["gatherInformation", "makeAnImpression", "request"].map((action) => Object.freeze({ action, skill: "occultism" }))),
  ...Object.fromEntries(THREADCUTTER_SKILLS.map(([skill]) => [threadcutterName(skill), Object.freeze([Object.freeze({ action: "dispel", skill })])]))
});

/**
 * THE TIME LADDERS TWO FEATS GIVE BLOCK 1's ACTIONS (TRG Prime 3.675.0's
 * `timeLadderByFeat`). The lead merges each into the action's
 * `timeLadderByFeat` where registration.mjs registers Block 1's actions.
 *   Magus Appraiser: "10 minutes (+2), 1 minute (+0), 1 round (-2), 1 AP (-5)".
 *   Rapid Binder: "You ignore the penalty to invest an item using Quickbind
 *   outside of normal daily preparation" — the outside rung at +0.
 */
export const TIME_LADDER_FEATS_B5D = Object.freeze({
  appraiseMagic: Object.freeze({
    [FEATS.magusAppraiser]: Object.freeze({
      options: Object.freeze([
        Object.freeze({ key: "tenMinutes", label: "10 minutes", modifier: 2, apCost: "10 minutes" }),
        Object.freeze({ key: "minute", label: "1 minute", modifier: 0, apCost: "1 minute" }),
        Object.freeze({ key: "round", label: "1 round", modifier: -2, apCost: "1 round" }),
        Object.freeze({ key: "action", label: "1 AP", modifier: -5, apCost: "1" })
      ]),
      defaultKey: "tenMinutes",
      hint: "Magus Appraiser: how long do you spend examining the item? If you are interrupted, you must start over."
    })
  }),
  quickbind: Object.freeze({
    [FEATS.rapidBinder]: Object.freeze({
      options: Object.freeze([
        Object.freeze({ key: "dailyPrep", label: "During your daily preparation", modifier: 0, apCost: "1 minute" }),
        Object.freeze({ key: "outside", label: "Outside daily preparation (Rapid Binder: no penalty)", modifier: 0, apCost: "1 minute" })
      ]),
      defaultKey: "dailyPrep",
      rowLabel: "When",
      title: "Quickbind — when",
      hint: "Rapid Binder: you ignore the penalty for investing outside your daily preparation. The DC is the item's: its Level DC."
    })
  })
});

/**
 * Hypnotic Savant: "its base duration increases by 10 minutes. On a
 * critical result, instead of 30 minutes, the effect lasts 1 hour" (n5).
 * Success is "as the Suggestion spell" (1 minute), so 11 minutes; Partial
 * 5 → 15; Heroic 1 hour → 1 hour 10. Seconds, or null.
 */
export function savantSuggestionSeconds(degree) {
  const k = norm(degree);
  if (k === "heroic") return 4200;
  if (k === "critical") return 3600;
  if (k === "success") return 660;
  if (k === "partial") return 900;
  return null;
}
export const describeSeconds = (s) => {
  const m = Math.round(int(s) / 60);
  if (m < 60) return `${m} minute${m === 1 ? "" : "s"}`;
  const hours = Math.floor(m / 60), rest = m % 60;
  return `${hours} hour${hours === 1 ? "" : "s"}${rest ? ` ${rest} minutes` : ""}`;
};

/** "If they are a spellcaster" (n5): a caster level of 1 or more. */
export const isSpellcaster = (actor) => int(actor?.system?.magic?.casterLevelValue ?? actor?.system?.magic?.casterLevel) >= 1;

/** Ley Channeler's PP on Tap Ley Line, by the printed degree: Success 1d4, Critical 2d4. */
export function leyChannelerDice(degree) {
  const k = norm(degree);
  if (k === "critical" || k === "heroic") return "2d4";
  if (k === "success") return "1d4";
  return null;
}
/** Q83: a Failure or a Fumble is rerolled; a Blunder reads as the Fumble (m42); a Partial is not a failure. */
export const leyChannelerRerolls = (degree) => ["failure", "fumble", "blunder"].includes(norm(degree));

/**
 * Essence Reservoir: "remains stored within you for up to 1 minute … You may
 * hold a maximum of PP equal to your Power Manipulation skill ranks in this
 * way." What a new siphon puts in the reservoir and what keeps its normal end.
 */
export function reservoirSplit({ gained = 0, held = 0, ranks = 0 } = {}) {
  const g = Math.max(0, int(gained));
  const room = Math.max(0, int(ranks) - Math.max(0, int(held)));
  const stored = Math.min(g, room);
  return { stored, excess: g - stored };
}

/** Circle Adept: "in half the normal time" — of Block 2b's own reckoning. */
export const circleAdeptMinutes = (level, care = "") => Math.ceil(circleMinutes(level, care) / 2);

/**
 * DISPEL POWER's printed results (book v1.6, L4374), for the core's own
 * ladder (C9). The rungs it does not print fall back as the core's do (m42).
 */
export const DISPEL_POWER_OUTCOMES = Object.freeze({
  critical: "You dispel the effect.",
  success: "You suppress the effect for 1 minute, after which it resumes and finishes any remaining duration.",
  failure: "You fail to dispel the effect.",
  fumble: "You fail to dispel the effect and trigger a resonance event. Furthermore, you cannot attempt to dispel this effect again."
});
/** The printed rung a resolved degree reads (m42: Heroic → Critical, Partial → Failure, Blunder → Fumble). */
export const dispelPowerRung = (degree) => printedDegree({ outcomes: DISPEL_POWER_OUTCOMES }, degree);

const casterLevelOf = (actor) => int(actor?.system?.magic?.casterLevelValue ?? actor?.system?.magic?.casterLevel);

/** Dispel Power's offer (Q84): no PP, the caster level as the value, Very Hard, its own ladder, its Focus use. */
export function dispelPowerOffer(ctx = {}) {
  const item = hasFeat(ctx.actor, FEATS.dispelPower);
  if (!item) return null;
  const cl = casterLevelOf(ctx.actor);
  return {
    label: `Dispel Power (no PP: caster level ${cl} as the counteract value; Very Hard; Focus)`,
    hint: "this feat's results replace Dispel's; its Focus use is spent when you roll",
    optional: true,
    ppReplace: cl,
    difficulty: "veryHard",
    outcomes: { ...DISPEL_POWER_OUTCOMES },
    focus: true,
    itemId: item.id
  };
}

/**
 * WHICH COUNTERS ARE COUNTER SPELL'S (review): "When you make a counter a
 * spell attempt using the Counter Spell feat". The core calls any
 * `presetDispel` a counter (Block 3b's Disrupting Magic, Block 5A's Resonant
 * Ascendance), so the offer is limited to the core feat's own free Dispel
 * (its action says `counterSpell`, with no preset) and this module's own
 * Counter Spell step (a preset marked `eaCounterSpell`).
 */
export const isCounterSpellDispel = (ctx = {}) => Boolean(ctx.counterSpell) && (ctx.presetDispel ? ctx.presetDispel.eaCounterSpell === true : true);

/** Mirrored Rebuke's offer (Q85): on a Counter Spell counter only, a tick. */
export function mirroredRebukeOffer(ctx = {}) {
  if (!isCounterSpellDispel(ctx) || !hasFeat(ctx.actor, FEATS.mirroredRebuke)) return null;
  return {
    label: "Mirrored Rebuke: reflect the spell back upon its caster",
    hint: "a Success or better: the spell is negated for its targets and resolves as cast by you at its caster",
    optional: true
  };
}

/** Runic Stabiliser's casting option (C14): offered on a High Magic cast to its owner. */
export const RUNIC_KEY = "runicStabiliser";
export const runicStabiliserOption = Object.freeze({
  offer: (ctx = {}) => (ctx.highMagic && hasFeat(ctx.actor, FEATS.runicStabiliser)
    ? { label: "Runic Stabiliser: inscribe a stabilising rune (1 AP)", hint: "a Partial casting result is treated as a Success" }
    : null),
  apply: () => ({ ap: 1, label: "Runic Stabiliser", lines: ["<strong>Runic Stabiliser:</strong> a stabilising rune is inscribed (1 AP); a Partial result is treated as a Success."] })
});
/** …and its reading of the degree: "If you do, you treat a Partial result as a Success." */
export function runicStabiliserRemap(ctx = {}) {
  const taken = (ctx.castOptions ?? []).map(norm).includes(norm(RUNIC_KEY));
  if (!taken || !ctx.highMagic || norm(ctx.degree) !== "partial") return null;
  return { degree: "success", lines: ["<em>Runic Stabiliser: the stabilising rune holds — the Partial is treated as a Success.</em>"] };
}

/**
 * MASKED CASTER on Block 2b's Spell Trickery option: "The DC increase for
 * Spell Trickery is reduced to +1 instead of +2." Registered under the same
 * key, after Block 2b's, so the one tick says the owner's own increase.
 */
export const maskedSpellTrickery = Object.freeze({
  offer: async (ctx = {}) => {
    const o = await spellTrickeryOption.offer(ctx);
    if (!o || !hasFeat(ctx.actor, FEATS.maskedCaster)) return o;
    return { ...o, label: "Spell Trickery (+1 to the casting DC — Masked Caster)" };
  },
  apply: async (ctx = {}) => {
    const o = await spellTrickeryOption.apply(ctx);
    if (!hasFeat(ctx.actor, FEATS.maskedCaster)) return o;
    return { ...o, castingDC: 1, label: "Spell Trickery (Masked Caster)", lines: [...(o?.lines ?? []), "<strong>Masked Caster:</strong> the casting DC rises by +1 instead of +2."] };
  }
});

/**
 * THE RITUAL (TRG Prime 3.679.0's ritual rules, D13). Archsage Command: "you
 * may treat the group as having an additional caster beyond those present"
 * (Q82: on top of Ritual Expert's or Rune-Binder's Precision's seat).
 * Lorekeeper's Insight: "+2-class bonus to all checks relating to magic
 * rituals" — the primary's ritual check.
 */
export const RITUAL_RULES_KEY_B5D = `${MODULE_ID}-block5d`;
export function prepareRitualB5D({ actor } = {}) {
  const out = { seats: 0, modifiers: [], lines: [] };
  if (hasFeat(actor, FEATS.archsage)) {
    out.seats = 1;
    out.lines.push("Archsage Command: one more caster counted, beyond those present.");
  }
  if (hasFeat(actor, FEATS.lorekeeper)) out.modifiers.push({ label: FEATS.lorekeeper, value: 2, type: "class" });
  return out.seats || out.modifiers.length ? out : null;
}

/** Archsage Command's hour: advantage on the next save against a magical effect (a tick: n1). */
export const archsageConditionals = () => [{ kind: "advantage", label: FEATS.archsage, scope: "Your next saving throw against a magical effect, within the hour — tick it on one", auto: false, oneShot: true, when: { checkTypes: ["save"] } }];

/** Esoteric Insight Master's Critical: +2 on the next save against that caster's spells (by uuid when targeted, else a tick). */
export function masterConditionals(casterUuid = "", casterName = "") {
  return [{
    kind: "modifier", value: 2, type: "circumstance", label: FEATS.master,
    scope: casterUuid ? `Your next saving throw against ${casterName || "that caster"}'s spells, before the end of your next turn` : "Your next saving throw against that caster's spells, before the end of your next turn — tick it",
    auto: Boolean(casterUuid), oneShot: true,
    when: casterUuid ? { checkTypes: ["save"], sourceUuids: [casterUuid] } : { checkTypes: ["save"] }
  }];
}

/** Wanderer's Mastery's journey: +2 luck on saves against magical effects — auto on a spell's save, a tick otherwise. */
const TRADITIONS = Object.freeze(["arcane", "divinity", "ethereal", "verdant"]);
export const journeyConditionals = () => [
  { kind: "modifier", value: 2, type: "luck", label: FEATS.wanderersMastery, scope: "Saving throws against magical effects (a spell's)", auto: true, when: { checkTypes: ["save"], traditions: [...TRADITIONS] } },
  { kind: "modifier", value: 2, type: "luck", label: FEATS.wanderersMastery, scope: "Saving throws against magical effects — tick if this one is", auto: false, when: { checkTypes: ["save"], not: { traditions: [...TRADITIONS] } } }
];
export const JOURNEY_LOCK_SECONDS = 7 * 86400;

/** A Threadcutter ability's data: the name its substitution is registered under. */
export function threadcutterAbility(skill, feat = null) {
  const name = threadcutterName(skill);
  const label = THREADCUTTER_SKILLS.find(([k]) => k === skill)?.[1] ?? skill;
  return {
    name, type: "ability", img: "icons/svg/upgrade.svg",
    system: {
      source: "Eldritch Arts", category: "General", active: true, traits: "", usesPerDay: "", sourceRace: "", sourceClass: "",
      description: `<p><strong>Threadcutter (${label}):</strong> you may use ${label} instead of Power Manipulation for the Dispel action, against magical effects within that tradition's domain.</p><p><em>Automated (0.8.0): the Dispel action is offered from ${label}. Whether an effect lies within the tradition's domain is yours and the GM's to judge.</em></p>`
    },
    flags: {
      [SYSTEM_ID]: { grantedBy: { sourceId: feat?.id ?? "", sourceName: FEATS.threadcutter, requested: name } },
      [MODULE_ID]: { threadcutter: skill, threadcutterFeat: feat?.id ?? "" }
    }
  };
}

/* ------------------------------------------------------------------ */
/* Foundry side: small steps                                            */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const ppOf = (actor) => ({ value: int(actor?.system?.resources?.pp?.value), max: int(actor?.system?.resources?.pp?.max) });
function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (!(left > 0)) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (token) => token?.document?.disposition;

/** Set this user's targets for the length of `run`, then put them back. */
async function withTargets(ids, run) {
  const placed = globalThis.canvas?.tokens?.placeables ?? [];
  const user = globalThis.game?.user;
  const previous = Array.from(user?.targets ?? []).map((t) => t.id);
  const set = (want) => {
    const s = new Set(want);
    for (const t of placed) if (Boolean(t.isTargeted) !== s.has(t.id)) t.setTarget?.(s.has(t.id), { user, releaseOthers: false, groupSelection: true });
  };
  try {
    set(ids);
    return await run();
  } finally {
    set(previous);
  }
}

/** A card for the GM's eyes only (a Secret action's extra). */
async function gmCard(actor, title, lines) {
  const CM = globalThis.ChatMessage;
  if (!CM?.create) return card(actor, title, lines);
  const whisper = Array.from(globalThis.game?.users ?? []).filter((u) => u.isGM).map((u) => u.id);
  return CM.create({ speaker: CM.getSpeaker?.({ actor }), whisper, content: `<div class="trg-prime trg-check-card"><h3 style="margin:0 0 4px 0">${title}</h3>${lines.join("")}</div>` });
}

/** An effect replaced rather than doubled (Archsage's hour, Master's +2). */
async function freshEffect(actor, source, data) {
  const old = ownEffects(actor, source).map((e) => e.id);
  if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old).catch(() => {});
  return h().createEffectsOn(actor, [effectData(source, data)]);
}

/* ------------------------------------------------------------------ */
/* Dispel riders                                                        */
/* ------------------------------------------------------------------ */

/** Dispel Power's results, said; a Fumble's Resonance event rolled. */
export async function dispelPowerResult(ctx = {}) {
  const rung = dispelPowerRung(ctx.degree);
  const lines = [`<strong>Dispel Power (${esc(rung)}):</strong> ${esc(DISPEL_POWER_OUTCOMES[rung] ?? "")}`];
  if (rung === "critical") lines.push("<em>The effect is dispelled — the GM removes it.</em>");
  if (rung === "success") lines.push("<em>The GM suspends the effect for 1 minute; then it resumes and runs its remaining duration.</em>");
  if (rung === "fumble") {
    await h().rollResonanceEvent(ctx.actor, { reason: "Dispel Power (Fumble)" });
    lines.push("<em>A Resonance event is rolled (its own card). You may not try to dispel this effect again — the GM keeps that record.</em>");
  }
  return { lines };
}

/**
 * Mirrored Rebuke's rider (Q85). Countered at Success or better: the spell is
 * negated and resolves as cast by you at its caster — released from you at
 * the PP it was cast at, no check and none of your PP, at your save DC and
 * spell attack, its range measured from you (the core's item release, C11 of
 * 3.673.0). A Fumble's rebound is the GM's.
 */
export async function mirroredRebukeResult(ctx = {}) {
  const actor = ctx.actor;
  const degree = norm(ctx.degree);
  if (["fumble", "blunder"].includes(degree)) {
    return { lines: ["<strong>Mirrored Rebuke (Fumble):</strong> the spell partly rebounds — it strikes you and one ally within its range as well (the GM chooses the ally and resolves it)."] };
  }
  if (!ctx.countered) return null;
  const spell = ctx.spell, caster = ctx.targetCaster;
  const name = String(spell?.name ?? ctx.effect ?? "").trim();
  const casterToken = caster ? tokenOf(caster) : null;
  if (!name || !casterToken) {
    return { lines: [`<strong>Mirrored Rebuke:</strong> ${esc(name || "the spell")} is negated for its targets and resolves as though cast by you at ${esc(caster?.name ?? "its caster")} — <em>the counter has no spell or caster in hand, so the GM resolves the reflection.</em>`] };
  }
  const feat = hasFeat(actor, FEATS.mirroredRebuke);
  const pp = Math.max(0, int(ctx.dispel?.effectValue ?? ctx.presetDispel?.effectValue ?? spell?.system?.ppCost));
  const out = await withTargets([casterToken.id], () => h().releaseItemSpell(actor, feat, { name, uuid: String(spell?.uuid ?? ""), pp }, { apPaid: true }));
  return {
    lines: [out?.cast
      ? `<strong>Mirrored Rebuke:</strong> ${esc(name)} is turned back on ${esc(caster.name)}, resolving as though cast by you (${pp} PP, none of yours, no casting check; its warps are not carried over).`
      : `<strong>Mirrored Rebuke:</strong> ${esc(name)} is negated, but its reflection could not be cast${out?.missing ? " (the spell was not found)" : ""} — the GM resolves it at ${esc(caster.name)}.`]
  };
}

/* ------------------------------------------------------------------ */
/* Mirrored Rebuke's counter (a cast reaction, as Disrupting Magic)      */
/* ------------------------------------------------------------------ */

export const MIRROR_STEP = "eldritchArts.mirroredRebuke";

/** May this creature counter now? A reason, or "". */
async function counterReadiness(actor) {
  if (!actor) return "no creature";
  if (!hasFeat(actor, FEATS.counterSpell) || !hasFeat(actor, FEATS.mirroredRebuke)) return "no Counter Spell and Mirrored Rebuke";
  if (actor.hasCondition?.("blinded")) return "blinded";
  if (actor.hasCondition?.("fixated")) return "fixated";
  if (await h().isDead?.(actor)) return "dead";
  if (!canDispel(actor)) return "untrained in the Dispel action";
  return "";
}

/**
 * ONE QUESTION A REACTOR (review). Block 3b's Disrupting Magic is asked first
 * (it is registered first) of every reactor holding that spell who is not the
 * caster's ally, within 120 feet, able to react and to Dispel. Such a reactor
 * has already been asked to stop this cast, so Counter Spell is not asked
 * again: they counter through Disrupting Magic (no reflection), or with
 * Counter Spell's Use from the sheet. The same conditions as Block 3b's.
 */
export async function askedByDisruptingMagic(reactor, reactorToken, casterToken) {
  const spell = items(reactor).find((i) => i.type === "spell" && norm(i.name) === "disrupting magic");
  if (!spell || allies(side(reactorToken), side(casterToken))) return false;
  const d = feetBetween(reactorToken, casterToken);
  if (d === null || d > 120) return false;
  if (reactor.hasCondition?.("blinded") || reactor.hasCondition?.("fixated") || !canDispel(reactor)) return false;
  if (await h().isDead?.(reactor)) return false;
  if (await h().reactionRefusal?.(reactor, spell.system?.traits ?? "")) return false;
  if (await h().castRefusal?.(reactor, spell)) return false;
  return true;
}

export async function mirroredRebukeReaction(ctx = {}) {
  const caster = ctx.actor, casterToken = ctx.token;
  if (!caster || !casterToken) return null;
  const said = [];
  for (const reactorToken of tokens()) {
    const reactor = reactorToken.actor;
    if (reactor === caster || reactorToken === casterToken) continue;
    // Not an ally's casting (as Disrupting Magic): nobody is asked to counter a friend.
    if (allies(side(reactorToken), side(casterToken))) continue;
    if (await counterReadiness(reactor)) continue;
    if (await askedByDisruptingMagic(reactor, reactorToken, casterToken)) continue;
    const q = await h().askReactor(reactor, {
      title: `Counter Spell (Mirrored Rebuke) — ${reactor.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${int(ctx.pp)} PP).</p>`
        + "<p>Counter it with <strong>Counter Spell</strong> (a free Dispel, Power Manipulation, at the PP you declare)? Tick Mirrored Rebuke on the Dispel prompt to turn it back on its caster on a Success.</p>",
      buttons: [{ action: "yes", label: "Counter it" }, { action: "no", label: "No" }],
      step: MIRROR_STEP,
      data: { effectValue: int(ctx.pp), dc: int(caster.system?.magic?.spellcraft?.dc), spellName: ctx.spell?.name ?? "", casterUuid: caster.uuid ?? "", spellUuid: ctx.spell?.uuid ?? "" }
    });
    if (!q?.result?.rolled) continue;
    if (q.result.countered) return { stop: true, line: [...said, `${esc(reactor.name)}'s <strong>Counter Spell</strong> (${esc(q.result.degree)}): ${esc(ctx.spell?.name ?? "the spell")} is countered before it resolves.`].join("<br>") };
    said.push(`${esc(reactor.name)}'s <strong>Counter Spell</strong> (${esc(q.result.degree)}) fails to counter ${esc(ctx.spell?.name ?? "the spell")}.`);
  }
  return said.length ? { stop: false, line: said.join("<br>") } : null;
}

/** On the reactor's client: Counter Spell's free Dispel, opened on the incoming spell. */
export async function mirroredRebukeStep(actor, answer, data = {}) {
  const dispel = Array.from(h().skillActions ?? []).find((a) => a.key === "dispel");
  if (!dispel) return { rolled: false };
  const check = await h().resolveAction(actor, { ...dispel, name: "Counter Spell (free Dispel)", apCost: "0", counterSpell: true }, {
    presetDispel: { effectValue: int(data.effectValue), dc: int(data.dc), what: String(data.spellName ?? ""), casterUuid: String(data.casterUuid ?? ""), spellUuid: String(data.spellUuid ?? ""), counterSpell: true, eaCounterSpell: true }
  });
  const degree = norm(check?.outcome?.degree?.key);
  if (!degree) return { rolled: false };
  return { rolled: true, degree: check.outcome.degree.label ?? degree, countered: SUCCESSES.includes(degree) };
}

/* ------------------------------------------------------------------ */
/* Check reactions                                                      */
/* ------------------------------------------------------------------ */

/** Ley Channeler: "Once per day, if you fail a Tap Ley Line check, you may reroll the attempt." */
export const leyChannelerReaction = Object.freeze({
  async after(ctx = {}) {
    const actor = ctx.actor;
    if (!actor?.isOwner || ctx.check?.actionKey !== "tapLeyLine" || !leyChannelerRerolls(ctx.degree)) return null;
    const feat = hasFeat(actor, FEATS.leyChanneler);
    if (!feat || !(usesLeft(feat) > 0)) return null;
    if (!(await confirm(`Ley Channeler — ${actor.name}`, `Your Tap Ley Line came out a ${esc(ctx.degree)}. Spend Ley Channeler's daily use to reroll it? The second result stands.`))) return null;
    if (!(await spendUse(feat))) return null;
    return { reroll: true, label: FEATS.leyChanneler, line: `${esc(actor.name)} uses <strong>Ley Channeler</strong>: the Tap Ley Line is rerolled, and the second result stands.` };
  }
});

/** Spell Recognition's riders (C11): Expert's tradition, Master's +2 after a Critical. */
export const esotericReaction = Object.freeze({
  async after(ctx = {}) {
    const actor = ctx.actor;
    if (!actor?.isOwner || ctx.check?.actionKey !== "spellRecognition") return null;
    const said = [];
    if (hasFeat(actor, FEATS.expert)) said.push("<strong>Esoteric Insight Expert:</strong> you know the spell's tradition, whatever the result — the GM tells you which.");
    if (hasFeat(actor, FEATS.master) && CRITICALS.includes(norm(ctx.degree))) {
      const target = Array.from(globalThis.game?.user?.targets ?? [])[0]?.actor ?? null;
      await freshEffect(actor, "esotericMaster", {
        name: `Esoteric Insight Master: +2 vs ${target?.name ?? "that caster"}'s spells`, img: "icons/svg/aura.svg",
        description: "+2 circumstance on your next saving throw against that caster's spells, before the end of your next turn.",
        system: { conditionals: masterConditionals(target?.uuid ?? "", target?.name ?? "") },
        expiry: expiryFor("endOfNextTurn", actor)
      });
      said.push(`<strong>Esoteric Insight Master:</strong> a fragment of resonance turns back — +2 circumstance on your next saving throw against ${esc(target?.name ?? "that caster")}'s spells before the end of your next turn${target ? "" : " (tick it on that save)"}.`);
    }
    return said.length ? { line: said.join("<br>") } : null;
  }
});

/** Archsage Command: "whenever you critically succeed on an Arcana check … advantage on your next saving throw vs a magical effect (within 1 hour)". */
async function archsageHour(actor, why) {
  await freshEffect(actor, "archsageCommand", {
    name: "Archsage Command: advantage on the next save vs magic", img: "icons/svg/aura.svg",
    description: "Advantage on your next saving throw against a magical effect, within 1 hour.",
    system: { conditionals: archsageConditionals() },
    expiry: forSeconds(3600)
  });
  return `<strong>Archsage Command</strong> (${esc(why)}): advantage on your next saving throw against a magical effect within the hour — tick it on that save.`;
}
export const archsageReaction = Object.freeze({
  async after(ctx = {}) {
    const actor = ctx.actor;
    if (!actor?.isOwner || ctx.type !== "skill" || norm(ctx.subject) !== "arcana" || !CRITICALS.includes(norm(ctx.degree))) return null;
    if (!hasFeat(actor, FEATS.archsage)) return null;
    return { line: await archsageHour(actor, "a Critical on Arcana") };
  }
});

/* ------------------------------------------------------------------ */
/* The Uses                                                             */
/* ------------------------------------------------------------------ */

const threadcutter = {
  hint: "Choose this copy's tradition skill for the Dispel action.",
  async use(actor, item) {
    const mine = item.getFlag?.(MODULE_ID, "threadcutter") ?? item.flags?.[MODULE_ID]?.threadcutter ?? "";
    const taken = new Set(items(actor).filter((i) => i.type === "feat" && norm(i.name) === norm(FEATS.threadcutter) && i.id !== item.id)
      .map((i) => i.flags?.[MODULE_ID]?.threadcutter).filter(Boolean));
    const open = THREADCUTTER_SKILLS.filter(([k]) => !taken.has(k));
    if (!open.length) return warn("Threadcutter: every tradition skill is already chosen by another copy.");
    const picked = await h().chooseFromList("Threadcutter — tradition skill", "Dispel with which skill?", open.map(([k, l]) => [k, l]));
    if (!open.some(([k]) => k === picked)) return false;
    if (picked === mine) return card(actor, "Threadcutter", [line(`This copy already uses <strong>${esc(threadcutterName(picked))}</strong>.`)]);
    const old = items(actor).filter((i) => i.type === "ability" && i.flags?.[MODULE_ID]?.threadcutterFeat === item.id).map((i) => i.id);
    if (old.length) await actor.deleteEmbeddedDocuments("Item", old);
    await actor.createEmbeddedDocuments("Item", [threadcutterAbility(picked, item)]);
    await item.setFlag(MODULE_ID, "threadcutter", picked);
    const label = THREADCUTTER_SKILLS.find(([k]) => k === picked)?.[1] ?? picked;
    await card(actor, "Threadcutter", [line(`<strong>${esc(threadcutterName(picked))}</strong>: the Dispel action is offered from ${esc(label)}, against effects within that tradition's domain.`)]);
    return true;
  }
};

/** Tick the companions: the creatures on your side of the board. */
async function chooseCompanions(actor) {
  const me = tokenOf(actor);
  const list = me ? tokens().filter((t) => t !== me && t.actor !== actor && Number(side(t) ?? 0) === Number(side(me) ?? 0)) : [];
  if (!list.length) return [];
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  const FDE = globalThis.foundry?.applications?.ux?.FormDataExtended ?? globalThis.FormDataExtended;
  const answer = await D?.prompt?.({
    window: { title: "Wanderer’s Mastery — your companions" },
    content: `<p>Who travelled with you?</p>${list.map((t, i) => `<div class="form-group"><label><input type="checkbox" name="t${i}" checked> ${esc(t.name)}</label></div>`).join("")}`,
    ok: { label: "Done", callback: (event, button) => new FDE(button.form).object },
    rejectClose: false
  }).catch(() => null);
  if (!answer) return [];
  return list.filter((t, i) => answer[`t${i}`]).map((t) => t.actor);
}

const wanderersMastery = {
  hint: "Sense the ley lines within a mile, or (once a week) complete the ritual journey.",
  async use(actor, item) {
    const choice = await h().chooseFromList("Wanderer’s Mastery", "What do you do?", [["ley", "Sense the ley lines within 1 mile"], ["journey", "Complete the 8-hour ritual journey (once a week)"]]);
    if (choice === "ley") {
      const token = tokenOf(actor);
      if (!token) return warn("Wanderer’s Mastery: place your token on the map first.");
      const found = await leyLinesWithin(token, 5280);
      return card(actor, "Wanderer’s Mastery", found.length
        ? [line("The ley lines within 1 mile:"), ...found.map((l) => line(`<strong>${esc(l.name || "A ley line")}</strong>: level ${int(l.level)}, ${l.feet === 0 ? "here" : `${int(l.feet)} ft ${esc(l.direction)}`}.`))]
        : [line("No ley line within 1 mile.")]);
    }
    if (choice !== "journey") return false;
    const until = Number(item.getFlag?.(MODULE_ID, "journeyUntil") ?? item.flags?.[MODULE_ID]?.journeyUntil ?? 0);
    if (until > now()) return warn(`Wanderer’s Mastery: the ritual journey is once a week (${Math.ceil((until - now()) / 86400)} more day(s)).`);
    const companions = await chooseCompanions(actor);
    const who = [actor, ...companions];
    for (const a of who) {
      await h().createEffectsOn(a, [effectData("wanderersJourney", {
        name: "Wanderer’s Mastery: +2 luck on saves vs magic", img: "icons/svg/sun.svg",
        description: "A ritual journey realigned you with the magical world: +2 luck bonus on saving throws against magical effects for 24 hours.",
        system: { conditionals: journeyConditionals() },
        expiry: forSeconds(86400)
      })]);
    }
    await item.setFlag(MODULE_ID, "journeyUntil", now() + JOURNEY_LOCK_SECONDS);
    return card(actor, "Wanderer’s Mastery", [line(`The ritual journey is complete: ${who.map((a) => `<strong>${esc(a.name)}</strong>`).join(", ")} gain a <strong>+2 luck bonus</strong> on saving throws against magical effects for 24 hours.`), line("<em>Once a week: the next journey in 7 days.</em>")]);
  }
};

const wanderersSense = {
  hint: "Once a day: automatically succeed at a Survival check to avoid becoming lost in magically active or distorted terrain.",
  ownsFocusUse: true,
  async use(actor, item) {
    if (!(usesLeft(item) > 0)) return warn("Wanderer’s Sense: today's use is spent — daily preparation restores it.");
    await spendUse(item);
    return card(actor, "Wanderer’s Sense", [line("Your Survival check to avoid becoming lost in magically active or distorted terrain <strong>succeeds</strong>."), line("<em>Today's use is spent.</em>")]);
  }
};

export const AUTOMATIONS_B5D = Object.freeze({
  [FEATS.threadcutter]: threadcutter,
  [FEATS.wanderersMastery]: wanderersMastery,
  [FEATS.wanderersSense]: wanderersSense
});

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

/**
 * Every registration group D makes. Called once from registration.mjs with
 * the module API, AFTER Block 2b's (Masked Caster's Spell Trickery replaces
 * Block 2b's option under the same key).
 */
export function registerBlock5D(api = globalThis.game?.trgPrime?.modules, moduleId = MODULE_ID) {
  if (!api) return;
  for (const [name, entry] of Object.entries(AUTOMATIONS_B5D)) api.registerFeatAutomation(name, entry, moduleId);
  for (const [name, entries] of Object.entries(DEGREE_UPGRADES_B5D)) api.registerDegreeUpgrades?.(name, entries.map((e) => ({ ...e })), moduleId);
  for (const [name, entries] of Object.entries(SKILL_SUBSTITUTIONS_B5D)) api.registerSkillSubstitution?.(name, entries.map((e) => ({ ...e })), moduleId);
  api.registerRitualRules?.(RITUAL_RULES_KEY_B5D, { prepare: prepareRitualB5D }, moduleId);
  api.registerDispelModifier?.("dispelPower", { offer: dispelPowerOffer, onResult: dispelPowerResult }, moduleId);
  api.registerDispelModifier?.("mirroredRebuke", { offer: mirroredRebukeOffer, onResult: mirroredRebukeResult }, moduleId);
  api.registerCastOption?.(RUNIC_KEY, runicStabiliserOption, moduleId);
  api.registerCastDegreeRemap?.(RUNIC_KEY, runicStabiliserRemap, moduleId);
  api.registerCastOption?.("spellTrickery", maskedSpellTrickery, moduleId);
  api.registerCheckReaction?.("leyChanneler", leyChannelerReaction, moduleId);
  api.registerCheckReaction?.("esotericInsightB5", esotericReaction, moduleId);
  api.registerCheckReaction?.("archsageCommand", archsageReaction, moduleId);
  api.registerCastReaction?.("mirroredRebuke", mirroredRebukeReaction, moduleId);
  api.registerReactionStep?.(MIRROR_STEP, mirroredRebukeStep, moduleId);
}

/* ------------------------------------------------------------------ */
/* Hooks                                                                */
/* ------------------------------------------------------------------ */

/** Spell Thief's Critical, waiting for Block 2b's borrowed copy (same client). */
export const pendingFreeBorrow = new Map();
/** Block 2b's plan for the action being resolved (its own flag, read before it clears it). */
const B2B_PLAN_FLAG = "block2bPlan";
const TAP_LEY_LINE = B2_ACTIONS.find((a) => a.key === "tapLeyLine");

/**
 * trgPrimeActionResolved. The synchronous part runs first: Block 2b's handler,
 * wired before this one, clears its plan and creates the borrowed copy only
 * after its own awaits.
 */
export async function onActionResolvedB5D(ctx = {}) {
  const { actor, action, targetActor } = ctx;
  const key = String(action?.key ?? "");
  const raw = norm(ctx.degree);
  if (!actor || !raw) return;
  // Synchronous, before anything is awaited.
  if (key === "borrowSpell" && actor.isOwner && CRITICALS.includes(raw) && hasFeat(actor, FEATS.spellThief)) pendingFreeBorrow.set(actor.uuid, now());
  const circlePlan = key === "inscribeSummoningCircle" ? actor.getFlag?.(MODULE_ID, B2B_PLAN_FLAG) ?? null : null;

  // Masked Caster: the caster's, though the observer rolled.
  if (key === "seeThroughSpellTrickery" && raw === "blunder" && hasFeat(targetActor, FEATS.maskedCaster) && actor.isOwner) {
    await card(targetActor, "Masked Caster", [line(`${esc(actor.name)} blundered seeing through your Spell Trickery: you may plant <strong>two</strong> false details (e.g. “it’s harmless” and “it’s divine”).`)]);
    return;
  }
  if (!actor.isOwner) return;
  switch (key) {
    case "tapLeyLine": {
      const feat = hasFeat(actor, FEATS.leyChanneler);
      const dice = feat ? leyChannelerDice(printedDegree(TAP_LEY_LINE, ctx.resolvedDegree ?? ctx.degree)) : null;
      if (!dice) return;
      const roll = await new Roll(dice).evaluate();
      const { value, max } = ppOf(actor);
      const after = Math.min(max, value + int(roll.total));
      await actor.update({ "system.resources.pp.value": after });
      await card(actor, "Ley Channeler", [line(`You draw <strong>${int(roll.total)} PP</strong> (${dice}) from the ley line: PP ${value} → ${after}${value + int(roll.total) > after ? " (capped at your maximum)" : ""}.`)]);
      return;
    }
    case "hypnotismSuggestion": {
      const seconds = hasFeat(actor, FEATS.savant) ? savantSuggestionSeconds(raw) : null;
      if (!seconds) return;
      await card(actor, "Hypnotic Savant", [line(`With Hypnotic Savant the suggestion lasts <strong>${describeSeconds(seconds)}</strong> (in place of the duration above).`)]);
      return;
    }
    case "hypnotismMemory": {
      if (!hasFeat(actor, FEATS.savant) || !SUCCESSES.includes(raw) || !targetActor || !isSpellcaster(targetActor)) return;
      const { value, max } = ppOf(targetActor);
      if (targetActor.isOwner) {
        const after = Math.min(max, value + 1);
        await targetActor.update({ "system.resources.pp.value": after });
        await card(actor, "Hypnotic Savant", [line(`${esc(targetActor.name)} regains <strong>1 PP</strong> (PP ${value} → ${after}${after === value ? ", already at its maximum" : ""}).`)]);
      } else {
        await card(actor, "Hypnotic Savant", [line(`${esc(targetActor.name)} regains <strong>1 PP</strong> — <em>the GM adds it (not yours to change).</em>`)]);
      }
      return;
    }
    case "inscribeSummoningCircle": {
      if (!hasFeat(actor, FEATS.circleAdept)) return;
      const level = int(circlePlan?.level);
      const care = String(circlePlan?.care ?? "");
      await card(actor, "Circle Adept", [line(level
        ? `The circle took half the normal time to draw: <strong>${circleAdeptMinutes(level, care)} minutes</strong> (instead of ${circleMinutes(level, care)}).`
        : "The circle took half the normal time to draw.")]);
      return;
    }
    case "appraiseMagic": {
      if (!CRITICALS.includes(raw) || !hasFeat(actor, FEATS.magusAppraiser)) return;
      await gmCard(actor, "Magus Appraiser", [line(`${esc(actor.name)}'s Critical: they also learn whether the item is cursed or has unusual activation requirements — tell them.`)]);
      return;
    }
    case "quickbind": {
      if (!SUCCESSES.includes(raw) || !hasFeat(actor, FEATS.rapidBinder)) return;
      await card(actor, "Rapid Binder", [line("The item is invested: you may activate it this round, as if it had already been invested.")]);
      return;
    }
    default:
  }
}

/** trgPrimeSpellSettled: Archsage Command's Critical on a ritual you lead. */
export async function onSpellSettledB5D(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner || !ctx.ritual || !CRITICALS.includes(norm(ctx.degree)) || !hasFeat(actor, FEATS.archsage)) return;
  await card(actor, "Archsage Command", [line(await archsageHour(actor, "a Critical ritual"))]);
}

/**
 * createActiveEffect: Essence Reservoir holds Tap Magical Energy's siphoned
 * essence for 1 minute, up to Power Manipulation ranks; the rest keeps the
 * end of the next turn (a second effect, its `before` raised by what is held).
 */
export async function onEffectCreatedB5D(effect, options = {}, userId = null) {
  if (effect?.getFlag?.(MODULE_ID, "source") !== "siphonedEssence") return;
  if (userId && globalThis.game?.user?.id && userId !== game.user.id) return;
  const actor = effect.parent;
  if (!actor || (actor.documentName && actor.documentName !== "Actor")) return;
  if (effect.getFlag(MODULE_ID, "eaReservoir") || effect.getFlag(MODULE_ID, "eaReservoirExcess")) return;
  if (!hasFeat(actor, FEATS.reservoir)) return;
  const ranks = int(actor.system?.skills?.powerManipulation?.ranks);
  const held = ownEffects(actor, "siphonedEssence").filter((e) => e.id !== effect.id && e.getFlag(MODULE_ID, "eaReservoir")).reduce((s, e) => s + int(e.getFlag(MODULE_ID, "siphon")), 0);
  const gained = int(effect.getFlag(MODULE_ID, "siphon"));
  const before = int(effect.getFlag(MODULE_ID, "before"));
  const { stored, excess } = reservoirSplit({ gained, held, ranks });
  if (!stored) {
    await card(actor, "Essence Reservoir", [line(`Your reservoir already holds ${held} PP (your Power Manipulation ranks, ${ranks}): this essence keeps its normal end.`)]);
    return;
  }
  // The excess keeps the effect's clock as it was made: copied before it is changed.
  const original = excess ? (typeof effect.toObject === "function" ? effect.toObject() : JSON.parse(JSON.stringify(effect))) : null;
  const minute = forSeconds(60);
  await effect.update({
    name: `Siphoned essence (${stored} PP, Essence Reservoir)`,
    [`flags.${SYSTEM_ID}.spellEffect`]: true,
    [`flags.${SYSTEM_ID}.spellEffectEnd`]: minute.system.spellEffectEnd,
    [`flags.${MODULE_ID}.${TURN_END_FLAG}`]: null,
    [`flags.${MODULE_ID}.eaReservoir`]: true,
    [`flags.${MODULE_ID}.siphon`]: stored,
    description: "Essence Reservoir: these siphoned PP dissipate after 1 minute if unspent."
  });
  if (original) {
    const data = original;
    delete data._id;
    delete data.id;
    data.name = `Siphoned essence (${excess} PP)`;
    data.flags = { ...(data.flags ?? {}), [MODULE_ID]: { ...(data.flags?.[MODULE_ID] ?? {}), siphon: excess, before: before + stored, eaReservoir: false, eaReservoirExcess: true } };
    await actor.createEmbeddedDocuments("ActiveEffect", [data]);
  }
  await card(actor, "Essence Reservoir", [line(`<strong>${stored} PP</strong> of the siphoned essence is held for 1 minute${excess ? `; ${excess} PP beyond your Power Manipulation ranks (${ranks}) keep the end of your next turn` : ""}.`)]);
}

/** createItem: Spell Thief's Critical makes Block 2b's borrowed copy a free preparation (C13), one at a time. */
export async function onItemCreatedB5D(item, options = {}, userId = null) {
  if (item?.type !== "spell" || !item.flags?.[MODULE_ID]?.borrowed) return;
  if (userId && globalThis.game?.user?.id && userId !== game.user.id) return;
  const actor = item.parent;
  if (!actor?.isOwner || !pendingFreeBorrow.has(actor.uuid)) return;
  pendingFreeBorrow.delete(actor.uuid);
  if (!hasFeat(actor, FEATS.spellThief)) return;
  const lines = [];
  for (const old of items(actor).filter((i) => i.type === "spell" && i !== item && i.id !== item.id && i.flags?.[SYSTEM_ID]?.memorisationFree && i.flags?.[MODULE_ID]?.borrowed)) {
    await old.update({ [`flags.${SYSTEM_ID}.memorisationFree`]: false, "system.prepared": false });
    lines.push(line(`<em>${esc(old.name)} is no longer your free borrowed spell (one at a time): it is unprepared, and counts again when you prepare it.</em>`));
  }
  await item.update({ [`flags.${SYSTEM_ID}.memorisationFree`]: true, "system.prepared": true });
  await card(actor, "Spell Thief", [line(`<strong>${esc(item.name)}</strong> is a free preparation: prepared, and not counted against your memorised spells, until it leaves your book at your next daily preparation.`), ...lines]);
}

/* For the harness. */
export const USES_B5D = Object.freeze({ threadcutter, wanderersMastery, wanderersSense });
