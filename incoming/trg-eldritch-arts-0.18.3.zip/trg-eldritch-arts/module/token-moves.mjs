/**
 * WHERE A TOKEN'S MOVE ENDS (0.11.2; logged live on Foundry 14.367).
 *
 * In V14's `updateToken` hook the token document's getters (`doc.x`, `doc.y`,
 * `doc.regions`) and its placeable still hold the OLD position while a move
 * animates; the document's `_source` and the hook's `change` hold the new.
 * The module's two token-centre helpers (block1-automations `tokenCentre`,
 * areas.mjs) read `_source` first. Block 8a's handlers, which have `change`
 * in hand, read the end from it through this helper.
 */

/** The move's end, document-shaped: `change` first, then the stored `_source`, then the document. */
export function endPositionOf(doc, change = {}) {
  const c = change ?? {};
  const s = doc?._source ?? {};
  const pick = (k, fallback) => Number(c[k] ?? s[k] ?? doc?.[k] ?? fallback);
  return { id: doc?.id, actor: doc?.actor, parent: doc?.parent, x: pick("x", 0), y: pick("y", 0), width: pick("width", 1), height: pick("height", 1) };
}
