/**
 * Block 9c (0.15.0, on TRG Prime 3.690.0): the orbs, the rods' module powers,
 * the staves' abilities, and the Spellhold rune's store. The rules are
 * module/block9c-rules.mjs; what TRG Prime already does (an orb's charge, its
 * wondrous abilities, a rod's metamagic, a staff's spells) is in the items'
 * own data (tools/content/block9c.mjs).
 *
 *   The Orb      a charged kind (H23): the orb's ladder, no natural recharge,
 *                Recharge Item at 4 PP, its 41–65 a Resonant Flare; one
 *                invested at a time (H25); its Critical Tap riders
 *   The rods     Binding Seal, Soul's Echo and Wild Surges as casting options
 *                (paid 1 PP from the rod once the cast is settled, or held);
 *                Ley Resonance as a source of PP; Catalyst Flow in the
 *                catalyst's settle (block9a-automations.mjs)
 *   Spellhold    the staff's sheet: store a spell (TRG Prime's hold window,
 *                H26), release one (Command, 1 AP), and the store fades at
 *                daily preparation
 */
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, tokenOf, feetBetween } from "./block1-automations.mjs";
import { allies, SOCKET } from "./block3b-automations.mjs";
import { isActingGM } from "./writer.mjs";
import * as R from "./block9c-rules.mjs";

const items = (actor) => Array.from(actor?.items ?? []);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (token) => token?.document?.disposition;
const within = (a, b, feet) => { const d = feetBetween(a, b); return d !== null && d <= feet; };
const core = async (path) => import(globalThis.foundry?.utils?.getRoute?.(`systems/trg-prime/${path}`) ?? `/systems/trg-prime/${path}`);

/** The flag the pack writes on each 9c item: its book name. */
export const ITEM_FLAG = "charged9c";
const upperOf = (item) => item?.flags?.[MODULE_ID]?.[ITEM_FLAG] ?? null;
const broken = (item) => int(item?.system?.hp?.max) > 0 && int(item?.system?.hp?.value) <= 0;
const held = (item) => Boolean(item?.system?.equipped) && !broken(item);

/** The held rod whose module power is `power`, or null. */
export function heldRod(actor, power) {
  return items(actor).find((i) => held(i) && R.RODS_9C[upperOf(i)]?.power === power) ?? null;
}
/** The held orbs, as { item, spec }. */
export function heldOrbs(actor) {
  return items(actor).filter((i) => held(i) && R.ORBS_9C[upperOf(i)]).map((item) => ({ item, spec: R.ORBS_9C[upperOf(item)] }));
}

/* ------------------------------------------------------------------ */
/* The Orb (H23, H25)                                                   */
/* ------------------------------------------------------------------ */

/** The kind's release ladder (TRG Prime's `releaseOptions`). */
export async function orbReleaseOptions(ctx = {}) {
  const [{ TRADITION_SKILLS }, { maxPPPerCast }] = await Promise.all([core("module/charged-items.mjs"), core("module/magic/casting.mjs")]);
  return R.orbReleaseOptions({ ...ctx, casterCap: maxPPPerCast(int(ctx.casterLevel)), traditionSkills: TRADITION_SKILLS });
}

/**
 * The kind's Charge Depletion (L9311): a 41–65 "unleashes a Resonant Flare …
 * a Wild Surge (based on the orbs level) that affects all creatures in a
 * 20-foot radius … The Orb is depleted (0 PP) but not broken." Any other row
 * is the core's.
 */
export async function orbDepletion({ actor, item, row } = {}) {
  if (!R.isFlareRow(row) || !item) return null;
  await item.update({ "system.uses": 0 });
  const level = int(item.system?.itemLevel) || int(R.ORBS_9C[upperOf(item)]?.level) || 1;
  // THE TABLE FROM ITS OWN FILE (0.15.1, live test): block2-automations
  // imports WILD_SURGE but does not export it, so it read as undefined.
  const { rollTable } = await import("./block2-automations.mjs");
  const { WILD_SURGE } = await import("./chapter7-tables.mjs");
  await rollTable(actor, { table: WILD_SURGE, column: "e", title: `${item.name} — Resonant Flare`, level, source: "wildSurge", radiusFeet: R.FLARE_RADIUS,
    // AN EXPIRY, AS EVERY OTHER WILD SURGE HAS (0.15.1, review): 1 round per area level.
    expiry: forSeconds(6 * Math.max(1, level)) });
  return { replaces: true, lines: [`<strong>Resonant Flare</strong> — instead of breaking, ${esc(item.name)} unleashes a Wild Surge (area level ${level}) on every creature within ${R.FLARE_RADIUS} feet. It is depleted to <strong>0 PP</strong> and is not broken.`] };
}

/** trgPrimeActionResolved: a Critical Tap Ley Line with a held orb that holds 3 PP or more. */
export async function onActionResolvedB9c(ctx = {}) {
  const { actor, action, degree } = ctx;
  if (action?.key !== "tapLeyLine" || degree !== "critical" || !actor?.isOwner) return;
  for (const { item, spec } of heldOrbs(actor)) {
    if (!spec.criticalTap || !item.system?.invested) continue;
    if (int(item.system?.uses) < R.ORB_ABILITY_MIN_PP) {
      await card(actor, `${item.name} — Critical Tap`, [line(`${esc(item.name)} holds ${int(item.system?.uses)} PP: its ability does not work at 2 PP or less.`)]);
      continue;
    }
    if (spec.criticalTap === "seeInvisible") await seeInvisibleFrom(actor, item);
    if (spec.criticalTap === "fastHealing") await fastHealingFrom(actor, item);
  }
}

/** Shattered Veils: "the effects of a See Invisible spell (with the +4 PP warping option) for 10 minutes". */
async function seeInvisibleFrom(actor, item) {
  const { normaliseAvoidanceSight } = await core("module/magic/avoidance-sight.mjs");
  const spec = normaliseAvoidanceSight({ kind: "avoidanceSight", sight: "seeInvisible", level: "concealed" }, { sightLevel: "clear" });
  if (!spec) return;
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("shatteredVeils9c", {
    name: `See Invisible (${item.name})`, img: "icons/svg/eye.svg",
    system: { spellBuff: true, [spec.flag]: spec.level }, expiry: forSeconds(600)
  })]);
  await card(actor, `${item.name} — Critical Tap`, [line(`${esc(actor.name)} sees as See Invisible with its +4 PP warp — invisible creatures are seen clearly, not concealed — for 10 minutes.`)]);
}

/** Verdant Heart: "you and all allies within 10 feet gain Fast Healing 2 for 1 minute". */
async function fastHealingFrom(actor, item) {
  const me = tokenOf(actor);
  const reached = [actor, ...(me ? tokens().filter((t) => t.actor !== actor && allies(side(t), side(me)) && within(t, me, 10)).map((t) => t.actor) : [])];
  const data = effectData("verdantHeart9c", {
    name: `Fast Healing 2 (${item.name})`, img: "icons/svg/regen.svg",
    system: { fastHealing: 2 }, expiry: forSeconds(60)
  });
  for (const target of [...new Set(reached)]) await writeOn(target, { kind: "createEffect", data });
  await card(actor, `${item.name} — Critical Tap`, [line(`Fast Healing 2 for 1 minute: ${reached.map((a) => esc(a.name)).join(", ")}.`)]);
}

/* ------------------------------------------------------------------ */
/* The socket: a write on a creature this client does not own             */
/* ------------------------------------------------------------------ */

export const SOCKET_ACTION_9C = "block9c";
/** Is this write one the acting GM may make for another client? Pure. */
export function writeAllowed9c(op = {}) {
  return op.kind === "createEffect" && op.data?.flags?.[MODULE_ID]?.source === "verdantHeart9c" && int(op.data?.flags?.[SYSTEM_ID]?.fastHealing) === 2;
}
async function writeOn(actor, op) {
  if (!actor || !writeAllowed9c(op)) return false;
  if (actor.isOwner) { await actor.createEmbeddedDocuments("ActiveEffect", [op.data]); return true; }
  const game = globalThis.game;
  if (!game?.users?.activeGM) { warn(`No GM is connected to update ${actor.name} (Eldritch Arts): apply it by hand.`); return false; }
  game.socket?.emit?.(SOCKET, { action: SOCKET_ACTION_9C, actorUuid: actor.uuid, op });
  return true;
}
/** The acting GM's side of the socket. */
export async function onBlock9cSocket(data = {}) {
  if (data?.action !== SOCKET_ACTION_9C || !isActingGM()) return false;
  const actor = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(data.actorUuid);
  if (!actor || !writeAllowed9c(data.op ?? {})) return false;
  await actor.createEmbeddedDocuments("ActiveEffect", [data.op.data]);
  return true;
}

/* ------------------------------------------------------------------ */
/* The rods (H24)                                                       */
/* ------------------------------------------------------------------ */

/** A held rod of this power that may be used now (not broken, the round's Rod free), or null. */
async function usableRod(actor, power) {
  const rod = heldRod(actor, power);
  if (!rod || !rod.system?.invested) return null;
  if (await h().rodUseRefusal?.(actor)) return null;
  return rod;
}

/** Rod powers taken on a cast, waiting to be paid: actor uuid → [{ power, rodId }]. */
const pending = new Map();
const OPTION_KEYS = Object.freeze({ bindingSeal: "eaBindingSeal", soulsEcho: "eaSoulsEcho", wildSurges: "eaWildSurges" });
const takes = (actor, power, rod) => {
  const list = (pending.get(actor.uuid) ?? []).filter((p) => p.power !== power);
  pending.set(actor.uuid, [...list, { power, rodId: rod.id, rodName: rod.name }]);
};
/**
 * ONE ROD A CAST (review): "only one Rod may be used each round". The offers
 * are asked before any is applied, so each passes the round's stamp; the
 * first applied takes the round, and a power on another rod is refused.
 * Returns the line saying so, or "".
 */
export function otherRodRefusal(list = [], rod = {}) {
  const other = (Array.isArray(list) ? list : []).find((p) => p?.rodId && p.rodId !== rod?.id);
  return other ? `${rod?.name ?? "That rod"} is not used: only one Rod may be used each round, and ${other.rodName || "another rod"} already is.` : "";
}
// THE CORE'S RODS TOO (0.15.2, on TRG Prime 3.691.0): a metamagic rod's power,
// a Rod of the Magi's draw — `ctx.rodsThisCast`, as {itemId, name}.
const coreRods = (ctx = {}) => (Array.isArray(ctx.rodsThisCast) ? ctx.rodsThisCast : []).map((r) => ({ rodId: r?.itemId, rodName: r?.name }));
const refusedByOtherRod = (actor, rod, ctx = {}) => otherRodRefusal([...coreRods(ctx), ...leyDrawn(ctx), ...(pending.get(actor.uuid) ?? [])], rod);
/** The Rod of Ley Resonance, when it paid part of this cast (a PP source, asked before the options). */
function leyDrawn(ctx = {}) {
  const drew = (Array.isArray(ctx.ppSources) ? ctx.ppSources : []).some((d) => norm(d?.key) === "ealeyresonance" && int(d?.drawn) > 0);
  const memo = drew ? leyRate.get(ctx.actor?.uuid) : null;
  return memo ? [{ rodId: memo.rodId, rodName: ctx.actor?.items?.get?.(memo.rodId)?.name ?? "the Rod of Ley Resonance" }] : [];
}
/** A NEW CAST'S OFFERS: whatever an earlier cast left unpaid (one called off after its options) is dropped. */
const freshCast = (actor) => { if (actor?.uuid) pending.delete(actor.uuid); };
const casts = (ctx) => !(ctx.innate || ctx.itemCast || ctx.stored || ctx.ritual);

export const ROD_OPTIONS_9C = Object.freeze({
  // "When casting a spell with the Summons trait, you may draw a PP from this
  // rod to reduce the casting DC by 1" (m180; Q208: once a cast).
  [OPTION_KEYS.bindingSeal]: {
    async offer(ctx = {}) {
      freshCast(ctx.actor);
      if (!casts(ctx) || !R.isSummons(ctx.spell?.system?.traits)) return null;
      const rod = await usableRod(ctx.actor, "bindingSeal");
      return rod && !otherRodRefusal(coreRods(ctx), rod) ? { label: `${rod.name}: casting DC −1 (1 PP from the rod)`, hint: `${int(rod.system?.uses)} PP held. Paid once the cast is settled.` } : null;
    },
    async apply(ctx = {}) {
      const rod = heldRod(ctx.actor, "bindingSeal");
      if (!rod) return { label: "Binding Seal", lines: [] };
      const refused = refusedByOtherRod(ctx.actor, rod, ctx);
      if (refused) return { label: rod.name, lines: [esc(refused)] };
      takes(ctx.actor, "bindingSeal", rod);
      return { castingDC: -1, label: rod.name, rodItemId: rod.id, rodName: rod.name, lines: [`${esc(rod.name)}: casting DC −1 (1 PP from the rod).`] };
    }
  },
  // "You may expend a PP from this rod when casting a spell. The spell's save
  // DC is increased by 2 for undead targets of this casting" (m181).
  [OPTION_KEYS.soulsEcho]: {
    async offer(ctx = {}) {
      freshCast(ctx.actor);
      if (!casts(ctx) || !R.hasSave(ctx.spell?.system?.defence)) return null;
      const rod = await usableRod(ctx.actor, "soulsEcho");
      return rod && !otherRodRefusal(coreRods(ctx), rod) ? { label: `${rod.name}: Save DC +2 for undead targets (1 PP from the rod)`, hint: `${int(rod.system?.uses)} PP held. Paid once the cast is settled.` } : null;
    },
    async apply(ctx = {}) {
      const rod = heldRod(ctx.actor, "soulsEcho");
      if (!rod) return { label: "Soul's Echo", lines: [] };
      const refused = refusedByOtherRod(ctx.actor, rod, ctx);
      if (refused) return { label: rod.name, lines: [esc(refused)] };
      takes(ctx.actor, "soulsEcho", rod);
      return { saveDCTarget: { traits: ["undead"], value: 2 }, label: rod.name, rodItemId: rod.id, rodName: rod.name, lines: [`${esc(rod.name)}: each undead target's Save DC is 2 higher (1 PP from the rod).`] };
    }
  },
  // "You may expend a PP from this rod when casting a spell to trigger a Wild
  // Surge. Area level = the spell's PP; the spell resolves normally" (M87).
  [OPTION_KEYS.wildSurges]: {
    async offer(ctx = {}) {
      freshCast(ctx.actor);
      if (!casts(ctx)) return null;
      const rod = await usableRod(ctx.actor, "wildSurges");
      return rod && !otherRodRefusal(coreRods(ctx), rod) ? { label: `${rod.name}: a Wild Surge ${ctx.holding ? "as the spell is stored" : "once the spell resolves"} (1 PP from the rod)`, hint: `${int(rod.system?.uses)} PP held. Area level = the spell's PP.` } : null;
    },
    async apply(ctx = {}) {
      const rod = heldRod(ctx.actor, "wildSurges");
      if (!rod) return { label: "Wild Surges", lines: [] };
      const refused = refusedByOtherRod(ctx.actor, rod, ctx);
      if (refused) return { label: rod.name, lines: [esc(refused)] };
      takes(ctx.actor, "wildSurges", rod);
      return { label: rod.name, rodItemId: rod.id, rodName: rod.name, lines: [`${esc(rod.name)}: a Wild Surge ${ctx.holding ? "as the spell is stored" : "follows the spell"} (1 PP from the rod).`] };
    }
  }
});

/**
 * PAID ONCE THE CAST IS OVER (trgPrimeSpellSettled), or once it is held
 * (trgPrimeSpellHeld): each power taken pays 1 PP from its rod through TRG
 * Prime's one spend path (the round's Rod, Charge Depletion), and Wild Surges
 * then surges. A refunded cast pays nothing.
 */
export async function settleRodPowers({ actor, castOptions = [], refunded = false, castPP = 0, held = false } = {}) {
  if (!actor) return;
  const taken = pending.get(actor.uuid) ?? [];
  pending.delete(actor.uuid);
  if (!taken.length || refunded || !actor.isOwner) return;
  const keys = new Set((castOptions ?? []).map((k) => norm(k)));
  const lines = [];
  for (const p of taken) {
    // ONLY THE POWERS THIS CAST TOOK (review), held or not.
    if (!keys.has(norm(OPTION_KEYS[p.power]))) continue;
    const rod = actor.items?.get?.(p.rodId);
    if (!rod) continue;
    lines.push(line(await h().spendFromRod(actor, rod, 1, { reason: R.ROD_POWERS[p.power] })));
    if (p.power === "wildSurges") {
      const level = Math.max(1, int(castPP));
      const { rollTable } = await import("./block2-automations.mjs");
      const { WILD_SURGE } = await import("./chapter7-tables.mjs");
      await rollTable(actor, { table: WILD_SURGE, column: "e", title: `${rod.name} — Wild Surge`, level, source: "wildSurge", radiusFeet: 5 * level, expiry: forSeconds(6 * level) });
    }
  }
  if (lines.length) await card(actor, "Rod powers", lines);
}
export async function onSpellSettledB9c(ctx = {}) {
  // A WOVEN OR HELD RELEASE TAKES NO OPTIONS OF ITS OWN (review): Spellthread's
  // second spell settles inside the first's, and must not drop what the first
  // has yet to pay.
  if (ctx.threaded || ctx.held) return;
  return settleRodPowers({ actor: ctx.actor, castOptions: ctx.castOptions, refunded: ctx.refunded, castPP: ctx.castPP ?? ctx.ppSpent });
}
export async function onSpellHeldB9c(ctx = {}) {
  return settleRodPowers({ actor: ctx.actor, castOptions: ctx.castOptions ?? ctx.record?.castOptions, castPP: ctx.record?.pp, held: true });
}

/**
 * THE ROD OF LEY RESONANCE as a source of a cast's PP (TRG Prime's
 * `registerCastPPSource`): "expend PP from this rod instead of your own
 * reserve. Within 60 ft of a ley line, each rod PP counts as 2 (round the
 * cost up)" (M86).
 */
const leyRate = new Map();
async function leyLineWithin(actor, feet) {
  const token = tokenOf(actor);
  if (!token) return null;
  const { leyLinesWithin } = await import("./areas.mjs");
  return (await leyLinesWithin(token, feet))[0] ?? null;
}
export const LEY_RESONANCE_SOURCE = Object.freeze({
  async offer(ctx = {}) {
    const actor = ctx.actor;
    const rod = await usableRod(actor, "leyResonance");
    if (!rod || int(rod.system?.uses) <= 0) return null;
    // NOT BESIDE THE CORE'S ROD (0.15.2): a metamagic rod's power or a Rod of
    // the Magi's draw already taken for this cast.
    if (otherRodRefusal(coreRods(ctx), rod)) return null;
    const near = Boolean(await leyLineWithin(actor, R.LEY_RESONANCE_FEET));
    const rate = R.leyResonanceRate(near);
    leyRate.set(actor.uuid, { rate, rodId: rod.id });
    const max = Math.min(R.leyResonanceMax(rod.system?.uses, rate), int(ctx.payable ?? ctx.totalPP));
    if (max <= 0) return null;
    // NAMED AS A ROD (0.15.2), so TRG Prime counts it as the cast's Rod.
    return { label: rod.name, hint: `${int(rod.system?.uses)} PP held${near ? "; a ley line is within 60 feet, so each rod PP counts as 2" : ""}.`, max, rodItemId: rod.id, rodName: rod.name };
  },
  async settle(ctx = {}, { paid = 0 } = {}) {
    const actor = ctx.actor;
    const memo = leyRate.get(actor?.uuid);
    leyRate.delete(actor?.uuid);
    const rod = memo ? actor.items?.get?.(memo.rodId) : null;
    if (!rod || int(paid) <= 0) return { lines: [] };
    const cost = R.leyResonanceRodCost(paid, memo.rate);
    const said = await h().spendFromRod(actor, rod, cost, { reason: "Ley Resonance" });
    return { lines: [`${memo.rate > 1 ? `Near a ley line: ${int(paid)} PP of the cast for ${cost} rod PP. ` : ""}${said}`] };
  }
});

/**
 * CATALYST FLOW (Q209), asked by the catalyst's settle once Catalyst
 * Conservation has not kept it: "expend 2 PP from this rod to prevent it from
 * being expended" — on any degree. Resolves whether the catalyst is kept.
 */
export async function catalystFlowKeeps(actor, name, lines = []) {
  const rod = await usableRod(actor, "catalystFlow");
  if (!rod) return false;
  const choice = await h().chooseFromList?.(rod.name, `Spend 2 PP from ${esc(rod.name)} (${int(rod.system?.uses)} held) to keep ${esc(name)}?`, [["yes", "Keep it (2 PP)"], ["no", "Let it be spent"]]);
  if (choice !== "yes") return false;
  lines.push(await h().spendFromRod(actor, rod, 2, { reason: "Catalyst Flow" }));
  lines.push(`${esc(name)} is not expended.`);
  return true;
}

/* ------------------------------------------------------------------ */
/* Spellhold (H26)                                                      */
/* ------------------------------------------------------------------ */

/** The Spellhold rune on a staff — its runes field, or a charged staff's weapon form — or null: { tier }. */
export async function spellholdOn(item) {
  const { runesOnField } = await import("./block9b-automations.mjs");
  const fields = [item?.system?.effectiveRunes, item?.system?.runes, item?.flags?.[SYSTEM_ID]?.chargedItem?.weaponForm?.runes].filter(Boolean);
  for (const field of fields) {
    const rune = runesOnField(String(field)).find((r) => r.upper === "SPELLHOLD");
    if (rune) return { tier: rune.tier };
  }
  return null;
}
const ROMAN = ["", "I", "II", "III", "IV"];

/** The staff's Spellhold window: its spells, room, and Store and Release. */
export async function openSpellhold(item) {
  const actor = item?.parent;
  const rune = await spellholdOn(item);
  if (!actor || !rune) return null;
  const label = `Spellhold ${ROMAN[rune.tier] ?? rune.tier}`;
  const capacity = R.spellholdCapacity(rune.tier);
  const list = await h().heldSpellsIn(item);
  const used = list.reduce((sum, r) => sum + int(r.pp), 0);
  const rows = list.length
    ? list.map((r) => [r.id, `Release ${r.spellName} (${r.pp} PP, ${r.degreeLabel}${r.attack ? `, attack ${r.total}` : ""}${r.saveDC ? `, Save DC ${r.saveDC}` : ""})`])
    : [];
  const choice = await h().chooseFromList?.(`${item.name} — ${label}`,
    `Holds ${used} of ${capacity} PP of spells. Store one by casting it now; release one for a Command (1 AP). Stored spells fade at your next daily preparation.`,
    [...rows, ["store", "Store a spell (cast it next)"], ["close", "Close"]]);
  if (!choice || choice === "close") return null;
  if (!item.system?.equipped || !item.system?.invested) return warn(`${item.name}: ${label} works while the staff is held and invested by you.`);
  if (choice === "store") {
    if (used >= capacity) return warn(`${item.name} is full (${used} of ${capacity} PP).`);
    // REFUSED, SAID ONCE (0.15.1, live test): TRG Prime will not overwrite an
    // open Spell Storing window, and warns why; no "cast it now" card follows.
    const armed = await h().armHold(actor, item, { capacityPP: capacity, label: `${item.name} (${label})` });
    if (!armed) return null;
    await card(actor, `${item.name} — ${label}`, [line(`Cast the spell to store now, this round: its check is rolled and its PP spent as it is stored. ${capacity - used} PP of room.`)]);
    return "armed";
  }
  return h().releaseHeldSpell(actor, item, choice, { ap: "1", label: `${item.name} (${label})` });
}

/** getHeaderControlsApplicationV2: a staff with Spellhold offers its store. */
export function onHeaderControlsB9c(app, controls) {
  const item = app?.document ?? app?.item;
  if (item?.documentName !== "Item" || !item.isOwner || !item.parent || !Array.isArray(controls)) return;
  if (controls.some((c) => c?.action === "eaSpellhold")) return;
  const field = [item.system?.effectiveRunes, item.system?.runes, item.flags?.[SYSTEM_ID]?.chargedItem?.weaponForm?.runes].filter(Boolean).join(", ");
  if (!/spellhold/i.test(field)) return;
  controls.push({ action: "eaSpellhold", icon: "fa-solid fa-box-archive", label: "Spellhold", onClick: () => openSpellhold(item) });
}

/** trgPrimeDailyPreparation: "stored spells fade at your next daily preparation". */
export async function onDailyPreparationB9c({ actor } = {}) {
  if (!actor?.isOwner) return;
  const faded = [];
  for (const item of items(actor)) {
    if (!(await spellholdOn(item))) continue;
    const n = await h().clearHeldSpells(item);
    if (n) faded.push(`${esc(item.name)}: ${n} stored spell${n === 1 ? "" : "s"} fade.`);
  }
  if (faded.length) await card(actor, "Spellhold", faded.map((t) => line(t)));
}

/** ready: the GM's side of this block's socket (Verdant Heart's Fast Healing on another's ally). */
export function onReadyB9c() {
  globalThis.game?.socket?.on?.(SOCKET, (data) => { onBlock9cSocket(data).catch((err) => console.warn("Eldritch Arts | Block 9c socket", err)); });
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export function registerBlock9c(api, moduleId) {
  api.registerChargedKind?.("orb", {
    label: "Orb", warp: "staff", naturalRecharge: false, rechargeItemPP: 4,
    releaseOptions: orbReleaseOptions, depletion: orbDepletion
  }, moduleId);
  api.registerOneInvestedTraits?.(["orb"], moduleId);
  for (const [key, spec] of Object.entries(ROD_OPTIONS_9C)) api.registerCastOption?.(key, spec, moduleId);
  api.registerCastPPSource?.("eaLeyResonance", LEY_RESONANCE_SOURCE, moduleId);
}
