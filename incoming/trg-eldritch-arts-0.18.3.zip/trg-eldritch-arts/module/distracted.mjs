/**
 * DISTRACTED (0.10.0, Block 7; sidebar 34, after L10708; Graham's Q157 "as
 * proposed", 7 November 2026). The book: "Whilst you have the condition, you
 * take a -1 penalty to all actions." Q157 reads that as a −1 status penalty to
 * attack checks, skill checks, saving throws and casting checks, and not to DB
 * or damage.
 *
 * NOT A CORE CONDITION, and a module cannot register one (audit §4). So it is
 * the spell engine's own `bonus` row, laid, timed and removed as any spell row
 * is. ONE EFFECT (0.10.1; 0.10.0's live test, finding 6: "Distracted shows as
 * six effect rows"): TRG Prime 3.685.1's bonus group — one row naming every
 * pool, one effect named "Distracted" carrying a −1 status change for each,
 * with the spell's duration and the cast's id, so it ends with the spell:
 *   attack       the attack pool (Strikes and spell attacks)
 *   allSkills    every skill the creature has
 *   fortitude, reflex, will   the three saves
 *   spellcraft   the casting check (Spellcraft is the casting check's pool)
 * `refresh`: a second Distracted FROM THE SAME SPELL replaces the first
 * (TRG Prime keys the refresh to the spell and caster); another spell's, or another caster's, stands beside it
 * as its own one effect, timed and ended with that spell. The penalty is −1,
 * never −2: same-type penalties do not stack, on every pool.
 * Pure data; no Foundry. Animate Moustache and Bubble Buffet use it.
 */

export const DISTRACTED_LABEL = "Distracted";
export const DISTRACTED_VALUE = -1;
export const DISTRACTED_TYPE = "status";
/** The pools Q157 names, as TRG Prime's bonus slots. */
export const DISTRACTED_SLOTS = Object.freeze(["attack", "allSkills", "fortitude", "reflex", "will", "spellcraft"]);

/**
 * The row, for a spell's effect list (an array of one, spread into it). `extra`
 * is laid over it (an `onSave` gate, a `duration`).
 * @param {object} [extra]
 * @returns {object[]}
 */
export function distractedRows(extra = {}) {
  return [{
    kind: "bonus", target: "targets", slots: [...DISTRACTED_SLOTS], bonusType: DISTRACTED_TYPE, value: DISTRACTED_VALUE,
    name: DISTRACTED_LABEL, refresh: true, ...extra
  }];
}

/** Is this row Distracted's? (The harness, and the cards.) */
export const isDistractedRow = (row) => row?.kind === "bonus" && row?.name === DISTRACTED_LABEL && row?.refresh === true
  && Array.isArray(row?.slots) && DISTRACTED_SLOTS.every((s) => row.slots.includes(s));
