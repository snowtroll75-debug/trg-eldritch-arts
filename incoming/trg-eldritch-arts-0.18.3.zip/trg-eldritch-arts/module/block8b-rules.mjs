/**
 * Eldritch Arts — Block 8b (0.12.0, on TRG Prime 3.687.0): the pure rules of
 * Chapter 8's ten rituals and its seven High Magic spells tied to Chapter 7.
 * No Foundry. The Foundry side is module/block8b-automations.mjs; the spells
 * are tools/content/block8b-spells.mjs.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2, §4.2 and §4.4, as Graham
 * answered it on 8 November 2026 (17:22, "As recommended"): Q170–Q182 as each
 * row recommends; H13–H16 (TRG Prime 3.687.0). Every number below is the
 * book's (v1.6, ea.md, the line given) or a ruling's (named).
 */
const freeze = Object.freeze;
const int = (v) => Math.trunc(Number(v) || 0);
const norm = (v) => String(v ?? "").trim().toLowerCase();

/* ================================================================== */
/* The keys                                                             */
/* ================================================================== */

export const RITUAL_KEYS = freeze(["armyOfTheGrave", "callOfTheAncestors", "concordOfStone", "elementalConvergence", "essenceReforging", "eternalInvocation", "riteOfBindingOath", "riteOfEchoedShadows", "sunsBenediction", "veilSevering"]);
export const HIGH_MAGIC_KEYS = freeze(["alterCorpse", "chaosShield", "leylineAnchor", "mimicSpell", "soulConfluence", "stormOfUnmaking", "veilfracture"]);
export const isRitual8b = (key) => RITUAL_KEYS.includes(String(key));
export const isHighMagic8b = (key) => HIGH_MAGIC_KEYS.includes(String(key));

/** The warp "unlocks" (a warp that is taken or not; core `unlocks`). */
export const UNLOCK = freeze({
  armyHalf: "ea8b:armyHalfLevels",
  armyPermanent: "ea8b:armyPermanent",
  concordDouble: "ea8b:concordDouble",
  concordPermanent: "ea8b:concordPermanent",
  convergenceMile: "ea8b:convergenceMile",
  sunInjured: "ea8b:sunInjured",
  sunTwenty: "ea8b:sunTwenty",
  sunLong: "ea8b:sunLong",
  echoInvisible: "ea8b:echoInvisible",
  veilLarger: "ea8b:veilLarger",
  veilLong: "ea8b:veilLong",
  mimicHold: "ea8b:mimicHold"
});
export const has = (unlocks, key) => Array.from(unlocks ?? []).map(String).includes(key);

/* ================================================================== */
/* Spans                                                                */
/* ================================================================== */

/** TRG Prime's own spans (module/afflictions.mjs UNIT_SECONDS: a month is 30 days, a year 365). */
export const SPAN = freeze({ round: 6, minute: 60, hour: 3600, day: 86400, week: 604800, month: 2592000, year: 31536000 });
/** "6 months" → seconds; "permanent" → Infinity; nothing readable → 0. */
export function spanSeconds(text) {
  const t = norm(text);
  if (/permanent/.test(t)) return Infinity;
  const m = /(\d+)\s*(round|minute|hour|day|week|month|year)s?/.exec(t);
  return m ? int(m[1]) * SPAN[m[2]] : 0;
}

/* ================================================================== */
/* Rituals (§4.2)                                                       */
/* ================================================================== */

const SIX = freeze(["critical", "success", "partial", "failure", "fumble", "blunder"]);

/**
 * Each ritual: the rungs it prints, whether its primary may perform it alone
 * (Q172, H14), its Cost (Q174), and the damage its failing rungs deal to the
 * casters (C3: at each caster's own level DC, no DC being printed).
 *   who  "casters" = the primary and every secondary (Q173); "primary"
 *        Concord of Stone's "primary casters" (M38: do not change it).
 */
export const RITUALS = freeze({
  armyOfTheGrave: freeze({ name: "Army of the Grave", line: 6290, printed: SIX, cost: freeze({ corpses: true }),
    hit: freeze({ who: "casters", save: "fortitude", type: "essence", failure: "2d10", fumble: "4d10", blunder: "8d10" }) }),
  callOfTheAncestors: freeze({ name: "Call of the Ancestors", line: 6416, printed: SIX, cost: freeze({ gp: 200 }),
    hit: freeze({ who: "casters", save: "fortitude", type: "mental", failure: "1d6", fumble: "2d6", blunder: "4d6" }) }),
  concordOfStone: freeze({ name: "Concord of Stone", line: 6486, printed: freeze(["critical", "partial", "failure", "blunder"]), cost: freeze({ gpPerPP: 100 }),
    hit: freeze({ who: "primary", save: "fortitude", type: "essence", failure: "2d6", blunder: "8d6" }) }),
  elementalConvergence: freeze({ name: "Elemental Convergence", line: 6720, printed: freeze(["critical", "failure", "fumble", "blunder"]), alone: true, cost: freeze({ note: "Offerings from each element (a flame, fresh water, rich soil, a breath of air) and an altar to elemental forces" }),
    hit: freeze({ who: "casters", save: "reflex", type: "chosen", failure: "2d6", fumble: "4d6", blunder: "8d6" }) }),
  essenceReforging: freeze({ name: "Essence Reforging", line: 6798, printed: freeze([]), noLadder: true, alone: true, cost: freeze({ gpPerTargetLevel: 200 }) }),
  eternalInvocation: freeze({ name: "Eternal Invocation", line: 6844, printed: freeze([]), noLadder: true, alone: true, cost: freeze({ gp: 10000 }) }),
  riteOfBindingOath: freeze({ name: "Rite of Binding Oath", line: 7544, printed: SIX, cost: freeze({ gp: 250 }),
    hit: freeze({ who: "casters", save: "fortitude", type: "essence", failure: "2d6", fumble: "4d6", blunder: "8d6" }) }),
  riteOfEchoedShadows: freeze({ name: "Rite of Echoed Shadows", line: 7578, printed: freeze(["critical", "partial", "failure", "blunder"]), cost: freeze({ gp: 50 }) }),
  sunsBenediction: freeze({ name: "Sun’s Benediction", line: 7703, printed: SIX, cost: freeze({ gp: 250 }),
    hit: freeze({ who: "casters", save: "fortitude", type: "essence", failure: "1d6", fumble: "2d6", blunder: "4d6" }) }),
  veilSevering: freeze({ name: "Veil Severing", line: 7937, printed: freeze(["heroic", ...SIX]), cost: freeze({ gp: 2000 }),
    hit: freeze({ who: "casters", save: "fortitude", type: "essence", failure: "4d6", fumble: "8d6", blunder: "12d6" }) })
});

/**
 * The rung a degree reads (m42's missing-results table): Heroic → Critical →
 * Success; Partial → Failure; Fumble → Failure; Blunder → Fumble → Failure. A
 * ritual that prints no Success line has the base effect there (M38). A ritual
 * with no ladder at all: "Success it works and failure it does not" (M45).
 */
export function ritualRung(spec, degree) {
  const d = norm(degree);
  if (spec?.noLadder) return ["heroic", "critical", "success"].includes(d) ? "works" : d === "partial" ? "fails" : ["fumble", "blunder"].includes(d) ? d : "fails";
  const p = new Set(spec?.printed ?? []);
  switch (d) {
    case "heroic": return p.has("heroic") ? "heroic" : p.has("critical") ? "critical" : "success";
    case "critical": return p.has("critical") ? "critical" : "success";
    case "success": return "success";
    case "partial": return p.has("partial") ? "partial" : "failure";
    case "fumble": return p.has("fumble") ? "fumble" : "failure";
    case "blunder": return p.has("blunder") ? "blunder" : p.has("fumble") ? "fumble" : "failure";
    default: return "failure";
  }
}
export const failingRung = (rung) => ["failure", "fumble", "blunder"].includes(String(rung));

/** The casters' damage on this rung, or null. */
export function casterHit(spec, rung) {
  const h = spec?.hit;
  if (!h || !failingRung(rung)) return null;
  const formula = h[rung] ?? h.failure;
  return formula ? { formula, save: h.save, type: h.type, who: h.who } : null;
}

/** "one intact corpse per 2 PP spent" (L6302), rounded down (m128). */
export const corpsesFor = (castPP) => Math.floor(Math.max(0, int(castPP)) / 2);

/**
 * A Cost's gold, as printed (Q174: on every attempt, when the ritual is
 * rolled; Concord's per PP as cast, warps included). Null: nothing in gold.
 */
export function ritualCostGP(spec, { castPP = 0, targetLevel = null } = {}) {
  const c = spec?.cost ?? {};
  if (c.gp) return int(c.gp);
  if (c.gpPerPP) return int(c.gpPerPP) * Math.max(0, int(castPP));
  if (c.gpPerTargetLevel) return targetLevel === null || targetLevel === undefined ? null : int(c.gpPerTargetLevel) * Math.max(0, int(targetLevel));
  return null;
}

/* ----------------------------- Army of the Grave ------------------ */

/**
 * Q175: one undead per corpse (so at most PP ÷ 2); their levels together no
 * more than the PP expended — each counted at half (rounded down) with the
 * +4 PP option (L6324); level 0 counts 0.
 * @returns {{ok: boolean, total: number, corpses: number, reason: string}}
 */
export function armyFits({ levels = [], castPP = 0, halfLevels = false } = {}) {
  const corpses = corpsesFor(castPP);
  const counted = levels.map((l) => (halfLevels ? Math.floor(Math.max(0, int(l)) / 2) : Math.max(0, int(l))));
  const total = counted.reduce((a, b) => a + b, 0);
  if (!levels.length) return { ok: false, total, corpses, reason: "no undead selected" };
  if (levels.length > corpses) return { ok: false, total, corpses, reason: `${levels.length} undead, but ${int(castPP)} PP raise at most ${corpses} (one intact corpse per 2 PP)` };
  if (total > int(castPP)) return { ok: false, total, corpses, reason: `their levels come to ${total}${halfLevels ? " (halved)" : ""}, more than the ${int(castPP)} PP expended` };
  return { ok: true, total, corpses, reason: "" };
}
/** How many rise under control: all, or half rounded down on a Partial (Q175, m128), or none. */
export const armyControlled = (count, rung) => (rung === "partial" ? Math.floor(int(count) / 2) : failingRung(rung) ? 0 : int(count));
export function armyDuration(rung, unlocks) {
  // A PARTIAL'S OWN SPAN WINS (the review): "Half rise under control for 1 day".
  if (has(unlocks, UNLOCK.armyPermanent) && !failingRung(rung) && rung !== "partial") return "permanent";
  return { critical: "1 month", success: "1 week", partial: "1 day" }[rung] ?? "";
}

/* ----------------------------- Call of the Ancestors --------------- */

/** "up to 3 questions"; "+2 PP: ask an additional question (max 10)". */
export const ancestorQuestions = (bought) => Math.min(10, 3 + Math.max(0, int(bought)));

/* ----------------------------- Concord of Stone ------------------- */

export function concordShape(rung, unlocks) {
  return {
    radius: 120 * (has(unlocks, UNLOCK.concordDouble) ? 2 : 1),
    dr: { critical: 10, success: 5, partial: 2 }[rung] ?? 0,
    // A Partial's own week wins over the permanent warp (the review), as for Echoed Shadows.
    duration: has(unlocks, UNLOCK.concordPermanent) && rung !== "partial" ? "permanent" : ({ critical: "6 months", success: "1 month", partial: "1 week" }[rung] ?? "")
  };
}
export const CONCORD_DB = 2;

/* ----------------------------- Elemental Convergence -------------- */

export const ELEMENTS = freeze(["fire", "cold", "electricity", "acid"]);
export const convergenceRadius = (unlocks) => (has(unlocks, UNLOCK.convergenceMile) ? 5280 : 500);
export const convergenceDice = (rung) => (rung === "critical" ? "2d6" : "1d6");

/* ----------------------------- Essence Reforging ------------------ */

export const REFORGING_USES = freeze([["remove", "Remove a permanent curse or transformation"], ["restore", "Restore life to a recently slain creature (as Resurrection)"], ["race", "Change a creature’s race"]]);
/** "you and the target take 1d8 force damage for each of their levels" (L6816). */
export const reforgingBacklash = (level) => `${Math.max(1, int(level))}d8`;
/** Q176: dead no longer than 7 days; 1 HP, 0 PP; injured 2 for a week; Death State −1. */
export const RESURRECTION = freeze({ maxDeadSeconds: 7 * SPAN.day, hp: 1, pp: 0, injured: 2, injuredSeconds: SPAN.week, deathStateStep: -1 });

/* ----------------------------- Eternal Invocation ---------------- */

/** TRG Prime's aligned traits and their opposites (module/aligned.mjs, creature-traits.mjs). */
export const ALIGNED = freeze(["balance", "chaos", "evil", "good", "order"]);
export const OPPOSITE = freeze({ good: "evil", evil: "good", chaos: "order", order: "chaos" });
export const alignedOf = (traits) => ALIGNED.filter((t) => Array.from(traits ?? []).map(norm).includes(t));
/** "share your aligned traits" → shared; "an opposed aligned trait" → opposed; else none (m107). */
export function alignedRelation(casterTraits, creatureTraits) {
  const mine = alignedOf(casterTraits);
  const theirs = alignedOf(creatureTraits);
  if (!mine.length || !theirs.length) return "none";
  if (theirs.some((t) => mine.map((m) => OPPOSITE[m]).includes(t))) return "opposed";
  if (theirs.some((t) => mine.includes(t))) return "shared";
  return "none";
}
export const ETERNAL_RADIUS_FEET = 5280;

/* ----------------------------- Rite of Binding Oath --------------- */

export function oathTerms(rung, damageDice = "") {
  const extra = String(damageDice ?? "").trim();
  return {
    duration: { critical: "1 year", success: "1 month", partial: "1 month" }[rung] ?? "",
    formula: extra ? `2d6 + ${extra}` : "2d6",
    double: rung === "critical",
    bound: rung === "partial" ? "half" : failingRung(rung) ? "none" : "all"
  };
}
export const OATH_DISADVANTAGE_SECONDS = SPAN.day;
/** Up to 10 willing creatures, +1 a warp. */
export const oathMax = (bought) => 10 + Math.max(0, int(bought));

/* ----------------------------- Rite of Echoed Shadows ------------- */

export function echoShape(rung, warpedDuration = "") {
  return {
    radius: { critical: 300, success: 60, partial: 30 }[rung] ?? 60,
    penalty: rung === "critical" ? -4 : -2,
    duration: rung === "partial" ? "1 hour" : (String(warpedDuration || "") || "1 day")
  };
}
export const ECHO_PENALTY_SECONDS = SPAN.minute;
export const ECHO_LEAVE_DAMAGE = "4d6";
/** "a powerful entity (PP cost of ritual +4 in level)" (L7600). */
export const echoEntityLevel = (castPP) => Math.max(0, int(castPP)) + 4;

/* ----------------------------- Sun’s Benediction ------------------ */

export const SUN_CONDITIONS = freeze(["dazed", "fatigued", "sickened", "weakened"]);
export function sunTerms(rung, { bought = 0, unlocks = [] } = {}) {
  const n = Math.max(0, int(bought));
  const base = rung === "critical" ? { dice: 4, bonus: 6 } : { dice: 2, bonus: 3 };
  const formula = `${base.dice + n}d8 + ${base.bonus + n}`;
  const long = has(unlocks, UNLOCK.sunLong);
  return {
    formula,
    half: rung === "partial",
    reduce: rung === "partial" || failingRung(rung) ? 0 : 1 + n,
    conditions: has(unlocks, UNLOCK.sunInjured) ? [...SUN_CONDITIONS, "injured"] : [...SUN_CONDITIONS],
    max: has(unlocks, UNLOCK.sunTwenty) ? 20 : 6,
    blessing: rung === "partial" || failingRung(rung) ? "" : rung === "critical" ? (long ? "1 month" : "24 hours") : (long ? "1 week" : "1 hour"),
    heals: !failingRung(rung)
  };
}
export const SUN_RADIUS_FEET = 30;
export const SUN_FEAR_BONUS = 2;

/* ----------------------------- Veil Severing ---------------------- */

export function veilDuration(rung, unlocks) {
  const long = has(unlocks, UNLOCK.veilLong);
  const table = long
    ? { heroic: "permanent", critical: "1 year", success: "1 month", partial: "1 week" }
    : { heroic: "1 year", critical: "1 month", success: "1 week", partial: "1 day" };
  return table[rung] ?? "";
}
export const VEIL_RADIUS_FEET = 30;

/* ================================================================== */
/* High Magic (§4.4)                                                    */
/* ================================================================== */

/* ----------------------------- Chaos Shield ---------------------- */

export const CHAOS_SHIELD_FLAG = "chaosShield8b";
export const CHAOS_NULLIFY_PP = 2;
export const CHAOS_DC_STEP = -2;
/** "30-foot emanation"; "+2 PP: aura increases to 60-ft" (core `areaOverride`). */
export const chaosRadius = (areaOverride) => (/60/.test(String(areaOverride ?? "")) ? 60 : 30);
/**
 * Two d100s, "taking the preferred result" (Q178: the surging creature picks)
 * — unless the roll is also at disadvantage (Wild Power in a Wild Magic area):
 * "if an action gains both advantage and disadvantage, they simply cancel each
 * other out" (core, the trait's rule) — one roll, as with neither.
 */
export const chaosRolls = ({ shielded, disadvantage }) => (shielded && !disadvantage ? 2 : disadvantage && !shielded ? 2 : 1);
/** Q178's reading of "resistance to wild surge backlash": a row's damage to a creature in the aura, halved (rounded down). */
export const shieldedDamage = (amount) => Math.floor(Math.max(0, int(amount)) / 2);

/* ----------------------------- Leyline Anchor -------------------- */

export const ANCHOR_FLAG = "leylineAnchor8b";
export const ANCHOR_RADIUS_FEET = 300;
export const ANCHOR_BONUS = 1;
export const ANCHOR_TAP_STEP = 5;
export const ANCHOR_RANGE_FEET = 5280;
/** Q179: payment only, 1 PP less, never below 1, a Highmagic spell cast within the radius. */
export const anchorDiscount = ({ highMagic, inside, totalPP }) => (highMagic && inside && int(totalPP) > 1 ? -1 : 0);

/* ----------------------------- Mimic Spell ----------------------- */

export const MIMIC_FLAG = "mimicImprint8b";
export const MIMIC_PP = 8;
export const MIMIC_HOLD_PP = 2;
export const MIMIC_RANGE_FEET = 60;
/** "the Spells Casting DC" (M48): the core's casting DC for the PP as cast, 10 + ⌊1.5 × PP⌋. */
export const mimicDC = (castPP) => 10 + Math.floor(Math.max(0, int(castPP)) * 1.5);
/** The imprint's hold: Critical 1 minute (10 with the warp); Success your next turn (1 minute with it). */
export function mimicHold(degree, unlocks) {
  const held = has(unlocks, UNLOCK.mimicHold);
  if (["heroic", "critical"].includes(norm(degree))) return { kind: "time", seconds: held ? 10 * SPAN.minute : SPAN.minute, freeChoice: true };
  if (norm(degree) === "success") return held ? { kind: "time", seconds: SPAN.minute, freeChoice: false } : { kind: "nextTurn", seconds: 2 * SPAN.round, freeChoice: false };
  return null;
}
/** M48: "You cannot mimic a spell whose PP exceeds your maximum PP per cast" (caster level + 1). */
export const mimicAllowed = (castPP, casterLevel) => int(castPP) <= Math.max(0, int(casterLevel)) + 1;
/** "1d6 essence damage (basic Will) per PP of the spell you tried to mimic". */
export const mimicBacklash = (castPP) => `${Math.max(1, int(castPP))}d6`;
/** Negative PP (core): "you instead take 5 Soul Drain for every PP that you would fall below 0". */
export const SOUL_DRAIN_PER_PP = 5;
export const mimicShortfall = (ppPool, cost) => Math.max(0, int(cost) - Math.max(0, int(ppPool)));

/* ----------------------------- Soul Confluence ------------------- */

export const CONFLUENCE_FLAG = "soulConfluence8b";
export const CONFLUENCE_RADIUS_FEET = 30;
export const CONFLUENCE_WILL_BONUS = 2;
/** Q181: the sum of the Constitution modifiers × 5, made once, minimum 0. */
export const confluencePool = (conMods = []) => Math.max(0, conMods.reduce((a, b) => a + int(b), 0) * 5);
/** What the pool takes of a blow, and what is left of each. */
export function confluenceTake(pool, amount) {
  const p = Math.max(0, int(pool));
  const a = Math.max(0, int(amount));
  const taken = Math.min(p, a);
  return { taken, pool: p - taken, rest: a - taken };
}
/** "1d6 Soul Drain per 2 rounds the spell lasted" (rounded down, m128). */
export const confluenceBacklash = (seconds) => Math.floor(Math.floor(Math.max(0, Number(seconds) || 0) / SPAN.round) / 2);

/* ----------------------------- Storm of Unmaking ----------------- */

/** The table (L7690–7699), in order: the storm's 1d6 is its face. Basic saves at the Save DC. */
export const UNMAKING_STORM = freeze({
  kind: "storm", label: "Storm of Unmaking", pick: "roll", strikes: "turnStart",
  modes: freeze([
    freeze({ key: "fire", label: "Fire", formula: "20d6", type: "fire", save: "reflex", basic: true }),
    freeze({ key: "electricity", label: "Electricity", formula: "10d12", type: "electricity", save: "reflex", basic: true }),
    freeze({ key: "cold", label: "Cold", formula: "30d4", type: "cold", save: "reflex", basic: true }),
    freeze({ key: "acid", label: "Acid", formula: "15d8", type: "acid", save: "reflex", basic: true }),
    freeze({ key: "bludgeoning", label: "Bludgeoning", formula: "20d8", type: "bludgeoning", save: "fortitude", basic: true }),
    freeze({ key: "force", label: "Force", formula: "12d10", type: "force", save: "fortitude", basic: true })
  ])
});
export const UNMAKING_RADIUS_FEET = 60;
export const UNMAKING_SECONDS = SPAN.minute;

/* ----------------------------- Veilfracture ---------------------- */

export const VEILFRACTURE_PULL = "1d4";
/** "portal 10 ft wide per 2 CL" (rounded down, m128; at least 10 ft). */
export const portalWidth = (casterLevel) => Math.max(1, Math.floor(Math.max(0, int(casterLevel)) / 2)) * 10;

/* ----------------------------- Alter Corpse ---------------------- */

export const CORPSE_USES = freeze([["decompose", "Decompose (a corpse of size Huge or smaller, to a cleaned skeleton)"], ["restore", "Restore (grow flesh on a Medium or smaller decomposed or skeletonized corpse)"]]);

/* ================================================================== */
/* Areas                                                                */
/* ================================================================== */

export const AREA8B_FLAG = "grimoireArea8b";
export const AURA8B_FLAG = "aura8b";
export const RITUAL_PLAN_FLAG = "ritualPlan8b";
