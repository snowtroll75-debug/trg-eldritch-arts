/**
 * Eldritch Arts — Block 7 (0.10.0): the pure rules and constants of the first
 * half of Chapter 8's Grimoire. No Foundry. The content build
 * (tools/content/block7-spells.mjs) and the automations
 * (module/block7-automations.mjs) both read them, so a number lives once.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK7_AUDIT.md §5.2 as Graham answered it on
 * 7 November 2026 (Q150 changed: recurring damage stacks by type, a core rule
 * in TRG Prime 3.685.0; Q151–Q166 as proposed; H1–H11 approved).
 *
 * GRAHAM'S TWO RULINGS OF 7 NOVEMBER 2026 (07:53), each one constant here:
 *   DRAGON_WINGS_FLY_CAP   "Max +50, four warps"
 *   SPIRIT_ARROW_FLAT      "Flat 6d6"
 */

export const MODULE_ID = "trg-eldritch-arts";
export const SYSTEM_ID = "trg-prime";

const int = (v) => Math.trunc(Number(v) || 0);
const norm = (v) => String(v ?? "").trim().toLowerCase();

/* ------------------------------------------------------------------ */
/* Graham's two rulings (7 November 2026, 07:53)                         */
/* ------------------------------------------------------------------ */

/**
 * DRAGON WINGS (L6554): "You gain a fly Speed equal to your land Speed +10
 * feet." "+2 PP: increase your fly Speed by an additional 10 feet (max +50
 * feet)." RULED: "Max +50, four warps" — the fly Speed is at most land Speed
 * + 50 in all: the base +10 and four warps. The core caps the whole `landPlus`
 * at the warp's `bonusMax` (`warpedBonusValue`), so a fifth warp adds nothing.
 */
export const DRAGON_WINGS_BASE_FEET = 10;
export const DRAGON_WINGS_STEP_FEET = 10;
export const DRAGON_WINGS_FLY_CAP = 50;
export const DRAGON_WINGS_MAX_WARPS = (DRAGON_WINGS_FLY_CAP - DRAGON_WINGS_BASE_FEET) / DRAGON_WINGS_STEP_FEET;

/**
 * SPIRIT ARROW (L7634): "The arrow deals 6d6 piercing damage (in place of the
 * arrows normal damage)". RULED: "Flat 6d6" — the arrow's damage is exactly
 * 6d6 piercing; nothing else adds (no BAB, attribute, feats or other
 * additions); a critical still doubles it as weapon damage. The rider says
 * `replacesDamage: true` (H10) and `flat: true` (H10's addition in the core).
 */
export const SPIRIT_ARROW_REPLACES = true;
export const SPIRIT_ARROW_FLAT = true;
export const SPIRIT_ARROW_DICE = "6d6";
export const SPIRIT_ARROW_MAX_ARROWS = 5;
/** Q161: frightened is half the margin, rounded down (m128), minimum 1 on any failed save. */
export function spiritArrowFrightened(margin) {
  if (margin === null || margin === undefined || !Number.isFinite(Number(margin))) return 0;
  const failedBy = Math.max(0, -Math.round(Number(margin)));
  if (failedBy <= 0) return 0;
  return Math.max(1, Math.floor(failedBy / 2));
}
/** "Feint, Grapple (1 round), Shove or Trip action" — the attacker's choice (Q161). */
export const SPIRIT_ARROW_MANOEUVRES = Object.freeze(["Feint", "Grapple (1 round)", "Shove", "Trip"]);
/**
 * Each manoeuvre as the core action it is treated as (L7634), resolved at the
 * attack total by TRG Prime 3.692.0's `resolveBasicActionAtTotal`. The
 * Grapple's "(1 round)" is its clock; the others keep their action's own.
 */
export const SPIRIT_ARROW_ACTIONS = Object.freeze({
  "Feint": Object.freeze({ key: "feint", rounds: null }),
  "Grapple (1 round)": Object.freeze({ key: "grappleAttack", rounds: 1 }),
  "Shove": Object.freeze({ key: "shoveAttack", rounds: null }),
  "Trip": Object.freeze({ key: "tripAttack", rounds: null })
});
export function spiritArrowAction(pick) {
  return SPIRIT_ARROW_ACTIONS[String(pick ?? "")] ?? null;
}

/* ------------------------------------------------------------------ */
/* Shared                                                               */
/* ------------------------------------------------------------------ */

/**
 * "ANY CREATURE THAT HITS YOU WITH A MELEE STRIKE" prints no contact distance;
 * the core's thorns default to adjacency (5 ft). A reach that every melee blow
 * is within, so a reach weapon's hit counts as the page says.
 */
export const ANY_MELEE_FEET = 100;

/** Tradition "all" (audit §6): the four traditions; the card keeps "all". */
export const ALL_TRADITIONS = "arcane, divinity, ethereal, verdant";

/** Every Chapter 8 spell is uncommon (m84 as proposed; Q166). */
export const GRIMOIRE_AVAILABILITY = "uncommon";

/** The core's maximum PP per cast (magic/casting.mjs `maxPPPerCast`): caster level + 1. */
export const maxPPPerCast = (casterLevel) => Math.max(0, int(casterLevel)) + 1;

const UP = ["heroic", "critical", "success"];
export const succeeded = (degree) => UP.includes(norm(degree));
/** m42: a Partial reads as a Failure where no Partial is printed. */
export const failedOrWorse = (degree) => ["partial", "failure", "fumble", "blunder"].includes(norm(degree));
/** On a BASIC save a Partial is its own result (half damage): "failed" is Failure, Fumble or Blunder (as Leyline Burst's push). */
export const basicSaveFailed = (degree) => ["failure", "fumble", "blunder"].includes(norm(degree));

/** Q28's sides, as Block 3b reads token disposition. */
export function enemiesBySide(a, b) {
  const x = int(a), y = int(b);
  return (x === 1 && y === -1) || (x === -1 && y === 1);
}

/* ------------------------------------------------------------------ */
/* Dragon's Breath and Elemental Strike: the type chosen when learned   */
/* ------------------------------------------------------------------ */

/** L6580: "acid, cold, electricity, fire or poison"; acid/electricity a 30-ft line, the rest a 15-ft cone. */
export const BREATH_TYPES = Object.freeze(["acid", "cold", "electricity", "fire", "poison"]);
export const BREATH_SHAPE = Object.freeze({
  line: Object.freeze({ area: "30-foot line", step: 10, max: 120 }),
  cone: Object.freeze({ area: "15-foot cone", step: 5, max: 60 })
});
export const breathShapeOf = (type) => (["acid", "electricity"].includes(norm(type)) ? "line" : "cone");
/** The type's trait (m104: the chosen type is the spell's elemental trait). */
export const typeTrait = (type) => (norm(type) ? norm(type)[0].toUpperCase() + norm(type).slice(1) : "");

/**
 * What the item becomes once its type is chosen: its damage type, its area,
 * its trait, and its range warp's step and maximum ("+1 PP: increase line
 * range by 10-ft (max 120) or cone range by 5-ft (max 60)").
 */
export function breathItemUpdate(system, type) {
  const t = norm(type);
  if (!BREATH_TYPES.includes(t)) return null;
  const shape = BREATH_SHAPE[breathShapeOf(t)];
  const traits = withTrait(system?.traits, typeTrait(t), BREATH_TYPES.map(typeTrait));
  const warps = (Array.isArray(system?.warps) ? system.warps : []).map((w, i) => (i === 1
    ? { ...w, mods: { areaGrowth: shape.step, areaMax: shape.max } }
    : w));
  return { "system.damage.type": t, "system.area": shape.area, "system.traits": traits, "system.warps": warps };
}

/** L6750: "acid, cold, electricity or fire". An Elemental Pact's element maps to it (Block 6). */
export const STRIKE_TYPES = Object.freeze(["acid", "cold", "electricity", "fire"]);
export const ELEMENT_TO_STRIKE = Object.freeze({ air: "electricity", earth: "acid", fire: "fire", water: "cold" });
export function strikeItemUpdate(system, type) {
  const t = norm(type);
  if (!STRIKE_TYPES.includes(t)) return null;
  return { "system.damage.type": t, "system.traits": withTrait(system?.traits, typeTrait(t), STRIKE_TYPES.map(typeTrait)) };
}

/** A trait list with one of `family` set to `trait` (any other of the family removed). */
export function withTrait(traits, trait, family = []) {
  const drop = new Set(family.map(norm));
  const list = String(traits ?? "").split(/[,;]/).map((t) => t.trim()).filter(Boolean).filter((t) => !drop.has(norm(t)));
  if (trait) list.push(trait);
  return [...new Set(list)].sort((a, b) => a.localeCompare(b)).join(", ");
}

/** The type flag the item keeps once chosen. */
export const CHOSEN_TYPE_FLAG = "eaChosenType";

/**
 * ELEMENTAL STRIKE'S STRIKE (Q155): "Any number, 1 AP each, for the minute.
 * Each is a Strike for rules that count Strikes, but takes and adds no
 * multiple attack penalty. The Save DC is fixed at the cast (warps included).
 * Base Damage 1d6 adds to the critical. A melee weapon must be wielded."
 */
export const ELEMENTAL_STRIKE_ABILITY = "Elemental Strike (Strike)";
export const ELEMENTAL_STRIKE_AP = 1;
export const ELEMENTAL_STRIKE_BASE = "1d6";
export function elementalStrikeDice(warpDice = "") {
  const extra = /^(\d+)d6$/i.exec(String(warpDice ?? "").trim());
  return `${1 + (extra ? int(extra[1]) : 0)}d6`;
}
export const elementalStrikeFormula = (dice, ability) => `${dice}${int(ability) ? ` + ${int(ability)}` : ""}`;

/* ------------------------------------------------------------------ */
/* Invoke True Name                                                     */
/* ------------------------------------------------------------------ */

export const TRUE_NAME_MARK = "invokeTrueName";
/** Q164: "Once, at CL 8: −4." −2 below. */
export const trueNamePenalty = (casterLevel) => (int(casterLevel) >= 8 ? -4 : -2);
/** Flat-footed loses the defender's Dexterity and dodge in DB (the core's `flatFootedLoss`). */
export function flatFootedLossOf(defence = {}) {
  return Math.max(0, Number(defence?.ability) || 0) + Math.max(0, Number(defence?.breakdown?.byType?.dodge) || 0);
}

/* ------------------------------------------------------------------ */
/* Planar Anchor                                                        */
/* ------------------------------------------------------------------ */

export const ANCHOR_MARK = "planarAnchor";
export const ANCHOR_VEIL_UNLOCK = "eaAnchorVeil";
/**
 * m121 as proposed: "any attempt to teleport the target or transport [it] [is]
 * counteracted by the spell" — a spell with the Teleportation trait, cast by
 * or on the anchored creature; with the +4 PP option, one that would make it
 * invisible or incorporeal (by its name or trait).
 */
export function anchorRefuses({ traits = "", name = "", veil = false } = {}) {
  const list = String(traits ?? "").toLowerCase().split(/[,;]/).map((t) => t.trim());
  if (list.includes("teleportation")) return "teleportation";
  if (veil && (list.includes("invisibility") || list.includes("incorporeal") || /invisib|incorporeal|ethereal ?form|gaseous/i.test(String(name ?? "")))) return "veil";
  return "";
}

/* ------------------------------------------------------------------ */
/* Zone Disruption                                                      */
/* ------------------------------------------------------------------ */

export const ZONE_EXEMPT_MARK = "zoneDisruptionExempt";
export const ZONE_AFFECTED_MARK = "zoneDisruption";
export const ZONE_FUMBLE_UNLOCK = "eaZoneFumble";
/** "Any Spell Concentration checks or sustain actions automatically increase their DC by +2." */
export const ZONE_CONCENTRATION_RISE = 2;

/* ------------------------------------------------------------------ */
/* Arcane Feedback, Arcane Bastion, Argent Reversal, Spectral Aegis      */
/* ------------------------------------------------------------------ */

export const FEEDBACK_FEET = 30;
/** The rung's critical before the warp, and each warp's step (max deadly). */
export const FEEDBACK_CRITICAL = Object.freeze({ failure: "minor", fumble: "serious", blunder: "serious" });
const SEVERITIES = ["minor", "serious", "deadly"];
export function feedbackSeverity(degree, steps = 0) {
  const base = FEEDBACK_CRITICAL[norm(degree)];
  if (!base) return null;
  return SEVERITIES[Math.min(SEVERITIES.length - 1, SEVERITIES.indexOf(base) + Math.max(0, int(steps)))];
}
/** Q158: every damaging rung is a penalty of its damage; no check (an innate cast) no penalty. */
export const feedbackPenalty = (taken, rollsCheck = true) => (rollsCheck && int(taken) > 0 ? -int(taken) : 0);

/**
 * ARCANE BASTION (Q151): if the injury would leave you dying or incapacitated,
 * the same d100 is read one severity lower, a further step per +2 PP (max 3 in
 * all), and the spell ends. INCAPACITATED read literally: unconscious,
 * paralysed, petrified, helpless, dying, or a death row. (Stunned is not read
 * as incapacitated: see For Graham.)
 */
export const BASTION_MAX_STEPS = 3;
export const bastionSteps = (warpBought = 0) => Math.min(BASTION_MAX_STEPS, 1 + Math.max(0, int(warpBought)));
const INCAPACITATING = /\b(dying|dies|die|death|dead|killed|slain|unconscious|paraly[sz]ed|petrified|helpless|incapacitat\w*)\b/i;
export function injuryIncapacitates(row = {}) {
  if (/^(death|fatal)$/i.test(String(row?.persistence ?? "").trim())) return true;
  return INCAPACITATING.test(String(row?.effect ?? ""));
}

/** Argent Reversal: one attempt, one more per +2 PP (max 5); Fumble 4d10, Blunder 8d10 essence (basic Fort). */
export const ARGENT_MAX_ATTEMPTS = 5;
export const argentAttempts = (bought = 0) => Math.min(ARGENT_MAX_ATTEMPTS, 1 + Math.max(0, int(bought)));
export const ARGENT_ABSORB_UNLOCK = "eaArgentAbsorb";
export function argentOutcome(degree) {
  const d = norm(degree);
  if (d === "heroic" || d === "critical") return { turn: true, choose: true, backlash: "" };
  if (d === "success") return { turn: true, choose: false, backlash: "" };
  if (d === "fumble") return { turn: false, choose: false, backlash: "4d10" };
  if (d === "blunder") return { turn: false, choose: false, backlash: "8d10" };
  return { turn: false, choose: false, backlash: "" };
}
/** "restoring PP equal to half the original cost of the incoming effect" (m128: rounded down). */
export const argentAbsorbPP = (pp) => Math.floor(Math.max(0, int(pp)) / 2);
/** Q153: "highest-level spell you can cast" = your maximum PP per cast. */
export const argentReaches = (incomingPP, casterLevel) => int(incomingPP) <= maxPPPerCast(casterLevel);

/** Spectral Aegis (Q152): one absorb, +1 per warp; PP 10 or lower, +1 per warp. */
export const AEGIS_PP_LIMIT = 10;
export const aegisState = (warpMods = {}) => ({ absorbs: 1 + Math.max(0, int(warpMods?.declareUses)), ppLimit: AEGIS_PP_LIMIT + Math.max(0, int(warpMods?.heldUses)) });
export const aegisAbsorbs = (incomingPP, state) => int(incomingPP) <= int(state?.ppLimit) && int(state?.absorbs) > 0;

/* ------------------------------------------------------------------ */
/* Mirror Reprise                                                        */
/* ------------------------------------------------------------------ */

export const MIRROR_IMAGES = 3;
/** "With three duplicates, roll 26 or higher. With two duplicates, roll 34 or higher. With one duplicate, roll 51 or higher." */
export const MIRROR_THRESHOLD = Object.freeze({ 3: 26, 2: 34, 1: 51 });
export const mirrorDiverts = (images, d100) => int(images) > 0 && int(d100) >= MIRROR_THRESHOLD[Math.min(3, int(images))];
export const MIRROR_SPELL_UNLOCK = "eaMirrorSpell";
export const MIRROR_TELEPORT_UNLOCK = "eaMirrorStep";
export const MIRROR_TELEPORT_FEET = 10;

/* ------------------------------------------------------------------ */
/* Panic Transposition                                                   */
/* ------------------------------------------------------------------ */

export const PANIC_FEET = 30;
export const PANIC_FAR_FEET = 60;
export const PANIC_UNSEEN_UNLOCK = "eaPanicUnseen";
export const PANIC_RESIST_UNLOCK = "eaPanicResist";
export const PANIC_FAR_UNLOCK = "eaPanicFar";
export const panicFeet = (unlocks = []) => (Array.from(unlocks ?? []).includes(PANIC_FAR_UNLOCK) ? PANIC_FAR_FEET : PANIC_FEET);

/* ------------------------------------------------------------------ */
/* Metamagic Resonance                                                   */
/* ------------------------------------------------------------------ */

export const RESONANCE_FEET = 30;
export const RESONANCE_FAR_FEET = 60;
export const RESONANCE_HALF_UNLOCK = "eaResonanceHalf";
export const RESONANCE_FREE_UNLOCK = "eaResonanceFree";
export const RESONANCE_SWAP_UNLOCK = "eaResonanceSwap";
/** Does this Sustain offer Metamagic Resonance's change of feat? Its own cast, with the option bought. */
export function resonanceSwapOnSustain(rec, castId) {
  return Boolean(rec && rec.swap === true && String(rec.castId ?? "") && String(rec.castId) === String(castId ?? ""));
}
/** m114: the +6 PP option replaces the +3 PP one; Q163: half rounds down (the core's H9 does it). */
export function resonanceCostFactor(unlocks = []) {
  const u = Array.from(unlocks ?? []);
  if (u.includes(RESONANCE_FREE_UNLOCK)) return 0;
  if (u.includes(RESONANCE_HALF_UNLOCK)) return 0.5;
  return 1;
}
export const resonanceFeet = (areaOverride = "") => (/60/.test(String(areaOverride ?? "")) ? RESONANCE_FAR_FEET : RESONANCE_FEET);

/* ------------------------------------------------------------------ */
/* Primal Snap, Arcane Mycelium, Chronoweave                             */
/* ------------------------------------------------------------------ */

export const SNAP_DICE = "6d8";
export const SNAP_SPEED_PENALTY = -10;
export function snapDice(warpDice = "") {
  const extra = /^(\d+)d8$/i.exec(String(warpDice ?? "").trim());
  return `${6 + (extra ? int(extra[1]) : 0)}d8`;
}
export const MYCELIUM_REACTIVE_UNLOCK = "eaMyceliumReactive";
export const MYCELIUM_DICE = "2d6";
/**
 * "emits dim light in a colour matching your magical tradition" (L6166). The
 * core's Dim Light is level 5 (TRG Prime 3.692.0's Region `emitsLight`: at
 * least that level inside, as a light source). The colour is cosmetic.
 */
export const MYCELIUM_LIGHT_LEVEL = 5;
export function myceliumLight(spellName = "Arcane Mycelium") {
  return { level: MYCELIUM_LIGHT_LEVEL, label: `${String(spellName || "Arcane Mycelium")} (dim light)` };
}
export const CHRONO_SLOW_UNLOCK = "eaChronoSlow";
export const CHRONO_FEET = 20;
/** The warp's Fortitude: Failure slowed 1, Fumble slowed 2 (m42: Partial reads Failure; Blunder Fumble). */
export function chronoSlowed(degree) {
  const d = norm(degree);
  if (d === "fumble" || d === "blunder") return 2;
  if (d === "failure" || d === "partial") return 1;
  return 0;
}

/* ------------------------------------------------------------------ */
/* Eaog Balls, Glyph of Retribution, Bouncy Body                         */
/* ------------------------------------------------------------------ */

export const EAOG_COLDFIRE_UNLOCK = "eaEaogColdfire";
export const GLYPH_TYPE_UNLOCK = "eaGlyphType";
/** "+4 PP: change the damage type to either acid, cold, electricity or fire each time you are struck" (L6990). */
export const GLYPH_TYPES = Object.freeze(["acid", "cold", "electricity", "fire"]);
export const BOUNCY_FALL_FEET = 20;

/** The spell's key on its item (`flags.trg-prime.eaGrimoire`), by name. */
export const keyOf = (spell) => String(spell?.flags?.[SYSTEM_ID]?.eaGrimoire ?? "");
