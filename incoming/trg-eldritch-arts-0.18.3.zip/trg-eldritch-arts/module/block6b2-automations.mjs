/**
 * Eldritch Arts — Block 6 (0.9.0), group B2: what the Runebreaker, Shade
 * Master, Spellwarden, Spell Duellist, Spell Weaver and Stormcaller
 * archetypes and their class feats do that is not data. On TRG Prime
 * 3.684.0 (seams G1, G4, G8, G9, G16, G17, G20, G21).
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md, Appendix B, as Graham
 * answered it on 4 November 2026 (Q90–Q149 as proposed). The pure rules come
 * first so the harness can run them; the Foundry side follows.
 *
 *   Uses        Fade Step (Eclipse Step, Shadowmantle, Grasping Shadows ride
 *               on it), Counter Channel (allies on/off), Absolute Denial
 *               (suppress/resume), Eye of the Storm, Gale Step (Stormcaller's
 *               0 AP — REPLACES Block 3's entry: register after Block 3)
 *   Reactions   Runebreaker's absorb (+ Rune Rend), Absolute Denial, Counter
 *               Channel (+ Reflective Warding) — cast reactions; Spellwarden
 *               and Shadowmantle (save bonuses), Deep Weave (a save's
 *               critical), Spellstrike Riposte against a spell attack —
 *               check reactions; Spellstrike Riposte against a Strike (hook)
 *   Seams       Runebreaker's and Glyph Shatter's Dispel modifiers; Spell
 *               Weaver's three metamagic options and Wellspring Conduit (G1);
 *               Stormcaller's Storm Bolt discount (G4); Shade Master's warp
 *               and Dark Whispers refusal; the three birthright gates (G9);
 *               Deep Weave's and Extra Reservoir's uses (G21); Runic
 *               Overload's cast option (G16)
 *   Hooks       see each `on…B6B2` handler: the event it expects is in its
 *               comment.
 */
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, tokenOf, tokenCentre, inCombat, spendAP, feetBetween } from "./block1-automations.mjs";
import { pickPoint, actsFor, birthrightOf } from "./block3-automations.mjs";
import { allies, enemies } from "./block3b-automations.mjs";

/* ------------------------------------------------------------------ */
/* Data shared with the content                                         */
/* ------------------------------------------------------------------ */

export const FADE_FEET = 30;
export const ECLIPSE_FEET = 120;
/** "Dim light or darkness", "shadow": Q61's ambient light, 5 or less. */
export const SHADOW_LIGHT_MAX = 5;
export const CC_FEET = 30;
export const CC_IMPROVED_FEET = 60;
export const CC_PP = 1;
export const RIPOSTE_PP = 1;
export const DENIAL_FEET = 20;
/** Q119: the PP as cast, warps included. */
export const DENIAL_MAX_PP = 8;
export const GRASP_FEET = 10;
export const GRASP_PP = 1;
export const GLYPH_FEET = 10;
export const GLYPH_BONUS = 1;
export const GLYPH_SECONDS = 60;
export const REND_PP = 1;
/** Runebreaker: "it costs you 2 PP less (min 1)" — the core's ppReduction floors at 1. */
export const DISPEL_REDUCTION = 2;
/** Q116: "effective PP +2". */
export const OVERLOAD_PP = 2;
export const EYE_FEET = 30;
export const EYE_PULSES = 3;
export const RESERVOIR_DISCOUNT = 2;
export const RESERVOIR_FACTOR = 1.5;
export const OVERFLOW_DIE = 6;
export const OVERFLOW_DICE_PER_CHARGE = 2;
export const OVERFLOW_SOUL_DRAIN = 5;
/** Shade Master: the +5 PP hidden option "costs your 2 PP less". */
export const SHADE_HIDDEN_PP = 3;
export const SHADE_UNLOCK = "eaShadeHidden";
export const STORM_DISCOUNT = 1;
export const SPELLWARDEN_BONUS = 2;
export const SHADOWMANTLE_BONUS = 1;
export const DUELLIST_FOCUS = Object.freeze({ strike: 1, spell: 2 });

export const NAMES = Object.freeze({
  fadeStep: "Fade Step", counterChannel: "Counter Channel", riposte: "Spellstrike Riposte", reservoir: "Magical Reservoir",
  storingRune: "Storing Rune", darkWhispers: "Dark Whispers", shadowShift: "Shadow Shift", stormBolt: "Storm Bolt", stormBurst: "Storm Bolt (Burst)"
});

/** The metamagic keys (G1; lower case, as the registry stores them). */
export const MM = Object.freeze({ discount: "easpellweaverdiscount", dieStep: "easpellweaverdiestep", extend: "easpellweaverextend", wellspring: "eawellspringconduit" });
export const WEAVER_GROUP = "easpellweaver";
export const OVERLOAD_KEY = "eaRunicOverload";

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const DEGREES_UP = ["heroic", "critical", "success"];
const CRITICAL_UP = ["heroic", "critical"];
const FUMBLE_DOWN = ["fumble", "blunder"];
export const succeeded = (degree) => DEGREES_UP.includes(String(degree ?? ""));

/** In shadow: a measured light of 5 or less. Null (no light read) is not shadow. */
export const inShadow = (level) => level !== null && level !== undefined && Number.isFinite(Number(level)) && Number(level) <= SHADOW_LIGHT_MAX;

/** "1d6 per 2 PP": the dice, or "" when the PP buy none. */
export function perTwoPP(pp, die = 6) {
  const n = Math.floor(Math.max(0, int(pp)) / 2);
  return n > 0 ? `${n}d${die}` : "";
}

/** G9: the archetype's birthright, by the Block 3 birthright ability on the sheet. */
export function birthrightGate(name) {
  return (actor) => (norm(birthrightOf(actor)?.name) === norm(name) ? null : `this archetype needs the ${name} birthright (a Sorcerer's).`);
}

/** Q115: Runebreaker absorbs a spell whose SOLE target is you; never an area spell. */
export function absorbable({ targets = [], reactor = null, caster = null, spellData = {} } = {}) {
  if (!reactor || !caster || reactor === caster) return false;
  if (String(spellData?.area ?? "").trim()) return false;
  const list = Array.from(targets ?? []);
  return list.length === 1 && list[0] === reactor;
}

/** Counter Channel's reach: 30 ft, 60 with Improved Counter Channel. */
export const counterChannelFeet = (hasImproved) => (hasImproved ? CC_IMPROVED_FEET : CC_FEET);

/**
 * "Power Manipulation check against the spells Save DC": 10 + the PP as cast
 * + the caster's casting ability (magic/casting.mjs `spellSaveDC`); a spell
 * with no save, its caster's Spell DC (m79).
 */
export function counterChannelDC({ hasSave = false, pp = 0, castingAbility = 0, spellDC = 0 } = {}) {
  return hasSave ? 10 + Math.max(0, int(pp)) + int(castingAbility) : int(spellDC);
}

/** Counter Channel's answer by degree (sidebar 13, Q118); Reflective Warding on a Critical. */
export function counterChannelAnswer(degree, { reflect = false } = {}) {
  const d = String(degree ?? "");
  if (CRITICAL_UP.includes(d)) return reflect ? { retargetCaster: true } : { stop: true };
  if (d === "success") return { scale: 0.5, saveBias: "advantage" };
  if (FUMBLE_DOWN.includes(d)) return { scale: 2, saveBias: "disadvantage" };
  return null;
}

/** Absolute Denial: an enemy's spell at 8 PP or less, cast from or into the 20-ft aura, while you are conscious and it is up. */
export function denialStops({ pp = 0, enemy = false, conscious = true, suppressed = false, casterFeet = null, targetFeet = [] } = {}) {
  if (!enemy || !conscious || suppressed) return false;
  if (int(pp) > DENIAL_MAX_PP) return false;
  const inside = (f) => f !== null && f !== undefined && Number(f) <= DENIAL_FEET;
  return inside(casterFeet) || Array.from(targetFeet ?? []).some(inside);
}

/** Grasping Shadows' Reflex ladder (m42: Partial reads Failure, Fumble reads Blunder). */
export function graspingSpec(dc) {
  const slowed = [{ key: "slowed", value: 1, rounds: 1 }];
  const held = [{ key: "immobilised", rounds: 1 }];
  return {
    save: "reflex", basic: false, dc: int(dc), scope: "targets",
    outcomes: { heroic: "No effect.", critical: "No effect.", success: "Slowed 1 until the end of its next turn.", partial: "Immobilised until the end of its next turn.", failure: "Immobilised until the end of its next turn.", fumble: "Immobilised until the end of its next turn, and the shadow-hands tear at it.", blunder: "Immobilised until the end of its next turn, and the shadow-hands tear at it." },
    conditions: { heroic: [], critical: [], success: slowed, partial: held, failure: held, fumble: held, blunder: held }
  };
}
/** …and the Blunder's "1d6 essence damage per 2-character levels (basic Fort)". */
export const graspingTear = (level) => perTwoPP(level);

/** Spell Weaver's ×1.5, one of three (chosen). */
export function weaverExtend(choice) {
  if (choice === "duration") return { durationFactor: RESERVOIR_FACTOR };
  if (choice === "range") return { rangeFactor: RESERVOIR_FACTOR };
  if (choice === "area") return { areaFactor: RESERVOIR_FACTOR };
  return null;
}

/** The Magical Reservoir's "(minimum 1)": the use an Intelligence of 0 or less leaves out. */
export const reservoirFloorBonus = (intelligence) => (int(intelligence) >= 1 ? 0 : 1);

/** Overflow Casting: 2d6 per excess charge. */
export const overflowDice = (excess) => (int(excess) > 0 ? `${OVERFLOW_DICE_PER_CHARGE * int(excess)}d${OVERFLOW_DIE}` : "");

/**
 * Wellspring Conduit: "+1d6 damage per 2 PP expended", of the spell's first
 * damage type, or healing. Graham's ruling of 4 November 2026: the PP the
 * spell is cast at (base + warps and metamagic, Q101's), read from the G1
 * `apply(ctx)`'s `castPP` (TRG Prime 3.684.1), else the printed base.
 */
/** Graham, 4 November 2026: the PP the spell is cast at (G1's `castPP`, 3.684.1), else its base. */
export const wellspringPP = (ctx = {}) => (ctx.castPP === undefined || ctx.castPP === null ? int(ctx.basePP) : int(ctx.castPP));

export function wellspringAnswer({ basePP = 0, damageTypes = [], healing = false } = {}) {
  const dice = perTwoPP(basePP);
  if (!dice) return null;
  const type = String(Array.from(damageTypes ?? [])[0] ?? "").toLowerCase();
  if (type) return { addedDamage: [{ dice, type, label: "Wellspring Conduit" }], lines: [`Wellspring Conduit: +${dice} ${type}.`] };
  if (healing) return { mods: { healDice: dice }, lines: [`Wellspring Conduit: +${dice} healing.`] };
  return null;
}

/** Stormcaller's discount: Storm Bolt or its burst variant, not an item's cast. */
export const stormDiscountApplies = (ctx = {}) => !ctx.itemCast && (norm(ctx.spell?.name) === norm(NAMES.stormBolt) || norm(ctx.spell?.flags?.[SYSTEM_ID]?.eaVariantOf) === norm(NAMES.stormBolt));

/** Duellist's Focus: +1, +2 when the miss was a spell attack. */
export const duellistFocusBonus = (spellAttack) => (spellAttack ? DUELLIST_FOCUS.spell : DUELLIST_FOCUS.strike);

/** A spell attack's casting check names its spell: "Name — Cast a Spell". */
export const spellNameOfCheck = (label) => String(label ?? "").split(" — ")[0].trim();

/** A Touch-range spell is a melee spell attack. */
export const touchRange = (range) => /^\s*touch\b/i.test(String(range ?? ""));

/** A round key for once-a-round marks: the combat's round, or the world minute out of combat. */
export function roundKey(combat, worldTime = 0) {
  return combat?.started ? `${combat.id}:${int(combat.round)}` : `t:${Math.floor(Number(worldTime || 0) / 60)}`;
}

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
export const ownedNamed = (actor, name, types = ["feat", "ability"]) => items(actor).find((i) => types.includes(i.type) && norm(i.name) === norm(name)) ?? null;
const has = (actor, name) => Boolean(ownedNamed(actor, name));
const spellNamed = (actor, name) => items(actor).find((i) => i.type === "spell" && norm(i.name) === norm(name)) ?? null;
const worldNow = () => Number(globalThis.game?.time?.worldTime ?? 0);
const thisRound = () => roundKey(globalThis.game?.combat, worldNow());
const placeables = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (t) => t?.document?.disposition;
const ppOf = (actor) => int(actor?.system?.resources?.pp?.value);
const spellDCOf = (actor) => int(actor?.system?.magic?.spellcraft?.dc);
const fromUuid = async (uuid) => {
  if (!uuid) return null;
  const f = globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid;
  try { return f ? await f(uuid) : null; } catch { return null; }
};
const actorOf = (doc) => doc?.actor ?? doc ?? null;
const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];
const confirm = async (title, content) => {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  return D?.confirm ? Boolean(await D.confirm({ window: { title }, content, rejectClose: false })) : false;
};

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function spendPP(actor, pp, label) {
  if (pp <= 0) return true;
  const have = ppOf(actor);
  if (have < pp) return warn(`${label}: ${pp} PP required (you have ${have}).`);
  await actor.update({ "system.resources.pp.value": have - pp });
  return true;
}
async function reactionBlocked(actor, traits = "") {
  if (!actor) return "no creature";
  if (actor.hasCondition?.("unconscious")) return "unconscious";
  if (await h().isDead?.(actor)) return "dead";
  return (await h().reactionRefusal?.(actor, traits)) || "";
}
async function lightAt(token) {
  try { const l = await h().lightLevelAt?.(token); return l === undefined ? null : l; } catch { return null; }
}
/** A mark on an item, kept until the round (or daily preparation) changes. */
const markFlag = (item, key) => item?.getFlag?.(MODULE_ID, key) ?? null;
async function setMark(item, key, value) { await item?.setFlag?.(MODULE_ID, key, value); }

/** Set this user's targets for the length of `run`, then put them back (as Block 5a's). */
async function withTargets(ids, run) {
  const tokens = globalThis.canvas?.tokens?.placeables ?? [];
  const previous = Array.from(game.user?.targets ?? []).map((t) => t.id);
  const set = (want) => {
    const s = new Set(want);
    for (const t of tokens) if (t.isTargeted !== s.has(t.id)) t.setTarget(s.has(t.id), { user: game.user, releaseOthers: false, groupSelection: true });
  };
  try { set(ids); return await run(); } finally { set(previous); }
}

/** Teleport to a clicked square within `feet` (Gale Step's click). `{ feet, was }`, or null. */
async function teleportWithin(token, feet, label) {
  const point = await pickPoint(`${label}: click where you land (up to ${feet} ft). Escape cancels.`);
  if (!point) return null;
  const grid = canvas.grid;
  const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x, y: point.y };
  const dist = grid.measurePath([tokenCentre(token), { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
  if (dist > feet) { warn(`${label}: that is ${Math.round(dist)} feet away; you may go up to ${feet} feet.`); return null; }
  const src = token.document._source ?? token.document;
  const was = { x: src.x, y: src.y };
  await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
  const now = token.document._source ?? token.document;
  if (now.x === was.x && now.y === was.y) { warn(`${label}: the teleport was refused (see the notice), so nothing is spent.`); return null; }
  return { feet: Math.max(1, Math.round(dist)), was };
}

/** Conditions until the start of the bearer's next turn (as Block 5a's Veil of Honour). */
async function conditionToNextTurn(actor, key, label) {
  const round = globalThis.game?.combat?.started ? int(game.combat.round) + 1 : null;
  await h().applyConditionTags(actor, [{ key, label }], round ? { expiresRound: round } : { expiresTime: worldNow() + 6 });
}

/* ------------------------------------------------------------------ */
/* Fade Step (Eclipse Step, Shadowmantle, Grasping Shadows)             */
/* ------------------------------------------------------------------ */

export const ECLIPSE_FREE_FLAG = "eclipseFreeRound";
export const ECLIPSE_DAY_FLAG = "eclipseLongUsed";
export const MANTLE_DAY_FLAG = "shadowmantleHiddenUsed";

/** The ways Fade Step can be taken now. */
export function fadeModes({ eclipse = false, freeUsedThisRound = false, longUsedToday = false, inCombat: fighting = false } = {}) {
  const out = [{ key: "ap", label: `1 AP — up to ${FADE_FEET} ft`, feet: FADE_FEET, ap: 1 }];
  if (eclipse && fighting && !freeUsedThisRound) out.push({ key: "free", label: `Free (Eclipse Step, once a round) — up to ${FADE_FEET} ft`, feet: FADE_FEET, ap: 0 });
  if (eclipse && !longUsedToday) out.push({ key: "long", label: `Eclipse Step (once a day) — up to ${ECLIPSE_FEET} ft, then Concealed`, feet: ECLIPSE_FEET, ap: 1 });
  return out;
}

const fadeStep = {
  hint: "1 AP: teleport from shadow to shadow, up to 30 ft (Focus).",
  async use(actor, item) {
    const token = tokenOf(actor);
    if (!token) return warn("Fade Step: place your token on the map first.");
    const eclipse = ownedNamed(actor, "Eclipse Step");
    const fighting = inCombat(actor);
    const modes = fadeModes({
      eclipse: Boolean(eclipse), inCombat: fighting,
      freeUsedThisRound: markFlag(eclipse, ECLIPSE_FREE_FLAG) === thisRound(),
      longUsedToday: Boolean(markFlag(eclipse, ECLIPSE_DAY_FLAG))
    });
    let mode = modes[0];
    if (modes.length > 1) {
      const pick = await h().chooseFromList("Fade Step", "How do you step?", modes.map((m) => [m.key, m.label]));
      mode = modes.find((m) => m.key === pick);
      if (!mode) return false;
    }
    const origin = await lightAt(token);
    if (origin !== null && !inShadow(origin)) return warn(`Fade Step: the light where you stand is ${origin}; you must start in light 5 or less (dim light or darkness).`);
    if (fighting && mode.ap > 0 && int(actor.system?.resources?.ap?.value) < mode.ap) return warn(`Fade Step: ${mode.ap} AP required.`);
    const moved = await teleportWithin(token, mode.feet, "Fade Step");
    if (!moved) return false;
    const landing = await lightAt(token);
    if (landing !== null && !inShadow(landing)) {
      await token.document.update({ x: moved.was.x, y: moved.was.y }, { animate: false, teleport: true });
      return warn(`Fade Step: the light where you would land is ${landing}, above 5 — you are put back and nothing is spent.`);
    }
    if (mode.ap > 0 && !(await spendAP(actor, "Fade Step", mode.ap))) return false;
    const lines = [line(`You fade through the shadows <strong>${moved.feet} feet</strong>${mode.key === "free" ? " as a free action (Eclipse Step)" : mode.key === "long" ? " (Eclipse Step's 120-foot step)" : ""}.`)];
    if (origin === null || landing === null) lines.push(line("<em>The light here could not be read: whether both ends are in shadow is the GM's call.</em>"));
    if (mode.key === "free") await setMark(eclipse, ECLIPSE_FREE_FLAG, thisRound());
    if (mode.key === "long") {
      await setMark(eclipse, ECLIPSE_DAY_FLAG, true);
      await conditionToNextTurn(actor, "concealed", "Concealed");
      lines.push(line("You are <strong>Concealed</strong> until the start of your next turn."));
    }
    const mantle = ownedNamed(actor, "Shadowmantle");
    if (mantle && !markFlag(mantle, MANTLE_DAY_FLAG) && await confirm("Shadowmantle", "<p>Use <strong>Shadowmantle</strong>'s once-a-day: become <strong>Hidden</strong> until the start of your next turn, even if observed?</p>")) {
      await setMark(mantle, MANTLE_DAY_FLAG, true);
      await conditionToNextTurn(actor, "hidden", "Hidden");
      lines.push(line("<strong>Shadowmantle</strong>: you are <strong>Hidden</strong> until the start of your next turn (today's use spent)."));
    }
    lines.push(line("<em>Focus use spent — Refocus restores it.</em>"));
    await card(actor, "Fade Step", lines);
    await offerGraspingShadows(actor, token, "Fade Step");
    return true;
  }
};

/** Grasping Shadows: 1 PP, one creature within 10 ft of `from` (you for a spell, the landing square for Fade Step; Q121). */
export async function offerGraspingShadows(actor, from, why) {
  if (!has(actor, "Grasping Shadows") || !from || ppOf(actor) < GRASP_PP) return false;
  const near = placeables().filter((t) => t.actor !== actor && t !== from).filter((t) => { const d = feetBetween(from, t); return d !== null && d <= GRASP_FEET; });
  if (!near.length) return false;
  const pick = await h().chooseFromList("Grasping Shadows", `${esc(why)}: spend ${GRASP_PP} PP to summon clutching shadow-hands on one creature within ${GRASP_FEET} feet? Cancel to decline.`, near.map((t) => [t.id, esc(t.name)]));
  const target = near.find((t) => t.id === pick);
  if (!target) return false;
  if (!(await spendPP(actor, GRASP_PP, "Grasping Shadows"))) return false;
  const dc = spellDCOf(actor);
  const results = [];
  const lines = await h().runAreaEffect(actor, graspingSpec(dc), { title: "Grasping Shadows", targets: [target.actor], results });
  const out = [line(`Shadow-hands clutch at <strong>${esc(target.name)}</strong>: Reflex against DC ${dc}.`), ...(lines ?? [])];
  const degree = String(results[0]?.degree ?? "");
  if (FUMBLE_DOWN.includes(degree)) {
    const dice = graspingTear(levelOf(actor));
    if (dice) out.push(...(await h().runAreaEffect(actor, { save: "fortitude", basic: true, dc, damage: { formula: dice, type: "essence" }, scope: "targets" }, { title: "Grasping Shadows", targets: [target.actor] }) ?? []));
  }
  out.push(line(`<em>${GRASP_PP} PP spent.</em>`));
  await card(actor, "Grasping Shadows", out);
  return true;
}

/* ------------------------------------------------------------------ */
/* The other Uses                                                       */
/* ------------------------------------------------------------------ */

export const CC_ALLIES_FLAG = "counterChannelAllies";
export const DENIAL_SUPPRESSED_FLAG = "denialSuppressed";
export const EYE_SOURCE = "eyeOfTheStorm";

const counterChannelUse = {
  hint: "Toggle: also be asked when an ally casts (Q118). Spends nothing.",
  ownsFocusUse: true,
  async use(actor, item) {
    const on = !item.getFlag?.(MODULE_ID, CC_ALLIES_FLAG);
    await item.setFlag(MODULE_ID, CC_ALLIES_FLAG, on);
    await card(actor, "Counter Channel", [line(on ? "You will also be asked when an <strong>ally</strong> casts within range." : "You will be asked only when a creature that is not your ally casts.")]);
    return true;
  }
};

const absoluteDenialUse = {
  hint: "0 AP at the start of your turn: suppress or resume the Denial Aura.",
  async use(actor, item) {
    const c = combatFor(actor);
    if (c && c.combatant?.actor !== actor) return warn("Absolute Denial: only on your own turn (at its start).");
    const suppressed = !item.getFlag?.(MODULE_ID, DENIAL_SUPPRESSED_FLAG);
    await item.setFlag(MODULE_ID, DENIAL_SUPPRESSED_FLAG, suppressed);
    await card(actor, "Absolute Denial", [line(suppressed ? "Your Denial Aura is <strong>suppressed</strong>." : "Your Denial Aura is <strong>resumed</strong> (20 ft: enemy spells of 8 PP or less fail).")]);
    return true;
  }
};

const eyeOfTheStorm = {
  hint: "Once a day: expand the storm aura to 30 ft for 3 rounds (electricity each of your turns; immune to electricity).",
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Eye of the Storm: once a day — daily preparation restores it.");
    if (!(await spendUse(item))) return false;
    await h().createEffectsOn(actor, [effectData(EYE_SOURCE, {
      name: "Eye of the Storm: expanded (30 ft)", img: "icons/svg/lightning.svg",
      description: "Eye of the Storm: the storm aura is 30 ft for 3 rounds; enemies within it take 1d6 electricity per level (basic Reflex) at the start of each of your turns; you are immune to electricity.",
      changes: [{ key: "system.combat.immunities", mode: 2, value: ", electricity", priority: 20 }],
      module: { pulsesLeft: EYE_PULSES },
      expiry: forSeconds(6 * (EYE_PULSES + 1))
    })]);
    await card(actor, "Eye of the Storm", [
      line(`Your storm aura expands to <strong>${EYE_FEET} feet</strong>: at the start of each of your next ${EYE_PULSES} turns every enemy in it takes <strong>${levelOf(actor)}d6 electricity</strong> (basic Reflex against DC ${spellDCOf(actor)}). You are <strong>immune to electricity</strong> while it lasts.`),
      line("<em>Today's use is spent. The 10-foot aura's difficult terrain is the GM's.</em>")
    ]);
    return true;
  }
};

/** Gale Step, REPLACING Block 3's entry: its own Use, at 0 AP for a Stormcaller. */
export const galeStepAP = (actor) => (has(actor, "Stormcaller") ? 0 : 1);
const galeStep = {
  hint: "1 AP (0 for a Stormcaller): teleport up to 15 feet.",
  async use(actor) {
    const token = tokenOf(actor);
    if (!token) return warn("Gale Step: place your token on the map first.");
    const ap = galeStepAP(actor);
    if (inCombat(actor) && ap > 0 && int(actor.system?.resources?.ap?.value) < ap) return warn("Gale Step: 1 AP required.");
    const moved = await teleportWithin(token, 15, "Gale Step");
    if (!moved) return;
    if (ap > 0 && !(await spendAP(actor, "Gale Step", ap))) return;
    await card(actor, "Gale Step", [line(`You teleport ${moved.feet} feet.`), ...(inCombat(actor) ? [line(ap ? "1 AP spent." : "0 AP (Stormcaller).")] : [])]);
  }
};

export const AUTOMATIONS_B6_B2 = Object.freeze({
  "Fade Step": fadeStep,
  "Counter Channel": counterChannelUse,
  "Absolute Denial": absoluteDenialUse,
  "Eye of the Storm": eyeOfTheStorm,
  "Gale Step": galeStep
});

/* ------------------------------------------------------------------ */
/* Cast reactions                                                       */
/* ------------------------------------------------------------------ */

export const ABSORB_STEP = "eldritchArts.runebreakerAbsorb";
export const COUNTER_STEP = "eldritchArts.counterChannel";
export const RIPOSTE_STEP = "eldritchArts.spellstrikeRiposte";

const userTargets = () => Array.from(globalThis.game?.user?.targets ?? []);

/**
 * THE PP AS CAST (review; Q119): the cast reaction's `castPP` (an innate
 * spell's printed PP + warps, which `pp` leaves at 0 + warps), else `pp`.
 */
export const castPPOf = (ctx = {}) => (ctx.castPP === undefined || ctx.castPP === null ? int(ctx.pp) : int(ctx.castPP));

/** Absolute Denial: stopped before anything else is asked. */
async function absoluteDenial(ctx) {
  const caster = ctx?.actor, casterToken = ctx?.token;
  if (!caster || !casterToken) return null;
  const targets = userTargets();
  for (const owner of placeables()) {
    if (owner.actor === caster) continue;
    const feat = ownedNamed(owner.actor, "Absolute Denial");
    if (!feat) continue;
    const stops = denialStops({
      pp: castPPOf(ctx), enemy: enemies(side(owner), side(casterToken)),
      conscious: !owner.actor.hasCondition?.("unconscious") && !(await h().isDead?.(owner.actor)),
      suppressed: Boolean(feat.getFlag?.(MODULE_ID, DENIAL_SUPPRESSED_FLAG)),
      casterFeet: feetBetween(owner, casterToken), targetFeet: targets.map((t) => feetBetween(owner, t))
    });
    if (stops) return { stop: true, line: `${esc(owner.name)}'s <strong>Absolute Denial</strong>: ${esc(ctx.spell?.name ?? "the spell")} (${castPPOf(ctx)} PP) fails within the Denial Aura.` };
  }
  return null;
}

/** Runebreaker: a spell whose sole target is you. */
async function runebreakerAbsorb(ctx) {
  const caster = ctx?.actor;
  if (!caster) return null;
  const targets = userTargets();
  const reactorToken = targets[0];
  const reactor = reactorToken?.actor;
  if (!absorbable({ targets: targets.map((t) => t.actor), reactor, caster, spellData: ctx.spellData })) return null;
  const feat = ownedNamed(reactor, "Runebreaker");
  const rune = spellNamed(reactor, NAMES.storingRune);
  if (!feat || !rune) return null;
  const runePP = int(rune.system?.ppCost);
  if (ppOf(reactor) < runePP) return null;
  if (await reactionBlocked(reactor, "")) return null;
  const q = await h().askReactor(reactor, {
    title: `Runebreaker — ${reactor.name}`,
    content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${castPPOf(ctx)} PP) at you alone.</p>`
      + `<p>Cast <strong>Storing Rune</strong> as your reaction (${runePP} PP) to absorb it? You roll Will against ${esc(caster.name)}'s Spell DC (${spellDCOf(caster)}); on a Success the spell is stopped and stored in your rune.</p>`,
    buttons: yesNo("Absorb it"),
    step: ABSORB_STEP,
    data: { spellUuid: ctx.spell?.uuid ?? "", spellName: ctx.spell?.name ?? "", pp: castPPOf(ctx), dc: spellDCOf(caster), casterUuid: caster.uuid ?? "", casterTokenUuid: ctx.token?.document?.uuid ?? ctx.token?.uuid ?? "", casterName: caster.name, runeId: rune.id }
  });
  if (!q?.result?.rolled) return null;
  return q.result.absorbed
    ? { stop: true, line: `${esc(reactor.name)}'s <strong>Runebreaker</strong> (${esc(q.result.degree)}): ${esc(ctx.spell?.name ?? "the spell")} is absorbed into the Storing Rune.` }
    : { stop: false, line: `${esc(reactor.name)}'s <strong>Runebreaker</strong> (${esc(q.result.degree)}) fails to absorb ${esc(ctx.spell?.name ?? "the spell")}.` };
}

async function absorbStep(actor, answer, data = {}) {
  const rune = actor?.items?.get?.(data.runeId);
  if (!rune) return { rolled: false };
  // EVERYTHING CHECKED BEFORE ANYTHING IS SPENT (review).
  if (ppOf(actor) < int(rune.system?.ppCost) || await reactionBlocked(actor, "")) return { rolled: false };
  if (!(await h().spendReaction?.(actor, "Runebreaker", { traits: "" }))) return { rolled: false };
  await spendPP(actor, int(rune.system?.ppCost), "Storing Rune");
  const check = await h().rollCheck({ actor, type: "save", subject: "will", label: `Runebreaker — absorb ${data.spellName}`, dc: int(data.dc), saveSource: data.spellName, sourceUuid: data.casterUuid });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  const lines = [line(`Storing Rune cast as your reaction (${int(rune.system?.ppCost)} PP): Will ${int(check?.outcome?.total)} against DC ${int(data.dc)} — <strong>${esc(degree)}</strong>.`)];
  let absorbed = false;
  if (succeeded(degree)) {
    const spell = await fromUuid(data.spellUuid);
    const kept = spell ? await h().storeForeignSpell(actor, spell, { ppPaid: int(data.pp), mods: {}, host: rune, from: { name: data.casterName, uuid: data.casterUuid } }) : null;
    absorbed = Boolean(kept);
    lines.push(line(absorbed
      ? `<strong>${esc(data.spellName)}</strong> is absorbed into your Storing Rune (${int(data.pp)} PP), to be released as your own casting. <em>Its caster's warps are not carried.</em>`
      : `<em>${esc(data.spellName)} could not be stored (no spell document or no rune to hold it): the GM settles it.</em>`));
  }
  await card(actor, "Runebreaker", lines);
  if (absorbed) await offerRuneRend(actor, data);
  return { rolled: true, absorbed, degree };
}

/** Rune Rend: after an absorb, 1 PP, the caster's basic Will. */
async function offerRuneRend(actor, data) {
  if (!has(actor, "Rune Rend") || ppOf(actor) < REND_PP) return;
  const dice = perTwoPP(data.pp);
  if (!dice) return;
  if (!(await confirm("Rune Rend", `<p>Spend ${REND_PP} PP to lash ${esc(data.casterName)} with the absorbed spell's unravelling: <strong>${dice} force</strong>, basic Will against your Spell DC (${spellDCOf(actor)})?</p>`))) return;
  const target = actorOf(await fromUuid(data.casterTokenUuid)) ?? actorOf(await fromUuid(data.casterUuid));
  if (!target) return void card(actor, "Rune Rend", [line("<em>The caster could not be found: the GM rolls it.</em>")]);
  if (!(await spendPP(actor, REND_PP, "Rune Rend"))) return;
  const lines = await h().runAreaEffect(actor, { save: "will", basic: true, dc: spellDCOf(actor), damage: { formula: dice, type: "force" }, scope: "targets" }, { title: "Rune Rend", targets: [target] });
  await card(actor, "Rune Rend", [...(lines ?? []), line(`<em>${REND_PP} PP spent.</em>`)]);
}

/** Counter Channel: a creature within 30 ft (60) casts. */
async function counterChannel(ctx) {
  const caster = ctx?.actor, casterToken = ctx?.token;
  if (!caster || !casterToken) return null;
  const said = [];
  for (const reactorToken of placeables()) {
    const reactor = reactorToken.actor;
    if (reactor === caster || reactorToken === casterToken) continue;
    const cc = ownedNamed(reactor, NAMES.counterChannel);
    if (!cc || usesLeft(cc) <= 0 || ppOf(reactor) < CC_PP) continue;
    const d = feetBetween(reactorToken, casterToken);
    if (d === null || d > counterChannelFeet(has(reactor, "Improved Counter Channel"))) continue;
    if (allies(side(reactorToken), side(casterToken)) && !cc.getFlag?.(MODULE_ID, CC_ALLIES_FLAG)) continue;
    const instinctive = has(reactor, "Instinctive Counter Channel") && markFlag(cc, "instinctiveRound") !== thisRound();
    if (!instinctive && await reactionBlocked(reactor, cc.system?.traits ?? "")) continue;
    const hasSave = Boolean(String(ctx.spellData?.defence ?? "").trim());
    const castingAbility = int(caster.system?.attributes?.[caster.system?.magic?.castingAbility]?.total);
    // THE SPELL'S SAVE DC (Q118): the cast's, when the core hands it; an
    // innate spell's own (10 + ability + level, G25); else 10 + the PP as cast + ability.
    const innateDC = ctx.innate && hasSave ? int((await h().innateSaveDCFor?.(caster, ctx.spell))?.value) : 0;
    const dc = int(ctx.saveDC) || innateDC || counterChannelDC({ hasSave, pp: castPPOf(ctx), castingAbility, spellDC: spellDCOf(caster) });
    const q = await h().askReactor(reactor, {
      title: `Counter Channel — ${reactor.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${castPPOf(ctx)} PP), ${d} feet from you.</p>`
        + `<p>Use <strong>Counter Channel</strong> (${instinctive ? "a free action (Instinctive)" : "your reaction"}, its Focus use and ${CC_PP} PP)? Power Manipulation against DC ${dc}: Critical negates it; Success halves it; Fumble doubles it.</p>`,
      buttons: yesNo("Counter Channel"),
      step: COUNTER_STEP,
      data: { itemId: cc.id, dc, instinctive, spellName: ctx.spell?.name ?? "" }
    });
    if (!q?.result?.rolled) continue;
    const answer = counterChannelAnswer(q.result.degree, { reflect: q.result.reflect });
    const name = esc(ctx.spell?.name ?? "the spell");
    if (!answer) { said.push(`${esc(reactor.name)}'s <strong>Counter Channel</strong> (${esc(q.result.degree)}): ${name} resolves normally.`); continue; }
    const what = answer.stop ? "negated" : answer.retargetCaster ? "turned back on its caster (Reflective Warding)" : answer.scale === 0.5 ? "halved" : "doubled";
    return { ...answer, line: [...said, `${esc(reactor.name)}'s <strong>Counter Channel</strong> (${esc(q.result.degree)}): ${name} is ${what}.`].join("<br>") };
  }
  return said.length ? { line: said.join("<br>") } : null;
}

async function counterStep(actor, answer, data = {}) {
  const item = actor?.items?.get?.(data.itemId);
  if (!item || usesLeft(item) <= 0 || ppOf(actor) < CC_PP) return { rolled: false };
  if (data.instinctive) await setMark(item, "instinctiveRound", thisRound());
  else if (!(await h().spendReaction?.(actor, "Counter Channel", { traits: String(item.system?.traits ?? "") }))) return { rolled: false };
  await spendUse(item);
  await spendPP(actor, CC_PP, "Counter Channel");
  const check = await h().rollCheck({ actor, type: "skill", subject: "powerManipulation", label: `Counter Channel — ${data.spellName}`, dc: int(data.dc) });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  let reflect = false;
  if (CRITICAL_UP.includes(degree) && has(actor, "Reflective Warding")) {
    const pick = await h().chooseFromList("Reflective Warding", `${esc(data.spellName)}: negate it, or redirect it at its caster (its own save DC; an area spell is the GM's)?`, [["negate", "Negate it"], ["reflect", "Redirect it at its caster"]]);
    reflect = pick === "reflect";
  }
  await card(actor, "Counter Channel", [line(`Power Manipulation ${int(check?.outcome?.total)} against DC ${int(data.dc)}: <strong>${esc(degree)}</strong>.`), line(`<em>${data.instinctive ? "Free action (Instinctive)" : "Reaction"}, Focus use and ${CC_PP} PP spent.</em>`)]);
  return { rolled: true, degree, reflect };
}

/* ------------------------------------------------------------------ */
/* Check reactions                                                      */
/* ------------------------------------------------------------------ */

/** Was this save forced by another creature's spell (`saveSource` is set by the cast)? */
export const spellForcedSave = (ctx = {}, self = []) => ctx.type === "save" && Boolean(String(ctx.saveSource ?? "").trim()) && Boolean(String(ctx.sourceUuid ?? "").trim()) && !self.includes(String(ctx.sourceUuid ?? ""));
/**
 * …AND ITS SOURCE IS A SPELL (review): `basicSaveHit` names any area's label
 * (Glyph Shatter, Eye of the Storm, a breath), so the save counts only when
 * the creature that forced it holds a spell of that name.
 */
export const isSpellOf = (source, name) => Array.from(source?.items ?? []).some((i) => i?.type === "spell" && norm(i.name) === norm(name));
async function spellSourced(ctx, self) {
  if (!spellForcedSave(ctx, self)) return false;
  return isSpellOf(actorOf(await fromUuid(ctx.sourceUuid)), ctx.saveSource);
}
const selfUuids = (actor, token) => [actor?.uuid, token?.document?.uuid, token?.uuid].filter(Boolean).map(String);

/** Spellwarden and Shadowmantle: before a spell-forced save. */
const saveWards = {
  async before(ctx) {
    const actor = ctx.actor;
    if (!(await spellSourced(ctx, selfUuids(actor, ctx.token)))) return null;
    const rows = [];
    if (has(actor, "Spellwarden")) rows.push({ label: "Spellwarden (save against magic)", value: SPELLWARDEN_BONUS, type: "class" });
    if (has(actor, "Shadowmantle") && inShadow(await lightAt(ctx.token))) rows.push({ label: "Shadowmantle (light 5 or less)", value: SHADOWMANTLE_BONUS, type: "circumstance" });
    return rows.length ? { modifiers: rows } : null;
  },
  /** Deep Weave: a critical save against a spell regains a charge, once a round. */
  async after(ctx) {
    if (!CRITICAL_UP.includes(String(ctx.degree)) || !(await spellSourced(ctx, selfUuids(ctx.actor, ctx.token)))) return null;
    await regainCharge(ctx.actor, "a critical save against a spell");
    return null;
  }
};

/** Spellstrike Riposte against a melee (Touch) spell attack that missed. */
const riposteSpell = {
  async after(ctx) {
    if (ctx.type !== "attack" || !ctx.failed || ctx.check?.reactionAs !== "attack" || !ctx.target) return null;
    const spell = spellNamed(ctx.actor, spellNameOfCheck(ctx.label));
    if (!spell || !touchRange(spell.system?.range)) return null;
    await offerRiposte(ctx.actor, ctx.target, { spellAttack: true });
    return null;
  }
};

/** Deep Weave: +1 charge, once a round, up to the maximum. */
export async function regainCharge(actor, why) {
  const dw = ownedNamed(actor, "Deep Weave");
  const res = ownedNamed(actor, NAMES.reservoir);
  if (!dw || !res || !actor?.isOwner) return false;
  if (markFlag(dw, "regainRound") === thisRound()) return false;
  const max = h().itemUsesMax(res);
  const left = h().itemUsesRemaining(res);
  if (!Number.isFinite(max) || left >= max) return false;
  await setMark(dw, "regainRound", thisRound());
  await res.update({ "system.usesValue": left + 1 });
  await card(actor, "Deep Weave", [line(`${esc(why)}: your Magical Reservoir regains <strong>1 charge</strong> (${left + 1}/${max}).`)]);
  return true;
}

/* ------------------------------------------------------------------ */
/* Spellstrike Riposte (Duellist's Focus, Supremacy, Rippling Counter)  */
/* ------------------------------------------------------------------ */

/**
 * Is `attacker` the Spellblade's Mark of `me`? Read off group C's Mark
 * effect on its maker (block6c-automations.mjs: source "spellbladesMark",
 * module flag `markUuid` = the marked creature's actor uuid).
 */
export const MARK_EFFECT_SOURCE = "spellbladesMark";
export function isMarkOf(attacker, me) {
  const uuid = String(attacker?.uuid ?? "");
  if (!uuid) return false;
  return Array.from(me?.effects ?? []).some((e) => !e?.disabled && e.flags?.[MODULE_ID]?.source === MARK_EFFECT_SOURCE && String(e.flags?.[MODULE_ID]?.markUuid ?? "") === uuid);
}

/** The PP the riposte costs now: none once a round with Duellist's Supremacy. */
export const ripostePP = ({ supremacy = false, freeUsedThisRound = false } = {}) => (supremacy && !freeUsedThisRound ? 0 : RIPOSTE_PP);

async function offerRiposte(attacker, target, { spellAttack = false } = {}) {
  const riposte = ownedNamed(target, NAMES.riposte);
  if (!riposte || usesLeft(riposte) <= 0) return;
  const sup = ownedNamed(target, "Duellist’s Supremacy");
  const pp = ripostePP({ supremacy: Boolean(sup), freeUsedThisRound: markFlag(sup, "freeRound") === thisRound() });
  if (ppOf(target) < pp) return;
  if (await reactionBlocked(target, riposte.system?.traits ?? "")) return;
  const attackerToken = tokenOf(attacker);
  await h().askReactor(target, {
    title: `Spellstrike Riposte — ${target.name}`,
    content: `<p><strong>${esc(attacker.name)}</strong> misses you with a melee ${spellAttack ? "spell attack" : "attack"}.</p>`
      + `<p>Use <strong>Spellstrike Riposte</strong> (your reaction, its Focus use${pp ? ` and ${pp} PP` : ", no PP (Duellist's Supremacy)"})? A melee Strike at it, ignoring the Multiple Attack Penalty, through which you may channel a cantrip.</p>`,
    buttons: yesNo("Riposte"),
    step: RIPOSTE_STEP,
    data: { itemId: riposte.id, attackerUuid: attacker.uuid ?? "", attackerTokenId: attackerToken?.id ?? "", attackerName: attacker.name, spellAttack, pp }
  });
}

/** Damaging cantrips this creature knows: `{ id, name, dice, type }`. */
export function damagingCantrips(actor) {
  return items(actor).filter((i) => i.type === "spell" && int(i.system?.ppCost) === 0 && String(i.system?.damage?.formula ?? "").trim() && String(i.system?.damage?.type ?? "").trim())
    .map((i) => ({ id: i.id, name: i.name, dice: String(i.system.damage.formula).trim(), type: String(i.system.damage.type).trim().toLowerCase() }));
}
const meleeWeapons = (actor) => items(actor).filter((i) => i.type === "weapon" && i.system?.equipped !== false && !["ranged", "thrown"].includes(norm(i.system?.attackMode)));

async function riposteStep(actor, answer, data = {}) {
  const item = actor?.items?.get?.(data.itemId);
  if (!item || usesLeft(item) <= 0) return { done: false };
  const attacker = actorOf(await fromUuid(data.attackerUuid));
  const weapons = meleeWeapons(actor);
  if (!attacker || !weapons.length || !data.attackerTokenId) { warn("Spellstrike Riposte: no melee weapon in hand, or the attacker has no token."); return { done: false }; }
  let weapon = weapons[0];
  if (weapons.length > 1) {
    const pick = await h().chooseFromList("Spellstrike Riposte", "Strike with which weapon?", weapons.map((w) => [w.id, esc(w.name)]));
    weapon = weapons.find((w) => w.id === pick);
    if (!weapon) return { done: false };
  }
  const cantrips = damagingCantrips(actor);
  let cantrip = null;
  if (cantrips.length) {
    const pick = await h().chooseFromList("Spellstrike Riposte", "Channel a cantrip through the Strike? Its damage is added as secondary damage if the Strike hits (Cancel: none).", cantrips.map((c) => [c.id, `${esc(c.name)} (${esc(c.dice)} ${esc(c.type)})`]));
    cantrip = cantrips.find((c) => c.id === pick) ?? null;
  }
  const pp = int(data.pp);
  // CHECKED FIRST, SPENT ONLY ONCE THE STRIKE IS MADE (review): a Strike the
  // core refuses (out of reach) costs nothing.
  if (ppOf(actor) < pp || await reactionBlocked(actor, String(item.system?.traits ?? ""))) return { done: false };
  const sup = ownedNamed(actor, "Duellist’s Supremacy");
  const extraModifiers = has(actor, "Duellist’s Focus") ? [{ label: "Duellist’s Focus", value: duellistFocusBonus(Boolean(data.spellAttack)), type: "circumstance" }] : [];
  // ADVANTAGE AGAINST YOUR MARK (Duellist's Supremacy): a one-shot row on this Strike's target only.
  const marked = sup && isMarkOf(attacker, actor);
  if (marked) {
    await h().createEffectsOn(actor, [effectData("riposteAdvantage", {
      name: "Duellist’s Supremacy: advantage on the riposte", img: item.img,
      system: { conditionals: [{ kind: "advantage", label: "Duellist’s Supremacy (your Mark)", auto: true, oneShot: true, when: { checkTypes: ["attack"], targetUuids: [attacker.uuid] } }] },
      expiry: forSeconds(6)
    })]);
  }
  let outcome = null;
  const made = await withTargets([data.attackerTokenId], () => h().rollWeaponAttack(actor, weapon, {
    apPaid: true, isReaction: true, skipTargetPrompt: true, mapOverride: 0, mapFrozen: true, optionLabel: "Spellstrike Riposte",
    extraModifiers, extraTypedDamage: cantrip ? [{ dice: cantrip.dice, type: cantrip.type, label: `${cantrip.name} (channelled)` }] : [],
    beforeDamage: ({ outcome: o }) => { outcome = o; return null; }
  }));
  if (!made) {
    if (marked) await actor.deleteEmbeddedDocuments("ActiveEffect", ownEffects(actor, "riposteAdvantage").map((e) => e.id));
    return { done: false };
  }
  const spentReaction = Boolean(await h().spendReaction?.(actor, "Spellstrike Riposte", { traits: String(item.system?.traits ?? "") }));
  if (pp) await spendPP(actor, pp, "Spellstrike Riposte");
  await spendUse(item);
  if (sup && !pp) await setMark(sup, "freeRound", thisRound());
  const lines = [line(`Riposte at <strong>${esc(data.attackerName)}</strong> with ${esc(weapon.name)}, ignoring the Multiple Attack Penalty${extraModifiers.length ? ` (+${extraModifiers[0].value} Duellist’s Focus)` : ""}${marked ? ", with advantage against your Mark" : ""}.`)];
  if (cantrip) lines.push(line(`${esc(cantrip.name)} is channelled: ${esc(cantrip.dice)} ${esc(cantrip.type)} as secondary damage if the Strike hits (the cantrip is not cast).`));
  lines.push(line(`<em>Reaction, Focus use${pp ? ` and ${pp} PP` : ""} spent.${spentReaction ? "" : " (The reaction could not be spent after the Strike: the GM settles it.)"}</em>`));
  await card(actor, "Spellstrike Riposte", lines);
  if (outcome?.hits && outcome?.critical && has(actor, "Rippling Counter")) await ripplingCounter(actor, weapon, data);
  return { done: true };
}

async function ripplingCounter(actor, weapon, data) {
  await h().armMove(actor, { maxFeet: 5, speedKey: "land", provokes: false, note: "Rippling Counter: a Step" }, "Rippling Counter");
  const go = await confirm("Rippling Counter", `<p>Your riposte was a critical hit. A 5-foot <strong>Step</strong> is armed: drag your token, then make <strong>another melee Strike</strong> at ${esc(data.attackerName)} (no cantrip)?</p>`);
  if (!go) return;
  await withTargets([data.attackerTokenId], () => h().rollWeaponAttack(actor, weapon, { apPaid: true, isReaction: true, skipTargetPrompt: true, optionLabel: "Rippling Counter" }));
}

/* ------------------------------------------------------------------ */
/* Dispel modifiers                                                     */
/* ------------------------------------------------------------------ */

export const GLYPH_BONUS_FLAG = "glyphShatterBonus";
const glyphBonusPending = new Set();

/** Runebreaker: 2 PP less on every Dispel. */
export const runebreakerDispel = {
  offer: (ctx = {}) => (has(ctx.actor, "Runebreaker") ? { label: "Runebreaker", hint: "Dispel costs 2 PP less (min 1).", ppReduction: DISPEL_REDUCTION } : null)
};

/** The +1 waiting from a shattered ward or barrier, if it is still within its minute. */
export function glyphBonusLive(record, now) {
  return Boolean(record) && Number(record.until) >= Number(now);
}

export const glyphShatterDispel = {
  offer(ctx = {}) {
    const actor = ctx.actor;
    if (!has(actor, "Glyph Shatter")) return null;
    const live = glyphBonusLive(actor.getFlag?.(MODULE_ID, GLYPH_BONUS_FLAG), worldNow());
    if (live) glyphBonusPending.add(actor.uuid ?? actor.id);
    return {
      label: "Glyph Shatter", hint: "On a success you may fracture the dispelled effect.",
      ...(live ? { modifiers: [{ label: "Glyph Shatter (a ward or barrier shattered)", value: GLYPH_BONUS, type: "circumstance" }] } : {})
    };
  },
  async onResult(ctx = {}) {
    const actor = ctx.actor;
    const key = actor?.uuid ?? actor?.id;
    if (glyphBonusPending.delete(key)) await actor.unsetFlag?.(MODULE_ID, GLYPH_BONUS_FLAG);
    const won = ctx.counterSpell ? Boolean(ctx.countered) : succeeded(ctx.degree);
    if (!won) return null;
    const value = int(ctx.dispel?.effectValue ?? ctx.dispel?.counteractValue);
    const dice = perTwoPP(value);
    const where = tokenOf(ctx.counterSpell ? ctx.targetCaster : ctx.target);
    const lines = [];
    if (dice && where && await confirm("Glyph Shatter", `<p>Fracture the dispelled effect violently? Every creature within ${GLYPH_FEET} feet of it: <strong>${dice} force</strong>, basic Reflex against your Spell DC (${spellDCOf(actor)}).</p>`)) {
      const hit = placeables().filter((t) => t === where || ((d) => d !== null && d <= GLYPH_FEET)(feetBetween(where, t))).map((t) => t.actor);
      lines.push(...(await h().runAreaEffect(actor, { save: "reflex", basic: true, dc: spellDCOf(actor), damage: { formula: dice, type: "force" }, scope: "targets" }, { title: "Glyph Shatter", targets: hit }) ?? []));
    }
    if (await confirm("Glyph Shatter", "<p>Was the dispelled effect a <strong>ward or barrier</strong>? (Your next Dispel within 1 minute takes +1 circumstance.)</p>")) {
      await actor.setFlag(MODULE_ID, GLYPH_BONUS_FLAG, { until: worldNow() + GLYPH_SECONDS });
      lines.push(`Your next Dispel within 1 minute takes <strong>+${GLYPH_BONUS} circumstance</strong>.`);
    }
    return lines.length ? { lines } : null;
  }
};

/* ------------------------------------------------------------------ */
/* Spell Weaver's reservoir (G1), Wellspring Conduit                     */
/* ------------------------------------------------------------------ */

const reservoirOf = (actor) => ownedNamed(actor, NAMES.reservoir);
export const reservoirCharges = (actor) => { const r = reservoirOf(actor); if (!r) return 0; const left = usesLeft(r); return Number.isFinite(left) ? left : 0; };
const overflowReady = (actor) => { const o = ownedNamed(actor, "Overflow Casting"); return Boolean(o) && usesLeft(o) > 0; };

/** What the reservoir can pay: its charges, or anything while Overflow Casting's Focus use is ready. */
export async function reservoirAvailable(ctx = {}) {
  return overflowReady(ctx.actor) ? Number.MAX_SAFE_INTEGER : reservoirCharges(ctx.actor);
}

/** Pay the charges; the missing ones through Overflow Casting. */
export async function reservoirPay(ctx = {}) {
  const actor = ctx.actor;
  const res = reservoirOf(actor);
  const amount = Math.max(1, int(ctx.amount));
  const have = reservoirCharges(actor);
  const spend = Math.min(have, amount);
  if (res && spend) await res.update({ "system.usesValue": have - spend });
  const excess = amount - spend;
  if (!excess) return { lines: [] };
  const over = ownedNamed(actor, "Overflow Casting");
  if (!over || !(await spendUse(over))) return { lines: ["Overflow Casting could not pay the missing charge: the GM settles it."] };
  const dice = overflowDice(excess);
  const roll = await new Roll(dice).evaluate();
  await h().applyTypedDamage(actor, { amount: roll.total, type: "untyped", ignoreDefences: true, sourceName: "Overflow Casting" });
  const lines = [`Overflow Casting: ${excess} charge${excess === 1 ? "" : "s"} you did not have — ${dice} = ${roll.total} damage, ignoring your defences (its Focus use spent).`];
  if (int(actor.system?.resources?.hp?.value) <= 0) {
    // THE CORE ADDS SOUL DRAIN (condition-rules.mjs `combinedConditionValue`): the 5 gained, not a total.
    await h().applyConditionTags(actor, [{ key: "soulDrain", label: "Soul Drain", value: OVERFLOW_SOUL_DRAIN }], {});
    lines.push(`You are at 0 HP or less: you gain ${OVERFLOW_SOUL_DRAIN} Soul Drain.`);
  }
  return { lines };
}

const reservoirPayment = { resource: { label: "Magical Reservoir charge", cost: 1, available: (ctx) => reservoirAvailable(ctx), pay: (ctx) => reservoirPay(ctx) } };

export const WEAVER_METAMAGIC = Object.freeze({
  [MM.discount]: { feat: "Spell Weaver", label: "Magical Reservoir: −2 PP", hint: "1 charge: 2 PP less to pay (min 0); the DC reads the PP as cast (Q93).", group: WEAVER_GROUP, payment: reservoirPayment, effects: { discount: { pp: RESERVOIR_DISCOUNT, floor: 0, label: "Magical Reservoir" } } },
  [MM.dieStep]: { feat: "Spell Weaver", label: "Magical Reservoir: dice one step up", hint: "1 charge: every damage die one size up (d6 → d8 …).", group: WEAVER_GROUP, payment: reservoirPayment, effects: { dieStep: 1 } },
  [MM.extend]: {
    feat: "Spell Weaver", label: "Magical Reservoir: ×1.5", hint: "1 charge: duration, range or area by 50%.", group: WEAVER_GROUP, payment: reservoirPayment,
    choices: [{ value: "duration", label: "Duration ×1.5" }, { value: "range", label: "Range ×1.5" }, { value: "area", label: "Area ×1.5" }],
    apply: (ctx) => weaverExtend(ctx.choice) ?? { cancel: true, reason: "no extension chosen" }
  },
  [MM.wellspring]: {
    feat: "Wellspring Conduit", label: "Wellspring Conduit", hint: "Reservoir empty: +1d6 per 2 PP (damage or healing).", focus: true,
    applies: (ctx) => Boolean(reservoirOf(ctx.actor)) && reservoirCharges(ctx.actor) === 0 && Boolean(wellspringAnswer({ basePP: wellspringPP(ctx), damageTypes: ctx.damageTypes, healing: /\bhealing\b/i.test(String(ctx.traits ?? "")) })),
    apply: (ctx) => wellspringAnswer({ basePP: wellspringPP(ctx), damageTypes: ctx.damageTypes, healing: /\bhealing\b/i.test(String(ctx.traits ?? "")) }) ?? { cancel: true, reason: "nothing to add" }
  }
});

/* ------------------------------------------------------------------ */
/* Cast cost, warps, refusals, options                                  */
/* ------------------------------------------------------------------ */

export const stormcallerDiscount = (ctx = {}) => (has(ctx.actor, "Stormcaller") && stormDiscountApplies(ctx)
  ? { ppDelta: -STORM_DISCOUNT, floor: 0, label: "Stormcaller", lines: ["Stormcaller: Storm Bolt costs 1 PP less to pay."] } : null);

export const SHADE_WARPS = Object.freeze([{ match: { name: NAMES.shadowShift }, warp: { ppCost: SHADE_HIDDEN_PP, text: "(Shade Master) you instead gain the hidden condition — the +5 PP option, 2 PP less", mods: { unlocks: [SHADE_UNLOCK] } } }]);

/** Shade Master's Dark Whispers: "while in darkness or dim light". */
export async function darkWhispersRefusal(ctx = {}) {
  const spell = ctx.spell;
  if (norm(spell?.name) !== norm(NAMES.darkWhispers)) return null;
  if (norm(spell?.flags?.[SYSTEM_ID]?.grantedBy?.sourceName) !== "shade master") return null;
  const level = await lightAt(tokenOf(ctx.actor));
  return level !== null && !inShadow(level) ? `Shade Master: you may cast Dark Whispers only in dim light or darkness (the light here is ${level}).` : null;
}

export const runicOverloadOption = {
  offer(ctx = {}) {
    if (!ctx.stored) return null;
    const feat = ownedNamed(ctx.actor, "Runic Overload");
    if (!feat || usesLeft(feat) <= 0) return null;
    return { label: "Runic Overload", hint: "Effective PP +2: 1d6 force per 2 PP to every creature it hits (basic Will), then the backlash on you (basic Fortitude). Focus." };
  },
  // Q116: "counts 2 PP higher for every number that reads PP" — the numbers a
  // cast option can reach: the spell's Save DC (10 + PP + ability: +2) and its
  // Casting DC (10 + 1.5 × PP: +3). It buys no warp. Per-PP spell riders (G12
  // `castPP`) cannot be shifted by a cast option on a stored release: the card says so.
  apply: () => ({ label: "Runic Overload", saveDC: OVERLOAD_PP, castingDC: Math.floor(1.5 * OVERLOAD_PP), lines: [`Runic Overload: the released spell counts ${OVERLOAD_PP} PP higher (Save DC +${OVERLOAD_PP}, Casting DC +${Math.floor(1.5 * OVERLOAD_PP)}); its force riders follow once it settles.`] })
};

/** The creatures a settled spell hit or made save, as actors. */
export function hitOrSaved(ctx = {}) {
  const out = [];
  for (const hit of ctx.spellHits ?? []) if (hit?.target && !out.includes(hit.target)) out.push(hit.target);
  for (const r of ctx.saveResults ?? []) if (r?.target && !out.includes(r.target)) out.push(r.target);
  return out;
}

/* ------------------------------------------------------------------ */
/* Hook handlers                                                        */
/* ------------------------------------------------------------------ */

/**
 * Hooks.on("trgPrimeSpellSettled"): Shade Master's hidden warp, Grasping
 * Shadows after a Shadow spell, Deep Weave's critical spell attack, Runic
 * Overload's riders. On the caster's client.
 */
export async function onSpellSettledB6B2(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner || !ctx.cast || ctx.refunded) return;
  const unlocks = Array.isArray(ctx.warpMods?.unlocks) ? ctx.warpMods.unlocks.map(String) : [];
  if (unlocks.includes(SHADE_UNLOCK) && has(actor, "Shade Master")) {
    await conditionToNextTurn(actor, "hidden", "Hidden");
    await card(actor, "Shade Master", [line("Shadow Shift: you are <strong>Hidden</strong> against the incoming attack (until the start of your next turn at most; remove it once the attack is resolved, as the concealed).")]);
  }
  if ((ctx.spellHits ?? []).some((x) => x?.critical)) await regainCharge(actor, "a critical spell attack");
  if (/\bshadow\b/i.test(String(ctx.spellData?.traits ?? ctx.spell?.system?.traits ?? ""))) await offerGraspingShadows(actor, tokenOf(actor), ctx.spell?.name ?? "A Shadow spell");
  const overloaded = (ctx.castOptions ?? []).map((k) => norm(k)).includes(norm(OVERLOAD_KEY));
  if (overloaded && ctx.stored) {
    const feat = ownedNamed(actor, "Runic Overload");
    if (feat) await spendUse(feat);
    const dice = perTwoPP(int(ctx.castPP ?? ctx.ppSpent) + OVERLOAD_PP);
    const dc = spellDCOf(actor);
    const lines = [line(`Runic Overload: effective PP ${int(ctx.castPP ?? ctx.ppSpent) + OVERLOAD_PP} (Q116).`)];
    const victims = hitOrSaved(ctx);
    if (dice && victims.length) lines.push(...(await h().runAreaEffect(actor, { save: "will", basic: true, dc, damage: { formula: dice, type: "force" }, scope: "targets" }, { title: "Runic Overload", targets: victims }) ?? []));
    if (dice) lines.push(...(await h().runAreaEffect(actor, { save: "fortitude", basic: true, dc, damage: { formula: dice, type: "force" }, scope: "targets" }, { title: "Runic Overload — backlash", targets: [actor] }) ?? []));
    lines.push(line("<em>Focus use spent — Refocus restores it.</em>"));
    await card(actor, "Runic Overload", lines);
  }
}

/** Hooks.on("trgPrimeStrikeResolved"): Spellstrike Riposte against a melee Strike that missed. On the attacker's client. */
export async function onStrikeResolvedB6B2(ctx = {}) {
  if (!ctx.melee || !ctx.missed || ctx.noReactions || ctx.held || !ctx.attacker || !ctx.target) return;
  if (ctx.attacker === ctx.target) return;
  await offerRiposte(ctx.attacker, ctx.target, { spellAttack: false });
}

/** Hooks.on("updateCombat", (combat, change)): Eye of the Storm's pulse at the start of its owner's turn. */
export async function onCombatTurnB6B2(combat, change = {}) {
  if (!("turn" in (change ?? {})) && !("round" in (change ?? {}))) return;
  const actor = combat?.combatant?.actor;
  if (!actor?.isOwner || !actsFor(actor)) return;
  const effect = ownEffects(actor, EYE_SOURCE)[0];
  if (!effect) return;
  const left = int(effect.flags?.[MODULE_ID]?.pulsesLeft);
  if (left <= 0) { await actor.deleteEmbeddedDocuments("ActiveEffect", [effect.id]); return; }
  const lines = await h().runAreaEffect(actor, { save: "reflex", basic: true, dc: spellDCOf(actor), damage: { formula: `${Math.max(1, levelOf(actor))}d6`, type: "electricity" }, scope: "area", radiusFeet: EYE_FEET, enemiesOnly: true }, { title: "Eye of the Storm" });
  if (left - 1 <= 0) await actor.deleteEmbeddedDocuments("ActiveEffect", [effect.id]);
  else await effect.update?.({ [`flags.${MODULE_ID}.pulsesLeft`]: left - 1 });
  await card(actor, "Eye of the Storm", [...(lines ?? []), line(left - 1 > 0 ? `<em>${left - 1} more turn${left - 1 === 1 ? "" : "s"}.</em>` : "<em>The storm aura shrinks back to 10 feet.</em>")]);
}

/** Keep the Magical Reservoir's "(minimum 1)". */
export async function syncReservoirFloor(actor, { topUp = false } = {}) {
  const res = reservoirOf(actor);
  if (!res) return;
  const bonus = reservoirFloorBonus(actor.system?.attributes?.intelligence?.total);
  if (int(res.system?.bonusUses) !== bonus) await res.update({ "system.bonusUses": bonus });
  if (topUp) { const max = h().itemUsesMax(res); if (Number.isFinite(max) && int(res.system?.usesValue) < max) await res.update({ "system.usesValue": max }); }
}

/** Hooks.on("createItem"): Shade Master's Dark Whispers is a specialist spell; the reservoir's floor. */
export async function onItemCreatedB6B2(item) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  if (item.type === "spell" && norm(item.name) === norm(NAMES.darkWhispers) && norm(item.flags?.[SYSTEM_ID]?.grantedBy?.sourceName) === "shade master" && !item.system?.specialist) await item.update({ "system.specialist": true });
  if (item.type === "ability" && norm(item.name) === norm(NAMES.reservoir)) await syncReservoirFloor(actor, { topUp: true });
}

/** Hooks.on("trgPrimeDailyPreparation"): the day's marks cleared, the reservoir's floor. */
export async function onDailyPreparationB6B2({ actor } = {}) {
  if (!actor?.isOwner) return;
  const eclipse = ownedNamed(actor, "Eclipse Step");
  if (eclipse && markFlag(eclipse, ECLIPSE_DAY_FLAG)) await eclipse.unsetFlag(MODULE_ID, ECLIPSE_DAY_FLAG);
  const mantle = ownedNamed(actor, "Shadowmantle");
  if (mantle && markFlag(mantle, MANTLE_DAY_FLAG)) await mantle.unsetFlag(MODULE_ID, MANTLE_DAY_FLAG);
  await syncReservoirFloor(actor, { topUp: true });
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const REACTIONS_B6_B2 = Object.freeze({ absoluteDenial, runebreakerAbsorb, counterChannel, saveWards, riposteSpell });
export const STEPS_B6_B2 = Object.freeze({ absorbStep, counterStep, riposteStep });

/**
 * Every registration group B2 makes; called once from registerContent. It
 * REPLACES Block 3's "Gale Step" Use (Stormcaller's 0 AP), so it must run
 * after Block 3's registrations.
 */
export function registerBlock6B2(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_B2)) api.registerFeatAutomation(name, entry, moduleId);
  for (const [name, bright] of [["Runebreaker", "Rune"], ["Shade Master", "Umbral"], ["Stormcaller", "Storm"]]) api.registerFeatEligibility?.(name, birthrightGate(bright), moduleId);
  api.registerExtraUses?.("Deep Weave", { ability: NAMES.reservoir, perCopy: 1 }, moduleId);
  api.registerExtraUses?.("Extra Reservoir", { ability: NAMES.reservoir, perCopy: 2 }, moduleId);
  api.registerDispelModifier?.("eaRunebreaker", runebreakerDispel, moduleId);
  api.registerDispelModifier?.("eaGlyphShatter", glyphShatterDispel, moduleId);
  // Absolute Denial first: a spell it stops is never offered to the others.
  api.registerCastReaction?.("eaAbsoluteDenial", absoluteDenial, moduleId);
  api.registerCastReaction?.("eaRunebreakerAbsorb", runebreakerAbsorb, moduleId);
  api.registerCastReaction?.("eaCounterChannel", counterChannel, moduleId);
  api.registerCheckReaction?.("eaSaveWards", saveWards, moduleId);
  api.registerCheckReaction?.("eaRiposteSpell", riposteSpell, moduleId);
  for (const [key, spec] of Object.entries(WEAVER_METAMAGIC)) api.registerMetamagic?.(key, spec, moduleId);
  api.registerCastCostModifier?.("eaStormcaller", stormcallerDiscount, moduleId);
  api.registerSpellWarps?.("Shade Master", SHADE_WARPS.map((e) => ({ match: { ...e.match }, warp: { ...e.warp, mods: { ...e.warp.mods, unlocks: [...e.warp.mods.unlocks] } } })), moduleId);
  api.registerCastRefusal?.("eaShadeMasterDarkWhispers", darkWhispersRefusal, moduleId);
  api.registerCastOption?.(OVERLOAD_KEY, runicOverloadOption, moduleId);
  api.registerReactionStep?.(ABSORB_STEP, absorbStep, moduleId);
  api.registerReactionStep?.(COUNTER_STEP, counterStep, moduleId);
  api.registerReactionStep?.(RIPOSTE_STEP, riposteStep, moduleId);
}
