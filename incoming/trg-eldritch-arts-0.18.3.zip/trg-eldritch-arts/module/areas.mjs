/**
 * Eldritch Arts Block 2 — Chapter 7's areas on the map: ley lines, Wild Magic
 * areas and Magic Suppression areas, each a Region carrying one of this
 * module's Region Behaviours with a level.
 *
 * The GM adds the behaviour in the Region's own configuration ("Ley Line",
 * "Wild Magic Area", "Magic Suppression Area") and sets its level; a
 * Suppression area also says whether it has backlash (Graham's M8: "Areas
 * flagged 'backlash' roll the table whenever a casting check in them
 * fails"). Antimagic is a Suppression area of level 20 or more (M8: dead
 * zones are 16–19).
 *
 * The bands and the Sense DCs are the book's (Chapter 7, the Ley Line table;
 * Levels of Suppression), read again by verify-block2 against the extract.
 */
export const MODULE_ID = "trg-eldritch-arts";

export const AREA_TYPES = Object.freeze({
  leyLine: `${MODULE_ID}.leyLine`,
  wildMagic: `${MODULE_ID}.wildMagic`,
  suppression: `${MODULE_ID}.suppression`
});

/** Chapter 7, LEY LINE LEVELS: the band, its Sense DC, and Channel Ley Line's dice (Minor 1d6 … Legendary 5d6). */
export const LEY_BANDS = Object.freeze([
  Object.freeze({ min: 1, max: 4, name: "Minor", title: "Minor Ley Thread", senseDC: 30, channelDice: 1 }),
  Object.freeze({ min: 5, max: 8, name: "Lesser", title: "Lesser Ley Flow", senseDC: 25, channelDice: 2 }),
  Object.freeze({ min: 9, max: 12, name: "Greater", title: "Greater Ley Current", senseDC: 20, channelDice: 3 }),
  Object.freeze({ min: 13, max: 16, name: "Prime", title: "Prime Ley Line", senseDC: 18, channelDice: 4 }),
  Object.freeze({ min: 17, max: Infinity, name: "Legendary", title: "Legendary Ley Nexus", senseDC: 15, channelDice: 5 })
]);

/** Chapter 7, LEVELS OF SUPPRESSION (Graham's M8: 16–19 dead zone, 20+ antimagic). */
export const SUPPRESSION_BANDS = Object.freeze([
  Object.freeze({ min: 1, max: 4, title: "Flickering zone" }),
  Object.freeze({ min: 5, max: 10, title: "Strong suppression" }),
  Object.freeze({ min: 11, max: 15, title: "Heavy suppression" }),
  Object.freeze({ min: 16, max: 19, title: "Dead zone" }),
  Object.freeze({ min: 20, max: Infinity, title: "Antimagic zone" })
]);

export const ANTIMAGIC_LEVEL = 20;

const int = (v) => Math.max(0, Math.floor(Number(v) || 0));

/** The ley line band for a level (a level below 1 reads as 1). */
export function leyBand(level) {
  const l = Math.max(1, int(level));
  return LEY_BANDS.find((b) => l >= b.min && l <= b.max);
}

/** The suppression band for a level. */
export function suppressionBand(level) {
  const l = Math.max(1, int(level));
  return SUPPRESSION_BANDS.find((b) => l >= b.min && l <= b.max);
}

export const isAntimagic = (level) => int(level) >= ANTIMAGIC_LEVEL;

/**
 * The areas a Region carries: one record per enabled behaviour of this
 * module's types.
 * @param {object} region a RegionDocument (or its shape)
 * @returns {Array<{region: object, kind: "leyLine"|"wildMagic"|"suppression", level: number, backlash: boolean, name: string}>}
 */
export function areasOfRegion(region) {
  const out = [];
  for (const behaviour of Array.from(region?.behaviors ?? [])) {
    if (!behaviour || behaviour.disabled) continue;
    const kind = Object.keys(AREA_TYPES).find((k) => AREA_TYPES[k] === behaviour.type);
    if (!kind) continue;
    out.push({ region, kind, level: Math.max(1, int(behaviour.system?.level)), backlash: behaviour.system?.backlash === true, name: String(region?.name ?? "") });
  }
  return out;
}

/**
 * Points around `centre` out to `feet`: the centre, then a ring every 5 ft
 * of 32 points. A Region "within 30 feet" is one that holds any of them —
 * at 30 ft the points are under 6 ft apart, so a line drawn at least one
 * square wide cannot slip between them.
 * @param {{x: number, y: number}} centre in pixels
 * @param {number} feet
 * @param {number} pxPerFoot
 */
export function pointsWithin(centre, feet, pxPerFoot) {
  const pts = [{ x: centre.x, y: centre.y, feet: 0 }];
  for (let r = 5; r <= Math.max(0, feet); r += 5) {
    for (let i = 0; i < 32; i += 1) {
      const a = (i / 32) * Math.PI * 2;
      pts.push({ x: centre.x + Math.cos(a) * r * pxPerFoot, y: centre.y + Math.sin(a) * r * pxPerFoot, feet: r });
    }
  }
  return pts;
}

/**
 * The nearest distance in feet (to 5 ft) at which `contains` holds, or null.
 * @param {(point: {x:number, y:number}) => boolean|Promise<boolean>} contains
 */
export async function nearestFeet(centre, feet, pxPerFoot, contains) {
  for (const p of pointsWithin(centre, feet, pxPerFoot)) {
    if (await contains({ x: p.x, y: p.y })) return p.feet;
  }
  return null;
}

/**
 * The distance in pixels from a point to a Region shape's edge (0 inside),
 * for the shapes a Region is drawn with: rectangle (rotated about its
 * centre), circle, ellipse (approximated), polygon. null for anything else,
 * which falls back to testing points.
 */
export function distanceToShape(point, shape) {
  return nearestOnShape(point, shape)?.d ?? null;
}

/** The nearest point of a shape to `point` (the point itself when inside), and the distance in pixels. */
export function nearestOnShape(point, shape) {
  const type = String(shape?.type ?? "");
  const px = Number(point.x), py = Number(point.y);
  if (type === "rectangle") {
    const w = Number(shape.width) || 0, hgt = Number(shape.height) || 0;
    const cx = Number(shape.x) + w / 2, cy = Number(shape.y) + hgt / 2;
    const a = -(Number(shape.rotation) || 0) * Math.PI / 180;
    const lx = (px - cx) * Math.cos(a) - (py - cy) * Math.sin(a);
    const ly = (px - cx) * Math.sin(a) + (py - cy) * Math.cos(a);
    const qx = Math.max(-w / 2, Math.min(w / 2, lx)), qy = Math.max(-hgt / 2, Math.min(hgt / 2, ly));
    const back = -a;
    return { d: Math.hypot(lx - qx, ly - qy), x: cx + qx * Math.cos(back) - qy * Math.sin(back), y: cy + qx * Math.sin(back) + qy * Math.cos(back) };
  }
  if (type === "circle") {
    const r = Number(shape.radius) || 0, dist = Math.hypot(px - Number(shape.x), py - Number(shape.y));
    if (dist <= r) return { d: 0, x: px, y: py };
    return { d: dist - r, x: Number(shape.x) + ((px - Number(shape.x)) / dist) * r, y: Number(shape.y) + ((py - Number(shape.y)) / dist) * r };
  }
  if (type === "ellipse") {
    const rx = Number(shape.radiusX) || 0, ry = Number(shape.radiusY) || 0;
    const a = -(Number(shape.rotation) || 0) * Math.PI / 180;
    const lx = (px - Number(shape.x)) * Math.cos(a) - (py - Number(shape.y)) * Math.sin(a);
    const ly = (px - Number(shape.x)) * Math.sin(a) + (py - Number(shape.y)) * Math.cos(a);
    const k = Math.hypot(lx / (rx || 1), ly / (ry || 1));
    return k <= 1 ? { d: 0, x: px, y: py } : { d: (k - 1) * Math.min(rx, ry), x: Number(shape.x), y: Number(shape.y) };
  }
  if (type === "polygon") {
    const pts = Array.isArray(shape.points) ? shape.points.map(Number) : [];
    if (pts.length < 6) return null;
    let inside = false;
    let best = { d: Infinity, x: px, y: py };
    for (let i = 0, j = pts.length - 2; i < pts.length; j = i, i += 2) {
      const xi = pts[i], yi = pts[i + 1], xj = pts[j], yj = pts[j + 1];
      if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi || 1e-9) + xi) inside = !inside;
      const ex = xi - xj, ey = yi - yj, len2 = ex * ex + ey * ey || 1e-9;
      const t = Math.max(0, Math.min(1, ((px - xj) * ex + (py - yj) * ey) / len2));
      const nx = xj + t * ex, ny = yj + t * ey, d = Math.hypot(px - nx, py - ny);
      if (d < best.d) best = { d, x: nx, y: ny };
    }
    return inside ? { d: 0, x: px, y: py } : best;
  }
  return null;
}

/** The nearest point of a Region's shapes (holes ignored) and its distance in feet, or null when no shape can be measured. */
export function regionNearest(region, point, pxPerFoot) {
  const found = Array.from(region?.shapes ?? []).filter((sh) => !sh?.hole).map((sh) => nearestOnShape(point, sh)).filter(Boolean);
  if (!found.length) return null;
  const best = found.reduce((a, b) => (b.d < a.d ? b : a));
  return { feet: best.d / (pxPerFoot || 1), x: best.x, y: best.y };
}

/** The compass direction from one point to another (north is up). */
export function compass(from, to) {
  const deg = (Math.atan2(Number(to.x) - Number(from.x), -(Number(to.y) - Number(from.y))) * 180 / Math.PI + 360) % 360;
  return ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"][Math.round(deg / 45) % 8];
}

/* ------------------------------------------------------------------ */
/* Foundry side                                                         */
/* ------------------------------------------------------------------ */

/** The Region Behaviour types, registered at init. */
export function registerAreaTypes() {
  const Base = globalThis.foundry?.data?.regionBehaviors?.RegionBehaviorType;
  const fields = globalThis.foundry?.data?.fields;
  if (!Base || !fields || !globalThis.CONFIG?.RegionBehavior) {
    console.warn("Eldritch Arts | Region Behaviours are not available: ley lines and Chapter 7's areas cannot be placed.");
    return false;
  }
  const level = (label, hint) => new fields.NumberField({ required: true, integer: true, min: 1, initial: 1, label, hint });
  class LeyLineBehavior extends Base {
    static defineSchema() { return { level: level("Ley line level", "Chapter 7: 1–4 Minor Ley Thread, 5–8 Lesser Ley Flow, 9–12 Greater Ley Current, 13–16 Prime Ley Line, 17+ Legendary Ley Nexus.") }; }
  }
  class WildMagicBehavior extends Base {
    static defineSchema() { return { level: level("Area level", "Wild Surge damage 1d8 × level, range 5 ft × level, duration 1 round × level.") }; }
  }
  class SuppressionBehavior extends Base {
    static defineSchema() {
      return {
        level: level("Area level", "Casting checks take a penalty equal to the level. 16–19 is a dead zone; 20 or more is an antimagic zone."),
        backlash: new fields.BooleanField({ initial: false, label: "Suppression backlash", hint: "A failed casting check in this area rolls the Suppression Backlash table." })
      };
    }
  }
  const types = [[AREA_TYPES.leyLine, LeyLineBehavior, "Ley Line", "fa-solid fa-wave-square"], [AREA_TYPES.wildMagic, WildMagicBehavior, "Wild Magic Area", "fa-solid fa-burst"], [AREA_TYPES.suppression, SuppressionBehavior, "Magic Suppression Area", "fa-solid fa-ban"]];
  for (const [type, model, label, icon] of types) {
    CONFIG.RegionBehavior.dataModels[type] = model;
    if (CONFIG.RegionBehavior.typeLabels) CONFIG.RegionBehavior.typeLabels[type] = label;
    if (CONFIG.RegionBehavior.typeIcons) CONFIG.RegionBehavior.typeIcons[type] = icon;
  }
  return true;
}

/** Every area on the viewed scene. */
export function sceneAreas(scene = globalThis.canvas?.scene) {
  return Array.from(scene?.regions ?? []).flatMap((r) => areasOfRegion(r));
}

function tokenCentre(token) {
  const doc = token?.document ?? token;
  // THE STORED POSITION FIRST (0.11.2): `_source` holds the move's end in V14's
  // updateToken while the getters lag; then the document's stored data, then
  // the document itself.
  const src = doc?._source ?? (doc?.toObject ? doc.toObject() : doc);
  const size = Number(globalThis.canvas?.dimensions?.size ?? 100);
  return { x: Number(src?.x ?? 0) + (Number(src?.width ?? 1) * size) / 2, y: Number(src?.y ?? 0) + (Number(src?.height ?? 1) * size) / 2, elevation: Number(src?.elevation ?? 0) };
}

async function contains(region, point) {
  const h = globalThis.game?.trgPrime?.modules?.helpers;
  if (h?.regionContains) return Boolean(await h.regionContains(region, point));
  return Boolean(region?.object?.testPoint?.(point) ?? region?.testPoint?.(point));
}

/** The areas whose Region holds this token's centre. */
export async function areasAt(token) {
  if (!token) return [];
  const centre = tokenCentre(token);
  const out = [];
  for (const area of sceneAreas(token.document?.parent ?? token.parent ?? globalThis.canvas?.scene)) {
    if (await contains(area.region, centre)) out.push(area);
  }
  return out;
}

/**
 * The ley lines within `feet` of this token, nearest first, each with its
 * distance (to the foot, from the Region's own shapes; by testing points every
 * 5 ft when a shape cannot be measured) and its direction.
 */
export async function leyLinesWithin(token, feet = 30) {
  if (!token) return [];
  const centre = tokenCentre(token);
  const pxPerFoot = Number(globalThis.canvas?.dimensions?.size ?? 100) / Number(globalThis.canvas?.dimensions?.distance ?? 5);
  const out = [];
  for (const area of sceneAreas(token.document?.parent ?? globalThis.canvas?.scene).filter((a) => a.kind === "leyLine")) {
    const near = regionNearest(area.region, centre, pxPerFoot);
    let d = near?.feet ?? null;
    if (d === null) d = await nearestFeet(centre, Math.min(feet, 60), pxPerFoot, (p) => contains(area.region, { ...p, elevation: centre.elevation }));
    if (d === null || d > feet) continue;
    out.push({ ...area, feet: Math.round(d), direction: d === 0 ? "here" : near ? compass(centre, near) : "" });
  }
  return out.sort((a, b) => a.feet - b.feet || b.level - a.level);
}

/** The strongest area of a kind a token stands in, or null. */
export async function strongestAreaAt(token, kind) {
  const here = (await areasAt(token)).filter((a) => a.kind === kind);
  return here.sort((a, b) => b.level - a.level)[0] ?? null;
}
