/**
 * Eldritch Arts — Block 3a (0.5.0, on TRG Prime 3.680.0): what the Archmage,
 * the Sorcerer's birthrights and the Witch do that is not data.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK3_AUDIT.md as Graham answered it on
 * 2 November 2026. The pure rules are exported first so the harness can run
 * them; the Foundry side follows.
 *
 *   - Raw Power: a warped High Magic casting's cap is 1 higher (D5's cap half).
 *   - Ley Bond: the High Magic casting DC −1 (with Ley Line Connection's gate,
 *     not stacking), and a Use that senses the ley lines in range.
 *   - Ley Tap: advantage on Power Recovery (Meditation) while a ley line is in
 *     range (sidebar 5: the Ley Bond range, 100 ft per level).
 *   - The birthrights' specialist lists (registerSpecialistAccess).
 *   - Dragon Claws, Gale Step, Umbral Affinity's Darkness, Wild Power.
 *   - The Soulbound Familiar (registerFamiliarModifier), its daily bonus and
 *     its Severed Bond; Verdant Communion; Hexes.
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds, ownEffects } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, owned, tokenOf, tokenCentre, inCombat, spendAP, feetBetween } from "./block1-automations.mjs";
import { leyLinesWithin, strongestAreaAt } from "./areas.mjs";
import { WILD_SURGE } from "./chapter7-tables.mjs";
import { rollTable } from "./block2-automations.mjs";

/* ------------------------------------------------------------------ */
/* Data shared with the content                                         */
/* ------------------------------------------------------------------ */

export const BIRTHRIGHT_NAMES = Object.freeze(["Arcanum", "Dragon", "Eternity", "Rune", "Storm", "Umbral", "Wild"]);
/** "You may select additional specialist spells from …" (each birthright's SPECIALIST SPELL). */
export const BIRTHRIGHT_ACCESS = Object.freeze({
  arcanum: { classes: ["wizard"] }, dragon: { classes: ["wizard"] }, eternity: { classes: ["cleric"] }, rune: { classes: ["cleric"] },
  storm: { classes: ["druid"] }, umbral: { traits: ["shadow"] }, wild: {}
});
export const DRAGON_TYPES = Object.freeze({ cave: "acid", cold: "cold", fire: "fire", forest: "poison", light: "electricity", sea: "sonic" });
/** Q19: the Wild birthright's spells owed — [Sorcerer level, PP]. */
export const WILD_SPELL_LADDER = Object.freeze([[1, 0], [1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12], [13, 14], [15, 16]]);
/** The printed d20 → tradition table. */
export const WILD_TRADITIONS = Object.freeze([[1, 5, "arcane"], [6, 10, "divinity"], [11, 15, "ethereal"], [16, 20, "verdant"]]);
export const LEY_BOND_FEET_PER_LEVEL = 100;
export const SOULBOUND_RANGE_FEET = 30;

/**
 * The eight Soulbound Familiar bonuses, as the Witch's daily choice: what each
 * changes on the Witch, in the keys the core's own feats use.
 */
export const SOULBOUND_BONUSES = Object.freeze([
  { key: "fortitude", label: "+2 class bonus to Fortitude saves", changes: [{ key: "system.combat.saves.fortitude.class", mode: 2, value: "2", priority: 20 }] },
  { key: "reflex", label: "+2 class bonus to Reflex saves", changes: [{ key: "system.combat.saves.reflex.class", mode: 2, value: "2", priority: 20 }] },
  { key: "will", label: "+2 class bonus to Will saves", changes: [{ key: "system.combat.saves.will.class", mode: 2, value: "2", priority: 20 }] },
  { key: "initiative", label: "+20 to initiative checks", changes: [{ key: "system.combat.initiative.other", mode: 0, value: "20", priority: 20 }] },
  { key: "db", label: "+1 circumstance bonus to DB", changes: [{ key: "system.combat.defence.circumstance", mode: 0, value: "1", priority: 20 }] },
  { key: "stealth", label: "+2 class bonus to Stealth checks", changes: [{ key: "system.skills.stealth.class", mode: 0, value: "2", priority: 20 }] },
  { key: "perception", label: "+2 class bonus to Perception checks", changes: [{ key: "system.skills.perception.class", mode: 0, value: "2", priority: 20 }] },
  { key: "hp", label: "+10 Hit Points", changes: [{ key: "system.resources.hp.other", mode: 2, value: "10", priority: 20 }] },
  {
    key: "traditions", label: "+2 circumstance bonus to Nature & Occultism checks related to the Ethereal and Verdant traditions", changes: [],
    conditionals: [{ kind: "modifier", value: 2, type: "circumstance", label: "Soulbound Familiar (Ethereal or Verdant)", scope: "Nature & Occultism checks related to the Ethereal and Verdant traditions", auto: false, when: { checkTypes: ["skill"], skills: ["nature", "occultism"] } }]
  },
  { key: "spellcraft", label: "+1 to Spellcraft checks", changes: [{ key: "system.magic.spellcraft.other", mode: 2, value: "1", priority: 20 }] }
]);

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const has = (actor, name, types = ["ability", "feat"]) => Array.from(actor?.items ?? []).some((i) => types.includes(i.type) && norm(i.name) === norm(name) && !(i.type === "ability" && i.system?.active === false));
const className = (actor) => norm(Array.from(actor?.items ?? []).find((i) => i.type === "class")?.name);
export const birthrightOf = (actor) => Array.from(actor?.items ?? []).find((i) => i.type === "ability" && i.flags?.[SYSTEM_ID]?.eaBirthright && BIRTHRIGHT_NAMES.includes(i.name) && i.system?.active !== false) ?? null;

/** Raw Power (D5): +1 to the cap of a warped High Magic casting. */
export function rawPowerRaise(ctx = {}) {
  if (!ctx.highMagic || !ctx.warped) return 0;
  return has(ctx.actor, "Raw Power") ? { value: 1, label: "Raw Power" } : 0;
}

/** Ley Bond and Ley Line Connection: one −1 to a High Magic casting's DC. */
export function leyBondHeld(actor) {
  return has(actor, "Ley Bond") || has(actor, "Ley Line Connection");
}

/**
 * Which specialist spells a character's class or birthright opens beyond the
 * core's class-tag rule:
 *   - an Archmage: "any Specialist Spell, from any class";
 *   - a birthright: its own spells (tagged with its name), and its list —
 *     the Wizard's, the Cleric's, the Druid's, or the shadow trait.
 */
export function specialistAccess(actor, spell) {
  // A SPECIALIST SPELL, AND NOT A HEX (review): the feat's list is specialist
  // spells; a hex is learned with the Witch's Hexes.
  if (!spell?.system?.specialist || spell?.flags?.[SYSTEM_ID]?.eaHex) return false;
  const tags = String(spell?.system?.specialistClass ?? "").split(",").map((t) => norm(t)).filter(Boolean);
  if (className(actor) === "archmage") return true;
  const br = birthrightOf(actor);
  if (!br) return false;
  const key = norm(br.name);
  if (tags.includes(key)) return true;
  const access = BIRTHRIGHT_ACCESS[key] ?? {};
  if (access.classes?.some((c) => tags.includes(c))) return true;
  if (access.traits?.length) {
    const traits = String(spell?.system?.traits ?? "").split(",").map((t) => norm(t));
    return access.traits.some((t) => traits.includes(t));
  }
  return false;
}

/** The Soulbound Familiar (D8): +level HP, the master's Charisma to every save. */
export function soulboundModifier(familiar, mirror) {
  const bound = familiar?.flags?.[MODULE_ID]?.soulbound ?? familiar?.getFlag?.(MODULE_ID, "soulbound");
  if (!bound || !mirror) return null;
  return { label: "Soulbound Familiar", hp: int(mirror.level), saves: int(mirror.abilities?.charisma), type: "class" };
}

/** Hexes owed: one at 1st, one more at 3rd and every three levels. */
export const hexesOwed = (level) => (int(level) >= 1 ? 1 + Math.floor(int(level) / 3) : 0);

/** The Wild birthright's spells owed at a level, as [level, PP] rows. */
export const wildSpellsOwed = (level) => WILD_SPELL_LADDER.filter(([at]) => int(level) >= at);

/** A d20 → its tradition. */
export function wildTradition(d20) {
  const n = int(d20);
  return WILD_TRADITIONS.find(([lo, hi]) => n >= lo && n <= hi)?.[2] ?? null;
}

/** A Wild Power surge: a spell of PP 2 or more, an unmodified 13. */
export const wildSurges = ({ natural, basePP, rollsCheck }) => Boolean(rollsCheck) && int(natural) === 13 && int(basePP) >= 2;

/** Power Recovery's bonus PP (the core's ladder, rest/recovery.mjs). */
export function powerRecoveryBonus(degree, casterLevel) {
  const cl = Math.max(0, int(casterLevel));
  return { heroic: cl * 2, critical: cl, success: Math.ceil(cl / 2), partial: 1 }[String(degree)] ?? 0;
}

/* ------------------------------------------------------------------ */
/* The gate, the cap, the hooks' targets                                */
/* ------------------------------------------------------------------ */

/** Replaces Block 2's Ley Line Connection gate: the same −1, from either bond. */
export async function leyBondGate(ctx = {}) {
  if (!ctx.highMagic || !ctx.rollsCheck) return null;
  if (!leyBondHeld(ctx.actor)) return null;
  const label = has(ctx.actor, "Ley Bond") ? "Ley Bond" : "Ley Line Connection";
  return { modifiers: [{ label: `${label} (High Magic casting DC −1)`, value: 1, type: "untyped", castingOnly: true }] };
}

/**
 * ONE CLIENT ACTS for an actor (0.5.0, review): the first active player who
 * owns it, else the active GM. Hooks such as updateActor and updateToken fire
 * on every client; without this the owner and the GM both acted.
 */
export function actsFor(actor) {
  const users = globalThis.game?.users;
  if (!users || typeof users.filter !== "function") return Boolean(actor?.isOwner);
  const owners = users.filter((u) => u.active && !u.isGM && actor?.testUserPermission?.(u, "OWNER")).sort((a, b) => String(a.id).localeCompare(String(b.id)));
  if (owners.length) return owners[0] === game.user;
  // THE GM'S ELECTED CONNECTION (0.12.0), not every tab of the GM's account.
  return isActingGM();
}

/* ------------------------------------------------------------------ */
/* Foundry side: the pack                                               */
/* ------------------------------------------------------------------ */

const pickRandom = (list) => list[Math.floor(Math.random() * list.length)];
const SPELL_FIELDS = ["system.tradition", "system.ppCost", "system.specialist", "system.specialistClass", "system.traits", "flags"];

/** Every spells pack the system federates (its own and every module's). */
function spellPacks() {
  return Array.from(globalThis.game?.packs ?? []).filter((p) => p.documentName === "Item" &&
    (p.collection === "trg-prime.spells" || p.metadata?.flags?.[SYSTEM_ID]?.extends === "spells"));
}
async function spellIndex() {
  const out = [];
  for (const pack of spellPacks()) {
    for (const entry of (await pack.getIndex({ fields: SPELL_FIELDS })).values()) out.push({ ...entry, pack });
  }
  return out;
}
const known = (actor) => new Set(Array.from(actor?.items ?? []).filter((i) => i.type === "spell").map((i) => norm(i.name)));
const tradIn = (entry, tradition) => String(entry.system?.tradition ?? "").split(",").map((t) => norm(t)).includes(tradition);

async function addSpell(actor, entry, source, flags = {}) {
  const doc = await entry.pack.getDocument(entry._id);
  if (!doc) return null;
  const data = doc.toObject();
  delete data._id;
  data.system = { ...data.system, prepared: true };
  data.flags = { ...data.flags, [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: source.id, sourceName: source.name, requested: doc.name } }, [MODULE_ID]: { ...(data.flags?.[MODULE_ID] ?? {}), ...flags } };
  const [created] = await actor.createEmbeddedDocuments("Item", [data]);
  return created ?? null;
}

/* ------------------------------------------------------------------ */
/* Ley Bond and Ley Tap                                                 */
/* ------------------------------------------------------------------ */

const leyBond = {
  hint: "Sense the ley lines within 100 ft per level.",
  async use(actor) {
    const token = tokenOf(actor);
    if (!token) return warn("Ley Bond: place your token on the map first.");
    const feet = LEY_BOND_FEET_PER_LEVEL * levelOf(actor);
    const lines = await leyLinesWithin(token, feet);
    await card(actor, "Ley Bond", lines.length
      ? [line(`Within ${feet} ft:`), ...lines.map((l) => line(`<strong>${esc(l.name || "Ley line")}</strong> — level ${l.level}, ${l.feet ? `${l.feet} ft ${esc(l.direction)}` : "here"}`))]
      : [line(`No ley line within ${feet} ft.`)]);
  }
};

const LEY_TAP_SOURCE = "leyTap";
/** Ley Tap's effect: advantage on Power Recovery (Meditation), while a line is in range. */
function leyTapEffect() {
  const data = effectData(LEY_TAP_SOURCE, {
    name: "Ley Tap: in range", img: "icons/svg/lightning.svg",
    description: "Ley Tap: a ley line is within your Ley Bond range, so your Power Recovery (Meditation) checks have advantage."
  });
  data.flags[SYSTEM_ID] = { ...(data.flags[SYSTEM_ID] ?? {}), conditionals: [{ kind: "advantage", label: "Ley Tap (ley line in range)", auto: true, when: { actions: ["powerRecovery"] } }] };
  return data;
}

/** Switch Ley Tap's effect on or off for one token (owner's client only). */
async function refreshLeyTap(token) {
  const actor = token?.actor;
  if (!actor?.isOwner || !has(actor, "Ley Tap") || !actsFor(actor)) return;
  const inRange = (await leyLinesWithin(token, LEY_BOND_FEET_PER_LEVEL * levelOf(actor))).length > 0;
  const current = ownEffects(actor, LEY_TAP_SOURCE);
  if (inRange && !current.length) await h().createEffectsOn(actor, [leyTapEffect()]);
  if (!inRange && current.length) await actor.deleteEmbeddedDocuments("ActiveEffect", current.map((e) => e.id));
}

/* ------------------------------------------------------------------ */
/* Dragon Claws, Gale Step                                              */
/* ------------------------------------------------------------------ */

const CLAW_FLAG = "dragonClaws";
function clawData() {
  return {
    name: "Dragon Claws", type: "weapon", img: "systems/trg-prime/assets/weapons/claw.png",
    system: {
      quantity: 1, weight: 0, price: 0, equipped: true, invested: false, hp: { value: 0, max: 0 },
      traits: "Agile, Finesse", description: "<p>Dragon Claws (the Dragon birthright): 1d6 piercing, agile and finesse. Your attack uses your BSB in place of your BAB when that is higher.</p>",
      attackBonus: 0, damage: "1d6", damageType: "piercing", baseDamage: 0, hands: 0, range: "", armourRending: 0, proficiency: "",
      fumbleDC: 5, attackMode: "melee", rangeIncrement: 0, group: "Brawling", category: "Unarmed", size: "medium",
      itemLevel: 0, quality: "standard", material: "", superiorTraits: "", loaded: true, natural: true
    },
    flags: { [SYSTEM_ID]: { attackBase: "bsb" }, [MODULE_ID]: { [CLAW_FLAG]: true } }
  };
}
export const clawsOf = (actor) => Array.from(actor?.items ?? []).filter((i) => i.type === "weapon" && i.flags?.[MODULE_ID]?.[CLAW_FLAG]);
export const dragonTypeOf = (actor) => norm(birthrightOf(actor)?.flags?.[MODULE_ID]?.dragonType);

const dragonClaws = {
  hint: "1 AP (concentrate): grow or retract your claws.",
  async use(actor) {
    const br = birthrightOf(actor);
    if (br && !dragonTypeOf(actor)) {
      const choice = await h().chooseFromList("Dragon type", "When you first select this birthright you must select a draconic type:", Object.entries(DRAGON_TYPES).map(([k, v]) => [k, `${k[0].toUpperCase()}${k.slice(1)} (${v})`]));
      if (!choice) return;
      await br.setFlag(MODULE_ID, "dragonType", choice);
    }
    const claws = clawsOf(actor);
    if (claws.length) {
      await actor.deleteEmbeddedDocuments("Item", claws.map((c) => c.id));
      return card(actor, "Dragon Claws", [line("Your claws retract.")]);
    }
    if (!(await spendAP(actor, "Dragon Claws", 1))) return;
    await actor.createEmbeddedDocuments("Item", [clawData()]);
    await card(actor, "Dragon Claws", [line(`You grow your claws: <strong>1d6 piercing</strong>, agile and finesse; your attack uses your BSB in place of your BAB.${dragonTypeOf(actor) ? ` Dragon type: ${esc(dragonTypeOf(actor))} (${DRAGON_TYPES[dragonTypeOf(actor)]}).` : ""}`), ...(inCombat(actor) ? [line("1 AP spent.")] : [])]);
  }
};

/**
 * THE LANDING PROMPT (0.10.1; 0.10.0's live test, finding 7: "a brief
 * notification, and the next canvas click picks the square"): the spell's
 * name, the range in feet, and how to cancel.
 */
const landingPrompt = (label, feet) => `${label}: click the square where you land, up to ${feet} ft away. Escape cancels.`;

/**
 * Wait for one click on the canvas; resolves to its point, or null on Escape.
 * The prompt is a PERMANENT notification (0.10.1), removed when the point is
 * picked or the pick is cancelled, so it cannot fade before the click.
 */
function pickPoint(prompt) {
  return new Promise((resolve) => {
    if (!globalThis.canvas?.stage) return resolve(null);
    const notice = ui.notifications?.info?.(prompt, { permanent: true }) ?? null;
    const stage = canvas.stage;
    // A SCENE CHANGE OR A CANVAS TORN DOWN ends the pick too (review): the
    // notice and the stage's listener do not outlive the canvas they ask about.
    let teardown = null;
    let finished = false;
    const done = (value) => {
      if (finished) return;
      finished = true;
      stage.off("pointerdown", onClick); window.removeEventListener("keydown", onKey);
      if (teardown !== null) globalThis.Hooks?.off?.("canvasTearDown", teardown);
      try { if (notice) ui.notifications?.remove?.(notice.id ?? notice); } catch (err) { console.warn("Eldritch Arts | removing the landing prompt", err); }
      resolve(value);
    };
    const onClick = (event) => done(event.data?.getLocalPosition?.(canvas.stage) ?? event.getLocalPosition?.(canvas.stage) ?? null);
    const onKey = (event) => { if (event.key === "Escape") done(null); };
    teardown = globalThis.Hooks?.once?.("canvasTearDown", () => done(null)) ?? null;
    stage.on("pointerdown", onClick);
    window.addEventListener("keydown", onKey);
  });
}

const galeStep = {
  hint: "1 AP: teleport up to 15 feet.",
  async use(actor) {
    const token = tokenOf(actor);
    if (!token) return warn("Gale Step: place your token on the map first.");
    const point = await pickPoint(landingPrompt("Gale Step", 15));
    if (!point) return;
    const grid = canvas.grid;
    const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x, y: point.y };
    const from = tokenCentre(token);
    const feet = grid.measurePath([from, { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
    if (feet > 15) return warn(`Gale Step: that is ${Math.round(feet)} feet away; you may teleport up to 15 feet.`);
    if (inCombat(actor) && int(actor.system?.resources?.ap?.value) < 1) return warn("Gale Step: 1 AP required.");
    // A REFUSED TELEPORT IS NO TELEPORT (live test, 0.5.1). The core vetoes
    // ending in an occupied space; 0.5.0 still carded "You teleport", which
    // spent the AP and, through the card, the Focus use. The move goes first,
    // and only a token that arrived pays.
    const src = token.document._source ?? token.document;
    const was = { x: src.x, y: src.y };
    await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
    const now = token.document._source ?? token.document;
    if (now.x === was.x && now.y === was.y) return warn("Gale Step: the teleport was refused (see the notice), so nothing is spent.");
    if (!(await spendAP(actor, "Gale Step", 1))) return;
    await card(actor, "Gale Step", [line(`You teleport ${Math.round(feet)} feet.`), ...(inCombat(actor) ? [line("1 AP spent.")] : [])]);
  }
};

/* ------------------------------------------------------------------ */
/* Wild Power                                                           */
/* ------------------------------------------------------------------ */

const wildPower = {
  hint: "Roll the random spells your birthright owes you.",
  async use(actor, item) {
    const level = levelOf(actor);
    // Rows are matched by their own level and PP, not counted (review): a row
    // whose pool was empty stays owed, and is not rolled as a later one.
    const have = new Set(Array.from(actor.items ?? []).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.wildSpell).map((i) => `${int(i.flags[MODULE_ID].wildSpell.level)}:${int(i.flags[MODULE_ID].wildSpell.pp)}`));
    const owed = wildSpellsOwed(level).filter(([at, pp]) => !have.has(`${at}:${pp}`));
    if (!owed.length) return card(actor, "Wild Power", [line(`All your random spells are rolled (${have.size}). The next arrives at ${WILD_SPELL_LADDER.find(([at]) => at > level)?.[0] ?? "—"}th level.`)]);
    const index = await spellIndex();
    for (const [at, pp] of owed) {
      const d20 = (await new Roll("1d20").evaluate()).total;
      const tradition = wildTradition(d20);
      const mine = known(actor);
      const pool = index.filter((e) => !e.system?.specialist && int(e.system?.ppCost) === pp && tradIn(e, tradition) && !mine.has(norm(e.name)));
      if (!pool.length) { await card(actor, "Wild Power", [line(`d20 <strong>${d20}</strong>: ${tradition}. No ${tradition} spell of PP ${pp} you do not already know — ask the GM.`)]); continue; }
      const rolled = pickRandom(pool);
      const choice = await h().chooseFromList(`Wild Power — level ${at}, PP ${pp}`,
        `d20 ${d20}: ${tradition}. Rolled: ${rolled.name}. Keep it, or the GM chooses another of the list:`,
        [[rolled._id + "|" + rolled.pack.collection, `${rolled.name} (rolled)`], ...pool.filter((e) => e !== rolled).sort((a, b) => a.name.localeCompare(b.name)).map((e) => [e._id + "|" + e.pack.collection, e.name])]);
      if (!choice) return;
      const [id, pk] = String(choice).split("|");
      const entry = pool.find((e) => e._id === id && e.pack.collection === pk) ?? rolled;
      const created = await addSpell(actor, entry, item, { wildSpell: { level: at, pp, d20, tradition } });
      if (created) await card(actor, "Wild Power", [line(`d20 <strong>${d20}</strong>: ${tradition}. <strong>${esc(created.name)}</strong> (PP ${pp}) is added to your repertoire${entry === rolled ? "" : " (chosen from the list)"}.`)]);
    }
  }
};

/** Daily preparation: Wild Power's random PP 1 specialist spell, replacing yesterday's (Q24). */
async function wildDailySpecialist(actor) {
  if (!has(actor, "Wild Power")) return;
  const old = Array.from(actor.items ?? []).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.wildDaily);
  if (old.length) await actor.deleteEmbeddedDocuments("Item", old.map((i) => i.id));
  const mine = known(actor);
  // A CLASS'S SPECIALIST SPELLS, NOT A WITCH'S HEXES: a hex is "treated as a
  // Specialist Spell for casting purposes" only, and is learned as a hex.
  const pool = (await spellIndex()).filter((e) => e.system?.specialist && !e.flags?.[SYSTEM_ID]?.eaHex && int(e.system?.ppCost) === 1 && !mine.has(norm(e.name)));
  if (!pool.length) return;
  const source = owned(actor, "Wild Power", ["ability"]);
  const created = await addSpell(actor, pickRandom(pool), source, { wildDaily: true });
  if (created) await card(actor, "Wild Power", [line(`Today's random specialist spell: <strong>${esc(created.name)}</strong> (PP 1)${old.length ? `, replacing ${esc(old.map((o) => o.name).join(", "))}` : ""}.`)]);
}

/** trgPrimeSpellSettled: Wild Power's surge on an unmodified 13. */
async function wildPowerSurge(ctx) {
  const { actor, spellData } = ctx;
  if (!actor?.isOwner || !has(actor, "Wild Power")) return;
  if (!wildSurges({ natural: ctx.natural, basePP: spellData?.ppCost, rollsCheck: ctx.rollsCheck })) return;
  const area = await strongestAreaAt(tokenOf(actor), "wildMagic");
  const level = area ? int(area.level) : int(spellData?.ppCost);
  const title = `Wild Surge — Wild Power (level ${level}${area ? `, ${area.name || "Wild Magic area"}` : ", the spell's PP"})`;
  const common = { table: WILD_SURGE, column: "e", title, level, expiry: forSeconds(6 * level), source: "wildSurge", radiusFeet: 5 * level };
  if (!area) return rollTable(actor, common);
  // WITHIN AN ALLY'S CHAOS SHIELD (0.12.0, Block 8b): its two rolls taking the
  // preferred and the area's two taking the worse cancel — one roll (Q178;
  // the core's "they simply cancel each other out").
  {
    const { chaosShieldFor } = await import("./block8b-automations.mjs");
    if ((await chaosShieldFor(actor))?.ally) return rollTable(actor, { ...common, cancels: true });
  }
  // In a Wild Magic area: "made at disadvantage (two rolls and the GM selects
  // the most undesirable result)" (L5752). Both are rolled and shown; the
  // choice is asked of whoever cast — the GM should make it.
  const a = (await new Roll("1d100").evaluate()).total;
  const b = (await new Roll("1d100").evaluate()).total;
  const pick = await h().chooseFromList(title, "Disadvantage in a Wild Magic area: two rolls, and the GM selects the more undesirable.", [[String(a), `d100 ${a}`], [String(b), `d100 ${b}`]]);
  return rollTable(actor, { ...common, forcedTotal: int(pick ?? Math.max(a, b)) });
}

/* ------------------------------------------------------------------ */
/* The Soulbound Familiar, Verdant Communion, Hexes                     */
/* ------------------------------------------------------------------ */

const SOULBOUND_BONUS = "soulboundBonus";
const SEVERED = "soulboundSevered";
// THE SOULBOUND ONE FIRST (review, 0.5.1): a Witch may also have a familiar
// the core's Familiar feat made. The bond, its bonus and its adder are the
// soulbound familiar's; only with none is the first familiar taken (the Use's
// menu, as in 0.5.0).
const isSoulboundTo = (familiar, actor) => familiar?.getFlag?.(MODULE_ID, "soulbound")?.masterId === actor?.id;
const familiarOf = async (actor) => { const list = (await h().familiarsOf?.(actor)) ?? []; return list.find((f) => isSoulboundTo(f, actor)) ?? list[0] ?? null; };
const soulboundItem = (actor) => owned(actor, "Soulbound Familiar", ["ability"]);

async function makeBond(actor, item) {
  const familiar = await h().createFamiliarFor(actor, item);
  if (!familiar) return null;
  await familiar.setFlag(MODULE_ID, "soulbound", { masterId: actor.id });
  await familiar.createEmbeddedDocuments("ActiveEffect", [effectData("soulboundDR", {
    name: "Soulbound Familiar: Base DR 2", img: "icons/svg/shield.svg",
    description: "The Soulbound Familiar \"gains a Base DR of 2\".",
    changes: [{ key: "system.combat.naturalArmourBase.natural", mode: 4, value: "2", priority: 20 }]
  })]);
  const lifted = await liftSeveredFatigue(actor, item);
  await syncSoulboundAdder(actor);
  await card(actor, "Soulbound Familiar", [line(`<strong>${esc(familiar.name)}</strong> holds a fraction of your soul: Base DR 2, +${levelOf(actor)} HP and your Charisma to its saves; a +1 spell adder.`), ...lifted]);
  return familiar;
}

/**
 * "You gain the fatigued 2 condition until you can create a new bond": a new
 * bond ends it. THE 2, NOT THE EFFECT (review, 0.5.1): Fatigued is one valued
 * condition, and fatigue gained before the sever or since sits in the same
 * effect, so the bond takes its 2 off the value (never below 0) through the
 * core's own setter and leaves the rest.
 */
async function liftSeveredFatigue(actor, item) {
  const severed = item.getFlag(MODULE_ID, SEVERED);
  if (!severed) return [];
  await item.unsetFlag(MODULE_ID, SEVERED);
  // A bond severed under 0.5.0 applied no fatigue (its tag was text), so it
  // records none and takes none off.
  const owed = Number(severed.fatigue ?? 0);
  const effect = Array.from(actor.effects ?? []).find((e) => e.flags?.[SYSTEM_ID]?.condition === "fatigued");
  const value = Number(effect?.flags?.[SYSTEM_ID]?.value ?? 0);
  if (!effect || !(owed > 0)) return [];
  const left = Math.max(0, value - owed);
  if (left > 0) await actor.toggleStatusEffect("fatigued", { value: left, force: true });
  else await actor.toggleStatusEffect("fatigued", { active: false });
  return [line(`The severed bond's <strong>fatigued 2</strong> ends${left > 0 ? `: Fatigued ${value} → ${left}` : ""}.`)];
}

/**
 * THE SPELL ADDER IS THE FAMILIAR'S (live test, 0.5.1). "It is also treated
 * as a +1-spell adder": with no familiar, a dead one or a severed bond there is
 * none. The core reads `flags.trg-prime.spellAdder` off any item, so the
 * ability carries it only while the bond holds. A 0.5.0 Witch's printed flag
 * is trued up at the first sync.
 */
async function syncSoulboundAdder(actor) {
  const item = soulboundItem(actor);
  if (!item || !actor?.isOwner) return;
  const familiar = await familiarOf(actor);
  // A dead familiar is not asked here: its death severs the bond first (on
  // its hooks, or the sync's own pass in refreshAllB3), so SEVERED says it.
  const live = isSoulboundTo(familiar, actor) && !item.getFlag(MODULE_ID, SEVERED);
  const flagged = item.flags?.[SYSTEM_ID]?.spellAdder;
  if (live && Number(flagged) !== 1) await item.setFlag(SYSTEM_ID, "spellAdder", 1);
  if (!live && flagged !== undefined && flagged !== null) await item.unsetFlag(SYSTEM_ID, "spellAdder");
}

async function chooseDailyBonus(actor) {
  const pick = await h().chooseFromList("Soulbound Familiar", "Today's bonus while your familiar is within 30 feet:", SOULBOUND_BONUSES.map((b) => [b.key, b.label]));
  if (!pick) return;
  const bonus = SOULBOUND_BONUSES.find((b) => b.key === pick);
  const old = ownEffects(actor, SOULBOUND_BONUS);
  if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old.map((e) => e.id));
  const data = effectData(SOULBOUND_BONUS, { name: `Soulbound Familiar: ${bonus.label}`, img: "icons/svg/aura.svg", description: `Your Soulbound Familiar grants ${bonus.label} while it is within 30 feet of you. Until your next daily preparation.`, changes: bonus.changes, module: { bonus: bonus.key } });
  if (bonus.conditionals) data.flags[SYSTEM_ID] = { ...(data.flags[SYSTEM_ID] ?? {}), conditionals: bonus.conditionals };
  await h().createEffectsOn(actor, [data]);
  await refreshSoulboundRange(actor);
  await card(actor, "Soulbound Familiar", [line(`Today's bonus: <strong>${esc(bonus.label)}</strong>, while your familiar is within 30 feet.`)]);
}

/** The bonus switched off while both tokens are on the map more than 30 ft apart. */
async function refreshSoulboundRange(actor) {
  if (!actor?.isOwner || !actsFor(actor)) return;
  const effects = ownEffects(actor, SOULBOUND_BONUS);
  if (!effects.length) return;
  const familiar = await familiarOf(actor);
  const a = tokenOf(actor);
  const b = familiar ? tokenOf(familiar) : null;
  let disabled = !familiar;
  if (a && b && a.scene === b.scene) { const d = feetBetween(a, b); disabled = d !== null && d > SOULBOUND_RANGE_FEET; }
  for (const e of effects) if (Boolean(e.disabled) !== disabled) await e.update({ disabled });
}

/**
 * ONE SEVERING AT A TIME (review, 0.5.1). One death reaches this client by
 * several roads (the Dying update, the Dead status, the core's slain hook),
 * each before the first's flag is written back, and each would add its own
 * fatigued 2 (valued conditions add). The master's id is held here, set
 * before the first await, as the core's `reapDead` holds its reaping.
 */
const SEVERING = new Set();
async function sever(actor, why) {
  const item = soulboundItem(actor);
  if (!item || item.getFlag(MODULE_ID, SEVERED) || SEVERING.has(actor.id)) return;
  SEVERING.add(actor.id);
  try {
    // "you gain the fatigued 2 condition until you can create a new bond":
    // the 2 is recorded, and a new bond takes it off (liftSeveredFatigue).
    //
    // A CONDITION TAG IS `{ key, value }` (live test, 0.5.1). 0.5.0 passed the
    // string "fatigued 2", which the core skips, so a severed bond fatigued no
    // one; the harness's fake took strings too. Both now take the real shape.
    await item.setFlag(MODULE_ID, SEVERED, { why, at: Number(game.time?.worldTime ?? 0), fatigue: 2 });
    await h().applyConditionTagsTo(actor, [{ key: "fatigued", value: 2 }]);
    const old = ownEffects(actor, SOULBOUND_BONUS);
    if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old.map((e) => e.id));
    await syncSoulboundAdder(actor);
    await card(actor, "Soulbound Familiar — Severed Bond", [line(`${esc(why)} Your bond is severed: you are <strong>fatigued 2</strong> until you create a new bond, which takes an hour of meditation at a daily preparation.`)]);
  } finally {
    SEVERING.delete(actor.id);
  }
}

const soulboundFamiliar = {
  hint: "Make your familiar; choose today's bonus; or record a severed bond.",
  async use(actor, item) {
    const familiar = await familiarOf(actor);
    if (familiar && (await h().isDead(familiar))) return warn(`Soulbound Familiar: ${familiar.name} is dead — delete its actor, then make a new bond at a daily preparation.`);
    if (!familiar) {
      if (item.getFlag(MODULE_ID, SEVERED)) return warn("Soulbound Familiar: a new bond may only be made during your daily preparation (it is offered then).");
      return makeBond(actor, item);
    }
    const what = await h().chooseFromList("Soulbound Familiar", `${familiar.name}:`, [["bonus", "Choose today's bonus"], ["sever", "The bond is severed (more than a mile apart for more than 24 hours)"]]);
    if (what === "bonus") return chooseDailyBonus(actor);
    if (what === "sever") return sever(actor, `${familiar.name} has been more than a mile away for more than 24 hours.`);
  }
};

async function soulboundDaily(actor) {
  const item = soulboundItem(actor);
  if (!item) return;
  let familiar = await familiarOf(actor);
  // A KILLED FAMILIAR IS NOT REBONDED (review): its actor must go before the
  // core makes another (it refuses while one exists), and that is the GM's or
  // player's to delete.
  if (familiar && (await h().isDead(familiar))) {
    await card(actor, "Soulbound Familiar", [line(`${esc(familiar.name)} is dead. Delete its actor, and a new bond is offered at your next daily preparation.`)]);
    return;
  }
  if (!familiar || item.getFlag(MODULE_ID, SEVERED)) {
    const yes = await foundry.applications.api.DialogV2.confirm({ window: { title: "Soulbound Familiar" }, content: "<p>Create a new bond? It takes an hour of meditation.</p>", rejectClose: false });
    if (!yes) return;
    if (familiar) {
      // A RENEWED BOND SAYS SO (live test, 0.5.1): 0.5.0 lifted the flag in
      // silence and went straight to the day's bonus.
      const lifted = await liftSeveredFatigue(actor, item);
      await syncSoulboundAdder(actor);
      await card(actor, "Soulbound Familiar", [line(`After an hour of meditation your bond with <strong>${esc(familiar.name)}</strong> is renewed.`), ...lifted]);
    } else familiar = await makeBond(actor, item);
    if (!familiar) return;
  }
  await chooseDailyBonus(actor);
}

/** A Soulbound familiar killed or deleted severs its master's bond. */
async function onFamiliarLost(familiar, why) {
  const bound = familiar?.getFlag?.(MODULE_ID, "soulbound");
  if (!bound) return;
  const master = game.actors?.get(bound.masterId);
  if (!master?.isOwner || !actsFor(master)) return;
  await sever(master, why);
}

const verdantCommunion = {
  hint: "1/day, 10 minutes: Power Recovery (Meditation) for its bonus PP, and +2 to Nature and Survival for an hour.",
  async use(actor, item) {
    const left = h().itemUsesRemaining(item);
    if (Number.isFinite(left) && left <= 0) return warn("Verdant Communion: once per day — daily preparation restores it.");
    const level = levelOf(actor);
    const check = await h().rollCheck({ actor, label: "Verdant Communion — Power Recovery", type: "skill", subject: "meditation", actionKey: "powerRecovery", dc: h().levelDC(level) });
    if (!check) return;
    const degree = check.outcome?.degree?.key ?? "failure";
    const pp = powerRecoveryBonus(degree, actor.system?.magic?.casterLevelValue);
    if (Number.isFinite(left)) await item.update({ "system.usesValue": left - 1 });
    const pool = actor.system?.resources?.pp;
    if (pp && pool) await actor.update({ "system.resources.pp.value": Math.min(int(pool.max), int(pool.value) + pp) });
    await h().createEffectsOn(actor, [effectData("verdantCommunion", {
      name: "Verdant Communion: +2 Nature and Survival", img: "icons/svg/oak.svg",
      description: "Verdant Communion: +2 class bonus to Nature and Survival checks for an hour.",
      changes: [{ key: "system.skills.nature.class", mode: 0, value: "2", priority: 20 }, { key: "system.skills.survival.class", mode: 0, value: "2", priority: 20 }],
      expiry: forSeconds(3600)
    })]);
    await card(actor, "Verdant Communion", [line(`Power Recovery: <strong>${esc(degree)}</strong> — ${pp} PP regained.`), line("+2 class bonus to Nature and Survival for an hour.")]);
  }
};

const hexes = {
  hint: "Choose a hex you are owed.",
  // EVERY HEX OWED, ONE AFTER ANOTHER (live test, 0.5.1), as Wild Power rolls
  // every spell owed. 0.5.0 took one a Use while its title read "1 of 2".
  // Cancelling stops; what was taken stays.
  async use(actor, item) {
    const hexesHeld = () => Array.from(actor.items ?? []).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.hexPick).length;
    const owed = hexesOwed(levelOf(actor));
    if (hexesHeld() >= owed) return card(actor, "Hexes", [line(`You know all ${owed} of your hexes. The next arrives at ${3 * Math.floor(levelOf(actor) / 3) + 3}th level.`)]);
    const index = await spellIndex();
    while (hexesHeld() < owed) {
      const mine = known(actor);
      const pool = index.filter((e) => e.flags?.[SYSTEM_ID]?.eaHex && !mine.has(norm(e.name)) && int(e.system?.ppCost) <= levelOf(actor));
      if (!pool.length) return warn("Hexes: no hex you can take is left.");
      const id = await h().chooseFromList(`Hexes — ${hexesHeld() + 1} of ${owed}`, "Choose a hex:", pool.sort((a, b) => a.name.localeCompare(b.name)).map((e) => [e._id, `${e.name} (PP ${int(e.system?.ppCost)})`]));
      const entry = id ? pool.find((e) => e._id === id) : null;
      if (!entry) return;
      const created = await addSpell(actor, entry, item, { hexPick: true });
      if (!created) return;
      await card(actor, "Hexes", [line(`<strong>${esc(created.name)}</strong> is added: a specialist spell, cast as High Magic.`)]);
    }
  }
};

/** Umbral Affinity's Darkness "which you may cast as a Specialist Spell". */
async function onItemCreated(item) {
  const actor = item?.parent;
  if (item?.type !== "spell" || !actor?.isOwner) return;
  const by = norm(item.flags?.[SYSTEM_ID]?.grantedBy?.sourceName);
  if (by === "umbral affinity" && norm(item.name) === "darkness" && !item.system?.specialist) await item.update({ "system.specialist": true });
}

/* ------------------------------------------------------------------ */
/* Registration and hooks                                               */
/* ------------------------------------------------------------------ */

export const AUTOMATIONS = Object.freeze({
  "Ley Bond": leyBond,
  "Dragon Claws": dragonClaws,
  "Gale Step": galeStep,
  "Wild Power": wildPower,
  "Soulbound Familiar": soulboundFamiliar,
  "Verdant Communion": verdantCommunion,
  Hexes: hexes
});

export async function onSpellSettledB3(ctx = {}) {
  await wildPowerSurge(ctx);
}

export async function onDailyPreparationB3({ actor } = {}) {
  if (!actor?.isOwner) return;
  await wildDailySpecialist(actor);
  await soulboundDaily(actor);
}

/**
 * A SOULBOUND FAMILIAR'S DEATH, HOWEVER IT COMES (live test, 0.5.1). The
 * core's death is Dying past the Death State (or an instant death), and a
 * creature already below 0 HP dies by its Dying rising, with no change to its
 * HP. 0.5.0 looked only when HP changed, so a familiar killed while dying
 * left the bond whole. Now any update to the familiar, any change to its
 * effects (Dying is one) and the core's "slain" hook all ask the core's
 * `isDead`. A bond already severed is not severed twice.
 */
export async function onFamiliarMaybeDiedB3(actor) {
  if (!actor?.getFlag?.(MODULE_ID, "soulbound")) return;
  if (await h().isDead(actor)) await onFamiliarLost(actor, `${actor.name} has been killed.`);
}
export async function onActorUpdatedB3(actor) {
  await onFamiliarMaybeDiedB3(actor);
}
export async function onActorDeletedB3(actor) {
  await onFamiliarLost(actor, `${actor.name} is gone.`);
}

export async function onTokenMovedB3(tokenDoc) {
  const token = tokenDoc?.object;
  if (!token?.actor) return;
  await refreshLeyTap(token);
  await refreshSoulboundRange(token.actor);
  const bound = token.actor.getFlag?.(MODULE_ID, "soulbound");
  if (bound) await refreshSoulboundRange(game.actors?.get(bound.masterId));
}
export async function refreshAllB3() {
  for (const token of canvas?.tokens?.placeables ?? []) {
    await refreshLeyTap(token);
    await refreshSoulboundRange(token.actor);
  }
  // A familiar that died unseen (0.5.0 missed a death by Dying) severs now;
  // then every Witch's spell adder is trued up to her bond (0.5.1).
  for (const actor of game.actors ?? []) await onFamiliarMaybeDiedB3(actor);
  for (const actor of game.actors ?? []) if (soulboundItem(actor) && actsFor(actor)) await syncSoulboundAdder(actor);
}
export { onItemCreated as onItemCreatedB3 };
// For Block 4 (0.7.0): Dimensional Step and Dimensional Assault click where they land, as Gale Step does.
export { pickPoint, landingPrompt, spellIndex, hexes as witchHexes };
