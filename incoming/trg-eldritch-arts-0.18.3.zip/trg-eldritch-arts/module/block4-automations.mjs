/**
 * Eldritch Arts — Block 4 (0.7.0, on TRG Prime 3.682.0): what the Spellblade
 * and the Warlock do that is not data.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK4_AUDIT.md as Graham answered it on
 * 3 November 2026. The pure rules are exported first so the harness can run
 * them; the Foundry side follows.
 *
 *   - Infuse Weapon (its daily choice and its runes) and the Book of
 *     Infusions' "Learn a rune" (Q44–Q46, M14).
 *   - The paths: Arcane Echo, Sacred Channel, Dimensional Step, Natural
 *     Resilience (Q36, Q43, Q50, Q51).
 *   - The five Spellblade spells: the Strike after the casting (Q47), the
 *     Strike as the casting (Thunderous Strike, Q48), Shooting Star's trail
 *     (Q49).
 *   - The Warlock: its innate Focus spells, hex and cantrips picked on its
 *     schedule (Q37, Q38), Xithra's damage type and the bonded souls' daily
 *     powers (Q41, Q42), and their "+1 level" (TRG Prime's innate level bonus).
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, tokenOf, tokenCentre } from "./block1-automations.mjs";
import { pickPoint, landingPrompt, spellIndex, witchHexes, actsFor } from "./block3-automations.mjs";

/* ------------------------------------------------------------------ */
/* Data shared with the content                                         */
/* ------------------------------------------------------------------ */

export const PATH_NAMES = Object.freeze(["Path of the Arcane Duellist", "Path of the Divine Arm", "Path of the Ethereal Strider", "Path of the Verdant Warden"]);
export const SOUL_NAMES = Object.freeze(["The Celestial Sentinel", "The Crystal Archon", "The Emberlord", "The Infernal Tempter", "The Pale Reaper", "The Verdant Spirit Walker", "The Void Seer", "The Whispered Sage"]);
/** Sidebar 16, as printed (the content reads the same sidebar). */
export const EXISTING_CLASS_FEATS = Object.freeze({
  Archmage: Object.freeze(["Familiar", "Versatile Familiar"]),
  Spellblade: Object.freeze(["Assess Target", "Combat Awareness", "Disrupting Stance"]),
  Warlock: Object.freeze(["Familiar", "Injury Relief", "Versatile Familiar"]),
  Witch: Object.freeze(["Familiar", "Injury Relief", "Versatile Familiar"])
});
/** The core's tradition skills, for "Learn a rune" (as Learn a Spell). */
export const TRADITION_SKILL = Object.freeze({ arcane: "arcana", divinity: "religion", ethereal: "occultism", verdant: "nature" });
/** Spinning Weapon's types, and the two its +2 PP option adds. */
export const SPINNING_TYPES = Object.freeze(["acid", "bludgeoning", "cold", "electricity", "fire"]);
export const SPINNING_EXTRA = Object.freeze(["force", "sonic"]);
/** Thunderous Strike's cone: 15 ft, the core's 90° (spell-template CONE_ANGLE). */
export const THUNDER_CONE = Object.freeze({ feet: 15, angle: 90 });
export const SHOOTING_STAR_REACH = 30;
export const INFUSION_FLAG = "infusedRunes";
export const BOOK_RUNES_FLAG = "infusionRunes";
export const TRAIL_SOURCE = "shootingStarTrail";

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const live = (i) => !(i.type === "ability" && i.system?.active === false);
const className = (actor) => norm(items(actor).find((i) => i.type === "class")?.name);
const traitList = (text) => String(text ?? "").split(/[,;]/).map((t) => norm(t)).filter(Boolean);

/** Infuse Weapon (M14): from 2nd level, runes up to the Spellblade level in total. */
export const infusionBudget = (level) => (int(level) >= 2 ? int(level) : 0);
/** The total level of a selection `[{level}]`. */
export const runeLevels = (selection = []) => (Array.isArray(selection) ? selection : []).reduce((sum, r) => sum + Math.max(0, int(r?.level)), 0);
/** Sacred Channel: 1d8, +1d8 at 5th and every 5. */
export const sacredChannelDice = (level) => `${1 + Math.floor(Math.max(0, int(level)) / 5)}d8`;
/** Dimensional Step (Q51): 10 ft per 2 levels, at least 10. */
export const dimensionalStepFeet = (level) => Math.max(10, 10 * Math.floor(Math.max(0, int(level)) / 2));
/** Dimensional Assault: "half your land speed", in whole 5-foot squares. */
export const halfSpeedFeet = (speed) => Math.max(0, Math.floor(Math.max(0, Number(speed) || 0) / 2 / 5) * 5);
/** Shielding Strike: +2 status DB, +1 a warp, max +5. */
export const shieldingBonus = (warpMods = {}) => Math.min(5, 2 + Math.max(0, int(warpMods?.bonusValue)));
/** Spinning Weapon's offer: the five, and force and sonic with the warp. */
export const spinningTypes = (warpMods = {}) => [...SPINNING_TYPES, ...((warpMods?.unlocks ?? []).includes("eaForceSonic") ? SPINNING_EXTRA : [])];
/** Spinning Weapon's dice: 1d6, +1d6 a warp, max 4d6. */
export function spinningDice(warpMods = {}) {
  const extra = /^(\d+)d6$/.exec(String(warpMods?.damageDice ?? "").trim());
  return `${Math.min(4, 1 + (extra ? int(extra[1]) : 0))}d6`;
}

/** The Warlock's spells owed: one at 1st, one more at 3rd and every 3. */
export const warlockSpellsOwed = (level) => (int(level) >= 1 ? 1 + Math.floor(int(level) / 3) : 0);
export const WARLOCK_CANTRIPS = 2;
export const WARLOCK_HEXES = 1;

/** The live bonded soul's declaration on an actor, or null. */
export function soulOf(actor) {
  const item = items(actor).find((i) => i.type === "ability" && live(i) && i.flags?.[SYSTEM_ID]?.eaBondedSoul);
  return item ? { item, ...item.flags[SYSTEM_ID].eaBondedSoul } : null;
}
/** The live Spellblade path's name on an actor, or "". */
export function pathOf(actor) {
  const item = items(actor).find((i) => i.type === "ability" && live(i) && i.flags?.[SYSTEM_ID]?.eaSpellbladePath && PATH_NAMES.includes(i.name));
  return item?.name ?? "";
}

/**
 * The bonded soul's "+1 level" (TRG Prime 3.682.0's registerInnateLevelBonus):
 * a spell carrying one of its traits or schools. The context's traits hold
 * both, lower-cased.
 */
export function soulLevelBonus(soul, ctx = {}) {
  if (!soul?.levelTraits?.length) return 0;
  const traits = Array.isArray(ctx.traits) ? ctx.traits.map(norm) : traitList(ctx.traits);
  return soul.levelTraits.some((t) => traits.includes(norm(t))) ? 1 : 0;
}

/** A cantrip, as the core's choosers read it: PP 0 and the Cantrip trait. */
export const isCantrip = (system) => int(system?.ppCost) === 0 && traitList(system?.traits).includes("cantrip");

/**
 * May a Warlock take this pack spell (index entry)? `slot` is "spell",
 * "cantrip" or "hex". Spells: the soul's traditions, no specialist spell, base
 * PP no higher than level + 1 (sidebar 8, Q38; one more where the soul's +1
 * applies). Cantrips: any tradition. Hexes: any hex the module knows, PP no
 * higher than level + 1.
 */
export function warlockMayTake(entry, { slot, soul, level }) {
  const sys = entry?.system ?? {};
  const pp = int(sys.ppCost);
  const cap = int(level) + 1;
  if (slot === "hex") return Boolean(entry?.flags?.[SYSTEM_ID]?.eaHex) && pp <= cap;
  if (sys.specialist || entry?.flags?.[SYSTEM_ID]?.eaHex) return false;
  if (slot === "cantrip") return isCantrip(sys);
  if (slot !== "spell" || isCantrip(sys) || pp < 1) return false;
  const trads = traitList(sys.tradition);
  if (!soul?.traditions?.some((t) => trads.includes(t))) return false;
  return pp <= cap + soulLevelBonus(soul, { traits: traitList(sys.traits) });
}

/**
 * The innate copy a Warlock's pick becomes (Q37): innate, Focus (one use until
 * Refocus), cast with Charisma, base PP up to level + 1 (`innatePPAllowance`).
 * Pure: the pack spell's data in, the copy's data out.
 */
export function warlockCopy(data, { source, slot }) {
  const out = JSON.parse(JSON.stringify(data ?? {}));
  delete out._id;
  out.type = "spell";
  const traits = String(out.system?.traits ?? "").trim();
  out.system = {
    ...(out.system ?? {}),
    innate: true,
    prepared: true,
    traits: traitList(traits).includes("focus") ? traits : (traits ? `${traits}, Focus` : "Focus"),
    usesPerDay: "",
    usesValue: 1
  };
  out.flags = {
    ...(out.flags ?? {}),
    [SYSTEM_ID]: { ...(out.flags?.[SYSTEM_ID] ?? {}), castingAbilityOverride: "charisma", innatePPAllowance: 1, grantedBy: { sourceId: source?.id ?? "", sourceName: source?.name ?? "", requested: data?.name ?? "" } },
    [MODULE_ID]: { ...(out.flags?.[MODULE_ID] ?? {}), warlockPick: slot }
  };
  return out;
}

/** Xithra's damage type offer: mental, and the soul's. */
export const xithraTypes = (soul) => [...new Set(["mental", ...(soul?.damageType ? [norm(soul.damageType)] : [])])];
/** Xithra's effect rows with the soul's offer written in (replacing any earlier). */
export function xithraEffects(effects = [], soul = null) {
  const rest = (Array.isArray(effects) ? effects : []).filter((e) => norm(e?.kind) !== "damagetypechoice");
  return soul ? [...rest, { kind: "damageTypeChoice", damageTypes: xithraTypes(soul) }] : rest;
}

/** Is the rider due on this settled Xithra? `{ due, target }`. */
export function riderDue(rider, ctx = {}) {
  if (!rider || !ctx.cast) return { due: false, target: null };
  const hit = (ctx.spellHits ?? [])[0]?.target ?? null;
  if (rider.onHit) return { due: Boolean(hit), target: hit };
  return { due: true, target: null };
}

/**
 * Thunderous Strike's cone (Q48): the tokens within 15 ft of the target whose
 * bearing from it lies within 45° of the caster→target line, the target and
 * the caster left out. `points` are centres `{id, x, y}`; `feetOf(a, b)` measures.
 */
export function coneBehind(caster, target, points = [], feetOf, { feet = THUNDER_CONE.feet, angle = THUNDER_CONE.angle } = {}) {
  if (!caster || !target) return [];
  const axis = Math.atan2(target.y - caster.y, target.x - caster.x);
  const half = (angle / 2) * Math.PI / 180;
  return points.filter((p) => {
    if (!p || p.id === target.id || p.id === caster.id) return false;
    const d = Number(feetOf(target, p));
    if (!Number.isFinite(d) || d > feet) return false;
    const bearing = Math.atan2(p.y - target.y, p.x - target.x);
    let diff = Math.abs(bearing - axis) % (2 * Math.PI);
    if (diff > Math.PI) diff = 2 * Math.PI - diff;
    return diff <= half + 1e-9;
  }).map((p) => p.id);
}

/**
 * The Arcane Echo effect's two rows (Q50). NOT one-shot (review): the core
 * spends a one-shot row by deleting the effect that carries it, so the
 * attack's roll would take the damage row with it. The effect is removed
 * once that melee Strike has resolved, hit or miss (onStrikeResolvedB4).
 */
export function arcaneEchoConditionals() {
  return [
    { kind: "modifier", value: 1, type: "circumstance", label: "Arcane Echo", scope: "your next melee attack, before the start of your next turn", auto: true, when: { checkTypes: ["attack"], attackModes: ["melee"] } },
    { kind: "modifier", value: 1, type: "circumstance", label: "Arcane Echo", scope: "that attack's damage", auto: true, when: { checkTypes: ["damage"], attackModes: ["melee"] } }
  ];
}

/** Specialist access the Warlock adds: hexes through the core Specialist Spell feat (M28 withdrawn). */
export function warlockHexAccess(actor, spell) {
  return className(actor) === "warlock" && Boolean(spell?.flags?.[SYSTEM_ID]?.eaHex);
}

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

/**
 * IN THIS COMBAT, NOT IN ANY (live test, 0.7.0): AP are spent, and asked
 * for, only when the actor is a combatant of the running combat. Block 1's
 * `inCombat` asks whether any combat is running, so a creature outside the
 * GM's fight paid AP it does not have.
 */
const fighting = (actor) => Boolean(combatFor(actor));
async function spendAPIn(actor, label, ap = 1) {
  if (!fighting(actor) || ap <= 0) return true;
  const have = int(actor.system?.resources?.ap?.value);
  if (have < ap) return warn(`${label}: ${ap} AP required.`);
  await actor.update({ "system.resources.ap.value": have - ap });
  return true;
}

const spellbladeSpell = (spell) => String(spell?.flags?.[SYSTEM_ID]?.eaSpellbladeSpell ?? "");
const hasAbility = (actor, name) => items(actor).find((i) => i.type === "ability" && live(i) && norm(i.name) === norm(name)) ?? null;

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}

async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}

/** The weapons in hand (equipped), melee only if asked. */
function wieldedWeapons(actor, { meleeOnly = false } = {}) {
  return items(actor).filter((i) => i.type === "weapon" && i.system?.equipped && (!meleeOnly || norm(i.system?.attackMode || "melee") !== "missile"));
}
async function chooseWeapon(actor, label, opts = {}) {
  const list = wieldedWeapons(actor, opts);
  if (!list.length) { warn(`${label}: you are wielding no ${opts.meleeOnly ? "melee " : ""}weapon.`); return null; }
  if (list.length === 1) return list[0];
  const id = await h().chooseFromList(label, "Strike with which weapon?", list.map((w) => [w.id, w.name]));
  return id ? list.find((w) => w.id === id) ?? null : null;
}

/**
 * One Strike, as part of a spell: the core's own Strike at no AP (Q47),
 * resolving `{ check, hit, target }`. The hit is read off the core's
 * trgPrimeStrikeResolved, which fires inside the Strike before it returns.
 */
async function strikeAsPart(actor, weapon, options = {}) {
  let seen = null;
  const listen = (ctx) => { if (ctx?.attacker === actor && (ctx?.weapon === weapon || (ctx?.weapon?.id && ctx.weapon.id === weapon.id))) seen = ctx; };
  const id = Hooks.on("trgPrimeStrikeResolved", listen);
  let check = null;
  try {
    check = await h().rollWeaponAttack(actor, weapon, { apPaid: true, ...options });
  } finally {
    Hooks.off("trgPrimeStrikeResolved", id);
  }
  return { check, hit: Boolean(seen?.hits), target: seen?.target ?? null, resolved: Boolean(seen?.resolved) };
}

/** A strike edge on the caster for one Strike (TRG Prime's `strikeEdge`), removed after. */
async function withEdge(actor, edge, run) {
  const [made] = await actor.createEmbeddedDocuments("ActiveEffect", [effectData("strikeEdge", {
    name: `${edge.label}: the Strike's edge`, img: "icons/svg/sun.svg",
    system: { strikeEdge: { ...edge } }
  })]);
  try {
    return await run();
  } finally {
    if (made) await made.delete().catch(() => {});
  }
}

/** Set this user's targets for the length of `run`, then put them back (as the core's castAsReaction). */
async function withTargets(ids, run) {
  const tokens = canvas?.tokens?.placeables ?? [];
  const previous = Array.from(game.user?.targets ?? []).map((t) => t.id);
  const set = (want) => {
    const s = new Set(want);
    for (const t of tokens) if (t.isTargeted !== s.has(t.id)) t.setTarget(s.has(t.id), { user: game.user, releaseOthers: false, groupSelection: true });
  };
  try {
    set(ids);
    return await run();
  } finally {
    set(previous);
  }
}

/** Teleport the actor's token to a clicked square within `feet` (as Gale Step). True if it arrived. */
async function teleportWithin(actor, feet, label) {
  const token = tokenOf(actor);
  if (!token) return warn(`${label}: place your token on the map first.`);
  const point = await pickPoint(landingPrompt(label, feet));
  if (!point) return false;
  const grid = canvas.grid;
  const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x, y: point.y };
  const dist = grid.measurePath([tokenCentre(token), { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
  if (dist > feet) return warn(`${label}: that is ${Math.round(dist)} feet away; you may teleport up to ${feet} feet.`);
  const src = token.document._source ?? token.document;
  const was = { x: src.x, y: src.y };
  // YOUR OWN SQUARE (re-review): no teleport, and said as such, not as a refusal.
  if (snapped.x === was.x && snapped.y === was.y) return warn(`${label}: you stay where you are; no teleport is made.`);
  await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
  const now = token.document._source ?? token.document;
  if (now.x === was.x && now.y === was.y) return warn(`${label}: the teleport was refused (see the notice).`);
  return Math.round(dist);
}

/** A pack spell's data by name (the federated spells packs). */
async function packSpellData(name) {
  const entry = (await spellIndex()).find((e) => norm(e.name) === norm(name));
  if (!entry) return null;
  const doc = await entry.pack.getDocument(entry._id);
  return doc ? doc.toObject() : null;
}

/* ------------------------------------------------------------------ */
/* Infuse Weapon and the Book of Infusions                              */
/* ------------------------------------------------------------------ */

const bookRunes = (actor) => (Array.isArray(actor?.getFlag?.(MODULE_ID, BOOK_RUNES_FLAG)) ? actor.getFlag(MODULE_ID, BOOK_RUNES_FLAG) : []);

async function infuse(actor) {
  const weapon = await chooseWeapon(actor, "Infuse Weapon", { meleeOnly: true });
  if (!weapon) return false;
  const level = levelOf(actor);
  const budget = infusionBudget(level);
  const picked = [];
  const known = bookRunes(actor);
  while (budget && known.length) {
    const left = budget - runeLevels(picked);
    const pool = known.filter((r) => !picked.some((p) => p.key === r.key) && int(r.level) <= left);
    if (!pool.length) break;
    const id = await h().chooseFromList(`Infuse Weapon — ${left} of ${budget} rune levels left`, "Infuse a rune (cancel when done):", pool.map((r, i) => [String(i), `${r.name} (level ${int(r.level)})`]));
    if (id === null || id === undefined || id === "") break;
    picked.push(pool[int(id)]);
  }
  const runes = picked.length ? await h().runesToField("weapon", picked.map((r) => ({ key: r.key, tier: r.tier, parameter: r.parameter ?? null }))) : "";
  await actor.setFlag(SYSTEM_ID, INFUSION_FLAG, { weaponId: weapon.id, runes, magical: true });
  await card(actor, "Infuse Weapon", [
    line(`<strong>${esc(weapon.name)}</strong> is infused: magical for overcoming resistances while you wield it, until your next daily preparation.`),
    ...(picked.length ? [line(`Infused runes (${runeLevels(picked)} of ${budget} levels): ${esc(runes)}.`)] : budget ? [line("No rune infused.")] : [])
  ]);
  return true;
}

async function learnRune(actor) {
  const path = pathOf(actor);
  const tradition = norm(actor.system?.progression?.tradition ?? "");
  const skill = TRADITION_SKILL[tradition];
  if (!path || !skill) return warn("Learn a rune: choose your Spellblade Path first (its tradition's skill makes the check).");
  const known = bookRunes(actor);
  const options = [];
  for (const rune of await h().runesFor("weapon")) {
    if (rune.spell || rune.parameter) continue;
    for (const tier of rune.tiers ?? []) {
      if (known.some((k) => k.key === rune.key && int(k.tier) >= int(tier.numeral))) continue;
      options.push({ key: rune.key, tier: int(tier.numeral), name: `${rune.name}${rune.tiers.length > 1 ? ` ${tier.tier}` : ""}`, level: int(tier.level) });
    }
  }
  if (!options.length) return warn("Learn a rune: there is no weapon rune left to learn.");
  const id = await h().chooseFromList("Learn a rune", "Which rune (its level is the spell's PP for Learn a Spell's time, price and DC)?", options.map((o, i) => [String(i), `${o.name} (level ${o.level})`]));
  const rune = id !== null && id !== undefined && id !== "" ? options[int(id)] : null;
  if (!rune) return false;
  const terms = await h().learnSpellTerms(rune.level);
  const ok = await confirm("Learn a rune", `${esc(rune.name)}: ${terms.hours} hour(s), materials ${terms.gp} gp, and a ${skill} check against DC ${terms.dc}. Go ahead?`);
  if (!ok) return false;
  // "Have materials with the Price indicated": in hand before the check;
  // what the check's degree consumes is Learn a Spell's (review).
  const purse = Number(await h().goldOf(actor)) || 0;
  if (purse < terms.gp) return warn(`Learn a rune: the materials cost ${terms.gp} gp (you have ${purse}).`);
  const check = await h().rollCheck({ actor, type: "skill", subject: skill, label: `Learn a rune — ${rune.name}`, dc: terms.dc });
  const degree = norm(check?.outcome?.degree?.key);
  const outcome = await h().learnSpellOutcome(degree);
  const cost = outcome?.materialsConsumed === "full" ? terms.gp : outcome?.materialsConsumed === "half" ? Math.floor(terms.gp / 2) : 0;
  if (cost) await h().deductGold(actor, cost);
  const learned = Boolean(outcome?.learned);
  if (learned) await actor.setFlag(MODULE_ID, BOOK_RUNES_FLAG, [...known.filter((k) => k.key !== rune.key), rune]);
  await card(actor, "Learn a rune", [line(`${esc(rune.name)}: <strong>${esc(degree || "—")}</strong>. ${learned ? "It is written into your Book of Infusions." : "Not learned."} ${terms.hours} hour(s) spent; materials ${cost ? `${cost} gp consumed` : "kept"}.`)]);
  return learned;
}

const infuseWeapon = {
  hint: "Infuse a melee weapon for the day, or learn a rune into your Book of Infusions.",
  async use(actor) {
    const choice = await h().chooseFromList("Infuse Weapon", "What do you do?", [["infuse", "Infuse a weapon (daily preparation)"], ["learn", "Learn a rune"]]);
    if (choice === "infuse") return infuse(actor);
    if (choice === "learn") return learnRune(actor);
    return false;
  }
};

/* ------------------------------------------------------------------ */
/* The paths                                                            */
/* ------------------------------------------------------------------ */

const dimensionalStep = {
  hint: "1 AP: teleport up to 10 ft per 2 levels (at least 10).",
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Dimensional Step: its use is spent — Refocus or daily preparation restores it.");
    if (fighting(actor) && int(actor.system?.resources?.ap?.value) < 1) return warn("Dimensional Step: 1 AP required.");
    const feet = dimensionalStepFeet(levelOf(actor));
    const moved = await teleportWithin(actor, feet, "Dimensional Step");
    if (!moved) return false;
    if (!(await spendAPIn(actor, "Dimensional Step", 1))) return false;
    await spendUse(item);
    await card(actor, "Dimensional Step", [line(`You teleport ${moved} feet.`), ...(fighting(actor) ? [line("1 AP spent.")] : [])]);
    return true;
  }
};

/** Arcane Echo (Q50): after a spell cast successfully, the next melee attack. */
async function arcaneEcho(ctx) {
  const actor = ctx.actor;
  const echo = hasAbility(actor, "Arcane Echo");
  // "After casting a spell": not an item's spell (review).
  if (!echo || !ctx.cast || ctx.refunded || ctx.itemCast) return;
  if (usesLeft(echo) <= 0) return;
  await spendUse(echo);
  const expiry = expiryFor("startOfNextTurn", actor);
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("arcaneEcho", {
    name: "Arcane Echo", img: "icons/svg/sword.svg", expiry,
    description: "+1 circumstance to your next melee attack and its damage, before the start of your next turn.",
    system: { conditionals: arcaneEchoConditionals() }
  })]);
  await card(actor, "Arcane Echo", [line("Your next melee attack before the start of your next turn has +1 circumstance to the attack and +1 to its damage. Arcane Echo's use is spent.")]);
}

/** Sacred Channel: on a weapon hit, 1 PP to heal 1d8 (+1d8 at 5th and every 5). */
async function sacredChannel(ctx) {
  const actor = ctx.attacker;
  if (!ctx.hits || ctx.held || !actor?.isOwner) return;
  const channel = hasAbility(actor, "Sacred Channel");
  if (!channel || usesLeft(channel) <= 0) return;
  if (int(actor.system?.resources?.pp?.value) < 1) return;
  const dice = sacredChannelDice(levelOf(actor));
  if (!(await confirm("Sacred Channel", `You hit. Spend 1 PP (and Sacred Channel's use) to heal ${dice} HP?`))) return;
  await actor.update({ "system.resources.pp.value": int(actor.system.resources.pp.value) - 1 });
  await spendUse(channel);
  const roll = await new Roll(dice).evaluate();
  const healed = await h().healActor(actor, roll.total, { magical: true });
  await card(actor, "Sacred Channel", [line(`1 PP spent: <strong>${roll.total}</strong> (${dice}) — ${int(healed)} HP healed.`)]);
}

/* ------------------------------------------------------------------ */
/* The five spells                                                      */
/* ------------------------------------------------------------------ */

/** Allies of the caster on the board: its disposition, not itself. */
function alliesOf(actor) {
  const mine = tokenOf(actor);
  if (!mine) return [];
  const side = Number(mine.document?.disposition ?? 0);
  return (canvas?.tokens?.placeables ?? []).filter((t) => t.actor && t.actor !== actor && Number(t.document?.disposition ?? 0) === side).map((t) => t.actor);
}

/** Shooting Star (Q47, Q49). */
async function shootingStar(ctx) {
  const actor = ctx.actor;
  const weapon = await chooseWeapon(actor, "Shooting Star");
  if (!weapon) return;
  const melee = norm(weapon.system?.attackMode || "melee") !== "missile";
  const edge = { ignoreConcealment: true, reduceCover: 1, label: "Shooting Star" };
  const out = await withEdge(actor, edge, () => strikeAsPart(actor, weapon, melee ? { reachOverrideFeet: SHOOTING_STAR_REACH } : {}));
  if (!out.hit || !out.target) return;
  // THE TRAIL (Q49): every ally's attacks against that creature, until the start of the caster's next turn.
  const expiry = combatFor(actor) ? expiryFor("startOfNextTurn", actor) : forSeconds(6);
  const allies = alliesOf(actor);
  for (const ally of allies) {
    await h().createEffectsOn(ally, [effectData(TRAIL_SOURCE, {
      name: `Shooting Star's trail (${out.target.name})`, img: "icons/svg/sun.svg",
      // A WORLD-CLOCK BACKSTOP (review): two rounds, so a combat that ends
      // before the caster's next turn does not leave the trail for ever.
      system: { strikeEdge: { ...edge, targetUuid: out.target.uuid, label: "Shooting Star's trail" }, ...(expiry.system ?? {}), spellEffect: true, spellEffectEnd: Math.trunc(Number(game.time?.worldTime ?? 0)) + 12 },
      module: { trailOf: actor.id }
    })]);
  }
  await card(actor, "Shooting Star", [line(`The meteor trail lingers on <strong>${esc(out.target.name)}</strong> until the start of your next turn: ${allies.length ? `${allies.length} ${allies.length === 1 ? "ally ignores" : "allies ignore"}` : "your allies ignore"} its concealment and step its cover down a degree.`)]);
}

/** Shielding Strike. */
async function shieldingStrike(ctx) {
  const actor = ctx.actor;
  const bonus = shieldingBonus(ctx.warpMods);
  const weapon = await chooseWeapon(actor, "Shielding Strike", { meleeOnly: true });
  if (weapon) await strikeAsPart(actor, weapon);
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("shieldingStrike", {
    name: `Shielding Strike (+${bonus} DB)`, img: "icons/svg/shield.svg", expiry: expiryFor("startOfNextTurn", actor),
    changes: [{ key: "system.combat.defence.status", mode: 2, value: String(bonus), priority: 20 }]
  })]);
  await card(actor, "Shielding Strike", [line(`+${bonus} status bonus to DB until the start of your next turn.`)]);
}

/** TRG Prime 3.685.1: Dimensional Assault's teleport is its hop, after the cast. */
export const dimensionalAssaultDefers = (ctx = {}) => spellbladeSpell(ctx.spell) === "dimensionalAssault";

/** Dimensional Assault: the hop, then a 0 AP melee Strike; the +5 to Spatial Awareness. */
async function dimensionalAssault(ctx) {
  const actor = ctx.actor;
  const feet = halfSpeedFeet(actor.system?.combat?.movement?.land?.total ?? 0);
  if (!feet) return warn("Dimensional Assault: you have no land speed to hop half of.");
  // A SECOND TELEPORTATION IN ONE TURN FAILS (the core's rule): no hop, and so no Strike.
  if (await h().teleportationFails?.(actor)) {
    await card(actor, "Dimensional Assault", [line("You have already been teleported this turn: a second teleportation automatically fails, so you do not hop, and make no Strike.")]);
    return;
  }
  const moved = await teleportWithin(actor, feet, "Dimensional Assault");
  if (!moved) return;
  // THE +5 ONCE THE HOP HAS HAPPENED (review): not on a refusal, an Escape or
  // a click too far, where it would wait for a check never owed.
  if ((ctx.warpMods?.unlocks ?? []).includes("eaSpatialAwareness5")) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("dimensionalAssault", {
      name: "Dimensional Assault: +5 Spatial Awareness", img: "icons/svg/door-exit.svg", expiry: forSeconds(6),
      system: { conditionals: [{ kind: "modifier", value: 5, type: "status", label: "Dimensional Assault", scope: "this teleport's Spatial Awareness check", auto: true, oneShot: true, when: { actions: ["spatialAwareness"] } }] }
    })]);
  }
  // THE HOP HAS HAPPENED (0.10.1; 0.10.0's live test, finding 1): its Spatial
  // Awareness card and record now, not at the cast (TRG Prime 3.685.1).
  const said = (await h().teleportationArrives?.(actor, ctx.spell, [actor])) ?? [];
  const weapon = await chooseWeapon(actor, "Dimensional Assault", { meleeOnly: true });
  if (weapon) await strikeAsPart(actor, weapon);
  await card(actor, "Dimensional Assault", [line(`You teleport ${moved} feet and strike.${fighting(actor) ? " Roll the Spatial Awareness check from its card now." : ""}`), ...said.map((s) => line(s))]);
}

/** Spinning Weapon: the next melee Strike this turn, a strike rider of the chosen type. */
async function spinningWeapon(ctx) {
  const actor = ctx.actor;
  const types = spinningTypes(ctx.warpMods);
  const type = await h().chooseFromList("Spinning Weapon", "The secondary damage's type:", types.map((t) => [t, t]));
  if (!type) return;
  const dice = spinningDice(ctx.warpMods);
  const expiry = combatFor(actor) ? expiryFor("endOfTurn", actor) : forSeconds(6);
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("spinningWeapon", {
    name: `Spinning Weapon (${dice} ${type})`, img: "icons/svg/explosion.svg", expiry,
    system: { strikeRider: { label: "Spinning Weapon", dice, damageType: type, scope: "melee", once: true } }
  })]);
  await card(actor, "Spinning Weapon", [line(`Your next melee Strike before the end of your turn deals <strong>${dice} ${esc(type)}</strong> secondary damage.`)]);
}

const AFTER_CAST = { shootingStar, shieldingStrike, dimensionalAssault, spinningWeapon };

/**
 * THUNDEROUS STRIKE (Q48): a cast's prelude. The Strike first; its roll is the
 * casting check (TRG Prime 3.682.0's `strikeCheck`), and the cone behind the
 * target saves. Refused before the Strike if the cast would be.
 */
export async function thunderousPrelude({ actor, spell }) {
  if (spellbladeSpell(spell) !== "thunderousStrike") return null;
  const refused = await h().castRefusal(actor, spell);
  if (refused) { warn(refused); return { handled: true, result: null }; }
  const ap = int(spell.system?.castAP);
  if (fighting(actor) && int(actor.system?.resources?.ap?.value) < ap) { warn(`Thunderous Strike: ${ap} AP required.`); return { handled: true, result: null }; }
  if (int(actor.system?.resources?.pp?.value) < int(spell.system?.ppCost)) { warn(`Thunderous Strike: ${int(spell.system?.ppCost)} PP required.`); return { handled: true, result: null }; }
  const weapon = await chooseWeapon(actor, "Thunderous Strike");
  if (!weapon) return { handled: true, result: null };
  const out = await strikeAsPart(actor, weapon);
  if (!out.check || !out.resolved) return { handled: true, result: null };
  const caster = tokenOf(actor);
  const target = out.target ? tokenOf(out.target) : null;
  let cone = [];
  if (caster && target) {
    const points = (canvas?.tokens?.placeables ?? []).map((t) => ({ id: t.id, ...tokenCentre(t) }));
    const feetOf = (a, b) => canvas.grid.measurePath([{ x: a.x, y: a.y }, { x: b.x, y: b.y }]).distance;
    cone = coneBehind({ id: caster.id, ...tokenCentre(caster) }, { id: target.id, ...tokenCentre(target) }, points, feetOf);
  }
  const result = await withTargets(cone, () => h().castSpell(actor, spell, { strikeCheck: out.check, presetTargets: true }));
  // THE CAST DID NOT GO AHEAD (review: a warp dialog cancelled, a refusal):
  // the Strike was made, so it is paid for as a Strike (1 AP).
  if (!result) {
    await spendAPIn(actor, "Thunderous Strike", 1);
    await card(actor, "Thunderous Strike", [line(`The spell was not cast, so the Strike stands on its own${fighting(actor) ? " (1 AP spent)" : ""}.`)]);
  }
  return { handled: true, result };
}

/**
 * DIMENSIONAL ASSAULT'S CAST, WITH NOTHING TARGETED: the core's Teleportation
 * rule moves "the targets, or the caster when there are none", and the
 * creature you mean to strike is not the one teleported. The cast goes on as
 * the core's (TRG Prime does not ask a prelude twice for one spell).
 */
export async function dimensionalAssaultPrelude({ actor, spell }) {
  if (spellbladeSpell(spell) !== "dimensionalAssault") return null;
  if (!(game.user?.targets?.size)) return null;
  const result = await withTargets([], () => h().castSpell(actor, spell));
  return { handled: true, result };
}

/* ------------------------------------------------------------------ */
/* The Warlock                                                          */
/* ------------------------------------------------------------------ */

const picksOf = (actor, slot) => items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.warlockPick === slot);

async function pickWarlockSpells(actor, source, slot, owed, label) {
  const soul = soulOf(actor);
  const level = levelOf(actor);
  const index = await spellIndex();
  while (picksOf(actor, slot).length < owed) {
    const mine = new Set(items(actor).filter((i) => i.type === "spell").map((i) => norm(i.name)));
    const pool = index.filter((e) => !mine.has(norm(e.name)) && warlockMayTake(e, { slot, soul, level }));
    if (!pool.length) return warn(`${label}: nothing you may take is left.`);
    const id = await h().chooseFromList(`${label} — ${picksOf(actor, slot).length + 1} of ${owed}`, `Choose ${slot === "cantrip" ? "a cantrip" : slot === "hex" ? "a hex" : "a spell"}:`,
      pool.sort((a, b) => a.name.localeCompare(b.name)).map((e) => [`${e._id}|${e.pack.collection}`, `${e.name} (PP ${int(e.system?.ppCost)})`]));
    if (!id) return "cancelled";
    const [eid, pk] = String(id).split("|");
    const entry = pool.find((e) => e._id === eid && e.pack.collection === pk);
    const doc = entry ? await entry.pack.getDocument(entry._id) : null;
    if (!doc) return false;
    const [created] = await actor.createEmbeddedDocuments("Item", [warlockCopy(doc.toObject(), { source, slot })]);
    if (created) await card(actor, label, [line(`<strong>${esc(created.name)}</strong> is added: an innate spell with the Focus trait (one use until Refocus), cast with Charisma.`)]);
  }
  return true;
}

const soulUse = {
  hint: "Choose the spells and cantrips you are owed.",
  async use(actor, item) {
    const level = levelOf(actor);
    const owed = warlockSpellsOwed(level);
    const spells = picksOf(actor, "spell").length, cantrips = picksOf(actor, "cantrip").length;
    if (spells >= owed && cantrips >= WARLOCK_CANTRIPS && (await writeWarlockTradition(actor))) return true;
    if (spells >= owed && cantrips >= WARLOCK_CANTRIPS) return card(actor, item.name, [line(`You have all ${owed} of your spells and both cantrips. The next spell arrives at ${3 * Math.floor(level / 3) + 3}th level.`)]);
    // A cancelled pick stops; an empty pool still lets the cantrips be chosen (review).
    if (spells < owed && (await pickWarlockSpells(actor, item, "spell", owed, "Warlock spells")) === "cancelled") return false;
    if (picksOf(actor, "cantrip").length < WARLOCK_CANTRIPS) await pickWarlockSpells(actor, item, "cantrip", WARLOCK_CANTRIPS, "Warlock cantrips");
    // Q97: a soul chosen before 0.9.0 left the sheet's tradition blank.
    await writeWarlockTradition(actor);
    return true;
  }
};

const warlockHexes = {
  hint: "Choose your hex.",
  async use(actor, item) {
    if (picksOf(actor, "hex").length >= WARLOCK_HEXES) return card(actor, "Hexes", [line("You know your hex. More come through the Specialist Spell feat.")]);
    return pickWarlockSpells(actor, item, "hex", WARLOCK_HEXES, "Hexes");
  }
};

/** "Hexes" is the Witch's and the Warlock's: each class's own. */
export const hexesDispatch = {
  hint: "Choose a hex you are owed.",
  async use(actor, item) {
    return norm(item?.system?.sourceClass ?? item?.flags?.[SYSTEM_ID]?.classAbility?.class) === "warlock" ? warlockHexes.use(actor, item) : witchHexes.use(actor, item);
  }
};

/** Xithra's damage type follows the soul: written when either arrives. */
async function syncXithra(actor) {
  const soul = soulOf(actor);
  for (const x of items(actor).filter((i) => i.type === "spell" && i.flags?.[SYSTEM_ID]?.eaXithra)) {
    const next = xithraEffects(x.system?.effects ?? [], soul);
    if (JSON.stringify(next) !== JSON.stringify(x.system?.effects ?? [])) await x.update({ "system.effects": next });
  }
}

/** The bonded soul's once-a-day power, offered after Xithra settles (Q41). */
async function xithraRider(ctx) {
  const actor = ctx.actor;
  const soul = soulOf(actor);
  if (!soul?.rider || !ctx.spell?.flags?.[SYSTEM_ID]?.eaXithra) return;
  if (soul.item.getFlag(MODULE_ID, "riderUsed")) return;
  const { due, target } = riderDue(soul.rider, ctx);
  if (!due) return;
  const r = soul.rider;
  const what = r.kind === "recurring" ? `${target.name} erupts into flames: ${r.dice} recurring ${r.type} damage` : `cast ${r.spell}${target ? ` on ${target.name}` : ""} at 0 AP, as an innate spell`;
  if (!(await confirm(soul.name, `Once a day: ${what}?`))) return;
  await soul.item.setFlag(MODULE_ID, "riderUsed", true);
  if (r.kind === "recurring") {
    const roll = await new Roll(r.dice).evaluate();
    const next = await h().addRecurringDamage(target, roll.total, r.type);
    await card(actor, soul.name, [line(`${esc(target.name)}: <strong>Recurring ${int(next?.value ?? roll.total)} ${esc(r.type)}</strong>.`)]);
    return;
  }
  const data = await packSpellData(r.spell);
  if (!data) return warn(`${soul.name}: ${r.spell} is not in the spells compendium.`);
  delete data._id;
  data.system = { ...data.system, innate: true, usesPerDay: "", usesValue: 0 };
  delete data.system.usesMax;
  // Cure "upon a target within its range": Xithra's 30 ft (Q41).
  if (norm(r.spell) === "cure") data.system.range = "30 feet";
  data.flags = { ...(data.flags ?? {}), [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), castingAbilityOverride: "charisma", innateOnce: true, innatePPAllowance: Math.max(0, int(data.system.ppCost) - levelOf(actor)) } };
  const temp = new Item.implementation(data, { parent: actor });
  const targetToken = target ? tokenOf(target) : null;
  if (targetToken) await withTargets([targetToken.id], () => h().castSpell(actor, temp, { apPaid: true, presetTargets: true }));
  // A self rider (Misty Step) with nothing targeted (review): the core's
  // Teleportation moves the targets, or the caster when there are none.
  else if (r.self) await withTargets([], () => h().castSpell(actor, temp, { apPaid: true }));
  else await h().castSpell(actor, temp, { apPaid: true });
}

/**
 * THE WARLOCK'S CHARISMA POOL (0.9.0; EA-C2, Q52, Graham's Q97). The core gives
 * PP = Charisma once the sheet names a tradition, and the Warlock class names
 * none, so a blank sheet had 0 PP. When the soul is chosen (or its Use is
 * pressed) and the sheet's tradition is blank, the player is asked which of
 * the soul's two traditions is theirs, and it is written where the sheet's own
 * select writes it. Spells never spend the pool (every Warlock spell is innate).
 */
export const warlockTraditionOwed = (actor, soul) => className(actor) === "warlock" && Boolean(soul?.traditions?.length) && !String(actor?.system?.magic?.tradition ?? "").trim();
async function writeWarlockTradition(actor) {
  const soul = soulOf(actor);
  if (!warlockTraditionOwed(actor, soul)) return false;
  const pick = await h().chooseFromList("Bonded Soul — your tradition", "Your Charisma PP pool needs a magical tradition: which of your soul's two is yours?", soul.traditions.map((t) => [t, t[0].toUpperCase() + t.slice(1)]));
  if (!soul.traditions.includes(pick)) return false;
  await actor.update({ "system.magic.tradition": pick });
  await card(actor, "Bonded Soul", [line(`Your tradition is <strong>${esc(pick)}</strong>: your pool is your Charisma in PP (spent only by Warlock’s Hex, Pact Channeler and what any character may pay PP for; never by your spells).`)]);
  return true;
}

/** A hex a Warlock gains through the Specialist Spell feat is innate and Focus too. */
async function warlockHexArrives(item) {
  const actor = item?.parent;
  if (item?.type !== "spell" || !actor?.isOwner || className(actor) !== "warlock") return;
  if (!item.flags?.[SYSTEM_ID]?.eaHex || item.flags?.[MODULE_ID]?.warlockPick || item.system?.innate) return;
  const copy = warlockCopy(item.toObject(), { source: { id: item.flags?.[SYSTEM_ID]?.grantedBy?.sourceId ?? "", name: item.flags?.[SYSTEM_ID]?.grantedBy?.sourceName ?? "Specialist Spell" }, slot: "featHex" });
  await item.update({ "system.innate": true, "system.traits": copy.system.traits, "system.usesValue": 1, [`flags.${SYSTEM_ID}.castingAbilityOverride`]: "charisma", [`flags.${SYSTEM_ID}.innatePPAllowance`]: 1, [`flags.${MODULE_ID}.warlockPick`]: "featHex" });
}

/* ------------------------------------------------------------------ */
/* Registration and hooks                                               */
/* ------------------------------------------------------------------ */

export const AUTOMATIONS_B4 = Object.freeze({
  "Infuse Weapon": infuseWeapon,
  "Dimensional Step": dimensionalStep,
  ...Object.fromEntries(SOUL_NAMES.map((n) => [n, soulUse]))
});

export function registerBlock4(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B4)) api.registerFeatAutomation(name, entry, moduleId);
  // The Witch's and the Warlock's Hexes, each its own (replaces Block 3's entry).
  api.registerFeatAutomation("Hexes", hexesDispatch, moduleId);
  for (const [cls, feats] of Object.entries(EXISTING_CLASS_FEATS)) api.registerFeatAccess?.("class", cls, [...feats], moduleId);
  api.registerPPGrant?.("Natural Resilience", { perLevel: 1, label: "Natural Resilience (+1 HP per level)", types: ["ability"], stat: "hp" }, moduleId);
  api.registerInnateLevelBonus?.("bondedSoul", (ctx) => soulLevelBonus(soulOf(ctx.actor), ctx), moduleId);
  api.registerCastPrelude?.("thunderousStrike", thunderousPrelude, moduleId);
  api.registerCastPrelude?.("dimensionalAssault", dimensionalAssaultPrelude, moduleId);
  // THE HOP IS AFTER THE CAST (0.10.1; TRG Prime 3.685.1): the core cards nothing at the cast.
  api.registerDeferredTeleport?.("eaDimensionalAssault", dimensionalAssaultDefers, moduleId);
  api.registerSpecialistAccess?.("warlockHexes", warlockHexAccess, moduleId);
}

export async function onSpellSettledB4(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner) return;
  await arcaneEcho(ctx);
  const key = spellbladeSpell(ctx.spell);
  // Q47: a path spell's Strike follows a casting of Success or better.
  if (AFTER_CAST[key] && ctx.cast && !ctx.refunded) await AFTER_CAST[key](ctx);
  await xithraRider(ctx);
}

export async function onStrikeResolvedB4(ctx = {}) {
  await sacredChannel(ctx);
  // Arcane Echo is spent on that melee attack, hit or miss (Q50).
  const actor = ctx.attacker;
  if (ctx.melee && ctx.resolved && actor?.isOwner) {
    const ids = Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, "source") === "arcaneEcho").map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
  }
}

export async function onDailyPreparationB4({ actor } = {}) {
  if (!actor?.isOwner) return;
  const soul = soulOf(actor);
  if (soul?.item?.getFlag(MODULE_ID, "riderUsed")) await soul.item.unsetFlag(MODULE_ID, "riderUsed");
  if (hasAbility(actor, "Infuse Weapon")) {
    if (actor.getFlag(SYSTEM_ID, INFUSION_FLAG)) await actor.unsetFlag(SYSTEM_ID, INFUSION_FLAG);
    if (await confirm("Infuse Weapon", "Daily preparation: infuse a melee weapon for the day?")) await infuse(actor);
  }
}

export async function onItemCreatedB4(item) {
  const actor = item?.parent;
  // ONE CLIENT (review): createItem fires on every client.
  if (!actor?.isOwner || !actsFor(actor)) return;
  if ((item.type === "ability" && item.flags?.[SYSTEM_ID]?.eaBondedSoul) || (item.type === "spell" && item.flags?.[SYSTEM_ID]?.eaXithra)) await syncXithra(actor);
  if (item.type === "ability" && item.flags?.[SYSTEM_ID]?.eaBondedSoul) await writeWarlockTradition(actor);
  await warlockHexArrives(item);
}

/** As the caster's turn starts, Shooting Star's trail ends (acting GM). */
export async function onTurnEndedB4(ctx = {}) {
  const game = globalThis.game;
  if (!isActingGM()) return;
  const next = (ctx.combat ?? game.combat)?.combatant?.actor;
  if (!next) return;
  // The world's actors and the board's (an unlinked token's actor is its own).
  const bearers = new Set([...(game.actors ?? []), ...(canvas?.tokens?.placeables ?? []).map((t) => t.actor).filter(Boolean)]);
  for (const actor of bearers) {
    const ids = Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, "source") === TRAIL_SOURCE && e.getFlag(MODULE_ID, "trailOf") === next.id).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
  }
}
