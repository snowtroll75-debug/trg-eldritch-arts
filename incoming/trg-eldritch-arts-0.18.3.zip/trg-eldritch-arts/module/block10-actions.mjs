/**
 * Eldritch Arts Block 10 — the Relic Bonding Ritual (Chapter 4, L1828), a
 * general skill action in the shape TRG Prime's SKILL_ACTIONS holds.
 *
 * THE DC (Q211): the Level DC of the WIELDER's level, the performer rolling
 * their trained Arcana, Nature, Occultism or Religion; `resolveDC` asks which
 * relic, checks its refusals and the cost (Q212: the performer's 1 PP and
 * 250 gp), and the degree is applied by onActionResolvedB10.
 *
 * BOOK TEXT IS VERBATIM (tools/content/book-text.json
 * `chapter4["RELIC BONDING RITUAL"]`), held against the extract by verify-block10.
 */
import { resolveBondingDC } from "./block10-automations.mjs";
import { BONDING_SKILLS } from "./block10-rules.mjs";

const ladder = (o) => ({ heroic: "", critical: "", success: "", partial: "", failure: "", fumble: "", blunder: "", ...o });

export const SKILL_ACTIONS = Object.freeze([
  {
    key: "relicBondingRitual",
    name: "Relic Bonding Ritual",
    skills: [...BONDING_SKILLS],
    traits: "Concentrate",
    apCost: "Varies (1 hour, ritual)",
    proficiency: "trained",
    checkType: "skill",
    against: "none",
    difficulty: "medium",
    outcomesApplied: true,
    resolveDC: (ctx) => resolveBondingDC(ctx),
    outcomes: ladder({
      critical: "The Relic bonds more deeply, immediately awakening to the next stage if the wielder qualifies by level.",
      success: "The Relic bonds with the chosen wielder.",
      failure: "The Relic rejects the attempt. The ritual may not be attempted again for 24 hours.",
      fumble: "The Relic lashes out, inflicting 1d6 essence damage per character level (basic Fort) and refuses further attempts for 1 week."
    }),
    description: "**Cost** 1 PP (wielder or ritualist) and rare incense/herbs/oils worth 250 gp (consumed). **Requirements** The Relic must willingly accept the bond. Certain Relics may impose trials, aligned trait restrictions, or conditions. A relic is always Dormant when first discovered. After bonding, the Relic advances one tier at each daily preparation until its tier matches the wielder's level. A ritual may be performed by another character to bond the Relic to its intended wielder (e.g., a priest binding a holy Relic to a champion). (Eldritch Arts, Chapter 4) — Target the wielder to bond it to them; with no target, it is bonded to you. Partial reads as Failure, Blunder as Fumble (Q211)."
  }
]);
