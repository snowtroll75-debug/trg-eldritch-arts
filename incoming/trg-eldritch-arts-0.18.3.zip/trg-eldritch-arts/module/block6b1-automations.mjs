/**
 * Eldritch Arts — Block 6 (0.9.0), group B1: what the archetypes Eternal
 * Vigil, Fatespinner, Ferromancer, Leyline Weaver and Runeblade and their
 * class feats do that is not data. On TRG Prime 3.684.0.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md (Appendix B) as Graham
 * answered it on 4 November 2026 (Q89–Q149 as proposed), on the seams as
 * built (b6-contracts.md: G7, G8, G18, G19, G22). The pure rules come first
 * so the harness can run them; the Foundry side follows.
 *
 *   Uses        Temporal Reprieve, Iron Ward, Runeblade (today's runes),
 *               Foreseen Danger (the asking on/off), Leyline Power (anchored)
 *   Reactions   Fatespinner's reroll and Destiny's Embrace (check, after);
 *               Foreseen Danger, Damaging Gambit, Confluence Master (check,
 *               before); Living Iron and Chronostasis (damage); Eternal
 *               Vigil (G7's unconscious offer)
 *   Seams       Eternal Vigil's warp (registerSpellWarps), Leywalk's +2
 *               (spell-check gate), Ley Walker's ley-line requirement (cast
 *               refusal)
 *   Hooks       spell settled (Eternal Vigil's fast healing, Shard Cloud);
 *               death guard held (Chronostasis); turn ended (Shard Cloud's
 *               turn-start bites); effect created (Last Horizon); effect
 *               deleted (Chronostasis ends); action resolved (Leyline Power,
 *               Leyline Anchor); actor updated (Runeblade's runes on a new
 *               infusion); item created (Runeblade's Book of Infusions);
 *               token moved (Shard Cloud's entry bite)
 *   Block 2     `leylineWeaverTap` — Leyline Weaver's replaced Tap ladder,
 *               for Block 2's Tap branch to call (the lead wires it).
 *
 * The hook handlers are exported for the lead to wire in
 * scripts/eldritch-arts.mjs; each says which `Hooks.on` event it expects.
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, now, levelOf, tokenOf, feetBetween } from "./block1-automations.mjs";
import { actsFor } from "./block3-automations.mjs";
import { allies, enemies } from "./block3b-automations.mjs";
import { applyRow } from "./block2-automations.mjs";
import { LEY_LINE_EFFECTS, rowFor } from "./chapter7-tables.mjs";
import { leyLinesWithin } from "./areas.mjs";

/* ------------------------------------------------------------------ */
/* Data shared with the content                                         */
/* ------------------------------------------------------------------ */

export const FEATS = Object.freeze({
  eternalVigil: "Eternal Vigil", fatespinner: "Fatespinner", ferromancer: "Ferromancer", leylineWeaver: "Leyline Weaver", runeblade: "Runeblade",
  chronostasis: "Chronostasis", confluence: "Confluence Master", gambit: "Damaging Gambit", destiny: "Destiny’s Embrace", fatesFavour: "Fate’s Favour",
  ironWard: "Iron Ward", lastHorizon: "Last Horizon", anchor: "Leyline Anchor", leywalk: "Leywalk", livingIron: "Living Iron",
  livingSigil: "Living Sigil", runeforge: "Runeforge Mastery", reprieve: "Temporal Reprieve", twinflare: "Twinflare Rune"
});
export const FORESEEN = "Foreseen Danger";
export const LEYLINE_POWER = "Leyline Power";
export const TOUCH_OF_HEALING = "Touch of Healing";
export const SHARD_CLOUD = "Shard Cloud";
export const LEY_WALKER = "Ley Walker";

/** Eternal Vigil's warp (Q108): "+2 PP: gain fast healing 5". */
export const VIGIL_WARP_PP = 2;
export const VIGIL_FAST_HEALING = 5;
export const VIGIL_UNLOCK = "eaEternalVigil";
/** Foreseen Danger, Destiny's Embrace: "an ally within 30 feet". */
export const FORESEEN_FEET = 30;
export const FORESEEN_DIE = "1d6";
export const IRON_WARD_DB = 2;
/** Living Iron: "While you have at least 2 PP remaining". */
export const LIVING_IRON_PP = 2;
export const LIVING_IRON_TYPES = Object.freeze(["slashing", "piercing"]);
export const LEYWALK_BONUS = 2;
/** Ley Walker: "within 30 feet of a ley line". */
export const LEY_WALKER_FEET = 30;
/** Last Horizon: "once per minute". */
export const LAST_HORIZON_SECONDS = 60;
/** Leyline Anchor: "for 1 minute". */
export const ANCHOR_SECONDS = 60;
/** Shard Cloud: 5-ft radius, max 30; 1d6 slashing; "1 minute (S)". */
export const SHARD_FEET = 5;
export const SHARD_MAX_FEET = 30;
export const SHARD_SECONDS = 60;

/**
 * Runeblade's list, as printed, less Defending I (Q117: no such rune exists).
 * Bane and Returning have one tier; the rest are the energy runes' tier I.
 */
export const RUNEBLADE_RUNES = Object.freeze([
  Object.freeze({ key: "acidic", tier: 1, name: "Acidic I" }),
  Object.freeze({ key: "bane", tier: 1, name: "Bane", parameter: true }),
  Object.freeze({ key: "flaming", tier: 1, name: "Flaming I" }),
  Object.freeze({ key: "frost", tier: 1, name: "Frost I" }),
  Object.freeze({ key: "returning", tier: 1, name: "Returning" }),
  Object.freeze({ key: "shock", tier: 1, name: "Shock I" }),
  Object.freeze({ key: "thundering", tier: 1, name: "Thundering I" })
]);
/** Block 4's flags (module/block4-automations.mjs): the infusion on the wielder, the Book of Infusions. */
export const INFUSION_FLAG = "infusedRunes";
export const BOOK_RUNES_FLAG = "infusionRunes";
/** On the infusion: what this module appended, and what Block 4 wrote before it. */
export const RUNEBLADE_MARK = "eaRuneblade";

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const SUCCESSES = Object.freeze(["heroic", "critical", "success"]);
const traitList = (traits) => String(traits ?? "").split(/[,;]/).map((t) => norm(t)).filter(Boolean);

/** Q108: rounds = the PP the spell was cast at, less this option's 2 (at least 1). */
export const vigilRounds = (castPP) => Math.max(1, int(castPP) - VIGIL_WARP_PP);

/** Was Eternal Vigil's warp bought on this cast? */
export const vigilWarpBought = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded && Array.from(ctx.warpMods?.unlocks ?? []).includes(VIGIL_UNLOCK);

/** Eternal Vigil's fast healing, as the core's healing-rate effect carries it. */
export function vigilFastHealingFlags() {
  return { spellBuff: true, fastHealing: VIGIL_FAST_HEALING };
}

/**
 * Fatespinner: "reroll a failed skill check as long as it is not either a
 * blunder result or an unmodified 1".
 */
export function fatespinnerRerolls(ctx = {}) {
  if (ctx.type !== "skill" || !ctx.failed) return false;
  if (norm(ctx.degree) === "blunder") return false;
  return int(ctx.check?.dice?.unmodified) !== 1;
}

/** Damaging Gambit: "casting a spell with the attack trait" — a spell attack's check is its attack (Q111). */
export const gambitWants = (ctx = {}) => ctx.type === "attack" && norm(ctx.check?.reactionAs) === "attack";

/** Destiny's Embrace: an attack that hit. */
export const destinyWants = (ctx = {}) => ctx.type === "attack" && Boolean(ctx.succeeded) && Boolean(ctx.target) && ctx.target !== ctx.actor;

/** Foreseen Danger: "makes a d20 check" — an attack, a save or a skill check (the core's reaction checks). */
export const foreseenWants = (ctx = {}) => ["attack", "save", "skill"].includes(ctx.type) && Boolean(ctx.actor);

/** Living Iron's answer, or null. */
export function livingIronResists({ pp = 0, types = [] } = {}) {
  if (int(pp) < LIVING_IRON_PP) return null;
  const hit = Array.from(types ?? []).map(norm).filter((t) => LIVING_IRON_TYPES.includes(t));
  return hit.length ? [...LIVING_IRON_TYPES] : null;
}

/** Temporal Reprieve (Q122): any number of PP up to your level, and no more than you have. */
export const reprieveMax = ({ level = 0, pp = 0 } = {}) => Math.max(0, Math.min(int(level), int(pp)));

/** How many Runeblade Runes a day: 1, 2 with Twinflare Rune, 3 with Living Sigil. */
export function runebladeCount(featNames = []) {
  const names = new Set(Array.from(featNames ?? []).map(norm));
  if (names.has(norm(FEATS.livingSigil))) return 3;
  if (names.has(norm(FEATS.twinflare))) return 2;
  return 1;
}

/** The field text for the chosen Runeblade Runes (core rune names, the parameter in brackets). */
export function runebladeText(picks = []) {
  return Array.from(picks ?? []).map((p) => {
    const rune = RUNEBLADE_RUNES.find((r) => r.key === p.key);
    if (!rune) return "";
    return p.parameter ? `${rune.name} (${String(p.parameter).trim()})` : rune.name;
  }).filter(Boolean).join(", ");
}

/** Block 4's runes and the Runeblade Runes, as one field. */
export const mergedRunes = (base, extra) => [String(base ?? "").trim(), String(extra ?? "").trim()].filter(Boolean).join(", ");

/**
 * Was this actor update a fresh infusion by Block 4 (its runes written, and
 * not by this module)? `change` is updateActor's diff.
 */
export function freshInfusion(change = {}) {
  const inf = change?.flags?.[SYSTEM_ID]?.[INFUSION_FLAG];
  if (!inf || typeof inf !== "object") return false;
  if (Object.hasOwn(inf, RUNEBLADE_MARK)) return false;
  return Object.hasOwn(inf, "runes") || Object.hasOwn(inf, "weaponId");
}

/** Runeforge Mastery's declaration (G19) for the day's Runeblade Runes. */
export function runeforgeBypass(keys = [], weaponId = "") {
  return { label: FEATS.runeforge, runes: Array.from(keys ?? []).map(String), weaponId: String(weaponId ?? ""), immunityAsResistance: true };
}

/**
 * Leyline Weaver's ladder (it replaces the Tap's results): what each degree
 * does, or null where the action's own result stands (Failure, Fumble).
 */
export function leylineWeaverRung(degree) {
  const k = norm(degree) === "heroic" ? "critical" : norm(degree);
  if (k === "critical") return { expiry: "endOfNextTurn", factor: 2, pp: "1d8" };
  if (k === "success") return { expiry: "endOfNextTurn", factor: 1, pp: "" };
  if (k === "partial") return { expiry: "endOfTurn", factor: 1, pp: "" };
  return null;
}

const levelNumber = (amount, level) => {
  const l = Math.max(0, int(level));
  const s = String(amount ?? "").trim();
  if (s === "level") return l;
  if (s === "halfLevel") return Math.floor(l / 2);
  return int(s);
};

/**
 * Q113: "every number in the rolled effect doubles". A Ley Line Effects row's
 * spec with its numbers doubled, for applyRow (Block 2). A row with no number
 * (advantage, a chosen resistance, a GM's row) is returned as it is.
 */
export function doubledLeySpec(spec, level, factor = 2) {
  if (!spec || factor === 1) return spec;
  const f = Math.max(1, int(factor));
  switch (spec.kind) {
    case "cond":
      return spec.mod?.kind === "modifier" ? { ...spec, mod: { ...spec.mod, value: int(spec.mod.value) * f }, label: String(spec.label ?? "").replace(/([+−-])(\d+)/, (m, s, n) => `${s}${int(n) * f}`) } : spec;
    case "db":
    case "spellDC":
      return { ...spec, value: int(spec.value) * f, ...(spec.label ? { label: String(spec.label).replace(/([+−-])(\d+)/, (m, s, n) => `${s}${int(n) * f}`) } : {}) };
    case "dr":
      return { ...spec, value: int(spec.value) * f, minutes: /^\d+$/.test(String(spec.minutes ?? "")) ? String(int(spec.minutes) * f) : `(${spec.minutes})*${f}` };
    case "tempHP":
    case "heal":
    case "pp":
      return { ...spec, amount: String(levelNumber(spec.amount, level) * f) };
    default:
      return spec;
  }
}

/** Shard Cloud's dice and radius from the cast's warps (each option as often as bought). */
export function shardCloudOf(warpMods = {}) {
  const m = /^(\d+)d6$/i.exec(String(warpMods?.damageDice ?? "").trim());
  const dice = 1 + (m ? int(m[1]) : 0);
  const feet = Math.min(SHARD_MAX_FEET, SHARD_FEET + Math.max(0, int(warpMods?.areaGrowth)));
  return { dice, feet };
}

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const ownedFeat = (actor, name) => items(actor).find((i) => ["feat", "ability"].includes(i.type) && norm(i.name) === norm(name)) ?? null;
const ownedSpell = (actor, name) => items(actor).find((i) => i.type === "spell" && norm(i.name) === norm(name)) ?? null;
const featNames = (actor) => items(actor).filter((i) => i.type === "feat").map((i) => i.name);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (t) => t?.document?.disposition;
const ppOf = (actor) => ({ value: int(actor?.system?.resources?.pp?.value), max: int(actor?.system?.resources?.pp?.max) });
const spellDC = (actor) => int(actor?.system?.magic?.spellcraft?.dc);
const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];
const fighting = (actor) => Boolean(combatFor(actor));
const roundKey = (actor) => { const c = combatFor(actor); return c ? `${c.id}:${c.round}` : ""; };

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function spendAP(actor, label, ap = 1) {
  if (!fighting(actor) || ap <= 0) return true;
  const have = int(actor.system?.resources?.ap?.value);
  if (have < ap) return warn(`${label}: ${ap} AP required.`);
  await actor.update({ "system.resources.ap.value": have - ap });
  return true;
}
async function rollTotal(formula) {
  if (!formula) return 0;
  const roll = await new Roll(String(formula)).evaluate();
  return int(roll.total);
}
async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }).catch(() => false));
}
async function gainPP(actor, amount) {
  const { value, max } = ppOf(actor);
  const after = max > 0 ? Math.min(max, value + int(amount)) : value + int(amount);
  await actor.update({ "system.resources.pp.value": after });
  return { before: value, after, capped: value + int(amount) > after };
}

/** Q28's awareness, and whether a reaction may be taken now: a reason, or "". */
async function reactionBlocked(actor, traits = "") {
  if (!actor) return "no creature";
  if (actor.hasCondition?.("blinded")) return "blinded";
  if (await h().isDead?.(actor)) return "dead";
  return (await h().reactionRefusal?.(actor, traits)) || "";
}

/** Set this user's targets for the length of `run`, then put them back. */
async function withTargets(ids, run) {
  const all = globalThis.canvas?.tokens?.placeables ?? [];
  const previous = Array.from(game.user?.targets ?? []).map((t) => t.id);
  const set = (want) => {
    const s = new Set(want);
    for (const t of all) if (t.isTargeted !== s.has(t.id)) t.setTarget(s.has(t.id), { user: game.user, releaseOthers: false, groupSelection: true });
  };
  try {
    set(ids);
    return await run();
  } finally {
    set(previous);
  }
}

/** Does the actor still sustain this spell (the core's active-spell register)? */
const sustains = (actor, name) => (Array.isArray(actor?.getFlag?.(SYSTEM_ID, "activeSpells")) ? actor.getFlag(SYSTEM_ID, "activeSpells") : []).some((e) => norm(e?.name) === norm(name));

/* ------------------------------------------------------------------ */
/* The Uses                                                             */
/* ------------------------------------------------------------------ */

const ironWard = {
  hint: "1 AP: +2 circumstance to DB until the start of your next turn (Focus).",
  async use(actor, item) {
    const asAction = { ...(item?.system ?? {}), traits: item?.system?.traits ?? "" };
    if (h().traitGate && !(await h().traitGate(actor, asAction, FEATS.ironWard))) return false;
    if (!(await spendAP(actor, FEATS.ironWard, 1))) return false;
    await h().createEffectsOn(actor, [effectData("eaIronWard", {
      name: `Iron Ward (+${IRON_WARD_DB} DB)`, img: "icons/svg/shield.svg",
      description: `Iron Ward: +${IRON_WARD_DB} circumstance to DB until the start of your next turn.`,
      changes: [{ key: "system.combat.defence.circumstance", type: "custom", value: String(IRON_WARD_DB), priority: 20 }],
      expiry: expiryFor("startOfNextTurn", actor)
    })]);
    if (h().recordTraitUsage) await h().recordTraitUsage(actor, asAction);
    await card(actor, FEATS.ironWard, [line(`A shield of metal shards: <strong>+${IRON_WARD_DB} circumstance to DB</strong> until the start of your next turn.`), ...(fighting(actor) ? [line("1 AP spent.")] : []), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return true;
  }
};

const temporalReprieve = {
  hint: "0 AP: expend PP (up to your level) and heal 1d8 HP for each (Focus).",
  async use(actor, item) {
    const asAction = { ...(item.system ?? {}), traits: item.system?.traits ?? "" };
    if (h().traitGate && !(await h().traitGate(actor, asAction, item.name))) return false;
    const max = reprieveMax({ level: levelOf(actor), pp: ppOf(actor).value });
    if (!max) return warn("Temporal Reprieve: you have no PP to expend.");
    const picked = await h().chooseFromList(FEATS.reprieve, `Expend how many PP (up to ${max})? You heal 1d8 HP for each.`, Array.from({ length: max }, (_, i) => [String(i + 1), `${i + 1} PP — ${i + 1}d8 HP`]));
    const n = Math.min(max, int(picked));
    if (!n) return false;
    await actor.update({ "system.resources.pp.value": ppOf(actor).value - n });
    const healed = await rollTotal(`${n}d8`);
    await h().healActor(actor, healed);
    if (h().recordTraitUsage) await h().recordTraitUsage(actor, asAction);
    await card(actor, FEATS.reprieve, [line(`You expend <strong>${n} PP</strong> and heal <strong>${healed} HP</strong> (${n}d8). It provokes no reactions.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return true;
  }
};

/** Foreseen Danger's Use: the asking on or off for this character (spends nothing). */
const foreseenDangerUse = {
  hint: "Turn the offer before your allies' checks on or off.",
  ownsFocusUse: true,
  async use(actor, item) {
    const off = Boolean(item.getFlag?.(MODULE_ID, "eaForeseenOff"));
    await item.setFlag(MODULE_ID, "eaForeseenOff", !off);
    await card(actor, FORESEEN, [line(off ? "You will be asked before an ally's check within 30 feet again." : "You will <strong>not</strong> be asked before your allies' checks until you turn it back on.")]);
    return true;
  }
};

/** Leyline Power's Use while Leyline Anchor holds a line: 1d8 PP, once a round. */
const leylinePower = {
  hint: "While anchored (Leyline Anchor): regain 1d8 PP without re-tapping, once a round (reaction, Focus).",
  async use(actor, item) {
    if (!ownEffects(actor, "eaLeylineAnchor").length) return warn("Leyline Power: it is used after a successful Tap Ley Line (you are asked then); its Use is for a line anchored by Leyline Anchor, and none is.");
    const key = roundKey(actor);
    if (key && actor.getFlag?.(MODULE_ID, "eaLeylinePowerRound") === key) return warn("Leyline Power: once a round while anchored.");
    if (await reactionBlocked(actor, item.system?.traits ?? "")) return warn("Leyline Power: you cannot take a reaction now.");
    if (!(await h().spendReaction?.(actor, LEYLINE_POWER, { traits: String(item.system?.traits ?? "") }))) return false;
    if (key) await actor.setFlag(MODULE_ID, "eaLeylinePowerRound", key);
    const gained = await rollTotal("1d8");
    const pp = await gainPP(actor, gained);
    await card(actor, LEYLINE_POWER, [line(`The anchored ley line: you regain <strong>${gained} PP</strong> (1d8): PP ${pp.before} → ${pp.after}${pp.capped ? " (capped at your maximum)" : ""}.`), line("<em>Reaction and Focus use spent (Q114) — Refocus restores the use.</em>")]);
    return true;
  }
};

/* Runeblade ------------------------------------------------------------ */

const infusionOf = (actor) => {
  const f = actor?.getFlag?.(SYSTEM_ID, INFUSION_FLAG);
  return f && typeof f === "object" ? f : null;
};

/** Ask for today's Runeblade Runes; `base` is Block 4's runes for the infusion. */
async function chooseRunebladeRunes(actor, base) {
  const inf = infusionOf(actor);
  if (!inf?.weaponId) return warn("Runeblade: infuse a weapon first (Infuse Weapon): the Runeblade Runes go on the infused weapon.");
  const count = runebladeCount(featNames(actor));
  const picks = [];
  while (picks.length < count) {
    const pool = RUNEBLADE_RUNES.filter((r) => !picks.some((p) => p.key === r.key));
    const id = await h().chooseFromList(`Runeblade — rune ${picks.length + 1} of ${count}`, "Today's Runeblade Rune (outside your rune levels; cancel when done):", pool.map((r) => [r.key, r.name]));
    const rune = pool.find((r) => r.key === id);
    if (!rune) break;
    let parameter = null;
    if (rune.parameter) {
      parameter = String(await h().enterText("Runeblade — Bane", "Bane: which kind of creature (canines, dragons, elves, spiders …)?", "dragons") ?? "").trim();
      if (!parameter) continue;
    }
    picks.push({ key: rune.key, tier: rune.tier, parameter });
  }
  const text = runebladeText(picks);
  const runes = mergedRunes(base, text);
  await actor.update({
    [`flags.${SYSTEM_ID}.${INFUSION_FLAG}.runes`]: runes,
    [`flags.${SYSTEM_ID}.${INFUSION_FLAG}.${RUNEBLADE_MARK}`]: { base: String(base ?? ""), text, keys: picks.map((p) => p.key) }
  });
  const forge = ownedFeat(actor, FEATS.runeforge);
  if (forge && picks.length) {
    await h().replaceFeatEffect(actor, forge, {
      name: "Runeforge Mastery: today's Runeblade Runes", img: forge.img,
      description: `Runeforge Mastery: ${text} ignore resistance to their damage type; immunity is treated as resistance.`,
      flags: { [SYSTEM_ID]: { runeDamageBypass: runeforgeBypass(picks.map((p) => p.key), inf.weaponId) } }
    }, { dailyPrep: true });
  }
  await card(actor, FEATS.runeblade, [
    line(picks.length ? `Today's Runeblade Rune${picks.length > 1 ? "s" : ""}: <strong>${esc(text)}</strong>, on your infused weapon, outside your rune levels.` : "No Runeblade Rune today."),
    ...(forge && picks.length ? [line("<em>Runeforge Mastery: their damage ignores resistance to its type, and immunity counts as resistance.</em>")] : [])
  ]);
  return true;
}

const runeblade = {
  hint: "Choose today's Runeblade Rune(s) for your infused weapon.",
  async use(actor) {
    const inf = infusionOf(actor);
    const mark = inf?.[RUNEBLADE_MARK];
    // Block 4's own runes: what it wrote before this module appended, if it has not rewritten them since.
    const base = mark && String(inf.runes ?? "") === mergedRunes(mark.base, mark.text) ? mark.base : String(inf?.runes ?? "");
    return chooseRunebladeRunes(actor, base);
  }
};

/** On the feat's arrival: Weapon Potency I and one Runeblade Rune into the Book of Infusions. */
async function fillRunebladeBook(actor) {
  const catalogue = (await h().runesFor("weapon")) ?? [];
  const levelOfRune = (key, tier = 1) => int((catalogue.find((r) => r.key === key)?.tiers ?? []).find((t) => int(t.numeral) === tier)?.level);
  const book = Array.isArray(actor.getFlag?.(MODULE_ID, BOOK_RUNES_FLAG)) ? [...actor.getFlag(MODULE_ID, BOOK_RUNES_FLAG)] : [];
  const add = (rune) => { if (!book.some((k) => k.key === rune.key && int(k.tier) >= int(rune.tier))) { const i = book.findIndex((k) => k.key === rune.key); if (i >= 0) book.splice(i, 1); book.push(rune); } };
  add({ key: "potency", tier: 1, name: "Potency I", level: levelOfRune("potency", 1) });
  // Bane takes a creature kind, which Infuse Weapon's book does not carry (Block 4); the rest are offered.
  const pool = RUNEBLADE_RUNES.filter((r) => !r.parameter);
  const id = await h().chooseFromList(FEATS.runeblade, "Add which Runeblade Rune to your Book of Infusions (with Weapon Potency I)?", pool.map((r) => [r.key, r.name]));
  const rune = pool.find((r) => r.key === id);
  if (rune) add({ key: rune.key, tier: rune.tier, name: rune.name, level: levelOfRune(rune.key, rune.tier) });
  await actor.setFlag(MODULE_ID, BOOK_RUNES_FLAG, book);
  await card(actor, FEATS.runeblade, [line(`Your Book of Infusions gains <strong>Weapon Potency I</strong>${rune ? ` and <strong>${esc(rune.name)}</strong>` : ""}.`)]);
}

export const AUTOMATIONS_B6_B1 = Object.freeze({
  [FEATS.ironWard]: ironWard,
  [FEATS.reprieve]: temporalReprieve,
  [FEATS.runeblade]: runeblade,
  [FORESEEN]: foreseenDangerUse,
  [LEYLINE_POWER]: leylinePower
});

/** What the passive feats say when their Use is pressed (the core's passive hints). */
export const PASSIVE_B6_B1 = Object.freeze({
  [FEATS.eternalVigil]: "Eternal Vigil is automatic: Death State +2; at 0 HP, once a day, you are asked to cast Touch of Healing on yourself; Healing spells offer its +2 PP fast-healing warp.",
  [FEATS.fatespinner]: "Fatespinner is automatic: conviction maximum +1, and you are asked to reroll a failed skill check with a conviction point.",
  [FEATS.ferromancer]: "Ferromancer is automatic: your arcane casts need no free hand for somatic, and spend a component pouch use.",
  [FEATS.leylineWeaver]: "Leyline Weaver is automatic: +2 circumstance to Ley Sense and Tap Ley Line, and the replaced Tap results.",
  [FEATS.chronostasis]: "Chronostasis is automatic: once a day, when damage would take you to 0 HP, you are asked.",
  [FEATS.confluence]: "Confluence Master is automatic: with two ley lines within 30 feet, you are asked whether you tap both.",
  [FEATS.gambit]: "Damaging Gambit is automatic: before a spell attack's check you are asked whether to spend a conviction point for advantage.",
  [FEATS.destiny]: "Destiny's Embrace is automatic: when an enemy hits an ally within 30 feet, you are asked (reaction and Foreseen Danger's use).",
  [FEATS.fatesFavour]: "Fate's Favour is automatic: the day's first conviction advantage on a save or skill check is refunded on a Partial or worse.",
  [FEATS.lastHorizon]: "Last Horizon is automatic: when you gain Dying you are asked.",
  [FEATS.anchor]: "Leyline Anchor is automatic: after a successful Tap Ley Line you are asked whether you anchor the line.",
  [FEATS.leywalk]: "Leywalk is automatic: +2 status to Ley Walker's casting check.",
  [FEATS.livingIron]: "Living Iron is automatic: resistance to slashing and piercing while you have at least 2 PP.",
  [FEATS.livingSigil]: "Living Sigil is read by Runeblade: three Runeblade Runes.",
  [FEATS.runeforge]: "Runeforge Mastery is automatic: your Runeblade Runes ignore resistance (immunity as resistance).",
  [FEATS.twinflare]: "Twinflare Rune is read by Runeblade: two Runeblade Runes."
});

/* ------------------------------------------------------------------ */
/* Reactions                                                            */
/* ------------------------------------------------------------------ */

export const FATESPINNER_STEP = "eldritchArts.fatespinnerReroll";
export const GAMBIT_STEP = "eldritchArts.damagingGambit";
export const FORESEEN_STEP = "eldritchArts.foreseenDanger";
export const DESTINY_STEP = "eldritchArts.destinysEmbrace";
export const VIGIL_STEP = "eldritchArts.eternalVigil";

/** Spend a conviction point on the answerer's client. */
async function convictionStep(actor) {
  const state = await h().convictionState(actor);
  if (!state?.ok) return { spent: false };
  return { spent: Boolean(await h().spendConviction(actor)) };
}

/** Fatespinner: after a failed skill check, a conviction point rerolls it. */
export const fatespinnerReroll = Object.freeze({
  async after(ctx = {}) {
    const actor = ctx.actor;
    if (!fatespinnerRerolls(ctx) || !ownedFeat(actor, FEATS.fatespinner)) return null;
    const state = await h().convictionState(actor);
    if (!state?.ok) return null;
    const q = await h().askReactor(actor, {
      title: `Fatespinner — ${actor.name}`,
      content: `<p>Your ${esc(ctx.label || "skill check")} came out a <strong>${esc(ctx.degree)}</strong> (${int(ctx.total)}).</p><p>Spend a conviction point to reroll it? The second result stands.</p>`,
      buttons: yesNo("Reroll (1 conviction)"), step: FATESPINNER_STEP, data: {}
    });
    if (!q?.result?.spent) return null;
    return { reroll: true, label: FEATS.fatespinner, line: `${esc(actor.name)} spends a conviction point (<strong>Fatespinner</strong>): the skill check is rerolled, and the second result stands.` };
  }
});

/** Damaging Gambit: before a spell attack's check, a conviction point for advantage (Q111). */
export const damagingGambit = Object.freeze({
  async before(ctx = {}) {
    const actor = ctx.actor;
    if (!gambitWants(ctx) || !ownedFeat(actor, FEATS.gambit)) return null;
    const state = await h().convictionState(actor);
    if (!state?.ok) return null;
    const q = await h().askReactor(actor, {
      title: `Damaging Gambit — ${actor.name}`,
      content: `<p>You cast <strong>${esc(ctx.label || "a spell")}</strong>, an attack.</p><p>Spend a conviction point for advantage on its check (the attack and the casting are one roll)?</p>`,
      buttons: yesNo("Advantage (1 conviction)"), step: GAMBIT_STEP, data: {}
    });
    if (!q?.result?.spent) return null;
    return { advantage: true, label: FEATS.gambit, line: `${esc(actor.name)} spends a conviction point (<strong>Damaging Gambit</strong>): the spell attack has advantage.` };
  }
});

/** The Foreseen Danger owners who could answer for this ally's check. */
async function foreseenReactors(allyToken, ally, { needFeat = null } = {}) {
  const out = [];
  for (const t of tokens()) {
    const owner = t.actor;
    if (!owner || owner === ally || t === allyToken) continue;
    if (needFeat && !ownedFeat(owner, needFeat)) continue;
    const ability = ownedFeat(owner, FORESEEN);
    if (!ability || usesLeft(ability) <= 0) continue;
    if (!needFeat && ability.getFlag?.(MODULE_ID, "eaForeseenOff")) continue;
    if (!allies(side(t), side(allyToken))) continue;
    const d = feetBetween(t, allyToken);
    if (d === null || d > FORESEEN_FEET) continue;
    if (await reactionBlocked(owner, ability.system?.traits ?? "")) continue;
    out.push({ token: t, owner, ability });
  }
  return out;
}

/** Foreseen Danger: before an ally's d20 check within 30 ft, +1d6 rolled now. */
export const foreseenDanger = Object.freeze({
  async before(ctx = {}) {
    if (!foreseenWants(ctx) || !ctx.token) return null;
    for (const { owner, ability } of await foreseenReactors(ctx.token, ctx.actor)) {
      const q = await h().askReactor(owner, {
        title: `Foreseen Danger — ${owner.name}`,
        content: `<p><strong>${esc(ctx.actor.name)}</strong> is about to roll ${esc(ctx.label || `a ${ctx.type} check`)}.</p><p>Use <strong>Foreseen Danger</strong> (your reaction and its Focus use) to add 1d6 to it?</p>`,
        buttons: yesNo("Foreseen Danger"), step: FORESEEN_STEP, data: { itemId: ability.id }
      });
      const value = int(q?.result?.value);
      if (!q?.result?.spent || !value) continue;
      return { modifiers: [{ label: `Foreseen Danger (${owner.name})`, value, type: "untyped" }], line: `${esc(owner.name)}'s <strong>Foreseen Danger</strong>: +${value} (1d6) to ${esc(ctx.actor.name)}'s check.` };
    }
    return null;
  }
});

async function foreseenStep(actor, answer, data) {
  const item = actor?.items?.get?.(data?.itemId);
  if (!item || usesLeft(item) <= 0) return { spent: false };
  if (!(await h().spendReaction?.(actor, FORESEEN, { traits: String(item.system?.traits ?? "") }))) return { spent: false };
  await spendUse(item);
  return { spent: true, value: await rollTotal(FORESEEN_DIE) };
}

/** Destiny's Embrace: an enemy's hit on an ally within 30 ft is rerolled (reaction, Foreseen's Focus use). */
export const destinysEmbrace = Object.freeze({
  async after(ctx = {}) {
    if (!destinyWants(ctx)) return null;
    const allyToken = tokenOf(ctx.target);
    const attackerToken = ctx.token ?? tokenOf(ctx.actor);
    if (!allyToken) return null;
    for (const { token, owner, ability } of await foreseenReactors(allyToken, ctx.target, { needFeat: FEATS.destiny })) {
      if (owner === ctx.actor || (attackerToken && !enemies(side(token), side(attackerToken)))) continue;
      const q = await h().askReactor(owner, {
        title: `Destiny’s Embrace — ${owner.name}`,
        content: `<p><strong>${esc(ctx.actor?.name ?? "An enemy")}</strong> hits <strong>${esc(ctx.target.name)}</strong> (${int(ctx.total)}).</p><p>Use <strong>Destiny’s Embrace</strong> (your reaction and Foreseen Danger's Focus use) to make them reroll? The second result stands.</p>`,
        buttons: yesNo("Destiny’s Embrace"), step: DESTINY_STEP, data: { itemId: ability.id }
      });
      if (!q?.result?.spent) continue;
      return { reroll: true, label: FEATS.destiny, line: `${esc(owner.name)}'s <strong>Destiny’s Embrace</strong>: ${esc(ctx.actor?.name ?? "the attacker")} rerolls, and the second result stands.` };
    }
    return null;
  }
});

async function destinyStep(actor, answer, data) {
  const item = actor?.items?.get?.(data?.itemId);
  if (!item || usesLeft(item) <= 0) return { spent: false };
  if (!(await h().spendReaction?.(actor, FEATS.destiny, { traits: String(item.system?.traits ?? "") }))) return { spent: false };
  await spendUse(item);
  return { spent: true };
}

/** Confluence Master: two ley lines within reach → "tap both?" → advantage on the Tap. */
export const confluenceMaster = Object.freeze({
  async before(ctx = {}) {
    const actor = ctx.actor;
    if (ctx.type !== "skill" || ctx.check?.actionKey !== "tapLeyLine" || !actor?.isOwner || !ownedFeat(actor, FEATS.confluence)) return null;
    const lines = await leyLinesWithin(ctx.token ?? tokenOf(actor), 30);
    if (lines.length < 2) return null;
    if (!(await confirm(`Confluence Master — ${actor.name}`, `${lines.length} ley lines lie within 30 feet (${lines.map((l) => esc(l.name || "a ley line")).join(", ")}). Do they overlap here (the GM's call), and do you tap both? Advantage on this check; Leyline Power then regains 1d8 PP more.`))) return null;
    await actor.setFlag(MODULE_ID, "eaConfluenceTap", now());
    return { advantage: true, label: FEATS.confluence, line: `${esc(actor.name)} taps two ley lines at once (<strong>Confluence Master</strong>): advantage.` };
  }
});

/** Living Iron: slashing and piercing resisted while PP ≥ 2. */
export async function livingIronReaction(ctx = {}) {
  const target = ctx.target;
  if (!ownedFeat(target, FEATS.livingIron)) return null;
  const resist = livingIronResists({ pp: ppOf(target).value, types: ctx.types });
  if (!resist) return null;
  return { resist, scope: "instance", line: `${esc(target.name)}'s <strong>Living Iron</strong>: resistance to slashing and piercing (${ppOf(target).value} PP).` };
}

/** Chronostasis, holding: resistance to all damage until the next turn starts. */
export async function chronostasisReaction(ctx = {}) {
  const target = ctx.target;
  if (!ownEffects(target, "eaChronostasis").length) return null;
  return { resist: "all", scope: "instance", line: `${esc(target.name)} is in <strong>Chronostasis</strong>: resistance to all damage.` };
}

/** Eternal Vigil (G7): at 0 HP, once a day, Touch of Healing on yourself. */
export const eternalVigilOffer = Object.freeze({
  applies(ctx = {}) {
    const actor = ctx.actor;
    const feat = ownedFeat(actor, FEATS.eternalVigil);
    const spell = ownedSpell(actor, TOUCH_OF_HEALING);
    if (!feat || !spell || usesLeft(feat) <= 0) return false;
    return ppOf(actor).value >= Math.max(1, int(spell.system?.ppCost));
  },
  async offer(ctx = {}) {
    const actor = ctx.actor;
    const feat = ownedFeat(actor, FEATS.eternalVigil);
    const spell = ownedSpell(actor, TOUCH_OF_HEALING);
    if (!feat || !spell) return null;
    const q = await h().askReactor(actor, {
      title: `Eternal Vigil — ${actor.name}`,
      content: `<p>${esc(ctx.sourceName || "The blow")} takes <strong>${esc(actor.name)}</strong> to 0 HP.</p><p>Cast <strong>Touch of Healing</strong> on yourself as a free action (once a day; its PP and warps as normal)? Above 0 HP afterwards, you do not fall.</p>`,
      buttons: yesNo("Touch of Healing"), step: VIGIL_STEP, data: { itemId: feat.id, spellId: spell.id }
    });
    if (!q?.result?.cast) return null;
    return { lines: [line(`<strong>Eternal Vigil</strong>: ${esc(actor.name)} casts Touch of Healing on themself as a free action (today's use spent).`)] };
  }
});

async function vigilStep(actor, answer, data) {
  const feat = actor?.items?.get?.(data?.itemId);
  const spell = actor?.items?.get?.(data?.spellId);
  if (!feat || !spell || usesLeft(feat) <= 0) return { cast: false };
  const me = tokenOf(actor);
  const run = () => h().castSpell(actor, spell, { apPaid: true, presetTargets: Boolean(me) });
  const result = await (me ? withTargets([me.id], run) : run());
  // ONLY A REAL CAST SPENDS THE DAY'S USE (review): castSpell answers null
  // when the Warp? dialog is cancelled or a refusal fires, and `cast: false`
  // when the casting fails; then the use is kept and the card claims nothing.
  if (!result?.cast) return { cast: false };
  await spendUse(feat);
  return { cast: true };
}

/* ------------------------------------------------------------------ */
/* Seams                                                                */
/* ------------------------------------------------------------------ */

/** Eternal Vigil's warp (Q108), for registerSpellWarps. */
export const VIGIL_WARPS = Object.freeze([Object.freeze({
  match: Object.freeze({ traits: ["healing"] }),
  warp: Object.freeze({ ppCost: VIGIL_WARP_PP, text: "(Eternal Vigil) gain fast healing 5 for a number of rounds equal to the PP of the spell cast (before applying this option).", mods: Object.freeze({ unlocks: [VIGIL_UNLOCK] }) })
})]);

/** Leywalk: +2 status to Ley Walker's casting check. */
export async function leywalkGate(ctx = {}) {
  if (norm(ctx.spell?.name) !== norm(LEY_WALKER) || !ownedFeat(ctx.actor, FEATS.leywalk)) return null;
  return { modifiers: [{ label: FEATS.leywalk, value: LEYWALK_BONUS, type: "status" }] };
}

/** Ley Walker's requirement: within 30 ft of a ley line (or one anchored by Leyline Anchor). */
export async function leyWalkerRefusal(ctx = {}) {
  if (norm(ctx.spell?.name) !== norm(LEY_WALKER) || ctx.itemCast) return null;
  const actor = ctx.actor;
  if (ownEffects(actor, "eaLeylineAnchor").length) return null;
  const token = tokenOf(actor);
  if (!token) return null;
  if ((await leyLinesWithin(token, LEY_WALKER_FEET)).length) return null;
  return `Ley Walker: you must be within ${LEY_WALKER_FEET} feet of a ley line you can perceive (none is on the map within reach).`;
}

/* ------------------------------------------------------------------ */
/* Leyline Weaver's Tap, for Block 2                                    */
/* ------------------------------------------------------------------ */

/**
 * LEYLINE WEAVER'S LADDER. Block 2's Tap Ley Line branch (block2-automations.mjs
 * `onActionResolvedB2`) must call this first and stop when it answers true:
 *
 *   if (await leylineWeaverTap(actor, { degree: k, level: L, title })) return;
 *
 * True when the actor owns Leyline Weaver and the degree is one it replaces
 * (Critical, Success, Partial); false otherwise (the action's own result).
 */
export async function leylineWeaverTap(actor, { degree, level, title = "Tap Ley Line" } = {}) {
  if (!ownedFeat(actor, FEATS.leylineWeaver)) return false;
  const rung = leylineWeaverRung(degree);
  if (!rung) return false;
  const L = Math.max(1, int(level));
  const expiry = expiryFor(rung.expiry, actor);
  const until = rung.expiry === "endOfNextTurn" ? "until the end of your next turn" : "until the end of your turn";
  const heading = `${title} (Leyline Weaver): ${rung.factor > 1 ? "benefits ×2 " : ""}${until}`;
  const applyOne = async (depth = 0) => {
    const total = await rollTotal("1d100");
    const row = rowFor(LEY_LINE_EFFECTS, total);
    const lines = [line(`d100 <strong>${total}</strong>: ${esc(row?.effect ?? "")}`)];
    if (row?.e?.kind === "reroll") {
      await card(actor, heading, [...lines, line("Two benefits from this table.")]);
      if (depth > 0) return;
      for (let i = 0; i < int(row.e.times); i += 1) {
        let again = await rollTotal("1d100");
        while (again === row.e.skip) again = await rollTotal("1d100");
        await applyRolled(again);
      }
      return;
    }
    await applyRolled(total, lines);
  };
  const applyRolled = async (total, lead = null) => {
    const row = rowFor(LEY_LINE_EFFECTS, total);
    const spec = doubledLeySpec(row?.e, L, rung.factor);
    const lines = lead ?? [line(`d100 <strong>${total}</strong>: ${esc(row?.effect ?? "")}`)];
    if (rung.factor > 1 && spec === row?.e && spec?.kind !== "defence" && spec?.kind !== "cond") lines.push(line("<em>Leyline Weaver's ×2: any number in this result is doubled (the GM's, as the result is).</em>"));
    lines.push(...await applyRow(actor, spec, { level: L, text: row?.effect ?? "", title: heading, expiry, source: "leyLineEffect" }));
    await card(actor, heading, lines);
  };
  await applyOne();
  if (rung.pp) {
    const gained = await rollTotal(rung.pp);
    const pp = await gainPP(actor, gained);
    await card(actor, `${title} (Leyline Weaver)`, [line(`You regain <strong>${gained} PP</strong> (${rung.pp}): PP ${pp.before} → ${pp.after}${pp.capped ? " (capped at your maximum)" : ""}.`)]);
  }
  return true;
}

/* ------------------------------------------------------------------ */
/* Hook handlers                                                        */
/* ------------------------------------------------------------------ */

/** Hooks.on("trgPrimeSpellSettled"): Eternal Vigil's fast healing; Shard Cloud raised. */
export async function onSpellSettledB6B1(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner) return;
  if (vigilWarpBought(ctx) && ownedFeat(actor, FEATS.eternalVigil)) {
    const rounds = vigilRounds(ctx.castPP ?? ctx.ppSpent);
    const targets = Array.from(ctx.targets ?? game.user?.targets ?? []).map((t) => t?.actor ?? t).filter(Boolean);
    const who = targets.length ? targets : [actor];
    for (const target of who) {
      await h().createEffectsOn(target, [effectData("eaEternalVigil", {
        name: `Eternal Vigil: Fast Healing ${VIGIL_FAST_HEALING}`, img: "icons/svg/regen.svg",
        description: `Fast healing ${VIGIL_FAST_HEALING} for ${rounds} round${rounds === 1 ? "" : "s"} (${actor.name}'s Eternal Vigil).`,
        system: vigilFastHealingFlags(), expiry: forSeconds(6 * rounds)
      })]);
    }
    await card(actor, FEATS.eternalVigil, [line(`${who.map((a) => esc(a.name)).join(", ")}: <strong>fast healing ${VIGIL_FAST_HEALING}</strong> for <strong>${rounds} round${rounds === 1 ? "" : "s"}</strong> (the spell's ${int(ctx.castPP ?? ctx.ppSpent)} PP less this option's ${VIGIL_WARP_PP}).`)]);
  }
  if (norm(ctx.spell?.name) === norm(SHARD_CLOUD) && ctx.cast && !ctx.refunded) {
    const { dice, feet } = shardCloudOf(ctx.warpMods);
    const old = ownEffects(actor, "eaShardCloud").map((e) => e.id);
    if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old);
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("eaShardCloud", {
      name: `Shard Cloud (${dice}d6, ${feet} ft)`, img: "icons/svg/sword.svg",
      description: `Shard Cloud: ${dice}d6 slashing (basic Reflex, DC ${spellDC(actor)}) to a creature other than you starting its turn within ${feet} ft, or entering it.`,
      module: { dice, feet, dc: spellDC(actor), entered: {} }, expiry: forSeconds(SHARD_SECONDS)
    })]);
    await card(actor, SHARD_CLOUD, [line(`The shards whirl around you: <strong>${dice}d6 slashing</strong> (basic Reflex, DC ${spellDC(actor)}) to each creature but you that starts its turn within <strong>${feet} feet</strong>, or enters it, while you sustain the spell.`)]);
  }
}

/** One Shard Cloud bite. */
async function shardBite(caster, cloud, victim, why) {
  const m = cloud.flags?.[MODULE_ID] ?? {};
  const out = await h().basicSaveHit({ caster, target: victim, save: "reflex", dc: int(m.dc), label: `${caster.name}'s Shard Cloud`, formula: `${Math.max(1, int(m.dice))}d6`, type: "slashing", baseDamage: "1d6" });
  await card(caster, SHARD_CLOUD, [line(`${esc(victim.name)} ${why}: ${out?.line ?? ""}`)]);
}

/** The live clouds on the scene, and their casters' tokens; lapsed ones are cleared. */
async function liveClouds() {
  const out = [];
  for (const t of tokens()) {
    for (const cloud of ownEffects(t.actor, "eaShardCloud")) {
      if (!sustains(t.actor, SHARD_CLOUD)) { await t.actor.deleteEmbeddedDocuments("ActiveEffect", [cloud.id]); continue; }
      out.push({ token: t, caster: t.actor, cloud });
    }
  }
  return out;
}

/**
 * Hooks.on("trgPrimeTurnEnded") (fired on the acting GM): Last Horizon's
 * waived turn ends; the creature whose turn now begins is bitten by every
 * Shard Cloud it stands in.
 */
export async function onTurnEndedB6B1(ctx = {}) {
  if (!isActingGM()) return;
  await lastHorizonTurnEnd(ctx);
  const combat = ctx.combat ?? game.combat;
  const next = combat?.combatant?.actor;
  const nextToken = combat?.combatant?.token?.object ?? tokenOf(next);
  if (!next || !nextToken) return;
  for (const { token, caster, cloud } of await liveClouds()) {
    if (caster === next) continue;
    const d = feetBetween(token, nextToken);
    if (d === null || d > int(cloud.flags?.[MODULE_ID]?.feet)) continue;
    await shardBite(caster, cloud, next, "starts its turn in the shards");
  }
}

/** Hooks.on("updateToken", (doc, change)) (acting GM, in combat): a creature entering a Shard Cloud, once a round. */
export async function onTokenMovedB6B1(doc, change = {}) {
  if (!("x" in (change ?? {})) && !("y" in (change ?? {}))) return;
  if (!isActingGM() || !game.combat?.started) return;
  const mover = doc?.object ?? null;
  const victim = doc?.actor;
  if (!mover || !victim) return;
  const round = `${game.combat.id}:${game.combat.round}`;
  for (const { token, caster, cloud } of await liveClouds()) {
    if (caster === victim || token === mover) continue;
    const m = cloud.flags?.[MODULE_ID] ?? {};
    const d = feetBetween(token, mover);
    if (d === null || d > int(m.feet)) continue;
    const key = String(mover.id);
    if (m.entered?.[key] === round) continue;
    await cloud.update?.({ [`flags.${MODULE_ID}.entered.${key}`]: round });
    await shardBite(caster, cloud, victim, "enters the shards");
  }
}

/** Hooks.on("trgPrimeDeathGuardHeld"): Chronostasis holds — 1 HP, not below, resist all, until the next turn. */
export async function onDeathGuardHeldB6B1(ctx = {}) {
  const actor = ctx.actor;
  if (ctx.label !== "Chronostasis" || ctx.trigger !== "zeroHp" || !actor) return;
  await h().createEffectsOn(actor, [effectData("eaChronostasis", {
    name: "Chronostasis", img: "icons/svg/clockwork.svg",
    description: "Chronostasis: you cannot be reduced below 1 HP and resist all damage until the start of your next turn; then, unless healed, Dying.",
    system: { deathGuard: { label: "Chronostasis (holding)", auto: true } },
    expiry: expiryFor("startOfNextTurn", actor)
  })]);
  await card(actor, FEATS.chronostasis, [line(`${esc(actor.name)} enters <strong>Chronostasis</strong>: 1 HP, and cannot be reduced below it, with resistance to all damage, until the start of their next turn. Then, unless healed, Dying.`)]);
}

const effectActor = (effect) => (effect?.parent?.documentName === "Actor" ? effect.parent : null);
const dyingOf = (effect) => {
  const s = effect?.statuses;
  return (s instanceof Set ? Array.from(s) : Array.isArray(s) ? s : []).map(norm).includes("dying");
};

/** Hooks.on("deleteActiveEffect"): Chronostasis ends — Dying as normal unless healed. */
export async function onEffectDeletedB6B1(effect) {
  const actor = effectActor(effect);
  if (!actor?.isOwner || !actsFor(actor) || effect.getFlag?.(MODULE_ID, "source") !== "eaChronostasis") return;
  if (int(actor.system?.resources?.hp?.value) > 1) {
    await card(actor, FEATS.chronostasis, [line(`Chronostasis ends: ${esc(actor.name)} was healed (${int(actor.system.resources.hp.value)} HP) and does not gain Dying.`)]);
    return;
  }
  await actor.update({ "system.resources.hp.value": 0 });
  await actor.toggleStatusEffect?.("dying", { value: 1 });
  await card(actor, FEATS.chronostasis, [line(`Chronostasis ends: ${esc(actor.name)} drops to <strong>0 HP</strong> and gains <strong>Dying 1</strong> as normal.`)]);
}

/** Hooks.on("createActiveEffect"): Dying gained → Last Horizon. */
export async function onEffectCreatedB6B1(effect) {
  const actor = effectActor(effect);
  if (!actor?.isOwner || !actsFor(actor) || !dyingOf(effect)) return;
  const feat = ownedFeat(actor, FEATS.lastHorizon);
  if (!feat || usesLeft(feat) <= 0) return;
  const last = Number(actor.getFlag?.(MODULE_ID, "eaLastHorizonAt"));
  if (Number.isFinite(last) && now() - last < LAST_HORIZON_SECONDS) return;
  if (!(await confirm(`Last Horizon — ${actor.name}`, "You gain the Dying condition. Use <strong>Last Horizon</strong> (its Focus use): stay conscious, and your next Dying check is not rolled — you act normally on your next turn?"))) return;
  if (!(await spendUse(feat))) return;
  await actor.update({
    [`flags.${SYSTEM_ID}.consciousWhileDying`]: effect.id,
    [`flags.${SYSTEM_ID}.dyingCheckWaived`]: { effect: effect.id, label: FEATS.lastHorizon, actNormally: true },
    [`flags.${MODULE_ID}.eaLastHorizonAt`]: now(),
    [`flags.${MODULE_ID}.eaLastHorizonDying`]: effect.id
  });
  await card(actor, FEATS.lastHorizon, [line(`${esc(actor.name)} clings on (<strong>Last Horizon</strong>): conscious while Dying; the next Dying check is not rolled and they act normally that turn. Unless healed, Dying acts as normal from the end of that turn.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
}

/**
 * The end of the turn whose Dying check Last Horizon waived (G7: the core
 * skips that check and clears the waiver): Dying acts as normal from here —
 * the creature is no longer kept conscious. Run by onTurnEndedB6B1.
 */
async function lastHorizonTurnEnd(ctx = {}) {
  const actor = ctx.actor ?? ctx.combatant?.actor;
  const dyingId = actor?.getFlag?.(MODULE_ID, "eaLastHorizonDying");
  if (!actor || !dyingId) return;
  // The waiver is spent by the core at the check; until then the turn is not the waived one.
  if (actor.getFlag?.(SYSTEM_ID, "dyingCheckWaived")) return;
  await actor.unsetFlag(MODULE_ID, "eaLastHorizonDying");
  await actor.unsetFlag(SYSTEM_ID, "consciousWhileDying");
  if (Array.from(actor.effects ?? []).some((e) => e.id === dyingId)) await card(actor, FEATS.lastHorizon, [line(`Last Horizon ends: ${esc(actor.name)} is still Dying, and it acts as normal.`)]);
}

/** Hooks.on("trgPrimeActionResolved"): Leyline Power, Leyline Anchor after a successful Tap. */
export async function onActionResolvedB6B1(ctx = {}) {
  const { actor, action } = ctx;
  if (action?.key !== "tapLeyLine" || !actor?.isOwner) return;
  // Block 2's plan for this Tap, read before Block 2's own handler clears it.
  const plan = actor.getFlag?.(MODULE_ID, "block2Plan") ?? null;
  const degree = norm(ctx.resolvedDegree ?? ctx.degree);
  if (!SUCCESSES.includes(degree)) return;
  const crit = degree !== "success";
  const confluenceAt = Number(actor.getFlag?.(MODULE_ID, "eaConfluenceTap"));
  const confluence = Number.isFinite(confluenceAt) && now() - confluenceAt <= 60;
  if (confluence) await actor.unsetFlag?.(MODULE_ID, "eaConfluenceTap");
  const power = ownedFeat(actor, LEYLINE_POWER);
  if (power && usesLeft(power) > 0 && !(await reactionBlocked(actor, power.system?.traits ?? ""))
    && (await confirm(`Leyline Power — ${actor.name}`, `Your Tap Ley Line came out a ${esc(degree)}. Use <strong>Leyline Power</strong> (your reaction and its Focus use) to regain ${crit ? "2d8" : "1d8"}${confluence ? " + 1d8 (Confluence Master)" : ""} PP?`))) {
    if (await h().spendReaction?.(actor, LEYLINE_POWER, { traits: String(power.system?.traits ?? "") })) {
      await spendUse(power);
      const formula = `${crit ? 2 : 1}d8${confluence ? " + 1d8" : ""}`;
      const gained = await rollTotal(formula);
      const pp = await gainPP(actor, gained);
      await card(actor, LEYLINE_POWER, [line(`You regain <strong>${gained} PP</strong> (${formula}${confluence ? ", the extra 1d8 Confluence Master's" : ""}): PP ${pp.before} → ${pp.after}${pp.capped ? " (capped at your maximum)" : ""}.`), line("<em>Reaction and Focus use spent — Refocus restores the use.</em>")]);
    }
  }
  const anchor = ownedFeat(actor, FEATS.anchor);
  if (anchor && usesLeft(anchor) > 0 && !ownEffects(actor, "eaLeylineAnchor").length
    && (await confirm(`Leyline Anchor — ${actor.name}`, `Anchor ${esc(plan?.name || "this ley line")} to yourself for 1 minute (today's use)?`))) {
    await spendUse(anchor);
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("eaLeylineAnchor", {
      name: `Leyline Anchor: ${plan?.name || "ley line"}`, img: "icons/svg/anchor.svg",
      description: "Leyline Anchor: you count as within 30 ft of the anchored ley line; Leyline Power's Use regains 1d8 PP once a round.",
      module: { regionId: plan?.regionId ?? "", level: int(plan?.level), name: plan?.name ?? "" }, expiry: forSeconds(ANCHOR_SECONDS)
    })]);
    await card(actor, FEATS.anchor, [line(`<strong>${esc(plan?.name || "The ley line")}</strong> is anchored to you for 1 minute: Leyline Power's Use regains 1d8 PP once a round without re-tapping.`), line("<em>Today's use spent. Tap and Channel Ley Line still read the map's 30 feet: the anchored line counting as near is the GM's.</em>")]);
  }
}

/** Hooks.on("updateActor", (actor, change)): a fresh infusion (Block 4) → today's Runeblade Runes. */
export async function onActorUpdatedB6B1(actor, change = {}) {
  if (!freshInfusion(change) || !actor?.isOwner || !actsFor(actor) || !ownedFeat(actor, FEATS.runeblade)) return;
  const inf = infusionOf(actor);
  if (!inf?.weaponId) return;
  await chooseRunebladeRunes(actor, String(change.flags[SYSTEM_ID][INFUSION_FLAG].runes ?? inf.runes ?? ""));
}

/** Hooks.on("createItem"): Runeblade arrives → its Book of Infusions entries. */
export async function onItemCreatedB6B1(item) {
  const actor = item?.parent;
  if (item?.type !== "feat" || norm(item.name) !== norm(FEATS.runeblade) || !actor?.isOwner || !actsFor(actor)) return;
  await fillRunebladeBook(actor);
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const REACTIONS_B6_B1 = Object.freeze({ fatespinnerReroll, damagingGambit, foreseenDanger, destinysEmbrace, confluenceMaster, livingIronReaction, chronostasisReaction, eternalVigilOffer });
export const STEPS_B6_B1 = Object.freeze({
  [FATESPINNER_STEP]: convictionStep, [GAMBIT_STEP]: convictionStep, [FORESEEN_STEP]: foreseenStep, [DESTINY_STEP]: destinyStep, [VIGIL_STEP]: vigilStep
});

/** Every registration group B1 makes; called once from registerContent (trgPrime.registerContent). */
export function registerBlock6B1(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_B1)) api.registerFeatAutomation(name, entry, moduleId);
  for (const [name, hint] of Object.entries(PASSIVE_B6_B1)) api.registerPassiveAutomation?.(name, hint, moduleId);
  api.registerSpellWarps?.(FEATS.eternalVigil, VIGIL_WARPS.map((w) => ({ match: { ...w.match, traits: [...w.match.traits] }, warp: { ...w.warp, mods: { unlocks: [...w.warp.mods.unlocks] } } })), moduleId);
  api.registerUnconsciousOffer?.("eternalVigil", eternalVigilOffer, moduleId);
  api.registerCheckReaction?.("fatespinnerReroll", fatespinnerReroll, moduleId);
  api.registerCheckReaction?.("damagingGambit", damagingGambit, moduleId);
  api.registerCheckReaction?.("foreseenDanger", foreseenDanger, moduleId);
  api.registerCheckReaction?.("destinysEmbrace", destinysEmbrace, moduleId);
  api.registerCheckReaction?.("confluenceMaster", confluenceMaster, moduleId);
  api.registerDamageReaction?.("livingIron", livingIronReaction, moduleId);
  api.registerDamageReaction?.("chronostasis", chronostasisReaction, moduleId);
  api.registerSpellCheckGate?.("leywalk", leywalkGate, moduleId);
  api.registerCastRefusal?.("leyWalker", leyWalkerRefusal, moduleId);
  for (const [name, run] of Object.entries(STEPS_B6_B1)) api.registerReactionStep?.(name, run, moduleId);
}
