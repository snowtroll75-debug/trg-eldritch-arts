/**
 * Eldritch Arts — Block 5, group B (0.8.0, on TRG Prime 3.683.0): what the
 * Emberkin and Nyrinn racial feats DO that is not data.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix B, as Graham answered
 * it on 3 November 2026 (Q67–Q75 as proposed). The pure rules are exported
 * first so the harness can run them; the Foundry side follows.
 *
 *   Uses              Elemental Apotheosis, Elemental Step, Emberkin Scholar,
 *                     Nyrinn Scholar, Eclipsed Form, Voidborn Wings; Vir-ellian
 *                     Release with Crystal Pulse (replaces Block 1's entry)
 *   Check reactions   Anchor in Nothing, Voidbound Resolve, Tideweaver's
 *                     Resilience (submerged), Veilstride, Mindshroud (C2)
 *   Damage reaction   Eclipsed Form (Q68)
 *   Dispel modifier   Threadbreaker's Precision (C9, Q67)
 *   Hooks             damage taken (Bulwark, Reprisal, Zeal), a cast settled
 *                     (Mantle), items, level, daily preparation (Vein of Power,
 *                     the Scholars, Voidbound's uses), effects and tokens
 *                     (flight, the glide, landing, Shadow Initiate's speed),
 *                     turn ends (the wings' rounds, the glide)
 *
 * BLOCK 1 IS READ, NOT EDITED: the heritage element (`eaElement`), Magic
 * Drain's stored energy, the Null Aura's reach (Silent Veil's bonus is read by
 * `nullAuraFeet` once the lead adds it there: `nullAuraBonusFeet` below).
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, owned, tokenOf, tokenCentre, feetBetween, spendAP, AUTOMATIONS as BLOCK1_AUTOMATIONS } from "./block1-automations.mjs";
import { pickPoint, actsFor } from "./block3-automations.mjs";

/* ------------------------------------------------------------------ */
/* Names and sources                                                    */
/* ------------------------------------------------------------------ */

/** The feats' names, matched case-insensitively (as the core matches them). */
export const N = Object.freeze({
  echo: "Echo of the Ancestors", apotheosis: "Elemental Apotheosis", bulwark: "Elemental Bulwark", reprisal: "Elemental Reprisal",
  step: "Elemental Step", fury: "Emberborn Fury", emberkinScholar: "Emberkin Scholar", mantle: "Mantle of Essence",
  zeal: "Stormrunner’s Zeal", tideweaver: "Tideweaver’s Resilience", vein: "Vein of Power",
  anchor: "Anchor in Nothing", crystal: "Crystal Pulse", eclipsed: "Eclipsed Form", mindshroud: "Mindshroud",
  nyrinnScholar: "Nyrinn Scholar", shadowInitiate: "Shadow Initiate", silentVeil: "Silent Veil",
  threadbreaker: "Threadbreaker’s Precision", veilstride: "Veilstride", grace: "Voidborn Grace",
  voidbound: "Voidbound Resolve", wings: "Voidborn Wings"
});

/** This module's effect sources (flags.trg-eldritch-arts.source). */
export const SRC = Object.freeze({
  apotheosis: "elementalApotheosis", bulwark: "elementalBulwark", mantle: "mantleOfEssence", zeal: "stormrunnersZeal",
  wings: "voidbornWings", glide: "voidbornGlide", eclipsed: "eclipsedForm", shadow: "shadowInitiate"
});
/** The effects that grant a fly speed through their feat. */
export const FLIGHT_SOURCES = Object.freeze({ [SRC.zeal]: N.zeal, [SRC.wings]: N.wings });

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);

/** The Emberkin heritage's element (Block 1's `eaElement`), or "". */
export function heritageElement(list = []) {
  const her = Array.from(list ?? []).find((i) => i?.type === "heritage");
  return norm(her?.flags?.[SYSTEM_ID]?.eaElement);
}
/** Does this damage meet the element? */
export const elementTaken = (damageTypes = [], element = "") => Boolean(element) && Array.from(damageTypes ?? []).map(norm).includes(norm(element));

/** "1d4 damage per 2 levels" (Elemental Reprisal; Voidbound Resolve's backlash), at least one die. */
export const perTwoLevelsD4 = (level) => `${Math.max(1, Math.floor(Math.max(0, int(level)) / 2))}d4`;
/** Mantle of Essence: +1, and +1 at 5th and every 5 levels thereafter. */
export const mantleBonus = (level) => 1 + Math.floor(Math.max(0, int(level)) / 5);
/** Vein of Power: a +1 Spell Adder, +1 at 5th and every 5 levels thereafter. */
export const veinAdder = (level) => 1 + Math.floor(Math.max(0, int(level)) / 5);
/** Voidborn Wings: "your level + your Dexterity modifier" rounds (the Dexterity total, the system's ability bonus). */
export const wingsRounds = (level, dexterity) => Math.max(0, int(level) + int(dexterity));
/** Voidborn Grace: 60 feet a round. */
export const GLIDE_FEET = 60;
export const glideStep = (elevation) => Math.max(0, Math.max(0, Number(elevation) || 0) - GLIDE_FEET);
/** Crystal Pulse: the release's d4s and 1d4 more (Q69), of force or electricity. */
export const CRYSTAL_TYPES = Object.freeze(["force", "electricity"]);
export const crystalFormula = (energy) => `${Math.max(0, int(energy)) + 1}d4`;
/** "Light level 5 (Dim Light) or less", the ambient level (Q61); unknown light is not dark. */
export const darkEnough = (level) => level !== null && level !== undefined && Number.isFinite(Number(level)) && Number(level) <= 5;
/** Veilstride (Q72): 10 ft of own movement since the last Veilstride advantage this turn, in light 5 or less. */
export const veilstrideDue = ({ feet = 0, usedAt = 0, light = null } = {}) => darkEnough(light) && Number(feet) - Number(usedAt) >= 10;
/** Voidbound Resolve (Q73): a Success that would have failed without the +2. */
export function voidboundCaused({ succeeded = false, total = null, dc = null, bonus = 2 } = {}) {
  if (!succeeded || dc === null || dc === undefined || total === null || total === undefined) return false;
  const t = Number(total), d = Number(dc);
  return Number.isFinite(t) && Number.isFinite(d) && t - Number(bonus) < d;
}
/** Voidbound Resolve's "targeted by a spell that requires a Will save": a Will save, not an area, forced by someone else. */
export const voidboundAsks = (ctx = {}) => ctx.type === "save" && norm(ctx.subject) === "will" && !ctx.isArea
  && Boolean(String(ctx.saveSource ?? "").trim()) && Boolean(ctx.sourceUuid) && ctx.sourceUuid !== ctx.actor?.uuid;

/** Eclipsed Form (Q68): the physical types it halves. */
export const PHYSICAL = Object.freeze(["bludgeoning", "piercing", "slashing"]);
/** Is a weapon a magical source, as the core decides a Strike is (a Potency rune, or a morph's magical strike)? */
export const weaponIsMagical = (w) => Boolean(w?.system?.runeModifiers?.potency) || w?.flags?.[SYSTEM_ID]?.magicalStrike === true;
/** Every wielded weapon of the attacker dealing this type is magical (and it has one): read as a magical blow. */
export function attackerBlowMagical(attacker, type) {
  const wielded = items(attacker).filter((i) => i.type === "weapon" && i.system?.equipped !== false && norm(i.system?.damageType) === norm(type));
  return wielded.length > 0 && wielded.every(weaponIsMagical);
}
/** Eclipsed Form's answer to a blow, or null. `magicalFor(type)` reads the attacker. */
export function eclipsedAnswer(ctx = {}, magicalFor = () => false) {
  if (ctx.kind !== "weapon" || ctx.magical) return null;
  const types = Array.from(ctx.types ?? []).map(norm).filter((t) => PHYSICAL.includes(t) && !magicalFor(t));
  return types.length ? { resist: types, scope: "instance" } : null;
}

/** Silent Veil (and anything like it): feet the owned feats add to the Null Aura. */
export function nullAuraBonusFeet(list = []) {
  return Array.from(list ?? []).filter((i) => i?.type === "feat").reduce((n, i) => n + Math.max(0, int(i.flags?.[SYSTEM_ID]?.eaNullAuraBonus)), 0);
}

/**
 * Threadbreaker's Precision's Dazed 1 "for 1 round" (Q67: until the end of its
 * next turn): the core's own reading of that phrase, two round boundaries
 * (effect-duration.mjs), in combat; six seconds of world time out of it.
 */
export function dazedTag({ inCombat = false, round = 0, worldTime = 0 } = {}) {
  return inCombat ? { key: "dazed", value: 1, expiresRound: int(round) + 2 } : { key: "dazed", value: 1, expiresTime: Math.trunc(Number(worldTime) || 0) + 6 };
}

/** The fly speed (and Voidborn Grace's Hover) a feat declares while its flight lasts. */
export function flightDerives(on, { hover = false } = {}) {
  if (!on) return null;
  return { movement: { key: "fly", orLand: true }, ...(hover ? { hover: true } : {}) };
}

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const featOf = (actor, name) => owned(actor, name, ["feat"]);
/** The acting GM: the one client a GM-only hook runs on. */
const fighting = (actor) => Boolean(combatFor(actor));
const worldNow = () => Number(globalThis.game?.time?.worldTime ?? 0);
const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return Number(h().itemUsesRemaining(item) ?? 0);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}
async function fromUuidSafe(uuid) {
  if (!uuid) return null;
  try {
    const doc = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(uuid);
    return doc?.documentName === "Token" ? (doc.actor ?? null) : (doc?.actor && doc.documentName !== "Actor" ? doc.actor : doc) ?? null;
  } catch {
    return null;
  }
}
const ownTurn = (actor) => {
  const combat = combatFor(actor);
  const active = combat?.combatant?.actor ?? null;
  return Boolean(active && (active === actor || (active.uuid && active.uuid === actor?.uuid)));
};

/** Teleport the actor's token to a clicked square within `feet` (as Block 4's Dimensional Step). Feet moved, or false. */
async function teleportWithin(actor, feet, label) {
  const token = tokenOf(actor);
  if (!token) return warn(`${label}: place your token on the map first.`);
  const point = await pickPoint(`${label}: click where you teleport (up to ${feet} ft). Escape cancels.`);
  if (!point) return false;
  const grid = canvas.grid;
  const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x, y: point.y };
  const dist = grid.measurePath([tokenCentre(token), { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
  if (dist > feet) return warn(`${label}: that is ${Math.round(dist)} feet away; you may teleport up to ${feet} feet.`);
  const src = token.document._source ?? token.document;
  const was = { x: src.x, y: src.y };
  await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
  const now = token.document._source ?? token.document;
  if (now.x === was.x && now.y === was.y) return warn(`${label}: the teleport was refused (see the notice), so nothing is spent.`);
  return Math.max(1, Math.round(dist));
}

/* ------------------------------------------------------------------ */
/* Effects                                                              */
/* ------------------------------------------------------------------ */

const custom = (key, value) => ({ key, mode: 0, value: String(value), priority: 20 });

export function bulwarkEffect(actor) {
  return effectData(SRC.bulwark, {
    name: "Elemental Bulwark (+1 racial DB and saves)", img: "icons/svg/shield.svg",
    description: "Elemental Bulwark: +1 racial bonus to DB and saving throws until the start of your next turn.",
    changes: [custom("system.combat.defence.racial", 1), ...["fortitude", "reflex", "will"].map((s) => custom(`system.combat.saves.${s}.racial`, 1))],
    expiry: expiryFor("startOfNextTurn", actor)
  });
}
export function mantleEffect(actor, bonus) {
  return effectData(SRC.mantle, {
    name: `Mantle of Essence (+${bonus} DB)`, img: "icons/svg/aura.svg",
    description: `Mantle of Essence: +${bonus} circumstance bonus to DB until the beginning of your next turn.`,
    changes: [custom("system.combat.defence.circumstance", bonus)],
    expiry: expiryFor("startOfNextTurn", actor)
  });
}
export function apotheosisEffect(element) {
  return effectData(SRC.apotheosis, {
    name: `Elemental Apotheosis: immune to ${element}`, img: "icons/svg/fire-shield.svg",
    description: `Elemental Apotheosis: immunity to ${element} for 1 minute; your ${element} damage inflicts an additional point per die.`,
    changes: [{ key: "system.combat.immunities", mode: 2, value: `, ${element}`, priority: 20 }],
    system: { spellDamageBonus: { label: "Elemental Apotheosis", perDie: 1, damageTypes: [element], type: "untyped" } },
    module: { element },
    expiry: forSeconds(60)
  });
}
export function zealEffect(actor) {
  return effectData(SRC.zeal, {
    name: "Stormrunner’s Zeal: flying", img: "icons/svg/wing.svg",
    description: "Stormrunner’s Zeal: a fly speed equal to your land speed until the end of your next turn.",
    expiry: expiryFor("endOfNextTurn", actor)
  });
}
export function wingsEffect(rounds) {
  return effectData(SRC.wings, {
    name: `Voidborn Wings (${rounds} rounds)`, img: "icons/svg/wing.svg",
    description: `Voidborn Wings: a fly speed equal to your land speed for ${rounds} rounds. Landing ends it.`,
    module: { rounds, tookOff: false },
    expiry: forSeconds(Math.max(1, rounds) * 6)
  });
}
export function glideEffect() {
  return effectData(SRC.glide, {
    name: "Voidborn Grace: gliding", img: "icons/svg/wing.svg",
    description: "Voidborn Grace: you descend 60 feet a round, taking no damage unless interrupted (grappled or knocked prone).",
    expiry: forSeconds(600)
  });
}
export function eclipsedEffect(actor) {
  return effectData(SRC.eclipsed, {
    name: "Eclipsed Form", img: "icons/svg/invisible.svg",
    description: "Eclipsed Form: until the start of your next turn, half damage from non-magical physical attacks; you can move through solid objects (but not end your turn inside one).",
    expiry: expiryFor("startOfNextTurn", actor)
  });
}
export function shadowInitiateEffect() {
  return effectData(SRC.shadow, {
    name: "Shadow Initiate: +5 ft (dim light)", img: "icons/svg/walk.svg",
    description: "Shadow Initiate: in light level 5 (Dim Light) or less, your movement speed increases by 5 ft.",
    changes: [custom("system.combat.movement.land.racial", 5)]
  });
}

/* ------------------------------------------------------------------ */
/* The Uses                                                             */
/* ------------------------------------------------------------------ */

const elementalApotheosis = {
  hint: "1 AP (Focus): immunity to your heritage's element for 1 minute, and +1 a die of it.",
  async use(actor) {
    const element = heritageElement(actor.items);
    if (!element) return warn("Elemental Apotheosis: your heritage names no element (add your Emberkin heritage first).");
    if (!(await spendAP(actor, "Elemental Apotheosis", 1))) return false;
    await h().createEffectsOn(actor, [apotheosisEffect(element)]);
    await card(actor, "Elemental Apotheosis", [
      line(`You are <strong>immune to ${esc(element)}</strong> for 1 minute, and your ${esc(element)} damage gains +1 a die rolled.`),
      ...(fighting(actor) ? [line("1 AP spent.")] : []),
      line("<em>Focus use spent — Refocus restores it.</em>")
    ]);
    return true;
  }
};

const elementalStep = {
  hint: "1 AP (Focus): teleport up to your land speed.",
  async use(actor, item) {
    const action = { key: "elementalStep", traits: String(item?.system?.traits ?? "Concentrate, Focus, Teleportation") };
    if (!(await h().traitGate(actor, action, "Elemental Step"))) return false;
    if (fighting(actor) && int(actor.system?.resources?.ap?.value) < 1) return warn("Elemental Step: 1 AP required.");
    const feet = Math.max(0, int(actor.system?.combat?.movement?.land?.total));
    if (!feet) return warn("Elemental Step: you have no land speed.");
    const moved = await teleportWithin(actor, feet, "Elemental Step");
    if (!moved) return false;
    if (!(await spendAP(actor, "Elemental Step", 1))) return false;
    await h().recordTraitUsage(actor, action);
    await card(actor, "Elemental Step", [line(`You dissolve into elemental energy and teleport ${moved} feet, provoking no attacks of opportunity.`), ...(fighting(actor) ? [line("1 AP spent.")] : [])]);
    return true;
  }
};

/** The specialist skill entries, `[slug, label]`. */
const specialistEntries = (actor) => Object.entries(actor?.system?.specialistSkills ?? {}).map(([slug, s]) => [slug, String(s?.label ?? slug)]);

async function scholarBonus(actor, item, { title, slug, label }) {
  await h().replaceFeatEffect(actor, item, {
    name: `${title}: ${label} +2`, img: item.img,
    changes: [{ key: `system.specialistSkills.${slug}.racial`, mode: 2, value: "2", priority: 20 }]
  });
  await card(actor, title, [line(`+2 racial bonus to your racial specialist skill, <strong>${esc(label)}</strong>.`)]);
  return true;
}

/** Emberkin Scholar: the race's Elemental Lore, found; asked only when it is missing. */
async function emberkinScholarApply(actor, item, { quiet = false } = {}) {
  const entries = specialistEntries(actor);
  const lore = entries.find(([, label]) => norm(label) === "elemental lore");
  if (lore) return scholarBonus(actor, item, { title: N.emberkinScholar, slug: lore[0], label: lore[1] });
  if (quiet) {
    await card(actor, N.emberkinScholar, [line("Your sheet has no <strong>Elemental Lore</strong> specialist skill yet. Press <strong>Use</strong> on Emberkin Scholar once it has your racial specialist skill.")]);
    return false;
  }
  if (!entries.length) return warn("Emberkin Scholar: this character has no specialist skills yet — add Elemental Lore on the Skills tab first.");
  const slug = await h().chooseFromList(N.emberkinScholar, "Your racial specialist skill, for the +2 racial bonus", entries);
  const at = entries.find(([s]) => s === slug);
  return at ? scholarBonus(actor, item, { title: N.emberkinScholar, slug: at[0], label: at[1] }) : false;
}

const emberkinScholar = {
  hint: "Put the +2 racial on your Elemental Lore (Arcana and Nature +1 are always on).",
  async use(actor, item) { return emberkinScholarApply(actor, item); }
};

/** Nyrinn Scholar (Q74): Spell Lore or Nyrinn Lore. */
export const NYRINN_LORES = Object.freeze(["spell lore", "nyrinn lore"]);
const nyrinnScholar = {
  hint: "Choose which racial specialist skill takes the +2 racial: Spell Lore or Nyrinn Lore (Occultism and Planes +1 are always on).",
  async use(actor, item) {
    const lores = specialistEntries(actor).filter(([, label]) => NYRINN_LORES.includes(norm(label)));
    if (!lores.length) return warn("Nyrinn Scholar: your sheet has neither Spell Lore nor Nyrinn Lore — add your racial specialist skills first.");
    const slug = lores.length === 1 ? lores[0][0] : await h().chooseFromList(N.nyrinnScholar, "Which racial specialist skill takes the +2 racial bonus?", lores);
    const at = lores.find(([s]) => s === slug);
    return at ? scholarBonus(actor, item, { title: N.nyrinnScholar, slug: at[0], label: at[1] }) : false;
  }
};

const eclipsedForm = {
  hint: "2 AP (Focus): incorporeal until the start of your next turn — half damage from non-magical physical attacks.",
  async use(actor) {
    if (!(await spendAP(actor, "Eclipsed Form", 2))) return false;
    await h().createEffectsOn(actor, [eclipsedEffect(actor)]);
    await card(actor, "Eclipsed Form", [
      line("You blur into the Void until the start of your next turn: <strong>half damage</strong> from non-magical bludgeoning, piercing and slashing weapon attacks."),
      line("<em>You may move through solid objects, but not end your turn inside one — the GM's to adjudicate.</em>"),
      ...(fighting(actor) ? [line("2 AP spent.")] : [])
    ]);
    return true;
  }
};

const voidbornWings = {
  hint: "Focus: fly at your land speed for your level + Dexterity rounds; Use again to land.",
  ownsFocusUse: true,
  async use(actor, item) {
    const up = ownEffects(actor, SRC.wings);
    if (up.length) {
      if (!(await confirm("Voidborn Wings", "End your Voidborn Wings flight now?"))) return false;
      await actor.deleteEmbeddedDocuments("ActiveEffect", up.map((e) => e.id));
      await card(actor, "Voidborn Wings", [line("Your Voidborn Wings flight ends.")]);
      return true;
    }
    if (usesLeft(item) <= 0) return warn("Voidborn Wings: its Focus use is spent — Refocus restores it.");
    const rounds = wingsRounds(levelOf(actor), actor.system?.attributes?.dexterity?.total);
    if (!rounds) return warn("Voidborn Wings: your level + Dexterity gives no rounds of flight.");
    if (!(await spendUse(item))) return false;
    await h().createEffectsOn(actor, [wingsEffect(rounds)]);
    await syncFlight(actor);
    await card(actor, "Voidborn Wings", [
      line(`The Void bears you up: a <strong>fly speed equal to your land speed</strong> for <strong>${rounds} rounds</strong>${featOf(actor, N.grace) ? ", with the Hover trait (Voidborn Grace)" : ""}. Landing ends it.`),
      line("<em>Focus use spent — Refocus restores it.</em>")
    ]);
    return true;
  }
};

/** Vir-ellian Release with Crystal Pulse: force or electricity, and 1d4 more (Q69). */
async function crystalRelease(actor, item) {
  const stored = ownEffects(actor, "magicDrainEnergy");
  const energy = stored.reduce((sum, e) => sum + int(e.getFlag(MODULE_ID, "energy")), 0);
  if (!energy) return warn("Vir-ellian Release: you hold no energy from Magic Drain.");
  if (usesLeft(item) <= 0) return warn("Vir-ellian Release: no uses remain — Refocus restores it.");
  const type = norm(await h().chooseFromList("Vir-ellian Release — Crystal Pulse", "The release's damage type", CRYSTAL_TYPES.map((t) => [t, t[0].toUpperCase() + t.slice(1)])));
  if (!CRYSTAL_TYPES.includes(type)) return false;
  if (!(await spendAP(actor, "Vir-ellian Release", 1))) return false;
  if (!(await spendUse(item))) return false;
  const me = tokenOf(actor);
  const targets = me ? (canvas.tokens.placeables ?? []).filter((t) => t !== me && t.actor && (feetBetween(me, t) ?? 99) <= 30).map((t) => t.actor) : [];
  const dc = await h().levelDC(levelOf(actor));
  const formula = crystalFormula(energy);
  const lines = targets.length
    ? await h().runAreaEffect(actor, { save: "will", basic: true, dc, damage: { formula, type }, scope: "targets" }, { title: "Vir-ellian Release", targets })
    : [line("<em>No creature stands within 30 feet.</em>")];
  await actor.deleteEmbeddedDocuments("ActiveEffect", stored.map((e) => e.id)).catch(() => {});
  await card(actor, "Vir-ellian Release", [
    line(`You release <strong>${energy} PP</strong> of drained energy with Crystal Pulse: <strong>${formula} ${esc(type)}</strong> (1d4 a PP, and 1d4 more) to every creature within 30 feet, basic Will against DC ${dc}.`),
    ...(lines ?? []),
    line("<em>The energy is spent. Focus use spent — Refocus restores it.</em>")
  ]);
  return true;
}

/** REPLACES Block 1's "Vir-ellian Release" entry: Block 1's own release, unless the releaser has Crystal Pulse. */
export const virEllianReleaseB5B = {
  hint: "1 AP (Concentrate, Focus): release your stored energy — 1d4 a PP to every creature within 30 feet (basic Will). Crystal Pulse: force or electricity, and 1d4 more.",
  ownsFocusUse: true,
  async use(actor, item) {
    if (!featOf(actor, N.crystal)) return BLOCK1_AUTOMATIONS["Vir-ellian Release"].use(actor, item);
    return crystalRelease(actor, item);
  }
};

export const AUTOMATIONS_B5B = Object.freeze({
  [N.apotheosis]: elementalApotheosis,
  [N.step]: elementalStep,
  [N.emberkinScholar]: emberkinScholar,
  [N.nyrinnScholar]: nyrinnScholar,
  [N.eclipsed]: eclipsedForm,
  [N.wings]: voidbornWings
});

/* ------------------------------------------------------------------ */
/* The reactions (C2) and their steps                                   */
/* ------------------------------------------------------------------ */

export const SPEND_STEP = "eldritchArts.b5b.spendUse";
export const BULWARK_STEP = "eldritchArts.b5b.elementalBulwark";
export const REPRISAL_STEP = "eldritchArts.b5b.elementalReprisal";

/** On the reactor's client: a use of the named feat, and the reaction when asked for in combat. */
async function spendStep(actor, answer, data = {}) {
  const item = actor?.items?.get?.(data.itemId);
  if (!item || usesLeft(item) <= 0) return { spent: false };
  if (data.reaction && fighting(actor) && !(await h().spendReaction(actor, String(data.label ?? item.name), { traits: String(data.traits ?? "") }))) return { spent: false };
  return { spent: await spendUse(item) };
}

async function bulwarkStep(actor, answer, data = {}) {
  const item = actor?.items?.get?.(data.itemId);
  if (!item || !(await spendUse(item))) return { done: false };
  await h().createEffectsOn(actor, [bulwarkEffect(actor)]);
  await card(actor, N.bulwark, [line("+1 racial bonus to DB and saving throws until the start of your next turn."), line("<em>Focus use spent — Refocus restores it.</em>")]);
  return { done: true };
}

async function reprisalStep(actor, answer, data = {}) {
  const item = actor?.items?.get?.(data.itemId);
  const element = norm(data.element) || heritageElement(actor?.items);
  if (!item || usesLeft(item) <= 0 || !element) return { done: false };
  const me = tokenOf(actor);
  if (!me) { warn("Elemental Reprisal: place your token on the map first."); return { done: false }; }
  const near = (canvas?.tokens?.placeables ?? []).filter((t) => t !== me && t.actor && t.actor !== actor && (feetBetween(me, t) ?? 99) <= 5);
  if (!near.length) { await card(actor, N.reprisal, [line("<em>No creature is adjacent to you: the burst finds no target, and the use is kept.</em>")]); return { done: false }; }
  const id = near.length === 1 ? near[0].id : await h().chooseFromList(N.reprisal, "The burst strikes which adjacent creature?", near.map((t) => [t.id, esc(t.name ?? t.actor.name)]));
  const target = near.find((t) => t.id === id)?.actor;
  if (!target || !(await spendUse(item))) return { done: false };
  const dice = perTwoLevelsD4(levelOf(actor));
  const roll = await new Roll(dice).evaluate();
  const bonus = await h().spellDamagePerDieBonus(actor, { type: element, dice });
  const amount = int(roll.total) + int(bonus?.total);
  const dc = await h().levelDC(levelOf(target));
  const out = await h().basicSaveHit({ caster: actor, target, save: "reflex", dc, label: N.reprisal, amount, type: element, baseDamage: dice });
  await card(actor, N.reprisal, [
    line(`A burst of ${esc(element)} lashes ${esc(target.name)}: <strong>${amount}</strong> (${dice} = ${int(roll.total)}${bonus?.total ? `, ${esc(bonus.text)}` : ""}), basic Reflex against its Level DC ${dc}.`),
    ...(out?.line ? [line(out.line)] : []),
    line("<em>Focus use spent — Refocus restores it.</em>")
  ]);
  return { done: true };
}

/** Anchor in Nothing: before a Will save's dice, once a day. */
async function anchorBefore(ctx) {
  const actor = ctx?.actor;
  if (ctx?.type !== "save" || norm(ctx.subject) !== "will") return null;
  const item = featOf(actor, N.anchor);
  if (!item || usesLeft(item) <= 0) return null;
  const q = await h().askReactor(actor, {
    title: `${N.anchor} — ${actor.name}`,
    content: `<p><strong>${esc(actor.name)}</strong> is about to make a Will save${ctx.saveSource ? ` against <strong>${esc(ctx.saveSource)}</strong>` : ""}${ctx.dc !== null ? ` (DC ${int(ctx.dc)})` : ""}.</p><p>Use <strong>Anchor in Nothing</strong> (once a day) to make it a Success before the dice are rolled?</p>`,
    buttons: yesNo("Anchor in Nothing"), step: SPEND_STEP, data: { itemId: item.id, label: N.anchor }
  });
  if (!q?.result?.spent) return null;
  return { declare: "success", label: N.anchor, line: `${actor.name} anchors in nothing: the Will save is a <strong>Success</strong>, the dice do not count (once a day).` };
}

/** Voidbound Resolve: before a targeted spell's Will save (Q73). */
async function voidboundBefore(ctx) {
  const actor = ctx?.actor;
  if (!voidboundAsks(ctx)) return null;
  const item = featOf(actor, N.voidbound);
  if (!item || usesLeft(item) <= 0) return null;
  if (fighting(actor) && await h().reactionRefusal?.(actor, "")) return null;
  const q = await h().askReactor(actor, {
    title: `${N.voidbound} — ${actor.name}`,
    content: `<p><strong>${esc(actor.name)}</strong> is targeted by <strong>${esc(ctx.saveSource)}</strong> and must make a Will save${ctx.dc !== null ? ` (DC ${int(ctx.dc)})` : ""}.</p><p>Use <strong>Voidbound Resolve</strong> (${fighting(actor) ? "your reaction and " : ""}one of ${usesLeft(item)} uses today) for +2 racial on the save? If it makes the difference, the caster takes the backlash. Decline if this is not a spell.</p>`,
    buttons: yesNo("Voidbound Resolve"), step: SPEND_STEP, data: { itemId: item.id, label: N.voidbound, reaction: true }
  });
  if (!q?.result?.spent) return null;
  if (ctx.check) ctx.check.eaVoidbound = { sourceUuid: ctx.sourceUuid, level: levelOf(actor) };
  return { modifiers: [{ label: N.voidbound, value: 2, type: "race" }], label: N.voidbound, line: `${actor.name} draws on the Null Aura: <strong>+2 racial</strong> on this Will save (Voidbound Resolve).` };
}

/** The backlash, once a check's final result is known (`mark` from voidboundBefore). Once a check. */
async function voidboundBacklash(saver, check, { succeeded, total, dc }) {
  const mark = check?.eaVoidbound;
  if (!mark || mark.done) return false;
  if (!voidboundCaused({ succeeded, total, dc })) return false;
  mark.done = true;
  const caster = await fromUuidSafe(mark.sourceUuid);
  if (!caster) { await card(saver, N.voidbound, [line("The +2 made the save: <em>the caster takes the backlash — roll it by hand (the caster could not be found).</em>")]); return true; }
  const dice = perTwoLevelsD4(mark.level);
  const cdc = await h().levelDC(levelOf(caster));
  const out = await h().basicSaveHit({ caster: saver, target: caster, save: "will", dc: cdc, label: N.voidbound, formula: dice, type: "mental", baseDamage: dice });
  await card(saver, N.voidbound, [line(`The +2 made the save: the backlash rattles through ${esc(caster.name)} — <strong>${dice} mental</strong>, basic Will against its own Level DC ${cdc}.`), ...(out?.line ? [line(out.line)] : [])]);
  return true;
}

/** …and after it: the backlash when the +2 made the difference. */
async function voidboundAfter(ctx) {
  if (!ctx?.check?.eaVoidbound || ctx.type !== "save") return null;
  await voidboundBacklash(ctx.actor, ctx.check, { succeeded: ctx.succeeded, total: ctx.total, dc: ctx.dc });
  return null;
}

const SUCCESS_DEGREES = Object.freeze(["heroic", "critical", "success"]);
/**
 * A REROLL OF A SAVE VOIDBOUND RESOLVE STRENGTHENED (review of 0.8.0): the +2
 * rides the reroll (C2), but the core asks no after-reaction once a check is
 * rerolled, so voidboundAfter never sees the second result. The reroll that
 * Mindshroud asks for is wrapped, on this one check, to judge the backlash on
 * the result that stands.
 */
function judgeVoidboundAfterReroll(saver, check) {
  if (!check?.eaVoidbound || typeof check.reroll !== "function" || check.eaVoidboundRerollWrapped) return;
  const reroll = check.reroll;
  check.eaVoidboundRerollWrapped = true;
  check.reroll = async function (...args) {
    const out = await reroll.apply(check, args);
    const o = check.outcome ?? {};
    await voidboundBacklash(saver, check, { succeeded: SUCCESS_DEGREES.includes(String(o.degree?.key ?? "")), total: o.total ?? null, dc: check.dc ?? null });
    return out;
  };
}

/** Tideweaver's Resilience: +1 racial to any check while submerged. */
async function tideweaverBefore(ctx) {
  const actor = ctx?.actor;
  if (!featOf(actor, N.tideweaver) || !ctx.token) return null;
  if (!(await h().isUnderwater(ctx.token))) return null;
  return { modifiers: [{ label: `${N.tideweaver} (submerged)`, value: 1, type: "race" }] };
}

/** Veilstride: advantage on the first melee attack after 10 ft of movement this turn, in the dark (Q72). */
const VEILSTRIDE_USED = new Map();
async function veilstrideBefore(ctx) {
  const actor = ctx?.actor;
  if (ctx?.type !== "attack" || norm(ctx.attackMode) !== "melee") return null;
  if (!featOf(actor, N.veilstride) || !ownTurn(actor) || !ctx.token) return null;
  const combat = combatFor(actor);
  const moved = await h().movementThisTurn(actor);
  const light = await h().lightLevelAt(ctx.token);
  const key = actor.uuid ?? actor.id;
  const prior = VEILSTRIDE_USED.get(key);
  const sameTurn = prior && prior.combatId === combat.id && prior.round === combat.round && prior.turn === combat.turn;
  const feet = Number(moved?.feet ?? 0);
  if (!veilstrideDue({ feet, usedAt: sameTurn ? prior.feet : 0, light })) return null;
  VEILSTRIDE_USED.set(key, { combatId: combat.id, round: combat.round, turn: combat.turn, feet });
  return { advantage: true, label: N.veilstride, line: `${actor.name} strikes out of the dark after ${Math.round(feet)} ft of movement (light ${light}): <strong>advantage</strong> (Veilstride).` };
}

/** Mindshroud: once a day, reroll a failed Will save. */
async function mindshroudAfter(ctx) {
  const actor = ctx?.actor;
  if (ctx?.type !== "save" || norm(ctx.subject) !== "will" || !ctx.failed) return null;
  const item = featOf(actor, N.mindshroud);
  if (!item || usesLeft(item) <= 0) return null;
  const q = await h().askReactor(actor, {
    title: `${N.mindshroud} — ${actor.name}`,
    content: `<p><strong>${esc(actor.name)}</strong> fails a Will save (${int(ctx.total)}${ctx.dc !== null ? ` vs DC ${int(ctx.dc)}` : ""}).</p><p>Use <strong>Mindshroud</strong> (once a day) to reroll it? The second result stands.</p>`,
    buttons: yesNo("Reroll"), step: SPEND_STEP, data: { itemId: item.id, label: N.mindshroud }
  });
  if (!q?.result?.spent) return null;
  judgeVoidboundAfterReroll(actor, ctx.check);
  return { reroll: true, label: N.mindshroud, line: `${actor.name} stills the Void's whisper: the Will save is rerolled, and the second result stands (Mindshroud).` };
}

/** Eclipsed Form (Q68): resistance to a non-magical physical weapon blow while it lasts. */
async function eclipsedReaction(ctx) {
  const actor = ctx?.target;
  if (!actor || !ownEffects(actor, SRC.eclipsed).length) return null;
  const answer = eclipsedAnswer(ctx, (type) => attackerBlowMagical(ctx.source, type));
  return answer ? { ...answer, line: `${actor.name} is eclipsed: half damage from this non-magical ${esc(answer.resist.join(" and "))} blow.` } : null;
}

/** Threadbreaker's Precision (C9, Q67). */
export const threadbreakerModifier = {
  offer(ctx = {}) {
    if (!featOf(ctx.actor, N.threadbreaker)) return null;
    return { label: N.threadbreaker, hint: "+2 racial to the Dispel check; a countered spell's caster is Dazed 1", modifiers: [{ label: N.threadbreaker, value: 2, type: "race" }] };
  },
  async onResult(ctx = {}) {
    if (!ctx.countered) return null;
    const raw = ctx.targetCaster ?? (ctx.presetDispel ? null : ctx.target);
    const caster = raw?.documentName === "Token" ? raw.actor : raw;
    if (!caster) return { lines: [`<strong>${N.threadbreaker}</strong>: the spell is countered — its caster is <strong>Dazed 1</strong> until the end of its next turn. <em>The Dispel does not name the caster: the GM applies it.</em>`] };
    const combat = combatFor(caster) ?? (globalThis.game?.combat?.started ? globalThis.game.combat : null);
    await h().applyConditionTagsTo(caster, [dazedTag({ inCombat: Boolean(combat), round: combat?.round ?? 0, worldTime: worldNow() })]);
    return { lines: [`<strong>${N.threadbreaker}</strong>: the spell is countered, and ${esc(caster.name)} is <strong>Dazed 1</strong> until the end of its next turn.`] };
  }
};

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const REACTIONS_B5B = Object.freeze({ anchorBefore, voidboundBefore, voidboundAfter, tideweaverBefore, veilstrideBefore, mindshroudAfter, eclipsedReaction });
export const STEPS_B5B = Object.freeze({ spendStep, bulwarkStep, reprisalStep });

/**
 * Every registration group B makes. Called once, inside the system's
 * "trgPrime.registerContent" hook, AFTER Block 1's (its Vir-ellian Release
 * entry replaces Block 1's: the later registration wins).
 */
export function registerBlock5B(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B5B)) api.registerFeatAutomation(name, entry, moduleId);
  api.registerFeatAutomation("Vir-ellian Release", virEllianReleaseB5B, moduleId);
  // ANCHOR FIRST: once it declares, no later reaction is asked (C2), so a
  // Voidbound Resolve is not spent on a save that is already a Success.
  api.registerCheckReaction?.("anchorInNothing", { before: anchorBefore }, moduleId);
  api.registerCheckReaction?.("voidboundResolve", { before: voidboundBefore, after: voidboundAfter }, moduleId);
  api.registerCheckReaction?.("tideweaversResilience", { before: tideweaverBefore }, moduleId);
  api.registerCheckReaction?.("veilstride", { before: veilstrideBefore }, moduleId);
  api.registerCheckReaction?.("mindshroud", { after: mindshroudAfter }, moduleId);
  api.registerDamageReaction?.("eclipsedForm", eclipsedReaction, moduleId);
  api.registerDispelModifier?.("threadbreakersPrecision", threadbreakerModifier, moduleId);
  api.registerReactionStep?.(SPEND_STEP, spendStep, moduleId);
  api.registerReactionStep?.(BULWARK_STEP, bulwarkStep, moduleId);
  api.registerReactionStep?.(REPRISAL_STEP, reprisalStep, moduleId);
}

/* ------------------------------------------------------------------ */
/* Flight: Stormrunner's Zeal, Voidborn Wings, Voidborn Grace           */
/* ------------------------------------------------------------------ */

/**
 * The fly speed follows the effects: a feat declares `creatureAbility.derives
 * .movement` (the core's granted speed, read from items) while one of its
 * flight effects is up. Voidborn Grace adds Hover to the wings' (C5's "held
 * up"). Written by the one client that acts for the actor.
 */
export async function syncFlight(actor) {
  if (!actor) return;
  const grace = Boolean(featOf(actor, N.grace));
  for (const [source, name] of Object.entries(FLIGHT_SOURCES)) {
    const item = featOf(actor, name);
    if (!item) continue;
    const want = flightDerives(ownEffects(actor, source).length > 0, { hover: source === SRC.wings && grace });
    const have = item.flags?.[SYSTEM_ID]?.creatureAbility?.derives ?? null;
    if (JSON.stringify(want) === JSON.stringify(have)) continue;
    if (want) await item.setFlag(SYSTEM_ID, "creatureAbility", { derives: want });
    else await item.unsetFlag(SYSTEM_ID, "creatureAbility");
  }
}

const elevationOf = (token) => Number(token?.document?.elevation ?? 0) || 0;
const flightUp = (actor) => Object.keys(FLIGHT_SOURCES).some((s) => ownEffects(actor, s).length > 0);

/** Lower the token and roll the core's Falling from Height for the height (C5). */
async function fallFrom(actor, token, height, note) {
  if (!token || !(height > 0)) return;
  await token.document.update({ elevation: 0 });
  await h().rollFalling(actor, { distance: height, note });
}

/** A flight ended: in the air with no fly speed left, fall — or glide, with Voidborn Grace after the wings. */
async function landIfAirborne(actor, { source }) {
  const token = tokenOf(actor);
  const height = elevationOf(token);
  if (!token || height <= 0 || flightUp(actor)) return;
  if (Number(actor.system?.combat?.movement?.fly?.total ?? 0) > 0) return;
  const label = source === SRC.wings ? N.wings : N.zeal;
  if (source === SRC.wings && featOf(actor, N.grace)) {
    if (!fighting(actor)) {
      await token.document.update({ elevation: 0 });
      await card(actor, N.grace, [line(`Your flight ends ${height} ft up: you drift safely to the ground, taking no damage.`)]);
      return;
    }
    await h().createEffectsOn(actor, [glideEffect()]);
    await card(actor, N.grace, [line(`Your flight ends ${height} ft up: you glide down 60 ft at the end of each of your turns, taking no damage unless you are grappled or knocked prone mid-glide.`)]);
    return;
  }
  await card(actor, label, [line(`The fly speed ends with you ${height} ft in the air: you fall.`)]);
  await fallFrom(actor, token, height, `${label}: the flight ended in the air.`);
}

/** Stormrunner's Zeal: a new flight effect; an older one ends on its own, later than none. */
async function zealTakesWing(actor) {
  await h().createEffectsOn(actor, [zealEffect(actor)]);
  await card(actor, N.zeal, [line("Lightning races through your blood: a <strong>fly speed equal to your land speed</strong> until the end of your next turn.")]);
}

/* ------------------------------------------------------------------ */
/* Shadow Initiate's speed                                              */
/* ------------------------------------------------------------------ */

/**
 * The +5 ft follows the light at the token: one client per actor (`actsFor`),
 * or the acting GM when the caller is the GM's own hook (`asActingGM`: the
 * core fires trgPrimeTurnEnded there only, review of 0.8.0).
 */
export async function refreshShadowInitiate(token, { asActingGM = false } = {}) {
  const actor = token?.actor;
  if (!actor || !(asActingGM ? isActingGM() : actsFor(actor))) return;
  const up = ownEffects(actor, SRC.shadow);
  const has = Boolean(featOf(actor, N.shadowInitiate));
  const dark = has && darkEnough(await h().lightLevelAt(token));
  if (dark && !up.length) await h().createEffectsOn(actor, [shadowInitiateEffect()]);
  if (!dark && up.length) await actor.deleteEmbeddedDocuments("ActiveEffect", up.map((e) => e.id)).catch(() => {});
}

/* ------------------------------------------------------------------ */
/* Vein of Power, the Scholars, Voidbound's uses                        */
/* ------------------------------------------------------------------ */

export async function syncVeinOfPower(actor) {
  const item = featOf(actor, N.vein);
  if (!item) return;
  const want = veinAdder(levelOf(actor));
  if (int(item.flags?.[SYSTEM_ID]?.spellAdder) !== want) await item.setFlag(SYSTEM_ID, "spellAdder", want);
}

/* ------------------------------------------------------------------ */
/* Hooks — each named for the event the lead wires it to                */
/* ------------------------------------------------------------------ */

/**
 * Hooks.on("trgPrimeDamageApplied", ctx): fired once, on the client that
 * applied the damage. Elemental Bulwark and Reprisal are asked of the
 * Emberkin's own player (askReactor); Stormrunner's Zeal takes wing (its
 * effect through the GM relay when this client does not own the creature).
 */
export async function onDamageAppliedB5B(ctx = {}) {
  const actor = ctx.actor;
  if (!actor || !(Number(ctx.amount) > 0)) return;
  const types = Array.from(ctx.damageTypes ?? []).map(norm);
  if (types.includes("electricity") && featOf(actor, N.zeal)) await zealTakesWing(actor);
  const element = heritageElement(actor.items);
  if (!elementTaken(types, element)) return;
  const asks = [
    [N.bulwark, BULWARK_STEP, "+1 racial to DB and saving throws until the start of your next turn"],
    [N.reprisal, REPRISAL_STEP, `a burst of ${perTwoLevelsD4(levelOf(actor))} ${element} at one adjacent creature (basic Reflex)`]
  ];
  for (const [name, step, what] of asks) {
    const item = featOf(actor, name);
    if (!item || usesLeft(item) <= 0) continue;
    await h().askReactor(actor, {
      title: `${name} — ${actor.name}`,
      content: `<p><strong>${esc(actor.name)}</strong> takes ${esc(element)} damage.</p><p>Use <strong>${esc(name)}</strong> (0 AP, its Focus use): ${esc(what)}?</p>`,
      buttons: yesNo(name), step, data: { itemId: item.id, element }
    });
  }
}

/** Hooks.on("trgPrimeSpellSettled", ctx): Mantle of Essence, on the caster's client. */
export async function onSpellSettledB5B(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner || !ctx.cast || ctx.refunded) return;
  const item = featOf(actor, N.mantle);
  if (!item || usesLeft(item) <= 0) return;
  const traits = String(item.system?.traits ?? "");
  if (fighting(actor) && await h().reactionRefusal?.(actor, traits)) return;
  const bonus = mantleBonus(levelOf(actor));
  if (!(await confirm(N.mantle, `${esc(ctx.spell?.name ?? "Your spell")} is cast. Use Mantle of Essence (${fighting(actor) ? "your reaction and " : ""}its Focus use) for +${bonus} circumstance to DB until the start of your next turn?`))) return;
  if (fighting(actor) && !(await h().spendReaction(actor, N.mantle, { traits }))) return;
  if (!(await spendUse(item))) return;
  await h().createEffectsOn(actor, [mantleEffect(actor, bonus)]);
  await card(actor, N.mantle, [line(`The air hardens around you: <strong>+${bonus} circumstance to DB</strong> until the start of your next turn.`), ...(fighting(actor) ? [line("Reaction spent.")] : []), line("<em>Focus use spent — Refocus restores it.</em>")]);
}

/** Hooks.on("createItem", item): Vein of Power's rating, Emberkin Scholar's lore, Voidbound Resolve's uses (one client). */
export async function onItemCreatedB5B(item) {
  const actor = item?.parent;
  if (item?.type !== "feat" || !actor?.isOwner || !actsFor(actor)) return;
  const name = norm(item.name);
  if (name === norm(N.vein)) await syncVeinOfPower(actor);
  if (name === norm(N.emberkinScholar)) await emberkinScholarApply(actor, item, { quiet: true });
  // A LEVELLED COUNT ARRIVES FULL: the stored 0 would read as spent until the first daily preparation.
  if (name === norm(N.voidbound)) {
    const max = h().itemUsesMax(item);
    if (Number.isFinite(max) && int(item.system?.usesValue) < max) await item.update({ "system.usesValue": max });
  }
}

/**
 * Hooks.on("updateActor", (actor, change)): a level change moves Vein of
 * Power's rating. A character's level is derived from its XP (the core's
 * actor), so its level-up arrives as an XP change; an NPC's level is set.
 */
export const levelMayHaveChanged = (change = {}) => change?.system?.identity?.level !== undefined || change?.system?.identity?.xp !== undefined;
export async function onActorUpdatedB5B(actor, change = {}) {
  if (!levelMayHaveChanged(change) || !actor?.isOwner || !actsFor(actor)) return;
  await syncVeinOfPower(actor);
}

/** Hooks.on("trgPrimeDailyPreparation", ctx): Vein of Power's rating, trued up. */
export async function onDailyPreparationB5B({ actor } = {}) {
  if (!actor?.isOwner) return;
  await syncVeinOfPower(actor);
}

const effectActor = (effect) => (effect?.parent?.documentName === "Actor" ? effect.parent : null);

/** Hooks.on("createActiveEffect", effect): flight on; a glide interrupted by grappled or prone. */
export async function onEffectCreatedB5B(effect) {
  const actor = effectActor(effect);
  if (!actor || !actsFor(actor)) return;
  const source = effect.getFlag?.(MODULE_ID, "source");
  if (FLIGHT_SOURCES[source]) await syncFlight(actor);
  const statuses = Array.from(effect.statuses ?? []);
  const glide = ownEffects(actor, SRC.glide);
  if (glide.length && statuses.some((s) => ["prone", "grappled"].includes(s))) {
    const token = tokenOf(actor);
    const height = elevationOf(token);
    await actor.deleteEmbeddedDocuments("ActiveEffect", glide.map((e) => e.id)).catch(() => {});
    await card(actor, N.grace, [line(`Your glide is interrupted ${height} ft up: you fall.`)]);
    await fallFrom(actor, token, height, `${N.grace}: the glide was interrupted.`);
  }
}

/** Hooks.on("deleteActiveEffect", effect): flight off; in the air with nothing holding you up, fall or glide. */
export async function onEffectDeletedB5B(effect) {
  const actor = effectActor(effect);
  if (!actor || !actsFor(actor)) return;
  const source = effect.getFlag?.(MODULE_ID, "source");
  if (!FLIGHT_SOURCES[source]) return;
  await syncFlight(actor);
  await landIfAirborne(actor, { source });
}

/** Hooks.on("updateToken", (doc, change)): landing ends the wings; a move rechecks Shadow Initiate. */
export async function onTokenUpdatedB5B(doc, change = {}) {
  const actor = doc?.actor;
  if (!actor) return;
  if ("x" in change || "y" in change) await refreshShadowInitiate(doc.object ?? { actor, document: doc });
  if (!("elevation" in change) || !actsFor(actor)) return;
  const elevation = Number(change.elevation) || 0;
  const wings = ownEffects(actor, SRC.wings)[0];
  if (wings && elevation > 0 && !wings.getFlag(MODULE_ID, "tookOff")) await wings.setFlag(MODULE_ID, "tookOff", true);
  if (wings && elevation <= 0 && wings.getFlag(MODULE_ID, "tookOff")) {
    await actor.deleteEmbeddedDocuments("ActiveEffect", [wings.id]).catch(() => {});
    await card(actor, N.wings, [line("You land: your Voidborn Wings flight ends.")]);
  }
  const glide = ownEffects(actor, SRC.glide);
  if (glide.length && elevation <= 0) await actor.deleteEmbeddedDocuments("ActiveEffect", glide.map((e) => e.id)).catch(() => {});
}

/**
 * Hooks.on("trgPrimeTurnEnded", ctx): the glide's 60 ft, the wings' round, and
 * the light. THE CORE FIRES IT ON THE ACTING GM'S CLIENT ONLY (documents/
 * combat.mjs), so that client does the work for every creature — a player's
 * included (review of 0.8.0: gated on `actsFor`, a connected player's glide
 * never descended and their wings never counted down).
 */
export async function onTurnEndedB5B(ctx = {}) {
  if (!isActingGM()) return;
  const actor = ctx.actor ?? ctx.combatant?.actor ?? null;
  if (actor) {
    const glide = ownEffects(actor, SRC.glide);
    if (glide.length) {
      const token = tokenOf(actor);
      const next = glideStep(elevationOf(token));
      if (token) await token.document.update({ elevation: next });
      if (next <= 0) await actor.deleteEmbeddedDocuments("ActiveEffect", glide.map((e) => e.id)).catch(() => {});
      await card(actor, N.grace, [line(next > 0 ? `You glide down 60 ft (${next} ft up).` : "You settle gently on the ground.")]);
    }
    const wings = ownEffects(actor, SRC.wings)[0];
    if (wings) {
      const rounds = int(wings.getFlag(MODULE_ID, "rounds")) - 1;
      if (rounds <= 0) await actor.deleteEmbeddedDocuments("ActiveEffect", [wings.id]).catch(() => {});
      else await wings.setFlag(MODULE_ID, "rounds", rounds);
    }
  }
  await refreshAllB5B({ asActingGM: true });
}

/**
 * Hooks.on("canvasReady") and the light and region hooks (every client, each
 * acting for its own actors): Shadow Initiate on every token. From the turn
 * end, the acting GM acts for all (`asActingGM`).
 */
export async function refreshAllB5B({ asActingGM = false } = {}) {
  const gm = asActingGM === true;
  for (const token of Array.from(globalThis.canvas?.tokens?.placeables ?? [])) {
    if (token?.actor && (featOf(token.actor, N.shadowInitiate) || ownEffects(token.actor, SRC.shadow).length)) await refreshShadowInitiate(token, { asActingGM: gm }).catch(() => {});
  }
}
