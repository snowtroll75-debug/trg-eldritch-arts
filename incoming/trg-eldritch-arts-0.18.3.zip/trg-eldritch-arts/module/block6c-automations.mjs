/**
 * Eldritch Arts — Block 6 (0.9.0), group C: what the Runemage, Sorcerer,
 * Spellblade and Martial class feats do that is not data. On TRG Prime
 * 3.684.0.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md (Appendices C and F) as
 * Graham answered it on 4 November 2026 (Q89–Q149 as proposed; Q89, one
 * release), on the core's seams as built (b6-contracts.md). The pure rules
 * come first so the harness can run them; the Foundry side follows.
 *
 *   Uses         Prepared Sigil, Arcane Study, Bespell Weapon, Call Bonded
 *                Weapon, Considered Attack, High Mage's Focus, Magical
 *                Retribution, Resonance Surge, Spellblade's Mark
 *   Seams        a cast prelude (Prepared Sigil), two module metamagics (G1,
 *                Ley-Etched Symbol's −1 PP; Resonance Surge's free warp), a metamagic payment (G3,
 *                Metamagic Adept), a Resonance modifier with roll and force
 *                (G5: High Magic Resonance, Resonance Surge), a degree remap
 *                (High Magic Resonance's daily Fumble), spell-check gates
 *                (Bonded Infusion, High Mage's Focus, Spellblade's Mark), a
 *                pending-cast step (G26, Magical Retribution), feat
 *                eligibility (G9: Arcane Study, High Magic Resonance,
 *                Resonance Surge), a reaction step
 *   Hooks        spell settled (sigils, Bespell, Resonance Surge), daily
 *                preparation (sigils, Arcane Study, High Magic Resonance,
 *                Resonance Surge, Bonded Infusion), actor and item updates
 *                (Bonded Infusion, High Mage's Focus), combat deleted
 *                (Spellblade's Mark), ready
 *
 * The hook handlers are exported for the lead to wire in
 * scripts/eldritch-arts.mjs; each says which `Hooks.on` event it expects.
 *
 * THE LEY-BENEFIT MARKER (Appendix C, N6): Ley-Etched Symbol's "You are
 * currently gaining the benefits of a ley line" is read from a marker effect
 * (`LEY_BENEFIT_SOURCE`), laid with `layLeyBenefitMarker` by Block 2's
 * `leyBenefits` (block2-automations.mjs) and Leyline Weaver's Tap and
 * Leyline Power.
 */
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, tokenOf, feetBetween } from "./block1-automations.mjs";
import { spellIndex, actsFor, birthrightOf } from "./block3-automations.mjs";
import { INFUSION_FLAG, TRADITION_SKILL } from "./block4-automations.mjs";
import { rollTable } from "./block2-automations.mjs";
import { LEY_LINE_EFFECTS } from "./chapter7-tables.mjs";

/* ------------------------------------------------------------------ */
/* Data                                                                 */
/* ------------------------------------------------------------------ */

export const SIGILS_FLAG = "eaSigils";
export const SIGILS_INSCRIBED_FLAG = "eaSigilsInscribed";
export const SIGIL_LOCK_FLAG = "eaSigilLock";
export const SIGIL_REFORM_SECONDS = 60;
export const SIGIL_REFORM_ROUNDS = 10;
export const ROUND_SECONDS = 6;
export const RESERVOIR_SIGILS = 3;
/** "Gaining the benefits of a ley line" (Q125): the marker Block 2's benefits lay. */
export const LEY_BENEFIT_SOURCE = "leyLineBenefit";
export const LEY_ETCHED_KEY = "leyEtchedSymbol";
export const LEY_ETCHED_LOCK_FLAG = "eaLeyEtchedLock";
export const ARCANE_BOOK_FLAG = "eaArcaneBook";
export const ARCANE_TODAY_FLAG = "eaArcaneToday";
export const ARCANE_DAILY_FLAG = "arcaneStudyDaily";
export const BESPELL_LAST_FLAG = "eaBespellLast";
export const BESPELL_SOURCE = "bespellWeapon";
export const BESPELL_DICE = "1d6";
export const BONDED_FOCUS_BONUS = 2;
export const BONDED_ADDER = 1;
/** Where group A records a High Mage's or Birthrager's borrowed birthright (system scope, on the feat). */
export const BORROWED_BIRTHRIGHT_FLAG = "eaBorrowedBirthright";
export const ALL_TRADITIONS = Object.freeze(["arcane", "divinity", "ethereal", "verdant"]);
export const CONSIDERED_BONUS = 2;
export const CONSIDERED_EXTRA_AP = 1;
export const HMF_BONUS = 2;
export const HMF_SECOND_BSB = 10;
export const HMF_PICKS_FLAG = "eaFocusSpells";
export const HMF_NOTED_FLAG = "eaFocusSecondNoted";
export const HMR_EASED_FLAG = "eaFumbleEased";
export const ADEPT_OPTIONS = Object.freeze(["extend", "reach", "silent", "still"]);
export const SURGE_SOURCE = "resonanceSurge";
export const SURGE_FREE_PP = 2;
export const MARK_SOURCE = "spellbladesMark";
export const MARK_FEET = 60;
export const MARK_DICE = "1d6";
export const MARK_LABEL = "Spellblade’s Mark";
export const RETRIBUTION_STEP = "eldritchArts.magicalRetribution";
export const PHYSICAL_TYPES = Object.freeze(["bludgeoning", "piercing", "slashing"]);
/** Bespell Weapon's table: the eight schools (data/spell-tables.mjs SPELL_SCHOOLS). */
export const BESPELL_SCHOOLS = Object.freeze({
  alteration: "physical", translocation: "physical",
  enchantment: "mental", insight: "mental", shadow: "mental",
  invocation: "dealt", soul: "essence", warding: "force"
});

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const live = (i) => !(i.type === "ability" && i.system?.active === false);
const ownedFeat = (actor, name) => items(actor).find((i) => i.type === "feat" && norm(i.name) === norm(name)) ?? null;
const traitList = (v) => (Array.isArray(v) ? v : String(v ?? "").split(/[,;]/)).map((t) => norm(t)).filter(Boolean);
const mflag = (doc, key) => doc?.flags?.[MODULE_ID]?.[key] ?? doc?.getFlag?.(MODULE_ID, key);

/** The core's own Runemage archetype feat (magic/runemage.mjs `isRunemage`). */
export const isRunemageActor = (actor) => items(actor).some((i) => ["feat", "ability"].includes(i.type) && norm(i.name) === "runemage");

/**
 * Does this spell use a Symbol component when a Runemage casts it? Symbol
 * replaces verbal, material and focus (runemage.mjs REPLACED_COMPONENTS); an
 * innate or componentless spell has none (symbolComponents' rule).
 */
export function usesSymbol(spellData = {}, { innate = false, runemage = true } = {}) {
  if (!runemage || innate || spellData?.innate) return false;
  const c = spellData?.components ?? {};
  return Boolean(c.verbal || c.material || c.focus);
}

/** How many sigils a day: one, three with Runic Reservoir. */
export const sigilCount = ({ reservoir = false } = {}) => (reservoir ? RESERVOIR_SIGILS : 1);

/** Is this sigil ready to activate now? Living Script's reform: 10 rounds of that combat, or 60 s. */
export function sigilReady(sigil, { combat = null, worldTime = 0 } = {}) {
  if (!sigil) return false;
  if (sigil.state === "ready") return true;
  if (sigil.state !== "reforming") return false;
  const r = sigil.reformRound;
  if (r && combat && String(r.combatId) === String(combat.id) && int(combat.round) >= int(r.round)) return true;
  return Number(worldTime) >= Number(sigil.reformAt ?? Infinity);
}

/** "only one Prepared Sigil per round": the stamp of the last activation. */
export function sigilLockHeld(lock, { combat = null, worldTime = 0 } = {}) {
  if (!lock) return false;
  if (combat) return String(lock.combatId ?? "") === String(combat.id) && int(lock.round) === int(combat.round);
  if (lock.combatId) return false;
  return Number(worldTime) - Number(lock.worldTime ?? -Infinity) < ROUND_SECONDS;
}

/** The stamp an activation writes. */
export const roundStamp = ({ combat = null, worldTime = 0 } = {}) => (combat ? { combatId: String(combat.id), round: int(combat.round) } : { worldTime: Number(worldTime) || 0 });

/** The sigil after its cast settled: spent; with Living Script, reforming, or kept on a Heroic. */
export function sigilAfterCast(sigil, { degree = "", livingScript = false, combat = null, worldTime = 0 } = {}) {
  if (!livingScript) return { ...sigil, state: "spent" };
  if (norm(degree) === "heroic") return { ...sigil, state: "ready" };
  return {
    ...sigil, state: "reforming",
    reformAt: (Number(worldTime) || 0) + SIGIL_REFORM_SECONDS,
    reformRound: combat ? { combatId: String(combat.id), round: int(combat.round) + SIGIL_REFORM_ROUNDS } : null
  };
}

/** Prepared Sigil's pick: a castable spell, not innate, with a component Symbol replaces. */
export const sigilSpellEligible = (spell) => spell?.type === "spell" && usesSymbol(spell.system ?? {}, { innate: Boolean(spell.system?.innate) });

/** The ley-benefit marker's data (for Block 2's leyBenefits; Appendix C N6). */
export function leyBenefitMarkerData({ level = 0, name = "", expiry = null } = {}) {
  return effectData(LEY_BENEFIT_SOURCE, {
    name: `Ley line benefit${name ? ` — ${name}` : ""} (level ${int(level)})`, img: "icons/magic/light/explosion-star-glow-blue-purple.webp",
    description: "You are gaining the benefits of a ley line (Ley-Etched Symbol reads this).",
    module: { leyLevel: int(level), leyName: String(name ?? "") }, expiry
  });
}

/** The marker on an actor: `{ level, name }`, or null. */
export function leyBenefitOf(actor) {
  const e = ownEffects(actor, LEY_BENEFIT_SOURCE).find((x) => !x.disabled);
  return e ? { level: int(mflag(e, "leyLevel")), name: String(mflag(e, "leyName") ?? "") } : null;
}

/** Ley-Etched Symbol's offer (Q125): marker on, a Symbol cast, not innate or an item's, the round free. */
export function leyEtchedOffered({ ctx = {}, owned = false, runemage = false, marker = null, lock = null, combat = null, worldTime = 0 } = {}) {
  if (!owned || !runemage || !marker) return false;
  if (ctx.innate || ctx.itemCast || ctx.cantrip) return false;
  if (!usesSymbol(ctx.spellData ?? {}, { innate: ctx.innate, runemage })) return false;
  return !sigilLockHeld(lock, { combat, worldTime });
}

/** Its answer: 1 PP off what is paid, floor 1 (Q93: payment only). */
export const leyEtchedAnswer = () => ({ discount: { pp: 1, floor: 1 }, lines: ["Ley-Etched Symbol: the ley line completes part of the rune — 1 PP less to pay (minimum 1 PP)."] });

/** "a Fumble or worse result". */
export const leyBacklashDue = (degree) => ["fumble", "blunder"].includes(norm(degree));

/** A birthright by name, the Sorcerer's own or one borrowed by High Mage or Birthrager (Q100). */
export function birthrightNames(actor) {
  const out = new Set();
  const own = birthrightOf(actor);
  if (own) out.add(norm(own.name));
  for (const i of items(actor)) {
    if (!live(i)) continue;
    // A HIGH MAGE'S OR BIRTHRAGER'S PICK: the name group A's Use writes on the
    // archetype feat (block6a-automations.mjs BORROWED_BIRTHRIGHT_FLAG).
    const pick = i.type === "feat" ? i.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG] : null;
    if (pick) out.add(norm(pick));
  }
  return out;
}

/** G9: Arcane Study's "Arcanum Birthright". */
export const arcaneStudyBlock = (actor) => (birthrightNames(actor).has("arcanum") ? null : "it needs the Arcanum birthright (a Sorcerer's, or a High Mage's or Birthrager's pick).");
/** G9: Resonance Surge's "Wild Birthright". */
export const resonanceSurgeBlock = (actor) => (birthrightNames(actor).has("wild") ? null : "it needs the Wild birthright.");
/** G9: "a Sorcerer with the Wild Birthright cannot take this feat". */
export const highMagicResonanceBlock = (actor) => (birthrightNames(actor).has("wild") ? "a Sorcerer with the Wild birthright cannot take it." : null);

/** Arcane Study's book: an arcane spell of PP 1 to caster level + 1, not specialist, not a hex (bookAdditionEligible's rule). */
export function arcaneScribable(entry, { casterLevel = 0 } = {}) {
  const sys = entry?.system ?? {};
  const pp = Number(sys.ppCost ?? -1);
  if (!Number.isFinite(pp) || pp < 1 || pp > int(casterLevel) + 1) return false;
  if (sys.specialist || entry?.flags?.[SYSTEM_ID]?.eaHex) return false;
  return traitList(sys.tradition).includes("arcane");
}

/** The spell's school (the first of the eight its traits carry), or "". */
export const schoolOf = (traits) => traitList(traits).find((t) => BESPELL_SCHOOLS[t]) ?? "";

/** Bespell Weapon: the types a school offers. */
export function bespellTypes({ school = "", damageTypes = [], weaponType = "" } = {}) {
  const kind = BESPELL_SCHOOLS[norm(school)];
  if (!kind) return [];
  if (kind === "physical") return PHYSICAL_TYPES.filter((t) => !traitList(weaponType).includes(t));
  if (kind === "dealt") {
    const dealt = [...new Set(traitList(damageTypes))];
    return dealt.length ? dealt : ["force"];
  }
  return [kind];
}

/** Bespell's rider: the weapon's, to the end of the turn. */
export const bespellRider = ({ type, weaponId }) => ({ label: "Bespell Weapon", dice: BESPELL_DICE, damageType: type, scope: "any", weaponScoped: true, weaponId, once: false });

/** May the last spell be siphoned now? This turn in combat; out of combat, the last cast. */
export function bespellDue(last, { combat = null } = {}) {
  if (!last?.name) return false;
  if (!combat) return !last.combatId;
  return String(last.combatId) === String(combat.id) && int(last.round) === int(combat.round) && int(last.turn) === int(combat.turn);
}

/** May it be sustained (Q143)? The last Bespell lasted to the end of the turn one round before. */
export function bespellSustainable(last, { combat = null } = {}) {
  if (!combat || !last?.bespelled) return false;
  return String(last.bespelled.combatId) === String(combat.id) && int(last.bespelled.round) === int(combat.round) - 1;
}

/** The infused weapon's id (Block 4's Infuse Weapon). */
export const infusedWeaponId = (actor) => String((actor?.flags?.[SYSTEM_ID]?.[INFUSION_FLAG] ?? actor?.getFlag?.(SYSTEM_ID, INFUSION_FLAG))?.weaponId ?? "");

/** Bonded Infusion's state: `{ infused, held, weapon }`. */
export function bondedInfusionState(actor) {
  const id = infusedWeaponId(actor);
  const weapon = id ? items(actor).find((i) => i.id === id && i.type === "weapon") ?? null : null;
  return { infused: Boolean(weapon), held: Boolean(weapon?.system?.equipped), weapon };
}

/** The feat's flags while infused / held (Q144). */
export function bondedInfusionFlags({ infused = false, held = false } = {}) {
  return {
    spellAdder: infused ? BONDED_ADDER : 0,
    freeSomatic: held ? { traditions: [...ALL_TRADITIONS], needsPouch: false, label: "Bonded Infusion (the infused weapon)" } : null
  };
}

/** Bonded Infusion's casting row (Q144). */
export function bondedInfusionRow({ held = false, innate = false, itemCast = false, focusSetAside = false } = {}) {
  if (!held || innate || itemCast || focusSetAside) return null;
  return { label: "Bonded Infusion (infused weapon)", value: BONDED_FOCUS_BONUS, type: "item" };
}

/** High Mage's Focus: how many picks the BSB allows. */
export const focusPicksAllowed = (bsb) => (int(bsb) >= HMF_SECOND_BSB ? 2 : 1);
/** The BSB as the core's prerequisites read it. */
export const bsbOf = (actor) => int(actor?.system?.magic?.bsb) + int(actor?.system?.progression?.bsb);
/** A High Magic spell (the core's Highmagic trait). */
export const isHighMagicSpell = (spellData) => traitList(spellData?.traits).some((t) => t === "highmagic" || t === "high magic");
/** Its casting row: +2, the casting's degree only. */
export const highMagesFocusRow = () => ({ label: "High Mage’s Focus (Casting DC −2)", value: HMF_BONUS, type: "untyped", castingOnly: true });

/** High Magic Resonance's daily remap: the first casting Fumble (Q147). */
export const hmrRemapDue = ({ degree = "", itemCast = false, used = false } = {}) => norm(degree) === "fumble" && !itemCast && !used;

/** A casting time read as AP, for Metamagic Adept's "1-2 AP" (a time unit is not an AP casting time). */
export function castTimeAPOf(castAP) {
  if (typeof castAP === "number") return Math.max(0, Math.trunc(castAP));
  const t = norm(castAP);
  if (!t || /second|minute|hour|day|week|round|reaction|free/.test(t)) return null;
  const m = /^(\d+)/.exec(t);
  return m ? int(m[1]) : null;
}
export const adeptCastTimeOk = (castAP) => { const ap = castTimeAPOf(castAP); return ap === 1 || ap === 2; };

/** Resonance Surge consumes on (and forces a Resonance for) the next levelled spell you cast. */
export function surgeConsumes(ctx = {}) {
  if (ctx.itemCast || ctx.ritual || ctx.innate || ctx.threaded || ctx.stored || ctx.cantrip) return false;
  return int(ctx.spellData?.ppCost ?? ctx.spell?.system?.ppCost) > 0;
}
/** The G1 key the surge's credit is taken under (the registry lower-cases it). */
export const SURGE_KEY = "resonanceSurge";
/** Did this cast take the surge (its G1 key among the cast's metamagic)? */
export const surgeTaken = (ctx = {}) => (Array.isArray(ctx.metamagic) ? ctx.metamagic : []).some((k) => norm(k) === norm(SURGE_KEY));
/** The credit (G1 `freeWarpPP`): up to 2 PP of the spell's own warps, no PP and no DC (Q148). */
export const surgeAnswer = () => ({ freeWarpPP: SURGE_FREE_PP, lines: [`Resonance Surge: up to ${SURGE_FREE_PP} PP of this spell's warping is free and adds nothing to the Casting DC; a Resonance event follows.`] });

/** Spellblade's Mark's four parts on one effect, against one creature (uuid). */
export function markFlags(uuid) {
  const u = String(uuid ?? "");
  return {
    conditionals: [{ kind: "modifier", value: 1, type: "circumstance", label: MARK_LABEL, scope: "melee Strikes against your Mark", auto: true, when: { checkTypes: ["attack"], attackModes: ["melee"], attackForms: ["weapon", "unarmed", "natural"], targetUuids: [u] } }],
    strikeRider: { label: MARK_LABEL, dice: MARK_DICE, damageType: "force", scope: "any", once: false, targetUuids: [u] },
    spellDamageRider: { label: MARK_LABEL, dice: MARK_DICE, damageType: "force", when: { targetUuids: [u], attackOnly: true } },
    defenceDC: [{ dc: "defence", value: 1, type: "circumstance", label: MARK_LABEL, scope: "against your Mark's attacks", when: { sourceUuids: [u] } }]
  };
}
/** The spell-attack row (G14): attack-only, against the Mark. */
export function markGateRow({ markUuid = "", targetUuids = [], attack = false } = {}) {
  if (!markUuid || !attack || !(targetUuids ?? []).includes(markUuid)) return null;
  return { label: MARK_LABEL, value: 1, type: "circumstance", attackOnly: true };
}

/** Magical Retribution's trigger in the window: a melee Strike's damage, its striker known. */
export const retributionWants = (ctx = {}) => Boolean(ctx.sourceUuid) && ctx.context?.kind === "strike" && ctx.context?.melee === true;

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const worldTime = () => Number(globalThis.game?.time?.worldTime ?? 0);
const combatState = (actor) => { const c = combatFor(actor); return c ? { id: c.id, round: int(c.round), turn: int(c.turn) } : null; };
const fighting = (actor) => Boolean(combatFor(actor));

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendAP(actor, label, ap = 1) {
  if (!fighting(actor) || ap <= 0) return true;
  const have = int(actor.system?.resources?.ap?.value);
  if (have < ap) return warn(`${label}: ${ap} AP required.`);
  await actor.update({ "system.resources.ap.value": have - ap });
  return true;
}
const hasAP = (actor, ap) => !fighting(actor) || int(actor.system?.resources?.ap?.value) >= ap;

async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}

async function reactionBlocked(actor, traits = "") {
  if (!actor) return "no creature";
  if (await h().isDead?.(actor)) return "dead";
  return (await h().reactionRefusal?.(actor, traits)) || "";
}

/** Set this user's targets for the length of `run`, then put them back. */
async function withTargets(ids, run) {
  const tokens = globalThis.canvas?.tokens?.placeables ?? [];
  const previous = Array.from(game.user?.targets ?? []).map((t) => t.id);
  const set = (want) => {
    const s = new Set(want);
    for (const t of tokens) if (t.isTargeted !== s.has(t.id)) t.setTarget(s.has(t.id), { user: game.user, releaseOthers: false, groupSelection: true });
  };
  try {
    set(ids);
    return await run();
  } finally {
    set(previous);
  }
}

/** The weapons in hand (equipped, not natural attacks), melee only if asked. */
function wieldedWeapons(actor, { meleeOnly = false } = {}) {
  return items(actor).filter((i) => i.type === "weapon" && i.system?.equipped && !/natural/i.test(String(i.system?.category ?? ""))
    && (!meleeOnly || String(i.system?.attackMode ?? "melee") !== "missile"));
}
async function chooseWeapon(actor, label, opts = {}) {
  const list = wieldedWeapons(actor, opts);
  if (!list.length) { warn(`${label}: you are wielding no ${opts.meleeOnly ? "melee " : ""}weapon.`); return null; }
  if (list.length === 1) return list[0];
  const id = await h().chooseFromList(label, "Which weapon?", list.map((w) => [w.id, w.name]));
  return id ? list.find((w) => w.id === id) ?? null : null;
}

const firstTarget = () => Array.from(globalThis.game?.user?.targets ?? [])[0] ?? null;

/* ------------------------------------------------------------------ */
/* Prepared Sigil, Runic Reservoir, Living Script                       */
/* ------------------------------------------------------------------ */

const sigilsOf = (feat) => (Array.isArray(mflag(feat, SIGILS_FLAG)) ? mflag(feat, SIGILS_FLAG) : []);

const preparedSigil = {
  hint: "Inscribe today's Prepared Sigil(s): a spell you can cast today with a Symbol (once until your next daily preparation).",
  async use(actor, item) {
    if (mflag(item, SIGILS_INSCRIBED_FLAG)) return warn("Prepared Sigil: today's sigils are inscribed — your next daily preparation clears them.");
    if (!isRunemageActor(actor)) return warn("Prepared Sigil: you are not a Runemage (no Symbol to inscribe).");
    const count = sigilCount({ reservoir: Boolean(ownedFeat(actor, "Runic Reservoir")) });
    const castable = [];
    for (const s of items(actor)) if (sigilSpellEligible(s) && (await h().spellCastable(actor, s))) castable.push(s);
    if (!castable.length) return warn("Prepared Sigil: you can cast no spell with a Symbol today.");
    const picked = [];
    while (picked.length < count) {
      const pool = castable.filter((s) => !picked.some((p) => p.spellId === s.id));
      if (!pool.length) break;
      const id = await h().chooseFromList(`Prepared Sigil — ${picked.length + 1} of ${count}`, picked.length ? "Another spell (cancel when done):" : "Which spell's Symbol do you inscribe?", pool.map((s) => [s.id, `${s.name} (PP ${int(s.system?.ppCost)})`]));
      const s = pool.find((x) => x.id === id);
      if (!s) break;
      picked.push({ spellId: s.id, name: s.name, state: "ready" });
    }
    if (!picked.length) return false;
    await item.setFlag(MODULE_ID, SIGILS_FLAG, picked);
    await item.setFlag(MODULE_ID, SIGILS_INSCRIBED_FLAG, true);
    await card(actor, "Prepared Sigil", [
      line(`Inscribed (on your skin, clothing, focus, book or another carried item — yours to say): <strong>${picked.map((p) => esc(p.name)).join(", ")}</strong>.`),
      line("<em>When you cast it from your sheet you are asked whether to activate the sigil: no free hand or room for the Symbol, 1 AP less casting time (minimum 1).</em>")
    ]);
    return true;
  }
};

/**
 * The cast prelude (registerCastPrelude): a ready sigil's spell, the round
 * free, asks whether to activate it; yes casts through the core's
 * prepared-Symbol cast (G25), whose own call meets no prelude.
 */
export async function preparedSigilPrelude(ctx = {}) {
  const { actor, spell } = ctx;
  const feat = ownedFeat(actor, "Prepared Sigil");
  if (!feat || !spell || !isRunemageActor(actor)) return null;
  const now = { combat: combatState(actor), worldTime: worldTime() };
  const sigil = sigilsOf(feat).find((s) => s.spellId === spell.id);
  if (!sigil || !sigilReady(sigil, now)) return null;
  if (sigilLockHeld(mflag(feat, SIGIL_LOCK_FLAG), now)) return null;
  if (!(await confirm("Prepared Sigil", `Activate your Prepared Sigil of <strong>${esc(spell.name)}</strong>? No free hand or room is needed for the Symbol, and the casting time is 1 AP less (minimum 1 AP). Somatic components are unaffected.`))) return null;
  const result = await h().castSpell(actor, spell, { preparedSymbol: { label: "Prepared Sigil" } });
  return { handled: true, result };
}

async function sigilSettled(ctx) {
  const { actor, spell } = ctx;
  // A REFUNDED CAST (called off at the target picker) did not use the sigil.
  if (!ctx.preparedSymbol || !spell || ctx.refunded) return;
  const feat = ownedFeat(actor, "Prepared Sigil");
  if (!feat) return;
  const now = { combat: combatState(actor), worldTime: worldTime() };
  const living = Boolean(ownedFeat(actor, "Living Script"));
  const list = sigilsOf(feat).map((s) => (s.spellId === spell.id ? sigilAfterCast(s, { degree: ctx.degree, livingScript: living, ...now }) : s));
  await feat.setFlag(MODULE_ID, SIGILS_FLAG, list);
  await feat.setFlag(MODULE_ID, SIGIL_LOCK_FLAG, roundStamp(now));
  const after = list.find((s) => s.spellId === spell.id);
  const said = after?.state === "spent" ? "The sigil fades until your next daily preparation."
    : after?.state === "ready" ? "A Heroic result: <strong>Living Script</strong> — the sigil reforms at once."
      : "<strong>Living Script</strong>: the sigil reforms in 1 minute.";
  await card(actor, "Prepared Sigil", [line(`${esc(spell.name)}: ${said}`)]);
}

/* ------------------------------------------------------------------ */
/* Ley-Etched Symbol (G1)                                               */
/* ------------------------------------------------------------------ */

/** Lay the ley-benefit marker (Block 2's leyBenefits calls this; Appendix C N6). */
export async function layLeyBenefitMarker(actor, { level = 0, name = "", expiry = null } = {}) {
  if (!actor) return null;
  const old = ownEffects(actor, LEY_BENEFIT_SOURCE).map((e) => e.id);
  if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old);
  return h().createEffectsOn(actor, [leyBenefitMarkerData({ level, name, expiry })]);
}

export const LEY_ETCHED_METAMAGIC = Object.freeze({
  feat: "Ley-Etched Symbol",
  label: "Ley-Etched Symbol",
  hint: "The ley line completes part of the rune: 1 PP less to pay (minimum 1). Once a round; a Fumble brings the line's backlash.",
  scope: { innate: false, item: false },
  needsSpell: true,
  applies(ctx = {}) {
    const actor = ctx.actor;
    const feat = ownedFeat(actor, "Ley-Etched Symbol");
    return leyEtchedOffered({ ctx, owned: Boolean(feat), runemage: isRunemageActor(actor), marker: leyBenefitOf(actor), lock: mflag(feat, LEY_ETCHED_LOCK_FLAG), combat: combatState(actor), worldTime: worldTime() });
  },
  apply() { return leyEtchedAnswer(); },
  async after(ctx = {}) {
    const actor = ctx.actor;
    const feat = ownedFeat(actor, "Ley-Etched Symbol");
    if (feat) await feat.setFlag(MODULE_ID, LEY_ETCHED_LOCK_FLAG, roundStamp({ combat: combatState(actor), worldTime: worldTime() }));
    if (!leyBacklashDue(ctx.degree)) return null;
    const marker = leyBenefitOf(actor);
    const level = Math.max(1, int(marker?.level));
    await rollTable(actor, { table: LEY_LINE_EFFECTS, column: "b", title: `Ley-Etched Symbol — the ley line's backlash (level ${level})`, level, expiry: expiryFor("endOfNextTurn", actor), source: "leyLineBacklash" });
    return { lines: [`Ley-Etched Symbol: a ${esc(ctx.degree)} on an enhanced spell — the ley line's backlash (level ${level}) is rolled, to the end of your next turn.`] };
  }
});

/* ------------------------------------------------------------------ */
/* Arcane Study                                                         */
/* ------------------------------------------------------------------ */

const bookOf = (feat) => (Array.isArray(mflag(feat, ARCANE_BOOK_FLAG)) ? mflag(feat, ARCANE_BOOK_FLAG) : []);
const entryUuid = (e) => String(e?.uuid ?? (e?.pack ? `Compendium.${e.pack.collection}.Item.${e._id}` : ""));

async function scribeSpell(actor, feat) {
  const casterLevel = int(actor.system?.magic?.casterLevelValue);
  const book = bookOf(feat);
  const pool = (await spellIndex()).filter((e) => arcaneScribable(e, { casterLevel }) && !book.some((b) => b.uuid === entryUuid(e))).sort((a, b) => String(a.name).localeCompare(String(b.name)));
  if (!pool.length) return warn("Arcane Study: there is no arcane spell you could scribe now.");
  const id = await h().chooseFromList("Arcane Study — scribe a spell", "Which arcane spell (Learn a Spell's time, materials and Arcana check)?", pool.map((e, i) => [String(i), `${e.name} (PP ${int(e.system?.ppCost)})`]));
  const entry = id !== null && id !== undefined && id !== "" ? pool[int(id)] : null;
  if (!entry) return false;
  const pp = int(entry.system?.ppCost);
  const terms = await h().learnSpellTerms(pp);
  const dc = int(await h().learnSpellDC(entry)) || int(terms.dc);
  if (!(await confirm("Arcane Study", `${esc(entry.name)}: ${terms.hours} hour(s), materials ${terms.gp} gp, and an Arcana check against DC ${dc}. Go ahead?`))) return false;
  const purse = Number(await h().goldOf(actor)) || 0;
  if (purse < terms.gp) return warn(`Arcane Study: the materials cost ${terms.gp} gp (you have ${purse}).`);
  const check = await h().rollCheck({ actor, type: "skill", subject: TRADITION_SKILL.arcane, label: `Arcane Study — scribe ${entry.name}`, dc });
  const degree = norm(check?.outcome?.degree?.key);
  const outcome = await h().learnSpellOutcome(degree);
  const cost = outcome?.materialsConsumed === "full" ? terms.gp : outcome?.materialsConsumed === "half" ? Math.floor(terms.gp / 2) : 0;
  if (cost) await h().deductGold(actor, cost);
  const learned = Boolean(outcome?.learned);
  if (learned) await feat.setFlag(MODULE_ID, ARCANE_BOOK_FLAG, [...book, { uuid: entryUuid(entry), name: entry.name, pp }]);
  await card(actor, "Arcane Study", [line(`${esc(entry.name)}: <strong>${esc(degree || "—")}</strong>. ${learned ? "It is scribed into your spellbook." : "Not scribed."} ${terms.hours} hour(s) spent; materials ${cost ? `${cost} gp consumed` : "kept"}.`)]);
  return learned;
}

/** Undo yesterday's pick: the day's spell removed, the discount taken back. */
async function arcaneStudyRevert(actor, feat) {
  const day = items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.[ARCANE_DAILY_FLAG]);
  if (day.length) await actor.deleteEmbeddedDocuments("Item", day.map((i) => i.id));
  const today = mflag(feat, ARCANE_TODAY_FLAG);
  if (today?.mode === "discount") {
    const spell = actor.items?.get?.(today.spellId);
    if (spell) await spell.setFlag(SYSTEM_ID, "warpDiscount", Math.max(0, int(spell.getFlag?.(SYSTEM_ID, "warpDiscount") ?? spell.flags?.[SYSTEM_ID]?.warpDiscount) - 1));
  }
  if (today) await feat.unsetFlag(MODULE_ID, ARCANE_TODAY_FLAG);
}

async function arcaneStudyPick(actor, feat, prompt) {
  const book = bookOf(feat);
  if (!book.length) return warn("Arcane Study: your spellbook is empty — scribe a spell first.");
  const id = await h().chooseFromList("Arcane Study", prompt, book.map((b, i) => [String(i), `${b.name} (PP ${int(b.pp)})`]));
  const pick = id !== null && id !== undefined && id !== "" ? book[int(id)] : null;
  if (!pick) return false;
  const known = items(actor).find((i) => i.type === "spell" && norm(i.name) === norm(pick.name) && !i.flags?.[MODULE_ID]?.[ARCANE_DAILY_FLAG]);
  if (known) {
    await known.setFlag(SYSTEM_ID, "warpDiscount", int(known.getFlag?.(SYSTEM_ID, "warpDiscount") ?? known.flags?.[SYSTEM_ID]?.warpDiscount) + 1);
    await feat.setFlag(MODULE_ID, ARCANE_TODAY_FLAG, { mode: "discount", spellId: known.id, name: known.name });
    await card(actor, "Arcane Study", [line(`<strong>${esc(known.name)}</strong> is already in your repertoire: its warping costs 1 PP less today (minimum 1), until your next daily preparation.`)]);
    return true;
  }
  const fromUuid = globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid;
  const doc = fromUuid ? await fromUuid(pick.uuid) : null;
  if (!doc) return warn(`Arcane Study: ${pick.name} is not in the spells compendium any more.`);
  const data = doc.toObject();
  delete data._id;
  data.system = { ...data.system, prepared: true };
  data.flags = { ...data.flags, [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: feat.id, sourceName: feat.name, requested: doc.name } }, [MODULE_ID]: { ...(data.flags?.[MODULE_ID] ?? {}), [ARCANE_DAILY_FLAG]: true } };
  const [created] = await actor.createEmbeddedDocuments("Item", [data]);
  await feat.setFlag(MODULE_ID, ARCANE_TODAY_FLAG, { mode: "add", spellId: created?.id ?? "", name: pick.name });
  await card(actor, "Arcane Study", [line(`<strong>${esc(pick.name)}</strong> joins your repertoire until your next daily preparation.`)]);
  return true;
}

const arcaneStudy = {
  hint: "Scribe an arcane spell into your book, or make today's pick.",
  async use(actor, item) {
    const opts = [["scribe", "Scribe a spell (Learn a Spell)"]];
    if (!mflag(item, ARCANE_TODAY_FLAG)) opts.push(["pick", "Today's pick (if you missed it at daily preparation)"]);
    const choice = await h().chooseFromList("Arcane Study", "What do you do?", opts);
    if (choice === "scribe") return scribeSpell(actor, item);
    if (choice === "pick") return arcaneStudyPick(actor, item, "Today's spell from your book");
    return false;
  }
};

/* ------------------------------------------------------------------ */
/* Bespell Weapon                                                       */
/* ------------------------------------------------------------------ */

async function bespellNow(actor, item, last) {
  const school = last.school;
  const weapon = await chooseWeapon(actor, "Bespell Weapon");
  if (!weapon) return false;
  const types = bespellTypes({ school, damageTypes: last.damageTypes, weaponType: weapon.system?.damageType });
  if (!types.length) return warn(`Bespell Weapon: ${last.name} has no spell school, so it gives no damage type.`);
  const type = types.length === 1 ? types[0] : await h().chooseFromList("Bespell Weapon", "Which damage type?", types.map((t) => [t, t]));
  if (!type || !types.includes(type)) return false;
  await layBespell(actor, { type, weapon, from: last.name });
  const c = combatState(actor);
  await actor.setFlag(MODULE_ID, BESPELL_LAST_FLAG, { ...last, bespelled: c ? { combatId: c.id, round: c.round, type, weaponId: weapon.id } : { type, weaponId: weapon.id } });
  await card(actor, "Bespell Weapon", [line(`The residue of <strong>${esc(last.name)}</strong> (${esc(school)}) runs into your <strong>${esc(weapon.name)}</strong>: +${BESPELL_DICE} secondary <strong>${esc(type)}</strong> damage until the end of your turn.`)]);
  return true;
}

async function layBespell(actor, { type, weapon, from }) {
  const old = ownEffects(actor, BESPELL_SOURCE).map((e) => e.id);
  if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old);
  await h().createEffectsOn(actor, [effectData(BESPELL_SOURCE, {
    name: `Bespell Weapon: ${weapon.name} +${BESPELL_DICE} ${type}`, img: "icons/svg/fire.svg",
    description: `${weapon.name} deals ${BESPELL_DICE} secondary ${type} damage until the end of your turn (${from}).`,
    system: { strikeRider: bespellRider({ type, weaponId: weapon.id }) },
    expiry: expiryFor("endOfTurn", actor)
  })]);
}

async function bespellSustain(actor, last) {
  const b = last.bespelled;
  const weapon = actor.items?.get?.(b.weaponId);
  if (!weapon?.system?.equipped) return warn("Bespell Weapon: you are no longer wielding that weapon.");
  if (!(await h().traitGate(actor, { key: "bespellSustain", traits: "Concentrate" }, "Bespell Weapon (sustain)"))) return false;
  if (!(await spendAP(actor, "Bespell Weapon (sustain)", 1))) return false;
  await h().recordTraitUsage(actor, { key: "bespellSustain", traits: "Concentrate" });
  await layBespell(actor, { type: b.type, weapon, from: last.name });
  const c = combatState(actor);
  await actor.setFlag(MODULE_ID, BESPELL_LAST_FLAG, { ...last, bespelled: { ...b, combatId: c.id, round: c.round } });
  await card(actor, "Bespell Weapon", [line(`Sustained (1 AP, Concentrate): your <strong>${esc(weapon.name)}</strong> keeps its +${BESPELL_DICE} secondary <strong>${esc(b.type)}</strong> damage until the end of this turn.`)]);
  return true;
}

const bespellWeapon = {
  hint: "Free: siphon this turn's spell into a wielded weapon (1d6 secondary by school); or sustain it (1 AP).",
  async use(actor, item) {
    const last = mflag(actor, BESPELL_LAST_FLAG) ?? null;
    const combat = combatState(actor);
    const now = bespellDue(last, { combat });
    const sustain = bespellSustainable(last, { combat });
    if (!now && !sustain) return warn("Bespell Weapon: cast a spell this turn first (or sustain last turn's on the turn after).");
    if (now && sustain) {
      const pick = await h().chooseFromList("Bespell Weapon", "Which?", [["now", `Siphon ${last.name} (free)`], ["sustain", "Sustain last turn's (1 AP)"]]);
      if (pick === "sustain") return bespellSustain(actor, last);
      if (pick !== "now") return false;
      return bespellNow(actor, item, last);
    }
    return now ? bespellNow(actor, item, last) : bespellSustain(actor, last);
  }
};

async function bespellRemember(ctx) {
  const { actor, spell, spellData } = ctx;
  if (!ownedFeat(actor, "Bespell Weapon") || !ctx.cast || ctx.itemCast || ctx.threaded) return;
  const c = combatState(actor);
  const prior = mflag(actor, BESPELL_LAST_FLAG) ?? {};
  const damageTypes = [spellData?.damage?.type, spellData?.secondaryDamage?.type].map((t) => norm(t)).filter(Boolean);
  await actor.setFlag(MODULE_ID, BESPELL_LAST_FLAG, {
    name: spell?.name ?? "", school: schoolOf(spellData?.traits), damageTypes,
    ...(c ? { combatId: c.id, round: c.round, turn: c.turn } : {}),
    ...(prior.bespelled ? { bespelled: prior.bespelled } : {})
  });
}

/* ------------------------------------------------------------------ */
/* Bonded Infusion                                                      */
/* ------------------------------------------------------------------ */

/** Bring the feat's spell adder and free somatic in line with the infusion. */
export async function syncBondedInfusion(actor) {
  const feat = ownedFeat(actor, "Bonded Infusion");
  if (!feat) return false;
  const want = bondedInfusionFlags(bondedInfusionState(actor));
  const have = { spellAdder: int(feat.flags?.[SYSTEM_ID]?.spellAdder), freeSomatic: feat.flags?.[SYSTEM_ID]?.freeSomatic ?? null };
  if (have.spellAdder === want.spellAdder && Boolean(have.freeSomatic) === Boolean(want.freeSomatic)) return false;
  await feat.update({
    [`flags.${SYSTEM_ID}.spellAdder`]: want.spellAdder,
    [`flags.${SYSTEM_ID}.${want.freeSomatic ? "freeSomatic" : "-=freeSomatic"}`]: want.freeSomatic ?? null
  });
  return true;
}

export async function bondedInfusionGate(ctx = {}) {
  const actor = ctx.actor;
  if (!ownedFeat(actor, "Bonded Infusion")) return null;
  const state = bondedInfusionState(actor);
  // HIGH MAGIC SETS A FOCUS ASIDE (high-magic.mjs highMagicFocusSetAside).
  const focusSetAside = Boolean(ctx.highMagic) && !items(actor).some((i) => live(i) && i.flags?.[SYSTEM_ID]?.highMagicFocus === true);
  const row = bondedInfusionRow({ held: state.held, innate: ctx.innate, itemCast: ctx.itemCast, focusSetAside });
  if (!row) return state.held && focusSetAside && !ctx.innate && !ctx.itemCast ? { lines: ["Bonded Infusion: High Magic sets the infused weapon aside as a focus."] } : null;
  return { modifiers: [row], lines: [`Bonded Infusion: ${esc(state.weapon.name)} is your casting focus (+${BONDED_FOCUS_BONUS} item).`] };
}

/* ------------------------------------------------------------------ */
/* Call Bonded Weapon, Considered Attack                                */
/* ------------------------------------------------------------------ */

/** The bonded weapons on the sheet: the Blade Ally's, today's infused one. */
export function bondedWeapons(actor) {
  const out = [];
  const ally = items(actor).find((i) => i.flags?.[SYSTEM_ID]?.bladeAlly?.weaponId);
  const allyId = ally?.flags?.[SYSTEM_ID]?.bladeAlly?.weaponId;
  const allyWeapon = allyId ? actor.items?.get?.(allyId) ?? items(actor).find((i) => i.id === allyId) : null;
  if (allyId) out.push({ kind: "Blade Ally", id: allyId, weapon: allyWeapon ?? null, name: allyWeapon?.name ?? ally.flags[SYSTEM_ID].bladeAlly.weaponName ?? "" });
  const inf = infusedWeaponId(actor);
  if (inf && inf !== allyId) { const w = actor.items?.get?.(inf) ?? items(actor).find((i) => i.id === inf); out.push({ kind: "Infused Weapon", id: inf, weapon: w ?? null, name: w?.name ?? "" }); }
  return out;
}

const callBondedWeapon = {
  hint: "1 AP (manipulate): your Blade Ally or infused weapon teleports into your hand.",
  async use(actor) {
    const list = bondedWeapons(actor);
    if (!list.length) return warn("Call Bonded Weapon: you have no Blade Ally weapon and no infused weapon today.");
    let pick = list[0];
    if (list.length > 1) {
      const id = await h().chooseFromList("Call Bonded Weapon", "Which weapon?", list.map((b) => [b.id, `${b.name || "?"} (${b.kind})`]));
      pick = list.find((b) => b.id === id);
      if (!pick) return false;
    }
    if (!pick.weapon) {
      await card(actor, "Call Bonded Weapon", [line(`Your ${esc(pick.kind)} (${esc(pick.name || "the weapon")}) is not on your sheet: if another creature holds it, the GM moves it to you.`)]);
      return false;
    }
    if (pick.weapon.system?.equipped) return warn(`Call Bonded Weapon: ${pick.weapon.name} is already in your hand.`);
    if (!hasAP(actor, 1)) return warn("Call Bonded Weapon: 1 AP required.");
    if (!(await h().traitGate(actor, { key: "callBondedWeapon", traits: "Manipulate" }, "Call Bonded Weapon"))) return false;
    if (!(await spendAP(actor, "Call Bonded Weapon", 1))) return false;
    await h().recordTraitUsage(actor, { key: "callBondedWeapon", traits: "Manipulate" });
    await pick.weapon.update({ "system.equipped": true });
    await card(actor, "Call Bonded Weapon", [
      line(`Your <strong>${esc(pick.weapon.name)}</strong> (${esc(pick.kind)}) teleports into your hand.`),
      line("<em>The two-hand limit is the sheet's to check: if your hands were full, unequip something.</em>")
    ]);
    return true;
  }
};

const consideredAttack = {
  hint: "A Strike for 1 AP more, with +2 to its attack.",
  async use(actor) {
    const weapon = await chooseWeapon(actor, "Considered Attack");
    if (!weapon) return false;
    if (!hasAP(actor, 1 + CONSIDERED_EXTRA_AP)) return warn(`Considered Attack: ${1 + CONSIDERED_EXTRA_AP} AP required (the Strike and 1 more).`);
    const result = await h().rollWeaponAttack(actor, weapon, { extraModifiers: [{ label: "Considered Attack", value: CONSIDERED_BONUS, type: "untyped" }] });
    if (!result) return false;
    await spendAP(actor, "Considered Attack", CONSIDERED_EXTRA_AP);
    await card(actor, "Considered Attack", [line(`A considered Strike with ${esc(weapon.name)}: +${CONSIDERED_BONUS} to the attack, ${CONSIDERED_EXTRA_AP} AP more.`)]);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* High Mage's Focus                                                    */
/* ------------------------------------------------------------------ */

const picksOf = (feat) => (Array.isArray(mflag(feat, HMF_PICKS_FLAG)) ? mflag(feat, HMF_PICKS_FLAG) : []);

const highMagesFocus = {
  hint: "Choose a High Magic spell you know: its Casting DC is 2 lower (a second at BSB +10).",
  async use(actor, item) {
    const picks = picksOf(item);
    const allowed = focusPicksAllowed(bsbOf(actor));
    if (picks.length >= allowed) return warn(`High Mage’s Focus: you have chosen ${picks.length} of ${allowed} (a second when your BSB reaches +${HMF_SECOND_BSB}).`);
    const pool = items(actor).filter((s) => s.type === "spell" && isHighMagicSpell(s.system) && !picks.some((p) => p.id === s.id));
    if (!pool.length) return warn("High Mage’s Focus: you know no High Magic spell (one with the Highmagic trait) to choose.");
    const id = await h().chooseFromList("High Mage’s Focus", "Which High Magic spell?", pool.map((s) => [s.id, s.name]));
    const s = pool.find((x) => x.id === id);
    if (!s) return false;
    await item.setFlag(MODULE_ID, HMF_PICKS_FLAG, [...picks, { id: s.id, name: s.name }]);
    await card(actor, "High Mage’s Focus", [line(`<strong>${esc(s.name)}</strong>: its Casting DC is 2 lower, permanently.`)]);
    return true;
  }
};

export async function highMagesFocusGate(ctx = {}) {
  const feat = ownedFeat(ctx.actor, "High Mage’s Focus");
  if (!feat || ctx.innate || ctx.itemCast || !ctx.spell) return null;
  if (!picksOf(feat).some((p) => p.id === ctx.spell.id)) return null;
  return { modifiers: [highMagesFocusRow()] };
}

/* ------------------------------------------------------------------ */
/* High Magic Resonance, Resonance Surge (G5), Metamagic Adept (G3)     */
/* ------------------------------------------------------------------ */

export const HIGH_MAGIC_RESONANCE = Object.freeze({
  roll(ctx = {}) {
    if (!ctx.highMagic || !ownedFeat(ctx.actor, "High Magic Resonance")) return null;
    return { single: true, label: "High Magic Resonance", line: "High Magic Resonance: the Resonance table is rolled once (High Magic's disadvantage is lifted)." };
  }
});

export async function highMagicResonanceRemap(ctx = {}) {
  const feat = ownedFeat(ctx.actor, "High Magic Resonance");
  if (!feat || !hmrRemapDue({ degree: ctx.degree, itemCast: ctx.itemCast, used: Boolean(mflag(feat, HMR_EASED_FLAG)) })) return null;
  await feat.setFlag(MODULE_ID, HMR_EASED_FLAG, true);
  return { degree: "failure", lines: ["High Magic Resonance: today's first spell Fumble is treated as a Failure (until your next daily preparation)."] };
}

export const RESONANCE_SURGE = Object.freeze({
  force(ctx = {}) {
    if (!ownEffects(ctx.actor, SURGE_SOURCE).length || !surgeConsumes(ctx) || !surgeTaken(ctx)) return null;
    return { reason: "Resonance Surge", line: "the surge's cost" };
  }
});

const resonanceSurge = {
  hint: "Focus: your next levelled spell warps up to 2 PP free (no DC), then a Resonance event.",
  async use(actor) {
    if (ownEffects(actor, SURGE_SOURCE).length) return warn("Resonance Surge: a surge is already armed for your next spell.");
    await h().createEffectsOn(actor, [effectData(SURGE_SOURCE, {
      name: "Resonance Surge: armed", img: "icons/svg/lightning.svg",
      description: "Your next levelled spell may warp up to 2 PP free, adding nothing to the Casting DC; a Resonance event follows it.",
      system: {}
    })]);
    await card(actor, "Resonance Surge", [line(`Armed: your next levelled spell's own warping options are free up to ${SURGE_FREE_PP} PP, and add nothing to the Casting DC. A Resonance event follows it.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return true;
  }
};

async function surgeSettled(ctx) {
  const armed = ownEffects(ctx.actor, SURGE_SOURCE);
  if (!armed.length || ctx.refunded || !surgeConsumes(ctx) || !surgeTaken(ctx)) return;
  await ctx.actor.deleteEmbeddedDocuments("ActiveEffect", armed.map((e) => e.id));
}

/**
 * THE SURGE'S CREDIT, THROUGH G1: a `required` module metamagic, applied
 * without a tick on the armed caster's next levelled spell (never a ritual,
 * an item's, an innate, a stored or a threaded cast), answering
 * `freeWarpPP: 2`. Its key on the cast is what spends the surge and forces
 * the Resonance, so the credit and its cost always meet on one cast.
 */
export const RESONANCE_SURGE_METAMAGIC = Object.freeze({
  feat: "Resonance Surge",
  label: "Resonance Surge",
  hint: "Armed: up to 2 PP of this spell's warping free, no DC; a Resonance event follows.",
  required: true,
  needsSpell: true,
  scope: { innate: false, item: false },
  applies(ctx = {}) { return ownEffects(ctx.actor, SURGE_SOURCE).length > 0 && surgeConsumes(ctx); },
  apply() { return surgeAnswer(); }
});

/** The G3 key as the registry stores it (lower-cased). */
export const ADEPT_KEY = "metamagicAdept";
/** Did this cast pay an option in AP through Metamagic Adept (the hooks' `metamagicPayments`)? */
export const adeptPaid = (ctx = {}) => (Array.isArray(ctx.metamagicPayments) ? ctx.metamagicPayments : []).some((k) => norm(k) === norm(ADEPT_KEY));

/** The Flourish Metamagic Adept spent, recorded in combat as the core records a trait (once a turn). */
async function adeptSettled(ctx) {
  if (!adeptPaid(ctx) || !ownedFeat(ctx.actor, "Metamagic Adept") || !combatFor(ctx.actor)) return;
  await h().recordTraitUsage(ctx.actor, { key: ADEPT_KEY, traits: "Flourish" });
}

export const METAMAGIC_ADEPT_PAYMENT = Object.freeze({
  label: "Metamagic Adept",
  options: [...ADEPT_OPTIONS],
  ap: 1,
  dcAsIfPP: true,
  max: 1,
  async applies(ctx = {}) {
    if (!ownedFeat(ctx.actor, "Metamagic Adept") || ctx.itemCast) return false;
    if (!adeptCastTimeOk(ctx.castAP)) return false;
    if (ctx.inCombat) {
      const blocked = await h().traitCheck?.(ctx.actor, { key: ADEPT_KEY, traits: "Flourish" });
      if (blocked?.blocked) return false;
    }
    return true;
  }
});

/* ------------------------------------------------------------------ */
/* Magical Retribution                                                  */
/* ------------------------------------------------------------------ */

async function retributionAttack(actor, attackerTokenId, attackerName) {
  if (!(await h().spendReaction?.(actor, "Magical Retribution", { traits: "Attack" }))) return { done: false };
  const weapon = await chooseWeapon(actor, "Magical Retribution", { meleeOnly: true });
  if (!weapon) return { done: false, line: `${esc(actor.name)} has no melee weapon in hand: no attack of opportunity.` };
  await withTargets([attackerTokenId], () => h().rollWeaponAttack(actor, weapon, { isReaction: true, skipTargetPrompt: true, reachAlreadyEstablished: true }));
  return { done: true, line: `${esc(actor.name)}'s <strong>Magical Retribution</strong>: an attack of opportunity at ${esc(attackerName || "the attacker")} with ${esc(weapon.name)}, before the casting's fate is rolled.` };
}

async function retributionStep(actor, answer, data) {
  return retributionAttack(actor, String(data?.attackerTokenId ?? ""), String(data?.attackerName ?? ""));
}

/** The pending-cast step (G26): a melee Strike's damage in the extra-casting-time window. */
export async function magicalRetributionStep(ctx = {}) {
  const actor = ctx.actor;
  const feat = ownedFeat(actor, "Magical Retribution");
  if (!feat || !retributionWants(ctx)) return null;
  if (await reactionBlocked(actor, String(feat.system?.traits ?? ""))) return null;
  const fromUuid = globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid;
  const source = fromUuid ? await fromUuid(ctx.sourceUuid) : null;
  const attacker = source?.actor ?? source ?? null;
  const attackerToken = attacker?.getActiveTokens?.()?.[0] ?? null;
  if (!attackerToken) return null;
  const q = await h().askReactor(actor, {
    title: `Magical Retribution — ${actor.name}`,
    content: `<p><strong>${esc(attacker?.name ?? ctx.sourceName ?? "A creature")}</strong> strikes you while you cast <strong>${esc(ctx.spellName || "a spell")}</strong>.</p><p>Use <strong>Magical Retribution</strong> (your reaction): an attack of opportunity at it, before the casting's Failure or Fumble is rolled?</p>`,
    buttons: [{ action: "yes", label: "Magical Retribution" }, { action: "no", label: "No" }],
    step: RETRIBUTION_STEP,
    data: { attackerTokenId: attackerToken.id, attackerName: attacker?.name ?? ctx.sourceName ?? "" }
  });
  return q?.result?.line ? { lines: [q.result.line] } : null;
}

const magicalRetribution = {
  hint: "Reaction: an attack of opportunity at your targeted attacker, when the table rules it struck you while you cast.",
  async use(actor, item) {
    const t = firstTarget();
    if (!t?.actor) return warn("Magical Retribution: target the creature that struck you first.");
    const refused = await reactionBlocked(actor, String(item?.system?.traits ?? ""));
    if (refused) return warn(`Magical Retribution: ${refused}.`);
    const out = await retributionAttack(actor, t.id, t.name);
    if (out.line) await card(actor, "Magical Retribution", [line(out.line)]);
    return out.done;
  }
};

/* ------------------------------------------------------------------ */
/* Spellblade's Mark                                                    */
/* ------------------------------------------------------------------ */

const markOf = (actor) => ownEffects(actor, MARK_SOURCE).find((e) => !e.disabled) ?? null;

const spellbladesMark = {
  hint: "1 AP (Concentrate, Focus): mark your targeted enemy within 60 ft.",
  async use(actor, item) {
    const t = firstTarget();
    if (!t?.actor || t.actor === actor) return warn("Spellblade’s Mark: target one enemy first.");
    const me = tokenOf(actor);
    if (me && t.document?.disposition === me.document?.disposition) return warn("Spellblade’s Mark: your Mark must be an enemy.");
    const d = me ? feetBetween(me, t) : null;
    if (d === null || d > MARK_FEET) return warn(`Spellblade’s Mark: your Mark must be within ${MARK_FEET} feet${d === null ? " (place your token on the map)" : ""}.`);
    const traits = String(item?.system?.traits ?? "Concentrate, Focus, Invocation, Spellblade");
    if (!hasAP(actor, 1)) return warn("Spellblade’s Mark: 1 AP required.");
    if (!(await h().traitGate(actor, { key: "spellbladesMark", traits }, "Spellblade’s Mark"))) return false;
    if (!(await spendAP(actor, "Spellblade’s Mark", 1))) return false;
    await h().recordTraitUsage(actor, { key: "spellbladesMark", traits });
    const old = ownEffects(actor, MARK_SOURCE).map((e) => e.id);
    if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old);
    const uuid = t.actor.uuid;
    await h().createEffectsOn(actor, [effectData(MARK_SOURCE, {
      name: `${MARK_LABEL}: ${t.name}`, img: "icons/svg/target.svg",
      description: `${t.name} is your Mark: +1 circumstance to melee Strikes and spell attacks against it, 1d6 secondary force damage on your attacks against it, +1 DB against its attacks.`,
      system: markFlags(uuid),
      module: { markUuid: uuid, markName: t.name, combatId: combatFor(actor)?.id ?? "" }
    })]);
    await card(actor, MARK_LABEL, [line(`<strong>${esc(t.name)}</strong> is your Mark until the end of the encounter or until you Mark another: +1 circumstance to your melee Strikes and spell attacks against it, +${MARK_DICE} secondary force damage on your attacks, +1 DB against its attacks.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return true;
  }
};

export async function spellbladesMarkGate(ctx = {}) {
  const mark = markOf(ctx.actor);
  if (!mark) return null;
  const row = markGateRow({ markUuid: String(mflag(mark, "markUuid") ?? ""), targetUuids: ctx.targetUuids ?? [], attack: Boolean(ctx.attack) });
  return row ? { modifiers: [row] } : null;
}

/* ------------------------------------------------------------------ */
/* Hook handlers                                                        */
/* ------------------------------------------------------------------ */

/** Hooks.on("trgPrimeSpellSettled"): the sigils, Bespell's memory, an armed surge spent, Metamagic Adept's Flourish. */
export async function onSpellSettledB6C(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner) return;
  await sigilSettled(ctx);
  await adeptSettled(ctx);
  await bespellRemember(ctx);
  await surgeSettled(ctx);
}

/** Hooks.on("trgPrimeDailyPreparation"): sigils cleared, Arcane Study's pick, the day's eased Fumble, a surge disarmed. */
export async function onDailyPreparationB6C({ actor } = {}) {
  if (!actor?.isOwner) return;
  const sigil = ownedFeat(actor, "Prepared Sigil");
  if (sigil) {
    await sigil.unsetFlag(MODULE_ID, SIGILS_FLAG);
    await sigil.unsetFlag(MODULE_ID, SIGILS_INSCRIBED_FLAG);
    await sigil.unsetFlag(MODULE_ID, SIGIL_LOCK_FLAG);
    await card(actor, "Prepared Sigil", [line("Yesterday's sigils have faded. Once you have prepared today's spells, use <strong>Prepared Sigil</strong> to inscribe today's.")]);
  }
  const hmr = ownedFeat(actor, "High Magic Resonance");
  if (hmr && mflag(hmr, HMR_EASED_FLAG)) await hmr.unsetFlag(MODULE_ID, HMR_EASED_FLAG);
  const armed = ownEffects(actor, SURGE_SOURCE).map((e) => e.id);
  if (armed.length) await actor.deleteEmbeddedDocuments("ActiveEffect", armed);
  const study = ownedFeat(actor, "Arcane Study");
  if (study) {
    await arcaneStudyRevert(actor, study);
    if (bookOf(study).length) await arcaneStudyPick(actor, study, "Daily preparation: today's spell from your book (a known one is warped 1 PP cheaper)");
  }
  await syncBondedInfusion(actor);
}

/** Hooks.on("updateActor", (actor, change)): Bonded Infusion follows the infusion; High Mage's Focus's second pick. */
export async function onActorUpdatedB6C(actor, change = {}) {
  if (!actor?.isOwner || !actsFor(actor)) return;
  const get = (p) => globalThis.foundry?.utils?.getProperty?.(change, p);
  if (get(`flags.${SYSTEM_ID}`) !== undefined) await syncBondedInfusion(actor);
  if (get("system.magic.bsb") !== undefined || get("system.progression") !== undefined || get("system.identity.level") !== undefined) {
    const hmf = ownedFeat(actor, "High Mage’s Focus");
    if (hmf && !mflag(hmf, HMF_NOTED_FLAG) && focusPicksAllowed(bsbOf(actor)) > picksOf(hmf).length && picksOf(hmf).length >= 1) {
      await hmf.setFlag(MODULE_ID, HMF_NOTED_FLAG, true);
      await card(actor, "High Mage’s Focus", [line(`Your BSB is +${bsbOf(actor)}: use <strong>High Mage’s Focus</strong> to choose a second High Magic spell.`)]);
    }
  }
}

/** Hooks.on("updateItem", (item, change)): a weapon equipped or put away (Bonded Infusion's hand). */
export async function onItemUpdatedB6C(item, change = {}) {
  const actor = item?.parent;
  if (item?.type !== "weapon" || !actor?.isOwner || !actsFor(actor)) return;
  if (globalThis.foundry?.utils?.getProperty?.(change, "system.equipped") === undefined) return;
  await syncBondedInfusion(actor);
}

/** Hooks.on("createItem"): Bonded Infusion arriving on an infused Spellblade. */
export async function onItemCreatedB6C(item) {
  const actor = item?.parent;
  if (item?.type !== "feat" || norm(item.name) !== "bonded infusion" || !actor?.isOwner || !actsFor(actor)) return;
  await syncBondedInfusion(actor);
}

/** Hooks.on("deleteCombat"): Spellblade's Mark ends with the encounter (one made outside combat, with the next). */
export async function onCombatDeletedB6C(combat) {
  for (const c of Array.from(combat?.combatants ?? [])) {
    const actor = c.actor;
    if (!actor?.isOwner || !actsFor(actor)) continue;
    const ids = ownEffects(actor, MARK_SOURCE).filter((e) => { const at = String(mflag(e, "combatId") ?? ""); return !at || at === String(combat.id); }).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
  }
}

/*
 * NOTHING AT READY (review, 0.9.0): loading a world writes nothing; Bonded
 * Infusion is synced on the actor and item events only, so this block has no
 * ready handler.
 */

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const AUTOMATIONS_B6_C = Object.freeze({
  "Prepared Sigil": preparedSigil,
  "Arcane Study": arcaneStudy,
  "Bespell Weapon": bespellWeapon,
  "Call Bonded Weapon": callBondedWeapon,
  "Considered Attack": consideredAttack,
  "High Mage’s Focus": highMagesFocus,
  "Magical Retribution": magicalRetribution,
  "Resonance Surge": resonanceSurge,
  "Spellblade’s Mark": spellbladesMark
});

export const STEPS_B6_C = Object.freeze({ retributionStep });

/** Every registration group C makes; called once from registerContent (trgPrime.registerContent). */
export function registerBlock6C(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_C)) api.registerFeatAutomation(name, entry, moduleId);
  api.registerCastPrelude?.("preparedSigil", preparedSigilPrelude, moduleId);
  api.registerMetamagic?.(LEY_ETCHED_KEY, LEY_ETCHED_METAMAGIC, moduleId);
  api.registerMetamagicPayment?.(ADEPT_KEY, METAMAGIC_ADEPT_PAYMENT, moduleId);
  api.registerMetamagic?.(SURGE_KEY, RESONANCE_SURGE_METAMAGIC, moduleId);
  api.registerResonanceModifier?.("highMagicResonance", HIGH_MAGIC_RESONANCE, moduleId);
  api.registerResonanceModifier?.("resonanceSurge", RESONANCE_SURGE, moduleId);
  api.registerCastDegreeRemap?.("highMagicResonance", highMagicResonanceRemap, moduleId);
  api.registerSpellCheckGate?.("bondedInfusion", bondedInfusionGate, moduleId);
  api.registerSpellCheckGate?.("highMagesFocus", highMagesFocusGate, moduleId);
  api.registerSpellCheckGate?.("spellbladesMark", spellbladesMarkGate, moduleId);
  api.registerPendingCastStep?.("magicalRetribution", magicalRetributionStep, moduleId);
  api.registerFeatEligibility?.("Arcane Study", arcaneStudyBlock, moduleId);
  api.registerFeatEligibility?.("High Magic Resonance", highMagicResonanceBlock, moduleId);
  api.registerFeatEligibility?.("Resonance Surge", resonanceSurgeBlock, moduleId);
  api.registerReactionStep?.(RETRIBUTION_STEP, retributionStep, moduleId);
}
