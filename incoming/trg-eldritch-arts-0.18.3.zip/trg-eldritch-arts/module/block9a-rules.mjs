/**
 * Eldritch Arts Block 9a (0.13.0, on TRG Prime 3.688.0): the rules, pure.
 * Chapter 6's catalysts (L5202–5508) and special materials (L4761–4903), and
 * Block 5's four catalyst feats (L4330–4355), as Graham answered the Block 9
 * audit on 13 November 2026 ("Go with your recommendation for all questions
 * and proceed": Q185–Q210). Nothing here touches Foundry.
 *
 * THE CATALYST RULES (L5212–5234), and the rulings that read them:
 *   - "invoked when declaring a spell, before the Spellcraft check is rolled":
 *     no action and no hand; on any cast that rolls its own Spellcraft check
 *     (Q186), through TRG Prime's H19;
 *   - "consumed immediately upon use, whether the spell succeeds or fails";
 *   - "Failure, Fumble, or Blunder … suffers the listed backlash" (Dragonbone
 *     Dust: Fumble or Blunder only, M10); a Partial is not one of the three;
 *   - "only one catalyst per spell";
 *   - "Any damage effects caused by catalysts require a basic saving throw of
 *     a type appropriate to the spell cast" (M18, as proposed): the dice a
 *     catalyst adds of its own ride the spell's own blow — its attack, or its
 *     save — as TRG Prime's added damage does;
 *   - "All bonuses and penalties gained from catalysts are item bonuses unless
 *     stated otherwise";
 *   - "per PP": the PP as cast (Q187).
 */

export const MODULE_ID = "trg-eldritch-arts";

const str = (v) => String(v ?? "").trim();
const lower = (v) => str(v).toLowerCase();
const int = (v) => Math.trunc(Number(v) || 0);

/** The flag a catalyst item carries (module scope): its key in CATALYSTS. */
export const CATALYST_FLAG = "catalyst";

/** The spell's first damage die: "2d6+4" → 6; none → 0. */
export function damageDie(formula) {
  const m = /(\d*)d(\d+)/i.exec(str(formula));
  return m ? Number(m[2]) : 0;
}

/** A spell that deals damage: a damage formula with a die or a number. */
export const isDamaging = (ctx) => Boolean(damageDie(ctx?.damage?.formula) || /\d/.test(str(ctx?.damage?.formula)));

/** Does a spell carry a trait (word, case-insensitive)? */
export function spellHasTrait(ctx, trait) {
  return str(ctx?.traits).split(/[,;\s]+/).some((t) => lower(t) === lower(trait));
}

/** Is it a spell of this tradition (High Magic is every tradition: Appendix, HIGHMAGIC)? */
export function spellOfTradition(ctx, tradition) {
  return lower(`${ctx?.traditions ?? ""} ${ctx?.tradition ?? ""}`).includes(lower(tradition));
}

/** The PP the spell is cast at (Q187), never below 0. */
/**
 * A warp (or Elemental Spell) has already changed the damage type: TRG Prime
 * hands the catalyst the type as warped, and the first change stands in its
 * fold (review), so a catalyst that changes the type would do nothing.
 */
export const typeWarped = (ctx) => Boolean(str(ctx?.damage?.type) && str(ctx?.spellData?.damage?.type) && lower(ctx.damage.type) !== lower(ctx.spellData.damage.type));
export const castPPOf = (ctx) => Math.max(0, int(ctx?.castPP ?? ctx?.totalPP));
/** "per 2 PP": whole pairs (m128, round down). */
export const perTwo = (ctx) => Math.floor(castPPOf(ctx) / 2);

/**
 * A backlash, as data:
 *   damage     [{ dice: "1d6", per: "pp"|"twoPP"|"once", type, also? }]
 *   conditions [{ key, value?, rounds?: number | "1d4×PP" | "1d4" | "1d6", minutes?: "1d4", seconds?, endOfNextTurn? }]
 *   soulDrain  { per: "pp" | "twoPP", dice?: "1d4" }
 *   effects    [{ label, conditional, seconds | rounds: "1d6" }]  a timed check penalty
 *   recurring  { dice, type }
 *   card       a line for the GM (Starpetal Oil's misfire)
 */
const S = (label, value, subjects) => ({ kind: "modifier", value, type: "item", label, scope: `${subjects} checks (catalyst backlash)`, auto: true, when: { checkTypes: ["skill"], subjects: [subjects.toLowerCase()] } });
const SPELLCRAFT = (label, value) => ({ kind: "modifier", value, type: "item", label, scope: "Spellcraft checks (catalyst backlash)", auto: true, when: { checkTypes: ["spellcraft"] } });
const SPELLCRAFT_DIS = (label) => ({ kind: "disadvantage", label, scope: "Spellcraft checks (catalyst backlash)", auto: true, when: { checkTypes: ["spellcraft"] } });

/**
 * The 24 catalysts. `applies(ctx)` answers whether it is offered on this
 * cast; `answer(ctx)` is H19's answer (TRG Prime 3.688.0, magic/cast-items.mjs);
 * `backlash` the printed backlash; `onFumbleOnly` Dragonbone Dust's (M10).
 */
export const CATALYSTS = Object.freeze({
  arcanitePowder: { name: "Arcanite Powder", applies: (c) => spellOfTradition(c, "arcane"),
    answer: () => ({ checkBias: "advantage", lines: ["Advantage on the Spellcraft check (an Arcane spell)."] }),
    backlash: { effects: [{ label: "Arcanite Powder backlash: −2 to Arcana checks", conditional: S("Arcanite Powder backlash", -2, "Arcana"), seconds: 3600 }] } },
  ashenLotusBloom: { name: "Ashen Lotus Bloom", applies: (c) => isDamaging(c) && (spellHasTrait(c, "essence") || spellHasTrait(c, "fire")),
    answer: (c) => ({ ignoreResistance: [lower(c?.damage?.type) || (spellHasTrait(c, "fire") ? "fire" : "essence")], lines: ["The spell's damage ignores resistance (an essence or fire spell)."] }),
    backlash: { soulDrain: { per: "pp" } } },
  // The ritual's catalyst (Graham, 13 November 2026: catalysts are offered for rituals): asked of the primary before the ritual check.
  bloodEtchedVellum: { name: "Blood-etched Vellum", ritualOnly: true, applies: (c) => Boolean(c?.ritual),
    answer: () => ({ checkModifiers: [{ label: "Blood-etched Vellum", value: 2, type: "item" }], lines: ["+2 item to the ritual check."] }),
    backlash: { bleeding: { per: "pp", max: 10 } } },
  celestialDewdrop: { name: "Celestial Dewdrop", applies: (c) => isDamaging(c) && castPPOf(c) > 0,
    answer: (c) => ({ addedDamage: [{ dice: `${castPPOf(c)}d6`, type: "essence", label: "Celestial Dewdrop" }], ignoreResistance: ["essence"], lines: [`+${castPPOf(c)}d6 secondary essence damage, which ignores resistance (it rides the spell's attack or save).`] }),
    backlash: { conditions: [{ key: "blinded", minutes: 1 }] } },
  chainedObsidianBead: { name: "Chained Obsidian Bead", applies: (c) => Boolean(c?.attack),
    answer: () => ({ attack: 2, lines: ["+2 item to the spell's attack."] }),
    backlash: { conditions: [{ key: "immobilised", endOfNextTurn: true }] } },
  cindersOfTheFirstFlame: { name: "Cinders of the First Flame", applies: (c) => damageDie(c?.damage?.formula) > 0,
    answer: () => ({ dieStep: 1, lines: ["The spell's damage dice step up one size (a d12 stays a d12, Q188)."] }),
    backlash: { recurring: { dice: "1d6", type: "fire" } } },
  dragonboneDust: { name: "Dragonbone Dust", applies: (c) => damageDie(c?.damage?.formula) > 0,
    answer: (c) => ({ mods: { damageDice: `1d${damageDie(c?.damage?.formula)}` }, lines: [`+1 damage die (d${damageDie(c?.damage?.formula)}), as ruled (M10).`] }),
    onFumbleOnly: true, backlash: { conditions: [{ key: "weakened", value: 1, rounds: "1d4×PP" }] } },
  eclipseResin: { name: "Eclipse Resin", applies: () => true,
    answer: () => ({ lines: ["Attempts to identify this spell are at disadvantage (the GM's: tick it on the identifying check)."] }),
    backlash: { damage: [{ dice: "1d6", per: "twoPP", type: "essence" }] } },
  frozenMarrowShard: { name: "Frozen Marrow Shard", applies: (c) => isDamaging(c) && !typeWarped(c),
    answer: () => ({ mods: { elementalType: "cold" }, lines: ["The spell's damage becomes cold; +1 DR until the end of your next turn."] }),
    castEffect: { label: "Frozen Marrow Shard: +1 DR", dr: 1 },
    backlash: { damage: [{ dice: "1d6", per: "twoPP", type: "cold" }], conditions: [{ key: "slowed", value: 1, rounds: 1 }] } },
  glimmercoal: { name: "Glimmercoal", applies: (c) => isDamaging(c) && perTwo(c) > 0,
    answer: (c) => ({ addedDamage: [{ dice: `${perTwo(c)}d6`, type: "fire", label: "Glimmercoal" }], lines: [`+${perTwo(c)}d6 fire damage (it rides the spell's attack or save).`] }),
    backlash: { damage: [{ dice: "1d6", per: "twoPP", type: "fire" }] } },
  graveSoil: { name: "Grave Soil", applies: (c) => damageDie(c?.damage?.formula) > 0 && spellHasTrait(c, "essence"),
    answer: (c) => ({ mods: { damageDice: `1d${damageDie(c?.damage?.formula)}` }, lines: [`+1 damage die (d${damageDie(c?.damage?.formula)}) (an essence spell).`] }),
    backlash: { conditions: [{ key: "frightened", value: 1, rounds: "1d6", together: "graveSoil" }], effects: [{ label: "Grave Soil backlash: −2 to Spellcraft checks", conditional: SPELLCRAFT("Grave Soil backlash (whispers)", -2), rounds: "1d6", together: "graveSoil" }] } },
  incenseOfStillness: { name: "Incense of Stillness", applies: () => true,
    answer: () => ({ checkBias: "advantage", lines: ["Advantage on the Spellcraft check."] }),
    backlash: { effects: [{ label: "Incense of Stillness backlash: disadvantage on Spellcraft checks", conditional: SPELLCRAFT_DIS("Incense of Stillness backlash"), seconds: 60 }] } },
  leydust: { name: "Leydust", applies: () => true,
    answer: () => ({ checkModifiers: [{ label: "Leydust", value: 2, type: "item" }], lines: ["+2 item to the Spellcraft check."] }),
    backlash: { damage: [{ dice: "1d6", per: "twoPP", type: "force" }] } },
  // "Illusion or enchantment": illusion is TRG Prime's Shadow trait (Graham, 13 November 2026).
  moonveilDust: { name: "Moonveil Dust", applies: (c) => Boolean(str(c?.defence)) && (spellHasTrait(c, "shadow") || spellHasTrait(c, "enchantment")),
    answer: () => ({ saveDC: [{ value: 2, type: "item", label: "Moonveil Dust" }], lines: ["+2 to the Spell Save DC (a Shadow or Enchantment spell)."] }),
    backlash: { conditions: [{ key: "dazzled", minutes: 1 }] } },
  phoenixFeatherAsh: { name: "Phoenix Feather Ash", applies: (c) => spellHasTrait(c, "healing") && castPPOf(c) > 0,
    answer: (c) => ({ mods: { healDice: `${castPPOf(c)}d6` }, lines: [`+${castPPOf(c)}d6 HP healed (a Healing spell).`] }),
    backlash: { damage: [{ dice: "1d6", per: "pp", type: "essence" }] } },
  // Not on a ritual variant: its PP are substituted (a sacrifice), so no discount reaches them (review, 0.13.1).
  resonantCrystalShard: { name: "Resonant Crystal Shard", applies: (c) => castPPOf(c) > 1 && !str(c?.variant),
    answer: () => ({ discount: { pp: 1, floor: 1, label: "Resonant Crystal Shard" }, lines: ["You pay 1 PP less (minimum 1); the Casting DC, cap and Save DC read the PP as cast (Q189)."] }),
    backlash: { damage: [{ dice: "1d6", per: "twoPP", type: "piercing" }, { dice: "1d6", per: "twoPP", type: "force" }] } },
  sanctifiedMyrrh: { name: "Sanctified Myrrh", applies: (c) => spellOfTradition(c, "divinity"),
    answer: () => ({ checkBias: "advantage", lines: ["Advantage on the Spellcraft check (a Divinity spell)."] }),
    backlash: { effects: [{ label: "Sanctified Myrrh backlash: −2 to Religion checks", conditional: S("Sanctified Myrrh backlash", -2, "Religion"), seconds: 3600 }] } },
  sandsOfTheHourglass: { name: "Sands of the Hourglass", applies: (c) => Boolean(c?.inCombat),
    answer: () => ({ lines: ["+1 AP this turn, once the cast has settled."] }),
    castAP: 1,
    backlash: { conditions: [{ key: "slowed", value: 1, rounds: "1d4" }] } },
  spellIncense: { name: "Spell Incense", applies: () => true,
    answer: () => ({ checkModifiers: [{ label: "Spell Incense", value: 1, type: "item" }], lines: ["+1 item to the Spellcraft check."] }),
    backlash: { effects: [{ label: "Spell Incense backlash: −1 to Spellcraft checks", conditional: SPELLCRAFT("Spell Incense backlash", -1), seconds: 60 }] } },
  starpetalOil: { name: "Starpetal Oil", applies: (c) => Boolean(c?.rangeScales || c?.durationScales), choice: true,
    answer: (c) => (c?.choice === "duration"
      ? { durationFactor: 1.5, lines: ["The spell's duration ×1.5."] }
      : { rangeFactor: 1.5, lines: ["The spell's range ×1.5."] }),
    backlash: { card: "Starpetal Oil misfires: the spell takes effect on you instead of its target, at half strength — damage and healing halved (round down), durations halved, any save yours at the cast's Save DC (Q190). Applied by the GM." } },
  stormglassPhial: { name: "Stormglass Phial", applies: (c) => isDamaging(c),
    answer: (c) => ({ addTraits: ["Electricity"], ...(perTwo(c) ? { addedDamage: [{ dice: `${perTwo(c)}d6`, type: "electricity", label: "Stormglass Phial" }] } : {}),
      lines: [`The spell gains the Electricity trait${perTwo(c) ? `, and +${perTwo(c)}d6 secondary electricity damage (it rides the spell's attack or save)` : ""}.`] }),
    backlash: { conditions: [{ key: "stunned", value: 3 }] } },
  verdantSap: { name: "Verdant Sap", applies: (c) => spellOfTradition(c, "verdant"),
    answer: () => ({ checkBias: "advantage", lines: ["Advantage on the Spellcraft check (a Verdant spell)."] }),
    backlash: { effects: [{ label: "Verdant Sap backlash: −2 to Nature checks", conditional: S("Verdant Sap backlash", -2, "Nature"), seconds: 3600 }] } },
  voidAsh: { name: "Void Ash", applies: (c) => isDamaging(c) && !typeWarped(c),
    answer: () => ({ mods: { elementalType: "essence" }, lines: ["The spell's damage becomes essence."] }),
    backlash: { soulDrain: { per: "twoPP", dice: "1d4" } } },
  whisperglassShard: { name: "Whisperglass Shard", applies: (c) => spellOfTradition(c, "ethereal"),
    answer: () => ({ checkBias: "advantage", lines: ["Advantage on the Spellcraft check (an Ethereal spell)."] }),
    backlash: { conditions: [{ key: "confused", minutes: "1d4" }] } }
});

/**
 * THE CATALYSTS THAT NAME A SPELLCRAFT CHECK (0.16.0; Graham, 15 November
 * 2026: on a mundane ritual, whose check is a tradition skill, they are
 * dropped). Blood-etched Vellum is one: the book's table prints "+2 to
 * Spellcraft checks for ritual casting" (L5487; found in review — an earlier
 * draft of this list kept it as "the ritual's own").
 */
export const SPELLCRAFT_CHECK_CATALYSTS = Object.freeze(["arcanitePowder", "bloodEtchedVellum", "incenseOfStillness", "leydust", "sanctifiedMyrrh", "spellIncense", "verdantSap", "whisperglassShard"]);

/** Whether a catalyst is offered on this check: not a Spellcraft one when the ritual's check is a skill. */
export function catalystFitsCheck(key, ctx = {}) {
  return !(SPELLCRAFT_CHECK_CATALYSTS.includes(key) && str(ctx?.checkSkill));
}

/** The key a catalyst's name answers to ("Blood-etched Vellum" → bloodEtchedVellum). */
export function catalystKey(name) {
  const want = lower(name).replace(/[’']/g, "");
  return Object.entries(CATALYSTS).find(([, c]) => lower(c.name).replace(/[’']/g, "") === want)?.[0] ?? null;
}

/** Does a degree bring this catalyst's backlash? Failure, Fumble or Blunder; Dragonbone Dust: Fumble or Blunder (M10). */
export function backlashDue(spec, degree, { mastery = false } = {}) {
  const d = lower(degree);
  const failed = ["failure", "fumble", "blunder"].includes(d);
  if (!failed) return false;
  if (spec?.onFumbleOnly && d === "failure") return false;
  // CATALYST MASTERY: "If you roll a failure on a Spellcraft check, you do
  // not suffer the effects of backlash. Fumble and blunder results are unaffected."
  if (mastery && d === "failure") return false;
  return true;
}

/**
 * CATALYST AFFINITY (L4330; R2: leave as printed): "reduce damage taken by 2
 * per character level, and reduce condition durations (such as stunned,
 * dazed, slowed) by 1 round (minimum 1)". As ruled (Q191): HP damage only
 * (not Soul Drain); a duration in rounds loses 1, minimum 1 (minutes and
 * hours are unchanged); Stunned 3 is Stunned 2, the feat naming stunned.
 */
export function affinityDamage(amount, level) {
  return Math.max(0, int(amount) - 2 * Math.max(0, int(level)));
}
export function affinityRounds(rounds) {
  return Math.max(1, int(rounds) - 1);
}
export function affinityCondition(cond) {
  if (cond?.key === "stunned" && int(cond.value) > 1 && !cond.rounds) return { ...cond, value: int(cond.value) - 1 };
  return cond;
}

/** How many dice a backlash damage row rolls: per PP, per 2 PP, or once. */
export function backlashDiceCount(row, ctx) {
  if (row?.per === "pp") return castPPOf(ctx);
  if (row?.per === "twoPP") return perTwo(ctx);
  return 1;
}

/** Blood-etched Vellum's bleeding (Q202): the PP as cast, at most 10. */
export function vellumBleeding(pp) {
  return Math.min(10, Math.max(0, int(pp)));
}

/**
 * CATALYST CONSERVATION (L4336): "attempt a DC 15 flat check. On success, the
 * catalyst is not consumed … On a fumble or blunder result of the
 * spellcasting check, the catalyst is always consumed."
 */
export function conservationKeeps(flatRoll, degree) {
  if (["fumble", "blunder"].includes(lower(degree))) return false;
  return int(flatRoll) >= 15;
}

/* ------------------------------------------------------------------ */
/* The special materials (Chapter 6, L4761–4903), for TRG Prime's H20  */
/* ------------------------------------------------------------------ */

/**
 * As TRG Prime's `registerMaterial` takes them. What a material does is the
 * core's own vocabulary where one fits (weight, HP, ACP, Max Dex, Speed,
 * silver, an extra die, a granted trait), `weaponDamageVs` for damage against
 * a kind of creature (Bane's shape), and `declaresByType` (the rune vocabulary,
 * for the item type the book names) for the conditionals and a critical's
 * secondary die. `card` is what the build
 * leaves to the table, said on the material's line in the module's notes.
 *
 * Rulings: Q193 (Ashbone's "all penalties" = ACP −1, Speed −5, Max Dex +1;
 * the "Stealth penalties" = −2 of the ACP on Stealth checks only); Q194
 * (implements, Sunbronze's shield CR, Nightsteel's magical armour,
 * Veilglass's planar and possession, Bloodglass's shatter save).
 */
// A save bonus scoped to a trait applies by itself when the effect names the
// trait; one the core cannot tell (Graveiron's disease, paralysis or soul
// drain) is a tick.
const SAVE = (label, value, scope, when, auto = true) => ({ kind: "modifier", value, type: "item", label, scope, auto, when: { checkTypes: ["save"], ...(when ?? {}) } });
const STEALTH = (label) => ({ kind: "modifier", value: 2, type: "untyped", label, scope: "Stealth checks: your armour's check penalty, less 2 (to no better than 0) — tick, and lower it to your penalty if that is under 2", auto: false, when: { checkTypes: ["skill"], subjects: ["stealth"] } });

// Veilglass (Q194): saves against Teleportation- or Translocation-trait effects, applied by
// themselves, and a tick for planar and possession effects (no trait names them).
const VEILGLASS = Object.freeze({ conditionals: [SAVE("Veilglass", 2, "Saving throws against Teleportation or Translocation effects", { traits: ["teleportation", "translocation"] }), SAVE("Veilglass", 2, "Saving throws against a planar or possession effect — tick if so", {}, false)] });

export const MATERIALS_9A = Object.freeze({
  ashbone: { label: "Ashbone", rarity: "Uncommon", levelDelta: 2, appliesTo: ["weapon", "armour", "shield"],
    weightPercent: -50, overcomesResistance: "silver", armourAcpReduction: 1, armourSpeedPenaltyReduction: 5, armourMaxDexBonus: 1,
    card: "Ashbone weapons: the half weight is not applied (the core's weapons take no material weight)." },
  bloodglass: { label: "Bloodglass", rarity: "Uncommon", levelDelta: 2, appliesTo: ["weapon", "armour", "shield"],
    weightPercent: -20, weaponGrantsTrait: "Serrated",
    declaresByType: { armour: { conditionals: [SAVE("Bloodglass", 1, "Saving throws against effects with the essence trait", { traits: ["essence"] })] } },
    shatter: { perTwoLevels: "1d6", type: "piercing", feet: 5, save: "reflex" },
    card: "Bloodglass shatters when destroyed (at a negative HP of half its maximum, rounded up): 1d6 piercing per 2 item levels to every creature within 5 ft., basic Reflex at the item's Level DC (Q194), rolled by the acting GM. Weapons: the 20% less weight is not applied." },
  bloodwood: { label: "Bloodwood", rarity: "Uncommon", levelDelta: 2, appliesTo: ["weapon", "armour", "shield"],
    weaponGrantsTrait: "Keen",
    declaresByType: { weapon: { conditionals: [{ kind: "modifier", value: 1, type: "item", label: "Bloodwood focus", scope: "Spellcraft checks with this staff, bow or wand as your focus, for a Soul-trait or Verdant spell — tick if so", auto: false, when: { checkTypes: ["spellcraft"] } }] } },
    card: "Staves and bows: the +1 Spellcraft as your focus for a Soul or Verdant spell is a tick. Armour and shields: +1 CR against essence or poison criticals is the GM's (the core's CR has no damage-type scope). Wands: the core's charged items carry no material." },
  eversmokeCloth: { label: "Eversmoke Cloth", rarity: "Rare", levelDelta: 3, appliesTo: ["armour"],
    weightPercent: -20,
    declares: { conditionals: [STEALTH("Eversmoke Cloth")] },
    card: "Eversmoke Cloth: Stealth penalties −2 (a tick). Cloaks and robes (their Hide advantage in dim light or darker, and the whispers on a Fumble or Blunder) are not built: the core's clothing carries no material." },
  graveiron: { label: "Graveiron", rarity: "Uncommon", levelDelta: 2, appliesTo: ["weapon", "armour", "shield"],
    overcomesResistance: "silver",
    weaponDamageVs: [{ dice: "1", against: ["undead"], label: "Graveiron" }],
    declaresByType: { armour: { conditionals: [SAVE("Graveiron", 1, "Fortitude saves against disease, paralysis or soul drain — tick if so", { subjects: ["fortitude"] }, false)] } },
    card: "Graveiron armour: the +1 to Fortitude saves against disease, paralysis or soul drain is a tick (no trait names them)." },
  nightsteel: { label: "Nightsteel", rarity: "Rare", levelDelta: 4, appliesTo: ["weapon", "armour", "shield"],
    hpPercent: 50, weaponExtraDie: true,
    declaresByType: { armour: { conditionals: [STEALTH("Nightsteel")] } },
    card: "Nightsteel: 50% more hardness, and weapons' AR 2 against magical armour (an armour with a potency rune, or a spell's DR such as Mage Armour, Q194), are the GM's. Armour and shield HP +50% and the weapon's extra die are applied; weapon HP is not (the core's weapons take no material HP). Armour: Stealth penalties −2 is a tick." },
  starion: { label: "Starion", rarity: "Rare", levelDelta: 4, appliesTo: ["weapon", "armour", "shield"],
    hpPercent: 50, weightPercent: -20,
    weaponDamageVs: [{ dice: "die", against: ["eternal"], label: "Starion" }],
    declaresByType: { armour: { conditionals: [SAVE("Starion", 1, "Saving throws against effects with the Insight trait", { traits: ["insight"] })] }, shield: { conditionals: [SAVE("Starion", 1, "Saving throws against effects with the Insight trait", { traits: ["insight"] })] } },
    card: "Starion: 50% more hardness, the GM's (the core models no hardness). Weapon HP +50% is not applied (the core's weapons take no material HP)." },
  sunbronze: { label: "Sunbronze", rarity: "Rare", levelDelta: 3, appliesTo: ["weapon", "armour", "shield"],
    weaponDamageVs: [{ dice: "die", against: ["undead"], label: "Sunbronze" }],
    // "fear and charm effects": charm is TRG Prime's Enchantment trait (Graham, 13 November 2026).
    declaresByType: { armour: { conditionals: [SAVE("Sunbronze", 1, "Will saves against Fear and Enchantment (charm) effects", { subjects: ["will"], traits: ["fear", "enchantment"] })] } },
    shieldLight: { dimFeet: 10 },
    card: "Sunbronze shields shed dim light (10 ft.) while held; their full CR against fire criticals (Q194) is the GM's." },
  tairneach: { label: "Tairneach", rarity: "Rare", levelDelta: 3, appliesTo: ["weapon", "armour", "shield"],
    declaresByType: {
      weapon: { strikeRider: { dice: "1d6", damageType: "electricity", onCritical: true, label: "Tairneach" } },
      armour: { conditionals: [SAVE("Tairneach", 1, "Saving throws against electricity and sonic effects", { traits: ["electricity", "sonic"] })] }
    },
    card: "" },
  veilglass: { label: "Veilglass", rarity: "Rare", levelDelta: 5, appliesTo: ["weapon", "armour", "shield"],
    hpMultiplier: 2,
    weaponDamageVs: [{ dice: "die", against: ["aberration", "incorporeal"], label: "Veilglass" }],
    declaresByType: { armour: VEILGLASS, shield: VEILGLASS },
    card: "Veilglass: double hardness, the GM's (the core models no hardness). Weapon HP ×2 is not applied (the core's weapons take no material HP)." }
});

/** What `registerMaterial` is given: the spec without the module's own keys. */
export function materialRegistration(key) {
  const m = MATERIALS_9A[key];
  if (!m) return null;
  const { card, shatter, shieldLight, ...spec } = m;
  // What is left to the table is shown under the item sheet's Material line (TRG Prime 3.688.0's `note`).
  return card ? { ...spec, note: card } : spec;
}

/**
 * "When destroyed" (Chapter 6, Item Damage, as TRG Prime's itemStatus reads
 * it): broken at 0 HP, destroyed at a negative value of half its HP, rounded
 * up. An item with no maximum HP is not tracked, so it is never destroyed.
 */
export function itemDestroyed(value, max) {
  const m = Math.max(0, Math.floor(Number(max) || 0));
  if (m <= 0) return false;
  return Math.floor(Number(value) || 0) <= -Math.ceil(m / 2);
}

/** Bloodglass's shatter (Q194): dice for an item of this level, "1d6 per 2 levels". */
export function shatterDice(itemLevel) {
  const n = Math.floor(Math.max(0, int(itemLevel)) / 2);
  return n > 0 ? `${n}d6` : "";
}
