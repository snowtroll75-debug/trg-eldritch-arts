/**
 * Eldritch Arts Block 2 — Chapter 4's three Power Manipulation actions on
 * raw essence: Tap Ley Line, Channel Ley Line and Tap Magical Energy, in the
 * shape TRG Prime's SKILL_ACTIONS holds.
 *
 * BOOK TEXT IS VERBATIM (tools/content/book-text.json `chapter4`), held
 * against the extract by verify-block2. `outcomesApplied: true`: each row is
 * applied by module/block2-automations.mjs.
 *
 * THE DC (TRG Prime 3.678.0's `resolveDC`, A1):
 *   - Tap and Channel: "a Hard (+2) / Very Hard (+5) DC check based upon the
 *     ley lines level" — the level DC of the nearest ley line within 30 feet
 *     (M5), the step being the action's difficulty. No line in range, no
 *     attempt.
 *   - Tap Magical Energy prints no DC: Graham's C3, "the Level DC of the
 *     target (if something is targeted)" — the charged item's level DC.
 */
import { resolveTapDC, resolveChannelDC, resolveSiphonDC } from "./block2-automations.mjs";

const ladder = (o) => ({ heroic: "", critical: "", success: "", partial: "", failure: "", fumble: "", blunder: "", ...o });

export const SKILL_ACTIONS = Object.freeze([
  {
    key: "tapLeyLine",
    name: "Tap Ley Line",
    skills: ["powerManipulation"],
    traits: "Concentrate",
    apCost: "1",
    checkType: "skill",
    against: "none",
    difficulty: "hard",
    outcomesApplied: true,
    resolveDC: (ctx) => resolveTapDC(ctx),
    outcomes: ladder({
      critical: "You channel the ley line’s power with perfect control, gaining its benefits until the end of your next turn.",
      success: "You successfully draw on the ley line’s energy, gaining its benefits until the end of your turn.",
      partial: "No effect.",
      failure: "The attempt backfires, sending a jolt of unstable magic through your mind. You take force damage equal to 1d6 × the ley line’s level (basic Will) and cannot Tap the Ley Line again for 1 hour.",
      fumble: "As Failure, but the ley line’s raw power lashes out violently. You are also subjected to its backlash effect and cannot Tap the Ley Line again for 24 hours."
    }),
    description: "You focus on a ley line within 30 feet that you can perceive, attempting to manipulate its flow of magical essence. This a Hard (+2) DC check based upon the ley lines level. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "channelLeyLine",
    name: "Channel Ley Line",
    skills: ["powerManipulation"],
    traits: "Concentrate",
    apCost: "10 minutes",
    checkType: "skill",
    against: "none",
    difficulty: "veryHard",
    outcomesApplied: true,
    resolveDC: (ctx) => resolveChannelDC(ctx),
    outcomes: ladder({
      heroic: "You recover PP as above and also gain the benefits of the ley line for 1 minute.",
      critical: "You recover PP as above and also gain the benefits of the ley line until the end of your next turn.",
      success: "You recover PP as above.",
      failure: "You recover no PP and instead take the amount as Essence damage (basic Fort).",
      fumble: "As Failure, but the damage is doubled.",
      blunder: "As Failure, but the damage is tripled and you may not attempt to manipulate this ley line again until the following day."
    }),
    description: "You focus on a ley line within 30 feet that you can perceive. You attempt to channel raw essence from the ley line into your personal reservoir. This a Very Hard (+5) DC check based upon the ley lines level. The amount of PP recovered depends on the ley line’s level: Minor 1d6 PP; Lesser 2d6 PP; Greater 3d6; Prime 4d6; Legendary 5d6. Add your casting tradition ability score to the amount of PP regained. If this would exceed your PP maximum, the excess is lost. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "tapMagicalEnergy",
    name: "Tap Magical Energy",
    skills: ["powerManipulation"],
    traits: "Concentrate",
    apCost: "1",
    requirements: "Power Manipulation 2 ranks.",
    minRanks: 2,
    requirement: "skills.powerManipulation.ranks",
    checkType: "skill",
    against: "none",
    outcomesApplied: true,
    resolveDC: (ctx) => resolveSiphonDC(ctx),
    outcomes: ladder({
      critical: "You siphon 1 PP per two caster levels from the item. The item only loses half this amount in PP (minimum 1).",
      success: "You siphon 1 PP per two caster levels from the item. The item loses the full amount of PP.",
      partial: "You siphon 1 PP per four caster levels from the charged item. The item loses the full amount of PP.",
      failure: "You fail to siphon energy and the item loses 1 PP.",
      fumble: "The essence lashes out; you take 1d6 force damage per item level (basic Fort) and the item loses 1d4 PP.",
      blunder: "As fumble and the item is depleted, immediately roll on the item depletion table (CRB 369)."
    }),
    description: "You draw unstable essence from a charged magical item (such as a wand, staff, rod, or orb) to fuel your own spellcasting. All magical energies gained using this action must be used before the end of your next turn, otherwise they dissipate harmlessly. Be aware that you cannot exceed your PP maximum using this action. (Eldritch Arts, Chapter 4)"
  }
]);

export const SKILL_ACTION_KEYS = Object.freeze(SKILL_ACTIONS.map((a) => a.key));
