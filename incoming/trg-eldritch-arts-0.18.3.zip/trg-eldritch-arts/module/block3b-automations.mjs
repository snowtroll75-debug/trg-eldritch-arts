/**
 * BLOCK 3b (0.6.0, on TRG Prime 3.681.0): the seven reactions Chapter 3 and
 * its spells print, built on the core's reaction seams from the Block 3b audit
 * (`docs/ELDRITCH_ARTS_BLOCK3B_AUDIT.md`), answered by Graham on 2 November
 * 2026: "Go with your proposals" (Q26–Q35).
 *
 *   Missed Chance      an enemy within 30 ft succeeds: force a reroll
 *   Second Chance      an ally within 60 ft fails: allow a reroll
 *   Prophetic Warning  before your own check: advantage
 *   Phase Familiar     your familiar within 60 ft would take damage
 *   Resist Magic       you take damage from a magical spell or effect
 *   Disrupting Magic   a creature within 120 ft casts a spell
 *   Eternity Resilience  you take a critical hit: Conviction for disadvantage
 *
 * Each is offered by the core at its moment, asked of the reactor's own player
 * (else the GM) with `askReactor`, and its work — a hex cast as a reaction, a
 * Dispel check, a Conviction point — is done on the reactor's client by a
 * reaction step. The hexes are cast in full: their casting check (Very Easy,
 * specialist), their PP and the reaction.
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID } from "./effects-clock.mjs";
import { norm, int, esc, h, owned, feetBetween } from "./block1-automations.mjs";

/* ------------------------------------------------------------------ */
/* Pure decisions                                                       */
/* ------------------------------------------------------------------ */

export const HEX_IMMUNITY_FLAG = "hexImmunity";
export const HEX_IMMUNITY_SECONDS = 3600;
export const REACH_FEET = Object.freeze({ "missed chance": 30, "second chance": 60, "phase familiar": 60, "disrupting magic": 120 });
export const PROPHETIC_SETTING = "propheticWarningPrompt";
export const SOCKET = `module.${MODULE_ID}`;

/**
 * Q30: immune to that hex, from any Witch, for an hour of world time. The
 * record is `{ hexName: untilWorldTime }`, on the creature made immune.
 */
export function immuneTo(record, hex, now) {
  return Number(record?.[norm(hex)] ?? -Infinity) > Number(now);
}
export function withImmunity(record, hex, now) {
  const kept = Object.fromEntries(Object.entries(record ?? {}).filter(([, until]) => Number(until) > Number(now)));
  return { ...kept, [norm(hex)]: Number(now) + HEX_IMMUNITY_SECONDS };
}

/**
 * Q28: enemy and ally are token disposition. Friendly (1) and hostile (−1)
 * are each other's enemies; a neutral or secret token is neither's. An ally
 * is another token of the same side.
 */
export function enemies(a, b) {
  const x = int(a), y = int(b);
  return (x === 1 && y === -1) || (x === -1 && y === 1);
}
export function allies(a, b) {
  const x = int(a), y = int(b);
  return (x === 1 || x === -1) && x === y;
}

/** What the reroll's question says the roller did. */
export function checkWords(ctx) {
  if (ctx?.type === "attack") return ctx.succeeded ? "hits" : "misses";
  const what = ctx?.type === "save" ? "saving throw" : "check";
  return `${ctx?.succeeded ? "succeeds at" : "fails"} ${ctx?.label ? `a ${what} (${ctx.label})` : `a ${what}`}`;
}

/**
 * Phase Familiar's answer: warped (+10 PP, read off the warp it paid for),
 * immunity to all damage; otherwise resistance to all damage and immunity to
 * precision. "The triggering damage" reaches the familiar in several packets
 * — a spell's rider and secondary type, a strike's runes and riders — so the
 * answer lasts that cast or that strike (the system's scope for both);
 * anything else is the one blow.
 */
export function phaseAnswer({ warpPP = 0, kind = "other" } = {}) {
  const scope = kind === "spell" || kind === "weapon" ? "cast" : "instance";
  return int(warpPP) >= 10
    ? { immune: "all", scope }
    : { resist: "all", immune: ["precision"], scope };
}

/**
 * Q32: Resist Magic answers a spell (cast from anything) and any damage the
 * core marks magical, but not a weapon's own damage. Its resistance covers the
 * spell's damage types, for every instance, until the cast settles.
 */
export function resistMagicApplies(ctx) {
  if (!ctx || ctx.kind === "weapon") return false;
  return ctx.kind === "spell" || Boolean(ctx.magical);
}

/**
 * What Resist Magic grants. A spell's: every damage type that cast deals —
 * the first packet's and any later one's (a "vs" rider, a secondary type, an
 * alternative) — until the cast settles; it is asked once a cast, so the
 * grant is to all of that cast's damage (found in review). Other magical
 * damage: its types, for that blow.
 */
export function resistMagicAnswer(ctx) {
  return ctx?.kind === "spell"
    ? { resist: "all", scope: "cast" }
    : { resist: Array.from(ctx?.types ?? []), scope: "instance" };
}

/** Q35, and found in review: a minor critical's roll is at disadvantage already, so a spend would buy nothing. */
export function eternityWorthOffering(bias) {
  return String(bias ?? "normal") !== "disadvantage";
}

/** Q35: every critical hit taken, weapon or spell; not one the creature dealt itself. */
export function eternityApplies(ctx) {
  return Boolean(ctx?.target) && ctx.target !== ctx.attacker;
}

/* ------------------------------------------------------------------ */
/* Foundry side                                                         */
/* ------------------------------------------------------------------ */

const worldNow = () => Number(globalThis.game?.time?.worldTime ?? 0);
const spellOf = (actor, name) => Array.from(actor?.items ?? []).find((i) => i.type === "spell" && norm(i.name) === norm(name)) ?? null;
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (token) => token?.document?.disposition;
const hexRecord = (actor) => actor?.flags?.[MODULE_ID]?.[HEX_IMMUNITY_FLAG] ?? {};

/**
 * The hour's immunity, on the creature made immune. The roller is often not
 * this client's to write (a GM's creature saving against a player's spell),
 * so a creature this client doesn't own is marked by the GM (found in review).
 */
async function markImmune(actor, hex) {
  if (!actor) return false;
  try {
    if (actor.isOwner) {
      await actor.setFlag(MODULE_ID, HEX_IMMUNITY_FLAG, withImmunity(hexRecord(actor), hex, worldNow()));
      return true;
    }
    const game = globalThis.game;
    if (!game?.users?.activeGM) {
      globalThis.ui?.notifications?.warn?.(`No GM is connected to record ${actor.name}'s hour of immunity to ${hex}: note it by hand.`);
      return false;
    }
    game.socket?.emit?.(SOCKET, { action: "hexImmunity", actorUuid: actor.uuid, hex: String(hex) });
    return true;
  } catch (error) {
    console.warn(`Eldritch Arts | could not record ${actor?.name}'s immunity to ${hex}`, error);
    return false;
  }
}

/** The GM's side: write the immunity a player's client asked for. */
export async function onHexImmunityRequest(data) {
  const game = globalThis.game;
  if (data?.action !== "hexImmunity" || !data.actorUuid || !data.hex) return false;
  if (!isActingGM()) return false;
  const actor = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(data.actorUuid);
  if (!actor) return false;
  await actor.setFlag(MODULE_ID, HEX_IMMUNITY_FLAG, withImmunity(hexRecord(actor), data.hex, worldNow()));
  return true;
}

/** Listen for those requests, at ready. */
export function registerBlock3bSocket() {
  globalThis.game?.socket?.on?.(SOCKET, (data) => {
    onHexImmunityRequest(data).catch((error) => console.warn("Eldritch Arts | hex immunity", error));
  });
}

/** Q28: can this creature take the reaction now? A reason, or "". */
async function readiness(actor, spell = null, { pp = true } = {}) {
  if (!actor) return "no creature";
  if (actor.hasCondition?.("blinded")) return "blinded";
  if (await h().isDead?.(actor)) return "dead";
  const refused = await h().reactionRefusal?.(actor, spell?.system?.traits ?? "");
  if (refused) return refused;
  if (pp && spell && int(actor.system?.resources?.pp?.value) < int(spell.system?.ppCost)) return "not enough PP";
  return "";
}

/**
 * Could this creature roll the Dispel at all? Dispel is a Trained action
 * (Power Manipulation, at least one rank), unless something it carries says
 * it may be taken untrained (the system's `untrainedActions`). Found live
 * (0.6.0): an untrained Arcanum was asked, said yes, and the system refused
 * the Dispel. Q33: Disrupting Magic is rolled as that Dispel.
 */
export function canDispel(actor) {
  if (int(actor?.system?.skills?.powerManipulation?.ranks) >= 1) return true;
  const sources = [...Array.from(actor?.items ?? []), ...Array.from(actor?.appliedEffects ?? []).filter((e) => !e?.disabled)];
  return sources.some((source) => {
    const declared = source?.flags?.["trg-prime"]?.untrainedActions;
    const keys = Array.isArray(declared) ? declared : String(declared ?? "").split(/[,;]/);
    return keys.map((k) => String(k ?? "").trim().toLowerCase()).includes("dispel");
  });
}

/** Within `feet` of another token, where both stand. */
const within = (a, b, feet) => {
  const d = feetBetween(a, b);
  return d !== null && d <= feet;
};

const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];

/**
 * The hexes' reroll (Missed Chance, Second Chance), asked of every Witch in
 * reach until one casts it. Resolves the core's answer, or null.
 */
async function rerollHex(ctx, { hex, wants, relation }) {
  if (!ctx?.token || !ctx?.actor) return null;
  if (!wants(ctx)) return null;
  if (immuneTo(hexRecord(ctx.actor), hex, worldNow())) return null;
  for (const witchToken of tokens()) {
    const witch = witchToken.actor;
    if (witchToken === ctx.token || witch === ctx.actor) continue;
    const spell = spellOf(witch, hex);
    if (!spell || !relation(side(witchToken), side(ctx.token))) continue;
    if (!within(witchToken, ctx.token, REACH_FEET[norm(hex)])) continue;
    if (await readiness(witch, spell)) continue;
    const q = await h().askReactor(witch, {
      title: `${hex} — ${witch.name}`,
      content: `<p><strong>${esc(ctx.actor.name)}</strong> ${esc(checkWords(ctx))} (${int(ctx.total)}).</p>`
        + `<p>Cast <strong>${esc(hex)}</strong> (${int(spell.system?.ppCost)} PP, your reaction) to make them reroll? The second result stands, and they are then immune to it for an hour.</p>`,
      buttons: yesNo(`Cast ${hex}`),
      step: CAST_STEP,
      data: { spellId: spell.id, targetTokenIds: [ctx.token.id] }
    });
    if (!q?.result?.cast) continue;
    await markImmune(ctx.actor, hex);
    return { reroll: true, label: hex, line: `${witch.name} casts <strong>${esc(hex)}</strong>: ${esc(ctx.actor.name)} rerolls, and the second result stands.` };
  }
  return null;
}

const missedChance = {
  after: (ctx) => rerollHex(ctx, {
    hex: "Missed Chance", relation: enemies,
    // Q29: "cannot be used to force a reroll if the d20 exploded".
    wants: (c) => c.succeeded && !c.exploded
  })
};

const secondChance = {
  after: (ctx) => rerollHex(ctx, { hex: "Second Chance", relation: allies, wants: (c) => c.failed })
};

/** Prophetic Warning's casts from the offer, so a sheet cast is told apart. */
const offered = new Set();

const propheticWarning = {
  async before(ctx) {
    const actor = ctx?.actor;
    const spell = spellOf(actor, "Prophetic Warning");
    if (!spell) return null;
    // Q31: only a check with a consequence; a prompt the setting turned off.
    if (ctx.dc === null || ctx.dc === undefined) return null;
    if (!promptOn()) return null;
    if (immuneTo(hexRecord(actor), "Prophetic Warning", worldNow())) return null;
    if (await readiness(actor, spell)) return null;
    const q = await h().askReactor(actor, {
      title: `Prophetic Warning — ${actor.name}`,
      content: `<p>Before <strong>${esc(ctx.label || "this check")}</strong>: cast <strong>Prophetic Warning</strong> (${int(spell.system?.ppCost)} PP, your reaction) for advantage? You are then immune to it for an hour.</p>`,
      buttons: yesNo("Cast Prophetic Warning"),
      step: CAST_STEP,
      // ITS RANGE IS SELF (found live, 0.6.0): cast at her own token, not at
      // whatever her user happens to have targeted.
      data: { spellId: spell.id, targetTokenIds: ctx.token?.id ? [ctx.token.id] : [], prophetic: true }
    });
    if (!q?.result?.cast) return null;
    await markImmune(actor, "Prophetic Warning");
    return { advantage: true, label: "Prophetic Warning", line: `${actor.name} casts <strong>Prophetic Warning</strong>: advantage on this check.` };
  }
};

function promptOn() {
  try { return globalThis.game?.settings?.get?.(MODULE_ID, PROPHETIC_SETTING) !== false; } catch { return true; }
}

/**
 * Prophetic Warning cast from the sheet (Q31, the prompt turned off, or cast
 * ahead): advantage on the next attack check, save or skill check, and the
 * hour's immunity.
 */
export async function onSpellSettledB3b(ctx) {
  const actor = ctx?.actor;
  if (!actor?.isOwner || norm(ctx?.spell?.name) !== "prophetic warning" || !ctx?.cast) return;
  if (offered.has(actor.id)) return;
  await h().addPendingModifier?.(actor, {
    kind: "advantage", value: 0, type: "untyped", label: "Prophetic Warning",
    scope: "your next attack check, saving throw or skill check", oneShot: true, auto: true,
    checkTypes: ["attack", "save", "skill"]
  });
  await markImmune(actor, "Prophetic Warning");
}

const phaseFamiliar = async (ctx) => {
  const familiar = ctx?.target;
  const masterId = familiar?.system?.familiar?.masterId ?? familiar?.flags?.[MODULE_ID]?.soulbound?.masterId;
  const master = masterId ? globalThis.game?.actors?.get?.(masterId) : null;
  const spell = spellOf(master, "Phase Familiar");
  if (!spell) return null;
  const famToken = familiar.getActiveTokens?.()?.[0];
  const witchToken = master.getActiveTokens?.()?.[0];
  if (!famToken || !witchToken || !within(witchToken, famToken, REACH_FEET["phase familiar"])) return null;
  if (await readiness(master, spell)) return null;
  const q = await h().askReactor(master, {
    title: `Phase Familiar — ${master.name}`,
    content: `<p><strong>${esc(familiar.name)}</strong> is about to take damage${ctx.sourceName ? ` from ${esc(ctx.sourceName)}` : ""}${ctx.spellName ? ` (${esc(ctx.spellName)})` : ""}.</p>`
      + `<p>Cast <strong>Phase Familiar</strong> (1 PP, your reaction): resistance to all damage and immunity to precision against it. Warp it for +10 PP in the cast for immunity instead.</p>`,
    buttons: yesNo("Cast Phase Familiar"),
    step: CAST_STEP,
    data: { spellId: spell.id, targetTokenIds: [famToken.id] }
  });
  if (!q?.result?.cast) return null;
  const answer = phaseAnswer({ warpPP: q.result.warpPP, kind: ctx.kind });
  return { ...answer, line: `${master.name} casts <strong>Phase Familiar</strong>: ${esc(familiar.name)} ${answer.immune === "all" ? "is immune to" : "resists"} this damage.` };
};

const resistMagic = async (ctx) => {
  const actor = ctx?.target;
  if (!owned(actor, "Resist Magic", ["ability"]) || !resistMagicApplies(ctx) || !ctx.types?.length) return null;
  if (await readiness(actor)) return null;
  const q = await h().askReactor(actor, {
    title: `Resist Magic — ${actor.name}`,
    content: `<p>${esc(ctx.spellName || "A magical effect")} is about to deal ${esc(ctx.types.join(" and "))} damage to <strong>${esc(actor.name)}</strong>.</p>`
      + `<p>Use <strong>Resist Magic</strong> (your reaction): resistance to its damage until the spell has been resolved?</p>`,
    buttons: yesNo("Resist Magic"),
    step: SPEND_STEP,
    data: { label: "Resist Magic", traits: "Warding" }
  });
  if (!q?.result?.spent) return null;
  const answer = resistMagicAnswer(ctx);
  return {
    ...answer,
    line: ctx.kind === "spell"
      ? `${actor.name} uses <strong>Resist Magic</strong>: resistance to ${esc(ctx.spellName || "the spell")}'s damage, every type and every instance, until it resolves.`
      : `${actor.name} uses <strong>Resist Magic</strong>: resistance to this ${esc(ctx.types.join(" and "))} damage.`
  };
};

const disruptingMagic = async (ctx) => {
  const caster = ctx?.actor;
  const casterToken = ctx?.token;
  if (!caster || !casterToken) return null;
  // Every one in reach may try in turn until one stops it (found in review).
  const said = [];
  for (const reactorToken of tokens()) {
    const reactor = reactorToken.actor;
    if (reactor === caster || reactorToken === casterToken) continue;
    const spell = spellOf(reactor, "Disrupting Magic");
    if (!spell) continue;
    // Not an ally's casting: a player has no reason to be asked to disrupt it.
    if (allies(side(reactorToken), side(casterToken))) continue;
    if (!within(reactorToken, casterToken, REACH_FEET["disrupting magic"])) continue;
    // Its PP is the Dispel's (Q23), so its own 1 PP is not asked for; but it
    // is a spell, so what forbids casting forbids it (found in review).
    if (await readiness(reactor, spell, { pp: false })) continue;
    if (!canDispel(reactor)) continue;
    // Dispel has the Concentrate trait, which a Fixated creature cannot use
    // (found in review).
    if (reactor.hasCondition?.("fixated")) continue;
    if (await h().castRefusal?.(reactor, spell)) continue;
    const dc = int(caster.system?.magic?.spellcraft?.dc);
    const q = await h().askReactor(reactor, {
      title: `Disrupting Magic — ${reactor.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${int(ctx.pp)} PP).</p>`
        + `<p>Use <strong>Disrupting Magic</strong> (your reaction)? Your Dispel (Power Manipulation) check is made against it, at the PP you declare, and spends PP as the Dispel does. On a Success or better the spell is stopped.</p>`,
      buttons: yesNo("Disrupt it"),
      step: DISRUPT_STEP,
      // The caster and spell ride to the Dispel (0.8.0) so a Dispel modifier
      // (TRG Prime 3.683.0, C9) can reach them: Threadbreaker's Precision Dazes the caster of a countered spell.
      data: { effectValue: int(ctx.pp), dc, spellName: ctx.spell?.name ?? "", casterUuid: caster.uuid ?? "", spellUuid: ctx.spell?.uuid ?? "" }
    });
    if (!q?.result?.rolled) continue;
    if (q.result.dispelled) {
      said.push(`${reactor.name}'s <strong>Disrupting Magic</strong> (${esc(q.result.degree)}): ${esc(ctx.spell?.name ?? "the spell")} is stopped before it resolves.`);
      return { stop: true, line: said.join("<br>") };
    }
    said.push(`${reactor.name}'s <strong>Disrupting Magic</strong> (${esc(q.result.degree)}) fails to stop ${esc(ctx.spell?.name ?? "the spell")}.`);
  }
  return said.length ? { stop: false, line: said.join("<br>") } : null;
};

const eternityResilience = async (ctx) => {
  const actor = ctx?.target;
  if (!eternityApplies(ctx) || !owned(actor, "Eternity Resilience", ["ability"])) return null;
  if (!eternityWorthOffering(ctx.bias)) return null;
  const state = await h().convictionState?.(actor);
  if (!state?.ok) return null;
  const q = await h().askReactor(actor, {
    title: `Eternity Resilience — ${actor.name}`,
    content: `<p><strong>${esc(ctx.attacker?.name ?? "A creature")}</strong> has dealt <strong>${esc(actor.name)}</strong> a ${esc(ctx.severity ?? "")} critical hit.</p>`
      + `<p>Spend a Conviction point (you have ${int(state.value)}) for disadvantage on the critical roll?</p>`,
    buttons: yesNo("Spend Conviction"),
    step: CONVICTION_STEP,
    data: {}
  });
  if (!q?.result?.spent) return null;
  return { disadvantage: true, line: `${actor.name}'s <strong>Eternity Resilience</strong>: a Conviction point spent, the critical roll has disadvantage.` };
};

/* ------------------------------------------------------------------ */
/* The steps, run on the reactor's client                                */
/* ------------------------------------------------------------------ */

export const CAST_STEP = "eldritchArts.castReaction";
export const SPEND_STEP = "eldritchArts.spendReaction";
export const DISRUPT_STEP = "eldritchArts.disruptMagic";
export const CONVICTION_STEP = "eldritchArts.spendConviction";

async function castStep(actor, answer, data) {
  const spell = actor?.items?.get?.(data?.spellId);
  if (!spell) return { cast: false };
  if (data?.prophetic) offered.add(actor.id);
  try {
    // A SELF SPELL'S TOKEN IS FOUND HERE (found in review): the client casting
    // it measures the range, and the asking client may not have her token
    // on its canvas at all.
    const own = data?.prophetic ? actor.getActiveTokens?.()?.[0]?.id ?? null : null;
    const ids = own ? [own] : Array.isArray(data?.targetTokenIds) ? data.targetTokenIds : [];
    const result = await h().castAsReaction(actor, spell, ids);
    return { cast: Boolean(result?.cast), warpPP: int(result?.warpPP) };
  } finally {
    offered.delete(actor.id);
  }
}

async function spendStep(actor, answer, data) {
  return { spent: Boolean(await h().spendReaction?.(actor, String(data?.label ?? "Reaction"), { traits: String(data?.traits ?? "") })) };
}

/**
 * Disrupting Magic: the core's Dispel, at no AP, opened on the incoming spell
 * (Q23, Q33). The reaction is spent once the Dispel is rolled, so a dialog
 * closed unrolled costs nothing (found in review).
 */
async function disruptStep(actor, answer, data) {
  if (await h().reactionRefusal?.(actor, "Utility, Warding")) return { rolled: false };
  const dispel = Array.from(h().skillActions ?? []).find((a) => a.key === "dispel");
  if (!dispel) return { rolled: false };
  const check = await h().resolveAction(actor, { ...dispel, apCost: "0" }, { presetDispel: { effectValue: int(data?.effectValue), dc: int(data?.dc), what: String(data?.spellName ?? ""), casterUuid: String(data?.casterUuid ?? ""), spellUuid: String(data?.spellUuid ?? ""), counterSpell: true } });
  const degree = String(check?.outcome?.degree?.key ?? "");
  if (!degree) return { rolled: false };
  if (!(await h().spendReaction?.(actor, "Disrupting Magic", { traits: "Utility, Warding" }))) return { rolled: false };
  return { rolled: true, degree: check.outcome.degree.label ?? degree, dispelled: ["heroic", "critical", "success"].includes(degree) };
}

async function convictionStep(actor) {
  return { spent: Boolean(await h().spendConviction?.(actor)) };
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export function registerBlock3b(api, moduleId) {
  api.registerCheckReaction?.("missedChance", missedChance, moduleId);
  api.registerCheckReaction?.("secondChance", secondChance, moduleId);
  api.registerCheckReaction?.("propheticWarning", propheticWarning, moduleId);
  api.registerDamageReaction?.("phaseFamiliar", phaseFamiliar, moduleId);
  api.registerDamageReaction?.("resistMagic", resistMagic, moduleId);
  api.registerCastReaction?.("disruptingMagic", disruptingMagic, moduleId);
  api.registerCriticalReaction?.("eternityResilience", eternityResilience, moduleId);
  api.registerReactionStep?.(CAST_STEP, castStep, moduleId);
  api.registerReactionStep?.(SPEND_STEP, spendStep, moduleId);
  api.registerReactionStep?.(DISRUPT_STEP, disruptStep, moduleId);
  api.registerReactionStep?.(CONVICTION_STEP, convictionStep, moduleId);
}

/** The setting Q31 names, registered at init. */
export function registerBlock3bSettings() {
  globalThis.game?.settings?.register?.(MODULE_ID, PROPHETIC_SETTING, {
    name: "Prophetic Warning: offer before each check",
    hint: "Offer a Witch's Prophetic Warning before her attack checks, saves and skill checks with a DC. Off: cast it from the sheet, and it gives advantage on her next such check. For the whole table: the check is often rolled on another player's or the GM's client.",
    scope: "world", config: true, type: Boolean, default: true
  });
}

/** For the harness. */
export const REACTIONS = Object.freeze({ missedChance, secondChance, propheticWarning, phaseFamiliar, resistMagic, disruptingMagic, eternityResilience });
export const STEPS = Object.freeze({ castStep, spendStep, disruptStep, convictionStep });
