/**
 * Eldritch Arts — Block 6 (0.9.0), group E: what the Warlock and Witch class
 * feats do that is not data. On TRG Prime 3.684.0.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md (Appendix E) as Graham
 * answered it on 4 November 2026 (Q89: one release; the rest as proposed).
 * The pure rules come first so the harness can run them; the Foundry side
 * follows.
 *
 *   Uses        Elemental Blast, Extra Bond, Forbidden Lore, Hex Binders
 *               Curse, High Sorcery, Pact Ascendant, Pact Boon, Ritual of
 *               Borrowed Power, Shadowed Grimoire, Soul-Bound Grimoire,
 *               Symbiotic Witch, Warding Sigil
 *   Seams       Extra Communion (G21 registerExtraUses), Hex Mastery (G4
 *               registerCastCostModifier), Xithra Cone (registerCastPrelude),
 *               Warlock's Hex (registerReactionStep, asked with askReactor)
 *   Hooks       the Xithra sync (item created/deleted, ready), Malevolent
 *               Blast and Ethereal Insight's sight (spell settled), Warlock's
 *               Hex and Hex Binders Curse (damage applied, G23), Extra Bond
 *               (effect created, token moved), Pact Ascendant's burst (death
 *               guard held, G7), the daily choices (daily preparation)
 *
 * The hook handlers are exported for the lead to wire in
 * scripts/eldritch-arts.mjs; each says which `Hooks.on` event it expects.
 */
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, tokenOf, feetBetween } from "./block1-automations.mjs";
import { spellIndex, actsFor, SOULBOUND_BONUSES, SOULBOUND_RANGE_FEET } from "./block3-automations.mjs";
import { soulOf, xithraTypes, warlockCopy, warlockMayTake, isCantrip } from "./block4-automations.mjs";
import { allies } from "./block3b-automations.mjs";

/* ------------------------------------------------------------------ */
/* Data                                                                 */
/* ------------------------------------------------------------------ */

export const ELEMENTAL_BLAST_TYPES = Object.freeze(["acid", "cold", "electricity", "fire", "sonic"]);
export const XITHRA_RANGE = "30 feet";
export const XITHRA_SPEAR_RANGE = "60 feet";
export const XITHRA_CONE_FEET = 30;
export const CURSE_FEET = 30;
export const ETHEREAL_FAMILIAR_FEET = 30;
export const CONDUIT_MAX_PP = 4;
export const DEMONIC_BURST = Object.freeze({ dice: "10d6", type: "fire", radiusFeet: 20, label: "Pact Ascendant (Demonic)" });
export const PACT_NAMES = Object.freeze(["Angelic Pact", "Demonic Pact", "Draconic Pact", "Elemental Pact", "Fey Pact", "Grave Pact", "Void Pact"]);
/** The Elemental Pact's map (L2970): air electricity, earth acid, fire fire, water cold. */
export const ELEMENT_DAMAGE = Object.freeze({ air: "electricity", earth: "acid", fire: "fire", water: "cold" });
/** Pact Boon (L3854), by pact. Dragon Wings is a Grimoire spell (Block 7, 0.10.0). */
export const BOON_SPELL = Object.freeze({ angelic: "Restoration", demonic: "Fireball", draconic: "Dragon Wings", elemental: "Conjure Elemental", fey: "Confusion", grave: "Create Undead", void: "Long Sense" });
/** Pact Ascendant (L3830), by pact; "Shape of the Dragon" is the core's Shape Of The Wyrm (minor 1, M2). */
export const ASCENDANT_SPELL = Object.freeze({ angelic: "Resurrection", demonic: "", draconic: "Shape Of The Wyrm", elemental: "Conjure Elemental", fey: "Dominate", grave: "Hand Of The Reaper", void: "Maze" });
export const HEX_STEP = "eldritchArts.warlocksHex";
export const DEMONIC_GUARD_LABEL = DEMONIC_BURST.label;
export const WITCH_TRADITIONS = Object.freeze(["ethereal", "verdant"]);

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const traitList = (text) => (Array.isArray(text) ? text : String(text ?? "").split(/[,;]/)).map((t) => norm(t)).filter(Boolean);
const featsNamed = (actor, name) => items(actor).filter((i) => i.type === "feat" && norm(i.name) === norm(name));
const featOf = (actor, name) => featsNamed(actor, name)[0] ?? null;
const className = (actor) => norm(items(actor).find((i) => i.type === "class")?.name);
const casterLevel = (actor) => int(actor?.system?.magic?.casterLevelValue) || levelOf(actor);

/** Xithra's damage types: mental, the soul's, today's Elemental Blast element. */
export function xithraOffer({ soul = null, element = "" } = {}) {
  return [...new Set([...xithraTypes(soul), ...(ELEMENTAL_BLAST_TYPES.includes(norm(element)) ? [norm(element)] : [])])];
}

/** "1d6 + 2" → "1d8 + 2" (every die of Xithra's formula). */
export const withDie = (formula, die) => String(formula ?? "").replace(/(\d+)d(?:6|8)\b/g, `$1d${die}`);

/**
 * What Xithra's item should hold, from the feats (Xithra Spear's range,
 * Enhanced Blast's d8) and the offer (Elemental Blast and the soul), as an
 * update of the changed paths only (`{}` when it is right already).
 */
export function xithraPatch(sys = {}, { spear = false, enhanced = false, types = ["mental"] } = {}) {
  const die = enhanced ? 8 : 6;
  const out = {};
  const range = spear ? XITHRA_SPEAR_RANGE : XITHRA_RANGE;
  if (String(sys.range ?? "") !== range) out["system.range"] = range;
  const formula = withDie(sys.damage?.formula ?? "1d6", die);
  if (formula !== String(sys.damage?.formula ?? "")) out["system.damage.formula"] = formula;
  const base = withDie(sys.baseDamage ?? "1d6", die);
  if (base !== String(sys.baseDamage ?? "")) out["system.baseDamage"] = base;
  const mods = (Array.isArray(sys.casterLevelMods) ? sys.casterLevelMods : []).map((m) => (m?.damageDice ? { ...m, damageDice: withDie(m.damageDice, die) } : m));
  if (JSON.stringify(mods) !== JSON.stringify(sys.casterLevelMods ?? [])) out["system.casterLevelMods"] = mods;
  const rest = (Array.isArray(sys.effects) ? sys.effects : []).filter((e) => norm(e?.kind) !== "damagetypechoice");
  const effects = types.length > 1 ? [...rest, { kind: "damageTypeChoice", damageTypes: [...types] }] : rest;
  if (JSON.stringify(effects) !== JSON.stringify(sys.effects ?? [])) out["system.effects"] = effects;
  return out;
}

/** Xithra's dice at an innate level: 1, +1 at 4th and every 4 (Q42). */
export const xithraDiceCount = (level) => 1 + Math.floor(Math.max(0, int(level)) / 4);

/** Hex Binders Curse: 1d6 from 5th, +1d6 at 10th and every 5. */
export const curseDice = (level) => (int(level) >= 5 ? `${Math.floor(int(level) / 5)}d6` : "");

/** Warlock's Hex: −1, −2 from 10th; Charisma rounds, at least 1 (Q134). */
export const hexPenalty = (level) => (int(level) >= 10 ? -2 : -1);
export const hexRounds = (charisma) => Math.max(1, int(charisma));
export function hexConditionals(warlockUuid, penalty) {
  return [{ kind: "modifier", value: penalty, type: "circumstance", label: "Warlock’s Hex", scope: "saving throws against the hexing Warlock's spells", auto: true, when: { checkTypes: ["save"], sourceUuids: [String(warlockUuid)] } }];
}

/** Warlock's Hex is asked after a spell's damage (a cast's packet or its area save), not a Strike, a curse or recurring damage. */
export const hexWanted = (payload = {}) => Number(payload.amount ?? 0) > 0 && Boolean(payload.sourceUuid) && ["spell", "areasave"].includes(norm(payload.context?.kind)) && payload.actor?.uuid !== payload.sourceUuid;
/** Hex Binders Curse answers a Strike or a spell of the curser's, never its own extra dice. */
export const curseWanted = (payload = {}) => Number(payload.amount ?? 0) > 0 && Boolean(payload.sourceUuid) && ["strike", "spell", "areasave"].includes(norm(payload.context?.kind));
/** One blow, however many packets: the source, the target, and the Strike's weapon or the spell. */
export const blowKey = (payload = {}) => `${payload.sourceUuid}|${payload.actor?.uuid ?? payload.actor?.id}|${norm(payload.context?.kind)}|${norm(payload.context?.spellName ?? payload.context?.label ?? payload.context?.weaponName ?? "")}`;
/** The triggering blow's damage type, where the payload says it. */
export const blowType = (payload = {}) => norm(payload.damageTypes?.[0] ?? payload.context?.damageType ?? "");

/** Malevolent Blast (Q136): a Failure or worse stuns, 2 on a critical hit; else nothing. */
export function malevolentStun(degree, critical = false) {
  return ["failure", "fumble", "blunder"].includes(norm(degree)) ? (critical ? 2 : 1) : 0;
}

/** The pact an actor holds: "angelic" … "void", or "". */
export function pactKeyOf(actor) {
  const f = items(actor).find((i) => i.type === "feat" && PACT_NAMES.map(norm).includes(norm(i.name)));
  return f ? norm(f.name).replace(/ pact$/, "") : "";
}
/**
 * The Elemental Pact's element, as its Use stores it on the pact feat
 * (Block 6 group A: `flags.trg-prime.eaElement`). READ, NOT OWNED; with none
 * stored, Pact Ascendant's own record (asked once, on its Use).
 */
export const PACT_ELEMENT_KEYS = Object.freeze([[SYSTEM_ID, "eaElement"]]);
export function pactElementOf(actor, own = null) {
  const pact = items(actor).find((i) => i.type === "feat" && norm(i.name) === "elemental pact");
  for (const [scope, key] of PACT_ELEMENT_KEYS) {
    const v = norm(pact?.flags?.[scope]?.[key]);
    if (ELEMENT_DAMAGE[v]) return v;
  }
  const mine = norm(own?.flags?.[MODULE_ID]?.element);
  return ELEMENT_DAMAGE[mine] ? mine : "";
}

/** Pact Ascendant's passive half, by pact: the effect's changes and declarations, the feat's auras. */
export function ascendantPassive(pact, element = "") {
  const imm = (v) => ({ key: "system.combat.immunities", mode: 2, value: `, ${v}`, priority: 20 });
  switch (pact) {
    case "angelic": return { changes: [], flags: {}, auras: [{ kind: "ally", radius: 10, name: "Pact Ascendant (Angelic)", allyEffect: { conditionals: [
      { kind: "advantage", label: "Pact Ascendant (Angelic)", scope: "Saving throws against effects with the fear trait", auto: true, when: { checkTypes: ["save"], traits: ["fear"] } },
      { kind: "advantage", label: "Pact Ascendant (Angelic)", scope: "Saving throws against an effect with the fear trait — tick if this save is one", auto: false, when: { checkTypes: ["save"], not: { traits: ["fear"] } } }
    ] } }], text: "allies within 10 feet: advantage on saves against fear" };
    case "demonic": return { changes: [imm("fire")], flags: { deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, frequency: "daily", heal: "half", notOutright: true } }, auras: [], text: "immune to fire; the once-a-day hellfire guard" };
    case "draconic": return { changes: [{ key: "system.combat.movement.fly.base", mode: 4, value: "40", priority: 20 }], flags: {}, auras: [], text: "a fly speed of 40 feet" };
    case "elemental": return ELEMENT_DAMAGE[element] ? { changes: [imm(ELEMENT_DAMAGE[element])], flags: {}, auras: [], text: `immune to ${ELEMENT_DAMAGE[element]}` } : null;
    case "fey": case "void": return { changes: [imm("mental")], flags: {}, auras: [], text: "immune to the mental trait" };
    case "grave": return { changes: [imm("essence")], flags: {}, auras: [], text: "immune to essence" };
    default: return null;
  }
}

/** The pick filters (index entries). Never a specialist spell, a hex or a cantrip. */
const plainSpell = (e) => !e?.system?.specialist && !e?.flags?.[SYSTEM_ID]?.eaHex && !isCantrip(e?.system) && int(e?.system?.ppCost) >= 1;
const tradsOf = (e) => traitList(e?.system?.tradition);
export const forbiddenLoreMay = (e, cl) => plainSpell(e) && tradsOf(e).some((t) => ["arcane", "divinity"].includes(t)) && int(e.system.ppCost) <= int(cl) + 1;
export function highSorceryMay(e, { cls, cl }) {
  if (!plainSpell(e) || int(e.system.ppCost) > int(cl) + 1) return false;
  if (cls === "witch") return tradsOf(e).some((t) => WITCH_TRADITIONS.includes(t));
  return cls === "sorcerer";
}
export const borrowedMay = (e, cl) => plainSpell(e) && int(e.system.ppCost) <= int(cl) + 1;
/** Soul-Bound Grimoire: an Ethereal or Verdant spell's scroll. */
export const grimoireScrollOk = (tradition) => traitList(tradition).some((t) => WITCH_TRADITIONS.includes(t));
/** Symbiotic Witch's conduit: base PP 4 or less (Q137). */
export const conduitAllows = (spell) => spell?.type === "spell" && int(spell.system?.ppCost) <= CONDUIT_MAX_PP;

/** A spell copy a Witch or Sorcerer gains outside her picks; the Highmagic trait when asked (Q99). */
export function repertoireCopy(data, { source, highMagic = false, flags = {} } = {}) {
  const out = JSON.parse(JSON.stringify(data ?? {}));
  delete out._id;
  out.type = "spell";
  const traits = String(out.system?.traits ?? "").trim();
  out.system = { ...(out.system ?? {}), prepared: true, traits: highMagic && !traitList(traits).includes("highmagic") ? (traits ? `${traits}, Highmagic` : "Highmagic") : traits };
  out.flags = {
    ...(out.flags ?? {}),
    [SYSTEM_ID]: { ...(out.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: source?.id ?? "", sourceName: source?.name ?? "", requested: data?.name ?? "" } },
    [MODULE_ID]: { ...(out.flags?.[MODULE_ID] ?? {}), ...flags }
  };
  return out;
}
/**
 * Is a Witch's spell outside Ethereal and Verdant (so it takes the trait, Q99)?
 * Since Graham's ruling of 4 November 2026 her class makes every spell she
 * casts High Magic (`highMagicCaster: true`); the trait is kept, so a sheet
 * whose Witch class predates 0.9.1 still casts these as High Magic.
 */
export const witchNeedsHighmagic = (cls, tradition) => cls === "witch" && !traitList(tradition).some((t) => WITCH_TRADITIONS.includes(t));

/** Extra Bond's offer: the bonuses not yet taken today. */
export const extraBondOptions = (taken = []) => SOULBOUND_BONUSES.filter((b) => !taken.includes(b.key));

/** Hex Mastery (G4, Q93): a hex cast with PP, −1 paid, min 1. */
export function hexMasteryModifier(ctx = {}) {
  if (!featOf(ctx.actor, "Hex Mastery")) return null;
  if (!ctx.spell?.flags?.[SYSTEM_ID]?.eaHex || ctx.innate || ctx.itemCast || ctx.cantrip) return null;
  return { ppDelta: -1, floor: 1, label: "Hex Mastery", lines: ["Hex Mastery: 1 PP less to pay (minimum 1); the DC reads the PP as cast."] };
}

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const fighting = (actor) => Boolean(combatFor(actor));
function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function spendAP(actor, label, ap = 1) {
  if (!fighting(actor) || ap <= 0) return true;
  const have = int(actor.system?.resources?.ap?.value);
  if (have < ap) return warn(`${label}: ${ap} AP required.`);
  await actor.update({ "system.resources.ap.value": have - ap });
  return true;
}
async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}
const fromUuid = async (uuid) => {
  const f = globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid;
  try { return uuid && f ? await f(uuid) : null; } catch { return null; }
};
const actorOf = (doc) => (doc?.documentName === "Actor" ? doc : doc?.actor ?? doc ?? null);
const xithraOf = (actor) => items(actor).filter((i) => i.type === "spell" && i.flags?.[SYSTEM_ID]?.eaXithra);
const elementOf = (actor) => norm(featOf(actor, "Elemental Blast")?.flags?.[MODULE_ID]?.element);
/** Xithra's offer on this actor. */
export const xithraOfferFor = (actor) => xithraOffer({ soul: soulOf(actor), element: elementOf(actor) });

/** The Witch's Soulbound familiar, and whether the bond holds. */
async function soulboundFamiliar(actor) {
  const list = (await h().familiarsOf?.(actor)) ?? [];
  const familiar = list.find((f) => f?.getFlag?.(MODULE_ID, "soulbound")?.masterId === actor?.id) ?? null;
  const ability = items(actor).find((i) => i.type === "ability" && norm(i.name) === "soulbound familiar");
  const severed = Boolean(ability?.getFlag?.(MODULE_ID, "soulboundSevered"));
  const dead = familiar ? Boolean(await h().isDead?.(familiar)) : false;
  return { familiar, severed, dead, holds: Boolean(familiar && !severed && !dead) };
}
/** Is the familiar out of range? Both tokens on one scene more than `feet` apart; no familiar is out. */
function familiarAway(actor, familiar, feet = SOULBOUND_RANGE_FEET) {
  if (!familiar) return true;
  const a = tokenOf(actor), b = tokenOf(familiar);
  if (!a || !b || a.scene !== b.scene) return false;
  const d = feetBetween(a, b);
  return d !== null && d > feet;
}

/** Pick one entry of the spells index; resolves the pack document's data, or null. */
async function pickSpell(title, prompt, pool) {
  if (!pool.length) { warn(`${title}: there is no spell you may take.`); return null; }
  const id = await h().chooseFromList(title, prompt, pool.sort((a, b) => a.name.localeCompare(b.name)).map((e) => [`${e._id}|${e.pack?.collection ?? ""}`, `${e.name} (PP ${int(e.system?.ppCost)})`]));
  if (!id) return null;
  const [eid, pk] = String(id).split("|");
  const entry = pool.find((e) => e._id === eid && (e.pack?.collection ?? "") === pk);
  const doc = entry ? await entry.pack.getDocument(entry._id) : null;
  return doc ? doc.toObject() : null;
}
async function packSpellData(name) {
  const entry = (await spellIndex()).find((e) => norm(e.name) === norm(name));
  if (!entry) return null;
  const doc = await entry.pack.getDocument(entry._id);
  return doc ? doc.toObject() : null;
}
const knownNames = (actor) => new Set(items(actor).filter((i) => i.type === "spell").map((i) => norm(i.name)));
const picksBy = (actor, item, key = "eaPick") => items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.[key]?.feat === item?.id);

/* ------------------------------------------------------------------ */
/* Xithra: Elemental Blast, Enhanced Blast, Xithra Spear                 */
/* ------------------------------------------------------------------ */

/**
 * THE ONE WRITER OF XITHRA'S RANGE, DICE AND OFFER (note 1). Block 4's
 * syncXithra writes the soul's offer on a soul's or Xithra's arrival; this
 * runs after it (wire onItemCreatedB6E after onItemCreatedB4) and writes the
 * whole state, so the last write is right.
 */
export async function syncXithraB6E(actor) {
  if (!actor) return;
  const state = { spear: Boolean(featOf(actor, "Xithra Spear")), enhanced: Boolean(featOf(actor, "Enhanced Blast")), types: xithraOfferFor(actor) };
  for (const x of xithraOf(actor)) {
    const patch = xithraPatch(x.system ?? {}, state);
    if (Object.keys(patch).length) await x.update(patch);
  }
}
const XITHRA_FEATS = ["elemental blast", "enhanced blast", "xithra spear"];

async function chooseElement(actor, item, prompt) {
  const pick = await h().chooseFromList("Elemental Blast", prompt, ELEMENTAL_BLAST_TYPES.map((t) => [t, t]));
  if (!ELEMENTAL_BLAST_TYPES.includes(pick)) return false;
  await item.setFlag(MODULE_ID, "element", pick);
  await syncXithraB6E(actor);
  await card(actor, "Elemental Blast", [line(`Today's element: <strong>${esc(pick)}</strong>. Xithra offers ${esc(xithraOfferFor(actor).join(", "))}.`)]);
  return true;
}
const elementalBlast = {
  hint: "Choose today's element for Xithra.",
  async use(actor, item) { return chooseElement(actor, item, "Xithra's element today (instead of mental):"); }
};

/* ------------------------------------------------------------------ */
/* Warding Sigil, Xithra Cone                                           */
/* ------------------------------------------------------------------ */

const wardingSigil = {
  hint: "1 AP (Focus): resistance to Xithra's damage types until the end of your next turn.",
  ownsFocusUse: true,
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Warding Sigil: its Focus use is spent — Refocus restores it.");
    if (!(await spendAP(actor, "Warding Sigil", 1))) return false;
    await spendUse(item);
    const types = xithraOfferFor(actor);
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("wardingSigil", {
      name: `Warding Sigil (${types.join(", ")})`, img: "icons/svg/shield.svg",
      description: `Resistance to ${types.join(", ")} until the end of your next turn.`,
      changes: [{ key: "system.combat.resistances", mode: 2, value: `, ${types.join(", ")}`, priority: 20 }],
      expiry: fighting(actor) ? expiryFor("endOfNextTurn", actor) : forSeconds(12)
    })]);
    await card(actor, "Warding Sigil", [line(`A glowing rune: <strong>resistance to ${esc(types.join(", "))}</strong> until the end of your next turn.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return true;
  }
};

/**
 * XITHRA CONE (Q136): Xithra's prelude. Bolt: the core's cast. Cone: Xithra's
 * AP and Focus use, then one roll of its damage and a basic Reflex save for
 * each targeted creature against the innate save DC (G25).
 */
export async function xithraConePrelude({ actor, spell }) {
  if (!spell?.flags?.[SYSTEM_ID]?.eaXithra || !featOf(actor, "Xithra Cone")) return null;
  const how = await h().chooseFromList("Xithra", "Release your Xithra as:", [["bolt", "a bolt (the attack)"], ["cone", `a ${XITHRA_CONE_FEET}-foot cone (basic Reflex)`]]);
  if (how === "bolt") return null;
  if (how !== "cone") return { handled: true, result: null };
  const refused = await h().castRefusal?.(actor, spell);
  if (refused) { warn(refused); return { handled: true, result: null }; }
  if (usesLeft(spell) <= 0) { warn("Xithra: its Focus use is spent — Refocus restores it."); return { handled: true, result: null }; }
  const targets = Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor).filter((a) => a && a !== actor);
  if (!targets.length) { warn(`Xithra Cone: target the creatures in your ${XITHRA_CONE_FEET}-foot cone first.`); return { handled: true, result: null }; }
  const types = xithraOfferFor(actor);
  const type = types.length > 1 ? await h().chooseFromList("Xithra Cone", "Damage type:", types.map((t) => [t, t])) : types[0];
  if (!types.includes(type)) return { handled: true, result: null };
  if (!(await spendAP(actor, "Xithra Cone", int(spell.system?.castAP) || 1))) return { handled: true, result: null };
  await spendUse(spell);
  const dc = await h().innateSaveDCFor(actor, spell);
  const die = featOf(actor, "Enhanced Blast") ? 8 : 6;
  const formula = `${xithraDiceCount(dc.level)}d${die} + ${int(actor.system?.attributes?.charisma?.total)}`;
  const roll = await new Roll(formula).evaluate();
  const lines = [line(`A ${XITHRA_CONE_FEET}-foot cone: <strong>${roll.total}</strong> ${esc(type)} (${esc(formula)}), basic Reflex against DC ${dc.value} (your innate save DC).`)];
  for (const target of targets) {
    const out = await h().basicSaveHit({ caster: actor, target, save: "reflex", dc: dc.value, label: "Xithra Cone", amount: roll.total, type });
    if (out?.line) lines.push(line(out.line));
  }
  lines.push(line("<em>Xithra's Focus use is spent. No attack is rolled, so on-hit powers do not apply.</em>"));
  await card(actor, "Xithra Cone", lines);
  return { handled: true, result: { cone: true, total: roll.total, type } };
}

/* ------------------------------------------------------------------ */
/* Warlock's Hex and Hex Binders Curse (G23)                            */
/* ------------------------------------------------------------------ */

const recentBlows = new Map();
/** Once a blow (two seconds a source, target and weapon or spell), as Veil of Honour asks. */
function firstOfBlow(tag, payload) {
  const key = `${tag}|${blowKey(payload)}`;
  const now = Date.now();
  if (now - (recentBlows.get(key) ?? 0) < 2000) return false;
  recentBlows.set(key, now);
  return true;
}

async function warlocksHexOffer(payload, source) {
  if (!hexWanted(payload)) return;
  const feat = featOf(source, "Warlock’s Hex");
  if (!feat || usesLeft(feat) <= 0 || int(source.system?.resources?.pp?.value) < 1) return;
  if (!firstOfBlow("hex", payload)) return;
  const target = payload.actor;
  await h().askReactor(source, {
    title: `Warlock’s Hex — ${source.name}`,
    content: `<p>Your spell damages <strong>${esc(target.name)}</strong>.</p><p>Spend <strong>1 PP</strong> and Warlock’s Hex's Focus use to hex them: ${hexPenalty(levelOf(source))} circumstance to saves against your spells for ${hexRounds(source.system?.attributes?.charisma?.total)} round(s)?</p>`,
    buttons: [{ action: "yes", label: "Hex them" }, { action: "no", label: "No" }],
    step: HEX_STEP,
    data: { itemId: feat.id, targetUuid: target.uuid ?? "" }
  });
}

/** The hex, on the Warlock's client: the use, the PP, then the effect on the target. */
async function hexStep(actor, answer, data) {
  const item = actor?.items?.get?.(data?.itemId);
  if (!item || usesLeft(item) <= 0) return { hexed: false };
  const pp = int(actor.system?.resources?.pp?.value);
  if (pp < 1) { warn("Warlock’s Hex: 1 PP required."); return { hexed: false }; }
  const target = actorOf(await fromUuid(data?.targetUuid));
  if (!target) return { hexed: false };
  await actor.update({ "system.resources.pp.value": pp - 1 });
  await spendUse(item);
  const penalty = hexPenalty(levelOf(actor));
  const rounds = hexRounds(actor.system?.attributes?.charisma?.total);
  const combat = combatFor(target) ?? (globalThis.game?.combat?.started ? game.combat : null);
  const expiry = forSeconds(6 * rounds);
  if (combat) expiry.system.conditionExpiresRound = int(combat.round) + rounds;
  await h().createEffectsOn(target, [effectData("warlocksHex", {
    name: `Warlock’s Hex (${actor.name}, ${penalty})`, img: "icons/svg/curse.svg",
    description: `${penalty} circumstance to saving throws against ${actor.name}'s spells, for ${rounds} round(s).`,
    system: { conditionals: hexConditionals(actor.uuid, penalty) }, module: { hexer: actor.uuid }, expiry
  })]);
  await card(actor, "Warlock’s Hex", [line(`<strong>${esc(target.name)}</strong> is hexed: ${penalty} circumstance to saves against your spells for ${rounds} round(s).`), line("<em>1 PP and the Focus use spent.</em>")]);
  return { hexed: true };
}

async function hexBindersExtra(payload, source) {
  const curse = source.getFlag?.(MODULE_ID, "hexCurse");
  if (!curse?.targetUuid || curse.targetUuid !== payload.actor?.uuid || !curseWanted(payload)) return;
  if (!featOf(source, "Hex Binders Curse")) return;
  const dice = curseDice(levelOf(source));
  if (!dice || !firstOfBlow("curse", payload)) return;
  let type = blowType(payload);
  if (!type && payload.context?.spellName) type = norm(items(source).find((i) => i.type === "spell" && norm(i.name) === norm(payload.context.spellName))?.system?.damage?.type);
  const roll = await new Roll(dice).evaluate();
  if (!type) {
    await card(source, "Hex Binders Curse", [line(`${esc(payload.actor.name)} is cursed: <strong>${roll.total}</strong> more damage (${dice}) of the blow's type — the blow named none, so the GM applies it.`)]);
    return;
  }
  const kind = norm(payload.context?.kind);
  const dealt = await h().applyTypedDamage(payload.actor, { amount: roll.total, type, sourceName: "Hex Binders Curse", sourceUuid: source.uuid, magical: kind !== "strike", context: { kind: "hexBindersCurse" } });
  await card(source, "Hex Binders Curse", [line(`${esc(payload.actor.name)} is cursed: <strong>${roll.total}</strong> ${esc(type)} more (${dice})${dealt?.packet ? ` — ${int(dealt.applied ?? dealt.packet.taken)} taken` : ""}.`)]);
}

/**
 * THE CURSE IS KEPT ON THE CURSER (review, 0.9.0): a flag naming the target,
 * and a marker effect on the curser's own sheet. Nothing is written on the
 * target, so a player whose curse ends never needs to delete an effect on an
 * NPC they do not own.
 */
async function clearCurse(actor) {
  if (actor.getFlag?.(MODULE_ID, "hexCurse")) await actor.unsetFlag(MODULE_ID, "hexCurse");
  const ids = ownEffects(actor, "hexBindersCurse").map((e) => e.id);
  if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
}

const hexBindersCurse = {
  hint: "1 AP (Concentrate): curse one targeted enemy within 30 feet.",
  async use(actor, item) {
    const me = tokenOf(actor);
    const targets = Array.from(globalThis.game?.user?.targets ?? []);
    if (targets.length !== 1 || !targets[0]?.actor || targets[0].actor === actor) return warn("Hex Binders Curse: target the one enemy you curse.");
    const t = targets[0];
    if (me && allies(t.document?.disposition, me.document?.disposition)) return warn("Hex Binders Curse: you may curse an enemy, not an ally.");
    const d = me ? feetBetween(me, t) : null;
    if (d !== null && d > CURSE_FEET) return warn(`Hex Binders Curse: ${t.name} is ${d} feet away (30 at most).`);
    const action = { key: "hexBindersCurse", traits: String(item.system?.traits ?? "Concentrate") };
    if (h().traitGate && !(await h().traitGate(actor, action, "Hex Binders Curse"))) return false;
    if (!(await spendAP(actor, "Hex Binders Curse", 1))) return false;
    await clearCurse(actor);
    const curseId = `${Date.now()}`;
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("hexBindersCurse", {
      name: `Hex Binders Curse: ${t.actor.name}`, img: "icons/svg/curse.svg",
      description: `You have cursed ${t.actor.name}: your Strikes and spells that damage it deal ${curseDice(levelOf(actor))} more.`,
      module: { targetUuid: t.actor.uuid, curseId }
    })]);
    await actor.setFlag(MODULE_ID, "hexCurse", { targetUuid: t.actor.uuid, curseId, name: t.actor.name });
    await h().recordTraitUsage?.(actor, action);
    await card(actor, "Hex Binders Curse", [line(`<strong>${esc(t.actor.name)}</strong> is cursed: each Strike or spell of yours that damages it deals <strong>${curseDice(levelOf(actor))}</strong> more, until you curse another, it dies, or your next daily preparation.`), ...(fighting(actor) ? [line("1 AP spent.")] : [])]);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* The spell picks                                                      */
/* ------------------------------------------------------------------ */

async function addCopy(actor, data, item, { highMagic, kind, extra = {} }) {
  const [made] = await actor.createEmbeddedDocuments("Item", [repertoireCopy(data, { source: item, highMagic, flags: { eaPick: { feat: item.id, kind, level: levelOf(actor) }, ...extra } })]);
  return made ?? null;
}

const forbiddenLore = {
  hint: "Choose your Arcane or Divinity spell (once).",
  async use(actor, item) {
    const have = picksBy(actor, item);
    if (have.length) return card(actor, "Forbidden Lore", [line(`Your forbidden spell is <strong>${esc(have[0].name)}</strong>. Delete it to choose again.`)]);
    const cl = casterLevel(actor);
    const mine = knownNames(actor);
    const data = await pickSpell("Forbidden Lore", `An Arcane or Divinity spell, PP ${cl + 1} or less:`, (await spellIndex()).filter((e) => !mine.has(norm(e.name)) && forbiddenLoreMay(e, cl)));
    if (!data) return false;
    const made = await addCopy(actor, data, item, { highMagic: true, kind: "forbiddenLore" });
    if (made) await card(actor, "Forbidden Lore", [line(`<strong>${esc(made.name)}</strong> joins your repertoire, outside your picks, cast as High Magic.`)]);
    return Boolean(made);
  }
};

const highSorcery = {
  hint: "Choose this copy's high magic spell.",
  async use(actor, item) {
    const have = picksBy(actor, item);
    if (have.length) return card(actor, "High Sorcery", [line(`This copy's spell is <strong>${esc(have[0].name)}</strong>.`)]);
    const cls = className(actor);
    const cl = casterLevel(actor);
    const mine = knownNames(actor);
    const data = await pickSpell("High Sorcery", `A spell your class could pick, PP ${cl + 1} or less:`, (await spellIndex()).filter((e) => !mine.has(norm(e.name)) && highSorceryMay(e, { cls, cl })));
    if (!data) return false;
    const made = await addCopy(actor, data, item, { highMagic: witchNeedsHighmagic(cls, data.system?.tradition), kind: "highSorcery" });
    if (made) await card(actor, "High Sorcery", [line(`<strong>${esc(made.name)}</strong> joins your repertoire, outside your picks, as High Magic.`)]);
    return Boolean(made);
  }
};

async function chooseBorrowed(actor, item) {
  const old = items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.eaBorrowed);
  if (old.length) await actor.deleteEmbeddedDocuments("Item", old.map((i) => i.id));
  const cl = casterLevel(actor);
  const mine = knownNames(actor);
  const data = await pickSpell("Ritual of Borrowed Power", `Today's borrowed spell, of any tradition, PP ${cl + 1} or less:`, (await spellIndex()).filter((e) => !mine.has(norm(e.name)) && borrowedMay(e, cl)));
  if (!data) return false;
  const made = await addCopy(actor, data, item, { highMagic: true, kind: "borrowed", extra: { eaBorrowed: true } });
  if (made) await card(actor, "Ritual of Borrowed Power", [line(`<strong>${esc(made.name)}</strong> is in your repertoire as a High Magic spell until your next daily preparation.`)]);
  return Boolean(made);
}
const borrowedPower = {
  hint: "Choose today's borrowed spell.",
  async use(actor, item) { return chooseBorrowed(actor, item); }
};

const shadowedGrimoire = {
  hint: "Choose this copy's spell, or replace it after a level gained.",
  async use(actor, item) {
    const soul = soulOf(actor);
    if (!soul) return warn("Shadowed Grimoire: choose your bonded soul first (its traditions are your spells').");
    const level = levelOf(actor);
    const have = items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.eaPick?.feat === item.id);
    if (have.length) {
      const was = int(have[0].flags[MODULE_ID].eaPick.level);
      if (level <= was) return card(actor, "Shadowed Grimoire", [line(`This copy's spell is <strong>${esc(have[0].name)}</strong>. It may be replaced once you gain a level.`)]);
      if (!(await confirm("Shadowed Grimoire", `You have gained a level since you chose ${esc(have[0].name)}. Replace it?`))) return false;
    }
    const mine = knownNames(actor);
    const data = await pickSpell("Shadowed Grimoire", "A spell of your soul's traditions:", (await spellIndex()).filter((e) => !mine.has(norm(e.name)) && warlockMayTake(e, { slot: "spell", soul, level })));
    if (!data) return false;
    if (have.length) await actor.deleteEmbeddedDocuments("Item", have.map((i) => i.id));
    const copy = warlockCopy(data, { source: item, slot: "grimoire" });
    copy.flags[MODULE_ID].eaPick = { feat: item.id, kind: "shadowedGrimoire", level };
    const [made] = await actor.createEmbeddedDocuments("Item", [copy]);
    if (made) await card(actor, "Shadowed Grimoire", [line(`<strong>${esc(made.name)}</strong> is added: innate, with the Focus trait, cast with Charisma.`)]);
    return Boolean(made);
  }
};

/* ------------------------------------------------------------------ */
/* Pact Boon and Pact Ascendant                                         */
/* ------------------------------------------------------------------ */

/** The pact's spell for this actor's class: a Warlock's innate Focus copy (Q37), a Witch's repertoire copy (Q99). */
async function grantPactSpell(actor, item, name, note = "") {
  if (!name) return null;
  if (knownNames(actor).has(norm(name))) { await card(actor, item.name, [line(`You already know <strong>${esc(name)}</strong>.`)]); return null; }
  const data = await packSpellData(name);
  if (!data) { await card(actor, item.name, [line(`<strong>${esc(name)}</strong> is not in the spells packs yet.`)]); return null; }
  const cls = className(actor);
  const copy = cls === "warlock" ? warlockCopy(data, { source: item, slot: "pact" }) : repertoireCopy(data, { source: item, highMagic: witchNeedsHighmagic(cls, data.system?.tradition) });
  copy.flags[MODULE_ID] = { ...(copy.flags[MODULE_ID] ?? {}), eaPick: { feat: item.id, kind: "pact", level: levelOf(actor) } };
  const [made] = await actor.createEmbeddedDocuments("Item", [copy]);
  if (made) await card(actor, item.name, [line(`<strong>${esc(made.name)}</strong> is added to your repertoire${cls === "warlock" ? ": innate, Focus, cast with Charisma" : ", outside your picks"}.${note ? ` ${note}` : ""}`)]);
  return made ?? null;
}

async function pactBoonGrant(actor, item) {
  const pact = pactKeyOf(actor);
  if (!pact) return warn("Pact Boon: you hold no Pact archetype feat.");
  return grantPactSpell(actor, item, BOON_SPELL[pact], pact === "elemental" ? "<em>Your element only: the GM's.</em>" : "");
}
const pactBoon = { hint: "Add your pact's boon spell.", async use(actor, item) { return Boolean(await pactBoonGrant(actor, item)); } };

/** Pact Ascendant's passive half: one feat effect, and the feat's aura (Angelic). */
async function syncAscendant(actor, item, { ask = false } = {}) {
  const pact = pactKeyOf(actor);
  let element = pactElementOf(actor, item);
  if (pact === "elemental" && !element && ask) {
    const pick = await h().chooseFromList("Pact Ascendant", "Your Elemental Pact's element:", Object.keys(ELEMENT_DAMAGE).map((k) => [k, `${k} (${ELEMENT_DAMAGE[k]})`]));
    if (ELEMENT_DAMAGE[pick]) { await item.setFlag(MODULE_ID, "element", pick); element = pick; }
  }
  const passive = ascendantPassive(pact, element);
  const auras = passive?.auras ?? [];
  if (JSON.stringify(item.flags?.[SYSTEM_ID]?.auras ?? []) !== JSON.stringify(auras)) await item.update({ [`flags.${SYSTEM_ID}.auras`]: auras });
  const stale = Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(SYSTEM_ID, "featSource") === item.id);
  if (!passive || (!passive.changes.length && !Object.keys(passive.flags).length)) {
    if (stale.length) await actor.deleteEmbeddedDocuments("ActiveEffect", stale.map((e) => e.id));
    return passive;
  }
  await h().replaceFeatEffect(actor, item, {
    name: `Pact Ascendant (${pact[0].toUpperCase()}${pact.slice(1)})`, img: item.img,
    description: `Pact Ascendant: ${passive.text}.`, changes: passive.changes,
    flags: { [SYSTEM_ID]: { ...passive.flags } }
  });
  return passive;
}

async function pactAscendantArrives(actor, item, { ask = true } = {}) {
  const pact = pactKeyOf(actor);
  if (!pact) return warn("Pact Ascendant: you hold no Pact archetype feat.");
  const passive = await syncAscendant(actor, item, { ask });
  await card(actor, "Pact Ascendant", [line(`Your ${esc(pact)} pact: ${passive ? esc(passive.text) : "its element is not chosen yet — press Use"}.`)]);
  if (ASCENDANT_SPELL[pact]) await grantPactSpell(actor, item, ASCENDANT_SPELL[pact], pact === "elemental" ? "<em>Your element only: the GM's.</em>" : "");
  return true;
}
const pactAscendant = { hint: "Apply your pact's ascendancy (again, if your pact changed).", async use(actor, item) { return pactAscendantArrives(actor, item); } };

/** The Demonic burst (Q141): 10d6 fire, basic Reflex against your Level DC, everyone within 20 feet. */
export async function demonicBurst(actor) {
  const me = tokenOf(actor);
  const roll = await new Roll(DEMONIC_BURST.dice).evaluate();
  const dc = h().levelDC(levelOf(actor));
  const lines = [line(`You explode in hellfire: <strong>${roll.total}</strong> fire (${DEMONIC_BURST.dice}), basic Reflex DC ${dc} (your Level DC), within ${DEMONIC_BURST.radiusFeet} feet. You rise at half your maximum HP.`)];
  const near = me ? Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor && t !== me && t.actor !== actor && (feetBetween(me, t) ?? Infinity) <= DEMONIC_BURST.radiusFeet) : [];
  if (!me) lines.push(line("<em>No token on the map: the GM resolves the burst.</em>"));
  for (const t of near) {
    const out = await h().basicSaveHit({ caster: actor, target: t.actor, save: "reflex", dc, label: DEMONIC_BURST.label, amount: roll.total, type: DEMONIC_BURST.type });
    if (out?.line) lines.push(line(out.line));
  }
  lines.push(line("<em>The Evil trait is the GM's to read against a creature resistant or weak to it.</em>"));
  await card(actor, DEMONIC_BURST.label, lines);
}

/* ------------------------------------------------------------------ */
/* The Witch's familiar: Extra Bond, Ethereal Insight, Soul-Bound Grimoire, Symbiotic Witch */
/* ------------------------------------------------------------------ */

async function chooseExtraBonds(actor, firstKey = "") {
  const copies = featsNamed(actor, "Extra Bond").length;
  if (!copies) return false;
  const old = ownEffects(actor, "extraBond");
  if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old.map((e) => e.id));
  const main = firstKey || ownEffects(actor, "soulboundBonus")[0]?.getFlag?.(MODULE_ID, "bonus") || "";
  const taken = main ? [main] : [];
  const made = [];
  for (let i = 0; i < copies; i += 1) {
    const pool = extraBondOptions(taken);
    const pick = await h().chooseFromList(`Extra Bond — ${i + 1} of ${copies}`, "One more bonus while your familiar is within 30 feet:", pool.map((b) => [b.key, b.label]));
    const bonus = pool.find((b) => b.key === pick);
    if (!bonus) break;
    taken.push(bonus.key);
    const data = effectData("extraBond", { name: `Extra Bond: ${bonus.label}`, img: "icons/svg/aura.svg", description: `Extra Bond: ${bonus.label} while your familiar is within 30 feet. Until your next daily bonus.`, changes: bonus.changes, module: { bonus: bonus.key } });
    if (bonus.conditionals) data.flags[SYSTEM_ID] = { ...(data.flags[SYSTEM_ID] ?? {}), conditionals: bonus.conditionals };
    await h().createEffectsOn(actor, [data]);
    made.push(bonus.label);
  }
  await refreshFamiliarRange(actor);
  if (made.length) await card(actor, "Extra Bond", [line(`Today's further bonus${made.length > 1 ? "es" : ""}: <strong>${esc(made.join("; "))}</strong>, while your familiar is within 30 feet.`)]);
  return made.length > 0;
}
const extraBond = { hint: "Choose today's further familiar bonuses.", async use(actor) { return chooseExtraBonds(actor); } };

async function abilityData(name) {
  const packs = Array.from(globalThis.game?.packs ?? []).filter((p) => p.documentName === "Item" && (p.collection === "trg-prime.abilities" || p.metadata?.flags?.[SYSTEM_ID]?.extends === "abilities"));
  for (const pack of packs) {
    const entry = Array.from((await pack.getIndex()).values()).find((e) => norm(e.name) === norm(name));
    if (entry) { const doc = await pack.getDocument(entry._id); if (doc) return doc.toObject(); }
  }
  return null;
}

/** Extra Bond's effects follow the familiar's range; Ethereal Insight's Darkvision rides on the familiar within 30 ft. */
export async function refreshFamiliarRange(actor) {
  if (!actor?.isOwner || !actsFor(actor)) return;
  const extra = ownEffects(actor, "extraBond");
  const insight = featOf(actor, "Ethereal Insight");
  if (!extra.length && !insight) return;
  const bond = await soulboundFamiliar(actor);
  const away = !bond.holds || familiarAway(actor, bond.familiar);
  for (const e of extra) if (Boolean(e.disabled) !== away) await e.update({ disabled: away });
  const fam = bond.familiar;
  if (!fam?.isOwner) return;
  const mine = items(fam).filter((i) => i.type === "ability" && i.flags?.[MODULE_ID]?.etherealInsightOf === actor.id);
  const wants = Boolean(insight) && bond.holds && !familiarAway(actor, fam, ETHEREAL_FAMILIAR_FEET);
  const native = items(fam).some((i) => i.type === "ability" && norm(i.name) === "darkvision" && !i.flags?.[MODULE_ID]?.etherealInsightOf);
  if (wants && !mine.length && !native) {
    const data = await abilityData("Darkvision");
    if (!data) return;
    delete data._id;
    data.flags = { ...(data.flags ?? {}), [MODULE_ID]: { ...(data.flags?.[MODULE_ID] ?? {}), etherealInsightOf: actor.id } };
    await fam.createEmbeddedDocuments("Item", [data]);
  } else if (!wants && mine.length) await fam.deleteEmbeddedDocuments("Item", mine.map((i) => i.id));
}

/** See Invisible, granted by Ethereal Insight, cast: its sight laid on the familiar within 30 ft (Q140). */
async function etherealSight(ctx) {
  const actor = ctx.actor;
  const spell = ctx.spell;
  if (!ctx.cast || ctx.refunded || norm(spell?.name) !== "see invisible" || norm(spell?.flags?.[SYSTEM_ID]?.grantedBy?.sourceName) !== "ethereal insight") return;
  const bond = await soulboundFamiliar(actor);
  if (!bond.holds || familiarAway(actor, bond.familiar, ETHEREAL_FAMILIAR_FEET)) return;
  const laid = Array.from(actor.effects ?? []).filter((e) => e.origin && e.origin === spell.uuid).map((e) => {
    const data = typeof e.toObject === "function" ? e.toObject() : JSON.parse(JSON.stringify(e));
    delete data._id;
    if (data.flags?.[SYSTEM_ID]) { delete data.flags[SYSTEM_ID].endsWithCast; delete data.flags[SYSTEM_ID].castId; }
    data.flags = { ...(data.flags ?? {}), [MODULE_ID]: { ...(data.flags?.[MODULE_ID] ?? {}), source: "etherealInsightSight" } };
    return data;
  });
  if (!laid.length) return;
  await h().createEffectsOn(bond.familiar, laid);
  await card(actor, "Ethereal Insight", [line(`<strong>${esc(bond.familiar.name)}</strong>, within 30 feet, sees as you do: See Invisible's sight, for the spell's duration.`)]);
}

/* Soul-Bound Grimoire */
const storedOf = (item) => (Array.isArray(item?.flags?.[MODULE_ID]?.stored) ? item.flags[MODULE_ID].stored : []);

async function revertImprint(actor) {
  const copies = items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.eaImprint);
  if (copies.length) await actor.deleteEmbeddedDocuments("Item", copies.map((i) => i.id));
  for (const s of items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.grimoireDiscount)) {
    const back = Math.max(0, int(s.flags?.[SYSTEM_ID]?.warpDiscount) - int(s.flags[MODULE_ID].grimoireDiscount));
    await s.update({ [`flags.${SYSTEM_ID}.warpDiscount`]: back, [`flags.${MODULE_ID}.grimoireDiscount`]: 0 });
  }
}

async function grimoireDaily(actor, item) {
  await revertImprint(actor);
  const bond = await soulboundFamiliar(actor);
  if (bond.dead && storedOf(item).length) {
    await item.setFlag(MODULE_ID, "stored", []);
    return card(actor, "Soul-Bound Grimoire", [line(`${esc(bond.familiar?.name ?? "Your familiar")} is dead: the spells stored in it are lost (Q138).`)]);
  }
  if (!bond.familiar || bond.dead) return;
  const index = await spellIndex();
  const tradOf = (name) => index.find((e) => norm(e.name) === norm(name))?.system?.tradition ?? "";
  let stored = [...storedOf(item)];
  for (;;) {
    const scrolls = items(actor).filter((i) => i.type === "consumable" && norm(i.flags?.[SYSTEM_ID]?.consumable?.kind) === "scroll")
      .map((i) => ({ item: i, spell: i.flags?.[SYSTEM_ID]?.consumable?.spell }))
      .map((s) => ({ ...s, name: typeof s.spell === "string" ? s.spell : String(s.spell?.name ?? "") }))
      .filter((s) => s.name && grimoireScrollOk(tradOf(s.name)) && !stored.some((x) => norm(x.name) === norm(s.name)));
    if (!scrolls.length) break;
    const id = await h().chooseFromList("Soul-Bound Grimoire", "Scribe a scroll into your familiar (it is used up; cancel when done):", scrolls.map((s) => [s.item.id, `${s.name} (${s.item.name})`]));
    const s = scrolls.find((x) => x.item.id === id);
    if (!s) break;
    const qty = int(s.item.system?.quantity ?? 1);
    if (qty > 1) await s.item.update({ "system.quantity": qty - 1 });
    else await actor.deleteEmbeddedDocuments("Item", [s.item.id]);
    stored = [...stored, { name: s.name }];
    await item.setFlag(MODULE_ID, "stored", stored);
    await card(actor, "Soul-Bound Grimoire", [line(`<strong>${esc(s.name)}</strong> is scribed into ${esc(bond.familiar.name)}; the scroll is consumed.`)]);
  }
  if (bond.severed) return card(actor, "Soul-Bound Grimoire", [line("Your bond is severed: nothing is imprinted today.")]);
  if (!stored.length) return;
  const pick = await h().chooseFromList("Soul-Bound Grimoire", "Imprint one stored spell for today:", stored.map((s, i) => [String(i), s.name]));
  const chosen = pick !== null && pick !== undefined && pick !== "" ? stored[int(pick)] : null;
  if (!chosen) return;
  const known = items(actor).find((i) => i.type === "spell" && norm(i.name) === norm(chosen.name));
  if (known) {
    await known.update({ [`flags.${SYSTEM_ID}.warpDiscount`]: int(known.flags?.[SYSTEM_ID]?.warpDiscount) + 1, [`flags.${MODULE_ID}.grimoireDiscount`]: 1 });
    return card(actor, "Soul-Bound Grimoire", [line(`<strong>${esc(known.name)}</strong> is already yours: −1 PP off its warping cost today (minimum 1).`)]);
  }
  const data = await packSpellData(chosen.name);
  if (!data) return warn(`Soul-Bound Grimoire: ${chosen.name} is not in the spells packs.`);
  const [made] = await actor.createEmbeddedDocuments("Item", [repertoireCopy(data, { source: item, flags: { eaImprint: true } })]);
  if (made) await card(actor, "Soul-Bound Grimoire", [line(`<strong>${esc(made.name)}</strong> rises from ${esc(bond.familiar.name)}'s memory: castable today as if in your repertoire.`)]);
}

const soulBoundGrimoire = {
  hint: "Erase a spell stored in your familiar.",
  async use(actor, item) {
    const stored = storedOf(item);
    if (!stored.length) return card(actor, "Soul-Bound Grimoire", [line("No spell is stored in your familiar. Scrolls are scribed at your daily preparation.")]);
    const pick = await h().chooseFromList("Soul-Bound Grimoire", "Erase which stored spell?", stored.map((s, i) => [String(i), s.name]));
    if (pick === null || pick === undefined || pick === "") return false;
    const gone = stored[int(pick)];
    await item.setFlag(MODULE_ID, "stored", stored.filter((_, i) => i !== int(pick)));
    await card(actor, "Soul-Bound Grimoire", [line(`<strong>${esc(gone?.name)}</strong> is erased from your familiar.`)]);
    return true;
  }
};

/* Symbiotic Witch */
const CONDUIT = new Set();
const symbioticWitch = {
  hint: "Cast through your familiar (1/day), or hand it a sustained spell.",
  async use(actor, item) {
    const bond = await soulboundFamiliar(actor);
    if (!bond.holds) return warn("Symbiotic Witch: your Soulbound bond must hold (and your familiar live).");
    const what = await h().chooseFromList("Symbiotic Witch", `${bond.familiar.name}:`, [["conduit", "Cast a spell of 4 PP or less through your familiar (once a day)"], ["sustain", "Your familiar sustains a spell (or hands it back)"]]);
    if (what === "sustain") return symbioticSustain(actor, bond.familiar);
    if (what !== "conduit") return false;
    if (usesLeft(item) <= 0) return warn("Symbiotic Witch: today's conduit is spent — daily preparation restores it.");
    const ftoken = tokenOf(bond.familiar);
    if (!ftoken) return warn("Symbiotic Witch: place your familiar's token on the map (its position is the cast's origin).");
    const castable = [];
    for (const s of items(actor).filter(conduitAllows)) if (await h().spellCastable(actor, s)) castable.push(s);
    if (!castable.length) return warn("Symbiotic Witch: you have no spell of 4 PP or less you can cast today.");
    const id = await h().chooseFromList("Symbiotic Witch", "Cast through your familiar:", castable.map((s) => [s.id, `${s.name} (PP ${int(s.system?.ppCost)})`]));
    const spell = castable.find((s) => s.id === id);
    if (!spell) return false;
    CONDUIT.add(actor.id);
    let result = null;
    try { result = await h().castSpell(actor, spell, { rangeFrom: ftoken.document?.uuid ?? "" }); } finally { CONDUIT.delete(actor.id); }
    if (!result) return false;
    await spendUse(item);
    await card(actor, "Symbiotic Witch", [line(`${esc(spell.name)} is cast through <strong>${esc(bond.familiar.name)}</strong>: range and area from its token.`), line("<em>Today's conduit is spent.</em>")]);
    return true;
  }
};

async function symbioticSustain(actor, familiar) {
  const entries = Array.isArray(actor.getFlag?.(SYSTEM_ID, "activeSpells")) ? actor.getFlag(SYSTEM_ID, "activeSpells") : [];
  const held = entries.find((e) => e?.sustainedBy?.uuid === familiar.uuid);
  if (held) {
    if (!(await confirm("Symbiotic Witch", `${esc(familiar.name)} sustains ${esc(held.name)}. Take it back?`))) return false;
    await h().setSpellSustainer(actor, held.id, null);
    await card(actor, "Symbiotic Witch", [line(`You sustain <strong>${esc(held.name)}</strong> again, from this round.`)]);
    return true;
  }
  const open = entries.filter((e) => e?.sustained && !e.sustainedBy);
  if (!open.length) return warn("Symbiotic Witch: you are sustaining no spell to hand over.");
  const id = await h().chooseFromList("Symbiotic Witch", `Which spell does ${familiar.name} sustain?`, open.map((e) => [e.id, e.name]));
  if (!open.some((e) => e.id === id)) return false;
  const entry = await h().setSpellSustainer(actor, id, { uuid: familiar.uuid, label: `${familiar.name} (Symbiotic Witch)` });
  if (!entry) return warn("Symbiotic Witch: that spell is not sustained.");
  await card(actor, "Symbiotic Witch", [line(`<strong>${esc(familiar.name)}</strong> sustains <strong>${esc(entry.name)}</strong>: you need not Sustain it and may recover PP. Damage to ${esc(familiar.name)} asks your Spell Concentration check; its death ends the spell at your next turn.`)]);
  return true;
}

/* ------------------------------------------------------------------ */
/* Malevolent Blast                                                     */
/* ------------------------------------------------------------------ */

async function malevolentBlast(ctx) {
  const actor = ctx.actor;
  if (!ctx.spell?.flags?.[SYSTEM_ID]?.eaXithra || !ctx.cast) return;
  const hit = (ctx.spellHits ?? [])[0];
  if (!hit?.target) return;
  const feat = featOf(actor, "Malevolent Blast");
  if (!feat || usesLeft(feat) <= 0) return;
  if (!(await confirm("Malevolent Blast", `Xithra hits ${esc(hit.target.name)}${hit.critical ? " (critical)" : ""}. Spend Malevolent Blast's Focus use: Will save or Stunned ${hit.critical ? 2 : 1}?`))) return;
  await spendUse(feat);
  const dc = await h().innateSaveDCFor(actor, ctx.spell);
  const check = await h().rollCheck({ actor: hit.target, type: "save", subject: "will", label: `${hit.target.name} — Will Save`, subtitle: `vs Malevolent Blast — DC ${dc.value}`, saveSource: "Malevolent Blast", sourceUuid: actor.uuid, dc: dc.value });
  const degree = check?.outcome?.degree?.key ?? "failure";
  const stun = malevolentStun(degree, hit.critical);
  if (stun) await h().applyConditionTagsTo(hit.target, [{ key: "stunned", value: stun }]);
  await card(actor, "Malevolent Blast", [line(`${esc(hit.target.name)}: Will <strong>${esc(check?.outcome?.degree?.label ?? degree)}</strong> (DC ${dc.value}) — ${stun ? `<strong>Stunned ${stun}</strong>` : "unaffected"}.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
}

/* ------------------------------------------------------------------ */
/* Registration and hooks                                               */
/* ------------------------------------------------------------------ */

export const AUTOMATIONS_B6_E = Object.freeze({
  "Elemental Blast": elementalBlast,
  "Extra Bond": extraBond,
  "Forbidden Lore": forbiddenLore,
  "Hex Binders Curse": hexBindersCurse,
  "High Sorcery": highSorcery,
  "Pact Ascendant": pactAscendant,
  "Pact Boon": pactBoon,
  "Ritual of Borrowed Power": borrowedPower,
  "Shadowed Grimoire": shadowedGrimoire,
  "Soul-Bound Grimoire": soulBoundGrimoire,
  "Symbiotic Witch": symbioticWitch,
  "Warding Sigil": wardingSigil
});
export const STEPS_B6_E = Object.freeze({ hexStep });

/** Every registration group E makes; called once from registerContent (trgPrime.registerContent). */
export function registerBlock6E(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_E)) api.registerFeatAutomation(name, entry, moduleId);
  api.registerExtraUses?.("Extra Communion", { ability: "Verdant Communion", perCopy: 1 }, moduleId);
  api.registerCastCostModifier?.("hexMastery", hexMasteryModifier, moduleId);
  api.registerCastPrelude?.("xithraCone", xithraConePrelude, moduleId);
  api.registerReactionStep?.(HEX_STEP, hexStep, moduleId);
}

/** Hooks.on("trgPrimeSpellSettled"): Malevolent Blast, Ethereal Insight's sight, the conduit's limit. */
export async function onSpellSettledB6E(ctx = {}) {
  const actor = ctx.actor;
  const conduit = actor && CONDUIT.has(actor.id);
  if (!actor?.isOwner) return;
  if (conduit && ctx.cast !== undefined) {
    const pp = int(ctx.castPP ?? ctx.totalPP ?? ctx.ppSpent);
    if (pp > CONDUIT_MAX_PP) await card(actor, "Symbiotic Witch", [line(`<em>${esc(ctx.spell?.name ?? "The spell")} was cast through your familiar at ${pp} PP, above the conduit's 4: the GM rules.</em>`)]);
  }
  await malevolentBlast(ctx);
  await etherealSight(ctx);
}

/**
 * Hooks.on("trgPrimeDamageApplied"): Warlock's Hex (asked of the Warlock)
 * and Hex Binders Curse's extra dice. Fired once, on the client that applied
 * the damage; acts there when it owns the source or is the GM.
 */
export async function onDamageAppliedB6E(payload = {}) {
  // The curse's own dice ({ kind: "hexBindersCurse" }) answer neither rule (hexWanted, curseWanted).
  if (!payload?.actor || !payload.sourceUuid) return;
  const source = actorOf(await fromUuid(payload.sourceUuid));
  if (!source || !(source.isOwner || globalThis.game?.user?.isGM)) return;
  await hexBindersExtra(payload, source);
  await warlocksHexOffer(payload, source);
}

/** Hooks.on("trgPrimeDailyPreparation"): Elemental Blast, Hex Binders Curse ends, Ritual of Borrowed Power, Soul-Bound Grimoire. */
export async function onDailyPreparationB6E({ actor } = {}) {
  if (!actor?.isOwner) return;
  if (actor.getFlag?.(MODULE_ID, "hexCurse")) await clearCurse(actor);
  const blast = featOf(actor, "Elemental Blast");
  if (blast) await chooseElement(actor, blast, "Daily preparation: Xithra's element today (instead of mental):");
  const borrowed = featOf(actor, "Ritual of Borrowed Power");
  if (borrowed) await chooseBorrowed(actor, borrowed);
  const grimoire = featOf(actor, "Soul-Bound Grimoire");
  if (grimoire) await grimoireDaily(actor, grimoire);
}

/** Hooks.on("createItem") — wire AFTER onItemCreatedB4: Xithra's sync; Pact Boon and Pact Ascendant arrive. */
export async function onItemCreatedB6E(item) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  const name = norm(item.name);
  if ((item.type === "feat" && XITHRA_FEATS.includes(name)) || (item.type === "spell" && item.flags?.[SYSTEM_ID]?.eaXithra) || (item.type === "ability" && item.flags?.[SYSTEM_ID]?.eaBondedSoul)) await syncXithraB6E(actor);
  if (item.type === "feat" && name === "pact boon") await pactBoonGrant(actor, item);
  if (item.type === "feat" && name === "pact ascendant") await pactAscendantArrives(actor, item);
  if (item.type === "feat" && name === "ethereal insight") await refreshFamiliarRange(actor);
}

/** Hooks.on("deleteItem"): Xithra put back; Ethereal Insight's familiar Darkvision removed. */
export async function onItemDeletedB6E(item) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  const name = norm(item.name);
  if (item.type === "feat" && XITHRA_FEATS.includes(name)) await syncXithraB6E(actor);
  if (item.type === "feat" && name === "ethereal insight") await refreshFamiliarRange(actor);
  if (item.type === "feat" && name === "pact ascendant") {
    const ids = Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(SYSTEM_ID, "featSource") === item.id).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids);
  }
}

/** Hooks.on("createActiveEffect"): the Soulbound daily bonus chosen → Extra Bond's further picks. */
export async function onEffectCreatedB6E(effect) {
  const actor = effect?.parent?.documentName === "Actor" ? effect.parent : null;
  if (!actor?.isOwner || !actsFor(actor)) return;
  if (effect.getFlag?.(MODULE_ID, "source") !== "soulboundBonus" || !featOf(actor, "Extra Bond")) return;
  await chooseExtraBonds(actor, effect.getFlag(MODULE_ID, "bonus") ?? "");
}

/** Hooks.on("updateToken", (doc, change)): the familiar's 30 feet, for its master or itself. */
export async function onTokenMovedB6E(doc, change = {}) {
  if (!("x" in (change ?? {})) && !("y" in (change ?? {}))) return;
  const actor = doc?.actor;
  if (!actor) return;
  await refreshFamiliarRange(actor);
  const bound = actor.getFlag?.(MODULE_ID, "soulbound");
  if (bound) await refreshFamiliarRange(globalThis.game?.actors?.get?.(bound.masterId));
}

/** Hooks.on("trgPrimeDeathGuardHeld", ctx): Pact Ascendant (Demonic)'s burst, on the client that applied the blow. */
export async function onDeathGuardHeldB6E(ctx = {}) {
  if (ctx?.label !== DEMONIC_GUARD_LABEL || !ctx.actor) return;
  await demonicBurst(ctx.actor);
}

/** Hooks.once("ready") and Hooks.on("canvasReady"): Xithra and Pact Ascendant trued up for every actor this client acts for. */
/**
 * Hooks.once("ready") and Hooks.on("canvasReady"): THE FAMILIAR'S RANGE ONLY
 * (review, 0.9.0) — Extra Bond's effects switched by the 30 feet, Ethereal
 * Insight's Darkvision on the familiar. Xithra and Pact Ascendant are written
 * only on their own events (createItem, deleteItem, a feat's Use), so a GM's
 * hand edit of either is never reverted by loading a scene.
 */
export async function refreshFamiliarsB6E() {
  for (const actor of Array.from(globalThis.game?.actors ?? [])) {
    if (!actor?.isOwner || !actsFor(actor)) continue;
    await refreshFamiliarRange(actor);
  }
}
