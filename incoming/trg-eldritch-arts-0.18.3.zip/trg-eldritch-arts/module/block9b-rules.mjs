/**
 * Block 9b (0.14.0, on TRG Prime 3.689.0): Chapter 9's 18 armour and shield
 * runes, 16 weapon runes, 5 specific armours and shields and 4 specific
 * weapons. Pure: the rune registrations (TRG Prime's `registerRunes`, with
 * what each declares — H21's keys and the core's own), the specific items'
 * printed figures, and the small rules the workflows ask. No Foundry.
 *
 * Built from the Block 9 audit (§3.2.4, §3.2.5, §3.2.9, §3.2.10) as Graham
 * answered it on 13 November 2026 ("Go with your recommendation for all
 * questions and proceed"): Q192–Q206.
 *
 * A RUNE COUNTS WHILE ITS ITEM IS EQUIPPED, as every rune in TRG Prime does
 * (`runesCountFor`). The 34 print INVESTED; the core tracks investment for
 * items with the Invested trait, not for the runes inscribed on mundane armour
 * and weapons, and its own INVESTED runes count while equipped. So do these.
 */

const freeze = Object.freeze;
const T = (...rows) => rows.map(([level, price, extra = {}]) => ({ level, price, ...extra }));

export const MODULE_ID = "trg-eldritch-arts";
export const SYSTEM_ID = "trg-prime";

/** The book's rune name → the key it is registered under. */
export const runeKey = (name) => `ea${String(name).replace(/[’']/g, "").split(/\s+/).map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join("")}`;

/* ------------------------------------------------------------------ */
/* Armour and shield runes (L8943–9153; tiers in sidebars 17–28)          */
/* ------------------------------------------------------------------ */

export const ARMOUR_RUNES_9B = freeze({
  AEGISFLOW: {
    on: ["armour"], traits: "Invested, Warding", tiers: T([8, 4200], [14, 36000]),
    declares: { uncoveredDR: { share: [0.5, 1] } },
    grade: "A", note: "On a critical to a location the armour does not cover, the armour gives that location half its DR (I) or all of it (II). A hit that is not a critical meets every worn piece's DR already."
  },
  "ARCANUM SEAL": {
    on: ["armour"], traits: "Enchantment, Invested", tiers: T([5, 1250], [10, 8000], [15, 55000]),
    declares: { spellAdder: [1, 2, 3] },
    grade: "A", note: "While the armour is worn: a +1 / +2 / +3 Spell Adder (that many free casts a day), among the character's Spell Adders."
  },
  "ASTRAL ECHOES": {
    on: ["armour"], traits: "Invested, Warding", tiers: T([6, 2000], [12, 16000], [18, 180000]),
    declares: { criticalRollModifier: { value: [-5, -10, -15], exceptFaces: [66, 100] } },
    grade: "A", note: "A critical injury rolled against the wearer is reduced by 5 / 10 / 15 (never below 1), shown on the injury card; nothing on an unmodified 66 or 100."
  },
  "BINDING SIGILS": {
    on: ["armour"], traits: "Enchantment, Invested", tiers: T([4, 750], [8, 4200], [12, 16000]),
    declares: { controlSaveModifier: [-2, -4, -6] },
    grade: "A", note: "−2 / −4 / −6 on the DC 20 Will save a creature over your control levels makes to break free (Graham's Q197), while the armour is worn. A bound creature commanded against its nature saves as the GM rules: apply the same penalty."
  },
  "BOUND CIRCLE": {
    on: ["armour"], traits: "Invested, Warding", tiers: T([4, 750], [10, 8000], [16, 80000]),
    declares: { defenceDC: [{ dc: "defence", value: [1, 2, 3], type: "untyped", label: "attacks by a conjured or summoned creature", scope: "conjured or summoned attacker", when: { sourceTraits: ["conjured", "summoned"] } }] },
    grade: "A", note: "+1 / +2 / +3 DB (the armour's item bonus, raised) against a Strike or spell attack by a creature with the Conjured trait or one somebody holds in their control register as bound or conjured (Q197)."
  },
  CATALYST: {
    on: ["shield"], traits: "Alteration, Invested", tiers: T([4, 750], [8, 4200], [12, 16000], [16, 80000]),
    declares: {}, slots: [1, 2, 3, 4],
    grade: "B", note: "Embed 1 / 2 / 3 / 4 catalysts (Embed a Catalyst, on the shield's owner: 10 minutes; replacing one destroys it — Q192). While the shield is wielded each is offered once a day among your catalysts when you cast, and is not consumed; its backlash applies as normal. Catalyst Conservation and the Rod of the Catalyst Flow do not apply to it."
  },
  COMFORT: {
    on: ["armour"], traits: "Alteration, Invested", level: 5, price: 1250,
    declares: { maxDexBonus: 1, sleepAdvantage: true },
    grade: "A", note: "Sleeping in Armour's Fortitude save is rolled with advantage, and the armour's Max Dex is 1 higher."
  },
  "FORCE WARDING": {
    on: ["armour"], traits: "Invested, Warding", level: 10, price: 8000,
    declares: { resistances: ["force"] },
    grade: "A", note: "Resistance to force damage while the armour is worn."
  },
  "LEY BINDING": {
    on: ["armour"], traits: "Invested, Warding", tiers: T([4, 750], [8, 4200], [12, 16000]),
    declares: { defenceDC: [{ dc: "defence", value: [1, 2, 3], type: "circumstance", label: "attack spells", scope: "spell attacks", when: { attackKinds: ["spell"] } }] },
    grade: "B", note: "+1 / +2 / +3 circumstance DB against a spell attack (Q194: circumstance). Against \"spells with the save trait that inflict damage\" DB is not rolled against, so that half is not applied — asked of Graham."
  },
  LUMINOUS: {
    on: ["armour", "shield"], traits: "Invested, Invocation", tiers: T([4, 750], [6, 2000], [8, 4200]),
    shieldPrices: [550, 1400, 3000], declares: {}, lightSteps: [1, 2, 3],
    grade: "A", note: "While the armour or shield is equipped, it raises the light level by one / two / three steps in a 20-foot radius around its bearer (a light source on the token). Shield prices: 550 / 1,400 / 3,000 gp."
  },
  NULLFLOW: {
    on: ["armour"], traits: "Invested, Warding", tiers: T([8, 4200], [12, 16000], [16, 80000]),
    declares: {}, perDay: [1, 2, 3],
    grade: "B", note: "When a spell's check succeeds against the wearer — targeted, or with the wearer in its area (Q195) — they are asked to react: a Dispel (Power Manipulation) check against the spell's Casting DC, ±2 for each step between the rune's level and the spell's PP; on a success the spell does not land on them. Once / twice / three times a day. \"Then resumes for any remaining duration\" after 1 minute: the GM applies what remains, if anything does."
  },
  RENEWAL: {
    on: ["armour", "shield"], traits: "Alteration, Invested", tiers: T([6, 2000], [10, 8000], [14, 36000]),
    shieldPrices: [1400, 5600, 25200], declares: {}, repairPerLevel: [1, 2, 3],
    grade: "A", note: "At your daily preparation the item regains HP equal to its level (I), twice (II) or three times (III), to its maximum. A destroyed item's rune unravels: it is struck from the item. Shield prices: 1,400 / 5,600 / 25,200 gp."
  },
  "RESONANT DEFIANCE": {
    on: ["shield"], traits: "Insight, Invested", tiers: T([5, 1250], [9, 6000], [13, 24000]),
    declares: {}, dcStep: [2, 4, 6],
    grade: "B", note: "When an enemy within 30 feet casts a spell, the shield's bearer is asked to react (once per trigger, using their reaction — Q198): the spell's Casting DC is raised by 2 / 4 / 6. \"Your shield is raised\" is read as the shield being equipped (TRG Prime keeps no raised state) — asked of Graham."
  },
  "SOUL WARDING": {
    on: ["armour"], traits: "Invested, Warding", level: 8, price: 4200,
    declares: { resistances: ["essence"] },
    grade: "A", note: "Resistance to essence damage while the armour is worn."
  },
  SWIFTBIND: {
    on: ["armour"], traits: "Alteration, Invested", level: 6, price: 2000, aliases: ["Quickbind"],
    declares: { donAP: { light: 1, medium: 2, heavy: 3, fullExtra: 1 } },
    grade: "A", note: "The armour is donned with a 1 AP (light), 2 AP (medium) or 3 AP (heavy) Interact; a full suit +1 AP. The item sheet shows it. (v1.6 renamed the Quickbind rune; Gravemeld Shirt still prints the old name.)"
  },
  TRANSCENDENT: {
    on: ["armour", "shield"], traits: "Alteration, Invested", level: 8, armourPrice: 4200, shieldPrice: 3000,
    declares: { armourCastingPenalty: 0 },
    grade: "A", note: "The armour adds no casting penalty: neither its tradition's nor High Magic's DR × 4 (Graham's Q199). It still does not allow a Druid to wear metal armour."
  },
  VEIL: {
    on: ["armour"], traits: "Alteration, Invested", tiers: T([6, 2000], [9, 6000], [12, 16000]),
    declares: {}, perDay: [1, 2, 3],
    grade: "B", note: "When an attack leaves the wearer below 25% of their maximum HP, or deals them a critical of serious or worse, they are asked to react: they become incorporeal until the end of their next turn (or until they end it, free), with their equipment, and may take only Move and Defence actions (Q196; M78: the Incorporeal trait in full). Once / twice / three times a day."
  },
  WILDBANE: {
    on: ["armour", "shield"], traits: "Invested, Warding", level: 11, armourPrice: 11000, shieldPrice: 7700,
    declares: { conditionals: [
      { kind: "modifier", value: 2, type: "circumstance", label: "against a Wild Magic surge", scope: "saving throws against a wild surge's effect", when: { checkTypes: ["save"] } }
    ] },
    grade: "B", note: "+2 circumstance to saves against a wild surge's effect (offered on the save, unticked: the save is the table's to name). Its +2 to DB against a surge's attack is the GM's to add. Whenever a wild surge occurs within 30 feet, a DC 15 flat check is rolled for the bearer, on the surge's card: on a success the surge is suppressed for them and their adjacent allies (the card names them; the GM leaves them out of its effect)."
  }
});

/* ------------------------------------------------------------------ */
/* Weapon runes (L9715–9955; tiers in sidebars 29–32)                     */
/* ------------------------------------------------------------------ */

const MELEE = (text = "any melee weapon") => ({ melee: true, text });

export const WEAPON_RUNES_9B = freeze({
  AETHERFANG: {
    on: ["weapon"], traits: "Invested, Shadow", level: 10, price: 6000, usage: { damage: ["piercing", "slashing"], text: "any piercing or slashing weapon" },
    declares: { ignoreResistance: ["bludgeoning", "piercing", "slashing", "physical"] },
    grade: "A", note: "Its Strikes ignore the target's resistance to physical damage (not immunity). On a critical: 1d6 essence damage per severity step (Minor 1, Serious 2, Deadly 3), basic Fortitude against your Level DC (Q201). If the weapon is fumbled: 2d6 essence damage to you, basic Fortitude against your Level DC."
  },
  CHRONO: {
    on: ["weapon"], traits: "Alteration, Invested", level: 13, price: 17000, usage: { text: "any weapon" },
    declares: { action: { verb: "Activate", apCost: 0, frequency: "atWill", state: "eaChrono", durationSeconds: 86400, describe: "You gain the quickened condition which may only be used to make an action with the attack trait. It runs until you end it (press again) or become Fatigued; the day on its timer is only a backstop." } },
    grade: "B", note: "Activate (Command, 0 AP): you are Quickened, its AP for a Strike only, from your next turn while it runs (Q200: until you end it, free, or become Fatigued). At the end of each of your turns it runs, an Exhaustion check: Easy, one step harder each consecutive turn. Fatigued ends it and it cannot be activated."
  },
  ECHOING: {
    on: ["weapon"], traits: "Invested, Invocation, Sonic", tiers: T([5, 900], [10, 6000], [15, 40000]), usage: MELEE(),
    declares: {}, recurring: [1, 2, 3],
    grade: "A", note: "On a critical: 1 / 2 / 3 recurring sonic damage on the target. The faint whispers after each strike (audible within 30 feet) are said on the card."
  },
  ESSENCEBREAKER: {
    on: ["weapon"], traits: "Invested, Save, Warding", level: 12, price: 11000, usage: { text: "any weapon" },
    declares: {},
    grade: "B", note: "On a hit: a Will save against your Level DC; on a failure the target loses one of its resistances (you choose, Q201) until the end of your next turn."
  },
  GRAVITAS: {
    on: ["weapon"], traits: "Alteration, Invested", level: 11, price: 8000, usage: { damage: ["bludgeoning"], text: "any bludgeoning weapon" },
    declares: { fumbleDCModifier: 2 },
    grade: "B", note: "Once per round on a critical you are offered a Trip or Shove of the target, free, with no MAP and no requirements, rolled with your weapon attack bonus. Drawback: the weapon's Fumble DC is 2 higher; its weight is doubled — change the item's weight by hand."
  },
  LEYBOUND: {
    on: ["weapon"], traits: "Insight, Invested", level: 8, price: 3000, usage: { text: "any weapon" },
    declares: {},
    grade: "A", note: "Within 30 feet of a ley line: +1 circumstance to your Strikes with it, and one more die of its base damage. When you fumble with it, a wild surge is rolled too, area level the ley line's level (the nearest line's, if any; else none)."
  },
  MINDPIERCER: {
    on: ["weapon"], traits: "Enchantment, Invested, Mental, Save", tiers: T([6, 1400], [10, 6000], [14, 25000], [18, 130000]), usage: { text: "any weapon" },
    declares: { conditionals: [{ kind: "modifier", value: -1, type: "untyped", label: "waking visions (GM discretion)", scope: "Perception, when the GM says so", when: { checkTypes: ["skill"], subjects: ["perception"] } }] },
    grade: "A", note: "On a critical: 1d8 / 2d8 / 3d8 / 4d8 mental damage, basic Will against your Level DC (Q201). Drawback: −1 to Perception at the GM's discretion (offered on the check, unticked)."
  },
  NULLFLARE: {
    on: ["weapon"], traits: "Invested, Save, Warding", level: 12, price: 11000, usage: { text: "any weapon" },
    declares: {},
    grade: "B", note: "On a hit: a Will save against your Level DC. Failure: the target's lowest-PP spell effect is suppressed until the beginning of your next turn; Fumble: until the end of your next turn; Blunder: it ends. A tie between effects is yours to break (the GM's, when they swing)."
  },
  PYREBRAND: {
    on: ["weapon"], traits: "Fire, Invested, Invocation", tiers: T([5, 900], [10, 6000], [15, 40000]), usage: MELEE(),
    declares: {
      energy: { type: "fire", tiers: [{ dice: "1d4" }, { dice: "2d4" }, { dice: "3d4" }] },
      conditionals: [{ kind: "modifier", value: -2, type: "circumstance", label: "smoking weapon", scope: "Hide (Stealth) checks to remain unnoticed", when: { checkTypes: ["skill"], subjects: ["stealth"] } }]
    },
    surge: ["1d8", "2d8", "3d8"],
    grade: "A", note: "Activate (Command, 1 AP), as an energy rune: 1d4 / 2d4 / 3d4 secondary fire on its Strikes. On a natural 20 while active: 1d8 / 2d8 / 3d8 fire to every creature adjacent to the target but you, basic Reflex against your Level DC (Q201). Drawback: −2 circumstance to Hide (Stealth), offered on the check."
  },
  RIFTCLEAVER: {
    on: ["weapon"], traits: "Invested, Teleportation, Translocation", level: 10, price: 6000, usage: MELEE(),
    declares: {},
    grade: "B", note: "Once per round after a hit you are offered a free teleport of up to 10 feet to a space you can see (the core's teleportation rule applies: a second teleport in a turn fails). Ending adjacent to the target gives +1 circumstance to your next attack against it before the end of your next turn. On a fumble you are teleported 1d6 × 5 feet in a random direction: the GM is shown the roll."
  },
  SANGUINE: {
    on: ["weapon"], traits: "Invested, Soul", level: 9, price: 4300, usage: { melee: true, damage: ["slashing"], text: "any slashing melee weapon" },
    declares: {},
    grade: "A", note: "When it damages a foe: Bleeding 1, or Bleeding 1d4 on a natural 20 (Q202: the bleeding condition, raised by Serrated). Drawback: in an encounter, three consecutive rounds wielding it without striking a foe gives you Bleeding 1d6."
  },
  SPELLHOLD: {
    on: ["weapon"], traits: "Alteration, Invested", tiers: T([5, 900], [9, 4300], [13, 17000], [17, 90000]), usage: { text: "any staff" },
    declares: {}, capacity: [6, 12, 24, 40],
    grade: "C", note: "Holds 6 / 12 / 24 / 40 PP of stored spells, each no more than your cap per cast; the check is rolled when a spell is stored and its PP spent then; release is a Command (1 AP) using that result (Q203); stored spells fade at your next daily preparation. TRG Prime's spell storing holds one spell per item, so the staff's store is the table's to track: the card says the capacity."
  },
  "SUMMONER’S BRAND": {
    on: ["weapon"], traits: "Invested, Translocation", level: 10, price: 6000, usage: MELEE(),
    declares: {
      controlLevelBonus: 2,
      conditionals: [{ kind: "modifier", value: 1, type: "item", label: "against a conjured or summoned creature", scope: "checks against a creature with the Conjured trait or summoned by a Summons spell", when: {} }]
    },
    grade: "A", note: "Whilst wielded: control levels +2; +1 item to checks against a creature with the Conjured trait or summoned by a Summons spell (offered on the check); your caster level is 1 higher for spells with the Summons trait — one more PP on their cap per cast (Q204: one +1, not two)."
  },
  TETHER: {
    on: ["weapon"], traits: "Invested, Save, Warding", level: 12, price: 11000, usage: MELEE(),
    declares: {},
    grade: "A", note: "Once per round after a hit you are offered to tether the target for 1 round: while tethered, a Translocation spell it casts or a teleport it attempts needs a Will save against your Level DC first, or it fails. On a fumble: a DC 15 flat check, or you are Immobilised until the beginning of your next turn."
  },
  VEILSTORM: {
    on: ["weapon"], traits: "Force, Invested, Invocation", level: 8, price: 3000, usage: MELEE(),
    declares: {},
    grade: "A", note: "Once per round after a hit you are offered a veil-tear: 1d6 force damage to every creature adjacent to the target but you, basic Reflex against your Level DC. On a fumble you are Blinded until the end of your next turn."
  },
  WARPFLARE: {
    on: ["weapon"], traits: "Alteration, Invested, Rare", level: 9, price: 4300, usage: { text: "any weapon" },
    declares: {},
    grade: "A", note: "On every hit a d6 is rolled (+1 within 30 feet of a ley line): 1–4 nothing more; 5: 2d6 secondary force damage; 6 or more: a wild surge with you as its source, area level 9 (the rune's level, Q205)."
  }
});

/** Every rune, by book name (upper-case), with its family. */
export const RUNES_9B = freeze({
  ...Object.fromEntries(Object.entries(ARMOUR_RUNES_9B).map(([n, r]) => [n, { ...r, family: "armour" }])),
  ...Object.fromEntries(Object.entries(WEAPON_RUNES_9B).map(([n, r]) => [n, { ...r, family: "weapon" }]))
});

/** The book's capitals → the rune's printed name ("SUMMONER’S BRAND" → "Summoner's Brand"). */
export const runeName = (upper) => String(upper).toLowerCase().replace(/[’]/g, "'").replace(/(^|[\s-])([a-z])/g, (m, a, b) => a + b.toUpperCase());

/** The registration TRG Prime's `registerRunes` takes, for one rune. */
export function runeRegistration(upper, spec = RUNES_9B[upper], { text = "" } = {}) {
  const name = runeName(upper);
  const out = { key: runeKey(name), name, on: [...spec.on], traits: spec.traits, declares: spec.declares ?? {}, note: spec.note, effect: text || spec.note };
  if (spec.tiers) out.tiers = spec.tiers.map((t) => ({ level: t.level, price: t.price }));
  else if (spec.armourPrice !== undefined) { out.level = spec.level; out.armourPrice = spec.armourPrice; out.shieldPrice = spec.shieldPrice; out.price = spec.armourPrice; }
  else { out.level = spec.level; out.price = spec.price; }
  if (spec.usage) out.usage = { ...spec.usage };
  return out;
}

/** A rune's tier list or [] (single-priced). */
export const tiersOf = (upper) => RUNES_9B[upper]?.tiers ?? [];

/** A value by the inscribed tier (1-based), the last for a tier beyond the list. */
export function byTier(list, tier = 1) {
  if (!Array.isArray(list) || !list.length) return 0;
  return list[Math.min(Math.max(1, Math.trunc(Number(tier) || 1)), list.length) - 1];
}

/* ------------------------------------------------------------------ */
/* The rules the workflows ask                                           */
/* ------------------------------------------------------------------ */

/** Aetherfang's dice on a critical: 1d6 per severity step (Minor 1 … Deadly 3). */
export function aetherfangDice(severity) {
  const steps = { minor: 1, serious: 2, deadly: 3 }[String(severity ?? "").toLowerCase()] ?? 0;
  return steps ? `${steps}d6` : "";
}

/** Nullflow's counteract modifier: ±2 per step between the rune's level and the spell's PP (Q195). */
export const nullflowModifier = (runeLevel, spellPP) => 2 * (Math.trunc(Number(runeLevel) || 0) - Math.trunc(Number(spellPP) || 0));

/** Veil's trigger: below 25% of maximum HP, or a critical of serious or worse (Q196). */
export function veilTriggers({ hp = 0, max = 0, severity = "" } = {}) {
  const low = Number(max) > 0 && Number(hp) < 0.25 * Number(max);
  const crit = ["serious", "deadly"].includes(String(severity ?? "").toLowerCase());
  return low || crit;
}

/**
 * Chrono's Exhaustion check for the nth consecutive turn (Q200: Easy first,
 * one step harder each turn): TRG Prime's difficulty ladder (Easy −2, Medium
 * +0, Hard +2, Very Hard +5, Incredibly Hard +10). The core's Exhaustion check
 * is Easy already, so the modifier handed to it is what moves it from Easy.
 */
export const CHRONO_STEPS = freeze([["easy", "Easy", -2], ["medium", "Medium", 0], ["hard", "Hard", 2], ["veryHard", "Very Hard", 5], ["incrediblyHard", "Incredibly Hard", 10]]);
export function chronoStep(turn) {
  const [key, label, dc] = CHRONO_STEPS[Math.min(Math.max(1, Math.trunc(Number(turn) || 1)), CHRONO_STEPS.length) - 1];
  return { key, label, modifier: (-(dc + 2)) || 0 };
}

/** The core's Casting DC for a spell of this many PP (magic/casting.mjs `castingDC`). */
export const castingDCOf = (pp) => 10 + Math.floor(Math.max(0, Number(pp) || 0) * 1.5);

/** Warpflare's d6 (+1 near a ley line): "", "force", or "surge". */
export function warpflareResult(roll, nearLine = false) {
  const r = Math.trunc(Number(roll) || 0) + (nearLine ? 1 : 0);
  return r >= 6 ? "surge" : r === 5 ? "force" : "";
}
export const WARPFLARE_SURGE_LEVEL = 9;

/** Sanguine's bleed: 1, or 1d4 on a natural 20 (Q202). */
export const sanguineBleed = (natural) => (Math.trunc(Number(natural) || 0) === 20 ? "1d4" : "1");

/** Renewal's daily HP: the item's level × the tier. */
export const renewalHP = (itemLevel, tier) => Math.max(0, Math.trunc(Number(itemLevel) || 0)) * byTier([1, 2, 3], tier);

/** TRG Prime's damage types: what Essencebreaker may take a resistance to. */
export const DAMAGE_TYPES = freeze(["acid", "aligned", "bludgeoning", "cold", "electricity", "essence", "fire", "force", "mental", "piercing", "poison", "slashing", "sonic"]);

/** Spellguard prints Resonant Defiance at +1 (M79, Graham: leave as printed). */
export const SPELLGUARD_DC_STEP = 1;

/* ------------------------------------------------------------------ */
/* Specific armour, shields and weapons (L9155–9255, L9957–10049)         */
/* ------------------------------------------------------------------ */

/**
 * Each as printed (Q206: statistics as printed; a rune line reads as the rune).
 * `runes` is the item's runes field, in TRG Prime's names; `base` the core
 * item it is made from (its coverage, category and the rest).
 */
export const SPECIFIC_9B = freeze({
  "GRAVEMELD SHIRT": {
    type: "armour", base: "Chain Shirt", level: 12, price: 21150, weight: 31, material: "graveiron", quality: "master",
    stats: { penalty: -1, maxDexBonus: 6, dr: 4, cr: 1, db: 2, hp: 63 }, runes: "Potency II, Swiftbind",
    printedTraits: ["Metal", "Grave Iron", "Lightweight", "Reinforced", "Master", "Potency II", "Quickbind"],
    grade: "A", note: "Graveiron armour's +1 item to Fortitude saves against disease, paralysis and soul drain (Eldritch Arts' material); the Reinforced trait's +1 DR against slashing (TRG Prime's trait); Swiftbind (the book's Quickbind): a 2 AP Interact to don."
  },
  "HEARTSTRAND HARNESS": {
    type: "armour", base: "Reinforced Leather Breastplate", level: 5, price: 1260, weight: 15, material: "", quality: "expert",
    stats: { penalty: -1, maxDexBonus: 6, dr: 1, db: 1, hp: 38 }, runes: "Potency I, Ley Binding I",
    printedTraits: ["Rigid", "Expert", "Potency I", "Ley Binding I"],
    grade: "B", note: "Ley Binding I: +1 circumstance DB against a spell attack (the save-spell half is not applied; see the rune)."
  },
  SHADESKIN: {
    type: "armour", base: "Full Leather", level: 12, price: 18230, weight: 9, material: "eversmokeCloth", quality: "master",
    stats: { penalty: 0, maxDexBonus: 9, dr: 1, db: 2, hp: 46 }, runes: "Potency II, Shadow II, Veil II", perception: -1,
    printedTraits: ["Eversmoke Cloth", "Master", "Full", "Lightweight", "Potency II", "Shadow II (+2 Stealth)", "Veil II"],
    grade: "B", note: "Shadow II (TRG Prime's rune), Veil II's reaction (twice a day), Eversmoke Cloth (Eldritch Arts' material) and the printed −1 to Perception (an item penalty while worn)."
  },
  SPELLGUARD: {
    type: "shield", base: "Light Steel Shield", level: 8, price: 3320, weight: 6, material: "metal", quality: "expert",
    stats: { penalty: -1, dr: 1, db: 2, hp: 44 }, runes: "Potency I, Resonant Defiance I",
    printedTraits: ["Metal", "Expert", "Potency I", "Resonant Defiance I", "Spell (Resist Energy – Fire 1/day)"],
    grade: "B", note: "Resonant Defiance I's reaction raises the caster's Casting DC by 1, as this shield prints (M79: leave as printed; an inscribed Resonant Defiance I gives +2). Its Resist Energy (Fire), Command 1 AP, 1/day, is a card: TRG Prime reads its Spell Effect rune on armour and weapons, not on a shield, so cast it from the item's text and mark the day's use by hand."
  },
  "WHISPERING HOLLOW": {
    type: "armour", base: "Scalemail", level: 13, price: 26200, weight: 19, material: "ashbone", quality: "master",
    stats: { penalty: -2, maxDexBonus: 7, dr: 4, db: 3, hp: 135 }, runes: "Potency III, Comfort, Soul Warding",
    printedTraits: ["Ashbone", "Full", "Metal", "Rigid", "Lightweight", "Master", "Potency III", "Comfort", "Soul Warding"],
    grade: "A", note: "Comfort (Sleeping in Armour with advantage; Max Dex +1 on top of the printed 7, Q206), Soul Warding (essence resistance), Ashbone (Eldritch Arts' material)."
  },
  "BLEEDING CROWN": {
    type: "weapon", base: "Battle Axe", level: 9, price: 5920, weight: 6, material: "", quality: "expert",
    stats: { attackBonus: 2, damage: "1d8", damageBonus: 1, damageType: "slashing", size: "M", fumbleDC: 18 }, runes: "Potency II, Sanguine",
    printedTraits: ["AR 2", "Hand & a Half", "Sweep", "Expert", "Potency II", "Sanguine"],
    grade: "A", note: "Sanguine: Bleeding 1 when it damages a foe, 1d4 on a natural 20; its drawback is the rune's v1.6 one (three consecutive rounds in an encounter without striking a foe: Bleeding 1d6), not the old line it prints (Q206)."
  },
  SOULREND: {
    type: "weapon", base: "Bardiche", level: 14, price: 26013, weight: 14, material: "", quality: "master",
    stats: { attackBonus: 3, damage: "1d12", damageBonus: 2, damageType: "slashing", size: "L", fumbleDC: 20 }, runes: "Potency III, Aetherfang, Essencebreaker",
    printedTraits: ["Reach", "Versatile P", "Master", "Potency III", "Aetherfang", "Essencebreaker"], dropTraits: ["Clumsy"],
    grade: "B", note: "Aetherfang and Essencebreaker (its Will save against your Level DC, as the rune now prints — Q206). No Clumsy (m200: removed on purpose)."
  },
  "RITUALISTS EDGE": {
    name: "Ritualist's Edge", type: "weapon", base: "Dagger", level: 10, price: 7602, weight: 1, material: "coldIron", quality: "expert",
    stats: { attackBonus: 2, damage: "1d4", damageBonus: 1, damageType: "piercing", size: "T", fumbleDC: 5 }, runes: "Potency II, Summoner's Brand",
    printedTraits: ["Agile", "Finesse", "Thrown 10 ft", "Versatile S", "Expert", "Potency II", "Summoner's Brand"],
    grade: "A", note: "Summoner's Brand, read as the rune (M95; Q204): control levels +2 while wielded, +1 item against conjured or summoned creatures, caster level +1 for Summons spells. Level 10 (m201: its 7,602 gp is a level-10 price; the book prints 11)."
  },
  STARFALL: {
    type: "weapon", base: "Tel'dorin", level: 14, price: 31200, weight: 7, material: "", quality: "master",
    stats: { attackBonus: 3, damage: "1d10", damageBonus: 2, damageType: "slashing", size: "L", fumbleDC: 8 }, runes: "Potency III, Chrono",
    printedTraits: ["AR 3", "Deadly", "Elf", "Exotic", "Finesse", "Master", "Potency III", "Chrono"],
    grade: "B", note: "Chrono's activation (Quickened for a Strike; the Exhaustion check each turn). AR 3 as printed."
  }
});
