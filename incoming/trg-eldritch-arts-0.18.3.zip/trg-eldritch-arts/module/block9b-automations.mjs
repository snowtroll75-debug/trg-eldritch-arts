/**
 * Block 9b (0.14.0, on TRG Prime 3.689.0): what Chapter 9's runes do in play,
 * beyond what they declare to the core (block9b-rules.mjs: H21's keys, the
 * core's `conditionals`, `defenceDC`, `energy` and `action`).
 *
 *   ARMOUR AND SHIELDS
 *     Catalyst      embedding (a header button on the shield's sheet); the
 *                   embedded catalysts offered at the cast (9a's catalyst
 *                   option reads `embeddedCatalystOffers`); their day's use
 *     Luminous      a light on the token while the item is equipped
 *     Nullflow      a cast reaction: Dispel against the Casting DC
 *     Renewal       daily preparation: the item's HP
 *     Resonant Def. a spell-check gate on an enemy's cast within 30 feet
 *     Veil          a reaction after the damage: incorporeal
 *     Wildbane      the DC 15 flat check when a wild surge occurs within 30 ft
 *   WEAPONS (trgPrimeStrikeResolved and trgPrimeWeaponFumble, H22)
 *     Aetherfang, Echoing, Essencebreaker, Gravitas, Mindpiercer, Nullflare,
 *     Pyrebrand's natural 20, Riftcleaver, Sanguine, Tether, Veilstorm,
 *     Warpflare; Leybound's +1 and its die; Chrono's turn-end check;
 *     Summoner's Brand's caster level for Summons spells
 *
 * Writes to a creature this client does not own go to the acting GM over the
 * module's socket, as an allow-listed operation (SOCKET_ACTION below).
 */

import { MODULE_ID, SYSTEM_ID, effectData, forSeconds, ownEffects } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, now, levelOf, tokenOf, tokenCentre, inCombat, feetBetween } from "./block1-automations.mjs";
import { allies, SOCKET } from "./block3b-automations.mjs";
import { isActingGM } from "./writer.mjs";
import * as R from "./block9b-rules.mjs";

const items = (actor) => Array.from(actor?.items ?? []);
const effects = (actor) => Array.from(actor?.effects ?? []);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (token) => token?.document?.disposition;
const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];
const within = (a, b, feet) => { const d = feetBetween(a, b); return d !== null && d <= feet; };
const levelDCOf = (actor) => int(h().levelDC?.(levelOf(actor)) ?? (14 + levelOf(actor)));
const key = (upper) => R.runeKey(R.runeName(upper));

/* ------------------------------------------------------------------ */
/* Reading the runes                                                    */
/* ------------------------------------------------------------------ */

/** "Aegisflow II" etc. on an item's runes field → [{ key, tier }]. Pure; mirrors the core's parse for this module's names. */
export function runesOnField(field = "") {
  const out = [];
  const roman = { I: 1, II: 2, III: 3, IV: 4, V: 5 };
  for (const part of String(field).split(/,\s*(?![^()]*\))/)) {
    const m = /^\s*(.*?)(?:\s+(I{1,3}|IV|V))?\s*(?:\(.*\))?\s*$/.exec(part);
    if (!m?.[1]) continue;
    const upper = Object.keys(R.RUNES_9B).find((n) => norm(R.runeName(n)) === norm(m[1]) || (R.RUNES_9B[n].aliases ?? []).some((a) => norm(a) === norm(m[1])));
    if (upper) out.push({ upper, key: key(upper), tier: roman[m[2]] ?? 1 });
  }
  return out;
}

/** This module's rune on one item, or null: { upper, key, tier }. */
export function runeOn(item, upper) {
  const field = String(item?.system?.effectiveRunes ?? item?.system?.runes ?? "");
  return runesOnField(field).find((r) => r.upper === upper) ?? null;
}

/** Equipped items carrying a rune, with its tier: [{ item, tier }]. */
export function equippedWith(actor, upper) {
  return items(actor).filter((i) => i.system?.equipped).map((item) => ({ item, rune: runeOn(item, upper) })).filter((x) => x.rune).map((x) => ({ item: x.item, tier: x.rune.tier }));
}

/** A day's uses of a rune on an item: { used, max }. Reset at daily preparation. */
const USED_FLAG = "runeUses9b";
function usesOf(item, upper) {
  const rune = runeOn(item, upper);
  const max = R.byTier(R.RUNES_9B[upper]?.perDay ?? [], rune?.tier ?? 1);
  return { used: int(item?.flags?.[MODULE_ID]?.[USED_FLAG]?.[key(upper)]), max };
}
async function spendUse(item, upper) {
  const now0 = item?.flags?.[MODULE_ID]?.[USED_FLAG] ?? {};
  await item.setFlag(MODULE_ID, USED_FLAG, { ...now0, [key(upper)]: int(now0[key(upper)]) + 1 });
}

/* ------------------------------------------------------------------ */
/* The socket: writes on a creature this client does not own             */
/* ------------------------------------------------------------------ */

export const SOCKET_ACTION = "block9b";
const OWN_SOURCES = Object.freeze(["essencebreaker9b", "tether9b", "riftcleaver9b"]);

/** Is this write one the acting GM may make for another client? Pure. */
export function writeAllowed(op = {}) {
  if (op.kind === "createEffect") return OWN_SOURCES.includes(op.data?.flags?.[MODULE_ID]?.source);
  if (op.kind === "suppressEffect") return Number.isFinite(Number(op.until)) && typeof op.effectId === "string";
  if (op.kind === "deleteEffect") return typeof op.effectId === "string" && op.nullflare === true;
  if (op.kind === "recurring") return int(op.amount) > 0 && typeof op.type === "string";
  return false;
}

async function applyWrite(actor, op) {
  if (!actor || !writeAllowed(op)) return false;
  if (op.kind === "createEffect") { await actor.createEmbeddedDocuments("ActiveEffect", [op.data]); return true; }
  if (op.kind === "suppressEffect") { const fx = actor.effects?.get?.(op.effectId); if (fx) await fx.setFlag(MODULE_ID, NULLFLARE_FLAG, { until: Number(op.until), by: String(op.by ?? "") }); return Boolean(fx); }
  if (op.kind === "deleteEffect") { const fx = actor.effects?.get?.(op.effectId); if (fx && fx.flags?.[SYSTEM_ID]?.spellEffect) await fx.delete(); return Boolean(fx); }
  if (op.kind === "recurring") { await h().addRecurringDamage(actor, int(op.amount), op.type); return true; }
  return false;
}

async function writeOn(actor, op) {
  if (!actor) return false;
  if (actor.isOwner) return applyWrite(actor, op);
  const game = globalThis.game;
  if (!game?.users?.activeGM) { warn(`No GM is connected to update ${actor.name} (Eldritch Arts): apply it by hand.`); return false; }
  game.socket?.emit?.(SOCKET, { action: SOCKET_ACTION, actorUuid: actor.uuid, op });
  return true;
}

/** The acting GM's side of the socket. */
export async function onBlock9bSocket(data = {}) {
  if (data?.action !== SOCKET_ACTION || !isActingGM()) return false;
  const actor = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(data.actorUuid);
  return applyWrite(actor, data.op ?? {});
}

/* ------------------------------------------------------------------ */
/* Catalyst rune                                                        */
/* ------------------------------------------------------------------ */

export const EMBED_FLAG = "embedded9b";
export const EMBED_USED_FLAG = "embeddedUsed9b";

/** The slots a shield's Catalyst rune holds (1–4), or 0. */
export const catalystSlots = (shield) => {
  const r = runeOn(shield, "CATALYST");
  return r && shield?.type === "shield" ? R.byTier(R.RUNES_9B.CATALYST.slots, r.tier) : 0;
};

/** Offers for 9a's catalyst option: each embedded catalyst on a wielded shield, unused today. */
export function embeddedCatalystOffers(actor, applies) {
  const out = [];
  for (const shield of items(actor).filter((i) => i.type === "shield" && i.system?.equipped && catalystSlots(i))) {
    const embedded = Array.from(shield.flags?.[MODULE_ID]?.[EMBED_FLAG] ?? []);
    const used = Array.from(shield.flags?.[MODULE_ID]?.[EMBED_USED_FLAG] ?? []).map(String);
    embedded.slice(0, catalystSlots(shield)).forEach((c, i) => {
      if (!c?.key || used.includes(String(i))) return;
      let ok = false;
      try { ok = applies(c.key); } catch { ok = false; }
      if (ok) out.push({ itemId: shield.id, slot: String(i), consume: false, label: `${c.name} (embedded in ${shield.name})`, hint: "Once a day; not consumed. Its backlash applies." });
    });
  }
  return out;
}

/** The catalyst key behind an embedded offer, or null. */
export function embeddedKey(shield, slot) {
  const c = Array.from(shield?.flags?.[MODULE_ID]?.[EMBED_FLAG] ?? [])[int(slot)];
  return c?.key ?? null;
}

/** Spend an embedded catalyst's day. */
export async function markEmbeddedUsed(shield, slot) {
  const used = Array.from(shield?.flags?.[MODULE_ID]?.[EMBED_USED_FLAG] ?? []).map(String);
  if (!used.includes(String(slot))) await shield.setFlag(MODULE_ID, EMBED_USED_FLAG, [...used, String(slot)]);
}

/** Embed a catalyst into a shield (Q192): 10 minutes; one already in that slot is destroyed. */
export async function embedCatalyst(shield) {
  const actor = shield?.parent;
  const slots = catalystSlots(shield);
  if (!actor || !slots) return warn(`${shield?.name ?? "That item"} carries no Catalyst rune.`);
  const { CATALYST_FLAG } = await import("./block9a-rules.mjs");
  const catalysts = items(actor).filter((i) => i.flags?.[MODULE_ID]?.[CATALYST_FLAG] && int(i.system?.quantity ?? 1) > 0);
  if (!catalysts.length) return warn(`${actor.name} carries no catalyst to embed.`);
  const embedded = Array.from(shield.flags?.[MODULE_ID]?.[EMBED_FLAG] ?? []);
  const pick = await h().chooseFromList(`Embed a Catalyst — ${shield.name}`, "Which catalyst?", catalysts.map((c) => [c.id, c.name]));
  const item = catalysts.find((c) => c.id === pick);
  if (!item) return false;
  const slotChoices = Array.from({ length: slots }, (_, i) => [String(i), embedded[i]?.name ? `Slot ${i + 1}: replace ${embedded[i].name} (it is destroyed)` : `Slot ${i + 1}: empty`]);
  const slot = slots === 1 ? "0" : await h().chooseFromList(`Embed a Catalyst — ${shield.name}`, "Which slot?", slotChoices);
  if (slot === null || slot === undefined) return false;
  const lost = embedded[int(slot)]?.name ?? "";
  const next = [...embedded];
  next[int(slot)] = { key: item.flags[MODULE_ID][CATALYST_FLAG], name: item.name, img: item.img };
  await shield.setFlag(MODULE_ID, EMBED_FLAG, next);
  const q = int(item.system?.quantity ?? 1);
  if (q <= 1) await item.delete(); else await item.update({ "system.quantity": q - 1 });
  return card(actor, `${shield.name} — Embed a Catalyst`, [
    line(`${esc(item.name)} is embedded in slot ${int(slot) + 1} of ${slots} (10 minutes).${lost ? ` ${esc(lost)} was in that slot and is destroyed.` : ""}`),
    line("While the shield is wielded it is offered once a day when you cast, and is not consumed; its backlash applies.")
  ]);
}

/** getHeaderControlsApplicationV2: the shield's sheet offers Embed a Catalyst. */
export function onHeaderControlsB9b(app, controls) {
  const item = app?.document ?? app?.item;
  if (item?.documentName !== "Item" || !catalystSlots(item) || !item.isOwner || !item.parent) return;
  if (!Array.isArray(controls) || controls.some((c) => c?.action === "eaEmbedCatalyst")) return;
  controls.push({ action: "eaEmbedCatalyst", icon: "fa-solid fa-flask", label: "Embed a Catalyst", onClick: () => embedCatalyst(item) });
}

/* ------------------------------------------------------------------ */
/* Luminous                                                             */
/* ------------------------------------------------------------------ */

export const LUMINOUS_LIGHTS = Object.freeze([1, 2, 3].map((steps) => ({
  key: `eaLuminous${steps}`, label: `Luminous ${["I", "II", "III"][steps - 1]}`, item: "Luminous rune", steps, cap: null, magical: true, radiusFeet: 20, dimFeet: 20, brightFeet: steps >= 2 ? 10 : 0
})));

/** The strongest Luminous light an actor's equipped items shed, or null. */
export function luminousLightOf(actor) {
  const best = equippedWith(actor, "LUMINOUS").reduce((m, x) => Math.max(m, R.byTier(R.RUNES_9B.LUMINOUS.lightSteps, x.tier)), 0);
  return best ? LUMINOUS_LIGHTS[best - 1] : null;
}

/** Keep the token's Luminous light in step with what is equipped (one effect, the source's light key). */
const syncing = new Set();
export async function syncLuminous(actor) {
  if (!actor?.isOwner) return;
  const { actsFor } = await import("./block3-automations.mjs");
  if (!actsFor(actor)) return;
  const id = actor.uuid ?? actor.id;
  if (syncing.has(id)) return;
  syncing.add(id);
  try { await syncLuminousNow(actor); } finally { syncing.delete(id); }
}
async function syncLuminousNow(actor) {
  const want = luminousLightOf(actor);
  const have = ownEffects(actor, "luminous9b");
  const haveKey = have[0]?.flags?.[SYSTEM_ID]?.lightSource ?? "";
  if (want && haveKey === want.key && have.length === 1) return;
  if (have.length) await actor.deleteEmbeddedDocuments("ActiveEffect", have.map((e) => e.id));
  if (want) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("luminous9b", { name: want.label, img: "icons/svg/sun.svg", system: { lightSource: want.key } })]);
  }
  await h().refreshTokenLight?.(actor);
}

/* ------------------------------------------------------------------ */
/* Renewal, and the day's uses                                          */
/* ------------------------------------------------------------------ */

/** trgPrimeDailyPreparation: Renewal's HP, and the runes' daily uses back. */
export async function onDailyPreparationB9b({ actor } = {}) {
  if (!actor?.isOwner) return;
  const lines = [];
  for (const item of items(actor).filter((i) => ["armour", "shield"].includes(i.type))) {
    const renewal = runeOn(item, "RENEWAL");
    if (renewal) {
      const hp = item.system?.hp ?? {};
      if (int(hp.max) > 0 && int(hp.value) <= 0 && int(hp.max) > 0 && item.flags?.[MODULE_ID]?.destroyed9b) {
        // "If the armour or shield is destroyed outright, the rune unravels and is lost."
        const field = String(item.system?.runes ?? "").split(/,\s*(?![^()]*\))/).filter((p) => !/^\s*Renewal\b/i.test(p)).join(", ");
        await item.update({ "system.runes": field });
        lines.push(`${esc(item.name)} was destroyed outright: its Renewal rune unravels and is lost.`);
      } else if (int(hp.max) > 0 && int(hp.value) < int(hp.max)) {
        const gain = Math.min(R.renewalHP(item.system?.itemLevel, renewal.tier), int(hp.max) - int(hp.value));
        if (gain > 0) { await item.update({ "system.hp.value": int(hp.value) + gain }); lines.push(`${esc(item.name)} mends ${gain} HP (Renewal ${["I", "II", "III"][renewal.tier - 1]}).`); }
      }
    }
    if (item.flags?.[MODULE_ID]?.[EMBED_USED_FLAG]?.length) await item.unsetFlag(MODULE_ID, EMBED_USED_FLAG);
  }
  for (const item of items(actor)) if (item.flags?.[MODULE_ID]?.[USED_FLAG]) await item.unsetFlag(MODULE_ID, USED_FLAG);
  if (lines.length) await card(actor, "Renewal", lines.map((t) => line(t)));
}

/**
 * updateItem: an item with Renewal brought to 0 HP is marked destroyed; if it
 * is still at 0 at the next daily preparation, the rune unravels ("If the
 * armour or shield is destroyed outright, the rune unravels and is lost"). An
 * item mended before then keeps it.
 */
export async function onItemDamagedB9b(item, change = {}) {
  const hp = change?.system?.hp?.value;
  if (hp === undefined || !runeOn(item, "RENEWAL") || !item.isOwner) return;
  const { actsFor } = await import("./block3-automations.mjs");
  if (item.parent && !actsFor(item.parent)) return;
  if (int(hp) <= 0 && !item.flags?.[MODULE_ID]?.destroyed9b) await item.setFlag(MODULE_ID, "destroyed9b", true);
  else if (int(hp) > 0 && item.flags?.[MODULE_ID]?.destroyed9b) await item.unsetFlag(MODULE_ID, "destroyed9b");
}

/* ------------------------------------------------------------------ */
/* Nullflow (cast reaction) and Resonant Defiance (spell-check gate)      */
/* ------------------------------------------------------------------ */

export const NULLFLOW_STEP = "eldritchArts.nullflow";
export const DEFIANCE_STEP = "eldritchArts.resonantDefiance";

/** registerCastReaction: each wearer of Nullflow the spell would reach is asked. */
export async function nullflowReaction(ctx = {}) {
  const caster = ctx.actor, casterToken = ctx.token ?? tokenOf(caster);
  if (!caster) return null;
  const targeted = new Set(Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor?.uuid));
  const area = String(ctx.spellData?.area ?? "").trim();
  const pp = int(ctx.castPP ?? ctx.pp);
  const dc = R.castingDCOf(pp);
  const excluded = [];
  const said = [];
  for (const t of tokens()) {
    const wearer = t.actor;
    if (wearer === caster) continue;
    const worn = equippedWith(wearer, "NULLFLOW").find((x) => usesOf(x.item, "NULLFLOW").used < usesOf(x.item, "NULLFLOW").max);
    if (!worn) continue;
    if (!targeted.has(wearer.uuid) && (!area || (casterToken && allies(side(t), side(casterToken))))) continue;
    if (await h().reactionRefusal?.(wearer, "Warding")) continue;
    const runeLevel = R.RUNES_9B.NULLFLOW.tiers[worn.tier - 1].level;
    const q = await h().askReactor(wearer, {
      title: `Nullflow — ${wearer.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${pp} PP)${targeted.has(wearer.uuid) ? " at you" : `, an area spell (${esc(area)}): answer only if you are in its area`}.</p><p>Use your reaction and a use of ${esc(worn.item.name)}'s Nullflow (${usesOf(worn.item, "NULLFLOW").max - usesOf(worn.item, "NULLFLOW").used} left today)? Dispel (Power Manipulation) against its Casting DC ${dc}, ${R.nullflowModifier(runeLevel, pp) >= 0 ? "+" : ""}${R.nullflowModifier(runeLevel, pp)} (the rune's level ${runeLevel} against ${pp} PP).</p>`,
      buttons: yesNo("Counteract it"), step: NULLFLOW_STEP, data: { dc, modifier: R.nullflowModifier(runeLevel, pp), itemId: worn.item.id, spell: ctx.spell?.name ?? "" }
    });
    if (!q?.result?.rolled) continue;
    if (q.result.succeeded) {
      excluded.push(wearer.uuid);
      said.push(`${esc(wearer.name)}'s <strong>Nullflow</strong> (${esc(q.result.degree)}, ${int(q.result.total)} against ${dc}) suppresses ${esc(ctx.spell?.name ?? "the spell")} against them for 1 minute: it does not land on them. If it would still be running after that minute, the GM applies what remains.`);
    } else said.push(`${esc(wearer.name)}'s <strong>Nullflow</strong> fails (${esc(q.result.degree)}, ${int(q.result.total)} against ${dc}).`);
  }
  if (!said.length) return null;
  return excluded.length ? { exclude: excluded, line: said.join("<br>") } : { line: said.join("<br>") };
}

/** On the wearer's client: the reaction, the use, and the Dispel check. */
async function nullflowStep(actor, answer, data) {
  if (answer !== "yes") return { rolled: false };
  const item = actor.items?.get?.(data?.itemId);
  if (!item || !(await h().spendReaction?.(actor, "Nullflow", { traits: "Warding" }))) return { rolled: false };
  await spendUse(item, "NULLFLOW");
  const skill = actor.system?.skills?.powerManipulation ?? {};
  const modifiers = [...(Array.isArray(skill.checkModifiers) && skill.checkModifiers.length ? skill.checkModifiers : [{ label: "Power Manipulation", value: Number(skill.total ?? 0) || 0, type: "untyped" }]),
    ...(int(data?.modifier) ? [{ label: "Nullflow (rune level against PP)", value: int(data.modifier), type: "untyped" }] : [])];
  const check = await h().rollCheck({ actor, type: "skill", subject: "powerManipulation", label: `${actor.name} — Nullflow (Dispel)`, dc: int(data?.dc), modifiers });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  return { rolled: true, degree, total: int(check?.outcome?.total), succeeded: ["heroic", "critical", "success"].includes(degree) };
}

/** registerSpellCheckGate: an enemy bearer of Resonant Defiance within 30 feet may raise the Casting DC. */
export async function resonantDefianceGate(ctx = {}) {
  const caster = ctx.actor, casterToken = tokenOf(caster);
  if (!caster || !casterToken || ctx.rollsCheck === false) return null;
  const modifiers = [];
  const lines = [];
  for (const t of tokens()) {
    const bearer = t.actor;
    if (bearer === caster || allies(side(t), side(casterToken)) || !within(t, casterToken, 30)) continue;
    const shield = items(bearer).find((i) => i.type === "shield" && i.system?.equipped && runeOn(i, "RESONANT DEFIANCE"));
    if (!shield) continue;
    if (await h().reactionRefusal?.(bearer, "Insight")) continue;
    const step = shield.flags?.[MODULE_ID]?.specific9b === "SPELLGUARD" ? R.SPELLGUARD_DC_STEP : R.byTier(R.RUNES_9B["RESONANT DEFIANCE"].dcStep, runeOn(shield, "RESONANT DEFIANCE").tier);
    const q = await h().askReactor(bearer, {
      title: `Resonant Defiance — ${bearer.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> is casting <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> within 30 feet of you.</p><p>Use your reaction: ${esc(shield.name)} raises its Casting DC by ${step}?</p>`,
      buttons: yesNo("Defy it"), step: DEFIANCE_STEP, data: {}
    });
    if (!q?.result?.spent) continue;
    modifiers.push({ label: `${bearer.name}'s ${shield.name} (Resonant Defiance: Casting DC +${step})`, value: -step, type: "untyped", castingOnly: true });
    lines.push(`${esc(bearer.name)}'s <strong>Resonant Defiance</strong> raises the Casting DC by ${step}.`);
  }
  return modifiers.length ? { modifiers, lines } : null;
}
async function defianceStep(actor, answer) {
  if (answer !== "yes") return { spent: false };
  return { spent: Boolean(await h().spendReaction?.(actor, "Resonant Defiance", { traits: "Insight" })) };
}

/* ------------------------------------------------------------------ */
/* Veil                                                                  */
/* ------------------------------------------------------------------ */

export const VEIL_STEP = "eldritchArts.veil";
const veilAsked = new Map();

/** Ask a Veil wearer, once per blow (two hooks may both see it). */
async function offerVeil(wearer, why) {
  if (!wearer || ownEffects(wearer, "veil9b").length) return;
  const at = veilAsked.get(wearer.uuid) ?? 0;
  if (Date.now() - at < 3000) return;
  const worn = equippedWith(wearer, "VEIL").find((x) => usesOf(x.item, "VEIL").used < usesOf(x.item, "VEIL").max);
  if (!worn) return;
  veilAsked.set(wearer.uuid, Date.now());
  if (await h().reactionRefusal?.(wearer, "Alteration")) return;
  const left = usesOf(worn.item, "VEIL").max - usesOf(worn.item, "VEIL").used;
  await h().askReactor(wearer, {
    title: `Veil — ${wearer.name}`,
    content: `<p>${esc(why)}</p><p>Use your reaction and ${esc(worn.item.name)}'s Veil (${left} left today)? You become incorporeal until the end of your next turn, with your equipment, and may take only Move and Defence actions.</p>`,
    buttons: yesNo("Step into the Veil"), step: VEIL_STEP, data: { itemId: worn.item.id }
  });
}
async function veilStep(actor, answer, data) {
  if (answer !== "yes") return { veiled: false };
  const item = actor.items?.get?.(data?.itemId);
  if (!item || !(await h().spendReaction?.(actor, "Veil", { traits: "Alteration" }))) return { veiled: false };
  await spendUse(item, "VEIL");
  const { expiryFor } = await import("./effects-clock.mjs");
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("veil9b", {
    name: `Veil (${item.name})`, img: "icons/svg/mystery-man.svg",
    description: "Incorporeal until the end of your next turn (or until you end it, free): only Move and Defence actions.",
    system: { grantedTraits: ["Incorporeal"] }, expiry: expiryFor("endOfNextTurn", actor)
  })]);
  await card(actor, `${item.name} — Veil`, [line(`${esc(actor.name)} slips into the half-light of the Shadescape: <strong>incorporeal</strong> until the end of their next turn (delete the effect to end it early). Only Move and Defence actions.`)]);
  return { veiled: true };
}

/** trgPrimeDamageApplied: below 25% of maximum HP. */
export async function onDamageAppliedB9b({ actor, amount } = {}) {
  if (!actor || !(int(amount) > 0) || !equippedWith(actor, "VEIL").length) return;
  if (!(globalThis.game?.user?.isGM ? true : actor.isOwner)) return;
  const hp = actor.system?.resources?.hp ?? {};
  if (R.veilTriggers({ hp: Number(hp.value), max: Number(hp.max) })) await offerVeil(actor, `${actor.name} is below 25% of their hit points.`);
}

/* ------------------------------------------------------------------ */
/* Leybound, Warpflare: the ley line                                    */
/* ------------------------------------------------------------------ */

const leyCache = new Map();
/** The nearest ley line within 30 feet of this token, cached briefly for the core's synchronous `when`. */
async function leyLineNear(token) {
  if (!token) return null;
  const { leyLinesWithin } = await import("./areas.mjs");
  const found = (await leyLinesWithin(token, 30))[0] ?? null;
  leyCache.set(token.actor?.uuid ?? token.id, { at: Date.now(), line: found });
  return found;
}
export const leyboundWhen = (ctx = {}) => {
  const c = leyCache.get(ctx.actor?.uuid ?? "");
  // THIS ATTACK'S READING (review): the check reaction reads it just before
  // the damage; an older one (a carried reroll, a preset die) does not count.
  return Boolean(c && Date.now() - c.at < 10000 && c.line);
};

/** registerCheckReaction before: a Strike with a Leybound weapon near a ley line, +1 circumstance. */
export async function leyboundBefore(ctx = {}) {
  if (ctx.type !== "attack" || !ctx.weaponUuid) return null;
  const weapon = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(ctx.weaponUuid);
  if (!weapon || !runeOn(weapon, "LEYBOUND")) return null;
  const near = await leyLineNear(tokenOf(ctx.actor));
  if (!near) return null;
  return { modifiers: [{ label: `Leybound (${near.name || "ley line"}, ${near.feet} ft)`, value: 1, type: "circumstance" }], line: `Leybound: within 30 feet of ${esc(near.name || "a ley line")} — +1 circumstance, and one more die of base damage.` };
}

/** Roll a wild surge from the module's table at a level, centred on a creature. */
async function wildSurgeAt(actor, level, title) {
  // THE TABLE FROM ITS OWN FILE (0.15.1, found in Block 9c's live test):
  // block2-automations does not export WILD_SURGE, so it read as undefined.
  const { rollTable } = await import("./block2-automations.mjs");
  const { WILD_SURGE } = await import("./chapter7-tables.mjs");
  return rollTable(actor, { table: WILD_SURGE, column: "e", title, level, expiry: forSeconds(6 * Math.max(1, int(level))), source: "wildSurge", radiusFeet: 5 * Math.max(1, int(level)) });
}

/* ------------------------------------------------------------------ */
/* Wildbane                                                             */
/* ------------------------------------------------------------------ */

/** A wild surge is occurring with `actor` as its source: each Wildbane bearer within 30 ft rolls DC 15 flat. Lines for the surge's card. */
export async function wildbaneLines(actor) {
  const source = tokenOf(actor);
  if (!source) return [];
  const out = [];
  for (const t of tokens()) {
    const bearer = t.actor;
    if (!within(t, source, 30) || !equippedWith(bearer, "WILDBANE").length) continue;
    const roll = await new Roll("1d20").evaluate();
    if (roll.total >= 15) {
      const near = tokens().filter((o) => o !== t && allies(side(o), side(t)) && within(o, t, 5)).map((o) => o.name);
      out.push(line(`${esc(bearer.name)}'s <strong>Wildbane</strong>: DC 15 flat check — <strong>${roll.total}</strong>: the surge is suppressed for ${esc(bearer.name)}${near.length ? ` and their adjacent allies (${near.map(esc).join(", ")})` : ""}. Leave them out of its effect.`));
    } else out.push(line(`${esc(bearer.name)}'s <strong>Wildbane</strong>: DC 15 flat check — ${roll.total}: no help this time (its +2 circumstance to saves and DB against the surge still stands).`));
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Summoner's Brand: caster level +1 for Summons spells                 */
/* ------------------------------------------------------------------ */

/** registerCastCapModifier: one more PP on the cap per cast for a Summons spell, whilst the weapon is wielded (Q204). */
export function summonersBrandCap(ctx = {}) {
  const traits = String(ctx.spellData?.traits ?? ctx.spell?.system?.traits ?? "").toLowerCase();
  if (!/\bsummons\b/.test(traits)) return 0;
  return equippedWith(ctx.actor, "SUMMONER’S BRAND").length ? { value: 1, label: "Summoner's Brand (caster level +1 for a Summons spell)" } : 0;
}

/* ------------------------------------------------------------------ */
/* Nullflare's suppression and Tether's gate                              */
/* ------------------------------------------------------------------ */

export const NULLFLARE_FLAG = "nullflared9b";
/** registerEffectSuppressor: a spell effect Nullflare suppressed, until its world time. */
export function nullflareSuppresses(effect) {
  const rec = effect?.flags?.[MODULE_ID]?.[NULLFLARE_FLAG];
  return Boolean(rec && Number(globalThis.game?.time?.worldTime ?? 0) < Number(rec.until));
}

/** registerCastRefusal: a tethered creature's Translocation spell needs a Will save first (Tether). */
export async function tetherRefusal(ctx = {}) {
  const caster = ctx.actor;
  const tether = ownEffects(caster, "tether9b")[0];
  if (!tether) return null;
  const traits = String(ctx.spellData?.traits ?? ctx.spell?.system?.traits ?? "").toLowerCase();
  if (!/\b(translocation|teleportation)\b/.test(traits)) return null;
  const rec = tether.flags?.[MODULE_ID]?.tether9b ?? {};
  const will = caster.system?.combat?.saves?.will;
  const check = await h().rollCheck({ actor: caster, type: "save", subject: "will", label: `${caster.name} — against ${rec.by ?? "a"} Tether`, dc: int(rec.dc), modifiers: [...(will?.checkModifiers ?? [{ label: "Will", value: Number(will?.total ?? 0), type: "untyped" }])] });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  if (["heroic", "critical", "success"].includes(degree)) return null;
  return `${caster.name} is tethered by ${rec.by ?? "a Tether rune"} and fails the Will save (DC ${int(rec.dc)}): the Translocation effect fails`;
}

/* ------------------------------------------------------------------ */
/* The weapon runes on a Strike (H22)                                    */
/* ------------------------------------------------------------------ */

const roundUsed = new Map();
/** Once per round per weapon and rune (combat round, else 6 s of world time). */
function oncePerRound(weapon, upper) {
  const combat = globalThis.game?.combat;
  const stamp = combat?.started ? `${combat.id}:${combat.round}` : `t${Math.floor(now() / 6)}`;
  const k = `${weapon?.uuid ?? weapon?.id}:${upper}`;
  if (roundUsed.get(k) === stamp) return false;
  roundUsed.set(k, stamp);
  return true;
}

async function ask(actor, title, content, yes) {
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2) return false;
  const got = await DialogV2.wait({ window: { title }, classes: ["trg-prime"], content: `<div class="trg-prime trg-check-dialog">${content}</div>`, buttons: yesNo(yes), rejectClose: false });
  return got === "yes";
}

/** Every creature but `except` adjacent (5 ft) to the target's token. */
function adjacentTo(targetToken, except = []) {
  if (!targetToken) return [];
  return tokens().filter((t) => t !== targetToken && !except.includes(t.actor) && within(t, targetToken, 5)).map((t) => t.actor);
}

/** A basic save against the wielder's Level DC, for each creature. */
async function basicAll(wielder, targets, { save, formula, type, label }) {
  const lines = [];
  for (const target of targets) {
    const hit = await h().basicSaveHit({ caster: wielder, target, save, dc: levelDCOf(wielder), label, formula, type });
    lines.push(hit?.line ?? `${esc(target.name)}: ${formula} ${type} (basic ${save}).`);
  }
  return lines;
}

/** trgPrimeStrikeResolved: the runes on the weapon swung. On the attacker's client. */
export async function onStrikeResolvedB9b(ctx = {}) {
  const { attacker, target, weapon } = ctx;
  if (!attacker?.isOwner || !weapon) return;
  // VEIL: the struck creature's critical of serious or worse.
  // ONE ASK A BLOW (review): the damage hook asks for "below 25%" (on the
  // client that applied it), so this asks only when that one did not.
  if (target && ["serious", "deadly"].includes(String(ctx.critical ?? "")) && equippedWith(target, "VEIL").length) {
    const hp = target.system?.resources?.hp ?? {};
    if (!R.veilTriggers({ hp: Number(hp.value), max: Number(hp.max) })) await offerVeil(target, `${target.name} takes a ${ctx.critical} critical.`);
  }
  const runes = runesOnField(weapon.system?.effectiveRunes ?? weapon.system?.runes ?? "").filter((r) => R.RUNES_9B[r.upper].family === "weapon");
  if (!runes.length) return;
  // SANGUINE'S DRAWBACK COUNTS STRIKES THAT LAND ON A FOE.
  if (ctx.hits && runes.some((r) => r.upper === "SANGUINE")) await weapon.setFlag(MODULE_ID, "sanguineIdle9b", { combatId: globalThis.game?.combat?.id ?? "", idle: 0 });
  if (!ctx.hits || !target) return;
  const tToken = tokenOf(target);
  const me = tokenOf(attacker);
  const lines = [];
  const crit = ctx.critical ? String(ctx.critical) : "";
  for (const r of runes) {
    const spec = R.RUNES_9B[r.upper];
    if (r.upper === "AETHERFANG" && crit) {
      const dice = R.aetherfangDice(crit);
      if (dice) lines.push(`<strong>Aetherfang</strong> (a ${esc(crit)} critical):`, ...await basicAll(attacker, [target], { save: "fortitude", formula: dice, type: "essence", label: "Aetherfang" }));
    }
    if (r.upper === "ECHOING" && crit) {
      const amount = R.byTier(spec.recurring, r.tier);
      await writeOn(target, { kind: "recurring", amount, type: "sonic" });
      lines.push(`<strong>Echoing</strong>: ${esc(target.name)} takes <strong>${amount} recurring sonic</strong> damage. Faint whispers follow the strike, audible within 30 feet.`);
    }
    if (r.upper === "MINDPIERCER" && crit) {
      lines.push(`<strong>Mindpiercer</strong>:`, ...await basicAll(attacker, [target], { save: "will", formula: R.byTier(["1d8", "2d8", "3d8", "4d8"], r.tier), type: "mental", label: "Mindpiercer" }));
    }
    if (r.upper === "GRAVITAS" && crit && oncePerRound(weapon, r.upper)) {
      lines.push(`<strong>Gravitas</strong>: you may Trip or Shove ${esc(target.name)} now as a free action — no MAP, no requirements, rolled with ${esc(weapon.name)}'s attack bonus. Take it from your actions (it is not rolled for you).`);
    }
    if (r.upper === "PYREBRAND" && int(ctx.natural) === 20) {
      // "When active" — the energy rune's own state (TRG Prime's `${key}Active`).
      const active = Boolean(weapon.flags?.[SYSTEM_ID]?.runeState?.[`${key("PYREBRAND")}Active`]
        || (weapon.flags?.[SYSTEM_ID]?.specificItem?.alwaysActive ?? []).includes(key("PYREBRAND")));
      if (active) {
        const near = adjacentTo(tToken, [attacker, target]);
        lines.push(`<strong>Pyrebrand</strong> surges on the natural 20:`, ...(near.length ? await basicAll(attacker, near, { save: "reflex", formula: R.byTier(spec.surge, r.tier), type: "fire", label: "Pyrebrand" }) : [line("No creature is adjacent to the target.")]));
      }
    }
    if (r.upper === "SANGUINE" && int(ctx.damageTaken) > 0) {
      const formula = R.sanguineBleed(ctx.natural);
      const value = formula === "1" ? 1 : (await new Roll(formula).evaluate()).total;
      await h().applyConditionTagsTo(target, [{ key: "bleeding", value }]);
      lines.push(`<strong>Sanguine</strong>: ${esc(target.name)} is Bleeding ${value}${formula !== "1" ? ` (${formula} on the natural 20)` : ""}.`);
    }
    if (r.upper === "WARPFLARE") {
      const near = Boolean(me && await leyLineNear(me));
      const roll = (await new Roll("1d6").evaluate()).total;
      const result = R.warpflareResult(roll, near);
      if (result === "force") {
        const amount = (await new Roll("2d6").evaluate()).total;
        await h().applyTypedDamage(target, { amount, type: "force", sourceName: "Warpflare", source: attacker });
        lines.push(`<strong>Warpflare</strong>: d6 ${roll}${near ? " +1 (ley line)" : ""} — reality buckles: <strong>${amount} force</strong> damage (2d6).`);
      } else if (result === "surge") {
        lines.push(`<strong>Warpflare</strong>: d6 ${roll}${near ? " +1 (ley line)" : ""} — wild magic, with ${esc(attacker.name)} as its source (area level ${R.WARPFLARE_SURGE_LEVEL}).`);
        await wildSurgeAt(attacker, R.WARPFLARE_SURGE_LEVEL, `Warpflare — Wild Surge (level ${R.WARPFLARE_SURGE_LEVEL})`);
      } else lines.push(`<strong>Warpflare</strong>: d6 ${roll}${near ? " +1 (ley line)" : ""} — the strike deals normal damage.`);
    }
    if (r.upper === "ESSENCEBREAKER") lines.push(...await essencebreaker(attacker, target));
    if (r.upper === "NULLFLARE") lines.push(...await nullflare(attacker, target));
    if (r.upper === "TETHER" && oncePerRound(weapon, r.upper) && await ask(attacker, `Tether — ${weapon.name}`, `<p>Tether ${esc(target.name)} for 1 round (free)? While tethered, a Translocation spell or teleport it attempts needs a Will save against your Level DC ${levelDCOf(attacker)}, or it fails.</p>`, "Tether it")) {
      await writeOn(target, { kind: "createEffect", data: effectData("tether9b", { name: `Tethered (${attacker.name})`, img: "icons/svg/net.svg", module: { tether9b: { dc: levelDCOf(attacker), by: `${attacker.name}'s ${weapon.name}` } }, expiry: forSeconds(6) }) });
      lines.push(`<strong>Tether</strong>: ${esc(target.name)} is tethered for 1 round (Will DC ${levelDCOf(attacker)} against any Translocation effect it attempts; a teleport not cast as a spell is the GM's to ask).`);
    }
    if (r.upper === "VEILSTORM" && oncePerRound(weapon, r.upper) && await ask(attacker, `Veilstorm — ${weapon.name}`, `<p>Tear the veil (free)? 1d6 force to every creature adjacent to ${esc(target.name)} but you, basic Reflex against your Level DC ${levelDCOf(attacker)}.</p>`, "Tear it")) {
      const near = adjacentTo(tToken, [attacker]).filter((a) => a !== target);
      lines.push(`<strong>Veilstorm</strong>:`, ...(near.length ? await basicAll(attacker, near, { save: "reflex", formula: "1d6", type: "force", label: "Veilstorm" }) : [line("No other creature is adjacent to the target.")]));
    }
    if (r.upper === "RIFTCLEAVER" && me && oncePerRound(weapon, r.upper) && await ask(attacker, `Riftcleaver — ${weapon.name}`, `<p>Teleport up to 10 feet to a space you can see (free)? Ending adjacent to ${esc(target.name)} gives +1 circumstance to your next attack against it before the end of your next turn.</p>`, "Teleport")) {
      lines.push(...await riftcleave(attacker, target, me, tToken));
    }
  }
  if (lines.length) await card(attacker, `${weapon.name} — runes`, lines.map((t) => (/^<p/.test(t) ? t : line(t))));
}

async function essencebreaker(attacker, target) {
  const dc = levelDCOf(attacker);
  const will = target.system?.combat?.saves?.will;
  const check = await h().rollCheck({ actor: target, type: "save", subject: "will", label: `${target.name} — Essencebreaker`, dc, modifiers: [...(will?.checkModifiers ?? [{ label: "Will", value: Number(will?.total ?? 0), type: "untyped" }])] });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  if (["heroic", "critical", "success"].includes(degree)) return [`<strong>Essencebreaker</strong>: ${esc(target.name)} saves (${esc(degree)}).`];
  // DAMAGE TYPES ONLY (review): a category ("mundane", "all damage") or a
  // bracketed entry is not one the suppression can take away.
  const resists = [...new Set(String(target.system?.combat?.resistances ?? "").split(/[,;]/).map((s) => s.trim().toLowerCase()).filter((t) => R.DAMAGE_TYPES.includes(t)))];
  if (!resists.length) return [`<strong>Essencebreaker</strong>: ${esc(target.name)} fails (${esc(degree)}), and has no resistance to lose.`];
  const pick = resists.length === 1 ? resists[0] : await h().chooseFromList("Essencebreaker", `${target.name} loses one resistance until the end of your next turn (you choose):`, resists.map((r) => [r, r]));
  if (!pick) return [`<strong>Essencebreaker</strong>: no resistance chosen.`];
  await writeOn(target, { kind: "createEffect", data: { ...effectData("essencebreaker9b", { name: `Essencebreaker: ${pick} resistance lost`, img: "icons/svg/downgrade.svg", system: { suppressedResistances: [pick] }, expiry: forSeconds(12) }) } });
  return [`<strong>Essencebreaker</strong>: ${esc(target.name)} fails (${esc(degree)}) and loses its resistance to <strong>${esc(pick)}</strong> until the end of your next turn.`];
}

async function nullflare(attacker, target) {
  const dc = levelDCOf(attacker);
  const will = target.system?.combat?.saves?.will;
  const check = await h().rollCheck({ actor: target, type: "save", subject: "will", label: `${target.name} — Nullflare`, dc, modifiers: [...(will?.checkModifiers ?? [{ label: "Will", value: Number(will?.total ?? 0), type: "untyped" }])] });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  if (["heroic", "critical", "success", "partial"].includes(degree)) return [`<strong>Nullflare</strong>: ${esc(target.name)} — ${esc(degree)}, no effect.`];
  // A SPELL'S EFFECT (review): one whose origin is a spell — not this module's
  // own clocks (every timed effect carries spellEffect) — read at its spell's PP.
  const originSpell = (e) => { try { const o = e.origin ? globalThis.fromUuidSync?.(e.origin) : null; return o?.type === "spell" ? o : null; } catch { return null; } };
  const spells = effects(target).filter((e) => !e.disabled && !e.flags?.[MODULE_ID]?.source && originSpell(e) && !nullflareSuppresses(e))
    .map((e) => ({ e, pp: int(originSpell(e)?.system?.ppCost) })).sort((a, b) => a.pp - b.pp);
  if (!spells.length) return [`<strong>Nullflare</strong>: ${esc(target.name)} — ${esc(degree)}, but carries no spell effect to nullify.`];
  let chosen = spells[0];
  const tied = spells.filter((s) => s.pp === spells[0].pp);
  if (tied.length > 1) {
    const id = await h().chooseFromList("Nullflare", "The lowest-PP effects tie (the GM breaks ties):", tied.map((s) => [s.e.id, `${s.e.name} (${s.pp} PP)`]));
    chosen = tied.find((s) => s.e.id === id) ?? spells[0];
  }
  if (degree === "blunder") {
    await writeOn(target, { kind: "deleteEffect", effectId: chosen.e.id, nullflare: true });
    return [`<strong>Nullflare</strong>: ${esc(target.name)} blunders — <strong>${esc(chosen.e.name)}</strong> is dispelled.`];
  }
  const seconds = degree === "fumble" ? 12 : 6;
  await writeOn(target, { kind: "suppressEffect", effectId: chosen.e.id, until: now() + seconds, by: attacker.name });
  return [`<strong>Nullflare</strong>: ${esc(target.name)} — ${esc(degree)}: <strong>${esc(chosen.e.name)}</strong> is nullified until ${degree === "fumble" ? "the end of your next turn" : "the beginning of your next turn"} (${seconds} seconds of world time).`];
}

async function riftcleave(attacker, target, me, tToken) {
  if (await h().teleportationFails?.(attacker)) return [`<strong>Riftcleaver</strong>: ${esc(attacker.name)} has already been teleported this turn — a second teleportation fails.`];
  const { teleportWithin } = await import("./block7-automations.mjs");
  const moved = await teleportWithin(me, 10, "Riftcleaver");
  if (!moved) return [];
  const pseudo = { name: "Riftcleaver", system: { traits: "Invested, Teleportation, Translocation", ppCost: 0 } };
  const said = (await h().teleportationArrives?.(attacker, pseudo, [attacker])) ?? [];
  const lines = [`<strong>Riftcleaver</strong>: ${esc(attacker.name)} teleports ${moved.feet} feet.`, ...said];
  if (tToken && within(me, tToken, 5)) {
    await attacker.createEmbeddedDocuments("ActiveEffect", [effectData("riftcleaver9b", {
      name: `Riftcleaver: +1 against ${target.name}`, img: "icons/svg/upgrade.svg",
      system: { conditionals: [{ kind: "modifier", value: 1, type: "circumstance", label: "Riftcleaver", scope: `your next attack against ${target.name}`, when: { checkTypes: ["attack"], targetUuids: [target.uuid] } }] },
      expiry: (await import("./effects-clock.mjs")).expiryFor("endOfNextTurn", attacker)
    })]);
    lines.push(`Adjacent to ${esc(target.name)}: +1 circumstance to your next attack against it before the end of your next turn (offered on the attack; delete the effect once used).`);
  }
  return lines;
}

/** trgPrimeWeaponFumble: the runes' drawbacks. On the attacker's client. */
export async function onWeaponFumbleB9b(ctx = {}) {
  const { attacker, weapon } = ctx;
  if (!attacker?.isOwner || !weapon) return;
  const runes = runesOnField(weapon.system?.effectiveRunes ?? weapon.system?.runes ?? "");
  const lines = [];
  for (const r of runes) {
    if (r.upper === "AETHERFANG") lines.push(`<strong>Aetherfang</strong> backlash:`, ...await basicAll(attacker, [attacker], { save: "fortitude", formula: "2d6", type: "essence", label: "Aetherfang (fumble)" }));
    if (r.upper === "LEYBOUND") {
      const near = await leyLineNear(tokenOf(attacker));
      if (near) { lines.push(`<strong>Leybound</strong>: the ley line answers the fumble — a wild surge, area level ${near.level} (${esc(near.name || "the ley line")}).`); await wildSurgeAt(attacker, near.level, `Leybound — Wild Surge (level ${near.level})`); }
      else lines.push("<strong>Leybound</strong>: no ley line within 30 feet, so no surge.");
    }
    if (r.upper === "RIFTCLEAVER") {
      const feet = 5 * (await new Roll("1d6").evaluate()).total;
      const dir = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"][(await new Roll("1d8").evaluate()).total - 1];
      await ChatMessage.create({ content: `<div class="trg-prime trg-check-card">${line(`<strong>Riftcleaver</strong> (${esc(attacker.name)}'s fumble): teleported <strong>${feet} feet ${dir}</strong>. Move the token (a teleport: the second in a turn fails).`)}</div>`, whisper: ChatMessage.getWhisperRecipients?.("GM") ?? [] });
      lines.push("<strong>Riftcleaver</strong>: the unstable magic backlashes — you are teleported 1d6 × 5 feet in a random direction (the GM has the roll).");
    }
    if (r.upper === "TETHER") {
      const roll = (await new Roll("1d20").evaluate()).total;
      if (roll < 15) { await h().applyConditionTagsTo(attacker, [{ key: "immobilised", ...((await import("./effects-clock.mjs")).expiryFor("startOfNextTurn", attacker).system ?? {}) }]); lines.push(`<strong>Tether</strong>: DC 15 flat check — ${roll}: you are <strong>Immobilised</strong> until the beginning of your next turn.`); }
      else lines.push(`<strong>Tether</strong>: DC 15 flat check — <strong>${roll}</strong>: you keep your footing.`);
    }
    if (r.upper === "VEILSTORM") {
      await h().applyConditionTagsTo(attacker, [{ key: "blinded", ...(inCombat(attacker) ? { expiresRound: int(globalThis.game.combat.round) + 2 } : { expiresTime: now() + 12 }) }]);
      lines.push("<strong>Veilstorm</strong>: the veil destabilises — you are <strong>Blinded</strong> until the end of your next turn.");
    }
  }
  if (lines.length) await card(attacker, `${weapon.name} — fumble`, lines.map((t) => (/^<p/.test(t) ? t : line(t))));
}

/* ------------------------------------------------------------------ */
/* Turn end: Chrono's check, Sanguine's thirst                            */
/* ------------------------------------------------------------------ */

const CHRONO_STATE = () => key("CHRONO");
export const chronoRunning = (weapon) => Boolean(weapon?.flags?.[SYSTEM_ID]?.runeState?.[CHRONO_STATE()]);

/*
 * ENDING CHRONO (0.14.0 live test). "It runs until you end it or become
 * Fatigued." The press starts the core's rune timer (its day is only a
 * backstop), so the rune is ended through that timer: the core's
 * `stopItemTimer` deletes it, and its ending turns the state off. Setting the
 * state alone left the timer effect on the wielder for a day.
 */
// The core's module API (not its helpers): `stopItemTimer` lives there.
const coreApi = () => globalThis.game?.trgPrime?.modules;
async function endChrono(actor, weapon, why) {
  const stopped = await coreApi()?.stopItemTimer?.(actor, weapon, CHRONO_STATE());
  if (!stopped && chronoRunning(weapon)) await weapon.setFlag(SYSTEM_ID, "runeState", { ...(weapon.flags?.[SYSTEM_ID]?.runeState ?? {}), [CHRONO_STATE()]: false });
  await card(actor, `${weapon.name} — Chrono`, [line(why)]);
}
const FATIGUED_ENDS = "Fatigued: the rune's effect ends, and it cannot be activated while you are Fatigued.";

/** trgPrimeTurnEnded: on the acting GM. */
export async function onTurnEndedB9b(ctx = {}) {
  if (!isActingGM()) return;
  const actor = ctx.actor ?? ctx.combatant?.actor;
  if (!actor) return;
  for (const weapon of items(actor).filter((i) => i.type === "weapon")) {
    if (runeOn(weapon, "CHRONO") && chronoRunning(weapon)) {
      if (actor.hasCondition?.("fatigued")) {
        await endChrono(actor, weapon, FATIGUED_ENDS);
      } else {
        const turn = int(weapon.flags?.[MODULE_ID]?.chronoTurns9b) + 1;
        await weapon.setFlag(MODULE_ID, "chronoTurns9b", turn);
        const step = R.chronoStep(turn);
        await card(actor, `${weapon.name} — Chrono`, [line(`The end of a turn the rune ran (${turn} in a row): an Exhaustion check, ${step.label}.`)]);
        // A CHECK THAT LEAVES YOU FATIGUED ends the rune as the condition
        // lands (`onChronoTimerCreatedB9b`), as Fatigue from anything else does.
        await h().rollExhaustionCheck?.(actor, { modifier: step.modifier, activity: `Chrono (${step.label})` });
      }
    } else if (weapon.flags?.[MODULE_ID]?.chronoTurns9b) await weapon.unsetFlag(MODULE_ID, "chronoTurns9b");
    if (runeOn(weapon, "SANGUINE") && weapon.system?.equipped && globalThis.game?.combat?.started) {
      // "DURING AN ENCOUNTER" (review): the count is this combat's; a new one starts at 0.
      const rec = weapon.flags?.[MODULE_ID]?.sanguineIdle9b ?? {};
      const combatId = globalThis.game.combat.id;
      const idle = (rec.combatId === combatId ? int(rec.idle) : 0) + 1;
      if (idle >= 3) {
        const value = (await new Roll("1d6").evaluate()).total;
        await h().applyConditionTagsTo(actor, [{ key: "bleeding", value }]);
        await card(actor, `${weapon.name} — Sanguine`, [line(`Three consecutive rounds without striking a foe: the weapon thirsts — ${esc(actor.name)} is <strong>Bleeding ${value}</strong> (1d6).`)]);
        await weapon.setFlag(MODULE_ID, "sanguineIdle9b", { combatId, idle: 0 });
      } else await weapon.setFlag(MODULE_ID, "sanguineIdle9b", { combatId, idle });
    }
  }
}

/** updateItem: Chrono switched on — a Quickened effect whose point buys a Strike; off — it goes. Fatigued refuses it. */
export async function onChronoToggledB9b(item, change = {}) {
  if (item?.type !== "weapon" || !runeOn(item, "CHRONO") || !item.isOwner) return;
  // ONE CLIENT (review): the GM's and the owner's both see the update.
  const { actsFor } = await import("./block3-automations.mjs");
  if (!item.parent || !actsFor(item.parent)) return;
  const stateChanged = change?.flags?.[SYSTEM_ID]?.runeState && Object.hasOwn(change.flags[SYSTEM_ID].runeState, CHRONO_STATE());
  if (!stateChanged) return;
  const actor = item.parent;
  if (!actor) return;
  const have = ownEffects(actor, "chrono9b");
  if (chronoRunning(item)) {
    if (actor.hasCondition?.("fatigued")) {
      await item.setFlag(SYSTEM_ID, "runeState", { ...(item.flags?.[SYSTEM_ID]?.runeState ?? {}), [CHRONO_STATE()]: false });
      return warn(`${item.name}: you cannot activate Chrono while Fatigued.`);
    }
    if (!have.length) await actor.createEmbeddedDocuments("ActiveEffect", [{ ...effectData("chrono9b", { name: `Chrono (${item.name})`, img: "icons/svg/clockwork.svg", system: { quickenedFor: ["strike"] } }), statuses: ["quickened"] }]);
  } else {
    if (have.length) await actor.deleteEmbeddedDocuments("ActiveEffect", have.map((e) => e.id));
    if (item.flags?.[MODULE_ID]?.chronoTurns9b) await item.unsetFlag(MODULE_ID, "chronoTurns9b");
  }
}

/**
 * createActiveEffect, on one client (`actsFor`), two cases (0.14.1, from the
 * 0.14.0 live test and its review):
 *
 *   A REFUSED PRESS'S TIMER. The press turns the state on (refused above
 *   while Fatigued) and only then starts the core's timer, so a timer that
 *   appears for Chrono while the wielder is Fatigued is removed as it lands.
 *
 *   BECOMING FATIGUED. "It runs until you end it or become Fatigued": the
 *   Fatigued condition landing on a wielder whose Chrono runs ends it then,
 *   whatever gave it (the rune's own Exhaustion check included), not at the
 *   turn's end, which would buy another quickened point first.
 */
const isFatiguedEffect = (effect) => effect?.flags?.[SYSTEM_ID]?.condition === "fatigued" || Boolean(effect?.statuses?.has?.("fatigued"));
export async function onChronoTimerCreatedB9b(effect) {
  const timer = effect?.flags?.[SYSTEM_ID]?.runeTimer;
  const chronoTimer = Boolean(timer && timer.state === CHRONO_STATE());
  const fatigue = isFatiguedEffect(effect);
  if (!chronoTimer && !fatigue) return;
  const actor = effect.parent;
  if (!actor?.hasCondition?.("fatigued")) return;
  const { actsFor } = await import("./block3-automations.mjs");
  if (!actsFor(actor)) return;
  if (chronoTimer) {
    const weapon = actor.items?.get?.(timer.itemId);
    if (weapon) await coreApi()?.stopItemTimer?.(actor, weapon, CHRONO_STATE());
    return;
  }
  for (const weapon of items(actor).filter((i) => i.type === "weapon" && runeOn(i, "CHRONO") && chronoRunning(i))) {
    await endChrono(actor, weapon, FATIGUED_ENDS);
  }
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export function runeRegistrations9b() {
  return Object.keys(R.RUNES_9B).map((upper) => {
    const reg = R.runeRegistration(upper);
    if (upper === "LEYBOUND") reg.declares = { ...reg.declares, extraBaseDie: { when: leyboundWhen } };
    return reg;
  });
}

export function registerBlock9b(api, moduleId) {
  api.registerRunes?.(runeRegistrations9b(), moduleId);
  api.registerLightSources?.(LUMINOUS_LIGHTS.map((l) => ({ ...l })), moduleId);
  api.registerCastReaction?.("eaNullflow", nullflowReaction, moduleId);
  api.registerSpellCheckGate?.("eaResonantDefiance", resonantDefianceGate, moduleId);
  api.registerCheckReaction?.("eaLeybound", { before: leyboundBefore }, moduleId);
  api.registerCastCapModifier?.("eaSummonersBrand", summonersBrandCap, moduleId);
  api.registerCastRefusal?.("eaTether", tetherRefusal, moduleId);
  api.registerEffectSuppressor?.("eaNullflare", nullflareSuppresses, moduleId);
  api.registerReactionStep?.(NULLFLOW_STEP, nullflowStep, moduleId);
  api.registerReactionStep?.(DEFIANCE_STEP, defianceStep, moduleId);
  api.registerReactionStep?.(VEIL_STEP, veilStep, moduleId);
}

/** Luminous follows what is equipped (create, update, delete of an item; ready). */
export async function onItemChangedB9b(item, change = {}) {
  await onItemDamagedB9b(item, change);
  await onChronoToggledB9b(item, change);
  if (["armour", "shield"].includes(item?.type) && (runeOn(item, "LUMINOUS") || ownEffects(item.parent, "luminous9b").length)) await syncLuminous(item.parent);
}
export async function onItemAddedOrRemovedB9b(item) {
  if (["armour", "shield"].includes(item?.type) && (runeOn(item, "LUMINOUS") || ownEffects(item.parent, "luminous9b").length)) await syncLuminous(item.parent);
}
export async function onReadyB9b() {
  for (const actor of Array.from(globalThis.game?.actors ?? [])) {
    if (!actor?.isOwner) continue;
    if (luminousLightOf(actor) || ownEffects(actor, "luminous9b").length) await syncLuminous(actor);
  }
  globalThis.game?.socket?.on?.(SOCKET, (data) => { onBlock9bSocket(data).catch((err) => console.warn("Eldritch Arts | Block 9b socket", err)); });
}
