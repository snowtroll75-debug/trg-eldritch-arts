/**
 * Eldritch Arts — Block 11 (0.18.0): what the Feat Additions do that is not
 * data. On TRG Prime 3.712.4; the two weapon and crafting-time seams need
 * 3.713.0 (C-EA11-1, C-EA11-2) and say so on the card when they are absent.
 *
 *   Uses        Modular Design (today's upgrades) and Advanced Design's swap,
 *               Quick Swap, Overclocked Weaponry, Mechanised Assistant (build,
 *               specialty, improvement, rebuild, retrieve), Emergency
 *               Contraption (a sprung trap), Triggered Sigil (designate,
 *               activate), Arcane Preparation, Perfected Arcane Memory, Grand
 *               Inscription (identify), and every Prepared ability's recharge
 *   Reactions   Power Sink / Instability Harness (check, after; and the
 *               Resonance suppressor), Emergency Contraption and Flash of
 *               Insight (check, after), Heritage of the First Weave, Runic
 *               Anchor, Arcane Preparation's gate (check, before), Triggered
 *               Sigil (defence offer, damage hook), Reactive Protocol (before)
 *   Seams       weapon enhancement (C-EA11-1), crafting work (C-EA11-2), the
 *               overload's effect suppressor, Grand Inscription's cast option,
 *               Ley Resonance's metamagic, Spell Relay Node's cast option, the
 *               assistant's familiar modifier
 *   Hooks       daily preparation, spell cast / settled, item deleted, effect
 *               deleted (traces), actor updated (Grand Inscription's identify
 *               rewrite), token moved (Tool Armature), world time (Prepared),
 *               item created on the assistant (Storage), healing (construct)
 *
 * The pure rules are block11-rules.mjs. Nothing here touches an ordinary
 * familiar, companion or weapon: every write is keyed to this module's flags.
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, now, levelOf, owned, tokenOf, inCombat, spendAP, feetBetween } from "./block1-automations.mjs";
import { allies } from "./block3b-automations.mjs";
import { leyLinesWithin } from "./areas.mjs";
import { SIGILS_FLAG, SIGIL_LOCK_FLAG, sigilReady, sigilLockHeld, roundStamp, isRunemageActor, leyBenefitOf } from "./block6c-automations.mjs";
import * as R from "./block11-rules.mjs";

const { FEATS } = R;
const items = (actor) => Array.from(actor?.items ?? []);
const featNames = (actor) => items(actor).filter((i) => ["feat", "ability"].includes(i.type)).map((i) => i.name);
const has = (actor, name) => owned(actor, name, ["feat", "ability"]);
const mflag = (doc, key) => doc?.flags?.[MODULE_ID]?.[key] ?? doc?.getFlag?.(MODULE_ID, key);
const side = (token) => token?.document?.disposition;
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []);
const worldTime = () => now();
const combatState = (actor) => combatFor(actor);
const sigilNow = (actor) => ({ combat: combatState(actor), worldTime: worldTime() });

async function confirm(title, content) {
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2) return false;
  return Boolean(await DialogV2.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}
const yesNo = (label) => [{ action: "yes", label, default: true }, { action: "no", label: "No" }];

/** Ask for free text (Flash of Insight's description). Returns "" when cancelled. */
async function askText(title, prompt) {
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2) return "";
  const out = await DialogV2.prompt({
    window: { title }, rejectClose: false,
    content: `<p>${prompt}</p><textarea name="text" rows="4" style="width:100%"></textarea>`,
    ok: { label: "Declare", callback: (event, button) => String(button.form?.elements?.text?.value ?? "").trim() }
  });
  return typeof out === "string" ? out : "";
}

/* ------------------------------------------------------------------ */
/* The Prepared trait                                                   */
/* ------------------------------------------------------------------ */

const preparedState = (item) => mflag(item, R.PREPARED_FLAG) ?? null;
export const preparedReadyNow = (item) => R.preparedReady(preparedState(item), worldTime());

async function expendPrepared(item) {
  await item.setFlag(MODULE_ID, R.PREPARED_FLAG, R.preparedExpended(worldTime()));
}

/** "Can be replenished … if you take a 3 AP (manipulate) Crafting action (level based DC)." */
async function rechargePrepared(actor, item) {
  if (preparedReadyNow(item)) return warn(`${item.name} is ready — nothing to recharge.`);
  if (!(await spendAP(actor, `${item.name}: recharge`, R.PREPARED_RECHARGE_AP))) return false;
  const dc = h().levelDC(levelOf(actor));
  const check = await h().rollCheck({
    actor, type: "skill", subject: R.PREPARED_RECHARGE_SKILL, dc, traits: "Manipulate",
    label: `Recharge ${item.name}`, subtitle: `Crafting (manipulate, ${R.PREPARED_RECHARGE_AP} AP), DC ${dc} (level based)`
  });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  const restored = R.preparedRestores(degree);
  if (restored) await item.unsetFlag(MODULE_ID, R.PREPARED_FLAG);
  const left = Math.ceil(R.preparedSecondsLeft(preparedState(item), worldTime()) / 60);
  await card(actor, item.name, [line(restored
    ? `<strong>${esc(item.name)}</strong> is replenished (Crafting ${esc(degree)} against DC ${dc}).`
    : `The recharge fails (${esc(degree)} against DC ${dc}). <strong>${esc(item.name)}</strong> recharges by itself in ${left} minute${left === 1 ? "" : "s"}.`)]);
  return restored;
}

/** A Prepared ability's state, for its Use menu. */
const preparedLine = (item) => (preparedReadyNow(item) ? "ready" : `expended — recharges in ${Math.ceil(R.preparedSecondsLeft(preparedState(item), worldTime()) / 60)} min, or with the ${R.PREPARED_RECHARGE_AP} AP Crafting action`);

/** Hooks.on("updateWorldTime"): clear the Prepared flags that have recharged (the sheet then reads "ready"). */
export async function onWorldTimeB11() {
  if (!isActingGM()) return;
  const t = worldTime();
  for (const actor of Array.from(globalThis.game?.actors ?? [])) {
    for (const item of items(actor)) {
      const s = preparedState(item);
      if (s?.expended && R.preparedReady(s, t)) await item.unsetFlag(MODULE_ID, R.PREPARED_FLAG).catch(() => {});
    }
  }
}

/* ------------------------------------------------------------------ */
/* Modular Design, Advanced Design, Integrated Modularity, Quick Swap   */
/* ------------------------------------------------------------------ */

const allocationsOf = (actor) => (Array.isArray(mflag(actor, R.MODULAR_FLAG)?.allocations) ? mflag(actor, R.MODULAR_FLAG).allocations : []);
const modularDay = (actor) => mflag(actor, R.MODULAR_FLAG) ?? {};

/** Proficiency through the core's own rule; fail open (and say so) when it cannot be read. */
async function proficient(actor, item) {
  const kind = R.modularKind(item);
  if (kind === "equipment") return { ok: true, why: "" };
  try {
    const { proficiencyOf, proficiencyProfile } = await import("/systems/trg-prime/module/proficiency-rules.mjs");
    const out = proficiencyOf(proficiencyProfile(actor), { type: item.type, name: item.name, system: item.system, flags: item.flags });
    return { ok: out?.proficient !== false, why: String(out?.why ?? "") };
  } catch {
    return { ok: true, why: "proficiency could not be read — the GM confirms it" };
  }
}

/** Broken as the core reads it (items.mjs itemStatus): tracked HP at 0 or below. Was "half HP" — out of step with the core's own suppression (found live, 0.18.1). */
const broken = (item) => {
  const hp = item?.system?.hp;
  if (!hp || !(Math.floor(Number(hp.max) || 0) > 0)) return false;
  return Math.floor(Number(hp.value) || 0) <= 0;
};

/** Write one upgrade onto its item: an effect (armour, shield, tool) or a flag the weapon seam reads. */
async function placeUpgrade(actor, a) {
  const item = actor.items.get(a.itemId);
  if (!item) return false;
  if (a.kind === "weapon") {
    // A LIST (A11-2): under Integrated Modularity a weapon may carry an attack
    // and a damage upgrade. Rewritten whole — setFlag merges, which would keep
    // a stale single upgrade's keys beside the list.
    const cur = mflag(item, R.MODULAR_ITEM_FLAG);
    const list = (Array.isArray(cur?.upgrades) ? cur.upgrades : (cur?.target ? [{ target: cur.target, value: cur.value }] : [])).filter((u) => u.target !== a.target);
    list.push({ target: a.target, value: a.value });
    if (cur) await item.unsetFlag(MODULE_ID, R.MODULAR_ITEM_FLAG);
    await item.setFlag(MODULE_ID, R.MODULAR_ITEM_FLAG, { upgrades: list, kind: "weapon", day: modularDay(actor).day ?? 0 });
    return true;
  }
  const effect = effectData(R.MODULAR_EFFECT, {
    name: `Modular upgrade +${a.value} (${a.target === "skill" ? a.skill : a.target.toUpperCase()})`,
    img: "modules/trg-eldritch-arts/assets/feats/class.png",
    description: `${FEATS.modular}: +${a.value} item bonus${a.target === "skill" ? ` to ${a.skill} checks using this tool` : ` to ${a.target.toUpperCase()}`}, until your next daily preparation. Counts only while equipped and not broken.`,
    changes: a.kind === "armour" ? [R.modularArmourChange(a.target, a.value)] : [],
    module: { upgrade: { ...a } }
  });
  effect.transfer = true;
  if (a.kind === "equipment") effect.flags[SYSTEM_ID].conditionals = [R.modularSkillConditional(a.skill, a.value, item.name)];
  await item.createEmbeddedDocuments("ActiveEffect", [effect]);
  return true;
}

/** Remove one item's upgrade, whatever form it took. */
async function clearUpgrade(item) {
  if (!item) return;
  if (mflag(item, R.MODULAR_ITEM_FLAG)) await item.unsetFlag(MODULE_ID, R.MODULAR_ITEM_FLAG);
  const ids = Array.from(item.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, "source") === R.MODULAR_EFFECT).map((e) => e.id);
  if (ids.length) await item.deleteEmbeddedDocuments("ActiveEffect", ids);
}

/** An item's upgrades set to exactly the allocations that name it (after a move). */
async function replaceItemUpgrades(actor, itemId, allocations) {
  const item = actor.items.get(itemId);
  if (!item) return;
  await clearUpgrade(item);
  for (const a of allocations.filter((x) => x.itemId === itemId)) await placeUpgrade(actor, a);
}

async function clearAllUpgrades(actor) {
  for (const item of items(actor)) {
    if (mflag(item, R.MODULAR_ITEM_FLAG) || Array.from(item.effects ?? []).some((e) => e.getFlag?.(MODULE_ID, "source") === R.MODULAR_EFFECT)) await clearUpgrade(item);
  }
}

async function eligibleItems(actor, { worn = false } = {}) {
  const out = [];
  for (const item of items(actor)) {
    const kind = R.modularKind(item);
    if (!kind) continue;
    if (worn && !(item.system?.equipped)) continue;
    if (broken(item)) continue;
    const p = await proficient(actor, item);
    if (!p.ok) continue;
    out.push({ item, kind, note: p.why });
  }
  return out;
}

async function chooseTarget(kind, itemName, actor = null, taken = []) {
  const targets = R.MODULAR_TARGETS[kind].filter(([k]) => !taken.includes(k));
  if (!targets.length) return null;
  const target = targets.length === 1 ? targets[0][0] : await h().chooseFromList(FEATS.modular, `${esc(itemName)}: which bonus?`, targets.map(([k, l]) => [k, l]));
  if (!target) return null;
  let skill = "";
  if (target === "skill") {
    // The actor's own skill list (key and label), as the sheet shows it. There is
    // no CONFIG.TRG_PRIME.skills: reading it gave an empty list, so the skill was
    // never asked and always fell back to Crafting (found live, 0.18.1).
    const skills = Object.entries(actor?.system?.skills ?? {}).filter(([, v]) => v && typeof v === "object").map(([k, v]) => [k, String(v.label ?? k)]);
    skill = skills.length ? await h().chooseFromList(FEATS.modular, `${esc(itemName)}: the skill it helps when you use it`, skills) : "crafting";
    if (!skill) return null;
  }
  return { target, skill };
}

/** Modular Design's Use: today's upgrades, within the one allowance. */
async function applyToday(actor) {
  const allowance = R.modularAllowance(featNames(actor));
  if (modularDay(actor).applied) {
    const which = await h().chooseFromList(FEATS.modular, "Today's upgrades are applied. Clear them and choose again? (They are normally chosen once, at daily preparation.)", [["keep", "Keep them"], ["redo", "Clear and choose again (GM's leave)"]]);
    if (which !== "redo") return false;
    await clearAllUpgrades(actor);
  }
  const pool = await eligibleItems(actor);
  if (!pool.length) return warn(`${FEATS.modular}: no armour, shield, tool or weapon you are proficient with (and that is not broken).`);
  const chosen = [];
  let left = allowance.budget;
  const onItem = (id) => chosen.filter((c) => c.itemId === id);
  const itemsUsed = () => new Set(chosen.map((c) => c.itemId)).size;
  while (left > 0) {
    // An item is open while it has room: a new item while the item count
    // allows; under Integrated Modularity (A11-2) also one already chosen that
    // has an untaken bonus and room under the per-item cap.
    const open = pool.filter((p) => {
      const mine = onItem(p.item.id);
      if (!mine.length) return itemsUsed() < allowance.maxItems;
      if (!allowance.split) return false;
      const used = mine.reduce((n, c) => n + c.value, 0);
      return used < allowance.maxPerItem && R.MODULAR_TARGETS[p.kind].some(([k]) => !mine.some((c) => c.target === k));
    });
    if (!open.length) break;
    const id = await h().chooseFromList(`${FEATS.modular} — +${left} left (${allowance.by})`, chosen.length ? "Another item, or another bonus on the same item (cancel when done):" : "Which item takes today's upgrade?", open.map((p) => [p.item.id, `${p.item.name} (${p.kind})${onItem(p.item.id).length ? ` — has +${onItem(p.item.id).map((c) => `${c.value} ${c.target}`).join(", ")}` : ""}${p.note ? ` — ${p.note}` : ""}`]));
    const pick = open.find((p) => p.item.id === id);
    if (!pick) break;
    const t = await chooseTarget(pick.kind, pick.item.name, actor, onItem(pick.item.id).map((c) => c.target));
    if (!t) break;
    const room = allowance.maxPerItem - onItem(pick.item.id).reduce((n, c) => n + c.value, 0);
    const max = Math.min(left, room);
    if (max < 1) break;
    const value = max === 1 ? 1 : int(await h().chooseFromList(FEATS.modular, `${esc(pick.item.name)}: how much of your +${left}?`, Array.from({ length: max }, (_, i) => [String(i + 1), `+${i + 1}`])));
    if (!value) break;
    chosen.push({ itemId: pick.item.id, itemName: pick.item.name, kind: pick.kind, target: t.target, skill: t.skill, value });
    left -= value;
  }
  const refusal = R.modularRefusal(chosen, allowance);
  if (!chosen.length) return false;
  if (refusal) return warn(`${FEATS.modular}: ${refusal}.`);
  for (const a of chosen) await placeUpgrade(actor, a);
  await actor.setFlag(MODULE_ID, R.MODULAR_FLAG, { day: Math.floor(worldTime() / 86400), applied: true, swapped: false, allocations: chosen });
  const weaponNote = chosen.some((a) => a.kind === "weapon") && !globalThis.game?.trgPrime?.modules?.registerWeaponEnhancement
    ? [line("<em>This core has no weapon-enhancement seam (TRG Prime 3.713.0): the weapon's upgrade is recorded here, and the GM adds it to its attacks or damage.</em>")] : [];
  await card(actor, FEATS.modular, [
    line(`Today's modular upgrades: ${chosen.map((a) => `<strong>${esc(a.itemName)}</strong> +${a.value} ${a.target === "skill" ? `(${esc(a.skill)})` : a.target.toUpperCase()}`).join("; ")}.`),
    line("<em>Item bonuses: the higher of two applies. They last until your next daily preparation, stop counting while an item is broken or unequipped, and are gone with an item that leaves your inventory.</em>"),
    ...weaponNote
  ]);
  return true;
}

/** Move one upgrade (Advanced Design's 10-minute swap, or Quick Swap). The old effect goes before the new one is placed. */
async function moveUpgrade(actor, { worn = false, title = "" } = {}) {
  const allocations = allocationsOf(actor);
  const allowance = R.modularAllowance(featNames(actor));
  const from = worn ? allocations.filter((a) => actor.items.get(a.itemId)?.system?.equipped) : allocations;
  if (!from.length) return warn(`${title}: no upgraded item${worn ? " that you are wielding or wearing" : ""}.`);
  const keyOf = (a) => `${a.itemId}|${a.target}`;
  const fromKey = await h().chooseFromList(title, "Move which upgrade?", from.map((a) => [keyOf(a), `${a.itemName} +${a.value} ${a.target === "skill" ? a.skill : a.target.toUpperCase()}`]));
  const src = from.find((a) => keyOf(a) === fromKey);
  if (!src) return false;
  // A destination may already carry an upgrade only under Integrated Modularity (A11-2), and then not the same bonus.
  const pool = (await eligibleItems(actor, { worn })).filter((p) => p.item.id !== src.itemId
    && (!allocations.some((a) => a.itemId === p.item.id) || (allowance.split && R.MODULAR_TARGETS[p.kind].some(([k]) => !allocations.some((a) => a.itemId === p.item.id && a.target === k)))));
  if (!pool.length) return warn(`${title}: no other eligible item${worn ? " that you are wielding or wearing" : ""}.`);
  const toId = await h().chooseFromList(title, `Move +${src.value} to which item?`, pool.map((p) => [p.item.id, `${p.item.name} (${p.kind})`]));
  const dest = pool.find((p) => p.item.id === toId);
  if (!dest) return false;
  const takenThere = allocations.filter((a) => a.itemId === dest.item.id).map((a) => a.target);
  const t = dest.kind === src.kind && !takenThere.includes(src.target) ? { target: src.target, skill: src.skill } : await chooseTarget(dest.kind, dest.item.name, actor, takenThere);
  if (!t) return false;
  const moved = R.modularMoved(allocations, src.itemId, { itemId: dest.item.id, itemName: dest.item.name, kind: dest.kind, target: t.target, skill: t.skill }, { fromTarget: src.target, split: allowance.split });
  if (!moved.ok) return warn(`${title}: ${moved.reason}.`);
  const refusal = R.modularRefusal(moved.allocations, allowance);
  if (refusal) return warn(`${title}: ${refusal}.`);
  // The old bonus goes before the new one is placed: both items are rewritten from the new list.
  await replaceItemUpgrades(actor, src.itemId, moved.allocations);
  await replaceItemUpgrades(actor, dest.item.id, moved.allocations);
  await actor.setFlag(MODULE_ID, R.MODULAR_FLAG, { ...modularDay(actor), allocations: moved.allocations });
  return { from: src, to: moved.allocations.find((a) => a.itemId === dest.item.id && a.target === t.target) };
}

const modularDesign = {
  hint: "Apply today's modular upgrades (normally at daily preparation).",
  async use(actor) { return applyToday(actor); }
};

const advancedDesign = {
  hint: "Once a day, spend 10 minutes moving one modular upgrade to another item.",
  async use(actor) {
    if (modularDay(actor).swapped) return warn(`${FEATS.advanced}: today's swap is spent.`);
    if (inCombat(actor)) return warn(`${FEATS.advanced}: the swap takes 10 minutes — not in combat.`);
    const out = await moveUpgrade(actor, { title: FEATS.advanced });
    if (!out) return false;
    await actor.setFlag(MODULE_ID, R.MODULAR_FLAG, { ...modularDay(actor), swapped: true });
    await card(actor, FEATS.advanced, [line(`Ten minutes' work: the +${out.to.value} moves from <strong>${esc(out.from.itemName)}</strong> to <strong>${esc(out.to.itemName)}</strong>. Today's swap is spent.`)]);
    return true;
  }
};

const integratedModularity = {
  hint: "Your Modular Design allowance is +3; Quick Swap is granted.",
  async use(actor) { return applyToday(actor); }
};

const quickSwap = {
  hint: "2 AP (manipulate): move a modular upgrade between two items you wield or wear. Prepared.",
  async use(actor, item) {
    if (!preparedReadyNow(item)) {
      const pick = await h().chooseFromList(R.QUICK_SWAP, `Quick Swap is ${preparedLine(item)}.`, [["recharge", `Recharge it (${R.PREPARED_RECHARGE_AP} AP Crafting, level DC)`], ["cancel", "Cancel"]]);
      return pick === "recharge" ? rechargePrepared(actor, item) : false;
    }
    if (inCombat(actor) && int(actor.system?.resources?.ap?.value) < R.QUICK_SWAP_AP) return warn(`${R.QUICK_SWAP}: ${R.QUICK_SWAP_AP} AP required.`);
    const out = await moveUpgrade(actor, { worn: true, title: R.QUICK_SWAP });
    if (!out) return false;
    if (!(await spendAP(actor, R.QUICK_SWAP, R.QUICK_SWAP_AP))) return false;
    await expendPrepared(item);
    await card(actor, R.QUICK_SWAP, [line(`The +${out.to.value} moves from <strong>${esc(out.from.itemName)}</strong> to <strong>${esc(out.to.itemName)}</strong> (${R.QUICK_SWAP_AP} AP). It lasts until your next daily preparation or another swap.`), line("<em>Prepared: expended.</em>")]);
    return true;
  }
};

/** The core's weapon seam (C-EA11-1): this weapon's modular upgrade and overclock, when standing. */
export function weaponEnhancementB11(weapon) {
  if (!weapon || broken(weapon)) return null;
  const out = [];
  out.push(...R.modularWeaponAnswers(mflag(weapon, R.MODULAR_ITEM_FLAG)));
  const oc = R.overclockAnswer(mflag(weapon, R.OVERCLOCK_FLAG));
  if (oc) out.push(oc);
  return out.length ? out : null;
}

/** An upgrade's or overload's effect switched off: the item unequipped (upgrade), or overloaded (its own effects). */
export function effectSuppressedB11(effect) {
  const item = effect?.parent;
  if (item?.documentName !== "Item") return false;
  if (effect.getFlag?.(MODULE_ID, "source") === R.MODULAR_EFFECT) {
    if (R.modularKind(item) && !item.system?.equipped) return true;
  }
  return overloadedNow(item);
}

/* ------------------------------------------------------------------ */
/* Overclocked Weaponry                                                 */
/* ------------------------------------------------------------------ */

const overclockedWeaponry = {
  hint: "One minute: overclock one weapon you crafted or modified (Plasma Edge, Gyroscopic Repeater or Impact Amplifier).",
  async use(actor) {
    if (inCombat(actor)) return warn(`${FEATS.overclock}: overclocking takes a minute — not in combat.`);
    const pool = (await eligibleItems(actor)).filter((p) => p.kind === "weapon");
    if (!pool.length) return warn(`${FEATS.overclock}: no weapon you are proficient with.`);
    const id = await h().chooseFromList(FEATS.overclock, "Which weapon (one you crafted or modified)?", pool.map((p) => [p.item.id, p.item.name]));
    const weapon = pool.find((p) => p.item.id === id)?.item;
    if (!weapon) return false;
    if (!(await confirm(FEATS.overclock, `You crafted or modified <strong>${esc(weapon.name)}</strong>? (The book requires it; the system cannot see it — the GM may ask.)`))) return false;
    const mode = await h().chooseFromList(FEATS.overclock, `${esc(weapon.name)}:`, R.overclockModesFor(weapon));
    if (!mode) return false;
    let element = "";
    if (mode === "plasma") {
      element = await h().chooseFromList("Plasma Edge", "Which element?", R.OVERCLOCK_ELEMENTS.map((e) => [e, e]));
      if (!element) return false;
    }
    for (const other of items(actor)) if (other.id !== weapon.id && mflag(other, R.OVERCLOCK_FLAG)) await other.unsetFlag(MODULE_ID, R.OVERCLOCK_FLAG);
    await weapon.setFlag(MODULE_ID, R.OVERCLOCK_FLAG, { mode, element, at: worldTime() });
    const seam = Boolean(globalThis.game?.trgPrime?.modules?.registerWeaponEnhancement);
    const label = R.overclockAnswer({ mode, element })?.label ?? mode;
    await card(actor, FEATS.overclock, [
      line(`A minute's work: <strong>${esc(weapon.name)}</strong> — ${esc(label)}, until your next daily preparation.`),
      ...(seam ? [] : [line("<em>This core has no weapon-enhancement seam (TRG Prime 3.713.0): the GM applies it.</em>")])
    ]);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* Power Sink, Instability Harness: the overload                        */
/* ------------------------------------------------------------------ */

/** Is this item overloaded now? (An effect on the Artificer names it; the clock ends it at the end of their next turn.) */
function overloadedNow(item) {
  const id = item?.id;
  const owner = item?.parent;
  if (!id || !owner) return false;
  return ownEffects(owner, R.OVERLOAD_EFFECT).some((e) => !e.disabled && e.getFlag?.(MODULE_ID, "itemId") === id);
}

async function overloadItem(actor, item, why) {
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData(R.OVERLOAD_EFFECT, {
    name: `Overloaded: ${item.name}`, img: "icons/svg/lightning.svg",
    description: `${why}: ${item.name} is overloaded and cannot be used until the end of your next turn. Its effects do not count meanwhile; nothing is destroyed or discharged.`,
    module: { itemId: item.id, itemName: item.name }, expiry: expiryFor("endOfNextTurn", actor)
  })]);
}

/** The magical items this Artificer holds or wears and that are not already overloaded. */
const sinkItems = (actor) => items(actor).filter((i) => R.isMagicalHeldItem(i) && !overloadedNow(i));

/** The Power Sink owners who could answer for a creature at `token` (themselves included). */
async function sinkReactors(token, { harness = false } = {}) {
  const out = [];
  if (!token) return out;
  for (const t of tokens()) {
    const owner = t.actor;
    const feat = has(owner, FEATS.powerSink);
    if (!feat || !preparedReadyNow(feat)) continue;
    if (harness && !has(owner, FEATS.harness)) continue;
    if (t !== token) {
      if (!allies(side(t), side(token))) continue;
      const d = feetBetween(t, token);
      if (d === null || d > R.POWER_SINK_FEET) continue;
    }
    if (!sinkItems(owner).length) continue;
    out.push({ token: t, owner, feat });
  }
  return out;
}

export const POWER_SINK_STEP = "eldritchArts.powerSink";

/** On the Artificer's client: pick the item, spend the reaction and the Prepared use, overload it. */
async function powerSinkStep(actor, answer, data) {
  const feat = has(actor, FEATS.powerSink);
  if (!feat || !preparedReadyNow(feat)) return { spent: false };
  const pool = sinkItems(actor);
  const id = pool.length === 1 ? pool[0].id : await h().chooseFromList(FEATS.powerSink, "Redirect it into which magical item you hold or wear?", pool.map((i) => [i.id, i.name]));
  const item = pool.find((i) => i.id === id);
  if (!item) return { spent: false };
  if (!(await h().spendReaction?.(actor, FEATS.powerSink, { traits: String(feat.system?.traits ?? "") }))) return { spent: false };
  await expendPrepared(feat);
  await overloadItem(actor, item, FEATS.powerSink);
  return { spent: true, itemName: item.name, what: data?.what ?? "" };
}

/** A save against a magic effect failed (a Failure; and Fumble or Blunder with Instability Harness). */
export const powerSinkReaction = Object.freeze({
  async after(ctx = {}) {
    if (ctx.type !== "save" || !ctx.failed || !R.saveIsMagical(ctx.check ?? {})) return null;
    const degree = norm(ctx.degree);
    const harness = !R.powerSinkDegrees().includes(degree);
    if (!R.powerSinkDegrees({ harness: true }).includes(degree)) return null;
    for (const { owner } of await sinkReactors(ctx.token ?? tokenOf(ctx.actor), { harness })) {
      const q = await h().askReactor(owner, {
        title: `${harness ? FEATS.harness : FEATS.powerSink} — ${owner.name}`,
        content: `<p><strong>${esc(ctx.actor.name)}</strong> ${esc(R.degreeVerb(degree))} ${esc(ctx.label || "a saving throw")} against a magical effect (${int(ctx.total)}).</p><p>Use <strong>Power Sink</strong> (your reaction; Prepared) to redirect it into a magical item you hold or wear? The item is overloaded until the end of your next turn, and the save is rerolled — the second result stands.</p>`,
        buttons: yesNo("Power Sink"), step: POWER_SINK_STEP, data: { what: "save" }
      });
      if (!q?.result?.spent) continue;
      return { reroll: true, label: FEATS.powerSink, line: `${esc(owner.name)}'s <strong>${harness ? `${FEATS.powerSink} (${FEATS.harness})` : FEATS.powerSink}</strong>: the effect is drawn into <strong>${esc(q.result.itemName)}</strong> (overloaded until the end of ${esc(owner.name)}'s next turn); the save is rerolled and the second result stands.` };
    }
    return null;
  }
});

/** "or suffers a Resonance Event": the event is redirected into the item (the core rolls none). */
export async function powerSinkResonance(ctx = {}) {
  const actor = ctx.actor;
  const token = tokenOf(actor);
  for (const { owner } of await sinkReactors(token)) {
    const q = await h().askReactor(owner, {
      title: `${FEATS.powerSink} — ${owner.name}`,
      content: `<p>A Magical Resonance Event is due for <strong>${esc(actor?.name ?? "a creature")}</strong>${ctx.reason ? ` (${esc(ctx.reason)})` : ""}.</p><p>Use <strong>Power Sink</strong> (your reaction; Prepared) to draw it into a magical item you hold or wear? The item is overloaded until the end of your next turn.</p>`,
      buttons: yesNo("Power Sink"), step: POWER_SINK_STEP, data: { what: "resonance" }
    });
    if (q?.result?.spent) return `${owner.name}'s Power Sink draws it into ${q.result.itemName} (overloaded until the end of their next turn)`;
  }
  return null;
}

const powerSinkUse = {
  hint: "Power Sink is asked when you or an ally within 30 ft fails a save against magic or suffers a Resonance Event. Use: recharge it.",
  async use(actor, item) {
    if (preparedReadyNow(item)) return warn(`${FEATS.powerSink} is ready; it is asked when it can be used.`);
    return rechargePrepared(actor, item);
  }
};

/* ------------------------------------------------------------------ */
/* Emergency Contraption, Flash of Insight                              */
/* ------------------------------------------------------------------ */

export const CONTRAPTION_STEP = "eldritchArts.emergencyContraption";
export const INSIGHT_STEP = "eldritchArts.flashOfInsight";

async function contraptionStep(actor) {
  const feat = has(actor, FEATS.contraption);
  if (!feat || !preparedReadyNow(feat)) return { spent: false };
  if (!(await h().spendReaction?.(actor, FEATS.contraption, { traits: String(feat.system?.traits ?? "") }))) return { spent: false };
  await expendPrepared(feat);
  return { spent: true };
}

/** A failed Disable Device check, yours or an ally's (A11-10: any ally you can see — no range is printed). */
export const contraptionReaction = Object.freeze({
  async after(ctx = {}) {
    if (ctx.type !== "skill" || !ctx.failed || !R.isDisableDevice(ctx)) return null;
    const here = ctx.token ?? tokenOf(ctx.actor);
    for (const t of tokens()) {
      const owner = t.actor;
      const feat = has(owner, FEATS.contraption);
      if (!feat || !preparedReadyNow(feat)) continue;
      if (t !== here && !(here && allies(side(t), side(here)))) continue;
      const q = await h().askReactor(owner, {
        title: `${FEATS.contraption} — ${owner.name}`,
        content: `<p><strong>${esc(ctx.actor.name)}</strong> fails ${esc(ctx.label || "a Disable Device check")} (${int(ctx.total)}).</p><p>Produce a hasty gadget (your reaction; Prepared)? The check is rerolled with a +2 item bonus, and the second result stands.</p>`,
        buttons: yesNo("Emergency Contraption"), step: CONTRAPTION_STEP, data: {}
      });
      if (!q?.result?.spent) continue;
      // ON THE REROLL ONLY: the row joins the check's modifiers now, and `reroll`
      // rolls fresh dice under them; the first total is already on the card.
      ctx.check?.modifiers?.push?.({ label: `${FEATS.contraption} (${owner.name})`, value: R.CONTRAPTION_BONUS, type: "item" });
      return { reroll: true, label: FEATS.contraption, line: `${esc(owner.name)}'s <strong>${FEATS.contraption}</strong>: rerolled with a +${R.CONTRAPTION_BONUS} item bonus; the second result stands.` };
    }
    return null;
  }
});

const contraptionUse = {
  hint: "Emergency Contraption is asked when a Disable Device check fails. Use: a sprung trap (for the GM), or recharge it.",
  async use(actor, item) {
    const ready = preparedReadyNow(item);
    const pick = await h().chooseFromList(FEATS.contraption, `Emergency Contraption is ${preparedLine(item)}.`, [
      ...(ready ? [["trap", "A trap was sprung (no failed check to reroll): post the contraption for the GM"]] : []),
      ...(!ready ? [["recharge", `Recharge it (${R.PREPARED_RECHARGE_AP} AP Crafting, level DC)`]] : [])
    ]);
    if (pick === "recharge") return rechargePrepared(actor, item);
    if (pick !== "trap") return false;
    if (!(await h().spendReaction?.(actor, FEATS.contraption, { traits: String(item.system?.traits ?? "") }))) return false;
    await expendPrepared(item);
    await card(actor, FEATS.contraption, [
      line("A trap was sprung, and you produce a hasty gadget."),
      line("<em>The trap's own check (if it calls for one — a save, a Disable Device) may be rerolled with a +2 item bonus; a trap that triggered with no failed check is not reversed by this feat. The GM decides what the gadget changes (audit A11-10).</em>")
    ]);
    return true;
  }
};

async function insightStep(actor, answer, data) {
  const feat = has(actor, FEATS.insight);
  // Once a day, and not Prepared (Graham's ruling A11-3): only the day's use gates it.
  if (!feat) return { spent: false };
  if (h().itemUsesRemaining(feat) <= 0) return { spent: false };
  const told = await askText(FEATS.insight, `Describe the inventive way your tools, knowledge or the environment help ${esc(data?.who ?? "")}. (The GM sees this.)`);
  if (!told) return { spent: false };
  await feat.update({ "system.usesValue": Math.max(0, h().itemUsesRemaining(feat) - 1) });
  return { spent: true, told };
}

/** A natural 20, by the core's own open-ended chain: the first face is 20 and the chain continues with real dice. */
async function naturalTwenty(check) {
  const roll = async () => (await new Roll("1d20").evaluate()).total;
  const faces = [20];
  let total = 20;
  for (let i = 0; i < 49; i += 1) {
    const next = await roll();
    faces.push(next);
    total += next;
    if (next < 20) break;
  }
  const chain = { faces, total, chaos: faces.slice(1).includes(1), direction: 1, exploded: true };
  check.dice = { kind: "d20", chains: [chain], chosen: chain, total, chaos: chain.chaos, unmodified: 20 };
  check.applyExtraModifier({ label: "Flash of Insight — the roll is a natural 20", value: 0, type: "untyped" });
  check.locked = FEATS.insight;
}

export const insightReaction = Object.freeze({
  async after(ctx = {}) {
    if (!R.insightWants(ctx)) return null;
    const here = ctx.token ?? tokenOf(ctx.actor);
    for (const t of tokens()) {
      const owner = t.actor;
      const feat = has(owner, FEATS.insight);
      if (!feat || h().itemUsesRemaining(feat) <= 0) continue;
      if (t !== here) {
        if (!(here && allies(side(t), side(here)))) continue;
        const d = feetBetween(t, here);
        if (d === null || d > R.INSIGHT_FEET) continue;
      }
      const q = await h().askReactor(owner, {
        title: `${FEATS.insight} — ${owner.name}`,
        content: `<p><strong>${esc(ctx.actor.name)}</strong> ${esc(R.degreeVerb(ctx.degree))} ${esc(ctx.label || `a ${ctx.type}`)} (${int(ctx.total)}).</p><p>Declare a <strong>Flash of Insight</strong> (free; today's use)? You describe your inventive help, and the roll is treated as a natural 20.</p>`,
        buttons: yesNo("Flash of Insight"), step: INSIGHT_STEP, data: { who: ctx.actor.name }
      });
      if (!q?.result?.spent) continue;
      await naturalTwenty(ctx.check);
      return { line: `${esc(owner.name)}'s <strong>${FEATS.insight}</strong>: “${esc(q.result.told)}” — the roll is a natural 20 (open-ended), now ${int(ctx.check?.outcome?.total)}: <strong>${esc(ctx.check?.outcome?.degree?.label ?? "")}</strong>. <em>GM: the description is yours to accept.</em>` };
    }
    return null;
  }
});

const insightUse = {
  hint: "Flash of Insight is asked when you or an ally within 30 ft fails or fumbles a skill check or save (once a day).",
  async use(actor, item) {
    return warn(`${FEATS.insight} ${h().itemUsesRemaining(item) > 0 ? "is ready" : "has been used today"}; it is asked when it can be used, once a day.`);
  }
};

/* ------------------------------------------------------------------ */
/* Tinkerer Precision                                                   */
/* ------------------------------------------------------------------ */

export function tinkererWork(ctx = {}) {
  return R.tinkererAnswer({ featNames: ctx.featNames ?? featNames(ctx.actor) });
}

/* ------------------------------------------------------------------ */
/* Mechanised Assistant                                                 */
/* ------------------------------------------------------------------ */

const assistantFlag = (familiar) => mflag(familiar, R.ASSISTANT_FLAG);
const isAssistant = (actor) => Boolean(assistantFlag(actor)?.masterId);
async function assistantOf(master) {
  const list = (await h().familiarsOf?.(master)) ?? [];
  return list.find((f) => assistantFlag(f)?.masterId === master?.id) ?? null;
}
const masterOf = (assistant) => globalThis.game?.actors?.get?.(assistantFlag(assistant)?.masterId) ?? null;

async function packEntry(logical, name) {
  // contentPacksFor is on the module API itself, not on its helpers (found live,
  // 0.18.1: the helpers' copy is undefined, so nothing was ever found).
  const api = globalThis.game?.trgPrime?.modules;
  for (const pack of (await api?.contentPacksFor?.(logical)) ?? []) {
    const index = await pack.getIndex();
    const hit = index.find((e) => norm(e.name) === norm(name));
    if (hit) return pack.getDocument(hit._id);
  }
  return null;
}

/**
 * The frame, the senses, the Slam, the class skills, the specialty.
 *
 * FOUND LIVE (0.18.1):
 *  - The familiar race's own grants (Nightvision, Bite (Tiny)) come back on
 *    the core's next grant sweep, which runs whenever an ability arrives — so
 *    deleting them never stuck. Darkvision and the Slam are stamped as the
 *    race's grants of those two names instead (grants.mjs alreadyGrantedNames
 *    matches on the source id and the requested name), and the originals are
 *    deleted after the core's pending sweep has run.
 *  - A familiar's class skills are derived, so writing classSkill did nothing:
 *    the Frame declares flags.trg-prime.classSkills (Crafting, Perception).
 */
async function fitOut(master, familiar, specialty) {
  // Let the familiar race's own grant pass finish first, so it cannot re-add
  // what is replaced below after the replacement.
  try {
    const { queueGrantPass } = await import("/systems/trg-prime/module/grant-autorun.mjs");
    await queueGrantPass(familiar);
  } catch { /* an older core: the stamps below still hold for later sweeps */ }
  const race = items(familiar).find((i) => i.type === "race") ?? null;
  const asGrantOf = (data, requested) => {
    if (!race) return data;
    data.flags ??= {};
    data.flags[SYSTEM_ID] = { ...(data.flags[SYSTEM_ID] ?? {}), grantedBy: { sourceId: race.id, sourceName: race.name, requested } };
    return data;
  };
  const frame = await packEntry("abilities", R.ASSISTANT_FRAME);
  const add = [];
  if (frame) add.push(frame.toObject());
  const dark = await packEntry("abilities", "Darkvision");
  if (dark) add.push(asGrantOf(dark.toObject(), "Nightvision"));
  // THE CORE'S "Slam", sized to the printed "Slam (Small) +1 (1d6 bludgeoning)":
  // the +1 is the attack's total, derived as every natural attack's is.
  const slam = (await packEntry("creature-attacks", "Slam")) ?? (await packEntry("weapons", "Slam"));
  if (slam) {
    const data = slam.toObject();
    data.name = R.ASSISTANT_PROFILE.attack.name;
    data.system = { ...data.system, damage: R.ASSISTANT_PROFILE.attack.damage, damageType: R.ASSISTANT_PROFILE.attack.damageType, size: R.ASSISTANT_PROFILE.size, natural: true, equipped: true };
    add.push(asGrantOf(data, "Bite (Tiny)"));
  }
  if (add.length) await familiar.createEmbeddedDocuments("Item", add, { eaAssistant: true });
  // Only what was replaced goes: a missing Darkvision or Slam leaves the original.
  const replaced = [dark ? "Nightvision" : "", slam ? "Bite (Tiny)" : ""].filter(Boolean);
  const drop = items(familiar).filter((i) => replaced.some((n) => norm(n) === norm(i.name))).map((i) => i.id);
  if (drop.length) await familiar.deleteEmbeddedDocuments("Item", drop);
  await familiar.update({ "system.identity.size": R.ASSISTANT_PROFILE.size, "prototypeToken.width": 1, "prototypeToken.height": 1 });
  await familiar.setFlag(MODULE_ID, R.ASSISTANT_FLAG, { masterId: master.id, specialty, improvements: [], hands: true, sense: "" });
  return { missing: [frame ? "" : R.ASSISTANT_FRAME, dark ? "" : "Darkvision", slam ? "" : R.ASSISTANT_PROFILE.attack.name].filter(Boolean) };
}

async function buildAssistant(master, feat) {
  const familiar = await h().createFamiliarFor(master, feat);
  if (!familiar) return null;
  const specialty = await h().chooseFromList(FEATS.assistant, "Its one specialty (chosen once):", R.ASSISTANT_SPECIALTIES);
  const { missing } = await fitOut(master, familiar, specialty || "");
  if (specialty === "scoutOptics") await chooseScoutSense(familiar);
  await syncToolArmature(master);
  await card(master, FEATS.assistant, [
    line(missing.length
      ? `<strong>${esc(familiar.name)}</strong> is built, but <strong>incomplete</strong>: see below.`
      : `<strong>${esc(familiar.name)}</strong> is built: Small, speed 20, Darkvision, Str 0 Dex 1 Con 1 Int 0 Wis 2 Cha −2, Base DR 2, Slam (Small) 1d6 bludgeoning, Crafting and Perception as class skills, and hands. It is your familiar in every other way (your level, saves, BAB, BDB and skills).`),
    ...(specialty ? [line(`Specialty: <strong>${esc(R.ASSISTANT_SPECIALTIES.find(([k]) => k === specialty)?.[1] ?? specialty)}</strong>.`)] : []),
    line("<em>Unlike an ordinary familiar it does not pick familiar abilities now: it chooses one improvement at your 4th level and every 4 levels after (its Use). The familiar card above (its two ability picks and the 600 gp summoning cost) does not apply to it.</em>"),
    ...(missing.length ? [line(`<em>Not found in the compendiums, so not placed: ${esc(missing.join(", "))} — add it by hand.</em>`)] : [])
  ]);
  return familiar;
}

async function chooseScoutSense(familiar) {
  const sense = await h().chooseFromList("Scout Optics", "Its additional sense (and Tracking as a class skill):", [...R.SCOUT_SENSES.map((s) => [s, s]), ["other", "Another sense (the GM adds it by hand)"]]);
  if (!sense) return;
  if (sense === "other") { await familiar.setFlag(MODULE_ID, R.ASSISTANT_FLAG, { ...assistantFlag(familiar), sense: "other (GM)" }); await scoutClassSkill(familiar); return; }
  const entry = await packEntry("abilities", sense);
  if (entry) await familiar.createEmbeddedDocuments("Item", [entry.toObject()], { eaAssistant: true });
  await familiar.setFlag(MODULE_ID, R.ASSISTANT_FLAG, { ...assistantFlag(familiar), sense });
  await scoutClassSkill(familiar);
}

/**
 * Scout Optics' class skill (Survival, A11-8), declared on the Frame beside
 * Crafting and Perception.
 *
 * FOUND LIVE (0.18.3): the Frame is an entry of the federated `abilities` pack,
 * so the core's Codex inheritance (codex-inheritance.mjs) lays the entry's
 * `flags.trg-prime` over every copy at prepare time — the Survival written to
 * this copy was saved but never seen. This copy opts out
 * (`codexInherit: false`, the core's documented switch for "a copy that
 * genuinely differs"), and the list is read from the stored data, not the
 * overlaid one.
 */
async function scoutClassSkill(familiar) {
  const frame = items(familiar).find((i) => norm(i.name) === norm(R.ASSISTANT_FRAME));
  if (!frame) return;
  const stored = frame._source?.flags?.[SYSTEM_ID]?.classSkills;
  const have = Array.isArray(stored) ? stored : ["Crafting", "Perception"];
  const list = have.includes(R.SCOUT_CLASS_SKILL) ? have : [...have, R.SCOUT_CLASS_SKILL];
  await frame.update({ [`flags.${SYSTEM_ID}.classSkills`]: list, [`flags.${SYSTEM_ID}.codexInherit`]: false });
}

async function improveAssistant(master, familiar) {
  const flag = assistantFlag(familiar) ?? {};
  const taken = Array.isArray(flag.improvements) ? flag.improvements : [];
  const earned = R.assistantImprovements(levelOf(master));
  if (taken.length >= earned) return warn(`${FEATS.assistant}: ${earned ? `all ${earned} improvement${earned === 1 ? "" : "s"} earned so far are chosen` : "the first improvement comes at 4th level"}.`);
  const options = [...R.ASSISTANT_FAMILIAR_CHOICES, ...R.ASSISTANT_OWN_CHOICES].filter((n) => R.improvementOpen(n, taken));
  const pick = await h().chooseFromList(FEATS.assistant, `Improvement ${taken.length + 1} of ${earned}:`, options.map((n) => [n, n]));
  if (!pick) return false;
  const entry = (await packEntry("abilities", pick)) ?? (await packEntry("familiars", pick));
  if (entry) await familiar.createEmbeddedDocuments("Item", [entry.toObject()], { eaAssistant: true });
  await familiar.setFlag(MODULE_ID, R.ASSISTANT_FLAG, { ...flag, improvements: [...taken, pick] });
  await card(master, FEATS.assistant, [line(`<strong>${esc(familiar.name)}</strong> gains <strong>${esc(pick)}</strong>${entry ? "" : " <em>(not found in the compendiums — add it by hand)</em>"}.`)]);
  return true;
}

async function rebuildAssistant(master, feat, familiar) {
  if (inCombat(master)) return warn(`${FEATS.assistant}: rebuilding takes 8 hours of uninterrupted work.`);
  // THE COST (Graham's ruling A11-7): the Equipment Cost Table (Core Rulebook p. 173) at the master's level.
  const level = levelOf(master);
  const cost = R.rebuildCost(level);
  const purse = cost ? Number(await h().goldOf?.(master) ?? 0) : 0;
  if (cost && purse < cost) return warn(`${FEATS.assistant}: rebuilding costs ${cost} gp (Equipment Cost Table, level ${level}); ${master.name} has ${purse} gp.`);
  if (!(await confirm(FEATS.assistant, `Rebuild your assistant: 8 hours of uninterrupted work and <strong>${cost} gp</strong> (the Equipment Cost Table, Core Rulebook p. 173, at level ${level}), taken from your purse. Begin?`))) return false;
  if (cost) {
    const paid = await h().deductGold?.(master, cost);
    if (!paid?.paid) return warn(`${FEATS.assistant}: the ${cost} gp could not be paid (short by ${paid?.shortfallGP ?? "?"} gp).`);
  }
  if (familiar) await familiar.delete();
  const built = await buildAssistant(master, feat);
  if (built) await card(master, FEATS.assistant, [line(`After 8 hours of work, <strong>${esc(built.name)}</strong> is rebuilt. <strong>${cost} gp</strong> paid (Equipment Cost Table, level ${level}).`)]);
  return Boolean(built);
}

const mechanisedAssistant = {
  hint: "Build your assistant; choose an improvement; rebuild it; retrieve a stored item.",
  async use(actor, item) {
    const familiar = await assistantOf(actor);
    if (!familiar) {
      const other = ((await h().familiarsOf?.(actor)) ?? []).filter((f) => !isAssistant(f));
      if (other.length) return warn(`${FEATS.assistant}: you already have a familiar (${other.map((f) => f.name).join(", ")}); the core allows one, so the assistant cannot be built beside it.`);
      return buildAssistant(actor, item);
    }
    const dead = await h().isDead?.(familiar);
    const what = await h().chooseFromList(FEATS.assistant, `${esc(familiar.name)}${dead ? " (destroyed)" : ""}:`, [
      ...(dead ? [] : [["improve", "Choose an improvement (4th level and every 4 levels)"]]),
      ...(!dead && items(familiar).some((i) => norm(i.name) === norm(R.ASSISTANT_ABILITIES.storage)) ? [["retrieve", "Retrieve a stored item (as part of a command)"]] : []),
      ["rebuild", dead ? "Rebuild it (8 hours of work)" : "It was destroyed: rebuild it (8 hours of work)"]
    ]);
    if (what === "improve") return improveAssistant(actor, familiar);
    if (what === "retrieve") return retrieveStored(actor, familiar);
    if (what === "rebuild") return rebuildAssistant(actor, item, familiar);
    return false;
  }
};

/** Storage: items it carries, up to 10 lbs. */
const storedOn = (familiar) => items(familiar).filter((i) => i.system?.quantity !== undefined && ["gear", "weapon", "consumable", "armour", "shield", "loot", "ammunition"].includes(i.type));
async function retrieveStored(master, familiar) {
  const pool = storedOn(familiar);
  if (!pool.length) return warn(`${familiar.name} carries nothing.`);
  const id = await h().chooseFromList("Storage", `${esc(familiar.name)} hands you:`, pool.map((i) => [i.id, `${i.name} (${Number(i.system?.weight ?? 0)} lb)`]));
  const it = pool.find((i) => i.id === id);
  if (!it) return false;
  await master.createEmbeddedDocuments("Item", [it.toObject()]);
  await familiar.deleteEmbeddedDocuments("Item", [it.id]);
  await card(master, "Storage", [line(`<strong>${esc(familiar.name)}</strong> retrieves <strong>${esc(it.name)}</strong> for you as part of your command.`)]);
  return true;
}

/** Hooks.on("preCreateItem"): an assistant with Storage refuses what would take it past 10 lbs. */
export function onPreCreateItemB11(item, data = {}, options = {}) {
  const actor = item?.parent;
  if (!isAssistant(actor) || item.type === "race") return true;
  // ONLY ITS OWN (Graham's ruling A11-8): the assistant takes the improvements
  // its Use offers and nothing else — no familiar picks from its sheet, and no
  // other feature's grant. Its Use creates them with { eaAssistant: true }; the
  // core's own grants of its race (Empathic Link) carry grantedBy.
  if (item.type === "ability" || item.type === "feat") {
    if (options?.eaAssistant === true || item.flags?.[SYSTEM_ID]?.grantedBy) return true;
    globalThis.ui?.notifications?.warn(`${actor.name} is a Mechanised Assistant: it gains only the improvements its feat's Use offers (${item.name} was not added).`);
    return false;
  }
  if (!items(actor).some((i) => norm(i.name) === norm(R.ASSISTANT_ABILITIES.storage))) {
    if (["gear", "weapon", "consumable", "loot", "ammunition"].includes(item.type) && !(item.system?.natural)) {
      globalThis.ui?.notifications?.warn(`${actor.name} has no Storage: it cannot carry items for you.`);
      return false;
    }
    return true;
  }
  const carried = storedOn(actor).map((i) => Number(i.system?.weight ?? 0) * Math.max(1, Number(i.system?.quantity ?? 1)));
  const add = Number(item.system?.weight ?? 0) * Math.max(1, Number(item.system?.quantity ?? 1));
  if (!R.storageFits(carried, add)) {
    globalThis.ui?.notifications?.warn(`${actor.name}'s Storage holds ${R.STORAGE_LBS} lbs: ${item.name} does not fit.`);
    return false;
  }
  return true;
}

/** "Cannot be healed by magical healing": a spell's healing on the assistant is taken back, and said. */
export async function onSpellHealedB11(ctx = {}) {
  const target = ctx.target ?? ctx.actor;
  if (!isAssistant(target) || !isActingGM()) return;
  const amount = int(ctx.amount ?? ctx.healed);
  if (amount <= 0) return;
  const hp = int(target.system?.resources?.hp?.value);
  await target.update({ "system.resources.hp.value": Math.max(0, hp - amount) });
  await card(target, FEATS.assistant, [line(`<strong>${esc(target.name)}</strong> is a construct and cannot be healed by magical healing (${amount} HP returned). Repair it with a Crafting check.`)]);
}

/** Tool Armature: +2 item to the master's Crafting while the assistant is adjacent. */
export const TOOL_ARMATURE_EFFECT = "eaToolArmature";
export async function syncToolArmature(master) {
  if (!master?.isOwner) return;
  const familiar = await assistantOf(master);
  const want = familiar && assistantFlag(familiar)?.specialty === "toolArmature" && !(await h().isDead?.(familiar));
  let adjacent = false;
  if (want) {
    const a = tokenOf(master);
    const b = tokenOf(familiar);
    const d = a && b ? feetBetween(a, b) : null;
    adjacent = d !== null && d <= 5;
  }
  const held = ownEffects(master, TOOL_ARMATURE_EFFECT);
  if (adjacent && !held.length) {
    await master.createEmbeddedDocuments("ActiveEffect", [effectData(TOOL_ARMATURE_EFFECT, {
      name: `Tool Armature (${familiar.name})`, img: "modules/trg-eldritch-arts/assets/feats/class.png",
      description: "+2 item bonus to your Crafting checks while your Mechanised Assistant is adjacent to you.",
      changes: [{ key: "system.skills.crafting.item", mode: 0, value: String(R.TOOL_ARMATURE_BONUS), priority: 20 }]
    })]);
  } else if (!adjacent && held.length) {
    await master.deleteEmbeddedDocuments("ActiveEffect", held.map((e) => e.id));
  }
}

/** Hooks.on("updateToken"): the master or the assistant moved — Tool Armature follows. */
export async function onTokenMovedB11(tokenDoc) {
  const actor = tokenDoc?.actor;
  // THE ACTING GM ALONE (the hook fires on every client; two owners would each make the effect).
  if (!actor || !isActingGM()) return;
  if (isAssistant(actor)) { const m = masterOf(actor); if (m) await syncToolArmature(m); return; }
  if (has(actor, FEATS.assistant)) await syncToolArmature(actor);
}

/** Spell Relay Node (a cast option): a line or area spell may originate from the assistant within 60 ft and in sight. */
export const relayNodeOption = Object.freeze({
  async offer(ctx = {}) {
    const { actor, spellData } = ctx;
    if (!actor || ctx.itemCast || !R.relayEligible(spellData ?? {})) return null;
    const familiar = await assistantOf(actor);
    if (!familiar || assistantFlag(familiar)?.specialty !== "relayNode" || (await h().isDead?.(familiar))) return null;
    const a = tokenOf(actor);
    const b = tokenOf(familiar);
    const d = a && b ? feetBetween(a, b) : null;
    if (d === null || d > R.RELAY_NODE_FEET) return null;
    let sight = true;
    try { sight = !globalThis.CONFIG?.Canvas?.polygonBackends?.sight?.testCollision?.(a.center, b.center, { type: "sight", mode: "any" }); } catch { /* unknown: allowed, said on the card */ }
    if (!sight) return null;
    return { label: `Spell Relay Node: originate from ${familiar.name}`, hint: `${familiar.name} is ${d} ft away and in sight. You remain the caster; PP, DC and components are yours.` };
  },
  async apply(ctx = {}) {
    const familiar = await assistantOf(ctx.actor);
    return { label: "Spell Relay Node", lines: [`The spell's line or area originates from <strong>${esc(familiar?.name ?? "the assistant")}</strong> (Spell Relay Node): place its template from the assistant's position. You are still the caster.`] };
  }
});

/** The familiar modifier: none on its numbers (the frame's effect carries the profile); kept for a future HP/save rule. */
export function assistantModifier() { return null; }

/* ------------------------------------------------------------------ */
/* Runemage                                                             */
/* ------------------------------------------------------------------ */

/** Hooks.on("trgPrimeSpellSettled"): a Symbol cast is remembered (Runic Anchor); a Triggered Sigil's cast clears its designation. */
export async function onSpellSettledB11(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner || !ctx.spell || ctx.refunded) return;
  // A cast ends the daily preparation's window for Triggered Sigil (A11-9).
  const win = mflag(actor, R.PREP_WINDOW_FLAG);
  if (win && !win.closed) await actor.setFlag(MODULE_ID, R.PREP_WINDOW_FLAG, { ...win, closed: true });
  if (isRunemageActor(actor) && R.usesSymbol(ctx.spellData ?? ctx.spell.system ?? {}, { innate: Boolean(ctx.innate) }) && !ctx.itemCast) {
    const map = { ...(mflag(actor, R.SYMBOL_CASTS_FLAG) ?? {}) };
    const t = worldTime();
    for (const [k, r] of Object.entries(map)) if (t - Number(r?.at ?? 0) > R.SYMBOL_CAST_MEMORY_SECONDS) delete map[k];
    map[String(ctx.castId ?? ctx.spell.id)] = { spellId: ctx.spell.id, name: ctx.spell.name, at: t };
    await actor.setFlag(MODULE_ID, R.SYMBOL_CASTS_FLAG, map);
  }
  if (ctx.preparedSymbol && has(actor, FEATS.triggered)) {
    const feat = has(actor, "Prepared Sigil");
    const list = Array.isArray(mflag(feat, SIGILS_FLAG)) ? mflag(feat, SIGILS_FLAG) : [];
    if (list.some((s) => s.spellId === ctx.spell.id && s.triggered)) {
      await feat.setFlag(MODULE_ID, SIGILS_FLAG, list.map((s) => (s.spellId === ctx.spell.id ? { ...s, triggered: null } : s)));
    }
  }
  await arcanePrepSettled(ctx);
  await recordTrace(ctx);
}

/** Runic Anchor: before a Spell Concentration check, asked which spell it is for. */
export const runicAnchorReaction = Object.freeze({
  async before(ctx = {}) {
    const actor = ctx.actor;
    if (ctx.type !== "skill" || norm(ctx.check?.actionKey) !== "spellconcentration" || !has(actor, FEATS.anchor) || !actor?.isOwner) return null;
    const casts = R.liveSymbolCasts(mflag(actor, R.SYMBOL_CASTS_FLAG) ?? {}, worldTime());
    if (!casts.length) return null;
    const pick = await h().chooseFromList(FEATS.anchor, "Is this Spell Concentration check to retain, sustain or recover a spell you cast with a Symbol?", [...casts.map((c) => [c.key, c.name]), ["none", "Another spell (no bonus)"]]);
    const cast = casts.find((c) => c.key === pick);
    if (!cast) return null;
    return { modifiers: [{ label: `${FEATS.anchor} (${cast.name})`, value: R.RUNIC_ANCHOR_BONUS, type: "class" }], line: `<strong>${FEATS.anchor}</strong>: +${R.RUNIC_ANCHOR_BONUS} class — ${esc(cast.name)} was cast with your Symbol.` };
  }
});

/** Grand Inscription's cast option: required on a Symbol cast, +1 more to the Save DC (the Runemage's +1 becomes +2). */
export const grandInscriptionOption = Object.freeze({
  async offer(ctx = {}) {
    const { actor, spellData } = ctx;
    if (!has(actor, FEATS.grand) || !isRunemageActor(actor) || ctx.itemCast) return null;
    if (!R.usesSymbol(spellData ?? {}, { innate: Boolean(ctx.innate) })) return null;
    // Only a spell with a saving throw has a Save DC to raise (found live, 0.18.1:
    // Magic Missile's card carried the line).
    if (!/fort|reflex|will|save/.test(norm(spellData?.defence))) return null;
    return { label: "Grand Inscription: the Runemage's +1 Save DC is +2", hint: "Applied to every Symbol cast; it replaces the +1.", required: true };
  },
  async apply() {
    return { saveDC: R.GRAND_SAVE_DC_EXTRA, label: "Grand Inscription (Runemage +1 → +2)", lines: ["Grand Inscription: the Runemage's Save DC increase is +2, not +1."] };
  }
});

/** Hooks.on("updateActor"): a queued Runemage identify bonus is +4 while Grand Inscription is held, +2 when it is not. */
export async function onActorUpdatedB11(actor, change = {}, options = {}, userId = null) {
  // ONE WRITER: the client that made the change (the hook fires on every client).
  if (!actor?.isOwner || (userId && userId !== globalThis.game?.user?.id)) return;
  const pending = globalThis.foundry?.utils?.getProperty?.(change, `flags.${SYSTEM_ID}.pendingModifiers`);
  if (pending === undefined) return;
  const out = has(actor, FEATS.grand) ? R.grandIdentifyRewrite(pending) : R.grandIdentifyRestore(pending);
  if (out.changed) await actor.setFlag(SYSTEM_ID, "pendingModifiers", out.pending);
}

/** Grand Inscription gained (0.18.1, found live): a +2 already queued becomes the +4. */
export async function onItemCreatedB11(item, options = {}, userId = null) {
  const actor = item?.parent;
  if (!actor?.isOwner || (userId && userId !== globalThis.game?.user?.id)) return;
  if (item.type !== "feat" || norm(item.name) !== norm(FEATS.grand)) return;
  const out = R.grandIdentifyRewrite(actor.getFlag?.(SYSTEM_ID, "pendingModifiers") ?? []);
  if (out.changed) await actor.setFlag(SYSTEM_ID, "pendingModifiers", out.pending);
}

/** Grand Inscription removed: any queued +4 returns to the Runemage's +2. */
export async function onItemDeletedB11(item, options = {}, userId = null) {
  const actor = item?.parent;
  if (!actor?.isOwner || (userId && userId !== globalThis.game?.user?.id)) return;
  if (item.type === "feat" && norm(item.name) === norm(FEATS.grand)) {
    const out = R.grandIdentifyRestore(actor.getFlag?.(SYSTEM_ID, "pendingModifiers") ?? []);
    if (out.changed) await actor.setFlag(SYSTEM_ID, "pendingModifiers", out.pending);
  }
  // A MODULAR UPGRADE ON A LOST ITEM: the allocation goes with it.
  const allocations = allocationsOf(actor);
  if (allocations.some((a) => a.itemId === item.id)) {
    await actor.setFlag(MODULE_ID, R.MODULAR_FLAG, { ...modularDay(actor), allocations: allocations.filter((a) => a.itemId !== item.id) });
  }
}

const grandInscriptionUse = {
  hint: "Queue the +4 class bonus for a check to identify runic symbols (it replaces the Runemage's +2).",
  async use(actor) {
    const list = (actor.getFlag?.(SYSTEM_ID, "pendingModifiers") ?? []).filter((p) => !norm(p?.label).startsWith(norm(R.RUNEMAGE_IDENTIFY_LABEL)));
    await actor.setFlag(SYSTEM_ID, "pendingModifiers", list);
    await h().addPendingModifier(actor, { value: R.GRAND_IDENTIFY_VALUE, type: "class", label: `${R.RUNEMAGE_IDENTIFY_LABEL} — Grand Inscription`, scope: "One check made to identify runic symbols", oneShot: true });
    await card(actor, FEATS.grand, [line(`A <strong>+${R.GRAND_IDENTIFY_VALUE} class bonus</strong> is queued for your next check to identify runic symbols (in place of the Runemage's +2).`)]);
    return true;
  }
};

/* Triggered Sigil ----------------------------------------------------- */

const sigilFeat = (actor) => has(actor, "Prepared Sigil");
const sigilsOf = (feat) => (Array.isArray(mflag(feat, SIGILS_FLAG)) ? mflag(feat, SIGILS_FLAG) : []);

async function designateTrigger(actor) {
  const feat = sigilFeat(actor);
  const list = sigilsOf(feat);
  if (!R.prepWindowOpen(mflag(actor, R.PREP_WINDOW_FLAG), { worldTime: worldTime(), inCombat: inCombat(actor) })) {
    return warn(`${FEATS.triggered}: a sigil is designated during your daily preparation — after inscribing today's sigils and before you cast a spell, enter combat or an hour passes. Today's chance has gone.`);
  }
  if (!feat || !list.length) return warn(`${FEATS.triggered}: inscribe today's Prepared Sigils first (Prepared Sigil's Use).`);
  if (list.some((s) => s.triggered)) return warn(`${FEATS.triggered}: today's Triggered Sigil is already designated.`);
  const pool = [];
  for (const s of list.filter((x) => x.state === "ready")) {
    const spell = actor.items.get(s.spellId);
    const ok = spell ? R.triggeredSpellEligible(spell.system ?? {}) : { ok: false, reason: "the spell is gone" };
    pool.push({ s, spell, ok });
  }
  const fit = pool.filter((p) => p.ok.ok);
  if (!fit.length) return warn(`${FEATS.triggered}: none of today's sigils fits (${pool.map((p) => `${p.s.name}: ${p.ok.reason}`).join("; ")}).`);
  const id = await h().chooseFromList(FEATS.triggered, "Which Prepared Sigil waits for its trigger?", fit.map((p) => [p.s.spellId, p.s.name]));
  const pick = fit.find((p) => p.s.spellId === id);
  if (!pick) return false;
  const trigger = await h().chooseFromList(FEATS.triggered, "Its trigger (simple, observable, involving you):", R.TRIGGER_CHOICES);
  if (!trigger) return false;
  let text = R.TRIGGER_CHOICES.find(([k]) => k === trigger)?.[1] ?? trigger;
  if (trigger === "other") { const said = await askText(FEATS.triggered, "Describe the trigger (the GM sees this):"); if (!said) return false; text = said; }
  await feat.setFlag(MODULE_ID, SIGILS_FLAG, list.map((s) => (s.spellId === pick.s.spellId ? { ...s, triggered: { trigger, text } } : s)));
  await card(actor, FEATS.triggered, [
    line(`<strong>${esc(pick.s.name)}</strong> waits as a Triggered Sigil: <em>${esc(text)}</em>.`),
    line(R.DETECTED_TRIGGERS.includes(trigger) ? "<em>You are asked when it happens.</em>" : "<em>When it happens, activate it from Triggered Sigil's Use.</em>")
  ]);
  return true;
}

/** Activate: the reaction, the one-sigil-a-round lock, then the sigil's cast (PP, range, targets as normal). */
async function activateTriggered(actor, { trigger = "", targetIds = [] } = {}) {
  const feat = sigilFeat(actor);
  const sigil = sigilsOf(feat).find((s) => s.triggered && (!trigger || s.triggered.trigger === trigger));
  if (!sigil) return warn(`${FEATS.triggered}: no designated sigil${trigger ? " for that trigger" : ""}.`);
  const t = sigilNow(actor);
  if (!sigilReady(sigil, t)) return warn(`${FEATS.triggered}: the sigil is not ready.`);
  if (sigilLockHeld(mflag(feat, SIGIL_LOCK_FLAG), t)) return warn(`${FEATS.triggered}: a Prepared Sigil was already activated this round.`);
  const spell = actor.items.get(sigil.spellId);
  if (!spell) return warn(`${FEATS.triggered}: the spell is no longer yours.`);
  if (!(await h().spendReaction?.(actor, FEATS.triggered, { traits: String(spell.system?.traits ?? "") }))) return false;
  await feat.setFlag(MODULE_ID, SIGIL_LOCK_FLAG, roundStamp(t));
  // THE REACTION IS THE CAST'S TIME (A11-9): `apPaid`, as a readied cast's
  // is; the spell's PP, range, line of sight and targets are the cast's own.
  const result = await h().castSpell(actor, spell, { preparedSymbol: { label: FEATS.triggered }, reaction: { presetTargets: targetIds.length > 0 }, apPaid: true });
  return Boolean(result);
}

const triggeredSigil = {
  hint: "Designate today's Triggered Sigil, or activate it when its trigger happens (a reaction).",
  async use(actor) {
    const feat = sigilFeat(actor);
    const designated = sigilsOf(feat).find((s) => s.triggered);
    const pick = await h().chooseFromList(FEATS.triggered, designated ? `${esc(designated.name)} waits for: ${esc(designated.triggered.text)}.` : "No sigil is designated today.", [
      ...(designated ? [["activate", "Its trigger has happened: activate it (reaction)"]] : [["designate", "Designate one of today's Prepared Sigils"]])
    ]);
    if (pick === "designate") return designateTrigger(actor);
    if (pick === "activate") return activateTriggered(actor);
    return false;
  }
};

/** "becoming the target of an attack": the core's defence offer, asked of the defender before the roll. */
const targetedSigil = (actor) => sigilsOf(sigilFeat(actor)).find((s) => s.triggered?.trigger === "targeted") ?? null;
export const triggeredTargetedOffer = Object.freeze({
  label: "Triggered Sigil",
  summary: "Your Triggered Sigil waits for this: cast its spell as your reaction.",
  against: "attack",
  find: (actor) => (targetedSigil(actor) ? has(actor, FEATS.triggered) : null),
  requires: (actor) => {
    const sigil = targetedSigil(actor);
    if (!sigil) return "no sigil waits for an attack";
    const t = sigilNow(actor);
    if (!sigilReady(sigil, t)) return "the sigil is not ready";
    if (sigilLockHeld(mflag(sigilFeat(actor), SIGIL_LOCK_FLAG), t)) return "a Prepared Sigil was already activated this round";
    return null;
  },
  use: (actor) => activateTriggered(actor, { trigger: "targeted" })
});

export const TRIGGER_STEP = "eldritchArts.triggeredSigil";
async function triggerStep(actor, answer, data) {
  return { spent: Boolean(await activateTriggered(actor, { trigger: String(data?.trigger ?? "") })) };
}

/** Hooks.on("trgPrimeDamageApplied"): "being struck" — a Strike's damage. Asked of the struck creature's player. */
export async function onDamageAppliedB11(ctx = {}) {
  const actor = ctx.actor;
  if (!actor || !isActingGM() || norm(ctx.context?.kind) !== "strike" || !(int(ctx.amount) > 0)) return;
  const sigil = sigilsOf(sigilFeat(actor)).find((s) => s.triggered?.trigger === "struck");
  if (!sigil || !sigilReady(sigil, sigilNow(actor))) return;
  await h().askReactor(actor, {
    title: `${FEATS.triggered} — ${actor.name}`,
    content: `<p>You are struck${ctx.sourceName ? ` by ${esc(ctx.sourceName)}` : ""}.</p><p>Activate your Triggered Sigil of <strong>${esc(sigil.name)}</strong> (your reaction; the spell's PP, range and targets as normal)?</p>`,
    buttons: yesNo(FEATS.triggered), step: TRIGGER_STEP, data: { trigger: "struck" }
  });
}

/* ------------------------------------------------------------------ */
/* Ascendan                                                             */
/* ------------------------------------------------------------------ */

/** Ley Resonance's module metamagic (Block 6's G1 shape): within 60 ft of a ley line or linked, a Focus use. */
export const leyResonanceMetamagic = Object.freeze({
  feat: FEATS.leyResonance,
  label: "Ley Resonance",
  hint: "Draw on the ley line: pay 1 PP less (2 with Perfected Arcane Memory); the casting DC falls with it; the Save DC does not.",
  focus: true,
  async applies(ctx = {}) {
    const actor = ctx.actor;
    if (!has(actor, FEATS.leyResonance) || ctx.itemCast || ctx.cantrip) return false;
    if (leyBenefitOf(actor)) return true;
    const t = tokenOf(actor);
    return Boolean(t && (await leyLinesWithin(t, R.LEY_RESONANCE_FEET)).length);
  },
  async apply(ctx = {}) {
    const out = R.leyResonanceAnswer(ctx.castPP, R.leyResonancePP(featNames(ctx.actor)));
    if (!out) return { lines: ["Ley Resonance: the spell already costs 1 PP; nothing to take off."] };
    return { discount: out.discount, dcDelta: out.dcDelta, lines: [`Ley Resonance: ${out.pp} PP less to pay; the Casting DC ${out.dcDelta} with it; the Save DC is unchanged.`] };
  }
});

/* Arcane Preparation --------------------------------------------------- */

const arcanePrepEffect = (actor) => ownEffects(actor, R.ARCANE_PREP_EFFECT).find((e) => !e.disabled) ?? null;

const arcanePreparation = {
  hint: "1 AP: +2 circumstance to your next Spellcraft check to cast a chosen arcane or ethereal spell (before the end of your next turn).",
  async use(actor) {
    const spells = items(actor).filter((i) => i.type === "spell" && R.arcanePrepSpell(i.system ?? {}));
    if (!spells.length) return warn(`${FEATS.arcanePrep}: you know no arcane or ethereal spell.`);
    const id = await h().chooseFromList(FEATS.arcanePrep, "Which spell do you intend to cast before the end of your next turn?", spells.map((s) => [s.id, s.name]));
    const spell = spells.find((s) => s.id === id);
    if (!spell) return false;
    if (!(await spendAP(actor, FEATS.arcanePrep, 1))) return false;
    const old = ownEffects(actor, R.ARCANE_PREP_EFFECT).map((e) => e.id);
    if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old);
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(R.ARCANE_PREP_EFFECT, {
      name: `Arcane Preparation: ${spell.name}`, img: "modules/trg-eldritch-arts/assets/feats/racial.png",
      description: `+2 circumstance to your next Spellcraft check to cast ${spell.name}. Lost if you cast another spell, fall unconscious, or reach the end of your next turn.`,
      module: { spellId: spell.id, spellName: spell.name }, expiry: expiryFor("endOfNextTurn", actor)
    })]);
    await card(actor, FEATS.arcanePrep, [line(`You study the structure of <strong>${esc(spell.name)}</strong> (1 AP): your next Spellcraft check to cast it gains +2 circumstance.`)]);
    return true;
  }
};

/** The spell-check gate: +2 circumstance on the prepared spell's check, once; another spell ends the preparation. */
export async function arcanePrepGate(ctx = {}) {
  const actor = ctx.actor;
  const e = arcanePrepEffect(actor);
  if (!e || ctx.itemCast || !ctx.spell) return null;
  const spellId = e.getFlag?.(MODULE_ID, "spellId");
  if (ctx.spell.id !== spellId) return null;
  await e.setFlag(MODULE_ID, "used", true);
  return { modifiers: [{ label: FEATS.arcanePrep, value: R.ARCANE_PREP_BONUS, type: "circumstance" }], lines: [`${FEATS.arcanePrep}: +${R.ARCANE_PREP_BONUS} circumstance (once).`] };
}

/** Settled: the preparation is spent on its own spell, and lost on any other. */
async function arcanePrepSettled(ctx = {}) {
  const e = arcanePrepEffect(ctx.actor);
  if (!e || ctx.itemCast) return;
  await ctx.actor.deleteEmbeddedDocuments("ActiveEffect", [e.id]).catch(() => {});
  if (ctx.spell?.id !== e.getFlag?.(MODULE_ID, "spellId")) await card(ctx.actor, FEATS.arcanePrep, [line(`You cast another spell: the preparation of <strong>${esc(e.getFlag?.(MODULE_ID, "spellName") ?? "")}</strong> is lost.`)]);
}

/** Hooks.on("createActiveEffect"): Unconscious ends the preparation. */
export async function onEffectCreatedB11(effect, options = {}, userId = null) {
  const actor = effect?.parent;
  if (!actor?.isOwner || actor.documentName !== "Actor") return;
  // ONE WRITER: the client that made the effect (0.18.1, now that a card is posted).
  if (userId && userId !== globalThis.game?.user?.id) return;
  const statuses = Array.from(effect.statuses ?? []);
  const cond = effect.getFlag?.(SYSTEM_ID, "condition");
  if (!(statuses.includes("unconscious") || cond === "unconscious")) return;
  const e = arcanePrepEffect(actor);
  if (!e) return;
  await actor.deleteEmbeddedDocuments("ActiveEffect", [e.id]).catch(() => {});
  // Said, as the other way it is lost is (found live, 0.18.1: it went silently).
  await card(actor, FEATS.arcanePrep, [line(`You fall unconscious: the preparation of <strong>${esc(e.getFlag?.(MODULE_ID, "spellName") ?? "")}</strong> is lost.`)]);
}

/* Heritage of the First Weave ------------------------------------------ */

export const FIRST_WEAVE_STEP = "eldritchArts.firstWeave";
async function firstWeaveStep(actor) {
  const feat = has(actor, FEATS.firstWeave);
  if (!feat || h().itemUsesRemaining(feat) <= 0) return { spent: false };
  if (!(await h().spendReaction?.(actor, FEATS.firstWeave, { traits: String(feat.system?.traits ?? "") }))) return { spent: false };
  await feat.update({ "system.usesValue": Math.max(0, h().itemUsesRemaining(feat) - 1) });
  return { spent: true };
}

export const firstWeaveReaction = Object.freeze({
  async before(ctx = {}) {
    const actor = ctx.actor;
    if (!R.firstWeaveWants(ctx)) return null;
    const feat = has(actor, FEATS.firstWeave);
    if (!feat || h().itemUsesRemaining(feat) <= 0) return null;
    const q = await h().askReactor(actor, {
      title: `${FEATS.firstWeave} — ${actor.name}`,
      content: `<p>You are about to save against a divine or verdant effect (${esc(ctx.label || "a saving throw")}).</p><p>Shelter in the First Weave (your reaction and its Focus use) for +2 circumstance? Forbidden Magic still applies.</p>`,
      buttons: yesNo(FEATS.firstWeave), step: FIRST_WEAVE_STEP, data: {}
    });
    if (!q?.result?.spent) return null;
    return { modifiers: [{ label: FEATS.firstWeave, value: R.FIRST_WEAVE_BONUS, type: "circumstance" }], line: `${esc(actor.name)}'s <strong>${FEATS.firstWeave}</strong>: +${R.FIRST_WEAVE_BONUS} circumstance (Forbidden Magic's penalty still applies).` };
  }
});

/* Perfected Arcane Memory ---------------------------------------------- */

/** A spell that ended leaves a trace: recorded when an arcane or ethereal spell's effect is deleted (acting GM). */
export async function onEffectDeletedB11(effect) {
  if (!isActingGM()) return;
  // FOUND LIVE (0.18.1): the core's spell effects carry no spellName or
  // tradition. They carry spellEffect, a castId and an origin (the spell item),
  // and the item has both; Mage Armour also names itself in spellArmour.
  const sys = effect?.flags?.[SYSTEM_ID] ?? {};
  if (!(sys.spellEffect || sys.spellBuff || sys.spellName)) return;
  let spell = null;
  try { spell = effect.origin ? globalThis.fromUuidSync?.(effect.origin) ?? null : null; } catch { spell = null; }
  const spellName = String(sys.spellName ?? sys.spellArmour?.spellName ?? spell?.name ?? "").trim();
  const tradition = arcaneTradition(spell?.system?.tradition ?? sys.tradition ?? sys.spellTradition ?? "");
  if (!spellName || !tradition) return;
  const caster = spell?.parent ?? null;
  const t = caster ? tokenOf(caster) : null;
  await pushTrace({ spellName, tradition, castId: sys.castId ?? null, castAt: Number(sys.castAt ?? effect.duration?.startTime ?? effect.duration?._worldTime ?? NaN), endedAt: worldTime(), origin: sys.origin ?? (t ? { x: t.center.x, y: t.center.y } : null), sceneId: globalThis.canvas?.scene?.id ?? "" });
}

/** The arcane or ethereal tradition among a spell's listed ones ("arcane, ethereal"), or "". */
function arcaneTradition(value) {
  const list = String(Array.isArray(value) ? value.join(",") : value ?? "").split(/[,;/]/).map(norm).filter(Boolean);
  return list.find((t) => R.ARCANE_PREP_TRADITIONS.includes(t)) ?? "";
}

/** And an instantaneous spell's trace (settled with no lasting effect), where it was cast. */
async function recordTrace(ctx = {}) {
  if (!isActingGM() || !ctx.cast || ctx.itemCast) return;
  const tradition = arcaneTradition(ctx.spellData?.tradition ?? ctx.spell?.system?.tradition ?? "");
  if (!tradition) return;
  if (norm(ctx.spellData?.duration ?? ctx.spell?.system?.duration) && !["instant", "instantaneous", "0", ""].includes(norm(ctx.spellData?.duration ?? ctx.spell?.system?.duration))) return;
  const t = tokenOf(ctx.actor);
  await pushTrace({ spellName: ctx.spell.name, tradition, castId: ctx.castId ?? null, castAt: worldTime(), endedAt: worldTime(), origin: t ? { x: t.center.x, y: t.center.y } : null, sceneId: globalThis.canvas?.scene?.id ?? "" });
}

async function pushTrace(trace) {
  const settings = globalThis.game?.settings;
  if (!settings) return;
  const held = settings.get(MODULE_ID, R.TRACES_SETTING) ?? [];
  // ONE TRACE A CAST: a spell on several targets ends on each of them.
  if (trace.castId && held.some((t) => t.castId === trace.castId)) return;
  const list = R.readableTraces([...held, trace], worldTime()).slice(-200);
  await settings.set(MODULE_ID, R.TRACES_SETTING, list);
}

const perfectedArcaneMemory = {
  hint: "Examine residual traces of an arcane or ethereal spell that ended within 24 hours (Arcana or Occultism, normal identification DC +5).",
  async use(actor) {
    const scene = globalThis.canvas?.scene?.id ?? "";
    const traces = R.readableTraces(globalThis.game?.settings?.get(MODULE_ID, R.TRACES_SETTING) ?? [], worldTime()).filter((t) => !t.sceneId || t.sceneId === scene);
    const known = await h().chooseFromList(FEATS.memory, "GM: which recorded trace is present where they examine? (Or none recorded: GM sets the spell by hand.)", [
      // The spell's name only on a GM's screen: a player choosing would otherwise
      // read the answer before the roll (found live, 0.18.1).
      ...traces.map((t, i) => [String(i), `A trace ended ${R.roughAgo(worldTime() - Number(t.endedAt))}${globalThis.game?.user?.isGM ? ` (GM: ${t.spellName})` : ` (trace ${i + 1})`}`]), ["manual", "Not recorded — the GM adjudicates"]
    ]);
    if (!known) return false;
    const trace = known === "manual" ? null : traces[int(known)];
    const skill = await h().chooseFromList(FEATS.memory, "Roll with:", R.MEMORY_SKILLS.map((s) => [s, s.charAt(0).toUpperCase() + s.slice(1)]));
    if (!skill) return false;
    const base = int(await h().chooseFromList(FEATS.memory, "GM: the normal identification DC (+5 is added for the weakened traces):", Array.from({ length: 31 }, (_, i) => [String(10 + i), `DC ${10 + i}`])));
    if (!base) return false;
    const dc = base + R.TRACE_DC_INCREASE;
    const check = await h().rollCheck({ actor, type: "skill", subject: skill, dc, label: `${FEATS.memory} — residual traces`, subtitle: `Identification DC ${base} +${R.TRACE_DC_INCREASE} (weakened traces)` });
    const degree = String(check?.outcome?.degree?.key ?? "failure");
    const from = tokenOf(actor)?.center ?? null;
    const out = trace ? R.traceReveals(trace, degree, { worldTime: worldTime(), from }) : { identified: ["success", "critical", "heroic"].includes(degree) };
    const lines = [];
    if (!out.identified) lines.push(line(`The traces do not yield to you (${esc(degree)} against DC ${dc}).`));
    else if (!trace) lines.push(line(`${esc(degree)} against DC ${dc}: <em>GM — reveal the spell and its tradition${["critical", "heroic"].includes(degree) ? ", and roughly when and from which direction, if the residue holds it" : ""}. Never the caster.</em>`));
    else {
      lines.push(line(`The residue is <strong>${esc(out.spell)}</strong>, a spell of the <strong>${esc(out.tradition)}</strong> tradition.`));
      if (out.agoSeconds !== undefined) lines.push(line(`It was cast ${esc(R.roughAgo(out.agoSeconds))}.`));
      if (out.direction) lines.push(line(`Its point of origin lies to the <strong>${esc(out.direction)}</strong>.`));
      if (["critical", "heroic"].includes(degree) && out.agoSeconds === undefined && !out.direction) lines.push(line("<em>The traces hold nothing about when or where it was cast.</em>"));
    }
    lines.push(line("<em>The caster's identity is not revealed.</em>"));
    await card(actor, FEATS.memory, lines);
    return true;
  }
};

/* ------------------------------------------------------------------ */
/* Daily preparation                                                    */
/* ------------------------------------------------------------------ */

/** Hooks.on("trgPrimeDailyPreparation"): yesterday's upgrades and overclock end; today's are asked for; the Prepared states clear. */
export async function onDailyPreparationB11({ actor } = {}) {
  if (!actor?.isOwner) return;
  const lines = [];
  if (mflag(actor, R.MODULAR_FLAG) || items(actor).some((i) => mflag(i, R.MODULAR_ITEM_FLAG))) {
    await clearAllUpgrades(actor);
    await actor.unsetFlag(MODULE_ID, R.MODULAR_FLAG);
    lines.push(line("Yesterday's modular upgrades are removed."));
  }
  for (const w of items(actor).filter((i) => mflag(i, R.OVERCLOCK_FLAG))) {
    await w.unsetFlag(MODULE_ID, R.OVERCLOCK_FLAG);
    lines.push(line(`<strong>${esc(w.name)}</strong> is no longer overclocked.`));
  }
  for (const i of items(actor).filter((x) => preparedState(x))) await i.unsetFlag(MODULE_ID, R.PREPARED_FLAG);
  if (has(actor, FEATS.modular)) lines.push(line(`Use <strong>${FEATS.modular}</strong> to apply today's upgrades (+${R.modularAllowance(featNames(actor)).budget} in all).`));
  if (has(actor, FEATS.triggered)) {
    await actor.setFlag(MODULE_ID, R.PREP_WINDOW_FLAG, { at: worldTime(), closed: false });
    lines.push(line(`As part of this preparation, inscribe your sigils and then use <strong>${FEATS.triggered}</strong> to designate one — before you cast a spell, enter combat or an hour passes.`));
  }
  if (lines.length) await card(actor, "Eldritch Arts — today's preparation", lines);
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const AUTOMATIONS_B11 = Object.freeze({
  [FEATS.modular]: modularDesign,
  [FEATS.advanced]: advancedDesign,
  [FEATS.integrated]: integratedModularity,
  [R.QUICK_SWAP]: quickSwap,
  [FEATS.overclock]: overclockedWeaponry,
  [FEATS.assistant]: mechanisedAssistant,
  [FEATS.powerSink]: powerSinkUse,
  [FEATS.contraption]: contraptionUse,
  [FEATS.insight]: insightUse,
  [FEATS.triggered]: triggeredSigil,
  [FEATS.grand]: grandInscriptionUse,
  [FEATS.arcanePrep]: arcanePreparation,
  [FEATS.memory]: perfectedArcaneMemory
});

export const PASSIVE_B11 = Object.freeze({
  [FEATS.harness]: "Instability Harness is automatic: Power Sink is also asked when a save against magic Fumbles or Blunders.",
  [FEATS.tinkerer]: "Tinkerer Precision is automatic: a Create project's time is read at +2 ranks and 75% of the item's value; the cost and the check are unchanged.",
  [FEATS.anchor]: "Runic Anchor is automatic: on a Spell Concentration check you are asked whether it is for a spell you cast with a Symbol (+2 class).",
  [FEATS.leyResonance]: "Ley Resonance is offered in the Warp? dialog while you are within 60 ft of a ley line or linked to one (a Focus use).",
  [FEATS.firstWeave]: "Heritage of the First Weave is asked before a saving throw against a divine or verdant effect (reaction; a Focus use)."
});

export const STEPS_B11 = Object.freeze({
  [POWER_SINK_STEP]: powerSinkStep, [CONTRAPTION_STEP]: contraptionStep, [INSIGHT_STEP]: insightStep, [FIRST_WEAVE_STEP]: firstWeaveStep, [TRIGGER_STEP]: triggerStep
});

/** Every registration Block 11 makes; called once from registerContent (trgPrime.registerContent). */
export function registerBlock11(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B11)) api.registerFeatAutomation(name, entry, moduleId);
  for (const [name, hint] of Object.entries(PASSIVE_B11)) api.registerPassiveAutomation?.(name, hint, moduleId);
  api.registerTraits?.([R.PREPARED_TRAIT, "Construct"], moduleId);
  // C-EA11-1 and C-EA11-2 (TRG Prime 3.713.0); absent on an older core, where the cards say the GM applies them.
  api.registerWeaponEnhancement?.("eaBlock11", weaponEnhancementB11, moduleId);
  api.registerCraftingWorkModifier?.("tinkererPrecision", tinkererWork, moduleId);
  api.registerEffectSuppressor?.("eaBlock11", effectSuppressedB11, moduleId);
  api.registerCheckReaction?.("powerSink", powerSinkReaction, moduleId);
  api.registerCheckReaction?.("emergencyContraption", contraptionReaction, moduleId);
  api.registerCheckReaction?.("flashOfInsight", insightReaction, moduleId);
  api.registerCheckReaction?.("runicAnchor", runicAnchorReaction, moduleId);
  api.registerCheckReaction?.("firstWeave", firstWeaveReaction, moduleId);
  api.registerResonanceSuppressor?.("powerSink", powerSinkResonance, moduleId);
  api.registerSpellCheckGate?.("arcanePreparation", arcanePrepGate, moduleId);
  api.registerCastOption?.("grandInscription", grandInscriptionOption, moduleId);
  api.registerCastOption?.("spellRelayNode", relayNodeOption, moduleId);
  api.registerMetamagic?.("leyResonance", leyResonanceMetamagic, moduleId);
  api.registerDefenceOffer?.("triggeredSigilTargeted", triggeredTargetedOffer, moduleId);
  for (const [name, run] of Object.entries(STEPS_B11)) api.registerReactionStep?.(name, run, moduleId);
}

/** The Perfected Arcane Memory traces live in a world setting (the acting GM writes them). */
export function registerBlock11Settings() {
  globalThis.game?.settings?.register?.(MODULE_ID, R.TRACES_SETTING, { scope: "world", config: false, type: Array, default: [] });
}
