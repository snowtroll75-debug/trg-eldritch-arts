/**
 * Block 9c (0.15.0, on TRG Prime 3.690.0): Chapter 9's charged items — the
 * five orbs and their rules, nine rods and five staves — and the Spellhold
 * rune's store. Pure; no Foundry. The automation is
 * module/block9c-automations.mjs; the pack, tools/content/block9c.mjs (which
 * checks every figure here against the book's own entry).
 *
 * Graham's rulings (ELDRITCH_ARTS_BLOCK9_AUDIT.md §8, "Go with your
 * recommendation", 13 November 2026; Spellhold, "Yes build it", 14 November):
 *   Q203 Spellhold: any staff; storing takes the spell's own AP; only the
 *        investor releases; targets and areas at release; the stored check's
 *        Save DC and attack; a failed check stores nothing
 *   Q207 Verdant Heart at level 13 as printed; the ley-line checks are Ley
 *        Sense, Tap Ley Line and Channel Ley Line (and the Power Manipulation
 *        check against Leyline Anchor), the bonus held whatever the PP; the
 *        "at least 3 PP" abilities stop at 2 PP or less
 *   Q208 Binding Seal: once per cast, 1 PP, casting DC −1
 *   Q209 Catalyst Flow: Catalyst Conservation's flat check first; the rod's
 *        2 PP keep the catalyst even on a Fumble or Blunder
 *   Q210 an orb's spell may be warped from the orb's PP up to its level
 */

const int = (v) => Math.trunc(Number(v) || 0);
const lower = (v) => String(v ?? "").trim().toLowerCase();

/** "The orb grants you a +1-item bonus to all checks related to ley lines" (L9325–9331): by the orb's level. */
export function orbLeyBonus(level) {
  const l = int(level);
  return l >= 17 ? 3 : l >= 9 ? 2 : 1;
}

/** The ley-line checks the bonus reaches (Q207): the actions' keys. */
export const LEY_ACTIONS = Object.freeze(["leySense", "tapLeyLine", "channelLeyLine"]);

/** "Such abilities will stop working if the Orb is reduced to 2 PP or less" (L9337). */
export const ORB_ABILITY_MIN_PP = 3;

/** The Resonant Flare's radius (L9311): "all creatures in a 20-foot radius". */
export const FLARE_RADIUS = 20;

/** Is this depletion row the one an orb flares on instead (41–65, "breaks")? */
export function isFlareRow(row) {
  return Boolean(row?.breaks) && int(row?.min) === 41 && int(row?.max) === 65;
}

/**
 * THE ORB'S LADDER (L9281–9299, M80, M81, m170, R17). Spellcraft, Hard (DC
 * +2), when your caster level covers the spell's PP — "the spell need not be
 * from your tradition" — with High Magic's own step on top ("this stacks
 * with the modifier for casting High Magic"). Otherwise the spell's tradition
 * skill, Very Hard (DC +5), with ranks at least the PP and Use Magic Device;
 * for a High Magic spell, Arcana or your own tradition's skill.
 *
 * @param {object} ctx  { spellPPCost, spellTradition, spellTraits, casterLevel,
 *   casterCap (the most PP the caster may cast), casterTradition, skillRanks,
 *   hasUseMagicDevice, traditionSkills ({tradition: skill}) }
 */
export function orbReleaseOptions(ctx = {}) {
  const pp = Math.max(0, int(ctx.spellPPCost));
  const cap = int(ctx.casterCap);
  const highMagic = /\bhighmagic\b/i.test(String(ctx.spellTraits ?? ""));
  const skills = ctx.traditionSkills ?? {};
  const ranksIn = (skill) => Math.max(0, int(ctx.skillRanks?.[skill]));
  const out = [{
    key: "spellcraft", label: "Spellcraft", skill: "spellcraft", difficulty: "hard",
    dcParts: highMagic ? [{ label: "High Magic", value: 2 }] : [],
    available: pp <= cap && int(ctx.casterLevel) > 0,
    reason: int(ctx.casterLevel) <= 0 ? "you have no caster level" : pp > cap ? `your caster level casts at most ${cap} PP, below the spell's ${pp}` : ""
  }];
  const spellTraditions = String(ctx.spellTradition ?? "").split(/[,/]/).map(lower).filter(Boolean);
  const own = lower(ctx.casterTradition);
  // A HIGH MAGIC SPELL: "use Arcana (or the skill of your own tradition)".
  const traditions = highMagic ? [...new Set(["arcane", ...(own && skills[own] ? [own] : [])])] : spellTraditions;
  for (const tradition of traditions) {
    const skill = skills[tradition] ?? "";
    const reasons = [];
    if (!skill) reasons.push(`"${tradition}" is not one of this world's traditions`);
    else if (ranksIn(skill) < pp) reasons.push(`your ${skill} ranks (${ranksIn(skill)}) are below the spell's ${pp} PP`);
    if (!ctx.hasUseMagicDevice) reasons.push("you do not have Use Magic Device");
    out.push({
      key: `tradition:${tradition}`, label: skill ? skill[0].toUpperCase() + skill.slice(1) : "Tradition skill",
      skill, difficulty: "veryHard", dcParts: [], available: Boolean(skill) && !reasons.length, reason: reasons.join("; ")
    });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* The items                                                            */
/* ------------------------------------------------------------------ */

const S = (...pairs) => pairs.map(([name, pp]) => ({ name, pp }));

/** The ley-line bonus as an item conditional (Q207): held, whatever its PP. */
const leyConditional = (level, name) => ({
  kind: "modifier", value: orbLeyBonus(level), type: "item", label: `${name} (ley lines)`,
  scope: "Ley Sense, Tap Ley Line and Channel Ley Line, while held", when: { actions: [...LEY_ACTIONS] }, auto: true
});

/**
 * The five orbs (L9347–9451). `wondrous` are its "at least 3 PP" abilities
 * (TRG Prime's wondrous channel, `minItemPP`); `conditionals` its item rows;
 * `criticalTap` what a Critical Tap Ley Line gives (the module's).
 */
export const ORBS_9C = Object.freeze({
  "ORB OF EMBERLIGHT": {
    name: "Orb of Emberlight", level: 8, price: 4375, pp: 24, weight: 5, traits: "Invested, Magical, Orb",
    spells: S(["Orb of Fire", 0], ["Burning Hands", 2], ["Fire Bolt", 4], ["Fireball", 6]),
    wondrous: [
      { kind: "resistance", damageType: "fire", minItemPP: ORB_ABILITY_MIN_PP, label: "Orb of Emberlight" },
      { kind: "spellAdder", value: 1, spellTraits: ["fire"], minItemPP: ORB_ABILITY_MIN_PP, label: "Orb of Emberlight" }
    ],
    conditionals: [],
    note: "Fire resistance and a +1 Spell Adder for fire spells while it holds 3 PP or more."
  },
  "ORB OF THE SHATTERED VEILS": {
    name: "Orb of the Shattered Veils", level: 11, price: 11250, pp: 33, weight: 4, traits: "Highmagic, Invested, Orb",
    spells: S(["Decoherence", 0], ["Leyline Burst", 4], ["See Invisible", 4], ["Planar Anchor", 8]),
    wondrous: [], conditionals: [], criticalTap: "seeInvisible",
    note: "A Critical Tap Ley Line while it holds 3 PP or more: See Invisible with its +4 PP warp (invisible creatures seen clearly) for 10 minutes."
  },
  "ORB OF SHIFTING CURRENTS": {
    name: "Orb of Shifting Currents", level: 4, price: 750, pp: 12, weight: 2, traits: "Invested, Magical, Orb",
    spells: S(["Orb of Water", 0], ["Gust", 2], ["Shield", 2], ["Obscuring Mist", 2]),
    wondrous: [{ kind: "skillBonus", skill: "acrobatics", target: "system.skills.acrobatics.bonus", value: 1, bonusType: "item", minItemPP: ORB_ABILITY_MIN_PP, label: "Orb of Shifting Currents" }],
    conditionals: [],
    note: "+1 item to Acrobatics while it holds 3 PP or more."
  },
  "ORB OF THE VERDANT HEART": {
    name: "Orb of the Verdant Heart", level: 13, price: 25000, pp: 39, weight: 3, traits: "Invested, Magical, Orb",
    spells: S(["Tanglefoot", 0], ["Conjure Plant", 4], ["Entangle", 4], ["Wall of Thorns", 6], ["Regenerate", 10]),
    wondrous: [], conditionals: [], criticalTap: "fastHealing",
    note: "Level 13 as printed (Q207). A Critical Tap Ley Line while it holds 3 PP or more: you and each ally within 10 feet gain Fast Healing 2 for 1 minute."
  },
  "ORB OF THE WHISPERING VEIL": {
    name: "Orb of the Whispering Veil", level: 6, price: 2000, pp: 18, weight: 5, traits: "Invested, Magical, Orb",
    spells: S(["Ghost Sound", 0], ["Face Shifting", 2], ["Cloak of Greying", 2], ["Invisibility", 4]),
    wondrous: [],
    conditionals: [{ kind: "modifier", value: 2, type: "item", label: "Orb of the Whispering Veil", scope: "Hide (Stealth), while it holds 3 PP or more", when: { actions: ["hide"] }, auto: true, minItemPP: ORB_ABILITY_MIN_PP }],
    note: "+2 item to Hide (Stealth) while it holds 3 PP or more."
  }
});
for (const [upper, o] of Object.entries(ORBS_9C)) {
  o.conditionals = [leyConditional(o.level, o.name), ...o.conditionals];
  void upper;
}

/** A rod's power the module runs (H24), by key. */
export const ROD_POWERS = Object.freeze({
  leyResonance: "Ley Resonance", bindingSeal: "Binding Seal", catalystFlow: "Catalyst Flow", soulsEcho: "Soul's Echo", wildSurges: "Wild Surges"
});

/** The nine rods (L9459–9603): Power Points 10, Recharge 1 per day. */
export const RODS_9C = Object.freeze({
  "ROD OF FOCUSED SPELL I": { name: "Rod of Focused Spell I", level: 7, price: 1800, weight: 3, traits: "Invested, Magical, Rod", metamagic: { kind: "focusedspell", maxPP: 4, cost: 2 }, note: "Offered in the Warp? dialog on a spell of PP 4 or less: Focused Spell (advantage on the casting check), paid 2 PP from the rod." },
  "ROD OF FOCUSED SPELL II": { name: "Rod of Focused Spell II", level: 11, price: 7000, weight: 3, traits: "Invested, Magical, Rod", metamagic: { kind: "focusedspell", maxPP: 8, cost: 2 }, note: "As Focused Spell I, on a spell of PP 8 or less." },
  "ROD OF FOCUSED SPELL III": { name: "Rod of Focused Spell III", level: 15, price: 33000, weight: 3, traits: "Invested, Magical, Rod", metamagic: { kind: "focusedspell", maxPP: 12, cost: 2 }, note: "As Focused Spell I, on a spell of PP 12 or less." },
  "ROD OF LEY RESONANCE": { name: "Rod of Ley Resonance", level: 5, price: 750, weight: 2, traits: "Invested, Magical, Rod", power: "leyResonance", note: "Offered as a source of PP on any cast: draw from the rod instead of your own pool. Within 60 feet of a ley line each rod PP counts as 2 (the rod pays half, rounded up)." },
  "ROD OF QUICKENING II": { name: "Rod of Quickening II", level: 16, price: 50000, weight: 2, traits: "Invested, Magical, Rod", metamagic: { kind: "quicken", maxPP: 8, cost: 2 }, note: "Quicken from the rod for 2 PP on a spell of PP 8 or less with an AP cost of 2 (a 1 AP spell cannot be quickened, R12)." },
  "ROD OF THE BINDING SEAL": { name: "Rod of the Binding Seal", level: 7, price: 1800, weight: 3, traits: "Invested, Translocation, Rod", power: "bindingSeal", note: "On a spell with the Summons trait: a casting option, 1 PP from the rod for casting DC −1 (once a cast, Q208)." },
  "ROD OF THE CATALYST FLOW": { name: "Rod of the Catalyst Flow", level: 10, price: 5000, weight: 2, traits: "Invested, Magical, Rod", power: "catalystFlow", note: "When a catalyst would be spent (after Catalyst Conservation's check, Q209), you are offered to keep it for 2 PP from the rod — even on a Fumble or Blunder." },
  "ROD OF SOUL’S ECHO": { name: "Rod of Soul’s Echo", level: 6, price: 1200, weight: 2, traits: "Invested, Magical, Rod", power: "soulsEcho", note: "On a spell with a save: a casting option, 1 PP from the rod; each undead target's Save DC is 2 higher." },
  "ROD OF WILD SURGES": { name: "Rod of Wild Surges", level: 6, price: 1200, weight: 2, traits: "Invested, Magical, Rod", power: "wildSurges", note: "A casting option, 1 PP from the rod: once the spell has resolved (a spell held in a Spellhold staff surges when it is stored), a Wild Surge with area level equal to the spell's PP, centred on you." }
});

/** The five staves (L9609–9713), core staves with their printed spells. */
export const STAVES_9C = Object.freeze({
  "DARKSTAFF": { name: "Darkstaff", level: 7, price: 2400, pp: 14, recharge: 2, weight: 4, traits: "Insight, Invested, Invocation, Staff", spells: S(["Orb of Cold", 0], ["Darkness", 4], ["Darkvision", 4]), note: "A TRG Prime staff: Cast from Item releases its spells and warps them from its own PP, and it recharges at daily preparation while invested." },
  "EIDOTHRIX": {
    name: "Eidothrix", level: 6, price: 1600, pp: 12, recharge: 2, weight: 4, traits: "Invested, Staff, Translocation", spells: S(["Obscuring Mist", 2], ["Phantom Steed", 4]),
    conditionals: [{ kind: "modifier", value: 1, type: "item", label: "Eidothrix", scope: "Spellcraft, casting a Translocation spell, while held", when: { checkTypes: ["spellcraft"], traits: ["translocation"] }, auto: true }],
    note: "+1 item to the Spellcraft check when casting a Translocation spell, while held."
  },
  "STAFF OF FLAME": { name: "Staff of Flame", level: 4, price: 600, pp: 8, recharge: 1, weight: 4, traits: "Invested, Invocation, Staff", spells: S(["Orb of Fire", 0], ["Burning Hands", 2]), note: "Lighting a flame with the staff's tip is an Interact action: the table's." },
  "STAFF OF HEAVEN & EARTH": { name: "Staff of Heaven & Earth", level: 11, price: 9000, pp: 22, recharge: 3, weight: 5, traits: "Invested, Magical, Staff", spells: S(["Gust", 2], ["Obscuring Mist", 2], ["Spike Stones", 6], ["Air Walk", 6], ["Shape Stone", 8]), note: "A TRG Prime staff: Cast from Item releases its spells and warps them from its own PP, and it recharges at daily preparation while invested." },
  "TESRA’ANVIR - ARCANE": {
    name: "Tesra’Anvir – Arcane", level: 18, price: 180000, pp: 36, recharge: 4, weight: 4, traits: "Arcane, Invested, Staff", spells: S(["Shield", 2], ["Knock", 4], ["Eldritch Bolt", 6], ["Eldritch Ball", 10], ["Spell Drain", 14]),
    wondrous: [{ kind: "spellAdder", value: 4, requiresArcaneOrHighMagicCaster: true, label: "Tesra’Anvir – Arcane" }],
    metamagic: { kind: "quicken", maxPP: 99, cost: 8 },
    note: "+4 Spell Adder for an arcane or High Magic caster; Quicken for 8 PP from the staff on any spell of 2 AP (R18: no PP limit; a 1 AP spell cannot be quickened, R12)."
  }
});

/* ------------------------------------------------------------------ */
/* Rod powers                                                           */
/* ------------------------------------------------------------------ */

/** "Within 60 ft of a ley line, each rod PP counts as 2 (round the cost up)." */
export const LEY_RESONANCE_FEET = 60;
export function leyResonanceRate(nearLine) { return nearLine ? 2 : 1; }
/** The most a cast may draw: the rod's PP at the rate. */
export function leyResonanceMax(rodPP, rate) { return Math.max(0, int(rodPP)) * Math.max(1, int(rate)); }
/** What the rod pays for `paid` PP of the cast: half near a line, rounded up. */
export function leyResonanceRodCost(paid, rate) { return Math.ceil(Math.max(0, int(paid)) / Math.max(1, int(rate))); }

/** Binding Seal (Q208): a spell with the Summons trait. */
export function isSummons(traits) { return /\bsummons?\b/i.test(String(traits ?? "")); }
/** Soul's Echo: a spell with a save. */
export function hasSave(defence) { return Boolean(String(defence ?? "").trim()); }

/* ------------------------------------------------------------------ */
/* Spellhold                                                            */
/* ------------------------------------------------------------------ */

/** The store's room by tier (L9879's sidebar): 6, 12, 24, 40 PP. */
export const SPELLHOLD_CAPACITY = Object.freeze([6, 12, 24, 40]);
export function spellholdCapacity(tier) {
  const t = Math.min(SPELLHOLD_CAPACITY.length, Math.max(1, int(tier)));
  return SPELLHOLD_CAPACITY[t - 1];
}
