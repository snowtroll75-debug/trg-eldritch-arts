/**
 * When an Eldritch Arts effect ends. Adapted from Inner Tempest's
 * skill-action-automations (the same author's rules, the same system).
 *
 * THE SYSTEM'S CLOCKS, WHERE IT HAS THEM:
 *   - out of combat, and for a span in seconds: `spellEffect` +
 *     `spellEffectEnd` (world time), swept by TRG Prime;
 *   - "until the start of your next turn": `conditionExpiresRound`, swept by
 *     TRG Prime at the round's first turn (a backstop) and removed by this
 *     module as the bearer's turn begins.
 * AND THIS MODULE'S OWN: "until the end of your next turn" is removed on
 * TRG Prime's `trgPrimeTurnEnded` (the bearer's turn, in that combat, from
 * that round on).
 *
 * Pure above the line; the sweep needs Foundry.
 */
import { isActingGM } from "./writer.mjs";

export const SYSTEM_ID = "trg-prime";
export const MODULE_ID = "trg-eldritch-arts";
/** On an effect: removed when its bearer's turn ends in this combat, from this round. */
export const TURN_END_FLAG = "endsAfterTurn";
/** On an effect: removed as its bearer's turn begins in this combat, in this round. */
export const TURN_START_FLAG = "endsAtTurnStart";
/** On every effect this module makes: which rule made it. */
export const SOURCE_FLAG = "source";

/**
 * The round in which a creature's next turn starts: the next round if it is
 * acting now or has acted, this one if its turn is still to come. A creature
 * not in the order is given the next round.
 */
export function nextTurnRound(combat, isBearer) {
  const round = Math.max(0, Number(combat?.round ?? 0));
  const turns = Array.from(combat?.turns ?? []);
  const index = turns.findIndex((c) => isBearer(c));
  if (index < 0) return round + 1;
  return index > Number(combat?.turn ?? 0) ? round : round + 1;
}

/**
 * The flags that end an effect.
 * @param {"startOfNextTurn"|"endOfNextTurn"|{seconds:number}} kind
 * @param {{inCombat: boolean, combatId: string, nextRound: number, worldTime: number}} now
 * @returns {{system: object, module: object}}
 */
export function expiryFlags(kind, now) {
  const seconds = typeof kind === "object" ? Math.max(1, Math.trunc(Number(kind.seconds) || 0)) : 6;
  if (now?.inCombat && kind === "startOfNextTurn") {
    const combatId = String(now.combatId ?? "");
    return { system: { conditionExpiresRound: Number(now.nextRound) + 1 }, module: { combatId, [TURN_START_FLAG]: { combatId, round: Number(now.nextRound) } } };
  }
  // "UNTIL THE END OF YOUR TURN" (0.3.0; Tap Ley Line's Success): the turn
  // now running if it is the bearer's, else their next one.
  if (now?.inCombat && kind === "endOfTurn") {
    const combatId = String(now.combatId ?? "");
    const round = now.currentTurn ? Number(now.round ?? 0) : Number(now.nextRound);
    return { system: { spellEffect: true, spellEffectEnd: Math.trunc(Number(now?.worldTime ?? 0)) + 6 }, module: { combatId, [TURN_END_FLAG]: { combatId, round } } };
  }
  if (now?.inCombat && kind === "endOfNextTurn") {
    const combatId = String(now.combatId ?? "");
    // A BACKSTOP ON THE WORLD CLOCK (found in review): the turn hook does not
    // fire while the system's combat automation is off, or for a creature in
    // stasis. Two rounds (12 seconds) is never sooner than the end of the
    // bearer's next turn, and ends the effect if the hook never comes.
    return { system: { spellEffect: true, spellEffectEnd: Math.trunc(Number(now?.worldTime ?? 0)) + 12 }, module: { combatId, [TURN_END_FLAG]: { combatId, round: Number(now.nextRound) } } };
  }
  return { system: { spellEffect: true, spellEffectEnd: Math.trunc(Number(now?.worldTime ?? 0)) + seconds }, module: {} };
}

/** Does a turn ending (or starting) now end this effect? */
export function endsWithTurn(flag, combat) {
  if (!flag || !combat) return false;
  return String(flag.combatId) === String(combat.id) && Number(combat.round ?? 0) >= Number(flag.round);
}

/** An effect's data with its source and clock. */
export function effectData(source, { name, description = "", img = "icons/svg/aura.svg", changes = [], system = {}, module = {}, expiry = null, statuses = [] }) {
  return {
    name, img, description, changes, statuses,
    flags: {
      [SYSTEM_ID]: { ...system, ...(expiry?.system ?? {}) },
      [MODULE_ID]: { [SOURCE_FLAG]: source, ...module, ...(expiry?.module ?? {}) }
    }
  };
}

/* ------------------------------------------------------------------ */
/* Foundry side                                                         */
/* ------------------------------------------------------------------ */

export function combatFor(actor) {
  const combat = globalThis.game?.combat;
  if (!combat?.started) return null;
  // An unlinked token's actor shares its base actor's id, so the id alone would
  // put every token of a goblin in the combat when one is (review, 0.7.1).
  return Array.from(combat.combatants ?? []).some((c) => c.actor === actor || (c.actorId === actor?.id && actor?.isToken !== true)) ? combat : null;
}

/** The clock for an effect on `bearer`, now. */
export function expiryFor(kind, bearer) {
  const combat = combatFor(bearer);
  const isBearer = (c) => c.actor === bearer || (c.actorId === bearer?.id && bearer?.isToken !== true);
  return expiryFlags(kind, {
    inCombat: Boolean(combat),
    combatId: combat?.id ?? "",
    round: Number(combat?.round ?? 0),
    currentTurn: Boolean(combat?.combatant && isBearer(combat.combatant)),
    nextRound: combat ? nextTurnRound(combat, (c) => c.actor === bearer || (c.actorId === bearer?.id && bearer?.isToken !== true)) : 0,
    worldTime: Number(globalThis.game?.time?.worldTime ?? 0)
  });
}

/** For a span of seconds: the world clock, in or out of combat. */
export function forSeconds(seconds) {
  return expiryFlags({ seconds }, { worldTime: Number(globalThis.game?.time?.worldTime ?? 0) });
}

/** This module's effects on an actor made by `source`. */
export function ownEffects(actor, source) {
  return Array.from(actor?.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, SOURCE_FLAG) === source);
}


/**
 * trgPrimeTurnEnded (acting GM): the ended turn's "until the end of your
 * next turn", and the next creature's "until the start of your next turn".
 */
export async function onTurnEnded(ctx = {}) {
  if (!isActingGM()) return;
  const combat = ctx.combat ?? game.combat;
  const actor = ctx.actor ?? ctx.combatant?.actor;
  if (!combat) return;
  if (actor) {
    const ids = Array.from(actor.effects ?? []).filter((e) => endsWithTurn(e.getFlag?.(MODULE_ID, TURN_END_FLAG), combat)).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
  }
  const next = combat.combatant?.actor;
  if (next) {
    const ids = Array.from(next.effects ?? []).filter((e) => endsWithTurn(e.getFlag?.(MODULE_ID, TURN_START_FLAG), combat)).map((e) => e.id);
    if (ids.length) await next.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
  }
}

/** deleteCombat (acting GM): this module's turn-clocked effects from that combat end with it. */
export async function onCombatDeleted(combat) {
  if (!isActingGM()) return;
  for (const c of Array.from(combat?.combatants ?? [])) {
    const actor = c.actor;
    if (!actor) continue;
    const ids = Array.from(actor.effects ?? []).filter((e) => {
      const mine = e.flags?.[MODULE_ID];
      return mine?.[SOURCE_FLAG] && (mine[TURN_END_FLAG]?.combatId === combat.id || mine[TURN_START_FLAG]?.combatId === combat.id);
    }).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {});
  }
}
