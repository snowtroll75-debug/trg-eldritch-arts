/**
 * Eldritch Arts — Block 7 (0.10.0, on TRG Prime 3.685.0): what the first half
 * of the Grimoire does that is not data. The spells are
 * tools/content/block7-spells.mjs; their numbers and pure rules are
 * module/block7-rules.mjs. Each spell is found by its `eaGrimoire` key.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK7_AUDIT.md §5.2, answered by Graham on
 * 7 November 2026 (Q150 changed, Q151–Q166 as proposed, H1–H11 approved;
 * Dragon Wings and Spirit Arrow ruled at 07:53).
 *
 *   Type when learned   Dragon's Breath, Elemental Strike (and the Pacts' grants)
 *   Uses                Elemental Strike (Strike)
 *   Spell-check gates   Arcane Feedback (a reaction cast in the gate), Arcane
 *                       Mycelium's reactive threads, Invoke True Name's
 *                       flat-footed, Zone Disruption (H8)
 *   Check reactions     Invoke True Name's −2/−4 save, Mirror Reprise (H6),
 *                       Panic Transposition (asked at the hit; the teleport once the attack is resolved)
 *   Damage reactions    Invoke True Name's weakness, Mirror Reprise's arming,
 *                       Panic Transposition's resistance
 *   Critical reaction   Arcane Bastion (H7, `after`)
 *   Cast reactions      Argent Reversal (H5 turnBack/exclude), Spectral Aegis (H5 exclude)
 *   Refusals            Planar Anchor; an untyped Dragon's Breath / Elemental Strike
 *   Prelude             Flesh to Blossom's acid or poison
 *   Dispel, fumble      Eaog Balls' disadvantage; Zone Disruption's fumble warp
 *   Hooks               the settled cast, a new item, a combat turn, a death
 *                       guard, a Strike, an effect's coming and going, a token's move
 */
import { isActingGM } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds, ownEffects } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, tokenOf, tokenCentre, spendAP, feetBetween } from "./block1-automations.mjs";
import { pickPoint, landingPrompt, actsFor } from "./block3-automations.mjs";
import { allies, SOCKET } from "./block3b-automations.mjs";
import * as R from "./block7-rules.mjs";

const worldNow = () => Number(globalThis.game?.time?.worldTime ?? 0);
const items = (actor) => Array.from(actor?.items ?? []);
const effects = (actor) => Array.from(actor?.effects ?? []);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const side = (token) => token?.document?.disposition;
const spellByKey = (actor, key) => items(actor).find((i) => i.type === "spell" && R.keyOf(i) === key) ?? null;
const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];
const within = (a, b, feet) => { const d = feetBetween(a, b); return d !== null && d <= feet; };
const casterLevelOf = (actor) => int(actor?.system?.magic?.casterLevelValue ?? actor?.system?.magic?.casterLevel);
const castingAbilityOf = (actor) => int(actor?.system?.attributes?.[actor?.system?.magic?.castingAbility]?.total);
const castIdOf = (effect) => String(effect?.flags?.[SYSTEM_ID]?.castId ?? "");
const markOf = (actor, key) => effects(actor).find((e) => !e?.disabled && e?.flags?.[MODULE_ID]?.[key]) ?? null;
const markRecord = (effect, key) => effect?.flags?.[MODULE_ID]?.[key] ?? null;
const unlocksOf = (warpMods) => Array.from(warpMods?.unlocks ?? []).map(String);
const sourceActor = (uuid) => {
  if (!uuid) return null;
  try { const d = globalThis.fromUuidSync?.(uuid); return d?.actor ?? d ?? null; } catch { return null; }
};
const sameCreature = (uuid, actor) => Boolean(uuid && actor?.uuid && (uuid === actor.uuid || String(uuid).startsWith(`${actor.uuid}.`) || sourceActor(uuid) === actor));

/* ================================================================== */
/* The type chosen when the spell is learned                           */
/* ================================================================== */

const TYPED = Object.freeze({
  dragonsBreath: { types: R.BREATH_TYPES, update: R.breathItemUpdate, pact: "draconic pact", pactFlag: "eaEnergy", title: "Dragon’s Breath" },
  elementalStrike: { types: R.STRIKE_TYPES, update: R.strikeItemUpdate, pact: "elemental pact", pactFlag: "eaElement", title: "Elemental Strike" }
});

/** The type a Pact grant takes: the Draconic Pact's energy, the Elemental Pact's element's (Block 6). */
export function pactTypeFor(key, pactItem) {
  const spec = TYPED[key];
  const raw = norm(pactItem?.flags?.[SYSTEM_ID]?.[spec?.pactFlag]);
  if (!spec || !raw) return "";
  return key === "elementalStrike" ? (R.ELEMENT_TO_STRIKE[raw] ?? "") : (spec.types.includes(raw) ? raw : "");
}

/** Write the chosen type onto the spell item (its damage, area, trait, range step). */
export async function setSpellType(item, type) {
  const spec = TYPED[R.keyOf(item)];
  const update = spec?.update(item.system, type);
  if (!update) return false;
  await item.update({ ...update, [`flags.${MODULE_ID}.${R.CHOSEN_TYPE_FLAG}`]: norm(type) });
  return true;
}
const chosenType = (item) => norm(item?.flags?.[MODULE_ID]?.[R.CHOSEN_TYPE_FLAG]);

async function askType(item) {
  const spec = TYPED[R.keyOf(item)];
  const pick = await h().chooseFromList(spec.title, `${spec.title}: choose its damage type (kept with the spell):`, spec.types.map((t) => [t, t]));
  if (!spec.types.includes(norm(pick))) return "";
  await setSpellType(item, pick);
  return norm(pick);
}

/** Hooks.on("createItem"): a Dragon's Breath or Elemental Strike takes its type. */
export async function onItemCreatedB7(item) {
  const actor = item?.parent;
  if (item?.type !== "spell" || !TYPED[R.keyOf(item)] || !actor?.isOwner || !actsFor(actor)) return;
  if (chosenType(item)) return;
  const spec = TYPED[R.keyOf(item)];
  const grantedBy = items(actor).find((i) => i.id === item.flags?.[SYSTEM_ID]?.grantedBy?.sourceId) ?? null;
  const fromPact = grantedBy && norm(grantedBy.name) === spec.pact ? pactTypeFor(R.keyOf(item), grantedBy) : "";
  if (fromPact) { await setSpellType(item, fromPact); return; }
  await askType(item);
}

/**
 * THE PACTS' GRANTS (Block 6's Draconic and Elemental Pact): once the Pact's
 * energy or element is chosen, its spell joins the sheet (granted by the
 * feat, so a Warlock's becomes innate and Focus as Block 6 does), or the one
 * it already granted takes the new type.
 */
export async function grantPactSpellB7(actor, pactItem, key, spellData) {
  const type = pactTypeFor(key, pactItem);
  if (!type) return null;
  const have = items(actor).find((i) => i.type === "spell" && R.keyOf(i) === key && i.flags?.[SYSTEM_ID]?.grantedBy?.sourceId === pactItem.id);
  if (have) { await setSpellType(have, type); return have; }
  if (items(actor).some((i) => i.type === "spell" && R.keyOf(i) === key)) return null;
  if (!spellData) return null;
  const out = JSON.parse(JSON.stringify(spellData));
  delete out._id;
  out.flags = {
    ...(out.flags ?? {}),
    [SYSTEM_ID]: { ...(out.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: pactItem.id, sourceName: pactItem.name, requested: out.name } },
    [MODULE_ID]: { ...(out.flags?.[MODULE_ID] ?? {}), [R.CHOSEN_TYPE_FLAG]: type }
  };
  const update = TYPED[key].update(out.system, type);
  for (const [path, value] of Object.entries(update)) globalThis.foundry?.utils?.setProperty?.(out, path, value);
  const [made] = await actor.createEmbeddedDocuments("Item", [out]);
  return made ?? null;
}

/** Refused until chosen; asked here first (a closed dialog when it arrived). */
export async function typeRefusal(ctx = {}) {
  const spell = ctx.spell;
  if (!TYPED[R.keyOf(spell)] || chosenType(spell)) return null;
  if (await askType(spell)) return null;
  return `${spell.name}: choose its damage type first (it is chosen once, when you learn the spell).`;
}

/* ================================================================== */
/* Elemental Strike (Strike)                                           */
/* ================================================================== */

export const STRIKE_STAMP = "elementalStrike";

const elementalStrikeUse = {
  hint: "1 AP: a creature in your weapon's reach makes a basic Reflex save (no multiple attack penalty).",
  async use(actor, item) {
    const stamp = item?.flags?.[MODULE_ID]?.[STRIKE_STAMP];
    if (!stamp?.dc) return warn("Elemental Strike: cast the spell first — its Save DC is fixed at the cast.");
    const weapon = items(actor).find((i) => i.type === "weapon" && i.system?.equipped && norm(i.system?.attackMode || "melee") === "melee");
    if (!weapon) return warn("Elemental Strike: wield a melee weapon (Q155).");
    const me = tokenOf(actor);
    const target = Array.from(globalThis.game?.user?.targets ?? [])[0] ?? null;
    if (!me || !target?.actor || target.actor === actor) return warn("Elemental Strike: target one creature within your weapon's reach.");
    const reach = Math.max(5, int(weapon.system?.reachFeet) || 5);
    if (!within(me, target, reach)) return warn(`Elemental Strike: ${target.name} is beyond your weapon's reach (${reach} ft).`);
    if (!(await spendAP(actor, "Elemental Strike", R.ELEMENTAL_STRIKE_AP))) return false;
    const formula = R.elementalStrikeFormula(stamp.dice, castingAbilityOf(actor));
    const hit = await h().basicSaveHit({ caster: actor, target: target.actor, save: "reflex", dc: int(stamp.dc), label: "Elemental Strike", formula, type: stamp.type, baseDamage: R.ELEMENTAL_STRIKE_BASE });
    await card(actor, "Elemental Strike", [line(`${esc(target.actor.name)}: a basic Reflex save at DC ${int(stamp.dc)} against <strong>${esc(formula)} ${esc(stamp.type)}</strong>. ${esc(hit?.line ?? "")}`), line("<em>No multiple attack penalty is taken or added (Q155). By hand: that it counts as a Strike for rules that count Strikes — this Use fires no Strike and no Strike count.</em>")]);
    return true;
  }
};

async function stampElementalStrike(actor, ctx) {
  const spell = ctx.spell;
  const granted = items(actor).filter((i) => i.type === "ability" && norm(i.name) === norm(R.ELEMENTAL_STRIKE_ABILITY));
  const ability = granted.at(-1);
  if (!ability) return;
  await ability.setFlag(MODULE_ID, STRIKE_STAMP, { dc: int(ctx.saveDC), dice: R.elementalStrikeDice(ctx.warpMods?.damageDice), type: chosenType(spell) || norm(spell?.system?.damage?.type) });
}

/* ================================================================== */
/* Arcane Feedback: a reaction cast inside the enemy's casting gate     */
/* ================================================================== */

export const FEEDBACK_STEP = "eldritchArts.arcaneFeedback";

export async function feedbackGate(ctx = {}) {
  const caster = ctx.actor;
  const casterToken = tokenOf(caster);
  if (!caster || !casterToken || ctx.itemCast) return null;
  for (const t of tokens()) {
    const reactor = t.actor;
    if (reactor === caster || !R.enemiesBySide(side(t), side(casterToken))) continue;
    const spell = spellByKey(reactor, "arcaneFeedback");
    if (!spell || !within(t, casterToken, R.FEEDBACK_FEET)) continue;
    if (await h().reactionRefusal?.(reactor, spell.system?.traits ?? "")) continue;
    if (int(reactor.system?.resources?.pp?.value) < int(spell.system?.ppCost)) continue;
    if (await h().castRefusal?.(reactor, spell)) continue;
    const q = await h().askReactor(reactor, {
      title: `Arcane Feedback — ${reactor.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> within ${R.FEEDBACK_FEET} feet of you.</p><p>Cast <strong>Arcane Feedback</strong> (${int(spell.system?.ppCost)} PP, your reaction)? Its damage is a penalty to that casting check.</p>`,
      buttons: yesNo("Cast Arcane Feedback"),
      step: FEEDBACK_STEP,
      data: { spellId: spell.id, targetTokenId: casterToken.id, casterUuid: caster.uuid }
    });
    if (!q?.result?.cast) continue;
    const penalty = R.feedbackPenalty(q.result.taken, ctx.rollsCheck !== false);
    const said = `${esc(reactor.name)}'s <strong>Arcane Feedback</strong>: ${esc(caster.name)} takes ${int(q.result.taken)} force damage${penalty ? `, a ${penalty} penalty to this casting check` : " (no casting check is rolled: no penalty)"}.`;
    return { modifiers: penalty ? [{ label: "Arcane Feedback", value: penalty, type: "untyped", castingOnly: true }] : [], lines: [said] };
  }
  return null;
}

/** On the reactor's client: the cast at the caster, the damage it took counted, the critical rolled. */
async function feedbackStep(actor, answer, data) {
  const spell = actor?.items?.get?.(data?.spellId);
  if (!spell) return { cast: false };
  let taken = 0;
  const watch = globalThis.Hooks?.on?.("trgPrimeDamageApplied", (p = {}) => { if (p.actor?.uuid === data.casterUuid) taken += int(p.amount); });
  let result;
  try {
    // castAsReaction sets the user's targets for the cast and puts them back (the 3.685.0 caveat).
    result = await h().castAsReaction(actor, spell, data?.targetTokenId ? [data.targetTokenId] : []);
  } finally {
    if (watch !== undefined) globalThis.Hooks?.off?.("trgPrimeDamageApplied", watch);
  }
  if (!result?.cast) return { cast: false };
  const degree = Array.from(result?.spellSave?.results ?? [])[0]?.degree ?? "";
  const severity = R.feedbackSeverity(degree, int(result?.warpMods?.bonusValue));
  const target = sourceActor(data.casterUuid);
  // THE REACTOR'S OWN SAVE DC, as the core's spell criticals pass it (cast-workflow's
  // `attackBonus: saveDC`, so a Death or Fatal row saves at Save DC + 10). castSpell does not
  // return it; the cast's own trgPrimeSpellSettled does (`settledSaveDC`).
  const saveDC = settledSaveDC(actor, "arcaneFeedback");
  if (severity && target) await h().rollCriticalInjury(actor, { targetActor: target, damageType: "force", severity, attackBonus: saveDC });
  return { cast: true, taken, degree, severity: severity ?? "", saveDC };
}

/* ================================================================== */
/* Regions the spells leave: Arcane Mycelium, Primal Snap, Zone Disruption */
/* ================================================================== */

export const REGION_FLAG = "grimoireArea";

/** The newest Region a cast of this spell drew (the core names it "<spell> Area"). */
/**
 * The newest unstamped Region this spell placed. TRG Prime names a placed area
 * "<spell> Area", and RENAMES it when the area is difficult terrain —
 * "<spell> (difficult terrain)" (`terrainRegionName`). Found live on 0.16.0:
 * Arcane Mycelium's Region was never found, so its DC, its reactive warp and
 * its light were never stamped.
 */
export function regionNamedFor(regionName, spellName) {
  const n = norm(regionName), s = norm(spellName);
  return Boolean(s) && (n === norm(`${spellName} Area`) || n.startsWith(`${s} (`));
}
function newestRegionOf(spellName) {
  const regions = Array.from(globalThis.canvas?.scene?.regions ?? []).filter((r) => regionNamedFor(r.name, spellName) && !r.flags?.[MODULE_ID]?.[REGION_FLAG]);
  return regions.at(-1) ?? null;
}
async function stampRegion(ctx, key, extra = {}) {
  const region = newestRegionOf(ctx.spell?.name);
  if (!region) return null;
  const record = { key, casterUuid: ctx.actor?.uuid ?? "", dc: int(ctx.saveDC), unlocks: unlocksOf(ctx.warpMods), damageDice: String(ctx.warpMods?.damageDice ?? ""), spellName: ctx.spell?.name ?? "", ...extra };
  await region.setFlag(MODULE_ID, REGION_FLAG, record);
  return region;
}
export function grimoireRegions(key) {
  return Array.from(globalThis.canvas?.scene?.regions ?? []).filter((r) => r.flags?.[MODULE_ID]?.[REGION_FLAG]?.key === key);
}
async function inside(region, token) {
  if (!region || !token) return false;
  return Boolean(await h().regionContains(region, tokenCentre(token)));
}

/** Arcane Mycelium's +2 PP: a creature inside that casts takes 2d6 essence (basic Fort). */
export async function myceliumGate(ctx = {}) {
  const token = tokenOf(ctx.actor);
  if (!token || ctx.itemCast) return null;
  const lines = [];
  for (const region of grimoireRegions("arcaneMycelium")) {
    const rec = region.flags[MODULE_ID][REGION_FLAG];
    if (!rec.unlocks.includes(R.MYCELIUM_REACTIVE_UNLOCK) || !(await inside(region, token))) continue;
    const hit = await h().basicSaveHit({ caster: sourceActor(rec.casterUuid), target: ctx.actor, save: "fortitude", dc: rec.dc, label: "Arcane Mycelium", formula: R.MYCELIUM_DICE, type: "essence" });
    lines.push(`<strong>Arcane Mycelium</strong> leeches ${esc(ctx.actor.name)}'s casting: ${R.MYCELIUM_DICE} essence (basic Fortitude, DC ${rec.dc}). ${esc(hit?.line ?? "")}`);
  }
  return lines.length ? { lines } : null;
}

/** Is this creature subject to a Zone Disruption it stands in? The region, or null. */
async function zoneOver(actor) {
  const token = tokenOf(actor);
  if (!token) return null;
  for (const region of grimoireRegions("zoneDisruption")) {
    if (!(await inside(region, token))) continue;
    const rec = region.flags[MODULE_ID][REGION_FLAG];
    const exempt = effects(actor).some((e) => !e?.disabled && markRecord(e, R.ZONE_EXEMPT_MARK)?.casterUuid === rec.casterUuid);
    if (!exempt) return region;
  }
  return null;
}

/** H8: casting checks at disadvantage; an innate cast rolls Spellcraft (Q154). */
export async function zoneGate(ctx = {}) {
  if (ctx.itemCast) return null;
  const region = await zoneOver(ctx.actor);
  if (!region) return null;
  return {
    disadvantage: true, innateCheck: ctx.innate === true,
    lines: [`<strong>Zone Disruption</strong>: the casting check is at disadvantage${ctx.innate ? "; this innate spell rolls Spellcraft (innate ability + level) against 10 + ⌊1.5 × PP⌋" : ""}.`]
  };
}

/** The +2 PP option: "roll on the fumble table twice and use the higher result". */
export async function zoneFumble(ctx = {}) {
  if (!ctx.actor || ctx.check?.type !== "spellcraft") return null;
  const region = await zoneOver(ctx.actor);
  if (!region?.flags?.[MODULE_ID]?.[REGION_FLAG]?.unlocks?.includes(R.ZONE_FUMBLE_UNLOCK)) return null;
  return { bias: "disadvantage", label: "Zone Disruption", line: "Zone Disruption: the fumble table is rolled twice, the higher result kept." };
}

/** The Region's Concentration rise (H8's castingZone), with the creatures that rolled a Critical. */
async function writeCastingZone(region) {
  const rec = region?.flags?.[MODULE_ID]?.[REGION_FLAG];
  if (!rec) return;
  const exempt = [];
  for (const t of tokens()) if (effects(t.actor).some((e) => markRecord(e, R.ZONE_EXEMPT_MARK)?.casterUuid === rec.casterUuid)) exempt.push(t.actor.uuid);
  await region.setFlag(SYSTEM_ID, "castingZone", { concentrationDC: R.ZONE_CONCENTRATION_RISE, label: "Zone Disruption", exempt });
}

/** Hooks.on("createActiveEffect"): only a creature's first Zone Disruption result counts. */
export async function onEffectCreatedB7(effect) {
  const actor = effect?.parent;
  const exempt = markRecord(effect, R.ZONE_EXEMPT_MARK), affected = markRecord(effect, R.ZONE_AFFECTED_MARK);
  const rec = exempt ?? affected;
  if (!rec || !actor?.isOwner || !actsFor(actor)) return;
  const earlier = effects(actor).filter((e) => e.id !== effect.id && (markRecord(e, R.ZONE_EXEMPT_MARK) ?? markRecord(e, R.ZONE_AFFECTED_MARK))?.castId === rec.castId);
  if (earlier.length) { await actor.deleteEmbeddedDocuments("ActiveEffect", [effect.id]); return; }
  if (exempt) for (const region of grimoireRegions("zoneDisruption")) if (region.flags[MODULE_ID][REGION_FLAG].casterUuid === rec.casterUuid) await writeCastingZone(region);
}

/** Primal Snap: a creature that begins its turn in the fog (Hooks.on("updateCombat")). */
export async function onCombatTurnB7(combat, change = {}) {
  if (!("turn" in (change ?? {})) && !("round" in (change ?? {}))) return;
  const actor = combat?.combatant?.actor;
  const token = combat?.combatant?.token?.object ?? tokenOf(actor);
  if (!actor || !token || !actor.isOwner || !actsFor(actor)) return;
  for (const region of grimoireRegions("primalSnap")) {
    if (!(await inside(region, token))) continue;
    const rec = region.flags[MODULE_ID][REGION_FLAG];
    const dice = R.snapDice(rec.damageDice);
    const hit = await h().basicSaveHit({ caster: sourceActor(rec.casterUuid), target: actor, save: "fortitude", dc: rec.dc, label: "Primal Snap", formula: dice, type: "cold" });
    const lines = [line(`${esc(actor.name)} begins its turn in the fog: ${dice} cold (basic Fortitude, DC ${rec.dc}). ${esc(hit?.line ?? "")}`)];
    // A BASIC SAVE'S PARTIAL IS ITS OWN RESULT (half damage), not a failure: Failure, Fumble or Blunder only.
    if (R.basicSaveFailed(hit?.degree) && !ownEffects(actor, "primalSnapSpeed").length) {
      await h().createEffectsOn(actor, [primalSnapSpeedEffect(actor)]);
      lines.push(line(`${esc(actor.name)}: −10 status to its Speeds until it regains any HP (Q160).`));
    }
    await card(actor, "Primal Snap", lines);
  }
}
/** −10 status to every Speed it has, ended by any healing (H11's `endsOnHeal`). */
export function primalSnapSpeedEffect(actor) {
  const movement = actor?.system?.combat?.movement ?? {};
  const keys = ["land", "fly", "swim", "climb", "burrow"].filter((k) => Number(movement[k]?.base ?? movement[k] ?? 0) > 0);
  return effectData("primalSnapSpeed", {
    name: "Primal Snap: −10 Speeds (until healed)", img: "icons/magic/water/snowflake-ice-blue.webp",
    description: "A failed save in Primal Snap's fog: −10 status to Speeds until it regains HP.",
    changes: keys.map((k) => ({ key: `system.combat.movement.${k}.status`, mode: 0, value: String(R.SNAP_SPEED_PENALTY) })),
    system: { endsOnHeal: true }
  });
}

/* ================================================================== */
/* Invoke True Name                                                     */
/* ================================================================== */

/** The caster's live mark on this creature, or null. */
function trueNameOn(target, caster) {
  const e = effects(target).find((x) => !x?.disabled && markRecord(x, R.TRUE_NAME_MARK)?.casterUuid === caster?.uuid);
  return e ? { effect: e, record: markRecord(e, R.TRUE_NAME_MARK) } : null;
}

/** Spell attacks against it treat it as flat-footed (an attack-only gate row, G14). */
export async function trueNameGate(ctx = {}) {
  if (!ctx.attack || ctx.itemCast) return null;
  const rows = [];
  for (const uuid of ctx.targetUuids ?? []) {
    const target = sourceActor(uuid);
    if (!trueNameOn(target, ctx.actor) || target?.hasCondition?.("flatFooted")) continue;
    const loss = R.flatFootedLossOf(target.system?.combat?.defence);
    if (loss > 0) rows.push({ label: `Invoke True Name: ${target.name} flat-footed`, value: loss, type: "untyped", attackOnly: true });
  }
  return rows.length ? { modifiers: rows, lines: rows.map((r) => `${esc(r.label)} (+${r.value} on the spell attack).`) } : null;
}

const trueNameSave = {
  before(ctx = {}) {
    if (ctx.type !== "save") return null;
    const caster = sourceActor(ctx.sourceUuid);
    const on = caster ? trueNameOn(ctx.actor, caster) : null;
    if (!on) return null;
    const value = R.trueNamePenalty(on.record?.casterLevel);
    return { modifiers: [{ label: "Invoke True Name", value, type: "circumstance" }], line: `${esc(ctx.actor.name)}'s true name was spoken: ${value} to this save.` };
  }
};


/* ================================================================== */
/* Writes on a creature this client may not own, and work for its owner  */
/* ================================================================== */

/**
 * A REACTION RUNS ON THE CLIENT THAT ROLLED: the attacker's, the caster's. The
 * creature it changes (an NPC's mark, a PC's Spectral Aegis, Mirror Reprise's
 * images) is often not that client's to write, and Foundry refuses a player's
 * write to an actor they do not own. So the write is made here when this
 * client owns the creature, and otherwise asked of the active GM through the
 * module socket (Block 3b's channel, its hex-immunity pattern). The GM side
 * does only these writes, on this module's own state, and checks each against
 * the creature's CURRENT state, never against what the request says
 * (second review, finding 1):
 *   effectFlag     on one of this module's own effects, under that effect's
 *                  own source key: a known counter (images, absorbs, attempts)
 *                  down by one with nothing else changed, or Mirror Reprise's
 *                  images armed from 0 to 3 with nothing else changed;
 *   deleteEffects  effects this module made, and effects stamped with a cast
 *                  id the creature's own state names: its Arcane Bastion
 *                  record, or the cast id on a Spectral Aegis or Mirror
 *                  Reprise effect of its own deleted in the same write. The
 *                  request's own cast id is ignored. When the Bastion's cast
 *                  has no effect left, its record is cleared too.
 * No PP is written for another: Argent Reversal's refund is made in its step,
 * on the bearer's own client (finding 2).
 * WORK FOR THE CREATURE'S OWNER (a teleport's click): `ownerTask`, run by the
 * client that acts for it (`actsFor`), here when that is this client.
 */
export const B7_ACTION = "eaBlock7";
// 0.11.0 (Block 8a): a Binding's "Bound to …" effect, deleted by the caster's client when the spell ends.
// 0.12.0 (Block 8b): Soul Confluence's links, deleted by the caster's client when the spell ends.
export const OWN_SOURCES = Object.freeze(["argentReversal", "spectralAegis", "mirrorReprise", "metamagicResonance", "chronoweave", "primalSnapSpeed", "bouncyBody", "bound8a", "confluenceLink8b"]);
// 0.12.0 (Block 8b): Soul Confluence's shared pool, taken down by a participant's damage.
export const FLAG_KEYS = Object.freeze(["spectralAegis", "mirrorReprise", "argentReversal", "soulConfluence8b"]);
/** The pools a relayed write may take down by any amount (never up), by flag key. */
export const FLAG_DRAINS = Object.freeze({ soulConfluence8b: "pool" });
/** The counters a relayed write may take down by one, by flag key. */
export const FLAG_COUNTERS = Object.freeze({ spectralAegis: "absorbs", mirrorReprise: "images", argentReversal: "attempts" });
const ownerTasks = {};

const sameJSON = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
/** Is `next` an allowed change of `prev` under `key`? Pure. */
export function flagChangeAllowed(key, prev, next) {
  const drain = FLAG_DRAINS[key];
  if (drain) {
    if (!prev || typeof prev !== "object" || !next || typeof next !== "object" || Array.isArray(next)) return false;
    for (const k of new Set([...Object.keys(prev), ...Object.keys(next)])) if (k !== drain && !sameJSON(prev[k], next[k])) return false;
    const was = int(prev[drain]), now = next[drain];
    return Number.isInteger(now) && now >= 0 && now < was;
  }
  const field = FLAG_COUNTERS[key];
  if (!field || !prev || typeof prev !== "object" || !next || typeof next !== "object" || Array.isArray(next)) return false;
  const keys = new Set([...Object.keys(prev), ...Object.keys(next)]);
  for (const k of keys) if (k !== field && !sameJSON(prev[k], next[k])) return false;
  const was = int(prev[field]), now = next[field];
  if (!Number.isInteger(now)) return false;
  if (now === was - 1 && now >= 0) return true;
  // Mirror Reprise's duplicates appear: 0 → 3, once.
  return key === "mirrorReprise" && was === 0 && now === R.MIRROR_IMAGES;
}
/** The cast ids the creature's own state allows a relayed delete to sweep, for these effect ids. */
export function allowedCastIds(actor, effectsOfActor = [], ids = []) {
  const out = new Set();
  const bastion = actor?.flags?.[MODULE_ID]?.[BASTION_FLAG]?.castId;
  if (bastion) out.add(String(bastion));
  for (const id of ids) {
    const e = effectsOfActor.find((x) => x.id === id);
    const src = e?.flags?.[MODULE_ID]?.source;
    if (src !== AEGIS_FLAG && src !== MIRROR_FLAG) continue;
    const c = e.flags?.[MODULE_ID]?.[src]?.castId;
    if (c) out.add(String(c));
  }
  return out;
}

/** Is this GM write one the module makes, on this creature as it is now? A reason, or "". Pure. */
export function writeRefusal(op = {}, effectsOfActor = [], actor = null) {
  if (op.kind === "effectFlag") {
    const e = effectsOfActor.find((x) => x.id === op.effectId);
    const src = e?.flags?.[MODULE_ID]?.source;
    if (!e || !FLAG_KEYS.includes(op.key) || src !== op.key) return "not this module's flag";
    return flagChangeAllowed(op.key, e.flags?.[MODULE_ID]?.[op.key], op.value) ? "" : "not a change the module makes";
  }
  if (op.kind === "deleteEffects") {
    const ids = Array.from(op.ids ?? []);
    const casts = allowedCastIds(actor, effectsOfActor, ids);
    const allowed = ids.every((id) => {
      const e = effectsOfActor.find((x) => x.id === id);
      if (!e) return true;
      if (OWN_SOURCES.includes(e.flags?.[MODULE_ID]?.source)) return true;
      const c = e.flags?.[SYSTEM_ID]?.castId;
      return Boolean(c) && casts.has(String(c));
    });
    return ids.length && allowed ? "" : "not this module's effects";
  }
  return "unknown write";
}

/** Do the write (on a creature this client owns, or as the GM). */
export async function applyWrite(actor, op) {
  if (!actor) return false;
  const list = effects(actor);
  if (writeRefusal(op, list, actor)) return false;
  if (op.kind === "effectFlag") { const fx = list.find((e) => e.id === op.effectId); if (fx) await fx.setFlag(MODULE_ID, op.key, op.value); return Boolean(fx); }
  if (op.kind === "deleteEffects") {
    const ids = op.ids.filter((id) => list.some((e) => e.id === id));
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids);
    // The Bastion's record goes with the last of its cast's effects.
    const bastion = actor.flags?.[MODULE_ID]?.[BASTION_FLAG]?.castId;
    if (bastion && !effects(actor).some((e) => castIdOf(e) === bastion)) await actor.unsetFlag?.(MODULE_ID, BASTION_FLAG);
    return true;
  }
  return false;
}

/** Write here, or have the GM write it. */
export async function writeOn(actor, op) {
  if (!actor) return false;
  if (actor.isOwner) return applyWrite(actor, op);
  const game = globalThis.game;
  if (!game?.users?.activeGM) { globalThis.ui?.notifications?.warn?.(`No GM is connected to update ${actor.name} (Eldritch Arts): apply it by hand.`); return false; }
  game.socket?.emit?.(SOCKET, { action: B7_ACTION, kind: "write", actorUuid: actor.uuid, op });
  return true;
}

/** Run a task on the creature's owner's client (here, if this client acts for it). */
export async function forOwner(actor, task, data = {}) {
  if (!actor || !ownerTasks[task]) return false;
  if (actsFor(actor)) { await ownerTasks[task](actor, data); return true; }
  globalThis.game?.socket?.emit?.(SOCKET, { action: B7_ACTION, kind: "owner", actorUuid: actor.uuid, task, data });
  return true;
}

/** The socket's two sides. */
export async function onBlock7Socket(data = {}) {
  if (data?.action !== B7_ACTION) return false;
  const game = globalThis.game;
  const actor = sourceActor(data.actorUuid) ?? await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(data.actorUuid);
  if (!actor) return false;
  if (data.kind === "write") {
    if (!isActingGM()) return false;
    return applyWrite(actor, data.op ?? {});
  }
  if (data.kind === "owner" && ownerTasks[data.task] && actsFor(actor)) { await ownerTasks[data.task](actor, data.data ?? {}); return true; }
  return false;
}
export function registerBlock7Socket() {
  globalThis.game?.socket?.on?.(SOCKET, (data) => { onBlock7Socket(data).catch((err) => console.warn("Eldritch Arts | Block 7 socket", err)); });
}

/* ================================================================== */
/* What a cast leaves on its caster                                       */
/* ================================================================== */

/** The Save DC each cast settled at, by caster and spell key (castSpell does not return it). */
const settledDC = new Map();
export const settledSaveDC = (actor, key) => int(settledDC.get(`${actor?.uuid}:${key}`));

/**
 * THE CAST'S OWN ACTIVE-SPELL ENTRY (the core's `getActiveSpells`, the
 * `activeSpells` flag): its id is the cast id the spell's effects carry. A
 * cast that does not register (a plain fixed duration) has none, and "".
 */
export function activeEntryFor(actor, spellName) {
  const entries = Array.from(actor?.getFlag?.(SYSTEM_ID, "activeSpells") ?? actor?.flags?.[SYSTEM_ID]?.activeSpells ?? []);
  return entries.filter((e) => norm(e?.name) === norm(spellName)).at(-1) ?? null;
}
const castRunning = (actor, castId) => Boolean(castId) && Array.from(actor?.getFlag?.(SYSTEM_ID, "activeSpells") ?? actor?.flags?.[SYSTEM_ID]?.activeSpells ?? []).some((e) => e?.id === castId);

/** "1 minute", "10 minutes", "1 hour (D)" → seconds (the spell's duration, warped). */
export function durationSeconds(text) {
  const m = /(\d+)\s*(round|minute|hour|day)s?/i.exec(String(text ?? ""));
  if (!m) return 0;
  return int(m[1]) * { round: 6, minute: 60, hour: 3600, day: 86400 }[m[2].toLowerCase()];
}
const warpedDuration = (ctx) => String(ctx.warpMods?.durationText || ctx.spellData?.duration || ctx.spell?.system?.duration || "");

/* ================================================================== */
/* Invoke True Name's weakness (spent on the caster's own record)          */
/* ================================================================== */

export const TRUE_NAME_SPENT = "trueNameWeakSpent";
async function trueNameWeak(ctx = {}) {
  if (ctx.kind !== "spell" || !ctx.types?.length) return null;
  const caster = sourceActor(ctx.sourceUuid);
  const on = caster ? trueNameOn(ctx.target, caster) : null;
  if (!on) return null;
  // KEPT ON THE CASTER (found in review): the mark sits on the named creature,
  // often the GM's, and a player's client may not write it.
  const key = `${on.effect.id}:${on.record?.castId ?? ""}`;
  const spent = Array.from(caster.flags?.[MODULE_ID]?.[TRUE_NAME_SPENT] ?? []);
  if (spent.includes(key)) return null;
  await caster.setFlag?.(MODULE_ID, TRUE_NAME_SPENT, [...spent.slice(-19), key]);
  return { weak: Array.from(ctx.types), scope: "cast", line: `${esc(ctx.target.name)}'s true name: weakness to this spell's ${esc(ctx.types.join(" and "))} damage.` };
}

/* ================================================================== */
/* Planar Anchor (the veil kept on the caster)                           */
/* ================================================================== */

export const ANCHOR_VEIL_FLAG = "anchorVeilCasts";
export async function anchorRefusal(ctx = {}) {
  const spell = ctx.spell;
  const traits = ctx.spellData?.traits ?? spell?.system?.traits ?? "";
  const involved = [ctx.actor, ...Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor)].filter(Boolean);
  for (const creature of involved) {
    const anchor = markOf(creature, R.ANCHOR_MARK);
    if (!anchor) continue;
    const rec = markRecord(anchor, R.ANCHOR_MARK);
    const veil = Array.from(sourceActor(rec?.casterUuid)?.flags?.[MODULE_ID]?.[ANCHOR_VEIL_FLAG] ?? []).includes(rec?.castId);
    const why = R.anchorRefuses({ traits, name: spell?.name, veil });
    if (why) return `${creature.name} is held by Planar Anchor: ${spell?.name ?? "the spell"} is counteracted${why === "veil" ? " (it would make it invisible or incorporeal)" : ""}.`;
  }
  return null;
}

/* ================================================================== */
/* Arcane Bastion                                                        */
/* ================================================================== */

export const BASTION_FLAG = "arcaneBastion";
const bastionAfter = async (ctx = {}) => {
  const target = ctx.target;
  const record = target?.flags?.[MODULE_ID]?.[BASTION_FLAG];
  if (!record?.castId || !R.injuryIncapacitates(ctx.row)) return null;
  if (!effects(target).some((e) => castIdOf(e) === record.castId)) return null;
  // THE ANSWER FIRST (second review, finding 3): a write that fails must not lose the lowered severity.
  const answer = { severitySteps: -record.steps, line: `<strong>Arcane Bastion</strong> shatters: the injury is read ${record.steps} severit${record.steps === 1 ? "y" : "ies"} lower.` };
  try { await endBastion(target, record.castId); } catch (err) { console.warn("Eldritch Arts | ending Arcane Bastion", err); }
  return answer;
};
/**
 * A PLAIN 10-MINUTE CAST IS NOT IN THE CORE'S REGISTRY (found in review):
 * `endActiveSpell` returns null for it and its effects stay. So the caster's
 * effects carrying the cast id (the resistance, the death guard) are deleted
 * here, as Spectral Aegis's are; a registered cast is ended too.
 */
async function endBastion(actor, castId) {
  if (castRunning(actor, castId)) { try { await h().endSpellOf(actor, castId); } catch (err) { console.warn("Eldritch Arts | ending a spell", err); } }
  const ids = effects(actor).filter((e) => castIdOf(e) === castId).map((e) => e.id);
  if (ids.length) await writeOn(actor, { kind: "deleteEffects", ids });
  // On a creature this client does not own, the GM clears the record with the last effect.
  if (actor?.isOwner && actor?.flags?.[MODULE_ID]?.[BASTION_FLAG]?.castId === castId) await actor.unsetFlag?.(MODULE_ID, BASTION_FLAG);
}
/** Hooks.on("trgPrimeDeathGuardHeld"): the 0 HP clause also ends the spell. */
export async function onDeathGuardHeldB7(ctx = {}) {
  if (norm(ctx.label) !== "arcane bastion" || !ctx.actor?.isOwner) return;
  const record = ctx.actor.flags?.[MODULE_ID]?.[BASTION_FLAG];
  if (record?.castId) await endBastion(ctx.actor, record.castId);
  await card(ctx.actor, "Arcane Bastion", [line("The shield shatters: you are left on 1 HP, and the spell ends.")]);
}

/* ================================================================== */
/* Argent Reversal and Spectral Aegis (H5)                               */
/* ================================================================== */

export const ARGENT_FLAG = "argentReversal";
export const AEGIS_FLAG = "spectralAegis";
export const ARGENT_STEP = "eldritchArts.argentReversal";
export const AEGIS_STEP = "eldritchArts.spectralAegis";

/** Q153 "you are aware of": the bearer is not blinded, and the caster's token is neither hidden nor invisible. */
export const canSee = (bearer, casterToken) => !bearer?.hasCondition?.("blinded") && !casterToken?.document?.hidden && !casterToken?.actor?.hasCondition?.("invisible");
/** A spell's printed range in feet (touch 5), or 0 when it has none to measure. */
export function rangeFeetOf(range) {
  const t = String(range ?? "").toLowerCase();
  if (/touch/.test(t)) return 5;
  const m = /(\d+)\s*(feet|foot|ft)/.exec(t);
  return m ? int(m[1]) : 0;
}

export async function argentReaction(ctx = {}) {
  const caster = ctx.actor, casterToken = ctx.token ?? tokenOf(caster);
  if (!caster || !casterToken) return null;
  for (const t of tokens()) {
    const bearer = t.actor;
    if (bearer === caster) continue;
    const charge = ownEffects(bearer, ARGENT_FLAG)[0];
    const rec = charge?.flags?.[MODULE_ID]?.[ARGENT_FLAG];
    if (!rec || int(rec.attempts) <= 0) continue;
    if (!canSee(bearer, casterToken) || !R.argentReaches(ctx.castPP ?? ctx.pp, casterLevelOf(bearer))) continue;
    if (await h().reactionRefusal?.(bearer, "Utility, Warding")) continue;
    const q = await h().askReactor(bearer, {
      title: `Argent Reversal — ${bearer.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${int(ctx.castPP ?? ctx.pp)} PP).</p><p>Use your reaction to redirect it? Spellcraft against its Save DC ${int(ctx.saveDC)}.${rec.absorb ? " A success absorbs it instead." : ""}</p>`,
      buttons: yesNo("Redirect it"),
      step: ARGENT_STEP,
      data: { dc: int(ctx.saveDC), effectId: charge.id, casterTokenId: casterToken.id, rangeFeet: rangeFeetOf(ctx.spellData?.range ?? ctx.spell?.system?.range), castPP: int(ctx.castPP ?? ctx.pp) }
    });
    if (!q?.result?.rolled) continue;
    const out = R.argentOutcome(q.result.degree);
    const said = [`${esc(bearer.name)}'s <strong>Argent Reversal</strong> (${esc(q.result.degree)}, ${int(q.result.total)})`];
    if (out.backlash) {
      const hit = await h().basicSaveHit({ caster, target: bearer, save: "fortitude", dc: int(ctx.saveDC), label: "Argent Reversal", formula: out.backlash, type: "essence" });
      said.push(`fails and lashes back: ${out.backlash} essence (basic Fortitude). ${esc(hit?.line ?? "")}`);
      return { line: said.join(" ") };
    }
    if (!out.turn) return { line: `${said[0]} fails: the spell resolves as cast.` };
    if (rec.absorb) {
      // THE REFUND IS THE BEARER'S OWN (second review, finding 2): made in the step, on its client.
      const regain = int(q.result.regained);
      return { exclude: [bearer.uuid], line: `${said[0]} absorbs it: it lands on everyone but ${esc(bearer.name)}, who regains ${regain} PP.` };
    }
    return { turnBack: { checkTotal: int(q.result.total), saveDC: int(rec.saveDC), target: q.result.target ?? "" }, line: `${said[0]} turns it back${q.result.target ? " on the creature chosen" : " on its caster"}, at Spellcraft ${int(q.result.total)} and Save DC ${int(rec.saveDC)}.` };
  }
  return null;
}

/** The creatures a Critical may turn it on: within the original spell's range of its caster (Q153). */
export function redirectChoices(actor, casterToken, rangeFeet) {
  const near = rangeFeet > 0 && casterToken ? tokens().filter((t) => t.actor !== actor && t !== casterToken && within(casterToken, t, rangeFeet)) : [];
  return [["", "Its caster"], ...near.map((t) => [t.actor.uuid, t.name])];
}

/** On the bearer's client: the reaction, the Spellcraft check, a Critical's choice, the attempt spent. */
async function argentStep(actor, answer, data) {
  if (!(await h().spendReaction?.(actor, "Argent Reversal", { traits: "Utility, Warding" }))) return { rolled: false };
  // THE SHEET'S SPELLCRAFT (0.12.0; found live with Mimic Spell): rollCheck
  // fills a save's or a skill's modifiers, not Spellcraft's, so this rolled +0.
  const sc = actor.system?.magic?.spellcraft ?? {};
  const modifiers = Array.isArray(sc.checkModifiers) && sc.checkModifiers.length ? sc.checkModifiers : [{ label: "Spellcraft", value: Number(sc.total ?? 0) || 0, type: "untyped" }];
  const check = await h().rollCheck({ actor, type: "spellcraft", label: `${actor.name} — Argent Reversal (Spellcraft)`, dc: int(data?.dc), modifiers });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  let target = "";
  if (R.argentOutcome(degree).choose) {
    const casterToken = tokens().find((t) => t.id === data?.casterTokenId) ?? null;
    target = String(await h().chooseFromList("Argent Reversal", "A Critical: turn it on its caster, or on another creature within its original range:", redirectChoices(actor, casterToken, int(data?.rangeFeet))) ?? "");
  }
  const charge = effects(actor).find((e) => e.id === data?.effectId) ?? null;
  const rec = charge?.flags?.[MODULE_ID]?.[ARGENT_FLAG];
  // An absorb's refund, here on the bearer's own client, at most to its PP maximum.
  let regained = 0;
  if (rec?.absorb && R.argentOutcome(degree).turn) {
    const pp = actor.system?.resources?.pp ?? {};
    const room = Number.isFinite(Number(pp.max)) && pp.max !== undefined && pp.max !== null ? Math.max(0, int(pp.max) - int(pp.value)) : Infinity;
    regained = Math.min(R.argentAbsorbPP(data?.castPP), room);
    if (regained > 0) await actor.update({ "system.resources.pp.value": int(pp.value) + regained });
  }
  if (rec) {
    const left = int(rec.attempts) - 1;
    if (left <= 0) await charge.delete?.();
    else await charge.setFlag?.(MODULE_ID, ARGENT_FLAG, { ...rec, attempts: left });
  }
  return { rolled: true, degree, total: int(check?.outcome?.total), target, regained };
}

export async function aegisReaction(ctx = {}) {
  const caster = ctx.actor, casterToken = ctx.token ?? tokenOf(caster);
  if (!caster || !casterToken || ctx.spellData?.category === "utility") return null;
  const area = String(ctx.spellData?.area ?? "").trim();
  const targeted = new Set(Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor?.uuid));
  const excluded = [];
  const said = [];
  for (const t of tokens()) {
    const warded = t.actor;
    // Q152: a HOSTILE spell — its caster is not the warded creature's ally (nor itself).
    if (warded === caster || allies(side(t), side(casterToken))) continue;
    const fx = ownEffects(warded, AEGIS_FLAG)[0];
    const state = fx?.flags?.[MODULE_ID]?.[AEGIS_FLAG];
    if (!state || !R.aegisAbsorbs(ctx.castPP ?? ctx.pp, state)) continue;
    if (!targeted.has(warded.uuid)) {
      if (!area) continue;
      const q = await h().askReactor(warded, {
        title: `Spectral Aegis — ${warded.name}`,
        content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "an area spell")}</strong> (${esc(area)}).</p><p>Will ${esc(warded.name)} be in its area? Yes: the Aegis absorbs it for you and ends.</p>`,
        buttons: yesNo("Absorb it"), step: AEGIS_STEP, data: {}
      });
      if (!q?.result?.yes) continue;
    }
    excluded.push(warded.uuid);
    said.push(`${esc(warded.name)}'s <strong>Spectral Aegis</strong> absorbs ${esc(ctx.spell?.name ?? "the spell")}.`);
    const left = int(state.absorbs) - 1;
    if (left <= 0) await endAegis(warded, fx);
    else await writeOn(warded, { kind: "effectFlag", effectId: fx.id, key: AEGIS_FLAG, value: { ...state, absorbs: left } });
  }
  return excluded.length ? { exclude: excluded, line: said.join("<br>") } : null;
}
async function endAegis(warded, fx) {
  const castId = String(fx.flags?.[MODULE_ID]?.[AEGIS_FLAG]?.castId ?? "");
  const resist = castId ? effects(warded).filter((e) => castIdOf(e) === castId).map((e) => e.id) : [];
  await writeOn(warded, { kind: "deleteEffects", ids: [...new Set([fx.id, ...resist])] });
}
const aegisStep = async (actor, answer) => ({ yes: answer === "yes" });

/* ================================================================== */
/* Mirror Reprise (H6) and Panic Transposition                           */
/* ================================================================== */

export const MIRROR_FLAG = "mirrorReprise";
const mirrorCastStamp = (castId) => (castId ? { castId: String(castId) } : {});
/** The waiting effect, while its cast runs (a dismissed (D) cast's effect does nothing, should it outlive the sweep). */
const mirrorLive = (actor, fx) => { const rec = fx?.flags?.[MODULE_ID]?.[MIRROR_FLAG]; return Boolean(rec) && (!rec.castId || castRunning(actor, rec.castId)); };
const mirrorOf = (actor) => {
  const fx = ownEffects(actor, MIRROR_FLAG).find((e) => mirrorLive(actor, e));
  return fx ? { fx, rec: fx.flags[MODULE_ID][MIRROR_FLAG] } : null;
};

async function mirrorArm(ctx = {}) {
  const m = mirrorOf(ctx.target);
  if (!m || int(m.rec.images) > 0) return null;
  const hostileSpell = ctx.kind === "spell" && m.rec.spellTriggers && !sameCreature(ctx.sourceUuid, ctx.target);
  if (ctx.kind !== "weapon" && !hostileSpell) return null;
  await writeOn(ctx.target, { kind: "effectFlag", effectId: m.fx.id, key: MIRROR_FLAG, value: { ...m.rec, images: R.MIRROR_IMAGES } });
  return { line: `<strong>Mirror Reprise</strong>: three duplicates of ${esc(ctx.target.name)} appear.` };
}

const mirrorAfter = async (ctx = {}) => {
  if (ctx.type !== "attack" || !ctx.succeeded || !ctx.target) return null;
  const m = mirrorOf(ctx.target);
  if (!m || int(m.rec.images) <= 0) return null;
  const roll = await new Roll("1d100").evaluate();
  if (!R.mirrorDiverts(m.rec.images, roll.total)) return null;
  const left = int(m.rec.images) - 1;
  // THE LAST DUPLICATE ENDS IT (found in review): the spell is note-only, so the
  // waiting effect is deleted itself, and a registered (D) cast is ended too.
  if (left <= 0) {
    await writeOn(ctx.target, { kind: "deleteEffects", ids: [m.fx.id] });
    if (m.rec.castId && castRunning(ctx.target, m.rec.castId)) { try { await h().endSpellOf(ctx.target, m.rec.castId); } catch (err) { console.warn("Eldritch Arts | ending a spell", err); } }
  } else await writeOn(ctx.target, { kind: "effectFlag", effectId: m.fx.id, key: MIRROR_FLAG, value: { ...m.rec, images: left } });
  // THE TELEPORT IS THE BEARER'S (found in review): asked and clicked on its owner's client.
  if (m.rec.teleport) await forOwner(ctx.target, "mirrorStep", {});
  return { miss: true, label: "Mirror Reprise", line: `d100 ${roll.total}: the attack struck a duplicate of ${esc(ctx.target.name)} — a miss; ${Math.max(0, left)} duplicate${left === 1 ? "" : "s"} left.` };
};
ownerTasks.mirrorStep = async (bearer) => {
  const token = tokenOf(bearer);
  if (!token) return;
  if (!(await globalThis.foundry?.applications?.api?.DialogV2?.confirm?.({ window: { title: `Mirror Reprise — ${bearer.name}` }, content: "<p>A duplicate is destroyed. Teleport up to 10 feet as a reaction?</p>" }))) return;
  if (await h().spendReaction?.(bearer, "Mirror Reprise", { traits: "Teleportation" })) await teleportWithin(token, R.MIRROR_TELEPORT_FEET, "Mirror Reprise");
};

/**
 * PANIC TRANSPOSITION. Asked on the attacker's client by the check reaction;
 * cast on the bearer's (its reaction step). Then, held in memory on the
 * attacker's client (where that attack resolves and its damage is applied),
 * for that attacker and bearer only:
 *  - the resistance warp answers the triggering attack's damage;
 *  - "After resolving the triggering attack, you teleport" (L7324): once the
 *    attack is resolved — `trgPrimeStrikeResolved` for a weapon Strike, the
 *    attacker's `trgPrimeSpellSettled` for a spell attack, both on the
 *    attacker's client and after the damage — that client relays the teleport
 *    to the bearer's owner (or the GM) over the module socket (`forOwner`),
 *    and the record is cleared. An attack never resolved, a cast refunded or
 *    not cast, or a bearer down or gone: the record is cleared, nothing sent;
 *  - the occupied square's basic Fortitude is at the Panic cast's own Save DC,
 *    read from its settled cast (castSpell does not return it).
 */
export const PANIC_STEP = "eldritchArts.panicTransposition";
/** Only for purging records an attack never ended (second review, finding 5): prompts may take minutes. */
export const PANIC_PURGE_MS = 10 * 60 * 1000;
const panicPending = new Map();
export const panicPendingFor = (bearer) => panicPending.get(bearer?.uuid) ?? null;
const panicAfter = async (ctx = {}) => {
  if (ctx.type !== "attack" || !ctx.succeeded || !ctx.target || ctx.target === ctx.actor) return null;
  const bearer = ctx.target;
  const spell = spellByKey(bearer, "panicTransposition");
  if (!spell || int(bearer.system?.resources?.pp?.value) < int(spell.system?.ppCost)) return null;
  if (await h().reactionRefusal?.(bearer, spell.system?.traits ?? "")) return null;
  // NOT OFFERED WHEN IT WOULD FAIL (review): a second teleportation this turn
  // fails, so no PP or reaction is spent on one.
  if (await h().teleportationFails?.(bearer)) return null;
  const q = await h().askReactor(bearer, {
    title: `Panic Transposition — ${bearer.name}`,
    content: `<p><strong>${esc(ctx.actor?.name ?? "An attacker")}</strong> hits you.</p><p>Cast <strong>Panic Transposition</strong> (${int(spell.system?.ppCost)} PP, your reaction) and teleport once the attack has been resolved?</p>`,
    buttons: yesNo("Cast it"), step: PANIC_STEP, data: { spellId: spell.id }
  });
  if (!q?.result?.cast) return null;
  const unlocks = Array.from(q.result.unlocks ?? []);
  panicPending.set(bearer.uuid, { attackerUuid: ctx.actor?.uuid ?? "", bearerUuid: bearer.uuid, bearer, unlocks, dc: int(q.result.saveDC), at: Date.now() });
  return { line: `${esc(bearer.name)} casts <strong>Panic Transposition</strong>: once the attack has been resolved, a teleport of up to ${R.panicFeet(unlocks)} feet.` };
};
async function panicStep(actor, answer, data) {
  const spell = actor?.items?.get?.(data?.spellId);
  if (!spell) return { cast: false };
  const own = tokenOf(actor)?.id;
  const result = await h().castAsReaction(actor, spell, own ? [own] : []);
  return { cast: Boolean(result?.cast), unlocks: unlocksOf(result?.warpMods), saveDC: settledSaveDC(actor, "panicTransposition") };
}
/** The resistance warp: against the triggering attack's damage, while it is pending. */
async function panicResist(ctx = {}) {
  const rec = panicPendingFor(ctx.target);
  if (!rec) return null;
  if (!rec.unlocks?.includes(R.PANIC_RESIST_UNLOCK) || !sameCreature(ctx.sourceUuid, sourceActor(rec.attackerUuid))) return null;
  return { resist: "all", scope: "instance", line: `<strong>Panic Transposition</strong>: ${esc(ctx.target.name)} resists the triggering attack.` };
}
/** A bearer that can no longer teleport: no token, or at 0 HP, unconscious, dying or dead. */
export const panicBearerDown = (bearer) => !bearer || !tokenOf(bearer) || int(bearer.system?.resources?.hp?.value ?? 1) <= 0 ||
  ["unconscious", "dying", "dead"].some((c) => bearer.hasCondition?.(c));
/**
 * The attack is over (its Strike, or its spell's cast): what it left pending
 * is cleared, and — when the attack was resolved — each bearer's teleport is
 * relayed to its owner now, after the attack's damage.
 */
export async function clearPanicFor(attacker, { resolved = false } = {}) {
  const due = [];
  for (const [uuid, rec] of panicPending) {
    // Matched on the attacker alone; a record no attack ended in ten minutes is purged.
    const mine = rec.attackerUuid === attacker?.uuid;
    if (!mine && Date.now() - rec.at <= PANIC_PURGE_MS) continue;
    panicPending.delete(uuid);
    if (resolved && mine) due.push(rec);
  }
  for (const rec of due) {
    const bearer = rec.bearer ?? sourceActor(rec.bearerUuid);
    if (panicBearerDown(bearer)) continue;
    await forOwner(bearer, "panicTeleport", { unlocks: rec.unlocks, dc: rec.dc });
  }
}
/** TRG Prime 3.685.1: Panic Transposition's teleport is later than its cast, so the core cards nothing at the cast. */
export const panicDefers = (ctx = {}) => R.keyOf(ctx.spell) === "panicTransposition";
ownerTasks.panicTeleport = async (bearer, data = {}) => {
  const token = tokenOf(bearer);
  if (!token) return;
  const spell = spellByKey(bearer, "panicTransposition");
  // A SECOND TELEPORTATION IN ONE TURN FAILS (the core's rule), so none is asked.
  if (await h().teleportationFails?.(bearer)) {
    await card(bearer, "Panic Transposition", [line(`${esc(bearer.name)} has already been teleported this turn: a second teleportation automatically fails, and nothing moves.`)]);
    return;
  }
  const moved = await teleportWithin(token, R.panicFeet(data.unlocks), "Panic Transposition");
  if (!moved) return;
  // THE TELEPORT HAS HAPPENED (0.10.0's live test, finding 1): its Spatial
  // Awareness card and record now, not at the cast (TRG Prime 3.685.1).
  const said = spell ? ((await h().teleportationArrives?.(bearer, spell, [bearer])) ?? []) : [];
  const lines = [line(`You wrench space and reappear ${moved.feet} feet away; the movement provokes nothing.`), ...said.map((s) => line(s))];
  const occupied = tokens().some((t) => t !== token && t.document && Math.abs(t.document.x - token.document.x) < 1 && Math.abs(t.document.y - token.document.y) < 1);
  if (occupied && Array.from(data.unlocks ?? []).includes(R.PANIC_UNSEEN_UNLOCK)) {
    const hit = await h().basicSaveHit({ caster: bearer, target: bearer, save: "fortitude", dc: int(data.dc), label: "Panic Transposition", formula: "2d6", type: "essence" });
    lines.push(line(`The space was occupied: 2d6 essence (basic Fortitude, DC ${int(data.dc)}). ${esc(hit?.line ?? "")} Move to the nearest safe square (by hand).`));
  }
  await card(bearer, "Panic Transposition", lines);
};

/** Measured from where the token stands; refused (and nothing moved) beyond `feet`. */
export async function teleportWithin(token, feet, label) {
  const point = await pickPoint(landingPrompt(label, feet));
  if (!point) return null;
  const grid = globalThis.canvas.grid;
  const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x - token.w / 2, y: point.y - token.h / 2 };
  const dist = grid.measurePath([tokenCentre(token), { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
  if (dist > feet) { warn(`${label}: that is ${Math.round(dist)} feet away; you may go up to ${feet} feet.`); return null; }
  // A REFUSED MOVE IS NO TELEPORT (review; as Block 4's): the core vetoes some
  // squares, and a vetoed move posts no card and records nothing.
  const src = token.document._source ?? token.document;
  const was = { x: src.x, y: src.y };
  // YOUR OWN SQUARE (re-review): no teleport, and said as such, not as a refusal.
  if (snapped.x === was.x && snapped.y === was.y) { warn(`${label}: you stay where you are; no teleport is made.`); return null; }
  await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
  const now = token.document._source ?? token.document;
  if (now.x === was.x && now.y === was.y) { warn(`${label}: the teleport was refused (see the notice).`); return null; }
  return { feet: Math.max(1, Math.round(dist)) };
}

/* ================================================================== */
/* Spirit Arrow                                                          */
/* ================================================================== */

export const SPIRIT_FLAG = "spiritArrow";
const firedAt = new Map();

/** Hooks.on("deleteActiveEffect"): a Spirit Arrow rider spent by a Strike. */
export async function onEffectDeletedB7(effect) {
  const actor = effect?.parent;
  if (effect?.flags?.[SYSTEM_ID]?.strikeRider?.label !== "Spirit Arrow" || !actor) return;
  firedAt.set(actor.uuid, { at: Date.now(), data: effect.toObject?.() ?? null });
}

async function spiritArrowStruck(ctx = {}) {
  const archer = ctx.attacker;
  const fired = firedAt.get(archer?.uuid);
  if (!fired || Date.now() - fired.at > 10000 || ctx.melee) return;
  firedAt.delete(archer.uuid);
  const rec = archer.flags?.[MODULE_ID]?.[SPIRIT_FLAG];
  const lines = [];
  if (rec && int(rec.left) > 0 && fired.data) {
    const again = { ...fired.data };
    delete again._id;
    await archer.createEmbeddedDocuments("ActiveEffect", [again]);
    await archer.setFlag(MODULE_ID, SPIRIT_FLAG, { ...rec, left: int(rec.left) - 1 });
    lines.push(line(`Another spirit arrow is nocked (${int(rec.left) - 1} more after it).`));
  }
  if (ctx.hits && ctx.target) {
    const pick = await h().chooseFromList("Spirit Arrow", "The spirits' manoeuvre (resolved at your attack total):", R.SPIRIT_ARROW_MANOEUVRES.map((m) => [m, m]));
    const action = R.spiritArrowAction(pick);
    const total = Number(ctx.total);
    if (action && Number.isFinite(total) && typeof h().resolveBasicActionAtTotal === "function") {
      // THE ACTION AT THE ATTACK TOTAL (TRG Prime 3.692.0): its DC, its
      // difficulty and its size penalty; its conditions, push and clock.
      const res = await h().resolveBasicActionAtTotal(archer, ctx.target, action.key, { total, label: "Spirit Arrow", rounds: action.rounds });
      lines.push(...(res?.lines ?? []).map(line));
    } else if (pick) lines.push(line(`The ghostly beasts ${esc(pick)} ${esc(ctx.target.name)}: resolve it with your attack total (by hand).`));
    const dc = int(rec?.dc);
    const check = await h().rollCheck({ actor: ctx.target, type: "save", subject: "will", dc, label: `${ctx.target.name} — Will Save`, saveSource: "Spirit Arrow", sourceUuid: archer.uuid });
    const value = R.spiritArrowFrightened(check?.outcome?.margin ?? null);
    if (value > 0) {
      await h().applyConditionTagsTo(ctx.target, [{ key: "frightened", value }]);
      lines.push(line(`${esc(ctx.target.name)} fails its Will save (DC ${dc}) by ${-int(check.outcome.margin)}: frightened ${value} (Q161).`));
    } else lines.push(line(`${esc(ctx.target.name)} resists the dread (Will, DC ${dc}).`));
  }
  if (lines.length) await card(archer, "Spirit Arrow", lines);
}

/** Hooks.on("trgPrimeStrikeResolved"). */
export async function onStrikeResolvedB7(ctx = {}) {
  // The Strike is resolved, its damage dealt: Panic Transposition's teleport now (L7324).
  await clearPanicFor(ctx.attacker, { resolved: Boolean(ctx.resolved) });
  await spiritArrowStruck(ctx);
}

/* ================================================================== */
/* Live memberships: Metamagic Resonance (H9) and Chronoweave (Q159)     */
/* ================================================================== */

/**
 * WHO IS INSIDE, WHILE INSIDE. Each aura is kept on its caster's flag, keyed
 * by the cast (its active-spell entry's id when it registers, as Metamagic
 * Resonance's sustained cast does) and ending at the cast's duration. On
 * every token move and every turn, each creature within the aura of the right
 * side has the module's effect, and each that left (or whose aura ended)
 * loses it. A lent effect also carries the spell's duration, so it cannot
 * outlive it on a world clock that ran on.
 */
export const RESONANCE_FLAG = "metamagicResonance";
export const CHRONO_FLAG = "chronoweave";
/** A core option's lent key is its feat's name in lower case ("Empower Spell — …" → "empower spell"). */
export const lentKeyOf = (entry) => (entry?.source === "core" ? norm(String(entry.label ?? "").split(" — ")[0]) : String(entry?.key ?? ""));

const auraLive = (caster, rec) => Boolean(rec) && worldNow() < Number(rec.until ?? 0) && (!rec.castId || castRunning(caster, rec.castId));

/**
 * One aura, once: each creature has at most ONE effect of this casting, and
 * it is the one wanted now. A re-cast (a new `until`, a new feat, another
 * slow) replaces the old effect, so its duration is refreshed; a duplicate is
 * removed (second review, findings 4 and 9).
 */
async function syncAura(caster, flag, rec, wants, { noToken = false } = {}) {
  const me = noToken ? null : tokenOf(caster);
  const live = auraLive(caster, rec);
  for (const t of tokens()) {
    const who = t.actor;
    if (!who) continue;
    const has = effects(who).filter((e) => e.flags?.[MODULE_ID]?.source === flag && e.flags?.[MODULE_ID]?.casterUuid === caster.uuid);
    const want = live && me ? wants(t, me) : null;
    const sig = want?.flags?.[MODULE_ID]?.sig;
    const keep = want ? has.find((e) => e.flags?.[MODULE_ID]?.sig === sig) : null;
    const drop = has.filter((e) => e !== keep);
    if (drop.length) await writeOn(who, { kind: "deleteEffects", ids: drop.map((e) => e.id) });
    if (want && !keep) await h().createEffectsOn(who, [want]);
  }
  if (!live) await caster.unsetFlag?.(MODULE_ID, flag);
}
const auraSig = (rec, extra = {}) => JSON.stringify({ until: Number(rec?.until ?? 0), castId: String(rec?.castId ?? ""), ...extra });

function resonanceWants(caster, rec) {
  return (t, me) => {
    if (t.actor === caster || !allies(side(t), side(me)) || !within(me, t, rec.feet)) return null;
    return { ...effectData(RESONANCE_FLAG, {
      name: `Metamagic Resonance: ${rec.label}`, img: "icons/magic/symbols/runes-star-blue.webp",
      description: `${caster.name}'s Metamagic Resonance: ${rec.label} on one spell a round${rec.costFactor === 1 ? "" : rec.costFactor ? ", half its PP" : ", at no PP"}.`,
      system: { lentMetamagic: { key: rec.key, costFactor: rec.costFactor, label: "Metamagic Resonance", from: caster.uuid } },
      module: { casterUuid: caster.uuid, castId: rec.castId, sig: auraSig(rec, { key: rec.key, costFactor: rec.costFactor }) }
    }), duration: { seconds: Math.max(6, Number(rec.until) - worldNow()), startTime: worldNow() } };
  };
}

function chronoWants(caster, rec) {
  return (t, me) => {
    if (!within(me, t, rec.feet) && t !== me) return null;
    const left = { duration: { seconds: Math.max(6, Number(rec.until) - worldNow()), startTime: worldNow() } };
    if (t.actor === caster || allies(side(t), side(me))) {
      return { ...effectData(CHRONO_FLAG, { name: "Chronoweave: quickened", img: "icons/magic/time/hourglass-tilted-glowing-gold.webp", description: "Quickened while inside Chronoweave; the extra AP may be used for anything (M37).", statuses: ["quickened"], module: { casterUuid: caster.uuid, sig: auraSig(rec, { quickened: true }) } }), ...left };
    }
    const slowed = int(rec.slowed?.[t.actor.uuid]);
    if (!slowed) return null;
    return { ...effectData(CHRONO_FLAG, { name: `Chronoweave: slowed ${slowed}`, img: "icons/magic/time/hourglass-tilted-glowing-gold.webp", description: "Slowed while inside Chronoweave, for its duration (Q159).", statuses: ["slowed"], system: { value: slowed }, module: { casterUuid: caster.uuid, sig: auraSig(rec, { slowed }) } }), ...left };
  };
}

async function syncCaster(caster, opts = {}) {
  const res = caster.flags?.[MODULE_ID]?.[RESONANCE_FLAG];
  if (res) await syncAura(caster, RESONANCE_FLAG, res, resonanceWants(caster, res), opts);
  const chrono = caster.flags?.[MODULE_ID]?.[CHRONO_FLAG];
  if (chrono) await syncAura(caster, CHRONO_FLAG, chrono, chronoWants(caster, chrono), opts);
}
async function syncAllOnce(forced) {
  const done = new Set();
  for (const [caster, opts] of forced) { done.add(caster); await syncCaster(caster, opts); }
  for (const t of tokens()) {
    const caster = t.actor;
    if (!caster || done.has(caster) || !caster.isOwner || !actsFor(caster)) continue;
    done.add(caster);
    await syncCaster(caster);
  }
}
/**
 * SERIALISED (second review, finding 4): two token moves at once (a group
 * drag) or a move during a turn change ran two syncs whose creates raced, and
 * a creature got two lends. One sync runs at a time; a call made while one
 * runs marks it dirty, and it runs again once more when it ends.
 * `force` syncs that caster here whoever acts for it (its own cast), and
 * `noToken` as though it had no token (its token deleted).
 */
let syncRunning = null, syncDirty = false;
const syncForced = new Map();
export function syncAll({ force = null, noToken = false } = {}) {
  if (force) syncForced.set(force, { noToken: noToken || Boolean(syncForced.get(force)?.noToken) });
  if (syncRunning) { syncDirty = true; return syncRunning; }
  syncRunning = (async () => {
    try {
      do {
        syncDirty = false;
        const forced = new Map(syncForced); syncForced.clear();
        await syncAllOnce(forced);
      } while (syncDirty || syncForced.size);
    } finally { syncRunning = null; }
  })();
  return syncRunning;
}

async function startResonance(actor, ctx) {
  const options = (await h().metamagicCatalogue(actor)) ?? [];
  if (!options.length) return card(actor, "Metamagic Resonance", [line("You have no metamagic feat to resonate.")]);
  const key = await h().chooseFromList("Metamagic Resonance", "Choose one metamagic feat you possess:", options.map((o) => [lentKeyOf(o), o.label]));
  const chosen = options.find((o) => lentKeyOf(o) === key);
  if (!chosen) return null;
  // KEYED ON THE CAST'S OWN ACTIVE-SPELL ENTRY (found in review): the spell's
  // id was no cast id, so the first token move found nothing and ended it.
  const castId = activeEntryFor(actor, ctx.spell?.name)?.id ?? "";
  const rec = { key: lentKeyOf(chosen), label: String(chosen.label).split(" — ")[0], costFactor: R.resonanceCostFactor(unlocksOf(ctx.warpMods)), feet: R.resonanceFeet(ctx.warpMods?.areaOverride), castId, until: worldNow() + (durationSeconds(warpedDuration(ctx)) || 60), swap: unlocksOf(ctx.warpMods).includes(R.RESONANCE_SWAP_UNLOCK) };
  await actor.setFlag(MODULE_ID, RESONANCE_FLAG, rec);
  await syncAll({ force: actor });
  return card(actor, "Metamagic Resonance", [line(`Allies within ${rec.feet} feet may apply <strong>${esc(rec.label)}</strong> to one spell a round.`)]);
}

/**
 * Hooks.on("trgPrimeSpellSustained") (TRG Prime 3.692.0): Metamagic
 * Resonance's "+2 PP: the caster may change the chosen metamagic feat each
 * time they sustain the spell" (L7156). Only this casting's own Sustain, and
 * only with the option bought; keeping the feat is one of the answers.
 */
export async function onSpellSustainedB7(ctx = {}) {
  const actor = ctx.actor;
  const rec = actor?.flags?.[MODULE_ID]?.[RESONANCE_FLAG];
  if (!R.resonanceSwapOnSustain(rec, ctx.castId) || !actor.isOwner) return null;
  const options = (await h().metamagicCatalogue(actor)) ?? [];
  if (!options.length) return null;
  const key = await h().chooseFromList("Metamagic Resonance", `You sustain it: keep ${esc(rec.label)}, or choose another metamagic feat you possess:`, options.map((o) => [lentKeyOf(o), o.label]));
  const chosen = options.find((o) => lentKeyOf(o) === key);
  if (!chosen || lentKeyOf(chosen) === rec.key) return null;
  const next = { ...rec, key: lentKeyOf(chosen), label: String(chosen.label).split(" — ")[0] };
  await actor.setFlag(MODULE_ID, RESONANCE_FLAG, next);
  await syncAll({ force: actor });
  return card(actor, "Metamagic Resonance", [line(`The resonance changes: allies within ${next.feet} feet may now apply <strong>${esc(next.label)}</strong> to one spell a round.`)]);
}

async function startChronoweave(actor, ctx) {
  const me = tokenOf(actor);
  const slowed = {};
  const lines = [];
  if (unlocksOf(ctx.warpMods).includes(R.CHRONO_SLOW_UNLOCK) && me) {
    for (const t of tokens()) {
      if (t.actor === actor || allies(side(t), side(me)) || !within(me, t, R.CHRONO_FEET)) continue;
      if (await h().temporaryImmunityRefusal?.(t.actor, "Chronoweave")) continue;
      const check = await h().rollCheck({ actor: t.actor, type: "save", subject: "fortitude", dc: int(ctx.saveDC), label: `${t.actor.name} — Fortitude Save`, saveSource: "Chronoweave", sourceUuid: actor.uuid });
      const value = R.chronoSlowed(check?.outcome?.degree?.key);
      if (value) slowed[t.actor.uuid] = value;
      await h().grantTemporaryImmunity?.(t.actor, "Chronoweave", durationSeconds(warpedDuration(ctx)) || 60);
      lines.push(line(`${esc(t.actor.name)}: ${value ? `slowed ${value} while inside, for the duration` : "unaffected"}; immune to this casting.`));
    }
  }
  const rec = { feet: R.CHRONO_FEET, until: worldNow() + (durationSeconds(warpedDuration(ctx)) || 60), slowed, castId: activeEntryFor(actor, ctx.spell?.name)?.id ?? "" };
  await actor.setFlag(MODULE_ID, CHRONO_FLAG, rec);
  await syncAll({ force: actor });
  await card(actor, "Chronoweave", [line(`You and your allies within ${R.CHRONO_FEET} feet are quickened while inside, until the spell ends.`), ...lines]);
}

/**
 * Hooks.on("deleteToken"): a caster's token gone, its auras' effects go with
 * it (second review, finding 9); a token placed again brings them back.
 */
export async function onTokenDeletedB7(doc) {
  const caster = doc?.actor;
  if (!caster?.isOwner || !actsFor(caster)) return;
  if (!caster.flags?.[MODULE_ID]?.[RESONANCE_FLAG] && !caster.flags?.[MODULE_ID]?.[CHRONO_FLAG]) return;
  await syncAll({ force: caster, noToken: true });
}

/** Hooks.on("updateToken"): creatures come into and go out of the auras. */
export async function onTokenMovedB7(doc, change = {}) {
  if (!("x" in (change ?? {})) && !("y" in (change ?? {}))) return;
  await syncAll();
}

/* ================================================================== */
/* Flesh to Blossom's type; Eaog Balls' Dispel                           */
/* ================================================================== */

export async function blossomPrelude(ctx = {}) {
  if (R.keyOf(ctx.spell) !== "fleshToBlossom") return null;
  const pick = await h().chooseFromList("Flesh to Blossom", "Its damage is acid or poison (chosen as you cast):", [["acid", "acid"], ["poison", "poison"]]);
  if (!["acid", "poison"].includes(pick)) return { handled: true, result: null };
  if (ctx.spell.system?.damage?.type !== pick) await ctx.spell.update({ "system.damage.type": pick });
  return null;
}

export const eaogDispel = {
  offer: (ctx = {}) => {
    const target = ctx.target;
    if (!target || !effects(target).some((e) => norm(e.name).startsWith("eaog balls"))) return null;
    return { label: "Against Eaog Balls: disadvantage", hint: "\"Any attempts to dispel this spell are made at disadvantage.\" Tick it when the Dispel is aimed at Eaog Balls.", optional: true, bias: "disadvantage" };
  }
};

/* ================================================================== */
/* The settled cast                                                      */
/* ================================================================== */

/** Hooks.on("trgPrimeSpellSettled"). */
export async function onSpellSettledB7(ctx = {}) {
  const actor = ctx.actor;
  const key = R.keyOf(ctx.spell);
  // FIRST, AND BEFORE ANY AWAIT: the Save DC this cast settled at, for the step that cast it.
  if (key && actor?.uuid) settledDC.set(`${actor.uuid}:${key}`, int(ctx.saveDC));
  // Any cast ends the attack it made, its damage dealt: a spell attack's Panic
  // Transposition teleports now (L7324); a refunded or failed cast sends nothing.
  await clearPanicFor(actor, { resolved: Boolean(ctx.cast) && !ctx.refunded });
  if (!key || !ctx.cast || ctx.refunded || !actor?.isOwner) return;
  const targets = Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor).filter(Boolean);
  const castIdNamed = () => castIdOf(effects(actor).filter((e) => norm(e.name).startsWith(norm(ctx.spell.name))).at(-1));
  switch (key) {
    case "elementalStrike": return stampElementalStrike(actor, ctx);
    case "arcaneMycelium": {
      // ITS DIM LIGHT (TRG Prime 3.692.0's Region `emitsLight`): the core
      // reads at least Dim Light inside the Region, as from a light source.
      const region = await stampRegion(ctx, key);
      if (region) await region.setFlag(SYSTEM_ID, "emitsLight", R.myceliumLight(ctx.spell?.name));
      return region;
    }
    case "primalSnap": return stampRegion(ctx, key);
    case "zoneDisruption": { const region = await stampRegion(ctx, key); if (region) await writeCastingZone(region); return; }
    case "arcaneBastion": return actor.setFlag(MODULE_ID, BASTION_FLAG, { castId: castIdNamed(), steps: R.bastionSteps(ctx.warpMods?.bonusValue) });
    case "argentReversal": {
      await actor.deleteEmbeddedDocuments("ActiveEffect", ownEffects(actor, ARGENT_FLAG).map((e) => e.id));
      return actor.createEmbeddedDocuments("ActiveEffect", [effectData(ARGENT_FLAG, {
        name: "Argent Reversal (sigil)", img: ctx.spell.img, description: "A redirect is ready, for an hour or until discharged.",
        module: { [ARGENT_FLAG]: { attempts: R.argentAttempts(ctx.warpMods?.bonusValue), absorb: unlocksOf(ctx.warpMods).includes(R.ARGENT_ABSORB_UNLOCK), saveDC: int(ctx.saveDC) } }, expiry: forSeconds(3600)
      })]);
    }
    case "spectralAegis": {
      const state = R.aegisState(ctx.warpMods);
      for (const warded of targets) {
        const castId = castIdOf(effects(warded).filter((e) => norm(e.name).startsWith("spectral aegis")).at(-1));
        await h().createEffectsOn(warded, [effectData(AEGIS_FLAG, { name: "Spectral Aegis (absorb)", img: ctx.spell.img, description: `Absorbs ${state.absorbs} hostile spell(s) of ${state.ppLimit} PP or lower.`, module: { [AEGIS_FLAG]: { ...state, castId } } })]);
      }
      return;
    }
    case "mirrorReprise":
      return actor.createEmbeddedDocuments("ActiveEffect", [effectData(MIRROR_FLAG, {
        name: "Mirror Reprise (waiting)", img: ctx.spell.img, description: "Three duplicates appear the first time an attack damages you.",
        // THE CAST'S ACTIVE-SPELL ENTRY ("1 hour (D)" registers); the waiting effect keeps the hour itself,
        // and carries the core's cast id so ending (dismissing) the cast sweeps it (second review, finding 6).
        system: mirrorCastStamp(activeEntryFor(actor, ctx.spell?.name)?.id),
        module: { [MIRROR_FLAG]: { images: 0, castId: activeEntryFor(actor, ctx.spell?.name)?.id ?? "", spellTriggers: unlocksOf(ctx.warpMods).includes(R.MIRROR_SPELL_UNLOCK), teleport: unlocksOf(ctx.warpMods).includes(R.MIRROR_TELEPORT_UNLOCK) } }, expiry: forSeconds(3600)
      })]);
    case "bouncyBody":
      for (const target of targets) {
        await h().createEffectsOn(target, [{ ...effectData("bouncyBody", { name: "Bouncy Body: falls 20 ft shorter", img: ctx.spell.img, system: { fallReduction: { value: R.BOUNCY_FALL_FEET, label: "Bouncy Body" } } }), duration: { seconds: /hour/i.test(String(ctx.warpMods?.durationText ?? "")) ? 3600 : 600, startTime: worldNow() } }]);
      }
      return;
    case "spiritArrow": return actor.setFlag(MODULE_ID, SPIRIT_FLAG, { dc: int(ctx.saveDC), left: Math.min(R.SPIRIT_ARROW_MAX_ARROWS - 1, int(ctx.warpMods?.bonusValue)) });
    case "metamagicResonance": return startResonance(actor, ctx);
    case "planarAnchor":
      // THE VEIL IS KEPT ON THE CASTER (found in review): the anchored creature's mark is often not the caster's to write.
      if (unlocksOf(ctx.warpMods).includes(R.ANCHOR_VEIL_UNLOCK)) {
        const castIds = [...new Set((ctx.saveResults ?? []).map((r) => markRecord(markOf(r.target, R.ANCHOR_MARK), R.ANCHOR_MARK)?.castId).filter(Boolean))];
        if (castIds.length) await actor.setFlag(MODULE_ID, ANCHOR_VEIL_FLAG, [...Array.from(actor.flags?.[MODULE_ID]?.[ANCHOR_VEIL_FLAG] ?? []).slice(-19), ...castIds]);
      }
      return;
    case "chronoweave": return startChronoweave(actor, ctx);
    default: return;
  }
}

/** Hooks.on("updateCombat"): the auras' memberships at each turn (an aura that ran out is taken back). */
export async function onCombatSyncB7(combat, change = {}) {
  if (!("turn" in (change ?? {})) && !("round" in (change ?? {}))) return;
  await syncAll();
}

/* ================================================================== */
/* Registration                                                          */
/* ================================================================== */

export function registerBlock7(api, moduleId) {
  api.registerFeatAutomation?.(R.ELEMENTAL_STRIKE_ABILITY, elementalStrikeUse, moduleId);
  api.registerSpellCheckGate?.("eaArcaneFeedback", feedbackGate, moduleId);
  api.registerSpellCheckGate?.("eaArcaneMycelium", myceliumGate, moduleId);
  api.registerSpellCheckGate?.("eaInvokeTrueName", trueNameGate, moduleId);
  api.registerSpellCheckGate?.("eaZoneDisruption", zoneGate, moduleId);
  api.registerCheckReaction?.("eaInvokeTrueName", trueNameSave, moduleId);
  api.registerCheckReaction?.("eaMirrorReprise", { after: mirrorAfter }, moduleId);
  api.registerCheckReaction?.("eaPanicTransposition", { after: panicAfter }, moduleId);
  api.registerDamageReaction?.("eaInvokeTrueName", trueNameWeak, moduleId);
  api.registerDamageReaction?.("eaMirrorReprise", mirrorArm, moduleId);
  api.registerDamageReaction?.("eaPanicTransposition", panicResist, moduleId);
  api.registerCriticalReaction?.("eaArcaneBastion", { after: bastionAfter }, moduleId);
  api.registerCastReaction?.("eaArgentReversal", argentReaction, moduleId);
  api.registerCastReaction?.("eaSpectralAegis", aegisReaction, moduleId);
  api.registerDeferredTeleport?.("eaPanicTransposition", panicDefers, moduleId);
  api.registerCastRefusal?.("eaPlanarAnchor", anchorRefusal, moduleId);
  api.registerCastRefusal?.("eaGrimoireType", typeRefusal, moduleId);
  api.registerCastPrelude?.("eaFleshToBlossom", blossomPrelude, moduleId);
  api.registerDispelModifier?.("eaEaogBalls", eaogDispel, moduleId);
  api.registerFumbleModifier?.("eaZoneDisruption", zoneFumble, moduleId);
  api.registerReactionStep?.(FEEDBACK_STEP, feedbackStep, moduleId);
  api.registerReactionStep?.(ARGENT_STEP, argentStep, moduleId);
  api.registerReactionStep?.(AEGIS_STEP, aegisStep, moduleId);
  api.registerReactionStep?.(PANIC_STEP, panicStep, moduleId);
}

/** For the harness. */
export const REACTIONS_B7 = Object.freeze({ trueNameSave, trueNameWeak, mirrorArm, mirrorAfter, panicAfter, panicResist, bastionAfter, elementalStrikeUse });
export const STEPS_B7 = Object.freeze({ feedbackStep, argentStep, aegisStep, panicStep });
export const OWNER_TASKS_B7 = ownerTasks;
