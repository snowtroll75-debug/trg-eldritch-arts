/**
 * Eldritch Arts — Block 5 (0.8.0), group A: what the Aetherial racial feats
 * and the other races' feats do that is not data. On TRG Prime 3.683.0.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md (Appendix A) as Graham
 * answered it on 3 November 2026: as proposed except Q58 and Q59. The pure
 * rules come first so the harness can run them; the Foundry side follows.
 *
 *   Uses        Aetherial Scholar, Astral Crossing, Astral Step, Ancestral
 *               Reverie, Endless Adaptation, Quiliesh
 *   Reactions   Chronal Echo (check reaction, after), Resonant Ascendance
 *               (cast reaction + Dispel modifier, C9), Veil of Honour (on
 *               trgPrimeDamageApplied, asked with askReactor)
 *   Seams       Quiliesh's heritage race grant, Radiant Presence's light,
 *               Relentless Will's dying recovery modifier (C8)
 *   Hooks       Aetherial Concord (spell settled), Astral Drift and Skyborne
 *               Agility (token moved, action resolved), Ancestral Reverie
 *               (daily preparation), Radiant Presence's light (item created
 *               or deleted, ready), Shadow's Discipline and Relentless Will
 *               (effect created or deleted, actor updated)
 *
 * The hook handlers are exported for the lead to wire in
 * scripts/eldritch-arts.mjs; each says which `Hooks.on` event it expects.
 */
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, tokenOf, tokenCentre, feetBetween } from "./block1-automations.mjs";
import { pickPoint, spellIndex, actsFor } from "./block3-automations.mjs";
import { canDispel, allies } from "./block3b-automations.mjs";

/* ------------------------------------------------------------------ */
/* Data shared with the content                                         */
/* ------------------------------------------------------------------ */

export const CONCORD_FEET = 30;
export const CONCORD_BONUS = 2;
export const ASCENDANCE_FEET = 30;
/** Q63: half the declared PP, rounded up, whatever the degree. */
export const ASCENDANCE_PP_FACTOR = 0.5;
export const DRIFT_AP = 3;
export const STEP_FEET = 5;
export const SKYBORNE_FEET = 15;
export const SKYBORNE_DB = 2;
export const SHADOW_HIDE_FEET = 10;
export const SHADOW_REFLEX = 2;
export const REVERIE_BONUS = 2;
export const RELENTLESS_ADVANTAGE_SECONDS = 60;
export const SHADOW_STANCE = "Shadow Stance";
/** Radiant Presence: "You emanate light in a 10’ radius (increases the light level by 2 steps)". */
export const RADIANT_LIGHT = Object.freeze({ key: "radiantPresence", label: "Radiant Presence", item: "Radiant Presence", steps: 2, cap: null, radiusFeet: 10 });

/**
 * Ancestral Reverie's "any one Intelligence or Wisdom based skill": the
 * seventeen master skills TRG Prime keys to either (config.mjs SKILLS).
 * Specialist (Lore) skills carry no ability there and are not offered.
 */
export const REVERIE_SKILLS = Object.freeze([
  ["arcana", "Arcana"], ["artistry", "Artistry"], ["crafting", "Crafting"], ["culture", "Culture"], ["linguistics", "Linguistics"],
  ["occultism", "Occultism"], ["planes", "Planes"], ["powerManipulation", "Power Manipulation"],
  ["handleAnimal", "Handle Animal"], ["medicine", "Medicine"], ["meditation", "Meditation"], ["mentalFocus", "Mental Focus"],
  ["nature", "Nature"], ["perception", "Perception"], ["religion", "Religion"], ["senseMotive", "Sense Motive"], ["survival", "Survival"]
]);

/** Every master skill, for Endless Adaptation's "any skill check". */
export const ALL_SKILLS = Object.freeze([
  ["acrobatics", "Acrobatics"], ["arcana", "Arcana"], ["artistry", "Artistry"], ["athletics", "Athletics"], ["climbing", "Climbing"],
  ["crafting", "Crafting"], ["culture", "Culture"], ["deception", "Deception"], ["diplomacy", "Diplomacy"], ["handleAnimal", "Handle Animal"],
  ["intimidate", "Intimidate"], ["linguistics", "Linguistics"], ["medicine", "Medicine"], ["meditation", "Meditation"], ["mentalFocus", "Mental Focus"],
  ["nature", "Nature"], ["occultism", "Occultism"], ["perception", "Perception"], ["perform", "Perform"], ["planes", "Planes"],
  ["powerManipulation", "Power Manipulation"], ["religion", "Religion"], ["senseMotive", "Sense Motive"], ["stealth", "Stealth"],
  ["survival", "Survival"], ["thievery", "Thievery"]
]);

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

/** Aetherial Concord: "When you successfully cast a spell" (Q26: Success or better), not an item's release. */
export const concordDue = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded && !ctx.itemCast;

/** The ally's +2: its next save or skill check, applied by itself and spent. */
export function concordConditionals() {
  return [{ kind: "modifier", value: CONCORD_BONUS, type: "circumstance", label: "Aetherial Concord", scope: "your next saving throw or skill check, before the end of your next turn", auto: true, oneShot: true, when: { checkTypes: ["save", "skill"] } }];
}

/**
 * Astral Crossing: "a free action at the start of your turn". In combat:
 * only on your own turn, and not once AP has been spent in it (the core's
 * own `apSpentRound` stamp, as the Open trait reads it). Out of combat: any time.
 */
export function crossingRefusal({ inCombat = false, ownTurn = false, apStamp = null, combat = null } = {}) {
  if (!inCombat) return "";
  if (!ownTurn) return "only at the start of your own turn.";
  const acted = Boolean(apStamp && combat && apStamp.combatId === combat.id && apStamp.round === combat.round && apStamp.turn === combat.turn);
  return acted ? "only at the start of your turn, before you have spent any AP." : "";
}

/** Astral Step: "a distance equal to your land speed", in whole feet. */
export const landSpeedFeet = (actor) => Math.max(0, int(actor?.system?.combat?.movement?.land?.total));

/** Astral Drift: "when you use all 3 AP during your turn to make actions with the movement trait". */
export const driftStepDue = (moved = {}) => int(moved?.apOnMovement) >= DRIFT_AP;
/** Skyborne Agility: "While moving at least 15 feet on your turn". */
export const skyborneDue = (moved = {}) => Number(moved?.feet ?? 0) >= SKYBORNE_FEET;
/** Shadow's Discipline: "If you move at least 10 feet during your turn while in Shadow Stance". */
export const shadowHideDue = (moved = {}) => Number(moved?.feet ?? 0) >= SHADOW_HIDE_FEET;

/** Q65: not a class skill, the class bonus + 2; already one, +2. */
export const endlessAdaptationBonus = ({ isClassSkill = false, classBonus = 0 } = {}) => (isClassSkill ? 2 : Math.max(0, int(classBonus)) + 2);

/** Endless Adaptation's one-shot row, on that skill only. */
export function endlessAdaptationConditionals(skill, value) {
  return [{ kind: "modifier", value, type: "class", label: "Endless Adaptation", scope: `your next ${skill} check, treated as a class skill`, auto: true, oneShot: true, when: { checkTypes: ["skill"], subjects: [skill] } }];
}

/** Ancestral Reverie's change: +2 racial on that skill. */
export const reverieChanges = (skill) => [{ key: `system.skills.${skill}.racial`, type: "add", value: String(REVERIE_BONUS), priority: 20 }];

/** Shadow's Discipline's companion: +2 racial to Reflex saves. */
export const shadowDisciplineChanges = () => [{ key: "system.combat.saves.reflex.racial", type: "add", value: String(SHADOW_REFLEX), priority: 20 }];

/** Relentless Will's advantage: the next save, within 1 minute, applied by itself and spent. */
export function relentlessConditionals() {
  return [{ kind: "advantage", label: "Relentless Will", scope: "your next saving throw within 1 minute", auto: true, oneShot: true, when: { checkTypes: ["save"] } }];
}

/** Chronal Echo: "you are struck by an attack" — a hit on you, by another. */
export const chronalEchoWants = (ctx = {}) => ctx.type === "attack" && Boolean(ctx.succeeded) && Boolean(ctx.target) && ctx.target !== ctx.actor;

/** Veil of Honour: "you take damage from a melee attack" — a melee Strike's damage, its striker known. */
export const veilOfHonourWants = (payload = {}) => Number(payload.amount ?? 0) > 0 && payload.context?.kind === "strike" && payload.context?.melee === true && Boolean(payload.sourceUuid);

/**
 * Resonant Ascendance's Dispel modifier (C9): its own Dispel only (the step
 * marks the preset), half the PP whatever the degree (Q63), its Focus use.
 */
export function ascendanceDispelOffer(ctx = {}) {
  const itemId = String(ctx?.presetDispel?.eaResonantAscendance ?? "");
  if (!itemId) return null;
  return { label: "Resonant Ascendance", hint: "Half the PP declared, rounded up, whatever the degree (Q63).", ppFactor: ASCENDANCE_PP_FACTOR, focus: true, itemId };
}

/** Is an effect the Kornargon's Shadow Stance (the core reads it by name)? */
export const isShadowStance = (effect) => norm(effect?.name) === norm(SHADOW_STANCE) && !effect?.disabled;

/** Does an effect carry the Dying condition? */
export const isDyingEffect = (effect) => {
  const s = effect?.statuses;
  const list = s instanceof Set ? Array.from(s) : Array.isArray(s) ? s : [];
  return list.map(norm).includes("dying");
};

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const ownedFeat = (actor, name) => items(actor).find((i) => i.type === "feat" && norm(i.name) === norm(name)) ?? null;
const fighting = (actor) => Boolean(combatFor(actor));
const ownTurn = (actor) => {
  const c = combatFor(actor);
  const active = c?.combatant?.actor ?? null;
  return Boolean(active && (active === actor || (active.uuid && active.uuid === actor?.uuid)));
};
const turnKey = (actor) => { const c = combatFor(actor); return c ? `${c.id}:${c.round}:${c.turn}` : ""; };
const inShadowStance = (actor) => Array.from(actor?.effects ?? []).some(isShadowStance);

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function spendAP(actor, label, ap = 1) {
  if (!fighting(actor) || ap <= 0) return true;
  const have = int(actor.system?.resources?.ap?.value);
  if (have < ap) return warn(`${label}: ${ap} AP required.`);
  await actor.update({ "system.resources.ap.value": have - ap });
  return true;
}

/** Q28's awareness, and whether a reaction may be taken now: a reason, or "". */
async function reactionBlocked(actor, traits = "") {
  if (!actor) return "no creature";
  if (actor.hasCondition?.("blinded")) return "blinded";
  if (await h().isDead?.(actor)) return "dead";
  return (await h().reactionRefusal?.(actor, traits)) || "";
}

const yesNo = (yes) => [{ action: "yes", label: yes }, { action: "no", label: "No" }];
const sides = (t) => t?.document?.disposition;

/** The tokens of this one's side, but itself, on the board. */
function alliedTokens(me) {
  return Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor && t !== me && t.actor !== me?.actor && allies(sides(t), sides(me)));
}

/** A once-a-turn mark on the actor, so a rule offered as it moves is offered once. */
async function onceThisTurn(actor, key) {
  const k = turnKey(actor);
  if (!k) return false;
  const marks = { ...(actor.getFlag?.(MODULE_ID, "b5aTurnMarks") ?? {}) };
  if (marks[key] === k) return false;
  marks[key] = k;
  await actor.setFlag(MODULE_ID, "b5aTurnMarks", marks);
  return true;
}

/** Set this user's targets for the length of `run`, then put them back. */
async function withTargets(ids, run) {
  const tokens = globalThis.canvas?.tokens?.placeables ?? [];
  const previous = Array.from(game.user?.targets ?? []).map((t) => t.id);
  const set = (want) => {
    const s = new Set(want);
    for (const t of tokens) if (t.isTargeted !== s.has(t.id)) t.setTarget(s.has(t.id), { user: game.user, releaseOthers: false, groupSelection: true });
  };
  try {
    set(ids);
    return await run();
  } finally {
    set(previous);
  }
}

/** Teleport the actor's token to a clicked square within `feet` (as Gale Step). Feet moved, or false. */
async function teleportWithin(actor, feet, label) {
  const token = tokenOf(actor);
  if (!token) return warn(`${label}: place your token on the map first.`);
  const point = await pickPoint(`${label}: click where you teleport (up to ${feet} ft). Escape cancels.`);
  if (!point) return false;
  const grid = canvas.grid;
  const snapped = grid.getSnappedPoint?.({ x: point.x - token.w / 2, y: point.y - token.h / 2 }, { mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER }) ?? { x: point.x, y: point.y };
  const dist = grid.measurePath([tokenCentre(token), { x: snapped.x + token.w / 2, y: snapped.y + token.h / 2 }]).distance;
  if (dist > feet) return warn(`${label}: that is ${Math.round(dist)} feet away; you may teleport up to ${feet} feet.`);
  const src = token.document._source ?? token.document;
  const was = { x: src.x, y: src.y };
  await token.document.update({ x: snapped.x, y: snapped.y }, { animate: false, teleport: true });
  const now = token.document._source ?? token.document;
  if (now.x === was.x && now.y === was.y) return warn(`${label}: the teleport was refused (see the notice).`);
  return Math.max(1, Math.round(dist));
}

/** A pack spell's data by name (the federated spells packs). */
async function packSpellData(name) {
  const entry = (await spellIndex()).find((e) => norm(e.name) === norm(name));
  if (!entry) return null;
  const doc = await entry.pack.getDocument(entry._id);
  return doc ? doc.toObject() : null;
}

/* ------------------------------------------------------------------ */
/* The Uses                                                             */
/* ------------------------------------------------------------------ */

const aetherialScholar = {
  hint: "Put the +2 racial on your Astral Lore specialist skill.",
  async use(actor, item) {
    const entry = Object.entries(actor.system?.specialistSkills ?? {}).find(([key, s]) => norm(s?.label ?? key) === "astral lore");
    if (!entry) return warn("Aetherial Scholar: your sheet has no Astral Lore specialist skill yet (the Aetherial race grants it).");
    await h().replaceFeatEffect(actor, item, {
      name: "Aetherial Scholar: Astral Lore +2", img: item.img,
      description: "+2 racial bonus to Astral Lore, your racial specialist skill.",
      changes: [{ key: `system.specialistSkills.${entry[0]}.racial`, type: "add", value: "2", priority: 20 }]
    });
    await card(actor, "Aetherial Scholar", [line("+2 racial bonus to <strong>Astral Lore</strong> (visible in its racial slot).")]);
    return true;
  }
};

const astralCrossing = {
  hint: "0 AP, at the start of your turn: incorporeal until the start of your next turn (Focus).",
  async use(actor) {
    const combat = combatFor(actor);
    const refusal = crossingRefusal({
      inCombat: Boolean(combat), ownTurn: ownTurn(actor), apStamp: actor.getFlag?.(SYSTEM_ID, "apSpentRound") ?? null,
      combat: combat ? { id: combat.id, round: combat.round, turn: combat.turn } : null
    });
    if (refusal) return warn(`Astral Crossing: ${refusal}`);
    if (ownEffects(actor, "astralCrossing").length) return warn("Astral Crossing: you are already incorporeal.");
    await h().createEffectsOn(actor, [effectData("astralCrossing", {
      name: "Astral Crossing: incorporeal", img: "icons/svg/invisible.svg",
      description: "Astral Crossing: incorporeal until the start of your next turn; you may pass through creatures (not end your move in their space).",
      system: { grantedTraits: ["incorporeal"] },
      expiry: expiryFor("startOfNextTurn", actor)
    })]);
    await card(actor, "Astral Crossing", [
      line("You become <strong>incorporeal</strong> until the start of your next turn: you may move through occupied squares, though not end there."),
      line("<em>Walls and solid objects are the GM's to allow. Focus use spent — Refocus restores it.</em>")
    ]);
    return true;
  }
};

const astralStep = {
  hint: "1 AP: teleport up to your land speed (Focus).",
  async use(actor) {
    if (fighting(actor) && int(actor.system?.resources?.ap?.value) < 1) return warn("Astral Step: 1 AP required.");
    const feet = landSpeedFeet(actor);
    if (!feet) return warn("Astral Step: you have no land speed to teleport.");
    const moved = await teleportWithin(actor, feet, "Astral Step");
    if (!moved) return false;
    if (!(await spendAP(actor, "Astral Step", 1))) return false;
    await card(actor, "Astral Step", [line(`You teleport <strong>${moved} feet</strong> (up to your land speed, ${feet}).`), ...(fighting(actor) ? [line("1 AP spent.")] : []), line("<em>Focus use spent — Refocus restores it.</em>")]);
    return true;
  }
};

async function chooseReverie(actor, item, prompt) {
  const skill = await h().chooseFromList("Ancestral Reverie", prompt, REVERIE_SKILLS.map(([k, l]) => [k, l]));
  const row = REVERIE_SKILLS.find(([k]) => k === skill);
  if (!row) return false;
  await h().replaceFeatEffect(actor, item, {
    name: `Ancestral Reverie: ${row[1]} +2`, img: item.img,
    description: `+2 racial bonus to ${row[1]} until your next daily preparation.`,
    changes: reverieChanges(row[0])
  }, { dailyPrep: true });
  await card(actor, "Ancestral Reverie", [line(`+2 racial bonus to <strong>${esc(row[1])}</strong> until your next daily preparation.`)]);
  return true;
}

const ancestralReverie = {
  hint: "Choose today's Intelligence- or Wisdom-based skill (+2 racial until the next daily preparation).",
  async use(actor, item) { return chooseReverie(actor, item, "Today's skill (+2 racial until your next daily preparation)"); }
};

const endlessAdaptation = {
  hint: "Once a day: treat your next check of a skill as a class skill, with +2 more.",
  async use(actor, item) {
    if (usesLeft(item) <= 0) return warn("Endless Adaptation: today's use is spent — daily preparation restores it.");
    const skill = await h().chooseFromList("Endless Adaptation", "Which skill's next check?", ALL_SKILLS.map(([k, l]) => [k, l]));
    const row = ALL_SKILLS.find(([k]) => k === skill);
    if (!row) return false;
    const isClassSkill = Boolean(actor.system?.skills?.[row[0]]?.isClassSkill);
    const value = endlessAdaptationBonus({ isClassSkill, classBonus: actor.system?.identity?.classBonus });
    if (!(await spendUse(item))) return false;
    await h().replaceFeatEffect(actor, item, {
      name: `Endless Adaptation: ${row[1]} +${value}`, img: item.img,
      description: `Your next ${row[1]} check takes a +${value} class bonus (${isClassSkill ? "already a class skill: +2" : "the class bonus + 2"}).`,
      flags: { [SYSTEM_ID]: { conditionals: endlessAdaptationConditionals(row[0], value) } }
    }, { dailyPrep: true });
    await card(actor, "Endless Adaptation", [
      line(`Your next <strong>${esc(row[1])}</strong> check takes <strong>+${value} class</strong> (${isClassSkill ? "already a class skill: +2" : `not a class skill: your class bonus ${int(actor.system?.identity?.classBonus)} + 2`}), applied by itself and then spent.`),
      line("<em>Today's use is spent.</em>")
    ]);
    return true;
  }
};

const quiliesh = {
  hint: "Choose your Arcane or Ethereal cantrip (cast with Spellcraft).",
  async use(actor, item) {
    return h().chooseSpell(actor, item, { ppCost: 0, tradition: "arcane|ethereal", note: "Quiliesh: your cantrip of the Arcane or Ethereal tradition, cast with your Spellcraft. Using Quiliesh again replaces it." });
  }
};

export const AUTOMATIONS_B5_A = Object.freeze({
  "Aetherial Scholar": aetherialScholar,
  "Astral Crossing": astralCrossing,
  "Astral Step": astralStep,
  "Ancestral Reverie": ancestralReverie,
  "Endless Adaptation": endlessAdaptation,
  Quiliesh: quiliesh
});

/* ------------------------------------------------------------------ */
/* Reactions                                                            */
/* ------------------------------------------------------------------ */

export const ECHO_STEP = "eldritchArts.chronalEcho";
export const ASCENDANCE_STEP = "eldritchArts.resonantAscendance";
export const VEIL_STEP = "eldritchArts.veilOfHonour";

/** Chronal Echo: after an attack hits its owner. */
const chronalEcho = {
  async after(ctx) {
    if (!chronalEchoWants(ctx)) return null;
    const target = ctx.target;
    const feat = ownedFeat(target, "Chronal Echo");
    if (!feat || usesLeft(feat) <= 0) return null;
    if (await reactionBlocked(target, feat.system?.traits ?? "")) return null;
    const q = await h().askReactor(target, {
      title: `Chronal Echo — ${target.name}`,
      content: `<p><strong>${esc(ctx.actor?.name ?? "An attacker")}</strong> hits <strong>${esc(target.name)}</strong> (${int(ctx.total)}).</p>`
        + "<p>Use <strong>Chronal Echo</strong> (your reaction and its Focus use) to make them reroll the attack? The second result stands.</p>",
      buttons: yesNo("Chronal Echo"),
      step: ECHO_STEP,
      data: { itemId: feat.id }
    });
    if (!q?.result?.spent) return null;
    return { reroll: true, label: "Chronal Echo", line: `${esc(target.name)}'s <strong>Chronal Echo</strong>: ${esc(ctx.actor?.name ?? "the attacker")} rerolls the attack, and the second result stands.` };
  }
};

async function echoStep(actor, answer, data) {
  const item = actor?.items?.get?.(data?.itemId);
  if (!item || usesLeft(item) <= 0) return { spent: false };
  if (!(await h().spendReaction?.(actor, "Chronal Echo", { traits: String(item.system?.traits ?? "") }))) return { spent: false };
  await spendUse(item);
  return { spent: true };
}

/** Resonant Ascendance: a creature within 30 ft casts a spell. */
async function resonantAscendance(ctx) {
  const caster = ctx?.actor;
  const casterToken = ctx?.token;
  if (!caster || !casterToken) return null;
  const said = [];
  for (const reactorToken of Array.from(globalThis.canvas?.tokens?.placeables ?? [])) {
    const reactor = reactorToken?.actor;
    if (!reactor || reactor === caster || reactorToken === casterToken) continue;
    const feat = ownedFeat(reactor, "Resonant Ascendance");
    if (!feat || usesLeft(feat) <= 0) continue;
    const d = feetBetween(reactorToken, casterToken);
    if (d === null || d > ASCENDANCE_FEET) continue;
    if (await reactionBlocked(reactor, feat.system?.traits ?? "")) continue;
    // Dispel is Trained and has the Concentrate trait (Disrupting Magic's rules, Q33).
    if (!canDispel(reactor) || reactor.hasCondition?.("fixated")) continue;
    const dc = int(caster.system?.magic?.spellcraft?.dc);
    const q = await h().askReactor(reactor, {
      title: `Resonant Ascendance — ${reactor.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> casts <strong>${esc(ctx.spell?.name ?? "a spell")}</strong> (${int(ctx.pp)} PP), within 30 feet of you.</p>`
        + "<p>Use <strong>Resonant Ascendance</strong> (your reaction and its Focus use)? Your Dispel (Power Manipulation) check is made against it at the PP you declare, and you pay half of it, whatever the result. On a Success or better the spell is stopped.</p>",
      buttons: yesNo("Dispel it"),
      step: ASCENDANCE_STEP,
      // THE CASTER AND THE SPELL (review): a Dispel modifier's onResult
      // (Threadbreaker's Dazed, Mirrored Rebuke) finds them by these, as
      // Disrupting Magic's preset carries them.
      data: { effectValue: int(ctx.pp), dc, spellName: ctx.spell?.name ?? "", casterUuid: caster.uuid ?? "", spellUuid: ctx.spell?.uuid ?? "", itemId: feat.id }
    });
    if (!q?.result?.rolled) continue;
    if (q.result.dispelled) {
      said.push(`${esc(reactor.name)}'s <strong>Resonant Ascendance</strong> (${esc(q.result.degree)}): ${esc(ctx.spell?.name ?? "the spell")} is stopped before it resolves.`);
      return { stop: true, line: said.join("<br>") };
    }
    said.push(`${esc(reactor.name)}'s <strong>Resonant Ascendance</strong> (${esc(q.result.degree)}) fails to stop ${esc(ctx.spell?.name ?? "the spell")}.`);
  }
  return said.length ? { stop: false, line: said.join("<br>") } : null;
}

/** The Dispel at no AP, marked so the modifier halves it; the reaction spent once it is rolled. */
async function ascendanceStep(actor, answer, data) {
  const item = actor?.items?.get?.(data?.itemId);
  if (!item || usesLeft(item) <= 0) return { rolled: false };
  if (await h().reactionRefusal?.(actor, String(item.system?.traits ?? ""))) return { rolled: false };
  const dispel = Array.from(h().skillActions ?? []).find((a) => a.key === "dispel");
  if (!dispel) return { rolled: false };
  const check = await h().resolveAction(actor, { ...dispel, apCost: "0" }, {
    presetDispel: {
      effectValue: int(data?.effectValue), dc: int(data?.dc), what: String(data?.spellName ?? ""),
      casterUuid: String(data?.casterUuid ?? ""), spellUuid: String(data?.spellUuid ?? ""),
      // A counter of the incoming spell, as Disrupting Magic's.
      counterSpell: true, eaResonantAscendance: item.id
    }
  });
  const degree = String(check?.outcome?.degree?.key ?? "");
  if (!degree) return { rolled: false };
  // THE ROLL STANDS (review): its PP and Focus use are already paid, so a
  // reaction the core will not spend now (refused above, so rare) does not
  // undo the Dispel; the card says so.
  const spent = Boolean(await h().spendReaction?.(actor, "Resonant Ascendance", { traits: String(item.system?.traits ?? "") }));
  if (!spent) await card(actor, "Resonant Ascendance", [line("<em>The Dispel was rolled, but the reaction could not be spent: the GM settles it.</em>")]);
  return { rolled: true, degree: check.outcome.degree.label ?? degree, dispelled: ["heroic", "critical", "success"].includes(degree), reactionSpent: spent };
}

const ascendanceDispel = { offer: (ctx) => ascendanceDispelOffer(ctx) };

/* Veil of Honour, asked on trgPrimeDamageApplied. */
const recentlyAsked = new Map();

/**
 * Hooks.on("trgPrimeDamageApplied"): a melee Strike's damage on a Kornargon
 * with Veil of Honour. Fired on the client that applied the damage; the Kornargon's player
 * is asked through askReactor, and the work is done on their client. A Strike's
 * several packets ask once (two seconds per striker).
 */
export async function onDamageAppliedB5A(payload = {}) {
  if (!veilOfHonourWants(payload)) return;
  const actor = payload.actor;
  const feat = ownedFeat(actor, "Veil of Honour");
  if (!feat || usesLeft(feat) <= 0) return;
  const key = `${actor.uuid ?? actor.id}|${payload.sourceUuid}`;
  const now = Date.now();
  if (now - (recentlyAsked.get(key) ?? 0) < 2000) return;
  recentlyAsked.set(key, now);
  if (await reactionBlocked(actor, feat.system?.traits ?? "")) return;
  const fromUuid = globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid;
  const source = fromUuid ? await fromUuid(payload.sourceUuid) : null;
  const attacker = source?.actor ?? source ?? null;
  const attackerToken = attacker?.getActiveTokens?.()?.[0] ?? null;
  await h().askReactor(actor, {
    title: `Veil of Honour — ${actor.name}`,
    content: `<p><strong>${esc(attacker?.name ?? payload.sourceName ?? "A creature")}</strong> deals <strong>${esc(actor.name)}</strong> ${int(payload.amount)} damage with a melee attack.</p>`
      + `<p>Use <strong>Veil of Honour</strong> (your reaction and its Focus use)? You ${inShadowStance(actor) ? "renew Concealed as if you had moved in Shadow Stance" : "enter Shadow Stance, Concealed"}, and an innate Daze is cast at your attacker.</p>`,
    buttons: yesNo("Veil of Honour"),
    step: VEIL_STEP,
    data: { itemId: feat.id, attackerTokenId: attackerToken?.id ?? "", attackerName: attacker?.name ?? payload.sourceName ?? "" }
  });
}

async function veilStep(actor, answer, data) {
  const item = actor?.items?.get?.(data?.itemId);
  if (!item || usesLeft(item) <= 0) return { done: false };
  const traits = String(item.system?.traits ?? "");
  if (!(await h().spendReaction?.(actor, "Veil of Honour", { traits }))) return { done: false };
  await spendUse(item);
  const lines = [];
  if (inShadowStance(actor)) {
    // "if already in this stance, concealed triggers as if you had moved":
    // Concealed to the start of the next turn, as the stance's own entry.
    const round = globalThis.game?.combat?.started ? int(game.combat.round) + 1 : null;
    await h().applyConditionTags(actor, [{ key: "concealed", label: "Concealed" }], { expiresRound: round });
    lines.push(line("Already in <strong>Shadow Stance</strong>: you are <strong>Concealed</strong> again until the start of your next turn."));
  } else if (await h().enterShadowStance(actor, { apCost: 0, ignoreOpen: true })) {
    lines.push(line("You enter <strong>Shadow Stance</strong> as a reaction (no AP): <strong>Concealed</strong> until the start of your next turn."));
  } else {
    lines.push(line("<em>Shadow Stance could not be entered (see the notice).</em>"));
  }
  const daze = await packSpellData("Daze");
  if (!daze) lines.push(line("<em>Daze is not in the spells compendium: the GM casts it by hand.</em>"));
  else if (!data?.attackerTokenId) lines.push(line(`<em>${esc(data?.attackerName || "The attacker")} has no token here: the innate Daze is the GM's to resolve.</em>`));
  else {
    delete daze._id;
    daze.system = { ...daze.system, innate: true, usesPerDay: "", usesValue: 0 };
    delete daze.system.usesMax;
    daze.flags = { ...(daze.flags ?? {}), [SYSTEM_ID]: { ...(daze.flags?.[SYSTEM_ID] ?? {}), innateOnce: true } };
    const temp = new Item.implementation(daze, { parent: actor });
    await withTargets([data.attackerTokenId], () => h().castSpell(actor, temp, { apPaid: true, presetTargets: true }));
    lines.push(line(`An innate <strong>Daze</strong> is cast at ${esc(data?.attackerName || "your attacker")}.`));
  }
  lines.push(line("<em>Reaction and Focus use spent — Refocus restores the use.</em>"));
  await card(actor, "Veil of Honour", lines);
  return { done: true };
}

/* ------------------------------------------------------------------ */
/* Relentless Will (C8)                                                 */
/* ------------------------------------------------------------------ */

export const RELENTLESS_ARMED = "relentlessWillArmed";
export const RELENTLESS_PENDING = "relentlessWillPending";

/** The dying recovery modifier: the day's first Dying (marked when gained) leaves without Fatigued. */
export function relentlessWaiver(ctx = {}) {
  const actor = ctx.actor;
  if (!ownedFeat(actor, "Relentless Will") || !ownEffects(actor, RELENTLESS_ARMED).length) return null;
  return { noFatigue: true, line: `<strong>Relentless Will</strong>: ${esc(actor.name)} leaves Dying without gaining a point of Fatigued (the first Dying today).` };
}

async function layRelentlessAdvantage(actor) {
  await h().createEffectsOn(actor, [effectData("relentlessWill", {
    name: "Relentless Will: advantage on the next save", img: "icons/svg/upgrade.svg",
    description: "Advantage on your next saving throw within 1 minute.",
    system: { conditionals: relentlessConditionals() },
    expiry: forSeconds(RELENTLESS_ADVANTAGE_SECONDS)
  })]);
  await card(actor, "Relentless Will", [line("Above 0 HP again: <strong>advantage</strong> on your next saving throw within 1 minute, applied by itself.")]);
}

/* ------------------------------------------------------------------ */
/* Hook handlers                                                        */
/* ------------------------------------------------------------------ */

/** Hooks.on("trgPrimeSpellSettled"): Aetherial Concord. */
export async function onSpellSettledB5A(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner || !concordDue(ctx)) return;
  const feat = ownedFeat(actor, "Aetherial Concord");
  if (!feat || usesLeft(feat) <= 0) return;
  const me = tokenOf(actor);
  if (!me) return;
  const near = alliedTokens(me).filter((t) => { const d = feetBetween(me, t); return d !== null && d <= CONCORD_FEET; });
  if (!near.length) return;
  const picked = await h().chooseFromList("Aetherial Concord", `Your spell succeeded: grant an ally within 30 feet +${CONCORD_BONUS} circumstance to its next saving throw or skill check (spends the Focus use)? Cancel to keep it.`, near.map((t) => [t.id, esc(t.name)]));
  const token = near.find((t) => t.id === picked);
  if (!token) return;
  if (!(await spendUse(feat))) return;
  const ally = token.actor;
  await h().createEffectsOn(ally, [effectData("aetherialConcord", {
    name: `Aetherial Concord (+${CONCORD_BONUS})`, img: "icons/svg/aura.svg",
    description: `+${CONCORD_BONUS} circumstance to your next saving throw or skill check before the end of your next turn (${actor.name}'s Aetherial Concord).`,
    system: { conditionals: concordConditionals() },
    expiry: expiryFor("endOfNextTurn", ally)
  })]);
  await card(actor, "Aetherial Concord", [line(`<strong>${esc(token.name)}</strong> gains +${CONCORD_BONUS} circumstance to its next saving throw or skill check before the end of its next turn.`), line("<em>Focus use spent — Refocus restores it.</em>")]);
}

/** Astral Drift, Skyborne Agility, Shadow's Discipline: read the turn's movement on the mover's client. */
async function afterMovement(actor) {
  if (!actor?.isOwner || !ownTurn(actor)) return;
  const drift = ownedFeat(actor, "Astral Drift");
  const sky = ownedFeat(actor, "Skyborne Agility");
  const shadow = ownedFeat(actor, "Shadow’s Discipline") && inShadowStance(actor);
  if (!drift && !sky && !shadow) return;
  const moved = await h().movementThisTurn(actor);
  if (drift && driftStepDue(moved) && (await onceThisTurn(actor, "astralDrift"))) {
    await h().armMove(actor, { maxFeet: STEP_FEET, speedKey: "land", provokes: false, note: "Astral Drift: a free Step" }, "Astral Drift");
    await card(actor, "Astral Drift", [line(`Your turn's ${DRIFT_AP} AP went on movement: your free <strong>Step</strong> is armed — drag your token up to ${STEP_FEET} feet on land, no AP, provoking no reactions.`)]);
  }
  if (sky && skyborneDue(moved) && !ownEffects(actor, "skyborneAgility").length && (await onceThisTurn(actor, "skyborneAgility"))) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("skyborneAgility", {
      name: `Skyborne Agility (+${SKYBORNE_DB} DB)`, img: "icons/svg/wing.svg",
      description: `+${SKYBORNE_DB} circumstance to DB until the start of your next turn.`,
      changes: [{ key: "system.combat.defence.circumstance", type: "custom", value: String(SKYBORNE_DB), priority: 20 }],
      expiry: expiryFor("startOfNextTurn", actor)
    })]);
    await card(actor, "Skyborne Agility", [line(`You have moved ${Math.round(Number(moved.feet))} feet this turn: <strong>+${SKYBORNE_DB} circumstance to DB</strong> until the start of your next turn.`)]);
  }
  if (shadow && shadowHideDue(moved) && (await onceThisTurn(actor, "shadowsDiscipline"))) {
    await card(actor, "Shadow’s Discipline", [line(`You have moved ${Math.round(Number(moved.feet))} feet in Shadow Stance: you may <strong>Hide</strong> this turn without cover or concealment.`), line("<em>The system refuses Hide only from Lesser Cover; there, the GM allows it.</em>")]);
  }
}

/** Hooks.on("updateToken", (doc, change, options, userId)): only the mover's client, only a move. */
export async function onTokenMovedB5A(doc, change = {}, options = {}, userId = null) {
  if (!("x" in (change ?? {})) && !("y" in (change ?? {}))) return;
  if (options?.teleport) return;
  if (userId && userId !== globalThis.game?.user?.id) return;
  await afterMovement(doc?.actor);
}

/** Hooks.on("trgPrimeActionResolved"): a Movement-trait action (Sneak …) counts toward Astral Drift. */
export async function onActionResolvedB5A(ctx = {}) {
  if (!/\bmovement\b/i.test(String(ctx.action?.traits ?? ""))) return;
  await afterMovement(ctx.actor);
}

/** Hooks.on("trgPrimeDailyPreparation"): Ancestral Reverie's question. */
export async function onDailyPreparationB5A({ actor } = {}) {
  if (!actor?.isOwner) return;
  const reverie = ownedFeat(actor, "Ancestral Reverie");
  if (reverie) await chooseReverie(actor, reverie, "Daily preparation: today's Intelligence- or Wisdom-based skill (+2 racial until the next)");
}

/** Radiant Presence's light, carried by an actor effect (a feat's transferred one is not read for light). */
export async function syncRadiantLight(actor) {
  if (!actor) return;
  const wants = Boolean(ownedFeat(actor, "Radiant Presence"));
  const have = ownEffects(actor, "radiantPresence");
  if (wants && !have.length) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("radiantPresence", {
      name: "Radiant Presence: light (10 ft, +2 steps)", img: "icons/svg/sun.svg",
      description: "Radiant Presence: you emanate light in a 10-foot radius, raising the light level by 2 steps.",
      system: { lightSource: RADIANT_LIGHT.key }
    })]);
  } else if (!wants && have.length) {
    await actor.deleteEmbeddedDocuments("ActiveEffect", have.map((e) => e.id));
  } else return;
  await h().refreshTokenLight?.(actor);
}

/** Hooks.on("createItem"): Radiant Presence's light arrives with the feat (one client). */
export async function onItemCreatedB5A(item) {
  const actor = item?.parent;
  if (item?.type !== "feat" || norm(item.name) !== "radiant presence" || !actor?.isOwner || !actsFor(actor)) return;
  await syncRadiantLight(actor);
}

/** Hooks.on("deleteItem"): …and leaves with it. */
export async function onItemDeletedB5A(item) {
  const actor = item?.parent;
  if (item?.type !== "feat" || norm(item.name) !== "radiant presence" || !actor?.isOwner || !actsFor(actor)) return;
  await syncRadiantLight(actor);
}

/** Hooks.once("ready"): the light for every actor this client acts for (a feat added before 0.8.0). */
export async function onReadyB5A() {
  for (const actor of Array.from(globalThis.game?.actors ?? [])) {
    if (!actor?.isOwner || !actsFor(actor)) continue;
    if (Boolean(ownedFeat(actor, "Radiant Presence")) !== Boolean(ownEffects(actor, "radiantPresence").length)) await syncRadiantLight(actor);
  }
}

const effectActor = (effect) => (effect?.parent?.documentName === "Actor" ? effect.parent : null);

/**
 * Hooks.on("createActiveEffect"): Shadow Stance up → Shadow's Discipline's
 * +2 Reflex; Dying gained → Relentless Will's mark, the first of the day.
 */
export async function onEffectCreatedB5A(effect) {
  const actor = effectActor(effect);
  if (!actor?.isOwner || !actsFor(actor)) return;
  if (isShadowStance(effect) && ownedFeat(actor, "Shadow’s Discipline") && !ownEffects(actor, "shadowsDiscipline").length) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData("shadowsDiscipline", {
      name: `Shadow’s Discipline (+${SHADOW_REFLEX} Reflex)`, img: "icons/svg/shield.svg",
      description: `+${SHADOW_REFLEX} racial bonus to Reflex saves while in Shadow Stance.`,
      changes: shadowDisciplineChanges()
    })]);
  }
  if (isDyingEffect(effect)) {
    const feat = ownedFeat(actor, "Relentless Will");
    if (!feat || usesLeft(feat) <= 0 || ownEffects(actor, RELENTLESS_ARMED).length) return;
    await spendUse(feat);
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(RELENTLESS_ARMED, {
      name: "Relentless Will: the first Dying today", img: "icons/svg/heal.svg",
      description: "Leaving this Dying costs no point of Fatigued; once above 0 HP, advantage on your next save within 1 minute."
    })]);
    await card(actor, "Relentless Will", [line("The first time today you are Dying: leaving it costs no point of <strong>Fatigued</strong>."), line("<em>Today's use is spent.</em>")]);
  }
}

/** Hooks.on("deleteActiveEffect"): the stance's end lifts the +2; Dying's end opens the advantage. */
export async function onEffectDeletedB5A(effect) {
  const actor = effectActor(effect);
  if (!actor?.isOwner || !actsFor(actor)) return;
  if (isShadowStance(effect) && !inShadowStance(actor)) {
    const ids = ownEffects(actor, "shadowsDiscipline").map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids);
  }
  if (isDyingEffect(effect) && ownEffects(actor, RELENTLESS_ARMED).length) {
    await actor.deleteEmbeddedDocuments("ActiveEffect", ownEffects(actor, RELENTLESS_ARMED).map((e) => e.id));
    if (Number(actor.system?.resources?.hp?.value ?? 0) > 0) await layRelentlessAdvantage(actor);
    else await actor.createEmbeddedDocuments("ActiveEffect", [effectData(RELENTLESS_PENDING, { name: "Relentless Will: advantage when above 0 HP", img: "icons/svg/heal.svg", description: "When your HP is next above 0: advantage on your next save within 1 minute." })]);
  }
}

/** Hooks.on("updateActor", (actor, change)): Relentless Will's advantage when HP is next above 0. */
export async function onActorUpdatedB5A(actor, change = {}) {
  if (globalThis.foundry?.utils?.getProperty?.(change, "system.resources.hp.value") === undefined) return;
  if (!actor?.isOwner || !actsFor(actor) || Number(actor.system?.resources?.hp?.value ?? 0) <= 0) return;
  const pending = ownEffects(actor, RELENTLESS_PENDING);
  if (!pending.length) return;
  await actor.deleteEmbeddedDocuments("ActiveEffect", pending.map((e) => e.id));
  await layRelentlessAdvantage(actor);
}

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const REACTIONS_B5_A = Object.freeze({ chronalEcho, resonantAscendance, ascendanceDispel });
export const STEPS_B5_A = Object.freeze({ echoStep, ascendanceStep, veilStep });

/** Every registration group A makes; called once from registerContent (trgPrime.registerContent). */
export function registerBlock5A(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B5_A)) api.registerFeatAutomation(name, entry, moduleId);
  // Q60: the Quiliesh "may also select racial feats which are available to the Ascendan race".
  api.registerHeritageRaceGrant?.("Quiliesh", ["Ascendan"], moduleId);
  api.registerLightSources?.([{ ...RADIANT_LIGHT }], moduleId);
  api.registerCheckReaction?.("chronalEcho", chronalEcho, moduleId);
  api.registerCastReaction?.("resonantAscendance", resonantAscendance, moduleId);
  api.registerDispelModifier?.("resonantAscendance", ascendanceDispel, moduleId);
  api.registerDyingRecoveryModifier?.("relentlessWill", relentlessWaiver, moduleId);
  api.registerReactionStep?.(ECHO_STEP, echoStep, moduleId);
  api.registerReactionStep?.(ASCENDANCE_STEP, ascendanceStep, moduleId);
  api.registerReactionStep?.(VEIL_STEP, veilStep, moduleId);
}

