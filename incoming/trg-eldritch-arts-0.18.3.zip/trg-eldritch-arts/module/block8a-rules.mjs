/**
 * Eldritch Arts — Block 8a (0.11.0): the pure rules and constants of the
 * second half of Chapter 8's Grimoire, first part — the eight Bindings, the
 * five Symbols (three new, Death and Fear rebuilt, Q184) and the eleven
 * exploration and utility spells. No Foundry. The content build
 * (tools/content/block8a-spells.mjs) and the automations
 * (module/block8a-automations.mjs) both read them, so a number lives once.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2 and §4, as Graham
 * answered it on 8 November 2026 (17:22): "As recommended" — Q167–Q184 as
 * each row recommends, seams H12–H18 approved (8a takes H12, H17, H18:
 * TRG Prime 3.686.0).
 */

export const MODULE_ID = "trg-eldritch-arts";
export const SYSTEM_ID = "trg-prime";

const int = (v) => Math.trunc(Number(v) || 0);
const norm = (v) => String(v ?? "").trim().toLowerCase();
const freeze = (o) => Object.freeze(o);

/** The order of the core's seven degrees, best first. */
export const DEGREES = freeze(["heroic", "critical", "success", "partial", "failure", "fumble", "blunder"]);
const UP = ["heroic", "critical", "success"];
export const succeeded = (degree) => UP.includes(norm(degree));

/**
 * m42 (the missing-results table): a rung the spell does not print reads as
 * Heroic → Critical → Success, Partial → Failure, Blunder → Fumble → Failure.
 * Returns the printed rung a rolled degree reads, or null with none printed.
 */
export function printedRung(printed = [], degree = "") {
  const have = new Set(Array.from(printed).map(norm));
  const d = norm(degree);
  const chain = {
    heroic: ["heroic", "critical", "success"], critical: ["critical", "success"], success: ["success"],
    partial: ["partial", "failure"], failure: ["failure"], fumble: ["fumble", "failure"], blunder: ["blunder", "fumble", "failure"]
  }[d] ?? [];
  return chain.find((k) => have.has(k)) ?? null;
}

/* ================================================================== */
/* The Bindings (§4.1; Q168, Q169, Q170)                                 */
/* ================================================================== */

/**
 * The eight, as printed (v1.6): the creature's trait and its maximum level
 * (L6088, 6706, 6784, 6830, 6930, 7400, 7889, 8033). M31: "leave this alone".
 */
export const BINDINGS = freeze({
  animalBinding: freeze({ name: "Animal Binding", type: "animal", max: 1 }),
  elementalBinding: freeze({ name: "Elemental Binding", type: "elemental", max: 2 }),
  entityBinding: freeze({ name: "Entity Binding", type: "aberration", max: 8 }),
  eternalBinding: freeze({ name: "Eternal Binding", type: "eternal", max: 6 }),
  feyBinding: freeze({ name: "Fey Binding", type: "fey", max: 1 }),
  plantBinding: freeze({ name: "Plant Binding", type: "plant", max: 2 }),
  undeadBinding: freeze({ name: "Undead Binding", type: "undead", max: 4 }),
  wyrmBinding: freeze({ name: "Wyrm Binding", type: "wyrm", max: 6 })
});
export const isBinding = (key) => Object.prototype.hasOwnProperty.call(BINDINGS, String(key ?? ""));

/** "Range 30 feet": the creature appears, or already stands, within 30 feet of the caster. */
export const BINDING_RANGE_FEET = 30;

/**
 * "+1 PP: increase the level of the creature by 1" — no ceiling printed
 * (Q169: none but the maximum PP per cast, which the core enforces). The warp
 * is `bonusValue: 1`, so `warpBonus` is the number bought.
 */
export const bindingMaxLevel = (key, warpBonus = 0) => (BINDINGS[key]?.max ?? 0) + Math.max(0, int(warpBonus));

/**
 * Q169: the Fumble's "+2 circumstance bonus to all checks" (Animal Binding
 * prints "checks", the seven "actions"): all checks, for all eight.
 */
export const LOYAL_BONUS = 2;

/**
 * What the creature's Will save does (§4.1's table; m42 for the missing
 * rungs; Block 2b's Fumble circle: "arrives hostile and unbound" whatever it
 * rolled).
 *   hostile  Critical: "arrives enraged and hostile, the duration ends"
 *   free     Success: "appears but resists, acting freely"
 *   bound    Failure: "bound and serves as a minion"
 *   loyal    Fumble: bound, and "unusually loyal" (+2 circumstance)
 */
export function bindingOutcome(degree, { circleFumble = false } = {}) {
  if (circleFumble) return "hostile";
  const rung = printedRung(["critical", "success", "failure", "fumble"], degree);
  return { critical: "hostile", success: "free", failure: "bound", fumble: "loyal" }[rung] ?? "bound";
}
/** Bound and loyal creatures count against Control Levels (H12, source "bound"); hostile and free ones do not (Q168). */
export const bindingControls = (outcome) => outcome === "bound" || outcome === "loyal";

/**
 * Block 2b's true name: "if the creature gets a success or greater on its
 * saving throw it becomes permanently hostile" — fed the binding's own save
 * (the audit's §5: the core's cast save is never rolled for a Binding).
 */
export const trueNameHostile = (degree) => succeeded(degree);

/** A creature's traits, from its creature-type item's name and its trait line (lower case). */
export function creatureTraitsOf({ typeName = "", traits = "" } = {}) {
  const out = new Set();
  if (norm(typeName)) out.add(norm(typeName));
  for (const t of String(traits ?? "").split(/[,;]/)) if (norm(t)) out.add(norm(t));
  return out;
}

/**
 * Why this creature cannot be the Binding's, or "" when it can. With
 * Versatile Binder the same checks apply to the existing creature (Q169).
 */
export function bindingRefusal(key, { traits = new Set(), level = 0, feet = null, isCaster = false } = {}, maxLevel = 0) {
  const spec = BINDINGS[key];
  if (!spec) return "not a Binding.";
  if (isCaster) return `${spec.name} cannot bind its caster.`;
  if (!traits.has(spec.type)) return `${spec.name} binds a creature with the ${spec.type} trait.`;
  if (int(level) > int(maxLevel)) return `${spec.name}: the creature must be level ${int(maxLevel)} or lower (it is level ${int(level)}).`;
  if (feet === null || feet === undefined) return "place the creature's token on the map first.";
  if (Number(feet) > BINDING_RANGE_FEET) return `${spec.name}: the creature must be within ${BINDING_RANGE_FEET} feet of the caster (it is ${Math.round(Number(feet))} ft away).`;
  return "";
}

/** The flags: the caster's record of a cast Binding, and the creature's bound effect. */
/**
 * A CLAIM ON A BINDING (the Block 8a re-review): who pressed Bind, and when
 * (real time, ms). The acting GM may take over a claim whose claimer is no
 * longer connected, or that is older than this (a client that dropped during
 * the save). Two minutes is the module's reading, not the book's.
 */
export const BINDING_CLAIM_STALE_MS = 120000;
/** Is this claim one the acting GM may take over? Pure. */
export function claimIsStale(claim, { now = 0, isActive = () => false } = {}) {
  if (!claim || !claim.user) return true;
  if (!isActive(String(claim.user))) return true;
  return Number(now) - Number(claim.at ?? 0) > BINDING_CLAIM_STALE_MS;
}

export const BINDING_FLAG = "binding8a";
export const BOUND_FLAG = "bound8a";
export const HOSTILE_FLAG = "binding8aHostile";

/* ================================================================== */
/* The Symbols (§4.3; Q184, m131, m132, m134, m135; M57)                 */
/* ================================================================== */

const cond = (key, value = null, extra = {}) => freeze({ key, ...(value === null ? {} : { value }), ...extra });

/**
 * The five, as printed. `rungs` holds only the printed rungs; a rolled
 * degree reads its rung by m42 (`symbolRung`). A rung's `conditions` are
 * condition tags; `critical` a critical injury's severity and type;
 * `dies` death; `insanity` core Insanity (H18) at the symbol's DC.
 *   curse  CURSE-trait Pain and Weakness: the conditions are held (H17)
 *          while within 60 ft and for 1 hour after (m135), and only Remove
 *          Curse ends them sooner (Q183).
 *   adds   the held condition's core rule: injured adds, weakened keeps the higher.
 */
export const SYMBOLS = freeze({
  symbolOfDeath: freeze({
    name: "Symbol of Death", save: "fortitude", livingOnly: true, fadesOnDeath: true,
    rungs: freeze({ success: freeze({}), failure: freeze({ critical: freeze({ severity: "deadly", damageType: "essence" }) }), fumble: freeze({ dies: true }) })
  }),
  symbolOfFear: freeze({
    name: "Symbol of Fear", save: "will",
    rungs: freeze({
      success: freeze({}), partial: freeze({ conditions: freeze([cond("frightened", 2)]) }),
      failure: freeze({ conditions: freeze([cond("frightened", 4), cond("fleeing", null, { rounds: 1 })]) }),
      fumble: freeze({ conditions: freeze([cond("frightened", 6), cond("fleeing", null, { rounds: 1 })]) })
    })
  }),
  symbolOfInsanity: freeze({ name: "Symbol of Insanity", save: "will", insanity: true, rungs: freeze({}) }),
  symbolOfPain: freeze({
    name: "Symbol of Pain", save: "fortitude", curse: true, held: "injured", adds: true,
    rungs: freeze({ success: freeze({}), failure: freeze({ hold: 2 }), fumble: freeze({ hold: 4 }) })
  }),
  symbolOfWeakness: freeze({
    name: "Symbol of Weakness", save: "fortitude", curse: true, held: "weakened", adds: false,
    rungs: freeze({ critical: freeze({}), success: freeze({ hold: 1 }), partial: freeze({ hold: 2 }), failure: freeze({ hold: 4 }), fumble: freeze({ hold: 6 }) })
  })
});
export const isSymbol = (key) => Object.prototype.hasOwnProperty.call(SYMBOLS, String(key ?? ""));

/** The rung a rolled degree reads, and what it does (m42; Insanity has no ladder: its save is core Insanity's). */
export function symbolRung(key, degree) {
  const spec = SYMBOLS[key];
  if (!spec) return { at: null, rung: null };
  if (spec.insanity) return { at: null, rung: null, insanity: true };
  const at = printedRung(Object.keys(spec.rungs), degree);
  return { at, rung: at ? spec.rungs[at] : null };
}

/**
 * Core Insanity's "On a failed Will save": its effect lands on a Failure,
 * Fumble or Blunder (a Partial is no success, and the core's save spells put
 * a Partial among those who failed, as here).
 */
export const insanityFails = (degree) => ["partial", "failure", "fumble", "blunder"].includes(norm(degree));

/** m135: "These effects last for 1 hour after the creature moves farther than 60 feet from the symbol". */
export const SYMBOL_HOLD_FEET = 60;
export const SYMBOL_HOLD_SECONDS = 3600;
/** "continues to glow until … no characters remain with line of sight to it for 10 minutes". */
export const SYMBOL_GLOW_SECONDS = 600;

/**
 * A later, worse result replaces a better one; an equal or better one leaves
 * it (§4.3). For a held condition: what to apply, and the hold's new share.
 * `adds` is the core's rule for the condition (injured adds; weakened keeps
 * the higher). `current` is what the creature has, `held` the value the hold
 * stands at, `contributed` what the hold has added to `current`.
 * @returns {{apply: number, after: number, held: number, contributed: number, worse: boolean}}
 */
export function heldStep({ adds = false, current = 0, held = 0, contributed = 0, next = 0 } = {}) {
  const c = Math.max(0, int(current)), h = Math.max(0, int(held)), n = Math.max(0, int(next));
  if (n <= h) return { apply: 0, after: c, held: h, contributed: Math.max(0, int(contributed)), worse: false };
  const apply = adds ? n - h : n;
  const after = adds ? c + apply : Math.max(c, apply);
  return { apply, after, held: n, contributed: Math.max(0, int(contributed)) + (after - c), worse: true };
}

/** Is the hold's hour running now (the creature farther than 60 ft), stopped (back within 60 ft), or unchanged? */
export function holdClock(feet, running) {
  if (feet === null || feet === undefined || !Number.isFinite(Number(feet))) return "unchanged";
  if (Number(feet) > SYMBOL_HOLD_FEET) return running ? "unchanged" : "start";
  return running ? "stop" : "unchanged";
}

/** Is the glow over: no character has had line of sight for 10 minutes of world time. */
export const glowLapsed = (lastSeen, now) => Number(now) - Number(lastSeen) >= SYMBOL_GLOW_SECONDS;

/** "Range touch": the symbol is carved within reach of the caster's space. */
export const TOUCH_FEET = 5;

export const SYMBOL_FLAG = "symbol8a";
export const SYMBOL_HOLD_FLAG = "symbolHold";

/* ================================================================== */
/* Exploration and utility (§3.2)                                       */
/* ================================================================== */

/** Arcane Pouch (L6206): "+1-circumstance bonus on Conceal an Object checks to conceal its contents". */
export const POUCH_CONCEAL_BONUS = 1;
/** "it can hold only 50 pounds. Regardless of what is placed into the pocket, it weighs 3 pounds." */
export const POUCH_CAPACITY_LB = 50;
export const POUCH_WEIGHT_LB = 3;

/** Archway of Ants (L6226): six 5-ft squares, +1 a warp; DB 10; the caster's HP; 10× the weight allowance. */
export const ARCHWAY_SQUARES = 6;
export const ARCHWAY_DB = 10;
export const ARCHWAY_RANGE_FEET = 30;
export const ARCHWAY_LOAD_FACTOR = 10;
export const archwaySquares = (warpBonus = 0) => ARCHWAY_SQUARES + Math.max(0, int(warpBonus));
/** The core's Weight Allowance (encumbrance.mjs): 50 + Strength score × 10. */
export const weightAllowance = (strength) => 50 + int(strength) * 10;
export const archwayLoad = (allowance) => ARCHWAY_LOAD_FACTOR * Math.max(0, int(allowance));

/** Harmonic Rift (L7026): two 5-ft openings within 500 ft; 3d8 sonic (basic Fortitude) to an enemy passing; +1d8 a warp. */
export const RIFT_RANGE_FEET = 500;
export const RIFT_DICE = "3d8";
export const riftDice = (warpDice = "") => {
  const extra = /^(\d+)d8$/.exec(String(warpDice ?? "").trim());
  return extra ? `${3 + int(extra[1])}d8` : RIFT_DICE;
};

/** Riserune (L7540): a Small or larger creature within 10 ft; up to 3 triggers. */
export const RISERUNE_FEET = 10;
export const RISERUNE_TRIGGERS = 3;
export const RISERUNE_SIZES = freeze(["small", "medium", "large", "huge", "gargantuan", "colossal"]);
export const riseruneTriggeredBy = (size) => RISERUNE_SIZES.includes(norm(size));

/** "1 week", "1 month", "1 year" in seconds (Argent Mark); "permanent" has none. */
export function markSeconds(duration) {
  const t = norm(duration);
  if (/permanent/.test(t)) return null;
  if (/year/.test(t)) return 365 * 86400;
  if (/month/.test(t)) return 30 * 86400;
  if (/week/.test(t)) return 7 * 86400;
  return 7 * 86400;
}

/** The flag the module's own Regions carry (Archway, Harmonic Rift, Riserune). */
export const AREA8A_FLAG = "grimoireArea8a";
/** Blood Biography's four questions (L6340–6346). */
export const BLOOD_QUESTIONS = freeze([
  "Who are you? (The name by which the creature is most commonly known)",
  "What are you? (Gender, race, profession/role)",
  "How was your blood shed? (Brief outline of the events that caused its wound, to the best of the victim’s knowledge)",
  "When was your blood shed?"
]);
/** Blood Biography: "living or undead creatures are entitled to a Will Saving Throw … (success or higher blocks the spell)". */
export const bloodBlocked = (degree) => succeeded(degree);

/* ================================================================== */
/* Ley Line Effects 25–27 (Q184)                                         */
/* ================================================================== */

/** "Your summoned creatures" and "Summons": the caster's bound and conjured entries in the control register. */
export const SUMMONED_SOURCES = freeze(["bound", "conjured"]);
export const isSummonedEntry = (entry) => SUMMONED_SOURCES.includes(String(entry?.source ?? ""));

/** The item's key (as Block 7's). */
export const keyOf = (spell) => String(spell?.flags?.[SYSTEM_ID]?.eaGrimoire ?? "");
