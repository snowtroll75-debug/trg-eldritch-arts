/**
 * Every registration Eldritch Arts makes with TRG Prime, in one place.
 * Called from the system's "trgPrime.registerContent" hook with the
 * module API (game.trgPrime.modules). Newer API calls are made with ?.
 * so an older system logs a problem instead of throwing.
 *
 * Kept apart from the Foundry-side automations' hooks so the harness can
 * hand it a fake `api` and assert exactly what was registered.
 */
import { registerBlock3b } from "./block3b-automations.mjs";
import { registerBlock4 } from "./block4-automations.mjs";
import { registerBlock5A } from "./block5a-automations.mjs";
import { registerBlock5B } from "./block5b-automations.mjs";
import { registerBlock5C } from "./block5c-automations.mjs";
import { registerBlock5D, TIME_LADDER_FEATS_B5D } from "./block5d-automations.mjs";
import { registerBlock6A } from "./block6a-automations.mjs";
import { registerBlock6B1 } from "./block6b1-automations.mjs";
import { registerBlock6B2 } from "./block6b2-automations.mjs";
import { registerBlock6C } from "./block6c-automations.mjs";
import { registerBlock6D } from "./block6d-automations.mjs";
import { registerBlock6E } from "./block6e-automations.mjs";
import { registerBlock7 } from "./block7-automations.mjs";
import { registerBlock8a } from "./block8a-automations.mjs";
import { registerBlock8b } from "./block8b-automations.mjs";
import { registerBlock9a } from "./block9a-automations.mjs";
import { registerBlock9b } from "./block9b-automations.mjs";
import { registerBlock9c } from "./block9c-automations.mjs";
import { registerBlock10, registerInfluenceFor } from "./block10-automations.mjs";
import { registerBlock11 } from "./block11-automations.mjs";
import { SKILL_ACTIONS as BLOCK10_ACTIONS } from "./block10-actions.mjs";
import { SKILL_ACTIONS } from "./block1-actions.mjs";
import { AUTOMATIONS, nullAuraGate, zhalVrynSurcharge, lingualCastingPath } from "./block1-automations.mjs";
import { SKILL_ACTIONS as BLOCK2_ACTIONS } from "./block2-actions.mjs";
import { SKILL_ACTIONS as BLOCK2B_ACTIONS } from "./block2b-actions.mjs";
import {
  RULES_KEY, ritualVariants, ritualFields, prepareRitual, ritualLiftsCap, ritualSettled, ritualSpellRefusal,
  summoningCircleGate, circleBindingOption, trueNameOption, spellTrickeryOption
} from "./block2b-automations.mjs";
import {
  suppressionGate, suppressionRemap, suppressionResonance, antimagicRefusal, antimagicSuppresses, chapter7Surcharge, resolveLeySenseDC
} from "./block2-automations.mjs";
import { AUTOMATIONS as BLOCK3_AUTOMATIONS, rawPowerRaise, specialistAccess, soulboundModifier, leyBondGate } from "./block3-automations.mjs";

export const SOURCEBOOK = "Eldritch Arts";

/**
 * THE 23 ARCHETYPES OF CHAPTER 5 (0.9.0, Block 6), registered with the core
 * so that the class feats traited with them gate (the core's class-feat slot
 * recognises a trait as an archetype gate only for a registered name, audit
 * "What the reviewers found"). High Mage and Birthrager also open the
 * Sorcerer's (Adept) feats (Q100; the core's 13 August ruling). The core's
 * own Runemage is not registered: it would duplicate the core's gate.
 *
 * The list is the runtime copy of tools/content/block6-common.mjs's
 * EA_ARCHETYPE_NAMES and block6-a.mjs's ARCHETYPE_OPTIONS_B6_A (those read
 * the book with node:fs and are not shipped); verify-block6-lead checks the
 * two are identical.
 */
export const ARCHETYPES_B6 = Object.freeze([
  "Angelic Pact", "Birthrager", "Blood of the Wyrm", "Bloodmage", "Demonic Pact", "Draconic Pact", "Elemental Pact",
  "Eternal Vigil", "Fatespinner", "Ferromancer", "Fey Pact", "Grave Pact", "Hex Weaver", "High Mage", "Leyline Weaver",
  "Runeblade", "Runebreaker", "Shade Master", "Spellwarden", "Spell Duellist", "Spell Weaver", "Stormcaller", "Void Pact"
]);
export const ARCHETYPE_OPTIONS_B6 = Object.freeze({
  "High Mage": Object.freeze({ classGrants: ["Sorcerer"], tierGrants: ["Adept"] }),
  Birthrager: Object.freeze({ classGrants: ["Sorcerer"], tierGrants: ["Adept"] })
});

/**
 * Chapter 2's Power Points, per level: "Power Points: +1" (Aetherial,
 * Emberkin, Scaelyn) and "Power Points: -1" (Nyrinn). No heritage prints
 * any (Wyrmdral's line replaces the attributes and size, not the PP).
 */
export const RACIAL_PP = Object.freeze({ Aetherial: 1, Emberkin: 1, Nyrinn: -1, Scaelyn: 1 });

/**
 * Chapter 5, EXISTING FEATS: "The races in this sourcebook also gain access
 * to the following racial feats from the TRG Core Rulebook" — as printed,
 * none limited to a heritage.
 */
export const EXISTING_RACIAL_FEATS = Object.freeze({
  Aetherial: Object.freeze(["Aura of Power", "Focused Pursuit"]),
  Emberkin: Object.freeze(["Component Savant", "Self Aware"]),
  Nyrinn: Object.freeze(["Ethereal Trick", "Shadow Magi"]),
  Scaelyn: Object.freeze(["Dracoris", "Sure Footed"])
});

/**
 * Chapter 6's two weapon traits the core does not list: Adept (the rule
 * below) and Ritualist (its ritual DC arrives with the rituals, Block 2).
 * Registered so a defence may name them, as the core's own traits.
 */
export const TRAITS = Object.freeze(["Adept", "Ritualist"]);

/**
 * Chapter 6, "ADEPT: This weapon is considered a simple weapon for those
 * with the Adept class type" (TRG Prime 3.675.0, C8).
 */
export const WEAPON_TRAIT_RULES = Object.freeze({ Adept: Object.freeze({ categoryAs: "Simple", classTypes: Object.freeze(["Adept"]) }) });

/**
 * Block 3a's three classes: proficiency as printed, and Chapter 6's Class
 * Wealth (Archmage 1, Sorcerer 0, Witch 1). Kept here as data (the content
 * build reads the same table) so registration needs no book at run time.
 */
export const CLASS_REGISTRATIONS = Object.freeze(Object.fromEntries([["Archmage", 1, [], ["Club", "Staff"], []], ["Sorcerer", 0, ["Simple"], [], []], ["Witch", 1, ["Simple"], [], []],
  // BLOCK 4 (0.7.0): "proficient in the use of light armour. You may use all simple and martial weapons";
  // "proficient with light armour. You may use all simple weapons". Class Wealth 2 and 1.
  ["Spellblade", 2, ["Simple", "Martial"], [], ["Light"]], ["Warlock", 1, ["Simple"], [], ["Light"]]].map(([name, wealth, cats, names, armour]) => [name, Object.freeze({
  wealth,
  proficiency: Object.freeze({
    label: name, armourCategories: armour, armourNames: [], otherTiers: [], armourExclude: [],
    shieldCategories: [], shieldNames: [], weaponCategories: cats, weaponNames: names, weaponRules: [], deityWeapons: false
  })
})])));

export function registerContent(api, moduleId) {
  api.registerSourcebook?.(moduleId, SOURCEBOOK, moduleId);

  // BLOCK 1 (0.1.0, on TRG Prime 3.675.0): Chapter 2, Chapter 4's actions,
  // the background feats, Chapter 6's exotic weapons and goods.
  for (const [name, per] of Object.entries(RACIAL_PP)) api.registerRacialPP(name, per, moduleId);
  for (const [race, feats] of Object.entries(EXISTING_RACIAL_FEATS)) api.registerFeatAccess?.("race", race, [...feats], moduleId);
  api.registerTraits?.([...TRAITS], moduleId);
  for (const [trait, spec] of Object.entries(WEAPON_TRAIT_RULES)) api.registerWeaponTraitRule?.(trait, { categoryAs: spec.categoryAs, classTypes: [...spec.classTypes] }, moduleId);
  // Ley Sense reads the map for its DC since 0.3.0 (a function, added after the clone).
  // Block 5 (0.8.0) adds feats' own time ladders to two of these actions:
  // Magus Appraiser (Appraise Magic) and Rapid Binder (Quickbind).
  api.registerSkillActions(SKILL_ACTIONS.map((a) => {
    const action = { ...structuredClone(a), ...(a.key === "leySense" ? { resolveDC: (ctx) => resolveLeySenseDC(ctx) } : {}) };
    const extra = TIME_LADDER_FEATS_B5D[a.key];
    if (extra) action.timeLadderByFeat = { ...(action.timeLadderByFeat ?? {}), ...structuredClone(extra) };
    return action;
  }), moduleId);
  for (const [name, entry] of Object.entries(AUTOMATIONS)) api.registerFeatAutomation(name, entry, moduleId);
  api.registerSpellCheckGate?.("nullAura", nullAuraGate, moduleId);
  api.registerCastSurcharge?.("zhalVryn", zhalVrynSurcharge, moduleId);
  api.registerReleasePath?.("lingualCasting", lingualCastingPath, moduleId);

  // BLOCK 2 (0.3.0, on TRG Prime 3.678.0): High Magic and Chapter 7.
  // Eldritch Arts' High Magic supersedes the Fiends & Fables guideline (M4).
  api.registerHighMagicRules?.(moduleId);
  // NOT CLONED: each carries its own DC (`resolveDC`), a function.
  api.registerSkillActions(BLOCK2_ACTIONS.map((a) => ({ ...a, outcomes: { ...a.outcomes } })), moduleId);
  api.registerSpellCheckGate?.("magicSuppression", suppressionGate, moduleId);
  api.registerCastDegreeRemap?.("magicSuppression", suppressionRemap, moduleId);
  api.registerResonanceSuppressor?.("magicSuppression", suppressionResonance, moduleId);
  api.registerCastRefusal?.("antimagic", antimagicRefusal, moduleId);
  api.registerEffectSuppressor?.("antimagic", antimagicSuppresses, moduleId);
  api.registerCastSurcharge?.("chapter7", chapter7Surcharge, moduleId);
  // Ley Line Connection's −1, from 0.5.0 also the Archmage's Ley Bond (one bond: the two do not stack).
  api.registerSpellCheckGate?.("leyLineConnection", leyBondGate, moduleId);

  // BLOCK 2b (0.4.0, on TRG Prime 3.679.0): rituals, summoning circles, true
  // names, Spell Trickery, Borrow Spell. NOT CLONED, as Block 2's: a DC is a function.
  api.registerSkillActions(BLOCK2B_ACTIONS.map((a) => ({ ...a, outcomes: { ...a.outcomes } })), moduleId);
  api.registerRitualRules?.(RULES_KEY, { variants: ritualVariants, fields: ritualFields, prepare: prepareRitual, liftsCap: ritualLiftsCap, settled: ritualSettled }, moduleId);
  api.registerCastRefusal?.("ritualSpells", ritualSpellRefusal, moduleId);
  api.registerSpellCheckGate?.("summoningCircle", summoningCircleGate, moduleId);
  api.registerCastOption?.("summoningCircle", circleBindingOption, moduleId);
  api.registerCastOption?.("trueName", trueNameOption, moduleId);
  api.registerCastOption?.("spellTrickery", spellTrickeryOption, moduleId);

  // BLOCK 3a (0.5.0, on TRG Prime 3.680.0): the Archmage, the Sorcerer and its
  // birthrights, the Witch and her Soulbound Familiar.
  for (const [name, spec] of Object.entries(CLASS_REGISTRATIONS)) api.registerClass?.(name, structuredClone(spec), moduleId);
  for (const [name, entry] of Object.entries(BLOCK3_AUTOMATIONS)) api.registerFeatAutomation(name, entry, moduleId);
  api.registerCastCapModifier?.("rawPower", rawPowerRaise, moduleId);
  api.registerSpecialistAccess?.("eldritchArtsClasses", specialistAccess, moduleId);
  api.registerFamiliarModifier?.("soulboundFamiliar", soulboundModifier, moduleId);
  api.registerPPGrant?.("Wild Power", { perLevel: 1, label: "Wild Power (+1 PP per level)", types: ["ability"] }, moduleId);

  // BLOCK 3b (0.6.0, on TRG Prime 3.681.0): the seven reactions.
  registerBlock3b(api, moduleId);

  // BLOCK 4 (0.7.0, on TRG Prime 3.682.0): the Spellblade and the Warlock —
  // their abilities' Uses, sidebar 16's feats (all four classes), Natural
  // Resilience's HP, the bonded souls' +1 level, Thunderous Strike's and
  // Dimensional Assault's preludes, a Warlock's hexes through the feat.
  registerBlock4(api, moduleId);

  // BLOCK 5 (0.8.0, on TRG Prime 3.683.0): Chapter 5's racial and general
  // feats. After Blocks 1 and 2b, whose entries two of them extend: Crystal
  // Pulse's Vir-ellian Release (5B), Masked Caster's Spell Trickery (5D).
  registerBlock5A(api, moduleId);
  registerBlock5B(api, moduleId);
  registerBlock5C(api, moduleId);
  registerBlock5D(api, moduleId);

  // BLOCK 6 (0.9.0, on TRG Prime 3.684.0): Chapter 5's archetypes and class
  // feats, and the module's metamagic (G1). After Blocks 3 and 5: 6B2
  // replaces Block 3's Gale Step Use (a Stormcaller pays 0 AP), and 6D
  // registers the metamagic of Block 5's five deferred feats.
  for (const name of ARCHETYPES_B6) api.registerArchetype?.(name, structuredClone(ARCHETYPE_OPTIONS_B6[name] ?? {}), moduleId);
  registerBlock6A(api, moduleId);
  registerBlock6B1(api, moduleId);
  registerBlock6B2(api, moduleId);
  registerBlock6C(api, moduleId);
  registerBlock6D(api, moduleId);
  registerBlock6E(api, moduleId);

  // BLOCK 7 (0.10.0, on TRG Prime 3.685.0): the first half of Chapter 8's
  // Grimoire — its gates, reactions, refusals, the Flesh to Blossom prelude,
  // Eaog Balls' Dispel bias and Zone Disruption's fumble warp, and the
  // Elemental Strike ability's Use.
  registerBlock7(api, moduleId);

  // BLOCK 8a (0.11.0, on TRG Prime 3.686.0): the Bindings, Symbols and
  // utilities of the Grimoire's second half — the two deferred teleports
  // (Arcane Pouch moves nobody; Harmonic Rift's passages are their own).
  registerBlock8a(api, moduleId);
  // BLOCK 8b (0.12.0, on TRG Prime 3.687.0): the rituals and Chapter 7's High Magic spells.
  registerBlock8b(api, moduleId);
  // BLOCK 9a (0.13.0, on TRG Prime 3.688.0): the catalysts (TRG Prime's cast
  // items, H19; Blood-etched Vellum in the ritual) and the special materials (H20).
  registerBlock9a(api, moduleId);
  // BLOCK 9b (0.14.0, on TRG Prime 3.689.0): the 34 runes (TRG Prime's rune
  // declarations, H21; the strike's die and fumble, H22) and their workflows.
  registerBlock9b(api, moduleId);
  // BLOCK 9c (0.15.0): the Orb kind and its one-invested trait, the rods' casting options, Ley Resonance's PP.
  registerBlock9c(api, moduleId);
  // BLOCK 10a (0.17.0, on TRG Prime 3.693.0): the relics and Dawnshield —
  // bonding (a skill action), awakening, the tier invested (H27's cost,
  // prepare and refusal), the powers, and the Veilshroud's absorption (H28).
  api.registerSkillActions(BLOCK10_ACTIONS.map((a) => ({ ...a, outcomes: { ...a.outcomes } })), moduleId);
  registerBlock10(api, moduleId);
  // BLOCK 11 (0.18.0): the Feat Additions — Artificer, Runemage and Ascendan feats.
  registerBlock11(api, moduleId);
  registerInfluenceFor(api, ["Dawnshield: Influence (GM)"], moduleId);
}
