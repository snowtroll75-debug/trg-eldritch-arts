/**
 * Eldritch Arts — Block 8b (0.12.0, on TRG Prime 3.687.0): what Chapter 8's
 * ten rituals and seven High Magic spells do that is not data. The spells are
 * tools/content/block8b-spells.mjs; their numbers and pure rules are
 * module/block8b-rules.mjs. Each spell is found by its `eaGrimoire` key.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2, §4.2 and §4.4, as Graham
 * answered it on 8 November 2026 (17:22, "As recommended"): Q170–Q182 as each
 * row recommends; seams H13 (a ritual's Partial casts), H14 (a ritual by its
 * primary alone), H15 (rest rates) and H16 (a rolled, turn-start, following
 * storm), TRG Prime 3.687.0.
 *
 * THE RITUAL MODEL (§4.2). The core's Magic Ritual rolls; Block 2b's rules
 * lift the cap and offer the variants; this block's rules (registered beside
 * them) add each ritual's dialog ticks (who takes part), check its Cost before
 * the roll, let its Partial cast (H13) and let three be performed alone (H14).
 * Once the cast is settled, the ritual's printed rung (m42's table for the
 * missing ones) is applied on top of the core's base result; its Cost is taken
 * whatever the degree (Q174); a failing rung's damage goes to every caster at
 * that caster's own level DC (C3).
 *
 * WHICH CLIENT DOES THE WORK (the 3.685.2/3.685.3 lesson, and 3.686.2's):
 *   the settled cast       the caster's client (the hook fires there only)
 *   a GM card's button     the GM who presses it (any tab of the GM's account)
 *   a token's move, the clock, a membership   the acting GM's elected tab
 *   a creature's own choice (an element)   its owner's client (`actsFor`)
 */
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, tokenOf, feetBetween, spendAP } from "./block1-automations.mjs";
import { pickPoint, actsFor } from "./block3-automations.mjs";
import { ritualVariants, isEldritchArtsSpell, hasTrait } from "./block2b-automations.mjs";
import { writeOn, activeEntryFor } from "./block7-automations.mjs";
import { enemiesBySide } from "./block7-rules.mjs";
import { feetFromPointDoc, docCentre, sightBlocked } from "./block8a-automations.mjs";
import { keyOf } from "./block8a-rules.mjs";
import { isActingGM, isActiveGMAccount } from "./writer.mjs";
import { endPositionOf } from "./token-moves.mjs";
import * as R from "./block8b-rules.mjs";

export const RULES_KEY_8B = `${MODULE_ID}-8b`;
const SOCKET = `module.${MODULE_ID}`;
const ACTION_8B = "eaBlock8b";

const worldNow = () => Number(globalThis.game?.time?.worldTime ?? 0);
const effects = (actor) => Array.from(actor?.effects ?? []);
const sourceOf = (effect) => effect?.flags?.[MODULE_ID]?.source ?? "";
const tokens = (scene = globalThis.canvas?.scene) => Array.from(scene?.tokens ?? []).filter((d) => d?.actor);
const allScenes = () => { const list = Array.from(globalThis.game?.scenes ?? []); return list.length ? list : [globalThis.canvas?.scene].filter(Boolean); };
/**
 * "YOUR SAVE DC" ON A CAST THAT CARRIES NONE (a failed one): TRG Prime's
 * spellSaveDC, 10 + the PP cast + the casting ability. FOUND LIVE twice (12
 * November): the sheet's Spellcraft DC (10 + BSB + ability) is not it — with
 * the PP added it gave 55 for a 20 PP storm whose cast used 35; alone it gave
 * 35 for a 10 PP Veilfracture whose Save DC is 25.
 */
export function failedCastSaveDC(actor, ctx = {}) {
  if (int(ctx.saveDC) > 0) return int(ctx.saveDC);
  const sys = actor?.system ?? {};
  const ability = Number(sys.attributes?.[sys.magic?.castingAbility]?.total ?? sys.magic?.castingAbilityScore ?? 0) || 0;
  const pp = Math.max(0, int(ctx.castPP ?? ctx.ppSpent ?? ctx.spell?.system?.ppCost));
  return 10 + pp + Math.floor(ability);
}
const casterLevelOf = (actor) => int(actor?.system?.magic?.casterLevelValue ?? actor?.system?.magic?.casterLevel);
const ppOf = (actor) => int(actor?.system?.resources?.pp?.value);
const ownLevelDC = (actor) => h().levelDC(levelOf(actor));
/** A check's success, from its degree (the core's `degree.success`, else its key). */
const succeeded = (check) => { const d = check?.outcome?.degree; return d?.success ?? ["success", "critical", "heroic"].includes(String(d?.key ?? "")); };
const regionVisibility = (key) => globalThis.CONST?.REGION_VISIBILITY?.[key] ?? { GAMEMASTER: 1, ALWAYS: 2 }[key];
const unlocksOf = (ctx) => Array.from(ctx?.warpMods?.unlocks ?? []).map(String);
const bonusOf = (ctx) => int(ctx?.warpMods?.bonusValue);
const durationTextOf = (ctx) => String(ctx?.warpMods?.durationText || ctx?.spellData?.duration || ctx?.spell?.system?.duration || "");
const conMod = (actor) => int(actor?.system?.attributes?.constitution?.total);
const sideOf = (doc) => int(doc?.disposition ?? doc?.document?.disposition);
const docOf = (actor) => { const t = tokenOf(actor); return t?.document ?? null; };
async function resolve(uuid) {
  if (!uuid) return null;
  try { return globalThis.fromUuidSync?.(uuid) ?? await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(uuid) ?? null; } catch { return null; }
}
/**
 * WHO ANSWERS A CREATURE'S OWN CHOICE (the review, 0.12.0): its first connected
 * player owner, else any tab of the active GM's account — the GM answers where
 * the GM is looking, not only on the elected tab. A second answer is ignored by
 * each task's own re-check.
 */
export function answersFor(actor) {
  const users = globalThis.game?.users;
  if (!users || typeof users.filter !== "function") return Boolean(actor?.isOwner);
  const owners = users.filter((u) => u.active && !u.isGM && actor?.testUserPermission?.(u, "OWNER")).sort((a, b) => String(a.id).localeCompare(String(b.id)));
  if (owners.length) return owners[0] === globalThis.game.user;
  return isActiveGMAccount();
}
/** The sheet's Spellcraft modifiers, for a Spellcraft check rolled through rollCheck. */
export const spellcraftModifiers = (actor) => {
  const sc = actor?.system?.magic?.spellcraft ?? {};
  return Array.isArray(sc.checkModifiers) && sc.checkModifiers.length ? sc.checkModifiers : [{ label: "Spellcraft", value: int(sc.total), type: "untyped" }];
};
const actorOf = (doc) => (doc?.documentName === "Actor" ? doc : doc?.actor ?? doc ?? null);
const pxPerFoot = (scene = globalThis.canvas?.scene) => Number(scene?.grid?.size ?? globalThis.canvas?.dimensions?.size ?? 100) / Number(scene?.grid?.distance ?? globalThis.canvas?.dimensions?.distance ?? 5);

/** The creature's traits, as TRG Prime reads them (module/creature-traits.mjs `creatureTraits`). */
export function traitsOf(actor) {
  const sys = actor?.system ?? {};
  const list = (v) => (Array.isArray(v) ? v : String(v ?? "").split(",")).map(norm).filter(Boolean);
  return [...new Set([...list(sys.details?.traits), ...list(sys.details?.creatureType), ...list(sys.details?.grantedTraits)])];
}

/* ================================================================== */
/* Cards with buttons (the Block 8a card, its own attribute)            */
/* ================================================================== */

function cardHTML(actor, title, lines, buttons = []) {
  const body = lines.map((l) => `<p style="margin:2px 0">${l}</p>`).join("");
  const row = buttons.length
    ? `<div class="ea8b-buttons" style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">${buttons.map((b) => `<button type="button" data-ea8b="${esc(b.action)}" data-ea8b-caster="${esc(b.caster ?? "")}" data-ea8b-ref="${esc(b.ref ?? "")}">${esc(b.label)}</button>`).join("")}</div>`
    : "";
  return `<div class="trg-prime trg-check-card"><header class="check-header"><div class="check-heading"><span class="check-actor">${esc(actor?.name ?? "")}</span><h3>${esc(title)}</h3></div></header>${body}${row}</div>`;
}
async function buttonCard(actor, title, lines, buttons = [], { gm = false } = {}) {
  const game = globalThis.game;
  const whisper = gm ? Array.from(game?.users ?? []).filter((u) => u.isGM).map((u) => u.id) : null;
  return globalThis.ChatMessage?.create?.({ speaker: globalThis.ChatMessage?.getSpeaker?.({ actor }) ?? {}, content: cardHTML(actor, title, lines, buttons), ...(whisper ? { whisper } : {}) });
}

/** A checklist dialog: the ids ticked, or null when cancelled. */
async function pickMany(title, hint, items, { max = Infinity, checked = true } = {}) {
  if (!items.length) return [];
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2) return items.map((i) => i.id).slice(0, max);
  const rows = items.map((i) => `<div class="form-group"><label><input type="checkbox" name="pick-${esc(i.id)}"${checked ? " checked" : ""}> ${esc(i.label)}</label></div>`).join("");
  const picked = await DialogV2.wait({
    window: { title }, classes: ["trg-prime"],
    content: `<div class="trg-prime trg-check-dialog"><p class="hint">${esc(hint)}</p>${rows}</div>`,
    buttons: [{ action: "ok", label: "Confirm", default: true, callback: (event, button) => Array.from(button.form?.elements ?? []).filter((el) => el.checked).map((el) => String(el.name).replace(/^pick-/, "")) }, { action: "cancel", label: "Cancel" }],
    rejectClose: false
  });
  if (!Array.isArray(picked)) return null;
  return picked.slice(0, max);
}

/** End a cast that left nothing standing (a Partial or a failing rung that cast, H13). */
async function endCast(actor, ctx) {
  const entry = activeEntryFor(actor, ctx.spell?.name);
  if (entry?.id) await h().endSpellOf?.(actor, entry.id);
}

/* ================================================================== */
/* The ritual's rules (TRG Prime 3.679.0 D13, 3.687.0 H13 and H14)      */
/* ================================================================== */

const ritualKeyOf = (spell) => (R.isRitual8b(keyOf(spell)) && isEldritchArtsSpell(spell) ? keyOf(spell) : "");
const others = (actor) => {
  const seen = new Set([actor?.id]);
  const out = [];
  for (const t of globalThis.canvas?.tokens?.placeables ?? []) {
    const a = t.actor;
    if (!a || seen.has(a.id)) continue;
    seen.add(a.id);
    out.push(a);
  }
  return out;
};

/** The dialog's ticks: secondary casters (unless Block 2b's variant ticks show them), and who else takes part. */
export async function ritualFields8b({ actor, spell, spellData } = {}) {
  const key = ritualKeyOf(spell);
  if (!key) return "";
  const list = others(actor);
  const tick = (name, label) => `<div class="form-group"><label><input type="checkbox" name="${name}"> ${label}</label></div>`;
  const parts = [`<hr><p class="hint">${esc(R.RITUALS[key].name)} (Eldritch Arts) — who takes part. The primary is always a caster.</p>`];
  const variants = await ritualVariants({ actor, spellData });
  if (!variants.length) {
    parts.push(`<p class="hint">Tick each secondary caster entered above (they share in its failure, Q173):</p>`
      + (list.length ? list.map((a) => tick(`eaSecondary-${a.id}`, esc(a.name))).join("") : `<p class="hint"><em>No other creature is on the scene.</em></p>`));
  }
  if (["sunsBenediction", "riteOfEchoedShadows", "callOfTheAncestors", "riteOfBindingOath"].includes(key)) {
    parts.push(`<p class="hint">Other willing creatures taking part (participants, Q173 — the casters are participants already):</p>`
      + (list.length ? list.map((a) => tick(`eaParticipant-${a.id}`, esc(a.name))).join("") : `<p class="hint"><em>No other creature is on the scene.</em></p>`));
  }
  const cost = R.RITUALS[key].cost;
  if (cost.corpses) parts.push(`<p class="hint">Cost: one intact corpse per 2 PP spent, consumed (counted on the card).</p>`);
  if (cost.note) parts.push(`<p class="hint">Cost: ${esc(cost.note)} — by hand.</p>`);
  return parts.join("");
}

/** The ritual's plan: who takes part, and the Cost checked before the roll (Q174). */
export async function prepareRitual8b({ actor, spell, form = {}, basePP = 0, ppOver = 0, secondaryCount = 0 } = {}) {
  const key = ritualKeyOf(spell);
  if (!key) return null;
  const spec = R.RITUALS[key];
  const secondaries = others(actor).filter((a) => form[`eaSecondary-${a.id}`]);
  if (secondaries.length !== int(secondaryCount)) {
    return { refused: `tick each secondary caster taking part (${int(secondaryCount)} entered, ${secondaries.length} ticked): they share in what follows` };
  }
  const participants = others(actor).filter((a) => form[`eaParticipant-${a.id}`] && !secondaries.includes(a));
  const lines = [];
  let targetLevel = null;
  if (spec.cost.gpPerTargetLevel) {
    const targets = Array.from(globalThis.game?.user?.targets ?? []);
    if (targets.length !== 1 || !targets[0]?.actor) return { refused: "target the one creature first: its level sets the Cost (200 gp × its level)" };
    targetLevel = levelOf(targets[0].actor);
  }
  const gp = R.ritualCostGP(spec, { castPP: int(basePP), targetLevel });
  if (gp) {
    const have = Number(await h().goldOf(actor)) || 0;
    if (have < gp) return { refused: `its Cost is ${gp} gp${spec.cost.gpPerPP ? " (100 gp per PP, before any warp)" : ""}, and ${actor.name} has ${have} gp` };
    lines.push(`Cost: <strong>${gp} gp</strong>${spec.cost.gpPerPP ? " at least (100 gp per PP as cast, warps included)" : ""}, taken when the casting is settled, whatever its degree (Q174).`);
  }
  await actor.setFlag(MODULE_ID, R.RITUAL_PLAN_FLAG, { key, spell: spell?.uuid ?? "", secondaries: secondaries.map((a) => a.uuid), participants: participants.map((a) => a.uuid), targetLevel, at: worldNow() });
  return { lines };
}

/** H13: an Eldritch Arts ritual's Partial casts (Q171) — every one of the ten, so every degree settles. */
export const ritualPartialCasts8b = ({ spell } = {}) => Boolean(ritualKeyOf(spell));
/** H14: Elemental Convergence, Essence Reforging and Eternal Invocation may be performed alone (Q172). */
export const ritualMinSecondaries8b = ({ spell } = {}) => (R.RITUALS[ritualKeyOf(spell)]?.alone ? 0 : null);

/* ================================================================== */
/* The settled ritual                                                   */
/* ================================================================== */

async function takePlan(actor, spell) {
  const plan = actor.getFlag?.(MODULE_ID, R.RITUAL_PLAN_FLAG) ?? null;
  if (plan) await actor.unsetFlag(MODULE_ID, R.RITUAL_PLAN_FLAG);
  return plan && plan.spell === (spell?.uuid ?? "") ? plan : { secondaries: [], participants: [], targetLevel: null };
}
const actorsOf = async (uuids) => (await Promise.all(Array.from(uuids ?? []).map(resolve))).map(actorOf).filter(Boolean);

/** The casters' damage (C3: each at its own level DC). */
async function hitCasters(actor, ctx, spec, rung, casters, chosenType = null) {
  const hit = R.casterHit(spec, rung);
  if (!hit) return [];
  const who = hit.who === "primary" ? [actor] : casters;
  const out = [];
  for (const c of who) {
    let type = hit.type;
    if (type === "chosen") type = chosenType?.get?.(c.uuid) ?? await chooseElement(c, `${spec.name}: the element ${c.name} chose`);
    if (!type) { out.push(line(`${esc(c.name)}: no element chosen — ${hit.formula} damage, basic ${hit.save}, by hand.`)); continue; }
    const res = await h().basicSaveHit({ caster: actor, target: c, save: hit.save, dc: ownLevelDC(c), label: `${spec.name} (${rung})`, formula: hit.formula, type });
    out.push(res?.line ?? line(`${esc(c.name)}: ${hit.formula} ${type}, basic ${hit.save}.`));
  }
  return out;
}

async function chooseElement(actor, prompt) {
  const pick = await h().chooseFromList(prompt, "Which element?", R.ELEMENTS.map((e) => [e, e.charAt(0).toUpperCase() + e.slice(1)]));
  return R.ELEMENTS.includes(String(pick)) ? String(pick) : null;
}

/** The Cost, taken (Q174): gold from the primary's purse. */
async function payCost(actor, spec, { castPP, targetLevel }) {
  if (spec.cost.corpses) return [line(`Cost: <strong>${R.corpsesFor(castPP)} intact corpse${R.corpsesFor(castPP) === 1 ? "" : "s"}</strong> (one per 2 PP spent), consumed — remove them by hand.`)];
  if (spec.cost.note) return [line(`Cost: ${esc(spec.cost.note)} — by hand.`)];
  const gp = R.ritualCostGP(spec, { castPP, targetLevel });
  if (!gp) return [];
  const paid = await h().deductGold(actor, gp);
  return [line(paid?.paid ? `Cost: <strong>${gp} gp</strong> consumed in the rite (taken from ${esc(actor.name)}'s purse).` : `Cost: <strong>${gp} gp</strong> — the purse is short by ${int(paid?.shortfallGP)} gp; nothing was taken. The GM settles it.`)];
}

export async function onRitualSettled(actor, ctx) {
  const key = ritualKeyOf(ctx.spell);
  const spec = R.RITUALS[key];
  if (!spec || !ctx.ritual) return null;
  const plan = await takePlan(actor, ctx.spell);
  const title = `${spec.name} — the rite`;
  if (ctx.refunded) return card(actor, title, [line("<em>The casting was stopped before it settled: the Cost is not taken and nothing happens.</em>")]);
  const rung = R.ritualRung(spec, ctx.degree);
  const castPP = int(ctx.castPP ?? ctx.ppSpent);
  const secondaries = await actorsOf(plan.secondaries);
  const participants = await actorsOf(plan.participants);
  const casters = [actor, ...secondaries];
  const lines = [line(`Rolled <strong>${esc(ctx.degree)}</strong>${rung !== ctx.degree ? `, read as <strong>${esc(rung)}</strong> (${spec.noLadder ? "M45: success works, failure does not" : "m42"})` : ""}.`)];
  lines.push(...await payCost(actor, spec, { castPP, targetLevel: plan.targetLevel }));
  const run = RITUAL_RUNNERS[key];
  const out = run ? await run(actor, ctx, { spec, rung, castPP, casters, secondaries, participants, plan }) : { lines: [] };
  lines.push(...(out?.lines ?? []));
  if (R.failingRung(rung) || rung === "fails" || out?.ends) await endCast(actor, ctx);
  return card(actor, title, lines);
}

/* ------------------------------------------------------------------ */
/* The ten                                                              */
/* ------------------------------------------------------------------ */

const ritualSite = (actor) => { const t = tokenOf(actor); return t ? { x: t.center?.x ?? docCentre(t.document).x, y: t.center?.y ?? docCentre(t.document).y } : null; };
const areaRecordOf = (region) => region?.flags?.[MODULE_ID]?.[R.AREA8B_FLAG] ?? null;
/** A cast-bound record's cast still stands (one with no cast, or no caster found, stands). */
export function castStands(rec) {
  if (!rec?.castBound || !rec.castId) return true;
  let caster = null;
  try { caster = actorOf(globalThis.fromUuidSync?.(rec.casterUuid) ?? null); } catch { caster = null; }
  if (!caster) return true;
  return Array.from(caster.getFlag?.(SYSTEM_ID, "activeSpells") ?? []).some((e) => e?.id === rec.castId);
}
export const areas8b = (key = null, scene = globalThis.canvas?.scene) => Array.from(scene?.regions ?? []).filter((r) => { const rec = areaRecordOf(r); return rec && (!key || rec.key === key) && worldNow() < Number(rec.until ?? Infinity) && castStands(rec); });
/** A circle Region at a point, with the module's record. */
async function createCircle(actor, name, centre, radiusFeet, rec, { hidden = false } = {}) {
  const scene = globalThis.canvas?.scene;
  if (!scene || !centre) return null;
  const [region] = await scene.createEmbeddedDocuments("Region", [{
    name, color: "#7a4fb0", visibility: regionVisibility(hidden ? "GAMEMASTER" : "ALWAYS"),
    shapes: [{ type: "circle", x: Number(centre.x), y: Number(centre.y), radius: Math.max(1, Number(radiusFeet)) * pxPerFoot(scene), hole: false }],
    flags: { [MODULE_ID]: { [R.AREA8B_FLAG]: { ...rec, centre: { x: Number(centre.x), y: Number(centre.y) }, radius: Number(radiusFeet), casterUuid: actor.uuid, sceneId: scene.id } } }
  }]);
  return region ?? null;
}
const untilOf = (text) => { const s = R.spanSeconds(text); return s === Infinity ? null : s ? worldNow() + s : null; };
const castIdOf = (actor, ctx) => activeEntryFor(actor, ctx.spell?.name)?.id ?? "";

const RITUAL_RUNNERS = {
  /* Army of the Grave: the GM raises the undead; they are counted and controlled. */
  async armyOfTheGrave(actor, ctx, { rung, castPP, casters, spec }) {
    const unlocks = unlocksOf(ctx);
    const lines = [];
    if (R.failingRung(rung)) {
      lines.push(line("<strong>All rise uncontrolled and attack.</strong> GM: place the undead (one per intact corpse) hostile to the casters."));
      lines.push(...await hitCasters(actor, ctx, spec, rung, casters));
      return { lines };
    }
    const rec = { id: globalThis.foundry?.utils?.randomID?.() ?? String(Date.now()), rung, castPP, half: R.has(unlocks, R.UNLOCK.armyHalf), duration: R.armyDuration(rung, unlocks), castId: castIdOf(actor, ctx), saveDC: int(ctx.saveDC), permanent: R.has(unlocks, R.UNLOCK.armyPermanent) };
    await actor.setFlag(MODULE_ID, "army8b", rec);
    lines.push(line(`${rung === "partial" ? "<strong>Half rise under control for 1 day; half are uncontrolled</strong> (this replaces the normal Partial)." : `<strong>All rise under control</strong> for ${esc(rec.duration)}.`} At most <strong>${R.corpsesFor(castPP)}</strong> undead (one per corpse), their levels totalling no more than <strong>${castPP}</strong>${rec.half ? " (each counted at half its level)" : ""} (Q175).`));
    lines.push(line("Skeletons and zombies may be raised freely; any other undead must be one you have studied — the GM's."));
    if (rec.permanent) lines.push(line("<strong>Permanent</strong>: the ritual site gains the Evil aligned trait and is tainted by the Shadescape (marked on the map)."));
    lines.push(line("Command: one 1 AP command (auditory, concentrate) gives them all the same action (Q175) — from your sheet."));
    await buttonCard(actor, `${spec.name} — the undead`, [`GM: place the undead within 300 ft of ${esc(actor.name)} and select them, then press the button.`], [{ action: "raiseUndead", caster: actor.uuid, ref: rec.id, label: "Raise the selected undead" }], { gm: true });
    return { lines };
  },

  /* Call of the Ancestors: the GM answers; a Critical's advantage is held. */
  async callOfTheAncestors(actor, ctx, { rung, casters, participants, spec }) {
    const lines = [];
    if (R.failingRung(rung)) {
      lines.push(...await hitCasters(actor, ctx, spec, rung, casters));
      if (rung === "blunder") lines.push(line("<strong>A hostile spirit possesses one participant</strong> — the GM chooses whom and runs it."));
      return { lines, ends: true };
    }
    const n = R.ancestorQuestions(bonusOf(ctx));
    lines.push(line(`The ancestral shades answer <strong>up to ${n} question${n === 1 ? "" : "s"}</strong> — the GM's answers: ${rung === "critical" ? "clear" : rung === "partial" ? "truthful but cryptic, and <strong>one answer is misleading</strong>" : "truthful but symbolic"}.`));
    if (rung === "critical") {
      const who = [...casters, ...participants];
      const pick = who.length === 1 ? who[0].id : await h().chooseFromList(spec.name, "Which participant gains advantage on a single check within 24 hours?", who.map((a) => [a.id, a.name]));
      const chosen = who.find((a) => a.id === pick) ?? null;
      if (chosen) {
        await h().createEffectsOn(chosen, [effectData("ancestorsFavour8b", { name: `${spec.name}: advantage on one check`, img: ctx.spell?.img,
          description: "Advantage on a single check within 24 hours — tick it on the check you choose.",
          system: { conditionals: [{ kind: "advantage", label: spec.name, scope: "a single check within 24 hours — tick it", auto: false, oneShot: true }] }, expiry: forSeconds(R.SPAN.day) })]);
        lines.push(line(`${esc(chosen.name)}: <strong>advantage on a single check</strong> within 24 hours (ticked on the check).`));
      } else lines.push(line("<em>No participant chosen: the advantage is the table's.</em>"));
    }
    return { lines, ends: true };
  },

  /* Concord of Stone: a Region; allies inside +2 circumstance to DB; DR on structures by hand. */
  async concordOfStone(actor, ctx, { rung, casters, spec }) {
    if (R.failingRung(rung)) return { lines: await hitCasters(actor, ctx, spec, rung, casters) };
    const shape = R.concordShape(rung, unlocksOf(ctx));
    const region = await createCircle(actor, `${spec.name}: structures DR ${shape.dr}; allies +${R.CONCORD_DB} DB`, ritualSite(actor), shape.radius,
      { key: "concordOfStone", castId: castIdOf(actor, ctx), until: untilOf(shape.duration), dr: shape.dr, side: sideOf(docOf(actor)), members: {} });
    if (region) await syncMembers(region);
    return { lines: [
      line(`A ${shape.radius}-ft radius around the ritual site, for <strong>${esc(shape.duration)}</strong>.`),
      line(`Allies of ${esc(actor.name)} defending within it: <strong>+${R.CONCORD_DB} circumstance to DB</strong> (applied while they stand inside).`),
      line(`Structures within it: <strong>DR ${shape.dr}</strong> — by hand (TRG Prime gives objects no DR row); labelled on the Region.`),
      ...(region ? [] : [line("<em>No scene or token to place the zone: the GM draws it.</em>")])
    ] };
  },

  /* Elemental Convergence: an emanation; each creature's element: resistance, and a strike rider. */
  async elementalConvergence(actor, ctx, { rung, casters, spec }) {
    if (R.failingRung(rung)) {
      const chosen = new Map();
      return { lines: [line("The convergence turns on its makers: each caster's damage is of the element that caster chose (M42)."), ...await hitCasters(actor, ctx, spec, rung, casters, chosen)] };
    }
    const radius = R.convergenceRadius(unlocksOf(ctx));
    const duration = durationTextOf(ctx) || "24 hours";
    const t = tokenOf(actor);
    const region = await createCircle(actor, `${spec.name}: the Elemental Convergence Zone`, ritualSite(actor), radius,
      { key: "elementalConvergence", castBound: true, castId: castIdOf(actor, ctx), until: untilOf(duration), dice: R.convergenceDice(rung), followTokenId: t?.document?.id ?? t?.id ?? "", members: {} });
    if (region) await syncMembers(region);
    return { lines: [
      line(`A ${radius === 5280 ? "1-mile" : `${radius}-foot`} emanation for <strong>${esc(duration)}</strong>. Each creature within chooses an element (fire, cold, electricity or acid): <strong>resistance</strong> to it, and <strong>+${R.convergenceDice(rung)} ${"secondary damage of that type"}</strong> on its weapon and unarmed Strikes — the rider is an effect it may switch off ("can choose").`),
      line("Each creature's owner is asked once, as it is first found within; leaving switches its effect off, coming back on."),
      line("<em>The volatile weather (storms, earthquakes, heat waves) is the GM's.</em>")
    ] };
  },

  /* Essence Reforging: one of three uses on one willing creature. */
  async essenceReforging(actor, ctx, { rung, castPP, plan, spec }) {
    const lines = [];
    const target = Array.from(globalThis.game?.user?.targets ?? [])[0]?.actor ?? null;
    if (rung !== "works") {
      lines.push(line("<strong>The reforging fails</strong> (no ladder: Success works, failure does not — M45)."));
      if (["fumble", "blunder"].includes(rung)) {
        const lvl = int(plan.targetLevel ?? levelOf(target));
        const formula = R.reforgingBacklash(lvl);
        lines.push(line(`<strong>${formula} force</strong> to you and the target (1d8 per its level), after the ritual's own failure:`));
        for (const who of [actor, target].filter(Boolean)) {
          const res = await h().applyTypedDamage(who, { amount: (await new Roll(formula).evaluate()).total, type: "force", sourceName: spec.name });
          lines.push(line(`${esc(who.name)} takes <strong>${int(res?.applied)}</strong> force.`));
        }
      }
      return { lines, ends: true };
    }
    if (!target) return { lines: [line("<em>No target: the reforging is the GM's.</em>")], ends: true };
    const use = await h().chooseFromList(spec.name, `What does the reforging do to ${target.name}?`, R.REFORGING_USES.map(([k, l]) => [k, l]));
    if (use === "remove") {
      const list = effects(target).filter((e) => !e.disabled).map((e) => ({ e, pp: int(e.origin ? globalThis.fromUuidSync?.(e.origin)?.system?.ppCost : 0) }));
      const able = list.filter((x) => !x.pp || x.pp <= castPP);
      const pick = able.length ? await h().chooseFromList(spec.name, `Which permanent curse or transformation (PP ${castPP} or lower)?`, able.map((x) => [x.e.id, `${x.e.name}${x.pp ? ` (PP ${x.pp})` : ""}`])) : null;
      const chosen = able.find((x) => x.e.id === pick)?.e ?? null;
      if (!chosen) lines.push(line(`<em>Nothing chosen on ${esc(target.name)}: the GM removes it by hand.</em>`));
      else {
        await buttonCard(actor, `${spec.name} — remove`, [`${esc(target.name)}: <strong>${esc(chosen.name)}</strong> is automatically counteracted (equal or lower PP/level). GM: confirm it is a permanent curse or transformation and press the button.`], [{ action: "reforgeRemove", caster: actor.uuid, ref: `${target.uuid}|${chosen.id}`, label: `Remove ${chosen.name}` }], { gm: true });
        lines.push(line(`${esc(target.name)}: <strong>${esc(chosen.name)}</strong> is counteracted — the GM confirms it on their card.`));
      }
    } else if (use === "restore") {
      lines.push(line(`<strong>Restore life</strong> to ${esc(target.name)}, as Resurrection (Q176): dead no longer than 7 days; it returns with 1 HP and 0 PP, injured 2 for a week (which nothing reduces), and its Death State 1 lower; a failed attempt cannot be retried. <em>By hand: TRG Prime applies Resurrection's consequences only from Resurrection's own effect row.</em>`));
    } else if (use === "race") {
      lines.push(line(`<strong>Change ${esc(target.name)}'s race</strong> (Q176): the GM rebuilds the race (ability modifiers, racial abilities and racial feats) as for a new character of that race.`));
    } else lines.push(line("<em>No use chosen: the GM's.</em>"));
    return { lines, ends: true };
  },

  /* Eternal Invocation: the flame, and the 1-mile emanation's aligned benefits. */
  async eternalInvocation(actor, ctx, { rung, spec }) {
    if (rung !== "works") return { lines: [line("<strong>The invocation fails</strong> (no ladder: Success works, failure does not — M45).")], ends: true };
    const castId = castIdOf(actor, ctx);
    const ids = await h().placeLightCircles?.(actor, { name: "Eternal flame", count: 1, radiusFeet: 5, rangeFeet: null, steps: 1, castId }) ?? [];
    const flame = ids[0] ? globalThis.canvas?.scene?.regions?.get?.(ids[0]) : null;
    const centre = flame?.shapes?.[0] ? { x: Number(flame.shapes[0].x), y: Number(flame.shapes[0].y) } : ritualSite(actor);
    const region = await createCircle(actor, `${spec.name}: the eternal flame's reach (1 mile)`, centre, R.ETERNAL_RADIUS_FEET,
      { key: "eternalInvocation", castBound: true, castId, until: null, aligned: R.alignedOf(traitsOf(actor)), members: {} }, { hidden: true });
    if (region) await syncMembers(region);
    const aligned = R.alignedOf(traitsOf(actor));
    return { lines: [
      line(`A 10-foot <strong>eternal flame</strong>${flame ? " (a light on the map)" : " — the GM places its light"}: it never dies and cannot be extinguished. <strong>Permanent until dispelled</strong>: the PP stay locked until it is (Q170).`),
      line(aligned.length
        ? `Within a mile, creatures sharing your aligned trait${aligned.length === 1 ? "" : "s"} (${esc(aligned.join(", "))}): <strong>double</strong> natural HP and PP recovery (H15), <strong>advantage</strong> on crafting and Spellcraft checks (casting checks too, Q177), and advantage on saves against creatures of an opposed aligned trait (a tick on the save). Creatures of an opposed aligned trait: <strong>half</strong> recovery and <strong>disadvantage</strong> on the same three.`
        : `<em>${esc(actor.name)} carries no aligned trait (good, evil, chaos, order, balance): nobody shares or opposes it, so the flame grants nothing beyond heat and light.</em>`),
      line("Applied to every creature within a mile as it is found there (and taken away when it leaves).")
    ] };
  },

  /* Rite of Binding Oath: the oath on its targets; the GM's "Oath broken". */
  async riteOfBindingOath(actor, ctx, { rung, casters, participants = [], spec }) {
    if (R.failingRung(rung)) return { lines: [line("<strong>The ritual collapses.</strong>"), ...await hitCasters(actor, ctx, spec, rung, casters)] };
    const terms = R.oathTerms(rung, ctx.warpMods?.damageDice);
    // THE PARTICIPANTS ARE ITS TARGETS (Q173; found live, 12 November): the
    // casters and the creatures ticked in the ritual dialog, not the creatures
    // targeted. The Oath prints no range, which TRG Prime reads as "self", so a
    // targeted participant refused the cast; the spell asks the core for no
    // creature (targetsObject) and the module takes them from the rite.
    const sworn = [...casters, ...participants].filter((a, i, all) => a && all.indexOf(a) === i).slice(0, R.oathMax(int(ctx.warpMods?.extraTargets)));
    if (!sworn.length) return { lines: [line("<em>Nobody took part: the oath binds nobody.</em>")], ends: true };
    const until = untilOf(terms.duration);
    const rec = { casterUuid: actor.uuid, saveDC: int(ctx.saveDC), formula: terms.formula, double: terms.double, spellName: spec.name };
    if (terms.bound === "half") {
      // "THE GM CHOOSES" (the review): on the GM's client, from a card, not the caster's.
      const keep = Math.floor(sworn.length / 2);
      const id = globalThis.foundry?.utils?.randomID?.() ?? String(Date.now());
      await actor.setFlag(MODULE_ID, "oathPending8b", { id, uuids: sworn.map((a) => a.uuid), keep, terms, until, rec, img: ctx.spell?.img ?? "" });
      await buttonCard(actor, `${spec.name} — Partial`, [`Only half the participants are bound: <strong>${keep}</strong> of ${sworn.map((a) => esc(a.name)).join(", ")}. GM: press the button and choose them.`],
        [{ action: "oathChoose", caster: actor.uuid, ref: id, label: "Choose who is bound" }], { gm: true });
      return { lines: [line(`<strong>Half the participants are bound</strong> (${keep} of ${sworn.length}) for <strong>${esc(terms.duration)}</strong> — the GM chooses them on their card.`)] };
    }
    await swearOath(actor, sworn, { terms, until, rec, img: ctx.spell?.img });
    return { lines: [line(`<strong>${sworn.length}</strong> bound for <strong>${esc(terms.duration)}</strong>${terms.double ? "; oath breakers take double damage" : ""}. Breaking it: ${esc(terms.formula)} essence (basic Fortitude at DC ${rec.saveDC}) and disadvantage on all rolls for 24 hours — the GM's button.`)] };
  },

  /* Rite of Echoed Shadows: a Region; participants' Stealth; an enemy's first entry. */
  async riteOfEchoedShadows(actor, ctx, { rung, castPP, casters, participants, spec }) {
    if (rung === "failure" || rung === "fumble") return { lines: [line(`<strong>One Shadow appears for every ritual caster and attacks</strong>: ${casters.length} Shadow${casters.length === 1 ? "" : "s"} (Fiends & Fables, M54) — the GM places them.`)], ends: true };
    if (rung === "blunder") return { lines: [line(`<strong>A tear opens in the Shadescape</strong>: a powerful entity of level <strong>${R.echoEntityLevel(castPP)}</strong> (the ritual's PP + 4) comes through and attempts to kill the ritual casters — the GM's.`)], ends: true };
    const shape = R.echoShape(rung, ctx.warpMods?.durationText);
    const invisible = R.has(unlocksOf(ctx), R.UNLOCK.echoInvisible);
    const region = await createCircle(actor, `${spec.name}: a distorted echo of reality`, ritualSite(actor), shape.radius,
      { key: "riteOfEchoedShadows", castId: castIdOf(actor, ctx), until: untilOf(shape.duration), penalty: shape.penalty, invisible, side: sideOf(docOf(actor)), participants: [...casters, ...participants].map((a) => a.uuid), entered: [], members: {} });
    if (region) await syncMembers(region);
    return { lines: [
      line(`A ${shape.radius}-ft radius for <strong>${esc(shape.duration)}</strong>. Participants within it: <strong>advantage on Stealth</strong>${invisible ? ", and <strong>invisible</strong> — leaving it costs 4d6 essence (basic Fortitude)" : ""}.`),
      line(`An enemy entering it for the first time: <strong>${shape.penalty} circumstance to attack checks</strong> for 1 minute.`)
    ] };
  },

  /* Sun’s Benediction: up to 6 (20) participants heal, lower a condition, and are blessed. */
  async sunsBenediction(actor, ctx, { rung, casters, participants, spec }) {
    const terms = R.sunTerms(rung, { bought: bonusOf(ctx), unlocks: unlocksOf(ctx) });
    if (!terms.heals) return { lines: [line("<strong>No healing.</strong>"), ...await hitCasters(actor, ctx, spec, rung, casters)], ends: true };
    const site = tokenOf(actor);
    const within = [...casters, ...participants].filter((a, i, all) => all.indexOf(a) === i).filter((a) => { const t = tokenOf(a); return !site || !t || (feetBetween(site, t) ?? 0) <= R.SUN_RADIUS_FEET; });
    const blessed = within.slice(0, terms.max);
    const lines = [line(`<strong>${blessed.length}</strong> participant${blessed.length === 1 ? "" : "s"} within 30 ft of the ritual focus (up to ${terms.max})${within.length > terms.max ? ` — the first ${terms.max} ticked` : ""}.`)];
    for (const who of blessed) {
      const rolled = (await new Roll(terms.formula).evaluate()).total;
      const amount = terms.half ? Math.floor(rolled / 2) : rolled;
      await h().healActor(who, amount);
      lines.push(line(`${esc(who.name)} regains <strong>${amount} HP</strong> (${esc(terms.formula)} = ${rolled}${terms.half ? ", halved" : ""}).`));
      if (terms.reduce) {
        // ITS OWN CHOICE, ON ITS OWNER'S CLIENT (the review): "reduce a condition it has".
        const present = terms.conditions.filter((c) => int(who.getConditionValue?.(c)) > 0);
        if (present.length) {
          const askId = globalThis.foundry?.utils?.randomID?.() ?? `${Date.now()}-${who.id}`;
          await askOwner(who, "sunCondition", { conditions: terms.conditions, by: terms.reduce, label: spec.name, askId });
          lines.push(line(`${esc(who.name)} lowers a condition it has by <strong>${terms.reduce}</strong> — its own choice (its card says which).`));
        }
      }
      if (terms.blessing) {
        await h().createEffectsOn(who, [effectData("sunBlessing8b", { name: `${spec.name}: blessed`, img: ctx.spell?.img, description: `+${R.SUN_FEAR_BONUS} status to saving throws against fear for ${terms.blessing}.`,
          system: { conditionals: [{ kind: "modifier", value: R.SUN_FEAR_BONUS, type: "status", label: spec.name, scope: "saving throws against fear", auto: true, when: { checkTypes: ["save"], traits: ["fear"] } }] },
          expiry: forSeconds(R.spanSeconds(terms.blessing)) })]);
      }
    }
    if (terms.blessing) lines.push(line(`Blessed: <strong>+${R.SUN_FEAR_BONUS} status to saves against fear</strong> for ${esc(terms.blessing)}.`));
    if (terms.half) lines.push(line("<em>Partial: half healing only — no condition is reduced and no blessing is given.</em>"));
    return { lines, ends: true };
  },

  /* Veil Severing: a portal marker for the degree's duration; travel by hand. */
  async veilSevering(actor, ctx, { rung, casters, spec }) {
    if (R.failingRung(rung)) {
      const lines = [line("<strong>The ritual collapses.</strong>"), ...await hitCasters(actor, ctx, spec, rung, casters)];
      if (rung === "blunder") lines.push(line("<strong>A hostile planar entity (at least EL 18) comes through</strong> before the portal closes — the GM's."));
      return { lines, ends: true };
    }
    const duration = R.veilDuration(rung, unlocksOf(ctx));
    const region = await createCircle(actor, `${spec.name}: a two-way portal`, ritualSite(actor), R.VEIL_RADIUS_FEET, { key: "veilSevering", castId: castIdOf(actor, ctx), until: untilOf(duration) });
    return { lines: [
      line(`A two-way portal to another plane or a known Luminex within 500 miles, for <strong>${esc(duration)}</strong>${region ? " (marked on the map)" : ""}.`),
      line(`It lets through any creature of up to ${R.has(unlocksOf(ctx), R.UNLOCK.veilLarger) ? "a larger size (the +2 PP option: the GM sets how large)" : "Large size"}. Where it leads and who steps through are the table's.`)
    ] };
  }
};

/** The oath on its sworn, and the GM's "Oath broken" card. */
async function swearOath(caster, sworn, { terms, until, rec, img }) {
  for (const who of sworn) {
    await h().createEffectsOn(who, [effectData("oath8b", { name: `${rec.spellName}: sworn`, img,
      description: `Bound by the oath for ${terms.duration}. Breaking it: ${terms.formula} essence${terms.double ? ", doubled" : ""} (basic Fortitude, DC ${rec.saveDC}) and disadvantage on all rolls for 24 hours.`,
      module: { oath8b: rec }, expiry: until ? forSeconds(until - worldNow()) : null })]);
  }
  return buttonCard(caster, `${rec.spellName} — the oath`, [`Sworn for <strong>${esc(terms.duration)}</strong>: ${sworn.map((a) => esc(a.name)).join(", ") || "nobody"}. The oath's words are the table's. GM: when one breaks it, press their button.`],
    sworn.map((a) => ({ action: "oathBroken", caster: caster.uuid, ref: a.uuid, label: `Oath broken: ${a.name}` })), { gm: true });
}

/* ================================================================== */
/* Memberships: who is inside an 8b Region, and what that gives         */
/* ================================================================== */

const membershipKeys = ["concordOfStone", "elementalConvergence", "riteOfEchoedShadows", "eternalInvocation", "leylineAnchor"];
const memberEffect = (actor, regionId) => effects(actor).find((e) => e.flags?.[MODULE_ID]?.[R.AURA8B_FLAG] === regionId) ?? null;
/** Where a Region's record is centred now: its following token's end, else its point. */
function centreOf(region, moved = null) {
  const rec = areaRecordOf(region);
  if (rec?.followTokenId) {
    const doc = moved && moved.doc && moved.doc.id === rec.followTokenId ? moved.at : region.parent?.tokens?.get?.(rec.followTokenId) ?? Array.from(region.parent?.tokens ?? []).find((t) => t.id === rec.followTokenId) ?? null;
    if (doc) return docCentre(doc);
  }
  return rec?.centre ?? null;
}

const memberEffects = (actor, regionId) => effects(actor).filter((e) => e.flags?.[MODULE_ID]?.[R.AURA8B_FLAG] === regionId);
/**
 * Bring one Region's members up to date (the acting GM). ONE AT A TIME PER
 * REGION (the review): the cast's own sync, the Region's creation hook and a
 * token's move may overlap, and two syncs at once would each create the effect.
 */
const syncChains = new Map();
export function syncMembers(region, moved = null) {
  const id = region?.uuid ?? region?.id ?? "";
  const next = (syncChains.get(id) ?? Promise.resolve()).catch(() => 0).then(() => syncMembersNow(region, moved));
  syncChains.set(id, next);
  next.catch(() => 0).finally(() => { if (syncChains.get(id) === next) syncChains.delete(id); });
  return next;
}
async function syncMembersNow(region, moved = null) {
  const rec = areaRecordOf(region);
  if (!rec || !membershipKeys.includes(rec.key)) return 0;
  if (!isActingGM() && !(region?.isOwner && !globalThis.game?.users?.activeGM)) return 0;
  const centre = centreOf(region, moved);
  if (!centre) return 0;
  const caster = actorOf(await resolve(rec.casterUuid));
  let changed = 0;
  for (const doc of tokens(region.parent)) {
    const at = moved && moved.doc && moved.doc.id === doc.id ? moved.at : doc;
    const feet = feetFromPointDoc(centre, at);
    const inside = feet !== null && feet <= Number(rec.radius);
    const actor = doc.actor;
    if (rec.key === "elementalConvergence") { changed += await convergenceMember(actor, region, rec, inside); continue; }
    const fx = memberEffect(actor, region.id);
    const wanted = inside ? await memberGrant(rec, actor, doc, caster, region) : null;
    if (wanted && !memberEffect(actor, region.id)) { await actor.createEmbeddedDocuments("ActiveEffect", [wanted]); changed += 1; }
    else if (wanted && fx?.disabled) { await fx.update({ disabled: false }); changed += 1; }
    else if (!wanted && fx && !fx.disabled) {
      await fx.delete();
      changed += 1;
      if (rec.key === "riteOfEchoedShadows" && rec.invisible && rec.participants?.includes(actor.uuid)) await echoLeft(actor, caster, region);
    }
    if (inside && rec.key === "riteOfEchoedShadows" && !rec.entered?.includes(actor.uuid) && enemiesBySide(rec.side, sideOf(doc))) await echoFirstEntry(actor, region);
  }
  return changed;
}

/**
 * Elemental Convergence's member (the review): two effects, its resistance and
 * its strike rider, the rider one it "can choose" to switch off. Leaving the
 * zone switches off only what is on, marked `zoneOff`; coming back switches on
 * only what the zone switched off, so a rider its owner turned off stays off.
 */
const ASK_HOLD_MS = 60000;
const asked = new Set();
async function convergenceMember(actor, region, rec, inside) {
  const fxs = memberEffects(actor, region.id);
  const k = `${region.id}:${actor.uuid}`;
  if (!inside) {
    const on = fxs.filter((e) => !e.disabled);
    for (const e of on) await e.update({ disabled: true, [`flags.${MODULE_ID}.zoneOff`]: true });
    return on.length;
  }
  if (!fxs.length) {
    // ASKED ONCE, until it answers (or a minute passes): a move meanwhile does not ask again.
    if (asked.has(k)) return 0;
    asked.add(k);
    const free = () => { const t = setTimeout(() => asked.delete(k), ASK_HOLD_MS); t?.unref?.(); };
    askOwner(actor, "convergenceElement", { regionUuid: region.uuid, dice: rec.dice }).catch((err) => console.warn("Eldritch Arts | Elemental Convergence: the element", err)).finally(free);
    return 0;
  }
  asked.delete(k);
  const off = fxs.filter((e) => e.disabled && e.flags?.[MODULE_ID]?.zoneOff);
  for (const e of off) await e.update({ disabled: false, [`flags.${MODULE_ID}.zoneOff`]: false });
  return off.length;
}

/** The effect a member should have, or null for none. */
async function memberGrant(rec, actor, doc, caster, region) {
  const base = (name, data) => {
    const d = effectData("member8b", { name, img: "icons/svg/aura.svg", description: `${name} — while within ${region.name}.`, ...data });
    d.flags[MODULE_ID][R.AURA8B_FLAG] = region.id;
    return d;
  };
  switch (rec.key) {
    case "concordOfStone": {
      // "Allies defending within the zone": the caster's side (and the caster).
      const ally = actor === caster || (int(rec.side) !== 0 && sideOf(doc) === int(rec.side));
      return ally ? base(`Concord of Stone: +${R.CONCORD_DB} DB`, { changes: [{ key: "system.combat.defence.circumstance", type: "custom", value: String(R.CONCORD_DB), priority: 20 }] }) : null;
    }
    case "riteOfEchoedShadows": {
      if (!rec.participants?.includes(actor.uuid)) return null;
      return base("Rite of Echoed Shadows: in the echo", { statuses: rec.invisible ? ["invisible"] : [],
        system: { conditionals: [{ kind: "advantage", label: "Rite of Echoed Shadows", scope: "Stealth checks within the area", auto: true, when: { checkTypes: ["skill"], subjects: ["stealth"] } }] } });
    }
    case "leylineAnchor": {
      // "All casters within 300 ft of the caster" — a creature with a caster level.
      if (casterLevelOf(actor) <= 0) return null;
      return base(`Leyline Anchor: +${R.ANCHOR_BONUS} Spellcraft and Power Recovery`, { system: { conditionals: [
        { kind: "modifier", value: R.ANCHOR_BONUS, type: "circumstance", label: "Leyline Anchor", scope: "Spellcraft checks", auto: true, when: { checkTypes: ["spellcraft"] } },
        { kind: "modifier", value: R.ANCHOR_BONUS, type: "circumstance", label: "Leyline Anchor", scope: "Power Recovery (Meditation) checks", auto: true, when: { actions: ["powerRecovery"] } }
      ] } });
    }
    case "eternalInvocation": {
      const relation = R.alignedRelation(rec.aligned ?? [], traitsOf(actor));
      if (relation === "none") return null;
      const sign = relation === "shared" ? "advantage" : "disadvantage";
      const rate = relation === "shared" ? 2 : 0.5;
      return base(`Eternal Invocation: ${relation === "shared" ? "blessed" : "opposed"}`, { system: {
        restRate: { hp: rate, pp: rate, label: "Eternal Invocation" },
        conditionals: [
          { kind: sign, label: "Eternal Invocation", scope: "crafting checks", auto: true, when: { checkTypes: ["skill"], subjects: ["crafting"] } },
          { kind: sign, label: "Eternal Invocation", scope: "Spellcraft checks, casting checks included (Q177)", auto: true, when: { checkTypes: ["spellcraft"] } },
          { kind: sign, label: "Eternal Invocation", scope: "a saving throw against a creature with an aligned trait opposed to yours — tick it", auto: false, when: { checkTypes: ["save"] } }
        ] } });
    }
    default: return null;
  }
}

async function echoFirstEntry(actor, region) {
  const rec = areaRecordOf(region);
  await region.setFlag(MODULE_ID, R.AREA8B_FLAG, { ...rec, entered: [...(rec.entered ?? []), actor.uuid] });
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData("echoPenalty8b", { name: `Rite of Echoed Shadows: ${rec.penalty} to attacks`, img: "icons/svg/aura.svg",
    description: `Entered the echo for the first time: ${rec.penalty} circumstance to attack checks for 1 minute.`,
    system: { conditionals: [{ kind: "modifier", value: rec.penalty, type: "circumstance", label: "Rite of Echoed Shadows", scope: "attack checks", auto: true, when: { checkTypes: ["attack"] } }] }, expiry: forSeconds(R.ECHO_PENALTY_SECONDS) })]);
}
async function echoLeft(actor, caster, region) {
  const res = await h().basicSaveHit({ caster: caster ?? actor, target: actor, save: "fortitude", dc: ownLevelDC(actor), label: "Rite of Echoed Shadows: leaving the zone", formula: R.ECHO_LEAVE_DAMAGE, type: "essence" });
  await card(actor, "Rite of Echoed Shadows", [res?.line ?? line(`${esc(actor.name)} leaves the zone: ${R.ECHO_LEAVE_DAMAGE} essence, basic Fortitude.`)]);
  void region;
}

/** Ask a creature's owner (or, with none connected, the GM) to choose something only it should. */
async function askOwner(actor, task, data = {}) {
  if (answersFor(actor)) return OWNER_TASKS[task]?.(actor, data);
  globalThis.game?.socket?.emit?.(SOCKET, { action: ACTION_8B, kind: "owner", actorUuid: actor.uuid, task, data });
  return null;
}
const OWNER_TASKS = {
  /* Elemental Convergence: the creature's element, and its effect (resistance and a strike rider). */
  async convergenceElement(actor, { regionUuid, dice }) {
    const region = await resolve(regionUuid);
    if (!region || memberEffects(actor, region.id).length) return;
    const element = await chooseElement(actor, `Elemental Convergence — ${actor.name}'s element`);
    if (!element) return;
    // ANSWERED ALREADY (another tab of the GM's account, or a second ask): the first stands.
    if (memberEffects(actor, region.id).length) return;
    const img = "icons/magic/fire/projectile-fireball-embers-yellow.webp";
    const resist = effectData("member8b", { name: `Elemental Convergence: resistance to ${element}`, img,
      description: `Resistance to ${element}, while within the zone.`,
      changes: [{ key: "system.combat.resistances", type: "add", value: `, ${element}`, priority: 20 }] });
    const rider = effectData("member8b", { name: `Elemental Convergence: ${dice} ${element} on Strikes`, img,
      description: `Your weapon and unarmed Strikes deal ${dice} secondary ${element} damage while within the zone. You can choose not to: switch this effect off.`,
      system: { strikeRider: { label: `Elemental Convergence (${element})`, dice, damageType: element, scope: "any", once: false } } });
    for (const [d, part] of [[resist, "resistance"], [rider, "rider"]]) { d.flags[MODULE_ID][R.AURA8B_FLAG] = region.id; d.flags[MODULE_ID].element = element; d.flags[MODULE_ID].part = part; }
    await actor.createEmbeddedDocuments("ActiveEffect", [resist, rider]);
  },

  /* Sun's Benediction: the creature lowers a condition it has (its own choice). */
  async sunCondition(actor, { conditions = [], by = 1, label = "Sun’s Benediction", askId = "" } = {}) {
    const allowed = [...R.SUN_CONDITIONS, "injured"];
    const list = Array.from(conditions).map(String).filter((c) => allowed.includes(c));
    const n = Math.max(1, Math.min(10, int(by)));
    const present = list.filter((c) => int(actor.getConditionValue?.(c)) > 0);
    if (!present.length) return null;
    const pick = present.length === 1 ? present[0] : await h().chooseFromList(label, `${actor.name}: lower which condition by ${n}?`, present.map((c) => [c, c]));
    if (!pick || !present.includes(pick)) return null;
    // ONCE (another tab answered): the ask's id is kept on the creature.
    if (askId && actor.getFlag?.(MODULE_ID, "sunAsked8b") === askId) return null;
    if (askId) await actor.setFlag(MODULE_ID, "sunAsked8b", askId);
    const out = await h().reduceCondition?.(actor, pick, n);
    return card(actor, label, [line(out?.held ? `${esc(actor.name)}: ${esc(pick)} is held by a curse and does not lower.` : `${esc(actor.name)}: <strong>${esc(pick)} ${int(out?.from)} → ${int(out?.to)}</strong>.`)]);
  }
};

/* ================================================================== */
/* The GM's buttons                                                      */
/* ================================================================== */

/** Army of the Grave: the selected undead, counted and controlled. */
export async function raiseUndead(caster, recordId, { selected = null } = {}) {
  const rec = caster.getFlag?.(MODULE_ID, "army8b");
  if (!rec || rec.id !== recordId) return warn("Eldritch Arts: this army has already been raised.");
  const picked = selected ?? Array.from(globalThis.canvas?.tokens?.controlled ?? []);
  const undead = picked.filter((t) => traitsOf(t.actor).includes("undead"));
  if (undead.length !== picked.length) return warn("Eldritch Arts: select only undead (a creature with the undead trait).");
  const casterTok = tokenOf(caster);
  const far = undead.filter((t) => casterTok && (feetBetween(casterTok, t) ?? 0) > 300);
  if (far.length) return warn(`Eldritch Arts: ${far.map((t) => t.name).join(", ")} ${far.length === 1 ? "is" : "are"} beyond the 300-ft radius.`);
  const fits = R.armyFits({ levels: undead.map((t) => levelOf(t.actor)), castPP: rec.castPP, halfLevels: rec.half });
  if (!fits.ok) return warn(`Eldritch Arts: ${fits.reason}.`);
  await caster.unsetFlag(MODULE_ID, "army8b");
  let controlled = undead;
  if (rec.rung === "partial") {
    const keep = R.armyControlled(undead.length, "partial");
    const ids = await pickMany("Army of the Grave — Partial", `Half rise under control (the GM picks ${keep}); the rest are uncontrolled.`, undead.map((t) => ({ id: t.id, label: t.name })), { max: keep, checked: false });
    controlled = undead.filter((t) => (ids ?? []).includes(t.id)).slice(0, keep);
  }
  const until = untilOf(rec.duration);
  const lines = [];
  for (const t of undead) {
    if (!controlled.includes(t)) { await t.document?.update?.({ disposition: -1 }); lines.push(line(`${esc(t.name)}: <strong>uncontrolled</strong> (hostile).`)); continue; }
    // ITS FULL LEVEL (the review): the +4 PP option halves only the count against the PP.
    const level = levelOf(t.actor);
    const entry = await h().recordControlled?.(caster, { target: t.actor, token: t, level, source: "undead", castId: rec.castId, data: { module: MODULE_ID, key: "armyOfTheGrave" } });
    await h().createEffectsOn(t.actor, [effectData("armyRaised8b", { name: `Army of the Grave: raised by ${caster.name}`, img: "icons/magic/death/skull-horned-goat-pentagram-red.webp",
      description: `Under ${caster.name}'s control for ${rec.duration} (Control Levels apply). Commanded, with the rest, by one 1 AP command (auditory, concentrate).`,
      module: { armyRaised8b: { casterUuid: caster.uuid, entryId: entry?.id ?? "" } }, expiry: until ? forSeconds(until - worldNow()) : null })]);
    lines.push(line(`${esc(t.name)}: <strong>under control</strong>${entry ? "" : " (not recorded: the core's control register refused it — see its card)"}.`));
  }
  if (rec.permanent) {
    const site = tokenOf(caster);
    if (site) await createCircle(caster, "Army of the Grave: Evil aligned, tainted by the Shadescape", { x: site.center.x, y: site.center.y }, 300, { key: "armySite", castId: rec.castId, until: null });
  }
  return card(caster, "Army of the Grave — the undead", [line(`${undead.length} undead, their levels counting ${fits.total} of ${rec.castPP}.`), ...lines]);
}

/** Essence Reforging's removal, on the GM's word. */
export async function reforgeRemove(caster, ref) {
  const [uuid, id] = String(ref).split("|");
  const target = actorOf(await resolve(uuid));
  const fx = effects(target).find((e) => e.id === id) ?? null;
  if (!fx) return warn("Eldritch Arts: that effect is already gone.");
  const name = fx.name;
  await fx.delete();
  return card(caster, "Essence Reforging", [line(`${esc(target.name)}: <strong>${esc(name)}</strong> is removed.`)]);
}

/** Rite of Binding Oath's Partial: the GM chooses the half that is bound. */
export async function oathChoose(caster, ref) {
  const rec = caster.getFlag?.(MODULE_ID, "oathPending8b");
  if (!rec || rec.id !== ref) return warn("Eldritch Arts: this oath's sworn have already been chosen.");
  const who = (await actorsOf(rec.uuids)).filter(Boolean);
  const ids = await pickMany(`${rec.rec?.spellName ?? "Rite of Binding Oath"} — Partial`, `Only half the participants are bound: choose ${rec.keep}.`, who.map((a) => ({ id: a.id, label: a.name })), { max: rec.keep, checked: false });
  if (ids === null) return null;
  await caster.unsetFlag(MODULE_ID, "oathPending8b");
  const sworn = who.filter((a) => ids.includes(a.id)).slice(0, rec.keep);
  return swearOath(caster, sworn, { terms: rec.terms, until: rec.until, rec: rec.rec, img: rec.img });
}

/** Rite of Binding Oath: the GM's "Oath broken". */
export async function oathBroken(caster, ref) {
  const who = actorOf(await resolve(ref));
  const fx = effects(who).find((e) => sourceOf(e) === "oath8b" && e.flags?.[MODULE_ID]?.oath8b?.casterUuid === caster.uuid) ?? null;
  if (!fx) return warn("Eldritch Arts: that creature is not bound by this oath (it ended, or was broken).");
  const rec = fx.flags[MODULE_ID].oath8b;
  const rolled = (await new Roll(rec.formula).evaluate()).total;
  const amount = rec.double ? rolled * 2 : rolled;
  const res = await h().basicSaveHit({ caster, target: who, save: "fortitude", dc: int(rec.saveDC), label: `${rec.spellName}: the oath broken`, amount, type: "essence" });
  await h().createEffectsOn(who, [effectData("oathBreaker8b", { name: `${rec.spellName}: oath breaker`, img: "icons/svg/downgrade.svg", description: "Disadvantage on all rolls for 24 hours.",
    system: { conditionals: [{ kind: "disadvantage", label: "Oath broken", scope: "all rolls", auto: true, always: true }] }, expiry: forSeconds(R.OATH_DISADVANTAGE_SECONDS) })]);
  await fx.delete();
  return card(caster, `${rec.spellName} — the oath broken`, [line(`${esc(who.name)} breaks the oath: ${esc(rec.formula)} = ${rolled}${rec.double ? `, doubled to ${amount}` : ""} essence.`), res?.line ?? "", line("Disadvantage on all rolls for 24 hours.")].filter(Boolean));
}

export const BUTTONS_8B = Object.freeze({
  raiseUndead: { gm: true, run: (c, ref) => raiseUndead(c, ref) },
  reforgeRemove: { gm: true, run: (c, ref) => reforgeRemove(c, ref) },
  oathBroken: { gm: true, run: (c, ref) => oathBroken(c, ref) },
  oathChoose: { gm: true, run: (c, ref) => oathChoose(c, ref) },
  veilfracturePull: { gm: true, run: (c, ref) => veilfracturePull(c, ref) }
});
export async function onCardButton8b(action, casterUuid, ref, user = globalThis.game?.user) {
  const spec = BUTTONS_8B[action];
  if (!spec) return false;
  if (spec.gm && !user?.isGM) return warn("Eldritch Arts: only the GM presses that.");
  if (spec.gm && !isActiveGMAccount()) return warn("Eldritch Arts: another GM is the acting GM; that GM presses it.");
  const caster = actorOf(await resolve(casterUuid));
  if (!caster) return warn("Eldritch Arts: the caster is gone.");
  return spec.run(caster, ref);
}
export function registerBlock8bCards() {
  globalThis.Hooks?.on?.("renderChatMessageHTML", (message, html) => {
    for (const button of html?.querySelectorAll?.("[data-ea8b]") ?? []) {
      button.addEventListener("click", (event) => {
        event.preventDefault();
        onCardButton8b(button.dataset.ea8b, button.dataset.ea8bCaster, button.dataset.ea8bRef).catch((err) => console.warn("Eldritch Arts | Block 8b card", err));
      });
    }
  });
}

/* ================================================================== */
/* High Magic (§4.4)                                                    */
/* ================================================================== */

/* ----------------------------- Chaos Shield ---------------------- */

const shieldMarkers = (actor) => effects(actor).filter((e) => sourceOf(e) === R.CHAOS_SHIELD_FLAG && !e.disabled);
async function chaosShield(actor, ctx) {
  const radius = R.chaosRadius(ctx.warpMods?.areaOverride);
  const castId = castIdOf(actor, ctx);
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData(R.CHAOS_SHIELD_FLAG, { name: `Chaos Shield (${radius} ft)`, img: ctx.spell?.img,
    description: `A ${radius}-foot aura against wild magic, while you sustain it.`, system: castId ? { castId } : {}, module: { [R.CHAOS_SHIELD_FLAG]: { radius, castId } } })]);
  return card(actor, ctx.spell?.name, [line(`A <strong>${radius}-foot</strong> aura while you sustain it. Within it, a wild surge: you may spend <strong>${R.CHAOS_NULLIFY_PP} PP</strong> as a reaction to nullify it (once per round); else an ally (you too) rolls the table twice and picks, its damage halved for allies inside, and its saves' DCs <strong>${R.CHAOS_DC_STEP}</strong> (Q178).`), line("<em>\"Hostile spell warp effects\" name no rule (Q178): nothing more is built for them.</em>")]);
}

/**
 * Is a surge by this creature within a Chaos Shield? The nearest shield whose
 * aura holds its token: its caster, whether the surger is on its side, and the
 * allies inside (for the halved damage). Null when none.
 */
export async function chaosShieldFor(actor) {
  const mine = tokenOf(actor);
  if (!mine) return null;
  for (const t of globalThis.canvas?.tokens?.placeables ?? []) {
    const caster = t.actor;
    const marker = shieldMarkers(caster)[0];
    if (!marker) continue;
    const rec = marker.flags[MODULE_ID][R.CHAOS_SHIELD_FLAG];
    if (rec.castId && !Array.from(caster.getFlag?.(SYSTEM_ID, "activeSpells") ?? []).some((e) => e?.id === rec.castId)) continue;
    const feet = feetBetween(t, mine);
    if (feet === null || feet > Number(rec.radius)) continue;
    const side = sideOf(t.document);
    const members = new Set();
    for (const o of globalThis.canvas?.tokens?.placeables ?? []) {
      if (!o.actor) continue;
      const f = feetBetween(t, o);
      if (f !== null && f <= Number(rec.radius) && (o.actor === caster || (side !== 0 && sideOf(o.document) === side))) members.add(o.actor.uuid);
    }
    return { caster, marker, radius: Number(rec.radius), ally: members.has(actor.uuid), members };
  }
  return null;
}

export const NULLIFY_STEP = "eldritchArts.chaosShieldNullify";
/** The shield's caster: nullify it (2 PP, a reaction), once per round. */
async function nullifyStep(actor, answer, data = {}) {
  if (answer !== "yes") return { nullified: false };
  const marker = shieldMarkers(actor)[0];
  if (!marker) return { nullified: false };
  const used = marker.flags[MODULE_ID][R.CHAOS_SHIELD_FLAG]?.used ?? null;
  const combat = globalThis.game?.combat;
  const stamp = combat?.started ? { combatId: combat.id, round: int(combat.round) } : { at: worldNow() };
  if (used && ((used.combatId && used.combatId === stamp.combatId && used.round === stamp.round) || (!used.combatId && !stamp.combatId && worldNow() - int(used.at) < R.SPAN.round))) {
    warn("Chaos Shield: already used to nullify a surge this round.");
    return { nullified: false };
  }
  if (ppOf(actor) < R.CHAOS_NULLIFY_PP) { warn(`Chaos Shield: ${R.CHAOS_NULLIFY_PP} PP required.`); return { nullified: false }; }
  if (!(await h().spendReaction?.(actor, "Chaos Shield", { traits: "" }))) return { nullified: false };
  await actor.update({ "system.resources.pp.value": ppOf(actor) - R.CHAOS_NULLIFY_PP });
  await marker.setFlag(MODULE_ID, R.CHAOS_SHIELD_FLAG, { ...marker.flags[MODULE_ID][R.CHAOS_SHIELD_FLAG], used: stamp });
  void data;
  return { nullified: true };
}

/**
 * THE SURGE, SHIELDED (block2 `rollTable` asks it for the Wild Surge table):
 * nullified by the shield's caster, or rolled twice and picked by the surger,
 * with what the rows then do to creatures in the aura.
 * @returns {Promise<{nullified: boolean, forcedTotal: number, shield: object|null, lines: string[]}>}
 */
export async function shieldSurge(actor, { title, forcedTotal = 0, cancels = false } = {}) {
  const found = await chaosShieldFor(actor);
  if (!found) return { nullified: false, forcedTotal, shield: null, lines: [] };
  const q = await h().askReactor?.(found.caster, {
    title: `Chaos Shield — ${found.caster.name}`,
    content: `<p>A wild surge (${esc(title)}) would occur within your Chaos Shield, by <strong>${esc(actor.name)}</strong>.</p><p>Spend <strong>${R.CHAOS_NULLIFY_PP} PP</strong> as a reaction to nullify it entirely? (Once per round.)</p>`,
    buttons: [{ action: "yes", label: "Nullify it" }, { action: "no", label: "No" }],
    step: NULLIFY_STEP, data: { actorUuid: actor.uuid }
  });
  if (q?.result?.nullified) return { nullified: true, forcedTotal, shield: null, lines: [line(`<strong>${esc(found.caster.name)}'s Chaos Shield nullifies the surge</strong> (${R.CHAOS_NULLIFY_PP} PP, a reaction).`)] };
  const shield = { members: found.members, dcStep: R.CHAOS_DC_STEP, name: found.caster.name };
  const lines = [];
  let total = forcedTotal;
  if (found.ally && !total && !cancels) {
    const a = (await new Roll("1d100").evaluate()).total;
    const b = (await new Roll("1d100").evaluate()).total;
    const pick = await h().chooseFromList(title, `Chaos Shield: roll twice and take the preferred result (${actor.name} chooses).`, [[String(a), `d100 ${a}`], [String(b), `d100 ${b}`]]);
    total = int(pick ?? a) || a;
    lines.push(line(`Chaos Shield: <strong>${a}</strong> and <strong>${b}</strong> rolled; ${esc(actor.name)} takes <strong>${total}</strong>.`));
  }
  if (found.ally && cancels) lines.push(line("Chaos Shield: the area's disadvantage and the shield's two rolls cancel each other out (one roll, as for any check)."));
  lines.push(line(`Within ${esc(found.caster.name)}'s Chaos Shield: this surge's saves are at DC ${R.CHAOS_DC_STEP}, and its damage to allies inside is halved (Q178).`));
  return { nullified: false, forcedTotal: total, shield, lines };
}

/* ----------------------------- Leyline Anchor -------------------- */

async function leylineAnchor(actor, ctx) {
  const me = tokenOf(actor);
  if (!me) return card(actor, ctx.spell?.name, [line("<em>Place your token on the map: the ley line is chosen from it.</em>")]);
  const { leyLinesWithin } = await import("./areas.mjs");
  const lines = await leyLinesWithin(me, R.ANCHOR_RANGE_FEET);
  if (!lines.length) return card(actor, ctx.spell?.name, [line("<em>No ley line within 1 mile on this scene: the anchor is the GM's.</em>")]);
  const pick = lines.length === 1 ? "0" : await h().chooseFromList(ctx.spell?.name, "Which ley line, that you are aware of?", lines.map((l, i) => [String(i), `${l.name || "Ley line"} — level ${l.level}, ${l.feet} ft`]));
  const chosen = lines[int(pick)] ?? null;
  if (!chosen) return card(actor, ctx.spell?.name, [line("<em>No ley line chosen.</em>")]);
  const duration = durationTextOf(ctx) || "10 minutes";
  const castId = castIdOf(actor, ctx);
  const region = await createCircle(actor, `Leyline Anchor: ${actor.name}'s 300 ft`, { x: me.center.x, y: me.center.y }, R.ANCHOR_RADIUS_FEET,
    { key: "leylineAnchor", castBound: true, castId, until: untilOf(duration), anchored: chosen.region.id, saveDC: int(ctx.saveDC), followTokenId: me.document.id, members: {} }, { hidden: true });
  if (region) await syncMembers(region);
  return card(actor, ctx.spell?.name, [
    line(`<strong>${esc(chosen.name || "The ley line")}</strong> (level ${chosen.level}) is anchored for <strong>${esc(duration)}</strong>; "fixed in its current state" — Block 2's ley lines have only a level, which stands.`),
    line(`Casters within 300 ft of you: <strong>+${R.ANCHOR_BONUS} circumstance</strong> to Power Recovery (Meditation) and Spellcraft checks. High Magic spells cast there pay <strong>1 PP less</strong> (minimum 1; the DC, cap and save DC read the PP as cast — Q179).`),
    line(`Another caster's Tap or Channel Ley Line on it first rolls Power Manipulation against DC <strong>${int(ctx.saveDC) + R.ANCHOR_TAP_STEP}</strong> (your Save DC + 5); a failure stops the attempt and spends its action.`)
  ]);
}
const anchorRegions = (scene = globalThis.canvas?.scene) => areas8b("leylineAnchor", scene);
/** Is this creature's token within an anchor's 300 ft? */
function insideAnchor(actor) {
  const me = tokenOf(actor);
  if (!me) return null;
  for (const region of anchorRegions()) {
    const c = centreOf(region);
    const feet = c ? feetFromPointDoc(c, me.document) : null;
    if (feet !== null && feet <= R.ANCHOR_RADIUS_FEET) return region;
  }
  return null;
}
/** registerCastCostModifier: a High Magic spell cast within an anchor's radius pays 1 PP less (Q179). */
export async function anchorCostCut(ctx = {}) {
  if (!ctx.highMagic && !hasTrait(ctx.spellData, "highmagic")) return null;
  const region = insideAnchor(ctx.actor);
  const delta = R.anchorDiscount({ highMagic: true, inside: Boolean(region), totalPP: ctx.totalPP });
  return delta ? { ppDelta: delta, floor: 1, label: "Leyline Anchor", lines: ["Leyline Anchor: this High Magic spell is treated as 1 PP lower (payment only, Q179)."] } : null;
}
/** Block 2's Tap and Channel Ley Line: another caster's check against the anchor first (M45, Q179). */
export async function anchorTapGate(actor, lineRegionId, actionName, apCost = 0) {
  const region = Array.from(allScenes()).flatMap((sc) => areas8b("leylineAnchor", sc)).find((r) => areaRecordOf(r)?.anchored === lineRegionId) ?? null;
  const rec = areaRecordOf(region);
  if (!rec || rec.casterUuid === actor?.uuid) return null;
  const dc = int(rec.saveDC) + R.ANCHOR_TAP_STEP;
  const check = await h().rollCheck({ actor, type: "skill", subject: "powerManipulation", label: `${actionName} — against the Leyline Anchor`, subtitle: `DC ${dc} (the anchoring caster's Save DC + 5)`, dc });
  if (succeeded(check)) return null;
  if (apCost) await spendAP(actor, actionName, apCost);
  return { refused: `the ley line is anchored, and your Power Manipulation check (${int(check?.outcome?.total)} against DC ${dc}) fails: the attempt stops${apCost ? `, and its ${apCost} AP are spent` : ""}.` };
}

/* ----------------------------- Mimic Spell ----------------------- */

const mimicSpellOf = (actor) => Array.from(actor?.items ?? []).find((i) => i.type === "spell" && keyOf(i) === "mimicSpell") ?? null;
export const MIMIC_STEP = "eldritchArts.mimicSpell";
/** registerCastReaction: offered to each creature that knows Mimic Spell, sees the caster within 60 ft, and has 8 PP. Never stops the cast. */
export async function mimicReaction(ctx = {}) {
  const caster = ctx.actor;
  const casterTok = ctx.token ?? tokenOf(caster);
  if (!caster || !casterTok || !ctx.spell) return null;
  if (ctx.spell.flags?.[MODULE_ID]?.[R.MIMIC_FLAG]) return null;
  const castPP = int(ctx.castPP ?? ctx.pp);
  for (const t of globalThis.canvas?.tokens?.placeables ?? []) {
    const reactor = t.actor;
    if (!reactor || reactor === caster || !mimicSpellOf(reactor)) continue;
    const feet = feetBetween(t, casterTok);
    if (feet === null || feet > R.MIMIC_RANGE_FEET || sightBlocked(t.center, casterTok.center)) continue;
    if (ppOf(reactor) < R.MIMIC_PP) continue;
    // NOT OFFERED WHEN IT COULD NEVER IMPRINT (found live): a Ritual spell (Q8)
    // or one cast above this reactor's maximum PP per cast (M48). The refusal
    // came only after the reactor had paid its PP and its reaction.
    if (hasTrait(ctx.spell.system ?? {}, "ritual") || !R.mimicAllowed(castPP, casterLevelOf(reactor))) continue;
    if (await h().reactionRefusal?.(reactor, "")) continue;
    await h().askReactor?.(reactor, {
      title: `Mimic Spell — ${reactor.name}`,
      content: `<p><strong>${esc(caster.name)}</strong> begins casting <strong>${esc(ctx.spell.name)}</strong> (${castPP} PP), within 60 feet.</p><p>Cast <strong>Mimic Spell</strong> as your reaction (${R.MIMIC_PP} PP; +${R.MIMIC_HOLD_PP} PP to hold it longer)? Spellcraft against its casting DC (${R.mimicDC(castPP)}).</p>`,
      buttons: [{ action: "yes", label: "Mimic it" }, { action: "hold", label: `Mimic it, held longer (+${R.MIMIC_HOLD_PP} PP)` }, { action: "no", label: "No" }],
      step: MIMIC_STEP,
      data: { spellUuid: ctx.spell.uuid ?? "", spellName: ctx.spell.name, castPP, casterName: caster.name, casterUuid: caster.uuid }
    });
  }
  return null;
}

/** The reactor's client: pay, roll, imprint. */
export async function mimicStep(actor, answer, data = {}) {
  if (answer !== "yes" && answer !== "hold") return { rolled: false };
  const mimic = mimicSpellOf(actor);
  const hold = answer === "hold";
  const total = R.MIMIC_PP + (hold ? R.MIMIC_HOLD_PP : 0);
  if (!mimic || ppOf(actor) < total) { warn(`Mimic Spell: ${total} PP required.`); return { rolled: false }; }
  if (!(await h().spendReaction?.(actor, "Mimic Spell", { traits: "verbal" }))) return { rolled: false };
  const castPP = int(data.castPP);
  const dc = R.mimicDC(castPP);
  // THE SHEET'S SPELLCRAFT (found live: the check rolled +0). TRG Prime's
  // rollCheck fills a save's or a skill's modifiers, not Spellcraft's.
  const check = await h().rollCheck({ actor, type: "spellcraft", label: `Mimic Spell — ${data.spellName}`, subtitle: `Spellcraft against its casting DC ${dc}`, dc, traits: "HighMagic, Utility", modifiers: spellcraftModifiers(actor) });
  const degree = String(check?.outcome?.degree?.key ?? "failure");
  // WHAT THE CASTING SPENDS, by its degree (the core's casting outcome: Critical
  // halves the base, Failure loses half, Fumble all, Partial none).
  const spent = { heroic: Math.ceil(total / 2), critical: Math.ceil(R.MIMIC_PP / 2) + (hold ? R.MIMIC_HOLD_PP : 0), success: total, partial: 0, failure: Math.floor(total / 2), fumble: total, blunder: total }[degree] ?? total;
  await actor.update({ "system.resources.pp.value": Math.max(0, ppOf(actor) - spent) });
  const lines = [line(`Spellcraft <strong>${int(check?.outcome?.total)}</strong> against DC ${dc}: <strong>${esc(degree)}</strong>. Mimic Spell costs <strong>${spent} PP</strong>.`)];
  const heldFor = R.mimicHold(degree, hold ? [R.UNLOCK.mimicHold] : []);
  if (heldFor) {
    const source = await resolve(data.spellUuid);
    const blocked = !source ? "the spell's document could not be found" : hasTrait(source.system, "ritual") ? "it has the Ritual trait: it may only be performed as a ritual (Q8)" : !R.mimicAllowed(castPP, casterLevelOf(actor)) ? `its ${castPP} PP exceed your maximum PP per cast (${casterLevelOf(actor) + 1}; M48)` : "";
    if (blocked) lines.push(line(`<em>No imprint: ${esc(blocked)}.</em>`));
    else {
      const raw = typeof source.toObject === "function" ? source.toObject() : JSON.parse(JSON.stringify(source));
      delete raw._id; delete raw._stats; delete raw.folder;
      raw.system = { ...raw.system, specialist: false, specialistClass: "", innate: false, usesPerDay: "", prepared: true };
      raw.flags = { ...(raw.flags ?? {}), [MODULE_ID]: { ...(raw.flags?.[MODULE_ID] ?? {}), [R.MIMIC_FLAG]: { castPP, from: data.casterName, fromUuid: data.casterUuid, freeChoice: heldFor.freeChoice, kind: heldFor.kind } } };
      const [copy] = await actor.createEmbeddedDocuments("Item", [raw]);
      if (copy) {
        const { expiryFor } = await import("./effects-clock.mjs");
        await actor.createEmbeddedDocuments("ActiveEffect", [effectData("mimicHold8b", { name: `Mimic Spell: ${data.spellName} imprinted`, img: mimic.img,
          description: `The imprint of ${data.spellName} (${castPP} PP as cast). Lost once cast or when this ends.`,
          module: { mimicHold8b: { itemId: copy.id } }, expiry: heldFor.kind === "nextTurn" ? expiryFor("endOfNextTurn", actor) : forSeconds(heldFor.seconds) })]);
        lines.push(line(`<strong>${esc(data.spellName)}</strong> is imprinted (${castPP} PP as cast) — cast it from your sheet ${heldFor.kind === "nextTurn" ? "on your next turn only" : `within ${heldFor.seconds >= 600 ? "10 minutes" : "1 minute"}`}, with your own PP, casting check, Save DC and cap (Q180).`));
        lines.push(line(heldFor.freeChoice ? "Critical: choose any targets, and add or drop metamagic you know." : "Success: the original targets, or those of them still in range."));
        lines.push(line(`<em>By hand: take the warps and metamagic it was cast with (${castPP} PP in all) — TRG Prime cannot hand a cast a warp already chosen. Short of PP, the cast offers PP below 0, at 5 Soul Drain each.</em>`));
      }
    }
  } else if (degree === "fumble" || degree === "blunder") {
    const res = await h().basicSaveHit({ caster: actor, target: actor, save: "will", dc: ownLevelDC(actor), label: "Mimic Spell: the resonance backlashes", formula: R.mimicBacklash(castPP), type: "essence" });
    lines.push(res?.line ?? line(`${R.mimicBacklash(castPP)} essence, basic Will.`));
  } else lines.push(line("You fail to capture the spell. No effect."));
  await card(actor, "Mimic Spell", lines);
  return { rolled: true, degree };
}
/** A cast of Mimic Spell from the sheet is refused: it is a reaction, offered when a spell is cast near you. */
export const mimicSheetRefusal = ({ spell } = {}) => (keyOf(spell) === "mimicSpell" ? "Mimic Spell is cast as a reaction: it is offered when a spellcaster you can see within 60 feet begins casting." : null);
/** registerCastPPSource: an imprint cast may go below 0 PP, at 5 Soul Drain each (Negative PP, core). */
export const mimicPPSource = {
  offer: async (ctx = {}) => {
    if (!ctx.spell?.flags?.[MODULE_ID]?.[R.MIMIC_FLAG]) return null;
    const short = R.mimicShortfall(ctx.ppPool, ctx.payable);
    return short > 0 ? { label: "Mimic Spell: below 0 PP", hint: `${R.SOUL_DRAIN_PER_PP} Soul Drain for every PP below 0`, max: short } : null;
  },
  settle: async (ctx = {}, { paid = 0 } = {}) => {
    const n = int(paid);
    if (!n) return null;
    // THE INCREMENT (the review): the core ADDS a Soul Drain tag's value.
    const add = R.SOUL_DRAIN_PER_PP * n;
    const value = int(ctx.actor?.getConditionValue?.("soulDrain")) + add;
    await h().applyConditionTagsTo(ctx.actor, [{ key: "soulDrain", value: add }]);
    return { lines: [`Mimic Spell: ${n} PP below 0 — <strong>${add} Soul Drain</strong> (Soul Drain ${value}).`] };
  }
};
/** The imprint is lost once cast. */
async function imprintCast(actor, ctx) {
  const item = ctx.spell;
  if (!item?.flags?.[MODULE_ID]?.[R.MIMIC_FLAG] || ctx.refunded) return;
  // THE ITEM FIRST (the 0.12.0 mutation run): its hold's end then finds no
  // imprint, and says nothing of one dissipating uncast.
  if (actor.items?.get?.(item.id)) await actor.deleteEmbeddedDocuments("Item", [item.id]);
  const hold = effects(actor).filter((e) => e.flags?.[MODULE_ID]?.mimicHold8b?.itemId === item.id).map((e) => e.id);
  if (hold.length) await actor.deleteEmbeddedDocuments("ActiveEffect", hold);
}

/* ----------------------------- Soul Confluence ------------------- */

async function soulConfluence(actor, ctx) {
  const me = tokenOf(actor);
  const near = (globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t.actor && t.actor !== actor && me && (feetBetween(me, t) ?? Infinity) <= R.CONFLUENCE_RADIUS_FEET && !enemiesBySide(sideOf(me.document), sideOf(t.document)));
  const ids = await pickMany(ctx.spell?.name, "Which willing allies within 30 feet join the confluence? (You are linked too.)", near.map((t) => ({ id: t.actor.uuid, label: t.name })));
  const allies = near.map((t) => t.actor).filter((a) => (ids ?? []).includes(a.uuid));
  const participants = [actor, ...allies];
  const pool = R.confluencePool(participants.map(conMod));
  const castId = castIdOf(actor, ctx);
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData(R.CONFLUENCE_FLAG, { name: `Soul Confluence: the shared pool (${pool})`, img: ctx.spell?.img,
    description: "The shared essence pool; damage to a participant comes off it first.", system: castId ? { castId } : {},
    module: { [R.CONFLUENCE_FLAG]: { pool, participants: participants.map((a) => a.uuid), start: worldNow(), castId } } })]);
  for (const who of participants) {
    await h().createEffectsOn(who, [effectData("confluenceLink8b", { name: `Soul Confluence: linked to ${actor.name}`, img: ctx.spell?.img,
      description: `Linked: damage comes off the shared pool first; +${R.CONFLUENCE_WILL_BONUS} status to Will saves.`,
      system: { conditionals: [{ kind: "modifier", value: R.CONFLUENCE_WILL_BONUS, type: "status", label: "Soul Confluence", scope: "Will saves", auto: true, when: { checkTypes: ["save"], subjects: ["will"] } }] },
      module: { confluenceLink8b: { casterUuid: actor.uuid } } })]);
  }
  return card(actor, ctx.spell?.name, [line(`<strong>${participants.length}</strong> linked: ${participants.map((a) => esc(a.name)).join(", ")}. The shared pool: <strong>${pool} HP</strong> (their Constitution modifiers × 5; Q181). Damage to any of them comes off it first (after temporary HP), until it is empty.`), line(`Linked: <strong>+${R.CONFLUENCE_WILL_BONUS} status to Will saves</strong>. When the spell ends (or is dismissed), each takes 1d6 Soul Drain per 2 rounds it lasted.`)]);
}
const localPools = new Map();
const confluenceMarker = (caster) => effects(caster).find((e) => sourceOf(e) === R.CONFLUENCE_FLAG) ?? null;
/** registerDamageShare: the pool takes a linked creature's damage first. */
export async function confluenceShare(actor, amount) {
  const link = effects(actor).find((e) => sourceOf(e) === "confluenceLink8b" && !e.disabled);
  if (!link) return null;
  const caster = actorOf(await resolve(link.flags[MODULE_ID].confluenceLink8b.casterUuid));
  const marker = confluenceMarker(caster);
  const rec = marker?.flags?.[MODULE_ID]?.[R.CONFLUENCE_FLAG];
  if (!rec || !rec.participants?.includes(actor.uuid)) return null;
  // THE POOL AS THIS CLIENT LAST LEFT IT (the review): a relayed write lands
  // later, so a second hit before it does must not draw on the old pool.
  const poolKey = `${caster.uuid}|${marker.id}`;
  const pool = Math.min(int(rec.pool), localPools.has(poolKey) ? localPools.get(poolKey) : Infinity);
  const out = R.confluenceTake(pool, amount);
  if (!out.taken) return null;
  const next = { ...rec, pool: out.pool };
  // HERE IF THIS CLIENT OWNS THE CASTER, ELSE THROUGH THE GM (Block 7's relay, which lets the pool only fall).
  const written = await writeOn(caster, { kind: "effectFlag", effectId: marker.id, key: R.CONFLUENCE_FLAG, value: next });
  if (written === false) return null;
  localPools.set(poolKey, out.pool);
  await card(actor, "Soul Confluence", [line(`The shared pool takes <strong>${out.taken}</strong> of ${esc(actor.name)}'s damage (${out.pool} left).`)]);
  return { taken: out.taken };
}
/** The spell's end: the backlash, and the links undone (the caster's client). */
async function confluenceEnded(caster, rec) {
  const seconds = worldNow() - Number(rec.start ?? worldNow());
  const dice = R.confluenceBacklash(seconds);
  const lines = [line(`Soul Confluence ends after ${Math.floor(Math.max(0, seconds) / R.SPAN.round)} round${Math.floor(seconds / R.SPAN.round) === 1 ? "" : "s"}: <strong>${dice ? `${dice}d6` : "no"} Soul Drain</strong> for each participant (1d6 per 2 rounds).`)];
  for (const who of await actorsOf(rec.participants)) {
    if (dice) {
      const n = (await new Roll(`${dice}d6`).evaluate()).total;
      const value = int(who.getConditionValue?.("soulDrain")) + n;
      await h().applyConditionTagsTo(who, [{ key: "soulDrain", value: n }]);
      lines.push(line(`${esc(who.name)}: <strong>${n} Soul Drain</strong> (Soul Drain ${value}).`));
    }
    const links = effects(who).filter((e) => sourceOf(e) === "confluenceLink8b" && e.flags?.[MODULE_ID]?.confluenceLink8b?.casterUuid === caster.uuid).map((e) => e.id);
    if (links.length) await writeOn(who, { kind: "deleteEffects", ids: links });
  }
  return card(caster, "Soul Confluence", lines);
}

/* ----------------------------- Storm of Unmaking ----------------- */

const fumbleDC = (actor, ctx) => failedCastSaveDC(actor, ctx);
async function stormFumble(actor, ctx) {
  const dc = fumbleDC(actor, ctx);
  const out = await h().placeStorm?.(actor, { ...R.UNMAKING_STORM, modes: R.UNMAKING_STORM.modes.map((m) => ({ ...m })), follow: true },
    { radiusFeet: R.UNMAKING_RADIUS_FEET, follow: true, dc, castId: "", seconds: R.UNMAKING_SECONDS, spellName: ctx.spell?.name ?? "Storm of Unmaking" });
  return card(actor, `${ctx.spell?.name ?? "Storm of Unmaking"} — the storm turns`, [
    line(`<strong>The storm appears above you and follows you</strong> for 1 minute (Q182), after the failure's own PP loss and fumble roll: a 60-ft radius on you, striking now and at the start of each of your turns, everyone in it saving against your Save DC (${dc}${int(ctx.saveDC) ? "" : ": 10 + the PP cast + your casting ability"}), you included.`),
    ...(out?.lines ?? [line("<em>The storm could not be raised: the GM places it.</em>")]).map((l) => line(l))
  ]);
}

/* ----------------------------- Veilfracture --------------------- */

async function veilfracture(actor, ctx) {
  const width = R.portalWidth(casterLevelOf(actor));
  const at = await pickPoint(`${ctx.spell?.name}: click where the rift opens (within 30 ft). Escape: the GM places it.`);
  const castId = castIdOf(actor, ctx);
  let placed = null;
  if (at && globalThis.canvas?.scene) {
    const px = pxPerFoot();
    const [region] = await globalThis.canvas.scene.createEmbeddedDocuments("Region", [{ name: `Veilfracture: a ${width}-ft rift`, color: "#3a1f5c", visibility: regionVisibility("ALWAYS"),
      shapes: [{ type: "rectangle", x: at.x - (width * px) / 2, y: at.y - (2.5 * px), width: width * px, height: 5 * px, rotation: 0, hole: false }],
      flags: { [MODULE_ID]: { [R.AREA8B_FLAG]: { key: "veilfracture", castBound: true, castId, casterUuid: actor.uuid, until: null, centre: at, radius: width / 2 } } } }]);
    placed = region ?? null;
  }
  return card(actor, ctx.spell?.name, [line(`A rift ${width} ft wide (10 ft per 2 caster levels)${placed ? " on the map" : ""}, while you sustain it. It links the Material Plane to a nearby coterminous plane — <strong>the GM's choice</strong>: the Shadescape, an Elemental Plane, or the Abyss.`)]);
}
async function veilfractureFumble(actor, ctx) {
  const id = globalThis.foundry?.utils?.randomID?.() ?? String(Date.now());
  const dc = failedCastSaveDC(actor, ctx);
  await actor.setFlag(MODULE_ID, "veilfracture8b", { id, dc, degree: ctx.degree });
  await buttonCard(actor, `${ctx.spell?.name} — the rift collapses`, [`The rift collapses violently: ${esc(actor.name)} and 1d4 creatures nearby are pulled into the plane — a Reflex save against ${esc(actor.name)}'s Save DC (${dc}${int(ctx.saveDC) ? "" : ": 10 + the PP cast + the casting ability"}) resists; a Fumble on it, lost there. GM: select the creatures nearby (the count is rolled), then press the button.`],
    [{ action: "veilfracturePull", caster: actor.uuid, ref: id, label: "Pull them into the plane" }], { gm: true });
  return card(actor, ctx.spell?.name, [line("<strong>The rift collapses violently</strong> — the GM's card rolls who is pulled in.")]);
}
export async function veilfracturePull(caster, ref) {
  const rec = caster.getFlag?.(MODULE_ID, "veilfracture8b");
  if (!rec || rec.id !== ref) return warn("Eldritch Arts: this rift has already collapsed.");
  await caster.unsetFlag(MODULE_ID, "veilfracture8b");
  const count = (await new Roll(R.VEILFRACTURE_PULL).evaluate()).total;
  const chosen = Array.from(globalThis.canvas?.tokens?.controlled ?? []).map((t) => t.actor).filter((a) => a && a !== caster).slice(0, count);
  const lines = [line(`1d4 = <strong>${count}</strong> creature${count === 1 ? "" : "s"} nearby${chosen.length < count ? ` (${chosen.length} selected)` : ""}, and ${esc(caster.name)}.`)];
  for (const who of [caster, ...chosen]) {
    const check = await h().rollCheck({ actor: who, type: "save", subject: "reflex", label: `${who.name} — Reflex against the collapsing rift`, dc: int(rec.dc), saveSource: "Veilfracture", sourceUuid: caster.uuid });
    const d = String(check?.outcome?.degree?.key ?? "failure");
    lines.push(line(`${esc(who.name)}: <strong>${esc(d)}</strong>${succeeded(check) ? " — resists." : d === "fumble" || d === "blunder" ? " — pulled into the plane, and <strong>lost there</strong>." : " — <strong>pulled into the plane</strong>."}`));
  }
  return card(caster, "Veilfracture — the rift collapses", lines);
}

/* ----------------------------- Alter Corpse ---------------------- */

async function alterCorpse(actor, ctx) {
  const pick = await h().chooseFromList(ctx.spell?.name, "Which use, selected as the spell is cast?", R.CORPSE_USES.map(([k, l]) => [k, l]));
  const use = R.CORPSE_USES.find(([k]) => k === pick);
  return card(actor, ctx.spell?.name, [line(use ? `<strong>${esc(use[1])}</strong> — the corpse is the table's.` : "<em>No use chosen: the table's.</em>")]);
}

/* ================================================================== */
/* Hooks                                                                */
/* ================================================================== */

/** Hooks.on("trgPrimeSpellSettled"). */
export async function onSpellSettledB8b(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner) return null;
  if (ctx.spell?.flags?.[MODULE_ID]?.[R.MIMIC_FLAG]) await imprintCast(actor, ctx);
  const key = keyOf(ctx.spell);
  if (R.isRitual8b(key)) return onRitualSettled(actor, ctx);
  if (!R.isHighMagic8b(key) || ctx.refunded) return null;
  if (key === "stormOfUnmaking") return ["fumble", "blunder"].includes(String(ctx.degree)) ? stormFumble(actor, ctx) : null;
  if (key === "veilfracture") return ["fumble", "blunder"].includes(String(ctx.degree)) ? veilfractureFumble(actor, ctx) : ctx.cast ? veilfracture(actor, ctx) : null;
  if (!ctx.cast) return null;
  switch (key) {
    case "alterCorpse": return alterCorpse(actor, ctx);
    case "chaosShield": return chaosShield(actor, ctx);
    case "leylineAnchor": return leylineAnchor(actor, ctx);
    case "soulConfluence": return soulConfluence(actor, ctx);
    default: return null;
  }
}

/** Hooks.on("updateToken"): memberships, and a Region that follows its token. */
export async function onTokenMovedB8b(doc, change = {}) {
  if (!("x" in (change ?? {})) && !("y" in (change ?? {}))) return 0;
  if (!isActingGM()) return 0;
  const at = endPositionOf(doc, change);
  let n = 0;
  for (const region of areas8b(null, doc?.parent)) {
    const rec = areaRecordOf(region);
    if (rec.followTokenId && rec.followTokenId === doc.id) {
      const c = docCentre(at);
      const shape = region.shapes?.[0];
      if (shape?.type === "circle") await region.update({ shapes: [{ ...(shape.toObject?.() ?? shape), x: c.x, y: c.y }] }).catch(() => {});
    }
    n += await syncMembers(region, { doc, at });
  }
  return n;
}

/** Hooks.on("updateWorldTime"): an 8b Region's end (its own clock, or its cast's), and its cast ended with it. */
export async function onWorldTimeB8b() {
  if (!isActingGM()) return 0;
  let n = 0;
  for (const scene of allScenes()) {
    for (const region of Array.from(scene?.regions ?? [])) {
      const rec = areaRecordOf(region);
      if (!rec) continue;
      const caster = actorOf(await resolve(rec.casterUuid));
      // A REGION BOUND TO ITS CAST goes when the cast does (dismissed, dispelled);
      // a ritual's own span outlasts the core's entry (Concord's 6 months).
      const castGone = rec.castBound && rec.castId && caster && !Array.from(caster.getFlag?.(SYSTEM_ID, "activeSpells") ?? []).some((e) => e?.id === rec.castId);
      const timeUp = rec.until !== null && rec.until !== undefined && Number(rec.until) <= worldNow();
      if (!timeUp && !castGone) continue;
      await region.delete().catch(() => {});
      if (timeUp && caster && rec.castId && !castGone) await h().endSpellOf?.(caster, rec.castId);
      n += 1;
    }
  }
  return n;
}

/** Hooks.on("createRegion"): a membership Region's first members, made by the acting GM whoever cast it (the review). */
export async function onRegionCreatedB8b(region) {
  if (!areaRecordOf(region) || !isActingGM()) return 0;
  return syncMembers(region);
}

/** Hooks.on("updateActor"): a cast dismissed or dispelled takes its cast-bound Regions now, not at the next clock tick (the review). */
export async function onActorUpdatedB8b(actor, change = {}) {
  const flags = change?.flags?.[SYSTEM_ID];
  if (!flags || !(("activeSpells" in flags) || ("-=activeSpells" in flags))) return 0;
  if (!isActingGM()) return 0;
  const live = new Set(Array.from(actor.getFlag?.(SYSTEM_ID, "activeSpells") ?? []).map((e) => e?.id));
  let n = 0;
  for (const scene of allScenes()) {
    for (const region of Array.from(scene?.regions ?? [])) {
      const rec = areaRecordOf(region);
      if (!rec?.castBound || !rec.castId || rec.casterUuid !== actor.uuid || live.has(rec.castId)) continue;
      await region.delete().catch(() => {});
      n += 1;
    }
  }
  return n;
}

/** Hooks.on("deleteRegion"): a membership Region gone takes its effects with it (the acting GM). */
export async function onRegionDeletedB8b(region) {
  if (!areaRecordOf(region) || !isActingGM()) return 0;
  const actors = new Set([...tokens(region.parent).map((d) => d.actor), ...Array.from(globalThis.game?.actors ?? [])]);
  let n = 0;
  for (const actor of actors) {
    const ids = effects(actor).filter((e) => e.flags?.[MODULE_ID]?.[R.AURA8B_FLAG] === region.id).map((e) => e.id);
    if (ids.length) { await actor.deleteEmbeddedDocuments("ActiveEffect", ids).catch(() => {}); n += ids.length; }
  }
  return n;
}

/** Hooks.on("deleteActiveEffect"): Soul Confluence's end; a mimic's hold ending takes its imprint. */
export async function onEffectDeletedB8b(effect) {
  const actor = effect?.parent;
  if (!actor || actor.documentName !== "Actor") return null;
  const src = sourceOf(effect);
  // ARMY OF THE GRAVE (the review): a raised undead's effect gone frees its
  // control entry, on the client that writes for the caster.
  if (src === "armyRaised8b") {
    const raised = effect.flags?.[MODULE_ID]?.armyRaised8b ?? {};
    const caster = actorOf(await resolve(raised.casterUuid));
    if (!caster || !raised.entryId || !actsFor(caster)) return null;
    return h().releaseControlled?.(caster, raised.entryId, { reason: "Army of the Grave ended", creature: actor });
  }
  if (!actsFor(actor)) return null;
  if (src === R.CONFLUENCE_FLAG) return confluenceEnded(actor, effect.flags[MODULE_ID][R.CONFLUENCE_FLAG]);
  if (src === "mimicHold8b") {
    const itemId = effect.flags[MODULE_ID].mimicHold8b?.itemId;
    if (itemId && actor.items?.get?.(itemId)) {
      await actor.deleteEmbeddedDocuments("Item", [itemId]);
      return card(actor, "Mimic Spell", [line("The imprint dissipates, uncast.")]);
    }
  }
  return null;
}

/** The socket: a task for a creature's owner (its own choice). No other kind is taken (the review). */
export async function onBlock8bSocket(data = {}) {
  if (data?.action !== ACTION_8B) return false;
  const actor = actorOf(await resolve(data.actorUuid));
  if (!actor) return false;
  if (data.kind === "owner" && OWNER_TASKS[data.task] && answersFor(actor)) { await OWNER_TASKS[data.task](actor, data.data ?? {}); return true; }
  return false;
}
export function registerBlock8bSocket() {
  globalThis.game?.socket?.on?.(SOCKET, (data) => { onBlock8bSocket(data).catch((err) => console.warn("Eldritch Arts | Block 8b socket", err)); });
}

export function registerBlock8b(api, moduleId) {
  // THE RITUALS (§4.2): ticks, the Cost before the roll, the Partial (H13), alone (H14).
  api.registerRitualRules?.(RULES_KEY_8B, { fields: ritualFields8b, prepare: prepareRitual8b, partialCasts: ritualPartialCasts8b, minSecondaries: ritualMinSecondaries8b }, moduleId);
  // TELEPORTATION WITHOUT A TELEPORT AT THE CAST (as Block 8a's): Veil Severing opens a portal.
  api.registerDeferredTeleport?.("eaVeilSevering", (ctx = {}) => keyOf(ctx.spell) === "veilSevering", moduleId);
  // HIGH MAGIC (§4.4).
  api.registerCastReaction?.("eaMimicSpell", mimicReaction, moduleId);
  api.registerReactionStep?.(MIMIC_STEP, mimicStep, moduleId);
  api.registerReactionStep?.(NULLIFY_STEP, nullifyStep, moduleId);
  api.registerCastRefusal?.("eaMimicSpellSheet", mimicSheetRefusal, moduleId);
  api.registerCastPPSource?.("eaMimicBelowZero", mimicPPSource, moduleId);
  api.registerCastCostModifier?.("eaLeylineAnchor", anchorCostCut, moduleId);
  api.registerDamageShare?.("eaSoulConfluence", confluenceShare, moduleId);
}

/** For the harness. */
export const INTERNALS_B8B = Object.freeze({ RITUAL_RUNNERS, memberGrant, syncMembers, convergenceMember, swearOath, localPools, asked, chaosShield, leylineAnchor, soulConfluence, confluenceEnded, stormFumble, veilfracture, veilfractureFumble, alterCorpse, nullifyStep, imprintCast, OWNER_TASKS, cardHTML, payCost, hitCasters, takePlan });
