/**
 * Eldritch Arts — Block 11 (0.18.0): the Feat Additions (ten Artificer class
 * feats, three Runemage class feats, four Ascendan racial feats, Quick Swap and
 * the Prepared trait). THE PURE HALF: every number, list and decision the
 * Foundry half (block11-automations.mjs) reads, so the harness can run them
 * without a world. No Foundry, no game.
 *
 * Source: "TRG Prime Eldritch Arts Feat Additions — Exact Format" (Graham,
 * November 2026), cut verbatim into tools/content/feat-additions.md. Where the
 * text leaves a question open, the reading taken here is the narrowest one the
 * words allow, and docs/ELDRITCH_ARTS_BLOCK11_AUDIT.md names it (A11-1 …).
 */

export const MODULE_ID = "trg-eldritch-arts";

const norm = (v) => String(v ?? "").trim().toLowerCase();
const int = (v) => {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) ? n : 0;
};
const traitList = (v) => (Array.isArray(v) ? v : String(v ?? "").split(/[,;]/)).map(norm).filter(Boolean);

/* ------------------------------------------------------------------ */
/* Names                                                                */
/* ------------------------------------------------------------------ */

export const FEATS = Object.freeze({
  modular: "Modular Design",
  advanced: "Advanced Design",
  integrated: "Integrated Modularity",
  assistant: "Mechanised Assistant",
  overclock: "Overclocked Weaponry",
  powerSink: "Power Sink",
  harness: "Instability Harness",
  contraption: "Emergency Contraption",
  insight: "Flash of Insight",
  tinkerer: "Tinkerer Precision",
  anchor: "Runic Anchor",
  triggered: "Triggered Sigil",
  grand: "Grand Inscription",
  leyResonance: "Ley Resonance",
  arcanePrep: "Arcane Preparation",
  firstWeave: "Heritage of the First Weave",
  memory: "Perfected Arcane Memory"
});
export const QUICK_SWAP = "Quick Swap";
/** The feats with a Use (a registered feat automation); the rest work on their own (a passive hint). */
export const USE_FEATS = Object.freeze(["Modular Design", "Advanced Design", "Integrated Modularity", "Mechanised Assistant", "Overclocked Weaponry", "Power Sink", "Emergency Contraption", "Flash of Insight", "Triggered Sigil", "Grand Inscription", "Arcane Preparation", "Perfected Arcane Memory"]);
export const ASSISTANT_FRAME = "Mechanised Assistant Frame";
/**
 * THE REBUILD'S COST (Graham's ruling A11-7, 25 Nov 2026): the Core Rulebook's
 * Equipment Cost Table (p. 173), "the cost of any goods, kits or tools", read
 * at the assistant's level, which is its master's. Level 0 has no cost.
 */
export const EQUIPMENT_COST = Object.freeze([0, 50, 125, 225, 375, 625, 1000, 1500, 2100, 3000, 4000, 5500, 8000, 12000, 18000, 27500, 40000, 60000, 90000, 150000, 250000]);
export const rebuildCost = (level) => EQUIPMENT_COST[Math.max(0, Math.min(20, int(level)))] ?? 0;
/** Scout Optics: "Tracking as a class skill" — Survival, by Graham's ruling (A11-8). */
export const SCOUT_CLASS_SKILL = "Survival";

export const ASSISTANT_ABILITIES = Object.freeze({ frame: "Reinforced Frame", storage: "Storage", reactive: "Reactive Protocol" });

export const ARTIFICER_FEATS = Object.freeze([FEATS.modular, FEATS.advanced, FEATS.integrated, FEATS.assistant, FEATS.overclock, FEATS.powerSink, FEATS.harness, FEATS.contraption, FEATS.insight, FEATS.tinkerer]);
export const RUNEMAGE_FEATS = Object.freeze([FEATS.anchor, FEATS.triggered, FEATS.grand]);
export const ASCENDAN_FEATS = Object.freeze([FEATS.leyResonance, FEATS.arcanePrep, FEATS.firstWeave, FEATS.memory]);
/** The five Runemage class feats Eldritch Arts v1.6 already prints; Block 11 must not touch them. */
export const EXISTING_RUNEMAGE_FEATS = Object.freeze(["Prepared Sigil", "Combat Inscription", "Ley-Etched Symbol", "Runic Reservoir", "Living Script"]);

/* ------------------------------------------------------------------ */
/* The Prepared trait                                                   */
/* ------------------------------------------------------------------ */

/**
 * "An ability with this trait can be replenished and used again if you take a
 * 3 AP (manipulate) Crafting action (level based DC). Such an ability will
 * recharge within ten minutes if the action is not taken."
 *
 * Not Focus (Refocus does not reach it) and not Prepared Sigil (a Runemage's
 * inscription). Its state lives on the item (`flags[MODULE_ID].eaPrepared`):
 * `{ expended: true, at: <world seconds> }`, so it survives a reload and a
 * sheet re-render; the ten minutes are read off the world clock.
 */
export const PREPARED_TRAIT = "Prepared";
export const PREPARED_FLAG = "eaPrepared";
export const PREPARED_RECHARGE_AP = 3;
export const PREPARED_RECHARGE_SECONDS = 600;
export const PREPARED_RECHARGE_SKILL = "crafting";
/** A1-6: the recharge check's degrees that replenish. Partial and worse do not (the 10 minutes still run). */
export const PREPARED_RECHARGE_DEGREES = Object.freeze(["heroic", "critical", "success"]);

export const hasPreparedTrait = (traits) => traitList(traits).includes("prepared");

/** Is a Prepared ability ready at `worldTime`? */
export function preparedReady(state, worldTime = 0) {
  if (!state || state.expended !== true) return true;
  return Number(worldTime) - Number(state.at ?? 0) >= PREPARED_RECHARGE_SECONDS;
}

/** Seconds until it recharges by itself (0 when ready). */
export function preparedSecondsLeft(state, worldTime = 0) {
  if (preparedReady(state, worldTime)) return 0;
  return Math.max(0, PREPARED_RECHARGE_SECONDS - (Number(worldTime) - Number(state.at ?? 0)));
}

export const preparedExpended = (worldTime = 0) => ({ expended: true, at: Math.trunc(Number(worldTime) || 0) });
export const preparedRestores = (degree) => PREPARED_RECHARGE_DEGREES.includes(norm(degree));

/* ------------------------------------------------------------------ */
/* Modular Design, Advanced Design, Integrated Modularity, Quick Swap   */
/* ------------------------------------------------------------------ */

export const MODULAR_FLAG = "eaModular";
export const MODULAR_ITEM_FLAG = "eaModularUpgrade";
/** The effect source on an armour, shield or tool's own upgrade effect. */
export const MODULAR_EFFECT = "eaModularUpgrade";

/** What each kind of item may be upgraded in. Weapon: attack or damage; armour (and shields, A11-11): DB or DR; equipment: a skill. */
export const MODULAR_TARGETS = Object.freeze({
  weapon: Object.freeze([["attack", "Attack rolls (item bonus)"], ["damage", "Damage (item bonus)"]]),
  armour: Object.freeze([["db", "DB (item bonus)"], ["dr", "DR (item bonus)"]]),
  equipment: Object.freeze([["skill", "A skill check when using the tool (item bonus)"]])
});

/** The kind an item is upgraded as, or null when it is not armour, equipment or a weapon. */
export function modularKind(item) {
  const type = norm(item?.type);
  if (type === "weapon") return item?.system?.natural ? null : "weapon";
  if (type === "armour" || type === "shield") return "armour";
  if (type === "gear") return "equipment";
  return null;
}

/**
 * THE ONE ALLOWANCE (A11-1, A11-2). Modular Design: "a temporary modular
 * upgrade to any one piece" — one item, +1. Advanced Design: "either a +1
 * bonus to items or a +2 bonus to a single item" — read on the feats'
 * progression (+1, +2, +3) as a budget of 2: +1 on each of two items, or +2 on
 * one. Integrated Modularity: "any combination of +3 amongst your bonus" — a
 * budget of 3, split as you like. One pool, so the three feats never keep
 * three incompatible lists.
 */
export function modularAllowance(featNames = []) {
  const has = (n) => featNames.some((f) => norm(f) === norm(n));
  if (!has(FEATS.modular)) return { budget: 0, maxPerItem: 0, maxItems: 0, by: "" };
  // GRAHAM'S RULING (A11-2, 25 Nov 2026): Integrated Modularity is "any
  // combination of +3" — three +1s, a +2 and a +1, or a +3 — and an item's
  // share may be split between its two bonuses (attack and damage; DB and DR).
  if (has(FEATS.integrated)) return { budget: 3, maxPerItem: 3, maxItems: 3, split: true, by: FEATS.integrated };
  // A11-1 (a typo, ruled): "+1 bonus to two items or a +2 bonus to a single item".
  if (has(FEATS.advanced)) return { budget: 2, maxPerItem: 2, maxItems: 2, split: false, by: FEATS.advanced };
  return { budget: 1, maxPerItem: 1, maxItems: 1, split: false, by: FEATS.modular };
}

/**
 * Is this allocation allowed? `[{ itemId, kind, target, skill?, value }]`.
 * One entry per item, one target per item ("a bonus to one of the
 * following"), each 1..maxPerItem, the sum within the budget, the target one
 * the item's kind takes. Returns "" or the reason.
 */
export function modularRefusal(allocations = [], allowance = {}) {
  const list = Array.isArray(allocations) ? allocations : [];
  if (!allowance?.budget) return "you do not have Modular Design";
  const seen = new Set();
  const perItem = new Map();
  let sum = 0;
  for (const a of list) {
    const value = int(a?.value);
    if (!a?.itemId) return "an upgrade names no item";
    const key = allowance.split ? `${a.itemId}:${a.target}` : a.itemId;
    if (seen.has(key)) return allowance.split ? "an item may carry one upgrade to each bonus" : "an item may carry one modular upgrade";
    seen.add(key);
    const targets = MODULAR_TARGETS[a?.kind];
    if (!targets) return "only armour, equipment or a weapon can take an upgrade";
    if (!targets.some(([k]) => k === a.target)) return `a${a.kind === "armour" ? "n armour" : ` ${a.kind}`} upgrade cannot be to ${a.target}`;
    if (a.target === "skill" && !norm(a.skill)) return "an equipment upgrade names the skill it helps";
    if (value < 1) return "an upgrade is at least +1";
    perItem.set(a.itemId, (perItem.get(a.itemId) ?? 0) + value);
    if (perItem.get(a.itemId) > allowance.maxPerItem) return `no item may carry more than +${allowance.maxPerItem} (${allowance.by})`;
    sum += value;
  }
  if (perItem.size > allowance.maxItems) return `${allowance.by} allows ${allowance.maxItems} upgraded item${allowance.maxItems === 1 ? "" : "s"}`;
  if (sum > allowance.budget) return `${allowance.by} allows +${allowance.budget} in all (this is +${sum})`;
  return "";
}

/**
 * The upgrades after moving one — the allocation on `fromId` (and, where an item
 * carries two, `fromTarget`) — to the item `to`. The value and target kind must
 * still fit the destination; a destination may already carry an upgrade only
 * under Integrated Modularity (`split`), and then not to the same bonus.
 */
export function modularMoved(allocations = [], fromId, to = {}, { fromTarget = null, split = false } = {}) {
  const at = allocations.find((a) => a.itemId === fromId && (!fromTarget || a.target === fromTarget));
  if (!at) return { ok: false, reason: "that item carries no upgrade", allocations };
  if (!to?.itemId || to.itemId === fromId) return { ok: false, reason: "choose another item", allocations };
  const kind = to.kind;
  const targets = MODULAR_TARGETS[kind];
  if (!targets) return { ok: false, reason: "the destination is not armour, equipment or a weapon", allocations };
  const target = to.target ?? (kind === at.kind ? at.target : targets[0][0]);
  if (!targets.some(([k]) => k === target)) return { ok: false, reason: `that bonus cannot go on a${kind === "armour" ? "n armour piece" : ` ${kind}`}`, allocations };
  const there = allocations.filter((a) => a.itemId === to.itemId);
  if (there.length && !split) return { ok: false, reason: "the destination already carries an upgrade", allocations };
  if (there.some((a) => a.target === target)) return { ok: false, reason: "the destination already carries that bonus", allocations };
  const moved = { ...at, itemId: to.itemId, itemName: to.itemName ?? at.itemName, kind, target, skill: target === "skill" ? (to.skill ?? at.skill ?? "") : "" };
  return { ok: true, reason: "", allocations: allocations.map((a) => (a === at ? moved : a)) };
}

/** The change an armour or shield upgrade writes into the core's typed pool (TRGActiveEffect: CUSTOM keys). */
export function modularArmourChange(target, value) {
  const v = String(Math.max(0, int(value)));
  if (target === "db") return { key: "system.combat.defence.item", mode: 0, value: v, priority: 20 };
  if (target === "dr") return { key: "system.combat.dr.item", mode: 0, value: v, priority: 20 };
  return null;
}

/** The conditional an equipment upgrade carries: an item bonus to one skill, pre-ticked, only while the tool is held. */
export function modularSkillConditional(skill, value, itemName = "") {
  return {
    kind: "modifier", value: Math.max(1, int(value)), type: "item",
    label: `Modular upgrade (${itemName || "tool"})`,
    scope: `${skill} checks made using ${itemName || "the tool"}`,
    auto: true, when: { checkTypes: ["skill"], subjects: [norm(skill)] }
  };
}

/**
 * A weapon upgrade's answers to the core's weapon-enhancement seam (C-EA11-1).
 * The weapon's flag holds one upgrade ({target, value}) or, under Integrated
 * Modularity, a list of them (attack and damage). Always an array.
 */
export function modularWeaponAnswers(flag) {
  if (!flag) return [];
  const list = Array.isArray(flag?.upgrades) ? flag.upgrades : [flag];
  const out = [];
  for (const u of list) {
    const value = Math.max(0, int(u?.value));
    if (!value) continue;
    if (u.target === "attack") out.push({ label: `Modular upgrade +${value} (attack)`, attack: value, attackType: "item" });
    else if (u.target === "damage") out.push({ label: `Modular upgrade +${value} (damage)`, damage: value, damageType: "item" });
  }
  return out;
}
/** One upgrade's answer (kept for callers of 0.18.0). */
export function modularWeaponAnswer(upgrade) {
  if (!upgrade || upgrade.kind !== "weapon") return null;
  return modularWeaponAnswers(upgrade)[0] ?? null;
}

/** Quick Swap: "from one item you are wielding or wearing to another eligible item you are currently wielding or wearing". */
export const QUICK_SWAP_AP = 2;
export const ADVANCED_SWAP_SECONDS = 600;

/* ------------------------------------------------------------------ */
/* Overclocked Weaponry                                                 */
/* ------------------------------------------------------------------ */

export const OVERCLOCK_FLAG = "eaOverclock";
export const OVERCLOCK_SECONDS = 60;
export const OVERCLOCK_ELEMENTS = Object.freeze(["acid", "fire", "electricity"]);
export const OVERCLOCK_MODES = Object.freeze([
  ["plasma", "Plasma Edge: +1d4 secondary elemental damage (acid, fire or electricity)"],
  ["gyro", "Gyroscopic Repeater: reload AP −1"],
  ["impact", "Impact Amplifier: base damage +1"]
]);
const LOAD = /\bload\s*(\d+)?\b|\bquick\s*load\b|\bmagazine\b/i;
export const weaponReloads = (weapon) => LOAD.test(String(weapon?.system?.traits ?? ""));

/** Which modes this weapon can take: Gyroscopic Repeater only on a weapon that reloads. */
export function overclockModesFor(weapon) {
  return OVERCLOCK_MODES.filter(([k]) => k !== "gyro" || weaponReloads(weapon));
}

/** An overclock's answer to the core's weapon-enhancement seam (C-EA11-1). */
export function overclockAnswer(state) {
  if (!state?.mode) return null;
  if (state.mode === "plasma" && OVERCLOCK_ELEMENTS.includes(norm(state.element))) {
    return { label: `Overclocked: Plasma Edge (${norm(state.element)})`, packets: [{ dice: "1d4", type: norm(state.element), label: "Plasma Edge" }] };
  }
  if (state.mode === "gyro") return { label: "Overclocked: Gyroscopic Repeater", reloadReduction: 1 };
  // A11-12: "base damage +1" — untyped, so it adds whatever item bonus the weapon has.
  if (state.mode === "impact") return { label: "Overclocked: Impact Amplifier", damage: 1, damageType: "untyped" };
  return null;
}

/* ------------------------------------------------------------------ */
/* Power Sink, Instability Harness                                      */
/* ------------------------------------------------------------------ */

export const POWER_SINK_FEET = 30;
export const OVERLOAD_EFFECT = "eaOverload";

/**
 * Power Sink: "fails a saving throw against a magical effect" — a Failure
 * (A11-5: TRG's Fumble and Blunder are their own degrees, and Instability
 * Harness is what adds them: "You may use Power Sink in the event of a fumble
 * or blunder"). Partial is not a failure to the core's reactions.
 */
/** "fails", "fumbles", "blunders" — the prompt's verb for a degree (0.18.1: "failures" was printed). */
export function degreeVerb(degree) {
  const d = norm(degree);
  return ({ failure: "fails", fumble: "fumbles", blunder: "blunders", partial: "partially succeeds at" })[d] ?? `${d || "fails"}:`;
}

export function powerSinkDegrees({ harness = false } = {}) {
  return harness ? ["failure", "fumble", "blunder"] : ["failure"];
}

/** Is this save against a magical effect? A spell's tradition, the magical trait, or a spell source. */
export function saveIsMagical(check = {}) {
  const traditions = traitList(check.traditions);
  if (traditions.length) return true;
  const traits = traitList(check.traits);
  if (traits.includes("magical") || traits.includes("arcane") || traits.includes("divine") || traits.includes("verdant") || traits.includes("ethereal")) return true;
  return ["spell", "magic", "magical", "item"].includes(norm(check.saveSource));
}

/**
 * A magical item the Artificer is holding or wearing (Power Sink): equipped or
 * invested, and magical — runes, or a wondrous, charged, specific or relic
 * item, or the Magical/Invested trait.
 */
export function isMagicalHeldItem(item) {
  if (!item) return false;
  const sys = item.system ?? {};
  if (!(sys.equipped || sys.invested)) return false;
  const runes = String(sys.runes ?? sys.effectiveRunes ?? "").trim();
  if (runes) return true;
  if (["wondrous", "charged", "chargeditem", "relic"].includes(norm(item.type))) return true;
  // The core's wondrous, charged and specific items are "gear" (or armour, a
  // shield) marked by a flag, not a type (found live, 0.18.1: a worn Ring of
  // Protection was not offered).
  const f = item.flags?.["trg-prime"] ?? {};
  if (f.wondrous || f.chargedItem || f.specificItem) return true;
  // Core items write traits space-separated ("Invested Warding"), the books' with commas.
  const words = String(Array.isArray(sys.traits) ? sys.traits.join(" ") : sys.traits ?? "").split(/[\s,;]+/).map(norm).filter(Boolean);
  return words.includes("magical") || words.includes("invested") || words.includes("relic");
}

/* ------------------------------------------------------------------ */
/* Emergency Contraption, Flash of Insight                              */
/* ------------------------------------------------------------------ */

export const CONTRAPTION_BONUS = 2;
/** The core's Disable Device action key(s) a failed check is read from. */
export const DISABLE_DEVICE_ACTIONS = Object.freeze(["disabledevice", "disable device", "disarmtrap", "disarm trap"]);
export const isDisableDevice = (ctx = {}) => {
  const key = norm(ctx.check?.actionKey ?? ctx.actionKey);
  const label = norm(ctx.label ?? ctx.check?.label);
  return DISABLE_DEVICE_ACTIONS.includes(key) || DISABLE_DEVICE_ACTIONS.some((a) => label.includes(a));
};

/** Flash of Insight: "fails or fumbles a skill check or saving throw" (A11-3: Blunder is not named). */
export const INSIGHT_DEGREES = Object.freeze(["failure", "fumble"]);
/** A11-4: "an ally that you are aware of within" — the distance is missing; read as Power Sink's 30 ft pending a ruling. */
export const INSIGHT_FEET = 30;
export const insightWants = (ctx = {}) => ["skill", "save"].includes(ctx.type) && INSIGHT_DEGREES.includes(norm(ctx.degree));

/* ------------------------------------------------------------------ */
/* Tinkerer Precision                                                   */
/* ------------------------------------------------------------------ */

export const TINKERER_RANKS = 2;
export const TINKERER_VALUE_FACTOR = 0.75;

/** Its answer to the core's crafting-work seam (C-EA11-2): time only, never the cost or the check. */
export function tinkererAnswer({ featNames = [] } = {}) {
  if (!featNames.some((n) => norm(n) === norm(FEATS.tinkerer))) return null;
  return { label: FEATS.tinkerer, ranks: TINKERER_RANKS, valueFactor: TINKERER_VALUE_FACTOR };
}

/** Days to finish, the arithmetic the core's Create uses (perDay = ranks × level × modifier), for the harness and the card. */
export function createDaysFor({ value = 0, ranks = 0, level = 1, modifier = 1, timeRanks = 0, valueFactor = 1 } = {}) {
  const perDay = Math.max(0, int(ranks) + int(timeRanks)) * Math.max(1, int(level)) * Math.max(0, Number(modifier) || 0);
  const target = Math.ceil(Math.max(0, Number(value) || 0) * (Number(valueFactor) > 0 && Number(valueFactor) <= 1 ? Number(valueFactor) : 1));
  return perDay > 0 ? Math.ceil(target / perDay) : Infinity;
}

/* ------------------------------------------------------------------ */
/* Mechanised Assistant                                                 */
/* ------------------------------------------------------------------ */

export const ASSISTANT_FLAG = "eaMechanised";
/** The printed companion profile. */
export const ASSISTANT_PROFILE = Object.freeze({
  size: "small",
  initiative: 15,
  speed: 20,
  senses: "Darkvision",
  abilities: Object.freeze({ strength: 0, dexterity: 1, constitution: 1, intelligence: 0, wisdom: 2, charisma: -2 }),
  db: 15,
  dbParts: Object.freeze({ bdb: 10, stat: 3, class: 2 }),
  dr: 2,
  classSkills: Object.freeze(["crafting", "perception"]),
  attack: Object.freeze({ name: "Slam (Small)", bonus: 1, damage: "1d6", damageType: "bludgeoning" })
});
/** The core's size table for Small (config.mjs SIZE_TABLE): Strength −1, Dexterity +1 are applied ON TOP of what is authored. */
export const SMALL_SIZE_MODS = Object.freeze({ strength: -1, dexterity: 1 });
/**
 * The scores to AUTHOR so the printed ones come out (the core familiar's own
 * round trip, familiar.mjs `familiarBaseAbilities`): printed − the size's mod.
 */
export function assistantBaseAbilities() {
  const a = ASSISTANT_PROFILE.abilities;
  return Object.freeze({ ...a, strength: a.strength - SMALL_SIZE_MODS.strength, dexterity: a.dexterity - SMALL_SIZE_MODS.dexterity });
}
export const ASSISTANT_SPECIALTIES = Object.freeze([
  ["toolArmature", "Tool Armature: +2 item bonus to your Crafting checks while it is adjacent to you"],
  ["injectorLimb", "Injector Limb: can deliver touch-range alchemical items or spells on your behalf"],
  ["scoutOptics", "Scout Optics: an additional sense, and Tracking as a class skill"],
  ["relayNode", "Spell Relay Node: the origin point for line- or area-based spells (within 60 ft and line of sight)"]
]);
export const TOOL_ARMATURE_BONUS = 2;
export const RELAY_NODE_FEET = 60;
/** The senses the core's abilities pack holds (Scent, Tremorsense); "another" is the GM's to add by hand. */
export const SCOUT_SENSES = Object.freeze(["Scent", "Tremorsense"]);
/** "At 4th level and then every 4 levels thereafter": how many improvements a master of this level has earned. */
export const assistantImprovements = (level) => Math.max(0, Math.floor(int(level) / 4));
/** The familiar abilities the feat names, plus its three own. */
export const ASSISTANT_FAMILIAR_CHOICES = Object.freeze([
  "Ability Enhancement", "Amphibious", "Burrower", "Climber", "Evasion", "Fast Movement", "Flier",
  "General Adeptness", "Improved Evasion", "Resilience", "Speak with Master", "Spell Battery", "Tough"
]);
export const ASSISTANT_OWN_CHOICES = Object.freeze([ASSISTANT_ABILITIES.frame, ASSISTANT_ABILITIES.storage, ASSISTANT_ABILITIES.reactive]);
/** "Ability Enhancement" may be taken more than once (core's familiar rule); the rest once. */
export const REPEATABLE_IMPROVEMENTS = Object.freeze(["Ability Enhancement"]);
export const STORAGE_LBS = 10;
export const REBUILD_HOURS = 8;

/** Is an improvement still open to this assistant? */
export function improvementOpen(name, taken = []) {
  if (REPEATABLE_IMPROVEMENTS.some((r) => norm(r) === norm(name))) return true;
  return !taken.some((t) => norm(t) === norm(name));
}

/** Storage: the weight of what it carries, and whether another item fits. */
export function storageFits(carried = [], add = 0) {
  const total = carried.reduce((s, w) => s + Math.max(0, Number(w) || 0), 0) + Math.max(0, Number(add) || 0);
  return total <= STORAGE_LBS + 1e-9;
}

/** Spell Relay Node: a line- or area-based spell. */
export function relayEligible(spellData = {}) {
  const area = norm(spellData.area);
  if (area && area !== "none" && area !== "—") return true;
  return traitList(spellData.traits).includes("line") || /\bline\b/.test(norm(spellData.range));
}

/** Injector Limb: a touch-range spell. */
export const isTouchSpell = (spellData = {}) => norm(spellData.range) === "touch" || norm(spellData.range).startsWith("touch");

/* ------------------------------------------------------------------ */
/* Runemage: Runic Anchor, Triggered Sigil, Grand Inscription           */
/* ------------------------------------------------------------------ */

export const RUNIC_ANCHOR_BONUS = 2;
export const SYMBOL_CASTS_FLAG = "eaSymbolCasts";
/** A Symbol cast is remembered for a day: a sustained spell or one recovered later still names its casting. */
export const SYMBOL_CAST_MEMORY_SECONDS = 86400;

/** Does this spell use a Symbol component when a Runemage casts it? (block6c's `usesSymbol`, kept in step.) */
export function usesSymbol(spellData = {}, { innate = false, runemage = true } = {}) {
  if (!runemage || innate || spellData?.innate) return false;
  const c = spellData?.components ?? {};
  return Boolean(c.verbal || c.material || c.focus);
}

/** Recent Symbol casts, those older than the memory dropped. */
export function liveSymbolCasts(map = {}, worldTime = 0) {
  return Object.entries(map ?? {})
    .filter(([, r]) => Number(worldTime) - Number(r?.at ?? -Infinity) <= SYMBOL_CAST_MEMORY_SECONDS)
    .map(([key, r]) => ({ key, ...r }));
}

export const TRIGGER_CHOICES = Object.freeze([
  ["struck", "Being struck (an attack hits you)"],
  ["targeted", "Becoming the target of an attack"],
  ["falling", "Falling"],
  ["fire", "Entering an area of fire"],
  ["other", "Another simple, observable trigger involving you"]
]);
/** Triggers the system can see; the rest are offered by the sigil's own Use (manual, with the same checks). */
export const DETECTED_TRIGGERS = Object.freeze(["struck", "targeted"]);
export const TRIGGERED_MAX_AP = 2;

/** "a normal casting time of 2 AP or less": `castAP` (default 2 when unset, the core's own default). */
export function spellCastAP(spellData = {}) {
  const raw = spellData.castAP;
  const n = Number(String(raw ?? "").match(/\d+/)?.[0]);
  return Number.isFinite(n) && n > 0 ? n : 2;
}

/**
 * "must be capable of legally targeting you or the creature responsible for
 * the trigger": a spell whose range is personal/self or touch or a distance,
 * and whose targets are a creature (or one/you). An area-only spell with no
 * creature target is refused (A11-9 names what is not decidable here).
 */
export function triggeredSpellEligible(spellData = {}) {
  if (spellCastAP(spellData) > TRIGGERED_MAX_AP) return { ok: false, reason: `its normal casting time is ${spellCastAP(spellData)} AP (2 AP or less)` };
  const range = norm(spellData.range);
  const targets = norm(spellData.targets);
  // A spell with no range, no targets and no area is the caster's own (the core
  // writes Shield and Mage Armour that way), and a touch spell can touch you
  // (found live, 0.18.1: Shield was refused).
  const area = norm(spellData.area);
  const blankSelf = !range && !targets && !area;
  const selfish = blankSelf || range.includes("touch") || ["self", "personal", "you"].some((w) => range.includes(w) || targets.includes(w));
  const creature = /creature|target|one |ally|enemy|foe|you/.test(targets) || /creature/.test(range);
  if (!selfish && !creature) return { ok: false, reason: "it cannot target you or a creature" };
  return { ok: true, reason: "" };
}

/**
 * TRIGGERED SIGIL IS DESIGNATED "DURING YOUR DAILY PREPARATION" (Graham's ruling
 * A11-9). Daily preparation is an hour (Core Rulebook p. 231: "Once every 24
 * hours, usually at the beginning of the day you spend an hour in
 * preparation"), so the window is: opened by daily preparation; closed by the
 * first spell cast, by combat, or an hour on.
 */
export const PREP_WINDOW_FLAG = "eaPrepWindow";
export const PREP_WINDOW_SECONDS = 3600;
export function prepWindowOpen(window, { worldTime = 0, inCombat = false } = {}) {
  if (!window || window.closed || inCombat) return false;
  const at = Number(window.at);
  return Number.isFinite(at) && worldTime >= at && worldTime - at <= PREP_WINDOW_SECONDS;
}

/** Grand Inscription: the save DC part that turns the Runemage's +1 into +2 (a Symbol cast only). */
export const GRAND_SAVE_DC_EXTRA = 1;
/** The identify bonus: the Runemage's +2 class becomes +4 (a replacement). */
export const RUNEMAGE_IDENTIFY_LABEL = "Runemage (runic symbols)";
export const GRAND_IDENTIFY_VALUE = 4;
export const RUNEMAGE_IDENTIFY_VALUE = 2;

/** The pending-modifier list with any queued Runemage identify bonus replaced (never stacked) by Grand Inscription's. */
export function grandIdentifyRewrite(pending = []) {
  let changed = false;
  const out = (Array.isArray(pending) ? pending : []).map((p) => {
    if (norm(p?.label) !== norm(RUNEMAGE_IDENTIFY_LABEL) || int(p?.value) >= GRAND_IDENTIFY_VALUE) return p;
    changed = true;
    return { ...p, value: GRAND_IDENTIFY_VALUE, label: `${RUNEMAGE_IDENTIFY_LABEL} — Grand Inscription`, scope: p.scope };
  });
  return { changed, pending: out };
}

/** Rewritten back to the Runemage's +2 when Grand Inscription is gone (removal, retraining). */
export function grandIdentifyRestore(pending = []) {
  let changed = false;
  const out = (Array.isArray(pending) ? pending : []).map((p) => {
    if (norm(p?.label) !== norm(`${RUNEMAGE_IDENTIFY_LABEL} — Grand Inscription`)) return p;
    changed = true;
    return { ...p, value: RUNEMAGE_IDENTIFY_VALUE, label: RUNEMAGE_IDENTIFY_LABEL };
  });
  return { changed, pending: out };
}

/* ------------------------------------------------------------------ */
/* Ascendan                                                             */
/* ------------------------------------------------------------------ */

export const LEY_RESONANCE_FEET = 60;
/** "reduce the casting cost of a spell by 1 PP"; Perfected Arcane Memory: "Your bonus from Ley Resonance increases to 2." */
export const leyResonancePP = (featNames = []) => (featNames.some((n) => norm(n) === norm(FEATS.memory)) ? 2 : 1);

/**
 * Its answer as a module metamagic (Block 6's G1): pay `pp` less, and the
 * casting DC falls with the PP ("the casting DC is also affected") —
 * `castingDC(pp) = 10 + ⌊1.5 × pp⌋` (core magic/casting.mjs) — while the Save
 * DC, read from the PP as cast, is left alone ("This does not affect any
 * associated Save DC"). Never below 1 PP paid.
 */
export function leyResonanceAnswer(castPP, reduction = 1) {
  const pp = Math.max(0, int(castPP));
  const off = Math.max(0, Math.min(int(reduction), pp - 1));
  if (!off) return null;
  const dc = (p) => 10 + Math.floor(p * 1.5);
  return { discount: { pp: off, floor: 1 }, dcDelta: dc(pp - off) - dc(pp), pp: off };
}

export const ARCANE_PREP_BONUS = 2;
export const ARCANE_PREP_TRADITIONS = Object.freeze(["arcane", "ethereal"]);
export const ARCANE_PREP_EFFECT = "eaArcanePreparation";
/** An arcane or ethereal spell. */
export function arcanePrepSpell(spellData = {}) {
  const t = traitList(spellData.tradition).concat(traitList(spellData.traits));
  return ARCANE_PREP_TRADITIONS.some((x) => t.includes(x));
}

/** Heritage of the First Weave: "a saving throw against a divine or verdant magical effect". */
export const FIRST_WEAVE_BONUS = 2;
const FIRST_WEAVE_TRADITIONS = Object.freeze(["divine", "divinity", "verdant"]);
export function firstWeaveWants(ctx = {}) {
  if (ctx.type !== "save") return false;
  const t = traitList(ctx.check?.traditions ?? ctx.traditions).concat(traitList(ctx.traits));
  return FIRST_WEAVE_TRADITIONS.some((x) => t.includes(x));
}

/** Perfected Arcane Memory: traces of arcane or ethereal spells ended within the previous 24 hours, DC +5. */
export const TRACE_SECONDS = 86400;
export const TRACE_DC_INCREASE = 5;
export const TRACES_SETTING = "eaSpellTraces";
export const MEMORY_SKILLS = Object.freeze(["arcana", "occultism"]);

/** The traces still readable at `worldTime`: arcane or ethereal, ended within 24 hours. */
export function readableTraces(traces = [], worldTime = 0) {
  return (Array.isArray(traces) ? traces : []).filter((t) =>
    ARCANE_PREP_TRADITIONS.includes(norm(t?.tradition))
    && Number.isFinite(Number(t?.endedAt))
    && Number(worldTime) - Number(t.endedAt) >= 0
    && Number(worldTime) - Number(t.endedAt) <= TRACE_SECONDS);
}

/** What an examination reveals, by degree. Never the caster; only what the trace recorded. */
export function traceReveals(trace = {}, degree = "", { worldTime = 0, from = null } = {}) {
  const d = norm(degree);
  if (!["success", "critical", "heroic"].includes(d)) return { identified: false };
  const out = { identified: true, spell: String(trace.spellName ?? ""), tradition: String(trace.tradition ?? "") };
  if (d === "critical" || d === "heroic") {
    if (Number.isFinite(Number(trace.castAt))) out.agoSeconds = Math.max(0, Number(worldTime) - Number(trace.castAt));
    if (from && trace.origin && Number.isFinite(Number(trace.origin.x)) && Number.isFinite(Number(trace.origin.y))) {
      out.direction = compassPoint(Number(trace.origin.x) - Number(from.x), Number(trace.origin.y) - Number(from.y));
    }
  }
  return out;
}

/** "the general direction": eight compass points on the canvas (north is up). */
export function compassPoint(dx, dy) {
  if (!dx && !dy) return "here";
  const deg = (Math.atan2(dx, -dy) * 180) / Math.PI;
  const points = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"];
  return points[(Math.round(((deg + 360) % 360) / 45)) % 8];
}

/** "approximately how long ago": the coarse phrase a residue supports. */
export function roughAgo(seconds) {
  const s = Math.max(0, Number(seconds) || 0);
  if (s < 600) return "minutes ago";
  if (s < 3600) return "within the hour";
  if (s < 6 * 3600) return "a few hours ago";
  if (s < 12 * 3600) return "about half a day ago";
  return "most of a day ago";
}
