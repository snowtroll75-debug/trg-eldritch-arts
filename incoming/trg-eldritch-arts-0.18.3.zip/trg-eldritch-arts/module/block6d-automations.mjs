/**
 * Eldritch Arts — Block 6 (0.9.0), group D: the metamagic and Adept class
 * feats, and the metamagic of the five feats Blocks 5 and 1 deferred here. On
 * TRG Prime 3.684.0.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md (Appendix D) as Graham
 * answered it on 4 November 2026: as proposed (Q94–Q96, Q126–Q133), one
 * release (Q89). The pure rules come first so the harness can run them; the
 * Foundry side follows.
 *
 *   G1 metamagic   Focused Spell, Lightning Rod, Pact Channeler, Sensory
 *                  Spell, Spellthread (+ Mastery, Unbound), Steelbinding,
 *                  Subconscious Casting (preset), Thunderclap Aura,
 *                  Unfettered Mastery, Versatile Binder; Echo of the
 *                  Ancestors, Resonant Pulse, Resonant Harmony, Spell Surge
 *   G5             Mana Bound (fumble modifier)
 *   G6             Conduit Mastery, Dual Channel, Metamagic Conduit,
 *                  Resonant Conduit, Weave Infusion (charged-item rules)
 *   G7             Subconscious Casting (unconscious offer)
 *   G9             Pact Channeler, Metamagic Conduit (eligibility)
 *   D7 remap       Spellthread's sidebar 15 (Partial→Failure, Failure→Fumble)
 *   Check reaction Arcane Fencer (G25: the weapon on the ctx)
 *   Use            Extra Cantrip
 *   Hooks          Lightning Rod's splash (spell settled) and its mark's end
 *                  (effect deleted); Piercing Insight (action resolved);
 *                  Resonant Conduit's day (daily preparation). A Spell Surge
 *                  copy made before 0.9.0 must be re-added from the
 *                  compendium to get its Focus use (nothing is rewritten).
 *
 * The hook handlers are exported for the lead to wire in
 * scripts/eldritch-arts.mjs; each says which `Hooks.on` event it expects.
 */
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, tokenOf, feetBetween } from "./block1-automations.mjs";
import { actsFor } from "./block3-automations.mjs";
import { allies } from "./block3b-automations.mjs";
import { heritageElement } from "./block5b-automations.mjs";
import { isBinding } from "./block8a-rules.mjs";
import { setBinderChoice } from "./block8a-automations.mjs";

/* ------------------------------------------------------------------ */
/* Keys and numbers                                                     */
/* ------------------------------------------------------------------ */

/** The metamagic keys (G1 lower-cases them; written lower-case so the hooks' `metamagic` lists match). */
export const MM = Object.freeze({
  focused: "focusedspell", lightningRod: "lightningrod", pact: "pactchanneler", sensory: "sensoryspell",
  thread: "spellthread", steel: "steelbinding", subconscious: "subconsciouscasting", thunderclap: "thunderclapaura",
  unfettered: "unfetteredmastery", binder: "versatilebinder",
  echo: "echooftheancestors", pulse: "resonantpulse", harmony: "resonantharmony", surge: "spellsurge"
});

export const FEAT = Object.freeze({
  fencer: "Arcane Fencer", conduitMastery: "Conduit Mastery", dualChannel: "Dual Channel", extraCantrip: "Extra Cantrip",
  focused: "Focused Spell", lightningRod: "Lightning Rod", manaBound: "Mana Bound", metamagicConduit: "Metamagic Conduit",
  pact: "Pact Channeler", resonantConduit: "Resonant Conduit", sensory: "Sensory Spell", thread: "Spellthread",
  threadMastery: "Spellthread Mastery", threadUnbound: "Spellthread Unbound", steel: "Steelbinding",
  subconscious: "Subconscious Casting", thunderclap: "Thunderclap Aura", unfettered: "Unfettered Mastery",
  binder: "Versatile Binder", weave: "Weave Infusion",
  echo: "Echo of the Ancestors", pulse: "Resonant Pulse", harmony: "Resonant Harmony", surge: "Spell Surge", piercing: "Piercing Insight"
});

export const FOCUSED_PP = 3;
export const LIGHTNING_ROD_PP = 2;
export const PACT_PP = 1;
export const SENSORY_PP = 1;
export const THREAD_PP = 2;
export const STEEL_PP = 2;
export const SUBCONSCIOUS_PP = 6;
export const THUNDERCLAP_PP = 2;
export const BINDER_PP = 1;
export const ECHO_PP = 2;
export const SURGE_PP = 1;
export const STEEL_FEET = 30;
export const THUNDERCLAP_FEET = 10;
export const SPLASH_FEET = 10;
export const MANA_BOUND_MODIFIER = -20;
export const SENSORY_BONUS = 2;
export const SENSORY_SKILLS = Object.freeze(["deception", "intimidate", "perform"]);
export const LIGHTNING_ROD_SAVE = -2;
/** Spellthread Mastery: "three spells instead of two" — woven spells beyond the first. */
export const threadCapacity = (mastery) => (mastery ? 2 : 1);

/** The seven Pact archetypes (Appendix A), and the patron each names. */
export const PACTS = Object.freeze({
  "Angelic Pact": "angelic", "Demonic Pact": "demonic", "Draconic Pact": "draconic", "Elemental Pact": "elemental",
  "Fey Pact": "fey", "Grave Pact": "grave", "Void Pact": "void"
});
/**
 * WHERE THE PACT'S CHOSEN TYPE IS READ (the cross-group contract with group A,
 * whose Use "chooses the energy (kept on the feat)"): the archetype item's
 * flags, under the system's scope or the module's, the first of these keys
 * set. Group A writes `eaEnergy` (Draconic Pact) and `eaElement` (Elemental
 * Pact, the element) under the system's scope; the rest are read in case.
 */
export const PACT_TYPE_FLAGS = Object.freeze(["eaEnergy", "eaElement", "eaPactType", "eaDragonType", "eaPactElement", "eaChosenType", "dragonType", "element"]);
/** Elemental Pact (Appendix A): air → electricity, earth → acid, fire → fire, water → cold. */
export const ELEMENT_ENERGY = Object.freeze({ air: "electricity", earth: "acid", fire: "fire", water: "cold" });
export const DRAGON_ENERGIES = Object.freeze(["acid", "cold", "electricity", "fire", "poison"]);

const SUCCESSES = Object.freeze(["heroic", "critical", "success"]);
const cap = (s) => String(s ?? "").charAt(0).toUpperCase() + String(s ?? "").slice(1);

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

/** A trait list ("Air, Evocation") holds this trait. */
export function hasTrait(traits, trait) {
  return String(traits ?? "").split(/[,;]/).map(norm).includes(norm(trait));
}

/** The first distance in a range or area text, in feet; Touch is 5; null when none. */
export function feetOf(text) {
  const t = norm(text);
  if (!t) return null;
  if (/^touch/.test(t)) return 5;
  const m = t.match(/(\d+)\s*(?:-|\s)?\s*(?:foot|feet|ft|’|')/);
  return m ? int(m[1]) : null;
}

/** A self-only spell: its range is Self and it has no area. */
export const selfOnly = (ctx = {}) => /^self\b/.test(norm(ctx.range)) && !norm(ctx.area);

/** The spell has a save (its defence names Fortitude, Reflex or Will). */
export const hasSave = (defence) => /fort|reflex|will/.test(norm(defence));

/** The spell deals damage (a damage formula or a damage type). */
export const damaging = (ctx = {}) => Boolean(String(ctx.spellData?.damage?.formula ?? "").trim() || (ctx.damageTypes ?? []).length);

/** The spell heals: a heal row, or the Healing category. */
export const heals = (spellData = {}) => norm(spellData?.category) === "healing" || Array.from(spellData?.effects ?? []).some((r) => norm(r?.kind) === "heal");

/**
 * Arcane Fencer's trigger: "You make a melee strike with a one-handed
 * weapon" — a weapon attack, melee, its weapon not Two-Handed by trait and
 * not held in two hands (the grip actually used, G25).
 */
export function fencerApplies(ctx = {}, weapon = null) {
  if (ctx.type !== "attack" || norm(ctx.attackMode) !== "melee" || !ctx.weaponUuid || ctx.twoHanded === true) return false;
  if (!weapon) return false;
  return !/\btwo-handed\b/i.test(String(weapon.system?.traits ?? ""));
}
/** "PP up to a maximum of your caster level", and no more than the pool holds. */
export const fencerMax = (casterLevel, pool) => Math.max(0, Math.min(int(casterLevel), int(pool)));
/** "+1-status bonus to your attack bonus" a PP. */
export const fencerModifiers = (pp) => (int(pp) > 0 ? [{ label: "Arcane Fencer", value: int(pp), type: "status" }] : []);

/** Conduit Mastery: −1 (minimum 1) on an activation; a Rod of the Magi's draw is not one (n6). */
export function conduitMasteryCost(ctx = {}) {
  if (norm(ctx.reason) === "ppsource") return null;
  return { reduction: 1, minimum: 1, label: "Conduit Mastery" };
}
/** Dual Channel: "If you fumble an activation check" — a release's Fumble or Blunder (Minor). */
export const dualChannelDue = (ctx = {}) => ctx.kind === "release" && ["fumble", "blunder"].includes(norm(ctx.degree));
/** Dual Channel: the released item's depletion is this rule's to roll only when its own spend took nothing (the core rolls an overspend). */
export const dualChannelRollsReleased = (ctx = {}) => ctx.paidBy === "wielder" || int(ctx.ppSpent) === 0;
/** Resonant Conduit: two or more wielded, the day's free activation unspent, not a PP draw. */
export const resonantConduitFree = (ctx = {}, spent = false) => !spent && Array.from(ctx.wielded ?? []).length >= 2 && norm(ctx.reason) !== "ppsource" && int(ctx.pp) > 0;

/** Mana Bound: "a Fumble on a Spellcraft check … does not affect Blunders or Chaos results". */
export function manaBoundModifier(ctx = {}) {
  if (ctx.blunder) return null;
  if (norm(ctx.check?.type) !== "spellcraft") return null;
  return { modifier: MANA_BOUND_MODIFIER, label: "Mana Bound", line: "Mana Bound: −20 circumstance to the Spell Fumble roll." };
}

/** Extra Cantrip: "no more than once every four levels" — why this copy may not be used, or "". */
export function extraCantripRefusal(copyIndex, level) {
  const allowed = Math.floor(int(level) / 4);
  return int(copyIndex) < allowed ? "" : `Extra Cantrip may be taken no more than once every four levels: at level ${int(level)}, ${allowed} cop${allowed === 1 ? "y" : "ies"}.`;
}

/** Does this cast deal electricity (printed, or Elemental Spell's type)? */
export const dealsElectricity = (damageTypes = [], elementalTypes = []) => damaging({ damageTypes }) && [...damageTypes, ...elementalTypes].map(norm).includes("electricity");

/** Lightning Rod's splash: "half the spell's damage dice", rounded down, of its primary pool. "" when none. */
export function splashDice(formula, extra = "") {
  const all = `${String(formula ?? "")} ${String(extra ?? "")}`;
  const terms = [...all.matchAll(/(\d+)\s*d\s*(\d+)/gi)];
  if (!terms.length) return "";
  const size = int(terms[0][2]);
  const count = terms.filter((t) => int(t[2]) === size).reduce((n, t) => n + int(t[1]), 0);
  const half = Math.floor(count / 2);
  return half > 0 ? `${half}d${size}` : "";
}

/** Thunderclap Aura: "1d6 electricity damage per 2 PP of the cast spell" (Q129: the total). "" under 2. */
export function thunderclapDice(totalPP) {
  const n = Math.floor(int(totalPP) / 2);
  return n > 0 ? `${n}d6` : "";
}

/** Pact Channeler's dice: "+2d6", "At level 14 … +4d6". */
export const pactDice = (level) => (int(level) >= 14 ? "4d6" : "2d6");
/** Fey: "–1 penalty on their Will save", "–2" from 14th. */
export const pactFeyPenalty = (level) => (int(level) >= 14 ? 2 : 1);

/**
 * A Pact archetype's patron and chosen type: `{ name, patron, energy, trait }`
 * or null. Draconic: the dragon's energy, its trait; Elemental: the element
 * (its trait) and the energy it maps to.
 */
export function pactOf(items = []) {
  const arch = Array.from(items ?? []).find((i) => i?.type === "feat" && PACTS[String(i.name ?? "").trim()]);
  if (!arch) return null;
  const patron = PACTS[String(arch.name).trim()];
  const flags = { ...(arch.flags?.[MODULE_ID] ?? {}), ...(arch.flags?.[SYSTEM_ID] ?? {}) };
  const chosen = norm(PACT_TYPE_FLAGS.map((k) => flags[k]).find((v) => norm(v)));
  if (patron === "draconic") return DRAGON_ENERGIES.includes(chosen) ? { name: arch.name, patron, energy: chosen, trait: cap(chosen) } : { name: arch.name, patron, energy: "", trait: "" };
  if (patron === "elemental") {
    const element = ELEMENT_ENERGY[chosen] ? chosen : Object.keys(ELEMENT_ENERGY).find((e) => ELEMENT_ENERGY[e] === chosen) ?? "";
    return element ? { name: arch.name, patron, energy: ELEMENT_ENERGY[element], trait: cap(element) } : { name: arch.name, patron, energy: "", trait: "" };
  }
  return { name: arch.name, patron, energy: "", trait: "" };
}

/** May Pact Channeler be offered for this patron (Draconic and Elemental need their type chosen)? */
export const pactReady = (pact) => Boolean(pact) && (!["draconic", "elemental"].includes(pact.patron) || Boolean(pact.energy));

/**
 * PACT CHANNELER'S CHANNEL, as a G1 answer (n4). `ctx`: the cast's
 * (`damageTypes` effective, `defence`, `spellData`).
 */
export function pactAnswer(pact, ctx = {}, level = 0) {
  if (!pactReady(pact)) return { cancel: true, reason: "your Pact's type is not chosen yet" };
  const dice = pactDice(level);
  const types = (ctx.damageTypes ?? []).map(norm);
  switch (pact.patron) {
    case "angelic":
      return { addTraits: ["Healing"], ...(heals(ctx.spellData) ? { mods: { healDice: dice } } : {}), lines: [`Pact Channeler (Angelic): the spell gains the Healing trait${heals(ctx.spellData) ? `, and heals ${dice} more` : ""}.`] };
    case "demonic":
      return { addTraits: ["Fire"], ...(damaging(ctx) ? { addedDamage: [{ dice, type: "fire", label: "Pact Channeler" }] } : {}), lines: [`Pact Channeler (Demonic): the spell gains the Fire trait${damaging(ctx) ? `, and deals ${dice} fire more` : ""}.`] };
    case "grave":
      return { addTraits: ["Essence"], ...(damaging(ctx) ? { addedDamage: [{ dice, type: "essence", label: "Pact Channeler" }] } : {}), lines: [`Pact Channeler (Grave): the spell gains the Essence trait${damaging(ctx) ? `, and deals ${dice} essence more` : ""}.`] };
    case "draconic":
    case "elemental": {
      const mods = types[0] === pact.energy ? { damageDice: dice } : types[1] === pact.energy ? { secondaryDice: dice } : null;
      return { addTraits: [pact.trait], ...(mods ? { mods } : {}), lines: [`Pact Channeler (${cap(pact.patron)}): the spell gains the ${pact.trait} trait${mods ? `, and its ${pact.energy} pool ${dice} more` : ""}.`] };
    }
    case "fey": {
      const will = /will/.test(norm(ctx.defence));
      const value = pactFeyPenalty(level);
      return { addTraits: ["Enchantment"], ...(will ? { saveDC: [{ value, type: "untyped", label: "Pact Channeler (Fey)" }] } : {}), lines: [`Pact Channeler (Fey): the spell gains the Enchantment trait${will ? `; its targets take −${value} on their Will save` : ""}.`] };
    }
    case "void":
      return { addTraits: ["Mental"], lines: ["Pact Channeler (Void): the spell gains the Mental trait; each target makes a Will save once it is cast."] };
    default:
      return { cancel: true, reason: "no patron" };
  }
}

/** Spell Surge's four, offered where they can apply (n8): `[value, label]`. */
export function surgeChoices(ctx = {}) {
  const out = [];
  const rangeFeet = feetOf(ctx.range);
  if (rangeFeet && !/^touch/.test(norm(ctx.range))) out.push({ value: "range", label: "Range +50%" });
  if (/\d+\s*(round|minute|hour|day|week)/i.test(String(ctx.duration ?? "")) && !/instant|permanent|sustain/i.test(String(ctx.duration ?? ""))) out.push({ value: "duration", label: "Duration +50%" });
  if (hasSave(ctx.defence)) out.push({ value: "save", label: "+2 class bonus to the Save DC" });
  if (/\d+\s*d\s*\d+/i.test(String(ctx.spellData?.damage?.formula ?? ""))) out.push({ value: "damage", label: "+1 die of damage" });
  return out;
}
/** Spell Surge's answer: the surge, and "that spell's Spell Fumble or Resonance … at disadvantage". */
export function surgeAnswer(choice, ctx = {}) {
  const base = { fumbleBias: "disadvantage", resonanceBias: "disadvantage" };
  switch (choice) {
    case "range": return { ...base, rangeFactor: 1.5, lines: ["Spell Surge: range +50%."] };
    case "duration": return { ...base, durationFactor: 1.5, lines: ["Spell Surge: duration +50%."] };
    case "save": return { ...base, saveDC: [{ value: 2, type: "class", label: "Spell Surge" }], lines: ["Spell Surge: +2 class bonus to the Save DC."] };
    case "damage": {
      const m = String(ctx.spellData?.damage?.formula ?? "").match(/(\d+)\s*d\s*(\d+)/i);
      return m ? { ...base, mods: { damageDice: `1d${int(m[2])}` }, lines: [`Spell Surge: +1d${int(m[2])} damage.`] } : { cancel: true, reason: "the spell has no damage dice" };
    }
    default: return { cancel: true, reason: "no surge chosen" };
  }
}

/**
 * Spellthread's woven spells (Q126): their base PP join the base, the
 * casting takes the longer time, sidebar 15's saving step and disadvantage.
 */
export function threadAnswer(woven = [], primaryAP = 0) {
  const basePPAdd = woven.reduce((n, s) => n + Math.max(0, int(s?.system?.ppCost)), 0);
  const longest = Math.max(int(primaryAP), ...woven.map((s) => int(s?.system?.castAP)));
  return {
    basePPAdd, apDelta: Math.max(0, longest - int(primaryAP)), savingStep: 1, fumbleBias: "disadvantage", resonanceBias: "disadvantage",
    lines: [`Spellthread: ${woven.map((s) => s.name).join(" and ")} woven in (+${basePPAdd} base PP${longest > int(primaryAP) ? `, ${longest} AP to cast` : ""}); a Heroic saves half the base PP and a Critical none; Spell Fumble and Resonance at disadvantage.`]
  };
}
/** Sidebar 15: "On a partial success, treat the result as a failure. On a failure, treat it as a fumble." */
export function threadRemap(ctx = {}) {
  if (ctx.threaded || !Array.from(ctx.metamagic ?? []).map(norm).includes(MM.thread)) return null;
  const d = norm(ctx.degree);
  if (d === "partial") return { degree: "failure", lines: ["Spellthread: a Partial is treated as a Failure (sidebar 15)."] };
  if (d === "failure") return { degree: "fumble", lines: ["Spellthread: a Failure is treated as a Fumble (sidebar 15)."] };
  return null;
}
/** Two spells "share the same tradition" (any one in common); Unbound lifts it. */
export function sameTradition(a, b) {
  const split = (t) => String(t ?? "").split(/[,;/|]|\bor\b/).map(norm).filter(Boolean);
  const x = split(a), y = split(b);
  return x.some((t) => y.includes(t));
}

/** Steelbinding's ladder (m42: Heroic as Critical, Partial and Fumble as Failure). */
export function steelTags(degree, { inCombat = false, round = 0, worldTime = 0 } = {}) {
  const d = norm(degree);
  const clock = inCombat ? { expiresRound: int(round) + 2 } : { expiresTime: Math.trunc(Number(worldTime) || 0) + 6 };
  if (d === "heroic" || d === "critical") return [];
  if (d === "success") return [{ key: "slowed", value: 1, ...clock }];
  return [{ key: "immobilised", ...clock }];
}
/** Does this creature wear metal armour? Equipped armour with the Metal trait, as the core tests it (attack-riders `wearsMetalArmour`). */
export const wearsMetalArmour = (items = []) => Array.from(items ?? []).some((i) => i?.type === "armour" && i.system?.equipped && /\bmetal\b/i.test(String(i.system?.traits ?? "")));

/** Lightning Rod's −2 on the marked creature's save against an electricity-trait spell (Q127). */
export function lightningRodConditionals(metalArmour) {
  return [{
    kind: "modifier", value: LIGHTNING_ROD_SAVE, type: "untyped", label: "Lightning Rod",
    scope: metalArmour ? "Your save against a spell with the electricity trait (marked, in metal armour)" : "Your save against a spell with the electricity trait — tick if you are holding metal",
    auto: Boolean(metalArmour), oneShot: true, when: { checkTypes: ["save"], traits: ["electricity"] }
  }];
}
/** Sensory Spell's +2 on the next Deception, Intimidate or Perform check. */
export function sensoryConditionals() {
  return [{ kind: "modifier", value: SENSORY_BONUS, type: "untyped", label: "Sensory Spell", scope: "your next Deception, Intimidate or Perform check this turn", auto: true, oneShot: true, when: { checkTypes: ["skill"], subjects: [...SENSORY_SKILLS] } }];
}

/**
 * YOUR SPELL'S SAVE DC for a rider rolled after the cast (Steelbinding,
 * Thunderclap Aura, Void, Versatile Binder): the core's spellSaveDC — 10 +
 * the PP the spell was cast at + your magical ability — and High Magic's +2;
 * an innate cast's own save DC (G25). The settled facts carry no save DC, so
 * effect-declared Save DC bonuses are not in it (said on the cards' lines).
 */
export function castSaveDC({ totalPP = 0, ability = 0, highMagic = false, innateDC = null } = {}) {
  if (innateDC !== null && innateDC !== undefined && Number.isFinite(Number(innateDC))) return int(innateDC);
  return 10 + Math.max(0, int(totalPP)) + int(ability) + (highMagic ? 2 : 0);
}

/** Discount-only options Piercing Insight never offers (they change no effect). */
export const PIERCING_LEFT_OUT = new Set(["leyetchedsymbol", "easpellweaverdiscount"]);

/** What a metamagic option changes on Sense Magic (Piercing Insight's card). */
export const SENSE_EFFECTS = Object.freeze({
  reach: "range ×2", widen: "area ×2", extend: "duration ×2", distant: "range increased", quicken: "1 AP less",
  silent: "no verbal component", still: "no somatic component", selective: "creatures excluded",
  empower: "numbers ×1.5", intensify: "effect intensified", lingering: "lingers", temporal: "duration extended"
});

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const featOf = (actor, name) => Array.from(actor?.items ?? []).find((i) => i?.type === "feat" && norm(i.name) === norm(name)) ?? null;
const has = (actor, name) => Boolean(featOf(actor, name));
function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
const poolOf = (actor) => int(actor?.system?.resources?.pp?.value);
const elementalTypesOf = (actor) => Array.from(actor?.appliedEffects ?? actor?.effects ?? []).filter((e) => !e?.disabled)
  .map((e) => norm(e.flags?.[SYSTEM_ID]?.elementalSpellType)).filter(Boolean);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const targetIds = (ctx) => new Set(Array.from(ctx.targets ?? []).map((t) => t?.id).filter(Boolean));
const uuidOf = (t) => String(t?.document?.uuid ?? t?.uuid ?? "");
async function saveDCFor(actor, ctx = {}) {
  // THE CAST'S OWN SAVE DC (TRG Prime 3.684.0, review): every bonus in. The
  // rebuilt formula is the fallback for a core that does not pass it.
  if (ctx.saveDC !== null && ctx.saveDC !== undefined && Number.isFinite(Number(ctx.saveDC)) && Number(ctx.saveDC) > 0) return int(ctx.saveDC);
  const innateDC = ctx.innate ? (await h().innateSaveDCFor?.(actor, ctx.spell))?.value ?? null : null;
  return castSaveDC({ totalPP: ctx.totalPP ?? ctx.basePP, ability: actor?.system?.magic?.spellcraft?.ability, highMagic: ctx.highMagic, innateDC });
}
const clockNow = (actor) => {
  const c = combatFor(actor) ?? (globalThis.game?.combat?.started ? game.combat : null);
  return { inCombat: Boolean(c), round: int(c?.round), worldTime: Number(globalThis.game?.time?.worldTime ?? 0) };
};
const fromUuidAsync = async (uuid) => (uuid ? (globalThis.fromUuid ? await globalThis.fromUuid(uuid) : await globalThis.foundry?.utils?.fromUuid?.(uuid)) : null);

/** A few boxes to tick, through the core's own dialog. Resolves the ticked values, or null when closed. */
async function tickMany(title, intro, options) {
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2?.prompt) return null;
  const form = await DialogV2.prompt({
    window: { title }, classes: ["trg-prime", "trg-check-dialog"],
    content: `<p>${intro}</p>${options.map(([v, l]) => `<div class="form-group"><label><input type="checkbox" name="pick-${esc(v)}" value="1"> ${l}</label></div>`).join("")}`,
    ok: { label: "Apply", callback: (event, button) => new (globalThis.foundry.applications.ux.FormDataExtended)(button.form).object },
    rejectClose: false
  });
  if (!form) return null;
  return options.map(([v]) => v).filter((v) => form[`pick-${v}`]);
}
/** A number, through the core's own dialog; null when closed. */
async function askNumber(title, intro, max) {
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2?.prompt) return null;
  const form = await DialogV2.prompt({
    window: { title }, classes: ["trg-prime", "trg-check-dialog"],
    content: `<p>${intro}</p><div class="form-group"><label>PP</label><input type="number" name="pp" value="0" min="0" max="${max}" step="1"></div>`,
    ok: { label: "Strike", callback: (event, button) => new (globalThis.foundry.applications.ux.FormDataExtended)(button.form).object },
    rejectClose: false
  });
  return form ? Math.max(0, Math.min(int(max), int(form.pp))) : null;
}

/* ------------------------------------------------------------------ */
/* G1: the metamagic options                                            */
/* ------------------------------------------------------------------ */

async function pickToken(title, prompt, list) {
  if (!list.length) return null;
  const picked = await h().chooseFromList(title, prompt, list.map((t) => [t.id, esc(t.name)]));
  return list.find((t) => t.id === picked) ?? null;
}

/** Creatures within the spell's range of the caster, not already targeted (Echo, Versatile Binder). */
function untargetedWithin(actor, ctx) {
  const me = tokenOf(actor);
  const range = feetOf(ctx.range);
  const chosen = targetIds(ctx);
  return tokens().filter((t) => t !== me && t.actor !== actor && !chosen.has(t.id) && (range === null || !me || (feetBetween(me, t) ?? Infinity) <= range));
}

const focusedSpell = {
  feat: FEAT.focused, label: "Focused Spell", hint: "advantage on the Spellcraft check", ppCost: FOCUSED_PP,
  scope: { innate: false, item: false },
  applies: (ctx) => Boolean(ctx.rollsCheck) && !ctx.itemCast && !ctx.innate,
  effects: { checkBias: "advantage", lines: ["Focused Spell: advantage on the casting check."] }
};

const lightningRod = {
  feat: FEAT.lightningRod, label: "Lightning Rod", hint: "mark a creature the spell hits", ppCost: LIGHTNING_ROD_PP,
  applies: (ctx) => dealsElectricity(ctx.damageTypes, elementalTypesOf(ctx.actor)),
  // OFFERED ON ELEMENTAL SPELL'S ELECTRICITY, which may not be ticked: then
  // the cast goes on and the option says why it does nothing (review).
  apply: (ctx) => (dealsElectricity(ctx.damageTypes)
    ? { lines: ["Lightning Rod: choose a creature the spell hits once it is cast."] }
    : { lines: ["Lightning Rod: this cast deals no electricity damage (Elemental Spell's electricity was not taken), so nothing will be marked."] }),
  after: (ctx) => lightningRodAfter(ctx)
};

const pactChanneler = {
  feat: FEAT.pact, label: "Pact Channeler", hint: "your patron's channel", ppCost: PACT_PP,
  applies: (ctx) => pactReady(pactOf(ctx.actor?.items)),
  apply: (ctx) => pactAnswer(pactOf(ctx.actor?.items), ctx, levelOf(ctx.actor)),
  after: (ctx) => (pactOf(ctx.actor?.items)?.patron === "void" ? voidAfter(ctx) : null)
};

const sensorySpell = {
  feat: FEAT.sensory, label: "Sensory Spell", hint: "describe the change; +2 on Deception, Intimidate or Perform", ppCost: SENSORY_PP,
  effects: { lines: ["Sensory Spell: the change is cosmetic — describe it."] },
  after: (ctx) => sensoryAfter(ctx)
};

const spellthread = {
  feat: FEAT.thread, label: "Spellthread", hint: "weave another spell into this one", ppCost: THREAD_PP, needsSpell: true,
  scope: { innate: false, item: false },
  applies: (ctx) => !ctx.innate && !ctx.itemCast && !ctx.ritual && !ctx.reaction,
  apply: (ctx) => threadApply(ctx),
  after: (ctx) => threadAfter(ctx)
};

const steelbinding = {
  feat: FEAT.steel, label: "Steelbinding", hint: "a target within 30 ft in metal armour: Fortitude or bound", ppCost: STEEL_PP,
  applies: (ctx) => steelCandidates(ctx.actor, ctx).length > 0,
  effects: { lines: ["Steelbinding: the target in metal armour saves once the spell is cast."] },
  after: (ctx) => steelAfter(ctx)
};

const subconsciousCasting = {
  feat: FEAT.subconscious, label: "Subconscious Casting", hint: "+6 PP, cast as you fall", ppCost: SUBCONSCIOUS_PP, preset: true,
  effects: { lines: ["Subconscious Casting: cast as a 0 AP action as you would fall unconscious."] }
};

const thunderclapAura = {
  feat: FEAT.thunderclap, label: "Thunderclap Aura", hint: "a 10-ft shockwave of electricity", ppCost: THUNDERCLAP_PP,
  applies: (ctx) => hasTrait(ctx.traits, "air") || hasTrait(ctx.traits, "electricity"),
  after: (ctx) => thunderclapAfter(ctx)
};

const unfetteredMastery = {
  feat: FEAT.unfettered, label: "Unfettered Mastery", hint: "1 AP less, as Quicken Spell", ppCost: 0, focus: true, kind: "quicken",
  applies: (ctx) => Boolean(ctx.highMagic) && int(ctx.castAP) > 1,
  effects: { lines: ["Unfettered Mastery: cast as if Quickened (1 AP less)."] }
};

const versatileBinder = {
  feat: FEAT.binder, label: "Versatile Binder", hint: "bind a creature already here", ppCost: BINDER_PP,
  applies: (ctx) => hasTrait(ctx.traits, "summons"),
  apply: (ctx) => binderApply(ctx),
  after: (ctx) => binderAfter(ctx)
};

const echoOfTheAncestors = {
  feat: FEAT.echo, label: "Echo of the Ancestors", hint: "a second creature at half damage", ppCost: ECHO_PP, focus: true, needsSpell: true,
  applies: (ctx) => {
    const element = heritageElement(ctx.actor?.items);
    return Boolean(element) && damaging(ctx) && [...(ctx.damageTypes ?? []).slice(0, 1), ...elementalTypesOf(ctx.actor)].map(norm).includes(element);
  },
  apply: (ctx) => echoApply(ctx)
};

const resonantPulse = {
  feat: FEAT.pulse, label: "Resonant Pulse", hint: "Save DC +1", ppCost: 0, focus: true,
  applies: (ctx) => hasSave(ctx.defence),
  effects: { saveDC: [{ value: 1, type: "untyped", label: "Resonant Pulse" }], lines: ["Resonant Pulse: Save DC +1."] }
};

const resonantHarmony = {
  feat: FEAT.harmony, label: "Resonant Harmony", hint: "an adjacent ally shares the effect", ppCost: 0, focus: true, needsSpell: true,
  applies: (ctx) => selfOnly(ctx),
  apply: (ctx) => harmonyApply(ctx)
};

const spellSurge = {
  feat: FEAT.surge, label: "Spell Surge", hint: "one surge; fumble and Resonance at disadvantage", ppCost: SURGE_PP, focus: true,
  applies: (ctx) => surgeChoices(ctx).length > 0,
  choices: (ctx) => surgeChoices(ctx).map((c) => ({ ...c, ppCost: SURGE_PP })),
  apply: (ctx) => surgeAnswer(ctx.choice, ctx)
};

export const METAMAGIC_B6_D = Object.freeze({
  [MM.focused]: focusedSpell, [MM.lightningRod]: lightningRod, [MM.pact]: pactChanneler, [MM.sensory]: sensorySpell,
  [MM.thread]: spellthread, [MM.steel]: steelbinding, [MM.subconscious]: subconsciousCasting, [MM.thunderclap]: thunderclapAura,
  [MM.unfettered]: unfetteredMastery, [MM.binder]: versatileBinder,
  [MM.echo]: echoOfTheAncestors, [MM.pulse]: resonantPulse, [MM.harmony]: resonantHarmony, [MM.surge]: spellSurge
});

/* ---- Echo, Harmony ---- */

async function echoApply(ctx) {
  const element = heritageElement(ctx.actor?.items);
  // OFFERED ON ELEMENTAL SPELL'S TYPE, which may not be ticked: then the cast
  // goes on and the echo says why it does nothing (review).
  if (!(ctx.damageTypes ?? []).slice(0, 1).map(norm).includes(element)) return { lines: [`Echo of the Ancestors: this cast's damage is not ${element} (Elemental Spell's ${element} was not taken), so there is no echo.`] };
  const t = await pickToken("Echo of the Ancestors", "Choose the second creature, within the spell's range and not already affected: it is affected at half damage.", untargetedWithin(ctx.actor, ctx));
  if (!t) return { cancel: true, reason: "Echo of the Ancestors: no second creature chosen" };
  return { targets: { extra: [{ tokenUuid: uuidOf(t), damageFactor: 0.5, label: "Echo of the Ancestors" }] }, lines: [`Echo of the Ancestors: ${esc(t.name)} is affected too, at half damage (rounded down).`] };
}

async function harmonyApply(ctx) {
  const me = tokenOf(ctx.actor);
  if (!me) return { cancel: true, reason: "Resonant Harmony: place your token on the map first" };
  const near = tokens().filter((t) => t !== me && t.actor !== ctx.actor && allies(t.document?.disposition, me.document?.disposition) && (feetBetween(me, t) ?? Infinity) <= 5);
  const t = await pickToken("Resonant Harmony", "Choose the adjacent ally who receives the same effect.", near);
  if (!t) return { cancel: true, reason: "Resonant Harmony: no adjacent ally chosen" };
  return { targets: { share: [{ tokenUuid: uuidOf(t) }] }, lines: [`Resonant Harmony: ${esc(t.name)} receives the same effect.`] };
}

/* ---- Lightning Rod ---- */

/** The casts whose splash a Lightning Rod `after` has already dealt with (the settled hook follows it). */
const LIGHTNING_HANDLED = new WeakSet();
export const LIGHTNING_MARK = "lightningRodMark";
export const LIGHTNING_MARKED = "lightningRodMarked";

const casterMark = (actor) => ownEffects(actor, LIGHTNING_MARK)[0] ?? null;

/** Delete an effect only while it still exists (another client or hook may have taken it). */
async function deleteIfPresent(effect) {
  if (!effect?.delete) return;
  const coll = effect.parent?.effects;
  if (typeof coll?.get === "function" && !coll.get(effect.id)) return;
  try { await effect.delete(); } catch (err) { if (!/does not exist/i.test(String(err?.message ?? err))) throw err; }
}

async function endMark(mark) {
  if (!mark) return;
  // THE MARKED CREATURE'S EFFECT FIRST (0.9.2, live test): deleting the
  // caster's mark fires onEffectDeletedB6D, which deletes the same effect;
  // the second delete threw, and the splash's card was never posted.
  const target = await fromUuidAsync(mark.flags?.[MODULE_ID]?.markedEffect);
  await deleteIfPresent(target);
  await deleteIfPresent(mark);
}

/** The splash of a marked creature, for a cast with the electricity trait. Plain lines (the caller wraps them). */
async function lightningSplash(actor, ctx, mark) {
  const lines = [];
  const markedToken = tokens().find((t) => uuidOf(t) === mark.flags?.[MODULE_ID]?.markedToken || t.actor?.uuid === mark.flags?.[MODULE_ID]?.markedActor);
  const dice = splashDice(ctx.spellData?.damage?.formula, ctx.warpMods?.damageDice);
  if (!dice) lines.push(`Lightning Rod: ${esc(ctx.spell?.name ?? "the spell")} rolls no damage dice — no splash.`);
  else if (!markedToken) lines.push("Lightning Rod: the marked creature is not on the map — no splash.");
  else {
    const me = tokenOf(actor);
    const enemies = tokens().filter((t) => t !== markedToken && t.actor !== actor && !allies(t.document?.disposition, me?.document?.disposition ?? 1) && (feetBetween(markedToken, t) ?? Infinity) <= SPLASH_FEET);
    if (!enemies.length) lines.push(`Lightning Rod: no enemy within ${SPLASH_FEET} feet of ${esc(markedToken.name)}.`);
    else {
      const roll = await new Roll(dice).evaluate();
      lines.push(`Lightning Rod: ${esc(markedToken.name)} conducts — <strong>${int(roll.total)}</strong> electricity (${dice}, half the dice, no save) to each enemy within ${SPLASH_FEET} feet.`);
      for (const t of enemies) {
        await h().applyTypedDamage(t.actor, { amount: int(roll.total), type: "electricity", sourceName: "Lightning Rod", sourceUuid: actor.uuid });
        lines.push(`${esc(t.name)}: ${int(roll.total)} electricity.`);
      }
    }
  }
  await endMark(mark);
  return lines;
}

async function lightningRodAfter(ctx) {
  const actor = ctx.actor;
  if (ctx.spellData) LIGHTNING_HANDLED.add(ctx.spellData);
  const lines = [];
  const electric = dealsElectricity(ctx.damageTypes ?? [ctx.spellData?.damage?.type, ctx.warpMods?.damageType].filter(Boolean));
  // An old mark is answered first by this cast, if it has the electricity trait.
  const old = casterMark(actor);
  if (old && ctx.cast && hasTrait(ctx.spellData?.traits, "electricity")) lines.push(...(await lightningSplash(actor, ctx, old)));
  if (!ctx.cast) return { lines: [...lines, "Lightning Rod: the spell did not go off — nothing is marked."] };
  if (!electric) return { lines: [...lines, "Lightning Rod: the spell dealt no electricity damage — nothing is marked."] };
  const hit = [...Array.from(ctx.spellHits ?? []).map((r) => r.target), ...Array.from(ctx.saveResults ?? []).map((r) => r.target)].filter(Boolean);
  const list = tokens().filter((t) => hit.includes(t.actor));
  const t = await pickToken("Lightning Rod", "Mark a creature the spell hit (one that took its electricity damage).", list);
  if (!t) return { lines: [...lines, "Lightning Rod: no creature marked."] };
  await endMark(casterMark(actor));
  const metal = wearsMetalArmour(t.actor.items);
  const expiry = expiryFor("endOfNextTurn", actor);
  const [marked] = await h().createEffectsOn(t.actor, [effectData(LIGHTNING_MARKED, {
    name: "Lightning Rod (marked)", img: "icons/svg/lightning.svg",
    description: `Marked by ${actor.name}'s Lightning Rod: −2 on your save against a spell with the electricity trait.`,
    system: { conditionals: lightningRodConditionals(metal) }, module: { caster: actor.uuid }, expiry
  })]) ?? [];
  await h().createEffectsOn(actor, [effectData(LIGHTNING_MARK, {
    name: `Lightning Rod: ${t.name} marked`, img: "icons/svg/lightning.svg",
    description: `Your next spell with the electricity trait before the end of your next turn splashes the enemies within ${SPLASH_FEET} feet of ${t.name}.`,
    module: { markedToken: uuidOf(t), markedActor: t.actor.uuid, markedEffect: marked?.uuid ?? "" }, expiry
  })]);
  return { lines: [...lines, `Lightning Rod: <strong>${esc(t.name)}</strong> is marked until the end of your next turn${metal ? " (in metal armour: −2 on its save against your next electricity spell)" : ""}.`] };
}

/* ---- Pact Channeler's Void ---- */

async function voidAfter(ctx) {
  if (!ctx.cast) return null;
  const targets = Array.from(ctx.targets ?? []).map((t) => t?.actor).filter((a) => a && a !== ctx.actor);
  if (!targets.length) return { lines: ["Pact Channeler (Void): no target to save."] };
  const dc = await saveDCFor(ctx.actor, ctx);
  const flat = [{ key: "flatFooted", rounds: 1 }];
  const out = await h().runAreaEffect(ctx.actor, {
    save: "will", dc, scope: "targets",
    intro: `Pact Channeler (Void): Will save against DC ${dc}; on a failure, Flat-Footed until the start of your next turn.`,
    outcomes: { heroic: "No effect.", critical: "No effect.", success: "No effect.", failure: "Flat-Footed until the start of your next turn.", fumble: "Flat-Footed until the start of your next turn." },
    conditions: { failure: flat, fumble: flat }
  }, { title: "Pact Channeler (Void)", targets });
  return { lines: out ?? [] };
}

/* ---- Sensory Spell ---- */

async function sensoryAfter(ctx) {
  if (!ctx.cast) return null;
  await h().createEffectsOn(ctx.actor, [effectData("sensorySpell", {
    name: `Sensory Spell (+${SENSORY_BONUS})`, img: "icons/svg/sound.svg",
    description: `+${SENSORY_BONUS} to your next Deception, Intimidate or Perform check this turn.`,
    system: { conditionals: sensoryConditionals() }, expiry: expiryFor("endOfTurn", ctx.actor)
  })]);
  return { lines: [`Sensory Spell: +${SENSORY_BONUS} on your next Deception, Intimidate or Perform check this turn.`] };
}

/* ---- Spellthread ---- */

async function threadApply(ctx) {
  const actor = ctx.actor;
  const unbound = has(actor, FEAT.threadUnbound);
  const room = threadCapacity(has(actor, FEAT.threadMastery));
  const primary = ctx.spell;
  const pool = [];
  for (const s of Array.from(actor?.items ?? [])) {
    if (s?.type !== "spell" || s === primary || s.id === primary?.id || s.system?.innate || int(s.system?.ppCost) <= 0) continue;
    if (!unbound && !sameTradition(s.system?.tradition, ctx.spellData?.tradition ?? ctx.tradition)) continue;
    if (h().spellCastable && !(await h().spellCastable(actor, s))) continue;
    pool.push(s);
  }
  if (!pool.length) return { cancel: true, reason: `Spellthread: no other spell ${unbound ? "" : "of this tradition "}you can cast now` };
  const woven = [];
  for (let i = 0; i < room; i += 1) {
    const left = pool.filter((s) => !woven.includes(s));
    if (!left.length) break;
    const picked = await h().chooseFromList("Spellthread", i ? "Weave a third spell into it (Spellthread Mastery)? Cancel to weave two." : "Choose the spell to weave into this one.", left.map((s) => [s.id, `${esc(s.name)} (${int(s.system?.ppCost)} PP)`]));
    const spell = left.find((s) => s.id === picked);
    if (!spell) break;
    woven.push(spell);
  }
  if (!woven.length) return { cancel: true, reason: "Spellthread: no spell woven" };
  ctx.eaWoven = woven.map((s) => s.id);
  return threadAnswer(woven, ctx.castAP);
}

async function threadAfter(ctx) {
  const ids = Array.isArray(ctx.eaWoven) ? ctx.eaWoven : [];
  if (!ids.length) return null;
  if (!ctx.cast || ctx.refunded || !SUCCESSES.includes(norm(ctx.degree))) return { lines: ["Spellthread: the weave did not hold — the woven spells do not resolve."] };
  const lines = [];
  for (const id of ids) {
    const spell = ctx.actor?.items?.get?.(id);
    if (!spell) continue;
    await h().castSpell(ctx.actor, spell, { thread: { check: ctx.check, degree: norm(ctx.degree), primaryUuid: ctx.spell?.uuid ?? "" } });
    lines.push(`Spellthread: ${esc(spell.name)} resolves, woven into ${esc(ctx.spell?.name ?? "the spell")} (${norm(ctx.degree)}).`);
  }
  lines.push("Spellthread: one concentration check covers the weave — the GM's.");
  return { lines };
}

/* ---- Steelbinding ---- */

function steelCandidates(actor, ctx) {
  const me = tokenOf(actor);
  return Array.from(ctx.targets ?? []).filter((t) => t?.actor && t.actor !== actor && wearsMetalArmour(t.actor.items) && (!me || (feetBetween(me, t) ?? Infinity) <= STEEL_FEET));
}

async function steelAfter(ctx) {
  if (!ctx.cast) return null;
  const list = steelCandidates(ctx.actor, ctx);
  const t = list.length > 1 ? await pickToken("Steelbinding", "Which creature in metal armour is bound?", list) : list[0];
  if (!t) return { lines: ["Steelbinding: no target in metal armour within 30 feet."] };
  const dc = await saveDCFor(ctx.actor, ctx);
  const check = await h().rollCheck({ actor: t.actor, type: "save", subject: "fortitude", label: `Steelbinding — Fortitude (DC ${dc})`, dc });
  const degree = norm(check?.outcome?.degree?.key ?? "failure");
  const tags = steelTags(degree, clockNow(t.actor));
  if (tags.length) await h().applyConditionTagsTo(t.actor, tags);
  const lines = [`Steelbinding: ${esc(t.name)}'s Fortitude save (DC ${dc}): ${degree} — ${tags.length ? (tags[0].key === "slowed" ? "Slowed 1 until the end of its next turn" : "Immobilised until the end of your next turn") : "no effect"}.`];
  if (degree === "blunder") {
    const weapons = Array.from(t.actor.items ?? []).filter((i) => i?.type === "weapon" && i.system?.equipped);
    const metal = weapons.filter((w) => /\bmetal\b/i.test(`${w.system?.traits ?? ""} ${w.system?.material ?? ""}`));
    const offer = metal.length ? metal : weapons;
    const picked = offer.length ? await h().chooseFromList("Steelbinding", `${esc(t.name)} drops a held metal weapon of your choice:`, offer.map((w) => [w.id, esc(w.name)])) : null;
    const weapon = offer.find((w) => w.id === picked);
    if (weapon && t.actor.isOwner) {
      await weapon.update({ "system.equipped": false });
      lines.push(`Steelbinding: ${esc(t.name)} drops ${esc(weapon.name)}.`);
    } else lines.push(weapon ? `Steelbinding: ${esc(t.name)} drops ${esc(weapon.name)} — the GM unequips it.` : `Steelbinding: ${esc(t.name)} holds no weapon to drop.`);
  }
  return { lines };
}

/* ---- Thunderclap Aura ---- */

async function thunderclapAfter(ctx) {
  if (!ctx.cast) return null;
  const dice = thunderclapDice(ctx.totalPP);
  if (!dice) return { lines: ["Thunderclap Aura: the cast cost under 2 PP — no shockwave."] };
  const dc = await saveDCFor(ctx.actor, ctx);
  const out = await h().runAreaEffect(ctx.actor, {
    save: "fortitude", basic: true, dc, scope: "area", radiusFeet: THUNDERCLAP_FEET, damage: { formula: dice, type: "electricity" },
    intro: `Thunderclap Aura: every creature within ${THUNDERCLAP_FEET} feet — ${dice} electricity (${int(ctx.totalPP)} PP), basic Fortitude against DC ${dc}.`
  }, { title: "Thunderclap Aura" });
  return { lines: out ?? [] };
}

/* ---- Versatile Binder ---- */

async function binderApply(ctx) {
  const t = await pickToken("Versatile Binder", "Choose the creature, already here and within the spell's range, to bind in place of a new summons.", untargetedWithin(ctx.actor, ctx));
  if (!t) return { cancel: true, reason: "Versatile Binder: no creature chosen" };
  ctx.eaBound = uuidOf(t);
  return { lines: [`Versatile Binder: ${esc(t.name)} is to be bound rather than a new creature summoned.`] };
}

async function binderAfter(ctx) {
  if (!ctx.cast || !ctx.eaBound) return null;
  const t = tokens().find((x) => uuidOf(x) === ctx.eaBound);
  if (!t) return { lines: ["Versatile Binder: the chosen creature is gone."] };
  // AN ELDRITCH ARTS BINDING (0.11.0, Block 8a; Q133, Q184): no save here. The
  // Binding model binds this creature with the spell's own save, after the
  // cast, by its trait and level (Q169) — and "it is bound as a summoned
  // creature would be": control levels, its end, broken (C → B).
  if (isBinding(String(ctx.spell?.flags?.[SYSTEM_ID]?.eaGrimoire ?? ""))) {
    setBinderChoice(ctx.actor, ctx.eaBound);
    return { lines: [`Versatile Binder: ${esc(t.name)} is the creature. Its Will save is the binding's own, rolled once the GM confirms it (the binding's card).`] };
  }
  const save = (norm(ctx.spellData?.defence).match(/fortitude|reflex|will/) ?? ["will"])[0];
  const dc = await saveDCFor(ctx.actor, ctx);
  const check = await h().rollCheck({ actor: t.actor, type: "save", subject: save, label: `Versatile Binder — ${cap(save)} (DC ${dc})`, dc });
  const degree = norm(check?.outcome?.degree?.key ?? "failure");
  return { lines: [SUCCESSES.includes(degree)
    ? `Versatile Binder: ${esc(t.name)} resists (${degree}); the spell is spent with no effect.`
    : `Versatile Binder: ${esc(t.name)} fails (${degree}) and is bound as the summoned creature would be, for the spell's duration — its control is the GM's.`] };
}

/* ------------------------------------------------------------------ */
/* G5, G6, G7, G9, the remap, the check reaction                        */
/* ------------------------------------------------------------------ */

export const manaBound = (ctx = {}) => (has(ctx.actor, FEAT.manaBound) ? manaBoundModifier(ctx) : null);

export const RESONANT_CONDUIT_FLAG = "resonantConduitSpent";

export const CHARGED_RULES_B6_D = Object.freeze({
  conduitMastery: {
    wieldLimit: ({ actor } = {}) => (has(actor, FEAT.conduitMastery) ? 3 : null),
    cost: (ctx = {}) => (has(ctx.actor, FEAT.conduitMastery) ? conduitMasteryCost(ctx) : null)
  },
  dualChannel: {
    wieldLimit: ({ actor } = {}) => (has(actor, FEAT.dualChannel) ? 2 : null),
    onRelease: (ctx = {}) => dualChannelRelease(ctx)
  },
  resonantConduit: {
    cost: (ctx = {}) => resonantConduitCost(ctx)
  },
  weaveInfusion: {
    payment: ({ actor } = {}) => (has(actor, FEAT.weave) ? { ownPP: true, allowEmpty: true, depletionBias: "disadvantage", label: "Weave Infusion: pay from your own PP" } : null)
  },
  metamagicConduit: {
    metamagic: ({ actor } = {}) => (has(actor, FEAT.metamagicConduit) ? { allowed: true, label: "Metamagic Conduit" } : null)
  }
});

async function dualChannelRelease(ctx) {
  if (!has(ctx.actor, FEAT.dualChannel) || !dualChannelDue(ctx)) return null;
  const lines = [];
  for (const item of Array.from(ctx.wielded ?? [])) {
    const before = int(item.system?.uses);
    await item.update({ "system.uses": Math.max(0, before - 1) });
    lines.push(`Dual Channel: the fumbled activation costs <strong>${esc(item.name)}</strong> 1 more PP (${Math.max(0, before - 1)} left).`);
    // NOT TWICE (review). Below 0 rolls Charge Depletion — but the RELEASED
    // item, emptied by its own spend, may already have been rolled by the core
    // (it overspent). So it is rolled here only when its own spend took
    // nothing from it (paid by the wielder, or a free activation); else, when
    // it was left exactly empty, the card says the roll is the GM's call.
    if (before - 1 < 0) {
      const released = item === ctx.item || (item?.id && item.id === ctx.item?.id);
      if (!released || dualChannelRollsReleased(ctx)) await h().rollItemDepletion(ctx.actor, item);
      else lines.push(`Dual Channel: if ${esc(item.name)}'s own spend left it exactly empty (not overspent), roll Charge Depletion for it — the core rolled only for an overspend.`);
    }
  }
  return { lines };
}

async function resonantConduitCost(ctx) {
  const actor = ctx.actor;
  if (!has(actor, FEAT.resonantConduit)) return null;
  if (!resonantConduitFree(ctx, Boolean(actor.getFlag?.(MODULE_ID, RESONANT_CONDUIT_FLAG)))) return null;
  await actor.setFlag(MODULE_ID, RESONANT_CONDUIT_FLAG, true);
  return { free: true, label: "Resonant Conduit (the day's first activation)" };
}

/** G9: "Pact Archetype feat" and "at least any one metamagic feat". */
export const ELIGIBILITY_B6_D = Object.freeze({
  [FEAT.pact]: (actor) => (pactOf(actor?.items) ? null : "it needs a Pact archetype feat (Angelic, Demonic, Draconic, Elemental, Fey, Grave or Void Pact)."),
  [FEAT.metamagicConduit]: (actor) => (Array.from(actor?.items ?? []).some((i) => i?.type === "feat" && hasTrait(i.system?.traits, "metamagic")) ? null : "it needs at least one metamagic feat.")
});

/** Arcane Fencer: a check reaction before the dice. */
export const arcaneFencer = {
  async before(ctx = {}) {
    const actor = ctx.actor;
    if (!has(actor, FEAT.fencer)) return null;
    const weapon = Array.from(actor.items ?? []).find((i) => i?.type === "weapon" && i.uuid === ctx.weaponUuid) ?? null;
    if (!fencerApplies(ctx, weapon)) return null;
    const max = fencerMax(actor.system?.magic?.casterLevelValue, poolOf(actor));
    if (!max) return null;
    const pp = await askNumber("Arcane Fencer", `Burn PP into this Strike with ${esc(weapon.name)}? +1 status to the attack for each, up to ${max} (your caster level, and your pool). 0 for none.`, max);
    if (!pp) return null;
    await actor.update({ "system.resources.pp.value": poolOf(actor) - pp });
    return { modifiers: fencerModifiers(pp), line: `Arcane Fencer: ${pp} PP burned, +${pp} status to the attack.` };
  }
};

/* ---- Subconscious Casting (G7) ---- */

export const SUBCONSCIOUS_STEP = "eldritchArts.subconsciousCasting";

/** The spells it may cast: prepared or known, 1 AP, Self or Touch, not a cantrip (a cantrip takes no metamagic, Q94). */
export function subconsciousSpells(items = []) {
  return Array.from(items ?? []).filter((s) => s?.type === "spell" && !s.system?.innate && int(s.system?.ppCost) > 0 && int(s.system?.castAP) === 1 && /^(self|touch)\b/.test(norm(s.system?.range)));
}

export const subconsciousOffer = {
  applies: (ctx = {}) => {
    const feat = featOf(ctx.actor, FEAT.subconscious);
    return Boolean(feat) && usesLeft(feat) > 0 && subconsciousSpells(ctx.actor?.items).length > 0;
  },
  async offer(ctx = {}) {
    const actor = ctx.actor;
    const q = await h().askReactor(actor, {
      title: `Subconscious Casting — ${actor.name}`,
      content: `<p>${esc(ctx.sourceName || "A blow")} would drop you to 0 HP. Cast a 1 AP Self or Touch spell now, as a 0 AP action, at +${SUBCONSCIOUS_PP} PP (its Focus use)?</p>`,
      buttons: [{ action: "yes", label: "Cast" }, { action: "no", label: "No" }],
      step: SUBCONSCIOUS_STEP, data: {}
    });
    const lines = Array.isArray(q?.result?.lines) ? q.result.lines : [];
    return lines.length ? { lines } : null;
  }
};

/** The step, on the caster's client: choose the spell, cast it with the preset +6, spend the Focus when paid (Q96). */
export async function subconsciousStep(actor, answer) {
  if (answer !== "yes") return { lines: [] };
  const feat = featOf(actor, FEAT.subconscious);
  if (!feat || usesLeft(feat) <= 0) return { lines: ["Subconscious Casting: its Focus use is spent."] };
  const list = [];
  for (const s of subconsciousSpells(actor.items)) if (!h().spellCastable || (await h().spellCastable(actor, s))) list.push(s);
  if (!list.length) return { lines: ["Subconscious Casting: no 1 AP Self or Touch spell you can cast now."] };
  const picked = await h().chooseFromList("Subconscious Casting", "Cast which spell as you fall?", list.map((s) => [s.id, `${esc(s.name)} (${int(s.system?.ppCost)} PP + ${SUBCONSCIOUS_PP})`]));
  const spell = list.find((s) => s.id === picked);
  if (!spell) return { lines: [] };
  const result = await h().castSpell(actor, spell, { apPaid: true, metamagic: { preset: [{ key: MM.subconscious }] } });
  const degree = norm(result?.check?.outcome?.degree?.key ?? result?.degree);
  const paid = Boolean(result) && !result.refunded && degree !== "partial";
  if (paid) await spendUse(feat);
  return { lines: [`Subconscious Casting: ${esc(spell.name)} cast as ${esc(actor.name)} falls${degree ? ` (${esc(degree)})` : ""}.${paid ? " Its Focus use is spent." : ""}`] };
}

/* ---- Extra Cantrip (Use) ---- */

const extraCantrip = {
  hint: "Your extra cantrip: the allowance rises by itself; a class with no cantrip pool chooses one here.",
  async use(actor, item) {
    const copies = Array.from(actor.items ?? []).filter((i) => i?.type === "feat" && norm(i.name) === norm(FEAT.extraCantrip)).sort((a, b) => String(a.id).localeCompare(String(b.id)));
    const refusal = extraCantripRefusal(Math.max(0, copies.indexOf(item)), levelOf(actor));
    if (refusal) return warn(refusal);
    const classes = Array.from(actor.items ?? []).filter((i) => i?.type === "class");
    const pool = classes.some((c) => int(c.system?.cantripsKnown) > 0 || int(c.system?.cantripsPerDay) > 0);
    if (pool) {
      await card(actor, FEAT.extraCantrip, [line("Your cantrip allowance is one higher: choose the extra cantrip in your cantrip panel, or memorise one more at daily preparation.")]);
      return true;
    }
    const tradition = norm(actor.system?.magic?.tradition);
    return h().chooseSpell(actor, item, { ppCost: 0, ...(tradition ? { tradition } : {}), note: "Extra Cantrip: your additional cantrip, cast with your Spellcraft. Using Extra Cantrip again replaces it." });
  }
};
export const AUTOMATIONS_B6_D = Object.freeze({ [FEAT.extraCantrip]: extraCantrip });

/* ------------------------------------------------------------------ */
/* Hooks                                                                */
/* ------------------------------------------------------------------ */

/** trgPrimeSpellSettled — Lightning Rod's splash on the caster's next electricity-trait cast. */
export async function onSpellSettledB6D(ctx = {}) {
  const actor = ctx.actor;
  if (!actor || !actsFor(actor)) return;
  if (ctx.spellData && LIGHTNING_HANDLED.has(ctx.spellData)) return;
  const mark = casterMark(actor);
  if (!mark || !ctx.cast || ctx.threaded || !hasTrait(ctx.spellData?.traits, "electricity")) return;
  const lines = await lightningSplash(actor, ctx, mark);
  if (lines.length) await card(actor, "Lightning Rod", lines.map((t) => line(t)));
}

/** deleteActiveEffect — the caster's mark ends, and the marked creature's −2 with it. */
export async function onEffectDeletedB6D(effect) {
  if (effect?.getFlag?.(MODULE_ID, "source") !== LIGHTNING_MARK || !actsFor(effect.parent)) return;
  const target = await fromUuidAsync(effect.flags?.[MODULE_ID]?.markedEffect);
  await deleteIfPresent(target);
}

/** trgPrimeActionResolved — Piercing Insight on both Sense Magic actions. */
export async function onActionResolvedB6D(ctx = {}) {
  const actor = ctx.actor;
  const key = String(ctx.action?.key ?? "");
  if (!actor || !["senseMagicBroad", "senseMagicFocused"].includes(key) || !has(actor, FEAT.piercing) || !actsFor(actor)) return;
  const list = [];
  for (const o of (await h().metamagicCatalogue?.(actor)) ?? []) {
    // A DISCOUNT BUYS NOTHING HERE (review): a module option of no PP and no
    // Focus (Ley-Etched Symbol's −1, the Reservoir's charges) is left out.
    if (o.source !== "core" && (PIERCING_LEFT_OUT.has(norm(o.key)) || (!int(o.ppCost) && !o.focus))) continue;
    // A FOCUS OPTION while its feat has a use; the use is spent with the PP (Q96).
    if (o.focus) {
      const feat = featOf(actor, o.feat);
      if (!feat || usesLeft(feat) <= 0) continue;
      o.focusItem = feat;
    }
    list.push(o);
  }
  if (!list.length) return;
  const picked = await tickMany("Piercing Insight", `Apply metamagic to ${esc(ctx.action?.name ?? "Sense Magic")}? Each costs its PP; no further check is made.`,
    list.map((o) => [o.key, `${esc(o.label)}${o.ppCost !== null && o.ppCost !== undefined ? ` (+${int(o.ppCost)} PP)` : ""}`]));
  if (!picked?.length) return;
  const chosen = list.filter((o) => picked.includes(o.key));
  const pp = chosen.reduce((n, o) => n + int(o.ppCost), 0);
  if (pp > poolOf(actor)) { warn(`Piercing Insight: those cost ${pp} PP; you have ${poolOf(actor)}.`); return; }
  if (pp) await actor.update({ "system.resources.pp.value": poolOf(actor) - pp });
  for (const o of chosen) if (o.focusItem) await spendUse(o.focusItem);
  await card(actor, "Piercing Insight", [
    line(`${esc(ctx.action?.name ?? "Sense Magic")} with ${chosen.map((o) => esc(o.label)).join(", ")} — ${pp} PP spent, no further check.`),
    ...chosen.map((o) => line(`${esc(o.label)}: ${SENSE_EFFECTS[o.key] ?? "as its feat says"} — the GM applies it.${o.focusItem ? " Its Focus use is spent." : ""}`))
  ]);
}

/** trgPrimeDailyPreparation — Resonant Conduit's free activation returns. */
export async function onDailyPreparationB6D({ actor } = {}) {
  if (actor?.getFlag?.(MODULE_ID, RESONANT_CONDUIT_FLAG)) await actor.unsetFlag(MODULE_ID, RESONANT_CONDUIT_FLAG);
}

/*
 * SPELL SURGE COPIES MADE BEFORE 0.9.0 ARE NOT REWRITTEN. The 0.9.0 item
 * carries the Focus trait (Q132), and that is where its one use comes from.
 * An earlier copy already on a sheet keeps its old traits: changing owned
 * items at load would alter world data, which Graham's brief forbids. The
 * release notes ask for such a copy to be added again from the compendium.
 */

/* ------------------------------------------------------------------ */
/* Registration                                                         */
/* ------------------------------------------------------------------ */

export const STEPS_B6_D = Object.freeze({ subconsciousStep });

/** Called once at init by the lead (module/registration.mjs). */
export function registerBlock6D(api, moduleId) {
  for (const [key, spec] of Object.entries(METAMAGIC_B6_D)) api.registerMetamagic?.(key, spec, moduleId);
  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_D)) api.registerFeatAutomation(name, entry, moduleId);
  for (const [key, rule] of Object.entries(CHARGED_RULES_B6_D)) api.registerChargedItemRule?.(key, rule, moduleId);
  for (const [name, check] of Object.entries(ELIGIBILITY_B6_D)) api.registerFeatEligibility?.(name, check, moduleId);
  api.registerFumbleModifier?.("manaBound", manaBound, moduleId);
  api.registerCastDegreeRemap?.("spellthread", threadRemap, moduleId);
  api.registerCheckReaction?.("arcaneFencer", arcaneFencer, moduleId);
  api.registerUnconsciousOffer?.("subconsciousCasting", subconsciousOffer, moduleId);
  api.registerReactionStep?.(SUBCONSCIOUS_STEP, subconsciousStep, moduleId);
}
