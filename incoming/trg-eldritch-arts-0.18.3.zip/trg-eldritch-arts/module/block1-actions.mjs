/**
 * Eldritch Arts Block 1 — Chapter 4's skill actions that need no new rule
 * engine (Ley Sense, Appraise Magic, Hypnotism, Mysterious Script,
 * Quickbind) and the Nyrinn's Magic Drain, in the exact shape TRG Prime's
 * own SKILL_ACTIONS holds, registered through `api.registerSkillActions`.
 * Lingual Casting is not an action of its own: it is another way to read a
 * scroll, registered as a release path (TRG Prime 3.675.0, C6).
 *
 * BOOK TEXT IS VERBATIM: the outcome rows and descriptions are the book's
 * (tools/content/book-text.json `chapter4`, the Magic Drain sidebar), and
 * verify-block1 holds every one against it.
 *
 * `outcomesApplied: true`: this module applies each row itself
 * (module/block1-automations.mjs), so the system's generic outcome readers
 * leave the text alone.
 *
 * A CHOICE BEFORE THE ROLL rides on the system's declared time ladder (TRG
 * Prime 3.666.0), whose rung is a modifier on the roll. Hypnotism's
 * "Incredibly Hard (DC +10)" and Quickbind's "Very Hard (DC +5)" are DC
 * increases; as a modifier on the roll they are the same number against
 * every degree, and the rung says which it is.
 *
 * Hypnotism's two uses ("either implant a suggestion or help a target recall
 * a memory") are two entries, so that the result knows which it was.
 */

const ladder = (o) => ({ heroic: "", critical: "", success: "", partial: "", failure: "", fumble: "", blunder: "", ...o });

/** "10 minutes (+0), 1 minute (-2), 1 round (-5), 1 AP (-10)" — Ley Sense and Appraise Magic. */
export const TIME_LADDER = Object.freeze({
  options: Object.freeze([
    Object.freeze({ key: "tenMinutes", label: "10 minutes", modifier: 0, apCost: "10 minutes" }),
    Object.freeze({ key: "minute", label: "1 minute", modifier: -2, apCost: "1 minute" }),
    Object.freeze({ key: "round", label: "1 round", modifier: -5, apCost: "1 round" }),
    Object.freeze({ key: "action", label: "1 AP", modifier: -10, apCost: "1" })
  ]),
  defaultKey: "tenMinutes"
});

/** Focused Ley Sense: "10 minutes (+2), 1 minute (+0), 1 round (-2), 1 AP (-5), 0 AP (-10)" (TRG Prime 3.675.0, C5). */
export const FOCUSED_TIME_LADDER = Object.freeze({
  options: Object.freeze([
    Object.freeze({ key: "tenMinutes", label: "10 minutes", modifier: 2, apCost: "10 minutes" }),
    Object.freeze({ key: "minute", label: "1 minute", modifier: 0, apCost: "1 minute" }),
    Object.freeze({ key: "round", label: "1 round", modifier: -2, apCost: "1 round" }),
    Object.freeze({ key: "action", label: "1 AP", modifier: -5, apCost: "1" }),
    Object.freeze({ key: "free", label: "0 AP", modifier: -10, apCost: "0" })
  ]),
  defaultKey: "tenMinutes",
  hint: "Focused Ley Sense: how long do you spend sensing ley?"
});

export const SKILL_ACTIONS = Object.freeze([
  {
    key: "leySense",
    name: "Ley Sense",
    skills: ["arcana", "nature", "occultism", "religion"],
    traits: "Concentrate, Focus",
    apCost: "10 minutes",
    proficiency: "trained",
    checkType: "skill",
    against: "none",
    outcomesApplied: true,
    timeLadder: { ...TIME_LADDER, hint: "How long do you spend sensing ley? Less time costs accuracy." },
    timeLadderByFeat: { "Focused Ley Sense": FOCUSED_TIME_LADDER },
    outcomes: ladder({
      critical: "You immediately detect all ley lines within 1000 feet, their direction, and general strength. You also detect any arcane anomalies or disturbances in the area.",
      success: "You detect the nearest ley line within 500 feet and its direction.",
      failure: "You fail to detect any ley lines and cannot attempt Ley Sense again for 10 minutes.",
      fumble: "Your magical senses are overwhelmed. You lose 1 PP and cannot attempt Ley Sense again for 1 hour."
    }),
    description: "By applying your lore of the magical traditions, you unravel subtle signs in the world around you, discerning the presence of ley lines, arcane nexuses, or shifts in the flow of magic that others would overlook.. You choose the amount of time you wish to spend sensing ley and apply the following modifiers; 10 minutes (+0), 1 minute (-2), 1 round (-5), 1 AP (-10). The DC of the check is set by the GM based upon magical interference, location complexity, or concealment. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "appraiseMagic",
    name: "Appraise Magic",
    skills: ["crafting"],
    traits: "Concentrate, Secret",
    apCost: "10 minutes",
    requirements: "Crafting 5 ranks.",
    requirement: "skills.crafting.ranks",
    minRanks: 5,
    checkType: "skill",
    against: "none",
    outcomesApplied: true,
    timeLadder: { ...TIME_LADDER, hint: "How long do you spend examining the item? If you are interrupted, you must start over." },
    outcomes: ladder({
      critical: "If the item is magical, you determine this and may also ascertain its basic purpose.",
      success: "If the item is magical, you determine this.",
      failure: "You can find no signs of magic upon the item.",
      fumble: "You believe that the item is magical if it is not, or non-magical if it is."
    }),
    description: "You may examine any one item which is covered by one of your crafting specialties to determine if it has magical properties. You choose the amount of time you wish to spend examining the item and apply the following modifiers; 10 minutes (+0), 1 minute (-2), 1 round (-5), 1 AP (-10). If your attempt is interrupted, you must start over. The GM sets the difficulty of your check. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "hypnotismSuggestion",
    name: "Hypnotism: Implant Suggestion",
    skills: ["diplomacy"],
    traits: "Concentrate, Emotion, Mental",
    apCost: "1 minute",
    checkType: "skill",
    against: "willDC",
    outcomesApplied: true,
    timeLadder: {
      options: [
        { key: "willing", label: "A willing creature", modifier: 0, apCost: "1 minute" },
        { key: "unwilling", label: "An unwilling creature, Indifferent or worse (Incredibly Hard, DC +10)", modifier: -10, apCost: "1 minute" }
      ],
      defaultKey: "willing",
      rowLabel: "The subject",
      title: "Hypnotism — the subject",
      hint: "An unwilling subject's DC is Incredibly Hard (+10), applied here as −10 on your check."
    },
    outcomes: ladder({
      heroic: "The subject accepts the trance effortlessly; suggestion effects last 1 hour and memory recall gains an additional +4 bonus.",
      critical: "The effect functions normally, but suggestion duration increases to 30 minutes.",
      success: "Effect functions as described.",
      partial: "You partially calm the subject; they gain only a +2 bonus to memory recall, and suggestions last 5 minutes.",
      failure: "The subject resists your influence; the attempt fails but can be retried the next day.",
      fumble: "You agitate or confuse the subject, shifting their attitude one step toward hostile.",
      blunder: "The attempt backfires; the subject becomes convinced you are trying to manipulate them, instantly ending any rapport and making them hostile."
    }),
    description: "You place a reasonable course of action in the subject’s mind, paired with a clear trigger. Willing Creature: Spend 1 minute inducing a trance, then make a skill check. On a success, you implant the suggestion as per the suggestion spell. If the target later becomes unwilling, they may attempt a Will save each round to end the effect (DC = your Diplomacy DC). Unwilling Creature (Indifferent or worse attitude) – You may attempt this after 1 minute of calm interaction, but the DC is Incredibly Hard (DC +10). The DC is equal to the targets Will DC. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "hypnotismMemory",
    name: "Hypnotism: Memory Recall",
    skills: ["diplomacy"],
    traits: "Concentrate, Emotion, Mental",
    apCost: "1 minute",
    checkType: "skill",
    against: "willDC",
    outcomesApplied: true,
    outcomes: ladder({
      heroic: "The subject accepts the trance effortlessly; suggestion effects last 1 hour and memory recall gains an additional +4 bonus.",
      critical: "The effect functions normally, but suggestion duration increases to 30 minutes.",
      success: "Effect functions as described.",
      partial: "You partially calm the subject; they gain only a +2 bonus to memory recall, and suggestions last 5 minutes.",
      failure: "The subject resists your influence; the attempt fails but can be retried the next day.",
      fumble: "You agitate or confuse the subject, shifting their attitude one step toward hostile.",
      blunder: "The attempt backfires; the subject becomes convinced you are trying to manipulate them, instantly ending any rapport and making them hostile."
    }),
    description: "You help a willing subject retrieve lost or suppressed memories. Spend 1 minute guiding the target into a trance, then make a check. On a success, the target may reroll any previously failed Recall Knowledge check to remember the forgotten information, gaining a +4-circumstance bonus to the roll. The memory must be of something the subject once knew or personally experienced. The DC is equal to the targets Will DC. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "mysteriousScript",
    name: "Mysterious Script",
    skills: ["linguistics"],
    traits: "Concentrate, Secret",
    apCost: "1 hour",
    checkType: "skill",
    against: "none",
    outcomesApplied: true,
    outcomes: ladder({
      critical: "You discern meaning equivalent to the Divine Vision spell.",
      success: "You discern meaning equivalent to the Augury spell."
    }),
    description: "You channel cryptic messages from unseen forces, whether guided by strange spirits or drawn forth from the depths of your own subconscious mind. These writings speak of the near future—though their meaning is often veiled in riddles and symbols. Once per week, you may spend 1 hour in quiet focus, posing questions aloud while your hand moves of its own accord, scribbling words, symbols, or diagrams. At the end of this time, you attempt a skill check to interpret the message. The GM determines the DC for this check. (Eldritch Arts, Chapter 4)"
  },
  {
    key: "quickbind",
    name: "Quickbind",
    skills: ["powerManipulation"],
    traits: "Concentrate",
    apCost: "1 minute",
    requirements: "Power Manipulation 5 ranks.",
    requirement: "skills.powerManipulation.ranks",
    minRanks: 5,
    checkType: "skill",
    against: "none",
    outcomesApplied: true,
    timeLadder: {
      options: [
        { key: "dailyPrep", label: "During your daily preparation", modifier: 0, apCost: "1 minute" },
        { key: "outside", label: "Outside daily preparation (Very Hard, DC +5)", modifier: -5, apCost: "1 minute" }
      ],
      defaultKey: "dailyPrep",
      rowLabel: "When",
      title: "Quickbind — when",
      hint: "Outside your daily preparation the DC is Very Hard (+5), applied here as −5 on your check. The DC is the item's: its Level DC."
    },
    outcomes: ladder({
      critical: "You invest the item much more quickly and the process takes 1 minute.",
      success: "You invest the item much more quickly and the process takes 5 minutes",
      failure: "The item is invested in the normal amount of time (10 minutes).",
      fumble: "You fail to invest the item."
    }),
    description: "You use this action to Invest Items in less time. Instead of using the Invest Item action from the Core Rulebook, make a skill check against the DC of the item with the following results. Be aware that you may only make one Quickbind check per item per day. You may attempt to Invest an item outside of normal daily preparation by increasing the difficulty of the check to Very Hard (DC +5) (Eldritch Arts, Chapter 4)"
  },
  {
    key: "magicDrain",
    name: "Magic Drain",
    skills: ["powerManipulation"],
    traits: "Concentrate, Focus, Warding",
    apCost: "2",
    requiresFeat: "Magic Drain",
    requirements: "The Magic Drain ability (Nyrinn). Range 30 feet: one magical effect or charged magic item.",
    checkType: "skill",
    against: "none",
    outcomesApplied: true,
    outcomes: ladder({
      critical: "The effect is negated or its PP reduced by 1d4 in the case of a charged item. You gain temporary magical energy equal to the drained PP (max your level × 2).",
      success: "As critical but you only gain temporary magical energy equal to half the drained PP (max your level × 2)."
    }),
    description: "You can choose one magical effect or charged magic item within 30 feet and attempt to drain its energy. You make a Dispel (Power Manipulation) check against the DC of the effect or item with the following effects: The absorbed energy grants you a +1 racial bonus to AB, DB, saving throws or skill checks for 1 minute per PP drained. (Eldritch Arts, Chapter 2)"
  }
]);

export const SKILL_ACTION_KEYS = Object.freeze(SKILL_ACTIONS.map((a) => a.key));
