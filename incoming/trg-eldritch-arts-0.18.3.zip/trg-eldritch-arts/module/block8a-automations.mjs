/**
 * Eldritch Arts — Block 8a (0.11.0, on TRG Prime 3.686.0): what the eight
 * Bindings, the five Symbols and the eleven exploration and utility spells do
 * that is not data. The spells are tools/content/block8a-spells.mjs (Symbol of
 * Death and Fear, rebuilt here on the Symbol model, stay in
 * tools/content/block3-spells.mjs); their numbers and pure rules are
 * module/block8a-rules.mjs. Each spell is found by its `eaGrimoire` key.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2 and §4, as Graham
 * answered it on 8 November 2026 (17:22, "As recommended"): Q167–Q184 as
 * recommended; H12, H17, H18 (TRG Prime 3.686.0).
 *
 * WHICH CLIENT DOES THE WORK (the 3.685.2/3.685.3 lesson: a world-changing
 * hook runs on exactly one client):
 *   the settled cast          the caster's client (the hook fires there only)
 *   a GM card's button        the GM who presses it (a player's click is refused)
 *   a binding's end           `actsFor` the caster (its player, else the acting GM)
 *   a creature breaking free  the client whose turn-start sweep released it
 *                             (the core's, the acting GM's)
 *   a token's move            `actsFor` the mover (a rift's passage, a curse's
 *                             hold); the acting GM for what the map watches
 *                             (a riserune, a symbol's glow)
 *   the world clock           the acting GM (the module's Regions' ends, the glow)
 * A write on a creature this client does not own goes through Block 7's
 * GM relay (`writeOn`), which checks it against the creature's own state.
 */
import { isActingGM, isActiveGMAccount } from "./writer.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, forSeconds } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, tokenOf, tokenCentre, feetBetween } from "./block1-automations.mjs";
import { pickPoint, actsFor } from "./block3-automations.mjs";
import { circleDegreeOf, trueNameHostile, TRUE_NAME_TAIL } from "./block2b-automations.mjs";
import { writeOn, activeEntryFor } from "./block7-automations.mjs";
import { enemiesBySide } from "./block7-rules.mjs";
import * as R from "./block8a-rules.mjs";
import { endPositionOf } from "./token-moves.mjs";
export { endPositionOf };

const worldNow = () => Number(globalThis.game?.time?.worldTime ?? 0);
const effects = (actor) => Array.from(actor?.effects ?? []);
const tokens = () => Array.from(globalThis.canvas?.tokens?.placeables ?? []).filter((t) => t?.actor);
const sourceOf = (effect) => effect?.flags?.[MODULE_ID]?.source ?? "";
const regionVisibility = (key) => globalThis.CONST?.REGION_VISIBILITY?.[key] ?? { GAMEMASTER: 1, ALWAYS: 2 }[key];
async function resolve(uuid) {
  if (!uuid) return null;
  try {
    const sync = globalThis.fromUuidSync?.(uuid);
    const doc = sync ?? await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(uuid);
    return doc ?? null;
  } catch { return null; }
}
const actorOf = (doc) => (doc?.documentName === "Actor" ? doc : doc?.actor ?? doc ?? null);
const gridFeet = () => Number(globalThis.canvas?.dimensions?.distance ?? 5);
const gridPx = () => Number(globalThis.canvas?.grid?.size ?? globalThis.canvas?.dimensions?.size ?? 100);

/** Feet from a point to a token's nearest edge (its own size counted, as `feetBetween` counts it). */
export function feetFromPoint(point, token) {
  try {
    const measured = globalThis.canvas.grid.measurePath([point, tokenCentre(token)]).distance;
    const reach = ((Math.max(1, Number(token.document?.width ?? 1)) - 1) / 2) * gridFeet();
    return Math.max(0, Math.round(measured - reach));
  } catch { return null; }
}
/*
 * A TOKEN BY ITS DOCUMENT (the Block 8a review): the mover's acting client may
 * not be viewing its scene, so nothing that runs there may need a token
 * placeable. The centre and the distance come from the document and its own
 * scene's grid.
 */
const sceneGridOf = (scene) => ({ size: Number(scene?.grid?.size ?? gridPx()), distance: Number(scene?.grid?.distance ?? gridFeet()) });
export function docCentre(doc) {
  const { size } = sceneGridOf(doc?.parent);
  return { x: Number(doc?.x ?? 0) + (Math.max(1, Number(doc?.width ?? 1)) * size) / 2, y: Number(doc?.y ?? 0) + (Math.max(1, Number(doc?.height ?? 1)) * size) / 2 };
}
/** Feet from a point to a token document's nearest edge, on its own scene's grid. */
export function feetFromPointDoc(point, doc) {
  if (!doc || !point) return null;
  const { size, distance } = sceneGridOf(doc.parent);
  const c = docCentre(doc);
  let measured = null;
  try { measured = doc.parent?.grid?.measurePath?.([point, c])?.distance ?? null; } catch { measured = null; }
  if (measured === null || measured === undefined || !Number.isFinite(Number(measured))) measured = (Math.hypot(c.x - point.x, c.y - point.y) / (size || 1)) * distance;
  const reach = ((Math.max(1, Number(doc.width ?? 1)) - 1) / 2) * distance;
  return Math.max(0, Math.round(Number(measured) - reach));
}
/** Every scene in the world (the sweeps), else the one on the canvas. */
const allScenes = () => { const list = Array.from(globalThis.game?.scenes ?? []); return list.length ? list : [globalThis.canvas?.scene].filter(Boolean); };
/** A cast still among its caster's active spells? (A symbol with no cast id has nothing to dismiss.) */
const castStands = (caster, castId) => !castId || Array.from(caster?.getFlag?.(SYSTEM_ID, "activeSpells") ?? caster?.flags?.[SYSTEM_ID]?.activeSpells ?? []).some((e) => e?.id === castId);

/** Does a sight-blocking wall stand between two points? (Foundry's own sight collision test.) */
export function sightBlocked(a, b) {
  const backend = globalThis.CONFIG?.Canvas?.polygonBackends?.sight;
  if (typeof backend?.testCollision !== "function") return false;
  try { return Boolean(backend.testCollision(a, b, { type: "sight", mode: "any" })); } catch { return false; }
}

/* ================================================================== */
/* Cards with buttons                                                   */
/* ================================================================== */

function cardHTML(actor, title, lines, buttons = []) {
  const body = lines.map((l) => `<p style="margin:2px 0">${l}</p>`).join("");
  const row = buttons.length
    ? `<div class="ea8a-buttons" style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">${buttons.map((b) => `<button type="button" data-ea8a="${esc(b.action)}" data-ea8a-caster="${esc(b.caster ?? "")}" data-ea8a-ref="${esc(b.ref ?? "")}">${esc(b.label)}</button>`).join("")}</div>`
    : "";
  return `<div class="trg-prime trg-check-card"><header class="check-header"><div class="check-heading"><span class="check-actor">${esc(actor?.name ?? "")}</span><h3>${esc(title)}</h3></div></header>${body}${row}</div>`;
}
/** A card with buttons; `gm` whispers it to the GMs, `owners` to the actor's owners. */
export async function buttonCard(actor, title, lines, buttons = [], { gm = false, owners = false } = {}) {
  const game = globalThis.game;
  const users = Array.from(game?.users ?? []);
  const whisper = gm ? users.filter((u) => u.isGM).map((u) => u.id)
    : owners ? users.filter((u) => u.isGM || actor?.testUserPermission?.(u, "OWNER")).map((u) => u.id) : null;
  return globalThis.ChatMessage?.create?.({
    speaker: globalThis.ChatMessage?.getSpeaker?.({ actor }) ?? {},
    content: cardHTML(actor, title, lines, buttons),
    ...(whisper ? { whisper } : {})
  });
}

/* ================================================================== */
/* The Bindings (§4.1)                                                  */
/* ================================================================== */

/** Versatile Binder's creature, handed over by its metamagic `after` (Block 6) before the settled hook. */
const binderChoices = new Map();
export const setBinderChoice = (actor, tokenUuid) => { if (actor?.uuid && tokenUuid) binderChoices.set(actor.uuid, String(tokenUuid)); };
const takeBinderChoice = (actor) => { const v = binderChoices.get(actor?.uuid) ?? ""; binderChoices.delete(actor?.uuid); return v; };

const bindingMarkers = (caster) => effects(caster).filter((e) => sourceOf(e) === R.BINDING_FLAG);
const recordOf = (effect) => effect?.flags?.[MODULE_ID]?.[R.BINDING_FLAG] ?? null;
const markerFor = (caster, id) => bindingMarkers(caster).find((e) => recordOf(e)?.id === id) ?? null;

/** The settled cast: the record on the caster and the GM's card. */
async function startBinding(actor, ctx) {
  const key = R.keyOf(ctx.spell);
  const spec = R.BINDINGS[key];
  const entry = activeEntryFor(actor, ctx.spell?.name);
  const binder = (ctx.metamagic ?? []).includes("versatilebinder") ? takeBinderChoice(actor) : "";
  const rec = {
    id: globalThis.foundry?.utils?.randomID?.() ?? String(Date.now()),
    key, spellName: ctx.spell?.name ?? spec.name, castId: entry?.id ?? "", saveDC: int(ctx.saveDC),
    maxLevel: R.bindingMaxLevel(key, ctx.warpMods?.bonusValue), type: spec.type,
    trueName: (ctx.castOptions ?? []).includes("truename"), circleFumble: circleDegreeOf(actor) === "fumble",
    binder, state: "pending", casterUuid: actor.uuid
  };
  await actor.createEmbeddedDocuments("ActiveEffect", [effectData(R.BINDING_FLAG, {
    name: `${rec.spellName}: awaiting the creature`, img: ctx.spell?.img,
    description: `A ${spec.type} of level ${rec.maxLevel} or lower, within ${R.BINDING_RANGE_FEET} feet; its Will save at DC ${rec.saveDC}.`,
    system: rec.castId ? { castId: rec.castId } : {},
    module: { [R.BINDING_FLAG]: rec }
  })]);
  const lines = [
    `<strong>${esc(rec.spellName)}</strong> (DC ${rec.saveDC}): ${binder ? "Versatile Binder binds the creature already chosen" : `a creature with the <strong>${esc(spec.type)}</strong> trait, level <strong>${rec.maxLevel}</strong> or lower, within ${R.BINDING_RANGE_FEET} feet of ${esc(actor.name)}`}.`,
    binder ? "GM: press the button to roll its Will save." : "GM: place its token (the Creature Codex builds one) and select it, or select one already there, then press the button.",
    ...(rec.trueName ? ["Its true name is invoked: a Success or better makes it permanently hostile."] : []),
    ...(rec.circleFumble ? ["The summoning circle was destabilised: it arrives hostile and unbound, whatever it rolls."] : []),
    ...(rec.castId ? [] : ["<em>The cast is not in the active-spell registry: Dismiss will not reach it.</em>"])
  ];
  await buttonCard(actor, `${rec.spellName} — the creature`, lines, [{ action: "bindCreature", caster: actor.uuid, ref: rec.id, label: binder ? "Roll its Will save" : "Bind the selected creature" }], { gm: true });
  return rec;
}

/** The creature's facts, for the refusal (block8a-rules `bindingRefusal`). */
function creatureFacts(caster, token) {
  const actor = token?.actor ?? null;
  const typeItem = Array.from(actor?.items ?? []).find((i) => i.type === "creature-type") ?? null;
  return {
    traits: R.creatureTraitsOf({ typeName: typeItem?.name ?? "", traits: actor?.system?.traits ?? actor?.system?.details?.traits ?? "" }),
    level: int(actor?.system?.identity?.level),
    feet: tokenOf(caster) ? feetBetween(tokenOf(caster), token) : null,
    isCaster: actor === caster
  };
}

/** The GM's button: check the creature, roll its save, and do what the binding does. */
export async function bindCreature(caster, recordId, { token = null } = {}) {
  const marker = markerFor(caster, recordId);
  let rec = recordOf(marker);
  if (!rec) return warn("Eldritch Arts: this binding has ended.");
  // A STALE CLAIM (the Block 8a re-review): a client that dropped during the
  // save left "binding". The acting GM takes over a claim whose claimer is no
  // longer connected, or that is older than two minutes (another GM's press is
  // refused below, stale claim or not).
  let tookOver = "";
  if (rec.state === "binding" && R.claimIsStale(rec.claim, { now: Date.now(), isActive: (id) => Boolean(globalThis.game?.users?.get?.(id)?.active) })) {
    tookOver = String(rec.claim?.user ?? "");
    const { claim, ...rest } = rec;
    rec = { ...rest, state: "pending" };
  }
  if (rec.state !== "pending") return warn(`Eldritch Arts: ${rec.spellName}'s creature has already been bound or refused it.`);
  // ONE GM BINDS IT (the Block 8a review): with two GMs connected, both see
  // the button; only the acting GM's press goes ahead, and a press is claimed
  // on this client before anything is rolled, so a double click binds once.
  // A BUTTON IS PRESSED IN ONE TAB (0.12.0): any tab of the active GM's account.
  if (globalThis.game?.user?.isGM && !isActiveGMAccount()) return warn("Eldritch Arts: another GM is the acting GM; that GM binds the creature.");
  if (claimedBindings.has(rec.id)) return warn(`Eldritch Arts: ${rec.spellName}'s creature is already being bound.`);
  claimedBindings.add(rec.id);
  try { return await bindClaimed(caster, marker, rec, token, tookOver); } finally { claimedBindings.delete(rec.id); }
}

/** Bindings being bound on this client now (the claim). */
const claimedBindings = new Set();

async function bindClaimed(caster, marker, rec, token, tookOver = "") {
  const chosen = token ?? (rec.binder ? tokens().find((t) => t.document?.uuid === rec.binder || t.actor?.uuid === rec.binder) : null) ?? globalThis.canvas?.tokens?.controlled?.[0] ?? null;
  if (!chosen?.actor) return warn(rec.binder ? "Versatile Binder: the chosen creature is gone." : `${rec.spellName}: select the creature's token first.`);
  const refusal = R.bindingRefusal(rec.key, creatureFacts(caster, chosen), rec.maxLevel);
  if (refusal) return warn(`Eldritch Arts: ${refusal}`);
  const creature = chosen.actor;
  // CLAIMED ON THE RECORD TOO, before the save: a second press anywhere reads
  // "binding". The claim says who and when, so a stale one can be taken over.
  await marker.setFlag(MODULE_ID, R.BINDING_FLAG, { ...rec, state: "binding", claim: { user: String(globalThis.game?.user?.id ?? ""), at: Date.now() } });
  let check;
  try { check = await h().rollCheck({ actor: creature, type: "save", subject: "will", dc: rec.saveDC, label: `${creature.name} — Will (DC ${rec.saveDC})`, subtitle: `${rec.spellName}: resisting the binding`, sourceUuid: caster.uuid }); }
  catch (err) { await marker.setFlag(MODULE_ID, R.BINDING_FLAG, rec); throw err; }
  const degree = norm(check?.outcome?.degree?.key ?? "failure");
  const outcome = R.bindingOutcome(degree, { circleFumble: rec.circleFumble });
  const lines = [...(tookOver ? [`<em>An earlier press of Bind never finished (its client dropped or it is stale): the acting GM binds the creature now.</em>`] : []), `${esc(creature.name)} rolls Will: <strong>${esc(check?.outcome?.degree?.label ?? degree)}</strong>${check?.outcome?.total !== undefined ? ` (${check.outcome.total} vs DC ${rec.saveDC})` : ""}.`];
  if (rec.trueName && R.trueNameHostile(degree)) { lines.push(await trueNameHostile(caster, creature, degree)); lines.push(TRUE_NAME_TAIL); }
  const next = { ...rec, creatureUuid: creature.uuid, tokenUuid: chosen.document?.uuid ?? "", creatureName: creature.name, degree, state: outcome };
  if (outcome === "hostile") {
    await h().createEffectsOn(creature, [effectData(R.HOSTILE_FLAG, { name: `Enraged and hostile to ${caster.name}`, img: "icons/magic/control/fear-fright-monster-grin-red.webp", description: `${rec.spellName}: it arrived enraged and hostile, and the spell ended. It stays; the GM runs it (Q168).`, module: { hostileTo: caster.uuid } })]);
    lines.push(rec.circleFumble ? `The destabilised circle: <strong>${esc(creature.name)} arrives hostile and unbound</strong>, and the spell ends.` : `<strong>${esc(creature.name)} arrives enraged and hostile</strong>; the spell ends. It stays, and the GM runs it (Q168).`);
    await marker.setFlag(MODULE_ID, R.BINDING_FLAG, next);
    await card(caster, rec.spellName, lines.map((l) => line(l)));
    await endBindingCast(caster, marker, next);
    return next;
  }
  if (outcome === "free") {
    await marker.setFlag(MODULE_ID, R.BINDING_FLAG, next);
    await marker.update?.({ name: `${rec.spellName}: ${creature.name} (free)` });
    lines.push(`<strong>${esc(creature.name)} appears but resists</strong>, acting freely: it is not under your control and counts against no control levels. Dismissing the spell sends it back (Q168).`);
    await card(caster, rec.spellName, lines.map((l) => line(l)));
    return next;
  }
  const entry = await h().recordControlled(caster, { target: creature, token: chosen, level: int(creature.system?.identity?.level), source: "bound", castId: rec.castId, data: { module: MODULE_ID, key: rec.key, recordId: rec.id } });
  next.entryId = entry?.id ?? "";
  await h().createEffectsOn(creature, [effectData(R.BOUND_FLAG, {
    name: `Bound to ${caster.name}`, img: "icons/magic/control/silhouette-hold-change-blue.webp",
    description: `${rec.spellName}: bound, and serves ${caster.name} as a minion (minion trait). It acts on ${caster.name}'s turn; ${caster.name} commands it with a 1 AP verbal command (auditory, concentrate; Q169).${outcome === "loyal" ? ` Unusually loyal: +${R.LOYAL_BONUS} circumstance to all its checks while it serves.` : ""}`,
    system: outcome === "loyal" ? { conditionals: [{ kind: "modifier", value: R.LOYAL_BONUS, type: "circumstance", label: "Unusually loyal", scope: `all checks while serving ${caster.name}`, auto: true, always: true }] } : {},
    module: { [R.BOUND_FLAG]: { casterUuid: caster.uuid, recordId: rec.id } }
  })]);
  await marker.setFlag(MODULE_ID, R.BINDING_FLAG, next);
  await marker.update?.({ name: `${rec.spellName}: ${creature.name} (bound)` });
  const held = (await h().controlledOf(caster)).reduce((s, e) => s + Math.max(0, int(e?.level)), 0);
  const cap = int(caster.system?.magic?.controlLevels);
  lines.push(`<strong>${esc(creature.name)} is bound</strong> and serves ${esc(caster.name)} as a minion${outcome === "loyal" ? `, unusually loyal: +${R.LOYAL_BONUS} circumstance to all its checks while it serves` : ""}.`);
  lines.push(`Control Levels: <strong>${held} of ${cap}</strong>${held > cap ? " — over the cap: the highest-level creature rolls a DC 20 Will save at the start of each of your turns to break free" : ""}.`);
  lines.push("Command it with a 1 AP verbal command (auditory, concentrate; Q169) — spend the AP from the sheet.");
  await card(caster, rec.spellName, lines.map((l) => line(l)));
  return next;
}

/** End the cast (Dismiss's own path when it is registered; else the marker). */
async function endBindingCast(caster, marker, rec) {
  const ended = rec?.castId ? await h().endSpellOf(caster, rec.castId) : null;
  if (!ended && effects(caster).includes(marker)) await marker.delete?.();
}

/** Hooks.on("deleteActiveEffect"): a binding's end (dismissed, broken, dispelled, or its Critical). */
export async function bindingEnded(caster, rec) {
  if (!caster || !rec) return null;
  const who = esc(rec.creatureName ?? "the creature");
  const returns = rec.binder ? `${who} is released where it stands (Q168)` : `${who} returns to where it was summoned from — GM, remove its token (Q168)`;
  if (rec.state === "hostile") return null;
  if (rec.state === "pending") { await card(caster, rec.spellName, [line(`${esc(rec.spellName)} ends before a creature was bound.`)]); return "pending"; }
  if (rec.state === "free") { await card(caster, rec.spellName, [line(`${esc(rec.spellName)} ends: ${returns}.`)]); return "free"; }
  if (rec.entryId && (await h().controlledOf(caster)).some((e) => e?.id === rec.entryId)) await h().releaseControlled(caster, rec.entryId, { reason: "ended" });
  const creature = actorOf(await resolve(rec.creatureUuid));
  const ids = effects(creature).filter((e) => sourceOf(e) === R.BOUND_FLAG && e.flags?.[MODULE_ID]?.[R.BOUND_FLAG]?.recordId === rec.id).map((e) => e.id);
  if (creature && ids.length) await writeOn(creature, { kind: "deleteEffects", ids });
  await card(caster, rec.spellName, [line(`${rec.state === "broken" ? `${who} broke free (DC 20 Will): the binding is broken and ${esc(rec.spellName)} ends.` : `${esc(rec.spellName)} ends.`} ${returns}.`)]);
  return rec.state;
}

/** Hooks.on("trgPrimeControlReleased") (H12): the DC 20 Will save freed a bound creature — "broken" (Q169). */
export async function onControlReleasedB8a(payload = {}) {
  const { controller, entry, reason } = payload;
  if (reason !== "overflow" || entry?.data?.module !== MODULE_ID || !controller) return null;
  const marker = bindingMarkers(controller).find((e) => recordOf(e)?.entryId === entry.id || recordOf(e)?.id === entry.data?.recordId);
  if (!marker) return null;
  const rec = { ...recordOf(marker), state: "broken" };
  await marker.setFlag(MODULE_ID, R.BINDING_FLAG, rec);
  await endBindingCast(controller, marker, rec);
  return rec;
}

/* ================================================================== */
/* The Symbols (§4.3)                                                   */
/* ================================================================== */

/** The Region a symbol was carved into, and its record. */
const symbolRecord = (region) => region?.flags?.[MODULE_ID]?.[R.SYMBOL_FLAG] ?? null;
export const symbolRegions = (scene = globalThis.canvas?.scene) => Array.from(scene?.regions ?? []).filter((r) => symbolRecord(r));

async function placeSymbol(actor, ctx) {
  const key = R.keyOf(ctx.spell);
  const me = tokenOf(actor);
  if (!me || !globalThis.canvas?.scene) { await card(actor, ctx.spell?.name, [line("<em>Place your token on the map, then cast again: the symbol is carved where you can touch.</em>")]); return null; }
  const point = await pickPoint(`${ctx.spell?.name}: click the surface you carve, within reach. Escape cancels.`);
  if (!point) { await card(actor, ctx.spell?.name, [line("<em>No surface chosen: the symbol is not placed.</em>")]); return null; }
  const feet = feetFromPoint(point, me);
  if (feet === null || feet > R.TOUCH_FEET) { await card(actor, ctx.spell?.name, [line(`<em>That is ${feet ?? "?"} ft away: a symbol is carved by touch (within ${R.TOUCH_FEET} ft). Not placed.</em>`)]); return null; }
  const g = gridPx();
  const sx = Math.floor(point.x / g) * g, sy = Math.floor(point.y / g) * g;
  const rec = {
    key, spellName: ctx.spell?.name ?? "", casterUuid: actor.uuid, castId: activeEntryFor(actor, ctx.spell?.name)?.id ?? "",
    saveDC: int(ctx.saveDC), pp: int(ctx.castPP ?? ctx.ppSpent), traits: String(ctx.spellData?.traits ?? ctx.spell?.system?.traits ?? ""),
    x: sx + g / 2, y: sy + g / 2, glowing: false, lastSeen: 0
  };
  const [region] = await globalThis.canvas.scene.createEmbeddedDocuments("Region", [{
    name: `${rec.spellName} (symbol)`, color: "#7a1f9a", visibility: regionVisibility("GAMEMASTER"),
    shapes: [{ type: "rectangle", x: sx, y: sy, width: g, height: g, rotation: 0, hole: false }],
    flags: { [MODULE_ID]: { [R.SYMBOL_FLAG]: rec } }
  }]);
  if (!region) return null;
  await buttonCard(actor, `${rec.spellName} — the symbol`, [
    `<strong>${esc(rec.spellName)}</strong> is carved (DC ${rec.saveDC}), hidden from the players.`,
    "GM: when a character moves within line of sight and you determine that it looks in its direction, press <strong>The symbol flashes</strong>."
  ], [{ action: "flashSymbol", caster: actor.uuid, ref: region.uuid, label: "The symbol flashes" }, { action: "removeSymbol", caster: actor.uuid, ref: region.uuid, label: "Remove the symbol" }], { gm: true });
  return region;
}

/** Every token with line of sight to the symbol's point, on its scene. */
export function tokensInSight(region, point, mover = null) {
  const scene = region?.parent ?? globalThis.canvas?.scene;
  // THE TOKEN MOVING NOW is read at the move's end (0.11.2); the others where they stand.
  return tokens().filter((t) => (t.document?.parent ?? scene) === scene && !sightBlocked(point, mover && t.document === mover.doc ? docCentre(mover.at) : tokenCentre(t)));
}

/** The GM's checklist: "the GM determines that it looks in its direction". */
async function confirmReached(title, list) {
  if (!list.length) return [];
  const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
  if (!DialogV2?.wait) return list;
  const rows = list.map((t, i) => `<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="t${i}" checked> ${esc(t.name)}</label>`).join("");
  const picked = await DialogV2.wait({
    window: { title }, content: `<p>Every token with line of sight to the symbol. Untick any it does not reach.</p>${rows}`,
    buttons: [{ action: "ok", label: "Flash", default: true, callback: (event, button) => list.filter((t, i) => button.form?.elements?.[`t${i}`]?.checked) }, { action: "cancel", label: "Cancel" }],
    rejectClose: false
  });
  return Array.isArray(picked) ? picked : [];
}

/** A curse's hold on one creature (H17): the condition and the effect that holds it. */
async function holdCondition(creature, region, rec, spec, next, token = null) {
  const hold = effects(creature).find((e) => sourceOf(e) === R.SYMBOL_HOLD_FLAG && e.flags?.[MODULE_ID]?.[R.SYMBOL_HOLD_FLAG]?.regionUuid === region.uuid) ?? null;
  const held = hold?.flags?.[SYSTEM_ID]?.heldConditions ?? null;
  const current = int(creature.conditions?.rawValues?.get?.(spec.held) ?? creature.getConditionValue?.(spec.held));
  const step = R.heldStep({ adds: spec.adds, current, held: int(hold?.flags?.[MODULE_ID]?.[R.SYMBOL_HOLD_FLAG]?.held), contributed: int(held?.values?.[spec.held]), next });
  if (!step.worse) return `${esc(creature.name)}: no worse than before — its ${spec.held} stands.`;
  // THE CONDITION ITSELF CARRIES NO CURSE TRAIT: only the hold does, so core
  // Remove Curse (H17) finds the curse, never the plain Injured or Weakened
  // (deleting that would take off every source's share).
  await h().applyConditionTagsTo(creature, [{ key: spec.held, label: spec.held, value: step.apply }], {});
  // ALREADY FARTHER THAN 60 FT AT THE FLASH: its hour starts now (m135).
  const far = token ? (feetFromPointDoc({ x: rec.x, y: rec.y }, token.document ?? token) ?? 0) > R.SYMBOL_HOLD_FEET : false;
  const flags = {
    [SYSTEM_ID]: { heldConditions: { keys: [spec.held], values: { [spec.held]: step.contributed }, endWith: true, label: spec.name }, sourceTraits: rec.traits, counteractAs: { pp: rec.pp, dc: rec.saveDC }, ...(far ? { spellEffect: true, spellEffectEnd: worldNow() + R.SYMBOL_HOLD_SECONDS } : {}) },
    [MODULE_ID]: { source: R.SYMBOL_HOLD_FLAG, [R.SYMBOL_HOLD_FLAG]: { regionUuid: region.uuid, x: rec.x, y: rec.y, key: rec.key, held: step.held } }
  };
  const name = `${spec.name} (curse): ${spec.held} ${step.held} held`;
  // A WORSE RESULT UPDATES THE HOLD IN PLACE: deleting it would be its end (H17), and take its share off.
  if (hold) await hold.update({ name, [`flags.${SYSTEM_ID}.heldConditions`]: flags[SYSTEM_ID].heldConditions, [`flags.${MODULE_ID}.${R.SYMBOL_HOLD_FLAG}.held`]: step.held });
  else await h().createEffectsOn(creature, [{ name, img: "icons/magic/unholy/strike-body-explode-disintegrate.webp", description: `Held while within ${R.SYMBOL_HOLD_FEET} ft of the symbol and for 1 hour after it moves farther (m135); only Remove Curse ends it sooner (Q183).`, changes: [], flags }]);
  return `${esc(creature.name)}: <strong>${spec.held} ${step.held}</strong>, held by the curse (within ${R.SYMBOL_HOLD_FEET} ft and 1 hour after; only Remove Curse ends it sooner).`;
}

/** The GM's button: the symbol flashes. */
export async function flashSymbol(caster, regionUuid, { reached = null } = {}) {
  const region = await resolve(regionUuid);
  const rec = symbolRecord(region);
  if (!rec) return warn("Eldritch Arts: that symbol is gone.");
  // A DISMISSED SYMBOL DOES NOT FLASH (the Block 8a review): its cast gone from
  // the caster's active spells, the Region goes and the button says so.
  if (!castStands(caster, rec.castId)) {
    await region.delete?.();
    await card(caster, rec.spellName, [line(`${esc(rec.spellName)} has ended: the symbol is gone, and nothing flashes.`)]);
    return { refused: "ended" };
  }
  const spec = R.SYMBOLS[rec.key];
  const point = { x: rec.x, y: rec.y };
  if (!reached && region.parent && globalThis.canvas?.scene && region.parent !== globalThis.canvas.scene) return warn(`Eldritch Arts: view ${region.parent.name ?? "the symbol's scene"} to flash ${rec.spellName} (line of sight is read on the canvas).`);
  const list = reached ?? await confirmReached(`${rec.spellName} flashes`, tokensInSight(region, point));
  const lines = [`<strong>${esc(rec.spellName)} flashes</strong> (DC ${rec.saveDC}).`];
  const slain = [];
  for (const t of list) {
    const creature = t.actor;
    if (!creature) continue;
    const check = await h().rollCheck({ actor: creature, type: "save", subject: spec.save, dc: rec.saveDC, label: `${creature.name} — ${spec.save[0].toUpperCase()}${spec.save.slice(1)} (DC ${rec.saveDC})`, subtitle: rec.spellName, sourceUuid: rec.casterUuid });
    const degree = norm(check?.outcome?.degree?.key ?? "failure");
    const said = `${esc(creature.name)}: ${esc(check?.outcome?.degree?.label ?? degree)}`;
    if (spec.insanity) {
      if (!R.insanityFails(degree)) { lines.push(`${said} — unaffected.`); continue; }
      const marked = await h().markTurnTable(creature, "insanity", { margin: check?.outcome?.margin ?? null, dc: rec.saveDC, casterUuid: rec.casterUuid, spellName: "Insanity" });
      lines.push(`${said} — ${marked?.line ?? "core Insanity could not be laid (TRG Prime 3.686.0's turn table)."}`);
      continue;
    }
    const { at, rung } = R.symbolRung(rec.key, degree);
    if (!rung || (!rung.conditions && !rung.critical && !rung.dies && !rung.hold)) { lines.push(`${said} — unaffected${at && at !== degree ? ` (read as ${at})` : ""}.`); continue; }
    if (rung.conditions) {
      const inCombat = Boolean(globalThis.game?.combat?.started);
      const tags = rung.conditions.map((c) => ({ key: c.key, label: c.key, ...(c.value ? { value: c.value } : {}), ...(c.rounds ? { expiresTime: worldNow() + 6 * c.rounds, ...(inCombat ? { expiresRound: int(globalThis.game.combat.round) + c.rounds } : {}) } : {}) }));
      await h().applyConditionTagsTo(creature, tags, { sourceTraits: rec.traits });
      lines.push(`${said} — ${rung.conditions.map((c) => `${c.key}${c.value ? ` ${c.value}` : ""}${c.rounds ? ` for ${c.rounds} round` : ""}`).join(" and ")}.`);
    } else if (rung.critical) {
      // THE SYMBOL'S DC IS THE CRITICAL'S ATTACK BONUS (review), as the core's
      // own save-spell criticals pass theirs (cast-workflow's ladder): without
      // it the Death and Fatal saves are against DC 10.
      await h().rollCriticalInjury(caster, { targetActor: creature, severity: rung.critical.severity, damageType: rung.critical.damageType, attackBonus: rec.saveDC });
      lines.push(`${said} — a <strong>${rung.critical.severity} ${rung.critical.damageType} critical</strong>.`);
      if (await h().isDead(creature)) slain.push(creature);
    } else if (rung.dies) {
      const ds = Math.max(0, int(creature.system?.combat?.deathState ?? 5) - int(creature.getConditionValue?.("doomed")));
      await h().applyConditionTagsTo(creature, [{ key: "dying", label: "dying", value: ds + 1 }], {});
      lines.push(`${said} — <strong>it dies</strong>.`);
      slain.push(creature);
    } else if (rung.hold) {
      lines.push(`${said} — ${await holdCondition(creature, region, rec, spec, rung.hold, t)}`);
    }
  }
  if (!list.length) lines.push("<em>No token was reached.</em>");
  if (spec.fadesOnDeath && slain.length) {
    lines.push(`A creature died from the symbol: <strong>it fades and the spell ends</strong> (m132).`);
    await card(caster, rec.spellName, lines.map((l) => line(l)));
    await region.delete?.();
    if (rec.castId) await h().endSpellOf(caster, rec.castId);
    return { slain: slain.length, faded: true };
  }
  await region.update?.({ visibility: regionVisibility("ALWAYS"), [`flags.${MODULE_ID}.${R.SYMBOL_FLAG}.glowing`]: true, [`flags.${MODULE_ID}.${R.SYMBOL_FLAG}.lastSeen`]: worldNow() });
  lines.push("It glows until no character has had line of sight to it for 10 minutes.");
  await card(caster, rec.spellName, lines.map((l) => line(l)));
  return { slain: slain.length, faded: false, reached: list.length };
}

/** The GM's button: remove the symbol (and end its cast, when it is registered). */
export async function removeSymbol(caster, regionUuid) {
  const region = await resolve(regionUuid);
  const rec = symbolRecord(region);
  if (!rec) return warn("Eldritch Arts: that symbol is gone.");
  await region.delete?.();
  if (rec.castId) await h().endSpellOf(caster, rec.castId);
  await card(caster, rec.spellName, [line(`${esc(rec.spellName)} is removed.`)]);
  return true;
}

/**
 * A SYMBOL WHOSE CAST HAS ENDED (dismissed, dispelled) loses its Region, on
 * every scene (acting GM). Hooks.on("updateActor") when the caster's active
 * spells change: the core fires no hook of its own at a spell's end.
 */
export async function removeEndedSymbols(caster) {
  if (!isActingGM() || !caster) return 0;
  let n = 0;
  for (const scene of allScenes()) {
    const gone = symbolRegions(scene).filter((r) => { const rec = symbolRecord(r); return rec.casterUuid === caster.uuid && rec.castId && !castStands(caster, rec.castId); });
    if (!gone.length) continue;
    await scene.deleteEmbeddedDocuments?.("Region", gone.map((r) => r.id))?.catch?.(() => {});
    for (const r of gone) await card(caster, symbolRecord(r).spellName, [line(`${esc(symbolRecord(r).spellName)} has ended: the symbol is gone.`)]);
    n += gone.length;
  }
  return n;
}
/** Hooks.on("updateActor"): only a change to the active spells matters. */
export async function onActorUpdatedB8a(actor, change = {}) {
  const flags = change?.flags?.[SYSTEM_ID];
  if (!flags || !("activeSpells" in flags || "-=activeSpells" in flags)) return 0;
  return removeEndedSymbols(actor);
}

/** The glow (acting GM): someone with line of sight keeps it; 10 minutes of none ends it. */
export async function refreshSymbolGlow(scene = null, mover = null) {
  if (!isActingGM()) return 0;
  let changed = 0;
  // EVERY SCENE (the Block 8a review), not only the one the GM is viewing.
  for (const region of (scene ? [scene] : allScenes()).flatMap((sc) => symbolRegions(sc))) {
    const rec = symbolRecord(region);
    if (!rec?.glowing) continue;
    // A SCENE NOT ON THE CANVAS: its walls are not loaded, so line of sight
    // cannot be read. A token there may be looking — left as it is; no token
    // there at all is no one looking.
    const viewed = !region.parent || region.parent === globalThis.canvas?.scene;
    if (!viewed && Array.from(region.parent?.tokens ?? []).length) continue;
    let seen = viewed ? tokensInSight(region, { x: rec.x, y: rec.y }, mover) : [];
    if (R.SYMBOLS[rec.key]?.livingOnly) { const alive = []; for (const t of seen) if (!(await h().isDead(t.actor))) alive.push(t); seen = alive; }
    const t = worldNow();
    if (seen.length) { if (t > Number(rec.lastSeen)) { await region.update?.({ [`flags.${MODULE_ID}.${R.SYMBOL_FLAG}.lastSeen`]: t }); changed += 1; } continue; }
    if (R.glowLapsed(rec.lastSeen, t)) { await region.update?.({ visibility: regionVisibility("GAMEMASTER"), [`flags.${MODULE_ID}.${R.SYMBOL_FLAG}.glowing`]: false }); changed += 1; }
  }
  return changed;
}

/** A curse's hour (m135), on the mover's own client: started past 60 ft, stopped within it. */
export async function refreshSymbolHolds(actor, doc, at = null) {
  // THE TOKEN'S DOCUMENT (the Block 8a review): the mover's client need not be viewing its scene.
  doc = doc?.document ?? doc;
  const pos = at;
  if (!actor || !doc || !actsFor(actor)) return 0;
  let changed = 0;
  for (const fx of effects(actor).filter((e) => sourceOf(e) === R.SYMBOL_HOLD_FLAG)) {
    const at = fx.flags[MODULE_ID][R.SYMBOL_HOLD_FLAG];
    const region = await resolve(at.regionUuid);
    const sameScene = !region || (region.parent ?? null) === (doc.parent ?? null);
    // THE MOVE'S END (0.11.2), not the document's old square.
    const feet = sameScene && region ? feetFromPointDoc({ x: at.x, y: at.y }, pos ?? doc) : Infinity;
    const running = Number.isFinite(Number(fx.flags?.[SYSTEM_ID]?.spellEffectEnd));
    const clock = R.holdClock(feet, running);
    if (clock === "start") { await fx.update({ [`flags.${SYSTEM_ID}.spellEffect`]: true, [`flags.${SYSTEM_ID}.spellEffectEnd`]: worldNow() + R.SYMBOL_HOLD_SECONDS }); changed += 1; }
    if (clock === "stop") { await fx.update({ [`flags.${SYSTEM_ID}.-=spellEffectEnd`]: null }); changed += 1; }
  }
  return changed;
}

/* ================================================================== */
/* Exploration and utility (§3.2)                                        */
/* ================================================================== */

const areaRecord = (region) => region?.flags?.[MODULE_ID]?.[R.AREA8A_FLAG] ?? null;
export const area8aRegions = (key, scene = globalThis.canvas?.scene) => Array.from(scene?.regions ?? []).filter((r) => areaRecord(r)?.key === key && worldNow() < Number(areaRecord(r)?.until ?? Infinity));

async function createArea(actor, name, shapes, rec, { hidden = false } = {}) {
  const [region] = await globalThis.canvas.scene.createEmbeddedDocuments("Region", [{
    name, color: "#a07a2a", visibility: regionVisibility(hidden ? "GAMEMASTER" : "ALWAYS"), shapes, flags: { [MODULE_ID]: { [R.AREA8A_FLAG]: rec } }
  }]);
  return region ?? null;
}
const square = (p) => { const g = gridPx(); return { type: "rectangle", x: Math.floor(p.x / g) * g, y: Math.floor(p.y / g) * g, width: g, height: g, rotation: 0, hole: false }; };
const squareCentre = (s) => ({ x: s.x + s.width / 2, y: s.y + s.height / 2 });
const durationOf = (ctx) => String(ctx.warpMods?.durationText || ctx.spellData?.duration || ctx.spell?.system?.duration || "");
const secondsOf = (text) => { const m = /(\d+)\s*(round|minute|hour|day)s?/i.exec(String(text ?? "")); return m ? int(m[1]) * { round: 6, minute: 60, hour: 3600, day: 86400 }[m[2].toLowerCase()] : 0; };

/** Arcane Pouch: a new casting ends the last (its bonus); the pouch itself by hand. */
async function arcanePouch(actor, ctx) {
  const mine = effects(actor).filter((e) => e.origin && e.origin === ctx.spell?.uuid);
  const older = mine.slice(0, -1).map((e) => e.id);
  if (older.length) await actor.deleteEmbeddedDocuments("ActiveEffect", older);
  await card(actor, ctx.spell?.name, [line(`The pouch holds up to ${R.POUCH_CAPACITY_LB} pounds and weighs ${R.POUCH_WEIGHT_LB} pounds (by hand).${older.length ? " Your earlier arcane pouch is nonmagical again." : ""}`)]);
}

/** Archway of Ants: the caster clicks its squares. */
async function archwayOfAnts(actor, ctx) {
  const me = tokenOf(actor);
  if (!me || !globalThis.canvas?.scene) return card(actor, ctx.spell?.name, [line("<em>Place your token on the map: the archway is clicked square by square.</em>")]);
  const n = R.archwaySquares(ctx.warpMods?.bonusValue);
  const shapes = [];
  for (let i = 0; i < n; i += 1) {
    const p = await pickPoint(`${ctx.spell?.name}: click square ${i + 1} of ${n}, within ${R.ARCHWAY_RANGE_FEET} ft. Escape ends.`);
    if (!p) break;
    const s = square(p);
    const feet = feetFromPoint(squareCentre(s), me);
    if (feet === null || feet > R.ARCHWAY_RANGE_FEET) { warn(`That square is beyond ${R.ARCHWAY_RANGE_FEET} ft.`); i -= 1; continue; }
    if (shapes.some((x) => x.x === s.x && x.y === s.y)) { i -= 1; continue; }
    shapes.push(s);
  }
  if (!shapes.length) return card(actor, ctx.spell?.name, [line("<em>No square clicked: the archway is not built.</em>")]);
  const hp = int(actor.system?.resources?.hp?.max);
  const allowance = int(actor.system?.encumbrance?.max) || R.weightAllowance(actor.system?.attributes?.strength?.total);
  const rec = { key: "archwayOfAnts", casterUuid: actor.uuid, db: R.ARCHWAY_DB, hp, load: R.archwayLoad(allowance), until: worldNow() + (secondsOf(durationOf(ctx)) || 600) };
  const region = await createArea(actor, `${ctx.spell?.name}: DB ${rec.db}, ${rec.hp} HP, bears ${rec.load} lb`, shapes, rec);
  if (!region) return null;
  await buttonCard(actor, ctx.spell?.name, [`The archway: ${shapes.length} square${shapes.length === 1 ? "" : "s"}, <strong>DB ${rec.db}</strong>, <strong>${rec.hp} HP</strong>, bears <strong>${rec.load} lb</strong> (10 × Weight Allowance ${allowance}); a pound more and it crumbles. For 10 minutes.`, "<em>By hand: its shape, moving it, the weight on it and its damage.</em>"],
    [{ action: "crumbleArchway", caster: actor.uuid, ref: region.uuid, label: "The archway crumbles" }], { gm: true });
  return region;
}
export async function crumbleArchway(caster, regionUuid) {
  const region = await resolve(regionUuid);
  if (!areaRecord(region)) return warn("Eldritch Arts: the archway is already gone.");
  await region.delete?.();
  await card(caster, "Archway of Ants", [line("The archway crumbles.")]);
  return true;
}

/** Argent Mark: a creature within reach, or a named object; "Where is the mark?". */
const MARKS_FLAG = "argentMarks8a";
async function argentMark(actor, ctx) {
  const me = tokenOf(actor);
  const near = me ? tokens().filter((t) => t !== me && (feetBetween(me, t) ?? Infinity) <= R.TOUCH_FEET) : [];
  const pick = await h().chooseFromList(ctx.spell?.name, "What do you brand? (a creature must be willing, m96)", [["object", "An object"], ...near.map((t) => [t.document?.uuid ?? t.id, `${t.name} (a willing creature)`])]);
  if (!pick) return card(actor, ctx.spell?.name, [line("<em>Nothing branded.</em>")]);
  const duration = durationOf(ctx);
  const seconds = R.markSeconds(duration);
  const castId = activeEntryFor(actor, ctx.spell?.name)?.id ?? "";
  const id = globalThis.foundry?.utils?.randomID?.() ?? String(Date.now());
  let entry;
  if (pick === "object") entry = { id, castId, targetUuid: "", name: "an object", until: seconds ? worldNow() + seconds : null };
  else {
    const t = near.find((x) => (x.document?.uuid ?? x.id) === pick);
    if (!t) return null;
    await h().createEffectsOn(t.actor, [effectData("argentMark", {
      name: `Argent Mark (${actor.name})`, img: ctx.spell?.img, description: `A silvery glyph, visible only under moonlight or to ${actor.name}, who always knows its direction and distance while on the same plane.`,
      system: castId ? { castId } : {}, module: { argentMark: { casterUuid: actor.uuid, id } }, expiry: seconds ? forSeconds(seconds) : null
    })]);
    entry = { id, castId, targetUuid: t.actor.uuid, tokenUuid: t.document?.uuid ?? "", name: t.name, until: seconds ? worldNow() + seconds : null };
  }
  const list = Array.from(actor.flags?.[MODULE_ID]?.[MARKS_FLAG] ?? []).filter((m) => m.until === null || Number(m.until) > worldNow()).slice(-19);
  await actor.setFlag(MODULE_ID, MARKS_FLAG, [...list, entry]);
  await buttonCard(actor, ctx.spell?.name, [`<strong>${esc(entry.name)}</strong> bears your Argent Mark (${esc(duration || "1 week")}).`], [{ action: "markWhere", caster: actor.uuid, ref: id, label: "Where is the mark?" }], { owners: true });
  return entry;
}
export async function markWhere(caster, id) {
  const m = Array.from(caster.flags?.[MODULE_ID]?.[MARKS_FLAG] ?? []).find((x) => x.id === id);
  if (!m || (m.until !== null && Number(m.until) <= worldNow())) return card(caster, "Argent Mark", [line("<em>That mark has faded.</em>")]);
  const me = tokenOf(caster);
  const there = m.targetUuid ? tokens().find((t) => t.actor?.uuid === m.targetUuid || t.document?.uuid === m.tokenUuid) : null;
  if (!me || !there) return card(caster, "Argent Mark", [line(`<em>${esc(m.name)} is not on this map with you: its direction and distance "while on the same plane" are the GM's.</em>`)]);
  const { compass } = await import("./areas.mjs");
  const feet = feetBetween(me, there);
  return card(caster, "Argent Mark", [line(`<strong>${esc(m.name)}</strong>: ${feet ?? "?"} ft, ${compass(tokenCentre(me), tokenCentre(there))}.`)]);
}

/** Blood Biography: the GM's card. */
const PENDING_FLAG = "pending8a";
async function bloodBiography(actor, ctx) {
  const id = globalThis.foundry?.utils?.randomID?.() ?? String(Date.now());
  const pending = { ...(actor.flags?.[MODULE_ID]?.[PENDING_FLAG] ?? {}), [id]: { key: "bloodBiography", saveDC: int(ctx.saveDC), spellName: ctx.spell?.name ?? "Blood Biography", at: worldNow() } };
  await actor.setFlag(MODULE_ID, PENDING_FLAG, pending);
  await buttonCard(actor, ctx.spell?.name, [`<strong>${esc(ctx.spell?.name)}</strong> (DC ${int(ctx.saveDC)}): whose blood is it? If it is living or undead, select its token and roll its Will save (Success or better blocks the spell).`],
    [{ action: "bloodSave", caster: actor.uuid, ref: id, label: "Living or undead: roll its Will save" }, { action: "bloodDead", caster: actor.uuid, ref: id, label: "Dead: no save" }], { gm: true });
  return id;
}
async function takePending(caster, id) {
  const all = { ...(caster.flags?.[MODULE_ID]?.[PENDING_FLAG] ?? {}) };
  const p = all[id];
  if (!p) return null;
  delete all[id];
  await caster.setFlag(MODULE_ID, PENDING_FLAG, all);
  return p;
}
const bloodAnswers = (name) => [`The answers appear for ${esc(name)}, in a language it can read — GM:`, ...R.BLOOD_QUESTIONS.map((q) => `• ${esc(q)}`)];
export async function bloodSave(caster, id, { token = null } = {}) {
  const t = token ?? globalThis.canvas?.tokens?.controlled?.[0] ?? null;
  if (!t?.actor) return warn("Blood Biography: select the token of the blood's owner first.");
  const p = await takePending(caster, id);
  if (!p) return warn("Blood Biography: already answered.");
  const check = await h().rollCheck({ actor: t.actor, type: "save", subject: "will", dc: p.saveDC, label: `${t.actor.name} — Will (DC ${p.saveDC})`, subtitle: p.spellName, sourceUuid: caster.uuid });
  const degree = norm(check?.outcome?.degree?.key ?? "failure");
  if (R.bloodBlocked(degree)) return card(caster, p.spellName, [line(`${esc(t.actor.name)} rolls ${esc(degree)}: <strong>the spell is blocked</strong> (M35).`)]);
  return card(caster, p.spellName, [line(`${esc(t.actor.name)} rolls ${esc(degree)}.`), ...bloodAnswers(caster.name).map((l) => line(l))]);
}
export async function bloodDead(caster, id) {
  const p = await takePending(caster, id);
  if (!p) return warn("Blood Biography: already answered.");
  return card(caster, p.spellName, [line("The blood's owner is dead: no save."), ...bloodAnswers(caster.name).map((l) => line(l))]);
}

/** Harmonic Rift: two openings. */
async function harmonicRift(actor, ctx) {
  const me = tokenOf(actor);
  if (!me || !globalThis.canvas?.scene) return card(actor, ctx.spell?.name, [line("<em>Place your token on the map: the openings are clicked.</em>")]);
  const ends = [];
  while (ends.length < 2) {
    const p = await pickPoint(`${ctx.spell?.name}: click opening ${ends.length + 1} of 2, within ${R.RIFT_RANGE_FEET} ft and in your sight. Escape cancels.`);
    if (!p) return card(actor, ctx.spell?.name, [line("<em>Cancelled: the rift does not open.</em>")]);
    const s = square(p);
    const c = squareCentre(s);
    const feet = feetFromPoint(c, me);
    if (feet === null || feet > R.RIFT_RANGE_FEET) { warn(`That opening is beyond ${R.RIFT_RANGE_FEET} ft.`); continue; }
    if (sightBlocked(tokenCentre(me), c)) { warn("You cannot see that square."); continue; }
    ends.push(s);
  }
  const until = worldNow() + (secondsOf(durationOf(ctx)) || 60);
  const base = { key: "harmonicRift", casterUuid: actor.uuid, spellUuid: ctx.spell?.uuid ?? "", spellName: ctx.spell?.name ?? "Harmonic Rift", traits: String(ctx.spellData?.traits ?? ""), dc: int(ctx.saveDC), dice: R.riftDice(ctx.warpMods?.damageDice), until };
  const a = await createArea(actor, `${ctx.spell?.name} (opening 1)`, [ends[0]], { ...base, end: 0 });
  const b = await createArea(actor, `${ctx.spell?.name} (opening 2)`, [ends[1]], { ...base, end: 1, pair: a?.id ?? "" });
  if (a && b) await a.update?.({ [`flags.${MODULE_ID}.${R.AREA8A_FLAG}.pair`]: b.id });
  await card(actor, ctx.spell?.name, [line(`The rift opens for ${secondsOf(durationOf(ctx)) >= 600 ? "10 minutes" : "1 minute"}: a token that ends a move in one opening steps out of the other. Your enemies passing roll basic Fortitude (DC ${base.dc}) against ${base.dice} sonic.`)]);
  return [a, b];
}

/** A token's move ending in an opening: the passage (on the mover's client). */
export async function riftPassage(doc, options = {}, at = null) {
  if (options?.eaRift) return null;
  // THE MOVE'S END, never the document's (stale) position (0.11.2).
  const pos = at ?? doc;
  // THE TOKEN'S DOCUMENT (the Block 8a review): the mover's client need not be
  // viewing the scene, so the passage reads the document, not a placeable.
  const actor = doc?.actor ?? null;
  if (!doc || !actor || !actsFor(actor)) return null;
  // A MOVE STILL UNDER WAY (0.11.1, review): V14 can split one move into
  // several updates when something pauses it partway; the passage waits for
  // the update with no waypoints left to go. The same field the core reads
  // (movement-workflow's `movement.pending.waypoints`); absent, the move is done.
  // V14 hands the record to updateToken as `_movement` (seen live on 14.367;
  // `movement` was absent on the GM's client): both are read, and with
  // neither the move is taken as done.
  const pending = (options?.movement?.[doc.id] ?? options?._movement?.[doc.id])?.pending?.waypoints;
  if (Array.isArray(pending) && pending.length) return null;
  for (const region of area8aRegions("harmonicRift", doc.parent ?? globalThis.canvas?.scene)) {
    // "ENDS A MOVE IN THE OPENING" FROM THE NEW POSITION ONLY (0.11.1; found
    // live): in V14's updateToken hook `doc.regions` still holds the regions
    // the token was in BEFORE the move, so a token walking out of an opening
    // was sent through. The token's centre, where it now stands, is tested.
    const inside = await h().regionContains(region, docCentre(pos));
    if (!inside) continue;
    const rec = areaRecord(region);
    const other = Array.from((doc.parent ?? globalThis.canvas.scene)?.regions ?? []).find((r) => r.id === rec.pair || (areaRecord(r)?.pair === region.id && r.id !== region.id));
    const shape = other?.shapes?.[0];
    if (!shape) return null;
    const caster = actorOf(await resolve(rec.casterUuid));
    // THE SPELL THE CORE'S CARD NAMES (its item, or its name and traits when the item is gone).
    const spell = (await resolve(rec.spellUuid)) ?? { name: rec.spellName ?? "Harmonic Rift", system: { traits: rec.traits ?? "" } };
    const lines = [];
    if (await h().teleportationFails(actor)) {
      await card(actor, "Harmonic Rift", [line(`${esc(actor.name)} steps into the rift, but a second teleport this turn <strong>fails</strong>.`)]);
      return { moved: false };
    }
    // THE SCENE'S OWN GRID (the Block 8a re-review): the mover's client may be viewing another scene.
    const g = sceneGridOf(doc.parent).size;
    const dest = { x: Number(shape.x) + Number(shape.width ?? g) / 2 - (Math.max(1, Number(pos.width ?? 1)) * g) / 2, y: Number(shape.y) + Number(shape.height ?? g) / 2 - (Math.max(1, Number(pos.height ?? 1)) * g) / 2 };
    // DID IT ACTUALLY MOVE (0.11.2; found live)? The core refuses a move that
    // would end in an occupied space, and the update then returns nothing.
    // Asked before anything is spent: no Spatial Awareness card, no save.
    const result = await doc.update({ x: dest.x, y: dest.y }, { eaRift: true, teleport: true, animate: false });
    // COUNTED ONLY IF IT LANDED (0.11.2, review): something returned AND the
    // document's source now stands at the far opening. A refused update has
    // been seen to return undefined on 14.367; one that resolves with the
    // document but did not move is treated the same.
    const moved = Boolean(result) && Number(doc._source?.x) === dest.x && Number(doc._source?.y) === dest.y;
    if (!moved) {
      await card(actor, "Harmonic Rift", [line(`${esc(actor.name)} reaches the rift, but <strong>the far opening is occupied</strong> (or the move was refused): it does not pass.`)]);
      return { moved: false, occupied: true };
    }
    if (caster) lines.push(...(await h().teleportationArrives(caster, spell, [actor]) ?? []));
    // THE CASTER'S SIDE FROM ITS TOKEN ON THIS SCENE (a document), else its prototype.
    const casterDoc = Array.from(doc.parent?.tokens ?? []).find((t) => t.actor === caster || (t.actorId && t.actorId === caster?.id)) ?? null;
    const casterSide = casterDoc?.disposition ?? caster?.prototypeToken?.disposition ?? tokenOf(caster)?.document?.disposition;
    if (caster && enemiesBySide(casterSide, doc.disposition)) {
      const hit = await h().basicSaveHit({ caster, target: actor, save: "fortitude", dc: rec.dc, label: "Harmonic Rift", formula: rec.dice, type: "sonic" });
      // THE CORE'S LINE IS ALREADY HTML (0.11.1; found live: "&lt;strong&gt;Failure"): used as Block 2's, 5b's and 6b1's are.
      lines.push(`The Grey's music: ${rec.dice} sonic (basic Fortitude, DC ${rec.dc}). ${hit?.line ?? ""}`);
    }
    await card(actor, "Harmonic Rift", [line(`${esc(actor.name)} steps through the rift.`), ...lines.map((l) => line(l))]);
    return { moved: true };
  }
  return null;
}

/** Riserune: a hidden 10-ft Region. */
async function riserune(actor, ctx) {
  const me = tokenOf(actor);
  if (!me || !globalThis.canvas?.scene) return card(actor, ctx.spell?.name, [line("<em>Place your token on the map: the rune is inscribed where you touch.</em>")]);
  const p = await pickPoint(`${ctx.spell?.name}: click the surface you inscribe, within reach. Escape cancels.`);
  if (!p) return card(actor, ctx.spell?.name, [line("<em>No surface chosen.</em>")]);
  const s = square(p);
  const c = squareCentre(s);
  if ((feetFromPoint(c, me) ?? Infinity) > R.TOUCH_FEET) return card(actor, ctx.spell?.name, [line(`<em>The rune is inscribed by touch (within ${R.TOUCH_FEET} ft): not placed.</em>`)]);
  const r = (R.RISERUNE_FEET / gridFeet()) * gridPx() + gridPx() / 2;
  const rec = { key: "riserune", casterUuid: actor.uuid, x: c.x, y: c.y, records: [], until: worldNow() + (secondsOf(durationOf(ctx)) || 3600) };
  const region = await createArea(actor, `${ctx.spell?.name} (rune)`, [{ type: "ellipse", x: c.x, y: c.y, radiusX: r, radiusY: r, rotation: 0, hole: false }], rec, { hidden: true });
  if (!region) return null;
  await buttonCard(actor, ctx.spell?.name, [`The rune is inscribed: it records up to ${R.RISERUNE_TRIGGERS} Small or larger creatures passing within ${R.RISERUNE_FEET} ft, for the hour.`], [{ action: "replayRune", caster: actor.uuid, ref: region.uuid, label: "Replay the rune" }], { owners: true });
  return region;
}
/** A token's move within 10 ft of a riserune (acting GM: the rune is the map's). */
export async function riseruneTriggered(doc, at = null) {
  if (!isActingGM()) return null;
  const actor = doc?.actor ?? null;
  if (!doc || !actor || !R.riseruneTriggeredBy(actor.system?.identity?.size ?? doc.size ?? "medium")) return null;
  let n = 0;
  for (const region of area8aRegions("riserune", doc.parent ?? globalThis.canvas?.scene)) {
    const rec = areaRecord(region);
    if (rec.records.length >= R.RISERUNE_TRIGGERS) continue;
    // THE MOVE'S END (0.11.2), not the document's old square.
    const feet = feetFromPointDoc({ x: rec.x, y: rec.y }, at ?? doc);
    if (feet === null || feet > R.RISERUNE_FEET) continue;
    const records = [...rec.records, { name: actor.name, img: doc.texture?.src ?? actor.img ?? "", time: worldNow() }];
    await region.update?.({ [`flags.${MODULE_ID}.${R.AREA8A_FLAG}.records`]: records });
    n += 1;
  }
  return n;
}
export async function replayRune(caster, regionUuid) {
  const region = await resolve(regionUuid);
  const rec = areaRecord(region);
  if (!rec) return card(caster, "Riserune", [line("<em>The rune has faded.</em>")]);
  const me = tokenOf(caster);
  if (!me || (feetFromPoint({ x: rec.x, y: rec.y }, me) ?? Infinity) > R.TOUCH_FEET) return warn("Riserune: touch the rune to replay it (within reach).");
  const lines = rec.records.length ? rec.records.map((r, i) => `${i + 1}. <strong>${esc(r.name)}</strong> (world time ${r.time})`) : ["No one has passed."];
  await buttonCard(caster, "Riserune — the echoes", lines, [], { owners: true });
  return rec.records.length;
}

/** The module's Regions that have run their time (acting GM). */
export async function expireAreas8a(scene = null) {
  if (!isActingGM()) return 0;
  let n = 0;
  // EVERY SCENE (the Block 8a review): a rift on a scene nobody views still ends.
  for (const sc of scene ? [scene] : allScenes()) {
    const gone = Array.from(sc?.regions ?? []).filter((r) => areaRecord(r) && Number(areaRecord(r).until) <= worldNow()).map((r) => r.id);
    if (gone.length) await sc.deleteEmbeddedDocuments("Region", gone).catch(() => {});
    n += gone.length;
  }
  return n;
}

/* ================================================================== */
/* The card buttons                                                     */
/* ================================================================== */

export const BUTTONS = Object.freeze({
  bindCreature: { gm: true, run: (c, ref) => bindCreature(c, ref) },
  flashSymbol: { gm: true, run: (c, ref) => flashSymbol(c, ref) },
  removeSymbol: { gm: true, run: (c, ref) => removeSymbol(c, ref) },
  crumbleArchway: { gm: true, run: (c, ref) => crumbleArchway(c, ref) },
  bloodSave: { gm: true, run: (c, ref) => bloodSave(c, ref) },
  bloodDead: { gm: true, run: (c, ref) => bloodDead(c, ref) },
  markWhere: { owner: true, run: (c, ref) => markWhere(c, ref) },
  replayRune: { owner: true, run: (c, ref) => replayRune(c, ref) }
});
/** A button pressed: only the GM presses a GM's button, only the caster's owner the caster's. */
export async function onCardButton(action, casterUuid, ref, user = globalThis.game?.user) {
  const spec = BUTTONS[action];
  if (!spec) return false;
  if (spec.gm && !user?.isGM) return warn("Eldritch Arts: only the GM presses that.");
  const caster = actorOf(await resolve(casterUuid));
  if (!caster) return warn("Eldritch Arts: the caster is gone.");
  if (spec.owner && !caster.isOwner) return warn(`Eldritch Arts: only ${caster.name}'s player presses that.`);
  return spec.run(caster, ref);
}
export function registerBlock8aCards() {
  globalThis.Hooks?.on?.("renderChatMessageHTML", (message, html) => {
    for (const button of html?.querySelectorAll?.("[data-ea8a]") ?? []) {
      button.addEventListener("click", (event) => {
        event.preventDefault();
        onCardButton(button.dataset.ea8a, button.dataset.ea8aCaster, button.dataset.ea8aRef).catch((err) => console.warn("Eldritch Arts | Block 8a card", err));
      });
    }
  });
}

/* ================================================================== */
/* Hooks                                                                */
/* ================================================================== */

/** Hooks.on("trgPrimeSpellSettled"). */
export async function onSpellSettledB8a(ctx = {}) {
  const actor = ctx.actor;
  const key = R.keyOf(ctx.spell);
  if (!key || !ctx.cast || ctx.refunded || !actor?.isOwner) return null;
  if (R.isBinding(key)) return startBinding(actor, ctx);
  if (R.isSymbol(key)) return placeSymbol(actor, ctx);
  switch (key) {
    case "arcanePouch": return arcanePouch(actor, ctx);
    case "archwayOfAnts": return archwayOfAnts(actor, ctx);
    case "argentMark": return argentMark(actor, ctx);
    case "bloodBiography": return bloodBiography(actor, ctx);
    case "harmonicRift": return harmonicRift(actor, ctx);
    case "riserune": return riserune(actor, ctx);
    default: return null;
  }
}

/** Hooks.on("deleteActiveEffect"): a binding's marker gone is its spell's end. */
export async function onEffectDeletedB8a(effect) {
  if (sourceOf(effect) !== R.BINDING_FLAG) return null;
  const caster = effect?.parent;
  if (!caster || caster.documentName !== "Actor" || !actsFor(caster)) return null;
  return bindingEnded(caster, effect.flags[MODULE_ID][R.BINDING_FLAG]);
}

/** Hooks.on("updateToken"): a rift's passage, a riserune's trigger, a curse's hour, a symbol's glow. */
export async function onTokenMovedB8a(doc, change = {}, options = {}) {
  if (!("x" in (change ?? {})) && !("y" in (change ?? {}))) return null;
  // WHERE THE MOVE ENDS, from `change` (0.11.2): the document is stale here.
  const at = endPositionOf(doc, change);
  const rift = await riftPassage(doc, options, at);
  await riseruneTriggered(doc, at);
  await refreshSymbolHolds(doc?.actor, doc, at);
  await refreshSymbolGlow(doc?.parent ?? null, { doc, at });
  return rift;
}

/** Hooks.on("updateWorldTime"): the module's Regions' ends, and the glow. */
export async function onWorldTimeB8a() {
  await expireAreas8a();
  await refreshSymbolGlow();
}

export function registerBlock8a(api, moduleId) {
  // TELEPORTATION WITHOUT A TELEPORT AT THE CAST (the audit's §5): Arcane
  // Pouch moves nobody; Harmonic Rift's passages are each their own teleport.
  api.registerDeferredTeleport?.("eaArcanePouch", (ctx = {}) => R.keyOf(ctx.spell) === "arcanePouch", moduleId);
  api.registerDeferredTeleport?.("eaHarmonicRift", (ctx = {}) => R.keyOf(ctx.spell) === "harmonicRift", moduleId);
}

/** For the harness. */
export const INTERNALS_B8A = Object.freeze({ startBinding, placeSymbol, holdCondition, arcanePouch, archwayOfAnts, argentMark, bloodBiography, harmonicRift, riserune, takeBinderChoice, cardHTML });
