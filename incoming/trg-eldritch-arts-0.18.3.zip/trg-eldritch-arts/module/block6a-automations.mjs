/**
 * Eldritch Arts — Block 6 (0.9.0), group A: what the Pacts, Hex Weaver,
 * Bloodmage, High Mage, Birthrager, Blood of the Wyrm and its class feats,
 * Sanguine Channel and Crimson Rite do that is not data. On TRG Prime 3.684.0.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md (Appendix A) as Graham
 * answered it on 4 November 2026 (Q89–Q149, as proposed; one release). The
 * pure rules come first so the harness can run them; the Foundry side follows.
 *
 *   Uses        Draconic Pact, Elemental Pact (the choice), Hex Weaver (the
 *               High Magic spell), High Mage and Birthrager (the borrowed
 *               birthright), Blood of the Wyrm and Draconic Claws (the dragon
 *               type), Crimson Rite (suppress), Elemental Exhalation,
 *               Wyrm Ascendant
 *   Seams       Bloodmage's cast PP source (G2), Sanguine Channel's cast
 *               option (G14), Blood of the Wyrm's warps (G15) and
 *               eligibility (G9), Birthrager's BSB floor (G11) and feat gate,
 *               the Pacts' exclusive group (Q92), the hex access (Q21, Q103),
 *               High Mage's class-skill grant
 *   Hooks       spell settled (Draconic Pact's roar, Void Pact's DB, Crimson
 *               Rite's critical, Sanguine Channel's Bleed); item created,
 *               updated, deleted (a Warlock's Pact spell, Void Pact's
 *               Darkvision, the dragon type's effects, Crimson Rite); effect
 *               created, updated, deleted (Crimson Rite's Bleed window, Wyrm
 *               Ascendant's flight and landing)
 *
 * The hook handlers are exported for the lead to wire in
 * scripts/eldritch-arts.mjs; each says which `Hooks.on` event it expects.
 */
import { grantPactSpellB7 } from "./block7-automations.mjs";
import { MODULE_ID, SYSTEM_ID, effectData, expiryFor, forSeconds, ownEffects, combatFor } from "./effects-clock.mjs";
import { norm, int, esc, h, line, card, warn, levelOf, owned, tokenOf, spendAP } from "./block1-automations.mjs";
import { actsFor, spellIndex, birthrightOf, dragonTypeOf, DRAGON_TYPES } from "./block3-automations.mjs";
import { warlockCopy } from "./block4-automations.mjs";

/* ------------------------------------------------------------------ */
/* Data                                                                 */
/* ------------------------------------------------------------------ */

export const PACT_NAMES = Object.freeze(["Angelic Pact", "Demonic Pact", "Draconic Pact", "Elemental Pact", "Fey Pact", "Grave Pact", "Void Pact"]);

/** Draconic Pact: "acid, cold, electricity, fire or poison". */
export const DRACONIC_ENERGIES = Object.freeze(["acid", "cold", "electricity", "fire", "poison"]);
/** Elemental Pact: "air -electricity, earth – acid, fire – fire or water – cold". */
export const ELEMENT_ENERGY = Object.freeze({ air: "electricity", earth: "acid", fire: "fire", water: "cold" });
/** The core's damage types (config.mjs DAMAGE_TYPES), for the Elemental Pact's "never twice". */
export const DAMAGE_TYPE_KEYS = Object.freeze(["bludgeoning", "piercing", "slashing", "subdual", "acid", "cold", "electricity", "fire", "sonic", "essence", "force", "aligned", "mental", "poison"]);

/**
 * The six birthrights a High Mage or Birthrager may borrow (Q100: not Wild),
 * from the book's KEY ABILITY SCORE, BONUS SKILLS and ADDITIONAL SPELLS
 * (Block 3a's data; the harness checks them against it): the first key
 * ability (min +2), the tradition, the two birthright skills, the specialist
 * spell and the 1st-level PP 0 cantrip (Storm's Shock Bolt is Orb of
 * Lightning, Q15).
 */
export const BORROWABLE_BIRTHRIGHTS = Object.freeze({
  Arcanum: Object.freeze({ ability: "intelligence", tradition: "arcane", skills: ["arcana", "linguistics"], specialist: "Disrupting Magic", cantrip: "Read Aura" }),
  Dragon: Object.freeze({ ability: "intelligence", tradition: "arcane", skills: ["arcana", "intimidate"], specialist: "Draconic Infusion", cantrip: "Light" }),
  Eternity: Object.freeze({ ability: "wisdom", tradition: "divinity", skills: ["diplomacy", "medicine"], specialist: "Touch of Healing", cantrip: "Stabilise" }),
  Rune: Object.freeze({ ability: "wisdom", tradition: "divinity", skills: ["crafting", "linguistics"], specialist: "Storing Rune", cantrip: "Forbidding Ward" }),
  Storm: Object.freeze({ ability: "constitution", tradition: "verdant", skills: ["nature", "survival"], specialist: "Storm Bolt", cantrip: "Orb Of Lightning" }),
  Umbral: Object.freeze({ ability: "charisma", tradition: "ethereal", skills: ["planes", "stealth"], specialist: "Shadow Shift", cantrip: "Ghost Sound" })
});
/** High Mage: "any one of the Sorcerer birthrights that you meet the minimum ability score requirement for". */
export const BIRTHRIGHT_MINIMUM = 2;

/** The flags a borrowed birthright leaves on the High Mage or Birthrager feat (system scope). */
export const BORROWED_BIRTHRIGHT_FLAG = "eaBorrowedBirthright";
export const BORROWED_DRAGON_FLAG = "eaDragonType";
/** The spells a borrowed birthright added (module scope), replaced on a new pick. */
export const BORROWED_SPELL_FLAG = "eaBorrowedSpell";
export const HEX_WEAVER_SPELL_FLAG = "eaHexWeaverPick";

/** High Mage's class skill: one of the birthright's two (the core's class-skill grant, read by "Gained class skill"). */
export const HIGH_MAGE_GRANT = Object.freeze({
  name: "high mage", flag: "highMageClassSkill", label: "High Mage",
  options: Object.freeze([...new Set(Object.values(BORROWABLE_BIRTHRIGHTS).flatMap((b) => b.skills))])
});

/** Blood of the Wyrm's warp (Q106): Elemental, or an element or energy trait. */
export const WYRM_WARP_TRAITS = Object.freeze(["elemental", "air", "earth", "fire", "water", "acid", "cold", "electricity", "sonic", "poison"]);
export const WYRM_WARP_PP = 2;
/** Draconic Claws (Q107): "1d6 secondary". */
export const DRACONIC_CLAWS_DICE = "1d6";
export const DRAGON_CLAWS_NAME = "Dragon Claws";
/**
 * Draconic Infusion (Block 3a's spell; Appendix A note 15): "your Claw
 * attacks" — the Dragon Claws, or a natural Claw or Claws (Q100) — 1d6 of the
 * dragon type, +1d6 a "+2 PP" warp (counted as `bonusValue`, max 5d6), for
 * 1 minute (10 with the warp); Blood of the Wyrm's die after the cap (note 16).
 */
export const INFUSION_CLAW_NAMES = Object.freeze(["dragon claws", "claw", "claws", "claws (tiny)", "claws (small)", "claws (medium)", "claws (large)"]);
export const INFUSION_MAX_EXTRA = 4;
export const INFUSION_SECONDS = Object.freeze({ base: 60, warped: 600 });
/** Elemental Exhalation (Q107): acid and electricity a 60-ft line; the rest a 30-ft cone. */
export const EXHALATION_LINE_TYPES = Object.freeze(["cave", "light"]);
export const EXHALATION_AP = 2;
export const EXHALATION_PP = 2;
/** Wyrm Ascendant: "for 10 minutes"; 1 AP (no action printed). */
export const ASCENDANT_SECONDS = 600;
export const ASCENDANT_AP = 1;
/** Void Pact: "+2-circumstance bonus to your DB"; "increased by 30-ft". */
export const VOID_DB = 2;
export const VOID_DARKVISION_FEET = 30;
/** Crimson Rite: "spending 1 PP"; suppression lowers every Bleed entry to nothing. */
export const CRIMSON_SUPPRESS_PP = 1;
export const CRIMSON_SUPPRESSION = 999;

export const SRC = Object.freeze({
  roar: "draconicRoar", infusion: "draconicInfusion", voidDB: "voidPactDB", crimson: "crimsonRite", crimsonOff: "crimsonRiteSuppressed", wings: "wyrmAscendant"
});

/* ------------------------------------------------------------------ */
/* Pure rules                                                           */
/* ------------------------------------------------------------------ */

const DEGREES_CRITICAL = Object.freeze(["critical", "heroic"]);
const statusList = (e) => { const s = e?.statuses; return (s instanceof Set ? Array.from(s) : Array.isArray(s) ? s : []).map(norm); };
const traitsOf = (text) => String(text ?? "").split(/[,;]/).map((t) => norm(t)).filter(Boolean);

/** Bloodmage: "cannot reduce a spell's cost below 1 PP this way" — all but 1 of what is paid. */
export const bloodmageMax = (payable) => Math.max(0, int(payable) - 1);

/**
 * Bloodmage's Bleed at settle: what the Bleed paid, and Q105's extra on a
 * Fumble (1 per 2 PP of the cast, rounded down) or a Blunder (1 per PP),
 * only on a cast that drew Bleed.
 */
export function bloodmageBleed({ drawn = 0, paid = 0, degree = "", totalPP = 0, refunded = false } = {}) {
  const base = refunded ? 0 : Math.max(0, int(paid));
  if (!(int(drawn) > 0) || refunded) return { paid: base, extra: 0, total: base };
  const d = norm(degree);
  const extra = d === "blunder" ? Math.max(0, int(totalPP)) : d === "fumble" ? Math.floor(Math.max(0, int(totalPP)) / 2) : 0;
  return { paid: base, extra, total: base + extra };
}

/** The Pact or Wyrm resistance change. */
export const resistanceChanges = (type) => [{ key: "system.combat.resistances", type: "add", value: `, ${type}`, priority: 20 }];

/**
 * Elemental Pact's +1 per die (Q102): a pool of the mapped energy type, or any
 * other pool of a spell carrying the element's trait — two rows that never
 * both match one pool.
 */
export function elementalPactRows(element) {
  const energy = ELEMENT_ENERGY[norm(element)];
  if (!energy) return [];
  return [
    { label: "Elemental Pact", perDie: 1, damageTypes: [energy], type: "untyped" },
    { label: "Elemental Pact", perDie: 1, traits: [norm(element)], damageTypes: DAMAGE_TYPE_KEYS.filter((t) => t !== energy), type: "untyped" }
  ];
}

/** Draconic Pact: "a critical result or greater … casting a spell with the attack trait" — a Critical hit of the cast's spell attack. */
export const roarDue = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded && (ctx.spellHits ?? []).some((hit) => hit?.critical);
/** …the roar: advantage on the next Demoralise, applied by itself and spent. */
export const roarConditionals = () => [{ kind: "advantage", label: "Draconic Pact: roar", scope: "your next Demoralise (Intimidate) check, before the end of your next turn", auto: true, oneShot: true, when: { checkTypes: ["skill"], actions: ["demoralise"] } }];

/** Void Pact: "a creature gets a critical or higher result against one of your spells". */
export const voidDBDue = (ctx = {}) => (ctx.saveResults ?? []).some((r) => DEGREES_CRITICAL.includes(norm(r?.degree)));
export const voidDBChanges = () => [{ key: "system.combat.defence.circumstance", type: "custom", value: String(VOID_DB), priority: 20 }];

/** Is this item a Darkvision sense (an item declaring the sense, by its name)? */
export function isDarkvisionSource(item) {
  const sense = item?.flags?.[SYSTEM_ID]?.creatureAbility?.derives?.sense;
  if (!sense || typeof sense !== "object") return false;
  return norm(String(sense.name ?? item.name).replace(/\(.*\)\s*$/, "")) === "darkvision";
}
/** Void Pact: "If you already have Darkvision" — a Darkvision from anything but the Pact's own grant. */
export function voidDarkvisionDue(items = [], pact = null) {
  if (!pact) return false;
  return Array.from(items ?? []).some((i) => isDarkvisionSource(i) && i.flags?.[SYSTEM_ID]?.grantedBy?.sourceId !== pact.id);
}
export const voidSenseBonus = () => ({ sense: "Darkvision", feet: VOID_DARKVISION_FEET });

/** Crimson Rite: the critical spell-attack hits' creatures. */
export const crimsonCriticals = (ctx = {}) => (Boolean(ctx.cast) && !ctx.refunded ? (ctx.spellHits ?? []).filter((hit) => hit?.critical && hit.target).map((hit) => hit.target) : []);
/** Crimson Rite's per-die row (C6). */
export const crimsonRow = () => ({ label: "Crimson Rite", perDie: 1, type: "circumstance" });
/** "While suffering from Bleed … if you [suppress it], you lose the above damage bonus." */
export const crimsonActive = ({ owns = false, bleeding = false, suppressed = false } = {}) => owns && bleeding && !suppressed;

/** Hex Weaver's spell (Q103): Ethereal or Verdant, base PP ≤ level + 1, not a specialist spell or a hex. */
export function hexWeaverMayTake(entry, level) {
  const sys = entry?.system ?? {};
  if (sys.specialist || entry?.flags?.[SYSTEM_ID]?.eaHex) return false;
  const trads = traitsOf(sys.tradition);
  if (!trads.some((t) => t === "ethereal" || t === "verdant")) return false;
  return int(sys.ppCost) <= int(level) + 1;
}
/** Add the Highmagic trait (High Magic, high-magic.mjs `spellIsHighmagic`). */
export function withHighmagic(traits) {
  const list = String(traits ?? "").split(",").map((t) => t.trim()).filter(Boolean);
  if (list.some((t) => ["highmagic", "high magic"].includes(norm(t)))) return list.join(", ");
  return [...list, "Highmagic"].join(", ");
}

/** The birthrights a High Mage may borrow: the first key ability at +2 or more. */
export function highMageChoices(attributes = {}) {
  return Object.entries(BORROWABLE_BIRTHRIGHTS).filter(([, b]) => int(attributes?.[b.ability]?.total) >= BIRTHRIGHT_MINIMUM).map(([name]) => name);
}

/** Specialist access: Hex Weaver's "Witch Specialist Spells (hexes)" (Q103) and the Bloodmage hexes (Q21). */
export const hexWeaverAllows = (owns, spell) => Boolean(owns) && Boolean(spell?.flags?.[SYSTEM_ID]?.eaHex);
export const bloodmageAllows = (owns, spell) => Boolean(owns) && traitsOf(spell?.system?.specialistClass).includes("bloodmage");

/** Blood of the Wyrm's six warps (G15): one per dragon type, offered only to that type's owner. */
export function wyrmWarpEntries(typeOf = () => "") {
  return Object.entries(DRAGON_TYPES).map(([type, energy]) => ({
    match: { anyTraits: [...WYRM_WARP_TRAITS], damaging: true },
    when: (actor) => typeOf(actor) === type,
    warp: { ppCost: WYRM_WARP_PP, text: `the spell's damage type changes to that of your dragon type (${energy}; Blood of the Wyrm).`, mods: { damageType: energy } }
  }));
}

/** Draconic Claws' rider (Q107): the Dragon Claws only, secondary, never spent. */
export function draconicClawsRider(energy) {
  return { label: "Draconic Claws", dice: DRACONIC_CLAWS_DICE, damageType: energy, scope: "melee", weaponNames: [DRAGON_CLAWS_NAME.toLowerCase()], once: false };
}

/** Draconic Infusion's rider on this cast: its dice, and how long. */
export function infusionRider({ energy = "", warpMods = {}, wyrm = false } = {}) {
  if (!energy) return null;
  const extra = Math.min(INFUSION_MAX_EXTRA, Math.max(0, int(warpMods?.bonusValue)));
  const dice = 1 + extra + (wyrm ? 1 : 0);
  const seconds = /10\s*minutes?/i.test(String(warpMods?.durationText ?? "")) ? INFUSION_SECONDS.warped : INFUSION_SECONDS.base;
  return { seconds, rider: { label: "Draconic Infusion", dice: `${dice}d6`, damageType: energy, scope: "melee", weaponNames: [...INFUSION_CLAW_NAMES], once: false } };
}
export const infusionDue = (ctx = {}) => norm(ctx.spell?.name) === "draconic infusion" && Boolean(ctx.cast) && !ctx.refunded && !ctx.itemCast;

/** Elemental Exhalation: "1d6 damage per two levels" (rounded down), or "" below 2nd. */
export const exhalationDice = (level) => { const n = Math.floor(Math.max(0, int(level)) / 2); return n > 0 ? `${n}d6` : ""; };
export const exhalationShape = (dragonType) => (EXHALATION_LINE_TYPES.includes(norm(dragonType)) ? "a 60-foot line" : "a 30-foot cone");

/** Sanguine Channel's offer: only when Bloodmage's Bleed was drawn on this cast (the cast-option ctx's `ppSources`). */
export const sanguineDrawn = (ctx = {}) => (ctx.ppSources ?? []).some((s) => norm(s?.key) === "bloodmage" && int(s?.drawn) > 0);
/** Sanguine Channel's +1 Bleed: only when Bloodmage's Bleed paid some of this cast. */
export const sanguineEarned = (ctx = {}) => (ctx.ppSources ?? []).some((s) => norm(s?.key) === "bloodmage" && int(s?.paid) > 0);
/** Is a spell one with an attack, a save, or both (Sanguine Channel's choice)? */
export function sanguineModes(system = {}) {
  const cat = norm(system.category);
  const def = norm(system.defence);
  const attack = cat === "attack" || /\bdb\b|defence/.test(def);
  const save = cat === "save" || /fortitude|reflex|will/.test(def);
  return { attack, save };
}

/** The fly speed Wyrm Ascendant's feat declares while its wings are out. */
export const wingsDerives = (on) => (on ? { movement: { key: "fly", orLand: true } } : null);

/* ------------------------------------------------------------------ */
/* Foundry side: small helpers                                          */
/* ------------------------------------------------------------------ */

const items = (actor) => Array.from(actor?.items ?? []);
const featOf = (actor, name) => owned(actor, name, ["feat"]);
const className = (actor) => norm(items(actor).find((i) => i.type === "class")?.name);
const isBleeding = (actor) => Array.from(actor?.effects ?? []).some((e) => !e.disabled && statusList(e).includes("bleeding"));
const effectActor = (effect) => (effect?.parent?.documentName === "Actor" ? effect.parent : null);

function usesLeft(item) {
  const max = h().itemUsesMax(item);
  if (max === null || max === undefined || max === Infinity) return Infinity;
  return h().itemUsesRemaining(item);
}
async function spendUse(item) {
  const left = usesLeft(item);
  if (left === Infinity) return true;
  if (left <= 0) return false;
  await item.update({ "system.usesValue": left - 1 });
  return true;
}
async function confirm(title, content) {
  const D = globalThis.foundry?.applications?.api?.DialogV2;
  if (!D?.confirm) return false;
  return Boolean(await D.confirm({ window: { title }, content: `<p>${content}</p>`, rejectClose: false }));
}
async function traitsAllow(actor, item, key, label) {
  const ok = await h().traitGate?.(actor, { key, traits: String(item?.system?.traits ?? "") }, label);
  return ok !== false;
}
async function spendPP(actor, pp, label) {
  const have = int(actor.system?.resources?.pp?.value);
  if (have < pp) return warn(`${label}: ${pp} PP required (you have ${have}).`);
  await actor.update({ "system.resources.pp.value": have - pp });
  return true;
}
const featEffect = (actor, item) => Array.from(actor?.effects ?? []).find((e) => e.getFlag?.(SYSTEM_ID, "featSource") === item?.id) ?? null;

/** The High Mage or Birthrager feat carrying a borrowed birthright, or null. */
export const borrowedBirthrightFeat = (actor) => items(actor).find((i) => i.type === "feat" && i.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG]) ?? null;
/**
 * The character's birthright by name: its own Sorcerer birthright, or the one
 * a High Mage or Birthrager borrowed (Q100: "the pick counts"). "" for none.
 * Exported for the other groups' "<Name> Birthright" eligibility (Arcane
 * Study, Resonance Surge, High Magic Resonance).
 */
export function birthrightNameOf(actor) {
  const own = birthrightOf(actor);
  if (own) return String(own.name);
  return String(borrowedBirthrightFeat(actor)?.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG] ?? "");
}
/** The dragon type: the Dragon birthright's own (Block 3a), else a borrowed Dragon's. */
export function wyrmTypeOf(actor) {
  const own = birthrightOf(actor);
  if (own && norm(own.name) === "dragon") return dragonTypeOf(actor);
  const feat = borrowedBirthrightFeat(actor);
  if (norm(feat?.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG]) !== "dragon") return "";
  const t = norm(feat?.flags?.[SYSTEM_ID]?.[BORROWED_DRAGON_FLAG]);
  return DRAGON_TYPES[t] ? t : "";
}
/** Blood of the Wyrm's "Dragon Birthright" (G9 eligibility; Q100). */
export const wyrmEligibility = (actor) => (norm(birthrightNameOf(actor)) === "dragon" ? null : "it needs the Dragon Birthright (a Sorcerer's, or a High Mage's or Birthrager's Dragon pick).");

/** High Mage's "Non-Sorcerer" (G9: the prerequisite parser does not read it). */
export const highMageEligibility = (actor) => (className(actor) === "sorcerer" ? "a Sorcerer may not take it (Non-Sorcerer)." : null);

const dragonChoices = () => Object.entries(DRAGON_TYPES).map(([k, v]) => [k, `${k[0].toUpperCase()}${k.slice(1)} (${v})`]);

/** The dragon type, asked and stored where it belongs when it is not set yet. */
async function askWyrmType(actor) {
  const have = wyrmTypeOf(actor);
  if (have) return have;
  const own = birthrightOf(actor);
  const borrowed = borrowedBirthrightFeat(actor);
  if (!(own && norm(own.name) === "dragon") && norm(borrowed?.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG]) !== "dragon") {
    warn("You have no Dragon Birthright, so no dragon type.");
    return "";
  }
  const choice = await h().chooseFromList("Dragon type", "Choose your draconic type:", dragonChoices());
  if (!DRAGON_TYPES[choice]) return "";
  if (own && norm(own.name) === "dragon") await own.setFlag(MODULE_ID, "dragonType", choice);
  else await borrowed.setFlag(SYSTEM_ID, BORROWED_DRAGON_FLAG, choice);
  return choice;
}

/** A pack spell's data by name, or by index entry. */
async function spellDataFor(nameOrEntry) {
  const entry = typeof nameOrEntry === "string" ? (await spellIndex()).find((e) => norm(e.name) === norm(nameOrEntry)) : nameOrEntry;
  if (!entry) return null;
  const doc = await entry.pack.getDocument(entry._id);
  return doc ? doc.toObject() : null;
}

/** Add a spell to the sheet, granted by `source` (castable by its stamp), flagged as the module's. */
async function addGrantedSpell(actor, data, source, moduleFlags = {}, { highMagic = false } = {}) {
  const out = JSON.parse(JSON.stringify(data));
  delete out._id;
  out.type = "spell";
  out.system = { ...(out.system ?? {}), prepared: true, ...(highMagic ? { traits: withHighmagic(out.system?.traits) } : {}) };
  out.flags = {
    ...(out.flags ?? {}),
    [SYSTEM_ID]: { ...(out.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: source.id, sourceName: source.name, requested: data.name } },
    [MODULE_ID]: { ...(out.flags?.[MODULE_ID] ?? {}), ...moduleFlags }
  };
  const [created] = await actor.createEmbeddedDocuments("Item", [out]);
  return created ?? null;
}
async function removeFlaggedSpells(actor, flag, sourceId) {
  const ids = items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.[flag] === sourceId).map((i) => i.id);
  if (ids.length) await actor.deleteEmbeddedDocuments("Item", ids);
}

/* ------------------------------------------------------------------ */
/* Syncs                                                                */
/* ------------------------------------------------------------------ */

/** Blood of the Wyrm's resistance and Draconic Claws' rider follow the dragon type. */
export async function syncWyrm(actor) {
  const type = wyrmTypeOf(actor);
  const energy = DRAGON_TYPES[type] ?? "";
  const wyrm = featOf(actor, "Blood of the Wyrm");
  const claws = featOf(actor, "Draconic Claws");
  const lines = [];
  if (wyrm && energy && featEffect(actor, wyrm)?.getFlag?.(MODULE_ID, "wyrmType") !== type) {
    await h().replaceFeatEffect(actor, wyrm, {
      name: `Blood of the Wyrm: resistance to ${energy}`, img: wyrm.img,
      description: `Blood of the Wyrm: resistance to ${energy}, your dragon type's energy.`,
      changes: resistanceChanges(energy), flags: { [MODULE_ID]: { wyrmType: type } }
    });
    lines.push(line(`<strong>Blood of the Wyrm</strong>: resistance to <strong>${esc(energy)}</strong>.`));
  }
  if (claws && energy && featEffect(actor, claws)?.getFlag?.(MODULE_ID, "wyrmType") !== type) {
    await h().replaceFeatEffect(actor, claws, {
      name: `Draconic Claws: +1d6 ${energy}`, img: claws.img,
      description: `Draconic Claws: your Dragon Claws deal 1d6 secondary ${energy} damage.`,
      changes: [], flags: { [SYSTEM_ID]: { strikeRider: draconicClawsRider(energy) }, [MODULE_ID]: { wyrmType: type } }
    });
    lines.push(line(`<strong>Draconic Claws</strong>: your Dragon Claws deal <strong>1d6 secondary ${esc(energy)}</strong>.`));
  }
  if (lines.length) await card(actor, "Blood of the Wyrm", lines);
  return lines.length;
}

/** Void Pact's +30 ft, declared on the feat only while Darkvision comes from elsewhere. */
export async function syncVoidDarkvision(actor) {
  const pact = featOf(actor, "Void Pact");
  if (!pact) return;
  const due = voidDarkvisionDue(items(actor), pact);
  const has = Boolean(pact.flags?.[SYSTEM_ID]?.senseRangeBonus);
  if (due && !has) await pact.setFlag(SYSTEM_ID, "senseRangeBonus", voidSenseBonus());
  else if (!due && has) await pact.unsetFlag(SYSTEM_ID, "senseRangeBonus");
}

/** Crimson Rite's per-die bonus, laid while Bleeding and not suppressed. */
export async function syncCrimson(actor) {
  if (!actor) return;
  const want = crimsonActive({ owns: Boolean(featOf(actor, "Crimson Rite")), bleeding: isBleeding(actor), suppressed: ownEffects(actor, SRC.crimsonOff).length > 0 });
  const have = ownEffects(actor, SRC.crimson);
  if (want && !have.length) {
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(SRC.crimson, {
      name: "Crimson Rite: +1 per die", img: "icons/svg/blood.svg",
      description: "Crimson Rite: while Bleeding, +1 circumstance per die to your spell damage rolls.",
      system: { spellDamageBonus: crimsonRow() }
    })]);
  } else if (!want && have.length) await actor.deleteEmbeddedDocuments("ActiveEffect", have.map((e) => e.id));
}

/** Wyrm Ascendant's fly speed follows its effect. */
async function syncWings(actor) {
  const item = featOf(actor, "Wyrm Ascendant");
  if (!item) return;
  const want = wingsDerives(ownEffects(actor, SRC.wings).length > 0);
  const have = item.flags?.[SYSTEM_ID]?.creatureAbility?.derives ?? null;
  if (JSON.stringify(want) === JSON.stringify(have)) return;
  if (want) await item.setFlag(SYSTEM_ID, "creatureAbility", { derives: want });
  else await item.unsetFlag(SYSTEM_ID, "creatureAbility");
}
async function landIfAloft(actor) {
  const token = tokenOf(actor);
  const height = Number(token?.document?.elevation ?? 0) || 0;
  if (!token || height <= 0) return;
  if (Number(actor.system?.combat?.movement?.fly?.total ?? 0) > 0) return;
  await card(actor, "Wyrm Ascendant", [line(`Your wings fold with you ${height} ft in the air: you fall.`)]);
  await token.document.update({ elevation: 0 });
  await h().rollFalling(actor, { distance: height, note: "Wyrm Ascendant: the wings ended in the air." });
}

/** A Warlock's Pact spell becomes an innate Focus copy, cast with Charisma (note 1; Q37). */
async function warlockPactSpell(item) {
  const actor = item?.parent;
  if (item?.type !== "spell" || className(actor) !== "warlock" || item.system?.innate) return false;
  if (!PACT_NAMES.map(norm).includes(norm(item.flags?.[SYSTEM_ID]?.grantedBy?.sourceName))) return false;
  const copy = warlockCopy(item.toObject?.() ?? item, { source: { id: item.flags[SYSTEM_ID].grantedBy.sourceId, name: item.flags[SYSTEM_ID].grantedBy.sourceName }, slot: "pact" });
  await item.update({
    "system.innate": true, "system.traits": copy.system.traits, "system.usesValue": 1,
    [`flags.${SYSTEM_ID}.castingAbilityOverride`]: "charisma", [`flags.${SYSTEM_ID}.innatePPAllowance`]: 1, [`flags.${MODULE_ID}.warlockPick`]: "pact"
  });
  return true;
}

/* ------------------------------------------------------------------ */
/* The Uses                                                             */
/* ------------------------------------------------------------------ */

const draconicPact = {
  hint: "Choose your patron's energy (acid, cold, electricity, fire or poison): resistance to it.",
  async use(actor, item) {
    const pick = await h().chooseFromList("Draconic Pact", "Your patron's energy type:", DRACONIC_ENERGIES.map((e) => [e, e]));
    if (!DRACONIC_ENERGIES.includes(pick)) return false;
    await item.setFlag(SYSTEM_ID, "eaEnergy", pick);
    await h().replaceFeatEffect(actor, item, { name: `Draconic Pact: resistance to ${pick}`, img: item.img, description: `Draconic Pact: resistance to ${pick}.`, changes: resistanceChanges(pick) });
    // FROM 0.10.0 (Block 7): Dragon's Breath of this energy joins the sheet, granted by the feat.
    const breath = await grantPactSpellB7(actor, item, "dragonsBreath", await spellDataFor("Dragon’s Breath"));
    await card(actor, "Draconic Pact", [line(`Your patron's energy is <strong>${esc(pick)}</strong>: you gain resistance to it.`), line(breath ? `<strong>Dragon’s Breath</strong> (${esc(pick)}) is in your repertoire.` : "<em>You already know Dragon’s Breath from another source; its type is your own choice.</em>")]);
    return true;
  }
};

const elementalPact = {
  hint: "Choose your element (air, earth, fire or water): resistance, and +1 per die on its spells.",
  async use(actor, item) {
    const pick = await h().chooseFromList("Elemental Pact", "Your elemental type:", Object.entries(ELEMENT_ENERGY).map(([k, v]) => [k, `${k} (${v})`]));
    const energy = ELEMENT_ENERGY[pick];
    if (!energy) return false;
    await item.setFlag(SYSTEM_ID, "eaElement", pick);
    await h().replaceFeatEffect(actor, item, {
      name: `Elemental Pact: ${pick}`, img: item.img,
      description: `Elemental Pact (${pick}): resistance to ${energy}; +1 damage per die on spells of your element.`,
      changes: resistanceChanges(energy), flags: { [SYSTEM_ID]: { spellDamageBonus: elementalPactRows(pick) } }
    });
    // FROM 0.10.0 (Block 7): Elemental Strike of this element joins the sheet, granted by the feat.
    const strike = await grantPactSpellB7(actor, item, "elementalStrike", await spellDataFor("Elemental Strike"));
    await card(actor, "Elemental Pact", [
      line(`Your element is <strong>${esc(pick)}</strong>: resistance to <strong>${esc(energy)}</strong>, and +1 damage per die on a spell with the ${esc(pick)} trait or on its ${esc(energy)} damage.`),
      line(strike ? `<strong>Elemental Strike</strong> (${esc(energy)}) is in your repertoire.` : "<em>You already know Elemental Strike from another source; its type is your own choice.</em>")
    ]);
    return true;
  }
};

const hexWeaver = {
  hint: "Choose your one Ethereal or Verdant spell, cast as High Magic.",
  async use(actor, item) {
    const level = levelOf(actor);
    const known = new Set(items(actor).filter((i) => i.type === "spell" && i.flags?.[MODULE_ID]?.[HEX_WEAVER_SPELL_FLAG] !== item.id).map((i) => norm(i.name)));
    const pool = (await spellIndex()).filter((e) => hexWeaverMayTake(e, level) && !known.has(norm(e.name))).sort((a, b) => a.name.localeCompare(b.name));
    if (!pool.length) return warn("Hex Weaver: no Ethereal or Verdant spell is open to you.");
    const id = await h().chooseFromList("Hex Weaver", `One spell of the Ethereal or Verdant tradition, base PP up to ${level + 1}, cast as High Magic:`, pool.map((e) => [`${e._id}|${e.pack.collection}`, `${e.name} (PP ${int(e.system?.ppCost)})`]));
    const entry = pool.find((e) => `${e._id}|${e.pack.collection}` === id);
    if (!entry) return false;
    const data = await spellDataFor(entry);
    if (!data) return false;
    await removeFlaggedSpells(actor, HEX_WEAVER_SPELL_FLAG, item.id);
    const made = await addGrantedSpell(actor, data, item, { [HEX_WEAVER_SPELL_FLAG]: item.id }, { highMagic: true });
    if (made) await card(actor, "Hex Weaver", [line(`<strong>${esc(made.name)}</strong> is yours permanently, outside your picks: cast with Spellcraft as <strong>High Magic</strong> (the Highmagic trait).`)]);
    return Boolean(made);
  }
};

/** The borrowed birthright, for High Mage and Birthrager: the pick, its dragon type, its spells. */
async function borrowBirthright(actor, item, { label, choices, highMagic, cantrip }) {
  if (!choices.length) return warn(`${label}: no birthright is open to you${highMagic ? " (each needs its first key ability at +2)" : ""}.`);
  const pick = await h().chooseFromList(label, "Choose a Sorcerer birthright (Wild is not offered):", choices.map((n) => [n, `${n} (${BORROWABLE_BIRTHRIGHTS[n].ability}, ${BORROWABLE_BIRTHRIGHTS[n].tradition})`]));
  const br = BORROWABLE_BIRTHRIGHTS[pick];
  if (!br) return null;
  let dragon = "";
  if (pick === "Dragon") {
    dragon = await h().chooseFromList(label, "Your draconic type:", dragonChoices());
    if (!DRAGON_TYPES[dragon]) return null;
  }
  await item.setFlag(SYSTEM_ID, BORROWED_BIRTHRIGHT_FLAG, pick);
  if (dragon) await item.setFlag(SYSTEM_ID, BORROWED_DRAGON_FLAG, dragon);
  else if (item.flags?.[SYSTEM_ID]?.[BORROWED_DRAGON_FLAG]) await item.unsetFlag(SYSTEM_ID, BORROWED_DRAGON_FLAG);
  await removeFlaggedSpells(actor, BORROWED_SPELL_FLAG, item.id);
  const added = [];
  for (const name of [br.specialist, ...(cantrip ? [br.cantrip] : [])]) {
    const data = await spellDataFor(name);
    if (!data) { added.push(`<em>${esc(name)} is not in the spells compendium: add it by hand.</em>`); continue; }
    const made = await addGrantedSpell(actor, data, item, { [BORROWED_SPELL_FLAG]: item.id }, { highMagic });
    if (made) added.push(`<strong>${esc(made.name)}</strong>${highMagic ? " (High Magic)" : ""}`);
  }
  return { pick, br, dragon, added };
}

const highMage = {
  hint: "Choose your borrowed birthright and one of its skills.",
  async use(actor, item) {
    const got = await borrowBirthright(actor, item, { label: "High Mage", choices: highMageChoices(actor.system?.attributes), highMagic: true, cantrip: false });
    if (!got) return false;
    const skill = await h().chooseFromList("High Mage", `One of the ${got.pick} birthright's skills becomes a class skill:`, got.br.skills.map((s) => [s, s]));
    const lines = [line(`Birthright: <strong>${esc(got.pick)}</strong>${got.dragon ? ` (${esc(got.dragon)}, ${esc(DRAGON_TYPES[got.dragon])})` : ""}. Added: ${got.added.join(", ") || "nothing"}.`)];
    if (got.br.skills.includes(skill)) {
      // The core's class-skill grant record (class-skills.mjs reads it; "Gained class skill" progression too).
      await actor.setFlag(SYSTEM_ID, HIGH_MAGE_GRANT.flag, { skill, written: 0 });
      lines.push(line(`<strong>${esc(skill)}</strong> is now a class skill (High Mage); your progression reads it at 10 ranks.`));
    } else lines.push(line("<em>No class skill chosen yet: use High Mage again to choose it (until then no other archetype is offered).</em>"));
    await card(actor, "High Mage", lines);
    await syncWyrm(actor);
    return true;
  }
};

const birthrager = {
  hint: "Choose your borrowed birthright: its specialist spell and cantrip.",
  async use(actor, item) {
    const got = await borrowBirthright(actor, item, { label: "Birthrager", choices: Object.keys(BORROWABLE_BIRTHRIGHTS), highMagic: false, cantrip: true });
    if (!got) return false;
    const lines = [line(`Birthright: <strong>${esc(got.pick)}</strong>${got.dragon ? ` (${esc(got.dragon)}, ${esc(DRAGON_TYPES[got.dragon])})` : ""}. Added: ${got.added.join(", ") || "nothing"}.`)];
    const stored = norm(actor._source?.system?.magic?.tradition ?? actor.system?.magic?.tradition);
    if (!stored) {
      await actor.update({ "system.magic.tradition": got.br.tradition });
      lines.push(line(`Your magical tradition is now <strong>${esc(got.br.tradition)}</strong>: ${esc(got.br.ability)} is your magical ability, and your PP pool is that tradition's (Q100).`));
    } else if (stored !== got.br.tradition) {
      lines.push(line(`<em>Your sheet already names the ${esc(stored)} tradition, so it is kept; the birthright's is ${esc(got.br.tradition)}.</em>`));
    }
    await card(actor, "Birthrager", lines);
    await syncWyrm(actor);
    return true;
  }
};

const wyrmUse = (label) => ({
  hint: "Choose your dragon type if you have not, and lay its effect.",
  async use(actor) {
    const type = await askWyrmType(actor);
    if (!type) return false;
    if (!(await syncWyrm(actor))) await card(actor, label, [line(`Your dragon type is <strong>${esc(type)}</strong> (${esc(DRAGON_TYPES[type])}); its effect is already in place.`)]);
    return true;
  }
});

const crimsonRite = {
  hint: "1 PP: suppress your Bleed until the start of your next turn (the damage bonus is lost meanwhile).",
  async use(actor) {
    if (!isBleeding(actor)) return warn("Crimson Rite: you are not Bleeding.");
    if (ownEffects(actor, SRC.crimsonOff).length) return warn("Crimson Rite: your Bleed is already suppressed.");
    if (!(await spendPP(actor, CRIMSON_SUPPRESS_PP, "Crimson Rite"))) return false;
    await h().createEffectsOn(actor, [effectData(SRC.crimsonOff, {
      name: "Crimson Rite: Bleed suppressed", img: "icons/svg/blood.svg",
      description: "Crimson Rite: your Bleeding deals no damage until the start of your next turn, and Crimson Rite's damage bonus is lost meanwhile.",
      system: { bleedReduction: CRIMSON_SUPPRESSION },
      expiry: expiryFor("startOfNextTurn", actor)
    })]);
    await syncCrimson(actor);
    await card(actor, "Crimson Rite", [line(`You spend ${CRIMSON_SUPPRESS_PP} PP: your Bleed is <strong>suppressed</strong> until the start of your next turn, and your +1 per die is lost meanwhile.`)]);
    return true;
  }
};

const elementalExhalation = {
  hint: "2 AP, 2 PP (Focus): target the creatures in your breath — 1d6 per two levels, basic Reflex against your Level DC.",
  ownsFocusUse: true,
  async use(actor, item) {
    const type = await askWyrmType(actor);
    if (!type) return false;
    const energy = DRAGON_TYPES[type];
    if (usesLeft(item) <= 0) return warn("Elemental Exhalation: its Focus use is spent — Refocus or daily preparation restores it.");
    const dice = exhalationDice(levelOf(actor));
    if (!dice) return warn("Elemental Exhalation: 1d6 per two levels is nothing below 2nd level.");
    const targets = Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor).filter((a) => a && a !== actor);
    if (!targets.length) return warn(`Elemental Exhalation: target the creatures in your breath (${exhalationShape(type)}) first.`);
    if (int(actor.system?.resources?.pp?.value) < EXHALATION_PP) return warn(`Elemental Exhalation: ${EXHALATION_PP} PP required.`);
    if (!(await traitsAllow(actor, item, "elementalExhalation", "Elemental Exhalation"))) return false;
    if (!(await spendAP(actor, "Elemental Exhalation", EXHALATION_AP))) return false;
    if (!(await spendPP(actor, EXHALATION_PP, "Elemental Exhalation"))) return false;
    if (!(await spendUse(item))) return false;
    const bonus = await h().spellDamagePerDieBonus?.(actor, { type: energy, dice, traits: traitsOf(item.system?.traits) });
    const formula = bonus?.total ? `${dice} + ${bonus.total}` : dice;
    const lines = await h().runAreaEffect(actor, {
      save: "reflex", basic: true, scope: "targets", damage: { formula, type: energy },
      intro: `${exhalationShape(type)} of ${energy}: ${formula}, basic Reflex against your Level DC.${bonus?.text ? ` (${bonus.text})` : ""}`
    }, { title: "Elemental Exhalation", targets });
    await h().recordTraitUsage?.(actor, { key: "elementalExhalation", traits: String(item.system?.traits ?? "") });
    await card(actor, "Elemental Exhalation", [...(lines ?? []), line(`${EXHALATION_PP} PP spent. <em>Focus use spent — Refocus or daily preparation restores it.</em>`)]);
    return true;
  }
};

const wyrmAscendant = {
  hint: "1 AP (Focus): fly at your land speed for 10 minutes; Use again to fold your wings.",
  ownsFocusUse: true,
  async use(actor, item) {
    const up = ownEffects(actor, SRC.wings);
    if (up.length) {
      if (!(await confirm("Wyrm Ascendant", "Fold your wings now?"))) return false;
      await actor.deleteEmbeddedDocuments("ActiveEffect", up.map((e) => e.id));
      return true;
    }
    if (usesLeft(item) <= 0) return warn("Wyrm Ascendant: its Focus use is spent — Refocus or daily preparation restores it.");
    if (!(await spendAP(actor, "Wyrm Ascendant", ASCENDANT_AP))) return false;
    if (!(await spendUse(item))) return false;
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(SRC.wings, {
      name: "Wyrm Ascendant: wings (10 minutes)", img: "icons/svg/wing.svg",
      description: "Wyrm Ascendant: a fly speed equal to your land speed for 10 minutes.",
      expiry: forSeconds(ASCENDANT_SECONDS)
    })]);
    await syncWings(actor);
    await card(actor, "Wyrm Ascendant", [line("Scaled wings of your dragon's type: a <strong>fly speed equal to your land speed</strong> for 10 minutes."), line(`${combatFor(actor) ? `${ASCENDANT_AP} AP spent. ` : ""}<em>Focus use spent — Refocus or daily preparation restores it.</em>`)]);
    return true;
  }
};

export const AUTOMATIONS_B6_A = Object.freeze({
  "Draconic Pact": draconicPact,
  "Elemental Pact": elementalPact,
  "Hex Weaver": hexWeaver,
  "High Mage": highMage,
  Birthrager: birthrager,
  "Blood of the Wyrm": wyrmUse("Blood of the Wyrm"),
  "Draconic Claws": wyrmUse("Draconic Claws"),
  "Crimson Rite": crimsonRite,
  "Elemental Exhalation": elementalExhalation,
  "Wyrm Ascendant": wyrmAscendant
});

/* ------------------------------------------------------------------ */
/* Seams                                                                */
/* ------------------------------------------------------------------ */

/** G2: Bloodmage's Bleed for PP. */
export const bloodmageSource = {
  offer(ctx = {}) {
    if (!featOf(ctx.actor, "Bloodmage")) return null;
    const max = bloodmageMax(ctx.payable);
    if (!max) return null;
    return { label: "Bleed (Bloodmage)", hint: `Each PP paid this way is 1 Bleed; at least 1 PP stays yours (up to ${max} here). The cap and the Casting DC read the spell's full PP.`, max };
  },
  async settle(ctx = {}, { drawn = 0, paid = 0 } = {}) {
    const actor = ctx.actor;
    const got = bloodmageBleed({ drawn, paid, degree: ctx.degree, totalPP: ctx.totalPP, refunded: ctx.refunded });
    if (!got.total || !actor) return { lines: [] };
    await h().applyConditionTags(actor, [{ key: "bleeding", value: got.total, label: "Bleeding" }]);
    const lines = [];
    if (got.paid) lines.push(`Bloodmage: ${got.paid} PP paid in blood — Bleeding +${got.paid}.`);
    if (got.extra) lines.push(`Bloodmage: the ${norm(ctx.degree)} tears the wound wider — Bleeding +${got.extra} more.`);
    return { lines };
  }
};

/** G14: Sanguine Channel's +1, attack or one target's Save DC. */
export const sanguineOption = {
  offer(ctx = {}) {
    const actor = ctx.actor;
    if (!featOf(actor, "Sanguine Channel") || !featOf(actor, "Bloodmage")) return null;
    if (ctx.innate || ctx.itemCast || ctx.stored || ctx.ritual) return null;
    if (int(ctx.spell?.system?.ppCost) < 1 || !sanguineDrawn(ctx)) return null;
    const modes = sanguineModes(ctx.spell?.system);
    if (!modes.attack && !modes.save) return null;
    return { label: "Sanguine Channel (+1 Bleed)", hint: "You are paying PP by Bleed (Bloodmage): +1 to the spell's attack, or to one target's Save DC, for 1 more Bleed." };
  },
  async apply(ctx = {}) {
    const modes = sanguineModes(ctx.spell?.system);
    let mode = modes.attack && !modes.save ? "attack" : !modes.attack && modes.save ? "save" : "";
    if (!mode) mode = await h().chooseFromList("Sanguine Channel", "+1 to which?", [["attack", "The spell's attack"], ["save", "One target's Save DC"]]);
    if (mode === "attack") return { attack: 1, label: "Sanguine Channel", lines: ["Sanguine Channel: +1 to the spell's attack (1 more Bleed at the end of the cast)."] };
    if (mode !== "save") return { label: "Sanguine Channel", lines: [] };
    const targets = Array.from(globalThis.game?.user?.targets ?? []).filter((t) => t?.actor);
    if (!targets.length) return { label: "Sanguine Channel", lines: ["Sanguine Channel: no target is selected, so no Save DC is raised."] };
    let token = targets[0];
    if (targets.length > 1) {
      const id = await h().chooseFromList("Sanguine Channel", "Only one target benefits — whose Save DC is +1?", targets.map((t) => [t.id, esc(t.name)]));
      token = targets.find((t) => t.id === id) ?? null;
    }
    if (!token) return { label: "Sanguine Channel", lines: [] };
    return { saveDCTarget: { uuid: token.actor.uuid, value: 1 }, label: "Sanguine Channel", lines: [`Sanguine Channel: ${esc(token.name)}'s Save DC +1 (1 more Bleed at the end of the cast).`] };
  }
};

export function hexWeaverAccess(actor, spell) { return hexWeaverAllows(featOf(actor, "Hex Weaver"), spell); }
export function bloodmageAccess(actor, spell) { return bloodmageAllows(featOf(actor, "Bloodmage"), spell); }

/** Every registration group A makes; called once from registerContent (trgPrime.registerContent). */
export function registerBlock6A(api, moduleId) {
  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_A)) api.registerFeatAutomation(name, entry, moduleId);
  // Q92: one Pact ever.
  api.registerExclusiveFeats?.("Pact", [...PACT_NAMES], moduleId);
  // Q103 (Hex Weaver's hexes, opened) and Q21 (the Bloodmage hexes).
  api.registerSpecialistAccess?.("hexWeaver", hexWeaverAccess, moduleId);
  api.registerSpecialistAccess?.("bloodmageHexes", bloodmageAccess, moduleId);
  // G2 and G14: Bloodmage's Bleed, Sanguine Channel's +1.
  api.registerCastPPSource?.("bloodmage", bloodmageSource, moduleId);
  api.registerCastOption?.("sanguineChannel", sanguineOption, moduleId);
  // Birthrager: BERSERKER means "you must have the Frenzy feat"; the BSB floor (G11).
  api.registerFeatGate?.("Berserker", ["Frenzy"], moduleId);
  api.registerPPGrant?.("Birthrager", { stat: "bsb", halfLevel: "up", types: ["feat"], label: "Birthrager (BSB half your level, rounded up)" }, moduleId);
  // Blood of the Wyrm: the warp (G15, Q106) and the Dragon Birthright (G9, Q100).
  api.registerSpellWarps?.("Blood of the Wyrm", wyrmWarpEntries(wyrmTypeOf), moduleId);
  api.registerFeatEligibility?.("Blood of the Wyrm", wyrmEligibility, moduleId);
  // High Mage's "Non-Sorcerer" (the parser reads no "Non-X" in a prerequisite).
  api.registerFeatEligibility?.("High Mage", highMageEligibility, moduleId);
  // High Mage's class skill, one of the borrowed birthright's two.
  api.registerClassSkillGrant?.({ ...HIGH_MAGE_GRANT, options: [...HIGH_MAGE_GRANT.options] }, moduleId);
}

/* ------------------------------------------------------------------ */
/* Hook handlers                                                        */
/* ------------------------------------------------------------------ */

/** Hooks.on("trgPrimeSpellSettled"): Draconic Pact's roar, Void Pact's DB, Crimson Rite's critical, Sanguine Channel's Bleed. */
export async function onSpellSettledB6A(ctx = {}) {
  const actor = ctx.actor;
  if (!actor?.isOwner) return;
  if (featOf(actor, "Draconic Pact") && roarDue(ctx) && (await confirm("Draconic Pact", "A critical hit with your spell: let out a roar (advantage on your next Demoralise before the end of your next turn)?"))) {
    for (const e of ownEffects(actor, SRC.roar)) await e.delete?.();
    await h().createEffectsOn(actor, [effectData(SRC.roar, {
      name: "Draconic Pact: roar", img: "icons/svg/sound.svg",
      description: "Advantage on your next Demoralise (Intimidate) check before the end of your next turn.",
      system: { conditionals: roarConditionals() }, expiry: expiryFor("endOfNextTurn", actor)
    })]);
    await card(actor, "Draconic Pact", [line("You <strong>roar</strong>: advantage on your next Demoralise (Intimidate) check before the end of your next turn.")]);
  }
  if (featOf(actor, "Void Pact") && voidDBDue(ctx) && Boolean(ctx.cast)) {
    const old = ownEffects(actor, SRC.voidDB);
    if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old.map((e) => e.id));
    await actor.createEmbeddedDocuments("ActiveEffect", [effectData(SRC.voidDB, {
      name: `Void Pact (+${VOID_DB} DB)`, img: "icons/svg/shield.svg",
      description: `+${VOID_DB} circumstance to DB until the start of your next turn.`,
      changes: voidDBChanges(), expiry: expiryFor("startOfNextTurn", actor)
    })]);
    await card(actor, "Void Pact", [line(`A creature resisted your spell with a Critical or better: <strong>+${VOID_DB} circumstance to DB</strong> until the start of your next turn.`)]);
  }
  const crits = featOf(actor, "Crimson Rite") ? crimsonCriticals(ctx) : [];
  if (crits.length) {
    for (const target of crits) await h().applyConditionTagsTo(target, [{ key: "bleeding", value: 1, label: "Bleeding" }]);
    await h().applyConditionTags(actor, [{ key: "bleeding", value: crits.length, label: "Bleeding" }]);
    await card(actor, "Crimson Rite", [line(`A critical spell attack: ${crits.map((t) => `<strong>${esc(t.name)}</strong>`).join(", ")} gain${crits.length === 1 ? "s" : ""} Bleeding 1, and your Bleeding rises by ${crits.length}.`)]);
  }
  if ((ctx.castOptions ?? []).map(norm).includes("sanguinechannel") && !ctx.refunded && sanguineEarned(ctx)) {
    await h().applyConditionTags(actor, [{ key: "bleeding", value: 1, label: "Bleeding" }]);
    await card(actor, "Sanguine Channel", [line("Your Bleed rises by 1 more for the channelled +1.")]);
  }
  if (infusionDue(ctx)) {
    const energy = DRAGON_TYPES[wyrmTypeOf(actor)] ?? "";
    const got = infusionRider({ energy, warpMods: ctx.warpMods, wyrm: Boolean(featOf(actor, "Blood of the Wyrm")) });
    if (!got) await card(actor, "Draconic Infusion", [line("<em>No dragon type chosen yet (Dragon Claws' Use): the claws' extra damage is not laid.</em>")]);
    else {
      const old = ownEffects(actor, SRC.infusion);
      if (old.length) await actor.deleteEmbeddedDocuments("ActiveEffect", old.map((e) => e.id));
      await actor.createEmbeddedDocuments("ActiveEffect", [effectData(SRC.infusion, {
        name: `Draconic Infusion: +${got.rider.dice} ${energy}`, img: "icons/svg/fire.svg",
        description: `Draconic Infusion: your Claw attacks deal ${got.rider.dice} secondary ${energy} damage.`,
        system: { strikeRider: got.rider }, expiry: forSeconds(got.seconds)
      })]);
      await card(actor, "Draconic Infusion", [line(`Your Claw attacks deal <strong>${got.rider.dice} secondary ${esc(energy)}</strong> for ${got.seconds / 60} minute${got.seconds > 60 ? "s" : ""}${featOf(actor, "Blood of the Wyrm") ? " (Blood of the Wyrm's die included)" : ""}.`)]);
    }
  }
}

/** Hooks.on("createItem"): a Warlock's Pact spell; Void Pact's Darkvision; the dragon type's effects; Crimson Rite. One client. */
export async function onItemCreatedB6A(item) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  await warlockPactSpell(item);
  if (featOf(actor, "Void Pact") && (item.type === "ability" || item.type === "feat")) await syncVoidDarkvision(actor);
  if (item.type === "feat" && ["blood of the wyrm", "draconic claws"].includes(norm(item.name))) {
    if (!(await syncWyrm(actor)) && !wyrmTypeOf(actor)) await card(actor, item.name, [line(`<em>No dragon type chosen yet: press <strong>Use</strong> on ${esc(item.name)} to choose it.</em>`)]);
  }
  if (item.type === "feat" && ["draconic pact", "elemental pact"].includes(norm(item.name))) await card(actor, item.name, [line(`<em>Press <strong>Use</strong> on ${esc(item.name)} to choose your patron's ${norm(item.name) === "draconic pact" ? "energy" : "element"}.</em>`)]);
  if (item.type === "feat" && norm(item.name) === "crimson rite") await syncCrimson(actor);
}

/** Hooks.on("updateItem", (item, change)): a dragon type chosen (Dragon Claws' Use, or a borrowed Dragon). */
export async function onItemUpdatedB6A(item, change = {}) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  const get = globalThis.foundry?.utils?.getProperty;
  const touched = get?.(change, `flags.${MODULE_ID}.dragonType`) !== undefined || get?.(change, `flags.${SYSTEM_ID}.${BORROWED_DRAGON_FLAG}`) !== undefined;
  if (touched) await syncWyrm(actor);
}

/** Hooks.on("deleteItem"): Void Pact's Darkvision from elsewhere may have gone. */
export async function onItemDeletedB6A(item) {
  const actor = item?.parent;
  if (!actor?.isOwner || !actsFor(actor)) return;
  if (featOf(actor, "Void Pact")) await syncVoidDarkvision(actor);
  if (norm(item?.name) === "crimson rite") await syncCrimson(actor);
}

/** Hooks.on("createActiveEffect") and Hooks.on("updateActiveEffect"): Crimson Rite's Bleed window. */
export async function onEffectChangedB6A(effect) {
  const actor = effectActor(effect);
  if (!actor?.isOwner || !actsFor(actor) || !featOf(actor, "Crimson Rite")) return;
  if (statusList(effect).includes("bleeding") || effect.getFlag?.(MODULE_ID, "source") === SRC.crimsonOff) await syncCrimson(actor);
}

/** Hooks.on("deleteActiveEffect"): Crimson Rite's window; Wyrm Ascendant's wings fold (and a fall if aloft). */
export async function onEffectDeletedB6A(effect) {
  const actor = effectActor(effect);
  if (!actor?.isOwner || !actsFor(actor)) return;
  const source = effect.getFlag?.(MODULE_ID, "source");
  if (featOf(actor, "Crimson Rite") && (statusList(effect).includes("bleeding") || source === SRC.crimsonOff)) await syncCrimson(actor);
  if (source === SRC.wings) {
    await syncWings(actor);
    await landIfAloft(actor);
  }
}
