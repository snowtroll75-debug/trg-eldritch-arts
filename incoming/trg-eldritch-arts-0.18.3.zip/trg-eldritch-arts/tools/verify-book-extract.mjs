#!/usr/bin/env node
/**
 * verify-book-extract — Eldritch Arts 0.10.0 (before Block 7): the book
 * extract (tools/content/book-text.json, cut by tools/content/extract-book.mjs)
 * and the two shipped corrections it brings (Block 7 audit §6; Graham's Q166).
 *
 *   A  every bold label of an entry's field lines reaches `fields` (the
 *      extractor records them in `labels`); no field line is left in `lines`
 *   B  the 16 "Target" lines of §6, Rippling Gaze's "Requirement", the three
 *      bold-comma Tradition lines (EA-m127), Steelbinding's "; Requirements"
 *      (m45), Spirit Arrow's standalone Target line
 *   C  the source, when it is on disk (EA_BOOK_MD, else ../../ea-src/v16/ea.md):
 *      re-cut into a scratch file, the extract is identical to book-text.json;
 *      and every field line in each entry's span has each bold label in `fields`
 *   D  shipped: Paradox Weave's "Target 1 willing creature" (card and
 *      system.targets); the six built Grimoire spells uncommon, as the core
 *      reads it, and nothing else; packs-source agrees with the build;
 *      Steelbinding's repair now writes what the extract holds
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-book-extract.mjs
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const BOOK_PATH = path.join(ROOT, "tools", "content", "book-text.json");
const book = JSON.parse(fs.readFileSync(BOOK_PATH, "utf8"));

/** Every entry list the extractor cuts with `entries()`: [list, entry]. */
const LISTS = {
  ...Object.fromEntries(Object.entries(book.sections).filter(([, v]) => Array.isArray(v))),
  grimoire: book.grimoire,
  specialist: book.specialist
};
const ALL = Object.entries(LISTS).flatMap(([k, list]) => list.map((e) => [k, e]));
const grim = (n) => book.grimoire.find((e) => e.name === n);
const spec = (n) => book.specialist.find((e) => e.name === n);
const KNOWN = new Set(ALL.flatMap(([, e]) => Object.keys(e.fields)));

/* ----------------------------------------------------------------- */
/* A  every bold label reaches fields                                   */
/* ----------------------------------------------------------------- */
{
  ok("A every entry records its field lines' labels", ALL.every(([, e]) => Array.isArray(e.labels)), `${ALL.filter(([, e]) => !Array.isArray(e.labels)).length} without`);
  const unrecorded = ALL.filter(([, e]) => (e.labels ?? []).length < Object.keys(e.fields).length).map(([k, e]) => `${k} ${e.name}`);
  equal("A every field an entry holds has its label recorded", unrecorded, []);
  const lost = ALL.flatMap(([k, e]) => (e.labels ?? []).filter((l) => !(l in e.fields)).map((l) => `${k} ${e.name} L${e.line}: "${l}"`));
  equal("A no bold label of a field line is lost (every one reaches fields)", lost, []);
  const stranded = ALL.flatMap(([k, e]) => e.lines.filter((l) => { const m = /^\*\*([^*]+?)\*\*\s*\S/.exec(l); return m && KNOWN.has(m[1].trim()) && !/:\s*$|:\*\*/.test(l.slice(0, m[0].length)); }).map((l) => `${k} ${e.name}: ${l.slice(0, 60)}`));
  equal("A no field line (a known label leading it) is left in lines", stranded, []);
  ok("A the entry lists are all there", ALL.length > 400, `${ALL.length}`);
}

/* ----------------------------------------------------------------- */
/* B  the lines §6 names                                                */
/* ----------------------------------------------------------------- */
{
  const TARGETS = {
    // Block 7 (10)
    "BOUNCY BODY": "1 creature", CHRONOWEAVE: "willing allies", "FLESH TO BLOSSOM": "1 creature", "LEYLINE BURST": "1 creature or object",
    "MANA SURGE": "1 creature", "MEMORY ECLIPSE": "1 creature", "METAMAGIC RESONANCE": "willing allies", "PLANAR ANCHOR": "one creature",
    PLEDGESHROUD: "one creature", "SPECTRAL AEGIS": "one creature",
    // Block 8 (5)
    "LEYLINE ANCHOR": "1 Leyline that you are aware of", "MIMIC SPELL": "1 spell being cast", RISERUNE: "one surface",
    "SOUL CONFLUENCE": "willing allies", "TRAVELLER’S CHARM": "one mundane, wearable item"
  };
  for (const [n, t] of Object.entries(TARGETS)) equal(`B ${n}: Target`, grim(n)?.fields?.Target, t);
  equal("B PARADOX WEAVE (shipped, 0.5.0): Target", spec("PARADOX WEAVE")?.fields?.Target, "1 willing creature");
  equal("B 16 Target lines in all (15 Grimoire + Paradox Weave), plus Spirit Arrow's own line", [book.grimoire.filter((e) => "Target" in e.fields).length, book.specialist.filter((e) => "Target" in e.fields).length], [16, 1]);
  equal("B SPIRIT ARROW: its standalone Target line is a field, not a line", [grim("SPIRIT ARROW")?.fields?.Target, grim("SPIRIT ARROW")?.lines.some((l) => /^\*\*Target\*\*/.test(l))], ["one arrow or bolt", false]);
  equal("B RIPPLING GAZE: Requirement", grim("RIPPLING GAZE")?.fields?.Requirement, "you are touching a body of water");
  equal("B RIPPLING GAZE: Range is not swallowed", grim("RIPPLING GAZE")?.fields?.Range, "500 feet");
  equal("B CALL OF THE ANCESTORS: Tradition (bold comma)", grim("CALL OF THE ANCESTORS")?.fields?.Tradition, "divinity, ethereal");
  equal("B UNDEAD BINDING: Tradition (bold comma)", grim("UNDEAD BINDING")?.fields?.Tradition, "arcane, divinity, ethereal");
  equal("B VEIL SEVERING: Tradition (bold comma)", grim("VEIL SEVERING")?.fields?.Tradition, "arcane, ethereal");
  ok("B no field value keeps a bold run's asterisks", ALL.every(([, e]) => Object.values(e.fields).every((v) => !/\*\*/.test(v))));
  const steel = book.sections.classFeats.find((e) => e.name === "STEELBINDING");
  equal("B STEELBINDING: '+2**; Requirements**' reads both (m45)", steel?.fields, { Prerequisites: "Iron Ward", "PP Cost": "+2", Requirements: "your spell targets a creature wearing metal armour who is within 30-ft." });
  equal("B counts unchanged: 87 Grimoire, 41 specialist", [book.grimoire.length, book.specialist.length], [87, 41]);
}

/* ----------------------------------------------------------------- */
/* C  against the source                                               */
/* ----------------------------------------------------------------- */
{
  const SRC = process.env.EA_BOOK_MD ?? path.resolve(ROOT, "..", "..", "ea-src", "v16", "ea.md");
  const SIDEBARS = path.join(path.dirname(SRC), "ea-sidebars.md");
  if (!fs.existsSync(SRC) || !fs.existsSync(SIDEBARS)) {
    console.log(`verify-book-extract: source not on disk (${SRC}); C skipped.`);
  } else {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ea-extract-"));
    const out = path.join(tmp, "book-text.json");
    try {
      execFileSync(process.execPath, [path.join(ROOT, "tools", "content", "extract-book.mjs"), SRC, SIDEBARS, out], { stdio: ["ignore", "pipe", "pipe"] });
      ok("C a re-cut from the source is identical to book-text.json", fs.readFileSync(out, "utf8") === fs.readFileSync(BOOK_PATH, "utf8"));
    } catch (e) {
      ok("C the extractor runs on the source", false, String(e.stderr ?? e.message).split("\n")[0]);
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); }

    // Independently of the extractor's own `labels`: every field line in the
    // entry's span of ea.md (heading to the next entry) has each bold label in fields.
    const L = fs.readFileSync(SRC, "utf8").split("\n");
    const fold = (s) => s.replace(/\*\*([,;.])\*\*/g, "$1").replace(/\*\*([,;]\s*)([^*]+?)\*\*/g, "$1**$2**");
    const missed = [];
    let fieldLines = 0;
    for (const list of Object.values(LISTS)) {
      list.forEach((e, i) => {
        const end = list[i + 1]?.line ?? e.line + 1;
        for (let n = e.line + 1; n < end; n += 1) {
          const t = fold((L[n - 1] ?? "").trim());
          const labels = [...t.matchAll(/\*\*([^*]+?)\*\*/g)].map((m) => m[1].trim().replace(/[:;]$/, "").trim());
          if (!t.startsWith("**") || !labels.some((l) => KNOWN.has(l)) || /^\*\*[^*]+:\*\*/.test(t)) continue;
          if (!labels.some((l) => l in e.fields)) continue; // a body line led by a word that is also a label elsewhere
          fieldLines += 1;
          for (const l of labels) if (!(l in e.fields)) missed.push(`${e.name} L${n}: "${l}"`);
        }
      });
    }
    equal("C every bold label on a source field line reaches fields", missed, []);
    ok("C the source scan saw the field lines", fieldLines > 400, `${fieldLines}`);
    for (const [n, want] of [[6358, "**Target** 1 creature"], [8525, "**Target** 1 willing creature"], [7518, "**Requirement** you are touching a body of water"], [6420, "**Tradition** divinity**,** ethereal"], [7881, "**Tradition** arcane**,** divinity, ethereal"], [7941, "**Tradition** arcane**,** ethereal"]]) {
      ok(`C ea.md L${n} still prints ${want}`, (L[n - 1] ?? "").includes(want), L[n - 1]);
    }
  }
}

/* ----------------------------------------------------------------- */
/* D  shipped content                                                   */
/* ----------------------------------------------------------------- */
{
  const SP = await import(new URL("./content/block3-spells.mjs", import.meta.url));
  const B1 = await import(new URL("./content/block1.mjs", import.meta.url));
  const B4 = await import(new URL("./content/block4-spells.mjs", import.meta.url));
  const B6b1 = await import(new URL("./content/block6-b1.mjs", import.meta.url));
  const B6b2 = await import(new URL("./content/block6-b2.mjs", import.meta.url));
  const rep = await import(sys("module", "magic", "repertoire.mjs"));
  const built = [...SP.BLOCK3_SPECIALIST, ...SP.BLOCK3_GRIMOIRE, ...B1.SPELLS, ...B4.BLOCK4_SPECIALIST, B4.XITHRA, ...(B6b1.SPELLS_B6_B1 ?? []), ...(B6b2.SPELLS_B6_B2 ?? [])];
  const GRIM_NAMES = new Set(book.grimoire.map((e) => e.name.toLowerCase()));

  const pw = built.find((s) => s.name === "Paradox Weave");
  equal("D Paradox Weave: system.targets", pw?.system?.targets, "1 willing creature");
  ok("D Paradox Weave: the card prints Target 1 willing creature, after Range", /<strong>Range<\/strong> 30 feet<\/p>\n<p><strong>Target<\/strong> 1 willing creature<\/p>/.test(pw?.system?.description ?? ""));

  const SIX = ["Orb of Water", "Dark Whispers", "Message Rune", "Observe the Weave", "Symbol of Death", "Symbol of Fear"];
  const grimBuilt = built.filter((s) => GRIM_NAMES.has(s.name.toLowerCase())).map((s) => s.name).sort();
  equal("D the built Grimoire spells are the six", grimBuilt, [...SIX].sort());
  for (const n of SIX) {
    const s = built.find((x) => x.name === n);
    equal(`D ${n}: system.availability`, s?.system?.availability, "uncommon");
    equal(`D ${n}: the core reads it uncommon, and warns at a level-up pick`, [rep.spellAvailabilityTier(s), rep.availabilityWarning(s).warn], ["uncommon", true]);
  }
  const others = built.filter((s) => !GRIM_NAMES.has(s.name.toLowerCase()) && rep.spellAvailabilityTier(s) !== "common").map((s) => s.name);
  equal("D no specialist (non-Grimoire) spell is marked", others, []);
  equal("D GRIMOIRE_AVAILABILITY", SP.GRIMOIRE_AVAILABILITY, "uncommon");

  // packs-source is what ships: it must agree with the build.
  const dir = path.join(ROOT, "packs-source", "ea-spells");
  const packed = new Map(fs.readdirSync(dir).map((f) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"))).map((d) => [d.name, d]));
  for (const n of [...SIX, "Paradox Weave"]) {
    const a = packed.get(n), b = built.find((x) => x.name === n);
    equal(`D packs-source ${n}: availability, targets, description as built`, [a?.system?.availability, a?.system?.targets, a?.system?.description], [b?.system?.availability, b?.system?.targets, b?.system?.description]);
  }
  // FROM 0.10.0 (Block 7) the 42 new Grimoire spells are uncommon too: every Grimoire spell, and nothing else.
  const B7 = (await import(new URL("./content/block7-spells.mjs", import.meta.url))).SPELLS_B7.map((d) => d.name);
  // …AND FROM 0.11.0 (Block 8a) its 22.
  const B8A = (await import(new URL("./content/block8a-spells.mjs", import.meta.url))).SPELLS_B8A.map((d) => d.name);
  // …AND FROM 0.12.0 (Block 8b) its 17.
  const B8B = (await import(new URL("./content/block8b-spells.mjs", import.meta.url))).SPELLS_B8B.map((d) => d.name);
  equal("D packs-source: no other spell is uncommon (the six, Block 7's 42, Block 8a's 22 and Block 8b's 17)", [...packed.values()].filter((d) => d.system?.availability === "uncommon").map((d) => d.name).sort(), [...SIX, ...B7, ...B8A, ...B8B].sort());

  // Steelbinding's repair (block6-common) now writes what the extract holds.
  const C6 = await import(new URL("./content/block6-common.mjs", import.meta.url));
  equal("D Steelbinding: the repair agrees with the extract", C6.bookFeat("STEELBINDING").fields, book.sections.classFeats.find((e) => e.name === "STEELBINDING").fields);
}

console.log(`verify-book-extract: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
