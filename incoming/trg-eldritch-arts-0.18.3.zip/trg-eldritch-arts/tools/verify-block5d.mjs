#!/usr/bin/env node
/**
 * verify-block5d — Eldritch Arts 0.8.0, Block 5 group D (on TRG Prime
 * 3.683.0): the thirty-four general feats Chapter 5 adds beyond Block 1's
 * nine, and Esoteric Insight's Spell Recognition tick (C11).
 *
 *   A  the feats against the book: names, category, prerequisites, traits,
 *      uses, the printed text, each card's automation paragraph and grade
 *   B  the declarations, read by the core's own code: conditionals, rerolls,
 *      the sense, the control levels, Sniping, the ally aura, Focus uses
 *   C  the rules, run: durations, dice, the reservoir, the circle, Dispel
 *      Power through the core's Dispel arithmetic, Mirrored Rebuke's offer,
 *      Runic Stabiliser and Masked Caster through the core's cast options and
 *      remap, the ritual seats through the core's ritual rules, the time
 *      ladders, the degree upgrade, the skill substitutions
 *   D  registration
 *   E  the Foundry side with fakes: the action hooks, the check reactions, the
 *      Uses, Essence Reservoir, Spell Thief, Mirrored Rebuke's counter
 *   F  Block 1's Esoteric Insight, scoped to Spell Recognition's roll
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block5d.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const confirms = [];
const created = [];
const released = [];
const resonance = [];
const resolved = [];
let resolveDegree = { key: "success", label: "Success" };
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => (answers.length ? answers.shift() : null),
  createEffectsOn: async (target, list) => { created.push(...list.map((d) => ({ on: target.name, ...d }))); return target.createEmbeddedDocuments("ActiveEffect", list); },
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (Number.isFinite(n) && n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  rollResonanceEvent: async (actor, opts) => { resonance.push({ actor: actor.name, ...opts }); },
  releaseItemSpell: async (actor, item, ref, opts) => { released.push({ actor: actor.name, item: item?.name, ref, opts, targets: [...globalThis.game.user.targets].map((t) => t.id) }); return { cast: true, missing: false }; },
  resolveAction: async (actor, action, options) => { resolved.push({ actor: actor.name, action, options }); return { outcome: { degree: resolveDegree } }; },
  askReactor: async (actor, q) => ({ answer: "yes", result: await STEP(actor, "yes", q.data) }),
  isDead: async () => false,
  get skillActions() { return [{ key: "dispel", name: "Dispel", skills: ["powerManipulation"] }]; }
};
let STEP = async () => ({ rolled: false });
const hookFns = {};
globalThis.Hooks = { on: (name, fn) => { (hookFns[name] ??= []).push(fn); return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = {
  applications: { api: { DialogV2: { confirm: async () => (confirms.length ? confirms.shift() : true), prompt: async () => ({ t0: true }) } }, ux: { FormDataExtended: class { constructor() { this.object = { t0: true }; } } } },
  utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false }
};
let rollTotal = 3;
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { const m = /^(\d+)d(\d+)$/.exec(this.f); this.total = m ? Number(m[1]) * rollTotal : rollTotal; return this; } };
const whispers = [];
globalThis.ChatMessage = { create: async (d) => { whispers.push(d); }, getSpeaker: () => ({}) };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };

let nextId = 0;
const set = (o, k, v) => globalThis.foundry.utils.setProperty(o, k, v);
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.update = async (u) => { for (const [k, v] of Object.entries(u)) set(e, k, v); };
  e.toObject = () => JSON.parse(JSON.stringify({ ...e, parent: undefined }));
  return e;
}
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) set(it, k, v); };
  return it;
}
function makeActor(name, { items = [], pp = 5, max = 20, cl = 6, ranks = {}, disposition = 1 } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, documentName: "Actor", effects: [], flags: {}, items: [] };
  a.system = { identity: { level: cl }, resources: { pp: { value: pp, max }, ap: { value: 6 } }, magic: { casterLevelValue: cl, spellcraft: { dc: 21 } }, skills: Object.fromEntries(Object.entries(ranks).map(([k, r]) => [k, { ranks: r }])) };
  a.items = items.map((d) => makeItem(d, a));
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) set(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = list.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => { if (type === "Item") a.items = a.items.filter((i) => !ids.includes(i.id)); else a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.token = { id: `t-${name}`, actor: a, name, document: { disposition }, setTarget(on) { if (on) globalThis.game.user.targets.add(this); else globalThis.game.user.targets.delete(this); }, get isTargeted() { return globalThis.game.user.targets.has(this); } };
  a.getActiveTokens = () => [a.token];
  return a;
}
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: [{ id: "gm", isGM: true }, { id: "u2", isGM: false }],
  combat: null, actors: [], packs: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.683.0" }
};
globalThis.canvas = { tokens: { placeables: [] } };

const D = await import(new URL("./content/block5-d.mjs", import.meta.url));
const common = await import(new URL("./content/block5-common.mjs", import.meta.url));
const { md } = await import(new URL("./content/markdown.mjs", import.meta.url));
const B1 = await import(new URL("./content/block1.mjs", import.meta.url));
const auto = await import(new URL("../module/block5d-automations.mjs", import.meta.url));
const b1actions = await import(new URL("../module/block1-actions.mjs", import.meta.url));
const b2b = await import(new URL("../module/block2b-automations.mjs", import.meta.url));
const F = (doc) => doc.flags?.["trg-prime"] ?? {};
const byName = Object.fromEntries(D.FEATS_B5_D.map((f) => [f.name, f]));
const feat = (name) => byName[name];
const owning = (...names) => names.map((n) => ({ ...(feat(n) ?? B1.BACKGROUND_FEATS.find((f) => f.name === n) ?? { name: n, type: "feat", system: {}, flags: {} }), type: "feat" }));

/* ----------------------------------------------------------------- */
/* A — the feats against the book                                       */
/* ----------------------------------------------------------------- */
const titleCase = (s) => s.toLowerCase().replace(/(^|[\s(\-–])([a-z’'])/g, (m, a, b) => a + b.toUpperCase()).replace(/’S\b/g, "’s");
const GENERAL = book.sections.generalFeats;
const builtIn = new Set(B1.BACKGROUND_FEATS.map((f) => f.name));
const expectedNames = GENERAL.map((f) => titleCase(f.name)).filter((n) => !builtIn.has(n));
equal("A the book prints 43 general feats; Block 1 ships nine of them", [GENERAL.length, B1.BACKGROUND_FEATS.length, D.BUILT_IN_BLOCK1.length], [43, 9, 9]);
equal("A …the nine Block 1 ships are the nine this group leaves out", [...builtIn].sort(), [...D.BUILT_IN_BLOCK1].sort());
equal("A group D builds the other thirty-four, in the book's order", D.FEATS_B5_D.map((f) => f.name), expectedNames);
equal("A none rebuilt: no name and no id shared with Block 1", D.FEATS_B5_D.filter((f) => builtIn.has(f.name) || B1.BACKGROUND_FEATS.some((b) => b._id === f._id)).map((f) => f.name), []);
equal("A ids are unique", new Set(D.FEATS_B5_D.map((f) => f._id)).size, 34);
ok("A the curly apostrophes are kept (Lorekeeper’s, Rune-Binder’s, Wanderer’s)", ["Lorekeeper’s Insight", "Rune-Binder’s Precision", "Wanderer’s Mastery", "Wanderer’s Sense"].every((n) => byName[n]));
equal("A Rune-Binder’s Precision is the name Block 2b's ritual seat reads", b2b.countsAsTwo({ items: [{ type: "feat", name: feat("Rune-Binder’s Precision").name }] }), true);
for (const b of GENERAL) {
  const name = titleCase(b.name);
  const f = byName[name];
  if (builtIn.has(name)) continue;
  if (!f) { ok(`A ${name} exists`, false); continue; }
  equal(`A ${name}: General, no race, the book's prerequisites`, [f.type, f.system.category, f.system.sourceRace, f.system.prerequisites], ["feat", "General", "", b.fields?.Prerequisites ?? ""]);
  const desc = f.system.description;
  ok(`A ${name}: the card opens with the book's traits, fields and text, verbatim`, desc.startsWith(common.printedCard(b)));
  ok(`A ${name}: …which holds every printed line`, b.lines.every((l) => common.printedCard(b).includes(md(l).replace(/^<p>|<\/p>$/g, "").slice(0, 40))));
  ok(`A ${name}: the card says what is automated`, /\*(Automated \(0\.(?:[48]|13)\.0|Partly automated \(0\.[89]\.0|Not yet automated:|Not automated:)/.test(desc.replace(/<\/?em>/g, "*")) || /<em>(Automated \(0\.(?:[48]|13)\.0|Partly automated \(0\.[89]\.0|Not yet automated:|Not automated:)/.test(desc));
  ok(`A ${name}: Block 5's markers`, f.flags["trg-prime"].eaBlock === 5 && f.flags["trg-prime"].eaBookLine === b.line);
}
equal("A Mirrored Rebuke prints its Free action", /\*\*Action\*\* Free|<strong>Action<\/strong> Free/.test(feat("Mirrored Rebuke").system.description), true);
equal("A the traits: none printed, Dispel Power's Focus from its text", D.FEATS_B5_D.filter((f) => f.system.traits).map((f) => [f.name, f.system.traits]), [["Dispel Power", "Focus"]]);
equal("A the counted uses: Expert, Ley Channeler and Wanderer’s Sense once a day; Dispel Power's Focus arrives full", D.FEATS_B5_D.filter((f) => f.system.usesPerDay || f.system.usesValue).map((f) => [f.name, f.system.usesPerDay, f.system.usesValue]), [["Dispel Power", "", 1], ["Esoteric Insight Expert", "1", 1], ["Ley Channeler", "1", 1], ["Wanderer’s Sense", "1", 1]]);
equal("A Threadcutter alone is repeatable (\"You may select this feat multiple times\")", D.FEATS_B5_D.filter((f) => f.system.repeatable).map((f) => f.name), ["Threadcutter"]);
equal("A the docs table names every feat", Object.keys(D.AUTOMATION_B5_D), D.FEATS_B5_D.map((f) => f.name));
const MARK = { A: /Automated \(0\.(?:[48]|13)\.0/, B: /Automated \(0\.8\.0/, C: /Partly automated \(0\.[89]\.0/, D: /Not (yet )?automated:/ };
for (const [n, row] of Object.entries(D.AUTOMATION_B5_D)) ok(`A ${n}: grade ${row.level} agrees with its card`, MARK[row.level]?.test(byName[n]?.system.description ?? "") && (row.level !== "D" || !/\*?Automated \(/.test(byName[n].system.description)));
equal("A the grades (A · B · C · D)", ["A", "B", "C", "D"].map((g) => Object.values(D.AUTOMATION_B5_D).filter((r) => r.level === g).length), [10, 14, 6, 4]); // 0.13.0: three Catalyst feats D → A (Block 9a)
equal("A the Catalyst feats say what Block 9a (0.13.0) automates, and Crafting why it does not", ["Catalyst Affinity", "Catalyst Conservation", "Catalyst Crafting", "Catalyst Mastery"].map((n) => (/Automated \(0\.13\.0, TRG Prime 3\.688\.0\)/.test(feat(n).system.description) ? "auto" : /Not automated:\*?<\/em>? TRG Prime’?\'?s Create/.test(feat(n).system.description) ? "card" : "?")), ["auto", "auto", "card", "auto"]);
// Piercing Insight arrived with Block 6 (0.9.0; block6d): partly automated, the GM applying the effect.
ok("A Piercing Insight: partly automated in 0.9.0 by Block 6's catalogue, the GM applying it", /Partly automated \(0\.9\.0/.test(feat("Piercing Insight").system.description) && /Block 6/.test(feat("Piercing Insight").system.description) && /the GM applies it/.test(feat("Piercing Insight").system.description) && D.AUTOMATION_B5_D["Piercing Insight"].level === "C");
// Prerequisite chains: every feat named in a prerequisite is an item somewhere (this group, Block 1, or the core).
/** The core's feat names, read from a copy of its pack (another reader may hold the pack's lock). */
async function coreFeatNames() {
  const dir = path.join(SYSTEM_ROOT, "packs", "feats");
  if (!fs.existsSync(dir)) return null;
  const os = await import("node:os");
  const copy = fs.mkdtempSync(path.join(os.tmpdir(), "ea-b5d-feats-"));
  try {
    for (const f of fs.readdirSync(dir)) if (f !== "LOCK") fs.copyFileSync(path.join(dir, f), path.join(copy, f));
    const { ClassicLevel } = await import("classic-level");
    const db = new ClassicLevel(copy, { valueEncoding: "json" });
    const names = new Set();
    try { for await (const [k, v] of db.iterator()) if (k.split("!")[1] && !k.split("!")[1].includes(".")) names.add(String(v.name).toLowerCase()); }
    finally { await db.close(); }
    return names;
  } finally { fs.rmSync(copy, { recursive: true, force: true }); }
}
const coreFeats = await coreFeatNames();
ok("A the core's feats pack was read", Boolean(coreFeats?.size));
equal("A no feat here clashes with a core feat of the same name", D.FEATS_B5_D.filter((f) => coreFeats?.has(f.name.toLowerCase())).map((f) => f.name), []);
const allNames = new Set([...D.FEATS_B5_D, ...B1.BACKGROUND_FEATS].map((f) => f.name));
for (const [n, needs] of [["Archsage Command", "Rune-Binder’s Precision"], ["Catalyst Mastery", "Catalyst Affinity"], ["Dispel Power", "Disrupt Magic"], ["Esoteric Insight Expert", "Esoteric Insight"], ["Esoteric Insight Master", "Esoteric Insight Expert"], ["Essence Reservoir", "Channel Siphoner"], ["Mnemonic Grasp", "Spell Transcription"], ["Rune-Binder’s Precision", "Lorekeeper’s Insight"], ["Wanderer’s Mastery", "Wanderer’s Sense"], ["Wanderer’s Sense", "Wanderer’s Instinct"]]) {
  ok(`A ${n} → ${needs}: printed, and an item of that exact name`, feat(n).system.prerequisites.includes(needs) && allNames.has(needs));
}
ok("A Counter Spell, Scribe Scroll and Spell Recognition are core feats (Mirrored Rebuke, Spell Transcription)", ["counter spell", "scribe scroll", "spell recognition"].every((n) => coreFeats?.has(n)));
// Dispel Power's ladder is the book's.
const dp = GENERAL.find((f) => f.name === "DISPEL POWER");
equal("A Dispel Power's four results are the book's own words", Object.entries(auto.DISPEL_POWER_OUTCOMES).map(([k, t]) => dp.lines.some((l) => l === `**${k[0].toUpperCase()}${k.slice(1)}** ${t}`)), [true, true, true, true]);

/* ----------------------------------------------------------------- */
/* B — the declarations, read by the core                               */
/* ----------------------------------------------------------------- */
const cond = await import(sys("module", "conditionals.mjs"));
const { BONUS_TYPES } = await import(sys("module", "dice", "resolution.mjs"));
const fumble = await import(sys("module", "fumble-reroll.mjs"));
{
  let n = 0;
  for (const f of D.FEATS_B5_D) for (const [i, raw] of (F(f).conditionals ?? []).entries()) {
    n += 1;
    const entry = cond.normaliseConditional(raw, { id: f._id, name: f.name }, i);
    ok(`B ${f.name}: conditionals[${i}] normalises, with a type the core knows`, entry !== null && (entry.kind !== "modifier" || Object.hasOwn(BONUS_TYPES, entry.type)), JSON.stringify(raw));
  }
  equal("B every conditional the group declares (Expert 1, Master 1, Ley Scholar 2, Lorekeeper 1, Master Binder 1, Runespeaker 1, Wanderer’s Sense 2)", n, 9);
  const row = (name, i = 0) => cond.normaliseConditional(F(feat(name)).conditionals[i], { name }, i);
  ok("B Ley Scholar's +2 is automatic on Tap and Channel Ley Line, not on Ley Sense", cond.matchesCheck(row("Ley Scholar"), { checkType: "skill", actionKey: "tapLeyLine" }) && cond.matchesCheck(row("Ley Scholar"), { checkType: "skill", actionKey: "channelLeyLine" }) && !cond.matchesCheck(row("Ley Scholar"), { checkType: "skill", actionKey: "leySense" }) && row("Ley Scholar").auto === true);
  ok("B …its anomaly tick is on other skill checks only", !cond.matchesCheck(row("Ley Scholar", 1), { checkType: "skill", actionKey: "tapLeyLine" }) && cond.matchesCheck(row("Ley Scholar", 1), { checkType: "skill", actionKey: "hide" }) && row("Ley Scholar", 1).auto === false);
  ok("B Expert's +2 circumstance meets a Shadow or Emotion save by itself, not a Fire one", cond.matchesCheck(row("Esoteric Insight Expert"), { checkType: "save", traits: ["shadow"] }) && cond.matchesCheck(row("Esoteric Insight Expert"), { checkType: "save", traits: ["Emotion"] }) && !cond.matchesCheck(row("Esoteric Insight Expert"), { checkType: "save", traits: ["fire"] }) && row("Esoteric Insight Expert").type === "circumstance");
  ok("B Master's advantage is a tick on Identify Power and Spell Recognition", cond.matchesCheck(row("Esoteric Insight Master"), { checkType: "skill", actionKey: "spellRecognition" }) && cond.matchesCheck(row("Esoteric Insight Master"), { checkType: "skill", actionKey: "identifyPower" }) && !row("Esoteric Insight Master").auto);
  ok("B Lorekeeper's +2 class is a tick on specialist checks only", cond.matchesCheck(row("Lorekeeper’s Insight"), { checkType: "specialist" }) && !cond.matchesCheck(row("Lorekeeper’s Insight"), { checkType: "skill" }) && row("Lorekeeper’s Insight").type === "class");
  ok("B Runespeaker's +2 is a tick on Decipher Writing and Identify Power", cond.matchesCheck(row("Runespeaker"), { checkType: "skill", actionKey: "decipherWriting" }) && cond.matchesCheck(row("Runespeaker"), { checkType: "skill", actionKey: "identifyPower" }) && !cond.matchesCheck(row("Runespeaker"), { checkType: "skill", actionKey: "hide" }));
  ok("B Master Binder's +2 is a tick on skill checks and saves", cond.matchesCheck(row("Master Binder"), { checkType: "save" }) && cond.matchesCheck(row("Master Binder"), { checkType: "skill" }) && !cond.matchesCheck(row("Master Binder"), { checkType: "attack" }));
  ok("B Wanderer’s Sense: advantage on Survival, +2 circumstance on saves, both ticks", row("Wanderer’s Sense").kind === "advantage" && cond.matchesCheck(row("Wanderer’s Sense"), { checkType: "skill", subject: "survival" }) && !cond.matchesCheck(row("Wanderer’s Sense"), { checkType: "skill", subject: "stealth" }) && cond.matchesCheck(row("Wanderer’s Sense", 1), { checkType: "save" }) && row("Wanderer’s Sense", 1).value === 2 && !row("Wanderer’s Sense", 1).auto);
  // The rerolls.
  const ei = owning("Esoteric Insight", "Esoteric Insight Expert", "Esoteric Insight Master");
  equal("B on a failed Arcana check: Esoteric Insight's, Expert's and Master's rerolls, in that order", fumble.fumbleRerollRows(ei, "skill", "arcana", "failure").map((r) => r.label), ["Esoteric Insight", "Esoteric Insight (Expert's additional use)", "Esoteric Insight Master"]);
  equal("B …not on Stealth, not on a Partial, not a reaction", [fumble.fumbleRerollRows(ei, "skill", "stealth", "failure").length, fumble.fumbleRerollRows(ei, "skill", "occultism", "partial").length, fumble.fumbleRerollRows(ei, "skill", "occultism", "fumble").some((r) => r.reaction)], [0, 0, false]);
  const uses = await import(sys("module", "uses.mjs"));
  equal("B Master's reroll has no count (Q81); Expert's is one a day; Dispel Power is one Focus use", [feat("Esoteric Insight Master").system.usesPerDay, feat("Esoteric Insight Expert").system.usesPerDay, uses.focusDefaultUses(feat("Dispel Power").system, "feat")], ["", "1", 1]);
  // The sense.
  const senses = await import(sys("module", "senses.mjs"));
  const s = senses.sensesOf([{ ...feat("Magic Sense"), type: "feat" }], 3);
  equal("B Magic Sense: a tertiary sense, 30 + 5 × Wisdom feet, not halved (n7)", s.map((x) => [x.name, x.category, x.rangeFeet, x.special]), [["Magic Sense", "tertiary", 45, false]]);
  equal("B …its block is the core's own shape for a granted sense", (({ category, finds, rollWith }) => ({ category, finds, rollWith }))(F(feat("Magic Sense")).creatureAbility.derives.sense), (({ category, finds, rollWith }) => ({ category, finds, rollWith }))(senses.grantedSenseBlock({ category: "tertiary", detects: F(feat("Magic Sense")).creatureAbility.derives.sense.finds, rollWith: "Sense Magic (Power Manipulation)" })));
  const casting = await import(sys("module", "magic", "casting.mjs"));
  equal("B Master Binder: +2 control levels by the core's sum (C12)", casting.declaredControlLevelBonus([{ ...feat("Master Binder"), type: "feat" }]), 2);
  const sniping = await import(sys("module", "magic", "spell-sniping.mjs"));
  equal("B Silent Spellstrike opens Sniping to spell criticals (C15); no other feat here does", [sniping.declaresSpellSniping([{ ...feat("Silent Spellstrike"), type: "feat" }]), D.FEATS_B5_D.filter((f) => sniping.declaresSpellSniping([{ ...f, type: "feat" }])).length], [true, 1]);
  const ca = await import(sys("module", "creature-auras.mjs"));
  const auras = ca.aurasOf([{ ...feat("Wanderer’s Sense"), type: "feat", id: "ws" }], 5);
  equal("B Wanderer’s Sense's ally aura: 10 ft, allies only, laying the +2 save tick", auras.map((a) => [a.kind, a.radius ?? a.radiusFeet, a.includeSelf, a.allyEffect?.conditionals?.[0]?.value, a.allyEffect?.conditionals?.[0]?.when]), [["ally", 10, false, 2, { checkTypes: ["save"] }]]);
  // Journey and Master's riders.
  const journey = auto.journeyConditionals().map((c, i) => cond.normaliseConditional(c, { name: "j" }, i));
  ok("B the journey's +2 luck: automatic on a spell's save, a tick on another, never both", cond.matchesCheck(journey[0], { checkType: "save", traditions: ["arcane"] }) && !cond.matchesCheck(journey[1], { checkType: "save", traditions: ["arcane"] }) && cond.matchesCheck(journey[1], { checkType: "save" }) && !cond.matchesCheck(journey[0], { checkType: "save" }) && journey[0].type === "luck");
  const m = cond.normaliseConditional(auto.masterConditionals("Actor.witch", "Witch")[0], { name: "m" }, 0);
  ok("B Master's +2 against that caster: automatic for that caster only, spent once", cond.matchesCheck(m, { checkType: "save", sourceUuid: "Actor.witch" }) && !cond.matchesCheck(m, { checkType: "save", sourceUuid: "Actor.orc" }) && m.oneShot && m.auto);
  ok("B …and a tick when no caster is targeted", (() => { const t = cond.normaliseConditional(auto.masterConditionals()[0], { name: "m" }, 0); return t.auto === false && cond.matchesCheck(t, { checkType: "save" }); })());
  const arch = cond.normaliseConditional(auto.archsageConditionals()[0], { name: "a" }, 0);
  ok("B Archsage's advantage: a one-shot tick on saves (n1)", arch.kind === "advantage" && arch.oneShot && !arch.auto && cond.matchesCheck(arch, { checkType: "save" }) && !cond.matchesCheck(arch, { checkType: "skill" }));
}

/* ----------------------------------------------------------------- */
/* C — the rules, run                                                   */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
{
  equal("C Hypnotic Savant (n5): Success 11 min, Partial 15, Critical 1 h, Heroic 1 h 10; nothing on a Failure", ["success", "partial", "critical", "heroic", "failure"].map(auto.savantSuggestionSeconds), [660, 900, 3600, 4200, null]);
  equal("C …said in words", [660, 3600, 4200].map(auto.describeSeconds), ["11 minutes", "1 hour", "1 hour 10 minutes"]);
  equal("C a spellcaster has a caster level", [auto.isSpellcaster({ system: { magic: { casterLevelValue: 1 } } }), auto.isSpellcaster({ system: { magic: { casterLevelValue: 0 } } })], [true, false]);
  equal("C Ley Channeler's PP: Success 1d4, Critical and Heroic 2d4, nothing else", ["success", "critical", "heroic", "partial", "failure"].map(auto.leyChannelerDice), ["1d4", "2d4", "2d4", null, null]);
  equal("C Q83: a Failure, a Fumble and a Blunder are rerolled; a Partial and a Success are not", ["failure", "fumble", "blunder", "partial", "success"].map(auto.leyChannelerRerolls), [true, true, true, false, false]);
  equal("C Essence Reservoir: up to the ranks, less what is held; the rest keeps its end", [auto.reservoirSplit({ gained: 3, held: 0, ranks: 4 }), auto.reservoirSplit({ gained: 3, held: 2, ranks: 4 }), auto.reservoirSplit({ gained: 3, held: 4, ranks: 4 })], [{ stored: 3, excess: 0 }, { stored: 2, excess: 1 }, { stored: 0, excess: 3 }]);
  equal("C Circle Adept halves Block 2b's time: level 3, 15 minutes; meticulous, 30", [auto.circleAdeptMinutes(3), auto.circleAdeptMinutes(3, "meticulous"), b2b.circleMinutes(3)], [15, 30, 30]);
  equal("C Dispel Power's unprinted rungs fall back (m42): Heroic → Critical, Partial → Failure, Blunder → Fumble", ["heroic", "partial", "blunder", "success"].map(auto.dispelPowerRung), ["critical", "failure", "fumble", "success"]);
  // Dispel Power and Mirrored Rebuke through the core's own Dispel arithmetic (C9).
  const dm = await import(sys("module", "combat", "dispel-modifiers.mjs"));
  capi.resetModuleRegistry();
  capi.registerDispelModifier("dispelPower", { offer: auto.dispelPowerOffer, onResult: auto.dispelPowerResult }, "test");
  capi.registerDispelModifier("mirroredRebuke", { offer: auto.mirroredRebukeOffer, onResult: auto.mirroredRebukeResult }, "test");
  const caster = makeActor("Sage", { items: owning("Dispel Power", "Mirrored Rebuke"), cl: 7 });
  const offers = await quiet(() => dm.offeredDispelModifiers({ actor: caster, counterSpell: false }));
  equal("C Dispel Power offers a tick: the CL as the value, Very Hard, its ladder, its Focus use", offers.map((o) => [o.key, o.optional, o.ppReplace, o.difficulty, o.focus, o.focusItemId === caster.items[0].id, Boolean(o.outcomes?.success)]), [["dispelpower", true, 7, "veryHard", true, true, true]]);
  const counter = await quiet(() => dm.offeredDispelModifiers({ actor: caster, counterSpell: true }));
  equal("C Mirrored Rebuke is offered on a counter only", [offers.some((o) => o.key === "mirroredrebuke"), counter.map((o) => o.key)], [false, ["dispelpower", "mirroredrebuke"]]);
  const mirrorOn = async (ctx) => (await quiet(() => dm.offeredDispelModifiers({ actor: caster, ...ctx }))).some((o) => o.key === "mirroredrebuke");
  equal("C …on Counter Spell's counters only: the core feat's free Dispel and this module's step; not Disrupting Magic's, not Resonant Ascendance's (review)", [
    await mirrorOn({ counterSpell: true, presetDispel: null }),
    await mirrorOn({ counterSpell: true, presetDispel: { effectValue: 4, casterUuid: "Actor.x", counterSpell: true, eaCounterSpell: true } }),
    await mirrorOn({ counterSpell: true, presetDispel: { effectValue: 4, casterUuid: "Actor.x", spellUuid: "s", counterSpell: true } }),
    await mirrorOn({ counterSpell: true, presetDispel: { effectValue: 4, eaResonantAscendance: "i" } })
  ], [true, true, false, false]);
  const setup = { pp: 4, ...dm.combinedDispelModifiers(dm.appliedDispelOffers(offers, ["dispelpower"])) };
  equal("C …ticked: no PP spent whatever the degree, the counteract value 7, Very Hard", [dm.dispelPPPaid("success", setup).pp, dm.dispelPPPaid("critical", setup).pp, dm.dispelCounteractValue(setup), setup.difficulty], [0, 0, 7, "veryHard"]);
  equal("C …and Dispel's results are replaced by the feat's", dm.dispelActionWithLadder({ key: "dispel", outcomes: { success: "x" } }, setup).outcomes.fumble, auto.DISPEL_POWER_OUTCOMES.fumble);
  const unticked = { pp: 4, ...dm.combinedDispelModifiers(dm.appliedDispelOffers(offers, [])) };
  equal("C …unticked, the Dispel is page 91's", [dm.dispelPPPaid("success", unticked).pp, dm.dispelCounteractValue(unticked)], [4, 4]);
  equal("C a caster without the feats is offered nothing", (await dm.offeredDispelModifiers({ actor: makeActor("Plain"), counterSpell: true })).length, 0);
  capi.resetModuleRegistry();
  // Runic Stabiliser and Masked Caster through the core's cast options (C14) and remap.
  const co = await import(sys("module", "magic", "cast-options.mjs"));
  const hooks = await import(sys("module", "magic", "cast-hooks.mjs"));
  capi.registerCastOption("spellTrickery", b2b.spellTrickeryOption, "test");
  capi.registerCastOption(auto.RUNIC_KEY, auto.runicStabiliserOption, "test");
  capi.registerCastDegreeRemap(auto.RUNIC_KEY, auto.runicStabiliserRemap, "test");
  capi.registerCastOption("spellTrickery", auto.maskedSpellTrickery, "test");
  const runer = makeActor("Runer", { items: owning("Runic Stabiliser", "Masked Caster") });
  runer.system.skills.deception = { dc: 18 };
  const offered = await co.offeredCastOptions({ actor: runer, highMagic: true });
  equal("C a High Magic cast offers the rune and Spell Trickery, in that one place each", offered.map((o) => o.key).sort(), ["runicstabiliser", "spelltrickery"]);
  equal("C …not a cast that is not High Magic", (await co.offeredCastOptions({ actor: runer, highMagic: false })).map((o) => o.key), ["spelltrickery"]);
  const taken = await co.appliedCastOptions({ actor: runer, highMagic: true }, ["runicstabiliser", "spelltrickery"]);
  equal("C taken: 1 AP for the rune (C14); Spell Trickery's casting DC +1 for a Masked Caster", [taken.ap, taken.castingDC.map((p) => p.value)], [1, [1]]);
  equal("C …+2 for anyone else (Block 2b's option, unchanged)", (await co.appliedCastOptions({ actor: makeActor("Other"), highMagic: true }, ["spelltrickery"])).castingDC.map((p) => p.value), [2]);
  ok("C …and the Masked Caster's label says +1", offered.find((o) => o.key === "spelltrickery").label.includes("+1"));
  equal("C the remap: a Partial is a Success with the rune on a High Magic cast; nothing otherwise", [
    (await hooks.remapCastDegree({ actor: runer, degree: "partial", highMagic: true, castOptions: ["runicstabiliser"] })).degree,
    (await hooks.remapCastDegree({ actor: runer, degree: "partial", highMagic: true, castOptions: [] })).degree,
    (await hooks.remapCastDegree({ actor: runer, degree: "partial", highMagic: false, castOptions: ["runicstabiliser"] })).degree,
    (await hooks.remapCastDegree({ actor: runer, degree: "failure", highMagic: true, castOptions: ["runicstabiliser"] })).degree
  ], ["success", "partial", "partial", "failure"]);
  capi.resetModuleRegistry();
  // The ritual seats, with Block 2b's rules, through the core's ritual rules (D13).
  const rr = await import(sys("module", "magic", "ritual-rules.mjs"));
  capi.registerRitualRules(b2b.RULES_KEY, { prepare: b2b.prepareRitual }, "test");
  capi.registerRitualRules(auto.RITUAL_RULES_KEY_B5D, { prepare: auto.prepareRitualB5D }, "test");
  const prep = async (...names) => quiet(() => rr.prepareRitual({ actor: makeActor("Primary", { items: owning(...names) }), form: {}, variant: "" }));
  equal("C Q82: Rune-Binder’s Precision 1 seat; with Archsage Command 2 (the primary counts as three); Archsage alone 1", [(await prep("Rune-Binder’s Precision")).seats, (await prep("Rune-Binder’s Precision", "Archsage Command")).seats, (await prep("Archsage Command")).seats, (await prep()).seats], [1, 2, 1, 0]);
  equal("C …Ritual Expert and Rune-Binder’s Precision do not stack (M21)", (await prep("Ritual Expert", "Rune-Binder’s Precision")).seats, 1);
  equal("C Lorekeeper’s Insight: +2 class on the primary's ritual check", (await prep("Lorekeeper’s Insight")).modifiers, [{ label: "Lorekeeper’s Insight", value: 2, type: "class" }]);
  capi.resetModuleRegistry();
  // The time ladders, merged into Block 1's actions as the lead will.
  const gso = await quiet(() => import(sys("module", "general-skill-options.mjs")));
  const withFeatLadders = (key) => { const a = b1actions.SKILL_ACTIONS.find((x) => x.key === key); return { ...a, timeLadderByFeat: { ...(a.timeLadderByFeat ?? {}), ...auto.TIME_LADDER_FEATS_B5D[key] } }; };
  equal("C Magus Appraiser: Appraise Magic's rungs +2/+0/−2/−5; without it, Block 1's", [gso.featTimeLadder(withFeatLadders("appraiseMagic"), ["magus appraiser"])?.options.map((o) => o.modifier), gso.featTimeLadder(withFeatLadders("appraiseMagic"), [])], [[2, 0, -2, -5], null]);
  equal("C Rapid Binder: Quickbind outside daily preparation at +0 (Block 1's is −5)", [gso.featTimeLadder(withFeatLadders("quickbind"), ["rapid binder"])?.options.map((o) => [o.key, o.modifier]), gso.declaredTimeLadder(b1actions.SKILL_ACTIONS.find((x) => x.key === "quickbind"))?.options.map((o) => o.modifier)], [[["dailyPrep", 0], ["outside", 0]], [0, -5]]);
  // The degree upgrade and the substitutions, through the core.
  capi.registerDegreeUpgrades(auto.FEATS.channelSiphoner, auto.DEGREE_UPGRADES_B5D[auto.FEATS.channelSiphoner], "test");
  equal("C Channel Siphoner: Partial → Success on Tap Magical Energy", capi.registeredDegreeUpgrades("Channel Siphoner"), [{ actionKey: "tapMagicalEnergy", from: "partial", to: "success" }]);
  const feats = await quiet(() => import(sys("module", "feats.mjs")));
  for (const [n, e] of Object.entries(auto.SKILL_SUBSTITUTIONS_B5D)) capi.registerSkillSubstitution(n, e, "test");
  const reg = [{ key: "gatherInformation" }, { key: "makeAnImpression" }, { key: "request" }, { key: "dispel" }, { key: "feint" }];
  equal("C Spirit Resources: the three from Occultism", feats.substituteSkillActions("occultism", ["Spirit Resources"], reg).map((a) => a.key), ["gatherInformation", "makeAnImpression", "request"]);
  equal("C Threadcutter (Nature): Dispel from Nature; not from Arcana", [feats.substituteSkillActions("nature", ["Threadcutter (Nature)"], reg).map((a) => a.key), feats.substituteSkillActions("arcana", ["Threadcutter (Nature)"], reg).length], [["dispel"], 0]);
  equal("C the four Threadcutter abilities' names", auto.THREADCUTTER_SKILLS.map(([k]) => auto.threadcutterName(k)), ["Threadcutter (Arcana)", "Threadcutter (Nature)", "Threadcutter (Occultism)", "Threadcutter (Religion)"]);
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* D — registration                                                     */
/* ----------------------------------------------------------------- */
const got = { auto: [], upgrades: [], subs: [], ritual: [], dispel: [], options: [], remaps: [], checks: [], casts: [], steps: [] };
auto.registerBlock5D({
  registerFeatAutomation: (n, e) => got.auto.push([n, e]), registerDegreeUpgrades: (n, e) => got.upgrades.push([n, e]), registerSkillSubstitution: (n, e) => got.subs.push([n, e]),
  registerRitualRules: (k, s) => got.ritual.push([k, s]), registerDispelModifier: (k, s) => got.dispel.push([k, s]), registerCastOption: (k, s) => got.options.push([k, s]),
  registerCastDegreeRemap: (k, f) => got.remaps.push([k, f]), registerCheckReaction: (k, s) => got.checks.push([k, s]), registerCastReaction: (k, f) => got.casts.push([k, f]), registerReactionStep: (k, f) => got.steps.push([k, f])
}, "trg-eldritch-arts");
equal("D the Uses: Threadcutter, Wanderer’s Mastery, Wanderer’s Sense", got.auto.map(([n]) => n), ["Threadcutter", "Wanderer’s Mastery", "Wanderer’s Sense"]);
ok("D …each Use names an item this group ships, flagged with its automation", got.auto.every(([n]) => byName[n]?.flags["trg-prime"].eaAutomation));
equal("D Channel Siphoner's upgrade", got.upgrades, [["Channel Siphoner", [{ actionKey: "tapMagicalEnergy", from: "partial", to: "success" }]]]);
equal("D the substitutions: Spirit Resources and the four Threadcutter abilities", got.subs.map(([n]) => n), ["Spirit Resources", "Threadcutter (Arcana)", "Threadcutter (Nature)", "Threadcutter (Occultism)", "Threadcutter (Religion)"]);
equal("D the ritual rules, prepare only", got.ritual.map(([k, s]) => [k, s.prepare === auto.prepareRitualB5D, Object.keys(s)]), [["trg-eldritch-arts-block5d", true, ["prepare"]]]);
equal("D the Dispel modifiers, each with its rider", got.dispel.map(([k, s]) => [k, typeof s.offer, typeof s.onResult]), [["dispelPower", "function", "function"], ["mirroredRebuke", "function", "function"]]);
equal("D the cast options: Runic Stabiliser, and Spell Trickery replaced by Masked Caster's wrap", got.options.map(([k, s]) => [k, s === auto.runicStabiliserOption || s === auto.maskedSpellTrickery]), [["runicStabiliser", true], ["spellTrickery", true]]);
equal("D the remap, the three check reactions, the cast reaction and its step", [got.remaps.map(([k]) => k), got.checks.map(([k]) => k), got.casts.map(([k]) => k), got.steps.map(([k, f]) => [k, f === auto.mirroredRebukeStep])], [["runicStabiliser"], ["leyChanneler", "esotericInsightB5", "archsageCommand"], ["mirroredRebuke"], [["eldritchArts.mirroredRebuke", true]]]);
ok("D every check reaction answers after the result", got.checks.every(([, s]) => typeof s.after === "function" && !s.before));
ok("D nothing is registered without an API", (() => { const was = globalThis.game.trgPrime; globalThis.game.trgPrime = {}; try { auto.registerBlock5D(undefined); return true; } catch { return false; } finally { globalThis.game.trgPrime = was; } })());

/* ----------------------------------------------------------------- */
/* E — the Foundry side, with fakes                                     */
/* ----------------------------------------------------------------- */
const reset = () => { cards.length = 0; created.length = 0; released.length = 0; resonance.length = 0; resolved.length = 0; whispers.length = 0; globalThis.game.user.targets.clear(); };
const lastCard = () => cards.filter((c) => !c.warn).at(-1);
{
  // Ley Channeler's PP on Tap Ley Line (the resolved degree, printed).
  reset();
  const tapper = makeActor("Tapper", { items: owning("Ley Channeler"), pp: 18, max: 20 });
  rollTotal = 3;
  await auto.onActionResolvedB5D({ actor: tapper, action: { key: "tapLeyLine" }, degree: "success", resolvedDegree: "success" });
  equal("E Ley Channeler: a Success regains 1d4 (3), capped at the maximum (20)", tapper.system.resources.pp.value, 20);
  tapper.system.resources.pp.value = 5;
  await auto.onActionResolvedB5D({ actor: tapper, action: { key: "tapLeyLine" }, degree: "critical", resolvedDegree: "critical" });
  equal("E …a Critical 2d4 (6)", tapper.system.resources.pp.value, 11);
  await auto.onActionResolvedB5D({ actor: tapper, action: { key: "tapLeyLine" }, degree: "heroic", resolvedDegree: "heroic" });
  equal("E …a Heroic reads as the Critical", tapper.system.resources.pp.value, 17);
  await auto.onActionResolvedB5D({ actor: tapper, action: { key: "tapLeyLine" }, degree: "partial", resolvedDegree: "partial" });
  await auto.onActionResolvedB5D({ actor: makeActor("NoFeat", { pp: 5 }), action: { key: "tapLeyLine" }, degree: "success" });
  equal("E …nothing on a Partial, nothing without the feat", tapper.system.resources.pp.value, 17);
  // Ley Channeler's reroll.
  const tap = (degree, actionKey = "tapLeyLine", actor = tapper) => auto.leyChannelerReaction.after({ actor, check: { actionKey }, degree });
  confirms.push(true);
  const r1 = await tap("failure");
  equal("E Ley Channeler: a failed Tap is rerolled once a day, the use spent", [Boolean(r1?.reroll), tapper.items[0].system.usesValue], [true, 0]);
  equal("E …not twice (the use is gone), not on a Partial, not on another action", [await tap("fumble"), await (async () => { tapper.items[0].system.usesValue = 1; return tap("partial"); })(), await tap("failure", "tapMagicalEnergy")], [null, null, null]);
  confirms.push(false);
  equal("E …a declined reroll keeps the use", [await tap("fumble"), tapper.items[0].system.usesValue], [null, 1]);
  // Spell Recognition's riders.
  reset();
  const scholar = makeActor("Scholar", { items: owning("Esoteric Insight Expert", "Esoteric Insight Master") });
  const witch = makeActor("Witch", { disposition: -1 });
  globalThis.game.user.targets.add(witch.token);
  const said = await auto.esotericReaction.after({ actor: scholar, check: { actionKey: "spellRecognition" }, degree: "critical" });
  const effect = scholar.effects.find((e) => e.flags["trg-eldritch-arts"].source === "esotericMaster");
  equal("E a Critical Spell Recognition: Expert's tradition line, and Master's +2 against the targeted caster", [/tradition/.test(said?.line ?? ""), effect?.flags["trg-prime"].conditionals[0].when.sourceUuids, effect?.flags["trg-prime"].conditionals[0].auto], [true, ["Actor.Witch"], true]);
  const failed = await auto.esotericReaction.after({ actor: scholar, check: { actionKey: "spellRecognition" }, degree: "failure" });
  equal("E …a failure: the tradition line only, no new effect", [/tradition/.test(failed?.line ?? ""), scholar.effects.filter((e) => e.flags["trg-eldritch-arts"].source === "esotericMaster").length], [true, 1]);
  equal("E …nothing on another roll", await auto.esotericReaction.after({ actor: scholar, check: { actionKey: "identifyPower" }, degree: "critical" }), null);
  const pupil = makeActor("Pupil", { items: owning("Esoteric Insight Master") });
  equal("E …a plain Success gives Master no +2", [await auto.esotericReaction.after({ actor: pupil, check: { actionKey: "spellRecognition" }, degree: "success" }), pupil.effects.length], [null, 0]);
  // Archsage Command.
  reset();
  const sage = makeActor("Archsage", { items: owning("Archsage Command") });
  const a1 = await auto.archsageReaction.after({ actor: sage, type: "skill", subject: "arcana", degree: "critical" });
  ok("E Archsage Command: a Critical Arcana check readies an hour's advantage tick", Boolean(a1?.line) && sage.effects.some((e) => e.flags["trg-eldritch-arts"].source === "archsageCommand" && e.flags["trg-prime"].spellEffectEnd === 1000 + 3600));
  equal("E …not a Success, not Occultism", [await auto.archsageReaction.after({ actor: sage, type: "skill", subject: "arcana", degree: "success" }), await auto.archsageReaction.after({ actor: sage, type: "skill", subject: "occultism", degree: "critical" })], [null, null]);
  await auto.onSpellSettledB5D({ actor: sage, ritual: true, degree: "critical" });
  equal("E …a Critical ritual too, refreshed rather than doubled", sage.effects.filter((e) => e.flags["trg-eldritch-arts"].source === "archsageCommand").length, 1);
  await auto.onSpellSettledB5D({ actor: makeActor("Caster", { items: owning("Archsage Command") }), ritual: false, degree: "critical" });
  equal("E …not an ordinary cast", cards.filter((c) => c.actor === "Caster").length, 0);
  // Hypnotic Savant.
  reset();
  const hypnotist = makeActor("Hypnotist", { items: owning("Hypnotic Savant") });
  await auto.onActionResolvedB5D({ actor: hypnotist, action: { key: "hypnotismSuggestion" }, degree: "critical" });
  ok("E Hypnotic Savant: a Critical suggestion lasts 1 hour", /1 hour/.test(lastCard()?.lines?.[0] ?? ""));
  const subject = makeActor("Subject", { pp: 3, max: 10, cl: 2 });
  await auto.onActionResolvedB5D({ actor: hypnotist, action: { key: "hypnotismMemory" }, degree: "success", targetActor: subject });
  const mundane = makeActor("Mundane", { pp: 3, max: 10, cl: 0 });
  await auto.onActionResolvedB5D({ actor: hypnotist, action: { key: "hypnotismMemory" }, degree: "success", targetActor: mundane });
  await auto.onActionResolvedB5D({ actor: hypnotist, action: { key: "hypnotismMemory" }, degree: "partial", targetActor: subject });
  equal("E …Memory Recall: a caster subject regains 1 PP on a Success; not a non-caster, not on a Partial", [subject.system.resources.pp.value, mundane.system.resources.pp.value], [4, 3]);
  // Circle Adept (Block 2b's plan, read before it is cleared).
  reset();
  const adept = makeActor("Adept", { items: owning("Circle Adept") });
  adept.flags["trg-eldritch-arts"] = { block2bPlan: { action: "inscribeSummoningCircle", level: 4, care: "meticulous" } };
  await auto.onActionResolvedB5D({ actor: adept, action: { key: "inscribeSummoningCircle" }, degree: "success" });
  ok("E Circle Adept: level 4 with meticulous care, 40 minutes instead of 80", /40 minutes<\/strong> \(instead of 80\)/.test(lastCard()?.lines?.[0] ?? ""));
  // Magus Appraiser, Rapid Binder, Masked Caster.
  reset();
  await auto.onActionResolvedB5D({ actor: makeActor("Appraiser", { items: owning("Magus Appraiser") }), action: { key: "appraiseMagic" }, degree: "critical" });
  equal("E Magus Appraiser: a Critical is whispered to the GM only", [whispers.length, whispers[0]?.whisper], [1, ["gm"]]);
  await auto.onActionResolvedB5D({ actor: makeActor("Appraiser2", { items: owning("Magus Appraiser") }), action: { key: "appraiseMagic" }, degree: "success" });
  equal("E …not on a Success", whispers.length, 1);
  await auto.onActionResolvedB5D({ actor: makeActor("Binder", { items: owning("Rapid Binder") }), action: { key: "quickbind" }, degree: "success" });
  ok("E Rapid Binder: on a Success, activate it this round", /activate it this round/.test(lastCard()?.lines?.[0] ?? ""));
  await auto.onActionResolvedB5D({ actor: makeActor("Binder2", { items: owning("Rapid Binder") }), action: { key: "quickbind" }, degree: "failure" });
  await auto.onActionResolvedB5D({ actor: makeActor("Observer2"), action: { key: "seeThroughSpellTrickery" }, degree: "fumble", targetActor: makeActor("Masked2", { items: owning("Masked Caster") }) });
  await auto.onActionResolvedB5D({ actor: makeActor("Plain Hypnotist"), action: { key: "hypnotismSuggestion" }, degree: "critical" });
  equal("E …nothing on a Failure; nothing on an observer's Fumble; no duration card without Hypnotic Savant", cards.filter((c) => ["Binder2", "Masked2", "Plain Hypnotist"].includes(c.actor)).length, 0);
  const masked = makeActor("Masked", { items: owning("Masked Caster") });
  await auto.onActionResolvedB5D({ actor: makeActor("Observer"), action: { key: "seeThroughSpellTrickery" }, degree: "blunder", targetActor: masked });
  equal("E Masked Caster: an observer's Blunder lets the caster plant two false details", [lastCard()?.actor, /two<\/strong> false details/.test(lastCard()?.lines?.[0] ?? "")], ["Masked", true]);
  // Essence Reservoir.
  reset();
  const siphoner = makeActor("Siphoner", { items: owning("Essence Reservoir"), ranks: { powerManipulation: 4 } });
  const [first] = await siphoner.createEmbeddedDocuments("ActiveEffect", [{ name: "Siphoned essence (3 PP)", flags: { "trg-prime": { spellEffect: true, spellEffectEnd: 1012 }, "trg-eldritch-arts": { source: "siphonedEssence", siphon: 3, before: 5, endsAfterTurn: { combatId: "c", round: 2 } } } }]);
  await auto.onEffectCreatedB5D(first, {}, "u1");
  equal("E Essence Reservoir: 3 PP held for 1 minute, the turn's end lifted", [first.flags["trg-prime"].spellEffectEnd, first.flags["trg-eldritch-arts"].endsAfterTurn, first.flags["trg-eldritch-arts"].eaReservoir, first.flags["trg-eldritch-arts"].siphon], [1060, null, true, 3]);
  const [second] = await siphoner.createEmbeddedDocuments("ActiveEffect", [{ name: "Siphoned essence (3 PP)", flags: { "trg-prime": { spellEffect: true, spellEffectEnd: 1012 }, "trg-eldritch-arts": { source: "siphonedEssence", siphon: 3, before: 8, endsAfterTurn: { combatId: "c", round: 2 } } } }]);
  await auto.onEffectCreatedB5D(second, {}, "u1");
  const excess = siphoner.effects.find((e) => e.flags["trg-eldritch-arts"].eaReservoirExcess);
  equal("E …a second siphon of 3: 1 more held (4 ranks), 2 keep the turn's end, counted from above the held PP", [second.flags["trg-eldritch-arts"].siphon, second.flags["trg-prime"].spellEffectEnd, excess?.flags["trg-eldritch-arts"].siphon, excess?.flags["trg-eldritch-arts"].before, excess?.flags["trg-eldritch-arts"].endsAfterTurn?.round, excess?.flags["trg-prime"].spellEffectEnd], [1, 1060, 2, 9, 2, 1012]);
  const n = siphoner.effects.length, cardsBefore = cards.length;
  await auto.onEffectCreatedB5D(excess, {}, "u1");
  await auto.onEffectCreatedB5D(first, {}, "u2");
  equal("E …the excess is not taken in again, and another user's creation is not this client's", [siphoner.effects.length, cards.length], [n, cardsBefore]);
  const outsider = makeActor("Outsider", { items: owning("Essence Reservoir"), ranks: { powerManipulation: 4 } });
  const [theirs] = await outsider.createEmbeddedDocuments("ActiveEffect", [{ name: "x", flags: { "trg-prime": { spellEffectEnd: 1012 }, "trg-eldritch-arts": { source: "siphonedEssence", siphon: 2, before: 5 } } }]);
  await auto.onEffectCreatedB5D(theirs, {}, "u2");
  equal("E …another user's siphon is left to that user", theirs.flags["trg-prime"].spellEffectEnd, 1012);
  const plainSiphon = makeActor("PlainSiphon", { ranks: { powerManipulation: 4 } });
  const [plainE] = await plainSiphon.createEmbeddedDocuments("ActiveEffect", [{ name: "x", flags: { "trg-prime": { spellEffectEnd: 1012 }, "trg-eldritch-arts": { source: "siphonedEssence", siphon: 3, before: 5 } } }]);
  await auto.onEffectCreatedB5D(plainE, {}, "u1");
  equal("E …without the feat, the essence keeps its end", plainE.flags["trg-prime"].spellEffectEnd, 1012);
  // Spell Thief.
  reset();
  const thief = makeActor("Thief", { items: [...owning("Spell Thief"), { name: "Old Borrow", type: "spell", system: { prepared: true }, flags: { "trg-prime": { memorisationFree: true }, "trg-eldritch-arts": { borrowed: { from: "x" } } } }] });
  await auto.onActionResolvedB5D({ actor: thief, action: { key: "borrowSpell" }, degree: "critical", resolvedDegree: "success" });
  const [copy] = await thief.createEmbeddedDocuments("Item", [{ name: "Fireball", type: "spell", system: { prepared: false }, flags: { "trg-eldritch-arts": { borrowed: { from: "Actor.lender" } } } }]);
  await auto.onItemCreatedB5D(copy, {}, "u1");
  const old = thief.items.find((i) => i.name === "Old Borrow");
  equal("E Spell Thief: a Critical borrow is a free, prepared copy; the last free one is cleared and unprepared", [copy.flags["trg-prime"]?.memorisationFree, copy.system.prepared, old.flags["trg-prime"].memorisationFree, old.system.prepared], [true, true, false, false]);
  const mem = await import(sys("module", "magic", "memorisation.mjs"));
  equal("E …which the core leaves out of the count (C13)", [mem.countsTowardMemorisation(copy), mem.countsTowardMemorisation(old)], [false, true]);
  await auto.onActionResolvedB5D({ actor: thief, action: { key: "borrowSpell" }, degree: "success" });
  const [plain] = await thief.createEmbeddedDocuments("Item", [{ name: "Haste", type: "spell", system: { prepared: false }, flags: { "trg-eldritch-arts": { borrowed: { from: "Actor.lender" } } } }]);
  await auto.onItemCreatedB5D(plain, {}, "u1");
  equal("E …a Success borrow is not free", [plain.flags["trg-prime"]?.memorisationFree, plain.system.prepared], [undefined, false]);
  // The Uses.
  reset();
  const cutter = makeActor("Cutter", { items: [{ ...feat("Threadcutter"), type: "feat", _id: "tc1" }, { ...feat("Threadcutter"), type: "feat", _id: "tc2" }] });
  answers.push("arcana");
  await auto.USES_B5D.threadcutter.use(cutter, cutter.items[0]);
  answers.push("arcana");
  await auto.USES_B5D.threadcutter.use(cutter, cutter.items[1]);
  equal("E Threadcutter: the first copy takes Arcana and adds its ability; a second copy cannot take Arcana again", [cutter.items.filter((i) => i.type === "ability").map((i) => i.name), cutter.items[0].flags["trg-eldritch-arts"].threadcutter, cutter.items[1].flags["trg-eldritch-arts"]?.threadcutter], [["Threadcutter (Arcana)"], "arcana", undefined]);
  answers.push("religion");
  await auto.USES_B5D.threadcutter.use(cutter, cutter.items[0]);
  equal("E …choosing again moves the copy's ability", cutter.items.filter((i) => i.type === "ability").map((i) => i.name), ["Threadcutter (Religion)"]);
  reset();
  const wanderer = makeActor("Wanderer", { items: owning("Wanderer’s Sense", "Wanderer’s Mastery") });
  await auto.USES_B5D.wanderersSense.use(wanderer, wanderer.items[0]);
  await auto.USES_B5D.wanderersSense.use(wanderer, wanderer.items[0]);
  equal("E Wanderer’s Sense: once a day the lost check succeeds; then refused", [wanderer.items[0].system.usesValue, cards.filter((c) => c.title === "Wanderer’s Sense").length, cards.filter((c) => c.warn).length], [0, 1, 1]);
  const ally = makeActor("Ally");
  globalThis.canvas.tokens.placeables = [wanderer.token, ally.token];
  answers.push("journey");
  await auto.USES_B5D.wanderersMastery.use(wanderer, wanderer.items[1]);
  equal("E Wanderer’s Mastery: the journey's 24 hours on you and a companion, then a week's wait", [created.filter((c) => c.flags["trg-eldritch-arts"].source === "wanderersJourney").map((c) => [c.on, c.flags["trg-prime"].spellEffectEnd]), wanderer.items[1].flags["trg-eldritch-arts"].journeyUntil], [[["Wanderer", 1000 + 86400], ["Ally", 1000 + 86400]], 1000 + 7 * 86400]);
  answers.push("journey");
  await auto.USES_B5D.wanderersMastery.use(wanderer, wanderer.items[1]);
  equal("E …not again within the week", created.filter((c) => c.flags["trg-eldritch-arts"].source === "wanderersJourney").length, 2);
  globalThis.canvas.tokens.placeables = [];
  // Dispel Power's rider.
  reset();
  const dpActor = makeActor("Dispeller", { items: owning("Dispel Power") });
  const fum = await auto.dispelPowerResult({ actor: dpActor, degree: "blunder" });
  const suc = await auto.dispelPowerResult({ actor: dpActor, degree: "success" });
  equal("E Dispel Power: a Blunder is the Fumble — a Resonance event, and no further attempt; a Success suppresses", [resonance.length, /cannot attempt to dispel this effect again/.test(fum.lines[0]), /suppress the effect for 1 minute/.test(suc.lines[0])], [1, true, true]);
  // Mirrored Rebuke: the counter, then the reflection.
  reset();
  const rebuker = makeActor("Rebuker", { items: [...owning("Mirrored Rebuke"), { name: "Counter Spell", type: "feat", system: {}, flags: {} }], ranks: { powerManipulation: 6 }, disposition: 1 });
  const foe = makeActor("Foe", { disposition: -1 });
  const friend = makeActor("Friend", { items: [...owning("Mirrored Rebuke"), { name: "Counter Spell", type: "feat", system: {}, flags: {} }], ranks: { powerManipulation: 6 }, disposition: -1 });
  globalThis.canvas.tokens.placeables = [friend.token, foe.token, rebuker.token];
  STEP = auto.mirroredRebukeStep;
  resolveDegree = { key: "success", label: "Success" };
  const spell = { name: "Fireball", uuid: "Actor.Foe.Item.fb", system: { ppCost: 6 } };
  const stop = await auto.mirroredRebukeReaction({ actor: foe, token: foe.token, spell, pp: 8 });
  equal("E Mirrored Rebuke: the reactor (not the caster's ally) is asked, and Counter Spell's free Dispel is opened on the spell", [stop?.stop, resolved.map((r) => r.actor), resolved[0]?.action.counterSpell, resolved[0]?.action.apCost, resolved[0]?.options.presetDispel], [true, ["Rebuker"], true, "0", { effectValue: 8, dc: 21, what: "Fireball", casterUuid: "Actor.Foe", spellUuid: "Actor.Foe.Item.fb", counterSpell: true, eaCounterSpell: true }]);
  // One question a reactor (review): a reactor Block 3b's Disrupting Magic asks is not asked again.
  resolved.length = 0;
  const disruptor = makeActor("Disruptor", { items: [...owning("Mirrored Rebuke"), { name: "Counter Spell", type: "feat", system: {}, flags: {} }, { name: "Disrupting Magic", type: "spell", system: { traits: "Utility, Warding" }, flags: {} }], ranks: { powerManipulation: 6 }, disposition: 1 });
  globalThis.canvas.grid = { measurePath: ([a, b]) => ({ distance: Math.hypot(a.x - b.x, a.y - b.y) }) };
  disruptor.token.center = { x: 0, y: 0 }; foe.token.center = { x: 100, y: 0 };
  globalThis.canvas.tokens.placeables = [disruptor.token, foe.token];
  helpers.reactionRefusal = async () => ""; helpers.castRefusal = async () => "";
  await auto.mirroredRebukeReaction({ actor: foe, token: foe.token, spell, pp: 8 });
  const nearAsked = resolved.length;
  foe.token.center = { x: 200, y: 0 };
  await auto.mirroredRebukeReaction({ actor: foe, token: foe.token, spell, pp: 8 });
  equal("E …a reactor within Disrupting Magic's 120 ft (asked by Block 3b) is not asked for Counter Spell; beyond it, asked", [nearAsked, resolved.length], [0, 1]);
  delete globalThis.canvas.grid; delete helpers.reactionRefusal; delete helpers.castRefusal;
  globalThis.canvas.tokens.placeables = [friend.token, foe.token, rebuker.token];
  resolveDegree = { key: "failure", label: "Failure" };
  resolved.length = 0;
  const kept = await auto.mirroredRebukeReaction({ actor: foe, token: foe.token, spell, pp: 8 });
  equal("E …a failed counter does not stop it", [kept?.stop, resolved.length], [false, 1]);
  resolveDegree = { key: "success", label: "Success" };
  globalThis.canvas.tokens.placeables = [rebuker.token, foe.token];
  const ref = await auto.mirroredRebukeResult({ actor: rebuker, degree: "success", countered: true, spell, targetCaster: foe, dispel: { effectValue: 8 } });
  equal("E …countered with the tick: released from the reactor at its caster, at the cast's PP, the AP paid", [released.map((r) => [r.actor, r.item, r.ref.name, r.ref.pp, r.opts.apPaid, r.targets]), /turned back/.test(ref.lines[0])], [[["Rebuker", "Mirrored Rebuke", "Fireball", 8, true, ["t-Foe"]]], true]);
  equal("E …the user's targets are put back", globalThis.game.user.targets.size, 0);
  globalThis.canvas.tokens.placeables = [];
  const noSpell = await auto.mirroredRebukeResult({ actor: rebuker, degree: "success", countered: true, spell: null, targetCaster: null, effect: "" });
  const fumbled = await auto.mirroredRebukeResult({ actor: rebuker, degree: "fumble", countered: false });
  const failedR = await auto.mirroredRebukeResult({ actor: rebuker, degree: "failure", countered: false });
  equal("E …no spell in hand: the GM's; a Fumble's rebound: the GM's; a Failure: nothing", [released.length, /GM resolves the reflection/.test(noSpell.lines[0]), /partly rebounds/.test(fumbled.lines[0]), failedR], [1, true, true, null]);
}

/* ----------------------------------------------------------------- */
/* F — Block 1's Esoteric Insight (C11)                                 */
/* ----------------------------------------------------------------- */
{
  const ei = B1.BACKGROUND_FEATS.find((f) => f.name === "Esoteric Insight");
  const tick = cond.normaliseConditional(F(ei).conditionals[1], { name: "Esoteric Insight" }, 1);
  ok("F Esoteric Insight's advantage tick is scoped to Spell Recognition's roll (actionKey spellRecognition), no longer Identify Power", cond.matchesCheck(tick, { checkType: "skill", actionKey: "spellRecognition" }) && !cond.matchesCheck(tick, { checkType: "skill", actionKey: "identifyPower" }) && tick.kind === "advantage" && !tick.auto);
  ok("F …and its card says so", /tick on Spell Recognition's roll/.test(ei.system.description) && /C11/.test(ei.system.description));
  const coreSrc = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "feats-workflow.mjs"), "utf8");
  ok("F the core's Spell Recognition roll names itself (C11)", /actionKey: "spellRecognition"/.test(coreSrc) && /subject: skillKey/.test(coreSrc));
  equal("F …so its reroll reaches a failed Spell Recognition made with Arcana", fumble.fumbleRerollRows([ei], "skill", "arcana", "failure").length, 1);
}

console.log(`verify-block5d: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
