#!/usr/bin/env node
/**
 * verify-block7 — Eldritch Arts 0.10.0 (Block 7, on TRG Prime 3.685.0): the
 * first half of Chapter 8's Grimoire, 42 spells, and the Elemental Strike
 * ability (docs/ELDRITCH_ARTS_BLOCK7_AUDIT.md §5.2; Graham's answers of
 * 7 November 2026: Q150 changed, Q151–Q166 as proposed, H1–H11; the 07:53
 * rulings on Dragon Wings and Spirit Arrow).
 *
 *   A  every spell against the book: name, PP, cast, traits, tradition (all →
 *      the four), uncommon, the printed text, the grade and its card, the key
 *   B  the data through the core's own readers: thorns (H1), caster-level
 *      steps (H2), the turn and entry ladders (H3), land + N (H4), the rider
 *      (H10), the free warp (H9b), held bonus, mark, conditions, slots,
 *      defences, the warp aggregator, Region claims, Distracted (Q157)
 *   C  the pure rules (module/block7-rules.mjs)
 *   D  registration, and the core's real collectors run with the module's
 *      offers: gates, cast reactions (H5), check reactions (H6), damage
 *      reactions (weak), critical reactions (H7), refusals, preludes, dispel
 *      and fumble modifiers
 *   E  the Foundry side with fakes: every hook, Use, step and offer
 *   F  the wiring (entry script, registration, packs, Block 6's Pacts)
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block7.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y) and the placeable keep the OLD
 * position; the document's `_source` and `change` carry the NEW one.
 */
function placeEnd(doc, change) {
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
}
async function moveV14(token, change, handler, ...rest) {
  placeEnd(token.document, change);
  return handler(token.document, change, ...rest);
}


const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

/* ----------------------------------------------------------------- */
/* Fakes (before any core import: its modules read these at load)     */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const reactorAnswers = [];
const asked = [];
const STEPS = {};
const calls = { saves: [], checks: [], conditions: [], casts: [], crits: [], effects: [], ended: [], spent: [], immunity: [] };
let checkDegree = "failure", checkTotal = 20, checkMargin = -5, saveDegree = "failure", inRegion = true, castResult = null, castTaken = 0, d100 = 99, castSettledDC = 0, nextClick = null;
const sent = [];
const pending = [];
// THE GM SIDE (second review): a relayed write is made only when flushed, one at
// a time, as the GM; outside it, a write on a document this client does not own
// THROWS, as Foundry refuses it ("User … lacks permission to update …").
let gmSide = 0;
const flush = async () => { while (pending.length) { const job = pending.shift(); gmSide++; try { await job(); } finally { gmSide--; } } };
const guard = (doc, what = "update") => { if (doc && doc.isOwner === false && !gmSide) throw new Error(`User Player lacks permission to ${what} ${doc.uuid ?? doc.name}`); };
const uuidMap = new Map();
// The reactor's step runs on its own client: there it owns the reactor.
async function asOwner(actor, fn) { const was = actor.isOwner; actor.isOwner = true; try { return await fn(); } finally { actor.isOwner = was; } }
const hookList = new Map();
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; return answers.length ? answers.shift() : null; },
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title, step: q.step, data: q.data }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; if (a !== "yes") return { answer: a, result: null }; return { answer: a, result: await asOwner(actor, () => STEPS[q.step](actor, a, q.data)) }; },
  reactionRefusal: async () => "",
  castRefusal: async () => "",
  // AS THE CORE'S castSpell: it fires trgPrimeSpellSettled (with the cast's Save DC) and returns no `saveDC`.
  castAsReaction: async (actor, spell, ids) => {
    calls.casts.push({ actor: actor.name, spell: spell.name, ids });
    if (castTaken) for (const fn of hookList.get("trgPrimeDamageApplied") ?? []) fn({ actor: uuidMap.get(castResult?.hurt) ?? null, amount: castTaken });
    if (castResult?.cast) await auto.onSpellSettledB7({ actor, spell, cast: true, refunded: false, saveDC: castSettledDC, warpMods: castResult.warpMods ?? {}, spellData: spell.system });
    const { saveDC, hurt, ...returned } = castResult ?? {};
    return castResult ? returned : null;
  },
  rollCriticalInjury: async (attacker, o) => { calls.crits.push({ attacker: attacker.name, target: o.targetActor?.name, severity: o.severity, type: o.damageType, attackBonus: o.attackBonus }); },
  basicSaveHit: async (o) => { calls.saves.push({ caster: o.caster?.name ?? null, target: o.target?.name, save: o.save, dc: o.dc, label: o.label, formula: o.formula, type: o.type, base: o.baseDamage ?? "" }); return { line: `${o.target.name} saved`, degree: saveDegree, taken: 5 }; },
  regionContains: async () => inRegion,
  // AS THE CORE'S: it relays the create for a creature this client does not own.
  createEffectsOn: async (target, list) => { calls.effects.push({ target: target.name, list }); gmSide++; try { return await target.createEmbeddedDocuments("ActiveEffect", list); } finally { gmSide--; } },
  // AS THE CORE'S endActiveSpell (via relayEndSpell): null for a cast that is not registered; a registered one leaves the registry and its effects go.
  endSpellOf: async (caster, castId) => {
    calls.ended.push({ caster: caster.name, castId });
    const entries = Array.from(caster.flags?.[SYS]?.activeSpells ?? []);
    if (!entries.some((e) => e.id === castId)) return null;
    caster.flags[SYS].activeSpells = entries.filter((e) => e.id !== castId);
    caster.effects = caster.effects.filter((e) => e.flags?.[SYS]?.castId !== castId);
    return { id: castId };
  },
  spendReaction: async (actor, label) => { calls.spent.push({ actor: actor.name, label }); return true; },
  rollCheck: async (cfg) => { calls.checks.push({ actor: cfg.actor?.name, type: cfg.type, subject: cfg.subject ?? "", dc: cfg.dc, sourceUuid: cfg.sourceUuid ?? "" }); return { outcome: { degree: { key: checkDegree, label: checkDegree }, total: checkTotal, margin: checkMargin } }; },
  applyConditionTagsTo: async (target, tags) => { calls.conditions.push({ target: target.name, tags }); },
  metamagicCatalogue: async () => [{ key: "empower", label: "Empower Spell — additional damage equal to base damage", source: "core" }, { key: "easpellweaverextend", label: "Weaver's Extend", source: "module" }],
  temporaryImmunityRefusal: async (target, key) => (target.flags?.[SYS]?.imm?.[key] ? "immune" : ""),
  grantTemporaryImmunity: async (target, key, seconds) => { calls.immunity.push({ target: target.name, key, seconds }); target.flags[SYS] ??= {}; (target.flags[SYS].imm ??= {})[key] = seconds; return true; },
  itemUsesMax: () => null, itemUsesRemaining: () => 0,
  // AS THE CORE'S (3.692.0): the action at a given total; recorded, its card lines returned.
  resolveBasicActionAtTotal: async (actor, target, actionKey, opts) => { (calls.atTotal ??= []).push({ actor: actor?.name, target: target?.name, actionKey, total: opts?.total, rounds: opts?.rounds ?? null }); return { ok: true, degree: "success", lines: [`${actionKey} at ${opts?.total}`] }; }
};
class FakeRoll {
  constructor(formula) { this.formula = String(formula); }
  async evaluate() { this.total = /1d100/.test(this.formula) ? d100 : 1; return this; }
}
globalThis.Roll = FakeRoll;
globalThis.Hooks = { on(name, fn) { if (!hookList.has(name)) hookList.set(name, []); hookList.get(name).push(fn); return fn; }, off(name, fn) { hookList.set(name, (hookList.get(name) ?? []).filter((f) => f !== fn)); }, callAll() {}, call() { return true; }, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { wait: async () => null, confirm: async () => true, prompt: async () => null } }, ux: {} }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, hasProperty: () => false, mergeObject: (a, b) => Object.assign(a ?? {}, b ?? {}), isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => "r1", deepClone: (x) => JSON.parse(JSON.stringify(x)), fromUuid: async (u) => uuidMap.get(u) ?? null } };
globalThis.fromUuidSync = (u) => uuidMap.get(u) ?? null;
globalThis.fromUuid = async (u) => uuidMap.get(u) ?? null;
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.CONFIG = { statusEffects: [], specialStatusEffects: {} };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };
globalThis.ChatMessage = { getSpeaker: () => ({}), create: async (d) => d };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: `i${++nextId}`, parent };
  it.flags = it.flags ?? {}; it.system = it.system ?? {};
  it.uuid = `${parent?.uuid ?? "X"}.Item.${it.id}`;
  it.getFlag = (s, k) => it.flags?.[s]?.[k];
  it.setFlag = async (s, k, v) => { (it.flags[s] ??= {})[k] = v; };
  it.unsetFlag = async (s, k) => { delete it.flags?.[s]?.[k]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.toObject = () => JSON.parse(JSON.stringify({ ...it, parent: undefined }));
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.flags = e.flags ?? {};
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.setFlag = async (s, k, v) => { guard(a); (e.flags[s] ??= {})[k] = v; };
  e.unsetFlag = async (s, k) => { guard(a); delete e.flags?.[s]?.[k]; };
  e.update = async (u) => { guard(a); for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(e, k, v); };
  e.delete = async () => { guard(a, "delete"); a.effects = a.effects.filter((x) => x !== e); };
  e.toObject = () => JSON.parse(JSON.stringify({ ...e, parent: undefined }));
  return e;
}
function makeActor(name, { level = 10, cl = null, pp = 30, ap = 3, cha = 3, dex = 2, items = [] } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name.replace(/\s/g, "")}`, isOwner: true, effects: [], flags: { [SYS]: {}, [MOD]: {} }, documentName: "Actor", conditions: new Set() };
  a.system = { identity: { level }, resources: { pp: { value: pp }, ap: { value: ap } }, attributes: { charisma: { total: cha }, intelligence: { total: 4 } }, magic: { casterLevelValue: cl ?? level, castingAbility: "intelligence" }, combat: { defence: { ability: dex, breakdown: { byType: { dodge: 1 } } }, movement: { land: { base: 25 }, fly: { base: 0 } } } };
  const list = []; list.get = function (id) { return this.find((i) => i.id === id); }; a.items = list;
  for (const d of items) a.items.push(makeItem(d, a));
  a.effects.get = undefined;
  a.getFlag = (s, k) => a.flags?.[s]?.[k];
  a.setFlag = async (s, k, v) => { guard(a); (a.flags[s] ??= {})[k] = v; };
  a.unsetFlag = async (s, k) => { guard(a); delete a.flags?.[s]?.[k]; };
  a.update = async (u) => { guard(a); for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, docs) => {
    guard(a, "create in");
    if (type === "Item") { const made = docs.map((d) => makeItem(d, a)); a.items.push(...made); for (const fn of hookList.get("createItem") ?? []) await fn(made[0]); return made; }
    const made = docs.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => { guard(a, "delete in"); if (type === "Item") { for (const id of ids) { const i = a.items.findIndex((x) => x.id === id); if (i >= 0) a.items.splice(i, 1); } return; } a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.hasCondition = (k) => a.conditions.has(k);
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
const effectsGetter = (a) => { a.effects.get = (id) => a.effects.find((e) => e.id === id); };
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100 };
  t.document = { actor, disposition, width: 1, height: 1, x, y, hidden: false, uuid: `Scene.s1.Token.${id}`, update: async (u) => Object.assign(t.document, u) };
  actor.token = t;
  return t;
}
globalThis.game = {
  // The module socket: what a player's client emits reaches the GM's handler (here, this process as the GM).
  socket: { emit: (channel, data) => { sent.push({ channel, data }); if (game.user.isGM) pending.push(() => auto.onBlock7Socket(data)); }, on() {} },
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: { id: "u1" }, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.685.1" }, messages: []
};
game.users.activeGM = game.user;
const regions = [];
globalThis.canvas = { stage: { on(evt, fn) { const at = nextClick; queueMicrotask(() => fn({ data: { getLocalPosition: () => at } })); }, off() {} }, tokens: { placeables: [] }, scene: { regions }, dimensions: { distance: 5, size: 100 }, grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) } };
function makeRegion(name) {
  const r = { id: `r${++nextId}`, name, flags: {} };
  r.setFlag = async (s, k, v) => { (r.flags[s] ??= {})[k] = v; };
  regions.push(r);
  return r;
}
const reset = () => { cards.length = 0; answers.length = 0; reactorAnswers.length = 0; asked.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; game.user.targets = new Set(); canvas.tokens.placeables = []; regions.length = 0; castTaken = 0; castResult = null; };

const C = await import(new URL("./content/block7-spells.mjs", import.meta.url));
const R = await import(new URL("../module/block7-rules.mjs", import.meta.url));
const auto = await import(new URL("../module/block7-automations.mjs", import.meta.url));
const DZ = await import(new URL("../module/distracted.mjs", import.meta.url));
const S = Object.fromEntries(C.SPELLS_B7.map((s) => [s.name, s]));
const eff = (name, kind, i = 0) => S[name].system.effects.filter((e) => e.kind === kind)[i];

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
{
  const audit = read("docs", "ELDRITCH_ARTS_BLOCK7_AUDIT.md");
  const rows = [...audit.matchAll(/^\| \d+ \| ([^|]+) \| \d+ \| \d+ \| [^|]+ \| [^|]* \| \*\*Block 7\*\* \|$/gm)].map((m) => m[1].trim());
  equal("A the 42 spells are the audit's Block 7, in the book's names", [...C.SPELLS_B7.map((s) => s.name)].sort(), rows.map((n) => n.replace(/ To /g, " to ")).sort());
  equal("A …42 of them", C.SPELLS_B7.length, 42);
  const grim = new Map(book.grimoire.map((e) => [e.name, e]));
  for (const [i, name] of C.BLOCK7_NAMES.entries()) {
    const s = C.SPELLS_B7[i], b = grim.get(name);
    ok(`A ${s.name}: in the book`, Boolean(b));
    if (!b) continue;
    equal(`A ${s.name}: PP, type, uncommon`, [s.system.ppCost, s.type, s.system.availability], [b.pp, "spell", "uncommon"]);
    const trad = String(b.fields.Tradition ?? "").trim().toLowerCase();
    equal(`A ${s.name}: tradition (all → the four; High Magic none)`, s.system.tradition, trad === "all" ? "arcane, divinity, ethereal, verdant" : trad);
    ok(`A ${s.name}: traits as printed`, s.system.traits.split(", ").map((t) => t.toUpperCase()).join(" ") === b.traits.join(" "));
    ok(`A ${s.name}: the card prints the book's text`, b.lines.every((l) => s.system.description.replace(/<[^>]+>/g, "").includes(l.replace(/\*\*/g, "").replace(/\*/g, "").slice(0, 40))));
    const g = C.SPELL_AUTOMATION_B7[s.name].grade;
    const opens = /<em>(Automated, with a choice|Automated|Partly automated|Not automated)/.exec(s.system.description)?.[1];
    equal(`A ${s.name}: its card opens with its grade (${g})`, opens, { A: "Automated", B: "Automated, with a choice", C: "Partly automated", D: "Not automated" }[g]);
    if (g === "C") ok(`A ${s.name}: a C card names what is by hand`, /By hand:|<em>By hand:<\/em>/.test(s.system.description));
    ok(`A ${s.name}: its key`, typeof s.flags[SYS].eaGrimoire === "string" && s.flags[SYS].eaGrimoire.length > 2);
    ok(`A ${s.name}: High Magic only where printed`, /HIGHMAGIC/.test(b.traits.join(" ")) === /Highmagic/.test(s.system.traits));
  }
  // 0.16.0 (TRG Prime 3.692.0's five seams): Mycelium C → A, Glyph and Spirit Arrow C → B; Eaog Balls stays C.
  equal("A grades: A 18, B 19, C 3, D 2", ["A", "B", "C", "D"].map((l) => Object.values(C.SPELL_AUTOMATION_B7).filter((r) => r.grade === l).length), [18, 19, 3, 2]);
  equal("A the regraded four (0.16.0)", ["arcaneMycelium", "glyphOfRetribution", "spiritArrow", "eaogBalls"].map((k) => Object.values(C.SPELL_AUTOMATION_B7).find((r) => r.key === k)?.grade), ["A", "B", "B", "C"]);
  equal("A keys are unique", new Set(C.SPELLS_B7.map((s) => s.flags[SYS].eaGrimoire)).size, 42);
  ok("A no card claims Automated and says by hand in the same opening (a D or C is never 'Automated')", Object.entries(C.SPELL_AUTOMATION_B7).every(([n, r]) => !["C", "D"].includes(r.grade) || !/<em>Automated/.test(S[n].system.description)));
  equal("A the Elemental Strike ability's uuid is the built ability's", C.ELEMENTAL_STRIKE_UUID.split(".").at(-1), C.ELEMENTAL_STRIKE_ITEM._id);
  equal("A …and the spell grants it by that uuid", eff("Elemental Strike", "grantAbility").uuid, C.ELEMENTAL_STRIKE_UUID);
  equal("A casts as printed: reactions, 1 AP, 3 AP, 1 minute", ["Air Bubble", "Arcane Feedback", "Panic Transposition", "Dreadmote", "Veil of Mist", "Glyph of Retribution"].map((n) => S[n].system.castAP), ["Reaction", "Reaction", "Reaction", 1, 3, "1 minute"]);
  equal("A Flesh to Blossom keeps the book's small 'to'", Boolean(S["Flesh to Blossom"]), true);
  equal("A sustained: Eaog Balls, Flesh to Blossom, Metamagic Resonance", C.SPELLS_B7.filter((s) => s.system.sustained).map((s) => s.name).sort(), ["Eaog Balls", "Flesh to Blossom", "Metamagic Resonance"]);
  const md = read("module", "block7-rules.mjs");
  ok("A Graham's two rulings are recorded as rulings, not open readings", /Max \+50, four warps/.test(md) && /Flat 6d6/.test(md) && !/OPEN FOR GRAHAM/.test(md));
}

/* ----------------------------------------------------------------- */
/* B — the data, through the core's own readers                       */
/* ----------------------------------------------------------------- */
{
  const T = await quiet(() => import(sys("module", "magic", "thorns.mjs")));
  const glyph = T.normaliseThorns(T.spellThorns(T.normaliseThorns(eff("Glyph of Retribution", "thorns")), { saveDC: 24, casterLevel: 20, spellName: "Glyph of Retribution" }));
  equal("B H1 Glyph: basic Fortitude at the cast's DC, 1d6 + CL max 15, sonic, any melee reach", [glyph.damage, glyph.damageType, glyph.saveRoll.key, glyph.saveRoll.dc, glyph.saveRoll.basic, glyph.reachFeet], ["1d6+15", "sonic", "fortitude", 24, true, R.ANY_MELEE_FEET]);
  {
    // THE +4 PP TYPE CHANGE (TRG Prime 3.692.0's thorns `typeChoices`): the warp swaps the plain row for one that asks.
    const CW = await quiet(() => import(sys("module", "magic", "condition-warp.mjs")));
    const rows = S["Glyph of Retribution"].system.effects.filter((e) => e.kind === "thorns");
    const live = (unlocks) => rows.filter((r) => CW.rowAppliesToCast(r, { unlocks })).map((r) => T.normaliseThorns(r).typeChoices ?? null);
    equal("B Glyph's +4 PP: without it one sonic row; with it one row offering acid, cold, electricity or fire (the printed four)", [live([]), live([R.GLYPH_TYPE_UNLOCK])], [[null], [["acid", "cold", "electricity", "fire"]]]);
    const asked = T.normaliseThorns(T.spellThorns(T.normaliseThorns(rows[1]), { saveDC: 24, casterLevel: 20 }));
    equal("B …the chosen type is dealt; an unanswered or unoffered one leaves the printed sonic; still 1d6 + CL max 15, Fortitude at the DC", [T.thornsDamageTypeFor(asked, "fire"), T.thornsDamageTypeFor(asked, ""), T.thornsDamageTypeFor(asked, "sonic"), asked.damage, asked.saveRoll.dc, asked.reachFeet], ["fire", "sonic", "sonic", "1d6+15", 24, R.ANY_MELEE_FEET]);
    ok("B …and Glyph's card leaves nothing by hand (0.16.0)", !/By hand/i.test(S["Glyph of Retribution"].system.description));
  }
  {
    // EAOG BALLS' HALVED SPEED (TRG Prime 3.692.0's `speedHalve`).
    const halves = S["Eaog Balls"].system.effects.filter((e) => e.kind === "speedHalve");
    equal("B Eaog Balls halves the speed on a Critical (to the end of its next turn) and a Success (the spell's length)", halves.map((e) => [e.onSave, e.duration ?? ""]), [[["critical"], "until the end of its next turn"], [["success"], ""]]);
    const EK = await quiet(() => import(sys("module", "magic", "effect-kinds.mjs")));
    equal("B …a kind the core's applier handles", EK.HANDLED_EFFECT_KINDS.includes("speedHalve"), true);
    equal("B …and no 'by hand' note for it is left", S["Eaog Balls"].system.effects.some((e) => e.kind === "note" && /speed halved/i.test(e.text ?? "")), false);
  }
  equal("B the thorns answer every melee hit, a reach weapon's at 10 or 15 ft included (none is printed)", [10, 15].map((d) => T.thornsTriggered(T.normaliseThorns(eff("Brittleskin", "thorns")), { hit: true, melee: true, distanceFeet: d })), [true, true]);
  const brittle = T.normaliseThorns(T.spellThorns(T.normaliseThorns(eff("Brittleskin", "thorns")), { saveDC: 15, casterLevel: 4 }));
  equal("B H1 Brittleskin: 1d4 piercing, basic Fortitude at the Save DC", [brittle.damage, brittle.damageType, brittle.saveRoll.dc, brittle.saveRoll.basic], ["1d4", "piercing", 15, true]);
  const mantle = T.normaliseThorns(T.spellThorns(T.normaliseThorns(T.warpedThorns(eff("Eldritch Mantle", "thorns"), 2)), { saveDC: 20, casterLevel: 10 }));
  equal("B H1 Eldritch Mantle: 1d6 force, +1d6 a warp (two: 3d6)", [mantle.damage, mantle.damageType, mantle.saveRoll.dc], ["3d6", "force", 20]);
  const guard = T.normaliseThorns(T.spellThorns(T.normaliseThorns(eff("Prismatic Guard", "thorns")), { saveDC: 26 }));
  equal("B H1 Prismatic Guard: a ladder, not basic; Success dazzled to its turn's end, Failure blinded, Fumble permanent, Partial its own",
    [Boolean(guard), guard.saveRoll.basic, T.thornsLadderRows(guard, "success").rows[0]?.condition, T.thornsLadderRows(guard, "partial").rows[0]?.duration, T.thornsLadderRows(guard, "failure").rows[0]?.condition, T.thornsLadderRows(guard, "fumble").rows[0]?.duration, T.thornsLadderRows(guard, "critical").rows.length],
    [true, false, "dazzled", "until the end of its next turn", "blinded", "permanent", 0]);

  const CL = await quiet(() => import(sys("module", "magic", "caster-level-mods.mjs")));
  const bs = S.Brittleskin.system;
  equal("B H2 Brittleskin: CL 3 DR 1 / 1d4; CL 8 DR 3 / 3d4", [CL.casterLevelRows(bs.effects, CL.applyCasterLevelMods(bs.casterLevelMods, 3)).slice(0, 2).map((r) => r.value ?? r.damage), CL.casterLevelRows(bs.effects, CL.applyCasterLevelMods(bs.casterLevelMods, 8)).slice(0, 2).map((r) => r.value ?? r.damage)], [[1, "1d4"], [3, "3d4"]]);
  equal("B H2 Decoherence: +1 at CL 4, +3 at CL 12", [CL.casterLevelRows(S.Decoherence.system.effects, CL.applyCasterLevelMods(S.Decoherence.system.casterLevelMods, 4))[0].value, CL.casterLevelRows(S.Decoherence.system.effects, CL.applyCasterLevelMods(S.Decoherence.system.casterLevelMods, 12))[0].value], [2, 4]);
  equal("B H2 Feltwarp: 1 hour, 3 hours at CL 8", CL.casterLevelDuration(S.Feltwarp.system.duration, CL.applyCasterLevelMods(S.Feltwarp.system.casterLevelMods, 8).duration), "3 hours");
  equal("B Invoke True Name's step: once, at CL 8 (Q164: the penalty is read off the mark's caster level)", [S["Invoke True Name"].system.casterLevelMods[0].threshold, S["Invoke True Name"].system.casterLevelMods[0].recurring], [8, false]);
  equal("B the cantrips' damage steps: Dreadmote 3d4 at CL 8; Necrotic Whisper and Orb of Dusk +1 secondary", [CL.applyCasterLevelMods(S.Dreadmote.system.casterLevelMods, 8).damageDice, CL.applyCasterLevelMods(S["Necrotic Whisper"].system.casterLevelMods, 8).secondary, S["Orb of Dusk"].system.secondaryDamage], ["2d4", 2, { formula: "1", type: "cold" }]);

  const L = await quiet(() => import(sys("module", "magic", "turn-ladder.mjs")));
  const bubble = L.normaliseTurnLadder(eff("Bubble Buffet", "turnLadder"));
  equal("B H3b Bubble Buffet: at the cast and the caster's turns, worse replaces, a failure stops (m100)", [bubble?.on, bubble?.atCast, bubble?.replace, bubble?.stopAt, L.turnLadderRollsAgain(bubble, "partial"), L.turnLadderRollsAgain(bubble, "failure")], ["casterTurnStart", true, "worse", "failure", true, false]);
  equal("B …Success and Partial lay Distracted (one row each, 0.10.1), Failure fixated, Fumble fixated + slowed 1", [bubble.degrees.success.rows.filter(DZ.isDistractedRow).length, bubble.degrees.partial.rows.filter(DZ.isDistractedRow).length, bubble.degrees.success.rows.length, bubble.degrees.failure.rows.map((r) => r.condition), bubble.degrees.fumble.rows.map((r) => `${r.condition}${r.value ?? ""}`)], [1, 1, 1, ["fixated"], ["fixated", "slowed1"]]);
  const blossom = L.normaliseTurnLadder(eff("Flesh to Blossom", "turnLadder"));
  const st = (p, r) => { const x = L.turnLadderStep(blossom, p, r); return [x.at, x.endsSpell, x.rung?.dice ?? ""]; };
  equal("B H3c Flesh to Blossom (Q156): each save replaces the last; a Critical ends it; Partial reads Failure", [blossom.on, st("failure", "success"), st("success", "critical"), st(null, "partial"), st("failure", "fumble")], ["targetTurnStart", ["success", false, "1d12"], ["critical", true, ""], ["failure", false, "2d12"], ["fumble", false, "4d12"]]);
  const E = await quiet(() => import(sys("module", "magic", "entry-check.mjs")));
  const myc = E.normaliseEntryCheck(eff("Arcane Mycelium", "entryCheck"));
  equal("B H3a Arcane Mycelium: Reflex, also at a turn's start; Failure/Partial slowed 1, Fumble slowed 2, to the end of the next turn", [myc.save, myc.atTurnStart, myc.degrees.failure.rows[0].value, myc.degrees.partial.rows[0].value, myc.degrees.fumble.rows[0].value, myc.degrees.fumble.rows[0].duration, myc.degrees.success.unaffected], ["reflex", true, 1, 1, 2, "until the end of its next turn", true]);
  const zone = E.normaliseEntryCheck(eff("Zone Disruption", "entryCheck"));
  equal("B Zone Disruption: Will on entering, not at a turn's start; a Critical marks it exempt, others subject", [zone.save, zone.atTurnStart ?? false, zone.degrees.critical.rows[0].key, zone.degrees.failure.rows[0].key], ["will", false, R.ZONE_EXEMPT_MARK, R.ZONE_AFFECTED_MARK]);

  const G = await quiet(() => import(sys("module", "combat", "granted-speeds.mjs")));
  const W = await quiet(() => import(sys("module", "magic", "spell-warp.mjs")));
  const wings = S["Dragon Wings"].system;
  const wingsAt = (n) => { const mods = W.aggregateWarpSelection(wings.warps, { "warp-0": n }).mods; const grant = G.normaliseGrantedSpeed({ key: "fly", landPlus: W.warpedBonusValue(eff("Dragon Wings", "speedGrant").landPlus, mods.bonusValue, mods.bonusMax) }, ["land", "fly"]); return G.grantedSpeedBase(grant, 25); };
  equal("B H4 Dragon Wings (ruled \"Max +50, four warps\"): land 25 → fly 35, 45 with one, 75 with four, still 75 with a fifth", [wingsAt(0), wingsAt(1), wingsAt(4), wingsAt(5)], [35, 45, 75, 75]);
  equal("B …the warp's cap is the whole +50", [wings.warps[0].mods.bonusMax, R.DRAGON_WINGS_MAX_WARPS], [50, 4]);

  const SR = await quiet(() => import(sys("module", "magic", "strike-riders.mjs")));
  const arrowRow = eff("Spirit Arrow", "strikeRider");
  equal("B H10 Spirit Arrow (ruled \"Flat 6d6\"): the rider carries replacesDamage and flat, once, ranged", [arrowRow.replacesDamage, arrowRow.flat, arrowRow.once, arrowRow.scope, arrowRow.dice, arrowRow.damageType], [true, true, true, "ranged", "6d6", "piercing"]);
  const arrow = SR.normaliseStrikeRider(arrowRow);
  equal("B …the core reads it as the bow's damage, not a sword's, and no secondary packet", [Boolean(arrow?.replacesDamage), SR.damageReplacement([arrow], { attackMode: "missile", name: "Longbow" })?.dice, SR.damageReplacement([arrow], { attackMode: "melee", name: "Sword" }), SR.riderPacketsFor([arrow], { attackMode: "missile", name: "Longbow" }).length], [true, "6d6", null, 0]);

  const rowsOf = (n, kind) => S[n].system.effects.filter((e) => e.kind === kind).map((e) => [e.condition ?? e.kind, e.value ?? null, e.onSave ?? null, e.duration ?? null]);
  equal("B Word of Pain (M58): weakened 1 for 1 round / 1 for 1 minute / 2 for 10 minutes / 4 for 1 hour", rowsOf("Word of Pain", "condition"), [["weakened", 1, ["critical"], "1 round"], ["weakened", 1, ["success"], "1 minute"], ["weakened", 2, ["failure"], "10 minutes"], ["weakened", 4, ["fumble"], "1 hour"]]);
  equal("B Memory Eclipse (M46): dazed 1 for 1 round / dazed 2 for 10 minutes / + frightened 2", rowsOf("Memory Eclipse", "condition"), [["dazed", 1, ["success"], "1 round"], ["dazed", 2, ["failure"], "10 minutes"], ["dazed", 2, ["fumble"], "10 minutes"], ["frightened", 2, ["fumble"], null]]);
  equal("B Leyline Burst pushes 10 ft on a Failure or worse only; its burst warp is 10 ft", [eff("Leyline Burst", "forcedMove").onSave, eff("Leyline Burst", "forcedMove").feet, S["Leyline Burst"].system.warps.map((w) => w.mods)], [["failure", "fumble"], 10, [{ damageDice: "1d6" }, { areaOverride: "10-foot radius" }]]);
  equal("B the area warps as printed: Acidic Burst +5 ft; Word of Pain, Planar Anchor and Zone Disruption's radii", [S["Acidic Burst"].system.warps[0].mods, S["Word of Pain"].system.warps[0].mods, S["Planar Anchor"].system.warps[0].mods, S["Zone Disruption"].system.warps[0].mods], [{ areaGrowth: 5 }, { areaOverride: "20-foot radius" }, { areaOverride: "20-foot radius" }, { areaOverride: "40-foot radius" }]);
  equal("B Chronoweave lays no condition row of its own: the module keeps who is inside quickened (Q159)", S.Chronoweave.system.effects.filter((e) => e.kind === "condition").length, 0);
  equal("B who an area takes: Chronoweave and Metamagic Resonance allies (you with them), the rest all", [S.Chronoweave.system.areaTargeting, S["Metamagic Resonance"].system.areaTargeting, S["Veil of Mist"].system.areaTargeting], ["allies", "allies", "all"]);
  const HB = await quiet(() => import(sys("module", "magic", "held-bonus.mjs")));
  const held = HB.normaliseHeldBonus(eff("Decoherence", "heldBonus"));
  equal("B Decoherence's held bonus: +1 circumstance, skill checks of the four actions", [held?.value, held?.bonusType, held?.checkTypes, held?.actions], [1, "circumstance", ["skill"], ["identifyPower", "recallKnowledge", "dispel", "disableADevice"]]);
  const MM = await quiet(() => import(sys("module", "magic", "module-mark.mjs")));
  equal("B the marks are the module's (Invoke True Name, Planar Anchor, Zone Disruption)", [MM.normaliseModuleMark(eff("Invoke True Name", "moduleMark"))?.key, MM.normaliseModuleMark(eff("Planar Anchor", "moduleMark", 2))?.key, MM.normaliseModuleMark(eff("Zone Disruption", "moduleMark"))?.module], [R.TRUE_NAME_MARK, R.ANCHOR_MARK, MOD]);
  equal("B Planar Anchor's rungs: 1 minute, 10 minutes, 1 hour (Fumble too), Fumble slowed 1 for 1 minute", [...S["Planar Anchor"].system.effects.filter((e) => e.kind === "moduleMark").map((e) => [e.onSave, e.duration]), eff("Planar Anchor", "condition").duration], [[["success"], "1 minute"], [["partial"], "10 minutes"], [["failure", "fumble"], "1 hour"], "1 minute"]);
  const CO = await quiet(() => import(sys("module", "conditions", "registry.mjs")));
  const conds = [...new Set(C.SPELLS_B7.flatMap((s) => JSON.stringify(s.system.effects).match(/"condition":"[a-zA-Z]+"/g) ?? []).map((m) => m.split(":")[1].replace(/"/g, "")))].sort();
  equal("B every condition a row names is the core's", conds.filter((c) => !CO.CONDITIONS[c]), []);
  const SE = await quiet(() => import(sys("module", "magic", "spell-effects.mjs")));
  equal("B Distracted (Q157): −1 status on attack, every skill, the three saves and Spellcraft — each a pool the core reaches — as one row (0.10.1)", [DZ.distractedRows().map((r) => [r.slots, r.value, r.bonusType, r.name, r.refresh]), DZ.distractedRows()[0].slots.filter((s) => s !== "allSkills").map((s) => SE.bonusTargetFor(s))],
    [[[["attack", "allSkills", "fortitude", "reflex", "will", "spellcraft"], -1, "status", "Distracted", true]], ["system.combat.attack", "system.combat.saves.fortitude", "system.combat.saves.reflex", "system.combat.saves.will", "system.magic.spellcraft"]]);
  ok("B …not DB or damage (Q157)", DZ.distractedRows().every((r) => r.slots.every((s) => !["defence", "damage", "dr"].includes(s))));
  equal("B Animate Moustache: Distracted on a Failure or Fumble (a Partial reads Failure, m42), for the spell's minute", [S["Animate Moustache"].system.effects.filter(DZ.isDistractedRow).length, [...new Set(S["Animate Moustache"].system.effects.map((e) => JSON.stringify(e.onSave)))], S["Animate Moustache"].system.duration], [1, ["[\"failure\",\"fumble\"]"], "1 minute"]);
  const SD = await quiet(() => import(sys("module", "magic", "spell-degrees.mjs")));
  equal("B …the core reads a Partial against Animate Moustache as its Failure", SD.effectiveSaveDegree(S["Animate Moustache"].system.effects, "partial", { basicSave: false }), "failure");
  const CTd = await quiet(() => import(sys("module", "creature-traits.mjs")));
  const dv = CTd.actorDefences({ combat: { resistances: eff("Arcane Bastion", "defence").value + ", " + eff("Prismatic Guard", "defence").value, immunities: eff("Prismatic Guard", "defence", 1).value, weaknesses: "" }, parent: null });
  equal("B defences, as the core reads them: all damage (Bastion, Aegis), M53's seven energies, immunity to blinded and dazzled (Prismatic Guard)", [eff("Spectral Aegis", "defence").value, [...dv.resistanceCategories], [...dv.resistances].sort(), [...dv.immuneConditions].sort()], ["all damage", ["all damage"], ["acid", "cold", "electricity", "essence", "fire", "force", "sonic"], ["blinded", "dazzled"]]);
  equal("B the Eaog coldfire rung is the warp's only: the core gates it on the unlock", await (async () => { const CW = await quiet(() => import(sys("module", "magic", "condition-warp.mjs"))); const row = S["Eaog Balls"].system.effects.find((e) => e.damageType === "coldfire"); return [CW.rowAppliesToCast(row, { unlocks: [] }), CW.rowAppliesToCast(row, { unlocks: [R.EAOG_COLDFIRE_UNLOCK] })]; })(), [false, true]);
  equal("B Eaog Balls' recurring rungs: force 1d6 / 2d6 / 3d6 and coldfire 2d8 — two types, each its own total (Q150)", S["Eaog Balls"].system.effects.filter((e) => e.condition === "recurring").map((e) => `${e.formula} ${e.damageType}`), ["1d6 force", "2d6 force", "3d6 force", "2d8 coldfire"]);
  equal("B Mana Surge: a free warp on every spell that raises the Save DC (H9b); 2 PP with +4 PP", [eff("Mana Surge", "freeWarp").trait, eff("Mana Surge", "freeWarp").raisesSaveDC, W.warpedBonusValue(1, W.aggregateWarpSelection(S["Mana Surge"].system.warps, { "warp-1": 1 }).mods.bonusValue, 2)], ["*", true, 2]);
  const ARL = await quiet(() => import(sys("module", "magic", "area-region-life.mjs")));
  const EM = await quiet(() => import(sys("module", "magic", "emanation.mjs")));
  equal("B the Regions outlive their casts: Mycelium, Bubble Buffet, Zone Disruption (claimed); Primal Snap and Veil of Mist (a live zone)", [ARL.areaRegionIsClaimed(S["Arcane Mycelium"].system), ARL.areaRegionIsClaimed(S["Bubble Buffet"].system), ARL.areaRegionIsClaimed(S["Zone Disruption"].system), EM.emanationIsLive(S["Primal Snap"].system), EM.emanationIsLive(S["Veil of Mist"].system)], [true, true, true, true, true]);
  equal("B Prismatic Guard is a placed radius (the cast's creatures keep it), not a following emanation", [S["Prismatic Guard"].system.area, EM.emanationIsLive(S["Prismatic Guard"].system)], ["10-foot radius", false]);
  // Every warp mod key a Block 7 spell authors is one the core's aggregator reads (a key it does not read is PP charged for nothing).
  const unread = [];
  for (const s of C.SPELLS_B7) for (const [i, w] of s.system.warps.entries()) {
    const keys = Object.keys(w.mods ?? {});
    const agg = W.aggregateWarpSelection([w], { "warp-0": 1 }).mods;
    for (const k of keys) if (JSON.stringify(agg[k]) === JSON.stringify(W.emptyWarp?.()?.[k] ?? W.aggregateWarpSelection([], {}).mods[k])) unread.push(`${s.name} #${i} ${k}`);
  }
  equal("B every warp mod key is read by the core's aggregator", unread, []);
  equal("B every printed warp is built, in order", C.SPELLS_B7.map((s) => s.system.warps.length), C.BLOCK7_NAMES.map((n) => book.grimoire.find((e) => e.name === n).lines.filter((l) => /^\*\*\+\d+ PP:?\*\*/.test(l)).length));
  const DE = await quiet(() => import(sys("module", "magic", "declared-effect.mjs")));
  const guardSpec = DE.normaliseDeclaredEffect(eff("Arcane Bastion", "declare"), { spellName: "Arcane Bastion" });
  equal("B Arcane Bastion's 0 HP clause is the core's death guard, automatic and once", [guardSpec?.flags?.deathGuard?.auto, guardSpec?.flags?.deathGuard?.once], [true, true]);
  const { normaliseConditional } = await quiet(() => import(sys("module", "conditionals.mjs")));
  const SC = await quiet(() => import(sys("module", "magic", "spell-conditional.mjs")));
  equal("B the conditionals read: Feltwarp +1 item Stealth (a tick), Bouncy Body +2 Escape/grapple (auto), Pledgeshroud −2 Deception (a tick)", [SC.normaliseSpellConditional(eff("Feltwarp", "conditional"), normaliseConditional)?.grants?.[0]?.value, SC.normaliseSpellConditional(eff("Bouncy Body", "conditional"), normaliseConditional)?.grants?.[0]?.auto, SC.normaliseSpellConditional(eff("Pledgeshroud", "conditional"), normaliseConditional)?.grants?.[0]?.value], [1, true, -2]);
  const LS = await quiet(() => import(sys("module", "magic", "light-shift.mjs")));
  equal("B Drearlight's dim light: one step, 10 ft, following its bearer", [LS.normaliseLightShift(eff("Drearlight", "lightShift"))?.steps, LS.normaliseLightShift(eff("Drearlight", "lightShift"))?.radiusFeet], [1, 10]);
}

/* ----------------------------------------------------------------- */
/* C — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  equal("C Spirit Arrow's manoeuvres as core actions, the Grapple for 1 round", R.SPIRIT_ARROW_MANOEUVRES.map((m) => [R.spiritArrowAction(m)?.key, R.spiritArrowAction(m)?.rounds]), [["feint", null], ["grappleAttack", 1], ["shoveAttack", null], ["tripAttack", null]]);
  equal("C Metamagic Resonance's change on a Sustain: its own cast, with the option bought", [R.resonanceSwapOnSustain({ swap: true, castId: "c1" }, "c1"), R.resonanceSwapOnSustain({ swap: true, castId: "c1" }, "c2"), R.resonanceSwapOnSustain({ swap: false, castId: "c1" }, "c1"), R.resonanceSwapOnSustain({ swap: true, castId: "" }, ""), R.resonanceSwapOnSustain(null, "c1")], [true, false, false, false, false]);
  equal("C Arcane Mycelium's light: Dim Light (5), named for the spell", R.myceliumLight("Arcane Mycelium"), { level: 5, label: "Arcane Mycelium (dim light)" });
  equal("C Spirit Arrow's fear (Q161): half the margin, rounded down, min 1; none on a success", [R.spiritArrowFrightened(-1), R.spiritArrowFrightened(-5), R.spiritArrowFrightened(-6), R.spiritArrowFrightened(0), R.spiritArrowFrightened(3), R.spiritArrowFrightened(null)], [1, 2, 3, 0, 0, 0]);
  equal("C Dragon's Breath: acid/electricity a 30-ft line (+10, max 120), the rest a 15-ft cone (+5, max 60); the type's trait", [R.breathItemUpdate(S["Dragon’s Breath"].system, "acid")["system.area"], R.breathItemUpdate(S["Dragon’s Breath"].system, "acid")["system.warps"][1].mods, R.breathItemUpdate(S["Dragon’s Breath"].system, "poison")["system.area"], R.breathItemUpdate(S["Dragon’s Breath"].system, "poison")["system.warps"][1].mods, R.breathItemUpdate(S["Dragon’s Breath"].system, "cold")["system.traits"], R.breathItemUpdate(S["Dragon’s Breath"].system, "sonic"), ["cold", "fire", "poison", "acid", "electricity"].map((t) => R.breathShapeOf(t))],
    ["30-foot line", { areaGrowth: 10, areaMax: 120 }, "15-foot cone", { areaGrowth: 5, areaMax: 60 }, "Cold, Elemental, Save, Uncommon", null, ["cone", "cone", "cone", "line", "line"]]);
  equal("C Elemental Strike: four types; the Pact's element maps (air → electricity, earth → acid)", [R.STRIKE_TYPES, R.ELEMENT_TO_STRIKE.air, R.ELEMENT_TO_STRIKE.earth, R.strikeItemUpdate({}, "poison")], [["acid", "cold", "electricity", "fire"], "electricity", "acid", null]);
  equal("C Elemental Strike's dice: 1d6, +1d6 a warp; + the casting ability", [R.elementalStrikeDice(""), R.elementalStrikeDice("2d6"), R.elementalStrikeFormula("2d6", 4), R.elementalStrikeFormula("1d6", 0)], ["1d6", "3d6", "2d6 + 4", "1d6"]);
  equal("C Invoke True Name: −2, −4 from CL 8 (Q164); flat-footed loses Dex + dodge", [R.trueNamePenalty(7), R.trueNamePenalty(8), R.trueNamePenalty(20), R.flatFootedLossOf({ ability: 3, breakdown: { byType: { dodge: 2 } } })], [-2, -4, -4, 5]);
  equal("C Planar Anchor refuses Teleportation; invisible/incorporeal only with the veil", [R.anchorRefuses({ traits: "Teleportation, Translocation" }), R.anchorRefuses({ traits: "Illusion", name: "Invisibility" }), R.anchorRefuses({ traits: "Illusion", name: "Invisibility", veil: true }), R.anchorRefuses({ traits: "Fire" }), R.anchorRefuses({ traits: "Translocation, Utility" })], ["teleportation", "", "veil", "", ""]);
  equal("C Arcane Feedback's critical: Failure Minor, Fumble Serious (Blunder as Fumble, m42), a step a warp, max Deadly; the penalty is the damage taken", [R.feedbackSeverity("failure"), R.feedbackSeverity("fumble"), R.feedbackSeverity("blunder"), R.feedbackSeverity("failure", 1), R.feedbackSeverity("fumble", 2), R.feedbackSeverity("success", 2), R.feedbackPenalty(9), R.feedbackPenalty(9, false), R.feedbackPenalty(0)], ["minor", "serious", "serious", "serious", "deadly", null, -9, 0, 0]);
  equal("C Arcane Bastion (Q151): 1 step, a further one a warp, max 3; dying, unconscious, a Death row incapacitate; Stunned does not", [R.bastionSteps(0), R.bastionSteps(2), R.bastionSteps(5), R.injuryIncapacitates({ effect: "Target is Dying" }), R.injuryIncapacitates({ effect: "Target becomes Unconscious." }), R.injuryIncapacitates({ persistence: "Death", effect: "x" }), R.injuryIncapacitates({ effect: "Target is Stunned 2." })], [1, 3, 3, true, true, true, false]);
  equal("C Argent Reversal: attempts 1–5; Critical turns back with a choice, Success to the source, Fumble 4d10, Blunder 8d10, Partial as Failure; half PP rounded down; reach = max PP per cast", [R.argentAttempts(0), R.argentAttempts(9), R.argentOutcome("critical"), R.argentOutcome("success").choose, R.argentOutcome("partial"), R.argentOutcome("fumble").backlash, R.argentOutcome("blunder").backlash, R.argentAbsorbPP(7), R.argentReaches(11, 10), R.argentReaches(12, 10)],
    [1, 5, { turn: true, choose: true, backlash: "" }, false, { turn: false, choose: false, backlash: "" }, "4d10", "8d10", 3, true, false]);
  equal("C Spectral Aegis (Q152): 1 absorb, PP 10; the warps add", [R.aegisState({}), R.aegisState({ declareUses: 2, heldUses: 1 }), R.aegisAbsorbs(10, R.aegisState({})), R.aegisAbsorbs(11, R.aegisState({})), R.aegisAbsorbs(11, R.aegisState({ heldUses: 1 }))], [{ absorbs: 1, ppLimit: 10 }, { absorbs: 3, ppLimit: 11 }, true, false, true]);
  equal("C Mirror Reprise: 26+/34+/51+ for 3/2/1; none with no images", [R.mirrorDiverts(3, 26), R.mirrorDiverts(3, 25), R.mirrorDiverts(2, 34), R.mirrorDiverts(2, 33), R.mirrorDiverts(1, 51), R.mirrorDiverts(1, 50), R.mirrorDiverts(0, 100)], [true, false, true, false, true, false, false]);
  equal("C Metamagic Resonance: ×1, ½ (+3 PP), 0 (+6 PP replaces it, m114); 30 or 60 ft", [R.resonanceCostFactor([]), R.resonanceCostFactor([R.RESONANCE_HALF_UNLOCK]), R.resonanceCostFactor([R.RESONANCE_HALF_UNLOCK, R.RESONANCE_FREE_UNLOCK]), R.resonanceFeet(""), R.resonanceFeet("60-foot emanation")], [1, 0.5, 0, 30, 60]);
  equal("C Primal Snap's dice and Chronoweave's slow", [R.snapDice(""), R.snapDice("2d8"), R.chronoSlowed("failure"), R.chronoSlowed("partial"), R.chronoSlowed("fumble"), R.chronoSlowed("success")], ["6d8", "8d8", 1, 1, 2, 0]);
  equal("C Panic Transposition: 30 ft, 60 with the warp; max PP per cast is CL + 1", [R.panicFeet([]), R.panicFeet([R.PANIC_FAR_UNLOCK]), R.maxPPPerCast(9)], [30, 60, 10]);
  equal("C lent keys: a core option's feat name in lower case; a module's key", [auto.lentKeyOf({ source: "core", label: "Empower Spell — additional damage" }), auto.lentKeyOf({ source: "module", key: "eaX" })], ["empower spell", "eaX"]);
}

/* ----------------------------------------------------------------- */
/* D — registration, and the core's real collectors                    */
/* ----------------------------------------------------------------- */
const API = await quiet(() => import(sys("module", "module-api.mjs")));
const reg = { feat: [], gate: [], check: [], damage: [], critical: [], cast: [], refusal: [], prelude: [], dispel: [], fumble: [], step: [] };
const recorder = {
  registerFeatAutomation: (n) => reg.feat.push(n), registerSpellCheckGate: (k, f, m) => { reg.gate.push(k); return API.registerSpellCheckGate(k, f, m); },
  registerCheckReaction: (k, s, m) => { reg.check.push(k); return API.registerCheckReaction(k, s, m); }, registerDamageReaction: (k, f, m) => { reg.damage.push(k); return API.registerDamageReaction(k, f, m); },
  registerCriticalReaction: (k, s, m) => { reg.critical.push(k); return API.registerCriticalReaction(k, s, m); }, registerCastReaction: (k, f, m) => { reg.cast.push(k); return API.registerCastReaction(k, f, m); },
  registerCastRefusal: (k, f, m) => { reg.refusal.push(k); return API.registerCastRefusal(k, f, m); }, registerCastPrelude: (k, f, m) => { reg.prelude.push(k); return API.registerCastPrelude(k, f, m); },
  registerDispelModifier: (k, s, m) => { reg.dispel.push(k); return API.registerDispelModifier(k, s, m); }, registerFumbleModifier: (k, f, m) => { reg.fumble.push(k); return API.registerFumbleModifier(k, f, m); },
  registerReactionStep: (k, f) => { reg.step.push(k); STEPS[k] = f; }
};
auto.registerBlock7(recorder, MOD);
equal("D registered: the ability's Use, four gates, three check, three damage and one critical reaction, two cast reactions, two refusals, a prelude, a dispel and a fumble modifier, four steps",
  [reg.feat, reg.gate, reg.check, reg.damage, reg.critical, reg.cast, reg.refusal, reg.prelude, reg.dispel, reg.fumble, reg.step.length],
  [[R.ELEMENTAL_STRIKE_ABILITY], ["eaArcaneFeedback", "eaArcaneMycelium", "eaInvokeTrueName", "eaZoneDisruption"], ["eaInvokeTrueName", "eaMirrorReprise", "eaPanicTransposition"], ["eaInvokeTrueName", "eaMirrorReprise", "eaPanicTransposition"], ["eaArcaneBastion"], ["eaArgentReversal", "eaSpectralAegis"], ["eaPlanarAnchor", "eaGrimoireType"], ["eaFleshToBlossom"], ["eaEaogBalls"], ["eaZoneDisruption"], 4]);
ok("D the critical reaction is an `after` one (H7), not a before", API.registeredCriticalAfterReactions().some((s) => typeof s === "function" || typeof s?.after === "function"));
const GT = await quiet(() => import(sys("module", "magic", "spell-check-gates.mjs")));
const RW = await quiet(() => import(sys("module", "reactions", "reactions-workflow.mjs")));
const CH = await quiet(() => import(sys("module", "magic", "cast-hooks.mjs")));
const DM = await quiet(() => import(sys("module", "combat", "dispel-modifiers.mjs")));
const FR = await quiet(() => import(sys("module", "magic", "fumble-resonance-modifiers.mjs")));

/* ----------------------------------------------------------------- */
/* E — the Foundry side, through the real collectors where there is one */
/* ----------------------------------------------------------------- */
// Type when learned, the Pacts, the refusal.
{
  reset();
  const actor = makeActor("Breather");
  answers.push("electricity");
  const [db] = await actor.createEmbeddedDocuments("Item", [S["Dragon’s Breath"]]);
  await auto.onItemCreatedB7(db);
  equal("E Dragon's Breath learned: the type asked and written — electricity, a 30-ft line, its trait, the line's step", [db.system.damage.type, db.system.area, /Electricity/.test(db.system.traits), db.system.warps[1].mods, db.flags[MOD][R.CHOSEN_TYPE_FLAG]], ["electricity", "30-foot line", true, { areaGrowth: 10, areaMax: 120 }, "electricity"]);
  const pactActor = makeActor("Pactbound", { items: [{ type: "feat", name: "Draconic Pact", system: {}, flags: { [SYS]: { eaEnergy: "poison" } } }] });
  const pact = pactActor.items[0];
  const made = await auto.grantPactSpellB7(pactActor, pact, "dragonsBreath", S["Dragon’s Breath"]);
  equal("E the Draconic Pact grants Dragon's Breath of its energy (poison, a cone), granted by the feat", [made?.system?.damage?.type, made?.system?.area, made?.flags?.[SYS]?.grantedBy?.sourceName], ["poison", "15-foot cone", "Draconic Pact"]);
  pact.flags[SYS].eaEnergy = "acid";
  await auto.grantPactSpellB7(pactActor, pact, "dragonsBreath", S["Dragon’s Breath"]);
  equal("E …a new energy retypes the one it granted, and adds no second", [pactActor.items.filter((i) => i.type === "spell").length, pactActor.items.find((i) => i.type === "spell").system.area], [1, "30-foot line"]);
  const ep = makeActor("Elemental", { items: [{ type: "feat", name: "Elemental Pact", system: {}, flags: { [SYS]: { eaElement: "water" } } }] });
  const es = await auto.grantPactSpellB7(ep, ep.items[0], "elementalStrike", S["Elemental Strike"]);
  equal("E the Elemental Pact's element maps (water → cold)", es?.system?.damage?.type, "cold");
  const fromPact = makeActor("Pact2", { items: [{ type: "feat", name: "Draconic Pact", system: {}, flags: { [SYS]: { eaEnergy: "fire" } } }] });
  answers.length = 0; answers.push("cold");
  const [g2] = await fromPact.createEmbeddedDocuments("Item", [{ ...S["Dragon’s Breath"], flags: { ...S["Dragon’s Breath"].flags, [SYS]: { ...S["Dragon’s Breath"].flags[SYS], grantedBy: { sourceId: fromPact.items[0].id, sourceName: "Draconic Pact" } } } }]);
  await auto.onItemCreatedB7(g2);
  equal("E a Pact's grant takes the Pact's type without asking", [g2.system.damage.type, answers.length], ["fire", 1]);
  answers.length = 0;
  const untyped = makeActor("Untyped");
  const [u] = await untyped.createEmbeddedDocuments("Item", [S["Elemental Strike"]]);
  answers.push(null);
  equal("E the real refusal collector: an untyped spell asks, and refuses when nothing is chosen", await CH.castRefusalFrom({ actor: untyped, spell: u }), "Elemental Strike: choose its damage type first (it is chosen once, when you learn the spell).");
  answers.push("acid");
  equal("E …and lets it through once chosen", [await CH.castRefusalFrom({ actor: untyped, spell: u }), u.system.damage.type], ["", "acid"]);
}
// Elemental Strike's Use.
{
  reset();
  const actor = makeActor("Striker", { items: [{ type: "weapon", name: "Sword", system: { equipped: true, attackMode: "melee" } }, C.ELEMENTAL_STRIKE_ITEM] });
  const foe = makeActor("Foe");
  const me = makeToken("me", actor, { x: 0, y: 0 }), ft = makeToken("ft", foe, { x: 100, y: 0, disposition: -1 });
  canvas.tokens.placeables = [me, ft];
  const ability = actor.items.find((i) => i.name === R.ELEMENTAL_STRIKE_ABILITY);
  await auto.onSpellSettledB7({ actor, spell: { ...S["Elemental Strike"], flags: { ...S["Elemental Strike"].flags, [MOD]: { [R.CHOSEN_TYPE_FLAG]: "cold" } } }, cast: true, saveDC: 21, warpMods: { damageDice: "1d6" } });
  equal("E the settled cast stamps the ability: the cast's DC, 1d6 + the warp's, the chosen type", ability.flags[MOD][auto.STRIKE_STAMP], { dc: 21, dice: "2d6", type: "cold" });
  game.user.targets = new Set([ft]);
  await auto.REACTIONS_B7.elementalStrikeUse.use(actor, ability);
  equal("E the Use: a basic Reflex at the stamped DC, dice + casting ability (Int 4), Base Damage 1d6", calls.saves.at(-1), { caster: "Striker", target: "Foe", save: "reflex", dc: 21, label: "Elemental Strike", formula: "2d6 + 4", type: "cold", base: "1d6" });
  ok("E …its chat card says counting as a Strike is by hand, as the item card does (no 'A Strike for rules that count them')", cards.some((c) => c.title === "Elemental Strike" && c.lines.some((l) => /By hand: that it counts as a Strike for rules that count Strikes/.test(l))) && !cards.some((c) => c.title === "Elemental Strike" && c.lines.some((l) => /A Strike for rules that count them/.test(l))));
  actor.items.find((i) => i.name === "Sword").system.equipped = false;
  const unarmed = calls.saves.length;
  await auto.REACTIONS_B7.elementalStrikeUse.use(actor, ability);
  equal("E …refused with no melee weapon wielded (Q155)", calls.saves.length, unarmed);
  actor.items.find((i) => i.name === "Sword").system.equipped = true;
  ok("E its card says counting as a Strike is by hand (no Strike hook or count fires)", /By hand:(\*|<\/em>) that each counts as a Strike/.test(S["Elemental Strike"].system.description) && /By hand:(\*|<\/em>) that each counts as a Strike/.test(C.ELEMENTAL_STRIKE_ITEM.system.description));
  ft.center.x = 400; ft.document.x = 350;  // at rest the document and the placeable agree
  const before = calls.saves.length;
  await auto.REACTIONS_B7.elementalStrikeUse.use(actor, ability);
  equal("E …refused beyond the weapon's reach", calls.saves.length, before);
}
// Arcane Feedback, through the real gate collector.
{
  reset();
  const caster = makeActor("Enemy Mage"), mage = makeActor("Feedbacker");
  const sp = makeItem(S["Arcane Feedback"], mage); mage.items.push(sp);
  const ct = makeToken("c", caster, { x: 0, y: 0, disposition: -1 }), mt = makeToken("m", mage, { x: 200, y: 0, disposition: 1 });
  canvas.tokens.placeables = [ct, mt];
  castResult = { cast: true, hurt: caster.uuid, spellSave: { results: [{ degree: "fumble" }] }, warpMods: { bonusValue: 1 } };
  castTaken = 14; castSettledDC = 27;
  const gated = await GT.runSpellCheckGates({ actor: caster, spell: { name: "Fireball" }, spellData: {}, innate: false, itemCast: false, attack: false, rollsCheck: true, targetUuids: [] });
  equal("E the real gates: Feedback cast at the enemy, its 14 damage a −14 casting-only penalty", gated.modifiers.filter((m) => m.label === "Arcane Feedback"), [{ label: "Arcane Feedback", value: -14, type: "untyped", castingOnly: true }]);
  equal("E …cast as a reaction at the caster's token; the Fumble's critical a step worse (Deadly)", [calls.casts.at(-1), calls.crits.at(-1)], [{ actor: "Feedbacker", spell: "Arcane Feedback", ids: ["c"] }, { attacker: "Feedbacker", target: "Enemy Mage", severity: "deadly", type: "force", attackBonus: 27 }]);
  ok("E …the injury's DC is the reactor's own Save DC from its settled cast (27), as the core's spell criticals pass `attackBonus: saveDC` (castSpell returns none)", calls.crits.at(-1).attackBonus === 27 && /attackBonus: saveDC/.test(fs.readFileSync(path.join(SYSTEM_ROOT, "module", "magic", "cast-workflow.mjs"), "utf8")));
  const g2 = await GT.runSpellCheckGates({ actor: caster, spell: { name: "Bolt" }, spellData: {}, innate: true, itemCast: false, attack: true, rollsCheck: false, targetUuids: [] });
  equal("E …an innate cast with no check takes the damage but no penalty (Q158)", g2.modifiers.filter((m) => m.label === "Arcane Feedback").length, 0);
  ct.document.disposition = 1;
  const g3 = await GT.runSpellCheckGates({ actor: caster, spell: { name: "Cure" }, spellData: {}, rollsCheck: true, targetUuids: [] });
  equal("E …not offered on an ally's cast", g3.modifiers.filter((m) => m.label === "Arcane Feedback").length, 0);
  ok("E the step lets go of its damage watch (no listener left)", (hookList.get("trgPrimeDamageApplied") ?? []).length === 0);
}
// Regions: Mycelium, Zone Disruption, Primal Snap.
{
  reset();
  const caster = makeActor("Druid"), victim = makeActor("Victim");
  const vt = makeToken("v", victim, { x: 0, y: 0, disposition: -1 }), dt = makeToken("d", caster, { x: 300, y: 0 });
  canvas.tokens.placeables = [vt, dt];
  const myc = makeRegion("Arcane Mycelium Area");
  await auto.onSpellSettledB7({ actor: caster, spell: S["Arcane Mycelium"], cast: true, saveDC: 19, warpMods: { unlocks: [R.MYCELIUM_REACTIVE_UNLOCK] } });
  equal("E Arcane Mycelium's Region is stamped with the caster, DC and warp", myc.flags[MOD][auto.REGION_FLAG].dc, 19);
  equal("E …and gives off dim light: the core's Region `emitsLight` at level 5", myc.flags[SYS]?.emitsLight, { level: 5, label: "Arcane Mycelium (dim light)" });
  // FOUND LIVE ON 0.16.0: TRG Prime renames a difficult-terrain area "<spell> (difficult terrain)".
  equal("E the spell's Region is found by either of TRG Prime's names, and no other spell's",
    [auto.regionNamedFor("Arcane Mycelium Area", "Arcane Mycelium"), auto.regionNamedFor("Arcane Mycelium (difficult terrain)", "Arcane Mycelium"), auto.regionNamedFor("Arcane Myceliums (difficult terrain)", "Arcane Mycelium"), auto.regionNamedFor("Primal Snap Area", "Arcane Mycelium"), auto.regionNamedFor("Arcane Mycelium Area", "")],
    [true, true, false, false, false]);
  {
    const renamed = makeRegion("Arcane Mycelium (difficult terrain)");
    await auto.onSpellSettledB7({ actor: caster, spell: S["Arcane Mycelium"], cast: true, saveDC: 21, warpMods: {} });
    equal("E …the renamed Region is stamped and lit, as the core names it", [renamed.flags[MOD]?.[auto.REGION_FLAG]?.dc, renamed.flags[SYS]?.emitsLight?.level], [21, 5]);
  }
  {
    const L = await quiet(() => import(sys("module", "light.mjs")));
    equal("E …which the core reads as at least Dim Light inside: darkness to 5, bright stays 8", [L.withEmittedLight(2, L.regionEmittedLight([myc.flags[SYS].emitsLight])), L.withEmittedLight(8, L.regionEmittedLight([myc.flags[SYS].emitsLight]))], [5, 8]);
  }
  const g = await GT.runSpellCheckGates({ actor: victim, spell: { name: "Bolt" }, spellData: {}, rollsCheck: true, targetUuids: [] });
  equal("E the real gates: a cast inside the reactive mycelium — 2d6 essence, basic Fortitude at DC 19", [calls.saves.at(-1), g.lines.some((l) => /Arcane Mycelium/.test(l))], [{ caster: "Druid", target: "Victim", save: "fortitude", dc: 19, label: "Arcane Mycelium", formula: "2d6", type: "essence", base: "" }, true]);
  myc.flags[MOD][auto.REGION_FLAG].unlocks = [];
  const n = calls.saves.length;
  await GT.runSpellCheckGates({ actor: victim, spell: { name: "Bolt" }, spellData: {}, rollsCheck: true, targetUuids: [] });
  equal("E …not without the warp", calls.saves.length, n);

  reset();
  canvas.tokens.placeables = [vt, dt];
  const zr = makeRegion("Zone Disruption Area");
  await auto.onSpellSettledB7({ actor: caster, spell: S["Zone Disruption"], cast: true, saveDC: 23, warpMods: { unlocks: [R.ZONE_FUMBLE_UNLOCK] } });
  equal("E Zone Disruption's Region: stamped, and H8's castingZone (+2 Concentration)", [zr.flags[MOD][auto.REGION_FLAG].key, zr.flags[SYS].castingZone.concentrationDC, zr.flags[SYS].castingZone.label], ["zoneDisruption", 2, "Zone Disruption"]);
  const gz = await GT.runSpellCheckGates({ actor: victim, spell: { name: "Bolt" }, spellData: {}, innate: true, rollsCheck: false, targetUuids: [] });
  equal("E the real gates: inside, disadvantage and the innate check (Q154)", [gz.disadvantage, gz.innateCheck], [true, true]);
  const fz = await FR.fumbleModifiersFrom({ actor: victim, check: { type: "spellcraft" }, cast: {} });
  equal("E the real fumble collector: the warp rolls twice, the higher (disadvantage)", JSON.stringify(fz).includes("disadvantage"), true);
  zr.flags[MOD][auto.REGION_FLAG].unlocks = [];
  equal("E …not without the warp", JSON.stringify(await FR.fumbleModifiersFrom({ actor: victim, check: { type: "spellcraft" }, cast: {} })).includes("Zone Disruption"), false);
  zr.flags[MOD][auto.REGION_FLAG].unlocks = [R.ZONE_FUMBLE_UNLOCK];
  // A Critical's mark exempts; a later result for the same cast is dropped.
  const exempt = { name: "x", flags: { [MOD]: { [R.ZONE_EXEMPT_MARK]: { casterUuid: caster.uuid, castId: "z1" } } } };
  const [ex] = await victim.createEmbeddedDocuments("ActiveEffect", [exempt]);
  await auto.onEffectCreatedB7(ex);
  const [later] = await victim.createEmbeddedDocuments("ActiveEffect", [{ name: "y", flags: { [MOD]: { [R.ZONE_AFFECTED_MARK]: { casterUuid: caster.uuid, castId: "z1" } } } }]);
  await auto.onEffectCreatedB7(later);
  equal("E only the first result counts: the later mark is removed; the exempt creature is on the Region's list", [victim.effects.filter((e) => e.flags?.[MOD]?.[R.ZONE_AFFECTED_MARK]).length, zr.flags[SYS].castingZone.exempt], [0, [victim.uuid]]);
  const gx = await GT.runSpellCheckGates({ actor: victim, spell: { name: "Bolt" }, spellData: {}, rollsCheck: true, targetUuids: [] });
  equal("E …and the exempt creature casts freely", gx.disadvantage, false);

  reset();
  const snapper = makeActor("Sleet"), walker = makeActor("Walker");
  walker.system.combat.movement = { land: { base: 25 }, fly: { base: 20 }, swim: { base: 0 } };
  const wt = makeToken("w", walker, { x: 0, y: 0, disposition: -1 });
  canvas.tokens.placeables = [wt];
  const sr = makeRegion("Primal Snap Area");
  await auto.onSpellSettledB7({ actor: snapper, spell: S["Primal Snap"], cast: true, saveDC: 22, warpMods: { damageDice: "1d8" } });
  saveDegree = "failure";
  await auto.onCombatTurnB7({ combatant: { actor: walker, token: { object: wt } } }, { turn: 1 });
  const fx = walker.effects.find((e) => e.flags?.[MOD]?.source === "primalSnapSpeed");
  equal("E Primal Snap: at the start of a turn inside — basic Fortitude 7d8 cold at DC 22; a Failure: −10 status to each Speed it has, ended by healing (H11)", [calls.saves.at(-1).formula, calls.saves.at(-1).dc, calls.saves.at(-1).type, fx?.changes?.map((c) => `${c.key}=${c.value}`), fx?.flags?.[SYS]?.endsOnHeal], ["7d8", 22, "cold", ["system.combat.movement.land.status=-10", "system.combat.movement.fly.status=-10"], true]);
  await auto.onCombatTurnB7({ combatant: { actor: walker, token: { object: wt } } }, { turn: 2 });
  equal("E …it does not stack with itself (Q160)", walker.effects.filter((e) => e.flags?.[MOD]?.source === "primalSnapSpeed").length, 1);
  const H = await quiet(() => import(sys("module", "magic", "heal-ends.mjs")));
  equal("E …and the core's heal rule ends it on any HP regained", H.effectsEndedByHealing([{ id: fx.id, flags: fx.flags }], 10, 11), [fx.id]);
  saveDegree = "partial";
  const w3 = makeActor("Halved"); const ht = makeToken("hh", w3); canvas.tokens.placeables = [ht];
  await auto.onCombatTurnB7({ combatant: { actor: w3, token: { object: ht } } }, { turn: 1 });
  equal("E …a basic save's Partial (half damage) is not a failed save: no speed penalty", w3.effects.length, 0);
  saveDegree = "success";
  const w2 = makeActor("Lucky"); const lt = makeToken("l", w2); canvas.tokens.placeables = [lt];
  await auto.onCombatTurnB7({ combatant: { actor: w2, token: { object: lt } } }, { turn: 1 });
  equal("E …a Success takes the damage only", w2.effects.length, 0);
  inRegion = false;
  const nsav = calls.saves.length;
  await auto.onCombatTurnB7({ combatant: { actor: w2, token: { object: lt } } }, { turn: 1 });
  equal("E …a creature outside rolls nothing", calls.saves.length, nsav);
  inRegion = true; saveDegree = "failure";
}
// Invoke True Name, through the real gate, check and damage collectors.
{
  reset();
  const caster = makeActor("Namer", { level: 10, cl: 9 }), target = makeActor("Named");
  const tt = makeToken("t", target, { disposition: -1 }); canvas.tokens.placeables = [tt];
  await target.createEmbeddedDocuments("ActiveEffect", [{ name: "Invoke True Name", flags: { [MOD]: { [R.TRUE_NAME_MARK]: { casterUuid: caster.uuid, casterLevel: 9, castId: "c1" } } } }]);
  const g = await GT.runSpellCheckGates({ actor: caster, spell: { name: "Bolt" }, spellData: {}, attack: true, rollsCheck: true, targetUuids: [target.uuid] });
  equal("E the real gates: a spell attack on the named creature adds its flat-footed loss (Dex 2 + dodge 1), on the attack only", g.modifiers.filter((m) => /Invoke True Name/.test(m.label)).map((m) => [m.value, m.attackOnly]), [[3, true]]);
  const other = makeActor("Other");
  const g2 = await GT.runSpellCheckGates({ actor: other, spell: { name: "Bolt" }, spellData: {}, attack: true, rollsCheck: true, targetUuids: [target.uuid] });
  equal("E …not for another caster's attack", g2.modifiers.filter((m) => /Invoke True Name/.test(m.label)).length, 0);
  const check = { actor: target, type: "save", subject: "will", label: "Will", modifiers: [], sourceUuid: caster.uuid, dc: 20 };
  const BIAS = { advantage: "advantage", disadvantage: "disadvantage", normal: "normal" };
  await RW.checkReactionsBefore(check, BIAS);
  equal("E the real check collector: its save against the namer's spell takes −4 circumstance at CL 9 (Q164)", check.modifiers.filter((m) => m.label === "Invoke True Name").map((m) => [m.value, m.type]), [[-4, "circumstance"]]);
  const ck2 = { actor: target, type: "save", subject: "will", label: "Will", modifiers: [], sourceUuid: other.uuid, dc: 20 };
  await RW.checkReactionsBefore(ck2, BIAS);
  equal("E …not against another's", ck2.modifiers.filter((m) => m.label === "Invoke True Name").length, 0);
  const GD = await quiet(() => import(sys("module", "combat", "granted-defences.mjs")));
  GD.resetGrantedDefences();
  const lines = await RW.damageReactionsBefore(target, { kind: "spell", types: ["fire"], sourceUuid: caster.uuid, spellName: "Bolt" });
  const CT = await quiet(() => import(sys("module", "creature-traits.mjs")));
  equal("E the real damage collector: weak to the first spell damage from the namer this turn", [lines.some((l) => /true name/.test(l)), CT.actorDefences({ combat: {}, parent: target }).weaknesses.has("fire")], [true, true]);
  GD.resetGrantedDefences();
  const again = await RW.damageReactionsBefore(target, { kind: "spell", types: ["fire"], sourceUuid: caster.uuid });
  equal("E …only the first time — kept on the caster, the named creature's mark not written", [again.some((l) => /true name/.test(l)), (caster.flags[MOD][auto.TRUE_NAME_SPENT] ?? []).length, Object.keys(target.effects[0].flags[MOD]).length], [false, 1, 1]);
}
// Planar Anchor, Flesh to Blossom's prelude, Eaog's Dispel.
{
  reset();
  const anchored = makeActor("Anchored");
  const anchorer = makeActor("Anchorer");
  await anchored.createEmbeddedDocuments("ActiveEffect", [{ name: "Planar Anchor", flags: { [MOD]: { [R.ANCHOR_MARK]: { casterUuid: anchorer.uuid, castId: "pa1" } } } }]);
  equal("E the real refusal collector: a Teleportation spell by the anchored creature is counteracted; another is not", [/counteracted/.test(await CH.castRefusalFrom({ actor: anchored, spell: { name: "Dimension Door", system: { traits: "Teleportation" } }, spellData: { traits: "Teleportation" } })), await CH.castRefusalFrom({ actor: anchored, spell: { name: "Fireball", system: { traits: "Fire" } }, spellData: { traits: "Fire" } })], [true, ""]);
  const mage = makeActor("Teleporter"); const at = makeToken("a", anchored); canvas.tokens.placeables = [at]; game.user.targets = new Set([at]);
  equal("E …and one cast at it", /Anchored is held/.test(await CH.castRefusalFrom({ actor: mage, spell: { name: "Teleport", system: { traits: "Teleportation" } }, spellData: { traits: "Teleportation" } })), true);
  anchored.isOwner = false;
  const markBefore = JSON.stringify(anchored.effects[0].flags);
  await auto.onSpellSettledB7({ actor: anchorer, spell: S["Planar Anchor"], cast: true, warpMods: { unlocks: [R.ANCHOR_VEIL_UNLOCK] }, saveResults: [{ target: anchored, degree: "failure" }] });
  equal("E the veil warp: invisibility is counteracted too — kept on the caster, the anchored creature's mark not written", [/invisible or incorporeal/.test(await CH.castRefusalFrom({ actor: anchored, spell: { name: "Invisibility", system: { traits: "Illusion" } }, spellData: { traits: "Illusion" } })), anchorer.flags[MOD][auto.ANCHOR_VEIL_FLAG], JSON.stringify(anchored.effects[0].flags) === markBefore], [true, ["pa1"], true]);
  anchored.isOwner = true;
  const blossom = makeItem(S["Flesh to Blossom"], mage);
  answers.push("poison");
  equal("E the real prelude collector: Flesh to Blossom asks acid or poison and the cast goes on, its item poison", [await CH.castPreludeFrom({ actor: mage, spell: blossom, options: {} }), blossom.system.damage.type], [null, "poison"]);
  answers.push(null);
  equal("E …a closed question casts nothing", await CH.castPreludeFrom({ actor: mage, spell: blossom, options: {} }), { handled: true, result: null });
  const crushed = makeActor("Crushed"); await crushed.createEmbeddedDocuments("ActiveEffect", [{ name: "Eaog Balls", flags: {} }]);
  const offers = await DM.offeredDispelModifiers({ actor: mage, target: crushed });
  const eaog = offers.find((o) => o.key === "eaeaogballs" || /Eaog/.test(o.label ?? ""));
  equal("E the real dispel offers: against Eaog Balls a tick for disadvantage (the core's bias)", [eaog?.optional, eaog?.bias], [true, "disadvantage"]);
  equal("E …none against a creature without it", (await DM.offeredDispelModifiers({ actor: mage, target: makeActor("Plain") })).some((o) => /Eaog/.test(o.label ?? "")), false);
}
// Arcane Bastion, through the real critical collector.
{
  reset();
  const mage = makeActor("Bastion");
  await mage.createEmbeddedDocuments("ActiveEffect", [{ name: "Arcane Bastion", flags: { [SYS]: { castId: "b1" } } }]);
  await auto.onSpellSettledB7({ actor: mage, spell: S["Arcane Bastion"], cast: true, warpMods: { bonusValue: 1 } });
  equal("E the settled cast records the cast and its steps (1 + a warp)", mage.flags[MOD][auto.BASTION_FLAG], { castId: "b1", steps: 2 });
  const low = await RW.criticalAfterReactionsFor({ target: mage, attacker: makeActor("Orc"), row: { effect: "Target is Unconscious." }, severity: "serious" });
  equal("E the real critical collector: an incapacitating injury is read 2 lower, and the shield ends — its effects gone though the cast was never registered (endActiveSpell would return null)", [low.steps, mage.effects.filter((e) => e.flags?.[SYS]?.castId === "b1").length, mage.flags[MOD][auto.BASTION_FLAG]], [-2, 0, undefined]);
  await mage.createEmbeddedDocuments("ActiveEffect", [{ name: "Arcane Bastion", flags: { [SYS]: { castId: "b2" } } }]);
  await mage.setFlag(MOD, auto.BASTION_FLAG, { castId: "b2", steps: 1 });
  equal("E …a stunning one is not lowered", (await RW.criticalAfterReactionsFor({ target: mage, row: { effect: "Target is Stunned 2." } })).steps, 0);
  await auto.onDeathGuardHeldB7({ actor: mage, label: "Arcane Bastion" });
  equal("E the 0 HP guard holding ends the spell (its resistance gone)", mage.effects.filter((e) => e.flags?.[SYS]?.castId === "b2").length, 0);
}
// Argent Reversal and Spectral Aegis, through the real cast-reaction collector.
{
  reset();
  const caster = makeActor("Hostile"), bearer = makeActor("Argent", { level: 10, cl: 10 });
  effectsGetter(bearer);
  const ct = makeToken("h", caster, { disposition: -1 }), bt = makeToken("b", bearer, { x: 200 });
  canvas.tokens.placeables = [ct, bt];
  await auto.onSpellSettledB7({ actor: bearer, spell: S["Argent Reversal"], cast: true, saveDC: 25, warpMods: { bonusValue: 1, unlocks: [] } });
  equal("E the sigil: two attempts (a warp), no absorb, its Save DC", ownCharge(bearer), { attempts: 2, absorb: false, saveDC: 25 });
  checkDegree = "success"; checkTotal = 31;
  const out = await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 6, castPP: 6, saveDC: 22 });
  equal("E the real cast reactions: Spellcraft against the cast's Save DC (22, H5's ctx); a Success turns it back at the bearer's total and Save DC", [calls.checks.at(-1).dc, out.turnBack, calls.spent.at(-1)?.label], [22, { checkTotal: 31, saveDC: 25, target: "" }, "Argent Reversal"]);
  equal("E …one attempt left", ownCharge(bearer).attempts, 1);
  checkDegree = "fumble";
  const fum = await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 6, castPP: 6, saveDC: 22 });
  equal("E …a Fumble: 4d10 essence, basic Fortitude; the sigil discharged", [calls.saves.at(-1).formula, calls.saves.at(-1).type, fum.turnBack, ownCharge(bearer)], ["4d10", "essence", null, null]);
  await auto.onSpellSettledB7({ actor: bearer, spell: S["Argent Reversal"], cast: true, saveDC: 25, warpMods: { unlocks: [R.ARGENT_ABSORB_UNLOCK] } });
  checkDegree = "critical"; bearer.system.resources.pp.value = 3;
  answers.push("");
  const abs = await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 7, castPP: 7, saveDC: 22 });
  equal("E …absorb warp: it lands on everyone but the bearer, who regains half its PP (3)", [abs.exclude, bearer.system.resources.pp.value], [[bearer.uuid], 6]);
  await auto.onSpellSettledB7({ actor: bearer, spell: S["Argent Reversal"], cast: true, saveDC: 25, warpMods: {} });
  const n = asked.length;
  await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Big" }, spellData: {}, pp: 12, castPP: 12, saveDC: 22 });
  equal("E …not offered on a spell above the bearer's maximum PP per cast (Q153)", asked.length, n);
  bearer.conditions.add("blinded");
  await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 6, castPP: 6, saveDC: 22 });
  equal("E …nor by a bearer who cannot see its caster (Q153: blinded)", asked.length, n);
  bearer.conditions.delete("blinded"); ct.document.hidden = true;
  await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 6, castPP: 6, saveDC: 22 });
  equal("E …nor of a hidden caster", asked.length, n);
  ct.document.hidden = false;
  const near = makeToken("n", makeActor("Near"), { x: 100, disposition: -1 }), far = makeToken("f", makeActor("Far"), { x: 1000, disposition: -1 });
  canvas.tokens.placeables = [ct, bt, near, far];
  equal("E a Critical may turn it only on a creature within the original spell's range (30 ft) of its caster", auto.redirectChoices(bearer, ct, auto.rangeFeetOf("30 feet")).map(([, l]) => l), ["Its caster", "Argent", "Near"].filter((l) => l !== "Argent"));
  sent.length = 0; checkDegree = "success";
  await auto.onSpellSettledB7({ actor: bearer, spell: S["Argent Reversal"], cast: true, saveDC: 25, warpMods: { unlocks: [R.ARGENT_ABSORB_UNLOCK] } });
  bearer.isOwner = false;
  const ppBefore = bearer.system.resources.pp.value;
  canvas.tokens.placeables = [ct, bt];
  await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 8, castPP: 8, saveDC: 22 });
  await flush();
  equal("E …an absorb's refund (+4) is made in the step, on the bearer's own client: nothing is relayed", [sent.length, bearer.system.resources.pp.value - ppBefore], [0, 4]);
  // At most to the bearer's PP maximum.
  bearer.isOwner = true;
  await auto.onSpellSettledB7({ actor: bearer, spell: S["Argent Reversal"], cast: true, saveDC: 25, warpMods: { unlocks: [R.ARGENT_ABSORB_UNLOCK] } });
  bearer.system.resources.pp.max = bearer.system.resources.pp.value + 2;
  bearer.isOwner = false;
  await RW.castReactionsFor({ actor: caster, token: ct, spell: { name: "Bolt" }, spellData: {}, pp: 8, castPP: 8, saveDC: 22 });
  equal("E …and never above its PP maximum (2 short: +2, not +4)", bearer.system.resources.pp.value, bearer.system.resources.pp.max);
  delete bearer.system.resources.pp.max;
  bearer.isOwner = true;
  equal("E the GM side writes only the module's own state", [auto.writeRefusal({ kind: "effectFlag", effectId: "x", key: "hp" }, []), auto.writeRefusal({ kind: "addPP", amount: 4 }), auto.writeRefusal({ kind: "deleteEffects", ids: ["e1"] }, [{ id: "e1", flags: {} }])], ["not this module's flag", "unknown write", "not this module's effects"]);

  reset();
  const foe = makeActor("Foe Caster"), ward = makeActor("Warded");
  effectsGetter(ward);
  const ft = makeToken("f", foe, { disposition: -1 }), wt = makeToken("w", ward, { x: 300 });
  canvas.tokens.placeables = [ft, wt]; game.user.targets = new Set([wt]);
  await ward.createEmbeddedDocuments("ActiveEffect", [{ name: "Spectral Aegis", flags: { [SYS]: { castId: "sa1" } } }]);
  await auto.onSpellSettledB7({ actor: makeActor("Priest"), spell: S["Spectral Aegis"], cast: true, warpMods: { declareUses: 1 } });
  const ex = await RW.castReactionsFor({ actor: foe, token: ft, spell: { name: "Bolt" }, spellData: { category: "attack", area: "" }, pp: 6, castPP: 6, saveDC: 20 });
  equal("E the real cast reactions: a hostile targeted spell excludes the warded creature (H5); two absorbs, one left", [ex.exclude, ward.effects.find((e) => e.flags?.[MOD]?.source === auto.AEGIS_FLAG)?.flags[MOD][auto.AEGIS_FLAG].absorbs], [[ward.uuid], 1]);
  game.user.targets = new Set();
  reactorAnswers.push("yes");
  const area = await RW.castReactionsFor({ actor: foe, token: ft, spell: { name: "Fireball" }, spellData: { category: "save", area: "20-foot radius" }, pp: 6, castPP: 6, saveDC: 20 });
  equal("E …an area spell: its player says it is caught, it is left out; the last absorb ends the Aegis and its resistance", [area.exclude, ward.effects.filter((e) => e.flags?.[SYS]?.castId === "sa1" || e.flags?.[MOD]?.source === auto.AEGIS_FLAG).length], [[ward.uuid], 0]);
  await ward.createEmbeddedDocuments("ActiveEffect", [{ name: "Spectral Aegis (absorb)", flags: { [MOD]: { source: auto.AEGIS_FLAG, [auto.AEGIS_FLAG]: { absorbs: 1, ppLimit: 10 } } } }]);
  game.user.targets = new Set([wt]);
  const friend = makeActor("Friendly Caster"); const frt = makeToken("fr", friend, { x: 600, disposition: 1 });
  canvas.tokens.placeables = [ft, wt, frt];
  equal("E …an ally's spell is not absorbed (Q152: hostile only)", (await RW.castReactionsFor({ actor: friend, token: frt, spell: { name: "Bolt" }, spellData: { category: "attack" }, pp: 6, castPP: 6 })).exclude, []);
  canvas.tokens.placeables = [ft, wt];
  ward.isOwner = false; sent.length = 0;
  const unowned = await RW.castReactionsFor({ actor: foe, token: ft, spell: { name: "Bolt" }, spellData: { category: "attack", area: "" }, pp: 6, castPP: 6, saveDC: 20 });
  await flush();
  equal("E …on a warded creature the caster's client does not own, the Aegis's end is the GM's write", [unowned.exclude, sent.some((m) => m.data?.op?.kind === "deleteEffects"), ward.effects.some((e) => e.flags?.[MOD]?.source === auto.AEGIS_FLAG)], [[ward.uuid], true, false]);
  ward.isOwner = true;
  await ward.createEmbeddedDocuments("ActiveEffect", [{ name: "Spectral Aegis (absorb)", flags: { [MOD]: { source: auto.AEGIS_FLAG, [auto.AEGIS_FLAG]: { absorbs: 1, ppLimit: 10 } } } }]);
  equal("E …a spell above its PP limit, or a beneficial one, passes", [(await RW.castReactionsFor({ actor: foe, token: ft, spell: { name: "Big" }, spellData: { category: "attack" }, pp: 11, castPP: 11 })).exclude, (await RW.castReactionsFor({ actor: foe, token: ft, spell: { name: "Haste" }, spellData: { category: "utility" }, pp: 6, castPP: 6 })).exclude], [[], []]);
}
function ownCharge(actor) { return actor.effects.find((e) => e.flags?.[MOD]?.source === auto.ARGENT_FLAG)?.flags[MOD][auto.ARGENT_FLAG] ?? null; }
// Mirror Reprise and Panic Transposition, through the real check and damage collectors.
{
  reset();
  const me = makeActor("Mirrored"), orc = makeActor("Orc");
  // A "1 hour (D)" cast registers (dismissible): its entry is the cast id; the spell lays no effect of its own.
  me.flags[SYS].activeSpells = [{ id: "m1", name: "Mirror Reprise" }];
  const AS = await quiet(() => import(sys("module", "magic", "active-spells.mjs")));
  equal("E the cast's entry, read as the core's getActiveSpells reads it", [auto.activeEntryFor(me, "Mirror Reprise")?.id, AS.getActiveSpells({ getFlag: (sc, k) => me.flags?.[sc]?.[k] })[0]?.id], ["m1", "m1"]);
  await auto.onSpellSettledB7({ actor: me, spell: S["Mirror Reprise"], cast: true, warpMods: {} });
  const mfx = () => me.effects.find((e) => e.flags?.[MOD]?.source === auto.MIRROR_FLAG);
  equal("E the waiting effect carries the cast's entry", mfx().flags[MOD][auto.MIRROR_FLAG].castId, "m1");
  me.isOwner = false;   // the attacker's client: the bearer is not its to write
  const GD = await quiet(() => import(sys("module", "combat", "granted-defences.mjs")));
  GD.resetGrantedDefences();
  await RW.damageReactionsBefore(me, { kind: "spell", types: ["fire"], sourceUuid: orc.uuid });
  await flush();
  equal("E the real damage collector: a spell's damage does not arm it (no warp)", mfx().flags[MOD][auto.MIRROR_FLAG].images, 0);
  GD.resetGrantedDefences();
  sent.length = 0;
  await RW.damageReactionsBefore(me, { kind: "weapon", types: ["slashing"], sourceUuid: orc.uuid });
  await flush();
  equal("E …an attack's does: three duplicates — written by the GM through the module socket (the attacker's client does not own the bearer)", [mfx().flags[MOD][auto.MIRROR_FLAG].images, sent.at(-1)?.data?.op?.kind, sent.at(-1)?.channel], [3, "effectFlag", "module.trg-eldritch-arts"]);
  d100 = 30;
  const hit = await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me });
  await flush();
  equal("E the real check collector: d100 30 ≥ 26 with three — the hit is a miss (H6); two left", [hit.missed, mfx().flags[MOD][auto.MIRROR_FLAG].images], [true, 2]);
  d100 = 33;
  const kept = await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me });
  await flush();
  equal("E …d100 33 < 34 with two: the hit stands", [Boolean(kept.missed), mfx().flags[MOD][auto.MIRROR_FLAG].images], [false, 2]);
  d100 = 99;
  await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me }); await flush();
  await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me }); await flush();
  equal("E …the last duplicate gone deletes the waiting effect and ends the registered cast", [Boolean(mfx()), me.flags[SYS].activeSpells.length], [false, 0]);
  me.isOwner = true;
  // The teleport warp is the bearer's, run where it is owned, and held to 10 feet.
  const tok = makeToken("me", me, { x: 0, y: 0 }); tok.center = { x: 50, y: 50 };
  canvas.tokens.placeables = [tok];
  nextClick = { x: 250, y: 50 };   // 10 ft: 200 px from the token's centre (50, 50)
  await auto.OWNER_TASKS_B7.mirrorStep(me, {});
  equal("E the teleport warp (on the bearer's client): a reaction, up to 10 ft", [calls.spent.at(-1)?.label, tok.document.x], ["Mirror Reprise", 200]);
  nextClick = { x: 600, y: 50 };
  await auto.OWNER_TASKS_B7.mirrorStep(me, {});
  equal("E …a click beyond 10 ft moves nothing", tok.document.x, 200);
  game.user.isGM = false; sent.length = 0;
  await auto.forOwner(makeActor("Someone's PC"), "mirrorStep", {});
  equal("E …a client that does not act for the bearer sends the task to its owner", sent.at(-1)?.data?.kind, "owner");
  game.user.isGM = true;
  // The teleport warp through the real check collector, on a client that is neither the bearer's nor the GM's.
  {
    const step = makeActor("Stepper"), foe2 = makeActor("Foe");
    await auto.onSpellSettledB7({ actor: step, spell: S["Mirror Reprise"], cast: true, warpMods: { unlocks: [R.MIRROR_TELEPORT_UNLOCK] } });
    const sfx = step.effects.find((e) => e.flags?.[MOD]?.source === auto.MIRROR_FLAG);
    sfx.flags[MOD][auto.MIRROR_FLAG].images = 3;
    step.isOwner = false; game.user.isGM = false; sent.length = 0;
    const spentBefore = calls.spent.length;
    d100 = 99;
    await RW.checkReactionsAfter({ actor: foe2, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: step });
    equal("E …a diverted attack sends the bearer's step to its owner; the attacker's client asks nothing and spends no reaction", [sent.some((m) => m.data?.kind === "owner" && m.data?.task === "mirrorStep"), calls.spent.length - spentBefore], [true, 0]);
    game.user.isGM = true; await flush();
  }

  reset();
  const runner = makeActor("Runner"), brute = makeActor("Brute");
  runner.items.push(makeItem(S["Panic Transposition"], runner));
  castResult = { cast: true, warpMods: { unlocks: [R.PANIC_RESIST_UNLOCK, R.PANIC_UNSEEN_UNLOCK] } };
  castSettledDC = 18;
  const rt = makeToken("r", runner, { x: 0, y: 0 }); rt.center = { x: 50, y: 50 };
  const other = makeToken("o", makeActor("Bystander"), { x: 200, y: 0 });
  canvas.tokens.placeables = [rt, other];
  nextClick = { x: 250, y: 50 };   // 10 ft away, onto the bystander's square
  const hitAt = () => RW.checkReactionsAfter({ actor: brute, outcome: { degree: { key: "success" }, total: 22 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: runner });
  const a = await hitAt();
  equal("E the real check collector: hit, asked, cast as a reaction at her own token; the hit stands; nothing written on her", [asked.at(-1)?.title, calls.casts.at(-1)?.ids, Boolean(a.missed), runner.flags[MOD][auto.PANIC_FLAG]], ["Panic Transposition — Runner", ["r"], false, undefined]);
  equal("E L7324 \"After resolving the triggering attack, you teleport\": at the hit she has not moved and nothing is asked of her client", [rt.document.x, calls.spent.length, calls.saves.filter((x) => x.label === "Panic Transposition").length], [0, 0, 0]);
  GD.resetGrantedDefences();
  const res = await RW.damageReactionsBefore(runner, { kind: "weapon", types: ["slashing"], sourceUuid: brute.uuid });
  equal("E the real damage collector: the warp's resistance to the triggering attack, and still she has not moved", [res.some((l) => /resists the triggering attack/.test(l)), rt.document.x], [true, 0]);
  await auto.onStrikeResolvedB7({ attacker: brute, target: runner, hits: true, melee: true, resolved: true });
  equal("E …the Strike resolved (its damage dealt): now she teleports; the occupied square: 2d6 essence at the Panic cast's own settled Save DC (18, castSpell returns none)", [rt.document.x, calls.saves.at(-1)?.formula, calls.saves.at(-1)?.dc], [200, "2d6", 18]);
  GD.resetGrantedDefences();
  equal("E …nothing is left pending: no resistance to the next blow", [auto.panicPendingFor(runner), (await RW.damageReactionsBefore(runner, { kind: "weapon", types: ["slashing"], sourceUuid: brute.uuid })).some((l) => /resists/.test(l))], [null, false]);
  // The attacker's client does not act for her: it relays the teleport to her owner, after the Strike, not at the hit.
  rt.document.x = 0; nextClick = { x: 250, y: 50 };
  castResult = { cast: true, warpMods: { unlocks: [] } };
  await hitAt();
  runner.isOwner = false; game.user.isGM = false; sent.length = 0;
  await RW.damageReactionsBefore(runner, { kind: "weapon", types: ["slashing"], sourceUuid: brute.uuid });
  const relayed = () => sent.filter((m) => m.data?.kind === "owner" && m.data?.task === "panicTeleport");
  equal("E …on a client that does not own her: nothing sent at the hit or its damage", relayed().length, 0);
  await auto.onStrikeResolvedB7({ attacker: brute, target: runner, hits: true, melee: true, resolved: true });
  equal("E …the Strike resolved: the teleport is sent to her owner over the module socket (with the Panic cast's DC), and the record cleared", [relayed().length, relayed()[0]?.data?.actorUuid, relayed()[0]?.data?.data?.dc, rt.document.x, auto.panicPendingFor(runner)], [1, runner.uuid, 18, 0, null]);
  game.user.isGM = true; runner.isOwner = true; await flush(); sent.length = 0;
  rt.document.x = 0;
  // A Strike never resolved (refused or cancelled): cleared, nothing sent.
  nextClick = { x: 250, y: 50 };
  await hitAt();
  await auto.onStrikeResolvedB7({ attacker: brute, target: runner, hits: false, melee: true, resolved: false });
  equal("E …a Strike never resolved: the record cleared, no teleport", [auto.panicPendingFor(runner), rt.document.x], [null, 0]);
  // The bearer down at the end of the attack: cleared, nothing sent.
  await hitAt();
  runner.conditions.add("unconscious");
  await auto.onStrikeResolvedB7({ attacker: brute, target: runner, hits: true, melee: true, resolved: true });
  equal("E …a bearer down when the attack resolves: the record cleared, no teleport", [auto.panicPendingFor(runner), rt.document.x], [null, 0]);
  runner.conditions.delete("unconscious");
  // A spell attack's hit: no Strike hook — the attacker's settled cast is the point.
  await hitAt();
  equal("E …a spell attack's hit leaves it pending until its cast settles, with no teleport yet", [Boolean(auto.panicPendingFor(runner)), rt.document.x], [true, 0]);
  GD.resetGrantedDefences();
  equal("E …while pending, no resistance without the warp", (await RW.damageReactionsBefore(runner, { kind: "weapon", types: ["slashing"], sourceUuid: brute.uuid })).some((l) => /resists/.test(l)), false);
  await auto.onSpellSettledB7({ actor: brute, spell: { name: "Bolt", flags: {} }, cast: true });
  equal("E …the attacker's cast settled (its damage dealt): she teleports and the record is cleared", [rt.document.x, auto.panicPendingFor(runner)], [200, null]);
  rt.document.x = 0;
  await hitAt();
  await auto.onSpellSettledB7({ actor: brute, spell: { name: "Bolt", flags: {} }, cast: true, refunded: true });
  equal("E …a refunded cast: the record cleared, no teleport", [auto.panicPendingFor(runner), rt.document.x], [null, 0]);
  await hitAt();
  await auto.onSpellSettledB7({ actor: brute, spell: { name: "Bolt", flags: {} }, cast: false });
  equal("E …a cast that was not cast: the record cleared, no teleport", [auto.panicPendingFor(runner), rt.document.x], [null, 0]);
  ok("E its card and record keep the book's timing: the teleport once the attack has been resolved (L7324)", /once the attack has been resolved \(its damage dealt\), your player's client asks you/.test(S["Panic Transposition"].system.description) && /once the attack is resolved you teleport/.test(C.SPELL_AUTOMATION_B7["Panic Transposition"].what) && !/at once|at the hit/.test(S["Panic Transposition"].system.description));
  nextClick = { x: 50 + 20 * 31, y: 50 };   // 31 ft
  const before = rt.document.x;
  await auto.OWNER_TASKS_B7.panicTeleport(runner, { unlocks: [], dc: 18 });
  equal("E the teleport is held to 30 ft (31 ft refused)", rt.document.x, before);
  nextClick = { x: 50 + 20 * 60, y: 50 };
  await auto.OWNER_TASKS_B7.panicTeleport(runner, { unlocks: [R.PANIC_FAR_UNLOCK], dc: 18 });
  equal("E …60 ft with the warp", rt.document.x, 20 * 60);
}
// Spirit Arrow.
{
  reset();
  const archer = makeActor("Archer"), deer = makeActor("Deer");
  effectsGetter(archer);
  await auto.onSpellSettledB7({ actor: archer, spell: S["Spirit Arrow"], cast: true, saveDC: 20, warpMods: { bonusValue: 2 } });
  equal("E the settled cast: the spell DC and two more arrows", archer.flags[MOD][auto.SPIRIT_FLAG], { dc: 20, left: 2 });
  const rider = { name: "Spirit Arrow", flags: { [SYS]: { strikeRider: { label: "Spirit Arrow", dice: "6d6", replacesDamage: true, flat: true } } } };
  const [fx] = await archer.createEmbeddedDocuments("ActiveEffect", [rider]);
  await fx.delete(); await auto.onEffectDeletedB7(fx);
  checkMargin = -5; answers.push("Trip");
  await auto.onStrikeResolvedB7({ attacker: archer, target: deer, hits: true, melee: false, total: 27 });
  equal("E a hit: the chosen Trip resolved at the attack total by the core (3.692.0)", calls.atTotal?.at(-1), { actor: "Archer", target: "Deer", actionKey: "tripAttack", total: 27, rounds: null });
  equal("E …its result on the card, and no 'by hand' line", [cards.at(-1)?.lines?.some((l) => /tripAttack at 27/.test(l)), cards.at(-1)?.lines?.some((l) => /by hand/.test(l))], [true, false]);
  equal("E a hit: the next arrow nocked; the manoeuvre asked; Will at DC 20, failed by 5: frightened 2", [archer.effects.filter((e) => e.flags?.[SYS]?.strikeRider?.label === "Spirit Arrow").length, archer.flags[MOD][auto.SPIRIT_FLAG].left, calls.checks.at(-1), calls.conditions.at(-1)], [1, 1, { actor: "Deer", type: "save", subject: "will", dc: 20, sourceUuid: archer.uuid }, { target: "Deer", tags: [{ key: "frightened", value: 2 }] }]);
  // END TO END AGAINST THE CORE (Graham's "Flat 6d6"): the archer's effect as the spell lays it, read by the
  // Strike's own reader, and the Strike's flat formula — the 6d6 alone, doubled on a serious critical.
  const SRW = await quiet(() => import(sys("module", "magic", "strike-riders-workflow.mjs")));
  const SR = await quiet(() => import(sys("module", "magic", "strike-riders.mjs")));
  const AT = await quiet(() => import(sys("module", "combat", "attack.mjs")));
  const laid = { items: [], getFlag: () => ({}), appliedEffects: [{ id: "sa", flags: { [SYS]: { strikeRider: SR.normaliseStrikeRider(S["Spirit Arrow"].system.effects[0]) } } }] };
  const rep = SRW.strikeDamageReplacement(laid, { system: { attackMode: "missile" }, name: "Longbow", type: "weapon" });
  equal("E Spirit Arrow end to end: the bow's Strike takes 6d6 piercing, flat; a sword's does not", [rep?.dice, rep?.damageType, rep?.flat, SRW.strikeDamageReplacement(laid, { system: { attackMode: "melee" }, name: "Sword", type: "weapon" })], ["6d6", "piercing", true, null]);
  equal("E …the Strike's flat formula is the 6d6 and nothing else; a serious critical doubles it as weapon damage", [AT.flatReplacementFormula(rep.dice), AT.flatReplacementFormula(rep.dice, { critical: "serious" }) !== AT.flatReplacementFormula(rep.dice), AT.buildWeaponDamageFormula(rep.dice, { bab: 12, quality: "superior" }) !== AT.flatReplacementFormula(rep.dice)], ["6d6", true, true]);
  ok("E …and the Strike rolls it when the replacement says flat", /replacingFlat = replacing\.flat === true;/.test(fs.readFileSync(path.join(SYSTEM_ROOT, "module", "combat", "attack-workflow.mjs"), "utf8")));
  const n = calls.checks.length;
  await auto.onStrikeResolvedB7({ attacker: archer, target: deer, hits: true, melee: false });
  equal("E …a Strike that spent no arrow asks nothing", calls.checks.length, n);
  const [fx2] = await archer.createEmbeddedDocuments("ActiveEffect", [rider]);
  await fx2.delete(); await auto.onEffectDeletedB7(fx2);
  await auto.onStrikeResolvedB7({ attacker: archer, target: deer, hits: true, melee: true });
  equal("E …nor a melee Strike", calls.checks.length, n);
}
// Bouncy Body, Chronoweave, Metamagic Resonance.
{
  reset();
  const mage = makeActor("Caster"), friend = makeActor("Friend"), foe = makeActor("Foe");
  const mt = makeToken("m", mage, { x: 0 }), ft = makeToken("f", friend, { x: 100 }), et = makeToken("e", foe, { x: 200, disposition: -1 });
  canvas.tokens.placeables = [mt, ft, et]; game.user.targets = new Set([ft]);
  await auto.onSpellSettledB7({ actor: mage, spell: S["Bouncy Body"], cast: true, warpMods: { durationText: "1 hour" } });
  const FD = await quiet(() => import(sys("module", "focus-declarations.mjs")));
  const DCR = await quiet(() => import(sys("module", "declaration-carriers.mjs")));
  equal("E Bouncy Body: the core reads its fall reduction off the effect (20 ft), for the hour", [FD.declaredFallReduction(DCR.declarationCarriers({ appliedEffects: friend.effects, items: [] })).feet, friend.effects[0].duration.seconds], [20, 3600]);
  checkDegree = "fumble";
  const isQuick = (a) => a.effects.some((e) => e.flags?.[MOD]?.source === "chronoweave" && (e.statuses ?? []).includes("quickened"));
  const slowedOf = (a) => a.effects.find((e) => e.flags?.[MOD]?.source === "chronoweave" && (e.statuses ?? []).includes("slowed"));
  await auto.onSpellSettledB7({ actor: mage, spell: S.Chronoweave, cast: true, saveDC: 24, warpMods: { unlocks: [R.CHRONO_SLOW_UNLOCK] } });
  equal("E Chronoweave's warp: the enemy saves Fortitude once, then is immune to this casting (for its duration); the ally is not asked", [calls.checks.map((c) => c.actor), calls.immunity.at(-1)], [["Foe"], { target: "Foe", key: "Chronoweave", seconds: 60 }]);
  equal("E Q159: you and the ally inside are quickened while inside; the enemy slowed 2 while inside — each for the spell's minute", [isQuick(mage), isQuick(friend), isQuick(foe), slowedOf(foe)?.flags?.[SYS]?.value, friend.effects.find((e) => e.flags?.[MOD]?.source === "chronoweave")?.duration?.seconds], [true, true, false, 2, 60]);
  const CR = await quiet(() => import(sys("module", "conditions", "registry.mjs")));
  ok("E …as statuses the core's condition reader takes (quickened, slowed with its value)", Boolean(CR.CONDITIONS.quickened) && CR.CONDITIONS.slowed?.valued === true);
  await moveV14(ft, { x: 900 }, auto.onTokenMovedB7);
  equal("E …the ally who leaves loses it", isQuick(friend), false);
  await moveV14(ft, { x: 100 }, auto.onTokenMovedB7);
  equal("E …and has it again on coming back", isQuick(friend), true);
  await moveV14(ft, { x: 500 }, auto.onTokenMovedB7);
  equal("E …at 25 ft the ally is outside the 20-ft emanation", isQuick(friend), false);
  await moveV14(ft, { x: 100 }, auto.onTokenMovedB7);
  await moveV14(et, { x: 900 }, auto.onTokenMovedB7);
  equal("E …the enemy who leaves is no longer slowed", Boolean(slowedOf(foe)), false);
  placeEnd(et.document, { x: 150 }); et.center.x = 200;  // V14: a token already moved is placed by its recorded end
  await auto.onSpellSettledB7({ actor: mage, spell: S.Chronoweave, cast: true, saveDC: 24, warpMods: { unlocks: [R.CHRONO_SLOW_UNLOCK] } });
  equal("E …an immune enemy is not asked again", calls.checks.length, 1);
  game.time.worldTime = 61;
  await auto.onCombatSyncB7({}, { turn: 1 });
  equal("E …the minute over: every Chronoweave effect is taken back and the record cleared", [isQuick(mage), isQuick(friend), mage.flags[MOD][auto.CHRONO_FLAG]], [false, false, undefined]);
  game.time.worldTime = 0;
  // Metamagic Resonance: keyed on its sustained cast's active-spell entry (the core's registry).
  mage.flags[SYS].activeSpells = [{ id: "mr1", name: "Metamagic Resonance", sustained: true }];
  answers.push("empower spell");
  await auto.onSpellSettledB7({ actor: mage, spell: S["Metamagic Resonance"], cast: true, warpMods: { unlocks: [R.RESONANCE_HALF_UNLOCK] }, spellData: S["Metamagic Resonance"].system });
  const lent = friend.effects.find((e) => e.flags?.[SYS]?.lentMetamagic);
  equal("E Metamagic Resonance: the ally within 30 ft is lent the chosen feat at half, for the spell's minute; the enemy is not; keyed on the cast's entry", [lent?.flags[SYS].lentMetamagic, lent?.duration?.seconds, foe.effects.some((e) => e.flags?.[SYS]?.lentMetamagic), mage.flags[MOD][auto.RESONANCE_FLAG].castId], [{ key: "empower spell", costFactor: 0.5, label: "Metamagic Resonance", from: mage.uuid }, 60, false, "mr1"]);
  const LM = await quiet(() => import(sys("module", "magic", "lent-metamagic.mjs")));
  equal("E …the core reads the lend (H9)", LM.lentMetamagicOf([{ id: lent.id, flags: lent.flags }], "")[0]?.key, "empower spell");
  {
    // THE CHANGE ON A SUSTAIN (TRG Prime 3.692.0's trgPrimeSpellSustained): not offered without the option.
    const n = cards.length;
    answers.push("easpellweaverextend");
    await auto.onSpellSustainedB7({ actor: mage, castId: "mr1" });
    equal("E Metamagic Resonance without the change option: a Sustain asks nothing", [cards.length, mage.flags[MOD][auto.RESONANCE_FLAG].key, answers.length], [n, "empower spell", 1]);
    answers.length = 0;
    mage.flags[MOD][auto.RESONANCE_FLAG].swap = true;
    answers.push("easpellweaverextend");
    await auto.onSpellSustainedB7({ actor: mage, castId: "other" });
    equal("E …nor another cast's Sustain", mage.flags[MOD][auto.RESONANCE_FLAG].key, "empower spell");
    answers.length = 0;
    answers.push("easpellweaverextend");
    await auto.onSpellSustainedB7({ actor: mage, castId: "mr1" });
    const lent2 = friend.effects.filter((e) => e.flags?.[SYS]?.lentMetamagic);
    equal("E …with it, its own Sustain changes the feat and the ally's lend follows", [mage.flags[MOD][auto.RESONANCE_FLAG].key, lent2.length, lent2[0]?.flags[SYS].lentMetamagic.key], ["easpellweaverextend", 1, "easpellweaverextend"]);
    answers.push("empower spell");
    await auto.onSpellSustainedB7({ actor: mage, castId: "mr1" });
    answers.length = 0;
    answers.push("empower spell");
    await auto.onSpellSettledB7({ actor: mage, spell: S["Metamagic Resonance"], cast: true, warpMods: { unlocks: [R.RESONANCE_HALF_UNLOCK, R.RESONANCE_SWAP_UNLOCK] }, spellData: S["Metamagic Resonance"].system });
    equal("E …the change option is recorded when it is bought, and not otherwise", mage.flags[MOD][auto.RESONANCE_FLAG].swap, true);
    mage.flags[MOD][auto.RESONANCE_FLAG].swap = false;
  }
  await moveV14(et, { x: 210 }, auto.onTokenMovedB7);
  equal("E …a token's move does not end it while its cast runs", [Boolean(mage.flags[MOD][auto.RESONANCE_FLAG]), friend.effects.some((e) => e.flags?.[SYS]?.lentMetamagic)], [true, true]);
  friend.isOwner = false; sent.length = 0;
  await moveV14(ft, { x: 900 }, auto.onTokenMovedB7);
  await flush();
  equal("E …and takes it back when the ally leaves the aura — the GM's write for a creature the caster does not own", [friend.effects.some((e) => e.flags?.[SYS]?.lentMetamagic), sent.some((m) => m.data?.op?.kind === "deleteEffects")], [false, true]);
  friend.isOwner = true;
  mage.flags[SYS].activeSpells = [];
  await moveV14(ft, { x: 900 }, auto.onTokenMovedB7);
  equal("E …the cast no longer in the registry, the aura's record is cleared", mage.flags[MOD][auto.RESONANCE_FLAG], undefined);
}

// The second review's probes (P1–P6) and its gaps, as regression tests.
{
  reset();
  // P1: a forged cast id deletes nothing; a forged flag value is refused.
  const boss = makeActor("Boss"); effectsGetter(boss);
  const [stone] = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Stoneskin (core spell)", flags: { [SYS]: { castId: "zz" } } }]);
  const [plain] = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Rage", flags: {} }]);
  const [sig] = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Argent", flags: { [MOD]: { source: "argentReversal", argentReversal: { attempts: 2, saveDC: 25 } } } }]);
  const [aeg] = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Aegis", flags: { [MOD]: { source: "spectralAegis", spectralAegis: { absorbs: 2, ppLimit: 10, castId: "ag" } } } }]);
  const [aegRes] = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Aegis resistance", flags: { [SYS]: { castId: "ag" } } }]);
  boss.isOwner = false;
  const gm = async (op) => { pending.push(() => auto.onBlock7Socket({ action: auto.B7_ACTION, kind: "write", actorUuid: boss.uuid, op })); await flush(); };
  uuidMap.set(boss.uuid, boss);
  await gm({ kind: "deleteEffects", ids: [plain.id] });
  await gm({ kind: "deleteEffects", ids: [stone.id], castId: "zz" });
  equal("E P1 the GM relay: a plain effect and a core spell's effect named by a forged cast id are both kept", [boss.effects.some((e) => e.id === plain.id), boss.effects.some((e) => e.id === stone.id)], [true, true]);
  await gm({ kind: "effectFlag", effectId: sig.id, key: "argentReversal", value: { attempts: 99, absorb: true, saveDC: 1 } });
  await gm({ kind: "effectFlag", effectId: sig.id, key: "argentReversal", value: { attempts: 1, saveDC: 1 } });
  await gm({ kind: "effectFlag", effectId: aeg.id, key: "argentReversal", value: { attempts: 1, saveDC: 25 } });
  equal("E P1 …a forged flag value, a changed field beside the counter, and a key not the effect's own source: all refused", [sig.flags[MOD].argentReversal, aeg.flags[MOD].argentReversal], [{ attempts: 2, saveDC: 25 }, undefined]);
  await gm({ kind: "effectFlag", effectId: sig.id, key: "argentReversal", value: { attempts: 1, saveDC: 25 } });
  boss.isOwner = true;
  const [twoKeys] = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Aegis2", flags: { [MOD]: { source: "spectralAegis", spectralAegis: { absorbs: 1 }, argentReversal: { attempts: 2 } } } }]);
  boss.isOwner = false;
  await gm({ kind: "effectFlag", effectId: twoKeys.id, key: "argentReversal", value: { attempts: 1 } });
  equal("E P1 …a key that is not the effect's own source, even one it carries: refused", twoKeys.flags[MOD].argentReversal.attempts, 2);
  equal("E P1 …a counter down by one, nothing else changed: written", sig.flags[MOD].argentReversal, { attempts: 1, saveDC: 25 });
  await gm({ kind: "effectFlag", effectId: sig.id, key: "argentReversal", value: { attempts: 1, saveDC: 25 } });
  await gm({ kind: "effectFlag", effectId: sig.id, key: "argentReversal", value: { attempts: 3, saveDC: 25 } });
  equal("E P1 …not the same value again, nor up", sig.flags[MOD].argentReversal.attempts, 1);
  equal("E P1 …the pure rule: Mirror Reprise armed 0 → 3 once, not 3 → 3, not 1 → 3; counters only down by one", [auto.flagChangeAllowed("mirrorReprise", { images: 0, castId: "m" }, { images: 3, castId: "m" }), auto.flagChangeAllowed("mirrorReprise", { images: 1 }, { images: 3 }), auto.flagChangeAllowed("spectralAegis", { absorbs: 2 }, { absorbs: 0 }), auto.flagChangeAllowed("spectralAegis", { absorbs: 1, ppLimit: 10 }, { absorbs: 0, ppLimit: 99 }), auto.flagChangeAllowed("spectralAegis", { absorbs: 1 }, { absorbs: 0 })], [true, false, false, false, true]);
  await gm({ kind: "deleteEffects", ids: [aegRes.id], castId: "ag" });
  equal("E P1 …the Aegis's resistance alone, cast id in the payload: kept (the cast id is the GM's to find)", boss.effects.some((e) => e.id === aegRes.id), true);
  await gm({ kind: "deleteEffects", ids: [aeg.id, aegRes.id] });
  equal("E P1 …the Aegis's own effect with its resistance: the cast id read off the Aegis effect, both deleted", [boss.effects.some((e) => e.id === aeg.id), boss.effects.some((e) => e.id === aegRes.id), boss.effects.some((e) => e.id === stone.id)], [false, false, true]);
  // The GM side's own guards: a player's client writes nothing; a second GM writes nothing.
  const [sig2] = await (async () => { boss.isOwner = true; const m = await boss.createEmbeddedDocuments("ActiveEffect", [{ name: "Argent", flags: { [MOD]: { source: "argentReversal", argentReversal: { attempts: 2 } } } }]); boss.isOwner = false; return m; })();
  game.user.isGM = false;
  await gm({ kind: "effectFlag", effectId: sig2.id, key: "argentReversal", value: { attempts: 1 } });
  equal("E the socket: a player's client applies no relayed write", sig2.flags[MOD].argentReversal.attempts, 2);
  game.user.isGM = true; game.users.activeGM = { id: "u2" };
  await gm({ kind: "effectFlag", effectId: sig2.id, key: "argentReversal", value: { attempts: 1 } });
  equal("E …nor a GM who is not the active GM", sig2.flags[MOD].argentReversal.attempts, 2);
  game.users.activeGM = game.user;
  await gm({ kind: "effectFlag", effectId: sig2.id, key: "argentReversal", value: { attempts: 1 } });
  equal("E …the active GM does", sig2.flags[MOD].argentReversal.attempts, 1);
  // P2: no PP through the relay at all.
  const pc = makeActor("Other PC", { pp: 30 }); pc.system.resources.pp.max = 30; pc.isOwner = false; uuidMap.set(pc.uuid, pc);
  for (let i = 0; i < 3; i++) { pending.push(() => auto.onBlock7Socket({ action: auto.B7_ACTION, kind: "write", actorUuid: pc.uuid, op: { kind: "addPP", amount: 10 } })); await flush(); }
  equal("E P2 three relayed addPP: refused (no PP write is relayed)", pc.system.resources.pp.value, 30);
}
{
  // P3: Arcane Bastion on a creature the attacker's client does not own.
  reset();
  const npc = makeActor("NPC Mage"); effectsGetter(npc); uuidMap.set(npc.uuid, npc);
  await npc.createEmbeddedDocuments("ActiveEffect", [{ name: "Arcane Bastion", flags: { [SYS]: { castId: "b9" } } }]);
  await auto.onSpellSettledB7({ actor: npc, spell: S["Arcane Bastion"], cast: true, warpMods: { bonusValue: 1 } });
  npc.isOwner = false; sent.length = 0;
  const warned = []; const realWarn = console.warn; console.warn = (...a) => { warned.push(a.map(String).join(" ")); };
  let low;
  try { low = await RW.criticalAfterReactionsFor({ target: npc, attacker: makeActor("PC"), row: { effect: "Target is Unconscious." }, severity: "serious" }); } finally { console.warn = realWarn; }
  equal("E P3 …and no write on it was tried here (none refused)", warned.filter((w) => /permission|Arcane Bastion/.test(w)), []);
  equal("E P3 an unowned bearer (its writes throw here): the core still gets the lowered severity; the delete is relayed, the record not written here", [low.steps, sent.map((m) => m.data?.op?.kind), Boolean(npc.flags[MOD][auto.BASTION_FLAG])], [-2, ["deleteEffects"], true]);
  await flush();
  equal("E P3 …the GM deletes the Bastion's effects (its record names the cast) and clears the record with the last", [npc.effects.some((e) => e.flags?.[SYS]?.castId === "b9"), npc.flags[MOD][auto.BASTION_FLAG]], [false, undefined]);
}
{
  // P4: two token moves at once; a re-cast refreshes; a caster's token deleted.
  reset();
  const mage = makeActor("Caster"), friend = makeActor("Friend");
  const mt = makeToken("m", mage, { x: 0 }), ft = makeToken("f", friend, { x: 900 });
  canvas.tokens.placeables = [mt, ft];
  await auto.onSpellSettledB7({ actor: mage, spell: S.Chronoweave, cast: true, saveDC: 24, warpMods: {} });
  placeEnd(ft.document, { x: 50 }); ft.center.x = 100;  // V14: a token already moved is placed by its recorded end
  const realCreate = helpers.createEffectsOn;
  const slow = async (t, l) => { await new Promise((res) => setTimeout(res, 20)); return realCreate(t, l); };
  helpers.createEffectsOn = slow;
  await Promise.all([moveV14(ft, { x: 100 }, auto.onTokenMovedB7), moveV14(mt, { x: 0 }, auto.onTokenMovedB7)]);
  helpers.createEffectsOn = realCreate;
  const chronoOn = (a) => a.effects.filter((e) => e.flags?.[MOD]?.source === "chronoweave");
  equal("E P4 two token moves at once (a relay round trip each): the friend has one Chronoweave effect, not two", chronoOn(friend).length, 1);
  // A duplicate found is removed.
  const dup = JSON.parse(JSON.stringify({ name: chronoOn(friend)[0].name, flags: chronoOn(friend)[0].flags, statuses: chronoOn(friend)[0].statuses }));
  await friend.createEmbeddedDocuments("ActiveEffect", [dup]);
  await moveV14(ft, { x: 100 }, auto.onTokenMovedB7);
  equal("E P4 …a duplicate found is removed", chronoOn(friend).length, 1);
  // A move made while a sync runs: the sync runs again, so the last position wins.
  await moveV14(ft, { x: 900 }, auto.onTokenMovedB7);
  placeEnd(ft.document, { x: 50 }); ft.center.x = 100;  // V14: a token already moved is placed by its recorded end
  helpers.createEffectsOn = slow;
  const first = moveV14(ft, { x: 100 }, auto.onTokenMovedB7);
  await new Promise((res) => setTimeout(res, 5));
  placeEnd(ft.document, { x: 850 }); ft.center.x = 900;  // V14: a token already moved is placed by its recorded end
  const second = moveV14(ft, { x: 900 }, auto.onTokenMovedB7);
  await Promise.all([first, second]);
  helpers.createEffectsOn = realCreate;
  equal("E P4 …a move made during a sync runs it again: the friend who left in the meantime has none", chronoOn(friend).length, 0);
  await moveV14(ft, { x: 100 }, auto.onTokenMovedB7);
  // A re-cast refreshes the duration.
  game.time.worldTime = 40;
  await auto.onSpellSettledB7({ actor: mage, spell: S.Chronoweave, cast: true, saveDC: 24, warpMods: {} });
  equal("E a re-cast refreshes the effects' duration (a minute from now, not what was left of the first)", [chronoOn(friend).length, chronoOn(friend)[0].duration.seconds, chronoOn(friend)[0].duration.startTime], [1, 60, 40]);
  game.time.worldTime = 0;
  // The caster's token deleted: the allies lose quickened.
  canvas.tokens.placeables = [ft];
  await auto.onTokenDeletedB7(mt.document);
  equal("E the caster's token deleted: the allies' Chronoweave effects are removed", chronoOn(friend).length, 0);
  canvas.tokens.placeables = [mt, ft];
  await moveV14(mt, { x: 0 }, auto.onTokenMovedB7);
  equal("E …placed again within the minute: they are back", chronoOn(friend).length, 1);
  // The lends.
  mage.flags[SYS].activeSpells = [{ id: "mrx", name: "Metamagic Resonance", sustained: true }];
  answers.push("empower spell");
  await moveV14(ft, { x: 900 }, auto.onTokenMovedB7);
  await auto.onSpellSettledB7({ actor: mage, spell: S["Metamagic Resonance"], cast: true, warpMods: {}, spellData: S["Metamagic Resonance"].system });
  placeEnd(ft.document, { x: 50 }); ft.center.x = 100;  // V14: a token already moved is placed by its recorded end
  helpers.createEffectsOn = slow;
  await Promise.all([moveV14(ft, { x: 100 }, auto.onTokenMovedB7), moveV14(mt, { x: 0 }, auto.onTokenMovedB7)]);
  helpers.createEffectsOn = realCreate;
  const LM = await quiet(() => import(sys("module", "magic", "lent-metamagic.mjs")));
  equal("E P4 …and one Metamagic Resonance lend the core reads, not two (one spell a round)", LM.lentMetamagicOf(friend.effects, "r1").length, 1);
  // syncAll's actsFor guard: another client acts for this caster, so this one keeps nothing in step.
  const other = makeActor("Other's caster"), near = makeActor("Near ally");
  const ot = makeToken("o", other, { x: 2000 }), nt = makeToken("n", near, { x: 2100 });
  other.flags[MOD][auto.CHRONO_FLAG] = { feet: 20, until: 60, slowed: {}, castId: "" };
  other.testUserPermission = () => true;
  canvas.tokens.placeables = [mt, ft, ot, nt];
  const realFilter = game.users.filter;
  game.users.filter = (fn) => [{ id: "p9", active: true, isGM: false }].filter(fn);
  await moveV14(nt, { x: 2100 }, auto.onTokenMovedB7);
  game.users.filter = realFilter;
  equal("E syncAll: a caster another client acts for (its connected owner) is not synced here", chronoOn(near).length, 0);
  await moveV14(nt, { x: 2100 }, auto.onTokenMovedB7);
  equal("E …and is, here, when this client acts for it", chronoOn(near).length, 1);
}
{
  // P5: Panic — minutes of prompts between the hit and the resolution.
  reset();
  const runner = makeActor("Runner"), brute = makeActor("Brute"), other = makeActor("Other attacker");
  runner.items.push(makeItem(S["Panic Transposition"], runner));
  castResult = { cast: true, warpMods: { unlocks: [R.PANIC_RESIST_UNLOCK] } }; castSettledDC = 18;
  const rt = makeToken("r", runner, { x: 0, y: 0 }); rt.center = { x: 50, y: 50 };
  canvas.tokens.placeables = [rt]; nextClick = { x: 250, y: 50 };
  await RW.checkReactionsAfter({ actor: brute, outcome: { degree: { key: "success" }, total: 22 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: runner });
  const realNow = Date.now; Date.now = () => realNow() + 5 * 60 * 1000;   // five minutes of dialogs
  const GD = await quiet(() => import(sys("module", "combat", "granted-defences.mjs"))); GD.resetGrantedDefences();
  const res = await RW.damageReactionsBefore(runner, { kind: "weapon", types: ["slashing"], sourceUuid: brute.uuid });
  // Another attacker's attack resolving in the meantime leaves this one's record.
  await auto.onStrikeResolvedB7({ attacker: other, target: runner, hits: true, melee: true, resolved: true });
  const kept = Boolean(auto.panicPendingFor(runner));
  await auto.onStrikeResolvedB7({ attacker: brute, target: runner, hits: true, melee: true, resolved: true });
  Date.now = realNow;
  equal("E P5 five minutes of prompts: still resisted and teleported; another attacker's resolution left the record (matched on the attacker)", [res.some((l) => /resists/.test(l)), kept, rt.document.x], [true, true, 200]);
  // A record no attack ended is purged after ten minutes, by the next resolution.
  rt.document.x = 0;
  await RW.checkReactionsAfter({ actor: brute, outcome: { degree: { key: "success" }, total: 22 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: runner });
  Date.now = () => realNow() + 11 * 60 * 1000;
  await auto.onStrikeResolvedB7({ attacker: other, target: runner, hits: true, melee: true, resolved: true });
  Date.now = realNow;
  equal("E P5 …a record no attack ended in ten minutes is purged (and sends nothing)", [auto.panicPendingFor(runner), rt.document.x], [null, 0]);
}
{
  // P6: Mirror Reprise dismissed.
  reset();
  const me = makeActor("Mirrored"), orc = makeActor("Orc");
  me.flags[SYS].activeSpells = [{ id: "m7", name: "Mirror Reprise" }];
  await auto.onSpellSettledB7({ actor: me, spell: S["Mirror Reprise"], cast: true, warpMods: {} });
  const fx = me.effects.find((e) => e.flags?.[MOD]?.source === auto.MIRROR_FLAG);
  equal("E P6 the waiting effect carries the core's cast id (so the cast's end sweeps it)", fx.flags[SYS].castId, "m7");
  fx.flags[MOD][auto.MIRROR_FLAG].images = 3;
  await helpers.endSpellOf(me, "m7");
  d100 = 99;
  const hit = await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me });
  equal("E P6 dismissed: the waiting effect is gone, and the hit stands", [Boolean(me.effects.find((e) => e.flags?.[MOD]?.source === auto.MIRROR_FLAG)), Boolean(hit.missed)], [false, false]);
  // Should it outlive the sweep, it does nothing once its cast has ended.
  me.flags[SYS].activeSpells = [{ id: "m8", name: "Mirror Reprise" }];
  await auto.onSpellSettledB7({ actor: me, spell: S["Mirror Reprise"], cast: true, warpMods: {} });
  const fx2 = me.effects.find((e) => e.flags?.[MOD]?.source === auto.MIRROR_FLAG);
  fx2.flags[MOD][auto.MIRROR_FLAG].images = 3;
  me.flags[SYS].activeSpells = [];
  const hit2 = await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me });
  equal("E P6 …a waiting effect whose cast has ended diverts nothing", Boolean(hit2.missed), false);
  // A cast not in the registry (no cast id): the last duplicate deletes the waiting effect itself.
  me.flags[SYS].activeSpells = [];
  await auto.onSpellSettledB7({ actor: me, spell: S["Mirror Reprise"], cast: true, warpMods: {} });
  const fx3 = me.effects.find((e) => e.flags?.[MOD]?.source === auto.MIRROR_FLAG && !e.flags[MOD][auto.MIRROR_FLAG].castId);
  fx3.flags[MOD][auto.MIRROR_FLAG].images = 1;
  d100 = 99;
  await RW.checkReactionsAfter({ actor: orc, outcome: { degree: { key: "success" }, total: 25 }, dice: {}, modifiers: [] }, { type: "attack", succeeded: true, failed: false, target: me });
  equal("E …an unregistered cast's last duplicate deletes the waiting effect", me.effects.some((e) => e === fx3), false);
}

/* ----------------------------------------------------------------- */
/* F — the wiring                                                      */
/* ----------------------------------------------------------------- */
{
  const script = read("scripts", "eldritch-arts.mjs");
  for (const [hook, fn] of [["trgPrimeSpellSettled", "onSpellSettledB7"], ["createItem", "onItemCreatedB7"], ["updateCombat", "onCombatTurnB7"], ["trgPrimeDeathGuardHeld", "onDeathGuardHeldB7"], ["trgPrimeStrikeResolved", "onStrikeResolvedB7"], ["deleteActiveEffect", "onEffectDeletedB7"], ["createActiveEffect", "onEffectCreatedB7"], ["updateToken", "onTokenMovedB7"], ["updateCombat", "onCombatSyncB7"], ["deleteToken", "onTokenDeletedB7"]]) {
    ok(`F ${fn} is wired on ${hook}`, new RegExp(`Hooks\\.on\\("${hook}", \\([^)]*\\) => \\{ ${fn}\\(`).test(script));
  }
  ok("F the module socket's listener is registered at ready", /Hooks\.once\("ready", \(\) => registerBlock7Socket\(\)\);/.test(script));
  equal("F the manifest asks Foundry for the module socket", JSON.parse(read("module.json")).socket, true);
  ok("F registration calls registerBlock7", /registerBlock7\(api, moduleId\);/.test(read("module", "registration.mjs")));
  ok("F the Sustain hook is listened for (0.16.0)", /Hooks\.on\("trgPrimeSpellSustained", \(ctx\) => \{ onSpellSustainedB7\(ctx\)/.test(script));
  const packs = await import(new URL("./content/packs.mjs", import.meta.url));
  const spells = packs.PACKS.find((p) => p.name === "ea-spells").docs, abilities = packs.PACKS.find((p) => p.name === "ea-abilities").docs;
  equal("F the packs hold the 42 and the ability", [C.SPELLS_B7.every((s) => spells.includes(s)), abilities.includes(C.ELEMENTAL_STRIKE_ITEM)], [true, true]);
  const dir = path.join(ROOT, "packs-source", "ea-spells");
  const built = fs.readdirSync(dir).map((f) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8")));
  // Skipped by mutate-block7 (EA_MUTATING=1), so each content mutation must be caught by a check of its own meaning.
  if (process.env.EA_MUTATING !== "1") equal("F packs-source is the build (run build-packs)", C.SPELLS_B7.map((s) => JSON.stringify(built.find((b) => b._id === s._id)?.system ?? null) === JSON.stringify(s.system)).every(Boolean), true);
  const b6a = read("module", "block6a-automations.mjs");
  ok("F the Draconic and Elemental Pacts' Uses grant their spells", /grantPactSpellB7\(actor, item, "dragonsBreath"/.test(b6a) && /grantPactSpellB7\(actor, item, "elementalStrike"/.test(b6a));
  ok("F no shipped card says a Grimoire spell waits for Blocks 7–8", packs.PACKS.flatMap((p) => p.docs).every((d) => !/arrives with the Grimoire|waits? (?:on|for) Blocks 7–8/i.test(String(d.system?.description ?? ""))));
  // RE-PINNED 0.11.0: Block 8a needs TRG Prime 3.686.0 (H12, H17, H18).
  ok("F the manifest and the entry script ask for TRG Prime 3.688.0", JSON.parse(read("module.json")).relationships.systems[0].compatibility.minimum === "3.694.0" && /REQUIRED_SYSTEM = "3\.694\.0"/.test(script)); // RE-PINNED 0.12.0, 0.14.0
}

if (failures.length) {
  console.log(`verify-block7: ${checks} checks, ${failures.length} failure(s).`);
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exitCode = 1;
} else console.log(`verify-block7: ${checks} checks, 0 failure(s).`);
