#!/usr/bin/env node
/**
 * mutate-block9a — the mutation half of verify-block9a. Each mutation breaks
 * one printed number, one ruling, one reading or one wire of Block 9a
 * (0.13.0: the catalysts, the four catalyst feats, the special materials);
 * verify-block9a must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block9a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "block9a-rules.mjs"), A = f("module", "block9a-automations.mjs"), C = f("tools", "content", "block9a.mjs"),
  D5 = f("tools", "content", "block5-d.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), MANIFEST = f("module.json"), PACKS = f("tools", "content", "packs.mjs");

const MUTATIONS = [
  // the rules: the backlash's gate, the feats
  { name: "a Partial brings the backlash", file: R, from: "  const failed = [\"failure\", \"fumble\", \"blunder\"].includes(d);", to: "  const failed = [\"partial\", \"failure\", \"fumble\", \"blunder\"].includes(d);" },
  { name: "Mastery waives a Fumble too", file: R, from: "  if (mastery && d === \"failure\") return false;", to: "  if (mastery) return false;" },
  { name: "Dragonbone's backlash on a Failure too (M10)", file: R, from: "onFumbleOnly: true, backlash:", to: "onFumbleOnly: false, backlash:" },
  { name: "Affinity takes 1 per level", file: A, from: "let reduction = affinity ? 2 * Math.max(0, level) : 0;", to: "let reduction = affinity ? Math.max(0, level) : 0;" },
  { name: "Affinity's rounds to 0", file: R, from: "  return Math.max(1, int(rounds) - 1);", to: "  return Math.max(0, int(rounds) - 1);" },
  { name: "Affinity leaves Stunned 3", file: R, from: "  if (cond?.key === \"stunned\" && int(cond.value) > 1 && !cond.rounds) return { ...cond, value: int(cond.value) - 1 };", to: "" },
  { name: "Conservation keeps on a 14", file: R, from: "  return int(flatRoll) >= 15;", to: "  return int(flatRoll) >= 14;" },
  { name: "Vellum's bleeding is not capped at 10 (Q202)", file: R, from: "  return Math.min(10, Math.max(0, int(pp)));", to: "  return Math.max(0, int(pp));" },
  { name: "the shatter is 1d6 per level", file: R, from: "const n = Math.floor(Math.max(0, int(itemLevel)) / 2);", to: "const n = Math.floor(Math.max(0, int(itemLevel)));" },
  // the catalysts' printed numbers
  { name: "Leydust is +1", file: R, from: "checkModifiers: [{ label: \"Leydust\", value: 2, type: \"item\" }]", to: "checkModifiers: [{ label: \"Leydust\", value: 1, type: \"item\" }]" },
  { name: "the Bead is +1", file: R, from: "answer: () => ({ attack: 2,", to: "answer: () => ({ attack: 1," },
  { name: "Starpetal ×2", file: R, from: "      : { rangeFactor: 1.5,", to: "      : { rangeFactor: 2," },
  { name: "Glimmercoal 1d6 per PP", file: R, from: "addedDamage: [{ dice: `${perTwo(c)}d6`, type: \"fire\", label: \"Glimmercoal\" }]", to: "addedDamage: [{ dice: `${castPPOf(c)}d6`, type: \"fire\", label: \"Glimmercoal\" }]" },
  { name: "Arcanite on any tradition", file: R, from: "arcanitePowder: { name: \"Arcanite Powder\", applies: (c) => spellOfTradition(c, \"arcane\"),", to: "arcanitePowder: { name: \"Arcanite Powder\", applies: () => true," },
  { name: "Ashen Lotus on any damaging spell", file: R, from: "applies: (c) => isDamaging(c) && (spellHasTrait(c, \"essence\") || spellHasTrait(c, \"fire\")),", to: "applies: (c) => isDamaging(c)," },
  { name: "Moonveil without a save", file: R, from: "applies: (c) => Boolean(str(c?.defence)) && (spellHasTrait(c, \"shadow\")", to: "applies: (c) => (spellHasTrait(c, \"shadow\")" },
  { name: "Moonveil not on Shadow (Graham's illusion)", file: R, from: "(spellHasTrait(c, \"shadow\") || spellHasTrait(c, \"enchantment\"))", to: "(spellHasTrait(c, \"enchantment\"))" },
  { name: "the Shard on a 1 PP spell", file: R, from: "applies: (c) => castPPOf(c) > 1 && !str(c?.variant),", to: "applies: (c) => castPPOf(c) > 0 && !str(c?.variant)," },
  { name: "Sands outside combat", file: R, from: "applies: (c) => Boolean(c?.inCombat),", to: "applies: () => true," },
  { name: "Stunned 2 from the Phial", file: R, from: "backlash: { conditions: [{ key: \"stunned\", value: 3 }] } },", to: "backlash: { conditions: [{ key: \"stunned\", value: 2 }] } }," },
  { name: "Ashen Lotus drains per 2 PP", file: R, from: "    backlash: { soulDrain: { per: \"pp\" } } },", to: "    backlash: { soulDrain: { per: \"twoPP\" } } }," },
  { name: "Blinded 10 minutes", file: R, from: "backlash: { conditions: [{ key: \"blinded\", minutes: 1 }] } },", to: "backlash: { conditions: [{ key: \"blinded\", minutes: 10 }] } }," },
  { name: "Leydust's backlash per PP", file: R, from: "    backlash: { damage: [{ dice: \"1d6\", per: \"twoPP\", type: \"force\" }] } },", to: "    backlash: { damage: [{ dice: \"1d6\", per: \"pp\", type: \"force\" }] } }," },
  { name: "Grave Soil's two rolls apart", file: R, from: "rounds: \"1d6\", together: \"graveSoil\" }], effects:", to: "rounds: \"1d6\" }], effects:" },
  { name: "Incense of Stillness's backlash lasts an hour", file: R, from: "conditional: SPELLCRAFT_DIS(\"Incense of Stillness backlash\"), seconds: 60 }", to: "conditional: SPELLCRAFT_DIS(\"Incense of Stillness backlash\"), seconds: 3600 }" },
  { name: "Frozen Marrow +2 DR", file: R, from: "castEffect: { label: \"Frozen Marrow Shard: +1 DR\", dr: 1 },", to: "castEffect: { label: \"Frozen Marrow Shard: +1 DR\", dr: 2 }," },
  // the materials
  { name: "Bloodglass's save on weapons too", file: R, from: "    declaresByType: { armour: { conditionals: [SAVE(\"Bloodglass\"", to: "    declaresByType: { weapon: { conditionals: [SAVE(\"Bloodglass\"" },
  { name: "Graveiron's save applies by itself", file: R, from: "{ subjects: [\"fortitude\"] }, false)] } },", to: "{ subjects: [\"fortitude\"] })] } }," },
  { name: "trait saves are ticks", file: R, from: "const SAVE = (label, value, scope, when, auto = true) =>", to: "const SAVE = (label, value, scope, when, auto = false) =>" },
  { name: "Veilglass +1", file: R, from: "SAVE(\"Veilglass\", 2, \"Saving throws against Teleportation or Translocation effects\"", to: "SAVE(\"Veilglass\", 1, \"Saving throws against Teleportation or Translocation effects\"" },
  { name: "Veilglass without Translocation (Q194)", file: R, from: "{ traits: [\"teleportation\", \"translocation\"] }", to: "{ traits: [\"teleportation\"] }" },
  { name: "Sunbronze's level +2", file: R, from: "sunbronze: { label: \"Sunbronze\", rarity: \"Rare\", levelDelta: 3,", to: "sunbronze: { label: \"Sunbronze\", rarity: \"Rare\", levelDelta: 2," },
  { name: "Graveiron +1d6 against undead", file: R, from: "weaponDamageVs: [{ dice: \"1\", against: [\"undead\"], label: \"Graveiron\" }],", to: "weaponDamageVs: [{ dice: \"1d6\", against: [\"undead\"], label: \"Graveiron\" }]," },
  { name: "Veilglass not against the incorporeal", file: R, from: "against: [\"aberration\", \"incorporeal\"]", to: "against: [\"aberration\"]" },
  { name: "Tairneach's rider on armour", file: R, from: "      weapon: { strikeRider:", to: "      armour: { strikeRider:" },
  { name: "Eversmoke Cloth on weapons", file: R, from: "eversmokeCloth: { label: \"Eversmoke Cloth\", rarity: \"Rare\", levelDelta: 3, appliesTo: [\"armour\"],", to: "eversmokeCloth: { label: \"Eversmoke Cloth\", rarity: \"Rare\", levelDelta: 3, appliesTo: [\"weapon\", \"armour\"]," },
  { name: "a module key leaks to the core", file: R, from: "  const { card, shatter, shieldLight, ...spec } = m;", to: "  const { card, ...spec } = m;" },
  // the Foundry side
  { name: "a spent catalyst is offered", file: A, from: ".filter((c) => c.key && Number(c.item.system?.quantity ?? 1) > 0)", to: ".filter((c) => c.key)" },
  { name: "Starpetal is never asked", file: A, from: "  if (facts.durationScales && !facts.rangeScales) return \"duration\";\n", to: "  return \"range\";\n" },
  { name: "Mastery is not read", file: A, from: "  const mastery = Boolean(owned(actor, \"Catalyst Mastery\", [\"feat\"]));\n  if (R.backlashDue(spec, ctx.degree, { mastery })) {", to: "  const mastery = false;\n  if (R.backlashDue(spec, ctx.degree, { mastery })) {" },
  { name: "Affinity is not read", file: A, from: "  const affinity = Boolean(owned(actor, \"Catalyst Affinity\", [\"feat\"]));", to: "  const affinity = false;" },
  { name: "Affinity's damage cut is per row", file: A, from: "    const cut = Math.min(rolled, reduction);\n    reduction -= cut;\n    const amount = rolled - cut;\n    if (amount > 0) await h().applyTypedDamage(", to: "    const cut = Math.min(rolled, reduction);\n    const amount = rolled - cut;\n    if (amount > 0) await h().applyTypedDamage(" },
  { name: "Affinity is not taken from recurring damage", file: A, from: "    const amount = rolled - cut;\n    if (amount > 0) await h().addRecurringDamage(actor, amount, b.recurring.type);", to: "    const amount = rolled;\n    if (amount > 0) await h().addRecurringDamage(actor, amount, b.recurring.type);" },
  { name: "Affinity is not taken from Bleeding", file: A, from: "    const value = rolled - cut;\n    if (value > 0) await h().applyConditionTagsTo(actor, [{ key: \"bleeding\", value }]);", to: "    const value = rolled;\n    if (value > 0) await h().applyConditionTagsTo(actor, [{ key: \"bleeding\", value }]);" },
  { name: "Affinity's rounds are not shortened", file: A, from: "      if (affinity) rounds = R.affinityRounds(rounds);\n      // SLOWED", to: "      // SLOWED" },
  { name: "Affinity's rounds are not taken from the effects", file: A, from: "      if (affinity) rounds = R.affinityRounds(rounds);\n      seconds = 6 * rounds;", to: "      seconds = 6 * rounds;" },
  { name: "Conservation on a Fumble", file: A, from: "  if ([\"fumble\", \"blunder\"].includes(lower(degree))) {\n    lines.push(\"Catalyst Conservation: a Fumble or Blunder always consumes the catalyst.\");\n    return false;\n  }\n", to: "" },
  { name: "Conservation without the feat", file: A, from: "  if (!owned(actor, \"Catalyst Conservation\", [\"feat\"])) return false;\n", to: "" },
  { name: "the Marrow's DR on a failed cast", file: A, from: "  if (spec.castEffect && ctx.cast) {", to: "  if (spec.castEffect) {" },
  { name: "the DR is not the core's", file: A, from: "changes: [{ key: \"system.combat.dr.other\", type: \"custom\"", to: "changes: [{ key: \"system.combat.dr.bonus\", type: \"custom\"" },
  { name: "Sands in or out of combat", file: A, from: "  if (spec.castAP && inCombat(actor)) {", to: "  if (spec.castAP) {" },
  { name: "the round clock is not set", file: A, from: "...(fighting ? { expiresRound: int(globalThis.game.combat.round) + rounds + bite } : {})", to: "" },
  { name: "Slowed's clock as any other's", file: A, from: "      const bite = cond.key === \"slowed\" ? 1 : 0;", to: "      const bite = 0;" },
  { name: "the Vellum's +2 is +1", file: R, from: "checkModifiers: [{ label: \"Blood-etched Vellum\", value: 2, type: \"item\" }]", to: "checkModifiers: [{ label: \"Blood-etched Vellum\", value: 1, type: \"item\" }]" },
  { name: "the Vellum on any cast", file: R, from: "applies: (c) => Boolean(c?.ritual),", to: "applies: () => true," },
  { name: "the Shard on a ritual variant", file: R, from: "applies: (c) => castPPOf(c) > 1 && !str(c?.variant),", to: "applies: (c) => castPPOf(c) > 1," },
  { name: "Starpetal stretches an unaltered duration", file: A, from: "TIME.test(String(sd.duration ?? \"\")) && !ctx?.durationUnaltered", to: "TIME.test(String(sd.duration ?? \"\"))" },
  { name: "the Vellum never offered in a ritual", file: A, from: "    if (c.spec.ritualOnly && !ctx.ritual) continue;\n", to: "    if (c.spec.ritualOnly) continue;\n" },
    { name: "the shatter by every client", file: A, from: "  if (!isActingGM()) return;\n  if (materialKeyOf(item) !== \"bloodglass\") return;", to: "  if (materialKeyOf(item) !== \"bloodglass\") return;" },
  { name: "the shatter at 0 HP (broken)", file: A, from: "  const destroyed = R.itemDestroyed(hp, item.system?.hp?.max);", to: "  const destroyed = Number(hp) <= 0;" },
  { name: "the shatter again and again", file: A, from: "  if (shattered) return;\n", to: "" },
  { name: "the shatter's mark is never cleared", file: A, from: "  if (!destroyed) { if (shattered) await item.unsetFlag?.(MODULE_ID, SHATTERED_FLAG); return; }", to: "  if (!destroyed) return;" },
  { name: "destroyed at minus half rounded down", file: R, from: "  return Math.floor(Number(value) || 0) <= -Math.ceil(m / 2);", to: "  return Math.floor(Number(value) || 0) <= -Math.floor(m / 2);" },
  { name: "the shatter reaches 10 feet", file: A, from: "feetBetween(token, t) <= R.MATERIALS_9A.bloodglass.shatter.feet", to: "feetBetween(token, t) <= 2 * R.MATERIALS_9A.bloodglass.shatter.feet" },
  { name: "the shatter's DC is the bearer's", file: A, from: "  const dc = await h().levelDC(levelOfItem);", to: "  const dc = await h().levelDC(levelOf(actor));" },
  { name: "Sunbronze's light while unequipped", file: A, from: "i.type === \"shield\" && i.system?.equipped && materialKeyOf(i) === \"sunbronze\"", to: "i.type === \"shield\" && materialKeyOf(i) === \"sunbronze\"" },
  { name: "Sunbronze's light is not refreshed", file: A, from: "  await h().refreshTokenLight?.(actor);\n}", to: "}" },
  { name: "Sunbronze's light raises two steps", file: A, from: "steps: 1, cap: 5, magical: true, radiusFeet: 10, dimFeet: 10, brightFeet: 0 });", to: "steps: 2, cap: 5, magical: true, radiusFeet: 10, dimFeet: 10, brightFeet: 0 });" },
  { name: "Sunbronze draws a bright ring", file: A, from: "dimFeet: 10, brightFeet: 0 });", to: "dimFeet: 10 });" },
  { name: "the materials are not registered", file: A, from: "  for (const key of Object.keys(R.MATERIALS_9A)) api.registerMaterial?.(key, R.materialRegistration(key), moduleId);\n", to: "" },
      // the content and the feats
  { name: "a catalyst's price is its level", file: C, from: "price: Number(cost.replace(/[^\\d.]/g, \"\")),", to: "price: Number(level)," },
  { name: "the rarity is dropped", file: C, from: "traits: [\"Consumable\", rarity].filter(Boolean).join(\" \"),", to: "traits: \"Consumable\"," },
  { name: "the catalyst flag is lost", file: C, from: "      [MODULE_ID]: { [CATALYST_FLAG]: key }\n", to: "      [MODULE_ID]: {}\n" },
  { name: "the printed Effect is dropped", file: C, from: "    md(`**Effect:** ${entry.fields.Effect}`),\n", to: "" },
  { name: "Eclipse Resin is A", file: C, from: "eclipseResin: { grade: \"C\",", to: "eclipseResin: { grade: \"A\"," },
  { name: "the pack is not built", file: PACKS, from: "BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);", to: "BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);" },
  { name: "the pack is not in the manifest's folder", file: MANIFEST, from: "        \"ea-gear\",\n        \"ea-consumables\"", to: "        \"ea-gear\"" },
  { name: "Catalyst Crafting is graded A", file: D5, from: "\"Catalyst Crafting\": { level: \"D\",", to: "\"Catalyst Crafting\": { level: \"A\"," },
  { name: "Affinity's card loses Q191", file: D5, from: "read by every catalyst's backlash (Graham's Q191)", to: "read by every catalyst's backlash" },
  // the wiring
  { name: "registration skips 9a", file: REG, from: "  registerBlock9a(api, moduleId);\n", to: "" },
  { name: "the Vellum still settles on trgPrimeSpellSettled", file: SCRIPT, from: "const warnB9a = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);\n", to: "const warnB9a = (what) => (err) => console.warn(`Eldritch Arts | ${what}`, err);\nHooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB9a(ctx); });\n" },
  { name: "the material's note is dropped", file: R, from: "  return card ? { ...spec, note: card } : spec;", to: "  return spec;" },
  { name: "Eversmoke armour gets the cloaks' Hide advantage", file: R, from: "    declares: { conditionals: [STEALTH(\"Eversmoke Cloth\")] },", to: "    declares: { conditionals: [STEALTH(\"Eversmoke Cloth\"), { kind: \"advantage\", label: \"Eversmoke Cloth\", scope: \"Hide\", auto: false, when: { checkTypes: [\"skill\"] } }] }," },
  { name: "Sunbronze not against Enchantment (Graham's charm)", file: R, from: "traits: [\"fear\", \"enchantment\"] })] } },", to: "traits: [\"fear\"] })] } }," },
  { name: "Starion shields not lighter", file: R, from: "    hpPercent: 50, weightPercent: -20,", to: "    hpPercent: 50, armourWeightPercent: -20," },
  { name: "Frozen Marrow offered over a warp's type", file: R, from: "frozenMarrowShard: { name: \"Frozen Marrow Shard\", applies: (c) => isDamaging(c) && !typeWarped(c),", to: "frozenMarrowShard: { name: \"Frozen Marrow Shard\", applies: (c) => isDamaging(c)," },
  { name: "Ashen Lotus falls back to essence on a Fire spell", file: R, from: "(spellHasTrait(c, \"fire\") ? \"fire\" : \"essence\")", to: "\"essence\"" },
  { name: "Moonveil is graded B", file: C, from: "moonveilDust: { grade: \"A\",", to: "moonveilDust: { grade: \"B\"," },
  { name: "the module asks for 3.687.1 again", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.687.1\";" },
  // 0.16.0 — Graham, 15 November 2026: a Spellcraft catalyst is dropped on a tradition-skill ritual.
  { name: "a Spellcraft catalyst is offered on a tradition-skill ritual", file: R, from: "return !(SPELLCRAFT_CHECK_CATALYSTS.includes(key) && str(ctx?.checkSkill));", to: "return true;" },
  { name: "Leydust is not a Spellcraft catalyst", file: R, from: '"incenseOfStillness", "leydust", "sanctifiedMyrrh"', to: '"incenseOfStillness", "sanctifiedMyrrh"' },
  { name: "the Vellum is kept on a tradition-skill ritual", file: R, from: '["arcanitePowder", "bloodEtchedVellum", "incenseOfStillness"', to: '["arcanitePowder", "incenseOfStillness"' },
  { name: "the embedded offers ignore the check", file: A, from: "      if (!R.catalystFitsCheck(key, facts)) return false;\n", to: "" },
  { name: "the main offers ignore the check", file: A, from: "    if (!R.catalystFitsCheck(c.key, facts)) continue;\n", to: "" },
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block9a.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block9a: verify-block9a already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block9a: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block9a: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
