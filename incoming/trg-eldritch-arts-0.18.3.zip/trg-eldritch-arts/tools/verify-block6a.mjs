#!/usr/bin/env node
/**
 * verify-block6a — Eldritch Arts 0.9.0 (Block 6, group A, on TRG Prime
 * 3.684.0): the seven Pacts, Hex Weaver, Bloodmage, High Mage, Birthrager,
 * Blood of the Wyrm, and Sanguine Channel, Crimson Rite, Draconic Claws,
 * Elemental Exhalation and Wyrm Ascendant.
 *
 *   A  every feat against the book: name, category, traits as stored,
 *      prerequisites, progression line, uses, the printed text and the
 *      automation paragraph, the docs' table
 *   B  the data: effects, conditionals, declarations, grants, flags
 *   C  the core, run with the content: progression (G8), prerequisites (G9),
 *      conditionals, healing and damage riders (G12), Save DC rows, per-die
 *      rows (C6), strike riders, senses (G13), rage (G10), caster style, Focus
 *      uses, the registrations reaching the core's registry
 *   D  the pure rules
 *   E  registration, with a recording fake
 *   F  the Foundry side with fakes: every Use, seam and hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const warns = [];
const answers = [];
let confirmAnswer = true;
const calls = { replace: [], conditions: [], conditionsTo: [], area: [], falling: [], traits: [], created: [] };
const sdb = await import(sys("module", "magic", "spell-damage-bonus.mjs"));
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; helpers.lastLabel = label; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  replaceFeatEffect: async (actor, item, data) => {
    calls.replace.push({ item: item.name, data });
    actor.effects = actor.effects.filter((e) => e.flags?.[SYS]?.featSource !== item.id);
    data.flags ??= {}; data.flags[SYS] = { ...(data.flags[SYS] ?? {}), featSource: item.id };
    return (await actor.createEmbeddedDocuments("ActiveEffect", [data]))[0];
  },
  applyConditionTags: async (actor, tags) => { calls.conditions.push({ actor: actor.name, tags }); },
  applyConditionTagsTo: async (actor, tags) => { calls.conditionsTo.push({ actor: actor.name, tags }); },
  spellDamagePerDieBonus: async (actor, { type = "", dice = 0, traits = [] } = {}) => sdb.spellDamagePerDie(dice, sdb.declaredSpellDamagePerDie(actor.effects, { damageType: type, traits })),
  runAreaEffect: async (actor, spec, opts) => { calls.area.push({ actor: actor.name, spec, targets: opts.targets.map((t) => t.name) }); return ["area"]; },
  traitGate: async () => true,
  recordTraitUsage: async (actor, rec) => { calls.traits.push(rec); },
  rollFalling: async (actor, opts) => { calls.falling.push({ actor: actor.name, ...opts }); }
};
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => confirmAnswer } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false, deepClone: (x) => JSON.parse(JSON.stringify(x)) } };
globalThis.ui = { notifications: { warn: (t) => warns.push(t), info() {}, error() {} } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.toObject = () => JSON.parse(JSON.stringify({ ...it, parent: undefined, getFlag: undefined }));
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.delete = async () => { a.effects = a.effects.filter((x) => x !== e); };
  return e;
}
function makeActor(name, { level = 10, items = [], pp = 10, ap = 3, attrs = {}, tradition = "" } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [], documentName: "Actor" };
  a.system = { identity: { level, classBonus: 3 }, resources: { pp: { value: pp }, ap: { value: ap }, hp: { value: 20 } }, attributes: Object.fromEntries(Object.entries(attrs).map(([k, v]) => [k, { total: v }])), magic: { tradition }, combat: { movement: { fly: { total: 0 } } } };
  a._source = { system: { magic: { tradition } } };
  const box = (list) => Object.assign(list, { get(id) { return this.find((i) => i.id === id); } });
  a.items = box(items.map((d) => makeItem(d, a)));
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); calls.created.push(...made); return made; }
    const made = list.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => {
    if (type === "Item") { a.items = box(a.items.filter((i) => !ids.includes(i.id))); return; }
    a.effects = a.effects.filter((e) => !ids.includes(e.id));
  };
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  return a;
}
const SPELLS = [
  ["Sleep", "ethereal, arcane", 2, "Mental"], ["Entangle", "verdant", 2, ""], ["Barkskin", "verdant", 4, ""], ["Fireball", "arcane, verdant", 6, "Fire"],
  ["Mind Spike", "ethereal", 12, "Mental"], ["Magic Missile", "arcane", 2, ""], ["Hexcraft", "ethereal", 1, "Hex", { eaHex: true }],
  ["Draconic Infusion", "", 1, "Alteration", {}, true], ["Light", "arcane", 0, "Cantrip"], ["Storm Bolt", "", 1, "Evocation", {}, true], ["Orb Of Lightning", "verdant", 0, "Cantrip"]
].map(([name, tradition, pp, traits, flags = {}, specialist = false], i) => ({ _id: `s${i}`, name, type: "spell", system: { tradition, ppCost: pp, traits, specialist, category: "save" }, flags: { [SYS]: flags } }));
const PACK = { documentName: "Item", collection: "trg-prime.spells", metadata: {}, getIndex: async () => new Map(SPELLS.map((s) => [s._id, s])), getDocument: async (id) => { const s = SPELLS.find((x) => x._id === id); return s ? { name: s.name, toObject: () => JSON.parse(JSON.stringify(s)) } : null; } };
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [PACK], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.684.0" }
};
globalThis.canvas = { tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 }, grid: { size: 100 } };

const C = await import(new URL("./content/block6-a.mjs", import.meta.url));
const auto = await import(new URL("../module/block6a-automations.mjs", import.meta.url));
const common = await import(new URL("./content/block6-common.mjs", import.meta.url));
const B3 = await import(new URL("./content/block3.mjs", import.meta.url));
const F = Object.fromEntries(C.FEATS_B6_A.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS];
const item = (name) => JSON.parse(JSON.stringify(F[name]));
const effFlags = (name, i = 0) => F[name].effects[i]?.flags?.[SYS] ?? {};
const PACT_LIST = [...C.PACT_NAMES];

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
// [list, category, stored traits, stored prerequisites, stored progression]
const LIST = {
  "ANGELIC PACT": ["archetype", "Warlock, Witch", "", "+10 levels"], "DEMONIC PACT": ["archetype", "Warlock, Witch", "", "+10 levels"],
  "DRACONIC PACT": ["archetype", "Warlock, Witch", "", "+10 levels"], "ELEMENTAL PACT": ["archetype", "Warlock, Witch", "", "+10 levels"],
  "FEY PACT": ["archetype", "Warlock, Witch", "", "+10 levels"], "GRAVE PACT": ["archetype", "Warlock, Witch", "", "+10 levels"],
  "VOID PACT": ["archetype", "Warlock, Witch", "", "+10 levels"], "HEX WEAVER": ["archetype", "Adept", "", "+10 levels."],
  "BLOODMAGE": ["archetype", "Adept", "Con +2, Level 2", "+10 levels"], "HIGH MAGE": ["archetype", "Adept", "BSB +4, Non-Sorcerer", "Gained class skill +10 ranks"],
  "BIRTHRAGER": ["archetype", "Berserker", "Arcana skill 2 ranks", "Arcana +10 ranks"], "BLOOD OF THE WYRM": ["archetype", "Sorcerer", "Intimidate 2 ranks", "+10 levels"],
  "SANGUINE CHANNEL": ["class", "Bloodmage", "Level 6", ""], "CRIMSON RITE": ["class", "Bloodmage", "Level 10, Sanguine Channel", ""],
  "DRACONIC CLAWS": ["class", "Blood of the Wyrm", "Intimidate 6 ranks", ""], "ELEMENTAL EXHALATION": ["class", "Blood of the Wyrm, Focus, Invocation", "Arcana or Nature 8 ranks", ""],
  "WYRM ASCENDANT": ["class", "Blood of the Wyrm, Focus, Invocation", "Arcana or Nature 12 ranks", ""]
};
{
  const t = common.titleCase;
  equal("A seventeen feats, in the book's names", C.FEATS_B6_A.map((f) => f.name), Object.keys(LIST).map(t));
  const classTraitNames = common.bookNames("class").filter((n) => common.bookFeat(n).traits.some((x) => ["BLOODMAGE", "BLOOD-OF-THE-WYRM"].includes(x)));
  equal("A …every class feat traited BLOODMAGE or BLOOD-OF-THE-WYRM is here, and no other", classTraitNames.sort(), Object.entries(LIST).filter(([, v]) => v[0] === "class").map(([k]) => k).sort());
  for (const [key, [list, traits, prereq, prog]] of Object.entries(LIST)) {
    const f = F[t(key)];
    const b = common.bookFeat(key, list);
    if (!f) { ok(`A ${key}: built`, false); continue; }
    equal(`A ${f.name}: category, stored traits, prerequisites`, [f.type, f.system.category, f.system.traits, f.system.prerequisites], ["feat", list === "archetype" ? "Archetype" : "Class", traits, prereq]);
    if (list === "archetype") equal(`A ${f.name}: progression line`, f.system.progressionRequirements, prog);
    const plainCard = f.system.description.replace(/<[^>]+>/g, "");
    ok(`A ${f.name}: the card prints the book's text`, b.lines.every((l) => plainCard.includes(l.replace(/\*\*/g, "").slice(0, 50))));
    ok(`A ${f.name}: the card keeps the printed trait line`, f.system.description.includes(b.traits.join(" ")));
    for (const [label, value] of Object.entries(b.fields ?? {})) ok(`A ${f.name}: the card prints its ${label}`, f.system.description.includes(value.replace(/\.$/, "")));
    ok(`A ${f.name}: the card says what is automated`, /(Automated|Partly automated|Not automated)/.test(f.system.description));
    equal(`A ${f.name}: Block 6 and its book line`, [f.flags[SYS].eaBlock, f.flags[SYS].eaBookLine], [6, b.line]);
  }
  equal("A no feat carries a daily count of its own (Focus is the core's default)", C.FEATS_B6_A.map((f) => f.system.usesPerDay).filter(Boolean), []);
  equal("A the docs' table: every feat, by name", Object.keys(C.AUTOMATION_B6_A), C.FEATS_B6_A.map((f) => f.name));
  equal("A …graded A 7, B 10, C 0, D 0", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B6_A).filter((r) => r.level === l).length), [7, 10, 0, 0]);
  // FROM 0.10.0 (Block 7) the spells are built, and the Use grants them (verify-block7 drives the grant).
  ok("A the Grimoire spells are granted by the Use, not said to wait (Draconic, Elemental)", /Dragon’s Breath(\*\*|<\/strong>) of your energy joins your repertoire with the Use/.test(F["Draconic Pact"].system.description) && /Elemental Strike(\*\*|<\/strong>) of your element's energy joins your repertoire with the Use/.test(F["Elemental Pact"].system.description) && !/Blocks 7–8/.test(F["Draconic Pact"].system.description + F["Elemental Pact"].system.description));
  ok("A Blood of the Wyrm's card says its Infusion die is laid with the spell's rider", /Draconic Infusion's claw damage gains one more d6/.test(F["Blood of the Wyrm"].system.description) && !/Not automated/.test(F["Blood of the Wyrm"].system.description));
  ok("A Sanguine Channel's card: offered only with Bleed drawn, nothing left to the GM", /offers \*\*Sanguine Channel\*\* \(not otherwise\)|offers <strong>Sanguine Channel<\/strong> \(not otherwise\)/.test(F["Sanguine Channel"].system.description) && !/GM removes/.test(F["Sanguine Channel"].system.description));
  ok("A High Mage's card says a Sorcerer is refused", /Not offered to a Sorcerer/.test(F["High Mage"].system.description));
  {
    const B3S = await import(new URL("./content/block3-spells.mjs", import.meta.url));
    const sw = await import(sys("module", "magic", "spell-warp.mjs"));
    const di = B3S.BLOCK3_SPECIALIST.find((x) => x.name === "Draconic Infusion");
    const agg = sw.aggregateWarpSelection(di.system.warps, { "warp-0": true, "warp-1": 3 });
    equal("A Draconic Infusion's warps: the core counts the +1d6 option as bonusValue, and the 10 minutes", [agg.mods.bonusValue, agg.mods.durationText], [3, "10 minutes"]);
    ok("A …its card says the rider is laid (Block 6)", /Partly automated \(0\.9\.0/.test(di.system.description.replace(/<\/?em>/g, "*")) && B3S.SPELL_AUTOMATION["Draconic Infusion"].level === "partly");
  }
  ok("A cards cite their rulings (Q90, Q92, Q101, Q102, Q105, Q107, Q100)", /Q90/.test(F["Angelic Pact"].system.description) && /Q92/.test(F["Fey Pact"].system.description) && /Q101/.test(F["Demonic Pact"].system.description) && /Q102/.test(F["Elemental Pact"].system.description) && /Q105/.test(F.Bloodmage.system.description) && /Q107/.test(F["Draconic Claws"].system.description) && /Q100/.test(F["High Mage"].system.description));
  equal("A the content's Pact names are the automations'", C.PACT_NAMES, auto.PACT_NAMES);
  equal("A …and every one is an archetype built here", auto.PACT_NAMES.every((n) => F[n]?.system.category === "Archetype"), true);
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
{
  equal("B the granted spells and abilities (note 1, n.4)", ["Angelic Pact", "Demonic Pact", "Fey Pact", "Grave Pact", "Void Pact"].map((n) => F[n].system.grantedSpells).concat([F["Void Pact"].system.grantedAbilities, F["Hex Weaver"].system.grantedFeats]),
    ["Sanctuary", "Burning Hands", "Charm Kind", "Dead Tongue", "Dark Tendrils", "Darkvision", "Familiar"]);
  equal("B G8: the ten \"+10 levels\" archetypes opt in, High Mage and Birthrager do not (Q90)", C.FEATS_B6_A.filter((f) => f.flags[SYS].progressionSinceTaken === true).map((f) => f.name),
    ["Angelic Pact", "Demonic Pact", "Draconic Pact", "Elemental Pact", "Fey Pact", "Grave Pact", "Void Pact", "Hex Weaver", "Bloodmage", "Blood of the Wyrm"]);
  const conds = (n) => fl(n).conditionals.map((c) => [c.kind, c.value, c.type, c.auto, c.when]);
  equal("B Angelic Pact: +2 circumstance saves vs Fear or Soul, auto and a tick", conds("Angelic Pact"), [["modifier", 2, "circumstance", true, { checkTypes: ["save"], traits: ["fear", "soul"] }], ["modifier", 2, "circumstance", false, { checkTypes: ["save"], not: { traits: ["fear", "soul"] } }]]);
  equal("B Grave Pact: +2 class saves vs Soul, auto and a tick", conds("Grave Pact"), [["modifier", 2, "class", true, { checkTypes: ["save"], traits: ["soul"] }], ["modifier", 2, "class", false, { checkTypes: ["save"], not: { traits: ["soul"] } }]]);
  equal("B Angelic Pact: a healing rider of 1 per PP on Healing spells", effFlags("Angelic Pact").healingRider, { label: "Angelic Pact", perPP: 1, traits: ["healing"] });
  equal("B Demonic Pact: +2 class Intimidate, and 1 secondary fire per PP", [F["Demonic Pact"].effects[0].changes.map((c) => [c.key, c.value]), effFlags("Demonic Pact", 1).spellDamageRider], [[["system.skills.intimidate.class", "2"]], { label: "Demonic Pact", perPP: 1, damageType: "fire" }]);
  equal("B Fey Pact: +2 class Deception and Diplomacy; Save DC +1 on mental", [F["Fey Pact"].effects[0].changes.map((c) => [c.key, c.value]), effFlags("Fey Pact", 1).spellDCBonus], [[["system.skills.deception.class", "2"], ["system.skills.diplomacy.class", "2"]], { label: "Fey Pact", value: 1, type: "untyped", traits: ["mental"] }]);
  equal("B Grave Pact: Save DC +1 on soul", effFlags("Grave Pact").spellDCBonus, { label: "Grave Pact", value: 1, type: "untyped", traits: ["soul"] });
  equal("B Birthrager: casts while raging (G10), instinctive", [fl("Birthrager").castsWhileRaging, F.Birthrager.system.casterStyle], [true, "instinctive"]);
  equal("B G9: the two compound prerequisites opt in", C.FEATS_B6_A.filter((f) => f.flags[SYS].compoundSkillPrerequisites).map((f) => f.name), ["Elemental Exhalation", "Wyrm Ascendant"]);
  equal("B the archetype options: High Mage and Birthrager open the Sorcerer and the Adept tier (Q100)", JSON.parse(JSON.stringify(C.ARCHETYPE_OPTIONS_B6_A)), { "High Mage": { classGrants: ["Sorcerer"], tierGrants: ["Adept"] }, Birthrager: { classGrants: ["Sorcerer"], tierGrants: ["Adept"] } });
  ok("B …each option names an archetype built here", Object.keys(C.ARCHETYPE_OPTIONS_B6_A).every((n) => F[n]?.system.category === "Archetype") && Object.keys(C.ARCHETYPE_OPTIONS_B6_A).every((n) => common.EA_ARCHETYPE_NAMES.includes(n)));
  ok("B every archetype is in the lead's registered list", C.FEATS_B6_A.filter((f) => f.system.category === "Archetype").every((f) => common.EA_ARCHETYPE_NAMES.includes(f.name)));
  // The borrowed birthrights against Block 3a's data.
  const tradOf = Object.fromEntries(B3.BIRTHRIGHTS.map((b) => [b.name, b]));
  for (const [name, b] of Object.entries(auto.BORROWABLE_BIRTHRIGHTS)) {
    const src = tradOf[name];
    const spells = src.system.grantedSpells.split(",").map((s) => s.trim());
    equal(`B ${name}: ability, tradition and skills are Block 3a's`, [b.ability, b.tradition, b.skills], [src.flags[SYS].classMagic.ability, src.flags[SYS].classMagic.tradition, src.flags[SYS].classSkills.map((s) => s.toLowerCase())]);
    equal(`B ${name}: its specialist spell is the first grant, its cantrip the 1st-level PP 0 spell`, [b.specialist, b.cantrip], [spells[0].replace(/^1: /, ""), B3.additionalSpells(name).find((s) => s.level === 1 && s.pp === 0).name]);
  }
  ok("B Wild is not borrowable (Q100)", !("Wild" in auto.BORROWABLE_BIRTHRIGHTS) && Object.keys(auto.BORROWABLE_BIRTHRIGHTS).length === 6);
}

/* ----------------------------------------------------------------- */
/* C — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
{
  const ap = await quiet(() => import(sys("module", "archetype-progression.mjs")));
  const ctx = (name, takenAt) => ap.archetypeProgressionContext({ flags: { [SYS]: { ...fl(name), ...(takenAt === undefined ? {} : { archetypeTakenAt: takenAt }) } } });
  const pass = (name, level, takenAt) => ap.meetsProgressionRequirement(F[name].system.progressionRequirements, { level }, ctx(name, takenAt));
  equal("C G8: a Pact taken at 1st blocks at 10th, opens at 11th; unstamped passes (Q90)", [pass("Angelic Pact", 10, 1), pass("Angelic Pact", 11, 1), pass("Angelic Pact", 3)], [false, true, true]);
  equal("C …Hex Weaver's full stop is no obstacle", [pass("Hex Weaver", 5, 1), pass("Hex Weaver", 12, 2)], [false, true]);
  equal("C …the stamp is written on arrival for an opted-in archetype, not for High Mage", [ap.archetypeTakenAtStamp(item("Bloodmage"), 4), ap.archetypeTakenAtStamp(item("High Mage"), 4)], [{ "flags.trg-prime.archetypeTakenAt": 4 }, null]);
  equal("C High Mage: Gained class skill +10 ranks reads its grant (note 11)", [ap.meetsProgressionRequirement(F["High Mage"].system.progressionRequirements, { skillRanks: { arcana: 10 } }, { hasGrant: true, grantedSkill: "arcana" }), ap.meetsProgressionRequirement(F["High Mage"].system.progressionRequirements, { skillRanks: { arcana: 10 } }, { hasGrant: true, grantedSkill: "" })], [true, false]);
  equal("C Birthrager: Arcana +10 ranks parses", [ap.meetsProgressionRequirement(F.Birthrager.system.progressionRequirements, { skillRanks: { arcana: 9 } }), ap.meetsProgressionRequirement(F.Birthrager.system.progressionRequirements, { skillRanks: { arcana: 10 } })], [false, true]);

  const pr = await quiet(() => import(sys("module", "prerequisites.mjs")));
  // AS THE PICKER CALLS IT (TRG Prime 3.684.1, picker-filters.mjs's
  // withPrerequisitesGate): the actor's stats and `knownNames`, no
  // `compoundSkills` option. The flag no longer changes the read.
  const meets = (n, stats) => pr.meetsParseablePrerequisites(F[n].system.prerequisites, { knownNames: null, ...stats });
  equal("C Bloodmage: Con +2 and Level 2", [meets("Bloodmage", { level: 2, abilities: { constitution: 2 } }), meets("Bloodmage", { level: 2, abilities: { constitution: 1 } }), meets("Bloodmage", { level: 1, abilities: { constitution: 3 } })], [true, false, false]);
  // RE-POINTED AT 0.9.1 (TRG Prime 3.684.1; Graham, 4 November 2026: "Yes for
  // the skill rank prerequisites"): the core reads "A or B N ranks" for every
  // feat now, flagged or not, so the unflagged read refuses too.
  equal("C G9: Elemental Exhalation reads Arcana or Nature 8 (the core reads it unflagged too, 3.684.1)", [meets("Elemental Exhalation", { skillRanks: { nature: 8 } }), meets("Elemental Exhalation", { skillRanks: { arcana: 7, nature: 7 } }), pr.meetsParseablePrerequisites(F["Elemental Exhalation"].system.prerequisites, { skillRanks: {} })], [true, false, false]);
  equal("C …Wyrm Ascendant at 12", [meets("Wyrm Ascendant", { skillRanks: { arcana: 12 } }), meets("Wyrm Ascendant", { skillRanks: { arcana: 11 } })], [true, false]);
  equal("C Blood of the Wyrm and the claws: Intimidate ranks", [meets("Blood of the Wyrm", { skillRanks: { intimidate: 2 } }), meets("Blood of the Wyrm", { skillRanks: { intimidate: 1 } }), meets("Draconic Claws", { skillRanks: { intimidate: 6 } }), meets("Draconic Claws", { skillRanks: { intimidate: 5 } })], [true, false, true, false]);
  equal("C Birthrager: Arcana 2 ranks", [meets("Birthrager", { skillRanks: { arcana: 2 } }), meets("Birthrager", { skillRanks: { arcana: 1 } })], [true, false]);
  const known = new Set(C.FEATS_B6_A.map((f) => pr.prerequisiteNameKey(f.name)));
  equal("C Crimson Rite: Level 10 and Sanguine Channel, by name", [meets("Crimson Rite", { level: 10, knownNames: known, ownedNames: new Set([pr.prerequisiteNameKey("Sanguine Channel")]) }), meets("Crimson Rite", { level: 10, knownNames: known, ownedNames: new Set() })], [true, false]);

  const cond = await quiet(() => import(sys("module", "conditionals.mjs")));
  const nc = (n, i) => cond.normaliseConditional(fl(n).conditionals[i], { name: n }, i);
  equal("C Angelic Pact's row: a save vs Fear, vs Soul, not vs Poison; the tick when untraited", [cond.matchesCheck(nc("Angelic Pact", 0), { checkType: "save", traits: "Fear, Mental" }), cond.matchesCheck(nc("Angelic Pact", 0), { checkType: "save", traits: "Soul" }), cond.matchesCheck(nc("Angelic Pact", 0), { checkType: "save", traits: "Poison" }), cond.matchesCheck(nc("Angelic Pact", 1), { checkType: "save", traits: "" }), cond.matchesCheck(nc("Angelic Pact", 1), { checkType: "save", traits: "Soul" })], [true, true, false, true, false]);
  equal("C Grave Pact's row: a class bonus vs Soul only", [nc("Grave Pact", 0).type, cond.matchesCheck(nc("Grave Pact", 0), { checkType: "save", traits: "Soul" }), cond.matchesCheck(nc("Grave Pact", 0), { checkType: "save", traits: "Fear" })], ["class", true, false]);
  const roar = cond.normaliseConditional(auto.roarConditionals()[0], { name: "roar" }, 0);
  equal("C the roar: advantage on Demoralise only, spent", [roar.kind, roar.oneShot, cond.matchesCheck(roar, { checkType: "skill", subject: "intimidate", actionKey: "demoralise" }), cond.matchesCheck(roar, { checkType: "skill", subject: "intimidate", actionKey: "coerce" })], ["advantage", true, true, false]);

  const hr = await import(sys("module", "magic", "healing-riders.mjs"));
  const angel = hr.declaredHealingRiders([{ id: "e1", flags: { [SYS]: effFlags("Angelic Pact") } }]);
  equal("C G12: Angelic Pact heals +PP on a Healing spell, nothing otherwise or on a cantrip (Q101)", [hr.applyHealingRiders(angel, { formula: "2d8", castPP: 4, traits: "Healing" }).extra, hr.applyHealingRiders(angel, { formula: "2d8", castPP: 4, traits: "Conjuration" }).extra, hr.applyHealingRiders(angel, { formula: "1d4", castPP: 0, traits: "Healing" }).extra], [4, 0, 0]);
  const cdr = await import(sys("module", "magic", "caster-damage-riders.mjs"));
  const demon = cdr.declaredSpellDamageRiders([{ id: "e2", flags: { [SYS]: effFlags("Demonic Pact", 1) } }]);
  equal("C G12: Demonic Pact's rider: fire, PP × 1, nothing at 0 PP or when nothing was taken", [demon[0]?.damageType, cdr.spellRiderFormula(demon[0], 5), cdr.spellDamageRidersFor(demon, { taken: 6, castPP: 5 }).length, cdr.spellDamageRidersFor(demon, { taken: 6, castPP: 0 }).length, cdr.spellDamageRidersFor(demon, { taken: 0, castPP: 5 }).length], ["fire", "5", 1, 0, 0]);
  const dcb = await import(sys("module", "magic", "spell-dc-bonus.mjs"));
  const fey = [{ flags: { [SYS]: effFlags("Fey Pact", 1) } }], grave = [{ flags: { [SYS]: effFlags("Grave Pact") } }];
  equal("C Fey and Grave: +1 on their trait, innate included, nothing else", [dcb.declaredSpellDCBonuses(fey, "Mental, Enchantment").length, dcb.declaredSpellDCBonuses(fey, "Emotion, Enchantment").length, dcb.declaredSpellDCBonuses(grave, "Soul", { innate: true }).length, dcb.declaredSpellDCBonuses(grave, "Essence").length], [1, 0, 1, 0]);

  const fire = [{ flags: { [SYS]: { spellDamageBonus: auto.elementalPactRows("fire") } } }];
  const pd = (eff, damageType, traits) => sdb.spellDamagePerDie("3d6", sdb.declaredSpellDamagePerDie(eff, { damageType, traits })).total;
  equal("C C6 / Q102: Elemental (fire): a fire pool +3 once, a Fire-trait cold pool +3, a cold pool without the trait 0", [pd(fire, "fire", "Fire, Invocation"), pd(fire, "fire", ""), pd(fire, "cold", "Fire"), pd(fire, "cold", "Evocation")], [3, 3, 3, 0]);
  const water = [{ flags: { [SYS]: { spellDamageBonus: auto.elementalPactRows("water") } } }];
  equal("C …(water): cold pools and Water-trait pools", [pd(water, "cold", ""), pd(water, "bludgeoning", "Water"), pd(water, "fire", "")], [3, 3, 0]);
  const crim = [{ flags: { [SYS]: { spellDamageBonus: auto.crimsonRow() } } }, { flags: { [SYS]: { spellDamageBonus: { label: "Other", perDie: 1, type: "circumstance" } } } }];
  equal("C Crimson Rite's per-die row: circumstance, so a second circumstance row does not stack", [pd([crim[0]], "fire", ""), pd(crim, "fire", "")], [3, 3]);

  const sr = await quiet(() => import(sys("module", "magic", "strike-riders.mjs")));
  const claws = sr.normaliseStrikeRider(auto.draconicClawsRider("fire"));
  const packets = (name) => sr.riderPacketsFor([claws], { name, attackMode: "melee", weaponId: "w" }, {});
  equal("C Draconic Claws: 1d6 fire on the Dragon Claws, nothing on a sword; never spent", [packets("Dragon Claws").length, packets("Longsword").length, claws.once, packets("Dragon Claws")[0]?.dice ?? packets("Dragon Claws")[0]?.formula], [1, 0, false, "1d6"]);
  const inf = sr.normaliseStrikeRider(auto.infusionRider({ energy: "cold", warpMods: { bonusValue: 2 } }).rider);
  const ip = (name) => sr.riderPacketsFor([inf], { name, attackMode: "melee", weaponId: "w" }, {});
  equal("C Draconic Infusion's rider: 3d6 cold on the Dragon Claws and a Scaelyn's Claws (Medium), not a sword; never spent", [ip("Dragon Claws")[0]?.dice, ip("Claws (Medium)").length, ip("Longsword").length, inf.once], ["3d6", 1, 0, false]);

  const senses = await quiet(() => import(sys("module", "senses.mjs")));
  const dvCore = { name: "Darkvision", type: "ability", system: { active: true }, flags: { [SYS]: { creatureAbility: { derives: { sense: { category: "primary", special: true, modality: "visual" } } } } } };
  const voidOn = { name: "Void Pact", type: "feat", system: {}, flags: { [SYS]: { senseRangeBonus: auto.voidSenseBonus() } } };
  const range = (list) => senses.sensesOf(list, 2).find((s) => /darkvision/i.test(s.name))?.rangeFeet;
  equal("C G13: Void Pact's +30 ft reaches the Darkvision sense", range([dvCore, voidOn]) - range([dvCore]), 30);

  const rage = await import(sys("module", "combat", "rage.mjs"));
  equal("C G10: the core reads Birthrager's castsWhileRaging", rage.castsWhileRagingFrom([{ name: "Birthrager", flags: F.Birthrager.flags }]), "Birthrager");
  const cs = await import(sys("module", "magic", "caster-style.mjs"));
  equal("C Birthrager makes its holder instinctive (the core's override)", cs.declaredCasterStyle([{ type: "feat", system: F.Birthrager.system }]), "instinctive");
  const uses = await import(sys("module", "uses.mjs"));
  equal("C the two Focus feats have one use (the core's default); the rest none", C.FEATS_B6_A.map((f) => uses.focusDefaultUses(f.system, "feat")).filter((n) => n !== null), [1, 1]);
  const gs = await import(sys("module", "combat", "granted-speeds.mjs"));
  equal("C Wyrm Ascendant's fly speed is the core's granted speed, land or more", gs.normaliseGrantedSpeed(auto.wingsDerives(true).movement, ["land", "fly", "swim", "climb", "burrow"]), { key: "fly", feet: 0, orLand: true });

  // The registrations reaching the real registry.
  capi.resetModuleRegistry();
  const real = new Proxy({}, { get: (_, k) => { const fn = k === "registerClassSkillGrant" ? capi.queueClassSkillGrant : capi[k]; return typeof fn === "function" ? (...a) => fn(...a) : () => {}; } });
  auto.registerBlock6A(real, "test");
  equal("C …with nothing the core refused", capi.registrationProblems(), []);
  equal("C Q92: a second Pact is refused, the first is not", [capi.exclusiveFeatConflict("Void Pact", ["Angelic Pact"])?.held, capi.exclusiveFeatConflict("Void Pact", ["Void Pact"]), capi.exclusiveFeatConflict("Hex Weaver", ["Angelic Pact"])], ["Angelic Pact", null, null]);
  equal("C Birthrager is gated by Frenzy", [capi.featGateBlock("Berserker", [], "Birthrager")?.needs, capi.featGateBlock("Berserker", ["Frenzy"], "Birthrager")], [["frenzy"], null]);
  const bsb = capi.registeredPPGrants().find((g) => g.name === "birthrager");
  equal("C G11: Birthrager's BSB floor, half rounded up, from the feat", [bsb?.stat, bsb?.halfLevel, bsb?.types], ["bsb", "up", ["feat"]]);
  equal("C G2 and G14: Bloodmage's source and Sanguine Channel's option are registered", [capi.registeredCastPPSources().map((s) => s.key), capi.registeredCastOptions().map((o) => o.key)], [["bloodmage"], ["sanguinechannel"]]);
  const warps = capi.registeredSpellWarps("Blood of the Wyrm");
  const sorc = (type) => makeActor(`ZZ Wyrm ${type}`, { items: [{ name: "Dragon", type: "ability", system: { active: true }, flags: { [SYS]: { eaBirthright: "Dragon" }, [MOD]: { dragonType: type } } }] });
  equal("C G15: six warps, each offered to its own type only, +2 PP, the damage type changed", [warps.length, warps.filter((w) => w.when(sorc("sea"))).map((w) => w.warp.mods.damageType), warps[0].warp.ppCost, warps[0].match.damaging, warps[0].match.anyTraits.includes("elemental")], [6, ["sonic"], 2, true, true]);
  const elig = capi.featEligibilityBlock("Blood of the Wyrm", makeActor("ZZ NoDragon"));
  equal("C G9: Blood of the Wyrm refused without the Dragon Birthright, open with it", [Boolean(elig), capi.featEligibilityBlock("Blood of the Wyrm", sorc("fire"))], [true, null]);
  const withClass = (cls) => makeActor(`ZZ ${cls}`, { items: [{ name: cls, type: "class", system: {} }] });
  equal("C G9: High Mage refused to a Sorcerer (Non-Sorcerer), open to a Wizard", [Boolean(capi.featEligibilityBlock("High Mage", withClass("Sorcerer"))), capi.featEligibilityBlock("High Mage", withClass("Wizard"))], [true, null]);
  const pr2 = await quiet(() => import(sys("module", "prerequisites.mjs")));
  equal("C …the parser leaves Non-Sorcerer open, so the check is what refuses it", pr2.parsePrerequisiteClause("Non-Sorcerer"), null);
  const access = capi.registeredSpecialistAccess();
  equal("C the hex accesses are registered", access.map((a) => a.key).sort(), ["bloodmagehexes", "hexweaver"]);
  equal("C High Mage's class-skill grant is queued under its name", capi.queuedClassSkillGrants().map((g) => [g.name, g.flag]), [["high mage", "highMageClassSkill"]]);
  capi.resetModuleRegistry();

  // G2 through the core's own prompt and split.
  const mmw = await quiet(() => import(sys("module", "magic", "module-metamagic-workflow.mjs")));
  capi.registerCastPPSource("bloodmage", auto.bloodmageSource, "test");
  globalThis.foundry.applications.api.DialogV2.prompt = async (o) => { helpers.lastPrompt = o.content; return { draw: 9 }; };
  const blood = makeActor("ZZ Blood Prompt", { items: [item("Bloodmage")] });
  const asked = await mmw.askCastPPSources({ actor: blood, spell: { name: "Fireball" }, payable: 6, ppPool: 10, rodDraw: 0 });
  equal("C G2: the core offers the Bleed, capped at all but 1 PP (a 9 asked is 5)", [asked.draws.map((d) => [d.key, d.drawn]), asked.total], [[["bloodmage", 5]], 5]);
  const nobody = await mmw.askCastPPSources({ actor: makeActor("ZZ Nobody"), spell: { name: "Fireball" }, payable: 6, ppPool: 10, rodDraw: 0 });
  equal("C …not to a caster without Bloodmage", nobody.draws.length, 0);
  delete globalThis.foundry.applications.api.DialogV2.prompt;
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  equal("D Bloodmage: all but 1 PP", [6, 2, 1, 0].map(auto.bloodmageMax), [5, 1, 0, 0]);
  equal("D Q105: Bleed paid; a Fumble +1 per 2 PP; a Blunder +1 per PP; only with Bleed drawn",
    [auto.bloodmageBleed({ drawn: 3, paid: 3, degree: "success", totalPP: 5 }).total, auto.bloodmageBleed({ drawn: 3, paid: 3, degree: "fumble", totalPP: 5 }).total, auto.bloodmageBleed({ drawn: 2, paid: 2, degree: "blunder", totalPP: 5 }).total, auto.bloodmageBleed({ drawn: 0, paid: 0, degree: "blunder", totalPP: 5 }).total, auto.bloodmageBleed({ drawn: 3, paid: 0, degree: "fumble", totalPP: 5, refunded: true }).total],
    [3, 5, 7, 0, 0]);
  equal("D the element map (air electricity, earth acid, fire fire, water cold)", JSON.parse(JSON.stringify(auto.ELEMENT_ENERGY)), { air: "electricity", earth: "acid", fire: "fire", water: "cold" });
  equal("D Draconic Pact's five energies", [...auto.DRACONIC_ENERGIES], ["acid", "cold", "electricity", "fire", "poison"]);
  equal("D the roar: a critical hit of a cast, not a refund, not a plain hit", [auto.roarDue({ cast: true, spellHits: [{ critical: true }] }), auto.roarDue({ cast: true, spellHits: [{ critical: false }] }), auto.roarDue({ cast: true, refunded: true, spellHits: [{ critical: true }] }), auto.roarDue({ cast: false, spellHits: [{ critical: true }] })], [true, false, false, false]);
  equal("D Void Pact: a Critical or Heroic save, not a Success", [auto.voidDBDue({ saveResults: [{ degree: "critical" }] }), auto.voidDBDue({ saveResults: [{ degree: "heroic" }] }), auto.voidDBDue({ saveResults: [{ degree: "success" }] })], [true, true, false]);
  equal("D …its DB: +2 circumstance", auto.voidDBChanges(), [{ key: "system.combat.defence.circumstance", type: "custom", value: "2", priority: 20 }]);
  const dv = { id: "d1", name: "Darkvision", flags: { [SYS]: { creatureAbility: { derives: { sense: { category: "primary" } } }, grantedBy: { sourceId: "pact" } } } };
  const dvRace = { id: "d2", name: "Darkvision", flags: { [SYS]: { creatureAbility: { derives: { sense: { category: "primary" } } } } } };
  equal("D Void Pact's +30: not for its own grant, yes for another source", [auto.voidDarkvisionDue([dv], { id: "pact" }), auto.voidDarkvisionDue([dvRace], { id: "pact" }), auto.voidDarkvisionDue([dv, dvRace], { id: "pact" }), auto.voidDarkvisionDue([{ name: "Nightvision", flags: { [SYS]: { creatureAbility: { derives: { sense: { category: "primary" } } } } } }], { id: "pact" })], [false, true, true, false]);
  equal("D Crimson Rite: the critical hits' creatures", auto.crimsonCriticals({ cast: true, spellHits: [{ target: "a", critical: true }, { target: "b", critical: false }] }), ["a"]);
  equal("D …active while Bleeding and not suppressed", [auto.crimsonActive({ owns: true, bleeding: true }), auto.crimsonActive({ owns: true, bleeding: true, suppressed: true }), auto.crimsonActive({ owns: true, bleeding: false }), auto.crimsonActive({ owns: false, bleeding: true })], [true, false, false, false]);
  const entry = (tradition, pp, extra = {}) => ({ system: { tradition, ppCost: pp, ...(extra.system ?? {}) }, flags: { [SYS]: extra.flags ?? {} } });
  equal("D Hex Weaver: Ethereal or Verdant, PP up to level + 1, no specialist or hex (Q103)", [auto.hexWeaverMayTake(entry("ethereal, arcane", 6), 5), auto.hexWeaverMayTake(entry("verdant", 7), 5), auto.hexWeaverMayTake(entry("arcane", 2), 5), auto.hexWeaverMayTake(entry("verdant", 2, { system: { specialist: true } }), 5), auto.hexWeaverMayTake(entry("ethereal", 1, { flags: { eaHex: true } }), 5)], [true, false, false, false, false]);
  equal("D the Highmagic trait, once", [auto.withHighmagic("Fire, Invocation"), auto.withHighmagic("Highmagic"), auto.withHighmagic("")], ["Fire, Invocation, Highmagic", "Highmagic", "Highmagic"]);
  equal("D High Mage: the first key ability at +2", auto.highMageChoices({ intelligence: { total: 2 }, wisdom: { total: 1 }, charisma: { total: 3 } }), ["Arcanum", "Dragon", "Umbral"]);
  equal("D the hex accesses: Hex Weaver any hex; Bloodmage the Bloodmage-class ones", [auto.hexWeaverAllows(true, { flags: { [SYS]: { eaHex: true } } }), auto.hexWeaverAllows(false, { flags: { [SYS]: { eaHex: true } } }), auto.hexWeaverAllows(true, { flags: { [SYS]: {} } }), auto.bloodmageAllows(true, { system: { specialistClass: "Bloodmage" } }), auto.bloodmageAllows(true, { system: { specialistClass: "Witch" } }), auto.bloodmageAllows(false, { system: { specialistClass: "Bloodmage" } })], [true, false, false, true, false, false]);
  equal("D Exhalation: 1d6 per two levels, rounded down; line for cave and light", [auto.exhalationDice(9), auto.exhalationDice(8), auto.exhalationDice(1), auto.exhalationShape("cave"), auto.exhalationShape("light"), auto.exhalationShape("fire"), auto.exhalationShape("sea")], ["4d6", "4d6", "", "a 60-foot line", "a 60-foot line", "a 30-foot cone", "a 30-foot cone"]);
  equal("D Draconic Infusion: 1d6 + a die a warp, at most 5d6, +1 with Blood of the Wyrm after the cap; 10 minutes with the warp",
    [auto.infusionRider({ energy: "fire" }).rider.dice, auto.infusionRider({ energy: "fire", warpMods: { bonusValue: 2 } }).rider.dice, auto.infusionRider({ energy: "fire", warpMods: { bonusValue: 6 } }).rider.dice, auto.infusionRider({ energy: "fire", warpMods: { bonusValue: 4 }, wyrm: true }).rider.dice, auto.infusionRider({ energy: "fire" }).seconds, auto.infusionRider({ energy: "fire", warpMods: { durationText: "10 minutes" } }).seconds, auto.infusionRider({ energy: "" })],
    ["1d6", "3d6", "5d6", "6d6", 60, 600, null]);
  equal("D …due on its own successful cast, not a refund or an item's", [auto.infusionDue({ spell: { name: "Draconic Infusion" }, cast: true }), auto.infusionDue({ spell: { name: "Draconic Infusion" }, cast: true, refunded: true }), auto.infusionDue({ spell: { name: "Draconic Infusion" }, cast: true, itemCast: true }), auto.infusionDue({ spell: { name: "Shield" }, cast: true })], [true, false, false, false]);
  equal("D Sanguine Channel: offered only with a Bloodmage draw", [auto.sanguineDrawn({ ppSources: [{ key: "bloodmage", drawn: 1 }] }), auto.sanguineDrawn({ ppSources: [{ key: "bloodmage", drawn: 0 }] }), auto.sanguineDrawn({ ppSources: [{ key: "rod", drawn: 2 }] }), auto.sanguineDrawn({})], [true, false, false, false]);
  equal("D Sanguine Channel: earned only when Bloodmage's Bleed paid", [auto.sanguineEarned({ ppSources: [{ key: "bloodmage", paid: 2 }] }), auto.sanguineEarned({ ppSources: [{ key: "bloodmage", paid: 0 }] }), auto.sanguineEarned({ ppSources: [{ key: "rod", paid: 2 }] })], [true, false, false]);
  equal("D Sanguine Channel's modes", [auto.sanguineModes({ category: "attack" }), auto.sanguineModes({ category: "save", defence: "Basic Reflex" }), auto.sanguineModes({ category: "utility" })], [{ attack: true, save: false }, { attack: false, save: true }, { attack: false, save: false }]);
  equal("D Blood of the Wyrm's warp traits (Q106)", [...auto.WYRM_WARP_TRAITS], ["elemental", "air", "earth", "fire", "water", "acid", "cold", "electricity", "sonic", "poison"]);
  equal("D Draconic Claws: 1d6 on the Dragon Claws (Q107)", auto.draconicClawsRider("acid"), { label: "Draconic Claws", dice: "1d6", damageType: "acid", scope: "melee", weaponNames: ["dragon claws"], once: false });
  equal("D the numbers: Void 2 and 30, Crimson 1 PP, Exhalation 2 AP and 2 PP, Ascendant 600 s and 1 AP, the warp 2 PP", [auto.VOID_DB, auto.VOID_DARKVISION_FEET, auto.CRIMSON_SUPPRESS_PP, auto.EXHALATION_AP, auto.EXHALATION_PP, auto.ASCENDANT_SECONDS, auto.ASCENDANT_AP, auto.WYRM_WARP_PP], [2, 30, 1, 2, 2, 600, 1, 2]);
}

/* ----------------------------------------------------------------- */
/* E — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const rec = [];
  const api = new Proxy({}, { get: (_, k) => (...a) => { rec.push([k, a[0], a[1]]); return true; } });
  auto.registerBlock6A(api, "trg-eldritch-arts");
  const of = (k) => rec.filter((r) => r[0] === k);
  equal("E the ten Uses", of("registerFeatAutomation").map((r) => r[1]), ["Draconic Pact", "Elemental Pact", "Hex Weaver", "High Mage", "Birthrager", "Blood of the Wyrm", "Draconic Claws", "Crimson Rite", "Elemental Exhalation", "Wyrm Ascendant"]);
  equal("E one Pact group of seven", of("registerExclusiveFeats").map((r) => [r[1], r[2].length]), [["Pact", 7]]);
  equal("E the seams", ["registerSpecialistAccess", "registerCastPPSource", "registerCastOption", "registerFeatGate", "registerPPGrant", "registerSpellWarps", "registerFeatEligibility", "registerClassSkillGrant"].map((k) => of(k).length), [2, 1, 1, 1, 1, 1, 2, 1]);
  ok("E no archetype is registered here (the lead registers them)", !of("registerArchetype").length);
  ok("E every Use is a function with a hint; the Focus ones own their use", Object.values(auto.AUTOMATIONS_B6_A).every((u) => typeof u.use === "function" && u.hint) && auto.AUTOMATIONS_B6_A["Elemental Exhalation"].ownsFocusUse && auto.AUTOMATIONS_B6_A["Wyrm Ascendant"].ownsFocusUse);
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side                                                */
/* ----------------------------------------------------------------- */
const reset = () => { cards.length = 0; warns.length = 0; answers.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; confirmAnswer = true; game.user.targets = new Set(); };
const lastCard = () => cards.at(-1)?.lines?.join(" ") ?? "";
{
  // Draconic and Elemental Pacts.
  reset();
  const w = makeActor("ZZ Draconic", { items: [item("Draconic Pact")] });
  const dp = w.items[0];
  answers.push("cold");
  await auto.AUTOMATIONS_B6_A["Draconic Pact"].use(w, dp);
  equal("F Draconic Pact's Use: the energy kept, resistance laid", [dp.flags[SYS].eaEnergy, calls.replace.at(-1).data.changes], ["cold", [{ key: "system.combat.resistances", type: "add", value: ", cold", priority: 20 }]]);
  answers.push("sonic");
  equal("F …sonic is not on its list", await auto.AUTOMATIONS_B6_A["Draconic Pact"].use(w, dp), false);
  reset();
  const e = makeActor("ZZ Elemental", { items: [item("Elemental Pact")] });
  answers.push("earth");
  await auto.AUTOMATIONS_B6_A["Elemental Pact"].use(e, e.items[0]);
  const eff = e.effects.find((x) => x.flags[SYS].featSource === e.items[0].id);
  equal("F Elemental Pact's Use: earth → acid resistance and the two per-die rows", [e.items[0].flags[SYS].eaElement, eff.changes[0].value, eff.flags[SYS].spellDamageBonus.map((r) => r.damageTypes.length)], ["earth", ", acid", [1, 13]]);

  // The roar.
  reset();
  await auto.onSpellSettledB6A({ actor: w, cast: true, spellHits: [{ target: { name: "T" }, critical: true }] });
  const roar = w.effects.find((x) => x.flags[MOD]?.source === auto.SRC.roar);
  equal("F a critical spell hit: the roar asked and laid, ending at the end of your next turn", [Boolean(roar), roar?.flags[SYS].conditionals[0].when.actions, cards.at(-1)?.title, roar?.flags[SYS].spellEffectEnd], [true, ["demoralise"], "Draconic Pact", 6]);
  reset(); confirmAnswer = false;
  const before = w.effects.length;
  await auto.onSpellSettledB6A({ actor: w, cast: true, spellHits: [{ target: { name: "T" }, critical: true }] });
  equal("F …declined, nothing", [w.effects.length, cards.length], [before, 0]);
  reset();
  const plain = makeActor("ZZ Plain");
  await auto.onSpellSettledB6A({ actor: plain, cast: true, spellHits: [{ critical: true }], saveResults: [{ degree: "critical" }] });
  equal("F …nothing for a caster with no Pact", [plain.effects.length, cards.length], [0, 0]);

  // Void Pact.
  reset();
  const v = makeActor("ZZ Void", { items: [item("Void Pact")] });
  await auto.onSpellSettledB6A({ actor: v, cast: true, saveResults: [{ degree: "heroic" }] });
  await auto.onSpellSettledB6A({ actor: v, cast: true, saveResults: [{ degree: "critical" }] });
  const db = v.effects.filter((x) => x.flags[MOD]?.source === auto.SRC.voidDB);
  equal("F Void Pact: a Critical save gives +2 DB, renewed not stacked, to the start of your next turn", [db.length, db[0]?.changes?.[0]?.value, db[0]?.flags[SYS].spellEffectEnd], [1, "2", 6]);
  const pact = v.items[0];
  const [own] = await v.createEmbeddedDocuments("Item", [{ name: "Darkvision", type: "ability", system: {}, flags: { [SYS]: { creatureAbility: { derives: { sense: { category: "primary" } } }, grantedBy: { sourceId: pact.id, sourceName: "Void Pact" } } } }]);
  await auto.onItemCreatedB6A(own);
  equal("F …its own Darkvision: no +30", Boolean(pact.flags[SYS].senseRangeBonus), false);
  const [race] = await v.createEmbeddedDocuments("Item", [{ name: "Darkvision (60 ft.)", type: "ability", system: {}, flags: { [SYS]: { creatureAbility: { derives: { sense: { category: "primary" } } } } } }]);
  await auto.onItemCreatedB6A(race);
  equal("F …a Darkvision from elsewhere: +30", pact.flags[SYS].senseRangeBonus, { sense: "Darkvision", feet: 30 });
  await v.deleteEmbeddedDocuments("Item", [race.id]);
  await auto.onItemDeletedB6A(race);
  equal("F …and it goes when that one does", Boolean(pact.flags[SYS].senseRangeBonus), false);

  // A Warlock's Pact spell.
  reset();
  const wl = makeActor("ZZ Warlock", { items: [{ name: "Warlock", type: "class", system: {} }, item("Angelic Pact")] });
  const [sanc] = await wl.createEmbeddedDocuments("Item", [{ name: "Sanctuary", type: "spell", system: { traits: "Warding", ppCost: 2, innate: false }, flags: { [SYS]: { grantedBy: { sourceId: wl.items[1].id, sourceName: "Angelic Pact" } } } }]);
  await auto.onItemCreatedB6A(sanc);
  equal("F a Warlock's Pact spell: innate, Focus, Charisma, one use (note 1)", [sanc.system.innate, sanc.system.traits, sanc.flags[SYS].castingAbilityOverride, sanc.system.usesValue, sanc.flags[MOD].warlockPick], [true, "Warding, Focus", "charisma", 1, "pact"]);
  const wi = makeActor("ZZ Witch", { items: [{ name: "Witch", type: "class", system: {} }] });
  const [wsanc] = await wi.createEmbeddedDocuments("Item", [{ name: "Sanctuary", type: "spell", system: { traits: "Warding", innate: false }, flags: { [SYS]: { grantedBy: { sourceName: "Angelic Pact" } } } }]);
  await auto.onItemCreatedB6A(wsanc);
  const [other] = await wl.createEmbeddedDocuments("Item", [{ name: "Light", type: "spell", system: { traits: "Cantrip", innate: false }, flags: { [SYS]: { grantedBy: { sourceName: "Some Feat" } } } }]);
  await auto.onItemCreatedB6A(other);
  equal("F …a Witch's stays a repertoire spell; another feat's grant is left alone", [wsanc.system.innate, other.system.innate], [false, false]);
  // GRAHAM'S RULING OF 4 NOVEMBER 2026: "All Witch spells are considered to be
  // High Magic" — her Pact spell too, whatever its tradition, by her class
  // (Block 3a's `highMagicCaster: true`), with no trait on the spell.
  const hmCore = await import(sys("module", "magic", "high-magic.mjs"));
  const witchWithClass = { items: [B3.WITCH, item("Demonic Pact")], system: { magic: { tradition: "ethereal" } } };
  equal("F a Witch's Pact spell is High Magic by her class (Burning Hands, arcane, no trait; ruling of 4 Nov 2026)",
    [hmCore.highMagicCast(witchWithClass, { tradition: "arcane", traits: "Fire, Save" }).highMagic, hmCore.highMagicCast(witchWithClass, { tradition: "arcane", traits: "Fire, Save" }).source], [true, "caster"]);
  ok("F …and the Pacts' cards say so", C.ARCHETYPES_B6_A.filter((f) => PACT_LIST.includes(f.name) && /is granted on taking the Pact/.test(f.system.description)).length === 5 && C.ARCHETYPES_B6_A.filter((f) => PACT_LIST.includes(f.name) && /is granted on taking the Pact/.test(f.system.description)).every((f) => /a Witch's is a repertoire spell outside her picks, cast as High Magic as every spell of hers is/.test(f.system.description)));

  // Hex Weaver.
  reset();
  const hw = makeActor("ZZ Hex Weaver", { level: 5, items: [item("Hex Weaver")] });
  answers.push("s0|trg-prime.spells");
  await auto.AUTOMATIONS_B6_A["Hex Weaver"].use(hw, hw.items[0]);
  const offered = helpers.lastOptions.map((o) => o[1].replace(/ \(PP \d+\)$/, ""));
  const pick = hw.items.find((i) => i.type === "spell");
  equal("F Hex Weaver's Use: Ethereal/Verdant up to PP 6, no hex or specialist", offered.sort(), ["Barkskin", "Entangle", "Fireball", "Orb Of Lightning", "Sleep"]);
  equal("F …the pick is High Magic, granted by the feat, flagged", [pick?.name, pick?.system.traits, pick?.flags[SYS].grantedBy.sourceName, pick?.flags[MOD][auto.HEX_WEAVER_SPELL_FLAG], pick?.system.prepared], ["Sleep", "Mental, Highmagic", "Hex Weaver", hw.items[0].id, true]);
  answers.push("s1|trg-prime.spells");
  await auto.AUTOMATIONS_B6_A["Hex Weaver"].use(hw, hw.items[0]);
  equal("F …a second Use replaces it", hw.items.filter((i) => i.type === "spell").map((i) => i.name), ["Entangle"]);

  // High Mage.
  reset();
  const hm = makeActor("ZZ High Mage", { items: [item("High Mage")], attrs: { intelligence: 3, wisdom: 0, constitution: 1, charisma: 1 } });
  answers.push("Dragon", "fire", "intimidate");
  await auto.AUTOMATIONS_B6_A["High Mage"].use(hm, hm.items[0]);
  equal("F High Mage: only the birthrights you meet are offered", helpers.lastOptions.map((o) => o[0]), ["arcana", "intimidate"]);
  const dragon = hm.items.find((i) => i.name === "Draconic Infusion");
  equal("F …Dragon (fire): the specialist spell as High Magic, the skill grant written, the pick and type kept", [dragon?.system.traits, hm.flags[SYS]?.highMageClassSkill, hm.items[0].flags[SYS][auto.BORROWED_BIRTHRIGHT_FLAG], hm.items[0].flags[SYS][auto.BORROWED_DRAGON_FLAG], hm.items.some((i) => i.name === "Light")], ["Alteration, Highmagic", { skill: "intimidate", written: 0 }, "Dragon", "fire", false]);
  equal("F …the pick counts as the Dragon Birthright (Q100), with its type", [auto.birthrightNameOf(hm), auto.wyrmTypeOf(hm), auto.wyrmEligibility(hm)], ["Dragon", "fire", null]);
  answers.push("Arcanum", "nature");
  await auto.AUTOMATIONS_B6_A["High Mage"].use(hm, hm.items[0]);
  equal("F …a new pick replaces the spell; a skill not of that birthright is refused", [hm.items.some((i) => i.name === "Draconic Infusion"), hm.flags[SYS].highMageClassSkill.skill, auto.wyrmTypeOf(hm), Boolean(hm.items[0].flags[SYS][auto.BORROWED_DRAGON_FLAG])], [false, "intimidate", "", false]);
  reset();
  const weak = makeActor("ZZ Weak Mage", { items: [item("High Mage")], attrs: { intelligence: 1 } });
  equal("F …nothing to offer below +2", [await auto.AUTOMATIONS_B6_A["High Mage"].use(weak, weak.items[0]), warns.some((t) => /no birthright is open/.test(t))], [false, true]);

  // Birthrager.
  reset();
  const br = makeActor("ZZ Birthrager", { items: [item("Birthrager")] });
  answers.push("Storm");
  await auto.AUTOMATIONS_B6_A.Birthrager.use(br, br.items[0]);
  equal("F Birthrager: any of the six, not Wild", helpers.lastOptions.map((o) => o[0]), ["Arcanum", "Dragon", "Eternity", "Rune", "Storm", "Umbral"]);
  equal("F …Storm: Storm Bolt and the Orb of Lightning cantrip, not High Magic; the tradition set (Q100)", [br.items.filter((i) => i.type === "spell").map((i) => [i.name, i.system.traits]), br.system.magic.tradition], [[["Storm Bolt", "Evocation"], ["Orb Of Lightning", "Cantrip"]], "verdant"]);
  reset();
  const br2 = makeActor("ZZ Birthrager 2", { items: [item("Birthrager")], tradition: "arcane" });
  answers.push("Umbral");
  await auto.AUTOMATIONS_B6_A.Birthrager.use(br2, br2.items[0]);
  equal("F …a tradition already on the sheet is kept", [br2.system.magic.tradition, /kept/.test(lastCard())], ["arcane", true]);

  // Blood of the Wyrm and Draconic Claws.
  reset();
  const s = makeActor("ZZ Wyrm Sorcerer", { items: [{ name: "Dragon", type: "ability", system: { active: true }, flags: { [SYS]: { eaBirthright: "Dragon" }, [MOD]: {} } }] });
  const [bw] = await s.createEmbeddedDocuments("Item", [item("Blood of the Wyrm")]);
  await auto.onItemCreatedB6A(bw);
  equal("F Blood of the Wyrm arriving with no type: a card asks for the Use", [s.effects.length, /press <strong>Use<\/strong>/.test(lastCard())], [0, true]);
  answers.push("light");
  await auto.AUTOMATIONS_B6_A["Blood of the Wyrm"].use(s, bw);
  equal("F …the Use asks the type, stores it on the birthright, lays electricity resistance", [s.items[0].flags[MOD].dragonType, s.effects.map((x) => x.changes?.[0]?.value)], ["light", [", electricity"]]);
  const [dc] = await s.createEmbeddedDocuments("Item", [item("Draconic Claws")]);
  await auto.onItemCreatedB6A(dc);
  const rider = s.effects.find((x) => x.flags[SYS].featSource === dc.id)?.flags[SYS].strikeRider;
  equal("F Draconic Claws arriving: the rider is laid at once", rider, auto.draconicClawsRider("electricity"));
  const n = s.effects.length, nr = calls.replace.length;
  await auto.syncWyrm(s);
  equal("F …a second sync changes nothing", [s.effects.length, calls.replace.length], [n, nr]);
  await s.items[0].setFlag(MOD, "dragonType", "cold");
  await auto.onItemUpdatedB6A(s.items[0], { flags: { [MOD]: { dragonType: "cold" } } });
  equal("F …a new dragon type re-lays both", s.effects.map((x) => x.changes?.[0]?.value ?? x.flags[SYS].strikeRider?.damageType).sort(), [", cold", "cold"]);
  reset();
  const none = makeActor("ZZ No Dragon", { items: [item("Draconic Claws")] });
  equal("F …without a Dragon Birthright the Use refuses", await auto.AUTOMATIONS_B6_A["Draconic Claws"].use(none, none.items[0]), false);

  // Elemental Exhalation.
  reset();
  const ex = makeActor("ZZ Exhaler", { level: 9, pp: 5, items: [{ name: "Dragon", type: "ability", system: { active: true }, flags: { [SYS]: { eaBirthright: "Dragon" }, [MOD]: { dragonType: "cave" } } }, { ...item("Elemental Exhalation"), system: { ...item("Elemental Exhalation").system, usesValue: 1 } }] });
  const exItem = ex.items[1];
  equal("F Exhalation with nobody targeted: refused, nothing spent", [await auto.AUTOMATIONS_B6_A["Elemental Exhalation"].use(ex, exItem), ex.system.resources.pp.value, exItem.system.usesValue], [false, 5, 1]);
  game.user.targets = new Set([{ actor: makeActor("ZZ Target A") }, { actor: makeActor("ZZ Target B") }]);
  await ex.createEmbeddedDocuments("ActiveEffect", [{ name: "Crimson", flags: { [SYS]: { spellDamageBonus: { perDie: 1, type: "circumstance" } } } }]);
  await auto.AUTOMATIONS_B6_A["Elemental Exhalation"].use(ex, exItem);
  const area = calls.area.at(-1);
  equal("F …4d6 acid + the per-die bonus, basic Reflex, on the targets; 2 PP and the use spent", [area?.spec.damage, area?.spec.save, area?.spec.basic, area?.targets, ex.system.resources.pp.value, exItem.system.usesValue, /60-foot line/.test(area?.spec.intro)], [{ formula: "4d6 + 4", type: "acid" }, "reflex", true, ["ZZ Target A", "ZZ Target B"], 3, 0, true]);
  equal("F …its use spent, it refuses, and spends no PP", [await auto.AUTOMATIONS_B6_A["Elemental Exhalation"].use(ex, exItem), ex.system.resources.pp.value], [false, 3]);
  reset();
  const poor = makeActor("ZZ Poor Exhaler", { level: 9, pp: 1, items: [{ name: "Dragon", type: "ability", system: { active: true }, flags: { [SYS]: { eaBirthright: "Dragon" }, [MOD]: { dragonType: "fire" } } }, { ...item("Elemental Exhalation"), system: { ...item("Elemental Exhalation").system, usesValue: 1 } }] });
  game.user.targets = new Set([{ actor: makeActor("ZZ T") }]);
  equal("F …without 2 PP, refused", [await auto.AUTOMATIONS_B6_A["Elemental Exhalation"].use(poor, poor.items[1]), poor.items[1].system.usesValue], [false, 1]);

  // Wyrm Ascendant.
  reset();
  const wa = makeActor("ZZ Ascendant", { items: [{ ...item("Wyrm Ascendant"), system: { ...item("Wyrm Ascendant").system, usesValue: 1 } }] });
  const waItem = wa.items[0];
  await auto.AUTOMATIONS_B6_A["Wyrm Ascendant"].use(wa, waItem);
  const wings = wa.effects.find((x) => x.flags[MOD]?.source === auto.SRC.wings);
  equal("F Wyrm Ascendant: 10 minutes of wings, the fly speed on the feat, the use spent", [wings?.flags[SYS].spellEffectEnd, waItem.flags[SYS].creatureAbility, waItem.system.usesValue], [600, { derives: { movement: { key: "fly", orLand: true } } }, 0]);
  wa.token = { document: { elevation: 25, update: async (u) => { Object.assign(wa.token.document, u); } } };
  await wa.deleteEmbeddedDocuments("ActiveEffect", [wings.id]);
  await auto.onEffectDeletedB6A(wings);
  equal("F …the wings end aloft: the feat's fly speed goes and you fall 25 ft", [waItem.flags[SYS].creatureAbility, calls.falling.at(-1)?.distance, wa.token.document.elevation], [undefined, 25, 0]);
  equal("F …its use spent, it refuses", await auto.AUTOMATIONS_B6_A["Wyrm Ascendant"].use(wa, waItem), false);

  // Bloodmage's source.
  reset();
  const bm = makeActor("ZZ Bloodmage", { items: [item("Bloodmage")] });
  equal("F Bloodmage's offer: all but 1 PP; none for a 1 PP spell or a caster without it", [auto.bloodmageSource.offer({ actor: bm, payable: 4 })?.max, auto.bloodmageSource.offer({ actor: bm, payable: 1 }), auto.bloodmageSource.offer({ actor: plain, payable: 4 })], [3, null, null]);
  await auto.bloodmageSource.settle({ actor: bm, degree: "fumble", totalPP: 5 }, { drawn: 3, paid: 3 });
  equal("F …settle: Bleeding = paid + the fumble's 1 per 2 PP", calls.conditions.at(-1), { actor: "ZZ Bloodmage", tags: [{ key: "bleeding", value: 5, label: "Bleeding" }] });
  const nCond = calls.conditions.length;
  await auto.bloodmageSource.settle({ actor: bm, degree: "success", totalPP: 5, refunded: true }, { drawn: 3, paid: 0 });
  equal("F …a refunded cast adds nothing", calls.conditions.length, nCond);

  // Sanguine Channel.
  reset();
  const sc = makeActor("ZZ Sanguine", { items: [item("Bloodmage"), item("Sanguine Channel")] });
  const atk = { system: { ppCost: 2, category: "attack" } }, sav = { system: { ppCost: 3, category: "save", defence: "Basic Reflex" } };
  const drew = [{ key: "bloodmage", label: "Bleed", drawn: 2 }];
  equal("F Sanguine Channel offered on an attack or save cast with Bleed drawn; not without the draw, innate, item, cantrip, or without Bloodmage", [Boolean(auto.sanguineOption.offer({ actor: sc, spell: atk, ppSources: drew })), Boolean(auto.sanguineOption.offer({ actor: sc, spell: sav, ppSources: drew })), auto.sanguineOption.offer({ actor: sc, spell: atk }), auto.sanguineOption.offer({ actor: sc, spell: atk, ppSources: [{ key: "bloodmage", drawn: 0 }] }), auto.sanguineOption.offer({ actor: sc, spell: atk, innate: true, ppSources: drew }), auto.sanguineOption.offer({ actor: sc, spell: atk, itemCast: true, ppSources: drew }), auto.sanguineOption.offer({ actor: sc, spell: { system: { ppCost: 0, category: "attack" } }, ppSources: drew }), auto.sanguineOption.offer({ actor: makeActor("ZZ SC only", { items: [item("Sanguine Channel")] }), spell: atk, ppSources: drew })], [true, true, null, null, null, null, null, null]);
  equal("F …an attack spell: +1 attack", (await auto.sanguineOption.apply({ actor: sc, spell: atk })).attack, 1);
  const ta = { id: "t1", name: "Goblin A", actor: { uuid: "Actor.GA" } }, tb = { id: "t2", name: "Goblin B", actor: { uuid: "Actor.GB" } };
  game.user.targets = new Set([ta, tb]);
  answers.push("t2");
  equal("F …a save spell with two targets: the named one's DC +1", (await auto.sanguineOption.apply({ actor: sc, spell: sav })).saveDCTarget, { uuid: "Actor.GB", value: 1 });
  await auto.onSpellSettledB6A({ actor: sc, cast: true, castOptions: ["sanguinechannel"], ppSources: [{ key: "bloodmage", drawn: 2, paid: 2 }] });
  equal("F …settled with Bleed paid: +1 Bleeding", calls.conditions.at(-1)?.tags, [{ key: "bleeding", value: 1, label: "Bleeding" }]);
  const nc = calls.conditions.length;
  await auto.onSpellSettledB6A({ actor: sc, cast: true, castOptions: ["sanguinechannel"], ppSources: [] });
  await auto.onSpellSettledB6A({ actor: sc, cast: true, refunded: true, castOptions: ["sanguinechannel"], ppSources: [{ key: "bloodmage", drawn: 2, paid: 2 }] });
  equal("F …nothing paid (or refunded): no Bleeding", calls.conditions.length, nc);

  // Draconic Infusion's claw rider (note 15).
  reset();
  const di = makeActor("ZZ Infuser", { items: [{ name: "Dragon", type: "ability", system: { active: true }, flags: { [SYS]: { eaBirthright: "Dragon" }, [MOD]: { dragonType: "forest" } } }, item("Blood of the Wyrm")] });
  await auto.onSpellSettledB6A({ actor: di, spell: { name: "Draconic Infusion" }, cast: true, warpMods: { bonusValue: 1, durationText: "10 minutes" } });
  await auto.onSpellSettledB6A({ actor: di, spell: { name: "Draconic Infusion" }, cast: true, warpMods: { bonusValue: 1, durationText: "10 minutes" } });
  const ir = di.effects.filter((x) => x.flags[MOD]?.source === auto.SRC.infusion);
  equal("F Draconic Infusion cast: one rider, 2d6 + Blood of the Wyrm's die of poison, 10 minutes", [ir.length, ir[0]?.flags[SYS].strikeRider.dice, ir[0]?.flags[SYS].strikeRider.damageType, ir[0]?.flags[SYS].spellEffectEnd], [1, "3d6", "poison", 600]);
  const nod = makeActor("ZZ Untyped Infuser", { items: [{ name: "Dragon", type: "ability", system: { active: true }, flags: { [SYS]: { eaBirthright: "Dragon" }, [MOD]: {} } }] });
  await auto.onSpellSettledB6A({ actor: nod, spell: { name: "Draconic Infusion" }, cast: true, warpMods: {} });
  equal("F …without a dragon type: nothing laid, a card says so", [nod.effects.length, /No dragon type/.test(lastCard())], [0, true]);

  // Crimson Rite.
  reset();
  const cr = makeActor("ZZ Crimson", { pp: 3, items: [item("Crimson Rite")] });
  const [bleed] = await cr.createEmbeddedDocuments("ActiveEffect", [{ name: "Bleeding", statuses: ["bleeding"], flags: {} }]);
  await auto.onEffectChangedB6A(bleed);
  const on = () => cr.effects.filter((x) => x.flags?.[MOD]?.source === auto.SRC.crimson);
  equal("F Crimson Rite: Bleeding lays the +1 circumstance per die", on().map((x) => x.flags[SYS].spellDamageBonus), [{ label: "Crimson Rite", perDie: 1, type: "circumstance" }]);
  await auto.onEffectChangedB6A(bleed);
  equal("F …once", on().length, 1);
  await auto.AUTOMATIONS_B6_A["Crimson Rite"].use(cr, cr.items[0]);
  const off = cr.effects.find((x) => x.flags?.[MOD]?.source === auto.SRC.crimsonOff);
  equal("F …the Use: 1 PP, the Bleed suppressed, the bonus lifted", [cr.system.resources.pp.value, off?.flags[SYS].bleedReduction, on().length], [2, 999, 0]);
  await cr.deleteEmbeddedDocuments("ActiveEffect", [off.id]);
  await auto.onEffectDeletedB6A(off);
  equal("F …the suppression ends: the bonus is back", on().length, 1);
  await cr.deleteEmbeddedDocuments("ActiveEffect", [bleed.id]);
  await auto.onEffectDeletedB6A(bleed);
  equal("F …the Bleeding ends: it goes", on().length, 0);
  equal("F …not Bleeding, the Use refuses", await auto.AUTOMATIONS_B6_A["Crimson Rite"].use(cr, cr.items[0]), false);
  await auto.onSpellSettledB6A({ actor: cr, cast: true, spellHits: [{ target: { name: "Orc" }, critical: true }, { target: { name: "Elf" }, critical: false }] });
  equal("F …a critical spell hit: the creature Bleeding 1, yours +1", [calls.conditionsTo.at(-1), calls.conditions.at(-1)?.tags], [{ actor: "Orc", tags: [{ key: "bleeding", value: 1, label: "Bleeding" }] }, [{ key: "bleeding", value: 1, label: "Bleeding" }]]);
}

console.log(`verify-block6a: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
