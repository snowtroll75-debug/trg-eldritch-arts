#!/usr/bin/env node
/**
 * verify-block6d — Eldritch Arts 0.9.0 (Block 6, group D, on TRG Prime
 * 3.684.0): the metamagic and Adept class feats, and the metamagic of the
 * five feats Blocks 5 and 1 deferred to Block 6.
 *
 *   A  every feat against the book: name, category, traits as stored,
 *      prerequisites, uses, the printed text and the automation paragraph,
 *      the docs' table; the five deferred cards
 *   B  the data the core reads: cantripBonus, compound prerequisites, the
 *      restored Requirements, Spell Surge's Focus trait
 *   C  the core, run with the content: G1's normaliser and fold, the scope
 *      (Q94), castingOutcome's saving step, the charged-item arithmetic, the
 *      prerequisite parser (G9), the offered options of a real cast ctx
 *   D  the pure rules
 *   E  registration
 *   F  the Foundry side with fakes: every apply and after, the hooks, the
 *      Use, the reaction, the offer and its step
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6d.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const prompts = [];
const reactorAnswers = [];
const checkDegrees = [];
const calls = { casts: [], area: [], damage: [], conditions: [], depletion: [], chooseSpell: [], checks: [], asked: [] };
const STEPS = {};
let castResult = null;
const uuidMap = new Map();
const helpers = {
  line: (t) => `<p>${t}</p>`,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; helpers.lastTitle = title; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  chooseSpell: async (actor, item, spec) => { calls.chooseSpell.push(spec); return true; },
  askReactor: async (actor, q) => { calls.asked.push({ actor: actor.name, title: q.title, step: q.step }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; return { answer: a, result: await STEPS[q.step](actor, a, q.data) }; },
  castSpell: async (actor, spell, options) => { calls.casts.push({ actor: actor.name, spell: spell.name, options }); return castResult; },
  rollCheck: async (config) => { calls.checks.push({ actor: config.actor?.name, type: config.type, subject: config.subject, dc: config.dc }); return { outcome: { degree: { key: checkDegrees.length ? checkDegrees.shift() : "failure" } } }; },
  applyConditionTagsTo: async (target, tags) => { calls.conditions.push({ target: target.name, tags }); },
  runAreaEffect: async (actor, spec, opts) => { calls.area.push({ actor: actor.name, spec, opts: { title: opts?.title, targets: (opts?.targets ?? null)?.map?.((a) => a.name) ?? null } }); return [`<p>${spec.intro ?? ""}</p>`]; },
  applyTypedDamage: async (target, spec) => { calls.damage.push({ target: target.name, ...spec }); },
  rollItemDepletion: async (actor, item) => { calls.depletion.push(item.name); },
  innateSaveDCFor: async () => ({ value: 19 }),
  spellCastable: async (actor, spell) => spell.system?.blocked !== true,
  metamagicCatalogue: async () => helpers.catalogue ?? [],
  catalogue: []
};
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = {
  applications: { api: { DialogV2: { confirm: async () => true, prompt: async (cfg) => { prompts.push(cfg.window?.title); helpers.lastPrompt = String(cfg.content ?? ""); return helpers.nextForm ?? null; }, wait: async () => null } }, ux: { FormDataExtended: class { constructor() { this.object = {}; } } } },
  utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, deepClone: (x) => JSON.parse(JSON.stringify(x)), randomID: () => "r1" }
};
globalThis.fromUuid = async (u) => uuidMap.get(u) ?? null;
globalThis.fromUuidSync = (u) => uuidMap.get(u) ?? null;
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.Roll = class { constructor(f) { this.formula = f; } async evaluate() { const m = /(\d+)d(\d+)/.exec(this.formula); this.total = m ? Number(m[1]) * 3 : 0; return this; } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent, actor: parent };
  it.uuid = `${parent?.uuid ?? "World"}.Item.${it.id}`;
  it.flags = it.flags ?? {};
  it.system = it.system ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  return it;
}
const hookOnDelete = { on: false, fn: null };
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.uuid = `${a.uuid}.ActiveEffect.${e.id}`;
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  // AS FOUNDRY DOES (0.9.2, live test): a second delete of the same effect
  // throws, and a delete fires deleteActiveEffect (onEffectDeletedB6D) when
  // a check turns `hookOnDelete` on.
  e.delete = async () => {
    if (!a.effects.includes(e)) throw new Error(`ActiveEffect "${e.id}" does not exist!`);
    a.effects = a.effects.filter((x) => x !== e); uuidMap.delete(e.uuid);
    if (hookOnDelete.on) await hookOnDelete.fn?.(e);
  };
  uuidMap.set(e.uuid, e);
  return e;
}
function makeActor(name, { level = 8, items = [], pp = 20, hp = 10, cl = 8, ability = 3, tradition = "arcane" } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [], documentName: "Actor" };
  a.system = { identity: { level }, resources: { pp: { value: pp }, hp: { value: hp } }, magic: { casterLevelValue: cl, tradition, spellcraft: { ability, dc: 20 } } };
  a.items = Object.assign(items.map((d) => makeItem(d, a)), { get(id) { return this.find((i) => i.id === id); } });
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = list.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100 };
  t.document = { actor, disposition, width: 1, height: 1, uuid: `Scene.s.Token.${id}`, _source: { x: x - 50, y: y - 50, width: 1, height: 1 } };
  actor.token = t;
  return t;
}
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.684.0" }
};
// 5 ft a square of 100 px.
globalThis.canvas = {
  tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) }
};

const C = await import(new URL("./content/block6-d.mjs", import.meta.url));
const R = await import(new URL("../module/block6d-automations.mjs", import.meta.url));
Object.assign(STEPS, { [R.SUBCONSCIOUS_STEP]: R.STEPS_B6_D.subconsciousStep });
const F = Object.fromEntries(C.FEATS_B6_D.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS];
const featDoc = (name, extra = {}) => ({ type: "feat", name, system: { traits: F[name]?.system.traits ?? "", usesPerDay: "", usesValue: 1, ...(extra.system ?? {}) }, flags: extra.flags ?? {} });

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
const LIST = {
  "ARCANE FENCER": ["Metamagic, Spellblade", "Weapon Focus, BAB +2"], "CONDUIT MASTERY": ["Adept", "Level 16, Dual Channel"], "DUAL CHANNEL": ["Adept", "level 6"],
  "EXTRA CANTRIP": ["Adept", "Level 4"], "FOCUSED SPELL": ["Adept, Metamagic", ""], "LIGHTNING ROD": ["Metamagic, Stormcaller", "Arcana or Survival 10 ranks, Thunderclap Aura"],
  "MANA BOUND": ["Adept", "BSB +4"], "METAMAGIC CONDUIT": ["Adept", "at least any one metamagic feat, BSB +8"], "PACT CHANNELER": ["Metamagic, Warlock, Witch", "Level 6, Pact Archetype feat"],
  "SENSORY SPELL": ["Adept, Metamagic, Shadow", ""], "SPELLTHREAD": ["Adept, Metamagic", "BSB +6"], "SPELLTHREAD MASTERY": ["Adept, Metamagic", "BSB +12, Spellthread"],
  "SPELLTHREAD UNBOUND": ["Adept, Metamagic", "BSB +12, Spellthread"], "STEELBINDING": ["Ferromancer, Metamagic", "Iron Ward"], "SUBCONSCIOUS CASTING": ["Adept, Focus, Metamagic", "BSB +8"],
  "THUNDERCLAP AURA": ["Metamagic, Stormcaller", "Survival 6 ranks"], "UNFETTERED MASTERY": ["Archmage, Focus, Metamagic, Sorcerer", "BSB +10"],
  "VERSATILE BINDER": ["Adept, Metamagic", "Ability to cast at least one spell with the Summons trait"], "WEAVE INFUSION": ["Adept", "BSB +6"], "RESONANT CONDUIT": ["Adept", "Level 10, Dual Channel"]
};
const MARK = { A: /<em>Automated \(0\.9\.0, TRG Prime 3\.684\.0\):<\/em>/, B: /<em>Automated \((0\.9\.0, TRG Prime 3\.684\.0|0\.11\.0, TRG Prime 3\.686\.0)\):<\/em>/, C: /<em>Partly automated \(0\.9\.0, TRG Prime 3\.684\.0\):<\/em>/, D: /<em>Not (yet )?automated:<\/em>/ };
{
  const common = await import(new URL("./content/block6-common.mjs", import.meta.url));
  const cls = new Map(book.sections.classFeats.map((f) => [f.name, f]));
  // Every METAMAGIC or ADEPT class feat the book prints is this group's, but Hex Mastery (group E's, a Witch feat).
  const printedMM = book.sections.classFeats.filter((f) => f.traits.some((t) => /^(METAMAGIC|ADEPT)$/.test(t))).map((f) => f.name).filter((n) => n !== "HEX MASTERY");
  equal("A twenty feats: every METAMAGIC and ADEPT class feat but Hex Mastery (group E)", [...printedMM].sort(), Object.keys(LIST).sort());
  equal("A …built in the book's names", C.FEATS_B6_D.map((f) => f.name).sort(), Object.keys(LIST).map(common.titleCase).sort());
  for (const [key, [traits, prereq]] of Object.entries(LIST)) {
    const f = F[common.titleCase(key)];
    const b = cls.get(key);
    ok(`A ${key}: built and printed`, Boolean(f && b));
    if (!f || !b) continue;
    equal(`A ${f.name}: a class feat, its traits as stored, its prerequisites`, [f.type, f.system.category, f.system.traits, f.system.prerequisites], ["feat", "Class", traits, prereq]);
    equal(`A ${f.name}: the prerequisite is the book's`, f.system.prerequisites, b.fields?.Prerequisites ?? "");
    const plain = (t) => String(t).replace(/<[^>]+>/g, "").replace(/\*\*?/g, "").replace(/&#39;|&rsquo;/g, "’").replace(/\s+/g, " ");
    ok(`A ${f.name}: the card prints every line of the book's text`, b.lines.every((l) => plain(f.system.description).includes(plain(l).slice(0, 60))));
    equal(`A ${f.name}: Block 6 and its book line`, [fl(f.name).eaBlock, fl(f.name).eaBookLine], [6, b.line]);
    const row = C.AUTOMATION_B6_D[f.name];
    ok(`A ${f.name}: the docs' grade (${row?.level}) agrees with its card`, Boolean(row && MARK[row.level]?.test(f.system.description)));
    ok(`A ${f.name}: the module's automation key is set`, typeof fl(f.name).eaAutomation === "string" && fl(f.name).eaAutomation.length > 3);
  }
  equal("A the docs' table names every feat", Object.keys(C.AUTOMATION_B6_D).sort(), C.FEATS_B6_D.map((f) => f.name).sort());
  equal("A graded A 4, B 13, C 3, D 0 (Versatile Binder C → B at 0.11.0)", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B6_D).filter((r) => r.level === l).length), [4, 13, 3, 0]);
  equal("A …the A feats are the passive rules", Object.entries(C.AUTOMATION_B6_D).filter(([, r]) => r.level === "A").map(([n]) => n).sort(), ["Conduit Mastery", "Dual Channel", "Mana Bound", "Resonant Conduit"]);
  equal("A …the C feats each leave a clause to the GM (Spellthread ×3)", Object.entries(C.AUTOMATION_B6_D).filter(([, r]) => r.level === "C").map(([n]) => n).sort(), ["Spellthread", "Spellthread Mastery", "Spellthread Unbound"]);
  ok("A every C card says what is the GM's", ["Spellthread", "Spellthread Mastery", "Spellthread Unbound"].every((n) => /GM's/.test(F[n].system.description)));
  ok("A the cards cite their rulings", [["Lightning Rod", "Q127"], ["Metamagic Conduit", "Q130"], ["Weave Infusion", "Q131"], ["Subconscious Casting", "Q128"], ["Thunderclap Aura", "Q129"], ["Spellthread", "Q126"], ["Versatile Binder", "Q133"], ["Pact Channeler", "Q95"], ["Focused Spell", "Q94"], ["Subconscious Casting", "Q96"]].every(([n, q]) => F[n].system.description.includes(q)));
  ok("A the hyphen-free archetype traits are stored as the registered names (Spellblade, Stormcaller, Ferromancer, Warlock, Witch)", ["Arcane Fencer", "Lightning Rod", "Thunderclap Aura", "Steelbinding", "Pact Channeler"].every((n) => !/-/.test(F[n].system.traits)));
  ok("A Steelbinding's restored Requirements is on its card (m45)", /Requirements\*\*|<strong>Requirements<\/strong>/.test(F.Steelbinding.system.description) && /wearing metal armour who is within 30-ft/.test(F.Steelbinding.system.description));
  equal("A Extra Cantrip is repeatable; the others are not", C.FEATS_B6_D.filter((f) => f.system.repeatable).map((f) => f.name), ["Extra Cantrip"]);
  equal("A the Focus feats are the book's (Subconscious Casting, Unfettered Mastery)", C.FEATS_B6_D.filter((f) => /\bFocus\b/.test(f.system.traits)).map((f) => f.name).sort(), ["Subconscious Casting", "Unfettered Mastery"]);
  equal("A the five deferred feats are listed for the docs with their new grades", Object.fromEntries(Object.entries(C.DEFERRED_B6_D).map(([n, r]) => [n, r.level])), { "Echo of the Ancestors": "B", "Resonant Pulse": "B", "Resonant Harmony": "B", "Spell Surge": "B", "Piercing Insight": "C" });
}

// The five deferred cards, read from their own files.
const B5A = await import(new URL("./content/block5-a.mjs", import.meta.url));
const B5B = await import(new URL("./content/block5-b.mjs", import.meta.url));
const B5D = await import(new URL("./content/block5-d.mjs", import.meta.url));
const B1 = await import(new URL("./content/block1.mjs", import.meta.url));
const findFeat = (list, n) => list.find((f) => f.name === n);
{
  const pulse = findFeat(B5A.FEATS_B5_A, "Resonant Pulse"), harmony = findFeat(B5A.FEATS_B5_A, "Resonant Harmony");
  const echo = findFeat(B5B.FEATS_B5_B, "Echo of the Ancestors"), piercing = findFeat(B5D.FEATS_B5_D, "Piercing Insight");
  const surge = (B1.BACKGROUND_FEATS ?? []).find((f) => f.name === "Spell Surge");
  ok("A deferred: all five items are still built where they were", Boolean(pulse && harmony && echo && piercing && surge));
  ok("A deferred: Pulse, Harmony, Echo and Surge say automated in 0.9.0", [pulse, harmony, echo, surge].every((f) => MARK.B.test(f?.system.description ?? "")));
  ok("A deferred: Piercing Insight says partly automated in 0.9.0, the GM applying the effect", MARK.C.test(piercing?.system.description ?? "") && /the GM applies it/.test(piercing.system.description));
  ok("A deferred: Pulse's card follows Q94 (no item casts; the old 'item casts too' gone)", /not a charged item's spell/.test(pulse.system.description) && !/reaches innate and item casts too/.test(pulse.system.description) && /Q94/.test(pulse.system.description));
  ok("A deferred: Echo's card keeps Q75 (half damage, rounded down, its own save)", /Q75/.test(echo.system.description) && /half the damage, rounded down/.test(echo.system.description) && /its own save/.test(echo.system.description));
  ok("A deferred: Spell Surge's card names its four and Q132", ["range +50%", "duration +50%", "+2 class bonus to the Save DC", "+1 die of damage", "Q132"].every((s) => surge.system.description.includes(s)));
  equal("A deferred: their docs' rows are B, B, B, C", [B5A.AUTOMATION_B5_A["Resonant Pulse"].level, B5A.AUTOMATION_B5_A["Resonant Harmony"].level, B5B.AUTOMATION_B5_B["Echo of the Ancestors"].level, B5D.AUTOMATION_B5_D["Piercing Insight"].level], ["B", "B", "B", "C"]);
  /* B */
  equal("B Spell Surge stores the Focus trait (Q132; the book prints none)", surge.system.traits, "Focus");
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
equal("B Extra Cantrip declares one bonus cantrip a copy (G25)", fl("Extra Cantrip").cantripBonus, 1);
equal("B Lightning Rod opts into the compound skill prerequisite (G9)", fl("Lightning Rod").compoundSkillPrerequisites, true);
equal("B no other feat opts in", C.FEATS_B6_D.filter((f) => f.flags[SYS].compoundSkillPrerequisites).map((f) => f.name), ["Lightning Rod"]);
equal("B the module's own flags are ea-prefixed", C.FEATS_B6_D.flatMap((f) => Object.keys(f.flags[SYS]).filter((k) => !k.startsWith("ea") && !["cantripBonus", "compoundSkillPrerequisites"].includes(k))), []);

/* ----------------------------------------------------------------- */
/* C — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
const MMcore = await import(sys("module", "magic", "module-metamagic.mjs"));
const casting = await import(sys("module", "magic", "casting.mjs"));
const CIR = await import(sys("module", "charged-item-rules.mjs"));
const prereq = await import(sys("module", "prerequisites.mjs"));
const hooksCore = await import(sys("module", "magic", "cast-hooks.mjs"));
const fumbleCore = await import(sys("module", "magic", "fumble-resonance-modifiers.mjs"));
{
  // E — registration, through the core's real registry.
  const api = { ...capi, registerFeatAutomation: capi.queueFeatAutomation };
  const before = capi.registeredMetamagic().length;
  await quiet(() => R.registerBlock6D(api, MOD));
  const keys = capi.registeredMetamagic().map((s) => s.key).sort();
  equal("E fourteen metamagic options registered through G1 (every one accepted by the core's normaliser)", [capi.registeredMetamagic().length - before, keys], [14, Object.values(R.MM).sort()]);
  equal("E …none is a core id", keys.filter((k) => ["quicken", "extend", "reach", "empower"].includes(k)), []);
  const spec = (k) => capi.registeredMetamagic().find((s) => s.key === k);
  equal("E the PP each costs (book): Focused 3, Lightning Rod 2, Pact 1, Sensory 1, Spellthread 2, Steelbinding 2, Subconscious 6, Thunderclap 2, Unfettered 0, Binder 1, Echo 2, Pulse 0, Harmony 0, Surge 1",
    [R.MM.focused, R.MM.lightningRod, R.MM.pact, R.MM.sensory, R.MM.thread, R.MM.steel, R.MM.subconscious, R.MM.thunderclap, R.MM.unfettered, R.MM.binder, R.MM.echo, R.MM.pulse, R.MM.harmony, R.MM.surge].map((k) => spec(k).ppCost), [3, 2, 1, 1, 2, 2, 6, 2, 0, 1, 2, 0, 0, 1]);
  equal("E the Focus options: Unfettered, Echo, Pulse, Harmony, Surge (Subconscious spends its own, as a preset)", capi.registeredMetamagic().filter((s) => s.focus && Object.values(R.MM).includes(s.key)).map((s) => s.key).sort(), [R.MM.unfettered, R.MM.echo, R.MM.pulse, R.MM.harmony, R.MM.surge].sort());
  equal("E Subconscious Casting is preset only (S-M4), never offered", [spec(R.MM.subconscious).preset, Object.values(R.MM).filter((k) => spec(k).preset)], [true, [R.MM.subconscious]]);
  equal("E Unfettered Mastery is a Quicken (one Quicken a cast)", spec(R.MM.unfettered).kind, "quicken");
  equal("E Focused Spell and Spellthread never reach an innate or item cast", [R.MM.focused, R.MM.thread].map((k) => [MMcore.scopeAdmits(spec(k), "innate"), MMcore.scopeAdmits(spec(k), "item"), MMcore.scopeAdmits(spec(k), "learned")]), [[false, false, true], [false, false, true]]);
  equal("E Q94: Pulse, Echo, Pact reach innate casts", [R.MM.pulse, R.MM.echo, R.MM.pact].map((k) => MMcore.scopeAdmits(spec(k), "innate")), [true, true, true]);
  equal("E the options opened by their feats (Block 5's, Block 1's and this group's names)", Object.values(R.MM).map((k) => spec(k).feats[0]).sort(), [R.FEAT.focused, R.FEAT.lightningRod, R.FEAT.pact, R.FEAT.sensory, R.FEAT.thread, R.FEAT.steel, R.FEAT.subconscious, R.FEAT.thunderclap, R.FEAT.unfettered, R.FEAT.binder, R.FEAT.echo, R.FEAT.pulse, R.FEAT.harmony, R.FEAT.surge].sort());
  ok("E every opening feat exists as an item", [...C.FEATS_B6_D, ...B5A.FEATS_B5_A, ...B5B.FEATS_B5_B, ...(B1.BACKGROUND_FEATS ?? [])].map((f) => f.name).filter((n) => capi.registeredMetamagic().some((s) => s.feats[0] === n)).length === 14);
  equal("E Spellthread, Echo and Harmony need a spell (left out of Piercing Insight's catalogue)", Object.values(R.MM).filter((k) => spec(k).needsSpell).sort(), [R.MM.thread, R.MM.echo, R.MM.harmony].sort());
  equal("E five charged-item rules (G6)", capi.registeredChargedItemRules().map((r) => r.key).filter((k) => Object.keys(R.CHARGED_RULES_B6_D).map((x) => x.toLowerCase()).includes(k)).length, 5);
  ok("E Mana Bound's fumble modifier, Spellthread's remap, Arcane Fencer's reaction, Subconscious's offer and step are registered",
    capi.registeredFumbleModifiers().some((m) => m.key === "manabound") && capi.registeredCastDegreeRemaps().some?.((r) => r) !== undefined
    && capi.registeredCheckReactions().some((r) => r.key === "arcanefencer") && capi.registeredUnconsciousOffers().some((o) => o.key === "subconsciouscasting") && typeof capi.registeredReactionStep(R.SUBCONSCIOUS_STEP) === "function");
  ok("E Extra Cantrip's Use is queued", capi.queuedFeatAutomation().has("extra cantrip"));
  ok("E G9: Pact Channeler and Metamagic Conduit check eligibility", capi.featEligibilityBlock("Pact Channeler", makeActor("NoPact")) !== null && capi.featEligibilityBlock("Metamagic Conduit", makeActor("NoMM")) !== null);
  ok("E …and pass when met", capi.featEligibilityBlock("Pact Channeler", makeActor("Pacted", { items: [{ type: "feat", name: "Fey Pact", system: {} }] })) === null
    && capi.featEligibilityBlock("Metamagic Conduit", makeActor("MMer", { items: [{ type: "feat", name: "Quicken Spell", system: { traits: "Metamagic" } }] })) === null);
  const remapped = await quiet(() => hooksCore.remapCastDegree({ degree: "partial", metamagic: [R.MM.thread], threaded: false }));
  equal("E Spellthread's remap runs in the core's remap (Partial → Failure)", remapped.degree, "failure");
  const fm = await quiet(() => fumbleCore.fumbleModifiersFrom({ actor: makeActor("MB", { items: [featDoc("Mana Bound")] }), blunder: false, check: { type: "spellcraft" } }));
  const fmBlunder = await quiet(() => fumbleCore.fumbleModifiersFrom({ actor: makeActor("MB3", { items: [featDoc("Mana Bound")] }), blunder: true, check: { type: "spellcraft" } }));
  equal("E Mana Bound through the core's fumble modifiers: −20 on a Fumble, nothing on a Blunder", [fm?.modifier, fmBlunder?.modifier], [-20, 0]);
}
{
  // G1's fold and arithmetic with this group's answers.
  const fold = (answer, offer = { key: "x", label: "X", ppCost: 0 }) => MMcore.foldModuleMetamagic(MMcore.emptyModuleMetamagic(), offer, { key: "x", times: 1, choice: "" }, MMcore.cleanMetamagicAnswer(answer));
  equal("C Focused Spell folds to advantage on the check", fold(R.METAMAGIC_B6_D[R.MM.focused].effects).checkBias, "advantage");
  equal("C Pulse folds to an untyped +1 Save DC row", fold(R.METAMAGIC_B6_D[R.MM.pulse].effects).saveDCRows.map((r) => [r.value, r.type]), [[1, "untyped"]]);
  const wm = MMcore.foldModuleMetamagicMods({}, fold(R.surgeAnswer("save", {})), {});
  equal("C Spell Surge's +2 is a class row, applied once", wm.warpMods.saveDC, 2);
  const surgeRange = MMcore.foldModuleMetamagicMods({}, fold(R.surgeAnswer("range", {})), { range: "30 feet" });
  equal("C Spell Surge's range ×1.5: 30 feet → 45 feet", surgeRange.warpMods.rangeOverride, "45 feet");
  const th = fold(R.threadAnswer([{ name: "Haste", system: { ppCost: 3, castAP: 3 } }], 2));
  equal("C Spellthread folds its woven base PP, AP, step and biases", [th.basePPAdd, th.apDelta, th.savingStep, th.fumbleBias, th.resonanceBias], [3, 1, 1, "disadvantage", "disadvantage"]);
  equal("C sidebar 15 by the core's castingOutcome: Heroic pays as a Critical, a Critical as a Success", [casting.castingOutcome("heroic", { basePP: 6, warpPP: 2, savingStep: 1 }).ppSpent, casting.castingOutcome("critical", { basePP: 6, warpPP: 2, savingStep: 1 }).ppSpent, casting.castingOutcome("critical", { basePP: 6, warpPP: 2 }).ppSpent], [casting.castingOutcome("critical", { basePP: 6, warpPP: 2 }).ppSpent, 8, casting.castingOutcome("critical", { basePP: 6, warpPP: 2 }).ppSpent]);
  const pact = fold(R.pactAnswer({ patron: "demonic" }, { spellData: { damage: { formula: "3d6" } }, damageTypes: ["cold"] }, 8));
  equal("C Pact Channeler (Demonic) folds the Fire trait and a 2d6 fire pool", [pact.addTraits, pact.addedDamage.map((d) => [d.dice, d.type])], [["Fire"], [["2d6", "fire"]]]);
  const echo = fold({ targets: { extra: [{ tokenUuid: "Scene.s.Token.t2", damageFactor: 0.5 }] } });
  equal("C Echo folds a second creature at half damage (Q75)", echo.extra.map((r) => r.damageFactor), [0.5]);
  const q = MMcore.foldModuleMetamagic(MMcore.emptyModuleMetamagic(), { key: R.MM.unfettered, label: "U", ppCost: 0, kind: "quicken", spec: { payment: { kind: "pp" } } }, { key: R.MM.unfettered, times: 1 }, MMcore.cleanMetamagicAnswer({}), { coreQuickened: false });
  const q2 = MMcore.foldModuleMetamagic(MMcore.emptyModuleMetamagic(), { key: R.MM.unfettered, label: "U", ppCost: 0, kind: "quicken", spec: { payment: { kind: "pp" } } }, { key: R.MM.unfettered, times: 1 }, MMcore.cleanMetamagicAnswer({}), { coreQuickened: true });
  equal("C Unfettered Mastery: 1 AP less, and nothing more beside Quicken Spell", [q.apDelta, q2.apDelta], [-1, 0]);
  equal("C the scope (Q94): a cantrip, a scroll, a stored spell take none; an item only with Metamagic Conduit", [MMcore.moduleMetamagicScope({ cantrip: true }).allowed, MMcore.moduleMetamagicScope({ itemCast: true }).allowed, MMcore.moduleMetamagicScope({ stored: true }).allowed, MMcore.moduleMetamagicScope({ itemCast: true, itemMetamagic: true }).kind], [false, false, false, "item"]);
  // G6's arithmetic with the rules' answers.
  const cm = R.conduitMasteryCost({ reason: "castFromItem" });
  equal("C Conduit Mastery: 3 PP → 2; 1 PP stays 1; a Rod of the Magi draw is not cut", [CIR.chargedItemCost(3, [cm]).pp, CIR.chargedItemCost(1, [cm]).pp, R.conduitMasteryCost({ reason: "ppSource" })], [2, 1, null]);
  equal("C Resonant Conduit's free answer pays nothing", CIR.chargedItemCost(4, [{ free: true }]).pp, 0);
  equal("C the wield limits: 1 alone, 2 with Dual Channel, 3 with Conduit Mastery", [CIR.chargedWieldLimit([]), CIR.chargedWieldLimit([2]), CIR.chargedWieldLimit([2, 3])], [1, 2, 3]);
  const wi = R.CHARGED_RULES_B6_D.weaveInfusion.payment({ actor: makeActor("Weaver", { items: [featDoc("Weave Infusion")] }) });
  equal("C Weave Infusion: own PP, empty allowed, depletion at disadvantage (the lower d100, Q131)", [CIR.chargedItemPayment([wi]).ownPP, CIR.chargedItemPayment([wi]).allowEmpty, CIR.chargedItemPayment([wi]).depletionBias, CIR.depletionKept(70, 20, "disadvantage")], [true, true, "disadvantage", 20]);
  const mc = R.CHARGED_RULES_B6_D.metamagicConduit.metamagic({ actor: makeActor("Conduit", { items: [featDoc("Metamagic Conduit")] }) });
  equal("C Metamagic Conduit: allowed, ceiling double the release PP (Q130)", [CIR.chargedItemMetamagic(4, [mc]).allowed, CIR.chargedItemMetamagic(4, [mc]).ceiling, MMcore.itemMetamagicCeilingRefusal({ releasePP: 4, metamagicPP: 5 }) !== ""], [true, 8, true]);
  equal("C …and nothing without the feat", R.CHARGED_RULES_B6_D.metamagicConduit.metamagic({ actor: makeActor("Plain") }), null);
  // G9: the parser with the opt-in.
  const lr = (ranks) => prereq.meetsParseablePrerequisites("Arcana or Survival 10 ranks, Thunderclap Aura", { compoundSkills: true, skillRanks: ranks, knownNames: new Set(["thunderclap aura"]), ownedNames: new Set(["thunderclap aura"]) });
  equal("C Lightning Rod's prerequisite: Arcana or Survival at 10 ranks, read with the opt-in", [lr({ arcana: 10 }), lr({ survival: 10 }), lr({ arcana: 9, survival: 9 })], [true, true, false]);
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  const w = (traits = "") => ({ system: { traits } });
  equal("D Arcane Fencer's trigger: a one-handed melee Strike", [
    R.fencerApplies({ type: "attack", attackMode: "melee", weaponUuid: "w", twoHanded: false }, w("Finesse")),
    R.fencerApplies({ type: "attack", attackMode: "melee", weaponUuid: "w", twoHanded: true }, w("")),
    R.fencerApplies({ type: "attack", attackMode: "melee", weaponUuid: "w", twoHanded: false }, w("Two-Handed")),
    R.fencerApplies({ type: "attack", attackMode: "ranged", weaponUuid: "w", twoHanded: false }, w("")),
    R.fencerApplies({ type: "save", attackMode: "melee", weaponUuid: "w" }, w(""))], [true, false, false, false, false]);
  equal("D Arcane Fencer: up to the caster level and the pool; +1 status a PP", [R.fencerMax(8, 20), R.fencerMax(8, 3), R.fencerModifiers(4)], [8, 3, [{ label: "Arcane Fencer", value: 4, type: "status" }]]);
  equal("D Dual Channel: a release's Fumble or Blunder", [R.dualChannelDue({ kind: "release", degree: "fumble" }), R.dualChannelDue({ kind: "release", degree: "blunder" }), R.dualChannelDue({ kind: "release", degree: "failure" }), R.dualChannelDue({ kind: "rod", degree: "fumble" })], [true, true, false, false]);
  equal("D Resonant Conduit: two wielded, unspent, not a draw, something due", [R.resonantConduitFree({ wielded: [1, 2], pp: 3 }), R.resonantConduitFree({ wielded: [1], pp: 3 }), R.resonantConduitFree({ wielded: [1, 2], pp: 3 }, true), R.resonantConduitFree({ wielded: [1, 2], pp: 3, reason: "ppSource" })], [true, false, false, false]);
  equal("D Mana Bound: −20 on a Spellcraft fumble, not a Blunder or a skill release", [R.manaBoundModifier({ check: { type: "spellcraft" } })?.modifier, R.manaBoundModifier({ blunder: true, check: { type: "spellcraft" } }), R.manaBoundModifier({ check: { type: "skill" } }), R.manaBoundModifier({ check: { type: "concentration" } })], [-20, null, null, null]);
  equal("D Extra Cantrip: one copy every four levels", [R.extraCantripRefusal(0, 4), R.extraCantripRefusal(0, 3) !== "", R.extraCantripRefusal(1, 7) !== "", R.extraCantripRefusal(1, 8)], ["", true, true, ""]);
  equal("D Lightning Rod's splash: half the dice count, rounded down, with the warps' dice", [R.splashDice("6d6"), R.splashDice("5d8+2"), R.splashDice("4d6", "2d6"), R.splashDice("1d6"), R.splashDice("")], ["3d6", "2d8", "3d6", "", ""]);
  equal("D Lightning Rod's −2: automatic in metal armour, a tick otherwise; saves vs electricity, one-shot", [R.lightningRodConditionals(true).map((c) => [c.value, c.auto, c.oneShot, c.when]), R.lightningRodConditionals(false)[0].auto], [[[-2, true, true, { checkTypes: ["save"], traits: ["electricity"] }]], false]);
  equal("D electricity dealt: printed or Elemental Spell's, and only by a damaging spell", [R.dealsElectricity(["electricity"]), R.dealsElectricity(["fire"], ["electricity"]), R.dealsElectricity([], ["electricity"]), R.dealsElectricity(["fire"])], [true, true, false, false]);
  equal("D Thunderclap Aura: 1d6 per 2 PP of the total (Q129)", [R.thunderclapDice(7), R.thunderclapDice(2), R.thunderclapDice(1)], ["3d6", "1d6", ""]);
  equal("D Pact Channeler's numbers: 2d6, 4d6 at 14; Fey 1, 2 at 14", [R.pactDice(13), R.pactDice(14), R.pactFeyPenalty(13), R.pactFeyPenalty(14)], ["2d6", "4d6", 1, 2]);
  const arch = (name, flags = {}) => [{ type: "feat", name, flags: { [SYS]: flags } }];
  equal("D the patron and type read from the Pact archetype", [R.pactOf(arch("Void Pact"))?.patron, R.pactOf(arch("Draconic Pact", { eaEnergy: "fire" }))?.energy, R.pactOf(arch("Elemental Pact", { eaElement: "air" }))?.energy, R.pactOf(arch("Elemental Pact", { eaElement: "air" }))?.trait, R.pactOf(arch("Elemental Pact", { eaElement: "earth" }))?.energy, R.pactOf([])],
    ["void", "fire", "electricity", "Air", "acid", null]);
  // Group A's Uses write these keys (block6a-automations: draconicPact eaEnergy, elementalPact eaElement).
  equal("D Draconic and Elemental wait for their type", [R.pactReady(R.pactOf(arch("Draconic Pact"))), R.pactReady(R.pactOf(arch("Draconic Pact", { eaPactType: "cold" }))), R.pactReady(R.pactOf(arch("Fey Pact")))], [false, true, true]);
  const dmg = { spellData: { damage: { formula: "4d6" } }, damageTypes: ["fire", "cold"] };
  equal("D Pact Channeler's channels", [
    R.pactAnswer({ patron: "angelic" }, { spellData: { effects: [{ kind: "heal" }] } }, 6).mods,
    R.pactAnswer({ patron: "angelic" }, dmg, 6).mods,
    R.pactAnswer({ patron: "draconic", energy: "fire", trait: "Fire" }, dmg, 6).mods,
    R.pactAnswer({ patron: "elemental", energy: "cold", trait: "Water" }, dmg, 14).mods,
    R.pactAnswer({ patron: "draconic", energy: "acid", trait: "Acid" }, dmg, 6).mods,
    R.pactAnswer({ patron: "grave" }, dmg, 6).addedDamage,
    R.pactAnswer({ patron: "grave" }, { damageTypes: [] }, 6).addedDamage,
    R.pactAnswer({ patron: "fey" }, { defence: "Will" }, 6).saveDC,
    R.pactAnswer({ patron: "fey" }, { defence: "Reflex" }, 6).saveDC,
    R.pactAnswer({ patron: "void" }, {}, 6).addTraits,
    R.pactAnswer({ patron: "draconic", energy: "" }, dmg, 6).cancel
  ], [{ healDice: "2d6" }, undefined, { damageDice: "2d6" }, { secondaryDice: "4d6" }, undefined, [{ dice: "2d6", type: "essence", label: "Pact Channeler" }], undefined, [{ value: 1, type: "untyped", label: "Pact Channeler (Fey)" }], undefined, ["Mental"], true]);
  equal("D Spell Surge's choices where they apply", [R.surgeChoices({ range: "60 feet", duration: "1 minute", defence: "Reflex", spellData: { damage: { formula: "3d8" } } }).map((c) => c.value), R.surgeChoices({ range: "Touch", duration: "Instantaneous", defence: "" }).map((c) => c.value)], [["range", "duration", "save", "damage"], []]);
  equal("D Spell Surge's answers: ×1.5, +2 class, +1 die; fumble and Resonance at disadvantage", [R.surgeAnswer("range").rangeFactor, R.surgeAnswer("duration").durationFactor, R.surgeAnswer("save").saveDC, R.surgeAnswer("damage", { spellData: { damage: { formula: "3d8+2" } } }).mods, R.surgeAnswer("save").fumbleBias, R.surgeAnswer("save").resonanceBias, R.surgeAnswer("").cancel],
    [1.5, 1.5, [{ value: 2, type: "class", label: "Spell Surge" }], { damageDice: "1d8" }, "disadvantage", "disadvantage", true]);
  equal("D Spellthread's remap: Partial → Failure, Failure → Fumble; not a woven spell, not without the option", [R.threadRemap({ degree: "partial", metamagic: [R.MM.thread] })?.degree, R.threadRemap({ degree: "failure", metamagic: [R.MM.thread] })?.degree, R.threadRemap({ degree: "success", metamagic: [R.MM.thread] }), R.threadRemap({ degree: "partial", metamagic: [R.MM.thread], threaded: true }), R.threadRemap({ degree: "partial", metamagic: [] })], ["failure", "fumble", null, null, null]);
  equal("D Spellthread's capacity: one woven, two with Mastery", [R.threadCapacity(false), R.threadCapacity(true)], [1, 2]);
  equal("D same tradition", [R.sameTradition("Arcane", "arcane"), R.sameTradition("Arcane, Divinity", "divinity"), R.sameTradition("Arcane", "Verdant")], [true, true, false]);
  equal("D Steelbinding's ladder (m42)", ["heroic", "critical", "success", "partial", "failure", "fumble", "blunder"].map((d) => R.steelTags(d, { inCombat: true, round: 3 }).map((t) => [t.key, t.value ?? null, t.expiresRound])), [[], [], [["slowed", 1, 5]], [["immobilised", null, 5]], [["immobilised", null, 5]], [["immobilised", null, 5]], [["immobilised", null, 5]]]);
  equal("D Steelbinding out of combat: 6 seconds", R.steelTags("success", { worldTime: 100 })[0].expiresTime, 106);
  equal("D metal armour: equipped armour with the Metal trait", [R.wearsMetalArmour([{ type: "armour", system: { equipped: true, traits: "Heavy, Metal" } }]), R.wearsMetalArmour([{ type: "armour", system: { equipped: false, traits: "Metal" } }]), R.wearsMetalArmour([{ type: "armour", system: { equipped: true, traits: "Light" } }])], [true, false, false]);
  equal("D the spell's save DC: 10 + PP + ability (+2 High Magic); an innate cast's own", [R.castSaveDC({ totalPP: 6, ability: 3 }), R.castSaveDC({ totalPP: 6, ability: 3, highMagic: true }), R.castSaveDC({ totalPP: 6, ability: 3, innateDC: 17 })], [19, 21, 17]);
  equal("D Sensory Spell's +2: one-shot, Deception, Intimidate or Perform", R.sensoryConditionals().map((c) => [c.value, c.oneShot, c.when.subjects]), [[2, true, ["deception", "intimidate", "perform"]]]);
  equal("D self-only spells (Harmony)", [R.selfOnly({ range: "Self" }), R.selfOnly({ range: "Self", area: "10-foot burst" }), R.selfOnly({ range: "Touch" })], [true, false, false]);
  equal("D a save (Pulse)", [R.hasSave("Will"), R.hasSave("Basic Reflex"), R.hasSave("DB"), R.hasSave("")], [true, true, false, false]);
  equal("D feet of a range", [R.feetOf("30 feet"), R.feetOf("Touch"), R.feetOf("60-ft."), R.feetOf("Self")], [30, 5, 60, null]);
  equal("D Subconscious Casting's spells: 1 AP, Self or Touch, not a cantrip, not innate", R.subconsciousSpells([
    { type: "spell", name: "Cure", system: { ppCost: 2, castAP: 1, range: "Touch" } }, { type: "spell", name: "Shield", system: { ppCost: 1, castAP: 1, range: "Self" } },
    { type: "spell", name: "Bolt", system: { ppCost: 2, castAP: 1, range: "60 feet" } }, { type: "spell", name: "Mend", system: { ppCost: 0, castAP: 1, range: "Touch" } },
    { type: "spell", name: "Heal", system: { ppCost: 4, castAP: 2, range: "Touch" } }, { type: "spell", name: "Gift", system: { ppCost: 2, castAP: 1, range: "Self", innate: true } }]).map((s) => s.name), ["Cure", "Shield"]);
  ok("D no load-time rewrite of owned Spell Surge copies (world data is not altered)", R.onReadyB6D === undefined && R.surgeTraitsFixed === undefined);
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side, with fakes                                    */
/* ----------------------------------------------------------------- */
const MMS = R.METAMAGIC_B6_D;
const reset = () => { cards.length = 0; answers.length = 0; prompts.length = 0; checkDegrees.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; helpers.nextForm = null; castResult = null; };
const place = (...list) => { canvas.tokens.placeables = list; };
{
  // Focused Spell, Unfettered Mastery, Thunderclap Aura, Steelbinding, Versatile Binder, Pulse, Harmony: applies.
  const me = makeActor("Caster", { items: [featDoc("Focused Spell")] });
  equal("F Focused Spell: learned casts that roll a check only", [MMS[R.MM.focused].applies({ rollsCheck: true }), MMS[R.MM.focused].applies({ rollsCheck: false, innate: true }), MMS[R.MM.focused].applies({ rollsCheck: true, itemCast: true })], [true, false, false]);
  equal("F Unfettered Mastery: High Magic, 2 AP or more", [MMS[R.MM.unfettered].applies({ highMagic: true, castAP: 2 }), MMS[R.MM.unfettered].applies({ highMagic: true, castAP: 1 }), MMS[R.MM.unfettered].applies({ highMagic: false, castAP: 3 })], [true, false, false]);
  equal("F Thunderclap Aura: an Air or Electricity trait", [MMS[R.MM.thunderclap].applies({ traits: "Air, Evocation" }), MMS[R.MM.thunderclap].applies({ traits: "Electricity" }), MMS[R.MM.thunderclap].applies({ traits: "Fire" })], [true, true, false]);
  equal("F Versatile Binder: a Summons trait", [MMS[R.MM.binder].applies({ traits: "Conjuration, Summons" }), MMS[R.MM.binder].applies({ traits: "Conjuration" })], [true, false]);
  equal("F Resonant Pulse: a spell with a save", [MMS[R.MM.pulse].applies({ defence: "Fortitude" }), MMS[R.MM.pulse].applies({ defence: "" })], [true, false]);
  equal("F Lightning Rod: electricity damage, or Elemental Spell's electricity", [MMS[R.MM.lightningRod].applies({ actor: me, damageTypes: ["electricity"] }), MMS[R.MM.lightningRod].applies({ actor: me, damageTypes: ["fire"] })], [true, false]);
  me.effects.push(makeEffect({ name: "Elemental Spell", flags: { [SYS]: { elementalSpellType: "electricity" } } }, me));
  equal("F …Elemental Spell's electricity opens it, and apply re-reads the effective type", [MMS[R.MM.lightningRod].applies({ actor: me, damageTypes: ["fire"] }), MMS[R.MM.lightningRod].apply({ actor: me, damageTypes: ["fire"] }).cancel, /no electricity damage/.test(MMS[R.MM.lightningRod].apply({ actor: me, damageTypes: ["fire"] }).lines[0]), MMS[R.MM.lightningRod].apply({ actor: me, damageTypes: ["electricity"] }).cancel], [true, undefined, true, undefined]);
  {
    const lrNo = await MMS[R.MM.lightningRod].after({ actor: me, cast: true, damageTypes: ["fire"], spellData: { traits: "Fire", damage: { formula: "2d6", type: "fire" } }, spellHits: [] });
    equal("F …taken without Elemental Spell's electricity: the cast goes on, nothing is marked, the card says why", [/no electricity damage/.test(lrNo.lines.at(-1)), me.effects.filter((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK).length], [true, 0]);
  }
}
{
  // Steelbinding: offered and resolved.
  reset();
  const caster = makeActor("Ferro", { items: [featDoc("Steelbinding")] });
  const knight = makeActor("Knight", { items: [{ type: "armour", name: "Plate", system: { equipped: true, traits: "Heavy, Metal" } }, { type: "weapon", name: "Longsword", system: { equipped: true, traits: "Metal" } }, { type: "weapon", name: "Club", system: { equipped: true, traits: "Wood" } }] });
  const monk = makeActor("Monk", { items: [{ type: "armour", name: "Robes", system: { equipped: true, traits: "Light" } }] });
  const tC = makeToken("tc", caster, { x: 0, y: 0 }), tK = makeToken("tk", knight, { x: 400, y: 0, disposition: -1 }), tM = makeToken("tm", monk, { x: 100, y: 0, disposition: -1 });
  const far = makeActor("FarKnight", { items: [{ type: "armour", name: "Plate", system: { equipped: true, traits: "Metal" } }] }); const tF = makeToken("tf", far, { x: 900, y: 0, disposition: -1 });
  place(tC, tK, tM, tF);
  equal("F Steelbinding: offered for a target in metal armour within 30 ft", [MMS[R.MM.steel].applies({ actor: caster, targets: [tK] }), MMS[R.MM.steel].applies({ actor: caster, targets: [tM] }), MMS[R.MM.steel].applies({ actor: caster, targets: [tF] })], [true, false, false]);
  checkDegrees.push("success");
  await MMS[R.MM.steel].after({ actor: caster, targets: [tK, tM], cast: true, totalPP: 6 });
  equal("F Steelbinding: without the core's saveDC, the knight's Fortitude vs 10 + 6 + 3", calls.checks, [{ actor: "Knight", type: "save", subject: "fortitude", dc: 19 }]);
  reset(); checkDegrees.push("success");
  await MMS[R.MM.steel].after({ actor: caster, targets: [tK], cast: true, totalPP: 6, saveDC: 23 });
  equal("F …the cast's own Save DC (the settled facts' saveDC) when the core passes it", calls.checks.map((c) => c.dc), [23]);
  equal("F …Success: Slowed 1", calls.conditions.map((c) => [c.target, c.tags.map((t) => [t.key, t.value ?? null])]), [["Knight", [["slowed", 1]]]]);
  reset(); checkDegrees.push("blunder"); answers.push(knight.items.find((i) => i.name === "Longsword").id);
  await MMS[R.MM.steel].after({ actor: caster, targets: [tK], cast: true, totalPP: 6 });
  equal("F …Blunder: Immobilised, and the chosen metal weapon dropped (only metal offered)", [calls.conditions[0]?.tags[0]?.key, helpers.lastOptions.map((o) => o[1]), knight.items.find((i) => i.name === "Longsword").system.equipped], ["immobilised", ["Longsword"], false]);
  reset(); checkDegrees.push("critical");
  await MMS[R.MM.steel].after({ actor: caster, targets: [tK], cast: true, totalPP: 6 });
  equal("F …Critical: no effect", calls.conditions, []);
  reset();
  equal("F …a cast that did not go off asks nothing", [await MMS[R.MM.steel].after({ actor: caster, targets: [tK], cast: false }), calls.checks.length], [null, 0]);
}
{
  // Thunderclap Aura.
  reset();
  const caster = makeActor("Storm", { items: [featDoc("Thunderclap Aura")] });
  await MMS[R.MM.thunderclap].after({ actor: caster, cast: true, totalPP: 7 });
  const a = calls.area[0]?.spec ?? {};
  equal("F Thunderclap Aura: a 10-ft area round you, 3d6 electricity for 7 PP, basic Fortitude vs DC 20", [a.scope, a.radiusFeet, a.damage, a.save, a.basic, a.dc], ["area", 10, { formula: "3d6", type: "electricity" }, "fortitude", true, 20]);
  reset();
  equal("F …on Success or better only", [await MMS[R.MM.thunderclap].after({ actor: caster, cast: false, totalPP: 7 }), calls.area.length], [null, 0]);
  await MMS[R.MM.thunderclap].after({ actor: caster, cast: true, totalPP: 7, innate: true, spell: {} });
  equal("F …an innate cast's DC is its innate save DC (G25)", calls.area[0]?.spec.dc, 19);
  reset();
  await MMS[R.MM.thunderclap].after({ actor: caster, cast: true, totalPP: 7, saveDC: 24 });
  equal("F …the cast's own Save DC when the core passes it", calls.area[0]?.spec.dc, 24);
}
{
  // Sensory Spell.
  reset();
  const caster = makeActor("Bard", { items: [featDoc("Sensory Spell")] });
  await MMS[R.MM.sensory].after({ actor: caster, cast: true });
  const e = caster.effects[0];
  equal("F Sensory Spell: a one-shot +2 effect, to the end of the turn", [caster.effects.length, e?.flags?.[SYS]?.conditionals?.[0]?.value, e?.flags?.[MOD]?.source], [1, 2, "sensorySpell"]);
  await MMS[R.MM.sensory].after({ actor: caster, cast: false });
  equal("F …nothing on a cast that did not go off", caster.effects.length, 1);
}
{
  // Echo of the Ancestors and Resonant Harmony.
  reset();
  const kin = makeActor("Kin", { items: [featDoc("Echo of the Ancestors", { system: { traits: "Focus, Metamagic" } }), { type: "heritage", name: "Cinderblood", flags: { [SYS]: { eaElement: "fire" } } }] });
  const foeA = makeActor("FoeA"), foeB = makeActor("FoeB"), pal = makeActor("Pal"), farFoe = makeActor("FarFoe");
  const tk = makeToken("tk", kin, { x: 0, y: 0 }), ta = makeToken("ta", foeA, { x: 300, y: 0, disposition: -1 }), tb = makeToken("tb", foeB, { x: 500, y: 0, disposition: -1 }), tp = makeToken("tp", pal, { x: 100, y: 0, disposition: 1 }), tfar = makeToken("tfar", farFoe, { x: 3000, y: 0, disposition: -1 });
  const pal2 = makeActor("Pal2"); const tp2 = makeToken("tp2", pal2, { x: 0, y: 600, disposition: 1 });
  place(tk, ta, tb, tp, tfar, tp2);
  const echo = MMS[R.MM.echo];
  equal("F Echo: offered on the heritage's element only", [echo.applies({ actor: kin, damageTypes: ["fire"], spellData: { damage: { formula: "4d6" } } }), echo.applies({ actor: kin, damageTypes: ["cold"], spellData: { damage: { formula: "4d6" } } })], [true, false]);
  answers.push("tb");
  const out = await echo.apply({ actor: kin, damageTypes: ["fire"], range: "60 feet", targets: [ta] });
  equal("F Echo: a creature within range not already targeted, at half damage", [helpers.lastOptions.map((o) => o[0]).sort(), out.targets.extra], [["tb", "tp", "tp2"], [{ tokenUuid: "Scene.s.Token.tb", damageFactor: 0.5, label: "Echo of the Ancestors" }]]);
  equal("F …none chosen cancels the option", (await echo.apply({ actor: kin, damageTypes: ["fire"], range: "60 feet", targets: [ta] })).cancel, true);
  { const no = await echo.apply({ actor: kin, damageTypes: ["cold"], range: "60 feet" });
    equal("F …Elemental Spell's type untaken: no cancel, no echo, a line saying why", [no.cancel, no.targets, /no echo/.test(no.lines[0])], [undefined, undefined, true]); }
  answers.push("tp");
  equal("F Harmony: offered on a self-only spell only", [MMS[R.MM.harmony].applies({ range: "Self" }), MMS[R.MM.harmony].applies({ range: "30 feet" }), MMS[R.MM.harmony].applies({ range: "Self", area: "20-foot burst" })], [true, false, false]);
  const sh = await MMS[R.MM.harmony].apply({ actor: kin });
  equal("F Harmony: only an adjacent ally is offered, and shares the self rows", [helpers.lastOptions.map((o) => o[0]), sh.targets.share], [["tp"], [{ tokenUuid: "Scene.s.Token.tp" }]]);
}
{
  // Pact Channeler, Void.
  reset();
  const lock = makeActor("Lock", { level: 6, items: [featDoc("Pact Channeler"), { type: "feat", name: "Void Pact", system: {} }] });
  const foe = makeActor("Foe"); const tf = makeToken("tf", foe, { disposition: -1 });
  equal("F Pact Channeler: offered with a Pact archetype", [MMS[R.MM.pact].applies({ actor: lock }), MMS[R.MM.pact].applies({ actor: makeActor("Nobody") })], [true, false]);
  await MMS[R.MM.pact].after({ actor: lock, cast: true, totalPP: 4, targets: [tf], saveDC: 22 });
  const a0 = calls.area[0]; reset();
  equal("F Void: the cast's own Save DC when the core passes it", a0?.spec.dc, 22);
  await MMS[R.MM.pact].after({ actor: lock, cast: true, totalPP: 4, targets: [tf] });
  const a = calls.area[0];
  equal("F Void: each target's Will save; Flat-Footed on a Failure or Fumble (and a Partial, a Blunder by the core's fallback)", [a?.spec.save, a?.opts.targets, Object.keys(a?.spec.conditions ?? {}).sort(), a?.spec.conditions.failure[0].key, a?.spec.dc], ["will", ["Foe"], ["failure", "fumble"], "flatFooted", 17]);
  reset();
  const angel = makeActor("Angel", { items: [featDoc("Pact Channeler"), { type: "feat", name: "Angelic Pact", system: {} }] });
  equal("F …no Will save for another patron", [await MMS[R.MM.pact].after({ actor: angel, cast: true, targets: [tf] }), calls.area.length], [null, 0]);
}
{
  // Spellthread.
  reset();
  const s = (name, tradition, ppCost, castAP = 2, extra = {}) => ({ type: "spell", name, system: { tradition, ppCost, castAP, ...extra } });
  const mage = makeActor("Mage", { items: [featDoc("Spellthread"), s("Bolt", "arcane", 3), s("Haste", "arcane", 4, 3), s("Bless", "divinity", 2), s("Light", "arcane", 0), s("Blocked", "arcane", 2, 2, { blocked: true })] });
  const primary = mage.items.find((i) => i.name === "Bolt");
  answers.push(mage.items.find((i) => i.name === "Haste").id);
  const ctx = { actor: mage, spell: primary, spellData: { tradition: "arcane" }, castAP: 2 };
  const ans = await MMS[R.MM.thread].apply(ctx);
  equal("F Spellthread: offers castable spells of the tradition, not cantrips, not itself", helpers.lastOptions.map((o) => o[1].split(" (")[0]), ["Haste"]);
  equal("F …Haste woven: +4 base PP, 1 AP more, sidebar 15", [ans.basePPAdd, ans.apDelta, ans.savingStep, ans.fumbleBias], [4, 1, 1, "disadvantage"]);
  castResult = { cast: true };
  await MMS[R.MM.thread].after({ ...ctx, cast: true, degree: "critical", check: { total: 25 } });
  equal("F …on a Critical the woven spell resolves under the same check and degree", calls.casts.map((c) => [c.spell, c.options.thread.degree, c.options.thread.check.total]), [["Haste", "critical", 25]]);
  reset();
  await MMS[R.MM.thread].after({ ...ctx, cast: false, degree: "fumble" });
  equal("F …nothing woven resolves on a failed weave", calls.casts.length, 0);
  // Unbound and Mastery.
  reset();
  const arch = makeActor("Arch", { items: [featDoc("Spellthread"), featDoc("Spellthread Unbound"), featDoc("Spellthread Mastery"), s("Bolt", "arcane", 3), s("Haste", "arcane", 4, 3), s("Bless", "divinity", 2)] });
  answers.push(arch.items.find((i) => i.name === "Bless").id, arch.items.find((i) => i.name === "Haste").id);
  const ans2 = await MMS[R.MM.thread].apply({ actor: arch, spell: arch.items.find((i) => i.name === "Bolt"), spellData: { tradition: "arcane" }, castAP: 2 });
  equal("F Unbound lifts the tradition, Mastery weaves a third", [ans2.basePPAdd, ans2.apDelta], [6, 1]);
  equal("F …no other spell: the option cancels", (await MMS[R.MM.thread].apply({ actor: makeActor("Lone", { items: [featDoc("Spellthread"), s("Bolt", "arcane", 3)] }), spell: null, spellData: { tradition: "arcane" }, castAP: 2 })).cancel, true);
}
{
  // Lightning Rod: mark, splash, the hook.
  reset();
  const rod = makeActor("Rod", { items: [featDoc("Lightning Rod")] });
  const marked = makeActor("Marked", { items: [{ type: "armour", name: "Mail", system: { equipped: true, traits: "Metal" } }] });
  const near = makeActor("Near"), farA = makeActor("Far"), ally = makeActor("Ally");
  const tr = makeToken("tr", rod, { x: 0, y: 0, disposition: 1 }), tm = makeToken("tm", marked, { x: 1000, y: 0, disposition: -1 }), tn = makeToken("tn", near, { x: 1150, y: 0, disposition: -1 }), tfa = makeToken("tfa", farA, { x: 1300, y: 0, disposition: -1 }), tal = makeToken("tal", ally, { x: 1100, y: 0, disposition: 1 });
  place(tr, tm, tn, tfa, tal);
  const spellData = { traits: "Electricity, Evocation", damage: { formula: "6d6" } };
  answers.push("tm");
  await MMS[R.MM.lightningRod].after({ actor: rod, cast: true, damageTypes: ["electricity"], spellData, spellHits: [{ target: marked }], saveResults: [] });
  const caster = rod.effects.find((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK);
  const onTarget = marked.effects.find((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARKED);
  equal("F Lightning Rod: the creature hit is offered and marked; the −2 is automatic in metal armour", [helpers.lastOptions.map((o) => o[0]), Boolean(caster), onTarget?.flags?.[SYS]?.conditionals?.[0]?.auto, caster?.flags?.[MOD]?.markedEffect === onTarget?.uuid], [["tm"], true, true, true]);
  await R.onSpellSettledB6D({ actor: rod, cast: true, spellData, warpMods: {} });
  equal("F …the marking cast's own settled hook splashes nothing", calls.damage.length, 0);
  await R.onSpellSettledB6D({ actor: rod, cast: true, spellData: { traits: "Fire", damage: { formula: "6d6" } }, warpMods: {} });
  equal("F …a spell without the electricity trait does not trigger it", [calls.damage.length, Boolean(rod.effects.find((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK))], [0, true]);
  await R.onSpellSettledB6D({ actor: rod, cast: true, spellData: { traits: "Electricity", damage: { formula: "4d8" } }, warpMods: { damageDice: "2d8" } });
  equal("F …the next electricity-trait spell: enemies within 10 ft of the mark, half the dice (3d8), no save; not the mark, not an ally", calls.damage.map((d) => [d.target, d.amount, d.type]), [["Near", 9, "electricity"]]);
  equal("F …and the mark ends on both", [rod.effects.filter((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK).length, marked.effects.length], [0, 0]);
  // A mark answered by the next Lightning Rod cast itself.
  reset(); answers.push("tm");
  await MMS[R.MM.lightningRod].after({ actor: rod, cast: true, damageTypes: ["electricity"], spellData: { ...spellData }, spellHits: [{ target: marked }] });
  reset(); answers.push("tn");
  const out = await MMS[R.MM.lightningRod].after({ actor: rod, cast: true, damageTypes: ["electricity"], spellData: { ...spellData }, spellHits: [{ target: near }] });
  equal("F …a second Lightning Rod cast splashes the old mark first, then marks anew (one mark)", [calls.damage.map((d) => d.target), rod.effects.filter((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK).map((e) => e.flags[MOD].markedActor), marked.effects.length, near.effects.length, out.lines.length], [["Near"], ["Actor.Near"], 0, 1, 3]);
  // THE SPLASH'S CARD WITH FOUNDRY'S DELETE HOOK LIVE (0.9.2, live test): the
  // mark's deletion fires onEffectDeletedB6D, which deletes the marked
  // creature's effect too; the splash still posts its card, and nothing throws.
  {
    reset(); answers.push("tn");
    await MMS[R.MM.lightningRod].after({ actor: rod, cast: true, damageTypes: ["electricity"], spellData: { ...spellData }, spellHits: [{ target: near }] });
    const before = cards.length;
    hookOnDelete.on = true; hookOnDelete.fn = (e) => R.onEffectDeletedB6D(e);
    let threw = false;
    try { await R.onSpellSettledB6D({ actor: rod, cast: true, spellData: { traits: "Electricity", damage: { formula: "4d8" } }, warpMods: {} }); } catch { threw = true; }
    hookOnDelete.on = false; hookOnDelete.fn = null;
    const posted = cards.slice(before).filter((c) => c.title === "Lightning Rod");
    equal("F …with the delete hook live: no throw, the splash card is posted, and both effects are gone",
      [threw, posted.length, /conducts/.test(JSON.stringify(posted[0]?.lines ?? [])), rod.effects.filter((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK).length, near.effects.length],
      [false, 1, true, 0, 0]);
  }
  // A MARKED EFFECT ALREADY GONE (another client took it, the uuid still
  // resolves): ending the mark does not throw (0.9.2).
  {
    reset(); answers.push("tn");
    await MMS[R.MM.lightningRod].after({ actor: rod, cast: true, damageTypes: ["electricity"], spellData: { ...spellData }, spellHits: [{ target: near }] });
    const mk = rod.effects.find((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK);
    near.effects = []; // gone from the actor, still in the uuid map
    let threw = false;
    try { await mk.delete(); await R.onEffectDeletedB6D(mk); } catch { threw = true; }
    equal("F …a marked effect already gone: ending the mark does not throw", threw, false);
  }
  reset(); answers.push("tn");
  await MMS[R.MM.lightningRod].after({ actor: rod, cast: true, damageTypes: ["electricity"], spellData: { ...spellData }, spellHits: [{ target: near }] });
  // The caster's mark deleted elsewhere ends the target's.
  const m2 = rod.effects.find((e) => e.flags?.[MOD]?.source === R.LIGHTNING_MARK);
  await m2.delete(); await R.onEffectDeletedB6D(m2);
  equal("F …the caster's mark deleted ends the marked creature's −2", near.effects.length, 0);
}
{
  // Versatile Binder.
  reset();
  const binder = makeActor("Binder", { items: [featDoc("Versatile Binder")] });
  const beast = makeActor("Beast"); const tb = makeToken("tb", beast, { x: 200, y: 0, disposition: -1 }); const tme = makeToken("tme", binder);
  place(tme, tb);
  answers.push("tb");
  const ctx = { actor: binder, range: "30 feet", targets: [] };
  await MMS[R.MM.binder].apply(ctx);
  checkDegrees.push("failure");
  const out = await MMS[R.MM.binder].after({ ...ctx, cast: true, totalPP: 5, spellData: { defence: "Will" } });
  equal("F Versatile Binder: the creature's own save (the spell's) vs your spell's DC; bound on a failure, its control the GM's", [calls.checks[0], /bound/.test(out.lines[0]) && /GM's/.test(out.lines[0])], [{ actor: "Beast", type: "save", subject: "will", dc: 18 }, true]);
  reset(); checkDegrees.push("success");
  await MMS[R.MM.binder].after({ ...ctx, cast: true, totalPP: 5, spellData: { defence: "Reflex" }, saveDC: 21 });
  equal("F …the cast's own Save DC when the core passes it, and the spell's own save", [calls.checks[0]?.dc, calls.checks[0]?.subject], [21, "reflex"]);
}
{
  // Charged-item rules with fakes.
  reset();
  const wand = { name: "Wand", system: { uses: 0 }, update: async (u) => { wand.system.uses = u["system.uses"]; } };
  const staff = { name: "Staff", system: { uses: 3 }, update: async (u) => { staff.system.uses = u["system.uses"]; } };
  const adept = makeActor("Adept", { items: [featDoc("Dual Channel"), featDoc("Conduit Mastery"), featDoc("Resonant Conduit")] });
  const out = await R.CHARGED_RULES_B6_D.dualChannel.onRelease({ actor: adept, kind: "release", degree: "fumble", wielded: [wand, staff] });
  equal("F Dual Channel: each wielded item loses 1 more; another item taken below 0 rolls Charge Depletion", [wand.system.uses, staff.system.uses, calls.depletion, out.lines.length], [0, 2, ["Wand"], 2]);
  reset(); wand.system.uses = 0; staff.system.uses = 3;
  const out2 = await R.CHARGED_RULES_B6_D.dualChannel.onRelease({ actor: adept, kind: "release", degree: "fumble", item: wand, ppSpent: 4, paidBy: "item", wielded: [wand, staff] });
  equal("F …the released item, emptied by its own spend, is not rolled twice (the core rolls an overspend); the card says so", [calls.depletion, out2.lines.some((l) => /exactly empty/.test(l))], [[], true]);
  reset(); wand.system.uses = 0;
  await R.CHARGED_RULES_B6_D.dualChannel.onRelease({ actor: adept, kind: "release", degree: "fumble", item: wand, ppSpent: 3, paidBy: "wielder", wielded: [wand] });
  equal("F …paid by the wielder, the released item is rolled here (the core did not)", calls.depletion, ["Wand"]);
  equal("F …the rule's reading", [R.dualChannelRollsReleased({ paidBy: "wielder", ppSpent: 3 }), R.dualChannelRollsReleased({ paidBy: "item", ppSpent: 0 }), R.dualChannelRollsReleased({ paidBy: "item", ppSpent: 2 })], [true, true, false]);
  equal("F …nothing on a Failure", await R.CHARGED_RULES_B6_D.dualChannel.onRelease({ actor: adept, kind: "release", degree: "failure", wielded: [wand, staff] }), null);
  equal("F the wield limits by feat", [R.CHARGED_RULES_B6_D.dualChannel.wieldLimit({ actor: adept }), R.CHARGED_RULES_B6_D.conduitMastery.wieldLimit({ actor: adept }), R.CHARGED_RULES_B6_D.dualChannel.wieldLimit({ actor: makeActor("No") })], [2, 3, null]);
  const first = await R.CHARGED_RULES_B6_D.resonantConduit.cost({ actor: adept, pp: 3, wielded: [wand, staff], reason: "castFromItem" });
  const second = await R.CHARGED_RULES_B6_D.resonantConduit.cost({ actor: adept, pp: 3, wielded: [wand, staff], reason: "castFromItem" });
  equal("F Resonant Conduit: the day's first activation is free, the second is not", [first?.free, second], [true, null]);
  await R.onDailyPreparationB6D({ actor: adept });
  equal("F …daily preparation restores it", (await R.CHARGED_RULES_B6_D.resonantConduit.cost({ actor: adept, pp: 3, wielded: [wand, staff] }))?.free, true);
  equal("F Mana Bound only with the feat", [R.manaBound({ actor: adept, check: { type: "spellcraft" } }), R.manaBound({ actor: makeActor("MB2", { items: [featDoc("Mana Bound")] }), check: { type: "spellcraft" } })?.modifier], [null, -20]);
}
{
  // Arcane Fencer.
  reset();
  const fencer = makeActor("Fencer", { pp: 5, cl: 4, items: [featDoc("Arcane Fencer"), { type: "weapon", name: "Rapier", system: { traits: "Finesse" } }, { type: "weapon", name: "Greatsword", system: { traits: "Two-Handed" } }] });
  const rapier = fencer.items.find((i) => i.name === "Rapier"), great = fencer.items.find((i) => i.name === "Greatsword");
  helpers.nextForm = { pp: 9 };
  const out = await R.arcaneFencer.before({ actor: fencer, type: "attack", attackMode: "melee", weaponUuid: rapier.uuid, twoHanded: false });
  equal("F Arcane Fencer: asked, capped at the caster level (4), the PP spent, +4 status", [prompts, out?.modifiers, fencer.system.resources.pp.value], [["Arcane Fencer"], [{ label: "Arcane Fencer", value: 4, type: "status" }], 1]);
  reset(); helpers.nextForm = { pp: 2 };
  equal("F …a Two-Handed weapon, a two-handed grip, a ranged Strike: not asked", [await R.arcaneFencer.before({ actor: fencer, type: "attack", attackMode: "melee", weaponUuid: great.uuid }), await R.arcaneFencer.before({ actor: fencer, type: "attack", attackMode: "melee", weaponUuid: rapier.uuid, twoHanded: true }), await R.arcaneFencer.before({ actor: fencer, type: "attack", attackMode: "ranged", weaponUuid: rapier.uuid }), prompts.length], [null, null, null, 0]);
  helpers.nextForm = { pp: 0 };
  equal("F …0 burned answers nothing and spends nothing", [await R.arcaneFencer.before({ actor: fencer, type: "attack", attackMode: "melee", weaponUuid: rapier.uuid }), fencer.system.resources.pp.value], [null, 1]);
}
{
  // Subconscious Casting.
  reset();
  const sp = (name, extra) => ({ type: "spell", name, system: { ppCost: 2, castAP: 1, range: "Touch", ...extra } });
  const sub = makeActor("Sub", { items: [featDoc("Subconscious Casting", { system: { traits: "Adept, Focus, Metamagic", usesValue: 1 } }), sp("Cure"), sp("Bolt", { range: "60 feet" })] });
  equal("F Subconscious: applies with the feat, its Focus use and a spell", [R.subconsciousOffer.applies({ actor: sub }), R.subconsciousOffer.applies({ actor: makeActor("Bare") })], [true, false]);
  answers.push(sub.items.find((i) => i.name === "Cure").id);
  castResult = { cast: true, check: { outcome: { degree: { key: "success" } } }, refunded: false };
  const out = await R.subconsciousOffer.offer({ actor: sub, sourceName: "An axe" });
  equal("F …asks the reactor, offers only the 1 AP Self/Touch spell, casts it at 0 AP with the preset +6", [calls.asked[0]?.step, helpers.lastOptions.map((o) => o[0]).length, calls.casts[0]?.spell, calls.casts[0]?.options], [R.SUBCONSCIOUS_STEP, 1, "Cure", { apPaid: true, metamagic: { preset: [{ key: R.MM.subconscious }] } }]);
  equal("F …the Focus use spent once the PP are paid (Q96); lines for the card", [sub.items[0].system.usesValue, out.lines.length], [0, 1]);
  equal("F …spent: no longer applies", R.subconsciousOffer.applies({ actor: sub }), false);
  reset(); sub.items[0].system.usesValue = 1;
  answers.push(sub.items.find((i) => i.name === "Cure").id);
  castResult = { cast: false, check: { outcome: { degree: { key: "partial" } } }, refunded: false };
  await R.subconsciousOffer.offer({ actor: sub });
  equal("F …a Partial spends no Focus use (Q96)", sub.items[0].system.usesValue, 1);
  reset(); reactorAnswers.push("no");
  equal("F …declined: nothing cast, no lines", [await R.subconsciousOffer.offer({ actor: sub }), calls.casts.length], [null, 0]);
}
{
  // Extra Cantrip's Use.
  reset();
  const auto = R.AUTOMATIONS_B6_D["Extra Cantrip"];
  const lone = makeActor("Lone", { level: 4, tradition: "verdant", items: [{ ...featDoc("Extra Cantrip"), _id: "x1" }, { type: "class", name: "Warlock", system: {} }] });
  await auto.use(lone, lone.items[0]);
  equal("F Extra Cantrip: a class with no cantrip pool chooses a PP 0 spell of its tradition", calls.chooseSpell.map((s) => [s.ppCost, s.tradition]), [[0, "verdant"]]);
  reset();
  const pooled = makeActor("Pooled", { level: 8, items: [{ ...featDoc("Extra Cantrip"), _id: "x1" }, { type: "class", name: "Wizard", system: { cantripsPerDay: 4 } }] });
  await auto.use(pooled, pooled.items[0]);
  equal("F …a class with a pool: the allowance rises, nothing is chosen", [calls.chooseSpell.length, cards.length], [0, 1]);
  reset();
  const early = makeActor("Early", { level: 7, items: [{ ...featDoc("Extra Cantrip"), _id: "x1" }, { ...featDoc("Extra Cantrip"), _id: "x2" }, { type: "class", name: "Warlock", system: {} }] });
  await auto.use(early, early.items[1]);
  equal("F …a second copy before 8th level is refused", [calls.chooseSpell.length, cards.some((c) => /once every four levels/.test(c.warn ?? ""))], [0, true]);
}
{
  // Piercing Insight.
  reset();
  const seer = makeActor("Seer", { pp: 5, items: [{ type: "feat", name: "Piercing Insight", system: {} }] });
  helpers.catalogue = [{ key: "reach", label: "Reach Spell", ppCost: 1, source: "core" }, { key: "extend", label: "Extend Spell", ppCost: 2, source: "core" }];
  helpers.nextForm = { "pick-reach": "1", "pick-extend": "1" };
  await R.onActionResolvedB6D({ actor: seer, action: { key: "senseMagicBroad", name: "Sense Magic" } });
  equal("F Piercing Insight: the catalogue offered, 3 PP spent, the card says what each changes", [seer.system.resources.pp.value, cards[0]?.lines.length, /range ×2/.test(cards[0]?.lines.join(" ")), /duration ×2/.test(cards[0]?.lines.join(" "))], [2, 3, true, true]);
  reset(); helpers.nextForm = { "pick-reach": "1", "pick-extend": "1" };
  await R.onActionResolvedB6D({ actor: seer, action: { key: "senseMagicFocused" } });
  equal("F …refused when the pool cannot pay", [seer.system.resources.pp.value, cards.some((c) => /you have 2/.test(c.warn ?? ""))], [2, true]);
  reset();
  await R.onActionResolvedB6D({ actor: seer, action: { key: "dispel" } });
  equal("F …another action asks nothing", prompts.length, 0);
  // Focus options and discounts (review).
  reset();
  const fseer = makeActor("FSeer", { pp: 5, items: [{ type: "feat", name: "Piercing Insight", system: {} }, featDoc("Resonant Pulse", { system: { traits: "Focus, Metamagic", usesValue: 1 } }), featDoc("Unfettered Mastery", { system: { traits: "Archmage, Focus, Metamagic, Sorcerer", usesValue: 0 } })] });
  helpers.catalogue = [
    { key: R.MM.pulse, label: "Resonant Pulse", ppCost: 0, focus: true, source: "module", feat: "Resonant Pulse" },
    { key: R.MM.unfettered, label: "Unfettered Mastery", ppCost: 0, focus: true, source: "module", feat: "Unfettered Mastery" },
    { key: "leyetchedsymbol", label: "Ley-Etched Symbol", ppCost: 0, focus: false, source: "module", feat: "Ley-Etched Symbol" },
    { key: "easpellweaverdiscount", label: "Magical Reservoir: −2 PP", ppCost: 0, focus: false, source: "module", feat: "Spell Weaver" },
    { key: R.MM.sensory, label: "Sensory Spell", ppCost: 1, focus: false, source: "module", feat: "Sensory Spell" }];
  helpers.nextForm = { [`pick-${R.MM.pulse}`]: "1", [`pick-${R.MM.sensory}`]: "1" };
  await R.onActionResolvedB6D({ actor: fseer, action: { key: "senseMagicBroad", name: "Sense Magic" } });
  const shown = [...helpers.lastPrompt.matchAll(/name="pick-([^"]+)"/g)].map((m) => m[1]);
  equal("F …a Focus option offered only while its feat has its use; discount-only options left out", shown, [R.MM.pulse, R.MM.sensory]);
  equal("F …the chosen Focus option's use is spent with its PP (Q96)", [fseer.items.find((i) => i.name === "Resonant Pulse").system.usesValue, fseer.system.resources.pp.value, /Focus use is spent/.test(cards[0]?.lines.join(" "))], [0, 4, true]);
}
{
  // The core's own offer list, with a real cast's ctx (module-metamagic-workflow).
  const wf = await quiet(() => import(sys("module", "magic", "module-metamagic-workflow.mjs")).catch(() => null));
  let offers = null;
  if (wf) {
    const kin = makeActor("Kin2", { items: [featDoc("Resonant Pulse", { system: { traits: "Focus, Metamagic", usesPerDay: "", usesValue: 1 } }), featDoc("Focused Spell")] });
    offers = await quiet(() => wf.offeredModuleMetamagic(kin, { scopeKind: "innate", defence: "Will", rollsCheck: false, innate: true, damageTypes: [], traits: "" }).catch((e) => ({ error: e.message })));
  }
  ok("F the core's offeredModuleMetamagic, on an innate cast with a save: Pulse shown, Focused Spell not (Q94)", Array.isArray(offers) && offers.some((o) => o.key === R.MM.pulse && !o.hidden) && !offers.some((o) => o.key === R.MM.focused), JSON.stringify(offers?.error ?? offers?.map?.((o) => [o.key, o.hidden])));
}

console.log(`verify-block6d: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
if (failures.length) process.exitCode = 1;
