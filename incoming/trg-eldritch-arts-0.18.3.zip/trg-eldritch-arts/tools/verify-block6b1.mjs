#!/usr/bin/env node
/**
 * verify-block6b1 — Eldritch Arts 0.9.0 (Block 6, group B1, on TRG Prime
 * 3.684.0): the archetypes Eternal Vigil, Fatespinner, Ferromancer, Leyline
 * Weaver and Runeblade and their fourteen class feats (Steelbinding is
 * group D's), the two sidebar abilities and the two specialist spells.
 *
 *   A  every feat against the book: name, category, traits as stored,
 *      prerequisites, progression, uses, the printed text and the automation
 *      paragraph, the docs' table; the split by trait is exact
 *   B  the data: effects, declarations, grants, abilities, spells
 *   C  the core, run with the content: progression (G8), the conviction
 *      refund (G18), the tradition waiver (G22), the rune bypass (G19), the
 *      death guards, Focus uses, the conditionals, the real registry
 *   D  the pure rules
 *   E  registration
 *   F  the Foundry side with fakes: every Use, reaction and hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6b1.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y) and the placeable keep the OLD
 * position; the document's `_source` and `change` carry the NEW one.
 */
function placeEnd(doc, change) {
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
}
async function moveV14(token, change, handler, ...rest) {
  placeEnd(token.document, change);
  return handler(token.document, change, ...rest);
}


const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const reactorAnswers = [];
const confirms = [];
const rolls = [];
const asked = [];
const calls = { formulas: [], replace: [], spendReaction: [], casts: [], heal: [], saves: [], texts: [], status: [], trait: [] };
let conviction = { ok: true, value: 2 };
let reactionRefused = "";
let castResult = { cast: true };
const STEPS = {};
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; return answers.length ? answers.shift() : null; },
  enterText: async (title, label) => { calls.texts.push(label); return answers.length ? answers.shift() : ""; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  replaceFeatEffect: async (actor, item, data, opts = {}) => {
    calls.replace.push({ item: item.name, data, opts });
    actor.effects = actor.effects.filter((e) => e.flags?.[SYS]?.featSource !== item.id);
    data.flags ??= {}; data.flags[SYS] = { ...(data.flags[SYS] ?? {}), featSource: item.id };
    return (await actor.createEmbeddedDocuments("ActiveEffect", [data]))[0];
  },
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title, step: q.step, data: q.data }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; if (a !== "yes") return { answer: a, result: null }; return { answer: a, result: await STEPS[q.step](actor, a, q.data) }; },
  spendReaction: async (actor, label) => { calls.spendReaction.push([actor.name, label]); return true; },
  reactionRefusal: async () => reactionRefused,
  isDead: async () => false,
  convictionState: async () => ({ ...conviction }),
  spendConviction: async (actor) => { if (!conviction.ok) return false; conviction.value -= 1; actor.spentConviction = (actor.spentConviction ?? 0) + 1; return true; },
  healActor: async (actor, n) => { calls.heal.push([actor.name, n]); },
  traitGate: async (actor, action, name) => { calls.trait.push(["gate", name, action.traits]); return true; },
  recordTraitUsage: async (actor, action) => { calls.trait.push(["record", action.traits]); },
  castSpell: async (actor, spell, options) => { calls.casts.push({ actor: actor.name, spell: spell.name, options, targets: [...(globalThis.game.user.targets ?? [])].map((t) => t.id) }); return castResult; },
  basicSaveHit: async (o) => { calls.saves.push({ caster: o.caster?.name, target: o.target?.name, save: o.save, dc: o.dc, formula: o.formula, type: o.type }); return { line: `${o.target.name} saves` }; },
  runesFor: async () => [{ key: "potency", tiers: [{ numeral: 1, level: 2 }] }, ...["acidic", "flaming", "frost", "shock", "thundering"].map((key) => ({ key, tiers: [{ numeral: 1, level: 5 }] })), { key: "returning", tiers: [{ numeral: 1, level: 4 }] }, { key: "bane", tiers: [{ numeral: 1, level: 4 }] }]
};
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => (confirms.length ? confirms.shift() : true) } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false, randomID: () => "r1", deepClone: (x) => JSON.parse(JSON.stringify(x)) } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.Roll = class { constructor(f) { this.formula = f; } async evaluate() { calls.formulas.push(this.formula); const dice = String(this.formula).match(/(\d+)d\d+/g) ?? []; const n = dice.reduce((s, d) => s + Number(d.split("d")[0]), 0); this.total = rolls.length ? rolls.shift() : n * 3; return this; } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  return it;
}
let deletedHook = null;
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.flags = e.flags ?? {};
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(e, k, v); };
  return e;
}
function makeActor(name, { level = 8, items = [], pp = 10, ppMax = 20, ap = 3, hp = 10 } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [], documentName: "Actor", conditions: new Set() };
  a.system = { identity: { level }, resources: { pp: { value: pp, max: ppMax }, ap: { value: ap }, hp: { value: hp } }, magic: { spellcraft: { dc: 17 } } };
  a.items = Object.assign(items.map((d) => makeItem(d, a)), { get(id) { return this.find((i) => i.id === id); } });
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => { const made = list.map((d) => makeEffect(d, a)); a.effects.push(...made); return made; };
  a.deleteEmbeddedDocuments = async (type, ids) => { const gone = a.effects.filter((e) => ids.includes(e.id)); a.effects = a.effects.filter((e) => !ids.includes(e.id)); if (deletedHook) for (const e of gone) await deletedHook(e); };
  a.hasCondition = (k) => a.conditions.has(k);
  a.toggleStatusEffect = async (k, o) => { calls.status.push([a.name, k, o]); };
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  return a;
}
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100, isTargeted: false };
  t.document = { actor, disposition, width: 1, height: 1, _source: { x: x - 50, y: y - 50, width: 1, height: 1 }, parent: null };
  t.document.object = t;
  t.setTarget = (on) => { t.isTargeted = on; if (on) game.user.targets.add(t); else game.user.targets.delete(t); };
  actor.token = t;
  return t;
}
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.684.0" }
};
// 5 ft a square of 100 px; 20 px a foot.
globalThis.canvas = {
  tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 }, scene: { regions: [] },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) }
};

const C = await import(new URL("./content/block6-b1.mjs", import.meta.url));
const common = await import(new URL("./content/block6-common.mjs", import.meta.url));
const auto = await import(new URL("../module/block6b1-automations.mjs", import.meta.url));
Object.assign(STEPS, auto.STEPS_B6_B1);
const F = Object.fromEntries(C.FEATS_B6_B1.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS];
const plain = (html) => String(html ?? "").replace(/<[^>]+>/g, "");
const prints = (desc, l) => plain(desc).includes(String(l).replace(/\*+/g, "").slice(0, 40));
const featDoc = (name) => F[name] ?? C.ABILITIES_B6_B1.find((a) => a.name === name);

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
const MINE = ["ETERNAL VIGIL", "FATESPINNER", "FERROMANCER", "LEYLINE WEAVER", "RUNEBLADE"];
const ARCH = {
  "ETERNAL VIGIL": ["Sorcerer", "Eternity, Medicine 2 ranks", "cannot progress", "1"],
  FATESPINNER: ["Adept, Diviner, Sorcerer, Witch", "Sense Motive 4 ranks", "Sense Motive +10 ranks", ""],
  FERROMANCER: ["Sorcerer, Spellblade, Wizard", "Arcana 2 ranks, Crafting 2 ranks, Metal Lore Specialty skill", "Arcana & Crafting +10 ranks", ""],
  "LEYLINE WEAVER": ["Adept", "BSB +2, any one tradition skill 2 ranks", "Tradition skill +10 ranks", ""],
  RUNEBLADE: ["Spellblade", "Level 2", "+10 levels.", ""]
};
const CLASS = {
  CHRONOSTASIS: ["Eternal Vigil", "Medicine 6 ranks", ""], "CONFLUENCE MASTER": ["Leyline Weaver", "Tradition skill 10 ranks, Leyline Anchor", ""],
  "DAMAGING GAMBIT": ["Fatespinner", "Sense Motive 10 ranks", ""], "DESTINY’S EMBRACE": ["Fatespinner", "Sense Motive 6 ranks", ""],
  "FATE’S FAVOUR": ["Fatespinner", "Sense Motive 6 ranks", ""], "IRON WARD": ["Focus, Ferromancer, Manipulate", "Arcana 6 ranks", ""],
  "LAST HORIZON": ["Eternal Vigil, Focus, Healing", "Medicine 12 ranks, Temporal Reprieve", ""], "LEYLINE ANCHOR": ["Leyline Weaver", "Tradition skill 6 ranks", "1"],
  LEYWALK: ["Leyline Weaver", "Tradition skill 12 ranks, Confluence Master", ""], "LIVING IRON": ["Ferromancer, Warding", "Arcana 12 ranks, Steelbinding", ""],
  "LIVING SIGIL": ["Runeblade", "Level 12, Twinflare Rune", ""], "RUNEFORGE MASTERY": ["Runeblade", "Level 18, Living Sigil", ""],
  "TEMPORAL REPRIEVE": ["Eternal Vigil, Flourish, Focus, Healing, Open", "Medicine 8 ranks, Chronostasis", ""], "TWINFLARE RUNE": ["Runeblade", "Level 6", ""]
};
{
  const t = common.titleCase;
  const mineTraits = MINE.map((n) => n.replace(/ /g, "-"));
  const other = ["RUNEBREAKER", "SHADE-MASTER", "SPELLWARDEN", "SPELL-DUELLIST", "SPELL-WEAVER", "STORMCALLER"];
  const byTrait = book.sections.classFeats.filter((f) => f.traits.some((x) => mineTraits.includes(x)) && !f.traits.some((x) => other.includes(x)) && f.name !== "STEELBINDING").map((f) => f.name).sort();
  equal("A the split is exact: every class feat whose trait names one of the five (not Steelbinding, none naming a B2 archetype)", byTrait, Object.keys(CLASS).sort());
  equal("A …Steelbinding (FERROMANCER METAMAGIC) is group D's, and not built here", [book.sections.classFeats.find((f) => f.name === "STEELBINDING")?.traits, Boolean(F.Steelbinding)], [["FERROMANCER", "METAMAGIC"], false]);
  equal("A nineteen feats: five archetypes and fourteen class feats, in the book's names", C.FEATS_B6_B1.map((f) => f.name), [...Object.keys(ARCH), ...Object.keys(CLASS)].map(t));
  for (const [key, [traits, prereq, prog, uses]] of Object.entries(ARCH)) {
    const f = F[t(key)], b = common.bookFeat(key, "archetype");
    equal(`A ${f?.name}: an archetype, its classes, prerequisites, progression, uses`, [f?.type, f?.system.category, f?.system.traits, f?.system.prerequisites, f?.system.progressionRequirements, f?.system.usesPerDay], ["feat", "Archetype", traits, prereq, prog, uses]);
    equal(`A ${f?.name}: the book's progression line is the stored one`, f?.system.progressionRequirements, b.fields["Progression Requirements"]);
    ok(`A ${f?.name}: the card prints the book's text and its printed prerequisite`, b.lines.every((l) => prints(f.system.description, l)) && f.system.description.includes(b.fields.Prerequisites));
    ok(`A ${f?.name}: the card says what is automated`, /(Automated|Partly automated|Not automated)/.test(f.system.description));
    equal(`A ${f?.name}: Block 6 and its book line`, [fl(f.name).eaBlock, fl(f.name).eaBookLine], [6, b.line]);
  }
  for (const [key, [traits, prereq, uses]] of Object.entries(CLASS)) {
    const f = F[t(key)], b = common.bookFeat(key);
    equal(`A ${f?.name}: a class feat, traits spaced, prerequisites, uses`, [f?.system.category, f?.system.traits, f?.system.prerequisites, f?.system.usesPerDay], ["Class", traits, prereq, uses]);
    equal(`A ${f?.name}: the prerequisite is the book's`, f?.system.prerequisites, b.fields.Prerequisites);
    ok(`A ${f?.name}: the card prints the book's text`, b.lines.every((l) => prints(f.system.description, l)));
    ok(`A ${f?.name}: the card says what is automated`, /(Automated|Partly automated|Not automated)/.test(f.system.description));
    equal(`A ${f?.name}: Block 6 and its book line`, [fl(f.name).eaBlock, fl(f.name).eaBookLine], [6, b.line]);
  }
  ok("A no stored trait is hyphenated (a hyphenated archetype trait would open the feat to everyone)", C.FEATS_B6_B1.every((f) => !/-/.test(f.system.traits)));
  ok("A Eternal Vigil's card keeps the printed \"Eternity Birthright\"", F["Eternal Vigil"].system.description.includes("Eternity Birthright, Medicine 2 ranks"));
  equal("A the docs' table: every feat, by its item's name", Object.keys(C.AUTOMATION_B6_B1), C.FEATS_B6_B1.map((f) => f.name));
  equal("A …graded A 6, B 12, C 1, D 0", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B6_B1).filter((r) => r.level === l).length), [6, 12, 1, 0]);
  ok("A the rulings are cited where they decided", [["Eternal Vigil", /Q108/], ["Eternal Vigil", /Q109/], ["Fate’s Favour", /Q110/], ["Damaging Gambit", /Q111/], ["Ferromancer", /Q112/], ["Leyline Weaver", /Q113/], ["Destiny’s Embrace", /Q114/], ["Runeblade", /Q117/], ["Temporal Reprieve", /Q122/], ["Runeblade", /Q90/], ["Leyline Weaver", /Q91/]].every(([n, re]) => re.test(F[n].system.description)));
  ok("A Runeblade's card says Defending I is left off (Q117)", /Defending I is left off/.test(F.Runeblade.system.description));
  ok("A Runeblade's card says Bane is not offered for the Book of Infusions", /Bane is not offered there/.test(F.Runeblade.system.description));
  ok("A Eternal Vigil's card says the use is kept when the cast does not happen", /spends the day's use only if the spell is cast/.test(F["Eternal Vigil"].system.description));
  ok("A Leyline Anchor's card says the Tap's line chooser is the GM's", /Not automated:\*? Tap and Channel Ley Line still offer only the lines within 30 feet/.test(F["Leyline Anchor"].system.description) || /Tap and Channel Ley Line still offer only/.test(F["Leyline Anchor"].system.description));
  equal("A the abilities: Foreseen Danger and Leyline Power, their sidebar traits", C.ABILITIES_B6_B1.map((a) => [a.name, a.type, a.system.traits, a.flags[SYS].eaSidebar]), [["Foreseen Danger", "ability", "Focus, Insight", 10], ["Leyline Power", "ability", "Concentrate, Focus, Magical", 11]]);
  for (const a of C.ABILITIES_B6_B1) ok(`A ${a.name}: the card prints the sidebar's text`, book.sidebars.find((s) => s.title === a.name.toUpperCase()).lines.slice(2).every((l) => a.system.description.includes(l.slice(0, 40))));
  const sp = (n) => C.SPELLS_B6_B1.find((s) => s.name === n);
  equal("A the spells: Shard Cloud (PP 1, 2 AP) and Ley Walker (PP 11, 3 AP), specialist", [["Shard Cloud", 1, 2], ["Ley Walker", 11, 3]].map(([n]) => [sp(n)?.name, sp(n)?.system.ppCost, sp(n)?.system.castAP, sp(n)?.system.specialist]), [["Shard Cloud", 1, 2, true], ["Ley Walker", 11, 3, true]]);
  for (const s of C.SPELLS_B6_B1) ok(`A ${s.name}: the card prints the book's text and says what is automated`, book.specialist.find((e) => e.name === s.name.toUpperCase()).lines.filter((l) => !/^\*\*\+/.test(l)).every((l) => s.system.description.includes(l.slice(0, 40))) && /Partly automated/.test(s.system.description));
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
{
  const changes = (n) => F[n].effects.flatMap((e) => e.changes);
  equal("B Eternal Vigil: Death State +2 (an ADD, stacking with Eternity Resilience's)", changes("Eternal Vigil"), [{ key: "system.combat.deathState", mode: 2, value: "2", priority: 20 }]);
  equal("B Fatespinner: conviction pool +1, Foreseen Danger granted", [fl("Fatespinner").convictionPool, F.Fatespinner.system.grantedAbilities], [1, "Foreseen Danger"]);
  equal("B Ferromancer: free somatic for arcane casts, the pouch needed; Shard Cloud granted (G22, Q112)", [fl("Ferromancer").freeSomatic, F.Ferromancer.system.grantedSpells], [{ traditions: ["arcane"], needsPouch: true, label: "Ferromancer" }, "Shard Cloud"]);
  const lw = fl("Leyline Weaver").conditionals;
  equal("B Leyline Weaver: +2 circumstance on Ley Sense and Tap Ley Line, automatic; Leyline Power granted", [lw.map((c) => [c.kind, c.value, c.type, c.auto, c.when]), F["Leyline Weaver"].system.grantedAbilities], [[["modifier", 2, "circumstance", true, { actions: ["leySense", "tapLeyLine"] }]], "Leyline Power"]);
  equal("B G8: only Runeblade opts in to \"+N levels\"", C.ARCHETYPES_B6_B1.map((f) => [f.name, f.flags[SYS].progressionSinceTaken === true]), [["Eternal Vigil", false], ["Fatespinner", false], ["Ferromancer", false], ["Leyline Weaver", false], ["Runeblade", true]]);
  equal("B Chronostasis: an offered, daily zero-HP guard, not against an outright kill, asked of its player", F.Chronostasis.effects[0].flags[SYS].deathGuard, { label: "Chronostasis", offer: true, askOwner: true, frequency: "daily", notOutright: true });
  equal("B Fate's Favour: refund on Partial or worse, saves and skills, daily (Q110 literal)", fl("Fate’s Favour").convictionRefund, { label: "Fate’s Favour", skills: [], degrees: ["partial", "failure", "fumble", "blunder"], checkTypes: ["save", "skill"], frequency: "daily" });
  equal("B Leywalk grants Ley Walker; Twinflare and Living Sigil declare 2 and 3 runes", [F.Leywalk.system.grantedSpells, fl("Twinflare Rune").eaRunebladeRunes, fl("Living Sigil").eaRunebladeRunes], ["Ley Walker", 2, 3]);
  const sc = C.SHARD_CLOUD.system;
  equal("B Shard Cloud: rolls nothing at the cast; its metal is a material component; +1d6 and +5 ft (max 30) warps", [sc.category, sc.defence, sc.components.material, sc.warps.map((w) => [w.ppCost, w.mods])], ["utility", "", true, [[1, { damageDice: "1d6" }], [2, { areaGrowth: 5, areaMax: 30 }]]]);
  equal("B Ley Walker: its +1 PP adds a target", C.LEY_WALKER.system.warps.map((w) => [w.ppCost, w.mods]), [[1, { extraTargets: 1 }], [2, {}], [3, {}]]);
  equal("B no archetype needs class or tier grants", C.ARCHETYPE_OPTIONS_B6_B1, {});
}

/* ----------------------------------------------------------------- */
/* C — the core, with the content                                      */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
{
  const ap = await quiet(() => import(sys("module", "archetype-progression.mjs")));
  const prog = (n) => F[n].system.progressionRequirements;
  equal("C G8: the five lines parse (never, skillAny, skillAll, tradition skill, levelsSince)", ["Eternal Vigil", "Fatespinner", "Ferromancer", "Leyline Weaver", "Runeblade"].map((n) => ap.parseProgressionClause(prog(n))?.type), ["never", "skillAny", "skillAll", "skillAny", "levelsSince"]);
  equal("C Eternal Vigil cannot progress, whatever the ranks", ap.meetsProgressionRequirement(prog("Eternal Vigil"), { level: 20, skillRanks: { medicine: 20 } }), false);
  equal("C Ferromancer needs Arcana AND Crafting +10", [ap.meetsProgressionRequirement(prog("Ferromancer"), { skillRanks: { arcana: 10, crafting: 9 } }), ap.meetsProgressionRequirement(prog("Ferromancer"), { skillRanks: { arcana: 10, crafting: 10 } })], [false, true]);
  equal("C Leyline Weaver: any one tradition skill +10 (Q91)", [ap.meetsProgressionRequirement(prog("Leyline Weaver"), { skillRanks: { nature: 10 } }), ap.meetsProgressionRequirement(prog("Leyline Weaver"), { skillRanks: { arcana: 9 } })], [true, false]);
  const rb = { flags: { [SYS]: { ...fl("Runeblade") } }, type: "feat", system: { category: "Archetype" } };
  const stamp = ap.archetypeTakenAtStamp(rb, 2);
  equal("C Runeblade is stamped with the level it was taken at (G8)", stamp, { "flags.trg-prime.archetypeTakenAt": 2 });
  rb.flags[SYS].archetypeTakenAt = 2;
  equal("C …and completes ten levels later (Q90), not before", [11, 12].map((level) => ap.meetsProgressionRequirement(prog("Runeblade"), { level }, ap.archetypeProgressionContext(rb))), [false, true]);

  const cr = await import(sys("module", "conviction-refund.mjs"));
  const ff = { name: "Fate’s Favour", type: "feat", system: {}, flags: { [SYS]: { convictionRefund: fl("Fate’s Favour").convictionRefund } } };
  equal("C G18: refunded on a Partial or worse of a save or skill check, not on a Success; not an attack",
    [["save", "partial"], ["skill", "failure"], ["save", "success"], ["skill", "critical"], ["attack", "failure"]].map(([checkType, degree]) => Boolean(cr.convictionRefundRow([ff], { checkType, subject: "will", degree }))), [true, true, false, false, false]);
  equal("C …the first time each day: the day's use is spent whatever the result, and then nothing", [cr.convictionRefundDailyUsed([ff], { checkType: "skill", degree: "success" }), Boolean(cr.convictionRefundRow([ff], { checkType: "skill", degree: "failure", usedToday: { [cr.convictionRefundDailyKey("Fate’s Favour")]: true } }))], [[cr.convictionRefundDailyKey("Fate’s Favour")], false]);

  const cg = await quiet(() => import(sys("module", "magic", "component-gate.mjs")));
  const ferro = { name: "Ferro", getFlag: () => null, items: [{ name: "Ferromancer", type: "feat", system: {}, flags: { [SYS]: { freeSomatic: fl("Ferromancer").freeSomatic } } }], effects: [] };
  const decl = cg.declaredTraditionComponents(ferro);
  equal("C G22: an arcane caster's arcane spell is covered, and spends the pouch; a divine one is not", [Boolean(cg.traditionComponentWaiver(decl, { tradition: "arcane" }, "arcane")), cg.castSpendsPouch({ material: false }, cg.traditionComponentWaiver(decl, { tradition: "arcane" }, "arcane")), Boolean(cg.traditionComponentWaiver(decl, { tradition: "divinity" }, "divinity"))], [true, true, false]);

  const rdb = await import(sys("module", "combat", "rune-damage-bypass.mjs"));
  const decl2 = [{ name: "x", flags: { [SYS]: { runeDamageBypass: auto.runeforgeBypass(["flaming"], "w1") } } }];
  equal("C G19: Runeforge Mastery's declaration answers its rune on its weapon, immunity as resistance; not another rune or weapon",
    [rdb.declaredRuneDamageBypass(decl2, { runeKey: "flaming", weaponId: "w1" }), rdb.declaredRuneDamageBypass(decl2, { runeKey: "frost", weaponId: "w1" }), rdb.declaredRuneDamageBypass(decl2, { runeKey: "flaming", weaponId: "w2" })], [{ label: "Runeforge Mastery", immunityAsResistance: true }, null, null]);

  const dg = await import(sys("module", "combat", "death-guard.mjs"));
  const guards = dg.declaredDeathGuards(F.Chronostasis.effects);
  equal("C Chronostasis is an offered daily zero-HP guard the core reads; refused against massive damage", [guards.length, guards[0]?.offer, guards[0]?.frequency, guards[0]?.askOwner, dg.deathGuardExcepted(guards[0], { massive: true }) !== null, dg.deathGuardHealTo(guards[0], 40)], [1, true, "daily", true, true, 1]);
  const held = dg.declaredDeathGuards([{ flags: { [SYS]: { deathGuard: { label: "Chronostasis (holding)", auto: true } } } }]);
  equal("C …and its holding effect an automatic guard to 1 HP", [held[0]?.auto, dg.deathGuardHealTo(held[0], 40)], [true, 1]);

  const uses = await import(sys("module", "uses.mjs"));
  equal("C the Focus feats and abilities have one use each (the core's default)", ["Iron Ward", "Last Horizon", "Temporal Reprieve", "Foreseen Danger", "Leyline Power"].map((n) => uses.focusDefaultUses(featDoc(n).system, featDoc(n).type)), [1, 1, 1, 1, 1]);

  const cond = await quiet(() => import(sys("module", "conditionals.mjs")));
  const rows = cond.collectConditionals([{ id: "lw", name: "Leyline Weaver", type: "feat", system: {}, flags: { [SYS]: { conditionals: fl("Leyline Weaver").conditionals } } }], []);
  equal("C Leyline Weaver's +2 reaches Tap Ley Line and Ley Sense, not Channel Ley Line", ["tapLeyLine", "leySense", "channelLeyLine"].map((a) => rows.some((r) => cond.matchesCheck(r, { checkType: "skill", subject: "powerManipulation", actionKey: a }))), [true, true, false]);

  capi.resetModuleRegistry();
  auto.registerBlock6B1(new Proxy({}, { get: (_, k) => (typeof capi[k] === "function" ? (...a) => capi[k](...a) : () => {}) }), "test");
  equal("C the real registry takes every registration, with nothing refused", capi.registrationProblems(), []);
  ok("C …the warp, the unconscious offer, five check reactions, two damage reactions, the gate, the refusal and five steps reach it",
    Boolean(capi.registeredSpellWarps("Eternal Vigil")?.[0]?.match?.traits?.includes("healing")) && capi.registeredUnconsciousOffers().length === 1 && capi.registeredCheckReactions().length === 5
      && capi.registeredDamageReactions().length === 2 && capi.registeredSpellCheckGates().length === 1 && capi.registeredCastRefusals().length === 1 && Object.keys(auto.STEPS_B6_B1).every((s) => capi.registeredReactionStep(s)));
  equal("C …the warp as the core keeps it: +2 PP, unlocking Eternal Vigil's fast healing", [capi.registeredSpellWarps("Eternal Vigil")[0].warp.ppCost, capi.registeredSpellWarps("Eternal Vigil")[0].warp.mods], [2, { unlocks: [auto.VIGIL_UNLOCK] }]);
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  equal("D Eternal Vigil's rounds (Q108): the cast's PP less 2, at least 1", [5, 3, 2].map(auto.vigilRounds), [3, 1, 1]);
  equal("D …bought only on a cast that landed and was not refunded", [{ cast: true, warpMods: { unlocks: [auto.VIGIL_UNLOCK] } }, { cast: true, warpMods: { unlocks: [] } }, { cast: false, warpMods: { unlocks: [auto.VIGIL_UNLOCK] } }, { cast: true, refunded: true, warpMods: { unlocks: [auto.VIGIL_UNLOCK] } }].map(auto.vigilWarpBought), [true, false, false, false]);
  equal("D …fast healing 5, as the core's healing rate", auto.vigilFastHealingFlags(), { spellBuff: true, fastHealing: 5 });
  const sk = (degree, die = 7, type = "skill") => ({ type, degree, failed: ["failure", "fumble", "blunder"].includes(degree), check: { dice: { unmodified: die } } });
  equal("D Fatespinner rerolls a failed skill check: not a Blunder, not an unmodified 1, not a save, not a success", [sk("failure"), sk("fumble"), sk("blunder"), sk("failure", 1), sk("failure", 7, "save"), sk("success")].map(auto.fatespinnerRerolls), [true, true, false, false, false, false]);
  equal("D Damaging Gambit: a spell attack's check only", [{ type: "attack", check: { reactionAs: "attack" } }, { type: "attack", check: {} }, { type: "save", check: { reactionAs: "attack" } }].map(auto.gambitWants), [true, false, false]);
  const a = { n: 1 }, b = { n: 2 };
  equal("D Destiny's Embrace: a hit, on another", [{ type: "attack", succeeded: true, target: b, actor: a }, { type: "attack", succeeded: false, target: b, actor: a }, { type: "attack", succeeded: true, target: a, actor: a }].map(auto.destinyWants), [true, false, false]);
  equal("D Living Iron: 2 PP or more, a slashing or piercing blow", [[2, ["slashing"]], [1, ["piercing"]], [5, ["fire"]], [5, ["piercing", "fire"]]].map(([pp, types]) => auto.livingIronResists({ pp, types })), [["slashing", "piercing"], null, null, ["slashing", "piercing"]]);
  equal("D Temporal Reprieve (Q122): up to the level, and the PP held", [auto.reprieveMax({ level: 8, pp: 20 }), auto.reprieveMax({ level: 8, pp: 3 }), auto.reprieveMax({ level: 8, pp: 0 })], [8, 3, 0]);
  equal("D Runeblade's count: 1, Twinflare 2, Living Sigil 3", [[], ["Twinflare Rune"], ["Twinflare Rune", "Living Sigil"]].map(auto.runebladeCount), [1, 2, 3]);
  equal("D Runeblade's list, as printed less Defending I (Q117)", auto.RUNEBLADE_RUNES.map((r) => r.name), ["Acidic I", "Bane", "Flaming I", "Frost I", "Returning", "Shock I", "Thundering I"]);
  equal("D …the field text and the merge with Block 4's runes", [auto.runebladeText([{ key: "flaming" }, { key: "bane", parameter: "dragons" }]), auto.mergedRunes("Potency I", "Flaming I"), auto.mergedRunes("", "Shock I")], ["Flaming I, Bane (dragons)", "Potency I, Flaming I", "Shock I"]);
  equal("D a fresh infusion is Block 4's write, not this module's", [{ flags: { [SYS]: { infusedRunes: { runes: "x" } } } }, { flags: { [SYS]: { infusedRunes: { runes: "x", eaRuneblade: {} } } } }, { flags: { [SYS]: {} } }, { system: {} }].map(auto.freshInfusion), [true, false, false, false]);
  equal("D Leyline Weaver's ladder: Critical ×2 + 1d8 PP to the end of the next turn; Success to the end of the next turn; Partial to the end of this one; Failure the action's",
    ["critical", "heroic", "success", "partial", "failure", "fumble"].map(auto.leylineWeaverRung), [{ expiry: "endOfNextTurn", factor: 2, pp: "1d8" }, { expiry: "endOfNextTurn", factor: 2, pp: "1d8" }, { expiry: "endOfNextTurn", factor: 1, pp: "" }, { expiry: "endOfTurn", factor: 1, pp: "" }, null, null]);
  equal("D Q113: a row's numbers doubled — a bonus, temporary HP at the level, PP, DB, the spell DC; advantage as it is",
    [auto.doubledLeySpec({ kind: "cond", mod: { kind: "modifier", value: 1 }, label: "+1 AB" }, 4), auto.doubledLeySpec({ kind: "tempHP", amount: "level" }, 4), auto.doubledLeySpec({ kind: "pp", amount: "level" }, 3), auto.doubledLeySpec({ kind: "db", value: 2, label: "+2 DB" }, 3), auto.doubledLeySpec({ kind: "spellDC", value: 2 }, 3), auto.doubledLeySpec({ kind: "cond", mod: { kind: "advantage" } }, 3)],
    [{ kind: "cond", mod: { kind: "modifier", value: 2 }, label: "+2 AB" }, { kind: "tempHP", amount: "8" }, { kind: "pp", amount: "6" }, { kind: "db", value: 4, label: "+4 DB" }, { kind: "spellDC", value: 4 }, { kind: "cond", mod: { kind: "advantage" } }]);
  equal("D …and not at all at ×1", auto.doubledLeySpec({ kind: "pp", amount: "level" }, 3, 1), { kind: "pp", amount: "level" });
  equal("D Shard Cloud: 1d6 and 5 ft, +1d6 and +5 ft a warp, at most 30 ft", [auto.shardCloudOf({}), auto.shardCloudOf({ damageDice: "2d6", areaGrowth: 10 }), auto.shardCloudOf({ areaGrowth: 40 })], [{ dice: 1, feet: 5 }, { dice: 3, feet: 15 }, { dice: 1, feet: 30 }]);
  equal("D the reaches: Foreseen 30, Ley Walker 30; Iron Ward +2; Living Iron 2 PP; Last Horizon a minute", [auto.FORESEEN_FEET, auto.LEY_WALKER_FEET, auto.IRON_WARD_DB, auto.LIVING_IRON_PP, auto.LAST_HORIZON_SECONDS, auto.ANCHOR_SECONDS], [30, 30, 2, 2, 60, 60]);
}

/* ----------------------------------------------------------------- */
/* E — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const got = { autos: {}, passive: {}, warps: [], uncon: [], check: [], damage: [], gate: [], refuse: [], steps: [] };
  const api = new Proxy({}, { get: (_, k) => ({
    registerFeatAutomation: (n, e) => { got.autos[n] = e; }, registerPassiveAutomation: (n, h) => { got.passive[n] = h; },
    registerSpellWarps: (n, e) => got.warps.push([n, e]), registerUnconsciousOffer: (n, s) => got.uncon.push([n, s]),
    registerCheckReaction: (n, s) => got.check.push([n, s]), registerDamageReaction: (n, f) => got.damage.push([n, f]),
    registerSpellCheckGate: (n, f) => got.gate.push([n, f]), registerCastRefusal: (n, f) => got.refuse.push([n, f]), registerReactionStep: (n, f) => got.steps.push([n, f])
  })[k] ?? (() => {}) });
  auto.registerBlock6B1(api, MOD);
  equal("E the Uses, by the items' names", Object.keys(got.autos), ["Iron Ward", "Temporal Reprieve", "Runeblade", "Foreseen Danger", "Leyline Power"]);
  ok("E …each an item of this group, with a use()", Object.keys(got.autos).every((n) => featDoc(n) && typeof got.autos[n].use === "function"));
  equal("E Foreseen Danger's toggle keeps its own Focus use (spends none)", got.autos["Foreseen Danger"].ownsFocusUse, true);
  ok("E every other feat says what it does at its Use (passive hints)", C.FEATS_B6_B1.every((f) => got.autos[f.name] || got.passive[f.name]));
  equal("E Eternal Vigil's warp: Healing spells, +2 PP", got.warps.map(([n, e]) => [n, e[0].match.traits, e[0].warp.ppCost]), [["Eternal Vigil", ["healing"], 2]]);
  ok("E G7: Eternal Vigil's offer with its applies()", got.uncon[0]?.[0] === "eternalVigil" && typeof got.uncon[0][1].applies === "function" && typeof got.uncon[0][1].offer === "function");
  equal("E the check reactions: after Fatespinner and Destiny's Embrace; before Damaging Gambit, Foreseen Danger, Confluence Master", got.check.map(([n, s]) => [n, Boolean(s.before), Boolean(s.after)]), [["fatespinnerReroll", false, true], ["damagingGambit", true, false], ["foreseenDanger", true, false], ["destinysEmbrace", false, true], ["confluenceMaster", true, false]]);
  equal("E the damage reactions, the gate, the refusal, the five steps", [got.damage.map(([n]) => n), got.gate.map(([n]) => n), got.refuse.map(([n]) => n), got.steps.map(([n]) => n)], [["livingIron", "chronostasis"], ["leywalk"], ["leyWalker"], Object.keys(auto.STEPS_B6_B1)]);
  const src = fs.readFileSync(path.join(ROOT, "module", "block6b1-automations.mjs"), "utf8");
  ok("E the hook handlers the lead wires are exported, each naming its Hooks.on event",
    [["onSpellSettledB6B1", "trgPrimeSpellSettled"], ["onTurnEndedB6B1", "trgPrimeTurnEnded"], ["onTokenMovedB6B1", "updateToken"], ["onDeathGuardHeldB6B1", "trgPrimeDeathGuardHeld"], ["onEffectDeletedB6B1", "deleteActiveEffect"], ["onEffectCreatedB6B1", "createActiveEffect"], ["onActionResolvedB6B1", "trgPrimeActionResolved"], ["onActorUpdatedB6B1", "updateActor"], ["onItemCreatedB6B1", "createItem"]]
      .every(([n, hook]) => typeof auto[n] === "function" && new RegExp(`Hooks\\.on\\("${hook}"[^\\n]*\\n(?:[^\\n]*\\n){0,4}?export async function ${n}\\(`).test(src)));
  ok("E Block 2's seam is exported with its wiring documented", typeof auto.leylineWeaverTap === "function" && /if \(await leylineWeaverTap\(actor, \{ degree: k, level: L, title \}\)\) return;/.test(src));
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side, with fakes                                    */
/* ----------------------------------------------------------------- */
const withUse = (name, value = 1) => { const d = JSON.parse(JSON.stringify(featDoc(name))); d.system.usesValue = value; return d; };
const spell = (name, pp = 1) => ({ _id: `s-${name}`, name, type: "spell", system: { ppCost: pp, traits: "Healing" }, flags: {} });
const reset = () => { cards.length = 0; asked.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; game.combat = null; game.user.targets = new Set(); canvas.tokens.placeables = []; conviction = { ok: true, value: 2 }; reactionRefused = ""; };
{
  // Iron Ward.
  reset();
  const iw = makeActor("ZZ Iron", { items: [withUse("Iron Ward")] });
  game.combat = { id: "c1", started: true, round: 1, turn: 0, combatants: [{ actor: iw, actorId: iw.id }], turns: [{ actor: iw, actorId: iw.id }] };
  game.combat.combatant = game.combat.turns[0];
  ok("F Iron Ward: the Use acts", await auto.AUTOMATIONS_B6_B1["Iron Ward"].use(iw, iw.items[0]));
  equal("F …+2 circumstance DB until the start of the next turn; 1 AP spent in combat", [iw.effects[0]?.changes, iw.effects[0]?.flags?.[MOD]?.endsAtTurnStart?.round, iw.system.resources.ap.value], [[{ key: "system.combat.defence.circumstance", type: "custom", value: "2", priority: 20 }], 2, 2]);
  iw.system.resources.ap.value = 0;
  equal("F …its Manipulate trait asked of the core and recorded", calls.trait.map((x) => x[0]), ["gate", "record"]);
  equal("F …refused with no AP", await auto.AUTOMATIONS_B6_B1["Iron Ward"].use(iw, iw.items[0]), false);
  iw.system.resources.ap.value = 3; calls.trait.length = 0;
  const gate = helpers.traitGate; helpers.traitGate = async () => false;
  equal("F …refused by the trait gate: nothing laid, no AP", [await auto.AUTOMATIONS_B6_B1["Iron Ward"].use(iw, iw.items[0]), iw.effects.length, iw.system.resources.ap.value], [false, 1, 3]);
  helpers.traitGate = gate;

  // Temporal Reprieve.
  reset();
  const tr = makeActor("ZZ Reprieve", { items: [withUse("Temporal Reprieve")], level: 6, pp: 10 });
  answers.push("4"); rolls.push(17);
  ok("F Temporal Reprieve: the Use acts", await auto.AUTOMATIONS_B6_B1["Temporal Reprieve"].use(tr, tr.items[0]));
  equal("F …rolled 4d8", calls.formulas, ["4d8"]);
  equal("F …4 PP spent, 4d8 healed; Flourish and Open asked of the core and recorded", [tr.system.resources.pp.value, calls.heal, calls.trait.map((x) => x[0]), helpers.lastOptions.length], [6, [["ZZ Reprieve", 17]], ["gate", "record"], 6]);
  tr.system.resources.pp.value = 0;
  equal("F …refused with no PP", await auto.AUTOMATIONS_B6_B1["Temporal Reprieve"].use(tr, tr.items[0]), false);

  // Foreseen Danger's toggle.
  reset();
  const fs1 = makeActor("ZZ Seer", { items: [withUse("Foreseen Danger")] });
  await auto.AUTOMATIONS_B6_B1["Foreseen Danger"].use(fs1, fs1.items[0]);
  equal("F Foreseen Danger's Use turns the asking off, and on again; it spends nothing", [fs1.items[0].flags[MOD]?.eaForeseenOff, (await auto.AUTOMATIONS_B6_B1["Foreseen Danger"].use(fs1, fs1.items[0]), fs1.items[0].flags[MOD]?.eaForeseenOff), fs1.items[0].system.usesValue], [true, false, 1]);

  // Fatespinner's reroll.
  reset();
  const fsp = makeActor("ZZ Spinner", { items: [F.Fatespinner] });
  const out = await auto.fatespinnerReroll.after({ actor: fsp, type: "skill", degree: "failure", failed: true, check: { dice: { unmodified: 5 } }, total: 9 });
  equal("F Fatespinner: asked, a conviction point spent, the check rerolled", [out?.reroll, fsp.spentConviction, asked[0]?.step], [true, 1, auto.FATESPINNER_STEP]);
  equal("F …not on a Blunder, nor an unmodified 1, nor without the feat", [await auto.fatespinnerReroll.after({ actor: fsp, type: "skill", degree: "blunder", failed: true, check: { dice: { unmodified: 5 } } }), await auto.fatespinnerReroll.after({ actor: fsp, type: "skill", degree: "failure", failed: true, check: { dice: { unmodified: 1 } } }), await auto.fatespinnerReroll.after({ actor: makeActor("ZZ None"), type: "skill", degree: "failure", failed: true, check: { dice: { unmodified: 5 } } })], [null, null, null]);
  conviction.ok = false;
  equal("F …nor when no conviction may be spent", await auto.fatespinnerReroll.after({ actor: fsp, type: "skill", degree: "failure", failed: true, check: { dice: { unmodified: 5 } } }), null);
  conviction.ok = true; reactorAnswers.push("no");
  equal("F …nor when declined (nothing spent)", [await auto.fatespinnerReroll.after({ actor: fsp, type: "skill", degree: "failure", failed: true, check: { dice: { unmodified: 5 } } }), fsp.spentConviction], [null, 1]);

  // Damaging Gambit.
  reset();
  const dgm = makeActor("ZZ Gambler", { items: [F["Damaging Gambit"]] });
  const g = await auto.damagingGambit.before({ actor: dgm, type: "attack", check: { reactionAs: "attack" }, label: "Ray" });
  equal("F Damaging Gambit: a conviction point for advantage on the spell attack (Q111)", [g?.advantage, dgm.spentConviction], [true, 1]);
  equal("F …not on a weapon attack", await auto.damagingGambit.before({ actor: dgm, type: "attack", check: {} }), null);

  // Foreseen Danger before an ally's check.
  reset();
  const seer = makeActor("ZZ Seer2", { items: [withUse("Foreseen Danger")] });
  const ally = makeActor("ZZ Ally");
  const foe = makeActor("ZZ Foe");
  const tSeer = makeToken("ts", seer, { x: 0, y: 0 }), tAlly = makeToken("ta", ally, { x: 400, y: 0 }), tFoe = makeToken("tf", foe, { x: 200, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tSeer, tAlly, tFoe];
  rolls.push(4);
  const fd = await auto.foreseenDanger.before({ actor: ally, token: tAlly, type: "save", label: "Will save" });
  equal("F Foreseen Danger: an ally within 30 ft is helped by +1d6 (untyped) before the dice; reaction and Focus spent", [fd?.modifiers, calls.spendReaction.length, seer.items[0].system.usesValue], [[{ label: "Foreseen Danger (ZZ Seer2)", value: 4, type: "untyped" }], 1, 0]);
  equal("F …1d6, rolled once it is accepted", calls.formulas, ["1d6"]);
  const askedBefore = asked.length;
  equal("F …not once the Focus use is spent (nobody asked)", [await auto.foreseenDanger.before({ actor: ally, token: tAlly, type: "save" }), asked.length - askedBefore], [null, 0]);
  seer.items[0].system.usesValue = 1;
  equal("F …not for its own check, nor a foe's", [await auto.foreseenDanger.before({ actor: seer, token: tSeer, type: "save" }), await auto.foreseenDanger.before({ actor: foe, token: tFoe, type: "save" })], [null, null]);
  tAlly.center = { x: 700, y: 0 }; tAlly.document._source.x = 650;
  equal("F …not beyond 30 ft", await auto.foreseenDanger.before({ actor: ally, token: tAlly, type: "skill" }), null);
  tAlly.center = { x: 400, y: 0 }; tAlly.document._source.x = 350;
  seer.items[0].flags[MOD] = { eaForeseenOff: true };
  equal("F …not when its owner turned the asking off", await auto.foreseenDanger.before({ actor: ally, token: tAlly, type: "skill" }), null);
  seer.items[0].flags[MOD] = {}; seer.conditions.add("blinded");
  equal("F …not while blinded", await auto.foreseenDanger.before({ actor: ally, token: tAlly, type: "skill" }), null);
  seer.conditions.clear();

  // Destiny's Embrace.
  calls.spendReaction.length = 0;
  const seerD = makeActor("ZZ Destiny", { items: [withUse("Foreseen Danger"), F["Destiny’s Embrace"]] });
  const tD = makeToken("td", seerD, { x: 0, y: 100 });
  canvas.tokens.placeables = [tD, tAlly, tFoe];
  const de = await auto.destinysEmbrace.after({ actor: foe, token: tFoe, target: ally, type: "attack", succeeded: true, total: 22 });
  equal("F Destiny's Embrace: an enemy's hit on an ally is rerolled; the reaction and Foreseen Danger's use spent (Q114)", [de?.reroll, calls.spendReaction.length, seerD.items[0].system.usesValue], [true, 1, 0]);
  seerD.items[0].system.usesValue = 1;
  equal("F …not on a miss, nor an ally's attack on an ally", [await auto.destinysEmbrace.after({ actor: foe, token: tFoe, target: ally, type: "attack", succeeded: false }), await auto.destinysEmbrace.after({ actor: seer, token: tSeer, target: ally, type: "attack", succeeded: true })], [null, null]);
  canvas.tokens.placeables = [tSeer, tAlly, tFoe];
  equal("F …nor by a Foreseen Danger owner without the feat", await auto.destinysEmbrace.after({ actor: foe, token: tFoe, target: ally, type: "attack", succeeded: true }), null);

  // Living Iron, Chronostasis's resistance.
  reset();
  const li = makeActor("ZZ Iron Body", { items: [F["Living Iron"]], pp: 2 });
  equal("F Living Iron: slashing resisted at 2 PP, not at 1, not fire", [(await auto.livingIronReaction({ target: li, types: ["slashing"] }))?.resist, (li.system.resources.pp.value = 1, await auto.livingIronReaction({ target: li, types: ["slashing"] })), (li.system.resources.pp.value = 5, await auto.livingIronReaction({ target: li, types: ["fire"] }))], [["slashing", "piercing"], null, null]);

  // Chronostasis: held, then its end.
  reset();
  const ch = makeActor("ZZ Chrono", { items: [F.Chronostasis], hp: 1 });
  await auto.onDeathGuardHeldB6B1({ actor: ch, label: "Chronostasis", hp: 1, trigger: "zeroHp" });
  const ce = ch.effects[0];
  equal("F Chronostasis holds: an automatic guard to 1 HP, until the start of the next turn", [ce?.flags?.[SYS]?.deathGuard, ce?.flags?.[MOD]?.source, ce?.flags?.[SYS]?.spellEffect], [{ label: "Chronostasis (holding)", auto: true }, "eaChronostasis", true]);
  equal("F …its clock: the start of the next turn (6 s out of combat), not a minute", ce?.flags?.[SYS]?.spellEffectEnd - game.time.worldTime, 6);
  equal("F …and resistance to all damage while it holds", (await auto.chronostasisReaction({ target: ch, types: ["fire"] }))?.resist, "all");
  await auto.onDeathGuardHeldB6B1({ actor: ch, label: "Unliving Fortitude", trigger: "zeroHp" });
  equal("F …another guard's holding lays nothing", ch.effects.length, 1);
  deletedHook = auto.onEffectDeletedB6B1;
  await ch.deleteEmbeddedDocuments("ActiveEffect", [ce.id]);
  equal("F …at its end, not healed: HP 0 and Dying 1", [ch.system.resources.hp.value, calls.status], [0, [["ZZ Chrono", "dying", { value: 1 }]]]);
  const ch2 = makeActor("ZZ Chrono2", { items: [F.Chronostasis], hp: 1 });
  await auto.onDeathGuardHeldB6B1({ actor: ch2, label: "Chronostasis", trigger: "zeroHp" });
  ch2.system.resources.hp.value = 9; calls.status.length = 0;
  await ch2.deleteEmbeddedDocuments("ActiveEffect", [ch2.effects[0].id]);
  equal("F …healed: no Dying", [ch2.system.resources.hp.value, calls.status.length, (await auto.chronostasisReaction({ target: ch2, types: ["fire"] }))], [9, 0, null]);
  deletedHook = null;

  // Last Horizon.
  reset();
  const lh = makeActor("ZZ Horizon", { items: [withUse("Last Horizon")] });
  const dying = (await lh.createEmbeddedDocuments("ActiveEffect", [{ name: "Dying", statuses: ["dying"] }]))[0];
  await auto.onEffectCreatedB6B1(dying);
  equal("F Last Horizon: conscious while Dying and the next check waived, acting normally (G7); the Focus use spent", [lh.flags[SYS]?.consciousWhileDying, lh.flags[SYS]?.dyingCheckWaived, lh.items[0].system.usesValue], [dying.id, { effect: dying.id, label: "Last Horizon", actNormally: true }, 0]);
  lh.items[0].system.usesValue = 1; delete lh.flags[SYS].consciousWhileDying;
  await auto.onEffectCreatedB6B1(dying);
  equal("F …not again within the minute", lh.flags[SYS].consciousWhileDying, undefined);
  game.time.worldTime += 61;
  confirms.push(false);
  await auto.onEffectCreatedB6B1(dying);
  equal("F …declined, nothing", [lh.flags[SYS].consciousWhileDying, lh.items[0].system.usesValue], [undefined, 1]);
  lh.flags[SYS].consciousWhileDying = dying.id;
  await auto.onTurnEndedB6B1({ actor: lh, combat: { id: "c", combatant: null } });
  equal("F …while the waiver is unspent, its turn's end keeps it conscious", lh.flags[SYS].consciousWhileDying, dying.id);
  delete lh.flags[SYS].dyingCheckWaived;
  await auto.onTurnEndedB6B1({ actor: lh, combat: { id: "c", combatant: null } });
  equal("F …once the core spent it, the end of that turn: Dying acts as normal", [lh.flags[SYS].consciousWhileDying, lh.flags[MOD].eaLastHorizonDying], [undefined, undefined]);

  // Eternal Vigil at 0 HP.
  reset();
  const ev = makeActor("ZZ Vigil", { items: [F["Eternal Vigil"], spell("Touch of Healing")], pp: 3, hp: 0 });
  makeToken("tv", ev);
  canvas.tokens.placeables = [ev.token];
  equal("F Eternal Vigil applies: the feat's use, Touch of Healing known, the PP", await auto.eternalVigilOffer.applies({ actor: ev }), true);
  const evOut = await auto.eternalVigilOffer.offer({ actor: ev, sourceName: "A blow" });
  equal("F …yes casts Touch of Healing on yourself as a free action, the day's use spent", [calls.casts[0]?.spell, calls.casts[0]?.options?.apPaid, calls.casts[0]?.targets, ev.items[0].system.usesValue, evOut?.lines?.length], ["Touch of Healing", true, ["tv"], 0, 1]);
  equal("F …the targets put back", [...game.user.targets].length, 0);
  ev.items[0].system.usesValue = 1;
  for (const failed of [null, { cast: false }]) {
    castResult = failed;
    const out = await auto.eternalVigilOffer.offer({ actor: ev, sourceName: "A blow" });
    equal(`F …a cast that ${failed ? "fails" : "is cancelled or refused"} keeps the use and claims nothing`, [out, ev.items[0].system.usesValue], [null, 1]);
  }
  castResult = { cast: true };
  ev.items[0].system.usesValue = 0;
  equal("F …not twice a day, not with no PP, not without the spell", [await auto.eternalVigilOffer.applies({ actor: ev }), (ev.items[0].system.usesValue = 1, ev.system.resources.pp.value = 0, await auto.eternalVigilOffer.applies({ actor: ev })), await auto.eternalVigilOffer.applies({ actor: makeActor("ZZ NoSpell", { items: [F["Eternal Vigil"]] }) })], [false, false, false]);

  // Eternal Vigil's warp on settle.
  reset();
  const ev2 = makeActor("ZZ Healer", { items: [F["Eternal Vigil"]] });
  const pal = makeActor("ZZ Patient");
  const tp = makeToken("tp", pal);
  game.user.targets = new Set([tp]);
  await auto.onSpellSettledB6B1({ actor: ev2, spell: { name: "Cure" }, cast: true, castPP: 5, warpMods: { unlocks: [auto.VIGIL_UNLOCK] } });
  equal("F the warp: fast healing 5 on the target, 3 rounds (5 PP less 2)", [pal.effects[0]?.flags?.[SYS]?.fastHealing, pal.effects[0]?.flags?.[SYS]?.spellEffectEnd - game.time.worldTime, ev2.effects.length], [5, 18, 0]);
  game.user.targets = new Set();
  await auto.onSpellSettledB6B1({ actor: ev2, spell: { name: "Touch of Healing" }, cast: true, castPP: 3, warpMods: { unlocks: [auto.VIGIL_UNLOCK] } });
  equal("F …no target: the caster", ev2.effects[0]?.flags?.[SYS]?.fastHealing, 5);
  await auto.onSpellSettledB6B1({ actor: pal, spell: { name: "Cure" }, cast: true, castPP: 5, warpMods: { unlocks: [auto.VIGIL_UNLOCK] } });
  equal("F …nothing for a caster without the feat", pal.effects.length, 1);

  // Shard Cloud.
  reset();
  const ferro = makeActor("ZZ Ferro", { items: [F.Ferromancer] });
  const victim = makeActor("ZZ Victim");
  const tF = makeToken("tfe", ferro, { x: 0, y: 0 }), tV = makeToken("tvi", victim, { x: 200, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tF, tV];
  await auto.onSpellSettledB6B1({ actor: ferro, spell: { name: "Shard Cloud" }, cast: true, warpMods: { damageDice: "1d6", areaGrowth: 5 } });
  equal("F Shard Cloud raised: 2d6, 10 ft, the Spell DC recorded", [ferro.effects[0]?.flags?.[MOD]?.dice, ferro.effects[0]?.flags?.[MOD]?.feet, ferro.effects[0]?.flags?.[MOD]?.dc], [2, 10, 17]);
  ferro.flags[SYS] = { activeSpells: [{ name: "Shard Cloud" }] };
  await auto.onTurnEndedB6B1({ combat: { id: "c1", combatant: { actor: victim, token: { object: tV } } } });
  equal("F …a creature starting its turn within 10 ft: basic Reflex, 2d6 slashing, the caster's DC", calls.saves, [{ caster: "ZZ Ferro", target: "ZZ Victim", save: "reflex", dc: 17, formula: "2d6", type: "slashing" }]);
  await auto.onTurnEndedB6B1({ combat: { id: "c1", combatant: { actor: ferro, token: { object: tF } } } });
  equal("F …never the caster", calls.saves.length, 1);
  tV.center = { x: 400, y: 0 }; tV.document._source.x = 350;
  await auto.onTurnEndedB6B1({ combat: { id: "c1", combatant: { actor: victim, token: { object: tV } } } });
  equal("F …not beyond its radius", calls.saves.length, 1);
  game.combat = { id: "c1", started: true, round: 2 };
  // V14 (0.11.2): the document and placeable still at the old square, outside the cloud; the end, inside, only in `change`.
  await moveV14(tV, { x: 100 }, auto.onTokenMovedB6B1);
  await moveV14(tV, { x: 100 }, auto.onTokenMovedB6B1);
  equal("F …entering it bites, once a round", calls.saves.length, 2);
  game.combat.round = 3;
  await moveV14(tV, { x: 100 }, auto.onTokenMovedB6B1);
  equal("F …and again the next round", calls.saves.length, 3);
  game.combat.round = 4;
  await moveV14(tV, { x: 400 }, auto.onTokenMovedB6B1);
  equal("F …a move that ENDS outside the cloud (V14: its end in `change`, the document still inside) does not bite", calls.saves.length, 3);
  ferro.flags[SYS] = { activeSpells: [] };
  await auto.onTurnEndedB6B1({ combat: { id: "c1", combatant: { actor: victim, token: { object: tV } } } });
  equal("F …no longer sustained: no bite, and the cloud is cleared", [calls.saves.length, ferro.effects.length], [3, 0]);
  game.user.isGM = false;
  placeEnd(tV.document, { x: 50, y: -50 }); tV.center = { x: 100, y: 0 }; tV.document._source.x = 50;  // V14: a token already moved is placed by its recorded end
  await auto.onSpellSettledB6B1({ actor: ferro, spell: { name: "Shard Cloud" }, cast: true, warpMods: {} });
  ferro.flags[SYS] = { activeSpells: [{ name: "Shard Cloud" }] };
  await auto.onTurnEndedB6B1({ combat: { id: "c1", combatant: { actor: victim, token: { object: tV } } } });
  equal("F …the bites are the acting GM's only", calls.saves.length, 3);
  game.user.isGM = true;

  // Leywalk and Ley Walker.
  const lwk = makeActor("ZZ Walker", { items: [F.Leywalk] });
  equal("F Leywalk: +2 status on Ley Walker's casting check, not another spell's", [await auto.leywalkGate({ actor: lwk, spell: { name: "Ley Walker" } }), await auto.leywalkGate({ actor: lwk, spell: { name: "Fireball" } })], [{ modifiers: [{ label: "Leywalk", value: 2, type: "status" }] }, null]);
  makeToken("tw", lwk);
  ok("F Ley Walker is refused with no ley line within 30 ft", /within 30 feet of a ley line/.test(await auto.leyWalkerRefusal({ actor: lwk, spell: { name: "Ley Walker" } }) ?? ""));
  await lwk.createEmbeddedDocuments("ActiveEffect", [{ name: "a", flags: { [MOD]: { source: "eaLeylineAnchor" } } }]);
  equal("F …but not while Leyline Anchor holds a line, nor for another spell", [await auto.leyWalkerRefusal({ actor: lwk, spell: { name: "Ley Walker" } }), await auto.leyWalkerRefusal({ actor: makeActor("ZZ X"), spell: { name: "Fireball" } })], [null, null]);

  // Leyline Power, Leyline Anchor, Confluence after a Tap.
  reset();
  const lw = makeActor("ZZ Weaver", { items: [withUse("Leyline Power"), withUse("Leyline Anchor"), F["Confluence Master"]], pp: 5, ppMax: 30 });
  lw.flags[MOD] = { block2Plan: { action: "tapLeyLine", name: "The Vein", level: 3, regionId: "r1" }, eaConfluenceTap: game.time.worldTime };
  rolls.push(11);
  await auto.onActionResolvedB6B1({ actor: lw, action: { key: "tapLeyLine" }, degree: "critical" });
  equal("F …the formula: 2d8 + 1d8", calls.formulas, ["2d8 + 1d8"]);
  equal("F Leyline Power on a Critical: 2d8 + Confluence's 1d8, the reaction and the Focus use", [lw.system.resources.pp.value, calls.spendReaction.length, lw.items[0].system.usesValue, lw.flags[MOD].eaConfluenceTap], [16, 1, 0, undefined]);
  equal("F Leyline Anchor: the day's use, a 1-minute anchor on the Tap's line", [lw.items[1].system.usesValue, lw.effects[0]?.flags?.[MOD]?.name, lw.effects[0]?.flags?.[SYS]?.spellEffectEnd - game.time.worldTime], [0, "The Vein", 60]);
  const lw2 = makeActor("ZZ Weaver2", { items: [withUse("Leyline Power")], pp: 5, ppMax: 30 });
  await auto.onActionResolvedB6B1({ actor: lw2, action: { key: "tapLeyLine" }, degree: "partial" });
  await auto.onActionResolvedB6B1({ actor: lw2, action: { key: "channelLeyLine" }, degree: "success" });
  equal("F …not on a Partial, nor another action", lw2.system.resources.pp.value, 5);
  rolls.push(4);
  await auto.onActionResolvedB6B1({ actor: lw2, action: { key: "tapLeyLine" }, degree: "success" });
  equal("F …a Success regains 1d8", lw2.system.resources.pp.value, 9);
  // The anchored Use.
  lw.items[0].system.usesValue = 1;
  game.combat = { id: "c9", started: true, round: 4, combatants: [{ actor: lw, actorId: lw.id }], turns: [] };
  rolls.push(6);
  const spentBefore = calls.spendReaction.length;
  ok("F Leyline Power's Use while anchored: 1d8 PP", await auto.AUTOMATIONS_B6_B1["Leyline Power"].use(lw, lw.items[0]));
  equal("F …PP gained, a reaction spent", [lw.system.resources.pp.value, calls.spendReaction.length - spentBefore], [22, 1]);
  equal("F …once a round", await auto.AUTOMATIONS_B6_B1["Leyline Power"].use(lw, lw.items[0]), false);
  equal("F …and not without an anchor", await auto.AUTOMATIONS_B6_B1["Leyline Power"].use(lw2, lw2.items[0]), false);
  game.combat = null;

  // Confluence Master's question.
  equal("F Confluence Master is not asked with fewer than two lines (or no feat, or another action)", [await auto.confluenceMaster.before({ actor: lw, type: "skill", check: { actionKey: "tapLeyLine" }, token: null }), await auto.confluenceMaster.before({ actor: lw2, type: "skill", check: { actionKey: "tapLeyLine" } }), await auto.confluenceMaster.before({ actor: lw, type: "skill", check: { actionKey: "leySense" } })], [null, null, null]);

  // Leyline Weaver's Tap, for Block 2.
  reset();
  const wv = makeActor("ZZ LW", { items: [F["Leyline Weaver"]], pp: 2, ppMax: 30 });
  rolls.push(44, 5);
  const handled = await auto.leylineWeaverTap(wv, { degree: "critical", level: 3, title: "Tap Ley Line — The Vein (level 3)" });
  equal("F Leyline Weaver's Critical: the row's PP doubled (2 × level 3), then 1d8 PP", [handled, wv.system.resources.pp.value], [true, 2 + 6 + 5]);
  rolls.push(47);
  await auto.leylineWeaverTap(wv, { degree: "success", level: 3 });
  equal("F …a Success: the row as it is (+2 DB), to the end of the next turn", [wv.effects.at(-1)?.changes?.[0]?.value, wv.effects.at(-1)?.flags?.[MOD]?.endsAfterTurn, wv.effects.at(-1)?.flags?.[SYS]?.spellEffectEnd - game.time.worldTime], ["2", undefined, 6]);
  rolls.push(47);
  await auto.leylineWeaverTap(wv, { degree: "critical", level: 3 });
  equal("F …a Critical's DB doubled", wv.effects.at(-1)?.changes?.[0]?.value, "4");
  equal("F …Failure and Fumble are the action's; nothing for a creature without the archetype", [await auto.leylineWeaverTap(wv, { degree: "failure", level: 3 }), await auto.leylineWeaverTap(makeActor("ZZ Plain"), { degree: "critical", level: 3 })], [false, false]);

  // Runeblade: the book, then the day's runes.
  reset();
  const rbA = makeActor("ZZ Runeblade", { items: [F.Runeblade] });
  answers.push("flaming");
  await auto.onItemCreatedB6B1({ ...rbA.items[0], type: "feat", name: "Runeblade", parent: rbA });
  equal("F Runeblade's book: Weapon Potency I and the chosen rune; Bane not offered there", [rbA.flags[MOD]?.infusionRunes, helpers.lastOptions.map(([k]) => k).includes("bane")], [[{ key: "potency", tier: 1, name: "Potency I", level: 2 }, { key: "flaming", tier: 1, name: "Flaming I", level: 5 }], false]);
  rbA.flags[SYS] = { infusedRunes: { weaponId: "w1", runes: "Potency I", magical: true } };
  answers.push("bane", "dragons");
  await auto.onActorUpdatedB6B1(rbA, { flags: { [SYS]: { infusedRunes: { weaponId: "w1", runes: "Potency I", magical: true } } } });
  equal("F a fresh infusion: one Runeblade Rune asked and added outside the budget; Bane's kind asked", [rbA.flags[SYS].infusedRunes.runes, rbA.flags[SYS].infusedRunes.eaRuneblade?.keys, calls.texts.length], ["Potency I, Bane (dragons)", ["bane"], 1]);
  answers.push("shock");
  await auto.onActorUpdatedB6B1(rbA, { flags: { [SYS]: { infusedRunes: { runes: "Potency I, Bane (dragons)", eaRuneblade: {} } } } });
  equal("F …its own write asks nothing", rbA.flags[SYS].infusedRunes.eaRuneblade.keys, ["bane"]);
  answers.length = 0;
  answers.push("shock");
  await auto.AUTOMATIONS_B6_B1.Runeblade.use(rbA, rbA.items[0]);
  equal("F the Use chooses again, on Block 4's runes (the old Runeblade Rune replaced)", rbA.flags[SYS].infusedRunes.runes, "Potency I, Shock I");
  const rbB = makeActor("ZZ Runelord", { items: [F.Runeblade, F["Twinflare Rune"], F["Living Sigil"], F["Runeforge Mastery"]] });
  rbB.flags[SYS] = { infusedRunes: { weaponId: "w9", runes: "" } };
  answers.push("frost", "acidic", "thundering");
  await auto.onActorUpdatedB6B1(rbB, { flags: { [SYS]: { infusedRunes: { weaponId: "w9", runes: "" } } } });
  equal("F Living Sigil: three runes, all different; Runeforge Mastery declares them on that weapon (G19)", [rbB.flags[SYS].infusedRunes.runes, rbB.effects[0]?.flags?.[SYS]?.runeDamageBypass, calls.replace[0]?.opts], ["Frost I, Acidic I, Thundering I", { label: "Runeforge Mastery", runes: ["frost", "acidic", "thundering"], weaponId: "w9", immunityAsResistance: true }, { dailyPrep: true }]);
  const rbC = makeActor("ZZ Twin", { items: [F.Runeblade, F["Twinflare Rune"]] });
  rbC.flags[SYS] = { infusedRunes: { weaponId: "w2", runes: "" } };
  answers.push("frost", "frost");
  await auto.AUTOMATIONS_B6_B1.Runeblade.use(rbC, rbC.items[0]);
  equal("F Twinflare: two asked; a rune already chosen is not offered again; no Runeforge without the feat", [helpers.lastOptions.map(([k]) => k).includes("frost"), rbC.flags[SYS].infusedRunes.eaRuneblade.keys, rbC.effects.length], [false, ["frost"], 0]);
  const rbD = makeActor("ZZ Uninfused", { items: [F.Runeblade] });
  equal("F …no infused weapon: the Use says so", await auto.AUTOMATIONS_B6_B1.Runeblade.use(rbD, rbD.items[0]), false);
}

console.log(`verify-block6b1: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
