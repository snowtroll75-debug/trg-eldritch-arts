#!/usr/bin/env node
/**
 * mutate-fixes-0101 — the mutation half of verify-fixes-0101 (0.10.1, the
 * 0.10.0 live test's findings). verify-fixes-0101 must fail on every one. It
 * rewrites files in place and restores them after each run, and on any exit:
 * run it on a copy of the tree. The verify is run with EA_MUTATING=1 (no
 * packs-source parity), so a content mutation is caught by its meaning.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-fixes-0101.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const B7 = f("module", "block7-automations.mjs"), B4 = f("module", "block4-automations.mjs"), B3 = f("module", "block3-automations.mjs"),
  C7 = f("tools", "content", "block7-spells.mjs"), D = f("module", "distracted.mjs");

const MUTATIONS = [
  // T — the teleport card with the teleport
  { name: "Panic's teleport is not registered as later than its cast", file: B7, from: "  api.registerDeferredTeleport?.(\"eaPanicTransposition\", panicDefers, moduleId);\n", to: "" },
  { name: "Panic's deferral names another spell", file: B7, from: "export const panicDefers = (ctx = {}) => R.keyOf(ctx.spell) === \"panicTransposition\";", to: "export const panicDefers = (ctx = {}) => R.keyOf(ctx.spell) === \"mirrorReprise\";" },
  { name: "Dimensional Assault's hop is not registered", file: B4, from: "  api.registerDeferredTeleport?.(\"eaDimensionalAssault\", dimensionalAssaultDefers, moduleId);\n", to: "" },
  { name: "Dimensional Assault's deferral names another spell", file: B4, from: "export const dimensionalAssaultDefers = (ctx = {}) => spellbladeSpell(ctx.spell) === \"dimensionalAssault\";", to: "export const dimensionalAssaultDefers = (ctx = {}) => spellbladeSpell(ctx.spell) === \"thunderousStrike\";" },
  { name: "Panic's move posts no card or record", file: B7, from: "  const said = spell ? ((await h().teleportationArrives?.(bearer, spell, [bearer])) ?? []) : [];", to: "  const said = [];" },
  { name: "Panic cards the teleport before the square is picked", file: B7, from: "  const moved = await teleportWithin(token, R.panicFeet(data.unlocks), \"Panic Transposition\");\n  if (!moved) return;\n", to: "  if (spell) await h().teleportationArrives?.(bearer, spell, [bearer]);\n  const moved = await teleportWithin(token, R.panicFeet(data.unlocks), \"Panic Transposition\");\n  if (!moved) return;\n" },
  { name: "Panic asks for a square on a second teleport this turn", file: B7, from: "  if (await h().teleportationFails?.(bearer)) {", to: "  if (false) {" },
  { name: "Dimensional Assault's hop posts no card or record", file: B4, from: "  const said = (await h().teleportationArrives?.(actor, ctx.spell, [actor])) ?? [];", to: "  const said = [];" },
  { name: "Dimensional Assault hops on a second teleport this turn", file: B4, from: "  if (await h().teleportationFails?.(actor)) {", to: "  if (false) {" },
  // the review (0.10.1)
  { name: "THE REVIEW'S DEFECT: Panic cards a vetoed move", file: B7, from: "  if (now.x === was.x && now.y === was.y) { warn(`${label}: the teleport was refused (see the notice).`); return null; }\n", to: "" },
  { name: "THE RE-REVIEW'S DEFECT: Panic calls its own square a refusal", file: B7, from: "  if (snapped.x === was.x && snapped.y === was.y) { warn(`${label}: you stay where you are; no teleport is made.`); return null; }\n", to: "" },
  { name: "THE RE-REVIEW'S DEFECT: Block 4 calls its own square a refusal", file: B4, from: "  if (snapped.x === was.x && snapped.y === was.y) return warn(`${label}: you stay where you are; no teleport is made.`);\n", to: "" },
  { name: "Panic's own square is carded as a teleport", file: B7, from: "  if (snapped.x === was.x && snapped.y === was.y) { warn(`${label}: you stay where you are; no teleport is made.`); return null; }", to: "  if (snapped.x === was.x && snapped.y === was.y) { warn(`${label}: you stay where you are; no teleport is made.`); return { feet: 1 }; }" },
  { name: "THE REVIEW'S DEFECT: Panic is offered when its teleport would fail", file: B7, from: "  if (await h().teleportationFails?.(bearer)) return null;\n", to: "" },
  { name: "THE REVIEW'S DEFECT: Dimensional Assault's +5 is laid before the hop", file: B4, from: "  const moved = await teleportWithin(actor, feet, \"Dimensional Assault\");\n  if (!moved) return;\n  // THE +5 ONCE", to: "  if ((ctx.warpMods?.unlocks ?? []).includes(\"eaSpatialAwareness5\")) await actor.createEmbeddedDocuments(\"ActiveEffect\", [{ name: \"Dimensional Assault: +5 Spatial Awareness\" }]);\n  const moved = await teleportWithin(actor, feet, \"Dimensional Assault\");\n  if (!moved) return;\n  if (false) // THE +5 ONCE" },
  { name: "the pick outlives a torn-down canvas", file: B3, from: "    teardown = globalThis.Hooks?.once?.(\"canvasTearDown\", () => done(null)) ?? null;\n", to: "" },
  { name: "a finished pick leaves its teardown hook", file: B3, from: "      if (teardown !== null) globalThis.Hooks?.off?.(\"canvasTearDown\", teardown);\n", to: "" },
  // O — an object, not a creature
  { name: "the Grimoire's object spells are not marked", file: C7, from: "eaGrimoire: spec.key, ...(spec.targetsObject ? { targetsObject: true } : {}) } };", to: "eaGrimoire: spec.key } };" },
  { name: "Spirit Arrow is not marked", file: C7, from: "targets: \"one arrow or bolt (you, the archer)\", targetsObject: true,", to: "targets: \"one arrow or bolt (you, the archer)\"," },
  { name: "Decoherence is not marked", file: C7, from: "key: \"decoherence\", grade: \"B\", category: \"utility\", targetsObject: true,", to: "key: \"decoherence\", grade: \"B\", category: \"utility\"," },
  { name: "Freshmark is not marked", file: C7, from: "key: \"freshmark\", grade: \"D\", category: \"utility\", targetsObject: true,", to: "key: \"freshmark\", grade: \"D\", category: \"utility\"," },
  { name: "Drearlight is marked (it targets the token carrying the object)", file: C7, from: "key: \"drearlight\", grade: \"C\", category: \"utility\",", to: "key: \"drearlight\", grade: \"C\", category: \"utility\", targetsObject: true," },
  // D — Distracted, one effect
  { name: "Distracted is six rows again", file: D, from: "  return [{\n    kind: \"bonus\", target: \"targets\", slots: [...DISTRACTED_SLOTS], bonusType: DISTRACTED_TYPE, value: DISTRACTED_VALUE,\n    name: DISTRACTED_LABEL, refresh: true, ...extra\n  }];", to: "  return DISTRACTED_SLOTS.map((slot) => ({ kind: \"bonus\", target: \"targets\", slot, bonusType: DISTRACTED_TYPE, value: DISTRACTED_VALUE, note: `(${DISTRACTED_LABEL})`, ...extra }));" },
  { name: "Distracted stacks rather than refreshing", file: D, from: "    name: DISTRACTED_LABEL, refresh: true, ...extra", to: "    name: DISTRACTED_LABEL, ...extra" },
  { name: "Distracted is named after the spell", file: D, from: "    name: DISTRACTED_LABEL, refresh: true, ...extra", to: "    refresh: true, ...extra" },
  { name: "Animate Moustache's text names the six rows' name", file: C7, from: "shown on its sheet as one effect, \"Distracted\" (your second casting replaces your first; another caster's, or another spell's, stands beside it, and the penalty stays −1).", to: "shown on its sheet as \"Animate Moustache (Distracted)\"." },
  // P — the landing prompt
  { name: "the prompt fades again", file: B3, from: "    const notice = ui.notifications?.info?.(prompt, { permanent: true }) ?? null;", to: "    const notice = ui.notifications?.info?.(prompt) ?? null;" },
  { name: "the prompt is never removed", file: B3, from: "      try { if (notice) ui.notifications?.remove?.(notice.id ?? notice); }", to: "      try { if (false) ui.notifications?.remove?.(notice.id ?? notice); }" },
  { name: "the prompt does not name the range", file: B3, from: "click the square where you land, up to ${feet} ft away. Escape cancels.", to: "click the square where you land. Escape cancels." },
  { name: "the prompt does not say Escape cancels", file: B3, from: "click the square where you land, up to ${feet} ft away. Escape cancels.", to: "click the square where you land, up to ${feet} ft away." },
  { name: "Block 4's copy keeps its own sentence", file: B4, from: "  const point = await pickPoint(landingPrompt(label, feet));\n  if (!point) return false;", to: "  const point = await pickPoint(`${label}: click where you teleport (up to ${feet} ft). Escape cancels.`);\n  if (!point) return false;" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-fixes-0101.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-fixes-0101: verify-fixes-0101 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-fixes-0101: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-fixes-0101: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
