#!/usr/bin/env node
/**
 * verify-block9b — Eldritch Arts 0.14.0 (Block 9b, on TRG Prime 3.689.0):
 * Chapter 9's 18 armour and shield runes, 16 weapon runes, 5 specific armours
 * and shields and 4 specific weapons, against the book (book-text.json, its
 * sidebars' tiers) and Graham's rulings (the Block 9 audit, Q192–Q206).
 *
 *   A  the book: every rune and item, its tiers' levels and prices
 *   B  the registrations: what each rune declares to TRG Prime
 *   C  the pure rules the workflows ask
 *   D  the workflows, against stubs
 *   E  the packs
 *   F  the wiring
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block9b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const CORE = process.env.TRG_PRIME_ROOT ? path.resolve(process.env.TRG_PRIME_ROOT) : path.resolve(ROOT, "..", "trpg-prime");
let checks = 0;
const failures = [];
const ok = (label, cond, detail = "") => { checks += 1; if (!cond) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); };
const equal = (label, a, e) => ok(label, JSON.stringify(a) === JSON.stringify(e), `expected ${JSON.stringify(e)}, got ${JSON.stringify(a)}`);
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const strip = (src) => src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");

globalThis.game = { time: { worldTime: 1000 }, user: { targets: new Set(), isGM: true }, combat: null, actors: [], settings: { get: () => null } };
const api = await import(path.join(CORE, "module", "module-api.mjs"));
const rd = await import(path.join(CORE, "module", "rune-declarations.mjs"));
const R = await import(path.join(ROOT, "module", "block9b-rules.mjs"));
const A = await import(path.join(ROOT, "module", "block9b-automations.mjs"));
const BOOK = JSON.parse(read("tools", "content", "book-text.json"));
const C = await import(path.join(ROOT, "tools", "content", "block9b.mjs"));

/* ================================================================== A */
const armourNames = BOOK.sections.armourRunes.map((e) => e.name);
const weaponNames = BOOK.sections.weaponRunes.map((e) => e.name);
equal("A the book prints 18 armour and shield runes and 16 weapon runes, every one with rules", [armourNames.length, weaponNames.length, [...armourNames, ...weaponNames].every((n) => R.RUNES_9B[n])], [18, 16, true]);
equal("A …and 5 specific armours and shields, 4 specific weapons", [BOOK.sections.specificArmour.length, BOOK.sections.specificWeapons.length, [...BOOK.sections.specificArmour, ...BOOK.sections.specificWeapons].every((e) => R.SPECIFIC_9B[e.name])], [5, 4, true]);
const price = (s) => Number(String(s).split("/")[0].replace(/[^\d]/g, ""));
for (const section of ["armourRunes", "weaponRunes"]) {
  for (const e of BOOK.sections[section]) {
    const spec = R.RUNES_9B[e.name];
    if (spec.tiers) {
      equal(`A ${e.name}: the sidebar's tiers, level and price`, (e.tiers ?? []).map((t) => [t.level, price(t.price)]), spec.tiers.map((t) => [t.level, t.price]));
    } else {
      const lv = Number(e.fields.Level);
      const both = e.fields["Armour/Shield Price"];
      const pr = both ? both.split("/").map(price) : [price(e.fields.Price)];
      equal(`A ${e.name}: its printed level and price`, [lv, pr], [spec.level, both ? [spec.armourPrice, spec.shieldPrice] : [spec.price]]);
    }
  }
}
equal("A the tiered armour/shield prices, the shield's second (Luminous, Renewal)", [R.RUNES_9B.LUMINOUS.shieldPrices, R.RUNES_9B.RENEWAL.shieldPrices, BOOK.sections.armourRunes.find((e) => e.name === "LUMINOUS").tiers.map((t) => t.price)], [[550, 1400, 3000], [1400, 5600, 25200], ["750 gp/550 gp", "2,000 gp/1,400 gp", "4,200/3,000 gp"]]);
equal("A Transcendent and Wildbane print an armour and a shield price", [[R.RUNES_9B.TRANSCENDENT.armourPrice, R.RUNES_9B.TRANSCENDENT.shieldPrice], [R.RUNES_9B.WILDBANE.armourPrice, R.RUNES_9B.WILDBANE.shieldPrice]], [[4200, 3000], [11000, 7700]]);

/* ================================================================== B */
api.resetModuleRegistry();
const regs = A.runeRegistrations9b();
api.registerRunes(regs, "trg-eldritch-arts");
equal("B all 34 register with TRG Prime, none refused", [api.registeredRunes().length, api.registrationProblems()], [34, []]);
const reg = (n) => regs.find((r) => r.name === n);
equal("B keys and names (Summoner's Brand keeps its apostrophe straight)", [reg("Summoner's Brand").key, reg("Aegisflow").key, reg("Resonant Defiance").key], ["eaSummonersBrand", "eaAegisflow", "eaResonantDefiance"]);
equal("B what goes where: armour, shield, both, weapon", [reg("Aegisflow").on, reg("Catalyst").on, reg("Luminous").on, reg("Echoing").on], [["armour"], ["shield"], ["armour", "shield"], ["weapon"]]);
equal("B the declarations (H21 and the core's own)", {
  aegis: reg("Aegisflow").declares.uncoveredDR, seal: reg("Arcanum Seal").declares.spellAdder, echoes: reg("Astral Echoes").declares.criticalRollModifier,
  sigils: reg("Binding Sigils").declares.controlSaveModifier, circle: reg("Bound Circle").declares.defenceDC[0].when, comfort: reg("Comfort").declares,
  force: reg("Force Warding").declares.resistances, soul: reg("Soul Warding").declares.resistances, ley: reg("Ley Binding").declares.defenceDC[0].when,
  swift: reg("Swiftbind").declares.donAP, trans: reg("Transcendent").declares, aether: reg("Aetherfang").declares.ignoreResistance,
  grav: reg("Gravitas").declares, brand: reg("Summoner's Brand").declares.controlLevelBonus, pyre: reg("Pyrebrand").declares.energy, chrono: reg("Chrono").declares.action.state
}, {
  aegis: { share: [0.5, 1] }, seal: [1, 2, 3], echoes: { value: [-5, -10, -15], exceptFaces: [66, 100] },
  sigils: [-2, -4, -6], circle: { sourceTraits: ["conjured", "summoned"] }, comfort: { maxDexBonus: 1, sleepAdvantage: true },
  force: ["force"], soul: ["essence"], ley: { attackKinds: ["spell"] },
  swift: { light: 1, medium: 2, heavy: 3, fullExtra: 1 }, trans: { armourCastingPenalty: 0 }, aether: ["bludgeoning", "piercing", "slashing", "physical"],
  grav: { fumbleDCModifier: 2 }, brand: 2, pyre: { type: "fire", tiers: [{ dice: "1d4" }, { dice: "2d4" }, { dice: "3d4" }] }, chrono: "eaChrono"
});
equal("B Leybound's extra die asks the module (a function)", typeof reg("Leybound").declares.extraBaseDie?.when, "function");
equal("B weapon usage lines", [reg("Aetherfang").usage, reg("Sanguine").usage, reg("Gravitas").usage, reg("Echoing").usage.melee], [{ damage: ["piercing", "slashing"], text: "any piercing or slashing weapon" }, { melee: true, damage: ["slashing"], text: "any slashing melee weapon" }, { damage: ["bludgeoning"], text: "any bludgeoning weapon" }, true]);
const armour = (runes, extra = {}) => ({ id: `a-${runes}`, type: "armour", name: "Mail", flags: {}, system: { equipped: true, runes, category: "Medium", ...extra } });
equal("B through TRG Prime's readers: Arcanum Seal II's adder, Bound Circle III's row, Comfort's Max Dex",
  [rd.runeSpellAdders([armour("Arcanum Seal II")])[0].value, rd.runeDefenceRows(armour("Bound Circle III"))[0].value, rd.runeMaxDexBonus(armour("Comfort"))], [2, 3, 1]);

/* ================================================================== C */
equal("C Aetherfang: 1d6 per severity step", ["minor", "serious", "deadly", ""].map(R.aetherfangDice), ["1d6", "2d6", "3d6", ""]);
equal("C Nullflow: ±2 per step between the rune's level and the spell's PP (Q195)", [R.nullflowModifier(8, 4), R.nullflowModifier(8, 10), R.nullflowModifier(16, 16)], [8, -4, 0]);
equal("C the core's Casting DC", [R.castingDCOf(4), R.castingDCOf(5), R.castingDCOf(0)], [16, 17, 10]);
equal("C Veil: below 25% of maximum HP, or a serious or deadly critical (Q196)", [R.veilTriggers({ hp: 9, max: 40 }), R.veilTriggers({ hp: 10, max: 40 }), R.veilTriggers({ hp: 30, max: 40, severity: "serious" }), R.veilTriggers({ hp: 30, max: 40, severity: "minor" })], [true, false, true, false]);
equal("C Chrono: Easy first, one step harder each turn, as the core's Easy check moves (Q200)", [1, 2, 3, 4, 5, 9].map((t) => [R.chronoStep(t).key, R.chronoStep(t).modifier]), [["easy", 0], ["medium", -2], ["hard", -4], ["veryHard", -7], ["incrediblyHard", -12], ["incrediblyHard", -12]]);
equal("C Warpflare: 5 force, 6 a surge, +1 near a ley line; its surge at level 9 (Q205)", [R.warpflareResult(4), R.warpflareResult(5), R.warpflareResult(6), R.warpflareResult(4, true), R.warpflareResult(5, true), R.WARPFLARE_SURGE_LEVEL], ["", "force", "surge", "force", "surge", 9]);
equal("C Sanguine: 1, or 1d4 on a natural 20 (Q202)", [R.sanguineBleed(19), R.sanguineBleed(20)], ["1", "1d4"]);
equal("C Renewal: the item's level × the tier", [R.renewalHP(8, 1), R.renewalHP(8, 2), R.renewalHP(8, 3)], [8, 16, 24]);
equal("C Spellguard's Resonant Defiance prints +1 (M79)", R.SPELLGUARD_DC_STEP, 1);
equal("C a value by tier, the last beyond the list", [R.byTier([1, 2, 3], 2), R.byTier([1, 2, 3], 7), R.byTier([], 1)], [2, 3, 0]);

/* ================================================================== D */
equal("D the runes on a field, by name and tier (and the book's old Quickbind)", A.runesOnField("Potency II, Aegisflow II, Summoner's Brand, Quickbind, Luminous III (lit)").map((r) => [r.key, r.tier]),
  [["eaAegisflow", 2], ["eaSummonersBrand", 1], ["eaSwiftbind", 1], ["eaLuminous", 3]]);
const shield = (runes, flags = {}, equipped = true) => ({ id: "s1", type: "shield", name: "Buckler", system: { equipped, runes }, flags: { "trg-prime": {}, "trg-eldritch-arts": flags } });
equal("D the Catalyst rune holds 1–4 (a shield only)", [A.catalystSlots(shield("Catalyst")), A.catalystSlots(shield("Catalyst IV")), A.catalystSlots(armour("Catalyst"))], [1, 4, 0]);
const embedded = [{ key: "leydust", name: "Leydust" }, { key: "arcanitePowder", name: "Arcanite Powder" }, { key: "spellIncense", name: "Spell Incense" }];
const actorWith = (list) => ({ items: list });
const offers = A.embeddedCatalystOffers(actorWith([shield("Catalyst II", { embedded9b: embedded, embeddedUsed9b: ["1"] })]), () => true);
equal("D embedded offers: up to the tier's slots, each once a day, not consumed, by slot", offers.map((o) => [o.itemId, o.slot, o.consume, o.label]), [["s1", "0", false, "Leydust (embedded in Buckler)"]]);
equal("D …only what fits the spell, and nothing from a shield not wielded",
  [A.embeddedCatalystOffers(actorWith([shield("Catalyst III", { embedded9b: embedded })]), (k) => k !== "leydust").map((o) => o.slot), A.embeddedCatalystOffers(actorWith([shield("Catalyst III", { embedded9b: embedded }, false)]), () => true).length], [["1", "2"], 0]);
equal("D the key behind a slot", [A.embeddedKey(shield("Catalyst III", { embedded9b: embedded }), "2"), A.embeddedKey(shield("Catalyst III", { embedded9b: embedded }), "5")], ["spellIncense", null]);
equal("D Luminous: the strongest equipped tier's light, 20 ft", [A.luminousLightOf(actorWith([armour("Luminous"), shield("Luminous III")]))?.key, A.luminousLightOf(actorWith([armour("Luminous II", { equipped: false })])), A.LUMINOUS_LIGHTS.map((l) => [l.steps, l.radiusFeet])], ["eaLuminous3", null, [[1, 20], [2, 20], [3, 20]]]);
const brandActor = actorWith([{ id: "w1", type: "weapon", name: "Edge", system: { equipped: true, runes: "Potency II, Summoner's Brand" }, flags: {} }]);
equal("D Summoner's Brand: +1 on a Summons spell's cap, whilst wielded (Q204)", [A.summonersBrandCap({ actor: brandActor, spellData: { traits: "Conjuration, Summons" } })?.value, A.summonersBrandCap({ actor: brandActor, spellData: { traits: "Evocation" } }), A.summonersBrandCap({ actor: actorWith([]), spellData: { traits: "Summons" } })], [1, 0, 0]);
equal("D Nullflare's suppression lasts to its world time", [A.nullflareSuppresses({ flags: { "trg-eldritch-arts": { nullflared9b: { until: 1006 } } } }), A.nullflareSuppresses({ flags: { "trg-eldritch-arts": { nullflared9b: { until: 1000 } } } }), A.nullflareSuppresses({ flags: {} })], [true, false, false]);
equal("D the GM writes only this module's own effects, a suppression, a Nullflare's dispel and recurring damage",
  [A.writeAllowed({ kind: "createEffect", data: { flags: { "trg-eldritch-arts": { source: "tether9b" } } } }), A.writeAllowed({ kind: "createEffect", data: { flags: { "trg-eldritch-arts": { source: "other" } } } }),
    A.writeAllowed({ kind: "suppressEffect", effectId: "e", until: 1006 }), A.writeAllowed({ kind: "deleteEffect", effectId: "e" }), A.writeAllowed({ kind: "deleteEffect", effectId: "e", nullflare: true }),
    A.writeAllowed({ kind: "recurring", amount: 2, type: "sonic" }), A.writeAllowed({ kind: "update" })], [true, false, true, false, true, true, false]);
const ra = await import(path.join(CORE, "module", "rune-actions.mjs"));
const chronoAction = ra.runeActionsFor({ type: "weapon", name: "Starfall", system: { equipped: true, runes: "Potency III, Chrono", traits: "", damageType: "slashing" }, flags: {} }).find((a) => a.key === "eaChrono");
equal("D Chrono's button, through TRG Prime's own reader: a 0 AP press that sets a running state (review: a press with no duration set nothing)",
  chronoAction && [chronoAction.apCost, chronoAction.state, chronoAction.durationSeconds > 0, chronoAction.declared], [0, "eaChrono", true, true]);
equal("D Essencebreaker offers damage types only (not a category or a bracketed entry)", ["fire", "mundane", "all damage", "cold", "mundane (silver)", "slashing"].filter((t) => R.DAMAGE_TYPES.includes(t)), ["fire", "cold", "slashing"]);
ok("D Veil is asked once a blow: the critical path only when the damage path's 25% did not ask", /if \(!R\.veilTriggers\(\{ hp: Number\(hp\.value\), max: Number\(hp\.max\) \}\)\) await offerVeil\(target, `\$\{target\.name\} takes a \$\{ctx\.critical\} critical\.`\);/.test(strip(read("module", "block9b-automations.mjs"))));
ok("D Nullflare picks among spell effects (a spell origin), not the module's own clocks", /const spells = effects\(target\)\.filter\(\(e\) => !e\.disabled && !e\.flags\?\.\[MODULE_ID\]\?\.source && originSpell\(e\) && !nullflareSuppresses\(e\)\)/.test(strip(read("module", "block9b-automations.mjs"))));
ok("D Sanguine's count is the encounter's", /const idle = \(rec\.combatId === combatId \? int\(rec\.idle\) : 0\) \+ 1;/.test(strip(read("module", "block9b-automations.mjs"))));
equal("D Leybound's die answers from the ley line found for the attack (none found: none)", [A.leyboundWhen({ actor: { uuid: "x" } })], [false]);

/* ================================================================== E */
equal("E the packs: 68 rune documents (one a tier) and 9 specific items", [C.RUNE_ITEMS_9B.length, C.SPECIFIC_ITEMS_9B.length, C.BLOCK9B_PACKS.map((p) => [p.name, p.extends])], [68, 9, [["ea-runes", "runes"], ["ea-specific-items", "specific-items"]]]);
const doc = (name) => [...C.RUNE_ITEMS_9B, ...C.SPECIFIC_ITEMS_9B].find((d) => d.name === name);
equal("E a rune tier is a gear item TRG Prime's rune picker knows", [doc("Aegisflow II").flags["trg-prime"].rune, doc("Aegisflow II").system.itemLevel, doc("Aegisflow II").system.price, doc("Force Warding").flags["trg-prime"].rune.tier],
  [{ key: "eaAegisflow", tier: 2, on: ["armour"], automation: "declared" }, 14, 36000, 1]);
ok("E each rune document carries the book's text, its tier's line and the automation note", /<strong>AEGISFLOW II<\/strong> — Level 14; Price 36,000 gp\. You apply all of your armours DR\./.test(doc("Aegisflow II").system.description)
  && /Automated \(0\.14\.0, TRG Prime 3\.689\.0\)/.test(doc("Aegisflow II").system.description) && /When you are hit and your armour lacks coverage/.test(doc("Aegisflow II").system.description));
equal("E the specific items' runes as TRG Prime records them",
  Object.fromEntries(C.SPECIFIC_ITEMS_9B.map((d) => [d.name, d.flags["trg-prime"].specificItem.runes.map((r) => `${r.key}:${r.tier}`)])),
  { "Gravemeld Shirt": ["potency:2", "eaSwiftbind:1"], "Heartstrand Harness": ["potency:1", "eaLeyBinding:1"], Shadeskin: ["potency:2", "shadow:2", "eaVeil:2"], Spellguard: ["potency:1", "eaResonantDefiance:1"],
    "Whispering Hollow": ["potency:3", "eaComfort:1", "eaSoulWarding:1"], "Bleeding Crown": ["potency:2", "eaSanguine:1"], Soulrend: ["potency:3", "eaAetherfang:1", "eaEssencebreaker:1"],
    "Ritualist's Edge": ["potency:2", "eaSummonersBrand:1"], Starfall: ["potency:3", "eaChrono:1"] });
equal("E printed statistics and materials (Q206)", [doc("Gravemeld Shirt").system.material, doc("Gravemeld Shirt").system.dr, doc("Whispering Hollow").system.maxDexBonus, doc("Shadeskin").system.material, doc("Spellguard").type, doc("Soulrend").system.fumbleDC, doc("Bleeding Crown").system.price],
  ["graveiron", 4, 7, "eversmokeCloth", "shield", 20, 5920]);
equal("E Ritualist's Edge: level 10 (m201), its name's apostrophe (Q204)", [doc("Ritualist's Edge").system.itemLevel, doc("Ritualist's Edge").system.price], [10, 7602]);
equal("E Soulrend has no Clumsy (m200)", /Clumsy/.test(doc("Soulrend").system.traits), false);
equal("E Shadeskin's printed −1 Perception, on the check", doc("Shadeskin").flags["trg-prime"].conditionals?.[0] && [doc("Shadeskin").flags["trg-prime"].conditionals[0].value, doc("Shadeskin").flags["trg-prime"].conditionals[0].when], [-1, { checkTypes: ["skill"], subjects: ["perception"] }]);

/* ================================================================== F */
// The two 9b packs are part of the built pack list.
const P = await import(path.join(ROOT, "tools", "content", "packs.mjs"));
for (const name of ["ea-runes", "ea-specific-items"]) ok(`the ${name} pack is built`, P.PACKS.some((p) => p.name === name));
const auto = strip(read("module", "block9b-automations.mjs"));
const a9 = strip(read("module", "block9a-automations.mjs"));
const script = strip(read("scripts", "eldritch-arts.mjs"));
const registration = strip(read("module", "registration.mjs"));
ok("F registered: the runes, the lights, Nullflow, Resonant Defiance, Leybound, Summoner's Brand, Tether, Nullflare and the three reaction steps",
  ["api.registerRunes?.(runeRegistrations9b(), moduleId);", "api.registerLightSources?.(LUMINOUS_LIGHTS.map", "api.registerCastReaction?.(\"eaNullflow\", nullflowReaction, moduleId);",
    "api.registerSpellCheckGate?.(\"eaResonantDefiance\", resonantDefianceGate, moduleId);", "api.registerCheckReaction?.(\"eaLeybound\", { before: leyboundBefore }, moduleId);",
    "api.registerCastCapModifier?.(\"eaSummonersBrand\", summonersBrandCap, moduleId);", "api.registerCastRefusal?.(\"eaTether\", tetherRefusal, moduleId);",
    "api.registerEffectSuppressor?.(\"eaNullflare\", nullflareSuppresses, moduleId);", "api.registerReactionStep?.(NULLFLOW_STEP, nullflowStep, moduleId);",
    "api.registerReactionStep?.(DEFIANCE_STEP, defianceStep, moduleId);", "api.registerReactionStep?.(VEIL_STEP, veilStep, moduleId);"].every((s) => auto.includes(s))
  && registration.includes("registerBlock9b(api, moduleId);"));
ok("F the hooks: strikes, fumbles, damage, turns, daily preparation, items, the sheet button",
  ["Hooks.on(\"trgPrimeStrikeResolved\", (ctx) => { onStrikeResolvedB9b(ctx)", "Hooks.on(\"trgPrimeWeaponFumble\", (ctx) => { onWeaponFumbleB9b(ctx)", "Hooks.on(\"trgPrimeDamageApplied\", (payload) => { onDamageAppliedB9b(payload)",
    "Hooks.on(\"trgPrimeTurnEnded\", (ctx) => { onTurnEndedB9b(ctx)", "Hooks.on(\"trgPrimeDailyPreparation\", (ctx) => { onDailyPreparationB9b(ctx)", "Hooks.on(\"updateItem\", (item, change) => { onItemChangedB9b(item, change)",
    "Hooks.on(\"getHeaderControlsApplicationV2\", (app, controls) => { try { onHeaderControlsB9b(app, controls);"].every((s) => script.includes(s)));
ok("F 9a's catalyst option offers the embedded ones, reads their key by slot, and keeps them (no Conservation)",
  /out\.push\(\.\.\.embeddedCatalystOffers\(ctx\.actor, \(key\) => \{/.test(a9) && /const key = ctx\.offer\?\.slot !== undefined \? embeddedKey\(ctx\.item, ctx\.offer\.slot\) : catalystKeyOf\(ctx\.item\);/.test(a9)
  && /if \(embedded\) \{[\s\S]{0,300}await embedded\.markEmbeddedUsed\(shield, slot\);\n\s*lines\.push\([^\n]*\);\n\s*return \{ keep: true, lines \};\n\s*\}\n\s*(?:const|let) keep = await conservation/.test(a9));
ok("F Wildbane's flat check is rolled on every wild surge's card (block2's table, once, at the top)", /if \(table === WILD_SURGE && depth === 0 && !shield\) \{[\s\S]{0,900}const \{ wildbaneLines \} = await import\("\.\/block9b-automations\.mjs"\);\n\s*shieldLines\.push\(\.\.\.await wildbaneLines\(actor\)\);/.test(strip(read("module", "block2-automations.mjs"))));
ok("F Pyrebrand's surge only while the rune is active (the core's energy state)", /weapon\.flags\?\.\[SYSTEM_ID\]\?\.runeState\?\.\[`\$\{key\("PYREBRAND"\)\}Active`\]/.test(auto));
ok("F once per round: Gravitas, Tether, Veilstorm, Riftcleaver", ["oncePerRound(weapon, r.upper) && await ask(attacker, `Tether", "oncePerRound(weapon, r.upper) && await ask(attacker, `Veilstorm", "oncePerRound(weapon, r.upper) && await ask(attacker, `Riftcleaver", "r.upper === \"GRAVITAS\" && crit && oncePerRound(weapon, r.upper)"].every((s) => auto.includes(s)));
ok("F a rune's day of uses is spent before its reaction acts, and returned at daily preparation",
  /await spendUse\(item, "NULLFLOW"\);/.test(auto) && /await spendUse\(item, "VEIL"\);/.test(auto) && /if \(item\.flags\?\.\[MODULE_ID\]\?\.\[USED_FLAG\]\) await item\.unsetFlag\(MODULE_ID, USED_FLAG\);/.test(auto));
ok("F Chrono: Quickened for a Strike only while it runs; the turn-end Exhaustion check by step; Fatigued ends it",
  /statuses: \["quickened"\]/.test(auto) && /system: \{ quickenedFor: \["strike"\] \}/.test(auto) && /await h\(\)\.rollExhaustionCheck\?\.\(actor, \{ modifier: step\.modifier/.test(auto) && /if \(actor\.hasCondition\?\.\("fatigued"\)\) \{\n\s*await endChrono\(actor, weapon, FATIGUED_ENDS\);/.test(auto));

// ── G: Chrono ends through the core's timer (0.14.1, from the 0.14.0 live test) ──
{
  const log = [];
  const fakeWeapon = (running) => {
    const w = { id: "w9", type: "weapon", name: "Starfall", system: { equipped: true, runes: "Potency III, Chrono" },
      flags: { "trg-prime": { runeState: { eaChrono: running } }, "trg-eldritch-arts": {} },
      setFlag: async (scope, k, v) => { w.flags[scope][k] = v; log.push(`setFlag ${scope}.${k}`); }, unsetFlag: async () => {} };
    return w;
  };
  const run = async ({ fatiguedBefore, fatiguedAfterCheck }) => {
    log.length = 0;
    const weapon = fakeWeapon(true);
    let fatigued = fatiguedBefore;
    const actor = { name: "A", items: [weapon], hasCondition: (c) => c === "fatigued" && fatigued, effects: [] };
    globalThis.game.trgPrime = { modules: {
      stopItemTimer: async (_a, item, key) => { log.push(`stop ${key}`); item.flags["trg-prime"].runeState[key] = false; return true; },
      helpers: { line: (t) => t, postCard: async (_a, title, lines) => { log.push(`card ${lines.join(" ")}`); },
        rollExhaustionCheck: async () => { log.push("check"); fatigued = fatiguedAfterCheck; return { fatigue: fatiguedAfterCheck ? 1 : 0 }; } } } };
    await A.onTurnEndedB9b({ actor });
    return { log: [...log], running: A.chronoRunning(weapon) };
  };
  const already = await run({ fatiguedBefore: true, fatiguedAfterCheck: true });
  equal("G Chrono: Fatigued at a turn's end ends it through the core's timer, with no check", [already.log.includes("stop eaChrono"), already.log.includes("check"), already.running], [true, false, false]);
  const fine = await run({ fatiguedBefore: false, fatiguedAfterCheck: false });
  equal("G …rested, the check is rolled and the rune runs on (a check that leaves you Fatigued is ended by the watcher below, on one client)", [fine.log.includes("check"), fine.log.includes("stop eaChrono"), fine.running], [true, false, true]);
  // A refused press's timer, removed as it lands.
  const weapon = fakeWeapon(false); let fatigued = true; const stops = [];
  const actor = { isOwner: true, items: { get: (id) => (id === "w9" ? weapon : null) }, hasCondition: (c) => c === "fatigued" && fatigued };
  globalThis.game.trgPrime.modules.stopItemTimer = async (_a, item, key) => { stops.push(`${item.name}:${key}`); return true; };
  const timer = (state) => ({ parent: actor, flags: { "trg-prime": { runeTimer: { itemId: "w9", key: state, state } } } });
  await A.onChronoTimerCreatedB9b(timer("eaChrono"));
  await A.onChronoTimerCreatedB9b(timer("animated"));
  fatigued = false; await A.onChronoTimerCreatedB9b(timer("eaChrono"));
  equal("G a Chrono timer that lands while the wielder is Fatigued is stopped; another rune's, or a rested wielder's, is not", stops, ["Starfall:eaChrono"]);
  // Becoming Fatigued while Chrono runs ends it then, whatever gave the condition.
  const runningWeapon = fakeWeapon(true); const idleWeapon = { ...fakeWeapon(false), id: "w8", name: "Other" };
  const cards = []; stops.length = 0; fatigued = true;
  const wielder = { isOwner: true, items: [runningWeapon, idleWeapon], hasCondition: (c) => c === "fatigued" && fatigued };
  globalThis.game.trgPrime.modules.helpers = { line: (t) => t, postCard: async (_a, _t, lines) => { cards.push(lines.join(" ")); } };
  const fatiguedEffect = { parent: wielder, statuses: new Set(["fatigued"]), flags: { "trg-prime": { condition: "fatigued" } } };
  await A.onChronoTimerCreatedB9b(fatiguedEffect);
  await A.onChronoTimerCreatedB9b({ parent: wielder, statuses: new Set(["prone"]), flags: { "trg-prime": { condition: "prone" } } });
  equal("G the Fatigued condition landing ends a running Chrono (once, with its card); another condition, or an idle Chrono, is left", [stops, cards.length, /Fatigued: the rune's effect ends/.test(cards[0] ?? "")], [["Starfall:eaChrono"], 1, true]);
  ok("G the timer watcher is hooked", read("scripts", "eldritch-arts.mjs").includes('Hooks.on("createActiveEffect", (effect) => { onChronoTimerCreatedB9b(effect)'));
  delete globalThis.game.trgPrime;
}

const manifest = JSON.parse(read("module.json"));
equal("Z the manifest: 0.15.0 on TRG Prime 3.690.0, its two packs, the script asks for 3.690.0",
  [manifest.version, manifest.relationships.systems[0].compatibility.minimum, ["ea-runes", "ea-specific-items"].every((n) => manifest.packs.some((p) => p.name === n)), /REQUIRED_SYSTEM = "3\.694\.0"/.test(read("scripts", "eldritch-arts.mjs")), manifest.download.includes("v0.18.3")],
  ["0.18.3", "3.694.0", true, true, true]);

if (failures.length) { for (const f of failures) console.log(`  ✗ ${f}`); console.log(`verify-block9b: ${checks} checks, ${failures.length} failure(s).`); process.exit(1); }
console.log(`verify-block9b: ${checks} checks, 0 failure(s).`);
