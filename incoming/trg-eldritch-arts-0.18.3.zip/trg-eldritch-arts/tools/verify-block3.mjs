#!/usr/bin/env node
/**
 * verify-block3 — Eldritch Arts 0.5.0 (Block 3a, on TRG Prime 3.680.0): the
 * Archmage, the Sorcerer and its seven birthrights, the Witch and her
 * Soulbound Familiar, their 34 specialist spells and hexes, and the five
 * Grimoire spells the birthrights grant.
 *
 *   A  the classes against the book: fields, the tables row by row (caster
 *      level, PP and BSB too), the class magic they declare
 *   B  the birthrights: ability, tradition, skills, the specialist spell and
 *      the additional spells (Q15's substitute), the special abilities
 *   C  the spells: every one printed, specialist and tagged as ruled
 *   D  the rules, run: Raw Power, Ley Bond, specialist access, the Soulbound
 *      Familiar, hexes owed, the Wild birthright
 *   E  registration
 *   F  the core, run with the content: the birthright's ability, the book
 *      ladder, the Witch's High Magic, the familiar, the PP grants (and the
 *      Block 1 racial PP found by the audit)
 *   G  the Foundry side with fakes: Hexes, Wild Power's daily spell and its
 *      surge, the Soulbound bond and bonus, Verdant Communion, Dragon Claws
 *   H  the hooks and the versions
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
function placeEnd(doc, change) { doc._source = { ...(doc._source ?? {}), ...change }; }

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const strip = (html) => String(html ?? "").replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/g, " ").replace(/\s+/g, " ").trim();
const plain = (md) => strip(String(md ?? "").replace(/\*\*([^*]+?)\*\*/g, "$1").replace(/\*([^*]+?)\*/g, "$1").replace(/<\/?sup>/g, "").replace(/<\/?u>/g, ""));
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));

/* Fakes. */
const cards = [];
const answers = [];
const created = [];
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => answers.shift() ?? null,
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  levelDC: (level) => Number(level) + 14,
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  rollCheck: async () => ({ outcome: { degree: { key: rollDegree } } }),
  // THE CORE'S SHAPE (0.5.1): a tag is `{ key, value }`, anything else is
  // skipped, and a valued condition already present takes the value into
  // its own effect. 0.5.0's fake took strings, and so missed that the
  // severed bond's "fatigued 2" fatigued no one in Foundry.
  applyConditionTagsTo: async (actor, tags) => {
    for (const t of tags) {
      if (!t || typeof t !== "object" || typeof t.key !== "string") continue;
      actor.conditions = [...(actor.conditions ?? []), `${t.key} ${t.value}`];
      const had = actor.effects.find((e) => e.flags?.["trg-prime"]?.condition === t.key);
      if (had) { had.flags["trg-prime"].value += Number(t.value); continue; }
      await actor.createEmbeddedDocuments("ActiveEffect", [{ name: `${t.key} ${t.value}`, statuses: new Set([t.key]), flags: { "trg-prime": { condition: t.key, value: Number(t.value) } } }]);
    }
  },
  // The core's death: Dying past the Death State (5 here), not HP.
  isDead: async (actor) => Number(actor.dying ?? 0) > 5,
  createFamiliarFor: async (master) => { const f = makeActor({ name: `${master.name}'s familiar`, type: "familiar" }); f.master = master.id; familiars.push(f); return f; },
  familiarsOf: async (master) => familiars.filter((f) => f.master === master.id)
};
let rollDegree = "success";
const familiars = [];
const worldActors = [];
let d20s = [];
let d100s = [];
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { this.total = this.f === "1d20" ? (d20s.shift() ?? 10) : (d100s.shift() ?? 50); return this; } };
globalThis.foundry = { utils: { hasProperty: (o, p) => p.split(".").reduce((a, k) => (a && k in a ? a[k] : undefined), o) !== undefined, escapeHTML: (s) => String(s) }, applications: { api: { DialogV2: { confirm: async () => answers.shift() ?? false } } } };
globalThis.game = { trgPrime: { modules: { helpers } }, time: { worldTime: 1000 }, combat: null, user: { isGM: true }, users: { activeGM: null }, packs: [], actors: Object.assign(worldActors, { get: (id) => worldActors.find((a) => a.id === id) ?? null }) };
globalThis.canvas = { tokens: { placeables: [] }, scene: null, dimensions: { size: 100, distance: 5 } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info: () => {} } };
globalThis.CONFIG = {};

let nextId = 1;
function makeActor({ name, type = "character", level = 1, items = [], system = {} } = {}) {
  const a = {
    id: `a${nextId++}`, name, type, isOwner: true, items: [], effects: [], flags: {}, conditions: [],
    system: { identity: { level }, magic: { casterLevelValue: level }, resources: { pp: { value: 5, max: 20 }, hp: { value: 10, max: 10 } }, ...system },
    getFlag(scope, key) { return this.flags?.[scope]?.[key]; },
    async setFlag(scope, key, value) { this.flags[scope] = { ...(this.flags[scope] ?? {}), [key]: value }; },
    async unsetFlag(scope, key) { if (this.flags[scope]) delete this.flags[scope][key]; },
    async update(data) { for (const [k, v] of Object.entries(data)) setPath(this, k, v); },
    async createEmbeddedDocuments(kind, list) {
      const out = list.map((d) => kind === "Item" ? itemOf(this, d) : effectOf(this, d));
      (kind === "Item" ? this.items : this.effects).push(...out);
      if (kind === "Item") created.push(...out);
      return out;
    },
    async deleteEmbeddedDocuments(kind, ids) { const key = kind === "Item" ? "items" : "effects"; this[key] = this[key].filter((x) => !ids.includes(x.id)); },
    // The core's setter for a valued condition: `value` sets it, `active: false` removes it.
    async toggleStatusEffect(id, { value, active } = {}) {
      const had = this.effects.find((e) => e.flags?.["trg-prime"]?.condition === id);
      if (active === false) { if (had) this.effects = this.effects.filter((e) => e !== had); return false; }
      if (had) had.flags["trg-prime"].value = Number(value);
      else await this.createEmbeddedDocuments("ActiveEffect", [{ name: `${id} ${value}`, statuses: new Set([id]), flags: { "trg-prime": { condition: id, value: Number(value) } } }]);
      return true;
    },
    getActiveTokens: () => []
  };
  for (const i of items) a.items.push(itemOf(a, i));
  worldActors.push(a);
  return a;
}
function setPath(o, p, v) { const ks = p.split("."); let t = o; for (const k of ks.slice(0, -1)) t = t[k] ??= {}; t[ks.at(-1)] = v; }
function itemOf(parent, d) {
  return {
    ...structuredClone({ ...d, flags: d.flags ?? {} }), id: d.id ?? `i${nextId++}`, parent,
    getFlag(scope, key) { return this.flags?.[scope]?.[key]; },
    // A write is a round trip to the server: the flag lands a moment later (review, 0.5.1).
    async setFlag(scope, key, value) { await new Promise((r) => setTimeout(r, 2)); this.flags[scope] = { ...(this.flags[scope] ?? {}), [key]: value }; },
    async unsetFlag(scope, key) { if (this.flags[scope]) delete this.flags[scope][key]; },
    async update(data) { for (const [k, v] of Object.entries(data)) setPath(this, k, v); }
  };
}
function effectOf(parent, d) { return { ...structuredClone(d), id: `e${nextId++}`, parent, disabled: Boolean(d.disabled), getFlag(scope, key) { return this.flags?.[scope]?.[key]; }, async setFlag(scope, key, value) { this.flags = { ...(this.flags ?? {}), [scope]: { ...(this.flags?.[scope] ?? {}), [key]: value } }; }, async update(data) { Object.assign(this, data); } }; }

const B3 = await import(new URL("./content/block3.mjs", import.meta.url));
const SP = await import(new URL("./content/block3-spells.mjs", import.meta.url));
const auto = await import(new URL("../module/block3-automations.mjs", import.meta.url));
const reg = await import(new URL("../module/registration.mjs", import.meta.url));
const scriptSrc = fs.readFileSync(path.join(ROOT, "scripts", "eldritch-arts.mjs"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "module.json"), "utf8"));
const F = (d) => d.flags?.["trg-prime"] ?? {};
const desc = (d) => strip(d.system.description);
// Tags become spaces when stripped ("2<sup>nd</sup>", "target<strong>.</strong>"),
// so the text is compared with its whitespace taken out.
const squash = (t) => String(t).replace(/\s+/g, "");
const printedIn = (d, lines) => lines.every((l) => squash(desc(d)).includes(squash(plain(l))));

/* ----------------------------------------------------------------- */
/* A — the classes                                                     */
/* ----------------------------------------------------------------- */
const C = book.classes;
const field = (cls, name) => C[cls].sections.find((s) => s.name === name).lines.join(" ");
for (const [key, item] of [["archmage", B3.ARCHMAGE], ["sorcerer", B3.SORCERER], ["witch", B3.WITCH]]) {
  const s = item.system;
  equal(`A ${item.name}: class type, key abilities, class skills, proficiencies as printed`,
    [s.classType, s.keyAbilityScores, s.classSkills, s.proficiencies], [field(key, "CLASS TYPE"), field(key, "KEY ABILITY SCORES"), field(key, "CLASS SKILLS"), field(key, "PROFICIENCIES")]);
  equal(`A ${item.name}: HP and skill points`, [`${s.hitPoints} + Con per level`, `${s.skillPoints} + Int per level`], [field(key, "HIT POINTS"), field(key, "SKILL POINTS")]);
  const tbl = C[key].sections.flatMap((x) => x.tables).find((t) => /TABLE$/.test(t.rows[0].cells[0]));
  const heads = tbl.rows[1].cells.map((c) => c.toLowerCase());
  const get = (row, ...n) => Number(row.cells[heads.findIndex((h) => n.includes(h))]);
  const rows = tbl.rows.slice(2);
  equal(`A ${item.name}: twenty table rows`, [rows.length, s.progression.length], [20, 20]);
  const bad = rows.map((row, i) => {
    const p = s.progression[i];
    const want = [get(row, "bab", "bab/bdb"), get(row, "bdb", "bab/bdb"), get(row, "fort"), get(row, "ref"), get(row, "will"), get(row, "bonus feats"), get(row, "caster level"), get(row, "pp"), get(row, "bsb")];
    const have = [p.bab, p.bdb, p.fortitude, p.reflex, p.will, p.bonusFeats, p.casterLevel, p.pp, p.bsb];
    return JSON.stringify(want) === JSON.stringify(have) && p.level === i + 1 ? null : i + 1;
  }).filter(Boolean);
  equal(`A ${item.name}: every row's BAB, BDB, saves, bonus feats, caster level, PP and BSB are the book's`, bad, []);
  ok(`A ${item.name}: the description prints the book's description`, printedIn(item, C[key].sections.find((x) => x.name === "DESCRIPTION").lines));
  ok(`A ${item.name}: …and says what is automated`, /Automated \(TRG Prime 3\.680\.0\):/.test(desc(item)));
}
equal("A Chapter 6's class wealth (L4754)", [B3.ARCHMAGE.system.wealth, B3.SORCERER.system.wealth, B3.WITCH.system.wealth], ["1", "0", "1"]);
equal("A the Archmage's magic: learned, book, six PP 2 picks, three cantrips a day from six, Int, every tradition, one a level, High Magic with a focus",
  [B3.ARCHMAGE.system.casterStyle, B3.ARCHMAGE.system.memorisationStyle, B3.ARCHMAGE.system.spellBookFirstPicks, B3.ARCHMAGE.system.cantripsPerDay, B3.ARCHMAGE.system.cantripsKnown, B3.ARCHMAGE.system.magicalAbility, F(B3.ARCHMAGE).classMagic, F(B3.ARCHMAGE).highMagicCaster, F(B3.ARCHMAGE).highMagicFocus],
  ["learned", "book", 6, 3, 6, "intelligence", { traditions: "any", bookPerLevel: 1, cantripBook: true }, true, true]);
equal("A the Archmage grants Scribe Scroll and its two abilities", [B3.ARCHMAGE.system.grantedFeats, B3.ARCHMAGE.system.classAbilities], ["1: Scribe Scroll", "1: Ley Bond, 1: Ley Tap"]);
equal("A the Sorcerer: no ability or tradition of its own (the birthright's), one any-tradition pick at 1st and every two from 3rd, no swaps, the birthright track, two cantrip slots",
  [B3.SORCERER.system.magicalAbility, B3.SORCERER.system.magicalTradition, F(B3.SORCERER).repertoire, F(B3.SORCERER).classMagic.tracks, F(B3.SORCERER).classMagic.cantrips.map((c) => c.track || c.traditions), F(B3.SORCERER).highMagicCaster],
  ["", "", { firstPicks: 1, firstPickExact: false, pickFrom: 3, pickStep: 2, swapFrom: 99 }, [{ key: "birthright", label: "Birthright", firstPicks: 0, pickFrom: 2, pickStep: 2, traditions: "track" }], ["birthright", "any"], true]);
equal("A the Sorcerer grants Component Mastery and Empower Spell, Birthright and Raw Power", [B3.SORCERER.system.grantedFeats, B3.SORCERER.system.classAbilities], ["1: Component Mastery, 1: Empower Spell", "1: Birthright, 1: Raw Power"]);
equal("A the Witch: Ethereal and Verdant picks, every spell High Magic (Graham, 4 Nov 2026), two picks at 1st and one a level from 2nd, Charisma",
  [F(B3.WITCH).classMagic, F(B3.WITCH).highMagicCaster, F(B3.WITCH).repertoire, B3.WITCH.system.magicalAbility, B3.WITCH.system.cantripsKnown],
  [{ traditions: ["ethereal", "verdant"] }, true, { firstPicks: 2, firstPickExact: false, pickFrom: 2, pickStep: 1, swapFrom: 99 }, "charisma", 2]);
ok("A the Witch's card says every spell she casts is High Magic, not Ethereal and Verdant only", /Every spell you cast is High Magic, whatever its tradition/.test(desc(B3.WITCH)) && !/Only Ethereal and Verdant spells/.test(desc(B3.WITCH)));
equal("A the Witch's abilities; a class feat at 1st (M15) is the table's", [B3.WITCH.system.classAbilities, B3.WITCH.system.progression[0].bonusFeats, B3.WITCH.system.progression[4].bonusFeats], ["1: Soulbound Familiar, 1: Verdant Communion, 1: Hexes", 1, 2]);
for (const a of B3.CLASS_ABILITIES) ok(`A ${a.name}: printed and says what is automated`, /(Automated|Waits for Block 3b)[^:]*:/.test(desc(a)) && desc(a).length > 80);
ok("A Ley Tap prints sidebar 5 (Ley Line Range)", desc(B3.LEY_TAP).includes("determined by the range of your Ley Bond ability (100 ft per level)"));
equal("A Birthright chooses the seven", F(B3.BIRTHRIGHT).abilityChoices, ["Arcanum", "Dragon", "Eternity", "Rune", "Storm", "Umbral", "Wild"]);
// The adder is the familiar's, set while the bond holds (G); the printed item carries none (0.5.1).
equal("A the Soulbound Familiar's item is no spell adder of itself", F(B3.SOULBOUND_FAMILIAR).spellAdder, undefined);
ok("A …and says the adder holds while the familiar lives and the bond holds", desc(B3.SOULBOUND_FAMILIAR).includes("+1 spell adder (one free casting a day) while it lives and the bond holds"));
equal("A Verdant Communion is once a day", [B3.VERDANT_COMMUNION.system.usesPerDay, B3.VERDANT_COMMUNION.system.usesValue], ["1", 1]);
equal("A the eight Soulbound bonuses are printed", B3.SOULBOUND_BONUSES.length, 8);

/* ----------------------------------------------------------------- */
/* B — the birthrights                                                 */
/* ----------------------------------------------------------------- */
const WANT = {
  Arcanum: ["intelligence", "arcane", ["Arcana", "Linguistics"], "Sorcerous Bond", "Disrupting Magic"],
  Dragon: ["intelligence", "arcane", ["Arcana", "Intimidate"], "Dragon Claws", "Draconic Infusion"],
  Eternity: ["wisdom", "divinity", ["Diplomacy", "Medicine"], "Eternity Resilience", "Touch of Healing"],
  Rune: ["wisdom", "divinity", ["Crafting", "Linguistics"], "Runic Resilience", "Storing Rune"],
  Storm: ["constitution", "verdant", ["Nature", "Survival"], "Gale Step", "Storm Bolt"],
  Umbral: ["charisma", "ethereal", ["Planes", "Stealth"], "Umbral Affinity", "Shadow Shift"],
  Wild: ["charisma", "", ["Perform", "Acrobatics"], "Wild Power", ""]
};
for (const b of B3.BIRTHRIGHTS) {
  const [ability, tradition, skills, special, spell] = WANT[b.name];
  const m = F(b).classMagic;
  equal(`B ${b.name}: magical ability (its first key ability), tradition, class skills, special ability`,
    [m.ability, m.tradition, m.tracks.birthright, F(b).classSkills, b.system.grantedAbilities], [ability, tradition, tradition || "any", skills, special]);
  const granted = b.system.grantedSpells.split(/,\s*/).filter(Boolean);
  if (spell) ok(`B ${b.name}: its specialist spell at 1st`, granted[0] === `1: ${spell}`);
  if (b.name !== "Wild") {
    const want = B3.additionalSpells(b.name).map((s) => `${s.level}: ${s.name}`);
    equal(`B ${b.name}: the additional spells at their printed levels`, granted.slice(1), want);
    equal(`B ${b.name}: two at 1st (a cantrip and a PP 2), then 3rd to 15th`, B3.additionalSpells(b.name).map((s) => [s.level, s.pp]), [[1, 0], [1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12], [13, 14], [15, 16]]);
  } else equal("B Wild: no fixed spells (rolled)", granted, []);
  ok(`B ${b.name}: printed (its introduction) and says what is automated`, desc(b).includes(plain(C.sorcerer.sections.find((s) => s.name === b.name.toUpperCase()).lines[0]).slice(0, 80)) && /Automated/.test(desc(b)));
}
equal("B Q15: Storm's printed 0 PP spell (v1.6: \"Orb of Electricity (0)\") is Orb of Lightning, and says so", [B3.additionalSpells("Storm")[0].name, /As ruled \(Q15\)/.test(desc(B3.BIRTHRIGHTS.find((b) => b.name === "Storm")))], ["Orb Of Lightning", true]);
equal("B the Arcanum allows a focus with High Magic (L5590)", [F(B3.BIRTHRIGHTS[0]).highMagicFocus, F(B3.SORCEROUS_BOND).highMagicFocus, B3.SORCEROUS_BOND.system.grantedAbilities], [true, true, "Arcane Bond"]);
equal("B Eternity Resilience: +2 Death State", B3.ETERNITY_RESILIENCE.effects[0].changes, [{ key: "system.combat.deathState", mode: 2, value: "2", priority: 20 }]);
equal("B Runic Resilience grants Resist Magic, printed from sidebar 6", [B3.RUNIC_RESILIENCE.system.grantedAbilities, desc(B3.RESIST_MAGIC_ABILITY).includes("You gain resistance to the spells damage type")], ["Resist Magic", true]);
equal("B Umbral Affinity: Darkvision, Darkness at 5th", [B3.UMBRAL_AFFINITY.system.grantedAbilities, B3.UMBRAL_AFFINITY.system.grantedSpells], ["Darkvision", "5: Darkness"]);
equal("B the Wild table's d20 traditions", B3.WILD_TRADITIONS.map((r) => [r.min, r.max, r.tradition]), auto.WILD_TRADITIONS.map((r) => [...r]));
equal("B the module's dragon types are the book's", Object.entries(B3.DRAGON_TYPES), Object.entries(auto.DRAGON_TYPES));
ok("B …as printed", plain(C.sorcerer.sections.find((s) => s.name === "DRAGON TYPE").lines[0]).includes("cave (acid), cold (cold), fire (fire), forest (poison), light (electricity), sea (sonic)"));
const allSpellNames = new Set([...book.grimoire.map((g) => g.name.toLowerCase()), ...book.specialist.map((s) => s.name.toLowerCase())]);
const grimoireNeeded = B3.BIRTHRIGHTS.flatMap((b) => b.system.grantedSpells.split(/,\s*/).filter(Boolean).map((x) => x.replace(/^\d+:\s*/, ""))).filter((n) => book.grimoire.some((g) => g.name.toLowerCase() === n.toLowerCase()));
equal("B the Grimoire spells the birthrights grant are the five shipped", [...new Set(grimoireNeeded)].sort(), SP.BLOCK3_GRIMOIRE.map((s) => s.name).sort());

/* ----------------------------------------------------------------- */
/* C — the spells                                                      */
/* ----------------------------------------------------------------- */
const SPEC = SP.BLOCK3_SPECIALIST;
equal("C 34 specialist spells and 5 Grimoire spells", [SPEC.length, SP.BLOCK3_GRIMOIRE.length, Object.keys(SP.SPELL_AUTOMATION).length], [34, 5, 39]);
const printedSpec = new Map(book.specialist.map((s) => [s.name.toLowerCase(), s]));
for (const s of SPEC) {
  const b = printedSpec.get(s.name.toLowerCase());
  ok(`C ${s.name}: in the book at the printed PP`, b && b.pp === s.system.ppCost, `${b?.pp} vs ${s.system.ppCost}`);
  ok(`C ${s.name}: every printed line is in the description`, b && printedIn(s, b.lines.filter((l) => l !== "WARPING OPTIONS")));
  ok(`C ${s.name}: specialist, no tradition of its own`, s.system.specialist === true && s.system.tradition === "");
  ok(`C ${s.name}: says what is automated`, /(Automated|Partly automated|Not automated|Waits for Block 3b)[^:]*:/.test(desc(s)));
}
for (const s of SP.BLOCK3_GRIMOIRE) {
  const b = book.grimoire.find((g) => g.name.toLowerCase() === s.name.toLowerCase());
  ok(`C ${s.name}: the Grimoire's, at its PP, not specialist, with a tradition`, b && b.pp === s.system.ppCost && !s.system.specialist && Boolean(s.system.tradition));
}
const hexes = SPEC.filter((s) => F(s).eaHex);
equal("C the 21 hexes", hexes.length, 21);
equal("C every hex carries the Hex trait", hexes.every((s) => /\bHex\b/.test(s.system.traits)), true);
const tag = (n) => SPEC.find((s) => s.name === n).system.specialistClass;
equal("C the tags: class trait, birthright, Bloodmage (Q17, Q18, Q21)",
  ["Arcane Singularity", "Ley Bolt", "Life Boost", "Disrupting Magic", "Storing Rune", "Shadow Shift", "Hemocovenant", "Cackle"].map(tag),
  ["Archmage", "Sorcerer", "Witch", "Arcanum", "Rune, Runemage", "Umbral", "Bloodmage", ""]);
equal("C the automation levels are those the cards say", Object.values(SP.SPELL_AUTOMATION).every((v) => ["automated", "partly", "not", "3b"].includes(v.level)), true);
ok("C Q22: Hemocovenant's stray \"+\" is noted", /typo/i.test(desc(SPEC.find((s) => s.name === "Hemocovenant"))));
const ids = [...SPEC, ...SP.BLOCK3_GRIMOIRE, ...B3.CLASS_ITEMS, ...B3.CLASS_ABILITIES, ...B3.BIRTHRIGHTS, ...B3.BIRTHRIGHT_ABILITIES].map((d) => d._id);
equal("C every id is unique", new Set(ids).size, ids.length);

/* ----------------------------------------------------------------- */
/* D — the rules, run                                                  */
/* ----------------------------------------------------------------- */
const ab = (name, extra = {}) => ({ type: "ability", name, system: { active: true }, flags: {}, ...extra });
const cls = (name) => ({ type: "class", name, system: {}, flags: {} });
const sorc = { items: [cls("Sorcerer"), ab("Raw Power")] };
equal("D Raw Power: +1 to a warped High Magic casting only",
  [auto.rawPowerRaise({ actor: sorc, highMagic: true, warped: true }), auto.rawPowerRaise({ actor: sorc, highMagic: true, warped: false }), auto.rawPowerRaise({ actor: sorc, highMagic: false, warped: true }), auto.rawPowerRaise({ actor: { items: [] }, highMagic: true, warped: true })],
  [{ value: 1, label: "Raw Power" }, 0, 0, 0]);
equal("D Ley Bond's −1: a High Magic check, once, from either bond",
  [(await auto.leyBondGate({ actor: { items: [ab("Ley Bond"), ab("Ley Line Connection")] }, highMagic: true, rollsCheck: true }))?.modifiers, await auto.leyBondGate({ actor: { items: [ab("Ley Bond")] }, highMagic: false, rollsCheck: true }),
    (await auto.leyBondGate({ actor: { items: [ab("Ley Line Connection")] }, highMagic: true, rollsCheck: true }))?.modifiers?.[0]?.label],
  [[{ label: "Ley Bond (High Magic casting DC −1)", value: 1, type: "untyped", castingOnly: true }], null, "Ley Line Connection (High Magic casting DC −1)"]);
const spellOf = (specialistClass, traits = "", extra = {}) => ({ name: "x", system: { specialistClass, traits, specialist: true, ...extra.system }, flags: extra.flags ?? {} });
equal("D only a specialist spell, and not a hex, is opened (review): an Archmage is not offered Invisibility, an Umbral not Blur, either not a hex",
  [auto.specialistAccess({ items: [cls("Archmage")] }, spellOf("", "Illusion", { system: { specialist: false } })), auto.specialistAccess({ items: [cls("Sorcerer"), ab("Umbral", { flags: { "trg-prime": { eaBirthright: "Umbral" } } })] }, spellOf("", "Shadow", { system: { specialist: false } })),
    auto.specialistAccess({ items: [cls("Archmage")] }, spellOf("", "Hex", { flags: { "trg-prime": { eaHex: true } } }))], [false, false, false]);
const br = (name) => ab(name, { flags: { "trg-prime": { eaBirthright: name } } });
const sorcOf = (b) => ({ items: [cls("Sorcerer"), br(b)] });
equal("D specialist access: the Archmage any class; a birthright its own and its list; Umbral the shadow trait; Wild none; a Wizard nothing new",
  [auto.specialistAccess({ items: [cls("Archmage")] }, spellOf("Druid")), auto.specialistAccess(sorcOf("Arcanum"), spellOf("Arcanum")), auto.specialistAccess(sorcOf("Arcanum"), spellOf("Wizard")), auto.specialistAccess(sorcOf("Arcanum"), spellOf("Cleric")),
    auto.specialistAccess(sorcOf("Eternity"), spellOf("Cleric, Druid")), auto.specialistAccess(sorcOf("Storm"), spellOf("Druid")), auto.specialistAccess(sorcOf("Umbral"), spellOf("Wizard", "Illusion, Shadow")), auto.specialistAccess(sorcOf("Umbral"), spellOf("Wizard", "Illusion")),
    auto.specialistAccess(sorcOf("Wild"), spellOf("Wizard")), auto.specialistAccess(sorcOf("Rune"), spellOf("Rune, Runemage")), auto.specialistAccess({ items: [cls("Wizard")] }, spellOf("Arcanum"))],
  [true, true, true, false, true, true, true, false, false, true, false]);
const mirror = { level: 6, abilities: { charisma: 4 } };
equal("D the Soulbound Familiar: +level HP, Charisma to every save, as a class bonus; an ordinary familiar nothing",
  [auto.soulboundModifier({ flags: { "trg-eldritch-arts": { soulbound: { masterId: "x" } } } }, mirror), auto.soulboundModifier({ flags: {} }, mirror)],
  [{ label: "Soulbound Familiar", hp: 6, saves: 4, type: "class" }, null]);
equal("D hexes owed: 1 at 1st, +1 at 3rd and every three", [1, 2, 3, 5, 6, 9, 20].map(auto.hexesOwed), [1, 1, 2, 2, 3, 4, 7]);
equal("D the Wild spells owed (Q19): two at 1st, then one at 3rd … 15th", [1, 2, 3, 15, 20].map((l) => auto.wildSpellsOwed(l).length), [2, 2, 3, 9, 9]);
equal("D the d20 tradition", [1, 5, 6, 10, 11, 15, 16, 20].map(auto.wildTradition), ["arcane", "arcane", "divinity", "divinity", "ethereal", "ethereal", "verdant", "verdant"]);
equal("D Wild Power surges on an unmodified 13 with a spell of PP 2 or more, rolled",
  [auto.wildSurges({ natural: 13, basePP: 2, rollsCheck: true }), auto.wildSurges({ natural: 13, basePP: 1, rollsCheck: true }), auto.wildSurges({ natural: 12, basePP: 4, rollsCheck: true }), auto.wildSurges({ natural: 13, basePP: 4, rollsCheck: false })],
  [true, false, false, false]);
equal("D Power Recovery's bonus (the core's ladder)", ["heroic", "critical", "success", "partial", "failure"].map((d) => auto.powerRecoveryBonus(d, 5)), [10, 5, 3, 1, 0]);
equal("D the ten Soulbound choices: the printed eight, the save split three ways", [auto.SOULBOUND_BONUSES.length, auto.SOULBOUND_BONUSES.filter((b) => /saves$/.test(b.label)).length], [10, 3]);

/* ----------------------------------------------------------------- */
/* E — registration                                                    */
/* ----------------------------------------------------------------- */
const got = { classes: {}, autos: [], cap: [], access: [], familiar: [], pp: [], gates: {} };
const fakeApi = new Proxy({}, { get: (t, k) => {
  if (k === "registerClass") return (n, s) => { got.classes[n] = s; };
  if (k === "registerFeatAutomation") return (n) => got.autos.push(n);
  if (k === "registerCastCapModifier") return (n, f) => got.cap.push([n, f]);
  if (k === "registerSpecialistAccess") return (n, f) => got.access.push([n, f]);
  if (k === "registerFamiliarModifier") return (n, f) => got.familiar.push([n, f]);
  if (k === "registerPPGrant") return (n, s) => got.pp.push([n, s]);
  if (k === "registerSpellCheckGate") return (n, f) => { got.gates[n] = f; };
  return () => {};
} });
reg.registerContent(fakeApi, "trg-eldritch-arts");
// Block 4 (0.7.0) registers two more; verify-block4 holds them.
const B3_CLASS_NAMES = ["Archmage", "Sorcerer", "Witch"];
equal("E the three classes, with Chapter 6's wealth and their proficiency", Object.entries(got.classes).filter(([n]) => B3_CLASS_NAMES.includes(n)).map(([n, s]) => [n, s.wealth, s.proficiency.weaponCategories, s.proficiency.weaponNames]),
  [["Archmage", 1, [], ["Club", "Staff"]], ["Sorcerer", 0, ["Simple"], []], ["Witch", 1, ["Simple"], []]]);
ok("E the seven Block 3 automations", Object.keys(auto.AUTOMATIONS).every((n) => got.autos.includes(n)) && Object.keys(auto.AUTOMATIONS).length === 7);
// Block 6 (0.9.0) adds Hex Weaver's and Bloodmage's hex access and Birthrager's BSB floor; verify-block6a holds them.
equal("E Raw Power, the specialist access, the Soulbound Familiar, Wild Power's PP", [got.cap.filter((x) => x[0] !== "eaSummonersBrand" && x[0] !== "easummonersbrand").map((x) => x[1] === auto.rawPowerRaise), /* Block 9b (0.14.0): Summoner's Brand's, held by verify-block9b */ got.access.filter((x) => !["warlockHexes", "hexWeaver", "bloodmageHexes"].includes(x[0])).map((x) => x[1] === auto.specialistAccess), got.familiar.map((x) => x[1] === auto.soulboundModifier), got.pp.filter((x) => !["Natural Resilience", "Scaled Focus", "Birthrager"].includes(x[0])).map((x) => [x[0], x[1].perLevel, x[1].types])],
  [[true], [true], [true], [["Wild Power", 1, ["ability"]]]]);
ok("E Ley Line Connection's gate is now the bond's (one row from either)", got.gates.leyLineConnection === auto.leyBondGate);
ok("E every automation names an item this module ships", Object.keys(auto.AUTOMATIONS).every((n) => [...B3.CLASS_ABILITIES, ...B3.BIRTHRIGHT_ABILITIES].some((d) => d.name === n)));

/* ----------------------------------------------------------------- */
/* F — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
{
  globalThis.foundry.applications.api.DialogV2.wait = async () => null;
  const cd = await import(sys("module", "class-derive.mjs"));
  const cp = await import(sys("module", "class-progression.mjs"));
  const hm = await import(sys("module", "magic", "high-magic.mjs"));
  const sb = await import(sys("module", "magic", "spellbook.mjs"));
  const capi = await import(sys("module", "module-api.mjs"));
  const fm = await import(sys("module", "familiar-modifiers.mjs"));
  const fw = await import(sys("module", "feats-workflow.mjs"));
  const actorWith = (items, level) => { const a = { items, system: { identity: { level }, magic: {} } }; cd.prepareClassProgression(a.system, a); return a; };
  const storm = B3.BIRTHRIGHTS.find((b) => b.name === "Storm");
  const s1 = actorWith([B3.SORCERER], 3);
  const s2 = actorWith([B3.SORCERER, storm], 3);
  equal("F a Sorcerer casts once it has a birthright: Constitution, verdant (D4e)",
    [cp.classCasts(s1.system.progression), cp.classCasts(s2.system.progression), s2.system.progression.magicalAbility, s2.system.progression.tradition, s2.system.progression.learnTraditions],
    [false, true, "constitution", "verdant", "any"]);
  const wild = actorWith([B3.SORCERER, B3.BIRTHRIGHTS.find((b) => b.name === "Wild")], 3);
  equal("F a Wild Sorcerer: Charisma, no tradition, but its PP ability bonus stands (a High Magic class)",
    [wild.system.progression.magicalAbility, wild.system.progression.tradition, cp.powerPointAbilityBonus({ tradition: "", abilityTotal: 3, highMagicClass: Boolean(wild.system.progression.learnTraditions) })], ["charisma", "", 3]);
  const arch = actorWith([B3.ARCHMAGE], 5);
  equal("F the Archmage's book: 6 + one a level", [sb.spellBookSlots(5, 6, arch.system.progression.classMagic.bookPerLevel), sb.spellBookSlots(20, 6, 1)], [10, 25]);
  const witch = { items: [B3.WITCH], system: { magic: { tradition: "ethereal" } } };
  const hex = SPEC.find((s) => s.name === "Hex Ward");
  equal("F the Witch: a verdant spell, a hex (Q16) and an arcane spell are all High Magic (Graham, 4 Nov 2026: \"All Witch spells\")",
    [hm.highMagicCast(witch, { tradition: "verdant" }).highMagic, hm.highMagicCast(witch, hex.system).highMagic, hm.highMagicCast(witch, { tradition: "arcane" }).highMagic, hm.highMagicCast(witch, { tradition: "divinity", traits: "Healing" }).highMagic], [true, true, true, true]);
  equal("F …while a caster with no High Magic class casts the arcane spell ordinarily", hm.highMagicCast({ items: [], system: { magic: { tradition: "arcane" } } }, { tradition: "arcane" }).highMagic, false);
  capi.resetModuleRegistry();
  // What registration.mjs registers for these, on the core's own registry.
  for (const [name, per] of Object.entries(reg.RACIAL_PP)) capi.registerRacialPP(name, per, "trg-eldritch-arts");
  for (const [name, spec] of got.pp) capi.registerPPGrant(name, spec, "trg-eldritch-arts");
  for (const [name, fn] of got.familiar) capi.registerFamiliarModifier(name, fn, "trg-eldritch-arts");
  const witchMaster = { identity: { level: 4 }, progression: {}, combat: { bab: { total: 2 }, bdb: { total: 2 } }, resources: { hp: { max: 30 } }, skills: {}, attributes: { charisma: { total: 3 } } };
  const famMod = (await import(sys("module", "familiar.mjs"))).familiarMirrorFrom(witchMaster, "W");
  equal("F the core asks the module for a Soulbound familiar: +4 HP, +3 to each save",
    fm.familiarModifierResults({ flags: { "trg-eldritch-arts": { soulbound: { masterId: "w" } } } }, famMod).map((r) => [r.hp, r.saves]), [[4, { fortitude: 3, reflex: 3, will: 3 }]]);
  const rows = fw.modulePPGrants();
  const due = (name, level) => rows.find((r) => r.name === name)?.due({ system: { identity: { level } } });
  equal("F THE AUDIT'S FIND, FIXED: the four races' PP reach the core's reconcile, per level, and Wild Power's",
    [due("aetherial", 5), due("emberkin", 5), due("nyrinn", 5), due("scaelyn", 5), due("wild power", 5)], [5, 5, -5, 5, 5]);
  equal("F …on the right items", rows.filter((r) => !["natural resilience", "scaled focus", "birthrager"].includes(r.name)).map((r) => [r.name, r.types]).sort(), [["aetherial", ["race", "heritage"]], ["emberkin", ["race", "heritage"]], ["nyrinn", ["race", "heritage"]], ["scaelyn", ["race", "heritage"]], ["wild power", ["ability"]]]);
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* G — the Foundry side, with fakes                                     */
/* ----------------------------------------------------------------- */
{
  // A fake spells pack: two hexes and a few spells.
  const doc = (d) => ({ ...d, toObject: () => structuredClone({ ...d, type: "spell" }) });
  const entries = [
    { _id: "h1", name: "Hex Ward", system: { ppCost: 1, specialist: true, tradition: "" }, flags: { "trg-prime": { eaHex: true } } },
    { _id: "h2", name: "Malicious Shadow", system: { ppCost: 7, specialist: true, tradition: "" }, flags: { "trg-prime": { eaHex: true } } },
    { _id: "h3", name: "Cackle", system: { ppCost: 1, specialist: true, tradition: "" }, flags: { "trg-prime": { eaHex: true } } },
    { _id: "s1", name: "Bolt", system: { ppCost: 2, specialist: false, tradition: "verdant" }, flags: {} },
    { _id: "s2", name: "Spark", system: { ppCost: 0, specialist: false, tradition: "verdant" }, flags: {} },
    { _id: "p1", name: "Force Bolt", system: { ppCost: 1, specialist: true, tradition: "" }, flags: {} },
    { _id: "p2", name: "Ice Shard", system: { ppCost: 1, specialist: true, tradition: "" }, flags: {} }
  ];
  const pack = { documentName: "Item", collection: "trg-prime.spells", metadata: {}, getIndex: async () => new Map(entries.map((e) => [e._id, e])), getDocument: async (id) => doc(entries.find((e) => e._id === id)) };
  game.packs = [pack];
  const witch = makeActor({ name: "ZZ Witch", level: 3, items: [{ ...B3.HEXES, id: "hexes" }, { ...B3.SOULBOUND_FAMILIAR, id: "sb" }, { ...B3.VERDANT_COMMUNION, id: "vc" }] });
  // One Use takes every hex owed (0.5.1): two at 3rd.
  answers.push("h1", "h3");
  const hexTitles = [];
  const chooser = helpers.chooseFromList;
  helpers.chooseFromList = async (title, ...rest) => { hexTitles.push(title); return chooser(title, ...rest); };
  await auto.AUTOMATIONS.Hexes.use(witch, witch.items[0]);
  helpers.chooseFromList = chooser;
  equal("G Hexes at 3rd: both owed in one Use, titled 1 of 2 and 2 of 2; a hex above your level is not offered; each a specialist spell from the Hexes ability",
    [hexTitles, witch.items.filter((i) => i.type === "spell").map((i) => [i.name, i.flags["trg-eldritch-arts"].hexPick, i.flags["trg-prime"].grantedBy.sourceName])],
    [["Hexes — 1 of 2", "Hexes — 2 of 2"], [["Hex Ward", true, "Hexes"], ["Cackle", true, "Hexes"]]]);
  await auto.AUTOMATIONS.Hexes.use(witch, witch.items[0]);
  ok("G …a second Use says every hex is known", cards.some((c) => c.title === "Hexes" && /You know all 2 of your hexes/.test((c.lines ?? []).join(" "))));
  const witch2 = makeActor({ name: "ZZ Witch 2", level: 3, items: [{ ...B3.HEXES, id: "hexes2" }] });
  answers.length = 0;
  answers.push("h1");
  await auto.AUTOMATIONS.Hexes.use(witch2, witch2.items[0]);
  equal("G …a cancelled second choice keeps the first", witch2.items.filter((i) => i.type === "spell").map((i) => i.name), ["Hex Ward"]);
  answers.length = 0;
  const witch3 = makeActor({ name: "ZZ Witch 3", level: 3, items: [{ ...B3.HEXES, id: "hexes3" }, { _id: "hw", name: "Hex Ward", type: "spell", flags: { "trg-eldritch-arts": { hexPick: true } } }, { _id: "ck", name: "Cackle", type: "spell", flags: {} }] });
  await auto.AUTOMATIONS.Hexes.use(witch3, witch3.items[0]);
  ok("G …and when no hex it may take is left, it says so", cards.some((c) => /no hex you can take/.test(c.warn ?? "")));
  // The Soulbound Familiar.
  const adder = () => witch.items[1].flags?.["trg-prime"]?.spellAdder;
  equal("G no familiar, no spell adder", adder(), undefined);
  await auto.AUTOMATIONS["Soulbound Familiar"].use(witch, witch.items[1]);
  const fam = familiars[0];
  equal("G the bond: a familiar, marked soulbound, with Base DR 2", [Boolean(fam), fam?.flags?.["trg-eldritch-arts"]?.soulbound?.masterId === witch.id, fam?.effects?.[0]?.changes?.[0]], [true, true, { key: "system.combat.naturalArmourBase.natural", mode: 4, value: "2", priority: 20 }]);
  equal("G …and while the bond holds the ability is a +1 spell adder", adder(), 1);
  answers.length = 0;
  answers.push("bonus", "will");
  await auto.AUTOMATIONS["Soulbound Familiar"].use(witch, witch.items[1]);
  const bonus = witch.effects.find((e) => e.flags?.["trg-eldritch-arts"]?.source === "soulboundBonus");
  equal("G today's bonus on the Witch", bonus?.changes, [{ key: "system.combat.saves.will.class", mode: 2, value: "2", priority: 20 }]);
  // The range is read where the tokens stand, not where they are drawn (0.5.1).
  const grid = { getSnappedPoint: (p) => p, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 100 * 5 }) };
  canvas.grid = grid;
  const tokenFor = (actor, x, drawnX) => { const t = { actor, w: 100, h: 100, scene: "s", center: { x: drawnX + 50, y: 50 }, document: { width: 1, _source: { x, y: 0, width: 1, height: 1 } } }; t.document.object = t; actor.getActiveTokens = () => [t]; return t; };
  tokenFor(witch, 0, 0);
  // V14 (0.11.2): the placeable is drawn at the OLD square (5 ft away); the source carries the move's end.
  const famToken = tokenFor(fam, 100, 100);
  famToken.document.id = "famTok";
  placeEnd(famToken.document, { x: 1000 });
  await auto.onTokenMovedB3(famToken.document);
  ok("G a familiar that has moved 50 ft away (its end in `change`) switches the bonus off, though it still stands and is drawn 5 ft away", bonus.disabled === true);
  placeEnd(famToken.document, { x: 200 });
  await auto.onTokenMovedB3(famToken.document);
  ok("G …and one moved back to 10 ft switches it on, though its document still says 50 ft away", bonus.disabled === false);
  witch.getActiveTokens = () => [];
  fam.getActiveTokens = () => [];
  // Killed while already below 0 HP: Dying rises, HP does not change (0.5.1).
  fam.dying = 6;
  // One death, several roads at once: the Dying update, the Dead status, the slain hook (review, 0.5.1).
  await Promise.all([auto.onActorUpdatedB3(fam, { flags: {} }), auto.onFamiliarMaybeDiedB3(fam), auto.onFamiliarMaybeDiedB3(fam)]);
  equal("G Severed Bond: the familiar killed by its Dying — fatigued 2, the bonus gone, rebonding only at daily preparation",
    [witch.conditions, witch.effects.some((e) => e.flags?.["trg-eldritch-arts"]?.source === "soulboundBonus"), Boolean(witch.items[1].flags["trg-eldritch-arts"]?.soulboundSevered)], [["fatigued 2"], false, true]);
  equal("G …severed once though told three times at once: one Fatigued 2, one card", [witch.effects.filter((e) => e.flags?.["trg-prime"]?.condition === "fatigued").map((e) => e.flags["trg-prime"].value), cards.filter((c) => c.actor === "ZZ Witch" && c.title === "Soulbound Familiar — Severed Bond").length], [[2], 1]);
  equal("G …and a dead familiar is no spell adder", adder(), undefined);
  await auto.onActorUpdatedB3(fam, { name: "x" });
  equal("G …a second word of the death does not sever twice", witch.conditions, ["fatigued 2"]);
  const deadBefore = cards.length;
  await auto.AUTOMATIONS["Soulbound Familiar"].use(witch, witch.items[1]);
  ok("G a dead familiar is not rebonded: delete its actor first (review)", cards.slice(deadBefore).some((c) => /is dead — delete its actor/.test(c.warn ?? "")) && familiars.length === 1);
  answers.length = 0;
  await auto.onDailyPreparationB3({ actor: witch });
  ok("G …nor at daily preparation", familiars.length === 1 && cards.some((c) => /is dead\. Delete its actor/.test((c.lines ?? []).join(" "))));
  familiars.length = 0;
  await auto.AUTOMATIONS["Soulbound Familiar"].use(witch, witch.items[1]);
  ok("G …a Use outside it is refused", cards.some((c) => /only be made during your daily preparation/.test(c.warn ?? "")) && familiars.length === 0);
  await helpers.applyConditionTagsTo(witch, [{ key: "fatigued", value: 1 }]);
  answers.length = 0;
  answers.push(true, "db");
  await auto.onDailyPreparationB3({ actor: witch });
  equal("G …the new bond takes its 2 off and leaves the 1 gained since (review)", witch.effects.filter((e) => e.flags?.["trg-prime"]?.condition === "fatigued").map((e) => e.flags["trg-prime"].value), [1]);
  equal("G …and at daily preparation the new bond and today's bonus, and the fatigue gone (review)", [familiars.length, Boolean(witch.items[1].flags["trg-eldritch-arts"]?.soulboundSevered), witch.effects.find((e) => e.flags?.["trg-eldritch-arts"]?.source === "soulboundBonus")?.changes?.[0]?.key], [1, false, "system.combat.defence.circumstance"]);
  ok("G …the new bond's card says the fatigue ends, and the adder is back", cards.some((c) => c.title === "Soulbound Familiar" && /fatigued 2<\/strong> ends: Fatigued 3 → 1/.test((c.lines ?? []).join(" "))) && adder() === 1);
  // A bond severed by distance, renewed with the same familiar, and fatigue the Witch already had (0.5.1).
  {
    const w = makeActor({ name: "ZZ Witch Far", level: 2, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sbf" }] });
    await auto.AUTOMATIONS["Soulbound Familiar"].use(w, w.items[0]);
    await w.createEmbeddedDocuments("ActiveEffect", [{ name: "fatigued 1", statuses: new Set(["fatigued"]), flags: { "trg-prime": { condition: "fatigued", value: 1 } } }]);
    answers.length = 0;
    answers.push("sever");
    await auto.AUTOMATIONS["Soulbound Familiar"].use(w, w.items[0]);
    const tired = w.effects.filter((e) => e.flags?.["trg-prime"]?.condition === "fatigued");
    equal("G a bond severed by distance: the 2 added to the fatigue already there, recorded, no spell adder", [tired.length, tired[0]?.flags?.["trg-prime"]?.value, w.items[0].flags["trg-eldritch-arts"]?.soulboundSevered?.fatigue, w.items[0].flags?.["trg-prime"]?.spellAdder], [1, 3, 2, undefined]);
    const n = cards.length;
    answers.length = 0;
    answers.push(true, "hp");
    await auto.onDailyPreparationB3({ actor: w });
    const said = cards.slice(n).filter((c) => c.title === "Soulbound Familiar").map((c) => (c.lines ?? []).join(" ")).join(" | ");
    ok("G …renewed at daily preparation with the same familiar, and the card says so", /bond with <strong>ZZ Witch Far&#39;s familiar<\/strong> is renewed/.test(said) && familiars.filter((f) => f.master === w.id).length === 1, said);
    equal("G …and the 2 comes off the fatigue it merged into, leaving the 1 she had", w.effects.filter((e) => e.flags?.["trg-prime"]?.condition === "fatigued").map((e) => e.flags["trg-prime"].value), [1]);
    // A bond severed under 0.5.0 applied no fatigue, and its renewal takes none.
    const w5 = makeActor({ name: "ZZ Witch 050", level: 1, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sb5", flags: { "trg-eldritch-arts": { soulboundSevered: { why: "x", at: 1 } } } }] });
    await w5.createEmbeddedDocuments("ActiveEffect", [{ name: "fatigued 1", statuses: new Set(["fatigued"]), flags: { "trg-prime": { condition: "fatigued", value: 1 } } }]);
    answers.length = 0;
    answers.push(true, "hp");
    await auto.onDailyPreparationB3({ actor: w5 });
    equal("G a 0.5.0 severed bond renewed takes no fatigue it never gave", w5.effects.filter((e) => e.flags?.["trg-prime"]?.condition === "fatigued").map((e) => e.flags["trg-prime"].value), [1]);
    equal("G …the bond whole again: no severed flag, the adder back", [Boolean(w.items[0].flags["trg-eldritch-arts"]?.soulboundSevered), w.items[0].flags?.["trg-prime"]?.spellAdder], [false, 1]);
    // A 0.5.0 Witch: the printed adder on her item and no familiar.
    const old = makeActor({ name: "ZZ Witch Old", level: 1, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sbo", flags: { "trg-prime": { spellAdder: 1 } } }] });
    await auto.refreshAllB3();
    equal("G a 0.5.0 Witch with no familiar loses the printed adder at the first sync", old.items[0].flags?.["trg-prime"]?.spellAdder, undefined);
    // Death told only by an update that is not to HP (the Dead status's actor write).
    const w6 = makeActor({ name: "ZZ Witch Upd", level: 1, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sb6" }] });
    const f6 = makeActor({ name: "ZZ Upd Cat", type: "familiar" });
    f6.master = w6.id; familiars.push(f6); await f6.setFlag("trg-eldritch-arts", "soulbound", { masterId: w6.id }); f6.dying = 6;
    await auto.onActorUpdatedB3(f6, { statuses: ["dead"] });
    ok("G a familiar's death told by an update to anything but HP severs the bond", Boolean(w6.items[0].flags["trg-eldritch-arts"]?.soulboundSevered));
    // A familiar that died unseen: severed at the next sync, its adder gone.
    const w2 = makeActor({ name: "ZZ Witch Unseen", level: 1, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sbu", flags: { "trg-prime": { spellAdder: 1 } } }] });
    const f2 = makeActor({ name: "ZZ Unseen Cat", type: "familiar" });
    f2.master = w2.id; familiars.push(f2); await f2.setFlag("trg-eldritch-arts", "soulbound", { masterId: w2.id }); f2.dying = 6;
    await auto.refreshAllB3();
    equal("G a familiar that died unseen severs the bond at the next sync, and takes the adder", [Boolean(w2.items[0].flags["trg-eldritch-arts"]?.soulboundSevered), w2.conditions, w2.items[0].flags?.["trg-prime"]?.spellAdder], [true, ["fatigued 2"], undefined]);
    // A dead familiar made otherwise (no Soulbound mark, so nothing severs): still no adder.
    const w3 = makeActor({ name: "ZZ Witch Other", level: 1, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sbx", flags: { "trg-prime": { spellAdder: 1 } } }] });
    const f3 = makeActor({ name: "ZZ Other Cat", type: "familiar" });
    f3.master = w3.id; familiars.push(f3); f3.dying = 6;
    await auto.refreshAllB3();
    equal("G …and a dead familiar the bond did not make gives no adder either", [Boolean(w3.items[0].flags["trg-eldritch-arts"]?.soulboundSevered), w3.items[0].flags?.["trg-prime"]?.spellAdder], [false, undefined]);
    // Nor a living one (review, 0.5.1): the adder is the soulbound familiar's.
    const w4 = makeActor({ name: "ZZ Witch Feat", level: 1, items: [{ ...B3.SOULBOUND_FAMILIAR, id: "sb4", flags: { "trg-prime": { spellAdder: 1 } } }] });
    const f4 = makeActor({ name: "ZZ Feat Owl", type: "familiar" });
    f4.master = w4.id; familiars.push(f4);
    await auto.refreshAllB3();
    equal("G …nor a living familiar the core's Familiar feat made", w4.items[0].flags?.["trg-prime"]?.spellAdder, undefined);
  }
  // Verdant Communion.
  rollDegree = "critical";
  witch.system.magic.casterLevelValue = 3;
  witch.system.resources.pp = { value: 5, max: 20 };
  await auto.AUTOMATIONS["Verdant Communion"].use(witch, witch.items[2]);
  equal("G Verdant Communion: a Critical regains 1 PP per caster level, +2 Nature and Survival for an hour, the day's use spent",
    [witch.system.resources.pp.value, witch.effects.find((e) => e.flags?.["trg-eldritch-arts"]?.source === "verdantCommunion")?.changes?.map((c) => c.key), witch.items[2].system.usesValue], [8, ["system.skills.nature.class", "system.skills.survival.class"], 0]);
  await auto.AUTOMATIONS["Verdant Communion"].use(witch, witch.items[2]);
  ok("G …once a day", cards.some((c) => /once per day/.test(c.warn ?? "")));
  // Wild Power.
  const sorc = makeActor({ name: "ZZ Wild", level: 3, items: [{ ...B3.WILD_POWER, id: "wp" }] });
  d20s = [17, 18, 19];
  answers.length = 0;
  await auto.AUTOMATIONS["Wild Power"].use(sorc, sorc.items[0]);
  ok("G Wild Power: a cancelled choice adds nothing", !sorc.items.some((i) => i.type === "spell"));
  d20s = [17, 17, 3];
  answers.length = 0;
  answers.push("s2|trg-prime.spells", "s1|trg-prime.spells");
  await auto.AUTOMATIONS["Wild Power"].use(sorc, sorc.items[0]);
  equal("G …at 3rd, the cantrip and the PP 2 of the d20's tradition; the 3rd-level PP 4 has none, and says so",
    [sorc.items.filter((i) => i.type === "spell").map((i) => [i.name, i.flags["trg-eldritch-arts"].wildSpell.pp, i.flags["trg-eldritch-arts"].wildSpell.tradition]), cards.some((c) => /No arcane spell of PP 4/.test((c.lines ?? []).join(" ")))],
    [[["Spark", 0, "verdant"], ["Bolt", 2, "verdant"]], true]);
  const random = Math.random;
  Math.random = () => 0;
  // A row whose pool was empty stays owed, and the next Use fills it (review).
  const wildRows = () => sorc.items.filter((i) => i.flags?.["trg-eldritch-arts"]?.wildSpell).map((i) => `${i.flags["trg-eldritch-arts"].wildSpell.level}:${i.flags["trg-eldritch-arts"].wildSpell.pp}`);
  const rowsBefore = wildRows();
  d20s = [3];
  answers.length = 0;
  await auto.AUTOMATIONS["Wild Power"].use(sorc, sorc.items[0]);
  equal("G Wild Power's rows are matched by level and PP: the empty 3rd-level row is rolled again, and nothing else", [rowsBefore, wildRows()], [["1:0", "1:2"], ["1:0", "1:2"]]);
  const wild1 = makeActor({ name: "ZZ Wild 1", level: 1, items: [{ ...B3.WILD_POWER, id: "wp1" }] });
  d20s = [1, 17];
  answers.length = 0;
  answers.push("s1|trg-prime.spells");
  await auto.AUTOMATIONS["Wild Power"].use(wild1, wild1.items[0]);
  d20s = [17];
  answers.push("s2|trg-prime.spells");
  await auto.AUTOMATIONS["Wild Power"].use(wild1, wild1.items[0]);
  equal("G …so a cantrip row left empty at 1st is the one rolled next, not a second PP 2 (review)",
    wild1.items.filter((i) => i.flags?.["trg-eldritch-arts"]?.wildSpell).map((i) => [i.name, i.flags["trg-eldritch-arts"].wildSpell.pp]), [["Bolt", 2], ["Spark", 0]]);
  await auto.onDailyPreparationB3({ actor: sorc });
  const daily1 = sorc.items.filter((i) => i.flags?.["trg-eldritch-arts"]?.wildDaily).map((i) => i.name);
  await auto.onDailyPreparationB3({ actor: sorc });
  const daily2 = sorc.items.filter((i) => i.flags?.["trg-eldritch-arts"]?.wildDaily).map((i) => i.name);
  Math.random = random;
  equal("G the daily PP 1 specialist spell, a class's and not a hex, replacing yesterday's (Q24)", [daily1, daily2], [["Force Bolt"], ["Force Bolt"]]);
  // A roll already made (two at disadvantage in a Wild Magic area, the GM's pick).
  const { rollTable } = await import(new URL("../module/block2-automations.mjs", import.meta.url));
  const { WILD_SURGE } = await import(new URL("../module/chapter7-tables.mjs", import.meta.url));
  const before3 = cards.length;
  await rollTable(sorc, { table: WILD_SURGE, column: "e", title: "T", level: 3, expiry: null, source: "wildSurge", radiusFeet: 15, forcedTotal: 77 });
  ok("G the GM's chosen d100 is the one applied", cards.slice(before3).some((c) => /^d100 <strong>77<\/strong>/.test(String(c.lines?.[0] ?? ""))));
  // The surge (outside an area: the spell's PP as its level).
  const before = cards.length;
  d100s = [40];
  await auto.onSpellSettledB3({ actor: sorc, spellData: { ppCost: 4 }, natural: 13, rollsCheck: true });
  ok("G an unmodified 13 on a PP 4 spell rolls the Wild Surge table at level 4 (Q20)", cards.slice(before).some((c) => /Wild Surge — Wild Power \(level 4, the spell's PP\)/.test(c.title ?? "")));
  const before2 = cards.length;
  await auto.onSpellSettledB3({ actor: sorc, spellData: { ppCost: 1 }, natural: 13, rollsCheck: true });
  ok("G …and a PP 1 spell does not", cards.length === before2);
  // Dragon Claws.
  const dragon = makeActor({ name: "ZZ Dragon", level: 2, items: [{ ...B3.BIRTHRIGHTS.find((b) => b.name === "Dragon"), id: "dr" }, { ...B3.DRAGON_CLAWS, id: "dc" }] });
  answers.length = 0;
  answers.push("fire");
  await auto.AUTOMATIONS["Dragon Claws"].use(dragon, dragon.items[1]);
  const claw = dragon.items.find((i) => i.type === "weapon");
  equal("G Dragon Claws: the type asked once and kept; a 1d6 piercing natural weapon, agile and finesse, rolled with BSB",
    [auto.dragonTypeOf(dragon), claw?.system?.damage, claw?.system?.damageType, claw?.system?.traits, claw?.system?.natural, claw?.flags?.["trg-prime"]?.attackBase], ["fire", "1d6", "piercing", "Agile, Finesse", true, "bsb"]);
  await auto.AUTOMATIONS["Dragon Claws"].use(dragon, dragon.items[1]);
  equal("G …and Use again retracts them", dragon.items.filter((i) => i.type === "weapon").length, 0);
  // Gale Step: only a token that arrived pays and is carded (0.5.1).
  {
    let click = null;
    let veto = false;
    globalThis.window = { addEventListener() {}, removeEventListener() {} };
    globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
    canvas.stage = { on(ev, fn) { setTimeout(() => fn({ data: { getLocalPosition: () => click } }), 0); }, off() {} };
    const storm = makeActor({ name: "ZZ Storm", level: 1, items: [{ ...B3.GALE_STEP, id: "gs" }] });
    const t = { actor: storm, w: 100, h: 100, center: { x: 50, y: 50 }, document: { width: 1, _source: { x: 0, y: 0, width: 1, height: 1 }, async update(d) { if (!veto) Object.assign(this._source, { x: d.x, y: d.y }); } } };
    storm.getActiveTokens = () => [t];
    const galeCards = () => cards.filter((c) => c.title === "Gale Step").length;
    const n0 = galeCards();
    veto = true;
    click = { x: 250, y: 50 };
    await auto.AUTOMATIONS["Gale Step"].use(storm, storm.items[0]);
    equal("G Gale Step into a space the core refuses: no teleport, no card (so no Focus use spent), and it says so", [t.document._source.x, galeCards() - n0, cards.some((c) => /teleport was refused \(see the notice\), so nothing is spent/.test(c.warn ?? ""))], [0, 0, true]);
    veto = false;
    await auto.AUTOMATIONS["Gale Step"].use(storm, storm.items[0]);
    equal("G …into a free one: there, and carded", [t.document._source.x, galeCards() - n0], [200, 1]);
    click = { x: 650, y: 50 };
    await auto.AUTOMATIONS["Gale Step"].use(storm, storm.items[0]);
    ok("G …and over 15 ft is refused, measured from where the token stands", t.document._source.x === 200 && cards.some((c) => /that is 20 feet away/.test(c.warn ?? "")));
    delete canvas.stage;
  }
  // The shared measure (Block 1's): the source position, else the drawn centre.
  {
    const { feetBetween } = await import(new URL("../module/block1-automations.mjs", import.meta.url));
    const at = (x, drawn) => ({ center: { x: drawn + 50, y: 50 }, document: { width: 1, _source: { x, y: 0, width: 1, height: 1 } } });
    equal("G feetBetween reads where a token stands (V14 draws a moving token behind its source)", feetBetween(at(0, 0), at(600, 100)), 30);
    equal("G …and a token with no source its centre", feetBetween({ center: { x: 50, y: 50 }, document: { width: 1 } }, { center: { x: 250, y: 50 }, document: { width: 1 } }), 10);
  }
}

/* ----------------------------------------------------------------- */
/* H — the hooks and the versions                                       */
/* ----------------------------------------------------------------- */
ok("H the hooks: settled, daily preparation, actor updated and deleted, item created, token moved, canvas ready",
  ["onSpellSettledB3", "onDailyPreparationB3", "onActorUpdatedB3", "onActorDeletedB3", "onItemCreatedB3", "onTokenMovedB3", "refreshAllB3"].every((n) => scriptSrc.includes(`${n}(`)));
ok("H a familiar's death is asked on its effects and on the core's slain hook (0.5.1)",
  /for \(const hook of \["createActiveEffect", "updateActiveEffect"\]\)[\s\S]{0,200}onFamiliarMaybeDiedB3\(effectOwner\(effect\)\)/.test(scriptSrc) && /Hooks\.on\("trgPrimeCreatureSlain", \(ctx\) => \{ onFamiliarMaybeDiedB3\(ctx\?\.victim\)/.test(scriptSrc));
// 0.7.0 OR LATER, ON 3.682.0 OR LATER (Block 4 moved both; verify-block4 pins them).
const atLeast = (v, min) => { const a = String(v).split(".").map(Number), b = min.split(".").map(Number); for (let i = 0; i < 3; i += 1) { if ((a[i] ?? 0) !== b[i]) return (a[i] ?? 0) > b[i]; } return true; };
equal("H 0.6.1 or later, on TRG Prime 3.681.0 or later", [atLeast(manifest.version, "0.6.1"), atLeast(manifest.relationships.systems[0].compatibility.minimum, "3.681.0"), /REQUIRED_SYSTEM = "3\.(?:68[1-9]|69\d)\.\d+"/.test(scriptSrc)], [true, true, true]);
ok("H the classes pack is declared, extending classes", manifest.packs.some((p) => p.name === "ea-classes" && p.flags?.["trg-prime"]?.extends === "classes"));

console.log(`verify-block3: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
