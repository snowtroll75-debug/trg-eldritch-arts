/**
 * Writes tools/inventory/parts/06-grimoire.txt, 07-specialist.txt,
 * 08-items.txt and 09-relics.txt from the reading audit's feature lists
 * (tools/inventory/source/*.json — one object per feature, with the line
 * it starts on in ea.md) and the audit's defect index
 * (tools/inventory/source/defects.json), which supplies the blocker column:
 * every Critical or Major defect whose lines fall inside a feature's span.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(HERE, "source");
const read = (f) => JSON.parse(fs.readFileSync(path.join(SRC, f), "utf8"));
const defects = read("defects.json");
const just = JSON.parse(fs.readFileSync(path.join(HERE, "justifications.json"), "utf8"));
const clean = (s) => String(s ?? "").replace(/\|/g, "/").replace(/\s+/g, " ").trim();
const title = (s) => String(s).toLowerCase().replace(/(^|[\s(\-–/])([a-z’'])/g, (m, a, b) => a + b.toUpperCase());

const KIND = {
  spell: { prefix: "S", type: "Spell", pack: "ea-spells", model: "spell item: ppCost, traits, range/area/targets, defence, damage, duration, effects[], warps[]" },
  "specialist-spell": { prefix: "SS", type: "Specialist spell", pack: "ea-spells", model: "spell item (specialist, specialistClass) + grant" },
  rune: { prefix: "RU", type: "Rune", pack: "ea-runes", model: "rune gear item + registerRunes declaration" },
  armour: { prefix: "AR", type: "Specific armour", pack: "ea-specific-items", model: "armour item with runes/effects" },
  weapon: { prefix: "SW", type: "Specific weapon", pack: "ea-specific-items", model: "weapon item with runes/effects" },
  orb: { prefix: "OR", type: "Orb", pack: "ea-charged-items", model: "charged item kind orb (D12)" },
  rod: { prefix: "RD", type: "Rod", pack: "ea-charged-items", model: "charged item (rod)" },
  staff: { prefix: "ST", type: "Staff", pack: "ea-charged-items", model: "charged item (staff)" },
  wondrous: { prefix: "WO", type: "Wondrous", pack: "ea-wondrous", model: "wondrous item + registerItemAutomation" },
  relic: { prefix: "RL", type: "Relic", pack: "ea-relics", model: "relic item: tiers by wielder level, innate grants per tier, bond flag" },
  rule: { prefix: "RR", type: "Rule", pack: "ea-rules", model: "rule implemented in module code / journal" },
  table: { prefix: "TB", type: "Table", pack: "ea-rules", model: "table roller / journal" }
};

// One counter per prefix across all four parts, so ids stay unique
// (armour runes and weapon runes share RU-).
const counters = {};

function blockersFor(start, end) {
  return defects.filter((d) => /^EA-[CM]\d/.test(d.id) && d.lines.some((l) => l >= start && l < end)).map((d) => d.id);
}

function rows(files, heading, section, refLabel, filter = () => true) {
  const list = [].concat(...[files].flat().map(read)).filter(filter).sort((a, b) => a.line - b.line);
  const out = ["#", `## ${heading} — ${list.length}`];
  list.forEach((f, i) => {
    const k = KIND[f.kind] ?? KIND.rule;
    const end = Math.min(list[i + 1]?.line ?? Infinity, f.line + 120);
    counters[k.prefix] = (counters[k.prefix] ?? 0) + 1;
    const id = `${section}${k.prefix}-${String(counters[k.prefix]).padStart(3, "0")}`;
    const ritual = f.ritual || (f.traits ?? []).includes("RITUAL");
    const type = f.kind === "spell" && ritual ? "Spell — Ritual" : f.kind === "specialist-spell" && (f.traits ?? []).includes("HEX") ? "Specialist spell — Hex" : k.type;
    const prereq = [f.tradition && `Tradition: ${f.tradition}`, f.traits?.length && `[${f.traits.join(" ")}]`, f.requirements, f.level != null && `Level ${f.level}`, f.price && `Price ${f.price}`].filter(Boolean).join("; ");
    const stat = [f.pp != null && `PP ${f.pp}`, f.cast && `Cast ${f.cast}`, f.range && `Range ${f.range}`, f.area && `Area ${f.area}`, f.targets && `Targets ${f.targets}`, f.duration && `Duration ${f.duration}`, f.save && `Save ${f.save}`, f.attack && "Attack", f.damage && `Damage ${f.damage}`, f.activation && `Activate ${f.activation}`, f.frequency && `Frequency ${f.frequency}`].filter(Boolean).join("; ");
    const auto = String(f.automation ?? "B").trim().charAt(0).toUpperCase();
    if (!/[ABCD]/.test(auto)) throw new Error(`${f.name}: automation "${f.automation}"`);
    const why = String(f.automation ?? "").slice(1).replace(/^[\s—:-]+/, "").trim() || f.note || "";
    if ((auto === "C" || auto === "D") && !just[id]) just[id] = `${auto} — ${why || "see the audit entries for this feature"}`;
    const deps = clean((f.references ?? []).slice(0, 6).join(", "));
    const impl = f.kind === "rule" || f.kind === "table" ? "module rule code; journal entry" : `PACK:${k.pack} + ${f.kind === "spell" || f.kind === "specialist-spell" ? "spell effects/warps" : "item declarations/automation"}`;
    out.push([id, `${refLabel} L${f.line}`, title(f.name), type, clean(prereq), clean(`${stat}${stat ? ". " : ""}${f.mechanics ?? ""}`), deps, k.model, auto, impl, blockersFor(f.line, end).join(", ")].map(clean).join("|"));
  });
  return out;
}

const parts = [
  ["06-grimoire.txt", rows(["grimoire-a.json", "grimoire-b.json"], "GRIMOIRE (Ch8)", "", "Ch8 Grimoire")],
  ["07-specialist-armour.txt", rows("specialist-armour.json", "SPECIALIST SPELLS, HEXES AND ARMOUR (Ch8, Ch9)", "", "Ch8/9")],
  ["08-items.txt", rows("items.json", "CHARGED ITEMS, WEAPONS (Ch9)", "", "Ch9 Magic items")],
  ["09-relics.txt", rows("relics.json", "RELICS, SENTIENT ITEMS, APPENDIX (Ch9)", "", "Ch9 Relics")]
];
for (const [file, lines] of parts) fs.writeFileSync(path.join(HERE, "parts", file), lines.join("\n") + "\n");
fs.writeFileSync(path.join(HERE, "justifications.json"), JSON.stringify(just, null, 1) + "\n");
console.log(parts.map(([f, l]) => `${f}: ${l.filter((x) => /^[A-Z]/.test(x) && x.includes("|")).length}`).join("; "));
