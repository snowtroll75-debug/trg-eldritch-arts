/**
 * Builds docs/ELDRITCH_ARTS_IMPLEMENTATION_MATRIX.md and
 * docs/ELDRITCH_ARTS_AUTOMATION_REPORT.md from tools/inventory/inventory.txt
 * (and tools/inventory/status.json for delivery status).
 *
 * inventory.txt is the single source of truth: edit it, then re-run
 *   node tools/inventory/build-docs.mjs
 * Never hand-edit the generated documents.
 *
 * Row format (11 pipe-separated fields):
 *   id | ref | feature | type | prerequisites | mechanics | dependencies |
 *   data model | automation (A/B/C/D) | implementation | blocker
 * `ref` is "ChN <section> L<line>" — the line in the v1.4 markdown cut of the
 * book (tools/content/book-text.json carries the same line numbers). The
 * docx has no fixed pagination, so page numbers are not available.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..", "..");
const SRC = path.join(HERE, "inventory.txt");

const FIELDS = ["id", "ref", "feature", "type", "prereqs", "mechanics", "deps", "model", "auto", "impl", "blocker"];

export function parseInventory(text) {
  const rows = [];
  const sections = [];
  let section = "";
  for (const raw of text.split("\n")) {
    const lineText = raw.trimEnd();
    if (!lineText) continue;
    if (lineText.startsWith("## ")) { section = lineText.slice(3).trim(); sections.push(section); continue; }
    if (lineText.startsWith("#")) continue;
    const parts = lineText.split("|");
    if (parts.length !== FIELDS.length) throw new Error(`inventory: ${parts.length} fields, expected ${FIELDS.length}: ${lineText}`);
    const row = Object.fromEntries(FIELDS.map((k, i) => [k, parts[i].trim()]));
    row.section = section;
    if (!/^[ABCD]$/.test(row.auto)) throw new Error(`inventory: bad automation class "${row.auto}" on ${row.id}`);
    rows.push(row);
  }
  const ids = new Set();
  for (const r of rows) { if (ids.has(r.id)) throw new Error(`inventory: duplicate id ${r.id}`); ids.add(r.id); }
  return { rows, sections };
}

/** Test evidence each type of feature needs before it can be marked tested. */
const VALIDATION = [
  [/^Race$/, "Pack loads; racial AE totals on a level-1 actor; languages, lore and PP granted; Sourcebook = Eldritch Arts"],
  [/^Heritage$/, "Picker filtered by race; AE totals; granted spells/abilities resolve"],
  [/Racial ability/, "Granted with the race; effect totals or action driven"],
  [/^Background$/, "Bonus feat resolves (prerequisites waived); skill bonuses; specialist lore; wealth"],
  [/^Class$/, "Progression L1–L20 matches the printed table; HP/skills/proficiencies; grants at each level; casting style, ability and pick schedule"],
  [/Class feature|Birthright|Path|Bonded soul/, "Granted at the right level/choice; passive totals or activation spends and applies; removal on loss"],
  [/Skill action/, "Offered on its skill; DC and every degree's outcome; requirements gate"],
  [/feat$|Archetype/, "Picker eligibility (traits, prerequisites, archetype gate); passive totals or activation; usage limits; removal"],
  [/Metamagic/, "Offered in the Warp? dialog only for eligible spells; PP/DC/AP costs; the spell's numbers change; chat card records it"],
  [/Weapon|Material|Armour/, "Pack stats vs table; traits behave in a Strike; proficiency"],
  [/Gear|Catalyst|Consumable/, "Pack stats; bonus applies when used; consumption; backlash by degree"],
  [/^Spell|Specialist spell|Hex/, "Pack fields vs book; cast as granted; PP/DC/max-PP; target/area; save/attack; damage/heal; effect and duration; warps"],
  [/Rune|Orb|Rod|Staff|Wondrous|Relic|Specific/, "Pack stats; invest/equip applies and removes; activation spends charges/uses; effect applied; recharge"],
  [/Subsystem|Rule|Table|Trait|Language/, "Rule-level harness checks and a live scenario"]
];
const validationFor = (t) => (VALIDATION.find(([re]) => re.test(t))?.[1]) ?? "Live test";
const COVERAGE = { A: "Full", B: "Interactive", C: "Partial", D: "Manual" };

/** What each automation class drops to if the named core dependency is NOT taken. */
export const DEGRADE = {};
const RANK = { A: 0, B: 1, C: 2, D: 3 };
export function withoutCore(row) {
  let worst = row.auto;
  for (const d of row.blocker.match(/\bD\d+\b/g) ?? []) {
    const to = DEGRADE[d] ?? "C";
    if (RANK[to] > RANK[worst]) worst = to;
  }
  return worst;
}

export const STATUS = fs.existsSync(path.join(HERE, "status.json")) ? JSON.parse(fs.readFileSync(path.join(HERE, "status.json"), "utf8")) : {};
export const testedLive = (id) => Array.isArray(STATUS[id]?.live) && STATUS[id].live.length > 0;
const statusFor = (row) => {
  const s = STATUS[row.id];
  if (s) return (s.achieved ? `${s.status} (${s.achieved})` : s.status) + (testedLive(row.id) ? " · tested live" : "");
  return row.blocker.match(/EA-C\d+/) ? `Blocked (${row.blocker.match(/EA-C\d+/g).join(", ")})` : "Not started";
};
const esc = (s) => String(s).replace(/\|/g, "/");

function matrix({ rows, sections }) {
  const counts = { A: 0, B: 0, C: 0, D: 0 };
  rows.forEach((r) => counts[r.auto]++);
  const blocked = rows.filter((r) => /EA-C\d+/.test(r.blocker)).length;
  const out = [];
  out.push("# Eldritch Arts — Implementation Matrix");
  out.push("");
  out.push("_Generated from `tools/inventory/inventory.txt` by `tools/inventory/build-docs.mjs`. Do not edit by hand._");
  out.push("");
  out.push("**Source:** TRG_Prime_Eldritch_Arts_1_4.docx (v1.4). **Target system:** TRG Prime 3.674.2 plus the core dependencies in ELDRITCH_ARTS_CORE_DEPENDENCIES.md.");
  out.push("");
  out.push(`**${rows.length} features inventoried.** Target automation (with core dependencies): A ${counts.A} · B ${counts.B} · C ${counts.C} · D ${counts.D}. Blocked on a Critical audit entry: ${blocked}. Implemented: ${rows.filter((r) => STATUS[r.id]?.status === "Implemented").length}. Tested live: ${rows.filter((r) => testedLive(r.id)).length}.`);
  out.push("");
  out.push("Legend:");
  out.push("- **Ref:** chapter, section and line in the v1.4 markdown cut of the book (the docx has no fixed pages, so page numbers cannot be given).");
  out.push("- **Automation / Coverage:** A Full · B Interactive (automated with a normal player/GM choice) · C Partial (justified in the Automation Report) · D Manual or descriptive (justified).");
  out.push("- **Implementation keys:** PACK:<pack> compendium entry · AE transferred Active Effect · COND conditional bonus · AUTO registered feat/item automation · SA registered skill action · RX reaction/defence offer · WARP registered spell warp · MM module metamagic (core D2) · GATE spell-check gate · INNATE innate spell grant · CHOICE sub-pick · GRANT levelled grant · REGION scene region · CARD chat card only (class D).");
  out.push("- **Blocker:** an audit entry (EA-C… Critical / EA-M… Major) needing your ruling, or a core dependency (D…).");
  out.push("- **Status:** Not started · In progress · Implemented · Blocked; \"tested live\" only where a live-testing report records it.");
  out.push("");
  for (const section of sections) {
    const sr = rows.filter((r) => r.section === section);
    if (!sr.length) continue;
    out.push(`## ${section}`);
    out.push("");
    out.push("| ID | Ref | Name | Type | Prerequisites | Mechanics | Dependencies | Data model | Automation | Testing | Status | Coverage | Blocker |");
    out.push("|---|---|---|---|---|---|---|---|---|---|---|---|---|");
    for (const r of sr) {
      out.push(`| ${r.id} | ${esc(r.ref)} | ${esc(r.feature)} | ${esc(r.type)} | ${esc(r.prereqs) || "—"} | ${esc(r.mechanics)} | ${esc(r.deps) || "—"} | ${esc(r.model)} | ${r.auto}: ${esc(r.impl)} | ${esc(validationFor(r.type))} | ${statusFor(r)} | ${COVERAGE[r.auto]} | ${esc(r.blocker) || "—"} |`);
    }
    out.push("");
  }
  return out.join("\n");
}

/** Why each C/D feature cannot go higher. Keep in step with the inventory. */
export const JUSTIFICATIONS = JSON.parse(fs.readFileSync(path.join(HERE, "justifications.json"), "utf8"));

function report({ rows }) {
  const out = [];
  const counts = (key) => rows.reduce((acc, r) => { const k = key(r); acc[k] = (acc[k] ?? 0) + 1; return acc; }, {});
  const target = counts((r) => r.auto);
  const degraded = counts((r) => withoutCore(r));
  out.push("# Eldritch Arts — Automation Report");
  out.push("");
  out.push("_Generated from `tools/inventory/inventory.txt`, `justifications.json` and `status.json`. \"Target\" is the class each feature is planned at. A feature that only posts its text to chat is class D, never A._");
  out.push("");
  out.push("## Planned coverage");
  out.push("");
  out.push("| Class | With the core dependencies | Module only (no core changes) |");
  out.push("|---|---|---|");
  for (const k of ["A", "B", "C", "D"]) out.push(`| ${k} (${COVERAGE[k]}) | ${target[k] ?? 0} | ${degraded[k] ?? 0} |`);
  out.push(`| **Total** | ${rows.length} | ${rows.length} |`);
  out.push("");
  const bySection = {};
  for (const r of rows) { bySection[r.section] ??= { A: 0, B: 0, C: 0, D: 0 }; bySection[r.section][r.auto]++; }
  out.push("## By section");
  out.push("");
  out.push("| Section | A | B | C | D |");
  out.push("|---|---|---|---|---|");
  for (const [s, c] of Object.entries(bySection)) out.push(`| ${s} | ${c.A} | ${c.B} | ${c.C} | ${c.D} |`);
  out.push("");
  out.push("## Features below A/B, with the reason");
  out.push("");
  for (const r of rows.filter((x) => x.auto === "C" || x.auto === "D")) {
    const why = JUSTIFICATIONS[r.id];
    if (!why) throw new Error(`report: no justification for ${r.id} (${r.auto})`);
    out.push(`- **${r.id} ${r.feature}** (${r.auto}) — ${why}`);
  }
  out.push("");
  out.push("## Features whose class depends on a core change");
  out.push("");
  out.push("| ID | Feature | With core | Without | Dependency |");
  out.push("|---|---|---|---|---|");
  for (const r of rows) {
    const w = withoutCore(r);
    if (w !== r.auto) out.push(`| ${r.id} | ${esc(r.feature)} | ${r.auto} | ${w} | ${(r.blocker.match(/\bD\d+\b/g) ?? []).join(", ")} |`);
  }
  out.push("");
  out.push("## Features blocked on a ruling");
  out.push("");
  for (const r of rows.filter((x) => /EA-[CM]\d+/.test(x.blocker))) out.push(`- **${r.id} ${r.feature}** — ${r.blocker.match(/EA-[CM]\d+/g).join(", ")}`);
  out.push("");
  return out.join("\n");
}

if (process.argv[1] && process.argv[1].endsWith("build-docs.mjs")) {
  const inv = parseInventory(fs.readFileSync(SRC, "utf8"));
  const docs = path.join(ROOT, "docs");
  fs.mkdirSync(docs, { recursive: true });
  fs.writeFileSync(path.join(docs, "ELDRITCH_ARTS_IMPLEMENTATION_MATRIX.md"), matrix(inv) + "\n");
  fs.writeFileSync(path.join(docs, "ELDRITCH_ARTS_AUTOMATION_REPORT.md"), report(inv) + "\n");
  const c = inv.rows.reduce((a, r) => ((a[r.auto] = (a[r.auto] ?? 0) + 1), a), {});
  console.log(`build-docs: ${inv.rows.length} features in ${inv.sections.length} sections; A ${c.A ?? 0} B ${c.B ?? 0} C ${c.C ?? 0} D ${c.D ?? 0}`);
}
