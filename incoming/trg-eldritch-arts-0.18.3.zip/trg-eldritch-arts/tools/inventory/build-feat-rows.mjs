/**
 * Writes tools/inventory/parts/04-feats.txt from tools/content/book-text.json
 * (names, lines, traits, prerequisites — the book's own) and the four
 * feats-*.mjs maps (mechanics summary, model, automation, implementation,
 * dependencies, blocker). Fails if a feat in the book has no row, or a row
 * names a feat the book does not have.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import racial from "./feats-racial.mjs";
import archetype from "./feats-archetype.mjs";
import klass from "./feats-class.mjs";
import general from "./feats-general.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const book = JSON.parse(fs.readFileSync(path.join(HERE, "..", "content", "book-text.json"), "utf8"));
const title = (s) => s.toLowerCase().replace(/(^|[\s(\-–])([a-z’'])/g, (m, a, b) => a + b.toUpperCase()).replace(/’S\b/g, "’s");

const GROUPS = [
  ["racialFeats", racial, "FR", "RACIAL FEATS (Ch5)", "Racial feat", "Ch5 Racial"],
  ["archetypeFeats", archetype, "FA", "ARCHETYPE FEATS (Ch5)", "Archetype", "Ch5 Archetype"],
  ["classFeats", klass, "FC", "CLASS FEATS (Ch5)", "Class feat", "Ch5 Class"],
  ["generalFeats", general, "FG", "GENERAL FEATS (Ch5)", "General feat", "Ch5 General"]
];

const out = ["#"];
const problems = [];
for (const [key, map, prefix, heading, type, ref] of GROUPS) {
  const entries = book.sections[key];
  out.push(`## ${heading} — ${entries.length}`);
  const seen = new Set();
  entries.forEach((e, i) => {
    const row = map[e.name];
    seen.add(e.name);
    if (!row) { problems.push(`${key}: no inventory row for ${e.name}`); return; }
    const [mechanics, model, auto, impl, deps, blocker] = row;
    const traits = e.traits.length ? ` [${e.traits.join(" ")}]` : "";
    const prereq = [e.fields.Prerequisites, e.fields.Requirements && `Req: ${e.fields.Requirements}`].filter(Boolean).join("; ");
    const t = e.traits.includes("METAMAGIC") ? `${type} — Metamagic` : type;
    const pp = e.fields["PP Cost"] ? ` PP ${e.fields["PP Cost"]};` : "";
    const action = e.fields.Action ? ` ${e.fields.Action};` : "";
    const id = `${prefix}-${String(i + 1).padStart(2, "0")}`;
    out.push([id, `${ref} L${e.line}`, title(e.name) + traits, t, prereq, `${pp}${action} ${mechanics}`.trim(), deps, model, auto, impl, blocker].map((s) => String(s ?? "").replace(/\|/g, "/")).join("|"));
  });
  for (const name of Object.keys(map)) if (!seen.has(name)) problems.push(`${key}: row for ${name} has no book entry`);
}
const exist = book.sections.existingRacialFeats;
out.push("#", "## EXISTING CORE RACIAL FEATS OPENED (Ch5)");
let n = 1;
for (const [race, feats] of Object.entries(exist)) {
  out.push([`FX-${String(n++).padStart(2, "0")}`, "Ch5 Existing feats L2872", `${feats.join(", ")} (opened to ${title(race)})`, "Feat access", "", "Core racial feats become available to the race", "registerFeatAccess", "feat access", "A", "registerFeatAccess(race)", ""].join("|"));
}
const CLASS_EXISTING = { Archmage: ["Familiar", "Versatile Familiar"], Spellblade: ["Assess Target", "Combat Awareness", "Disrupting Stance"], "Warlock and Witch": ["Familiar", "Injury Relief", "Versatile Familiar"] };
for (const [klass, feats] of Object.entries(CLASS_EXISTING)) {
  out.push([`FX-${String(n++).padStart(2, "0")}`, "Ch5 sidebar after L4322", `${feats.join(", ")} (opened to ${klass})`, "Feat access", "", "Core class feats become available to the class", "registerFeatAccess", "feat access", "A", "registerFeatAccess(class)", ""].join("|"));
}
if (problems.length) { console.error(problems.join("\n")); process.exit(1); }
fs.writeFileSync(path.join(HERE, "parts", "04-feats.txt"), out.join("\n") + "\n");
console.log(`feat rows: ${out.filter((l) => /^F[RACGX]-/.test(l)).length}`);
