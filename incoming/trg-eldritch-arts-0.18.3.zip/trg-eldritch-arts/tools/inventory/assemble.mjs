// Concatenate tools/inventory/parts/*.txt (in name order) into inventory.txt.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const dir = path.join(HERE, "parts");
const parts = fs.readdirSync(dir).filter((f) => f.endsWith(".txt")).sort();
fs.writeFileSync(path.join(HERE, "inventory.txt"), parts.map((f) => fs.readFileSync(path.join(dir, f), "utf8").trimEnd()).join("\n") + "\n");
console.log(`assemble: ${parts.length} parts → inventory.txt`);
