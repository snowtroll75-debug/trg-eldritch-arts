/**
 * Writes tools/inventory/parts/05-gear-items.txt: one row per special
 * material, exotic weapon, good/tool and catalyst, from book-text.json
 * (the book's own tables). Automation per kind; per-item overrides below.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const S = JSON.parse(fs.readFileSync(path.join(HERE, "..", "content", "book-text.json"), "utf8")).sections;
const title = (s) => s.toLowerCase().replace(/(^|[\s(\-–])([a-z’'])/g, (m, a, b) => a + b.toUpperCase());
const clean = (s) => String(s).replace(/\|/g, "/").replace(/\s+/g, " ").trim();
const out = ["#", "## SPECIAL MATERIALS (Ch6) — 10"];
S.materials.forEach((e, i) => out.push([`MAT-${String(i + 1).padStart(2, "0")}`, `Ch6 Special materials L${e.line}`, title(e.name), "Material", `Rarity: ${title(e.traits.join(" "))}`, clean(e.lines.filter((l) => l.startsWith("-")).map((l) => l.replace(/^-\s*/, "")).join("; ")), "core item quality (MATERIALS)", "material registry entry", "A", "registerMaterial; material chosen when crafting/buying", "D18"].join("|")));
const OVR = {
  "Gilded Censer Chains": ["B", "ritual/censer radius flag", "", "EA-m65"],
  "Ritual Censer": ["A", "ritual modifier when used with 5 gp incense", "D13", "EA-m66"],
  "Runestone Chalkboard": ["A", "ritual modifier (one per ritual)", "D13", ""],
  "Bloodscribe’s Bowl": ["B", "ritual modifier when blood is offered (ticked)", "D13", ""],
  "Bone Dice of Fate": ["B", "daily use: advantage tickbox", "", ""],
  "Camel Pouch": ["A", "draw cost override for the stored item", "", ""],
  "Crystal Phials": ["D", "protection of contents is narrative", "", ""],
  "Etheric Ink": ["D", "forgery modifier is narrative", "", ""],
  "Leyline Satchel": ["D", "protection of contents is narrative", "", ""],
  "Void Chalk": ["B", "circle duration flag", "", ""],
  "Umbral Lantern": ["C", "registerLightSources; illusion/invisibility reveal as a card", "", ""],
  "Ward-Twine": ["A", "circle DC modifier", "", "EA-m68"],
  "Warding Spikes": ["B", "region aura vs summoned/extraplanar", "", ""],
  "Leybraid Rope": ["B", "COND advantage on Climb (scope ticked)", "", "EA-m67"]
};
out.push("#", "## EXOTIC WEAPONS (Ch6) — 18");
const head = S.meleeWeapons.rows[1].cells;
let w = 1;
for (const [tbl, kind] of [[S.meleeWeapons, "melee"], [S.rangedWeapons, "ranged"]]) {
  for (const r of tbl.rows.slice(2)) {
    const c = Object.fromEntries(head.map((h, i) => [h, r.cells[i]]));
    out.push([`WPN-${String(w++).padStart(2, "0")}`, `Ch6 Weapons L${r.line}`, c.Weapon, "Weapon", "", clean(`${kind}; ${c.Price}; level ${c.Level}; ${c.Damage}; size ${c.Size}; FDC ${c.FDC}; ${c.Weight}; ${c.Group}; ${c.Traits}`), "weapons pack; traits", "weapon item", "A", "PACK:ea-weapons", /Claidheamh Dubh/.test(c.Weapon) ? "EA-m62" : /Bogha/.test(c.Weapon) ? "EA-m63" : /Emberkin|Wyrmdral|Scaelyn|Aetherial|Nyrrin/.test(c.Traits) ? "EA-m64" : ""].join("|"));
  }
}
out.push("#", "## GOODS & TOOLS (Ch6) — 31");
const gh = S.goods.rows[1].cells;
S.goods.rows.slice(2).forEach((r, i) => {
  const c = Object.fromEntries(gh.map((h, k) => [h, r.cells[k]]));
  const o = OVR[c.Name] ?? ["B", "COND item bonus, ticked when the situation applies", "", ""];
  out.push([`GD-${String(i + 1).padStart(2, "0")}`, `Ch6 Goods & Tools L${r.line}`, c.Name, "Gear", "", clean(`${c.Cost}; size ${c.Size}; level ${c.Level}; ${c.Weight}; ${c.Effect}`), "gear pack", "gear item + conditionals", o[0], `PACK:ea-gear + ${o[1]}`, [o[2], o[3]].filter(Boolean).join(", ")].join("|"));
});
out.push("#", "## CATALYSTS (Ch6) — 24");
const ch = S.catalysts.rows[1].cells;
S.catalysts.rows.slice(2).forEach((r, i) => {
  const c = Object.fromEntries(ch.map((h, k) => [h, r.cells[k]]));
  const e = S.catalystEntries[i];
  const blk = /Dragonbone/.test(c.Catalyst) ? "D3, EA-M10" : /Frozen|Stormglass/.test(c.Catalyst) ? "D3, EA-m69" : /Ashen|Void Ash/.test(c.Catalyst) ? "D3, EA-R3" : "D3";
  out.push([`CAT-${String(i + 1).padStart(2, "0")}`, `Ch6 Catalysts L${e.line}`, c.Catalyst, "Catalyst", `Rarity: ${title(e.traits.join(" "))}`, clean(`${c.Cost}; level ${c.Level}; Effect: ${c.Effect}; Backlash: ${c.Backlash}`), "catalyst engine (GEAR-09)", "consumable + catalyst flags", "A", "PACK:ea-consumables + catalyst declaration", blk].join("|"));
});
fs.writeFileSync(path.join(HERE, "parts", "05-gear-items.txt"), out.join("\n") + "\n");
console.log("gear rows:", out.filter((l) => /^[A-Z]+-\d/.test(l)).length);
