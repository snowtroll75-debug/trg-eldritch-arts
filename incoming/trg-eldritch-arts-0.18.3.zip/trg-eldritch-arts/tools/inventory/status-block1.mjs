#!/usr/bin/env node
/**
 * Block 1's delivery status, written into tools/inventory/status.json (which
 * build-docs.mjs reads for the matrix). Each row says what 0.1.0 achieved,
 * not what is planned; "tested live" is added only from a live-testing
 * report.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { GOODS_AUTOMATION } from "../content/block1.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FILE = path.join(HERE, "status.json");
const status = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : {};
const set = (id, s, achieved, note = "") => { status[id] = { status: s, achieved, note, ...(status[id]?.live ? { live: status[id].live } : {}) }; };
const done = (id, achieved, note = "") => set(id, "Implemented", achieved, note);

for (const id of ["R-01", "R-02", "R-03", "R-04"]) done(id, "A");
done("R-05", "A", "Elemental Language as the heritage's tongue (B1-1)");
done("RA-01", "A"); done("RA-02", "A"); done("RA-03", "A"); done("RA-04", "A", "TRG Prime 3.675.0 C1");
done("RA-05", "B", "no trigger printed (B1-10)"); done("RA-06", "A");
done("RA-07", "B", "energy pool as proposed (B1-8)");
done("RA-08", "C", "the beneficial-spell save is a GM reminder (EA-C1)");
done("RA-09", "A");
set("RA-10", "In progress", "D", "text only until the Ley Bond (Block 3) and High Magic (Block 2)");
done("RA-11", "B"); done("RA-12", "A", "the core's abilities");
for (let i = 1; i <= 18; i++) done(`H-${String(i).padStart(2, "0")}`, ["H-11", "H-14", "H-15", "H-18"].includes(`H-${String(i).padStart(2, "0")}`) ? "B" : "A");
status["H-12"].note = "TRG Prime 3.675.0 C3 (B1-6)";
for (let i = 1; i <= 12; i++) done(`BG-${String(i).padStart(2, "0")}`, i === 4 ? "B" : "A", i === 10 ? "wealth 0 until ruled (B1-14)" : "");
for (const id of ["FX-01", "FX-02", "FX-03", "FX-04"]) done(id, "A");
done("FG-09", "A"); done("FG-10", "B"); done("FG-11", "B", "TRG Prime 3.675.0 C4"); done("FG-15", "A", "TRG Prime 3.675.0 C5");
set("FG-28", "In progress", "D", "the ritual seats arrive with Block 2");
done("FG-34", "A", "TRG Prime 3.675.0 C2");
set("FG-35", "In progress", "D", "the surge arrives with High Magic (Block 2)");
done("FG-39", "D"); done("FG-41", "B");
done("S-055", "A", "TRG Prime 3.675.0 C9");
done("SA-01", "C", "what is sensed is the GM's until ley lines (Block 2); the Focus trait spends no use (B1-17)");
done("SA-04", "C", "the result is the GM's to tell");
done("SA-06", "B", "two actions, Implant Suggestion and Memory Recall");
done("SA-07", "A", "TRG Prime 3.675.0 C6; High Magic's all-four rule with Block 2");
done("SA-08", "D", "the weekly limit is kept");
done("SA-09", "A");
const BRACE = ["WPN-09", "WPN-14", "WPN-18"], RITUALIST = ["WPN-01", "WPN-02", "WPN-03"];
for (let i = 1; i <= 18; i++) {
  const id = `WPN-${String(i).padStart(2, "0")}`;
  done(id, "A", [BRACE.includes(id) ? "Brace held back (B1-12)" : "", RITUALIST.includes(id) ? "Ritualist's ritual DC with Block 2" : ""].filter(Boolean).join("; "));
}
Object.keys(GOODS_AUTOMATION).forEach((name, i) => {
  const id = `GD-${String(i + 1).padStart(2, "0")}`;
  const g = GOODS_AUTOMATION[name];
  if (g.rows.length) done(id, "B", "offered as a tick while carried");
  else if (/Not yet automated/.test(g.note)) set(id, "In progress", "D", "Block 2's rituals, circles or zones");
  else done(id, "D");
});
fs.writeFileSync(FILE, `${JSON.stringify(status, null, 2)}\n`);
console.log(`status-block1: ${Object.keys(status).length} rows in status.json`);
