import sys, numpy as np
from PIL import Image
import colorsys
src, dst = sys.argv[1], sys.argv[2]
im = Image.open(src).convert("RGBA"); a = np.asarray(im).astype(np.float32)/255.0
rgb, alpha = a[..., :3], a[..., 3:]
# vectorised RGB->HSV
mx = rgb.max(-1); mn = rgb.min(-1); d = mx - mn
h = np.zeros_like(mx)
mask = d > 1e-6
r,g,b = rgb[...,0], rgb[...,1], rgb[...,2]
idx = mask & (mx == r); h[idx] = ((g-b)[idx]/d[idx]) % 6
idx = mask & (mx == g); h[idx] = ((b-r)[idx]/d[idx]) + 2
idx = mask & (mx == b); h[idx] = ((r-g)[idx]/d[idx]) + 4
h = h/6.0
s = np.where(mx > 1e-6, d/np.maximum(mx,1e-6), 0); v = mx
# EA arcane purple (#7a4fb0 hue ~ 0.74): warm golds/bronzes -> violet; keep greys/whites (pages, blade) near neutral
target = 0.745
warm = (h < 0.17) | (h > 0.92)
newh = np.where(warm & (s > 0.12), target + (h - 0.09)*0.35, h)
news = np.where(warm & (s > 0.12), np.clip(s*0.62, 0, 1), s*0.5)
# vectorised HSV->RGB
hh = (newh % 1.0)*6; i = np.floor(hh).astype(int) % 6; f = hh - np.floor(hh)
p = v*(1-news); q = v*(1-news*f); t = v*(1-news*(1-f))
out = np.zeros_like(rgb)
for k,(R,G,B) in enumerate([(v,t,p),(q,v,p),(p,v,t),(p,q,v),(t,p,v),(v,p,q)]):
    m = i == k; out[...,0][m]=R[m]; out[...,1][m]=G[m]; out[...,2][m]=B[m]
res = np.concatenate([out, alpha], -1)
Image.fromarray((np.clip(res,0,1)*255).astype(np.uint8), "RGBA").save(dst, optimize=True)
