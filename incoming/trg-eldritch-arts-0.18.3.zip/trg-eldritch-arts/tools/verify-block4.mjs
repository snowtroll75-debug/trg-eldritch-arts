#!/usr/bin/env node
/**
 * verify-block4 — Eldritch Arts 0.7.0 (Block 4, on TRG Prime 3.682.0): the
 * Spellblade and its four paths, the Warlock and its eight bonded souls,
 * Xithra, and the Spellblade's five specialist spells.
 *
 *   A  the classes against the book: fields, the tables row by row, the class
 *      magic they declare (the L+1 budget, the innate grant, High Magic)
 *   B  the paths and the souls: abilities, traditions, skills, special
 *      abilities, path spells, the souls' types, traditions, traits, riders
 *   C  the spells: as printed, specialist, their warps' mods, Xithra
 *   D  the rules, run: budgets, dice, feet, picks, copies, the cone, riders
 *   E  registration
 *   F  the core, run with the content: the memorisation budget, the innate
 *      level bonus, the edges, the rider, the conditionals, the warps, the
 *      damage choice, an innate Focus copy, Natural Resilience's halving and HP
 *   G  the Foundry side with fakes: Infuse Weapon, the soul's picks, Xithra's
 *      sync and rider, Arcane Echo, Sacred Channel, Spinning Weapon, Shielding
 *      Strike, the trail's end
 *   H  the hooks and the versions
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

/* Fakes. */
const cards = [];
const answers = [];
const confirms = [];
let rollDegree = { key: "success", success: true };
const strikes = [];
const casts = [];
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => (answers.length ? answers.shift() : null),
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => (/\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null),
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  rollCheck: async (config) => { helpers.lastCheck = config; return { outcome: { degree: rollDegree } }; },
  learnSpellTerms: async (pp) => ({ gp: 100 * pp, dc: 15 + pp, hours: pp }),
  // The core's own table (magic/learn-spell.mjs), as the helper hands it over.
  learnSpellOutcome: async (degree) => (await import(sys("module", "magic", "learn-spell.mjs"))).learnSpellOutcome(degree),
  goldOf: async (actor) => Number(actor.gp ?? 0),
  deductGold: async (actor, gp) => { actor.gp = (actor.gp ?? 0) - gp; return { paid: actor.gp >= 0, shortfallGP: Math.max(0, -actor.gp) }; },
  runesFor: async () => [{ key: "flaming", name: "Flaming", parameter: null, spell: false, tiers: [{ tier: "I", numeral: 1, level: 3 }, { tier: "II", numeral: 2, level: 8 }] }, { key: "keen", name: "Keen", parameter: null, spell: false, tiers: [{ tier: "I", numeral: 1, level: 2 }] }],
  runesToField: async (kind, sel) => sel.map((s) => `${s.key} ${s.tier}`).join(", "),
  healActor: async (actor, amount) => { actor.healed = (actor.healed ?? 0) + amount; return amount; },
  addRecurringDamage: async (target, amount, type) => { target.recurring = { amount, type }; return { value: amount, damageType: type }; },
  rollWeaponAttack: async (actor, weapon, options) => { strikes.push({ actor: actor.name, weapon: weapon.name, options }); for (const fn of hookFns.trgPrimeStrikeResolved ?? []) fn({ attacker: actor, weapon, hits: strikeHits, resolved: true, target: strikeTarget, melee: true }); return { dice: { unmodified: 12 }, modifiers: [], outcome: { total: 20 } }; },
  castSpell: async (actor, spell, options) => { casts.push({ actor: actor.name, spell: spell.name, options, targets: [...(globalThis.game.user.targets ?? [])].map((t) => t.id) }); return "cast"; },
  castRefusal: async () => ""
};
let strikeHits = true, strikeTarget = null;
const hookFns = {};
let hookId = 0;
globalThis.Hooks = { on: (name, fn) => { (hookFns[name] ??= []).push(fn); fn.__id = ++hookId; return hookId; }, off: (name, id) => { hookFns[name] = (hookFns[name] ?? []).filter((f) => f.__id !== id); }, callAll() {}, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => (confirms.length ? confirms.shift() : true) } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => "r1" } };
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { const m = /^(\d+)d(\d+)$/.exec(this.f); this.total = m ? Number(m[1]) * 4 : 4; return this; } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.toObject = () => JSON.parse(JSON.stringify({ ...it, parent: undefined }));
  it.delete = async () => { parent.items = parent.items.filter((x) => x !== it); };
  return it;
}
function makeActor(name, { level = 1, items = [], pp = 5, ap = 6 } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [] };
  a.system = { identity: { level }, resources: { pp: { value: pp }, ap: { value: ap } }, combat: { movement: { land: { total: 30 } } }, progression: {} };
  a.items = items.map((d) => makeItem(d, a));
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = list.map((d) => ({ ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, getFlag(s, k) { return this.flags?.[s]?.[k]; }, delete: async () => { a.effects = a.effects.filter((x) => x.id !== made[0].id); } }));
    a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => { a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.getActiveTokens = () => [];
  return a;
}

globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.682.0" }
};
globalThis.canvas = { tokens: { placeables: [] } };

const C = await import(new URL("./content/block4.mjs", import.meta.url));
const SP = await import(new URL("./content/block4-spells.mjs", import.meta.url));
const auto = await import(new URL("../module/block4-automations.mjs", import.meta.url));
const reg = await import(new URL("../module/registration.mjs", import.meta.url));
const manifest = JSON.parse(read("module.json"));
const scriptSrc = read("scripts", "eldritch-arts.mjs");

/* ----------------------------------------------------------------- */
/* A — the classes                                                      */
/* ----------------------------------------------------------------- */
const tableOf = (cls) => book.classes[cls].sections.flatMap((s) => s.tables).find((t) => /TABLE$/.test(t.rows[0]?.cells?.[0] ?? ""));
{
  const S = C.SPELLBLADE, W = C.WARLOCK;
  equal("A the Spellblade: Martial, HP 10, SP 4, Transcend Armour, its three abilities", [S.system.classType, S.system.hitPoints, S.system.skillPoints, S.system.grantedFeats, S.system.classAbilities], ["Martial", 10, 4, "1: Transcend Armour", "1: Infuse Weapon, 1: Battle Mage, 1: Spellblade Path"]);
  equal("A …a semi-learned book: four first picks, one a level, memorise level + 1, its tradition the path's", [S.system.casterStyle, S.system.memorisationStyle, S.system.spellBookFirstPicks, S.flags["trg-prime"].classMagic, S.system.magicalTradition, S.system.magicalAbility, S.system.cantripsKnown], ["learned", "book", 4, { bookPerLevel: 1, memorisedPerDay: "L+1" }, "", "", 0]);
  equal("A …its printed lines", [S.system.keyAbilityScores, S.system.classSkills, S.system.proficiencies], ["Tradition (min +2), Dexterity, Strength", "Acrobatics, Athletics, Climbing, Culture, Mental Focus, Meditation, Planes", "You are proficient in the use of light armour. You may use all simple and martial weapons."]);
  const st = tableOf("spellblade").rows.slice(2);
  equal("A the Spellblade's table, row by row (BAB/BDB, saves, feats, CL, PP, BSB)", S.system.progression.map((r) => [r.bab, r.bdb, r.fortitude, r.reflex, r.will, r.bonusFeats, r.casterLevel, r.pp, r.bsb]), st.map((r) => [1, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => Number(r.cells[i]))));
  equal("A …which is CL ⌈L/2⌉, PP L, BSB ⌊L/2⌋, Fort and Will 5 + L, Ref 2 + L", S.system.progression.map((r) => [r.casterLevel, r.pp, r.bsb, r.fortitude, r.reflex, r.will]), S.system.progression.map((r) => [Math.ceil(r.level / 2), r.level, Math.floor(r.level / 2), 5 + r.level, 2 + r.level, 5 + r.level]));
  equal("A the Warlock: Adept, Expert, HP 8, SP 6, Xithra granted innate, its abilities", [W.system.classType, W.system.hitPoints, W.system.skillPoints, W.system.grantedSpells, W.flags["trg-prime"].grantInnate, W.system.classAbilities], ["Adept, Expert", 8, 6, "1: Xithra", true, "1: Bonded Soul, 1: Hexes"]);
  equal("A …no casting style, Charisma, every cast High Magic", [W.system.casterStyle, W.system.magicalAbility, W.flags["trg-prime"].highMagicCaster], ["", "charisma", true]);
  const wt = tableOf("warlock").rows.slice(2);
  equal("A the Warlock's table, row by row; no CL, PP or BSB", W.system.progression.map((r) => [r.bab, r.bdb, r.fortitude, r.reflex, r.will, r.bonusFeats, r.casterLevel, r.pp, r.bsb]), wt.map((r) => [...[1, 2, 3, 4, 5, 6].map((i) => Number(r.cells[i])), 0, 0, 0]));
  equal("A …BAB ⌊3L/4⌋, every save 2 + L, a feat at 3rd and every 3", W.system.progression.map((r) => [r.bab, r.fortitude, r.reflex, r.will, r.bonusFeats]), W.system.progression.map((r) => [Math.floor(3 * r.level / 4), 2 + r.level, 2 + r.level, 2 + r.level, Math.floor(r.level / 3)]));
  equal("A class wealth (Chapter 6): Spellblade 2, Warlock 1", [S.system.wealth, W.system.wealth], ["2", "1"]);
}

/* ----------------------------------------------------------------- */
/* B — the paths and the souls                                          */
/* ----------------------------------------------------------------- */
{
  equal("B the path chooser offers the four", C.SPELLBLADE_PATH.flags["trg-prime"].abilityChoices, ["Path of the Arcane Duellist", "Path of the Divine Arm", "Path of the Ethereal Strider", "Path of the Verdant Warden"]);
  equal("B each path: ability, tradition, skills, special, spell", C.SPELLBLADE_PATHS.map((p) => [p.name, p.flags["trg-prime"].classMagic.ability, p.flags["trg-prime"].classMagic.tradition, p.flags["trg-prime"].classSkills, p.system.grantedAbilities, p.system.grantedSpells]), [
    ["Path of the Arcane Duellist", "intelligence", "arcane", ["Arcana", "Linguistics"], "Arcane Echo", "1: Shooting Star"],
    ["Path of the Divine Arm", "wisdom", "divinity", ["Religion", "Sense Motive"], "Sacred Channel", "1: Shielding Strike"],
    ["Path of the Ethereal Strider", "charisma", "ethereal", ["Occultism", "Stealth"], "Dimensional Step", "1: Dimensional Assault"],
    ["Path of the Verdant Warden", "constitution", "verdant", ["Nature", "Survival"], "Natural Resilience", "1: Thunderous Strike"]]);
  equal("B the specials' printed traits (Focus each, but Natural Resilience)", [C.ARCANE_ECHO, C.SACRED_CHANNEL, C.DIMENSIONAL_STEP, C.NATURAL_RESILIENCE].map((a) => a.system.traits), ["Focus, Invocation", "Focus, Healing, Soul", "Focus, Teleportation, Translocation", ""]);
  equal("B Natural Resilience resists poison and disease (Q43)", C.NATURAL_RESILIENCE.effects[0].changes, [{ key: "system.combat.resistances", mode: 2, value: ", poison, disease", priority: 20 }]);
  equal("B Battle Mage declares the spell attack base", C.BATTLE_MAGE.flags["trg-prime"].spellAttackBase, "bab");
  equal("B the soul chooser offers the eight", C.BONDED_SOUL.flags["trg-prime"].abilityChoices, auto.SOUL_NAMES);
  equal("B the souls: skills, Xithra's type, traditions, +1 traits, rider", C.BONDED_SOULS.map((s) => { const b = s.flags["trg-prime"].eaBondedSoul; return [s.name, s.flags["trg-prime"].classSkills, b.damageType, b.traditions, b.levelTraits, b.rider?.spell ?? b.rider?.kind ?? null, b.rider?.onHit ?? null]; }), [
    ["The Celestial Sentinel", ["Medicine", "Religion"], "aligned", ["arcane", "divinity"], ["aligned", "healing"], "Cure", false],
    ["The Crystal Archon", ["Diplomacy", "Religion"], "essence", ["arcane", "divinity"], ["light", "warding"], "Blindness", true],
    ["The Emberlord", ["Arcana", "Intimidate"], "fire", ["arcane", "divinity"], ["fire", "healing"], "recurring", true],
    ["The Infernal Tempter", ["Deception", "Occultism"], "fire", ["arcane", "ethereal"], ["emotion", "fire"], "Idiocy", true],
    ["The Pale Reaper", ["Intimidate", "Religion"], "essence", ["divinity", "ethereal"], ["fear", "soul"], "Fear", true],
    ["The Verdant Spirit Walker", ["Nature", "Survival"], "poison", ["ethereal", "verdant"], ["animal", "plant"], "Slow", true],
    ["The Void Seer", ["Occultism", "Sense Motive"], "force", ["arcane", "ethereal"], ["insight"], null, null],
    ["The Whispered Sage", ["Occultism", "Stealth"], "cold", ["arcane", "ethereal"], ["shadow"], "Misty Step", false]]);
  const printedTypes = C.SOULS.map((s) => s.printedType ?? s.damageType);
  ok("B …each type as its special prints it", C.BONDED_SOULS.every((s, i) => s.system.description.includes(`inflict ${printedTypes[i]} damage instead of mental`)));
  equal("B the automation's lists are the content's", [auto.PATH_NAMES, auto.SOUL_NAMES], [C.PATH_NAMES, C.SOUL_NAMES]);
  equal("B sidebar 16, as printed and as registered", C.EXISTING_CLASS_FEATS, JSON.parse(JSON.stringify(auto.EXISTING_CLASS_FEATS)));
}

/* ----------------------------------------------------------------- */
/* C — the spells                                                       */
/* ----------------------------------------------------------------- */
{
  const by = Object.fromEntries(SP.BLOCK4_SPECIALIST.map((s) => [s.flags["trg-prime"].eaSpellbladeSpell, s]));
  equal("C the five: names, PP 1, AP as printed, Spellblade specialist", SP.BLOCK4_SPECIALIST.map((s) => [s.name, s.system.ppCost, s.system.castAP, s.system.specialist, s.system.specialistClass]), [
    ["Shooting Star", 1, 2, true, "Spellblade"], ["Shielding Strike", 1, 2, true, "Spellblade"], ["Dimensional Assault", 1, 2, true, "Spellblade"], ["Thunderous Strike", 1, 2, true, "Spellblade"], ["Spinning Weapon", 1, 1, true, "Spellblade"]]);
  equal("C their warps' mods: Shielding +1 DB (max 5), Dimensional +5 Spatial, Thunder +1d6, Spinning +1d6 and force/sonic",
    [by.shieldingStrike.system.warps.map((w) => w.mods), by.dimensionalAssault.system.warps.map((w) => w.mods), by.thunderousStrike.system.warps.map((w) => w.mods), by.spinningWeapon.system.warps.map((w) => [w.ppCost, w.mods])],
    [[{ bonusValue: 1, bonusMax: 5 }], [{ unlocks: ["eaSpatialAwareness5"] }], [{ damageDice: "1d6" }], [[2, { damageDice: "1d6" }], [2, { unlocks: ["eaForceSonic"] }]]]);
  equal("C Thunderous Strike's cone: basic Fortitude against 1d6 sonic, its targets named so none is asked", [by.thunderousStrike.system.category, by.thunderousStrike.system.defence, by.thunderousStrike.system.damage.formula, by.thunderousStrike.system.damage.type, by.thunderousStrike.system.targets], ["save", "basic Fortitude", "1d6", "sonic", "each creature in a 15-foot cone behind the target"]);
  equal("C …its range ungated, as none is printed (live test: blank read as self)", by.thunderousStrike.system.range, "see text");
  equal("C the other Strike spells' ranges ungated too (live test: blank read as self); Dimensional Assault keeps its square's", ["shootingStar", "shieldingStrike", "spinningWeapon"].map((k) => by[k].system.range), ["see text", "see text", "see text"]);
  ok("C each prints the book's lines", SP.BLOCK4_SPECIALIST.every((s) => { const e = book.specialist.find((x) => x.name.toLowerCase() === s.name.toLowerCase()); return e && e.lines.filter((l) => !/^\*\*\+|^WARPING/.test(l)).every((l) => s.system.description.includes(l.slice(0, 40).replace(/’/g, "’"))); }));
  const X = SP.XITHRA;
  equal("C Xithra: innate, 0 PP, 1 AP, 30 ft, an attack, 1d6 + Charisma mental, +1d6 every 4", [X.system.innate, X.system.ppCost, X.system.castAP, X.system.range, X.system.category, X.system.damage.formula, X.system.damage.type, X.system.damage.addAbility, X.system.casterLevelMods[0].threshold, X.system.casterLevelMods[0].recurring, X.system.casterLevelMods[0].damageDice], [true, 0, 1, "30 feet", "attack", "1d6", "mental", "charisma", 4, true, "1d6"]);
  equal("C …its printed traits, Focus among them; cast with Charisma", [X.system.traits, X.flags["trg-prime"].castingAbilityOverride, X.flags["trg-prime"].eaXithra], ["Attack, Focus, Magical, Mental", "charisma", true]);
}

/* ----------------------------------------------------------------- */
/* D — the rules, run                                                   */
/* ----------------------------------------------------------------- */
{
  equal("D Infuse Weapon's rune budget: none at 1st, the level from 2nd", [1, 2, 9].map(auto.infusionBudget), [0, 2, 9]);
  equal("D a selection's levels", auto.runeLevels([{ level: 3 }, { level: 2 }, {}]), 5);
  equal("D Sacred Channel: 1d8, +1d8 at 5th and every 5", [1, 4, 5, 10, 20].map(auto.sacredChannelDice), ["1d8", "1d8", "2d8", "3d8", "5d8"]);
  equal("D Dimensional Step: 10 ft per 2 levels, at least 10 (Q51)", [1, 2, 3, 4, 9, 20].map(auto.dimensionalStepFeet), [10, 10, 10, 20, 40, 100]);
  equal("D half a land speed, in squares", [30, 25, 0].map(auto.halfSpeedFeet), [15, 10, 0]);
  equal("D Shielding Strike: +2, +1 a warp, max +5", [{}, { bonusValue: 1 }, { bonusValue: 3 }, { bonusValue: 9 }].map(auto.shieldingBonus), [2, 3, 5, 5]);
  equal("D Spinning Weapon's types, force and sonic with the warp", [auto.spinningTypes({}), auto.spinningTypes({ unlocks: ["eaForceSonic"] }).slice(-2)], [["acid", "bludgeoning", "cold", "electricity", "fire"], ["force", "sonic"]]);
  equal("D …its dice, max 4d6", [{}, { damageDice: "1d6" }, { damageDice: "5d6" }].map(auto.spinningDice), ["1d6", "2d6", "4d6"]);
  equal("D the Warlock's spells: one at 1st, +1 at 3rd and every 3", [0, 1, 2, 3, 5, 6, 20].map(auto.warlockSpellsOwed), [0, 1, 1, 2, 2, 3, 7]);
  const ember = C.BONDED_SOULS[2].flags["trg-prime"].eaBondedSoul, seer = C.BONDED_SOULS[6].flags["trg-prime"].eaBondedSoul;
  equal("D the soul's +1: a matching trait or school", [auto.soulLevelBonus(ember, { traits: ["attack", "fire"] }), auto.soulLevelBonus(ember, { traits: ["cold"] }), auto.soulLevelBonus(seer, { traits: ["insight"] }), auto.soulLevelBonus(null, { traits: ["fire"] })], [1, 0, 1, 0]);
  const e = (sys, flags = {}) => ({ system: sys, flags: { "trg-prime": flags } });
  equal("D a spell of the soul's traditions, PP ≤ level + 1 (one more with its +1)", [
    auto.warlockMayTake(e({ tradition: "arcane", ppCost: 2, traits: "Evocation" }), { slot: "spell", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ tradition: "arcane", ppCost: 3, traits: "Evocation" }), { slot: "spell", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ tradition: "arcane", ppCost: 3, traits: "Fire" }), { slot: "spell", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ tradition: "verdant", ppCost: 1, traits: "" }), { slot: "spell", soul: ember, level: 5 }),
    auto.warlockMayTake(e({ tradition: "arcane", ppCost: 1, specialist: true }), { slot: "spell", soul: ember, level: 5 }),
    auto.warlockMayTake(e({ tradition: "arcane", ppCost: 0, traits: "Cantrip" }), { slot: "spell", soul: ember, level: 5 })
  ], [true, false, true, false, false, false]);
  equal("D a cantrip of any tradition; a hex, PP ≤ level + 1", [
    auto.warlockMayTake(e({ tradition: "verdant", ppCost: 0, traits: "Cantrip, Fire" }), { slot: "cantrip", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ tradition: "verdant", ppCost: 1, traits: "Fire" }), { slot: "cantrip", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ ppCost: 2, specialist: true }, { eaHex: true }), { slot: "hex", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ ppCost: 3, specialist: true }, { eaHex: true }), { slot: "hex", soul: ember, level: 1 }),
    auto.warlockMayTake(e({ ppCost: 2, specialist: true }), { slot: "hex", soul: ember, level: 1 })
  ], [true, false, true, false, false]);
  const copy = auto.warlockCopy({ _id: "x", name: "Burning Hands", system: { traits: "Fire, Invocation", usesPerDay: "2", prepared: false }, flags: { "trg-prime": { keep: 1 } } }, { source: { id: "s1", name: "The Emberlord" }, slot: "spell" });
  equal("D the copy: innate, Focus, one use, Charisma, PP up to level + 1, granted by the soul (Q37)",
    [copy._id, copy.system.innate, copy.system.traits, copy.system.usesPerDay, copy.system.usesValue, copy.system.prepared, copy.flags["trg-prime"].castingAbilityOverride, copy.flags["trg-prime"].innatePPAllowance, copy.flags["trg-prime"].grantedBy.sourceName, copy.flags["trg-prime"].keep, copy.flags["trg-eldritch-arts"].warlockPick],
    [undefined, true, "Fire, Invocation, Focus", "", 1, true, "charisma", 1, "The Emberlord", 1, "spell"]);
  equal("D …a cantrip's too, and Focus is not doubled", [auto.warlockCopy({ system: { traits: "Cantrip" } }, { slot: "cantrip" }).system.traits, auto.warlockCopy({ system: { traits: "Focus, Hex" } }, { slot: "hex" }).system.traits], ["Cantrip, Focus", "Focus, Hex"]);
  equal("D Xithra's offer: mental and the soul's; the row replaced, not added", [auto.xithraTypes(ember), auto.xithraEffects([{ kind: "note" }, { kind: "damageTypeChoice", damageTypes: ["x"] }], ember), auto.xithraEffects([{ kind: "damageTypeChoice" }], null)], [["mental", "fire"], [{ kind: "note" }, { kind: "damageTypeChoice", damageTypes: ["mental", "fire"] }], []]);
  const hit = { name: "Orc" };
  equal("D a rider on a hit needs the hit; on use, the cast", [auto.riderDue({ onHit: true }, { cast: true, spellHits: [{ target: hit }] }).due, auto.riderDue({ onHit: true }, { cast: true, spellHits: [] }).due, auto.riderDue({ onHit: false }, { cast: true, spellHits: [] }).due, auto.riderDue(null, { cast: true }).due, auto.riderDue({ onHit: false }, { cast: false }).due], [true, false, true, false, false]);
  // The cone: caster at (0,0), target at 10 squares east (100 px = 20 ft at 5 ft/25 px).
  const feetOf = (a, b) => Math.hypot(b.x - a.x, b.y - a.y) / 5;
  const pts = [{ id: "t", x: 100, y: 0 }, { id: "behind", x: 150, y: 0 }, { id: "diag", x: 140, y: 30 }, { id: "wide", x: 110, y: 60 }, { id: "far", x: 200, y: 0 }, { id: "front", x: 60, y: 0 }, { id: "c", x: 0, y: 0 }];
  equal("D Thunderous Strike's cone: behind the target, 15 ft, 90°; the target and the caster out", auto.coneBehind({ id: "c", x: 0, y: 0 }, { id: "t", x: 100, y: 0 }, pts, feetOf), ["behind", "diag"]);
  const conds = auto.arcaneEchoConditionals();
  equal("D Arcane Echo: +1 circumstance to the melee attack and its damage; not one-shot, or the attack would delete the damage row with the effect (review)", conds.map((c) => [c.value, c.type, Boolean(c.oneShot), c.when.checkTypes, c.when.attackModes]), [[1, "circumstance", false, ["attack"], ["melee"]], [1, "circumstance", false, ["damage"], ["melee"]]]);
  equal("D a Warlock reaches hexes through the feat; nobody else, and not a non-hex", [auto.warlockHexAccess({ items: [{ type: "class", name: "Warlock" }] }, { flags: { "trg-prime": { eaHex: true } } }), auto.warlockHexAccess({ items: [{ type: "class", name: "Witch" }] }, { flags: { "trg-prime": { eaHex: true } } }), auto.warlockHexAccess({ items: [{ type: "class", name: "Warlock" }] }, { flags: {} })], [true, false, false]);
}

/* ----------------------------------------------------------------- */
/* E — registration                                                     */
/* ----------------------------------------------------------------- */
const got = { classes: {}, autos: {}, access: [], pp: [], bonus: [], preludes: [], featAccess: [] };
const fakeApi = new Proxy({}, { get: (_, k) => {
  if (k === "registerClass") return (n, s) => { got.classes[n] = s; };
  if (k === "registerFeatAutomation") return (n, e) => { got.autos[n] = e; };
  if (k === "registerSpecialistAccess") return (n, f) => got.access.push([n, f]);
  if (k === "registerPPGrant") return (n, s) => got.pp.push([n, s]);
  if (k === "registerInnateLevelBonus") return (n, f) => got.bonus.push([n, f]);
  if (k === "registerCastPrelude") return (n, f) => got.preludes.push([n, f]);
  if (k === "registerFeatAccess") return (kind, n, feats) => got.featAccess.push([kind, n, feats]);
  return () => {};
} });
reg.registerContent(fakeApi, "trg-eldritch-arts");
{
  const cls = (n) => [got.classes[n]?.wealth, got.classes[n]?.proficiency?.armourCategories, got.classes[n]?.proficiency?.weaponCategories];
  equal("E the two classes: wealth and proficiency, as printed", [cls("Spellblade"), cls("Warlock")], [[2, ["Light"], ["Simple", "Martial"]], [1, ["Light"], ["Simple"]]]);
  equal("E …as the content's", [cls("Spellblade"), cls("Warlock")], ["Spellblade", "Warlock"].map((n) => [C.CLASS_REGISTRATIONS_B4[n].wealth, C.CLASS_REGISTRATIONS_B4[n].proficiency.armourCategories, C.CLASS_REGISTRATIONS_B4[n].proficiency.weaponCategories]));
  ok("E the automations: Infuse Weapon, Dimensional Step, the eight souls", ["Infuse Weapon", "Dimensional Step", ...auto.SOUL_NAMES].every((n) => got.autos[n] === auto.AUTOMATIONS_B4[n]));
  ok("E Hexes is the dispatcher (the Witch's and the Warlock's)", got.autos.Hexes === auto.hexesDispatch);
  equal("E sidebar 16's feats, for all four classes", got.featAccess.filter(([k]) => k === "class").map(([, n, f]) => [n, f]), Object.entries(auto.EXISTING_CLASS_FEATS).map(([n, f]) => [n, [...f]]));
  equal("E Natural Resilience: +1 HP per level, on the ability", got.pp.filter(([n]) => n === "Natural Resilience").map(([, s]) => [s.perLevel, s.types, s.stat]), [[1, ["ability"], "hp"]]);
  // Block 6 (0.9.0) adds Prepared Sigil's and Xithra Cone's preludes; verify-block6c and 6e hold them;
  // Block 7 (0.10.0) Flesh to Blossom's, which verify-block7 holds.
  equal("E the soul's +1, the two preludes, the Warlock's hex access", [got.bonus.map(([n]) => n), got.preludes.filter(([n]) => !["preparedSigil", "xithraCone", "eaFleshToBlossom"].includes(n)).map(([n, f]) => [n, f === auto.thunderousPrelude || f === auto.dimensionalAssaultPrelude]), got.access.filter(([n]) => n === "warlockHexes").map(([, f]) => f === auto.warlockHexAccess)], [["bondedSoul"], [["thunderousStrike", true], ["dimensionalAssault", true]], [true]]);
}

/* ----------------------------------------------------------------- */
/* F — the core, run with the content                                   */
/* ----------------------------------------------------------------- */
{
  const cm = await import(sys("module", "magic", "class-magic.mjs"));
  const mem = await import(sys("module", "magic", "memorisation.mjs"));
  const pathItem = (n) => ({ ...C.SPELLBLADE_PATHS[n], type: "ability", flags: { "trg-prime": { ...C.SPELLBLADE_PATHS[n].flags["trg-prime"], grantedBy: { sourceId: "p" } } } });
  const magic = cm.classMagicOf(C.SPELLBLADE, [pathItem(0)]);
  equal("F the Spellblade's magic, the path folded in: Intelligence, Arcane, one a level, L + 1", [magic.ability, magic.tradition, magic.bookPerLevel, magic.memorisedPerDay], ["intelligence", "arcane", 1, "L+1"]);
  equal("F …memorises level + 1 (TRG Prime 3.682.0)", [1, 5, 20].map((l) => mem.memorisationState({ level: l, memorisedPerDay: magic.memorisedPerDay }).leveledAllowed), [2, 6, 21]);
  const capi = await import(sys("module", "module-api.mjs"));
  const ilb = await import(sys("module", "magic", "innate-level-bonus.mjs"));
  capi.resetModuleRegistry();
  const warlock = makeActor("ZZ EA Warlock", { level: 3, items: [{ ...C.WARLOCK, type: "class" }, { ...C.BONDED_SOULS[2], type: "ability" }] });
  for (const [n, f] of got.bonus) capi.registerInnateLevelBonus(n, f, "test");
  equal("F the Emberlord's +1 reaches the core's innate cast: Fire and Healing, not Cold", await Promise.all([{ traits: "Fire, Invocation" }, { traits: "Healing" }, { traits: "Cold" }].map((s) => ilb.innateLevelBonusFor(warlock, { system: s }))), [1, 1, 0]);
  capi.resetModuleRegistry();
  const fd = await import(sys("module", "focus-declarations.mjs"));
  equal("F a copy's base PP may be level + 1, and the soul's +1 raises the level it is read at", [fd.innateLevelRefusal({ actorType: "character", basePP: 4, castLevel: 3, allowance: 1 }), Boolean(fd.innateLevelRefusal({ actorType: "character", basePP: 5, castLevel: 3, allowance: 1 })), fd.innateLevelRefusal({ actorType: "character", basePP: 5, castLevel: 4, allowance: 1 })], [null, true, null]);
  const av = await import(sys("module", "magic", "spell-availability.mjs"));
  const uses = await import(sys("module", "uses.mjs"));
  const copy = auto.warlockCopy({ name: "Fire Bolt", system: { traits: "Fire", ppCost: 2 } }, { source: { id: "s" }, slot: "spell" });
  equal("F the copy is castable from the innate table, with one Focus use", [av.spellAvailability(copy).castable, av.spellAvailability(copy).onTable, uses.focusDefaultUses(copy.system, "spell")], [true, false, 1]);
  equal("F Xithra is one Focus use too", uses.focusDefaultUses(SP.XITHRA.system, "spell"), 1);
  const se = await import(sys("module", "magic", "strike-edge.mjs"));
  equal("F Shooting Star's edge, as the core reads it", se.strikeEdgeFrom([{ flags: { "trg-prime": { strikeEdge: { ignoreConcealment: true, reduceCover: 1, label: "Shooting Star" } } } }], "Actor.x"), { ignoreCircumstance: false, ignoreConcealment: true, reduceCover: 1, label: "Shooting Star" });
  equal("F …and the trail's, for that creature only", [Boolean(se.strikeEdgeFrom([{ flags: { "trg-prime": { strikeEdge: { ignoreConcealment: true, reduceCover: 1, targetUuid: "Actor.orc" } } } }], "Actor.orc")), se.strikeEdgeFrom([{ flags: { "trg-prime": { strikeEdge: { reduceCover: 1, targetUuid: "Actor.orc" } } } }], "Actor.elf")], [true, null]);
  const sr = await import(sys("module", "magic", "strike-riders.mjs"));
  const rider = sr.normaliseStrikeRider({ label: "Spinning Weapon", dice: "2d6", damageType: "cold", scope: "melee", once: true });
  equal("F Spinning Weapon's rider is a rider the core accepts", [rider?.dice, rider?.damageType, rider?.scope, rider?.once], ["2d6", "cold", "melee", true]);
  const cond = await import(sys("module", "conditionals.mjs"));
  const echo = auto.arcaneEchoConditionals().map((c, i) => cond.normaliseConditional(c, { name: "Arcane Echo" }, i));
  equal("F Arcane Echo's rows are conditionals the core reads: automatic, and not spent alone", echo.map((c) => [Boolean(c), Boolean(c?.oneShot), c?.auto]), [[true, false, true], [true, false, true]]);
  ok("F …the attack row matches a melee attack and not a ranged one", cond.matchesCheck(echo[0], { checkType: "attack", attackMode: "melee" }) && !cond.matchesCheck(echo[0], { checkType: "attack", attackMode: "ranged" }) && !cond.matchesCheck(echo[0], { checkType: "skill" }));
  const sw = await import(sys("module", "magic", "spell-warp.mjs"));
  const by = Object.fromEntries(SP.BLOCK4_SPECIALIST.map((s) => [s.flags["trg-prime"].eaSpellbladeSpell, s]));
  const agg = (spell, form) => sw.aggregateWarpSelection(spell.system.warps, form).mods;
  equal("F the warps, aggregated by the core: Shielding ×3 bonusValue 3; Spinning 2 dice and the unlock; Dimensional's unlock", [agg(by.shieldingStrike, { "warp-0": 3 }).bonusValue, agg(by.spinningWeapon, { "warp-0": 2, "warp-1": true }).damageDice, agg(by.spinningWeapon, { "warp-1": true }).unlocks, agg(by.dimensionalAssault, { "warp-0": true }).unlocks], [3, "2d6", ["eaForceSonic"], ["eaSpatialAwareness5"]]);
  equal("F …which the module reads as +5, 3d6 with force and sonic", [auto.shieldingBonus(agg(by.shieldingStrike, { "warp-0": 3 })), auto.spinningDice(agg(by.spinningWeapon, { "warp-0": 2 })), auto.spinningTypes(agg(by.spinningWeapon, { "warp-1": true })).length], [5, "3d6", 7]);
  const dtc = await import(sys("module", "magic", "damage-type-choice.mjs"));
  equal("F every soul's Xithra offer is a choice the core honours", C.BONDED_SOULS.map((s) => dtc.offeredTypes({ damageTypes: auto.xithraTypes(s.flags["trg-prime"].eaBondedSoul) }).length), [2, 2, 2, 2, 2, 2, 2, 2]);
  const df = await import(sys("module", "defences.mjs"));
  const dmg = await import(sys("module", "combat", "damage.mjs"));
  const aw = await quiet(() => import(sys("module", "combat", "affliction-workflow.mjs")));
  const field = df.resolveDamageTypeField(C.NATURAL_RESILIENCE.effects[0].changes[0].value);
  const take = (type, item) => dmg.resolveDamagePacket({ amount: 9, type, sourceTraits: aw.stageDamageTraits(item, type), resistances: field.damageTypes, resistanceTraits: field.traits }).taken;
  equal("F Natural Resilience (Q43): a disease's essence halved, poison halved, a curse's not, a sword's not",
    [take("essence", { system: { afflictionType: "disease" } }), take("poison", { system: { afflictionType: "poison" } }), take("essence", { system: { afflictionType: "curse" } }), dmg.resolveDamagePacket({ amount: 9, type: "slashing", resistances: field.damageTypes, resistanceTraits: field.traits }).taken], [4, 4, 9, 9]);
  const fw = await quiet(() => import(sys("module", "feats-workflow.mjs")));
  capi.resetModuleRegistry();
  for (const [n, s] of got.pp) capi.registerPPGrant(n, s, "test");
  const row = fw.modulePPGrants().find((r) => r.name === "natural resilience");
  equal("F …and +1 maximum HP per level through the core's stored grant", [row?.path, row?.due({ system: { identity: { level: 6 } } })], ["system.resources.hp.other", 6]);
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* G — the Foundry side with fakes                                      */
/* ----------------------------------------------------------------- */
{
  // Infuse Weapon: at 3rd, Flaming I (3) fits; Keen (2) does not after it.
  const sword = { _id: "sword", name: "Longsword", type: "weapon", system: { equipped: true, attackMode: "melee" } };
  const sb = makeActor("ZZ EA Spellblade", { level: 3, items: [{ ...C.INFUSE_WEAPON, type: "ability" }, sword] });
  sb.flags["trg-eldritch-arts"] = { infusionRunes: [{ key: "flaming", tier: 1, name: "Flaming I", level: 3 }, { key: "keen", tier: 1, name: "Keen", level: 2 }] };
  // A second answer offered: only a pool that ignores the budget would take Keen.
  answers.push("infuse", "0", "0");
  await auto.AUTOMATIONS_B4["Infuse Weapon"].use(sb, sb.items[0]);
  answers.length = 0;
  equal("G Infuse Weapon writes the core's flag: the weapon, the runes within the level budget, magical", sb.flags["trg-prime"]?.infusedRunes, { weaponId: "sword", runes: "flaming 1", magical: true });
  // Learn a rune: the path's tradition skill, Learn a Spell's terms, a Success writes it.
  const sb2 = makeActor("ZZ EA Learner", { level: 3, items: [{ ...C.INFUSE_WEAPON, type: "ability" }, { ...C.SPELLBLADE_PATHS[3], type: "ability" }] });
  sb2.system.progression.tradition = "verdant"; sb2.gp = 1000;
  answers.push("learn", "1"); confirms.push(true); rollDegree = { key: "success", success: true };
  await auto.AUTOMATIONS_B4["Infuse Weapon"].use(sb2, sb2.items[0]);
  equal("G Learn a rune (Q46): Nature, DC and price for the rune's level, written into the book", [helpers.lastCheck?.subject, helpers.lastCheck?.dc, sb2.gp, sb2.flags["trg-eldritch-arts"]?.infusionRunes], ["nature", 23, 200, [{ key: "flaming", tier: 2, name: "Flaming II", level: 8 }]]);
  answers.push("learn", "0"); confirms.push(true); rollDegree = { key: "failure", success: false };
  await auto.AUTOMATIONS_B4["Infuse Weapon"].use(sb2, sb2.items[0]);
  equal("G …a failed check learns nothing, and keeps its materials (Learn a Spell's Failure)", [sb2.flags["trg-eldritch-arts"].infusionRunes.length, sb2.gp], [1, 200]);
  answers.push("learn", "0"); confirms.push(true); rollDegree = { key: "critical", success: true };
  await auto.AUTOMATIONS_B4["Infuse Weapon"].use(sb2, sb2.items[0]);
  equal("G …a Critical learns it for half the price", [sb2.flags["trg-eldritch-arts"].infusionRunes.map((r) => r.key), sb2.gp], [["flaming", "keen"], 100]);
  answers.push("learn"); confirms.push(true);
  sb2.gp = 0; sb2.flags["trg-eldritch-arts"].infusionRunes = []; answers.push("0");
  await auto.AUTOMATIONS_B4["Infuse Weapon"].use(sb2, sb2.items[0]);
  answers.length = 0; confirms.length = 0;
  ok("G …and is not attempted without the materials in hand", sb2.gp === 0 && cards.some((c) => /the materials cost/.test(c.warn ?? "")));
  rollDegree = { key: "success", success: true };

  // The soul's picks: one spell at 1st (the soul's traditions), two cantrips.
  const fakePack = { collection: "trg-prime.spells", getIndex: async () => new Map(index.map((e) => [e._id, e])), getDocument: async (id) => { const e = index.find((x) => x._id === id); return e ? { ...e, toObject: () => JSON.parse(JSON.stringify(e)) } : null; }, documentName: "Item" };
  const index = [
    { _id: "s1", type: "spell", name: "Fire Bolt", system: { tradition: "arcane", ppCost: 2, traits: "Fire, Invocation" }, flags: {} },
    { _id: "s2", type: "spell", name: "Entangle", system: { tradition: "verdant", ppCost: 1, traits: "Plant" }, flags: {} },
    { _id: "c1", type: "spell", name: "Light", system: { tradition: "divinity", ppCost: 0, traits: "Cantrip, Light" }, flags: {} },
    { _id: "c2", type: "spell", name: "Spark", system: { tradition: "verdant", ppCost: 0, traits: "Cantrip" }, flags: {} },
    { _id: "h1", type: "spell", name: "Witch Bolt", system: { ppCost: 2, specialist: true }, flags: { "trg-prime": { eaHex: true } } }
  ];
  game.packs = [fakePack];
  const wl = makeActor("ZZ EA Warlock", { level: 1, items: [{ ...C.WARLOCK, type: "class" }, { ...C.BONDED_SOULS[2], type: "ability" }] });
  answers.push("s1|trg-prime.spells", "c1|trg-prime.spells", "c2|trg-prime.spells");
  await auto.AUTOMATIONS_B4["The Emberlord"].use(wl, wl.items[1]);
  const picks = wl.items.filter((i) => i.type === "spell");
  equal("G the soul's Use: the spell, then both cantrips, each innate Focus", picks.map((p) => [p.name, p.flags["trg-eldritch-arts"].warlockPick, p.system.innate, /Focus/.test(p.system.traits)]), [["Fire Bolt", "spell", true, true], ["Light", "cantrip", true, true], ["Spark", "cantrip", true, true]]);
  answers.push("h1|trg-prime.spells");
  await auto.hexesDispatch.use(wl, { name: "Hexes", system: { sourceClass: "Warlock" } });
  equal("G the Warlock's Hexes: the hex, innate Focus", wl.items.filter((i) => i.flags?.["trg-eldritch-arts"]?.warlockPick === "hex").map((p) => [p.name, p.system.innate]), [["Witch Bolt", true]]);

  // Xithra's type follows the soul.
  const xa = makeActor("ZZ EA Xithra", { level: 1, items: [{ ...C.WARLOCK, type: "class" }, { ...SP.XITHRA, type: "spell" }] });
  const [soulMade] = await xa.createEmbeddedDocuments("Item", [{ ...C.BONDED_SOULS[3], type: "ability" }]);
  await auto.onItemCreatedB4(soulMade);
  equal("G Xithra's offer is written when the soul arrives", xa.items.find((i) => i.name === "Xithra").system.effects, [{ kind: "damageTypeChoice", damageTypes: ["mental", "fire"] }]);
  // The Emberlord's rider: once a day, on a hit.
  const orc = makeActor("ZZ EA Orc");
  const ea = makeActor("ZZ EA Ember", { level: 1, items: [{ ...C.WARLOCK, type: "class" }, { ...C.BONDED_SOULS[2], type: "ability" }] });
  const xithra = { name: "Xithra", flags: { "trg-prime": { eaXithra: true } } };
  confirms.push(true);
  await auto.onSpellSettledB4({ actor: ea, spell: xithra, cast: true, spellHits: [{ target: orc }] });
  const first = orc.recurring;
  orc.recurring = null;
  await auto.onSpellSettledB4({ actor: ea, spell: xithra, cast: true, spellHits: [{ target: orc }] });
  ok("G …the second hit that day gives nothing", orc.recurring === null);
  orc.recurring = first;
  equal("G the Emberlord's flames: 1d6 recurring fire on a hit, once a day", [orc.recurring, ea.items[1].flags["trg-eldritch-arts"]?.riderUsed], [{ amount: 4, type: "fire" }, true]);
  await auto.onDailyPreparationB4({ actor: ea });
  equal("G …ready again after daily preparation", ea.items[1].flags["trg-eldritch-arts"]?.riderUsed, undefined);
  orc.recurring = undefined;
  await auto.onSpellSettledB4({ actor: ea, spell: xithra, cast: true, spellHits: [] });
  equal("G …and not on a miss", orc.recurring, undefined);

  // Arcane Echo: after a cast, spends its use, one effect; a melee Strike ends it.
  const ad = makeActor("ZZ EA Duellist", { level: 2, items: [{ ...C.ARCANE_ECHO, type: "ability", system: { ...C.ARCANE_ECHO.system, usesValue: 1 } }] });
  await auto.onSpellSettledB4({ actor: ad, spell: { name: "Spark", flags: {} }, cast: true });
  const echoEffect = ad.effects.find((e) => e.flags?.["trg-eldritch-arts"]?.source === "arcaneEcho");
  equal("G Arcane Echo: the effect with its two rows, and the use spent", [Boolean(echoEffect), echoEffect?.flags?.["trg-prime"]?.conditionals?.length, ad.items[0].system.usesValue], [true, 2, 0]);
  await auto.onSpellSettledB4({ actor: ad, spell: { name: "Spark", flags: {} }, cast: true });
  equal("G …not again without its use", ad.effects.filter((e) => e.flags?.["trg-eldritch-arts"]?.source === "arcaneEcho").length, 1);
  await auto.onStrikeResolvedB4({ attacker: ad, melee: true, resolved: true, hits: false });
  equal("G …spent on that melee attack, hit or miss (Q50)", ad.effects.filter((e) => e.flags?.["trg-eldritch-arts"]?.source === "arcaneEcho").length, 0);

  // Sacred Channel: a hit, 1 PP and the use, 1d8.
  const da = makeActor("ZZ EA Divine", { level: 1, pp: 3, items: [{ ...C.SACRED_CHANNEL, type: "ability", system: { ...C.SACRED_CHANNEL.system, usesValue: 1 } }] });
  confirms.push(true);
  await auto.onStrikeResolvedB4({ attacker: da, hits: true, melee: true, resolved: true });
  equal("G Sacred Channel: 1 PP, the use, 1d8 healed", [da.system.resources.pp.value, da.items[0].system.usesValue, da.healed], [2, 0, 4]);
  await auto.onStrikeResolvedB4({ attacker: da, hits: true, melee: true, resolved: true });
  equal("G …once until Refocus (Q36)", [da.system.resources.pp.value, da.healed], [2, 4]);

  // Spinning Weapon: the rider effect, the type chosen, the warp's dice.
  const sw = makeActor("ZZ EA Spinner", { level: 1 });
  answers.push("cold");
  await auto.onSpellSettledB4({ actor: sw, spell: { name: "Spinning Weapon", flags: { "trg-prime": { eaSpellbladeSpell: "spinningWeapon" } } }, cast: true, warpMods: { damageDice: "1d6" } });
  equal("G Spinning Weapon: the core's strike rider, 2d6 cold, melee, once", sw.effects[0]?.flags?.["trg-prime"]?.strikeRider, { label: "Spinning Weapon", dice: "2d6", damageType: "cold", scope: "melee", once: true });
  answers.push("fire");
  await auto.onSpellSettledB4({ actor: sw, spell: { name: "Spinning Weapon", flags: { "trg-prime": { eaSpellbladeSpell: "spinningWeapon" } } }, cast: false });
  answers.length = 0;
  equal("G …nothing on a failed cast (Q47)", sw.effects.length, 1);

  // Shielding Strike: the Strike at no AP, then the DB.
  const ss = makeActor("ZZ EA Shield", { level: 1, items: [sword] });
  strikes.length = 0;
  await auto.onSpellSettledB4({ actor: ss, spell: { name: "Shielding Strike", flags: { "trg-prime": { eaSpellbladeSpell: "shieldingStrike" } } }, cast: true, warpMods: { bonusValue: 1 } });
  equal("G Shielding Strike: one Strike at no AP, then +3 status DB", [strikes.length, strikes[0]?.options?.apPaid, ss.effects[0]?.changes], [1, true, [{ key: "system.combat.defence.status", mode: 2, value: "3", priority: 20 }]]);

  // Shooting Star: the edge on the Strike, 30 ft for melee; then the trail on each ally.
  const star = makeActor("ZZ EA Star", { level: 1, items: [sword] });
  const ally = makeActor("ZZ EA Ally");
  const tok = (a, id, d) => ({ id, actor: a, document: { disposition: d }, isTargeted: false, setTarget(v) { this.isTargeted = v; if (v) game.user.targets.add(this); else game.user.targets.delete(this); } });
  star.getActiveTokens = () => [tok(star, "tS", 1)];
  canvas.tokens.placeables = [tok(star, "tS", 1), tok(ally, "tA", 1), tok(orc, "tO", -1)];
  strikes.length = 0; strikeTarget = orc; strikeHits = true;
  let edgeDuring = null;
  const prevRoll = helpers.rollWeaponAttack;
  helpers.rollWeaponAttack = async (a, w, o) => { edgeDuring = a.effects.map((e) => e.flags?.["trg-prime"]?.strikeEdge).find(Boolean) ?? null; return prevRoll(a, w, o); };
  await auto.onSpellSettledB4({ actor: star, spell: { name: "Shooting Star", flags: { "trg-prime": { eaSpellbladeSpell: "shootingStar" } } }, cast: true });
  helpers.rollWeaponAttack = prevRoll;
  equal("G Shooting Star: the Strike at no AP, a melee weapon's reach 30 ft, through concealment and a degree of cover", [strikes[0]?.options?.apPaid, strikes[0]?.options?.reachOverrideFeet, edgeDuring], [true, 30, { ignoreConcealment: true, reduceCover: 1, label: "Shooting Star" }]);
  equal("G …its edge gone after the Strike", star.effects.filter((e) => e.flags?.["trg-prime"]?.strikeEdge).length, 0);
  const trail = ally.effects.find((e) => e.flags?.["trg-eldritch-arts"]?.source === "shootingStarTrail");
  equal("G …on a hit, the trail on the ally: that creature only (Q49)", [trail?.flags?.["trg-prime"]?.strikeEdge, trail?.flags?.["trg-eldritch-arts"]?.trailOf], [{ ignoreConcealment: true, reduceCover: 1, label: "Shooting Star's trail", targetUuid: orc.uuid }, star.id]);
  equal("G …with a world-clock backstop, two rounds (review)", [trail?.flags?.["trg-prime"]?.spellEffect, trail?.flags?.["trg-prime"]?.spellEffectEnd], [true, 12]);
  game.actors = [star, ally, orc];
  game.user.isGM = true; game.users.activeGM = game.user;
  await auto.onTurnEndedB4({ combat: { combatant: { actor: star } } });
  equal("G …and it ends as the caster's turn starts", ally.effects.filter((e) => e.flags?.["trg-eldritch-arts"]?.source === "shootingStarTrail").length, 0);
  strikeHits = false; strikes.length = 0;
  await auto.onSpellSettledB4({ actor: star, spell: { name: "Shooting Star", flags: { "trg-prime": { eaSpellbladeSpell: "shootingStar" } } }, cast: true });
  equal("G …a miss leaves no trail", ally.effects.length, 0);
  strikeHits = true;

  // Thunderous Strike's prelude: the Strike first, then the cast on its roll.
  casts.length = 0; strikes.length = 0;
  const vw = makeActor("ZZ EA Warden", { level: 1, items: [sword] });
  const thunder = { name: "Thunderous Strike", system: { castAP: 2 }, flags: { "trg-prime": { eaSpellbladeSpell: "thunderousStrike" } } };
  const out = await auto.thunderousPrelude({ actor: vw, spell: thunder });
  equal("G Thunderous Strike: one Strike at no AP, then the cast with its check and preset targets (Q48)", [strikes.length, strikes[0]?.options?.apPaid, casts.length, Boolean(casts[0]?.options?.strikeCheck?.dice), casts[0]?.options?.presetTargets, out?.handled], [1, true, 1, true, true, true]);
  equal("G …another spell is not taken over", await auto.thunderousPrelude({ actor: vw, spell: { name: "Fireball", flags: {} } }), null);
  // A cast that does not go ahead after the Strike: the Strike is paid for (review).
  const prevCast = helpers.castSpell;
  helpers.castSpell = async () => null;
  game.combat = { started: true, combatants: [{ actor: vw }] }; vw.system.resources.ap.value = 6;
  await auto.thunderousPrelude({ actor: vw, spell: thunder });
  equal("G …a Strike whose cast was cancelled costs 1 AP, as a Strike", vw.system.resources.ap.value, 5);
  // Live test (0.7.0): a creature outside the running combat pays no AP.
  game.combat = { started: true, combatants: [{ actor: orc }] };
  await auto.thunderousPrelude({ actor: vw, spell: thunder });
  helpers.castSpell = prevCast; game.combat = null;
  equal("G …and a creature not in the running combat pays none (live test)", vw.system.resources.ap.value, 5);
  // …and the same for Blocks 1 and 3 (Gale Step, Dragon Claws, Vir-ellian Release, Elemental Symbiosis): 0.7.1.
  const b1 = await import(new URL("../module/block1-automations.mjs", import.meta.url));
  game.combat = { started: true, combatants: [{ actor: orc }] };
  const apBefore = vw.system.resources.ap.value;
  await b1.spendAP(vw, "Gale Step", 1);
  equal("G Blocks 1 and 3: in a running combat, only a combatant pays AP (live test)", [b1.inCombat(vw), b1.inCombat(orc), b1.inCombat(), vw.system.resources.ap.value], [false, true, true, apBefore]);
  // Review (0.7.1): an unlinked token is in the combat only as itself, not by its base actor's id.
  const tokA = { id: "orc-base", isToken: true }, tokB = { id: "orc-base", isToken: true }, linked = { id: "orc-base", isToken: false };
  game.combat = { started: true, combatants: [{ actor: tokA, actorId: "orc-base" }] };
  equal("G …an unlinked token is in it as itself, not by its base actor's id (review)", [b1.inCombat(tokA), b1.inCombat(tokB), b1.inCombat(linked)], [true, false, true]);
  game.combat = null;
  vw.system.resources.pp.value = 0;
  strikes.length = 0;
  await auto.thunderousPrelude({ actor: vw, spell: { ...thunder, system: { castAP: 2, ppCost: 1 } } });
  equal("G …and no Strike at all without the PP to cast it", strikes.length, 0);
  // The Whispered Sage's Misty Step: cast with nothing targeted (review).
  const sage = makeActor("ZZ EA Sage", { level: 1, items: [{ ...C.WARLOCK, type: "class" }, { ...C.BONDED_SOULS[7], type: "ability" }] });
  game.packs = [{ collection: "trg-prime.spells", documentName: "Item", getIndex: async () => new Map([["m1", { _id: "m1", type: "spell", name: "Misty Step", system: { ppCost: 6 }, flags: {} }]]), getDocument: async () => ({ toObject: () => ({ _id: "m1", type: "spell", name: "Misty Step", system: { ppCost: 6, traits: "Teleportation" }, flags: {} }) }) }];
  globalThis.Item = { implementation: class { constructor(d) { Object.assign(this, d); } } };
  const orcTok = canvas.tokens.placeables.find((t) => t.id === "tO"); orcTok.setTarget(true);
  casts.length = 0; confirms.push(true);
  await auto.onSpellSettledB4({ actor: sage, spell: xithra, cast: true, spellHits: [{ target: orc }] });
  equal("G the Whispered Sage's Misty Step: 0 AP, innate at its base PP, nothing targeted while it is cast", [casts[0]?.spell, casts[0]?.options?.apPaid, casts[0]?.targets, game.user.targets.has(orcTok)], ["Misty Step", true, [], true]);
}

/* ----------------------------------------------------------------- */
/* H — the hooks and the versions                                       */
/* ----------------------------------------------------------------- */
ok("H the hooks: settled, strike resolved, daily preparation, item created, turn ended",
  [["trgPrimeSpellSettled", "onSpellSettledB4"], ["trgPrimeStrikeResolved", "onStrikeResolvedB4"], ["trgPrimeDailyPreparation", "onDailyPreparationB4"], ["createItem", "onItemCreatedB4"], ["trgPrimeTurnEnded", "onTurnEndedB4"]].every(([hook, n]) => new RegExp(`Hooks\\.on\\("${hook}", \\([a-z]+\\) => \\{ ${n}\\(`).test(scriptSrc)));
ok("H registration calls Block 4", /registerBlock4\(api, moduleId\);/.test(read("module", "registration.mjs")));
// 0.7.1 (the live test's fixes) on 3.682.1 (Battle Mage on the core's attack spells).
// From 0.8.0 "or later", as the earlier blocks' version checks are.
{
  const atLeastV = (v, min) => { const a = String(v).split(".").map(Number), b = min.split(".").map(Number); for (let i = 0; i < 3; i++) { if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0); } return true; };
  const req = scriptSrc.match(/REQUIRED_SYSTEM = "([\d.]+)"/)?.[1] ?? "0";
  equal("H 0.7.1 or later on TRG Prime 3.682.1 or later", [atLeastV(manifest.version, "0.7.1"), atLeastV(manifest.relationships.systems[0].compatibility.minimum, "3.682.1"), atLeastV(req, "3.682.1"), manifest.download.includes(`/v${manifest.version}/`)], [true, true, true, true]);
}
ok("H the classes, abilities and spells packs carry Block 4", ["ea-classes", "ea-abilities", "ea-spells"].every((n) => fs.readdirSync(path.join(ROOT, "packs-source", n)).length > 0)
  && ["Spellblade", "Warlock"].every((n) => fs.readdirSync(path.join(ROOT, "packs-source", "ea-classes")).some((f) => f.startsWith(`${n}_`)))
  && ["Xithra", "Thunderous-Strike", "The-Emberlord", "Path-of-the-Verdant-Warden"].every((n) => [...fs.readdirSync(path.join(ROOT, "packs-source", "ea-spells")), ...fs.readdirSync(path.join(ROOT, "packs-source", "ea-abilities"))].some((f) => f.startsWith(`${n}_`))));

console.log(`verify-block4: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
