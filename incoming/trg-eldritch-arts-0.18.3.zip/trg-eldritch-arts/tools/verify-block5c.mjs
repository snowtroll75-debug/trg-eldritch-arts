#!/usr/bin/env node
/**
 * verify-block5c — Eldritch Arts 0.8.0 (Block 5, group C, on TRG Prime
 * 3.683.0): the nineteen Scaelyn racial feats.
 *
 *   A  the feats against the book: names, race, traits, prerequisites, uses,
 *      text, the automation paragraph, the grades
 *   B  the core, run with the content: prerequisite gating (C1), the innate
 *      grants and their PP (Q76), the claws in the companions pack, the
 *      conditionals, the immunities, the granted speeds, Ghostscale's light,
 *      the spell DC rows, the one-attack DB and the spell-only offer (C3),
 *      the check reaction's modifiers (C2), the PP grant
 *   C  the rules, run
 *   D  registration
 *   E  the Foundry side with fakes: every Use and every hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block5c.mjs
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const norm = (v) => String(v ?? "").trim().toLowerCase();

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const asked = [];
const areaRuns = [];
const spellChoices = [];
const reactionsSpent = [];
let light = 4;
let reactorSays = "yes";
const steps = {};
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => (answers.length ? answers.shift() : null),
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => (/\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null),
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  replaceFeatEffect: async (actor, item, data) => {
    actor.effects = actor.effects.filter((e) => e.flags?.["trg-prime"]?.featSource !== item.id);
    const [made] = await actor.createEmbeddedDocuments("ActiveEffect", [{ ...data, flags: { ...(data.flags ?? {}), "trg-prime": { ...(data.flags?.["trg-prime"] ?? {}), featSource: item.id } } }]);
    return made;
  },
  chooseSpell: async (actor, item, spec) => { spellChoices.push({ item: item.name, spec }); return true; },
  runAreaEffect: async (actor, spec, opts) => { areaRuns.push({ actor: actor.name, spec, targets: (opts?.targets ?? []).map((a) => a.name), title: opts?.title }); return ["area"]; },
  spendReaction: async (actor, label) => { reactionsSpent.push(label); const v = Number(actor.system.resources.reactions?.value ?? 0); if (v <= 0) return false; actor.system.resources.reactions.value = v - 1; return true; },
  reactionRefusal: async (actor) => (Number(actor.system.resources.reactions?.value ?? 0) > 0 ? "" : "no reaction left this round"),
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, q }); if (reactorSays !== "yes") return { answer: "no", result: null }; return { answer: "yes", result: await steps[q.step]?.(actor, "yes", q.data) }; },
  lightLevelAt: async () => light
};
const hookFns = {};
globalThis.Hooks = { on: (name, fn) => { (hookFns[name] ??= []).push(fn); return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => true } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false, randomID: () => "r1" } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.uuid = `${parent.uuid}.Item.${it.id}`;
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.toObject = () => JSON.parse(JSON.stringify({ ...it, parent: undefined }));
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}` };
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.delete = async () => { a.effects = a.effects.filter((x) => x.id !== e.id); };
  return e;
}
function makeActor(name, { level = 5, items = [], ap = 6, reactions = 1, size = "small", specialist = {} } = {}) {
  const a = { name, id: `a-${name.replace(/\W/g, "")}`, isOwner: true, effects: [], flags: {}, items: [] };
  a.uuid = `Actor.${a.id}`;
  a.system = { identity: { level, size }, resources: { pp: { value: 5 }, ap: { value: ap }, reactions: { value: reactions } }, specialistSkills: specialist };
  a.items = items.map((d) => makeItem(d, a));
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = list.map((d) => makeEffect(d, a));
    a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => {
    if (type === "Item") a.items = a.items.filter((i) => !ids.includes(i.id));
    else a.effects = a.effects.filter((e) => !ids.includes(e.id));
  };
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  return a;
}
const userTargets = new Set();
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: userTargets }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.683.0" }
};
globalThis.canvas = { tokens: { placeables: [] } };
const uuids = new Map();
globalThis.fromUuidSync = (u) => uuids.get(u) ?? null;

const C = await import(new URL("./content/block5-c.mjs", import.meta.url));
const B1 = await import(new URL("./content/block1.mjs", import.meta.url));
const auto = await import(new URL("../module/block5c-automations.mjs", import.meta.url));
const byName = Object.fromEntries(C.FEATS_B5_C.map((d) => [d.name, d]));
const F = (d) => d.flags?.["trg-prime"] ?? {};
const conds = (d) => F(d).conditionals ?? [];

/* ----------------------------------------------------------------- */
/* A — the feats against the book                                       */
/* ----------------------------------------------------------------- */
const PRINTED = {
  "Alchemical Purifier": ["Focus", "Level 5, Sludge Blooded"],
  "Ancestral Awakening": ["Concentrate, Focus, Warding", "Level 10, Scaled Focus"],
  "Claws of the Wyrm": ["", ""],
  "Desert Wraith": ["Focus", "Level 5, Sandstrider"],
  "Draconic Immunity": ["", "Level 5"],
  "Draconic Wings": ["", "Level 10"],
  "Elemental Breath": ["Elemental, Focus, Invocation, Save", "Wyrmdral Heritage"],
  "Ember Handed": ["Fire, Invocation", "Sparktail Heritage"],
  "Ghostscale": ["", "Wisperfin Heritage"],
  "Glyph Unleashed": ["Focus, Rune, Warding", "Level 5, Runic Aptitude"],
  "Pyrotechnic Flair": ["Fire, Focus, Invocation", "Level 5, Ember Handed"],
  "Runic Aptitude": ["", "Glyphweave Heritage"],
  "Sandstrider": ["", "Dustscale Heritage"],
  "Scaelyn Scholar": ["", ""],
  "Scaled Focus": ["", "Level 5, Wyrm’s Cunning"],
  "Scaled Trickster": ["", ""],
  "Silence Unbound": ["Focus", "Level 5, Ghostscale"],
  "Sludge Blooded": ["", "Ironmuk Heritage"],
  "Wyrm’s Cunning": ["", ""]
};
const SCAELYN = book.sections.racialFeats.filter((f) => f.traits.includes("SCAELYN"));
{
  equal("A nineteen feats, every SCAELYN feat the book prints", [C.FEATS_B5_C.length, SCAELYN.length], [19, 19]);
  equal("A the names, in the book's order", C.FEATS_B5_C.map((d) => d.name), Object.keys(PRINTED));
  equal("A every one a Racial feat of the Scaelyn, its book line kept", C.FEATS_B5_C.map((d) => [d.type, d.system.category, d.system.sourceRace, F(d).eaBlock, F(d).eaBookLine]), SCAELYN.map((f) => ["feat", "Racial", "Scaelyn", 5, f.line]));
  equal("A traits (the race trait as sourceRace) and prerequisites, as printed", Object.fromEntries(C.FEATS_B5_C.map((d) => [d.name, [d.system.traits, d.system.prerequisites]])), PRINTED);
  ok("A no feat prints a count of uses (Focus is the core's one use)", C.FEATS_B5_C.every((d) => d.system.usesPerDay === "" && d.system.usesValue === 0 && d.system.repeatable === false));
  for (const f of SCAELYN) {
    const d = C.FEATS_B5_C.find((x) => x.system.description.includes(f.lines[0].slice(0, 50)) && F(x).eaBookLine === f.line);
    ok(`A ${f.name}: the book's text on the card`, Boolean(d) && f.lines.every((l) => d.system.description.includes(l.slice(0, 60))) && (!f.flavour || d.system.description.includes(f.flavour.slice(0, 40))));
  }
  ok("A every card says what is automated (an Automated paragraph)", C.FEATS_B5_C.every((d) => /<em>Automated \(0\.8\.0/.test(d.system.description)));
  ok("A …and what is not, where a clause is not (Ghostscale, Sludge Blooded, Glyph Unleashed)", ["Ghostscale", "Sludge Blooded", "Glyph Unleashed"].every((n) => /<em>Not automated:<\/em>/.test(byName[n].system.description)));
  ok("A …and cites the ruling where one decided it (Q76–Q80)", [["Alchemical Purifier", "Q76"], ["Elemental Breath", "Q77"], ["Sandstrider", "Q78"], ["Desert Wraith", "Q78"], ["Runic Aptitude", "Q79"], ["Glyph Unleashed", "Q80"]].every(([n, q]) => byName[n].system.description.includes(q)));
  equal("A the grades: one per feat, 12 A and 7 B (the audit's)", [Object.keys(C.AUTOMATION_B5_C), ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B5_C).filter((e) => e.level === l).length)], [Object.keys(PRINTED), [12, 7, 0, 0]]);
  equal("A the B feats: those with a pick, a tick or a reaction", Object.entries(C.AUTOMATION_B5_C).filter(([, e]) => e.level === "B").map(([n]) => n), ["Ancestral Awakening", "Desert Wraith", "Elemental Breath", "Ember Handed", "Glyph Unleashed", "Runic Aptitude", "Sludge Blooded"]);
  ok("A ids unique", new Set(C.FEATS_B5_C.map((d) => d._id)).size === 19);
  ok("A no name clashes with a Block 1 feat", C.FEATS_B5_C.every((d) => !B1.BACKGROUND_FEATS.some((b) => norm(b.name) === norm(d.name))));
  const named = C.FEATS_B5_C.flatMap((d) => d.system.prerequisites.split(",").map((s) => s.trim())).filter((s) => s && !/^Level \d+$/.test(s) && !/ Heritage$/.test(s));
  ok("A every feat a prerequisite names is one of these, curly apostrophe and all", named.length === 7 && named.every((n) => Boolean(byName[n])), JSON.stringify(named));
  const heritages = C.FEATS_B5_C.map((d) => /^(\S+) Heritage$/.exec(d.system.prerequisites)?.[1]).filter(Boolean);
  ok("A every heritage a prerequisite names is a Block 1 Scaelyn heritage", heritages.length === 6 && heritages.every((n) => B1.HERITAGES.some((h) => h.name === n && h.system.sourceRace === "Scaelyn")), JSON.stringify(heritages));
}

/* ----------------------------------------------------------------- */
/* B — the core, run with the content                                   */
/* ----------------------------------------------------------------- */
async function packDocs(pack) {
  const { ClassicLevel } = await import("classic-level");
  const src = path.join(SYSTEM_ROOT, "packs", pack);
  if (!fs.existsSync(src)) return null;
  // READ FROM A COPY: another harness may hold the pack's lock.
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ea-b5c-"));
  fs.cpSync(src, tmp, { recursive: true });
  fs.rmSync(path.join(tmp, "LOCK"), { force: true });
  const db = new ClassicLevel(tmp, { valueEncoding: "json" });
  const docs = [];
  try { for await (const [k, v] of db.iterator()) if (k.split("!")[1] && !k.split("!")[1].includes(".")) docs.push(v); }
  finally { await db.close(); fs.rmSync(tmp, { recursive: true, force: true }); }
  return docs;
}
const corePack = { spells: await packDocs("spells"), companions: await packDocs("companions"), feats: await packDocs("feats") };
ok("B the system's spells, companions and feats packs were read", Object.values(corePack).every((p) => Array.isArray(p) && p.length));
{
  const pre = await import(sys("module", "prerequisites.mjs"));
  const knownHeritages = new Set(B1.HERITAGES.map((h) => pre.heritageNameKey(h.name)));
  const knownNames = new Set([...C.FEATS_B5_C.map((d) => pre.prerequisiteNameKey(d.name))]);
  const stats = (level, heritage, owned = []) => ({ level, heritageNames: new Set([pre.heritageNameKey(heritage)]), knownHeritages, knownNames, ownedNames: new Set(owned.map((n) => pre.prerequisiteNameKey(n))) });
  const meets = (n, s) => pre.meetsParseablePrerequisites(byName[n].system.prerequisites, s);
  equal("B C1: Elemental Breath is a Wyrmdral's, not a Sparktail's; Ember Handed the reverse",
    [meets("Elemental Breath", stats(1, "Wyrmdral")), meets("Elemental Breath", stats(1, "Sparktail")), meets("Ember Handed", stats(1, "Sparktail")), meets("Ember Handed", stats(1, "Wyrmdral"))], [true, false, true, false]);
  equal("B …each heritage feat gated to its heritage", ["Ghostscale", "Runic Aptitude", "Sandstrider", "Sludge Blooded"].map((n, i) => [meets(n, stats(1, ["Wisperfin", "Glyphweave", "Dustscale", "Ironmuk"][i])), meets(n, stats(1, "Wyrmdral"))]), [[true, false], [true, false], [true, false], [true, false]]);
  equal("B the chains: Scaled Focus wants 5th level and Wyrm’s Cunning (curly ’ matched)", [meets("Scaled Focus", stats(5, "Wyrmdral", ["Wyrm’s Cunning"])), meets("Scaled Focus", stats(4, "Wyrmdral", ["Wyrm’s Cunning"])), meets("Scaled Focus", stats(5, "Wyrmdral"))], [true, false, false]);
  equal("B …Ancestral Awakening 10th and Scaled Focus; Glyph Unleashed Runic Aptitude", [meets("Ancestral Awakening", stats(10, "Wyrmdral", ["Scaled Focus"])), meets("Ancestral Awakening", stats(9, "Wyrmdral", ["Scaled Focus"])), meets("Glyph Unleashed", stats(5, "Glyphweave", ["Runic Aptitude"])), meets("Glyph Unleashed", stats(5, "Glyphweave"))], [true, false, true, false]);

  // The innate grants and Q76.
  const GRANTS = { "Alchemical Purifier": ["Stinking Cloud", "Neutralise Poison"], "Desert Wraith": ["Pass Without Trace"], "Pyrotechnic Flair": ["Burning Hands"], "Silence Unbound": ["Silence"] };
  equal("B the four innate grants, by the core's names, granted innate", Object.keys(GRANTS).map((n) => [byName[n].system.grantedSpells, F(byName[n]).grantInnate]), Object.values(GRANTS).map((s) => [s.join(", "), true]));
  ok("B …and no other feat grants a spell", C.FEATS_B5_C.filter((d) => d.system.grantedSpells).length === 4);
  const spell = (n) => corePack.spells?.find((s) => norm(s.name) === norm(n));
  equal("B every granted spell is in the core pack (PP 6, 6, 2, 2, 4)", Object.values(GRANTS).flat().map((n) => Number(spell(n)?.system?.ppCost)), [6, 6, 2, 2, 4]);
  const fd = await import(sys("module", "focus-declarations.mjs"));
  const refusal = (n, level, allowance) => fd.innateLevelRefusal({ actorType: "character", basePP: Number(spell(n)?.system?.ppCost), castLevel: level, allowance });
  equal("B Q76: the PP 6 spells at 5th level, refused without the allowance and cast with it", [Boolean(refusal("Stinking Cloud", 5, 0)), refusal("Stinking Cloud", 5, auto.PURIFIER_ALLOWANCE), refusal("Neutralise Poison", 5, auto.PURIFIER_ALLOWANCE), Boolean(refusal("Neutralise Poison", 4, auto.PURIFIER_ALLOWANCE))], [true, null, null, true]);
  equal("B …the other grants castable at their feats' 5th level as they stand", ["Pass Without Trace", "Burning Hands", "Silence"].map((n) => refusal(n, 5, 0)), [null, null, null]);
  const uses = await import(sys("module", "uses.mjs"));
  equal("B a Focus feat has the core's one use; the others none", C.FEATS_B5_C.map((d) => uses.focusDefaultUses(d.system, "feat")), C.FEATS_B5_C.map((d) => (/Focus/.test(d.system.traits) ? 1 : null)));

  // Claws of the Wyrm.
  const claws = Object.values(auto.CLAW_BY_SIZE).map((n) => corePack.companions?.find((c) => c.name === n));
  equal("B the companions pack's claws: Tiny 1d4, Small 1d5, Medium 1d6, slashing, natural", claws.map((c) => [c?.system?.size, c?.system?.damage, c?.system?.damageType, c?.system?.natural]), [["tiny", "1d4", "slashing", true], ["small", "1d5", "slashing", true], ["medium", "1d6", "slashing", true]]);

  // The conditionals, as the core reads them.
  const cond = await import(sys("module", "conditionals.mjs"));
  const n = (d, i) => cond.normaliseConditional(conds(d)[i], { name: d.name }, i);
  const all = C.FEATS_B5_C.flatMap((d) => conds(d).map((c, i) => [d.name, cond.normaliseConditional(c, { name: d.name }, i)]));
  ok("B every conditional is one the core accepts", all.length === 5 && all.every(([, c]) => Boolean(c)), JSON.stringify(all.map(([nm, c]) => [nm, Boolean(c)])));
  ok("B the racial ones are the core's \"race\" type", all.filter(([, c]) => c.kind === "modifier").every(([, c]) => c.type === "race"));
  const sludge = n(byName["Sludge Blooded"], 0), subsist = n(byName["Sludge Blooded"], 1);
  equal("B Sludge Blooded: +2 by itself on a disease's or an ingested poison's save, not an injury poison's or a skill",
    [sludge.auto, cond.matchesCheck(sludge, { checkType: "save", subject: "fortitude", traits: "Disease" }), cond.matchesCheck(sludge, { checkType: "save", subject: "fortitude", traits: "Alchemical, Consumable, Ingested, Poison" }), cond.matchesCheck(sludge, { checkType: "save", traits: "Injury, Poison" }), cond.matchesCheck(sludge, { checkType: "skill", traits: "Disease" })], [true, true, true, false, false]);
  equal("B …the Subsist tick: Culture or Survival, not Planes", [subsist.auto, subsist.value, cond.matchesCheck(subsist, { checkType: "skill", subject: "survival", actionKey: "subsist" }), cond.matchesCheck(subsist, { checkType: "skill", subject: "culture", actionKey: "subsist" }), cond.matchesCheck(subsist, { checkType: "skill", subject: "planes", actionKey: "subsist" })], [false, 2, true, true, false]);
  const wraith = n(byName["Desert Wraith"], 0);
  equal("B Desert Wraith: advantage offered on Hide, not on Sneak", [wraith.kind, wraith.auto, cond.matchesCheck(wraith, { checkType: "skill", subject: "stealth", actionKey: "hide" }), cond.matchesCheck(wraith, { checkType: "skill", subject: "stealth", actionKey: "sneak" })], ["advantage", false, true, false]);
  const ember = n(byName["Ember Handed"], 0);
  equal("B Ember Handed: +2 offered on Crafting", [ember.value, ember.auto, cond.matchesCheck(ember, { checkType: "skill", subject: "crafting" }), cond.matchesCheck(ember, { checkType: "skill", subject: "arcana" })], [2, false, true, false]);
  const runic = n(byName["Runic Aptitude"], 0);
  equal("B Runic Aptitude: +2 offered on Decipher Writing, Mysterious Script, Identify Power", [runic.auto, ...["decipherWriting", "mysteriousScript", "identifyPower", "recallKnowledge"].map((a) => cond.matchesCheck(runic, { checkType: "skill", subject: "linguistics", actionKey: a }))], [false, true, true, true, false]);
  const fire = cond.normaliseConditional(auto.emberHandedConditional(), { name: "Ember Handed" }, 0);
  equal("B the fire's +1: automatic, one-shot, an attack or a skill check, not a save", [fire?.auto, fire?.oneShot, cond.matchesCheck(fire, { checkType: "attack" }), cond.matchesCheck(fire, { checkType: "skill", subject: "crafting" }), cond.matchesCheck(fire, { checkType: "save" })], [true, true, true, true, false]);
  const actionsSrc = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "data", "skill-actions.mjs"), "utf8") + fs.readFileSync(path.join(ROOT, "module", "block1-actions.mjs"), "utf8");
  const named = new Set(C.FEATS_B5_C.flatMap((d) => conds(d).flatMap((c) => c.when?.actions ?? [])));
  ok("B every action a conditional names exists (the core's or Block 1's)", [...named].every((a) => new RegExp(`key: "${a}"`).test(actionsSrc)), JSON.stringify([...named]));

  // Effects, as the core reads them.
  const df = await import(sys("module", "defences.mjs"));
  const immune = df.resolveImmunities({ combat: { immunities: byName["Draconic Immunity"].effects[0].changes[0].value } });
  equal("B Draconic Immunity: the Sleep trait and the Paralyzed condition, nothing unread", [immune.traits.has("sleep"), immune.conditions.has("paralyzed"), immune.unresolved], [true, true, []]);
  equal("B the skill effects: racial, ADD", ["Scaelyn Scholar", "Wyrm’s Cunning", "Scaled Trickster"].map((nm) => byName[nm].effects[0].changes.map((c) => [c.key, c.mode, c.value])), [
    [["system.skills.arcana.racial", 2, "1"], ["system.skills.crafting.racial", 2, "1"]],
    [["system.skills.arcana.racial", 2, "2"]],
    [["system.skills.deception.racial", 2, "2"], ["system.skills.thievery.racial", 2, "2"]]]);
  const gs = await import(sys("module", "combat", "granted-speeds.mjs"));
  const KEYS = ["land", "fly", "burrow", "climb", "swim"];
  const speed = (d, land) => { const g = gs.grantedSpeeds([d], KEYS)[0]; return g ? [g.key, gs.grantedSpeedBase(g, land)] : null; };
  equal("B Draconic Wings: fly at the land Speed (25, 30)", [speed(byName["Draconic Wings"], 25), speed(byName["Draconic Wings"], 30)], [["fly", 25], ["fly", 30]]);
  equal("B Sandstrider (Q78): burrow at half the land Speed, rounded down to 5 ft (25, 30, 40)", [25, 30, 40].map((l) => speed(byName.Sandstrider, l)), [["burrow", 10], ["burrow", 15], ["burrow", 20]]);
  const lc = await import(sys("module", "light-check.mjs"));
  const gsf = byName.Ghostscale;
  equal("B Ghostscale: concealed at light 5 and below, not at 6, nor with no light known", [lc.lightConcealment([gsf], 5).concealed, lc.lightConcealment([gsf], 1).concealed, lc.lightConcealment([gsf], 6).concealed, lc.lightConcealment([gsf], null).concealed], [true, true, false, false]);
  equal("B …the module's restored declaration is the content's", [F(gsf).creatureAbility.derives.light, C.GHOSTSCALE_LIGHT], [auto.GHOSTSCALE_LIGHT, auto.GHOSTSCALE_LIGHT]);
  const broken = { ...gsf, flags: { "trg-prime": { ...F(gsf), creatureAbility: { derives: { light: null } } } } };
  equal("B …and nothing conceals once the module breaks it", lc.lightConcealment([broken], 2).concealed, false);
  const dcb = await import(sys("module", "magic", "spell-dc-bonus.mjs"));
  const aa = { flags: { "trg-prime": auto.ancestralEffect("fire").flags } };
  const wyrm = { flags: { "trg-prime": { spellDCBonus: { label: "Wyrmdral", value: 1, type: "untyped", traits: ["fire"] } } } };
  equal("B Ancestral Awakening: +1 to a fire spell's DC, not a cold one's; it adds to Wyrmdral's +1", [dcb.declaredSpellDCBonuses([aa], "Fire, Invocation").map((r) => r.value), dcb.declaredSpellDCBonuses([aa], "Cold").length, dcb.declaredSpellDCBonuses([aa, wyrm], ["fire"]).reduce((s, r) => s + r.value, 0)], [[1], 0, 2]);
  const oa = await import(sys("module", "combat", "one-attack.mjs"));
  const spec = oa.oneAttackSpec(auto.glyphDefence("Actor.caster").oneAttack);
  equal("B Glyph Unleashed's DB (C3): spent by that caster's spell attack, not a sword, not another caster", [oa.oneAttackUsedBy(spec, { kind: "spell", attackerUuid: "Actor.caster" }), oa.oneAttackUsedBy(spec, { kind: "weapon", attackerUuid: "Actor.caster" }), oa.oneAttackUsedBy(spec, { kind: "spell", attackerUuid: "Actor.other" })], [true, false, false]);
  const reg = await import(sys("module", "bonuses", "registry.mjs"));
  ok("B …its +2 is the racial DB slot the system pools", Boolean(reg.parseBonusKey(auto.glyphDefence().changes[0].key)) && auto.glyphDefence().changes[0].mode === 0);
  const dof = await import(sys("module", "combat", "defence-offer.mjs"));
  equal("B …the offer answers a spell attack only", [dof.defenceAnswersAttack(auto.glyphDefenceOffer.against, { kind: "spell" }), dof.defenceAnswersAttack(auto.glyphDefenceOffer.against, { kind: "weapon" }), dof.defenceAnswersAttack(auto.glyphDefenceOffer.against, { kind: "bomb" })], [true, false, false]);
  const rw = await quiet(() => import(sys("module", "reactions", "reactions-workflow.mjs")));
  const res = await import(sys("module", "dice", "resolution.mjs"));
  equal("B …its save answer (C2) is a +2 the core keeps, typed racial", [rw.reactionModifiersOf({ modifiers: auto.glyphSaveModifiers() }, "glyphUnleashed"), Boolean(res.BONUS_TYPES[auto.glyphSaveModifiers()[0].type])], [[{ label: "Glyph Unleashed", value: 2, type: "race" }], true]);
  ok("B the Wyrm Lore +2 is a specialist skill's racial slot", /^system\.specialistSkills\.[A-Za-z0-9]+\.racial$/.test(auto.wyrmLoreChange("wyrmLore").key));
  ok("B no feat clashes with a core feat's name", C.FEATS_B5_C.every((d) => !corePack.feats?.some((f) => norm(f.name) === norm(d.name))));
}

/* ----------------------------------------------------------------- */
/* C — the rules, run                                                   */
/* ----------------------------------------------------------------- */
{
  equal("C the claw for each size; none above Medium", ["tiny", "Small", "medium", "large", ""].map(auto.clawFor), ["Claws (Tiny)", "Claws (Small)", "Claws (Medium)", null, null]);
  equal("C the breath: 1d6 a level, at least 1", [0, 1, 7, 20].map(auto.breathDice), ["1d6", "1d6", "7d6", "20d6"]);
  equal("C Q77: the element is the Wyrmdral heritage's own; none without it, or with an Emberkin's", [
    auto.breathElement([{ type: "heritage", name: "Wyrmdral", flags: { "trg-prime": { eaElement: "acid" } } }]),
    auto.breathElement([{ type: "heritage", name: "Wyrmdral", flags: {} }]),
    auto.breathElement([{ type: "heritage", name: "Cinderblood", flags: { "trg-prime": { eaElement: "fire" } } }]),
    auto.breathElement([{ type: "heritage", name: "Wyrmdral", flags: { "trg-prime": { eaElement: "sonic" } } }])], ["acid", "", "", ""]);
  equal("C the five elements are Block 1's Wyrmdral's", auto.SCAELYN_ELEMENTS, B1.WYRMDRAL_ELEMENTS);
  equal("C Ancestral Awakening's rows: resistance, and the +1 to that element's DCs", auto.ancestralEffect("cold"), { changes: [{ key: "system.combat.resistances", mode: 2, value: ", cold", priority: 20 }], flags: { spellDCBonus: { label: "Ancestral Awakening", value: 1, type: "untyped", traits: ["cold"] } } });
  equal("C Ember Handed: fire that reduced HP", [{ amount: 3, damageTypes: ["fire"] }, { amount: 0, damageTypes: ["fire"] }, { amount: 4, damageTypes: ["Cold"] }, { amount: 2, damageTypes: ["Fire", "divine"] }].map(auto.emberHandedTriggered), [true, false, false, true]);
  equal("C Ghostscale breaks only where it conceals (a known light, 5 or lower)", [1, 5, 6, null, undefined, "", "4"].map(auto.ghostscaleBreaks), [true, true, false, false, false, false, true]);
  equal("C …and returns out of combat after 6 seconds, never by the clock in combat", [auto.ghostscaleReturnDue({ at: 10 }, { worldTime: 15 }), auto.ghostscaleReturnDue({ at: 10 }, { worldTime: 16 }), auto.ghostscaleReturnDue({ at: 10 }, { worldTime: 99, inCombat: true }), auto.ghostscaleReturnDue(null, { worldTime: 99 })], [false, true, false, false]);
  equal("C Q80: the ward is that spell from that caster", [auto.wardMatches({ spellName: "Fireball", sourceUuid: "A" }, "fireball", "A"), auto.wardMatches({ spellName: "Fireball", sourceUuid: "A" }, "Fireball", "B"), auto.wardMatches({ spellName: "Fireball", sourceUuid: "A" }, "Lightning Bolt", "A"), auto.wardMatches({ spellName: "", sourceUuid: "" }, "", "")], [true, false, false, false]);
  equal("C Wyrm Lore found by its label, whatever its key", [auto.specialistKeyByLabel({ x1: { label: "Astral Lore" }, wyrm2: { label: "wyrm lore" } }), auto.specialistKeyByLabel({ x1: { label: "Astral Lore" } })], ["wyrm2", null]);
  equal("C Q76's allowance is one PP", auto.PURIFIER_ALLOWANCE, 1);
}

/* ----------------------------------------------------------------- */
/* D — registration                                                     */
/* ----------------------------------------------------------------- */
const got = { autos: {}, pp: [], checks: [], offers: [], steps: [] };
const fakeApi = new Proxy({}, { get: (_, k) => {
  if (k === "registerFeatAutomation") return (n, e, m) => { got.autos[n] = [e, m]; };
  if (k === "registerPPGrant") return (n, s) => got.pp.push([n, s]);
  if (k === "registerCheckReaction") return (n, s) => got.checks.push([n, s]);
  if (k === "registerDefenceOffer") return (n, s) => got.offers.push([n, s]);
  if (k === "registerReactionStep") return (n, f) => { got.steps.push([n, f]); steps[n] = f; };
  return () => {};
} });
auto.registerBlock5C(fakeApi, "trg-eldritch-arts");
{
  equal("D the Uses registered, for the module", Object.entries(got.autos).map(([n, [, m]]) => [n, m]), Object.keys(auto.AUTOMATIONS_B5_C).map((n) => [n, "trg-eldritch-arts"]));
  ok("D …each names a feat of this group", Object.keys(got.autos).every((n) => C.FEATS_B5_C.some((d) => norm(d.name) === norm(n))));
  ok("D …each carries a use() and a hint", Object.values(got.autos).every(([e]) => typeof e.use === "function" && e.hint));
  equal("D …the Focus feats keep their own use (ownsFocusUse)", Object.entries(got.autos).filter(([, [e]]) => e.ownsFocusUse).map(([n]) => n).sort(), ["Alchemical Purifier", "Ancestral Awakening", "Elemental Breath", "Glyph Unleashed"]);
  ok("D …and every Focus feat with a Use declares it", Object.keys(got.autos).filter((n) => /Focus/.test(C.FEATS_B5_C.find((d) => norm(d.name) === norm(n)).system.traits)).every((n) => got.autos[n][0].ownsFocusUse === true));
  equal("D Scaled Focus: +1 PP per level, on the feat", got.pp.map(([n, s]) => [n, s.perLevel, s.types, s.stat ?? "pp"]), [["Scaled Focus", 1, ["feat"], "pp"]]);
  equal("D Glyph Unleashed: the check reaction, the spell-only offer, the step", [got.checks.map(([n, s]) => [n, typeof s.before]), got.offers.map(([n, s]) => [n, s.against, typeof s.use, typeof s.find]), got.steps.map(([n]) => n)], [[["glyphUnleashed", "function"]], [["Glyph Unleashed", "spell", "function", "function"]], [auto.GLYPH_STEP]]);
  const capi = await import(sys("module", "module-api.mjs"));
  const fw = await quiet(() => import(sys("module", "feats-workflow.mjs")));
  capi.resetModuleRegistry();
  for (const [nm, s] of got.pp) capi.registerPPGrant(nm, s, "test");
  const row = fw.modulePPGrants().find((r) => r.name === "scaled focus");
  equal("D …the core owes it as maximum PP, the level's worth", [row?.path, row?.due({ system: { identity: { level: 7 } } }), row?.types], ["system.resources.pp.base", 7, ["feat"]]);
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* E — the Foundry side with fakes                                      */
/* ----------------------------------------------------------------- */
const asFeat = (n, extra = {}) => ({ ...JSON.parse(JSON.stringify(byName[n])), ...extra });
const withUse = (n) => asFeat(n, { system: { ...byName[n].system, usesValue: 1 } });
const source = (e) => e.flags?.["trg-eldritch-arts"]?.source;
const A_ = (n) => auto.AUTOMATIONS_B5_C[n];
{
  // Alchemical Purifier (Q76).
  const ap = makeActor("ZZ Purifier", { items: [asFeat("Alchemical Purifier")] });
  const featId = ap.items[0].id;
  const [sc] = await ap.createEmbeddedDocuments("Item", [{ type: "spell", name: "Stinking Cloud", system: { ppCost: 6, innate: true }, flags: { "trg-prime": { grantedBy: { sourceId: featId, sourceName: "Alchemical Purifier" } } } }]);
  const [np] = await ap.createEmbeddedDocuments("Item", [{ type: "spell", name: "Neutralise Poison", system: { ppCost: 6, innate: true }, flags: { "trg-prime": { grantedBy: { sourceId: featId, sourceName: "Alchemical Purifier" } } } }]);
  const [other] = await ap.createEmbeddedDocuments("Item", [{ type: "spell", name: "Purify", system: { ppCost: 2, innate: true }, flags: { "trg-prime": { grantedBy: { sourceId: "h", sourceName: "Ironmuk" } } } }]);
  for (const i of [sc, np, other]) await auto.onItemCreatedB5C(i);
  equal("E Q76: the feat's two copies arrive with the allowance; another grant's does not", [sc, np, other].map((i) => i.flags["trg-prime"].innatePPAllowance), [1, 1, undefined]);
  delete np.flags["trg-prime"].innatePPAllowance;
  await A_("Alchemical Purifier").use(ap, ap.items[0]);
  equal("E …its Use puts a lost allowance back", np.flags["trg-prime"].innatePPAllowance, 1);

  // Ancestral Awakening.
  const aw = makeActor("ZZ Awakened", { level: 10, items: [withUse("Ancestral Awakening")] });
  answers.push("fire");
  await A_("Ancestral Awakening").use(aw, aw.items[0]);
  const ae = aw.effects.find((e) => source(e) === "ancestralAwakening");
  equal("E Ancestral Awakening: the chosen element's resistance and DC row, for 1 minute; the use spent", [ae?.changes, ae?.flags?.["trg-prime"]?.spellDCBonus?.traits, ae?.flags?.["trg-prime"]?.spellEffectEnd, aw.items[0].system.usesValue], [[{ key: "system.combat.resistances", mode: 2, value: ", fire", priority: 20 }], ["fire"], 60, 0]);
  answers.push("cold");
  await A_("Ancestral Awakening").use(aw, aw.items[0]);
  equal("E …refused once the use is spent", aw.effects.filter((e) => source(e) === "ancestralAwakening").map((e) => e.name), ["Ancestral Awakening: fire"]);
  answers.length = 0;
  const aw2 = makeActor("ZZ Awakened 2", { level: 10, items: [withUse("Ancestral Awakening")] });
  answers.push("sonic");
  await A_("Ancestral Awakening").use(aw2, aw2.items[0]);
  answers.length = 0;
  equal("E …and an element it does not print is no pick: nothing spent", [aw2.effects.length, aw2.items[0].system.usesValue], [0, 1]);

  // Claws of the Wyrm.
  const index = [{ _id: "ct", name: "Claws (Tiny)", type: "weapon", system: { damage: "1d4", damageType: "slashing", size: "tiny" } }, { _id: "cs", name: "Claws (Small)", type: "weapon", system: { damage: "1d5", damageType: "slashing", size: "small" } }, { _id: "cm", name: "Claws (Medium)", type: "weapon", system: { damage: "1d6", damageType: "slashing", size: "medium" } }];
  const companions = { collection: "trg-prime.companions", documentName: "Item", getIndex: async () => new Map(index.map((e) => [e._id, e])), getDocument: async (id) => { const e = index.find((x) => x._id === id); return e ? { toObject: () => JSON.parse(JSON.stringify(e)) } : null; } };
  game.packs = [companions];
  const cw = makeActor("ZZ Clawed", { size: "small", items: [] });
  const [claws] = await cw.createEmbeddedDocuments("Item", [asFeat("Claws of the Wyrm")]);
  await auto.onItemCreatedB5C(claws);
  const clawItems = () => cw.items.filter((i) => i.type === "weapon");
  equal("E Claws of the Wyrm: the Small claw when the feat lands, granted by it (cleanup takes it with the feat)", clawItems().map((i) => [i.name, i.flags["trg-prime"].grantedBy.sourceId === claws.id, i._id]), [["Claws (Small)", true, undefined]]);
  cw.system.identity.size = "medium";
  await A_("Claws of the Wyrm").use(cw, claws);
  equal("E …Use resizes it: one claw, the Medium", clawItems().map((i) => i.name), ["Claws (Medium)"]);
  await A_("Claws of the Wyrm").use(cw, claws);
  equal("E …and pressing it again changes nothing", clawItems().map((i) => i.name), ["Claws (Medium)"]);
  cw.system.identity.size = "large";
  cards.length = 0;
  await A_("Claws of the Wyrm").use(cw, claws);
  ok("E …a Large creature is told there is no claw for it, and keeps what it has", clawItems().length === 1 && cards.some((c) => (c.lines ?? []).some((l) => /no natural claw for a large/.test(l))));
  game.api = null;

  // Elemental Breath (Q77).
  const wyrmdral = { type: "heritage", name: "Wyrmdral", flags: { "trg-prime": { eaElement: "cold" } } };
  const br = makeActor("ZZ Breather", { level: 7, size: "medium", items: [withUse("Elemental Breath"), wyrmdral] });
  const orc = makeActor("ZZ Orc"), elf = makeActor("ZZ Elf");
  userTargets.clear(); userTargets.add({ actor: orc }); userTargets.add({ actor: elf }); userTargets.add({ actor: br });
  game.combat = { started: true, combatants: [{ actor: br }] };
  areaRuns.length = 0;
  await A_("Elemental Breath").use(br, br.items[0]);
  equal("E Elemental Breath: the Wyrmdral's cold, 1d6 a level, basic Reflex, the targets not the breather", [areaRuns[0]?.spec?.save, areaRuns[0]?.spec?.basic, areaRuns[0]?.spec?.scope, areaRuns[0]?.spec?.damage, areaRuns[0]?.spec?.dc, areaRuns[0]?.targets], ["reflex", true, "targets", { formula: "7d6", type: "cold" }, undefined, ["ZZ Orc", "ZZ Elf"]]);
  equal("E …2 AP and the Focus use spent", [br.system.resources.ap.value, br.items[0].system.usesValue], [4, 0]);
  await A_("Elemental Breath").use(br, br.items[0]);
  equal("E …not again until Refocus", [areaRuns.length, br.system.resources.ap.value], [1, 4]);
  const nb = makeActor("ZZ No Element", { level: 7, items: [withUse("Elemental Breath"), { type: "heritage", name: "Wyrmdral", flags: {} }] });
  await A_("Elemental Breath").use(nb, nb.items[0]);
  const nt = makeActor("ZZ No Target", { level: 7, items: [withUse("Elemental Breath"), wyrmdral] });
  userTargets.clear();
  await A_("Elemental Breath").use(nt, nt.items[0]);
  equal("E …refused with no element chosen, or nothing targeted: nothing spent", [areaRuns.length, nb.items[0].system.usesValue, nt.items[0].system.usesValue, nt.system.resources.ap.value], [1, 1, 1, 6]);
  const outside = makeActor("ZZ Outside", { level: 3, items: [withUse("Elemental Breath"), wyrmdral] });
  userTargets.add({ actor: orc });
  await A_("Elemental Breath").use(outside, outside.items[0]);
  equal("E …a breather outside the running combat pays no AP", [outside.system.resources.ap.value, areaRuns.at(-1)?.spec?.damage?.formula], [6, "3d6"]);
  userTargets.clear(); game.combat = null;

  // Runic Aptitude (Q79).
  const ra = makeActor("ZZ Runic", { items: [asFeat("Runic Aptitude")] });
  await A_("Runic Aptitude").use(ra, ra.items[0]);
  equal("E Runic Aptitude: any cantrip, cast with Spellcraft, not innate (Q79)", [spellChoices[0]?.spec?.ppCost, Boolean(spellChoices[0]?.spec?.innate), spellChoices[0]?.spec?.names, spellChoices[0]?.spec?.traitsAny], [0, false, undefined, undefined]);

  // Wyrm Lore.
  const sch = makeActor("ZZ Scholar", { specialist: { wyrmLore: { label: "Wyrm Lore" }, astral: { label: "Astral Lore" } } });
  const [scholar] = await sch.createEmbeddedDocuments("Item", [asFeat("Scaelyn Scholar")]);
  const [cunning] = await sch.createEmbeddedDocuments("Item", [asFeat("Wyrm’s Cunning")]);
  await auto.onItemCreatedB5C(scholar); await auto.onItemCreatedB5C(cunning);
  equal("E Scaelyn Scholar and Wyrm’s Cunning: +2 racial to Wyrm Lore each, as the feat's own effect", sch.effects.map((e) => [e.flags["trg-prime"].featSource === scholar.id ? "scholar" : e.flags["trg-prime"].featSource === cunning.id ? "cunning" : "?", e.changes]), [["scholar", [{ key: "system.specialistSkills.wyrmLore.racial", mode: 2, value: "2", priority: 20 }]], ["cunning", [{ key: "system.specialistSkills.wyrmLore.racial", mode: 2, value: "2", priority: 20 }]]]);
  await A_("Scaelyn Scholar").use(sch, scholar);
  equal("E …pressing Use again replaces, not adds", sch.effects.length, 2);
  const none = makeActor("ZZ No Lore", { specialist: {} });
  const [s2] = await none.createEmbeddedDocuments("Item", [asFeat("Scaelyn Scholar")]);
  cards.length = 0;
  await auto.onItemCreatedB5C(s2);
  ok("E …with no Wyrm Lore, nothing is written and the card says so", none.effects.length === 0 && cards.some((c) => (c.lines ?? []).some((l) => /no <strong>Wyrm Lore<\/strong>/.test(l))));
  const notMine = makeActor("ZZ Not Mine", { specialist: { wyrmLore: { label: "Wyrm Lore" } } });
  notMine.isOwner = false;
  const [s3] = await notMine.createEmbeddedDocuments("Item", [asFeat("Wyrm’s Cunning")]);
  await auto.onItemCreatedB5C(s3);
  equal("E …and a client that does not own the actor does nothing", notMine.effects.length, 0);

  // Ember Handed.
  const eh = makeActor("ZZ Sparktail", { items: [asFeat("Ember Handed")] });
  game.combat = { id: "c1", started: true, round: 2, turn: 0, turns: [{ actor: eh }], combatants: [{ actor: eh }], combatant: { actor: orc } };
  await auto.onDamageAppliedB5C({ actor: eh, amount: 3, damageTypes: ["fire"] });
  const eff = eh.effects.filter((e) => source(e) === "emberHanded");
  equal("E Ember Handed: fire damage puts the one-shot +1, to the end of the next turn", [eff.length, eff[0]?.flags?.["trg-prime"]?.conditionals?.[0]?.oneShot, eff[0]?.flags?.["trg-prime"]?.conditionals?.[0]?.value, Boolean(eff[0]?.flags?.["trg-eldritch-arts"]?.endsAfterTurn)], [1, true, 1, true]);
  await auto.onDamageAppliedB5C({ actor: eh, amount: 5, damageTypes: ["fire"] });
  equal("E …a second fire hit refreshes it: still one", eh.effects.filter((e) => source(e) === "emberHanded").length, 1);
  await auto.onDamageAppliedB5C({ actor: eh, amount: 0, damageTypes: ["fire"] });
  await auto.onDamageAppliedB5C({ actor: eh, amount: 4, damageTypes: ["cold"] });
  const plain = makeActor("ZZ Plain");
  await auto.onDamageAppliedB5C({ actor: plain, amount: 4, damageTypes: ["fire"] });
  equal("E …not for no damage, cold, or a creature without the feat", [eh.effects.length, plain.effects.length], [1, 0]);
  game.combat = null;

  // Ghostscale.
  const gh = makeActor("ZZ Wisperfin", { items: [asFeat("Ghostscale")] });
  gh.token = { id: "tG", actor: gh };
  const gi = gh.items[0];
  game.actors = [gh];
  light = 4; game.time.worldTime = 100;
  await auto.onStrikeRolledB5C({ attacker: gh, target: orc });
  equal("E Ghostscale: an attack in Dim Light breaks the concealment, and remembers when", [gi.flags["trg-prime"].creatureAbility.derives.light, gi.flags["trg-eldritch-arts"]?.ghostscaleBroken?.at], [null, 100]);
  game.time.worldTime = 103;
  await auto.onWorldTimeB5C(103);
  equal("E …not back 3 seconds later", gi.flags["trg-prime"].creatureAbility.derives.light, null);
  await auto.onWorldTimeB5C(106);
  equal("E …back after 6 seconds out of combat (acting GM)", [gi.flags["trg-prime"].creatureAbility.derives.light, gi.flags["trg-eldritch-arts"]?.ghostscaleBroken], [{ concealedAtOrBelow: 5 }, undefined]);
  light = 7;
  await auto.onSpellCastB5C({ actor: gh });
  equal("E …a cast in bright light breaks nothing (there was no concealment)", gi.flags["trg-prime"].creatureAbility.derives.light, { concealedAtOrBelow: 5 });
  light = 5;
  game.combat = { id: "c2", started: true, round: 1, turns: [{ actor: gh }, { actor: orc }], combatants: [{ actor: gh }, { actor: orc }], combatant: { actor: orc } };
  await auto.onSpellCastB5C({ actor: gh });
  await auto.onWorldTimeB5C(999);
  equal("E …a cast at light 5 breaks it; in combat the clock does not return it", gi.flags["trg-prime"].creatureAbility.derives.light, null);
  await auto.onTurnEndedB5C({ combat: game.combat });
  equal("E …another's turn starting does not either", gi.flags["trg-prime"].creatureAbility.derives.light, null);
  game.combat.combatant = { actor: gh };
  game.user.isGM = false;
  await auto.onTurnEndedB5C({ combat: game.combat });
  equal("E …only the acting GM restores it", gi.flags["trg-prime"].creatureAbility.derives.light, null);
  game.user.isGM = true;
  await auto.onTurnEndedB5C({ combat: game.combat });
  equal("E …its bearer's turn starting does", gi.flags["trg-prime"].creatureAbility.derives.light, { concealedAtOrBelow: 5 });
  await auto.onStrikeRolledB5C({ attacker: gh, target: orc });
  game.combat = null;
  await auto.onDailyPreparationB5C({ actor: gh });
  equal("E …and daily preparation makes it whole", gi.flags["trg-prime"].creatureAbility.derives.light, { concealedAtOrBelow: 5 });
  gh.token = null;
  await auto.onStrikeRolledB5C({ attacker: gh, target: orc });
  equal("E …with no token there is no light to read, and nothing breaks", gi.flags["trg-prime"].creatureAbility.derives.light, { concealedAtOrBelow: 5 });
  light = 4;

  // Glyph Unleashed (Q80).
  const caster = makeActor("ZZ Caster", { items: [{ type: "spell", name: "Fireball", system: { ppCost: 6 } }] });
  const rival = makeActor("ZZ Other Caster", { items: [{ type: "spell", name: "Fireball", system: { ppCost: 6 } }] });
  uuids.set(caster.uuid, caster); uuids.set(rival.uuid, rival);
  const gw = makeActor("ZZ Glyphweave", { items: [withUse("Glyph Unleashed")] });
  const gfeat = gw.items[0];
  game.combat = { id: "c3", started: true, round: 1, turn: 0, turns: [{ actor: caster }, { actor: gw }], combatants: [{ actor: caster }, { actor: gw }], combatant: { actor: caster } };
  game.packs = [];
  const save = (o = {}) => ({ type: "save", actor: gw, saveSource: "Fireball", sourceUuid: caster.uuid, isArea: true, label: "Reflex", ...o });
  asked.length = 0; reactorSays = "no";
  equal("E Glyph Unleashed: declined, nothing is given or spent", [await auto.glyphCheckReaction.before(save()), asked.length, gfeat.system.usesValue, gw.system.resources.reactions.value], [null, 1, 1, 1]);
  reactorSays = "yes";
  const first = await auto.glyphCheckReaction.before(save());
  equal("E …an area spell's save (Q80): asked, the ward taken — +2 racial, the reaction and the Focus use spent", [first?.modifiers, asked.length, gfeat.system.usesValue, gw.system.resources.reactions.value], [[{ label: "Glyph Unleashed", value: 2, type: "race" }], 2, 0, 0]);
  const ward = gw.effects.find((e) => source(e) === auto.GLYPH_WARD);
  equal("E …the ward: that spell, that caster, until the start of the next turn", [ward?.flags?.["trg-eldritch-arts"]?.spellName, ward?.flags?.["trg-eldritch-arts"]?.sourceUuid, Boolean(ward?.flags?.["trg-eldritch-arts"]?.endsAtTurnStart), Boolean(ward?.flags?.["trg-prime"]?.conditionExpiresRound)], ["Fireball", caster.uuid, true, true]);
  const again = await auto.glyphCheckReaction.before(save());
  equal("E …a second save against it from that caster: +2, no question", [again?.modifiers?.[0]?.value, asked.length], [2, 2]);
  equal("E …not against another caster's Fireball (the use is spent)", [await auto.glyphCheckReaction.before(save({ sourceUuid: rival.uuid })), asked.length], [null, 2]);
  equal("E …not on a skill check or an attack", [await auto.glyphCheckReaction.before(save({ type: "skill" })), await auto.glyphCheckReaction.before(save({ type: "attack" }))], [null, null]);
  const gw2 = makeActor("ZZ Glyphweave 2", { items: [withUse("Glyph Unleashed")] });
  equal("E …not when the save is no spell's (a breath, a Vir-ellian Release)", [await auto.glyphCheckReaction.before({ type: "save", actor: gw2, saveSource: "Vir-ellian Release", sourceUuid: caster.uuid }), asked.length], [null, 2]);
  game.packs = [{ collection: "trg-prime.spells", documentName: "Item", getIndex: async () => new Map([["s1", { _id: "s1", name: "Sleep", system: {}, flags: {} }]]) }];
  const fromScroll = await auto.glyphCheckReaction.before({ type: "save", actor: gw2, saveSource: "Sleep", sourceUuid: caster.uuid });
  equal("E …a spell the caster does not hold (a scroll's), found in the spells compendium", [fromScroll?.modifiers?.[0]?.value, asked.length], [2, 3]);
  const gw3 = makeActor("ZZ Glyphweave 3", { reactions: 0, items: [withUse("Glyph Unleashed")] });
  game.combat.combatants.push({ actor: gw3 });
  equal("E …in combat with no reaction left, not asked", [await auto.glyphCheckReaction.before(save({ actor: gw3 })), asked.length], [null, 3]);
  equal("E …nor with no Glyph Unleashed", await auto.glyphCheckReaction.before(save({ actor: plain })), null);
  // The DB half (C3).
  const gw4 = makeActor("ZZ Glyphweave 4", { items: [withUse("Glyph Unleashed")] });
  game.combat.combatants.push({ actor: gw4 });
  const of = auto.glyphDefenceOffer;
  equal("E the defence offer finds the feat, and is open while the use is", [of.find(gw4)?.name, of.requires(gw4, of.find(gw4))], ["Glyph Unleashed", null]);
  await of.use(gw4, of.find(gw4), { kind: "spell", what: "Fire Bolt", attackerUuid: caster.uuid });
  const db = gw4.effects.find((e) => source(e) === auto.GLYPH_DB);
  equal("E …taken: +2 racial DB against that caster's spell attack, one attack; the ward for its saves", [db?.changes, db?.flags?.["trg-prime"]?.oneAttack, gw4.effects.find((e) => source(e) === auto.GLYPH_WARD)?.flags?.["trg-eldritch-arts"]?.spellName, gfeat !== of.find(gw4) && of.find(gw4).system.usesValue, gw4.system.resources.reactions.value], [[{ key: "system.combat.defence.racial", mode: 0, value: "2", priority: 20 }], { against: "spell", fromUuids: [caster.uuid] }, "Fire Bolt", 0, 0]);
  ok("E …its name starts with the offer's, so it is not offered twice", /^glyph unleashed/i.test(db?.name ?? ""));
  equal("E …then the spell's save takes the +2 with no question; the offer is closed", [(await auto.glyphCheckReaction.before({ type: "save", actor: gw4, saveSource: "Fire Bolt", sourceUuid: caster.uuid }))?.modifiers?.[0]?.value, asked.length, typeof of.requires(gw4, of.find(gw4))], [2, 3, "string"]);
  game.combat = null;
  const gw5 = makeActor("ZZ Glyphweave 5", { reactions: 0, items: [withUse("Glyph Unleashed")] });
  await auto.glyphCheckReaction.before(save({ actor: gw5 }));
  equal("E …out of combat no reaction is spent, only the use", [gw5.items[0].system.usesValue, gw5.system.resources.reactions.value, reactionsSpent.length], [0, 0, 2]);
  cards.length = 0;
  await A_("Glyph Unleashed").use(gw5, gw5.items[0]);
  ok("E …its Use only says where it is offered", cards.some((c) => /offered when a spell/.test(c.warn ?? "")));
}

console.log(`verify-block5c: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
