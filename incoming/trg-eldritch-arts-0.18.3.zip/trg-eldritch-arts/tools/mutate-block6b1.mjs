#!/usr/bin/env node
/**
 * mutate-block6b1 — the mutation half of verify-block6b1. Each mutation breaks
 * one printed number, one reading or one wire of Block 6's group B1;
 * verify-block6b1 must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6b1.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block6-b1.mjs"), A = f("module", "block6b1-automations.mjs");

const MUTATIONS = [
  // The content
  { name: "Eternal Vigil's Death State +1", file: C, from: "export const VIGIL_DEATH_STATE = 2;", to: "export const VIGIL_DEATH_STATE = 1;" },
  { name: "Eternal Vigil's Death State is an override", file: C, from: "[{ key: \"system.combat.deathState\", mode: 2,", to: "[{ key: \"system.combat.deathState\", mode: 5," },
  { name: "Eternal Vigil's prerequisite names the unparsed birthright", file: C, from: "prerequisites: \"Eternity, Medicine 2 ranks\",", to: "prerequisites: \"Eternity Birthright, Medicine 2 ranks\"," },
  { name: "Eternal Vigil's 0 HP cast is not daily", file: C, from: "export const VIGIL_DAILY = \"1\";", to: "export const VIGIL_DAILY = \"\";" },
  { name: "G8 undone: Runeblade does not opt in", file: C, from: "flags: { eaAutomation: \"runeblade\", progressionSinceTaken: true },", to: "flags: { eaAutomation: \"runeblade\" }," },
  { name: "Fatespinner's conviction pool +2", file: C, from: "flags: { eaAutomation: \"fatespinner\", convictionPool: 1 },", to: "flags: { eaAutomation: \"fatespinner\", convictionPool: 2 }," },
  { name: "Fatespinner grants nothing", file: C, from: "    grantedAbilities: \"Foreseen Danger\",\n", to: "" },
  { name: "Q112 undone: Ferromancer's shards cover divine casts", file: C, from: "traditions: [\"arcane\"], needsPouch: true, label: \"Ferromancer\" });", to: "traditions: [\"arcane\", \"divinity\"], needsPouch: true, label: \"Ferromancer\" });" },
  { name: "Ferromancer's shards need no pouch", file: C, from: "traditions: [\"arcane\"], needsPouch: true, label: \"Ferromancer\" });", to: "traditions: [\"arcane\"], needsPouch: false, label: \"Ferromancer\" });" },
  { name: "Ferromancer grants no Shard Cloud", file: C, from: "    grantedSpells: \"Shard Cloud\",\n", to: "" },
  { name: "Leyline Weaver's +2 is status", file: C, from: "conditional({ kind: \"modifier\", value: 2, type: \"circumstance\", label: \"Leyline Weaver\"", to: "conditional({ kind: \"modifier\", value: 2, type: \"status\", label: \"Leyline Weaver\"" },
  { name: "Leyline Weaver's +2 reaches Channel Ley Line", file: C, from: "export const LEYLINE_WEAVER_ACTIONS = Object.freeze([\"leySense\", \"tapLeyLine\"]);", to: "export const LEYLINE_WEAVER_ACTIONS = Object.freeze([\"leySense\", \"tapLeyLine\", \"channelLeyLine\"]);" },
  { name: "Leyline Weaver grants nothing", file: C, from: "    grantedAbilities: \"Leyline Power\",\n", to: "" },
  { name: "Chronostasis's guard holds against a kill", file: C, from: "frequency: \"daily\", notOutright: true });", to: "frequency: \"daily\" });" },
  { name: "Chronostasis's guard is not daily", file: C, from: "askOwner: true, frequency: \"daily\", notOutright: true });", to: "askOwner: true, notOutright: true });" },
  { name: "Q110 undone: Fate's Favour refunds a Success", file: C, from: "degrees: [\"partial\", \"failure\", \"fumble\", \"blunder\"], checkTypes:", to: "degrees: [\"success\", \"critical\", \"heroic\"], checkTypes:" },
  { name: "Fate's Favour forgets saves", file: C, from: "checkTypes: [\"save\", \"skill\"], frequency: \"daily\" });", to: "checkTypes: [\"skill\"], frequency: \"daily\" });" },
  { name: "Fate's Favour is not daily", file: C, from: "checkTypes: [\"save\", \"skill\"], frequency: \"daily\" });", to: "checkTypes: [\"save\", \"skill\"] });" },
  { name: "Leyline Anchor is not daily", file: C, from: "  classFeat(\"LEYLINE ANCHOR\", {\n    usesPerDay: \"1\",", to: "  classFeat(\"LEYLINE ANCHOR\", {" },
  { name: "Leywalk grants no Ley Walker", file: C, from: "    grantedSpells: \"Ley Walker\",\n", to: "" },
  { name: "Shard Cloud rolls a save at the cast", file: C, from: "  category: \"utility\", defence: \"\",\n  // \"2 AP (metal)\"", to: "  category: \"save\", defence: \"Basic Reflex\",\n  // \"2 AP (metal)\"" },
  { name: "Shard Cloud's radius warp has no cap", file: C, from: "{ areaGrowth: 5, areaMax: 30 }", to: "{ areaGrowth: 5 }" },
  { name: "Shard Cloud's metal is no component", file: C, from: "components: { somatic: false, verbal: false, material: true, focus: false },", to: "components: { somatic: false, verbal: false, material: false, focus: false }," },
  { name: "Runeblade's card hides the missing rune", file: C, from: "**Defending I is left off** (Q117)", to: "**Defending I is built**" },
  { name: "the docs grade Leyline Anchor B", file: C, from: "\"Leyline Anchor\": { level: \"C\",", to: "\"Leyline Anchor\": { level: \"B\"," },
  // The rules
  { name: "Q108 undone: the rounds include the warp's 2", file: A, from: "export const vigilRounds = (castPP) => Math.max(1, int(castPP) - VIGIL_WARP_PP);", to: "export const vigilRounds = (castPP) => Math.max(1, int(castPP));" },
  { name: "Eternal Vigil's fast healing 3", file: A, from: "export const VIGIL_FAST_HEALING = 5;", to: "export const VIGIL_FAST_HEALING = 3;" },
  { name: "Eternal Vigil's warp on a refunded cast", file: A, from: "export const vigilWarpBought = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded &&", to: "export const vigilWarpBought = (ctx = {}) => Boolean(ctx.cast) &&" },
  { name: "Eternal Vigil's warp costs 3", file: A, from: "export const VIGIL_WARP_PP = 2;", to: "export const VIGIL_WARP_PP = 3;" },
  { name: "Eternal Vigil's warp on any spell", file: A, from: "match: Object.freeze({ traits: [\"healing\"] }),", to: "match: Object.freeze({ traits: [] })," },
  { name: "Eternal Vigil's 0 HP cast with no PP", file: A, from: "    return ppOf(actor).value >= Math.max(1, int(spell.system?.ppCost));", to: "    return true;" },
  { name: "Eternal Vigil's 0 HP cast every time", file: A, from: "    if (!feat || !spell || usesLeft(feat) <= 0) return false;\n    return ppOf", to: "    if (!feat || !spell) return false;\n    return ppOf" },
  { name: "Eternal Vigil's cast costs AP", file: A, from: "h().castSpell(actor, spell, { apPaid: true, presetTargets: Boolean(me) })", to: "h().castSpell(actor, spell, { presetTargets: Boolean(me) })" },
  { name: "Eternal Vigil spends no use", file: A, from: "  if (!result?.cast) return { cast: false };\n  await spendUse(feat);", to: "  if (!result?.cast) return { cast: false };" },
  { name: "Eternal Vigil spends the use on a failed cast", file: A, from: "  if (!result?.cast) return { cast: false };\n", to: "" },
  { name: "Iron Ward skips the trait gate", file: A, from: "    if (h().traitGate && !(await h().traitGate(actor, asAction, FEATS.ironWard))) return false;\n", to: "" },
  { name: "Iron Ward records no trait use", file: A, from: "    if (h().recordTraitUsage) await h().recordTraitUsage(actor, asAction);\n    await card(actor, FEATS.ironWard", to: "    await card(actor, FEATS.ironWard" },
  { name: "Runeblade's card hides Bane's absence from the book", file: C, from: "Bane is not offered there,", to: "Bane is offered there," },
  { name: "Eternal Vigil's cast targets nobody", file: A, from: "  const result = await (me ? withTargets([me.id], run) : run());", to: "  const result = await run();" },
  { name: "Fatespinner rerolls a Blunder", file: A, from: "  if (norm(ctx.degree) === \"blunder\") return false;\n", to: "" },
  { name: "Fatespinner rerolls an unmodified 1", file: A, from: "  return int(ctx.check?.dice?.unmodified) !== 1;", to: "  return true;" },
  { name: "Fatespinner rerolls saves", file: A, from: "  if (ctx.type !== \"skill\" || !ctx.failed) return false;", to: "  if (!ctx.failed) return false;" },
  { name: "Fatespinner's reroll spends no conviction", file: A, from: "  return { spent: Boolean(await h().spendConviction(actor)) };", to: "  return { spent: true };" },
  { name: "Damaging Gambit on a weapon attack", file: A, from: "export const gambitWants = (ctx = {}) => ctx.type === \"attack\" && norm(ctx.check?.reactionAs) === \"attack\";", to: "export const gambitWants = (ctx = {}) => ctx.type === \"attack\";" },
  { name: "Damaging Gambit gives no advantage", file: A, from: "    return { advantage: true, label: FEATS.gambit,", to: "    return { label: FEATS.gambit," },
  { name: "Foreseen Danger rolls 1d8", file: A, from: "export const FORESEEN_DIE = \"1d6\";", to: "export const FORESEEN_DIE = \"1d8\";" },
  { name: "Foreseen Danger reaches 60 ft", file: A, from: "export const FORESEEN_FEET = 30;", to: "export const FORESEEN_FEET = 60;" },
  { name: "Foreseen Danger helps its owner", file: A, from: "    if (!owner || owner === ally || t === allyToken) continue;", to: "    if (!owner) continue;" },
  { name: "Foreseen Danger helps foes", file: A, from: "    if (!allies(side(t), side(allyToken))) continue;\n", to: "" },
  { name: "Foreseen Danger with its use spent", file: A, from: "    if (!ability || usesLeft(ability) <= 0) continue;", to: "    if (!ability) continue;" },
  { name: "Foreseen Danger's toggle ignored", file: A, from: "    if (!needFeat && ability.getFlag?.(MODULE_ID, \"eaForeseenOff\")) continue;\n", to: "" },
  { name: "Foreseen Danger blind", file: A, from: "  if (actor.hasCondition?.(\"blinded\")) return \"blinded\";\n", to: "" },
  { name: "Foreseen Danger spends no reaction", file: A, from: "  if (!(await h().spendReaction?.(actor, FORESEEN, { traits: String(item.system?.traits ?? \"\") }))) return { spent: false };", to: "" },
  { name: "Foreseen Danger's toggle spends the Focus use", file: A, from: "  ownsFocusUse: true,\n", to: "" },
  { name: "Destiny's Embrace on a miss", file: A, from: "export const destinyWants = (ctx = {}) => ctx.type === \"attack\" && Boolean(ctx.succeeded) &&", to: "export const destinyWants = (ctx = {}) => ctx.type === \"attack\" &&" },
  { name: "Destiny's Embrace against an ally's attack", file: A, from: "      if (owner === ctx.actor || (attackerToken && !enemies(side(token), side(attackerToken)))) continue;", to: "      if (owner === ctx.actor) continue;" },
  { name: "Destiny's Embrace without the feat", file: A, from: "await foreseenReactors(allyToken, ctx.target, { needFeat: FEATS.destiny })", to: "await foreseenReactors(allyToken, ctx.target, { needFeat: null })" },
  { name: "Destiny's Embrace spends no Focus use", file: A, from: "  if (!(await h().spendReaction?.(actor, FEATS.destiny, { traits: String(item.system?.traits ?? \"\") }))) return { spent: false };\n  await spendUse(item);", to: "  if (!(await h().spendReaction?.(actor, FEATS.destiny, { traits: String(item.system?.traits ?? \"\") }))) return { spent: false };" },
  { name: "Living Iron at 1 PP", file: A, from: "export const LIVING_IRON_PP = 2;", to: "export const LIVING_IRON_PP = 1;" },
  { name: "Living Iron resists fire", file: A, from: "export const LIVING_IRON_TYPES = Object.freeze([\"slashing\", \"piercing\"]);", to: "export const LIVING_IRON_TYPES = Object.freeze([\"slashing\", \"piercing\", \"fire\"]);" },
  { name: "Chronostasis resists nothing", file: A, from: "  return { resist: \"all\", scope: \"instance\", line: `${esc(target.name)} is in <strong>Chronostasis</strong>", to: "  return { resist: [], scope: \"instance\", line: `${esc(target.name)} is in <strong>Chronostasis</strong>" },
  { name: "Chronostasis's hold is not a guard", file: A, from: "    system: { deathGuard: { label: \"Chronostasis (holding)\", auto: true } },", to: "    system: {}," },
  { name: "Chronostasis lasts a minute", file: A, from: "    expiry: expiryFor(\"startOfNextTurn\", actor)\n  })]);\n  await card(actor, FEATS.chronostasis", to: "    expiry: forSeconds(60)\n  })]);\n  await card(actor, FEATS.chronostasis" },
  { name: "Chronostasis answers any guard", file: A, from: "  if (ctx.label !== \"Chronostasis\" || ctx.trigger !== \"zeroHp\" || !actor) return;", to: "  if (!actor) return;" },
  { name: "Chronostasis's end gives no Dying", file: A, from: "  await actor.toggleStatusEffect?.(\"dying\", { value: 1 });", to: "" },
  { name: "Chronostasis's end ignores healing", file: A, from: "  if (int(actor.system?.resources?.hp?.value) > 1) {", to: "  if (false) {" },
  { name: "Last Horizon keeps no one conscious", file: A, from: "    [`flags.${SYSTEM_ID}.consciousWhileDying`]: effect.id,\n", to: "" },
  { name: "Last Horizon waives nothing", file: A, from: "    [`flags.${SYSTEM_ID}.dyingCheckWaived`]: { effect: effect.id, label: FEATS.lastHorizon, actNormally: true },", to: "" },
  { name: "Last Horizon does not act normally", file: A, from: "label: FEATS.lastHorizon, actNormally: true },", to: "label: FEATS.lastHorizon },"},
  { name: "Last Horizon twice in a minute", file: A, from: "  if (Number.isFinite(last) && now() - last < LAST_HORIZON_SECONDS) return;\n", to: "" },
  { name: "Last Horizon spends no use", file: A, from: "  if (!(await spendUse(feat))) return;\n  await actor.update({\n    [`flags.${SYSTEM_ID}.consciousWhileDying`]", to: "  await actor.update({\n    [`flags.${SYSTEM_ID}.consciousWhileDying`]" },
  { name: "Last Horizon's consciousness never ends", file: A, from: "  await actor.unsetFlag(SYSTEM_ID, \"consciousWhileDying\");", to: "" },
  { name: "Last Horizon ends before the waived turn", file: A, from: "  if (actor.getFlag?.(SYSTEM_ID, \"dyingCheckWaived\")) return;\n", to: "" },
  { name: "Iron Ward gives +1", file: A, from: "export const IRON_WARD_DB = 2;", to: "export const IRON_WARD_DB = 1;" },
  { name: "Iron Ward's DB is status", file: A, from: "changes: [{ key: \"system.combat.defence.circumstance\", type: \"custom\", value: String(IRON_WARD_DB), priority: 20 }],", to: "changes: [{ key: \"system.combat.defence.status\", type: \"custom\", value: String(IRON_WARD_DB), priority: 20 }]," },
  { name: "Iron Ward costs no AP", file: A, from: "    if (!(await spendAP(actor, FEATS.ironWard, 1))) return false;\n", to: "" },
  { name: "Iron Ward lasts a minute", file: A, from: "      expiry: expiryFor(\"startOfNextTurn\", actor)\n    })]);\n    if (h().recordTraitUsage) await h().recordTraitUsage(actor, asAction);\n    await card(actor, FEATS.ironWard", to: "      expiry: forSeconds(60)\n    })]);\n    if (h().recordTraitUsage) await h().recordTraitUsage(actor, asAction);\n    await card(actor, FEATS.ironWard" },
  { name: "Q122 undone: Temporal Reprieve past the level", file: A, from: "export const reprieveMax = ({ level = 0, pp = 0 } = {}) => Math.max(0, Math.min(int(level), int(pp)));", to: "export const reprieveMax = ({ level = 0, pp = 0 } = {}) => Math.max(0, int(pp));" },
  { name: "Temporal Reprieve spends no PP", file: A, from: "    await actor.update({ \"system.resources.pp.value\": ppOf(actor).value - n });\n", to: "" },
  { name: "Temporal Reprieve heals 1d6 a PP", file: A, from: "    const healed = await rollTotal(`${n}d8`);", to: "    const healed = await rollTotal(`${n}d6`);" },
  { name: "Temporal Reprieve skips the trait gate", file: A, from: "    if (h().traitGate && !(await h().traitGate(actor, asAction, item.name))) return false;\n", to: "" },
  { name: "Leywalk's +2 is circumstance", file: A, from: "  return { modifiers: [{ label: FEATS.leywalk, value: LEYWALK_BONUS, type: \"status\" }] };", to: "  return { modifiers: [{ label: FEATS.leywalk, value: LEYWALK_BONUS, type: \"circumstance\" }] };" },
  { name: "Leywalk helps every spell", file: A, from: "  if (norm(ctx.spell?.name) !== norm(LEY_WALKER) || !ownedFeat(ctx.actor, FEATS.leywalk)) return null;", to: "  if (!ownedFeat(ctx.actor, FEATS.leywalk)) return null;" },
  { name: "Ley Walker never refused", file: A, from: "  return `Ley Walker: you must be within ${LEY_WALKER_FEET} feet", to: "  return null && `Ley Walker: you must be within ${LEY_WALKER_FEET} feet" },
  { name: "Ley Walker ignores the anchor", file: A, from: "  if (ownEffects(actor, \"eaLeylineAnchor\").length) return null;\n  const token = tokenOf(actor);", to: "  const token = tokenOf(actor);" },
  { name: "Q113 undone: a Critical is not doubled", file: A, from: "  if (k === \"critical\") return { expiry: \"endOfNextTurn\", factor: 2, pp: \"1d8\" };", to: "  if (k === \"critical\") return { expiry: \"endOfNextTurn\", factor: 1, pp: \"1d8\" };" },
  { name: "Leyline Weaver's Critical regains no PP", file: A, from: "factor: 2, pp: \"1d8\" };", to: "factor: 2, pp: \"\" };" },
  { name: "Leyline Weaver's Success ends this turn", file: A, from: "  if (k === \"success\") return { expiry: \"endOfNextTurn\", factor: 1, pp: \"\" };", to: "  if (k === \"success\") return { expiry: \"endOfTurn\", factor: 1, pp: \"\" };" },
  { name: "Leyline Weaver's Partial does nothing", file: A, from: "  if (k === \"partial\") return { expiry: \"endOfTurn\", factor: 1, pp: \"\" };\n", to: "" },
  { name: "the doubling misses PP", file: A, from: "    case \"tempHP\":\n    case \"heal\":\n    case \"pp\":\n", to: "    case \"tempHP\":\n    case \"heal\":\n" },
  { name: "the doubling misses DB", file: A, from: "    case \"db\":\n    case \"spellDC\":\n", to: "    case \"spellDC\":\n" },
  { name: "Leyline Weaver's Tap for anyone", file: A, from: "  if (!ownedFeat(actor, FEATS.leylineWeaver)) return false;\n  const rung", to: "  const rung" },
  { name: "Leyline Power on a Partial", file: A, from: "  if (!SUCCESSES.includes(degree)) return;\n  const crit", to: "  const crit" },
  { name: "Leyline Power's Critical rolls 1d8", file: A, from: "      const formula = `${crit ? 2 : 1}d8${confluence ? \" + 1d8\" : \"\"}`;", to: "      const formula = `1d8${confluence ? \" + 1d8\" : \"\"}`;" },
  { name: "Confluence Master adds nothing", file: A, from: "      const formula = `${crit ? 2 : 1}d8${confluence ? \" + 1d8\" : \"\"}`;", to: "      const formula = `${crit ? 2 : 1}d8`;" },
  { name: "Leyline Power spends no Focus use", file: A, from: "      await spendUse(power);\n", to: "" },
  { name: "Leyline Power's anchored Use without an anchor", file: A, from: "    if (!ownEffects(actor, \"eaLeylineAnchor\").length) return warn(", to: "    if (false) return warn(" },
  { name: "Leyline Power's anchored Use every time", file: A, from: "    if (key && actor.getFlag?.(MODULE_ID, \"eaLeylinePowerRound\") === key) return warn(\"Leyline Power: once a round while anchored.\");\n", to: "" },
  { name: "Leyline Anchor lasts 10 minutes", file: A, from: "export const ANCHOR_SECONDS = 60;", to: "export const ANCHOR_SECONDS = 600;" },
  { name: "Leyline Anchor spends no use", file: A, from: "    await spendUse(anchor);\n", to: "" },
  { name: "Shard Cloud bites its caster", file: A, from: "    if (caster === next) continue;\n", to: "" },
  { name: "Shard Cloud reaches everyone", file: A, from: "    if (d === null || d > int(cloud.flags?.[MODULE_ID]?.feet)) continue;\n    await shardBite(caster, cloud, next", to: "    await shardBite(caster, cloud, next" },
  { name: "Shard Cloud bites on every move", file: A, from: "    if (m.entered?.[key] === round) continue;\n", to: "" },
  { name: "Shard Cloud outlives its sustain", file: A, from: "      if (!sustains(t.actor, SHARD_CLOUD)) { await t.actor.deleteEmbeddedDocuments(\"ActiveEffect\", [cloud.id]); continue; }\n", to: "" },
  { name: "Shard Cloud's bite is Fortitude", file: A, from: "target: victim, save: \"reflex\", dc: int(m.dc)", to: "target: victim, save: \"fortitude\", dc: int(m.dc)" },
  { name: "Shard Cloud's radius cap 40", file: A, from: "export const SHARD_MAX_FEET = 30;", to: "export const SHARD_MAX_FEET = 40;" },
  { name: "Shard Cloud's warp dice lost", file: A, from: "  const dice = 1 + (m ? int(m[1]) : 0);", to: "  const dice = 1;" },
  { name: "Shard Cloud's bites on every client", file: A, from: "export async function onTurnEndedB6B1(ctx = {}) {\n  if (!isActingGM()) return;", to: "export async function onTurnEndedB6B1(ctx = {}) {" },
  { name: "Runeblade's count ignores Living Sigil", file: A, from: "  if (names.has(norm(FEATS.livingSigil))) return 3;\n", to: "" },
  { name: "Runeblade's count ignores Twinflare", file: A, from: "  if (names.has(norm(FEATS.twinflare))) return 2;\n", to: "" },
  { name: "Q117 undone: Defending I offered", file: A, from: "  Object.freeze({ key: \"bane\", tier: 1, name: \"Bane\", parameter: true }),", to: "  Object.freeze({ key: \"bane\", tier: 1, name: \"Bane\", parameter: true }),\n  Object.freeze({ key: \"defending\", tier: 1, name: \"Defending I\" })," },
  { name: "Runeblade offers a chosen rune twice", file: A, from: "    const pool = RUNEBLADE_RUNES.filter((r) => !picks.some((p) => p.key === r.key));", to: "    const pool = [...RUNEBLADE_RUNES];" },
  { name: "Runeblade's Bane names no kind", file: A, from: "    return p.parameter ? `${rune.name} (${String(p.parameter).trim()})` : rune.name;", to: "    return rune.name;" },
  { name: "Runeblade asks again on its own write", file: A, from: "  if (Object.hasOwn(inf, RUNEBLADE_MARK)) return false;\n", to: "" },
  { name: "Runeblade replaces Block 4's runes", file: A, from: "  const runes = mergedRunes(base, text);", to: "  const runes = text;" },
  { name: "Runeblade's Use stacks the old Runeblade Rune", file: A, from: "    const base = mark && String(inf.runes ?? \"\") === mergedRunes(mark.base, mark.text) ? mark.base : String(inf?.runes ?? \"\");", to: "    const base = String(inf?.runes ?? \"\");" },
  { name: "Runeblade's book lacks Potency I", file: A, from: "  add({ key: \"potency\", tier: 1, name: \"Potency I\", level: levelOfRune(\"potency\", 1) });\n", to: "" },
  { name: "Runeforge Mastery's immunity stands", file: A, from: "weaponId: String(weaponId ?? \"\"), immunityAsResistance: true };", to: "weaponId: String(weaponId ?? \"\"), immunityAsResistance: false };" },
  { name: "Runeforge Mastery on every weapon", file: A, from: "runes: Array.from(keys ?? []).map(String), weaponId: String(weaponId ?? \"\"),", to: "runes: Array.from(keys ?? []).map(String), weaponId: \"\"," },
  { name: "Runeforge Mastery is never declared", file: A, from: "  if (forge && picks.length) {\n    await h().replaceFeatEffect", to: "  if (false) {\n    await h().replaceFeatEffect" },
  // Registration
  { name: "the warp is not registered", file: A, from: "  api.registerSpellWarps?.(FEATS.eternalVigil,", to: "  void (FEATS.eternalVigil," },
  { name: "Eternal Vigil's offer is not registered", file: A, from: "  api.registerUnconsciousOffer?.(\"eternalVigil\", eternalVigilOffer, moduleId);\n", to: "" },
  { name: "Living Iron is not registered", file: A, from: "  api.registerDamageReaction?.(\"livingIron\", livingIronReaction, moduleId);\n", to: "" },
  { name: "Leywalk's gate is not registered", file: A, from: "  api.registerSpellCheckGate?.(\"leywalk\", leywalkGate, moduleId);\n", to: "" },
  { name: "Ley Walker's refusal is not registered", file: A, from: "  api.registerCastRefusal?.(\"leyWalker\", leyWalkerRefusal, moduleId);\n", to: "" },
  { name: "Damaging Gambit is not registered", file: A, from: "  api.registerCheckReaction?.(\"damagingGambit\", damagingGambit, moduleId);\n", to: "" },
  { name: "the passive hints are not registered", file: A, from: "  for (const [name, hint] of Object.entries(PASSIVE_B6_B1)) api.registerPassiveAutomation?.(name, hint, moduleId);\n", to: "" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6b1.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6b1: verify-block6b1 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6b1: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6b1: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
