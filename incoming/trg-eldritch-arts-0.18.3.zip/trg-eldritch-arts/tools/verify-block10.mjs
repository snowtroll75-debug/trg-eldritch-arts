#!/usr/bin/env node
/**
 * verify-block10 — Eldritch Arts 0.17.0 (Block 10a, on TRG Prime 3.693.0):
 * Chapter 9's four relics and Dawnshield, and the Relic Bonding Ritual,
 * against the book (book-text.json) and Graham's rulings (the Block 10 audit,
 * Q211–Q220; "Go with your recommendations", 15 November 2026).
 *
 *   A  the book: the relics' tiers, Dawnshield's figures, the ritual's text
 *   B  the pure rules
 *   C  the registrations with TRG Prime
 *   D  the workflows, against stubs
 *   E  the pack
 *   F  the wiring
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block10.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const CORE = process.env.TRG_PRIME_ROOT ? path.resolve(process.env.TRG_PRIME_ROOT) : path.resolve(ROOT, "..", "trpg-prime");
let checks = 0;
const failures = [];
const ok = (label, cond, detail = "") => { checks += 1; if (!cond) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); };
const equal = (label, a, e) => ok(label, JSON.stringify(a) === JSON.stringify(e), `expected ${JSON.stringify(e)}, got ${JSON.stringify(a)}`);
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const strip = (src) => src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");

/* ------------------------------------------------------------------ */
/* A small Foundry                                                      */
/* ------------------------------------------------------------------ */

const getProperty = (o, k) => String(k).split(".").reduce((x, p) => (x == null ? undefined : x[p]), o);
const setProperty = (o, k, v) => { const ps = String(k).split("."); let x = o; for (const p of ps.slice(0, -1)) { x[p] ??= {}; x = x[p]; } x[ps.at(-1)] = v; };
const expand = (u) => { const out = {}; for (const [k, v] of Object.entries(u)) setProperty(out, k, v); return out; };
const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
const mergeInto = (a, b) => { if (!isObj(a) || !isObj(b)) return b; const out = { ...a }; for (const [k, v] of Object.entries(b)) out[k] = mergeInto(a[k], v); return out; };
let ids = 0;
const updates = [];
function makeItem(data, parent = null) {
  const item = {
    id: data._id ?? `i${(ids += 1)}`, name: data.name, type: data.type, parent, isOwner: data.isOwner ?? true,
    system: structuredClone(data.system ?? {}), flags: structuredClone(data.flags ?? {}), effects: data.effects ?? [],
    get uuid() { return `${parent?.uuid ?? "Item"}.Item.${this.id}`; },
    async update(u, options = {}) { updates.push([this.name, u]); for (const [k, v] of Object.entries(u)) setProperty(this, k, v); await fireUpdate(this, expand(u), options); return this; },
    // AS FOUNDRY DOES (found in review): an object is merged into what is stored, never replaced.
    async setFlag(scope, key, value) { this.flags[scope] ??= {}; this.flags[scope][key] = mergeInto(this.flags[scope][key], structuredClone(value)); await fireUpdate(this, { flags: { [scope]: { [key]: value } } }, {}); return this; },
    async unsetFlag(scope, key) { delete this.flags?.[scope]?.[key]; await fireUpdate(this, { flags: { [scope]: { [`-=${key}`]: null } } }, {}); return this; },
    getFlag(scope, key) { return this.flags?.[scope]?.[key]; },
    toObject() { return structuredClone({ _id: this.id, name: this.name, type: this.type, system: this.system, flags: this.flags, effects: this.effects }); }
  };
  return item;
}
let hooked = false;
const fireUpdate = async (item, changed, options) => { if (hooked) await A.onItemUpdatedB10(item, changed, options); };
function makeActor(name, { level = 5, pp = 10, gold = 1000, aligned = [] } = {}) {
  const list = [];
  const actor = {
    id: name, name, uuid: `Actor.${name}`, isOwner: true, documentName: "Actor",
    system: { identity: { level }, resources: { pp: { value: pp }, ap: { value: 6 } }, magic: { investmentSlots: 6 }, details: { get traits() { return actor.aligned.join(", "); } } },
    flags: {}, effects: [], gold, aligned, items: list,
    async createEmbeddedDocuments(kind, docs) {
      if (kind === "Item") { const made = docs.map((d) => makeItem(d, actor)); list.push(...made); return made; }
      const made = docs.map((d) => ({ ...structuredClone(d), id: `e${(ids += 1)}` })); actor.effects.push(...made); return made;
    },
    async deleteEmbeddedDocuments(kind, delIds) {
      const arr = kind === "Item" ? list : actor.effects;
      const gone = arr.filter((x) => delIds.includes(x.id));
      for (const g of gone) arr.splice(arr.indexOf(g), 1);
      if (kind === "Item" && hooked) for (const g of gone) await A.onItemDeletedB10(g);
      return gone;
    },
    async update(u) { for (const [k, v] of Object.entries(u)) setProperty(actor, k, v); return actor; },
    async updateEmbeddedDocuments(kind, rows) { for (const row of rows) { const it = list.find((i) => i.id === row._id); if (it) for (const [k, v] of Object.entries(row)) if (k !== "_id") setProperty(it, k, v); } return rows; },
    testUserPermission: () => true,
    async setFlag(s, k, v) { actor.flags[s] ??= {}; actor.flags[s][k] = structuredClone(v); },
    async unsetFlag(s, k) { delete actor.flags[s]?.[k]; },
    getFlag(s, k) { return actor.flags?.[s]?.[k]; },
    getActiveTokens: () => []
  };
  return actor;
}

// The core spell pack and the module's, as Foundry would hold them.
const DUMP = process.env.TRG_PRIME_DUMP ?? "/home/claude/b9/core-dump/spells.json";
const coreSpells = fs.existsSync(DUMP) ? JSON.parse(fs.readFileSync(DUMP, "utf8")) : [];
const eaDir = path.join(ROOT, "packs-source", "ea-spells");
const eaSpells = fs.readdirSync(eaDir).map((f) => JSON.parse(fs.readFileSync(path.join(eaDir, f), "utf8")));
const pack = (collection, docs, ext) => ({
  documentName: "Item", collection, metadata: { flags: ext ? { "trg-prime": { extends: ext } } : {} },
  getIndex: async () => new Map(docs.map((d) => [d._id, { _id: d._id, name: d.name, system: d.system, flags: d.flags }])),
  getDocument: async (id) => { const d = docs.find((x) => x._id === id); return d ? { toObject: () => structuredClone(d) } : null; }
});

globalThis.foundry = {
  utils: { getProperty, getRoute: (p) => pathToFileURL(path.join(CORE, String(p).replace(/^\/?systems\/trg-prime\//, ""))).href, fromUuid: async (u) => UUIDS.get(u) ?? null },
  applications: { api: { DialogV2: { confirm: async () => confirmAnswer } } }
};
const UUIDS = new Map();
let confirmAnswer = true;
globalThis.game = { time: { worldTime: 100000 }, user: { targets: new Set(), isGM: true }, combat: null, actors: [], settings: { get: () => null }, packs: [pack("trg-prime.spells", coreSpells), pack("trg-eldritch-arts.ea-spells", eaSpells, "spells")] };
globalThis.ui = { notifications: { warn: (t) => { warnings.push(t); } } };
const warnings = [];
const cards = [];
let chosen = null;
const effectsMade = [];
const saves = [];
let rollDegree = "success";
globalThis.game.trgPrime = { modules: { helpers: {
  line: (t) => t, postCard: async (_a, title, lines) => { cards.push([title, lines.join(" ")]); },
  chooseFromList: async (_t, _q, options) => (typeof chosen === "function" ? chosen(options) : chosen),
  goldOf: async (a) => a.gold, deductGold: async (a, n) => { a.gold -= n; },
  levelDC: (l) => 14 + Math.floor(Number(l)), // a stub; the core's table is its own
  basicSaveHit: async (o) => { saves.push(o); return { line: `${o.target.name} takes it.` }; },
  rollCheck: async (o) => { saves.push(o); return { outcome: { degree: { key: rollDegree, label: rollDegree } } }; },
  createEffectsOn: async (a, docs) => { effectsMade.push([a.name, docs]); },
  lightLevelAt: async () => 1
} } };

const api = await import(path.join(CORE, "module", "module-api.mjs"));
const R = await import(path.join(ROOT, "module", "block10-rules.mjs"));
const A = await import(path.join(ROOT, "module", "block10-automations.mjs"));
const ACT = await import(path.join(ROOT, "module", "block10-actions.mjs"));
const C = await import(path.join(ROOT, "tools", "content", "block10.mjs"));
const BOOK = JSON.parse(read("tools", "content", "book-text.json"));
const auto = strip(read("module", "block10-automations.mjs"));
const MOD = "trg-eldritch-arts";

/* ================================================================== A */
const relicsBook = BOOK.chapter9.relics;
equal("A the book prints four relics, each with rules", [relicsBook.length, relicsBook.every((r) => R.RELICS_10[r.name])], [4, true]);
equal("A each prints five tiers at 1–4, 5–8, 9–12, 13–16 and 17–20 (L10081)", relicsBook.map((r) => r.tiers.map((t) => [t.from, t.to])), relicsBook.map(() => [[1, 4], [5, 8], [9, 12], [13, 16], [17, 20]]));
{
  // Every spell the rules grant at a tier is named in that tier's printed bullets.
  const missing = [];
  for (const r of relicsBook) {
    const spec = R.RELICS_10[r.name];
    spec.tiers.forEach((t, i) => { for (const s of t.spells) if (!r.tiers[i].bullets.join(" ").toLowerCase().includes(s.toLowerCase())) missing.push(`${spec.name} ${i} ${s}`); });
  }
  equal("A every granted spell is printed at its tier", missing, []);
  const printedSpells = [];
  for (const r of relicsBook) r.tiers.forEach((t, i) => { for (const b of t.bullets) { const m = /cast (?:an? )?([A-Z][\w' ]+?) (?:as an innate spell|spell)/.exec(b); if (m) printedSpells.push([R.RELICS_10[r.name].key, i, m[1].trim()]); } });
  const ruled = new Set(Object.values(R.RELICS_10).flatMap((s) => s.tiers.flatMap((t, i) => t.spells.map((n) => `${s.key}|${i}|${n.toLowerCase()}`))));
  equal("A …and every innate spell the bullets print is granted", printedSpells.filter(([k, i, n]) => !ruled.has(`${k}|${i}|${n.toLowerCase()}`)), []);
}
equal("A the runes and quality as printed (the Aegis: Potency I/I/II/III; Emberfang: Potency I to V, Flaming I to III)",
  [[0, 1, 2, 3, 4].map((t) => R.relicStateAt(R.RELICS_10["THE AEGIS OF VALTEA"], t).runes), [0, 1, 2, 3, 4].map((t) => R.relicStateAt(R.RELICS_10.EMBERFANG, t).runes), [0, 2, 4].map((t) => R.relicStateAt(R.RELICS_10.EMBERFANG, t).quality)],
  [["Potency I", "Potency I, Benevolent", "Potency II, Benevolent", "Potency III, Benevolent", "Potency III, Benevolent"], ["Potency I", "Potency II, Flaming I", "Potency III, Flaming II", "Potency IV, Flaming III", "Potency V, Flaming III"], ["expert", "master", "legendary"]]);
{
  // Each rune a tier adds or raises is printed in that tier's bullets ("Gains the Flaming I rune", "Potency rune increases to II").
  const unprinted = [];
  for (const r of relicsBook) {
    const spec = R.RELICS_10[r.name];
    let before = [];
    spec.tiers.forEach((t, i) => {
      if (t.runes === undefined) return;
      const now = t.runes.split(",").map((x) => x.trim()).filter(Boolean);
      for (const rune of now.filter((x) => !before.includes(x))) {
        const m = /^(.*?)(?:\s+([IVX]+))?$/.exec(rune);
        const re = m[2] ? new RegExp(`${m[1]}[^.]*?\\b${m[2]}\\b`) : new RegExp(m[1]);
        if (!re.test(r.tiers[i].bullets.join(" "))) unprinted.push(`${spec.name} ${i} ${rune}`);
      }
      before = now;
    });
  }
  equal("A every rune a tier adds or raises is printed at that tier", unprinted, []);
}
const codexBook = relicsBook.find((r) => r.name === "OBSIDIAN CODEX");
ok("A the Codex's requirement: a blood sacrifice; never Good; Balance or Order suffer Dissonance", /blood sacrifice/.test(codexBook.requirement) && /cannot be bonded by Good/.test(codexBook.requirement) && /Balance or Order suffer constant Dissonance/.test(codexBook.requirement));
equal("A …in the rules", [R.RELICS_10["OBSIDIAN CODEX"].forbiddenAligned, R.RELICS_10["OBSIDIAN CODEX"].dissonance, R.RELICS_10["OBSIDIAN CODEX"].sacrifice], [["good"], ["balance", "order"], true]);
const dawnLines = BOOK.chapter9.sentient.map((l) => l.text);
ok("A Dawnshield: level 15, 38,500 gp, 10 lbs, DR 3, DB +4, HP 110, Ego 24 (DC 34), as printed",
  dawnLines.some((l) => /\*\*Level\*\* 15; \*\*Price\*\* 38,500 gp/.test(l)) && dawnLines.some((l) => /\*\*Weight\*\* 10 lbs/.test(l)) && dawnLines.some((l) => /\*\*DR\*\* 3; \*\*DB\*\* \+4; \*\*HP\*\* 110/.test(l)) && dawnLines.some((l) => /\*\*Ego\*\* 24 \(Ego DC 34\)/.test(l)));
equal("A …in the rules", [R.DAWNSHIELD.level, R.DAWNSHIELD.price, R.DAWNSHIELD.weight, R.DAWNSHIELD.stats, R.DAWNSHIELD.ego, R.DAWNSHIELD.egoDC], [15, 38500, 10, { penalty: 0, dr: 3, db: 4, hp: 110 }, 24, 34]);
equal("A Dawnshield's three Influence results are its own, verbatim", ["success", "failure", "fumble"].map((d) => dawnLines.some((l) => l.replace(/\*\*/g, "").includes(R.DAWNSHIELD.overrides[d]))), [true, true, true]);
{
  const ritual = BOOK.chapter4["RELIC BONDING RITUAL"].lines;
  const a = ACT.SKILL_ACTIONS[0];
  for (const d of ["critical", "success", "failure", "fumble"]) {
    const printed = ritual.find((l) => l.startsWith(`**${d[0].toUpperCase()}${d.slice(1)}**`));
    equal(`A the ritual's ${d}, verbatim`, a.outcomes[d], printed?.replace(/^\*\*\w+\*\*\s*/, ""));
  }
  ok("A the cost, requirement and awakening lines, verbatim", [ritual[2], ritual[3], ritual[11], ritual[12]].every((l) => a.description.includes(l.replace(/^\*\*Cost\*\* |^\*\*Requirements\*\* /, ""))));
  equal("A the skills: trained Arcana, Nature, Occultism or Religion", [a.skills, a.proficiency, /\(Trained Only\) Arcana, Nature, Occultism or Religion/.test(ritual[0])], [["arcana", "nature", "occultism", "religion"], "trained", true]);
}
{
  const spellNames = new Set([...coreSpells, ...eaSpells].map((d) => d.name.toLowerCase()));
  const all = [...Object.values(R.RELICS_10).flatMap((s) => s.tiers.flatMap((t) => t.spells)), "Cure"];
  equal("A every spell a relic or Dawnshield grants is in a pack (TRG Prime's or this module's)", coreSpells.length ? all.filter((n) => !spellNames.has(n.toLowerCase())) : [], []);
}

/* ================================================================== B */
equal("B the tier of a level", [1, 4, 5, 8, 9, 12, 13, 16, 17, 20].map(R.tierForLevel), [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]);
equal("B a tier's slots, 1 to 5", [0, 1, 2, 3, 4].map(R.slotsForTier), [1, 2, 3, 4, 5]);
equal("B the daily awakening: one tier, never past the level's", [R.awakenedAfterDay(0, 3), R.awakenedAfterDay(0, 9), R.awakenedAfterDay(1, 9), R.awakenedAfterDay(2, 9), R.awakenedAfterDay(3, 9)], [0, 1, 2, 2, 3]);
equal("B the highest tier the free slots pay for", [R.highestAffordableTier(3, 5), R.highestAffordableTier(3, 2), R.highestAffordableTier(0, 3), R.highestAffordableTier(2, 0)], [3, 1, 0, -1]);
{
  const relic = (o) => ({ system: { invested: o.invested ?? true }, flags: { [MOD]: { relic: { key: "emberfang", wielderUuid: "Actor.W", awakened: 2, investedTier: 1, ...o } } } });
  equal("B a relic costs its invested tier's slots (H27); unset, one", [R.investCostOf(relic({})), R.investCostOf(relic({ investedTier: null })), R.investCostOf(relic({ investedTier: 4 }))], [2, 1, 5]);
  equal("B a sentient item costs two (L10441); another item, no answer", [R.investCostOf({ flags: { [MOD]: { sentient: { ego: 1 } } } }), R.investCostOf({ flags: {} })], [2, null]);
  equal("B the active tier: invested and bonded, capped at the awakened; else -1 (Q215)",
    [R.activeTier(relic({})), R.activeTier(relic({ investedTier: 4 })), R.activeTier(relic({ invested: false })), R.activeTier(relic({ wielderUuid: "" })), R.activeTier(relic({ investedTier: null }))], [1, 2, -1, -1, -1]);
  equal("B bonding refusals: a recent failure; the Codex for a Good character",
    [R.bondingRefusal(relic({ refusedUntil: 200 }), { now: 100 }).startsWith("it refuses another attempt"), R.bondingRefusal({ flags: { [MOD]: { relic: { key: "obsidianCodex" } } } }, { wielderAligned: ["Good"] }).includes("Good"), R.bondingRefusal(relic({}), { now: 100 }), R.bondingRefusal({ flags: {} })],
    [true, true, "", "it is not a relic"]);
}
equal("B the bonding ladder (Q211); an unknown degree is a Failure, never a Fumble", ["heroic", "critical", "success", "partial", "failure", "fumble", "blunder", "", "nonsense"].map(R.bondingDegree), ["critical", "critical", "success", "failure", "failure", "fumble", "fumble", "failure", "failure"]);
equal("B the Fumble: 1d6 per level (Q211)", [R.bondingFumbleFormula(7), R.bondingFumbleFormula(0)], ["7d6", "1d6"]);
equal("B the cost and the waits", [R.BONDING_COST, R.BONDING_WAIT], [{ pp: 1, gp: 250 }, { failure: 86400, fumble: 604800 }]);
equal("B Dissonance: Balance or Order, the Codex only", [R.suffersDissonance("obsidianCodex", ["Balance"]), R.suffersDissonance("obsidianCodex", ["order"]), R.suffersDissonance("obsidianCodex", ["evil"]), R.suffersDissonance("obsidianCodex", []), R.suffersDissonance("emberfang", ["order"])], [true, true, false, false, false]);
{
  const aegis = R.RELICS_10["THE AEGIS OF VALTEA"];
  equal("B the plain Dormant item: its quality, trait and runes, no spells or powers (Q215)", R.relicStateAt(aegis, -1), { tier: -1, quality: "expert", superior: "Lightweight", runes: "Potency I", spells: [], powers: [] });
  equal("B the Aegis at Legendary: five spells, immunity in place of resistance, Shield of Dawn", [R.relicStateAt(aegis, 4).spells.map((s) => s.name), R.relicStateAt(aegis, 4).powers.map((p) => p.key)], [["Light", "Cure", "Restoration", "Forbiddance", "Heal"], ["aegisAura", "aegisImmune", "shieldOfDawn"]]);
  equal("B the Aegis's aura reaches you too (Q214)", [aegis.tiers[1].powers[0].self.length, aegis.tiers[1].powers[0].auras[0].radius, aegis.tiers[1].powers[0].self[0].when], [1, 10, { checkTypes: ["save"], traits: ["fear", "curse"] }]);
  equal("B every relic's immunity replaces its resistance", Object.values(R.RELICS_10).map((s) => R.relicStateAt(s, 4).powers.filter((p) => /Resist/.test(p.key)).length), [0, 0, 0, 0]);
  equal("B the Veilshroud at Legendary drinks essence (H28)", R.relicStateAt(R.RELICS_10["THE VEILSHROUD"], 4).powers.find((p) => p.absorb)?.absorb, { type: "essence", heal: 0.5 });
}
equal("B the innate allowance over the tier's first level (Undead Binding 3, Gate 3, Meteor Swarm 1, Heal 0)", [R.innateAllowance(8, 1), R.innateAllowance(20, 4), R.innateAllowance(18, 4), R.innateAllowance(16, 4)], [3, 3, 1, 0]);
equal("B Ego and its DC (L10395)", [R.egoOf({ level: 15, int: 3, wis: 4, cha: 6, powers: 3 }), R.egoDC(24)], [24, 34]);
equal("B Influence: the item's own text first, then the ladder", [R.influenceText("success", R.DAWNSHIELD.overrides).slice(0, 11), R.influenceText("partial", R.DAWNSHIELD.overrides).slice(0, 26), R.influenceText("nonsense")], ["You resist,", "The wielder resists for no", R.INFLUENCE.failure]);
equal("B Influence waits", [R.influenceRefusal({ influenceBlockedUntil: 200, blockedBy: "critical" }, 100).startsWith("its influence is suppressed"), R.influenceRefusal({ influenceBlockedUntil: 50 }, 100)], [true, ""]);

/* ================================================================== C */
api.resetModuleRegistry();
const feats = [];
const reactions = [];
A.registerBlock10({
  registerOneInvestedTraits: api.registerOneInvestedTraits, registerInvestCost: api.registerInvestCost, registerInvestRefusal: api.registerInvestRefusal, registerInvestPrepare: api.registerInvestPrepare,
  registerDamageReaction: (k, fn) => reactions.push([k, fn]), registerFeatAutomation: (n, spec) => feats.push([n, spec])
}, MOD);
A.registerInfluenceFor({ registerFeatAutomation: (n, spec) => feats.push([n, spec]) }, ["Dawnshield: Influence (GM)"], MOD);
equal("C RELIC and SENTIENT are one-invested", api.registeredOneInvestedTraits(), ["relic", "sentient"]);
equal("C the investment cost, refusal and prepare (H27)", [api.registeredInvestCosts?.().length ?? [...(api.registeredInvestCosts?.() ?? [])].length, typeof api.registeredInvestRefusals, typeof api.registeredInvestPrepares], [1, "function", "function"]);
equal("C the Veil-Drinker reaction (H28)", reactions.map(([k, fn]) => [k, fn === A.veilDrinker]), [["eaVeilDrinker", true]]);
equal("C the Uses: Shield of Dawn, the shadow step, Influence", feats.map(([n, s]) => [n, s === A.USES_10.shieldOfDawn || s === A.USES_10.shadowStep || s === A.USES_10.influence]), [["Shield of Dawn", true], ["The Veilshroud: Shadow Step", true], ["Dawnshield: Influence (GM)", true]]);

/* ================================================================== D */
const relicOf = (upper, extra = {}) => {
  const doc = C.RELIC_ITEMS_10.find((d) => d.name === R.RELICS_10[upper].name);
  const it = makeItem(structuredClone(doc));
  Object.assign(it.flags[MOD].relic, extra);
  return it;
};
const give = (actor, item) => { item.parent = actor; actor.items.push(item); UUIDS.set(item.uuid, item); return item; };
{
  const W = makeActor("Wynn", { level: 9 }); UUIDS.set(W.uuid, W);
  const P = makeActor("Priest", { level: 6, pp: 3, gold: 300 }); UUIDS.set(P.uuid, P);
  const aegis = give(W, relicOf("THE AEGIS OF VALTEA"));
  equal("D refusal: unbonded, then another's", [A.relicInvestRefusal(aegis, W), (() => { aegis.flags[MOD].relic.wielderUuid = "Actor.Else"; aegis.flags[MOD].relic.wielderName = "Else"; const r = A.relicInvestRefusal(aegis, W); aegis.flags[MOD].relic.wielderUuid = ""; return r; })()], ["bond it first (the Relic Bonding Ritual)", "it is bonded to Else"]);
  equal("D refusal: no answer for another item", A.relicInvestRefusal(makeItem({ name: "Rope", type: "gear", flags: {} }), W), "");

  // BONDING — performed by the priest for Wynn.
  chosen = null;
  let dc = await A.resolveBondingDC({ actor: P, targetActor: W });
  equal("D the DC: the Level DC of the WIELDER's level (Q211)", [dc.dc, dc.label], [23, "Level DC (Wynn, level 9)"]);
  equal("D …the plan recorded on the performer", P.flags[MOD]?.relicBondPlan, { relicUuid: aegis.uuid, wielderUuid: W.uuid, wielderName: "Wynn", wielderLevel: 9 });
  P.system.resources.pp.value = 0;
  equal("D refused: the performer's PP short (Q212)", (await A.resolveBondingDC({ actor: P, targetActor: W })).refused, "it costs 1 PP, and Priest has 0");
  P.system.resources.pp.value = 3; P.gold = 100;
  equal("D refused: the performer's purse short", (await A.resolveBondingDC({ actor: P, targetActor: W })).refused, "it costs 250 gp of incense, herbs and oils, and Priest has 100 gp");
  P.gold = 300;
  dc = await A.resolveBondingDC({ actor: P, targetActor: W });
  cards.length = 0;
  await A.onActionResolvedB10({ actor: P, action: { key: "relicBondingRitual" }, degree: "critical" });
  equal("D a Critical: bonded, awakened at once to Awakened; the performer paid", [aegis.flags[MOD].relic.wielderUuid, aegis.flags[MOD].relic.awakened, P.system.resources.pp.value, P.gold, P.flags[MOD]?.relicBondPlan], [W.uuid, 1, 2, 50, undefined]);
  ok("D …said on the card", /bonds with <strong>Wynn<\/strong>, and awakens at once to <strong>Awakened<\/strong>/.test(cards.at(-1)?.[1] ?? ""), cards.at(-1)?.[1]);
  // A relic on a character the performer may not write to is refused before anything is paid.
  const C2 = makeActor("Champion", { level: 9 }); UUIDS.set(C2.uuid, C2);
  const foreign = give(C2, relicOf("EMBERFANG")); foreign.isOwner = false;
  const pp0 = P.system.resources.pp.value, gp0 = P.gold;
  const refusedForeign = await A.resolveBondingDC({ actor: P, targetActor: C2 });
  equal("D a relic the performer cannot write to is refused, and nothing is paid", [/is carried by Champion: the performer holds it during the ritual/.test(refusedForeign.refused ?? ""), P.system.resources.pp.value, P.gold, P.flags[MOD]?.relicBondPlan], [true, pp0, gp0, undefined]);
  equal("D no unbonded relic left to bond to Wynn", (await A.resolveBondingDC({ actor: P, targetActor: W })).refused, "no unbonded relic is carried by Wynn or Priest");

  // A low-level wielder's Critical stays Dormant.
  const L = makeActor("Lowe", { level: 3 }); UUIDS.set(L.uuid, L);
  const ember = give(L, relicOf("EMBERFANG"));
  await A.resolveBondingDC({ actor: L });
  await A.onActionResolvedB10({ actor: L, action: { key: "relicBondingRitual" }, degree: "heroic" });
  equal("D a Critical for a level-3 wielder stays Dormant (\"if the wielder qualifies by level\")", [ember.flags[MOD].relic.wielderUuid, ember.flags[MOD].relic.awakened], [L.uuid, 0]);

  // Failure and Fumble.
  const F = makeActor("Fay", { level: 7 }); UUIDS.set(F.uuid, F);
  const veil = give(F, relicOf("THE VEILSHROUD"));
  await A.resolveBondingDC({ actor: F });
  await A.onActionResolvedB10({ actor: F, action: { key: "relicBondingRitual" }, degree: "partial" });
  equal("D a Partial reads Failure: not bonded, 24 hours' wait", [veil.flags[MOD].relic.wielderUuid, veil.flags[MOD].relic.refusedUntil - game.time.worldTime], ["", 86400]);
  ok("D …and the wait refuses the next attempt", /refuses another attempt for 24 more hour/.test((await A.resolveBondingDC({ actor: F })).refused ?? ""));
  veil.flags[MOD].relic.refusedUntil = 0;
  saves.length = 0;
  const P2 = makeActor("Acolyte", { level: 4, pp: 3, gold: 300 });
  await A.resolveBondingDC({ actor: P2, targetActor: F });
  await A.onActionResolvedB10({ actor: P2, action: { key: "relicBondingRitual" }, degree: "blunder" });
  equal("D a Blunder reads Fumble: the performer's level in d6 essence, on the performer, basic Fortitude at the wielder's DC; a week's wait", [saves.at(-1)?.formula, saves.at(-1)?.target?.name, saves.at(-1)?.type, saves.at(-1)?.save, saves.at(-1)?.dc, veil.flags[MOD].relic.refusedUntil - game.time.worldTime], ["4d6", "Acolyte", "essence", "fortitude", 21, 604800]);
  await A.onActionResolvedB10({ actor: F, action: { key: "otherAction" }, degree: "success" });
  equal("D another action is left alone", saves.length, 1);

  // The Codex.
  const G = makeActor("Gale", { level: 5, aligned: ["Good"] });
  const codex = give(G, relicOf("OBSIDIAN CODEX"));
  equal("D the Codex refuses a Good wielder", (await A.resolveBondingDC({ actor: G })).refused, "Obsidian Codex: it cannot be bonded by a Good-aligned character");
  G.aligned = ["Order"];
  confirmAnswer = false;
  equal("D …and asks its sacrifice", (await A.resolveBondingDC({ actor: G })).refused, "Obsidian Codex demands its sacrifice");
  confirmAnswer = true;
}

// THE TIER: syncRelic, through the item hooks.
{
  hooked = true;
  const W = makeActor("Wren", { level: 9 }); UUIDS.set(W.uuid, W);
  const aegis = give(W, relicOf("THE AEGIS OF VALTEA", { wielderUuid: "Actor.Wren", wielderName: "Wren", awakened: 2 }));
  chosen = (options) => options[1][0]; // the second-highest offered
  const free = 6;
  const out = await A.relicInvestPrepare(aegis, W, { free });
  equal("D Invest asks the tier up to the awakened (Empowered) and records the one picked, chosen below the most it could", [out, aegis.flags[MOD].relic.investedTier, aegis.flags[MOD].relic.chosenBelow], [null, 1, true]);
  equal("D …a relic needing a slot with none free is refused", (await A.relicInvestPrepare(aegis, W, { free: 0 })).refused, "it needs 1 free investment slot at least");
  updates.length = 0;
  await aegis.update({ "system.invested": true });
  const grants = W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id);
  equal("D invested at Awakened: Light and Cure granted innate and focus-ready, and the warding aura", [grants.filter((i) => i.type === "spell").map((i) => [i.name, i.system.innate, i.flags["trg-prime"].grantedBy.sourceId === aegis.id]), grants.filter((i) => i.type === "ability").map((i) => i.name)], [[["Light", true, true], ["Cure", true, true]], ["Aegis of Valtea: Warding Light"]]);
  equal("D …each with the Focus trait and one use (\"as an innate spell with the focus trait\")", grants.filter((i) => i.type === "spell").map((i) => [/\bFocus\b/.test(i.system.traits), i.system.usesPerDay, i.system.usesValue]), [[true, "", 1], [true, "", 1]]);
  equal("D …the item rewritten: Potency I and Benevolent, expert, lightweight (HP from TRG Prime's customisation)", [aegis.system.runes, aegis.system.quality, aegis.system.superiorTraits, aegis.system.hp.max, aegis.system.weight], ["Potency I, Benevolent", "expert", "lightweight", 44, 5]);
  const aura = grants.find((i) => i.type === "ability");
  equal("D …the aura and your own conditional", [aura.flags["trg-prime"].auras[0].kind, aura.flags["trg-prime"].auras[0].radius, aura.effects[0].flags["trg-prime"].conditionals[0].value, aura.effects[0].transfer], ["ally", 10, 1, true]);
  const before = W.items.length;
  await A.syncRelic(W, aegis);
  equal("D a second sync changes nothing", W.items.length, before);
  {
    // A WORLD FROM 0.17.0 (found in review): grants made under the old format are rebuilt once.
    const old = JSON.parse(aegis.flags[MOD].relicSignature); delete old.g;
    aegis.flags[MOD].relicSignature = JSON.stringify(old);
    const ids0 = W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id).map((i) => i.id).sort();
    await A.syncRelic(W, aegis);
    const ids1 = W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id).map((i) => i.id).sort();
    equal("D grants under an older format are rebuilt once, then left alone", [ids0.length === ids1.length, ids0.some((id) => ids1.includes(id)), JSON.parse(aegis.flags[MOD].relicSignature).g], [true, false, A.GRANT_FORMAT]);
  }
  await aegis.setFlag(MOD, "relic", { ...aegis.flags[MOD].relic, investedTier: 2 });
  equal("D raised to Empowered: Restoration and essence resistance join", W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id).map((i) => i.name).sort(), ["Aegis of Valtea: Essence Resistance", "Aegis of Valtea: Warding Light", "Cure", "Light", "Restoration"]);
  equal("D …the resistance as TRG Prime's change", W.items.find((i) => i.name === "Aegis of Valtea: Essence Resistance").effects[0].changes, [{ key: "system.combat.resistances", type: "add", value: ", essence", priority: 20 }]);
  W.items.find((i) => i.name === "Cure" && i.flags?.[MOD]?.relicGrant === aegis.id).system.usesValue = 0;
  aegis.system.hp.value = aegis.system.hp.max - 10;
  await aegis.setFlag(MOD, "relic", { ...aegis.flags[MOD].relic, investedTier: 1 });
  await aegis.setFlag(MOD, "relic", { ...aegis.flags[MOD].relic, investedTier: 2 });
  equal("D a rewrite keeps the day's spent uses (Cure still 0) and the shield's damage (10 below its new maximum)", [W.items.find((i) => i.name === "Cure" && i.flags?.[MOD]?.relicGrant === aegis.id)?.system.usesValue, aegis.system.hp.max - aegis.system.hp.value], [0, 10]);
  await aegis.update({ "system.invested": false });
  await aegis.update({ "system.invested": true });
  await aegis.setFlag(MOD, "relic", { ...aegis.flags[MOD].relic, investedTier: 1 });
  equal("D …and ending and redoing the investment does not refresh them", W.items.find((i) => i.name === "Cure" && i.flags?.[MOD]?.relicGrant === aegis.id)?.system.usesValue, 0);
  await aegis.update({ "system.invested": false });
  equal("D investment ended: every grant goes, the tier is forgotten, the item is the plain Dormant one", [W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id).length, aegis.flags[MOD].relic.investedTier, aegis.system.runes, aegis.system.hp.max], [0, null, "Potency I", 44]);
  aegis.system.hp.value = aegis.system.hp.max;

  // The daily preparation: awaken, and rise to what the slots pay for.
  aegis.flags[MOD].relic.awakened = 1;
  aegis.flags[MOD].relic.investedTier = 0;
  aegis.flags[MOD].relic.chosenBelow = false; // invested at the most the slots then paid
  aegis.system.invested = true;
  await A.syncRelic(W, aegis);
  cards.length = 0;
  // The GM prepares an online player's character: this client is not the elected owner, and still awakens it.
  const me = { id: "gm", active: true, isGM: true };
  game.user = Object.assign(game.user, me);
  game.users = [me, { id: "p1", active: true, isGM: false }];
  await A.onDailyPreparationB10({ actor: W });
  delete game.users;
  equal("D daily preparation: Awakened to Empowered, invested to the highest the slots pay (M98 (a))", [aegis.flags[MOD].relic.awakened, aegis.flags[MOD].relic.investedTier], [2, 2]);
  ok("D …said", /awakens to <strong>Empowered<\/strong>/.test(cards.at(-1)?.[1] ?? "") && /invested at Empowered \(3 slots\)/.test(cards.at(-1)?.[1] ?? ""), cards.at(-1)?.[1]);
  await A.onDailyPreparationB10({ actor: W });
  equal("D …at the level's tier it stops (level 9: Empowered)", aegis.flags[MOD].relic.awakened, 2);
  equal("D …and the day's kept uses are forgotten", aegis.flags[MOD].keptUses, undefined);
  await aegis.setFlag(MOD, "relic", { ...aegis.flags[MOD].relic, investedTier: 0, chosenBelow: true });
  await A.onDailyPreparationB10({ actor: W });
  equal("D a tier chosen below what the slots pay is kept at the daily preparation (M98 (a))", aegis.flags[MOD].relic.investedTier, 0);

  // A traded copy, invested by its old holder, is not the new holder's.
  const T = makeActor("Thief", { level: 9 });
  const copy = makeItem(aegis.toObject(), T); T.items.push(copy);
  equal("D a relic arriving on another creature has no powers there", R.activeTier(copy), -1);
  await A.onItemCreatedB10(copy);
  equal("D …and its old investment is ended", [copy.system.invested, T.items.filter((i) => i.flags?.[MOD]?.relicGrant === copy.id).length], [false, 0]);

  // Removing the relic takes its grants.
  const n = W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id).length;
  await W.deleteEmbeddedDocuments("Item", [aegis.id]);
  equal("D the relic deleted: its grants go with it", [n > 0, W.items.filter((i) => i.flags?.[MOD]?.relicGrant === aegis.id).length], [true, 0]);

  // The Veilshroud at Legendary: Gate once a day with the allowance; Perfect Darkvision; the drink.
  const V = makeActor("Vex", { level: 18 }); UUIDS.set(V.uuid, V);
  V.items.push(makeItem({ name: "Darkvision", type: "ability", system: {}, flags: { "trg-prime": { creatureAbility: { derives: { sense: { name: "Darkvision" } } } } } }, V));
  const veil = give(V, relicOf("THE VEILSHROUD", { wielderUuid: "Actor.Vex", wielderName: "Vex", awakened: 4, investedTier: 4 }));
  await veil.update({ "system.invested": true });
  const vg = V.items.filter((i) => i.flags?.[MOD]?.relicGrant === veil.id);
  const gate = vg.find((i) => i.name === "Gate");
  equal("D the Veilshroud at Legendary: Gate once a day, the core's allowance of 3", [gate?.system.usesPerDay, gate?.system.usesValue, gate?.flags["trg-prime"].innatePPAllowance], ["1", 1, 3]);
  {
    const O2 = makeActor("Ossian", { level: 5 }); UUIDS.set(O2.uuid, O2);
    const cx = give(O2, relicOf("OBSIDIAN CODEX", { wielderUuid: "Actor.Ossian", wielderName: "Ossian", awakened: 0, investedTier: 0 }));
    await cx.update({ "system.invested": true });
    const du = O2.items.find((i) => i.name === "Detect Undead" && i.flags?.[MOD]?.relicGrant === cx.id);
    equal("D the Codex's Detect Undead is at will (Graham's yes): unlimited, without Focus", [du?.system.usesPerDay, /\bFocus\b/.test(du?.system.traits ?? "")], ["unlimited", false]);
  }
  equal("D …Perfect Darkvision, as the wielder already sees in the dark", vg.find((i) => /Darkvision/.test(i.name))?.flags["trg-prime"].creatureAbility.derives, { sense: { name: "Perfect Darkvision", category: "primary", special: true, modality: "visual" }, light: { raisesLevelBy: 3 } });
  equal("D …the Veil I rune on the cloak", veil.system.runes, "Veil I");
  equal("D Veil-Drinker: essence ignored and half healed (H28)", await A.veilDrinker({ target: V, types: ["essence"] }), { immune: ["essence"], heal: 0.5, scope: "instance", line: "Vex's Veilshroud drinks the essence" });
  equal("D …not a fire blow, and not without the cloak's power", [await A.veilDrinker({ target: V, types: ["fire"] }), await A.veilDrinker({ target: makeActor("Bare"), types: ["essence"] })], [null, null]);
  equal("D …a spell's answer is the cast's, so a later essence packet is drunk too (TRG Prime asks once a cast)", await A.veilDrinker({ target: V, kind: "spell", types: ["fire"] }), { immune: ["essence"], heal: 0.5, scope: "cast", line: "" });

  // Dissonance.
  const O = makeActor("Orrin", { level: 5, aligned: ["Order"] });
  const codex = give(O, relicOf("OBSIDIAN CODEX"));
  await codex.setFlag(MOD, "relic", { ...codex.flags[MOD].relic, wielderUuid: O.uuid, wielderName: "Orrin" });
  equal("D the Codex bonded to an Order wielder: Dissonance, invested or not (Q220)", O.effects.filter((e) => e.flags?.[MOD]?.source === A.DISSONANCE_SOURCE).map((e) => e.flags["trg-prime"].conditionals[0].when), [{ checkTypes: ["save"], subjects: ["will"] }]);
  await O.deleteEmbeddedDocuments("Item", [codex.id]);
  equal("D …and it goes with the Codex", O.effects.filter((e) => e.flags?.[MOD]?.source === A.DISSONANCE_SOURCE).length, 0);
  hooked = false;
}

// THE USES.
{
  const S = makeActor("Sola", { level: 17 });
  const sod = makeItem({ name: "Shield of Dawn", type: "ability", system: { usesValue: 1 }, flags: {} }, S);
  effectsMade.length = 0;
  ok("D Shield of Dawn: used", await A.USES_10.shieldOfDawn.use(S, sod));
  const fx = effectsMade[0]?.[1]?.[0];
  equal("D …on you: Fast Healing 10, advantage on saves against aberrations, eternals and undead, 1 minute", [effectsMade.map((e) => e[0]), fx?.flags?.["trg-prime"]?.fastHealing, fx?.flags?.["trg-prime"]?.conditionals?.[0]?.when, fx?.flags?.["trg-prime"]?.conditionals?.[0]?.kind], [["Sola"], 10, { checkTypes: ["save"], sourceTypes: ["aberration", "eternal", "undead"] }, "advantage"]);
  equal("D …once a day", [sod.system.usesValue, await A.USES_10.shieldOfDawn.use(S, sod)], [0, false]);
  ok("D …the Evil-concealment line is by hand", /By hand: enemies with the Evil aligned trait/.test(cards.at(-1)?.[1] ?? ""));
  const step = makeItem({ name: "The Veilshroud: Shadow Step", type: "ability", system: { usesValue: 1 }, flags: {} }, S);
  equal("D the shadow step with no token on the map asks for one", await A.USES_10.shadowStep.use(S, step), false);
}

// SENTIENT: Dawnshield.
{
  hooked = true;
  const D = makeActor("Dara", { level: 15 });
  const dawn = give(D, makeItem(structuredClone(C.DAWNSHIELD_ITEM)));
  await dawn.update({ "system.invested": true });
  const dg = () => D.items.filter((i) => i.flags?.[MOD]?.relicGrant === dawn.id);
  equal("D Dawnshield invested: the fear aura, Cure once a day, and the Influence button", dg().map((i) => [i.name, i.type]).sort(), [["Cure", "spell"], ["Dawnshield: Influence (GM)", "ability"], ["Dawnshield: Morale-Steadying Light", "ability"]]);
  equal("D …the aura is +2 untyped vs fear, you and allies within 10 ft (Q214)", [dg().find((i) => /Morale/.test(i.name)).flags["trg-prime"].auras[0].allyEffect.conditionals[0].value, dg().find((i) => /Morale/.test(i.name)).effects[0].flags["trg-prime"].conditionals[0].type], [2, "untyped"]);
  const { innateCastLevel } = await import(path.join(CORE, "module", "item-innate-level.mjs"));
  // TRG Prime reads an item's level only through a Spell Effect rune's or a
  // wondrous item's own grant record, which its reconciliation would delete
  // here; so Dawnshield's Cure is cast at its wielder's level (asked of Graham).
  equal("D …Cure is cast at the shield's level 15, through TRG Prime 3.694.0's opt-in (Graham's yes); never as a Spell Effect rune's grant", [innateCastLevel(dg().find((i) => i.name === "Cure"), D.items, 12).level, dg().find((i) => i.name === "Cure").flags["trg-prime"].grantedBy.atItemLevel, Boolean(dg().find((i) => i.name === "Cure").flags["trg-prime"].spellEffectRune)], [15, true, false]);
  {
    // A relic's spell is not opted in: its level is its wielder's (Q213).
    const relicSpells = D.items.filter((i) => i.type === "spell" && i.flags?.[MOD]?.relicGrant && i.flags?.[MOD]?.relicGrant !== dawn.id);
    ok("D …while a relic's spells stay at the wielder's level", relicSpells.every((i) => !i.flags["trg-prime"].grantedBy.atItemLevel));
  }
  {
    const old = JSON.parse(dawn.flags[MOD].sentientSignature); delete old.g;
    dawn.flags[MOD].sentientSignature = JSON.stringify(old);
    const cure0 = dg().find((i) => i.name === "Cure").id;
    await A.syncSentient(D, dawn);
    ok("D a sentient item's grants under an older format are rebuilt once", dg().find((i) => i.name === "Cure").id !== cure0 && JSON.parse(dawn.flags[MOD].sentientSignature).g === A.GRANT_FORMAT);
  }
  const infl = dg().find((i) => i.name === "Dawnshield: Influence (GM)");
  game.user.isGM = false;
  equal("D Influence: a player cannot press it (Q218)", await A.USES_10.influence.use(D, infl), false);
  game.user.isGM = true;
  saves.length = 0; rollDegree = "failure"; cards.length = 0;
  await A.USES_10.influence.use(D, infl);
  equal("D the GM presses it: the wielder's Will save against Ego DC 34", [saves.at(-1)?.type, saves.at(-1)?.subject, saves.at(-1)?.dc], ["save", "will", 34]);
  ok("D …a Failure: Dawnshield's own text, and it dims", cards.at(-1)?.[1].includes(R.DAWNSHIELD.overrides.failure) && dawn.flags[MOD].sentient.dimmed === true);
  equal("D …dimmed: its powers withdrawn, the Influence button kept", dg().map((i) => i.name), ["Dawnshield: Influence (GM)"]);
  confirmAnswer = true;
  await A.USES_10.influence.use(D, D.items.find((i) => i.name === "Dawnshield: Influence (GM)"));
  equal("D the GM restores it after a protective act: its powers return", [dawn.flags[MOD].sentient.dimmed, dg().map((i) => i.name).sort()], [false, ["Cure", "Dawnshield: Influence (GM)", "Dawnshield: Morale-Steadying Light"]]);
  rollDegree = "critical";
  await A.USES_10.influence.use(D, D.items.find((i) => i.name === "Dawnshield: Influence (GM)"));
  equal("D a Critical suppresses it for 24 hours", [dawn.flags[MOD].sentient.influenceBlockedUntil - game.time.worldTime, await A.USES_10.influence.use(D, D.items.find((i) => i.name === "Dawnshield: Influence (GM)"))], [86400, false]);
  await dawn.update({ "system.invested": false });
  equal("D investment ended: everything it granted goes", dg().length, 0);
  hooked = false;
}

/* ================================================================== E */
equal("E the pack: four relics and Dawnshield", C.BLOCK10_PACKS.map((p) => [p.name, p.extends, p.docs.map((d) => d.name)]), [["ea-relics", "specific-items", ["The Aegis of Valtea", "Emberfang", "Obsidian Codex", "The Veilshroud", "Dawnshield"]]]);
equal("E each relic ships unbonded, uninvested, Dormant (Q215)", C.RELIC_ITEMS_10.map((d) => [d.system.invested, d.flags[MOD].relic.wielderUuid, d.flags[MOD].relic.awakened, d.flags[MOD].relic.investedTier]), C.RELIC_ITEMS_10.map(() => [false, "", 0, null]));
equal("E the types, weights and traits as printed", C.RELIC_ITEMS_10.map((d) => [d.type, d.system.weight, /Relic/.test(d.system.traits)]), [["shield", 5, true], ["weapon", 4, true], ["gear", 10, true], ["gear", 1, true]]);
equal("E the shield and the sword keep TRG Prime's base figures for the customisation, and skip its dialog", C.RELIC_ITEMS_10.filter((d) => d.flags["trg-prime"]?.baseCustomisation).map((d) => d.flags["trg-prime"].baseCustomisation), [{ level: 0, price: 20, hp: 12, weight: 6, category: "light", metal: true }, { level: 0, price: 10, hp: 0, weight: 4, category: "Martial" }]);
equal("E Dawnshield: a specific item, DR 3, DB 4, HP 110, level 15, fire Dragonhide (its +2 DB vs fire), two slots", [Boolean(C.DAWNSHIELD_ITEM.flags["trg-prime"].specificItem), C.DAWNSHIELD_ITEM.system.dr, C.DAWNSHIELD_ITEM.system.defenceBonus, C.DAWNSHIELD_ITEM.system.hp.max, C.DAWNSHIELD_ITEM.system.itemLevel, C.DAWNSHIELD_ITEM.system.material, C.DAWNSHIELD_ITEM.system.dragonType, R.investCostOf(C.DAWNSHIELD_ITEM)], [true, 3, 4, 110, 15, "dragonhide", "fire", 2]);
{
  // THE DORMANT FIGURES (0.17.1, found live): what TRG Prime's customisation makes of the base at the Dormant tier.
  const { computeFullCustomisation } = await import(path.join(CORE, "module", "item-quality.mjs"));
  const off = C.RELIC_ITEMS_10.filter((d) => d.flags["trg-prime"]?.baseCustomisation).map((d) => {
    const st = R.relicStateAt(R.relicSpecOf(d), -1);
    const made = computeFullCustomisation(d.type, d.flags["trg-prime"].baseCustomisation, { quality: st.quality, traitKeys: st.superior ? [st.superior.toLowerCase()] : [], runes: st.runes });
    return [d.name, d.system.hp.max, d.type === "shield" ? made.hpMax : 0, d.system.weight, made.weight];
  });
  equal("E each relic ships with its Dormant figures, as TRG Prime's customisation makes them (Aegis HP 44)", off.map(([n, hp, want, w, ww]) => [n, hp === want || (want === 0 && hp === 0), w === ww]), off.map(([n]) => [n, true, true]));
}
ok("E each description prints its tiers and says what is automated", C.RELIC_ITEMS_10.every((d) => /Dormant \(Levels 1–4\)/.test(d.system.description) && /Legendary \(Levels 17–20\)/.test(d.system.description) && /Automated \(0\.17\.\d/.test(d.system.description)));
ok("E the pack is built", fs.existsSync(path.join(ROOT, "packs-source", "ea-relics")) && fs.readdirSync(path.join(ROOT, "packs-source", "ea-relics")).length === 5);

/* ================================================================== F */
const reg = strip(read("module", "registration.mjs"));
const script = strip(read("scripts", "eldritch-arts.mjs"));
const manifest = JSON.parse(read("module.json"));
ok("F registered: the ritual, the block, Dawnshield's Influence", /registerSkillActions\(BLOCK10_ACTIONS/.test(reg) && /registerBlock10\(api, moduleId\)/.test(reg) && /registerInfluenceFor\(api, \["Dawnshield: Influence \(GM\)"\]/.test(reg));
ok("F the hooks: the ritual's degree, the daily preparation, an item updated or deleted", ["trgPrimeActionResolved\", (ctx) => { onActionResolvedB10", "trgPrimeDailyPreparation\", (ctx) => { onDailyPreparationB10", "updateItem\", (item, changed, options) => { onItemUpdatedB10", "deleteItem\", (item) => { onItemDeletedB10"].every((s) => script.includes(s)));
ok("F the item hook skips the module's own rewrite (no loop)", /if \(options\?\.eaRelicSync\) return;/.test(auto) && /item\.update\(update, \{ eaRelicSync: true \}\)/.test(auto));
ok("F only the acting owner writes", /!actor\.isOwner \|\| !actsFor\(actor\)\) return;/.test(auto));
equal("F the manifest: 0.17.0, TRG Prime 3.693.0, the pack in the folder", [manifest.version, manifest.relationships.systems[0].compatibility.minimum, manifest.packs.some((p) => p.name === "ea-relics" && p.flags["trg-prime"].extends === "specific-items"), manifest.packFolders[0].packs.includes("ea-relics")], ["0.18.3", "3.694.0", true, true]);
ok("F the module asks for 3.693.0", /REQUIRED_SYSTEM = "3\.694\.0"/.test(read("scripts", "eldritch-arts.mjs")));

console.log(`verify-block10: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exitCode = failures.length ? 1 : 0;
