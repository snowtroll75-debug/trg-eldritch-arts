#!/usr/bin/env node
/**
 * mutate-block5a — the mutation half of verify-block5a. Each mutation breaks
 * one printed number, one reading or one wire of Block 5's group A;
 * verify-block5a must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block5a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block5-a.mjs"), A = f("module", "block5a-automations.mjs");

const MUTATIONS = [
  // The content
  { name: "Chronal Awareness gives +10", file: C, from: "[{ key: \"system.combat.initiative.race\", mode: 0, value: \"20\", priority: 20 }]", to: "[{ key: \"system.combat.initiative.race\", mode: 0, value: \"10\", priority: 20 }]" },
  { name: "Chronal Awareness's bonus is circumstance", file: C, from: "key: \"system.combat.initiative.race\"", to: "key: \"system.combat.initiative.circumstance\"" },
  { name: "Q61 undone: Veil of Silence holds at Twilight", file: C, from: "export const DIM_OR_LESS = Object.freeze({ max: 5 });", to: "export const DIM_OR_LESS = Object.freeze({ max: 6 });" },
  { name: "Veil of Silence's save is Fortitude", file: C, from: "when: { checkTypes: [\"save\"], subjects: [\"reflex\"], lightLevels: DIM_OR_LESS }", to: "when: { checkTypes: [\"save\"], subjects: [\"fortitude\"], lightLevels: DIM_OR_LESS }" },
  { name: "Moonlight Precision forgets Twilight", file: C, from: "export const DIM_OR_TWILIGHT = Object.freeze([5, 6]);", to: "export const DIM_OR_TWILIGHT = Object.freeze([5]);" },
  { name: "Moonlight Precision's attacks are melee", file: C, from: "attackModes: [\"ranged\"], lightLevels: DIM_OR_TWILIGHT", to: "attackModes: [\"melee\"], lightLevels: DIM_OR_TWILIGHT" },
  { name: "Moonlight Precision's Spellcraft row holds in any light", file: C, from: "when: { checkTypes: [\"spellcraft\"], lightLevels: DIM_OR_TWILIGHT }", to: "when: { checkTypes: [\"spellcraft\"] }" },
  { name: "Starseer’s Intuition reads Divination", file: C, from: "when: { checkTypes: [\"spellcraft\"], traits: [\"insight\"] }", to: "when: { checkTypes: [\"spellcraft\"], traits: [\"divination\"] }" },
  { name: "Starseer’s Intuition's Sense Motive is lost", file: C, from: "effects: [skills([\"Sense Motive\"])],", to: "effects: []," },
  { name: "Starseer’s Sight's tick is automatic", file: C, from: "scope: \"Saving throws against an effect with the mental trait — tick if this save is one\", auto: false,", to: "scope: \"Saving throws against an effect with the mental trait — tick if this save is one\", auto: true," },
  { name: "Radiant Presence reaches 20 ft", file: C, from: "kind: \"ally\", radius: 10, name: \"Radiant Presence\",", to: "kind: \"ally\", radius: 20, name: \"Radiant Presence\"," },
  { name: "Radiant Presence's fear row is a status bonus", file: C, from: "label: \"Radiant Presence\", scope: \"Saving throws against effects with the fear trait\"", to: "type: \"status\", label: \"Radiant Presence\", scope: \"Saving throws against effects with the fear trait\"" },
  { name: "Radiant Bulwark's DB is status", file: C, from: "allyEffect: { changes: [{ key: \"system.combat.defence.circumstance\", value: \"1\" }] }", to: "allyEffect: { changes: [{ key: \"system.combat.defence.status\", value: \"1\" }] }" },
  { name: "Astral Drift eases every terrain", file: C, from: "flags: { ignoresDifficultTerrain: \"magical\", eaAutomation: \"astralDrift\" },", to: "flags: { ignoresDifficultTerrain: true, eaAutomation: \"astralDrift\" }," },
  { name: "Q59 undone: Unbound declares nothing", file: C, from: "flags: { forbiddenSparesHighMagic: true },", to: "flags: {}," },
  { name: "Skyborne Waltz's Feather Fall is not innate", file: C, from: "  grantedSpells: \"Feather Fall\",\n    flags: { grantInnate: true },", to: "  grantedSpells: \"Feather Fall\",\n    flags: {}," },
  { name: "Veil of Dusk grants Silence", file: C, from: "grantedSpells: \"Darkness\",", to: "grantedSpells: \"Silence\"," },
  { name: "Q60 undone: the Quiliesh is an Ascendan feat", file: C, from: "sourceRace: \"Human\",", to: "sourceRace: \"Ascendan\"," },
  { name: "the Quiliesh gains no Forbidden Magic", file: C, from: "grantedAbilities: \"Forbidden Magic\",", to: "grantedAbilities: \"\"," },
  { name: "Feyblood Glamour gives Diplomacy", file: C, from: "effects: [skills([\"Deception\", \"Perform\"])],", to: "effects: [skills([\"Deception\", \"Diplomacy\"])]," },
  { name: "Aetherial Scholar gives +2 to Arcana", file: C, from: "effects: [skills([\"Arcana\", \"Occultism\"])],\n    automation: \"*Automated:* +1 racial to Arcana", to: "effects: [skills([\"Arcana\", \"Occultism\"], 2)],\n    automation: \"*Automated:* +1 racial to Arcana" },
  { name: "Endless Adaptation is not once a day", file: C, from: "  racialFeat(\"ENDLESS ADAPTATION\", {\n    usesPerDay: \"1\",", to: "  racialFeat(\"ENDLESS ADAPTATION\", {" },
  { name: "Q94 undone: Resonant Pulse's card says item casts again", file: C, from: "It reaches learned and innate casts; not a charged item's spell", to: "It reaches innate and item casts too; not a charged item's spell" },
  { name: "Resonant Harmony is graded D again", file: C, from: "\"Resonant Harmony\": { level: \"B\",", to: "\"Resonant Harmony\": { level: \"D\"," },
  { name: "the docs grade Unbound D", file: C, from: "\"Unbound\": { level: \"A\",", to: "\"Unbound\": { level: \"D\"," },
  // The rules
  { name: "Aetherial Concord reaches 60 ft", file: A, from: "export const CONCORD_FEET = 30;", to: "export const CONCORD_FEET = 60;" },
  { name: "Aetherial Concord answers an item's spell", file: A, from: "export const concordDue = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded && !ctx.itemCast;", to: "export const concordDue = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded;" },
  { name: "Aetherial Concord answers a failed cast", file: A, from: "export const concordDue = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded && !ctx.itemCast;", to: "export const concordDue = (ctx = {}) => !ctx.refunded && !ctx.itemCast;" },
  { name: "Aetherial Concord's +2 is never spent", file: A, from: "auto: true, oneShot: true, when: { checkTypes: [\"save\", \"skill\"] } }];", to: "auto: true, when: { checkTypes: [\"save\", \"skill\"] } }];" },
  { name: "Aetherial Concord's +2 lasts for ever", file: A, from: "    expiry: expiryFor(\"endOfNextTurn\", ally)\n", to: "" },
  { name: "Aetherial Concord spends no use", file: A, from: "  if (!(await spendUse(feat))) return;\n  const ally = token.actor;", to: "  const ally = token.actor;" },
  { name: "Aetherial Concord offers the foes", file: A, from: "t.actor !== me?.actor && allies(sides(t), sides(me)));", to: "t.actor !== me?.actor);" },
  { name: "Astral Crossing on another's turn", file: A, from: "  if (!ownTurn) return \"only at the start of your own turn.\";\n", to: "" },
  { name: "Astral Crossing after AP are spent", file: A, from: "  return acted ? \"only at the start of your turn, before you have spent any AP.\" : \"\";", to: "  return \"\";" },
  { name: "Astral Crossing lasts 1 minute", file: A, from: "      expiry: expiryFor(\"startOfNextTurn\", actor)\n    })]);\n    await card(actor, \"Astral Crossing\"", to: "      expiry: forSeconds(60)\n    })]);\n    await card(actor, \"Astral Crossing\"" },
  { name: "Q62 undone: Astral Step costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Astral Step\", 1))) return false;\n", to: "" },
  { name: "Astral Step reaches twice the speed", file: A, from: "    const feet = landSpeedFeet(actor);", to: "    const feet = 2 * landSpeedFeet(actor);" },
  { name: "Astral Drift's Step after 2 AP", file: A, from: "export const DRIFT_AP = 3;", to: "export const DRIFT_AP = 2;" },
  { name: "Astral Drift's Step provokes", file: A, from: "{ maxFeet: STEP_FEET, speedKey: \"land\", provokes: false, note: \"Astral Drift: a free Step\" }", to: "{ maxFeet: STEP_FEET, speedKey: \"land\", note: \"Astral Drift: a free Step\" }" },
  { name: "Astral Drift's Step is offered every move", file: A, from: "if (drift && driftStepDue(moved) && (await onceThisTurn(actor, \"astralDrift\"))) {", to: "if (drift && driftStepDue(moved)) {" },
  { name: "a Movement-trait action is not counted", file: A, from: "  if (!/\\bmovement\\b/i.test(String(ctx.action?.traits ?? \"\"))) return;\n", to: "  return;\n" },
  { name: "another user's move is read here", file: A, from: "  if (userId && userId !== globalThis.game?.user?.id) return;\n", to: "" },
  { name: "movement is read on another's turn", file: A, from: "  if (!actor?.isOwner || !ownTurn(actor)) return;\n  const drift", to: "  if (!actor?.isOwner) return;\n  const drift" },
  { name: "Skyborne Agility at 10 ft", file: A, from: "export const SKYBORNE_FEET = 15;", to: "export const SKYBORNE_FEET = 10;" },
  { name: "Skyborne Agility's DB is status", file: A, from: "changes: [{ key: \"system.combat.defence.circumstance\", type: \"custom\", value: String(SKYBORNE_DB), priority: 20 }],", to: "changes: [{ key: \"system.combat.defence.status\", type: \"custom\", value: String(SKYBORNE_DB), priority: 20 }]," },
  { name: "Shadow's Discipline's Hide at 15 ft", file: A, from: "export const SHADOW_HIDE_FEET = 10;", to: "export const SHADOW_HIDE_FEET = 15;" },
  { name: "Shadow's Discipline gives Fortitude", file: A, from: "[{ key: \"system.combat.saves.reflex.racial\", type: \"add\", value: String(SHADOW_REFLEX), priority: 20 }]", to: "[{ key: \"system.combat.saves.fortitude.racial\", type: \"add\", value: String(SHADOW_REFLEX), priority: 20 }]" },
  { name: "Shadow's Discipline outlives the stance", file: A, from: "    const ids = ownEffects(actor, \"shadowsDiscipline\").map((e) => e.id);\n    if (ids.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", ids);", to: "" },
  { name: "Shadow's Discipline without the feat", file: A, from: "if (isShadowStance(effect) && ownedFeat(actor, \"Shadow’s Discipline\") && !ownEffects", to: "if (isShadowStance(effect) && !ownEffects" },
  { name: "Q65 undone: no +2 on a skill that is not a class skill", file: A, from: "(isClassSkill ? 2 : Math.max(0, int(classBonus)) + 2)", to: "(isClassSkill ? 2 : Math.max(0, int(classBonus)))" },
  { name: "Endless Adaptation reaches every skill", file: A, from: "when: { checkTypes: [\"skill\"], subjects: [skill] } }];", to: "when: { checkTypes: [\"skill\"] } }];" },
  { name: "Endless Adaptation spends no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    await h().replaceFeatEffect(actor, item, {\n      name: `Endless Adaptation", to: "    await h().replaceFeatEffect(actor, item, {\n      name: `Endless Adaptation" },
  { name: "Ancestral Reverie gives +1", file: A, from: "export const REVERIE_BONUS = 2;", to: "export const REVERIE_BONUS = 1;" },
  { name: "Ancestral Reverie lasts past the day", file: A, from: "    changes: reverieChanges(row[0])\n  }, { dailyPrep: true });", to: "    changes: reverieChanges(row[0])\n  });" },
  { name: "Ancestral Reverie is not asked at daily preparation", file: A, from: "  if (reverie) await chooseReverie(", to: "  if (false) await chooseReverie(" },
  { name: "Q63 undone: a quarter of the PP", file: A, from: "export const ASCENDANCE_PP_FACTOR = 0.5;", to: "export const ASCENDANCE_PP_FACTOR = 0.25;" },
  { name: "Resonant Ascendance halves any Dispel", file: A, from: "  const itemId = String(ctx?.presetDispel?.eaResonantAscendance ?? \"\");\n  if (!itemId) return null;", to: "  const itemId = String(ctx?.presetDispel?.eaResonantAscendance ?? \"any\");" },
  { name: "Resonant Ascendance spends no Focus use", file: A, from: "ppFactor: ASCENDANCE_PP_FACTOR, focus: true, itemId };", to: "ppFactor: ASCENDANCE_PP_FACTOR, itemId };" },
  { name: "Resonant Ascendance reaches 60 ft", file: A, from: "export const ASCENDANCE_FEET = 30;", to: "export const ASCENDANCE_FEET = 60;" },
  { name: "Resonant Ascendance's Dispel costs AP", file: A, from: "h().resolveAction(actor, { ...dispel, apCost: \"0\" }, {\n    presetDispel:", to: "h().resolveAction(actor, dispel, {\n    presetDispel:" },
  { name: "Resonant Ascendance's Dispel is not marked", file: A, from: "counterSpell: true, eaResonantAscendance: item.id", to: "counterSpell: true, eaUnmarked: item.id" },
  { name: "Resonant Ascendance untrained", file: A, from: "    if (!canDispel(reactor) || reactor.hasCondition?.(\"fixated\")) continue;", to: "    if (reactor.hasCondition?.(\"fixated\")) continue;" },
  { name: "Resonant Ascendance's Dispel names no caster (review)", file: A, from: "      casterUuid: String(data?.casterUuid ?? \"\"), spellUuid: String(data?.spellUuid ?? \"\"),\n", to: "" },
  { name: "Resonant Ascendance's Dispel is not a counter (review)", file: A, from: "      counterSpell: true, eaResonantAscendance: item.id", to: "      eaResonantAscendance: item.id" },
  { name: "Resonant Ascendance asks without the caster's uuid (review)", file: A, from: "casterUuid: caster.uuid ?? \"\", spellUuid: ctx.spell?.uuid ?? \"\", itemId: feat.id }", to: "itemId: feat.id }" },
  { name: "a refused reaction discards the rolled Dispel (review)", file: A, from: "  if (!spent) await card(actor, \"Resonant Ascendance\"", to: "  if (!spent) return { rolled: false };\n  if (!spent) await card(actor, \"Resonant Ascendance\"" },
  { name: "Resonant Ascendance blind", file: A, from: "  if (actor.hasCondition?.(\"blinded\")) return \"blinded\";\n", to: "" },
  { name: "Resonant Ascendance spends no reaction", file: A, from: "  const spent = Boolean(await h().spendReaction?.(actor, \"Resonant Ascendance\", { traits: String(item.system?.traits ?? \"\") }));", to: "  const spent = true;" },
  { name: "Resonant Ascendance with its use spent", file: A, from: "    if (!feat || usesLeft(feat) <= 0) continue;\n    const d = feetBetween(reactorToken, casterToken);", to: "    if (!feat) continue;\n    const d = feetBetween(reactorToken, casterToken);" },
  { name: "Chronal Echo answers a miss", file: A, from: "export const chronalEchoWants = (ctx = {}) => ctx.type === \"attack\" && Boolean(ctx.succeeded) &&", to: "export const chronalEchoWants = (ctx = {}) => ctx.type === \"attack\" &&" },
  { name: "Chronal Echo spends no use", file: A, from: "  if (!(await h().spendReaction?.(actor, \"Chronal Echo\", { traits: String(item.system?.traits ?? \"\") }))) return { spent: false };\n  await spendUse(item);", to: "  if (!(await h().spendReaction?.(actor, \"Chronal Echo\", { traits: String(item.system?.traits ?? \"\") }))) return { spent: false };" },
  { name: "Chronal Echo asked though the reaction is refused", file: A, from: "  return (await h().reactionRefusal?.(actor, traits)) || \"\";", to: "  return \"\";" },
  { name: "Veil of Honour answers a ranged Strike", file: A, from: "payload.context?.kind === \"strike\" && payload.context?.melee === true &&", to: "payload.context?.kind === \"strike\" &&" },
  { name: "Veil of Honour asks every packet", file: A, from: "  if (now - (recentlyAsked.get(key) ?? 0) < 2000) return;\n", to: "" },
  { name: "Veil of Honour's stance costs 1 AP", file: A, from: "h().enterShadowStance(actor, { apCost: 0, ignoreOpen: true })", to: "h().enterShadowStance(actor, { apCost: 1, ignoreOpen: true })" },
  { name: "Veil of Honour re-enters the stance it is in", file: A, from: "  if (inShadowStance(actor)) {\n    // \"if already", to: "  if (false) {\n    // \"if already" },
  { name: "Veil of Honour's Daze costs AP", file: A, from: "h().castSpell(actor, temp, { apPaid: true, presetTargets: true })", to: "h().castSpell(actor, temp, { presetTargets: true })" },
  { name: "Veil of Honour's Daze is not innate", file: A, from: "    daze.system = { ...daze.system, innate: true, usesPerDay: \"\", usesValue: 0 };", to: "    daze.system = { ...daze.system, usesPerDay: \"\", usesValue: 0 };" },
  { name: "Veil of Honour spends no use", file: A, from: "  if (!(await h().spendReaction?.(actor, \"Veil of Honour\", { traits }))) return { done: false };\n  await spendUse(item);", to: "  if (!(await h().spendReaction?.(actor, \"Veil of Honour\", { traits }))) return { done: false };" },
  { name: "the targets are not put back", file: A, from: "  } finally {\n    set(previous);\n  }", to: "  } finally {\n  }" },
  { name: "Relentless Will waives every Dying", file: A, from: "  if (!ownedFeat(actor, \"Relentless Will\") || !ownEffects(actor, RELENTLESS_ARMED).length) return null;", to: "  if (!ownedFeat(actor, \"Relentless Will\")) return null;" },
  { name: "Relentless Will marks every Dying of the day", file: A, from: "    if (!feat || usesLeft(feat) <= 0 || ownEffects(actor, RELENTLESS_ARMED).length) return;", to: "    if (!feat || ownEffects(actor, RELENTLESS_ARMED).length) return;" },
  { name: "Relentless Will's advantage is never spent", file: A, from: "label: \"Relentless Will\", scope: \"your next saving throw within 1 minute\", auto: true, oneShot: true,", to: "label: \"Relentless Will\", scope: \"your next saving throw within 1 minute\", auto: true," },
  { name: "Relentless Will's advantage lasts 10 minutes", file: A, from: "export const RELENTLESS_ADVANTAGE_SECONDS = 60;", to: "export const RELENTLESS_ADVANTAGE_SECONDS = 600;" },
  { name: "Relentless Will's advantage at 0 HP", file: A, from: "    if (Number(actor.system?.resources?.hp?.value ?? 0) > 0) await layRelentlessAdvantage(actor);", to: "    if (true) await layRelentlessAdvantage(actor);" },
  { name: "Relentless Will's wait never ends", file: A, from: "  const pending = ownEffects(actor, RELENTLESS_PENDING);\n  if (!pending.length) return;", to: "  const pending = [];\n  if (!pending.length) return;" },
  { name: "Radiant Presence's light raises 1 step", file: A, from: "label: \"Radiant Presence\", item: \"Radiant Presence\", steps: 2,", to: "label: \"Radiant Presence\", item: \"Radiant Presence\", steps: 1," },
  { name: "Radiant Presence's light is not laid", file: A, from: "      system: { lightSource: RADIANT_LIGHT.key }", to: "      system: {}" },
  { name: "Radiant Presence's light outlives the feat", file: A, from: "  } else if (!wants && have.length) {", to: "  } else if (false) {" },
  { name: "the light is laid twice", file: A, from: "  if (wants && !have.length) {", to: "  if (wants) {" },
  { name: "the old Caelari is not lit at ready", file: A, from: "if (Boolean(ownedFeat(actor, \"Radiant Presence\")) !== Boolean(ownEffects(actor, \"radiantPresence\").length)) await syncRadiantLight(actor);", to: "" },
  { name: "Aetherial Scholar writes Spell Lore", file: A, from: "norm(s?.label ?? key) === \"astral lore\");", to: "norm(s?.label ?? key) === \"spell lore\");" },
  { name: "Quiliesh's cantrip from any tradition", file: A, from: "tradition: \"arcane|ethereal\",", to: "tradition: \"arcane|divinity|ethereal\"," },
  { name: "Quiliesh's cantrip is innate", file: A, from: "{ ppCost: 0, tradition: \"arcane|ethereal\",", to: "{ ppCost: 0, innate: true, tradition: \"arcane|ethereal\"," },
  // Registration
  { name: "Q60 undone: the Quiliesh opens nothing", file: A, from: "  api.registerHeritageRaceGrant?.(\"Quiliesh\", [\"Ascendan\"], moduleId);\n", to: "" },
  { name: "the dying modifier is not registered", file: A, from: "  api.registerDyingRecoveryModifier?.(\"relentlessWill\", relentlessWaiver, moduleId);\n", to: "" },
  { name: "the Dispel modifier is not registered", file: A, from: "  api.registerDispelModifier?.(\"resonantAscendance\", ascendanceDispel, moduleId);\n", to: "" },
  { name: "the light is not registered", file: A, from: "  api.registerLightSources?.([{ ...RADIANT_LIGHT }], moduleId);\n", to: "" },
  { name: "Chronal Echo is not registered", file: A, from: "  api.registerCheckReaction?.(\"chronalEcho\", chronalEcho, moduleId);\n", to: "" },
  { name: "Veil of Honour's step is not registered", file: A, from: "  api.registerReactionStep?.(VEIL_STEP, veilStep, moduleId);\n", to: "" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block5a.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block5a: verify-block5a already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block5a: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block5a: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
