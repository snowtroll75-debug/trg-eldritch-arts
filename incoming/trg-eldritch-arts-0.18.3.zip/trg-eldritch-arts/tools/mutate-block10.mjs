#!/usr/bin/env node
/**
 * mutate-block10 — the mutation half of verify-block10. Each mutation breaks
 * one printed number, one ruling, one reading or one wire of Block 10a
 * (0.17.0: the relics, Dawnshield and the Relic Bonding Ritual);
 * verify-block10 must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block10.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "block10-rules.mjs"), A = f("module", "block10-automations.mjs"), ACT = f("module", "block10-actions.mjs"), C = f("tools", "content", "block10.mjs"),
  SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), MANIFEST = f("module.json");

const MUTATIONS = [
  // B — the rules
  { name: "the Awakened tier from level 6", file: R, from: "{ key: \"awakened\", label: \"Awakened\", from: 5, to: 8, slots: 2 }", to: "{ key: \"awakened\", label: \"Awakened\", from: 6, to: 8, slots: 2 }" },
  { name: "a tier's slots start at 0", file: R, from: "export const slotsForTier = (tier) => int(tier) + 1;", to: "export const slotsForTier = (tier) => int(tier);" },
  { name: "the awakening runs past the level", file: R, from: "  return now >= cap ? now : now + 1;", to: "  return now + 1;" },
  { name: "the affordable tier ignores the awakened", file: R, from: "  return Math.min(Math.max(0, int(awakened)), int(free) - 1);", to: "  return int(free) - 1;" },
  { name: "a sentient item costs one slot", file: R, from: "  if (sentientRecord(item, moduleId)) return 2;", to: "  if (sentientRecord(item, moduleId)) return 1;" },
  { name: "an unbonded relic keeps its powers", file: R, from: "  if (!r || !item?.system?.invested || !r.wielderUuid) return -1;", to: "  if (!r || !item?.system?.invested) return -1;" },
  { name: "the invested tier not capped at the awakened", file: R, from: "  return t < 0 ? -1 : Math.min(t, Math.max(0, int(r.awakened)));", to: "  return t < 0 ? -1 : t;" },
  { name: "the cost 2 PP", file: R, from: "export const BONDING_COST = Object.freeze({ pp: 1, gp: 250 });", to: "export const BONDING_COST = Object.freeze({ pp: 2, gp: 250 });" },
  { name: "the cost 200 gp", file: R, from: "export const BONDING_COST = Object.freeze({ pp: 1, gp: 250 });", to: "export const BONDING_COST = Object.freeze({ pp: 1, gp: 200 });" },
  { name: "a Fumble's wait a day", file: R, from: "export const BONDING_WAIT = Object.freeze({ failure: 86400, fumble: 7 * 86400 });", to: "export const BONDING_WAIT = Object.freeze({ failure: 86400, fumble: 86400 });" },
  { name: "Q211: a Partial reads Success", file: R, from: "  if (d === \"success\") return \"success\";", to: "  if (d === \"success\" || d === \"partial\") return \"success\";" },
  { name: "Q211: a Heroic reads Success", file: R, from: "  if (d === \"heroic\" || d === \"critical\") return \"critical\";", to: "  if (d === \"critical\") return \"critical\";" },
  { name: "the Fumble a flat 1d6", file: R, from: "export const bondingFumbleFormula = (level) => `${Math.max(1, int(level))}d6`;", to: "export const bondingFumbleFormula = (level) => `1d6`;" },
  { name: "the Codex lets Good bond it", file: R, from: "forbiddenAligned: [\"good\"], dissonance:", to: "forbiddenAligned: [], dissonance:" },
  { name: "Dissonance for Order only", file: R, from: "dissonance: [\"balance\", \"order\"], sacrifice: true,", to: "dissonance: [\"order\"], sacrifice: true," },
  { name: "the Codex asks no sacrifice", file: R, from: "dissonance: [\"balance\", \"order\"], sacrifice: true,", to: "dissonance: [\"balance\", \"order\"]," },
  { name: "Q214: the Aegis's aura not on you", file: R, from: "text: \"You and allies within 10 ft gain a +1 item bonus to saving throws vs. fear and curse (Q214: you too).\",\n          self: [cond(", to: "text: \"You and allies within 10 ft gain a +1 item bonus to saving throws vs. fear and curse (Q214: you too).\",\n          selfX: [cond(" },
  { name: "the Aegis's aura at 30 ft", file: R, from: "auras: [{ kind: \"ally\", radius: 10, name: \"Aegis of Valtea\"", to: "auras: [{ kind: \"ally\", radius: 30, name: \"Aegis of Valtea\"" },
  { name: "the Aegis's immunity beside its resistance", file: R, from: "{ key: \"aegisImmune\", replaces: \"aegisResist\",", to: "{ key: \"aegisImmune\"," },
  { name: "the Aegis Restoration at Transcendent", file: R, from: "{ runes: \"Potency II, Benevolent\", spells: [\"Restoration\"], powers: [", to: "{ runes: \"Potency II, Benevolent\", spells: [], powers: [" },
  { name: "Emberfang's Flaming II at Transcendent", file: R, from: "{ runes: \"Potency IV, Flaming III\", spells: [\"Fireball\"], powers: [] },", to: "{ runes: \"Potency IV, Flaming II\", spells: [\"Fireball\"], powers: [] }," },
  { name: "Emberfang never legendary", file: R, from: "{ quality: \"legendary\", runes: \"Potency V, Flaming III\"", to: "{ runes: \"Potency V, Flaming III\"" },
  { name: "the Veilshroud's Veil I lost", file: R, from: "{ runes: \"Veil I\", spells: [\"Misty Step\"], powers: [", to: "{ spells: [\"Misty Step\"], powers: [" },
  { name: "the Veil-Drinker heals in full", file: R, from: "absorb: { type: \"essence\", heal: 0.5 } }", to: "absorb: { type: \"essence\", heal: 1 } }" },
  { name: "the allowance from the tier's last level", file: R, from: "TIERS[Math.max(0, Math.min(4, int(tier)))].from);", to: "TIERS[Math.max(0, Math.min(4, int(tier)))].to);" },
  { name: "Gate not once a day", file: R, from: "export const ONCE_A_DAY_SPELLS = Object.freeze({ veilshroud: [\"Gate\"] });", to: "export const ONCE_A_DAY_SPELLS = Object.freeze({ veilshroud: [] });" },
  { name: "the Dormant item keeps its powers", file: R, from: "    if (t < 0) break;", to: "" },
  { name: "Ego DC 11 + Ego", file: R, from: "export const egoDC = (ego) => 10 + int(ego);", to: "export const egoDC = (ego) => 11 + int(ego);" },
  { name: "Dawnshield's overrides ignored", file: R, from: "  return String(overrides?.[d] ?? INFLUENCE[d] ?? INFLUENCE.failure);", to: "  return String(INFLUENCE[d] ?? INFLUENCE.failure);" },
  { name: "Dawnshield at level 14", file: R, from: "key: \"dawnshield\", name: \"Dawnshield\", level: 15,", to: "key: \"dawnshield\", name: \"Dawnshield\", level: 14," },
  { name: "a Critical's suppression an hour", file: R, from: "export const INFLUENCE_WAIT = Object.freeze({ heroic: 86400, critical: 86400, fumble: 3600 });", to: "export const INFLUENCE_WAIT = Object.freeze({ heroic: 86400, critical: 3600, fumble: 3600 });" },
  // D — the workflows
  { name: "another may invest a bonded relic", file: A, from: "  if (actor?.uuid && r.wielderUuid !== actor.uuid) return", to: "  if (false) return" },
  { name: "an unbonded relic may be invested", file: A, from: "  if (!r.wielderUuid) return \"bond it first (the Relic Bonding Ritual)\";", to: "" },
  { name: "Q211: the performer's level for the DC", file: A, from: "  return { dc: h().levelDC(levelOf(wielder)), label:", to: "  return { dc: h().levelDC(levelOf(actor)), label:" },
  { name: "the PP not checked", file: A, from: "  if (pp < R.BONDING_COST.pp) return", to: "  if (false) return" },
  { name: "the purse not checked", file: A, from: "  if (gold < R.BONDING_COST.gp) return", to: "  if (false) return" },
  { name: "Q212: the PP not paid", file: A, from: "  await actor.update({ \"system.resources.pp.value\": Math.max(0, int(actor.system?.resources?.pp?.value) - R.BONDING_COST.pp) });", to: "" },
  { name: "Q212: the gold not paid", file: A, from: "  await h().deductGold(actor, R.BONDING_COST.gp);", to: "" },
  { name: "a Critical does not awaken", file: A, from: "    const awakened = degree === \"critical\" ? Math.min(1, cap) : 0;", to: "    const awakened = 0;" },
  { name: "a Critical awakens past the level", file: A, from: "    const awakened = degree === \"critical\" ? Math.min(1, cap) : 0;", to: "    const awakened = degree === \"critical\" ? 1 : 0;" },
  { name: "a Failure sets no wait", file: A, from: "    await relic.setFlag(MODULE_ID, \"relic\", { ...r, refusedUntil: now() + R.BONDING_WAIT.failure });", to: "    await relic.setFlag(MODULE_ID, \"relic\", { ...r });" },
  { name: "the Fumble at the performer's DC", file: A, from: "save: \"fortitude\", dc: h().levelDC(int(plan.wielderLevel)), label: `${relic.name} lashes out`", to: "save: \"fortitude\", dc: h().levelDC(levelOf(actor)), label: `${relic.name} lashes out`" },
  { name: "the tier step offers no lower tier", file: A, from: "    for (let t = top; t >= 0; t -= 1) options.push(", to: "    for (let t = top; t >= top; t -= 1) options.push(" },
  { name: "the tier picked not recorded", file: A, from: "  await item.setFlag(MODULE_ID, \"relic\", { ...r, investedTier: tier, chosenBelow: tier < top });", to: "" },
  { name: "the item's runes not rewritten", file: A, from: "\"system.runes\": state.runes || \"\" };", to: "};" },
  { name: "the old grants kept", file: A, from: "  if (had.length) await actor.deleteEmbeddedDocuments(\"Item\", had.map((i) => i.id));\n  if (tier >= 0) {", to: "  if (tier >= 0) {" },
  { name: "the relic's spells not innate", file: A, from: "    data.system = { ...data.system, innate: true, prepared: true, usesPerDay: \"\" };", to: "    data.system = { ...data.system, prepared: true, usesPerDay: \"\" };" },
  { name: "the allowance not written", file: A, from: "...(allowance ? { innatePPAllowance: allowance } : {})", to: "" },
  { name: "Perfect Darkvision never", file: A, from: "state.powers.map((p) => powerItem(item, p, { perfectDarkvision: ownDarkvision }))", to: "state.powers.map((p) => powerItem(item, p, { perfectDarkvision: false }))" },
  { name: "the tier not forgotten on ending investment", file: A, from: "    if (invest && !item.system?.invested && R.relicRecord(item, MODULE_ID)?.investedTier !== null) return item.setFlag(MODULE_ID, \"relic\", { ...R.relicRecord(item, MODULE_ID), investedTier: null });", to: "" },
  { name: "the daily preparation does not raise the invested tier", file: A, from: "      if (!r.chosenBelow) investedTier = Math.max(int(r.investedTier ?? 0), R.highestAffordableTier(awakened, free));", to: "" },
  { name: "Dissonance never laid", file: A, from: "  if (want && !have.length) {", to: "  if (false) {" },
  { name: "a deleted relic leaves its grants", file: A, from: "  if (grants.length) await actor.deleteEmbeddedDocuments(\"Item\", grants);", to: "" },
  { name: "Shield of Dawn without fast healing", file: A, from: "system: { fastHealing: 10, conditionals:", to: "system: { conditionals:" },
  { name: "Shield of Dawn not daily", file: A, from: "    if (usesLeft(item) <= 0) return warn(\"Shield of Dawn: already invoked today.\");", to: "" },
  { name: "the Veil-Drinker for every blow", file: A, from: "  if (!spell && !(ctx.types ?? []).includes(absorb.type)) return null;", to: "" },
  { name: "Influence for anyone", file: A, from: "  if (!globalThis.game?.user?.isGM) return warn(", to: "  if (false) return warn(" },
  { name: "Influence does not dim", file: A, from: "    if (rec.dimsOnFailure && degree === \"failure\") next.dimmed = true;", to: "" },
  { name: "Influence's wait not set", file: A, from: "    if (wait) { next.influenceBlockedUntil = now() + wait;", to: "    if (false) { next.influenceBlockedUntil = now() + wait;" },
  { name: "a dimmed item keeps its powers", file: A, from: "  const active = Boolean(item.system?.invested) && !rec.dimmed;", to: "  const active = Boolean(item.system?.invested);" },
  { name: "the rewrite loops on its own update", file: A, from: "  if (options?.eaRelicSync) return;", to: "" },
  { name: "the rewrite not marked as the module's", file: A, from: "  if (changed) await item.update(update, { eaRelicSync: true });", to: "  if (changed) await item.update(update);" },
  { name: "RELIC not one-invested", file: A, from: "  api.registerOneInvestedTraits?.([\"relic\", \"sentient\"], moduleId);", to: "  api.registerOneInvestedTraits?.([\"sentient\"], moduleId);" },
  { name: "the cost not registered", file: A, from: "  api.registerInvestCost?.(\"eaRelicSentient\", relicInvestCost, moduleId);", to: "" },
  { name: "the Veil-Drinker not registered", file: A, from: "  api.registerDamageReaction?.(\"eaVeilDrinker\", veilDrinker, moduleId);", to: "" },
  // A — the ritual's text
  { name: "the ritual's Failure reworded", file: ACT, from: "failure: \"The Relic rejects the attempt. The ritual may not be attempted again for 24 hours.\"", to: "failure: \"The Relic rejects the attempt. The ritual may not be attempted again for 12 hours.\"" },
  { name: "the ritual untrained", file: ACT, from: "    proficiency: \"trained\",", to: "" },
  // Found in review
  { name: "no Focus trait on a relic spell", file: A, from: "    else if (!/\\bfocus\\b/i.test(String(data.system.traits ?? \"\"))) data.system =", to: "    else if (false) data.system =" },
  { name: "a relic the performer cannot write is bonded anyway", file: A, from: "  if (!relic.isOwner) return { refused:", to: "  if (false) return { refused:" },
  { name: "the GM's preparation awakens nothing", file: A, from: "  if (!actor?.isOwner) return;\n  // The day's uses are back", to: "  if (!actor?.isOwner || !actsFor(actor)) return;\n  // The day's uses are back" },
  { name: "the day's kept uses never forgotten", file: A, from: "if (item.flags?.[MODULE_ID]?.[KEPT_USES]) await item.unsetFlag(MODULE_ID, KEPT_USES);", to: "if (item.flags?.[MODULE_ID]?.[KEPT_USES]) await item.setFlag(MODULE_ID, KEPT_USES, {});" },
  { name: "a chosen lower tier is raised anyway", file: A, from: "      if (!r.chosenBelow) investedTier =", to: "      investedTier =" },
  { name: "a chosen lower tier not recorded", file: A, from: "investedTier: tier, chosenBelow: tier < top });", to: "investedTier: tier });" },
  { name: "a traded relic keeps its old investment", file: A, from: "    if (item.system?.invested && r?.wielderUuid !== actor.uuid) { await item.update({ \"system.invested\": false }); return; }", to: "" },
  { name: "a traded relic keeps its powers", file: R, from: "  if (item?.parent?.uuid && item.parent.uuid !== r.wielderUuid) return -1;", to: "" },
  { name: "an unknown degree is a Fumble", file: R, from: "  if (d === \"fumble\" || d === \"blunder\") return \"fumble\";\n  // Partial, Failure, and anything unrecognised (found in review: never a Fumble's damage by default).\n  return \"failure\";", to: "  if (d === \"partial\" || d === \"failure\" || !d) return \"failure\";\n  return \"fumble\";" },
  { name: "the spent uses come back on a rewrite", file: A, from: "    if (docs.length) await restoreUses(actor, item, await actor.createEmbeddedDocuments(\"Item\", docs));\n  }", to: "    if (docs.length) await actor.createEmbeddedDocuments(\"Item\", docs);\n  }" },
  { name: "the spent uses not recorded", file: A, from: "  await recordUses(item, had);", to: "" },
  { name: "a rewrite repairs the shield", file: A, from: "      update[\"system.hp.value\"] = Math.max(-result.hpMax, result.hpMax - lost);", to: "      update[\"system.hp.value\"] = result.hpMax;" },
  { name: "the Veil-Drinker's spell answer only for an essence packet", file: A, from: "  if (!spell && !(ctx.types ?? []).includes(absorb.type)) return null;", to: "  if (!(ctx.types ?? []).includes(absorb.type)) return null;" },
  { name: "the Veil-Drinker's spell answer not the cast's", file: A, from: "scope: spell ? \"cast\" : \"instance\"", to: "scope: \"instance\"" },
  // 0.17.1 (Graham's yes; found live)
  { name: "Dawnshield's Cure not at its own level", file: A, from: "requested: s.name, atItemLevel: true }", to: "requested: s.name }" },
  { name: "Detect Undead not at will", file: R, from: "export const AT_WILL_SPELLS = Object.freeze({ obsidianCodex: [\"Detect Undead\"] });", to: "export const AT_WILL_SPELLS = Object.freeze({});" },
  { name: "at will still takes Focus", file: A, from: "    else if (atWill) data.system = { ...data.system, usesPerDay: \"unlimited\" };\n", to: "" },
  { name: "the Aegis ships at its base HP", file: C, from: "export const DORMANT_HP = Object.freeze({ aegisOfValtea: 44 });", to: "export const DORMANT_HP = Object.freeze({});" },
  { name: "the Codex's refusal repeats its name", file: R, from: "return `it cannot be bonded by a ${", to: "return `${spec.name} cannot be bonded by a ${" },
  { name: "the grant format left out of the relic's signature", file: A, from: "const signature = JSON.stringify({ g: GRANT_FORMAT, tier,", to: "const signature = JSON.stringify({ tier," },
  { name: "the grant format left out of the sentient signature", file: A, from: "const signature = JSON.stringify({ g: GRANT_FORMAT, active,", to: "const signature = JSON.stringify({ active," },
  // E — the pack
  { name: "a relic ships invested", file: C, from: "quantity: 1, weight, price: 0, equipped: false, invested: false, hp: { value: DORMANT_HP[spec.key] ?? b.base.hp", to: "quantity: 1, weight, price: 0, equipped: false, invested: true, hp: { value: DORMANT_HP[spec.key] ?? b.base.hp" },
  { name: "Dawnshield not fire Dragonhide", file: C, from: "dragonType: \"fire\", superiorTraits", to: "dragonType: \"\", superiorTraits" },
  { name: "the relics' base customisation lost", file: C, from: "    flags[SYSTEM_ID] = { baseCustomisation: { ...b.base } };", to: "" },
  { name: "Dawnshield's DB at 2", file: C, from: "...b.system, dr: s.dr, defenceBonus: s.db, penalty: s.penalty,", to: "...b.system, dr: s.dr, penalty: s.penalty," },
  // F — the wiring
  { name: "the ritual's degree not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeActionResolved\", (ctx) => { onActionResolvedB10(", to: "Hooks.on(\"trgPrimeActionResolvedX\", (ctx) => { onActionResolvedB10(" },
  { name: "the awakening not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeDailyPreparation\", (ctx) => { onDailyPreparationB10(", to: "Hooks.on(\"trgPrimeDailyPreparationX\", (ctx) => { onDailyPreparationB10(" },
  { name: "the item update not hooked", file: SCRIPT, from: "Hooks.on(\"updateItem\", (item, changed, options) => { onItemUpdatedB10(", to: "Hooks.on(\"updateItemX\", (item, changed, options) => { onItemUpdatedB10(" },
  { name: "the ritual not registered", file: REG, from: "  api.registerSkillActions(BLOCK10_ACTIONS.map(", to: "  void (BLOCK10_ACTIONS.map(" },
  { name: "the block not registered", file: REG, from: "  registerBlock10(api, moduleId);", to: "" },
  { name: "the module asks for 3.692.0", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.692.0\";" },
  { name: "the pack not in the manifest's folder", file: MANIFEST, from: "        \"ea-charged-items\",\n        \"ea-relics\"", to: "        \"ea-charged-items\"" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block10.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block10: verify-block10 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block10: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block10: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
