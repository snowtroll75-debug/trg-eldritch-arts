#!/usr/bin/env node
/**
 * mutate-block8b — the mutation half of verify-block8b. Each mutation breaks
 * one printed number, one reading, one ruling, one client guard or one wire of
 * Block 8b (0.12.0) or of 0.12.0's writer; verify-block8b must fail on every
 * one. Files are restored after each run, and on any exit. It rewrites files
 * in place: run it on a copy of the tree.
 *
 * verify-block8b is run with EA_MUTATING=1, which skips its packs-source parity
 * check, so a content mutation is caught by a check of its own meaning.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block8b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "block8b-rules.mjs"), A = f("module", "block8b-automations.mjs"), C = f("tools", "content", "block8b-spells.mjs"),
  B2 = f("module", "block2-automations.mjs"), B3 = f("module", "block3-automations.mjs"), B7 = f("module", "block7-automations.mjs"), B8A = f("module", "block8a-automations.mjs"),
  W = f("module", "writer.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), MANIFEST = f("module.json"), PACKS = f("tools", "content", "packs.mjs"),
  EC = f("module", "effects-clock.mjs");

const MUTATIONS = [
  // m42 and M45
  { name: "a Heroic not printed reads as Success", file: R, from: "    case \"heroic\": return p.has(\"heroic\") ? \"heroic\" : p.has(\"critical\") ? \"critical\" : \"success\";", to: "    case \"heroic\": return p.has(\"heroic\") ? \"heroic\" : \"success\";" },
  { name: "a Partial not printed is a Success", file: R, from: "    case \"partial\": return p.has(\"partial\") ? \"partial\" : \"failure\";", to: "    case \"partial\": return p.has(\"partial\") ? \"partial\" : \"success\";" },
  { name: "a Fumble not printed is a Blunder", file: R, from: "    case \"fumble\": return p.has(\"fumble\") ? \"fumble\" : \"failure\";", to: "    case \"fumble\": return p.has(\"fumble\") ? \"fumble\" : \"blunder\";" },
  { name: "a Blunder not printed skips the Fumble", file: R, from: "    case \"blunder\": return p.has(\"blunder\") ? \"blunder\" : p.has(\"fumble\") ? \"fumble\" : \"failure\";", to: "    case \"blunder\": return p.has(\"blunder\") ? \"blunder\" : \"failure\";" },
  { name: "no ladder: a Partial works", file: R, from: "d === \"partial\" ? \"fails\" :", to: "d === \"partial\" ? \"works\" :" },
  // the printed numbers
  { name: "Army's Failure is 2d8", file: R, from: "failure: \"2d10\", fumble: \"4d10\", blunder: \"8d10\"", to: "failure: \"2d8\", fumble: \"4d10\", blunder: \"8d10\"" },
  { name: "Call's damage is essence", file: R, from: "save: \"fortitude\", type: \"mental\", failure: \"1d6\"", to: "save: \"fortitude\", type: \"essence\", failure: \"1d6\"" },
  { name: "Concord hits every caster (M38: the primary)", file: R, from: "hit: freeze({ who: \"primary\", save: \"fortitude\", type: \"essence\", failure: \"2d6\", blunder: \"8d6\" })", to: "hit: freeze({ who: \"casters\", save: \"fortitude\", type: \"essence\", failure: \"2d6\", blunder: \"8d6\" })" },
  { name: "Convergence's damage is a Fortitude save", file: R, from: "hit: freeze({ who: \"casters\", save: \"reflex\", type: \"chosen\"", to: "hit: freeze({ who: \"casters\", save: \"fortitude\", type: \"chosen\"" },
  { name: "Veil Severing's Blunder is 8d6", file: R, from: "failure: \"4d6\", fumble: \"8d6\", blunder: \"12d6\"", to: "failure: \"4d6\", fumble: \"8d6\", blunder: \"8d6\"" },
  { name: "Convergence needs a secondary (H14)", file: R, from: "printed: freeze([\"critical\", \"failure\", \"fumble\", \"blunder\"]), alone: true,", to: "printed: freeze([\"critical\", \"failure\", \"fumble\", \"blunder\"]), alone: false," },
  { name: "Call costs 250 gp", file: R, from: "cost: freeze({ gp: 200 }),", to: "cost: freeze({ gp: 250 })," },
  { name: "Concord's Cost is flat", file: R, from: "  if (c.gpPerPP) return int(c.gpPerPP) * Math.max(0, int(castPP));", to: "  if (c.gpPerPP) return int(c.gpPerPP);" },
  { name: "corpses round up", file: R, from: "export const corpsesFor = (castPP) => Math.floor(Math.max(0, int(castPP)) / 2);", to: "export const corpsesFor = (castPP) => Math.ceil(Math.max(0, int(castPP)) / 2);" },
  { name: "Army's levels are not halved", file: R, from: "(halfLevels ? Math.floor(Math.max(0, int(l)) / 2) : Math.max(0, int(l)))", to: "(Math.max(0, int(l)))" },
  { name: "Army may raise more than its corpses", file: R, from: "  if (levels.length > corpses) return", to: "  if (false) return" },
  { name: "Army's Partial controls all", file: R, from: "(rung === \"partial\" ? Math.floor(int(count) / 2) :", to: "(rung === \"partial\" ? int(count) :" },
  { name: "Call allows 11 questions", file: R, from: "Math.min(10, 3 + Math.max(0, int(bought)))", to: "Math.min(11, 3 + Math.max(0, int(bought)))" },
  { name: "Concord's Critical lasts 1 month", file: R, from: "({ critical: \"6 months\", success: \"1 month\", partial: \"1 week\" }[rung] ?? \"\")", to: "({ critical: \"1 month\", success: \"1 month\", partial: \"1 week\" }[rung] ?? \"\")" },
  { name: "Concord's DR on a Partial is 5", file: R, from: "dr: { critical: 10, success: 5, partial: 2 }[rung] ?? 0,", to: "dr: { critical: 10, success: 5, partial: 5 }[rung] ?? 0," },
  { name: "Convergence's Critical is 1d6", file: R, from: "export const convergenceDice = (rung) => (rung === \"critical\" ? \"2d6\" : \"1d6\");", to: "export const convergenceDice = (rung) => \"1d6\";" },
  { name: "an opposed trait reads as shared", file: R, from: "  if (theirs.some((t) => mine.map((m) => OPPOSITE[m]).includes(t))) return \"opposed\";", to: "  if (theirs.some((t) => mine.map((m) => OPPOSITE[m]).includes(t))) return \"shared\";" },
  { name: "the oath's Critical does not double", file: R, from: "    double: rung === \"critical\",", to: "    double: false," },
  { name: "the oath's Partial binds all", file: R, from: "    bound: rung === \"partial\" ? \"half\" :", to: "    bound: rung === \"partial\" ? \"all\" :" },
  { name: "Echoed Shadows' Critical radius is 60", file: R, from: "radius: { critical: 300, success: 60, partial: 30 }[rung] ?? 60,", to: "radius: { critical: 60, success: 60, partial: 30 }[rung] ?? 60," },
  { name: "Echoed Shadows' penalty is −2 on a Critical", file: R, from: "    penalty: rung === \"critical\" ? -4 : -2,", to: "    penalty: -2," },
  { name: "the entity is PP + 2", file: R, from: "export const echoEntityLevel = (castPP) => Math.max(0, int(castPP)) + 4;", to: "export const echoEntityLevel = (castPP) => Math.max(0, int(castPP)) + 2;" },
  { name: "Sun's Critical heals 2d8+3", file: R, from: "const base = rung === \"critical\" ? { dice: 4, bonus: 6 } : { dice: 2, bonus: 3 };", to: "const base = { dice: 2, bonus: 3 };" },
  { name: "Sun's warp adds no +1", file: R, from: "  const formula = `${base.dice + n}d8 + ${base.bonus + n}`;", to: "  const formula = `${base.dice + n}d8 + ${base.bonus}`;" },
  { name: "Sun's Partial lowers a condition", file: R, from: "    reduce: rung === \"partial\" || failingRung(rung) ? 0 : 1 + n,", to: "    reduce: failingRung(rung) ? 0 : 1 + n," },
  { name: "Sun's +6 PP is 10 creatures", file: R, from: "    max: has(unlocks, UNLOCK.sunTwenty) ? 20 : 6,", to: "    max: has(unlocks, UNLOCK.sunTwenty) ? 10 : 6," },
  { name: "Veil's Heroic lasts a month", file: R, from: ": { heroic: \"1 year\", critical: \"1 month\", success: \"1 week\", partial: \"1 day\" };", to: ": { heroic: \"1 month\", critical: \"1 month\", success: \"1 week\", partial: \"1 day\" };" },
  { name: "a month is 31 days", file: R, from: "month: 2592000, year: 31536000", to: "month: 2678400, year: 31536000" },
  { name: "Chaos Shield's warp is ignored", file: R, from: "export const chaosRadius = (areaOverride) => (/60/.test(String(areaOverride ?? \"\")) ? 60 : 30);", to: "export const chaosRadius = (areaOverride) => 30;" },
  { name: "the anchor's discount has no floor", file: R, from: "(highMagic && inside && int(totalPP) > 1 ? -1 : 0)", to: "(highMagic && inside ? -1 : 0)" },
  { name: "Mimic's DC is the Save DC formula", file: R, from: "export const mimicDC = (castPP) => 10 + Math.floor(Math.max(0, int(castPP)) * 1.5);", to: "export const mimicDC = (castPP) => 10 + Math.max(0, int(castPP));" },
  { name: "Mimic ignores the cap (M48)", file: R, from: "export const mimicAllowed = (castPP, casterLevel) => int(castPP) <= Math.max(0, int(casterLevel)) + 1;", to: "export const mimicAllowed = () => true;" },
  { name: "Mimic's backlash is 1d6", file: R, from: "export const mimicBacklash = (castPP) => `${Math.max(1, int(castPP))}d6`;", to: "export const mimicBacklash = () => \"1d6\";" },
  { name: "the pool is the sum × 3", file: R, from: "conMods.reduce((a, b) => a + int(b), 0) * 5)", to: "conMods.reduce((a, b) => a + int(b), 0) * 3)" },
  { name: "Soul Drain per round, not per 2", file: R, from: "Math.floor(Math.floor(Math.max(0, Number(seconds) || 0) / SPAN.round) / 2)", to: "Math.floor(Math.max(0, Number(seconds) || 0) / SPAN.round)" },
  { name: "the storm's acid is 15d6", file: R, from: "freeze({ key: \"acid\", label: \"Acid\", formula: \"15d8\"", to: "freeze({ key: \"acid\", label: \"Acid\", formula: \"15d6\"" },
  { name: "the storm's force is a Reflex save", file: R, from: "freeze({ key: \"force\", label: \"Force\", formula: \"12d10\", type: \"force\", save: \"fortitude\"", to: "freeze({ key: \"force\", label: \"Force\", formula: \"12d10\", type: \"force\", save: \"reflex\"" },
  { name: "the storm is chosen, not rolled", file: R, from: "kind: \"storm\", label: \"Storm of Unmaking\", pick: \"roll\", strikes: \"turnStart\",", to: "kind: \"storm\", label: \"Storm of Unmaking\", pick: \"choose\", strikes: \"turnStart\"," },
  { name: "the rift is 5 ft per level", file: R, from: "Math.max(1, Math.floor(Math.max(0, int(casterLevel)) / 2)) * 10", to: "Math.max(1, Math.max(0, int(casterLevel))) * 5" },
  // the rituals' settle
  { name: "the Cost is not taken", file: A, from: "  lines.push(...await payCost(actor, spec, { castPP, targetLevel: plan.targetLevel }));\n", to: "" },
  { name: "a refunded casting takes the Cost", file: A, from: "  if (ctx.refunded) return card(actor, title,", to: "  if (false) return card(actor, title," },
  { name: "the casters' damage is at the caster's DC", file: A, from: "    const res = await h().basicSaveHit({ caster: actor, target: c, save: hit.save, dc: ownLevelDC(c),", to: "    const res = await h().basicSaveHit({ caster: actor, target: c, save: hit.save, dc: ownLevelDC(actor)," },
  { name: "only the primary is a caster", file: A, from: "  const casters = [actor, ...secondaries];", to: "  const casters = [actor];" },
  { name: "a failing rung leaves the cast running", file: A, from: "  if (R.failingRung(rung) || rung === \"fails\" || out?.ends) await endCast(actor, ctx);", to: "" },
  { name: "the purse is not checked before the roll", file: A, from: "    if (have < gp) return { refused:", to: "    if (false) return { refused:" },
  { name: "secondaries need not be ticked", file: A, from: "  if (secondaries.length !== int(secondaryCount)) {", to: "  if (false) {" },
  { name: "every ritual may be alone", file: A, from: "export const ritualMinSecondaries8b = ({ spell } = {}) => (R.RITUALS[ritualKeyOf(spell)]?.alone ? 0 : null);", to: "export const ritualMinSecondaries8b = ({ spell } = {}) => (ritualKeyOf(spell) ? 0 : null);" },
  { name: "no Partial casts", file: A, from: "export const ritualPartialCasts8b = ({ spell } = {}) => Boolean(ritualKeyOf(spell));", to: "export const ritualPartialCasts8b = () => false;" },
  { name: "Sun's participants need not be within 30 ft", file: A, from: "return !site || !t || (feetBetween(site, t) ?? 0) <= R.SUN_RADIUS_FEET; });", to: "return true; });" },
  { name: "Sun's Partial heals in full", file: A, from: "      const amount = terms.half ? Math.floor(rolled / 2) : rolled;", to: "      const amount = rolled;" },
  { name: "Sun's blessing is not against fear", file: A, from: "when: { checkTypes: [\"save\"], traits: [\"fear\"] } }] },", to: "when: { checkTypes: [\"save\"] } }] }," },
  { name: "the oath's broken damage is not doubled", file: A, from: "  const amount = rec.double ? rolled * 2 : rolled;", to: "  const amount = rolled;" },
  { name: "the oath breaker has no disadvantage", file: A, from: "system: { conditionals: [{ kind: \"disadvantage\", label: \"Oath broken\", scope: \"all rolls\", auto: true, always: true }] }, expiry: forSeconds(R.OATH_DISADVANTAGE_SECONDS) })]);", to: "system: {}, expiry: forSeconds(R.OATH_DISADVANTAGE_SECONDS) })]);" },
  { name: "the oath button is a player's", file: A, from: "  oathBroken: { gm: true, run:", to: "  oathBroken: { gm: false, run:" },
  { name: "Army takes a living creature", file: A, from: "  if (undead.length !== picked.length) return warn(", to: "  if (false) return warn(" },
  { name: "Army's levels are not checked", file: A, from: "  if (!fits.ok) return warn(`Eldritch Arts: ${fits.reason}.`);", to: "" },
  { name: "Army records no control", file: A, from: "    const entry = await h().recordControlled?.(caster,", to: "    const entry = null; void (caster," },
  { name: "Army's button may be pressed twice", file: A, from: "  await caster.unsetFlag(MODULE_ID, \"army8b\");\n  let controlled", to: "  let controlled" },
  { name: "Essence Reforging's backlash spares the target", file: A, from: "        for (const who of [actor, target].filter(Boolean)) {", to: "        for (const who of [actor].filter(Boolean)) {" },
  { name: "the remove button keeps the effect", file: A, from: "  await fx.delete();\n  return card(caster, \"Essence Reforging\"", to: "  return card(caster, \"Essence Reforging\"" },
  // the memberships
  { name: "a foe defends in the Concord", file: A, from: "      const ally = actor === caster || (int(rec.side) !== 0 && sideOf(doc) === int(rec.side));", to: "      const ally = true;" },
  { name: "the member effects never leave", file: A, from: "    else if (!wanted && fx && !fx.disabled) {", to: "    else if (false) {" },
  { name: "the members follow the stale document", file: A, from: "    const at = moved && moved.doc && moved.doc.id === doc.id ? moved.at : doc;", to: "    const at = doc;" },
  { name: "any client syncs the members", file: A, from: "  if (!isActingGM() && !(region?.isOwner && !globalThis.game?.users?.activeGM)) return 0;", to: "" },
  { name: "an echo's every entry is a first", file: A, from: "    if (inside && rec.key === \"riteOfEchoedShadows\" && !rec.entered?.includes(actor.uuid) && enemiesBySide(rec.side, sideOf(doc))) await echoFirstEntry(actor, region);", to: "    if (inside && rec.key === \"riteOfEchoedShadows\" && enemiesBySide(rec.side, sideOf(doc))) await echoFirstEntry(actor, region);" },
  { name: "an ally's entry is punished", file: A, from: "!rec.entered?.includes(actor.uuid) && enemiesBySide(rec.side, sideOf(doc))) await echoFirstEntry", to: "!rec.entered?.includes(actor.uuid)) await echoFirstEntry" },
  { name: "leaving the echo costs nothing", file: A, from: "      if (rec.key === \"riteOfEchoedShadows\" && rec.invisible && rec.participants?.includes(actor.uuid)) await echoLeft(actor, caster, region);\n", to: "" },
  { name: "Eternal: an opposed creature gets the blessing", file: A, from: "      const rate = relation === \"shared\" ? 2 : 0.5;", to: "      const rate = 2;" },
  { name: "Eternal: the save is automatic", file: A, from: "scope: \"a saving throw against a creature with an aligned trait opposed to yours — tick it\", auto: false,", to: "scope: \"a saving throw against a creature with an aligned trait opposed to yours — tick it\", auto: true," },
  { name: "a ritual's own span is cut by the core's entry", file: A, from: "      const castGone = rec.castBound && rec.castId", to: "      const castGone = rec.castId" },
  { name: "a cast-bound Region outlives its cast", file: A, from: "      const castGone = rec.castBound && rec.castId", to: "      const castGone = false && rec.castId" },
  { name: "a Region's end leaves its members' effects", file: A, from: "    const ids = effects(actor).filter((e) => e.flags?.[MODULE_ID]?.[R.AURA8B_FLAG] === region.id).map((e) => e.id);", to: "    const ids = [];" },
  { name: "Convergence asks again for a creature that has chosen", file: A, from: "  asked.delete(k);\n  const off", to: "  if (asked.has(k)) return 0;\n  const off" },
  { name: "Convergence's rider is melee only", file: A, from: "system: { strikeRider: { label: `Elemental Convergence (${element})`, dice, damageType: element, scope: \"any\", once: false } } });", to: "system: { strikeRider: { label: `Elemental Convergence (${element})`, dice, damageType: element, scope: \"melee\", once: false } } });" },
  // Chaos Shield
  { name: "the shield is offered to enemies too (allies only halve)", file: A, from: "if (f !== null && f <= Number(rec.radius) && (o.actor === caster || (side !== 0 && sideOf(o.document) === side))) members.add(o.actor.uuid);", to: "if (f !== null && f <= Number(rec.radius)) members.add(o.actor.uuid);" },
  { name: "the shield is twice a round", file: A, from: "  if (used && ((used.combatId", to: "  if (false && ((used.combatId" },
  { name: "nullifying costs nothing", file: A, from: "  await actor.update({ \"system.resources.pp.value\": ppOf(actor) - R.CHAOS_NULLIFY_PP });", to: "" },
  { name: "the shield rolls once", file: A, from: "  if (found.ally && !total && !cancels) {", to: "  if (false) {" },
  { name: "an ended shield still shields", file: A, from: "    if (rec.castId && !Array.from(caster.getFlag?.(SYSTEM_ID, \"activeSpells\") ?? []).some((e) => e?.id === rec.castId)) continue;", to: "" },
  { name: "Block 2: the DC is not lowered", file: B2, from: "dc: ownLevelDC(target) + int(shield?.dcStep),", to: "dc: ownLevelDC(target)," },
  { name: "Block 2: allies are not halved", file: B2, from: "  if (shielded && amount !== null) amount = Math.floor(Math.max(0, int(amount)) / 2);", to: "" },
  { name: "Block 2: the shield is not asked", file: B2, from: "  if (table === WILD_SURGE && depth === 0 && !shield) {", to: "  if (false) {" },
  { name: "Block 2: a nullified surge still rolls", file: B2, from: "    if (got.nullified) {\n      await card(actor, title, got.lines);\n      return { row: null, roll: 0, nullified: true };\n    }", to: "" },
  { name: "Block 3: Wild Power's two rolls stand under the shield", file: B3, from: "    if ((await chaosShieldFor(actor))?.ally) return rollTable(actor, { ...common, cancels: true });", to: "" },
  // Leyline Anchor
  { name: "the anchor's tap DC is the Save DC", file: A, from: "  const dc = int(rec.saveDC) + R.ANCHOR_TAP_STEP;", to: "  const dc = int(rec.saveDC);" },
  { name: "a failed tap keeps its AP", file: A, from: "  if (apCost) await spendAP(actor, actionName, apCost);", to: "" },
  { name: "the anchorer is gated too", file: A, from: "  if (!rec || rec.casterUuid === actor?.uuid) return null;", to: "  if (!rec) return null;" },
  { name: "the anchor gives non-casters the bonus", file: A, from: "      if (casterLevelOf(actor) <= 0) return null;", to: "" },
  { name: "Block 2's Tap does not ask the anchor", file: B2, from: "const gate = await anchorTapGate(actor, l.region.id, \"Tap Ley Line\", 1); if (gate) return gate; }", to: "void anchorTapGate; }" },
  // Mimic Spell
  { name: "Mimic is offered through walls", file: A, from: "    if (feet === null || feet > R.MIMIC_RANGE_FEET || sightBlocked(t.center, casterTok.center)) continue;", to: "    if (feet === null || feet > R.MIMIC_RANGE_FEET) continue;" },
  { name: "Mimic is offered at any range", file: A, from: "    if (feet === null || feet > R.MIMIC_RANGE_FEET || sightBlocked", to: "    if (feet === null || sightBlocked" },
  { name: "Mimic is offered for a Ritual spell (found live)", file: A, from: "    if (hasTrait(ctx.spell.system ?? {}, \"ritual\") || !R.mimicAllowed(castPP, casterLevelOf(reactor))) continue;", to: "    if (!R.mimicAllowed(castPP, casterLevelOf(reactor))) continue;" },
  { name: "Mimic is offered above the reactor's cap (found live)", file: A, from: "    if (hasTrait(ctx.spell.system ?? {}, \"ritual\") || !R.mimicAllowed(castPP, casterLevelOf(reactor))) continue;", to: "    if (hasTrait(ctx.spell.system ?? {}, \"ritual\")) continue;" },
  { name: "Mimic's check rolls +0 (found live)", file: A, from: "traits: \"HighMagic, Utility\", modifiers: spellcraftModifiers(actor) });", to: "traits: \"HighMagic, Utility\" });" },
  { name: "spellcraftModifiers drops the sheet's own", file: A, from: "  return Array.isArray(sc.checkModifiers) && sc.checkModifiers.length ? sc.checkModifiers : [{ label: \"Spellcraft\", value: int(sc.total), type: \"untyped\" }];", to: "  return [{ label: \"Spellcraft\", value: int(sc.total), type: \"untyped\" }];" },
  { name: "Argent Reversal's check rolls +0", file: B7, from: "dc: int(data?.dc), modifiers });", to: "dc: int(data?.dc) });" },
  { name: "the Oath binds the targeted, not the participants (found live)", file: A, from: "    const sworn = [...casters, ...participants].filter((a, i, all) => a && all.indexOf(a) === i).slice(0, R.oathMax(int(ctx.warpMods?.extraTargets)));", to: "    const sworn = Array.from(globalThis.game?.user?.targets ?? []).map((t) => t.actor).filter(Boolean).slice(0, R.oathMax(int(ctx.warpMods?.extraTargets)));" },
  { name: "the Oath leaves out its casters", file: A, from: "    const sworn = [...casters, ...participants]", to: "    const sworn = [...participants]" },
  { name: "the Oath's dialog has no participants", file: A, from: "\"callOfTheAncestors\", \"riteOfBindingOath\"].includes(key)) {", to: "\"callOfTheAncestors\"].includes(key)) {" },
  { name: "the Oath asks the core for creatures", file: C, from: "key: \"riteOfBindingOath\", grade: \"B\", category: \"utility\", defence: \"\", targetsObject: true,", to: "key: \"riteOfBindingOath\", grade: \"B\", category: \"utility\", defence: \"\"," },
  { name: "Soul Confluence asks the core for creatures", file: C, from: "key: \"soulConfluence\", area: \"\", grade: \"B\", category: \"utility\", targetsObject: true,", to: "key: \"soulConfluence\", area: \"\", grade: \"B\", category: \"utility\"," },
  { name: "Mimic spends no reaction", file: A, from: "  if (!(await h().spendReaction?.(actor, \"Mimic Spell\", { traits: \"verbal\" }))) return { rolled: false };", to: "" },
  { name: "the imprint stays specialist", file: A, from: "raw.system = { ...raw.system, specialist: false, specialistClass: \"\", innate: false, usesPerDay: \"\", prepared: true };", to: "raw.system = { ...raw.system, innate: false, usesPerDay: \"\", prepared: true };" },
  { name: "the imprint survives its cast", file: A, from: "  if (actor.items?.get?.(item.id)) await actor.deleteEmbeddedDocuments(\"Item\", [item.id]);", to: "" },
  { name: "PP below 0 costs no Soul Drain", file: A, from: "    const add = R.SOUL_DRAIN_PER_PP * n;", to: "    const add = 0;" },
  { name: "the below-0 Soul Drain is passed as the new total (the review)", file: A, from: "[{ key: \"soulDrain\", value: add }]", to: "[{ key: \"soulDrain\", value }]" },
  { name: "the confluence's backlash is passed as the new total (the review)", file: A, from: "[{ key: \"soulDrain\", value: n }]", to: "[{ key: \"soulDrain\", value }]" },
  { name: "any spell may go below 0", file: A, from: "    if (!ctx.spell?.flags?.[MODULE_ID]?.[R.MIMIC_FLAG]) return null;\n    const short", to: "    const short" },
  { name: "Mimic's backlash is at the caster's DC", file: A, from: "save: \"will\", dc: ownLevelDC(actor), label: \"Mimic Spell: the resonance backlashes\"", to: "save: \"will\", dc: 30, label: \"Mimic Spell: the resonance backlashes\"" },
  // Soul Confluence
  { name: "the pool takes nothing", file: A, from: "  if (!out.taken) return null;\n  const next", to: "  return null;\n  const next" },
  { name: "the pool is not written down", file: A, from: "  const written = await writeOn(caster, { kind: \"effectFlag\", effectId: marker.id, key: R.CONFLUENCE_FLAG, value: next });", to: "  const written = true;" },
  { name: "a refused pool write still takes (the review)", file: A, from: "  if (written === false) return null;\n", to: "" },
  { name: "the local pool is not kept (the review)", file: A, from: "  localPools.set(poolKey, out.pool);", to: "" },
  { name: "an enemy may join the confluence", file: A, from: " && !enemiesBySide(sideOf(me.document), sideOf(t.document)));", to: ");" },
  { name: "the links stay after the end", file: A, from: "    if (links.length) await writeOn(who, { kind: \"deleteEffects\", ids: links });", to: "" },
  { name: "Block 7: the pool may go up", file: B7, from: "    return Number.isInteger(now) && now >= 0 && now < was;", to: "    return Number.isInteger(now) && now >= 0;" },
  { name: "Block 7: the links are not this module's", file: B7, from: ", \"bound8a\", \"confluenceLink8b\"]);", to: ", \"bound8a\"]);" },
  // Storm, Veilfracture
  { name: "the fumble's storm does not follow", file: A, from: "{ radiusFeet: R.UNMAKING_RADIUS_FEET, follow: true, dc,", to: "{ radiusFeet: R.UNMAKING_RADIUS_FEET, follow: false, dc," },
  { name: "a failed cast's Save DC is the sheet's Spellcraft DC (found live)", file: A, from: "  return 10 + pp + Math.floor(ability);\n}", to: "  return int(actor?.system?.magic?.spellcraft?.dc);\n}" },
  { name: "a failed cast's Save DC leaves out the PP", file: A, from: "  return 10 + pp + Math.floor(ability);\n}", to: "  return 10 + Math.floor(ability);\n}" },
  { name: "a failed cast's Save DC leaves out the ability", file: A, from: "  return 10 + pp + Math.floor(ability);\n}", to: "  return 10 + pp;\n}" },
  { name: "a failed cast's Save DC ignores the cast's own", file: A, from: "  if (int(ctx.saveDC) > 0) return int(ctx.saveDC);\n", to: "" },
  { name: "the fumble's storm uses the sheet's DC", file: A, from: "const fumbleDC = (actor, ctx) => failedCastSaveDC(actor, ctx);", to: "const fumbleDC = (actor) => int(actor?.system?.magic?.spellcraft?.dc);" },
  { name: "Veilfracture's collapse uses the sheet's DC (found live)", file: A, from: "  const dc = failedCastSaveDC(actor, ctx);\n  await actor.setFlag(MODULE_ID, \"veilfracture8b\"", to: "  const dc = int(actor?.system?.magic?.spellcraft?.dc);\n  await actor.setFlag(MODULE_ID, \"veilfracture8b\"" },
  { name: "a successful storm also raises one on you", file: A, from: "  if (key === \"stormOfUnmaking\") return [\"fumble\", \"blunder\"].includes(String(ctx.degree)) ? stormFumble(actor, ctx) : null;", to: "  if (key === \"stormOfUnmaking\") return stormFumble(actor, ctx);" },
  { name: "the rift's pull spares the caster", file: A, from: "  for (const who of [caster, ...chosen]) {", to: "  for (const who of [...chosen]) {" },
  // the spells
  { name: "Sun's Benediction is cast without the ritual's area cleared", file: C, from: "    key: \"sunsBenediction\", area: \"\", grade:", to: "    key: \"sunsBenediction\", grade:" },
  { name: "Storm of Unmaking keeps \"varies\" as base damage", file: C, from: "  if (spec.key === \"stormOfUnmaking\") sys.baseDamage = \"\";", to: "" },
  { name: "Leyline Anchor asks for a creature", file: C, from: "    key: \"leylineAnchor\", grade: \"B\", category: \"utility\", targetsObject: true,", to: "    key: \"leylineAnchor\", grade: \"B\", category: \"utility\"," },
  { name: "Concord's grade claims B", file: C, from: "    key: \"concordOfStone\", area: \"\", grade: \"C\",", to: "    key: \"concordOfStone\", area: \"\", grade: \"B\"," },
  { name: "Army's permanent option locks nothing", file: C, from: "warpMods: [{ unlocks: [UNLOCK.armyHalf] }, { unlocks: [UNLOCK.armyPermanent], durationText: \"permanent\" }],", to: "warpMods: [{ unlocks: [UNLOCK.armyHalf] }, { unlocks: [UNLOCK.armyPermanent] }]," },
  { name: "the 17 are not packed", file: PACKS, from: "BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);", to: "BLOCK8A_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);" },
  // the wiring
  { name: "the settle is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB8b(ctx)", to: "Hooks.on(\"trgPrimeSpellSettledOff\", (ctx) => { onSpellSettledB8b(ctx)" },
  { name: "a Region's creation is not wired (the review)", file: SCRIPT, from: "Hooks.on(\"createRegion\", (region) => { onRegionCreatedB8b(region)", to: "Hooks.on(\"createRegionOff\", (region) => { onRegionCreatedB8b(region)" },
  { name: "an actor's update is not wired (the review)", file: SCRIPT, from: "Hooks.on(\"updateActor\", (actor, change) => { onActorUpdatedB8b(actor, change)", to: "Hooks.on(\"updateActorOff\", (actor, change) => { onActorUpdatedB8b(actor, change)" },
  { name: "a Region's end is not wired", file: SCRIPT, from: "Hooks.on(\"deleteRegion\", (region) => { onRegionDeletedB8b(region)", to: "Hooks.on(\"deleteRegionOff\", (region) => { onRegionDeletedB8b(region)" },
  { name: "registration skips 8b", file: REG, from: "  registerBlock8b(api, moduleId);\n", to: "" },
  { name: "the manifest stays at 3.686.0", file: MANIFEST, from: "\"minimum\": \"3.694.0\"", to: "\"minimum\": \"3.686.0\"" },
  { name: "the script asks for 3.686.0", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.686.0\";" },
  { name: "the Veil teleport is not deferred", file: A, from: "  api.registerDeferredTeleport?.(\"eaVeilSevering\", (ctx = {}) => keyOf(ctx.spell) === \"veilSevering\", moduleId);\n", to: "" },
  { name: "the PP source is not registered", file: A, from: "  api.registerCastPPSource?.(\"eaMimicBelowZero\", mimicPPSource, moduleId);\n", to: "" },
  // the review's fixes
  { name: "Army's Partial ignores the permanent warp no longer", file: R, from: " && !failingRung(rung) && rung !== \"partial\") return \"permanent\";", to: " && !failingRung(rung)) return \"permanent\";" },
  { name: "Concord's Partial is permanent with the warp", file: R, from: "has(unlocks, UNLOCK.concordPermanent) && rung !== \"partial\" ? \"permanent\"", to: "has(unlocks, UNLOCK.concordPermanent) ? \"permanent\"" },
  { name: "Army records half its level", file: A, from: "    const level = levelOf(t.actor);\n    const entry", to: "    const level = rec.half ? Math.floor(levelOf(t.actor) / 2) : levelOf(t.actor);\n    const entry" },
  { name: "a raised undead's end keeps its control entry", file: A, from: "    return h().releaseControlled?.(caster, raised.entryId, { reason: \"Army of the Grave ended\", creature: actor });", to: "    return null;" },
  { name: "syncs are not serialised", file: A, from: "  const next = (syncChains.get(id) ?? Promise.resolve()).catch(() => 0).then(() => syncMembersNow(region, moved));", to: "  const next = syncMembersNow(region, moved);" },
  // (The createRegion hook's own acting-GM guard is not mutated: syncMembers keeps the same guard, so dropping it changes nothing.)
  { name: "the zone switches the owner's rider back on", file: A, from: "  const off = fxs.filter((e) => e.disabled && e.flags?.[MODULE_ID]?.zoneOff);", to: "  const off = fxs.filter((e) => e.disabled);" },
  { name: "the convergence's rider and resistance are one effect", file: A, from: "    await actor.createEmbeddedDocuments(\"ActiveEffect\", [resist, rider]);", to: "    resist.flags[SYSTEM_ID] = { ...(resist.flags[SYSTEM_ID] ?? {}), ...(rider.flags[SYSTEM_ID] ?? {}) };\n    await actor.createEmbeddedDocuments(\"ActiveEffect\", [resist]);" },
  { name: "the convergence asks on every move", file: A, from: "    if (asked.has(k)) return 0;\n", to: "" },
  { name: "a second element answer is taken", file: A, from: "    // ANSWERED ALREADY (another tab of the GM's account, or a second ask): the first stands.\n    if (memberEffects(actor, region.id).length) return;\n", to: "" },
  { name: "answersFor ignores a connected player", file: A, from: "  if (owners.length) return owners[0] === globalThis.game.user;\n  return isActiveGMAccount();", to: "  return isActiveGMAccount();" },
  { name: "the Oath's Partial is chosen on the caster's client", file: A, from: "    if (terms.bound === \"half\") {\n      // \"THE GM CHOOSES\"", to: "    if (false) {\n      // \"THE GM CHOOSES\"" },
  { name: "the Oath's choice is not spent", file: A, from: "  await caster.unsetFlag(MODULE_ID, \"oathPending8b\");\n", to: "" },
  { name: "the Oath's choice binds everyone", file: A, from: "  const sworn = who.filter((a) => ids.includes(a.id)).slice(0, rec.keep);", to: "  const sworn = who;" },
  { name: "Sun's condition is lowered twice", file: A, from: "    if (askId && actor.getFlag?.(MODULE_ID, \"sunAsked8b\") === askId) return null;\n", to: "" },
  { name: "Sun lowers any condition named", file: A, from: "    const list = Array.from(conditions).map(String).filter((c) => allowed.includes(c));", to: "    const list = Array.from(conditions).map(String);" },
  { name: "a dismissed cast's Region still counts", file: A, from: " && worldNow() < Number(rec.until ?? Infinity) && castStands(rec); });", to: " && worldNow() < Number(rec.until ?? Infinity); });" },
  { name: "the actor hook keeps a dismissed cast's Region", file: A, from: "      if (!rec?.castBound || !rec.castId || rec.casterUuid !== actor.uuid || live.has(rec.castId)) continue;", to: "      continue;" },
  { name: "the actor hook runs on any update", file: A, from: "  if (!flags || !((\"activeSpells\" in flags) || (\"-=activeSpells\" in flags))) return 0;", to: "  void flags;" },
  // the writer (0.12.0)
  { name: "the writer ignores the election", file: W, from: "  try { return electionWriter ? electionWriter() !== false : true; } catch { return true; }", to: "  return true;" },
  { name: "a player is the active GM's account", file: W, from: "  if (!game?.user?.isGM) return false;\n  const active", to: "  const active" },
  { name: "the election is not loaded", file: SCRIPT, from: "Hooks.once(\"init\", () => { loadCoreElection(); });", to: "Hooks.once(\"init\", () => {});" },
  { name: "Block 8a's bind button wants the elected tab", file: B8A, from: "  if (globalThis.game?.user?.isGM && !isActiveGMAccount()) return warn(\"Eldritch Arts: another GM is the acting GM; that GM binds the creature.\");", to: "  if (globalThis.game?.user?.isGM && !isActingGM()) return warn(\"Eldritch Arts: another GM is the acting GM; that GM binds the creature.\");" },
  { name: "effects-clock keeps its own account test", file: EC, from: "import { isActingGM } from \"./writer.mjs\";\n", to: "const isActingGM = () => Boolean(globalThis.game?.user?.isGM && (!game.users?.activeGM || game.users.activeGM === game.user));\n" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block8b.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block8b: verify-block8b already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block8b: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block8b: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
