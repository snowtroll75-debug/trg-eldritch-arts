#!/usr/bin/env node
/**
 * verify-block3b — Eldritch Arts 0.6.0 and 0.6.1 (Block 3b, on TRG Prime 3.681.0): the
 * seven reactions, run against fakes of the core's reaction helpers.
 *
 *   A  the readings: immunity (Q30), enemy and ally (Q28), Phase Familiar's
 *      answer, what Resist Magic and Eternity Resilience answer (Q32, Q35)
 *   B  Missed Chance        C  Second Chance        D  Prophetic Warning
 *   E  Phase Familiar       F  Resist Magic         G  Disrupting Magic
 *   H  Eternity Resilience  I  the reaction steps    J  registration, hooks, versions
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block3b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }

/* Fakes: the helpers the reactions call. */
const asks = [];
let answer = "yes";
const stepResults = {};
const calls = { spendReaction: [], castAsReaction: [], resolveAction: [], spendConviction: [], pending: [] };
let refusal = "";
let spendFails = false;
let convictionOk = true;
let dispelDegree = "success";
let castResult = { cast: true, warpPP: 0 };
let castRefusalReason = "";
const emitted = [];
const helpers = {
  castRefusal: async () => castRefusalReason,
  isDead: async (a) => Boolean(a?.dead),
  reactionRefusal: async () => refusal,
  askReactor: async (actor, q) => {
    asks.push({ actor: actor.name, title: q.title, step: q.step, data: q.data });
    if (answer !== "yes") return { answer, result: null };
    const run = stepResults[q.step];
    return { answer, result: run ? await run(actor, answer, q.data) : null };
  },
  castAsReaction: async (actor, spell, ids) => { calls.castAsReaction.push([actor.name, spell.name, ids]); return castResult; },
  spendReaction: async (actor, label) => { calls.spendReaction.push([actor.name, label]); return !refusal && !spendFails; },
  get skillActions() { return [{ key: "dispel", name: "Dispel", apCost: "2" }]; },
  resolveAction: async (actor, action, opts) => { calls.resolveAction.push([actor.name, action.key, action.apCost, opts.presetDispel]); return dispelDegree ? { outcome: { degree: { key: dispelDegree, label: dispelDegree[0].toUpperCase() + dispelDegree.slice(1) } } } : null; },
  convictionState: async (actor) => ({ ok: convictionOk, value: 2 }),
  spendConviction: async (actor) => { calls.spendConviction.push(actor.name); return convictionOk; },
  addPendingModifier: async (actor, entry) => { calls.pending.push([actor.name, entry.kind, entry.oneShot, entry.checkTypes]); return entry; },
  postCard: async () => {}
};
let settings = { propheticWarningPrompt: true };
const flagsOf = (a) => a.flags;
globalThis.game = {
  trgPrime: { modules: { helpers } }, time: { worldTime: 1000 }, user: { isGM: true, id: "gm" }, users: { activeGM: null },
  socket: { emit: (channel, data) => emitted.push([channel, data]), on: (channel, fn) => { emitted.listener = [channel, fn]; } },
  settings: { get: (m, k) => settings[k], register: (m, k, spec) => { settings.__registered = { m, k, spec }; } },
  actors: { get: (id) => worldActors.find((a) => a.id === id) ?? null }
};
globalThis.ui = { notifications: { warn() {}, info() {} } };
globalThis.canvas = { grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 100 * 5 }) }, dimensions: { size: 100, distance: 5 }, tokens: { placeables: [] } };
globalThis.foundry = { utils: { escapeHTML: (s) => String(s), fromUuid: async (uuid) => worldActors.find((a) => a.uuid === uuid) ?? null } };
let warned = [];
globalThis.ui.notifications.warn = (m) => warned.push(String(m));

const worldActors = [];
let nextId = 1;
function actor(name, { items = [], pp = 20, blinded = false, dead = false, familiar = null } = {}) {
  const a = {
    id: `a${nextId}`, uuid: `Actor.a${nextId++}`, name, items: items.map((i) => ({ id: `i${nextId++}`, ...i })), flags: {}, isOwner: true, dead,
    system: { resources: { pp: { value: pp } }, magic: { spellcraft: { dc: 16 } }, skills: { powerManipulation: { ranks: 1 } }, ...(familiar ? { familiar } : {}) },
    hasCondition: (c) => c === "blinded" && blinded,
    async setFlag(scope, key, value) { this.flags[scope] = { ...(this.flags[scope] ?? {}), [key]: value }; },
    getActiveTokens() { return this._token ? [this._token] : []; }
  };
  a.items.get = (id) => a.items.find((i) => i.id === id);
  worldActors.push(a);
  return a;
}
function place(a, col, disposition = 1) {
  const t = { id: `t${a.id}`, actor: a, center: { x: col * 100 + 50, y: 50 }, document: { width: 1, disposition, _source: { x: col * 100, y: 0, width: 1, height: 1 } } };
  a._token = t;
  canvas.tokens.placeables.push(t);
  return t;
}
const spell = (name, pp = 3, traits = "Fortune, Hex, Utility") => ({ type: "spell", name, system: { ppCost: pp, traits } });
const abilityItem = (name) => ({ type: "ability", name, system: {} });
const reset = () => { castRefusalReason = ""; emitted.length = 0; warned = []; game.users.activeGM = null; spendFails = false; asks.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; answer = "yes"; refusal = ""; convictionOk = true; dispelDegree = "success"; castResult = { cast: true, warpPP: 0 }; canvas.tokens.placeables.length = 0; worldActors.length = 0; game.time.worldTime = 1000; };

const B = await import(new URL("../module/block3b-automations.mjs", import.meta.url));
for (const [k, fn] of Object.entries({ [B.CAST_STEP]: B.STEPS.castStep, [B.SPEND_STEP]: B.STEPS.spendStep, [B.DISRUPT_STEP]: B.STEPS.disruptStep, [B.CONVICTION_STEP]: B.STEPS.convictionStep })) stepResults[k] = fn;
const R = B.REACTIONS;
const script = fs.readFileSync(path.join(ROOT, "scripts", "eldritch-arts.mjs"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "module.json"), "utf8"));
const S = await import(new URL("./content/block3-spells.mjs", import.meta.url));
const C3 = await import(new URL("./content/block3.mjs", import.meta.url));

/* A — the readings */
equal("A1 Q30: immune for an hour of world time, to that hex only", [B.immuneTo({ "missed chance": 4600 }, "Missed Chance", 4599), B.immuneTo({ "missed chance": 4600 }, "Missed Chance", 4600), B.immuneTo({ "missed chance": 4600 }, "Second Chance", 1000)], [true, false, false]);
equal("A2 marking adds the hour and drops the lapsed", B.withImmunity({ "second chance": 10, "prophetic warning": 9999 }, "Missed Chance", 1000), { "prophetic warning": 9999, "missed chance": 4600 });
equal("A3 Q28: friendly and hostile are enemies; same side are allies; neutral and secret are neither",
  [B.enemies(1, -1), B.enemies(-1, 1), B.enemies(1, 1), B.enemies(0, -1), B.enemies(-2, 1), B.allies(1, 1), B.allies(-1, -1), B.allies(1, -1), B.allies(0, 0)], [true, true, false, false, false, true, true, false, false]);
equal("A4 the question's words", [B.checkWords({ type: "attack", succeeded: true }), B.checkWords({ type: "attack", succeeded: false }), B.checkWords({ type: "save", succeeded: true, label: "Will Save" }), B.checkWords({ type: "skill", succeeded: false })],
  ["hits", "misses", "succeeds at a saving throw (Will Save)", "fails a check"]);
equal("A5 Phase Familiar: resistance to all and precision immunity; warped (+10 PP), immunity to all; for that strike or that cast, else that blow",
  [B.phaseAnswer({ warpPP: 0, kind: "weapon" }), B.phaseAnswer({ warpPP: 10, kind: "spell" }), B.phaseAnswer({ warpPP: 0, kind: "other" })],
  [{ resist: "all", immune: ["precision"], scope: "cast" }, { immune: "all", scope: "cast" }, { resist: "all", immune: ["precision"], scope: "instance" }]);
equal("A6 Q32: a spell, or magical damage; not a weapon's own", [B.resistMagicApplies({ kind: "spell" }), B.resistMagicApplies({ kind: "other", magical: true }), B.resistMagicApplies({ kind: "weapon", magical: true }), B.resistMagicApplies({ kind: "other" })], [true, true, false, false]);
equal("A8 Q32 (found in review): a spell's every type and instance until it settles; other magical damage, its types for that blow",
  [B.resistMagicAnswer({ kind: "spell", types: ["fire"] }), B.resistMagicAnswer({ kind: "other", types: ["force"] })],
  [{ resist: "all", scope: "cast" }, { resist: ["force"], scope: "instance" }]);
equal("A9 (found in review) a minor critical's roll is at disadvantage already: not worth a point", [B.eternityWorthOffering("disadvantage"), B.eternityWorthOffering("normal"), B.eternityWorthOffering("advantage"), B.eternityWorthOffering(undefined)], [false, true, true, true]);
const someone = { name: "x" };
equal("A7 Q35: any critical taken from another", [B.eternityApplies({ target: someone, attacker: { name: "y" } }), B.eternityApplies({ target: someone, attacker: someone }), B.eternityApplies({})], [true, false, false]);

/* B — Missed Chance */
{
  reset();
  const witch = actor("Witch", { items: [spell("Missed Chance")] });
  const orc = actor("Orc");
  place(witch, 0, 1);
  const orcToken = place(orc, 4, -1);
  const ctx = { actor: orc, token: orcToken, type: "save", label: "Will Save", succeeded: true, failed: false, exploded: false, total: 18 };
  const out = await R.missedChance.after(ctx);
  ok("B1 an enemy within 30 ft succeeds: the Witch is asked, the hex is cast at the enemy, and the check is rerolled",
    out?.reroll === true && asks.length === 1 && asks[0].actor === "Witch" && asks[0].step === B.CAST_STEP && JSON.stringify(calls.castAsReaction[0]) === JSON.stringify(["Witch", "Missed Chance", [orcToken.id]]));
  equal("B2 Q30: the enemy is immune to Missed Chance for an hour", orc.flags["trg-eldritch-arts"]?.hexImmunity, { "missed chance": 4600 });
  asks.length = 0;
  equal("B3 …so it is not offered again inside the hour", [await R.missedChance.after(ctx), asks.length], [null, 0]);
  game.time.worldTime = 4601;
  ok("B4 …and is after it", (await R.missedChance.after(ctx))?.reroll === true);
  const trials = [
    ["B5 not for a failure", { succeeded: false, failed: true }],
    ["B6 Q29: not if the d20 exploded", { exploded: true }]
  ];
  for (const [label, extra] of trials) { asks.length = 0; game.time.worldTime += 4000; equal(label, [await R.missedChance.after({ ...ctx, ...extra }), asks.length], [null, 0]); }
  orcToken.document._source.x = 900;
  asks.length = 0; game.time.worldTime += 4000;
  equal("B7 not beyond 30 ft (45 ft here)", [await R.missedChance.after(ctx), asks.length], [null, 0]);
  orcToken.document._source.x = 400;
  orcToken.document.disposition = 1;
  asks.length = 0;
  equal("B8 not at an ally", [await R.missedChance.after(ctx), asks.length], [null, 0]);
  orcToken.document.disposition = -1;
  for (const [label, setup, undo] of [
    ["B9 Q28: not by a blinded Witch", () => { witch.hasCondition = (c) => c === "blinded"; }, () => { witch.hasCondition = () => false; }],
    ["B10 not without the PP", () => { witch.system.resources.pp.value = 2; }, () => { witch.system.resources.pp.value = 20; }],
    ["B11 not without a reaction (the core's refusal)", () => { refusal = "no reaction left"; }, () => { refusal = ""; }]
  ]) { setup(); asks.length = 0; equal(label, [await R.missedChance.after(ctx), asks.length], [null, 0]); undo(); }
  answer = "no";
  asks.length = 0;
  equal("B12 a no: asked, nothing cast, no reroll", [await R.missedChance.after(ctx), asks.length, calls.castAsReaction.length], [null, 1, 2]);
  answer = "yes";
  castResult = { cast: false };
  const second = actor("Second Witch", { items: [spell("Missed Chance")] });
  place(second, 5, 1);
  asks.length = 0;
  const out2 = await R.missedChance.after(ctx);
  equal("B13 a cast that fails asks the next Witch in reach", [asks.map((a) => a.actor), out2], [["Witch", "Second Witch"], null]);
}

/* C — Second Chance */
{
  reset();
  const witch = actor("Witch", { items: [spell("Second Chance")] });
  const ally = actor("Ally");
  place(witch, 0, 1);
  const allyToken = place(ally, 6, 1);
  const ctx = { actor: ally, token: allyToken, type: "attack", succeeded: false, failed: true, exploded: true, total: 7 };
  const out = await R.secondChance.after(ctx);
  ok("C1 an ally within 60 ft misses: asked and rerolled, an exploded die notwithstanding (Q29)", out?.reroll === true && /rerolls/.test(out.line));
  ok("C2 …and is immune to Second Chance for an hour", ally.flags["trg-eldritch-arts"]?.hexImmunity?.["second chance"] === 4600);
  game.time.worldTime = 9000; asks.length = 0;
  equal("C3 not for a success", [await R.secondChance.after({ ...ctx, succeeded: true, failed: false }), asks.length], [null, 0]);
  allyToken.document.disposition = -1;
  equal("C4 not for an enemy", await R.secondChance.after(ctx), null);
  allyToken.document.disposition = 1;
  equal("C5 not for the Witch's own check", await R.secondChance.after({ ...ctx, actor: witch, token: witch._token }), null);
  allyToken.document._source.x = 1300;
  equal("C6 not beyond 60 ft (65 ft here)", await R.secondChance.after(ctx), null);
}

/* D — Prophetic Warning */
{
  reset();
  const witch = actor("Witch", { items: [spell("Prophetic Warning")] });
  place(witch, 0, 1);
  const ctx = { actor: witch, token: witch._token, type: "save", label: "Reflex Save", dc: 15 };
  const out = await R.propheticWarning.before(ctx);
  ok("D1 before her own check with a DC: asked of the Witch, cast, advantage", out?.advantage === true && out.label === "Prophetic Warning" && asks[0].actor === "Witch" && asks[0].data.prophetic === true);
  equal("D1b (found live) cast at her own token, its range being self, not at whatever her user has targeted", [asks[0].data.targetTokenIds, calls.castAsReaction[0]?.[2]], [[witch._token.id], [witch._token.id]]);
  ok("D2 …and she is immune to it for an hour", witch.flags["trg-eldritch-arts"]?.hexImmunity?.["prophetic warning"] === 4600);
  asks.length = 0;
  equal("D3 not again inside the hour", [await R.propheticWarning.before(ctx), asks.length], [null, 0]);
  game.time.worldTime = 9000;
  equal("D4 Q31: not for a check with no DC", [await R.propheticWarning.before({ ...ctx, dc: null }), asks.length], [null, 0]);
  settings.propheticWarningPrompt = false;
  equal("D5 Q31: not while the setting is off", [await R.propheticWarning.before(ctx), asks.length], [null, 0]);
  settings.propheticWarningPrompt = true;
  equal("D6 not for a creature without the hex", await R.propheticWarning.before({ ...ctx, actor: actor("Plain") }), null);
  // Cast from the sheet.
  calls.pending.length = 0;
  await B.onSpellSettledB3b({ actor: witch, spell: { name: "Prophetic Warning" }, cast: true });
  equal("D7 cast from the sheet: advantage on the next attack check, save or skill check, once", calls.pending, [["Witch", "advantage", true, ["attack", "save", "skill"]]]);
  await B.onSpellSettledB3b({ actor: witch, spell: { name: "Prophetic Warning" }, cast: false });
  await B.onSpellSettledB3b({ actor: witch, spell: { name: "Missed Chance" }, cast: true });
  equal("D8 …not for a failed cast or another spell", calls.pending.length, 1);
  // The offer's own cast does not arm a second advantage.
  helpers.castAsReaction = async (a, s, ids) => { await B.onSpellSettledB3b({ actor: a, spell: s, cast: true }); return { cast: true, warpPP: 0 }; };
  game.time.worldTime = 20000;
  await R.propheticWarning.before(ctx);
  equal("D9 the offered cast is not also armed for the next check", calls.pending.length, 1);
  helpers.castAsReaction = async (actor, spell, ids) => { calls.castAsReaction.push([actor.name, spell.name, ids]); return castResult; };
}

/* E — Phase Familiar */
{
  reset();
  const witch = actor("Witch", { items: [spell("Phase Familiar", 1, "Hex, Utility")] });
  const owl = actor("Owl", { familiar: { masterId: witch.id } });
  place(witch, 0, 1);
  const owlToken = place(owl, 10, 1);
  const out = await R.phaseFamiliar({ target: owl, kind: "weapon", types: ["slashing"] });
  ok("E1 her familiar within 60 ft, about to be struck: she is asked, the hex cast on it, resistance to all and precision immunity for the strike",
    out?.resist === "all" && JSON.stringify(out.immune) === JSON.stringify(["precision"]) && out.scope === "cast" && JSON.stringify(calls.castAsReaction[0]) === JSON.stringify(["Witch", "Phase Familiar", [owlToken.id]]));
  castResult = { cast: true, warpPP: 10 };
  const warped = await R.phaseFamiliar({ target: owl, kind: "spell", types: ["fire"] });
  ok("E2 warped (+10 PP): immunity to all, for the spell's casting", warped?.immune === "all" && warped.scope === "cast" && !warped.resist);
  castResult = { cast: true, warpPP: 0 };
  equal("E3 not for a creature that is no one's familiar", await R.phaseFamiliar({ target: actor("Stray"), kind: "weapon" }), null);
  owlToken.document._source.x = 1300;
  equal("E4 not beyond 60 ft", await R.phaseFamiliar({ target: owl, kind: "weapon" }), null);
  owlToken.document._source.x = 1000;
  castResult = { cast: false };
  equal("E5 a cast that fails grants nothing", await R.phaseFamiliar({ target: owl, kind: "weapon" }), null);
  castResult = { cast: true, warpPP: 0 };
  const sbOwl = actor("Soul Owl");
  sbOwl.flags["trg-eldritch-arts"] = { soulbound: { masterId: witch.id } };
  place(sbOwl, 2, 1);
  ok("E6 a soulbound familiar's master is found by its mark", (await R.phaseFamiliar({ target: sbOwl, kind: "weapon" }))?.resist === "all");
}

/* F — Resist Magic */
{
  reset();
  const sorc = actor("Rune Sorcerer", { items: [abilityItem("Resist Magic")] });
  place(sorc, 0, 1);
  const out = await R.resistMagic({ target: sorc, kind: "spell", types: ["fire", "cold"], spellName: "Frostfire" });
  ok("F1 a spell's damage: asked, the reaction spent, resistance to all its damage until it resolves", out?.resist === "all" && out.scope === "cast" && /every type and every instance/.test(out.line) && JSON.stringify(calls.spendReaction[0]) === JSON.stringify(["Rune Sorcerer", "Resist Magic"]));
  ok("F2 typed magical damage outside a cast: for that blow", (await R.resistMagic({ target: sorc, kind: "other", magical: true, types: ["force"] }))?.scope === "instance");
  equal("F3 not a weapon's damage, not damage of no type, not without the ability",
    [await R.resistMagic({ target: sorc, kind: "weapon", magical: true, types: ["slashing"] }), await R.resistMagic({ target: sorc, kind: "spell", types: [] }), await R.resistMagic({ target: actor("Plain"), kind: "spell", types: ["fire"] })], [null, null, null]);
  refusal = "flat-footed";
  equal("F4 not when the core refuses the reaction", await R.resistMagic({ target: sorc, kind: "spell", types: ["fire"] }), null);
  refusal = "";
  spendFails = true;
  equal("F5 nothing granted when the reaction could not be spent after all", await R.resistMagic({ target: sorc, kind: "spell", types: ["fire"] }), null);
  spendFails = false;
}

/* G — Disrupting Magic */
{
  reset();
  const arcanum = actor("Arcanum", { items: [spell("Disrupting Magic", 1, "Utility, Warding")] });
  const mage = actor("Enemy Mage");
  place(arcanum, 0, 1);
  const mageToken = place(mage, 20, -1);
  const ctx = { actor: mage, token: mageToken, spell: { name: "Fireball" }, pp: 6, degree: "success" };
  const out = await R.disruptingMagic(ctx);
  ok("G1 an enemy within 120 ft casts: asked; a Success stops the spell", out?.stop === true && /stopped/.test(out.line));
  equal("G2 Q23, Q33: the core's Dispel at no AP, opened on the spell's PP and its caster's spell DC, and the reaction spent",
    [calls.spendReaction[0], calls.resolveAction[0]], [["Arcanum", "Disrupting Magic"], ["Arcanum", "dispel", "0", { effectValue: 6, dc: 16, what: "Fireball", casterUuid: "Actor.a22", spellUuid: "", counterSpell: true }]]);
  dispelDegree = "partial";
  const failed = await R.disruptingMagic(ctx);
  ok("G3 a Partial does not stop it, and says so", failed?.stop === false && /fails to stop/.test(failed.line));
  dispelDegree = "critical";
  ok("G4 a Critical stops it", (await R.disruptingMagic(ctx))?.stop === true);
  mageToken.document.disposition = 1;
  asks.length = 0;
  equal("G5 not an ally's casting", [await R.disruptingMagic(ctx), asks.length], [null, 0]);
  mageToken.document.disposition = -1;
  mageToken.document._source.x = 2500;
  equal("G6 not beyond 120 ft", await R.disruptingMagic(ctx), null);
  mageToken.document._source.x = 2000;
  equal("G7 not the caster's own", await R.disruptingMagic({ ...ctx, actor: arcanum, token: arcanum._token }), null);
  dispelDegree = "success";
  castRefusalReason = "Arcanum cannot cast spells while raging.";
  asks.length = 0;
  equal("G8 (found in review) it is a spell: not while casting is refused", [await R.disruptingMagic(ctx), asks.length], [null, 0]);
  castRefusalReason = "";
  arcanum.system.resources.pp.value = 0;
  asks.length = 0;
  ok("G9 Q23: its own 1 PP is not asked for (the Dispel's PP is)", (await R.disruptingMagic(ctx))?.stop === true && asks.length === 1);
  arcanum.system.resources.pp.value = 20;
  dispelDegree = "";
  calls.spendReaction.length = 0;
  equal("G10 (found in review) a Dispel dialog closed unrolled spends no reaction", [await R.disruptingMagic(ctx), calls.spendReaction.length], [null, 0]);
  const second = actor("Second Arcanum", { items: [spell("Disrupting Magic", 1, "Utility, Warding")] });
  place(second, 1, 1);
  let n = 0;
  helpers.resolveAction = async (a) => { n += 1; return { outcome: { degree: n === 1 ? { key: "failure", label: "Failure" } : { key: "success", label: "Success" } } }; };
  asks.length = 0;
  const both = await R.disruptingMagic(ctx);
  ok("G11 (found in review) one fails, the next in reach tries, and both are told", both?.stop === true && asks.length === 2 && /fails to stop/.test(both.line) && /is stopped/.test(both.line));
  helpers.resolveAction = async (actor, action, opts) => { calls.resolveAction.push([actor.name, action.key, action.apCost, opts.presetDispel]); return dispelDegree ? { outcome: { degree: { key: dispelDegree, label: dispelDegree[0].toUpperCase() + dispelDegree.slice(1) } } } : null; };
  dispelDegree = "success";
  arcanum.system.skills.powerManipulation.ranks = 0;
  second.system.skills.powerManipulation.ranks = 0;
  asks.length = 0;
  equal("G12 (found live) not asked of a creature that could not roll the Dispel (untrained in Power Manipulation)", [await R.disruptingMagic(ctx), asks.length], [null, 0]);
  arcanum.items.push({ id: "fx", type: "feat", name: "Untrained Dispel", flags: { "trg-prime": { untrainedActions: "dispel, tumble" } } });
  ok("G13 …unless something it carries lets it take Dispel untrained", (await R.disruptingMagic(ctx))?.stop === true && asks.length === 1);
  arcanum.hasCondition = (c) => c === "fixated";
  asks.length = 0;
  equal("G15 (found in review) not asked of a Fixated creature: Dispel has the Concentrate trait", [await R.disruptingMagic(ctx), asks.length], [null, 0]);
  arcanum.hasCondition = () => false;
  equal("G14 the reading", [B.canDispel({ system: { skills: { powerManipulation: { ranks: 2 } } } }), B.canDispel({ system: {} }), B.canDispel({ system: {}, items: [], appliedEffects: [{ disabled: true, flags: { "trg-prime": { untrainedActions: ["dispel"] } } }] }), B.canDispel({ system: {}, appliedEffects: [{ flags: { "trg-prime": { untrainedActions: ["Dispel"] } } }] }), B.canDispel({ system: {}, items: [{ flags: { "trg-prime": { untrainedActions: "tumble; feint" } } }] })], [true, false, false, true, false]);
}

/* H — Eternity Resilience */
{
  reset();
  const sorc = actor("Eternity", { items: [abilityItem("Eternity Resilience")] });
  const orc = actor("Orc");
  const out = await R.eternityResilience({ attacker: orc, target: sorc, severity: "deadly", bias: "advantage" });
  ok("H1 a critical taken: asked, a Conviction point spent, disadvantage", out?.disadvantage === true && JSON.stringify(calls.spendConviction) === JSON.stringify(["Eternity"]));
  convictionOk = false;
  equal("H2 Q35: not when the core's one point a round is spent (or none is left)", [await R.eternityResilience({ attacker: orc, target: sorc }), calls.spendConviction.length], [null, 1]);
  convictionOk = true;
  calls.spendConviction.length = 0;
  equal("H4 (found in review) not for a minor critical, already rolled at disadvantage", [await R.eternityResilience({ attacker: orc, target: sorc, severity: "minor", bias: "disadvantage" }), calls.spendConviction.length], [null, 0]);
  equal("H3 not for a creature without it, nor its own critical", [await R.eternityResilience({ attacker: sorc, target: orc }), await R.eternityResilience({ attacker: sorc, target: sorc })], [null, null]);
}

/* I — the steps */
{
  reset();
  dispelDegree = "fumble";
  const a = actor("A");
  equal("I1 the Disrupt step on a Fumble: rolled, not dispelled", await B.STEPS.disruptStep(a, "yes", { effectValue: 4, dc: 15 }), { rolled: true, degree: "Fumble", dispelled: false });
  refusal = "no reaction left";
  equal("I2 …and refused without its reaction, rolling nothing", [await B.STEPS.disruptStep(a, "yes", {}), calls.resolveAction.length], [{ rolled: false }, 1]);
  refusal = "";
  equal("I3 the cast step on an item the creature lacks casts nothing", await B.STEPS.castStep(a, "yes", { spellId: "nope" }), { cast: false });
  const w = actor("W", { items: [spell("Prophetic Warning")] });
  place(w, 0, 1);
  calls.castAsReaction.length = 0;
  await B.STEPS.castStep(w, "yes", { spellId: w.items[0].id, targetTokenIds: [], prophetic: true });
  equal("I4 (found in review) Prophetic Warning's token is found on the casting client, even when the asker had none to send", calls.castAsReaction[0]?.[2], [w._token.id]);
  calls.castAsReaction.length = 0;
  await B.STEPS.castStep(w, "yes", { spellId: w.items[0].id, targetTokenIds: ["t-other"] });
  equal("I5 …and any other cast keeps the ids it was sent", calls.castAsReaction[0]?.[2], ["t-other"]);
}

/* K — the hour's immunity on a creature this client does not own (found in review) */
{
  reset();
  const witch = actor("Witch", { items: [spell("Missed Chance")] });
  const npc = actor("GM's Orc");
  npc.isOwner = false;
  place(witch, 0, 1);
  const npcToken = place(npc, 3, -1);
  const ctx = { actor: npc, token: npcToken, type: "save", label: "Will Save", succeeded: true, failed: false, exploded: false, total: 18 };
  game.users.activeGM = { id: "gm" };
  ok("K1 not owned: the reroll stands, and the GM is asked to mark it", (await R.missedChance.after(ctx))?.reroll === true && !npc.flags["trg-eldritch-arts"]
    && JSON.stringify(emitted) === JSON.stringify([[B.SOCKET, { action: "hexImmunity", actorUuid: npc.uuid, hex: "Missed Chance" }]]));
  game.user.isGM = false;
  equal("K2 the request is the active GM's to write, nobody else's", [await B.onHexImmunityRequest(emitted[0][1]), npc.flags["trg-eldritch-arts"]], [false, undefined]);
  game.user.isGM = true;
  equal("K3 the GM writes the hour", [await B.onHexImmunityRequest(emitted[0][1]), npc.flags["trg-eldritch-arts"]?.hexImmunity], [true, { "missed chance": 4600 }]);
  equal("K4 nothing else is written by the request", [await B.onHexImmunityRequest({ action: "other", actorUuid: npc.uuid, hex: "x" }), await B.onHexImmunityRequest({ action: "hexImmunity", actorUuid: "Actor.none", hex: "x" })], [false, false]);
  emitted.length = 0; game.users.activeGM = null; game.time.worldTime = 9000;
  ok("K5 no GM connected: said so, nothing sent", (await R.missedChance.after(ctx))?.reroll === true && emitted.length === 0 && warned.some((w) => /No GM is connected/.test(w)));
  B.registerBlock3bSocket();
  ok("K6 the listener is on the module's channel", emitted.listener?.[0] === "module.trg-eldritch-arts" && typeof emitted.listener?.[1] === "function");
}

/* J — registration, hooks, the cards, versions */
{
  const got = {};
  const fakeApi = new Proxy({}, { get: (_, k) => (...args) => { (got[k] ??= []).push(args[0]); return true; } });
  B.registerBlock3b(fakeApi, "trg-eldritch-arts");
  equal("J1 registered: three check reactions, two damage, one cast, one critical, four steps",
    [got.registerCheckReaction, got.registerDamageReaction, got.registerCastReaction, got.registerCriticalReaction, got.registerReactionStep],
    [["missedChance", "secondChance", "propheticWarning"], ["phaseFamiliar", "resistMagic"], ["disruptingMagic"], ["eternityResilience"], [B.CAST_STEP, B.SPEND_STEP, B.DISRUPT_STEP, B.CONVICTION_STEP]]);
  B.registerBlock3bSettings();
  equal("J2 Q31's setting: for the table (found in review: a check is often rolled on another client), shown, on by default", [settings.__registered?.k, settings.__registered?.spec?.scope, settings.__registered?.spec?.config, settings.__registered?.spec?.default], ["propheticWarningPrompt", "world", true, true]);
  ok("J3 the setting at init; the sheet cast's arming on the settled hook",
    /Hooks\.once\("init", \(\) => \{ registerAreaTypes\(\); registerBlock3bSettings\(\); \}\);/.test(script) && /Hooks\.on\("trgPrimeSpellSettled", \(ctx\) => \{ onSpellSettledB3b\(ctx\)/.test(script));
  ok("J3b the GM's listener at ready", /Hooks\.once\("ready", \(\) => registerBlock3bSocket\(\)\);/.test(script));
  const reg = fs.readFileSync(path.join(ROOT, "module", "registration.mjs"), "utf8");
  ok("J4 registered with the rest of the content", /registerBlock3b\(api, moduleId\);/.test(reg));
  const cardOf = (name) => S.BLOCK3_SPECIALIST.find((s) => s.name === name)?.system?.description ?? "";
  ok("J5 the five spells' cards say what is automated, and none waits any more",
    ["Missed Chance", "Second Chance", "Prophetic Warning", "Phase Familiar", "Disrupting Magic"].every((n) => /Automated \(0\.6\.0, TRG Prime 3\.681\.0\):/.test(cardOf(n)) && !/Waits for Block 3b/.test(cardOf(n))));
  ok("J6 …and Resist Magic's and Eternity Resilience's", [C3.RESIST_MAGIC_ABILITY, C3.ETERNITY_RESILIENCE].every((d) => /Automated \(0\.6\.0, TRG Prime 3\.681\.0\):/.test(d.system.description) && !/Waits for Block 3b/.test(d.system.description)));
  // 0.6.1 OR LATER, ON 3.681.0 OR LATER (Block 4 moved both; verify-block4 pins them).
  const atLeast = (v, min) => { const a = String(v).split(".").map(Number), b = min.split(".").map(Number); for (let i = 0; i < 3; i += 1) { if ((a[i] ?? 0) !== b[i]) return (a[i] ?? 0) > b[i]; } return true; };
  equal("J7 0.6.1 or later, on TRG Prime 3.681.0 or later", [atLeast(manifest.version, "0.6.1"), atLeast(manifest.relationships.systems[0].compatibility.minimum, "3.681.0"), /REQUIRED_SYSTEM = "3\.(?:68[1-9]|69\d)\.\d+"/.test(script)], [true, true, true]);
}

if (failures.length) {
  console.log(`verify-block3b: ${checks} checks, ${failures.length} failure(s).`);
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exit(1);
}
console.log(`verify-block3b: ${checks} checks, 0 failure(s).`);
