#!/usr/bin/env node
/**
 * verify-block6b2 — Eldritch Arts 0.9.0 (Block 6, group B2, on TRG Prime
 * 3.684.0): Runebreaker, Shade Master, Spellwarden, Spell Duellist, Spell
 * Weaver, Stormcaller, their eighteen class feats, their four abilities and
 * the burst Storm Bolt.
 *
 *   A  every feat against the book: name, category, traits as stored,
 *      prerequisites, progression line, uses, the printed text and the
 *      automation paragraph, the docs' table
 *   B  the data: grants, conditionals, the defence row, declarations, the
 *      abilities and the variant spell, Storing Rune's host (G16)
 *   C  the core, run with the content: G8's progression, the archetype gate,
 *      the conditionals and the defence row, G21's extra uses, G1's specs,
 *      G17's shape, the Dispel modifiers, G9, G16's host, the Focus uses
 *   D  the pure rules
 *   E  registration
 *   F  the Foundry side with fakes: every Use, reaction, step and hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6b2.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const confirms = [];
const reactorAnswers = [];
const asked = [];
const calls = { spendReaction: [], rollCheck: [], area: [], store: [], strikes: [], damage: [], conditions: [], armMove: [] };
let checkDegree = "success";
let reactionRefused = "";
let lightQueue = [];
let lightDefault = 3;
let strikeOutcome = { hits: false, critical: null };
const STEPS = {};
const ATTR = (item) => item?.parent?.system?.attributes ?? {};
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; helpers.lastLabel = label; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => {
    const f = String(item.system?.usesPerDay ?? "").trim();
    const bonus = Number(item.system?.bonusUses ?? 0);
    if (/^\d+$/.test(f)) return Number(f) + bonus;
    if (f === "intelligence") return Math.max(0, Number(ATTR(item).intelligence?.total ?? 0)) + bonus;
    return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null;
  },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title, step: q.step, data: q.data }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; if (a !== "yes") return { answer: a, result: null }; return { answer: a, result: await STEPS[q.step](actor, a, q.data) }; },
  spendReaction: async (actor, label) => { calls.spendReaction.push([actor.name, label]); return true; },
  reactionRefusal: async () => reactionRefused,
  isDead: async () => false,
  lightLevelAt: async () => (lightQueue.length ? lightQueue.shift() : lightDefault),
  rollCheck: async (config) => { calls.rollCheck.push(config); return { outcome: { degree: { key: checkDegree }, total: 20 } }; },
  runAreaEffect: async (actor, spec, opts) => { calls.area.push({ actor: actor.name, spec, opts }); if (Array.isArray(opts?.results)) opts.results.push({ degree: helpers.areaDegree ?? "failure" }); return [`area:${opts?.title}`]; },
  storeForeignSpell: async (actor, spell, opts) => { calls.store.push({ actor: actor.name, spell: spell?.name, opts }); return { item: opts.host, spell }; },
  innateSaveDCFor: async () => ({ value: 21 }),
  rollWeaponAttack: async (actor, weapon, opts) => { if (helpers.refuseStrike) return null; calls.strikes.push({ actor: actor.name, weapon: weapon.name, opts, targets: [...game.user.targets].map((t) => t.id) }); if (opts.beforeDamage) await opts.beforeDamage({ outcome: { ...strikeOutcome }, check: {} }); return {}; },
  applyTypedDamage: async (actor, d) => { calls.damage.push({ actor: actor.name, ...d }); actor.system.resources.hp.value -= d.amount; },
  applyConditionTags: async (actor, tags, opts) => { calls.conditions.push({ actor: actor.name, tags, opts }); },
  armMove: async (actor, leg, label) => { calls.armMove.push({ actor: actor.name, leg, label }); return true; }
};
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
const uuidMap = new Map();
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => (confirms.length ? confirms.shift() : true) } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, deepClone: (x) => JSON.parse(JSON.stringify(x)), fromUuid: async (u) => uuidMap.get(u) ?? null } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { const m = /^(\d+)d(\d+)$/.exec(this.f); this.total = m ? Number(m[1]) * 4 : 0; return this; } };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.uuid = `${parent.uuid}.Item.${it.id}`;
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  uuidMap.set(it.uuid, it);
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(e, k, v); };
  return e;
}
function makeActor(name, { level = 10, items = [], pp = 10, ap = 3, hp = 20, int = 3, dc = 18 } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [], documentName: "Actor", conditions: new Set() };
  a.system = { identity: { level }, attributes: { intelligence: { total: int }, charisma: { total: 2 } }, resources: { pp: { value: pp, max: 20 }, ap: { value: ap }, hp: { value: hp } }, magic: { spellcraft: { dc }, castingAbility: "charisma" } };
  a.items = Object.assign(items.map((d) => makeItem(d, a)), { get(id) { return this.find((i) => i.id === id); } });
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = list.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => { a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.hasCondition = (k) => a.conditions.has(k);
  a.getConditionValue = () => 0;
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
let refuseTeleport = false;
let clicked = null;
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100, isTargeted: false };
  t.document = { actor, disposition, width: 1, height: 1, uuid: `Scene.s.Token.${id}`, _source: { x: x - 50, y: y - 50, width: 1, height: 1 }, update: async (u) => { if (!refuseTeleport) Object.assign(t.document._source, { x: u.x, y: u.y }); } };
  t.setTarget = (on) => { t.isTargeted = on; if (on) game.user.targets.add(t); else game.user.targets.delete(t); };
  actor.token = t;
  uuidMap.set(t.document.uuid, t.document);
  return t;
}
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.684.0" }
};
globalThis.canvas = {
  tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }), getSnappedPoint: (p) => ({ x: Math.round(p.x / 100) * 100, y: Math.round(p.y / 100) * 100 }) },
  stage: { on: (ev, fn) => { if (clicked) fn({ data: { getLocalPosition: () => clicked } }); }, off() {} }
};
const startCombat = (actor, { round = 1, turn = 0, others = [] } = {}) => {
  const turns = [{ actor, actorId: actor.id }, ...others.map((o) => ({ actor: o, actorId: o.id }))];
  game.combat = { id: "c1", started: true, round, turn, combatants: turns, turns, combatant: turns[turn] };
};

const C = await import(new URL("./content/block6-b2.mjs", import.meta.url));
const common = await import(new URL("./content/block6-common.mjs", import.meta.url));
const auto = await import(new URL("../module/block6b2-automations.mjs", import.meta.url));
Object.assign(STEPS, { [auto.ABSORB_STEP]: auto.STEPS_B6_B2.absorbStep, [auto.COUNTER_STEP]: auto.STEPS_B6_B2.counterStep, [auto.RIPOSTE_STEP]: auto.STEPS_B6_B2.riposteStep });
const F = Object.fromEntries(C.FEATS_B6_B2.map((f) => [f.name, f]));
const plainText = (html) => String(html ?? "").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&");
const prints = (f, l) => plainText(f.system.description).includes(l.replace(/\*\*/g, "").slice(0, 50));
const A = Object.fromEntries(C.ABILITIES_B6_B2.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS];

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
const ARCH = {
  "RUNEBREAKER": ["Sorcerer", "Rune Birthright, Linguistics 2 ranks", "cannot progress"],
  "SHADE MASTER": ["Sorcerer", "Umbral Birthright, Survival 2 ranks", "cannot progress"],
  "SPELLWARDEN": ["Archmage", "Arcana skill 2 ranks", "Arcana +10 ranks"],
  "SPELL DUELLIST": ["Spellblade", "Level 2", "+10 levels."],
  "SPELL WEAVER": ["Archmage, Wizard", "Arcana skill 2 ranks", "Arcana +10 ranks"],
  "STORMCALLER": ["Sorcerer", "Storm Birthright, Survival 2 ranks", "cannot progress"]
};
const CLASS = {
  "ABSOLUTE DENIAL": ["Spellwarden", ""], "DEEP WEAVE": ["Spell Weaver", ""], "DUELLIST’S FOCUS": ["Spell Duellist", ""], "DUELLIST’S SUPREMACY": ["Spell Duellist", ""],
  "ECLIPSE STEP": ["Shade Master, Shadow", ""], "EXTRA RESERVOIR": ["Spell Weaver", ""], "EYE OF THE STORM": ["Air, Electricity, Stormcaller", "1"], "GLYPH SHATTER": ["Runebreaker, Runemage", ""],
  "GRASPING SHADOWS": ["Shade Master, Shadow", ""], "IMPROVED COUNTER CHANNEL": ["Spellwarden", ""], "INSTINCTIVE COUNTER CHANNEL": ["Spellwarden", ""], "OVERFLOW CASTING": ["Focus, Spell Weaver", ""],
  "REFLECTIVE WARDING": ["Spellwarden", ""], "RIPPLING COUNTER": ["Spell Duellist", ""], "RUNE REND": ["Runebreaker", ""], "RUNIC OVERLOAD": ["Focus, Force, Runebreaker, Save", ""],
  "SHADOWMANTLE": ["Shade Master", ""], "WELLSPRING CONDUIT": ["Focus, Spell Weaver", ""]
};
{
  const t = common.titleCase;
  equal("A twenty-four feats: six archetypes, eighteen class feats, in the book's names", C.FEATS_B6_B2.map((f) => f.name), [...Object.keys(ARCH), ...Object.keys(CLASS)].map(t));
  // The split with group B1, by the book's own traits (the brief's rule).
  const mine = ["RUNEBREAKER", "SHADE-MASTER", "SPELLWARDEN", "SPELL-DUELLIST", "SPELL-WEAVER", "STORMCALLER"];
  const byTrait = common.bookNames("class").filter((n) => common.bookFeat(n).traits.some((x) => mine.includes(x)) && !["LIGHTNING ROD", "THUNDERCLAP AURA"].includes(n));
  equal("A …every class feat naming one of the six archetypes, but Lightning Rod and Thunderclap Aura (group D)", byTrait.sort(), Object.keys(CLASS).sort());
  for (const [key, [traits, prereq, prog]] of Object.entries(ARCH)) {
    const f = F[t(key)], b = common.bookFeat(key, "archetype");
    equal(`A ${f.name}: archetype, its classes, prerequisites, progression line`, [f.type, f.system.category, f.system.traits, f.system.prerequisites, f.system.progressionRequirements], ["feat", "Archetype", traits, prereq, prog]);
    ok(`A ${f.name}: the card prints the book's text`, b.lines.every((l) => prints(f, l)));
    ok(`A ${f.name}: the card prints the book's progression line or none`, b.fields["Progression Requirements"] ? f.system.description.includes(b.fields["Progression Requirements"]) : !/Progression Requirements/.test(f.system.description));
    ok(`A ${f.name}: the card says what is automated`, /<em>(Automated|Partly automated|Granted)/.test(f.system.description));
    equal(`A ${f.name}: Block 6 and its book line`, [fl(f.name).eaBlock, fl(f.name).eaBookLine], [6, b.line]);
  }
  for (const [key, [traits, uses]] of Object.entries(CLASS)) {
    const f = F[t(key)], b = common.bookFeat(key);
    equal(`A ${f.name}: class, traits stored spaced, prerequisite, uses`, [f.system.category, f.system.traits, f.system.prerequisites, f.system.usesPerDay], ["Class", traits, b.fields.Prerequisites, uses]);
    ok(`A ${f.name}: the card prints the book's text`, b.lines.every((l) => prints(f, l)));
    ok(`A ${f.name}: the card says what is automated`, /<em>(Automated|Partly automated|Granted)/.test(f.system.description));
    equal(`A ${f.name}: Block 6 and its book line`, [fl(f.name).eaBlock, fl(f.name).eaBookLine], [6, b.line]);
  }
  ok("A no stored trait keeps a hyphen", C.FEATS_B6_B2.every((f) => !/-/.test(f.system.traits)));
  equal("A the docs' table: every feat, by its item's name", Object.keys(C.AUTOMATION_B6_B2), C.FEATS_B6_B2.map((f) => f.name));
  equal("A …graded A 8, B 13, C 3, D 0", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B6_B2).filter((r) => r.level === l).length), [8, 13, 3, 0]);
  ok("A the rulings are cited where they decided it", [["Runebreaker", "Q115"], ["Runebreaker", "Q91"], ["Spell Duellist", "Q90"], ["Absolute Denial", "Q119"], ["Stormcaller", "Q93"], ["Grasping Shadows", "Q121"], ["Runic Overload", "Q116"], ["Eclipse Step", "Q120"]].every(([n, q]) => F[n].system.description.includes(q)));
  ok("A the C feats say what is the GM's", ["Absolute Denial", "Eye of the Storm", "Reflective Warding"].every((n) => /GM/.test(F[n].system.description) && C.AUTOMATION_B6_B2[n].level === "C"));
  ok("A Wellspring Conduit's card is automated, reads the PP as cast and cites Graham's ruling of 4 November 2026",
    /<em>Automated \(0\.9\.1/.test(F["Wellspring Conduit"].system.description) && /Graham(’|')s ruling, 4 November 2026/.test(F["Wellspring Conduit"].system.description) && /the warps and every metamagic option/.test(F["Wellspring Conduit"].system.description) && !/GM/.test(F["Wellspring Conduit"].system.description));
  // REVIEW (0.9.1): Economic and Signature Spell lower `castPP`, a G4 discount does not.
  ok("A …and says Economic and Signature Spell lower that PP, another discount (G4's) does not",
    /Economic Spell and Signature Spell lower that figure/.test(F["Wellspring Conduit"].system.description) && /G4(’|')s\) is taken off what you pay and does not/.test(F["Wellspring Conduit"].system.description) && !/a PP discount does not lower them/.test(F["Wellspring Conduit"].system.description));
  ok("A Shadowmantle's card and table entry: +1 circumstance to DB, which does not stack with another circumstance bonus",
    /\+1 circumstance to your DB against spell attacks \(a circumstance bonus: it does not stack with another circumstance bonus to your DB/.test(F.Shadowmantle.system.description) && /\+1 circumstance vs spell attacks/.test(C.AUTOMATION_B6_B2.Shadowmantle.what) && /stacks it by type/.test(C.AUTOMATION_B6_B2.Shadowmantle.what));
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
{
  equal("B the grants: Fade Step and Dark Whispers; Counter Channel; Spellstrike Riposte; the Reservoir; the burst Storm Bolt",
    [[F["Shade Master"].system.grantedAbilities, F["Shade Master"].system.grantedSpells], F.Spellwarden.system.grantedAbilities, F["Spell Duellist"].system.grantedAbilities, F["Spell Weaver"].system.grantedAbilities, F.Stormcaller.system.grantedSpells],
    [["Fade Step", "Dark Whispers"], "Counter Channel", "Spellstrike Riposte", "Magical Reservoir", "Storm Bolt (Burst)"]);
  equal("B Spell Duellist opts in to G8's +N levels (Q90); no other archetype does", C.FEATS_B6_B2.filter((f) => f.flags[SYS].progressionSinceTaken).map((f) => f.name), ["Spell Duellist"]);
  const cd = fl("Spell Duellist").conditionals[0];
  equal("B Spell Duellist: +2 class on Spell Recognition, automatic", [cd.kind, cd.value, cd.type, cd.auto, cd.when], ["modifier", 2, "class", true, { actions: ["spellRecognition"] }]);
  const sw = fl("Spellwarden").conditionals[0];
  equal("B Spellwarden's other-magic row: +2 class on saves, a tick", [sw.value, sw.type, sw.auto, sw.when], [2, "class", false, { checkTypes: ["save"] }]);
  equal("B Shadowmantle's defence row: DB +1 vs spell attacks in light 5 or less (G20)", fl("Shadowmantle").defenceDC, [{ dc: "defence", value: 1, type: "circumstance", label: "Shadowmantle", scope: "spell attacks, in light 5 or less", when: { attackKinds: ["spell"], lightLevels: { max: 5 } } }]);
  equal("B the abilities: archetype category, traits from the sidebars, the Reservoir's Intelligence uses", C.ABILITIES_B6_B2.map((a) => [a.name, a.type, a.system.category, a.system.traits, a.system.usesPerDay]),
    [["Fade Step", "ability", "Archetype", "Focus, Shadow, Teleportation", ""], ["Counter Channel", "ability", "Archetype", "Focus, Warding", ""], ["Spellstrike Riposte", "ability", "Archetype", "Focus, Invocation", ""], ["Magical Reservoir", "ability", "Archetype", "", "intelligence"]]);
  ok("B …each ability's card prints its sidebar and says what is automated", ["FADE STEP", "COUNTER CHANNEL", "SPELLSTRIKE RIPOSTE"].every((s, i) => { const sb = book.sidebars.find((x) => x.title === s); return sb.lines.slice(2).every((l) => C.ABILITIES_B6_B2[i].system.description.includes(l.slice(0, 40))) && /Automated/.test(C.ABILITIES_B6_B2[i].system.description); }));
  const burst = C.STORM_BOLT_BURST;
  equal("B the burst Storm Bolt: a save at 3 PP (1 + 2), basic Reflex, 10-ft radius, the attack trait dropped, the four types chosen", [burst.name, burst.type, burst.system.category, burst.system.ppCost, burst.system.defence, burst.system.area, burst.system.traits, burst.system.damage.formula, burst.system.effects[0]?.damageTypes, burst.flags[SYS].eaVariantOf, burst.system.specialist],
    ["Storm Bolt (Burst)", "spell", "save", 3, "basic Reflex", "10-foot radius", "Elemental, Invocation, Save, Utility", "1d12", ["acid", "cold", "electricity", "fire"], "Storm Bolt", true]);
  ok("B …its id is stable and its own", /^[A-Za-z0-9]{16}$/.test(burst._id) && C.SPELLS_B6_B2.length === 1);
  const b3 = await import(new URL("./content/block3-spells.mjs", import.meta.url));
  equal("B Storing Rune's row names its host: the spell (G16's fix)", b3.BLOCK3_SPECIALIST.find((s) => s.name === "Storing Rune").system.effects, [{ kind: "spellStoring", label: "Storing Rune", target: "self", host: "spell" }]);
  equal("B the module's own flags are ea-prefixed", C.FEATS_B6_B2.flatMap((f) => Object.keys(f.flags[SYS]).filter((k) => !k.startsWith("ea") && !["conditionals", "defenceDC", "progressionSinceTaken"].includes(k))), []);
}

/* ----------------------------------------------------------------- */
/* C — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
{
  const ap = await quiet(() => import(sys("module", "archetype-progression.mjs")));
  equal("C G8: Runebreaker, Shade Master, Stormcaller never progress (Q91)", ["Runebreaker", "Shade Master", "Stormcaller"].map((n) => ap.meetsProgressionRequirement(F[n].system.progressionRequirements, { level: 20 }, {})), [false, false, false]);
  const ctx = ap.archetypeProgressionContext({ flags: { [SYS]: { ...fl("Spell Duellist"), archetypeTakenAt: 2 } } });
  equal("C G8: Spell Duellist taken at 2 completes at 12, not 11 (Q90)", [ap.meetsProgressionRequirement(F["Spell Duellist"].system.progressionRequirements, { level: 11 }, ctx), ap.meetsProgressionRequirement(F["Spell Duellist"].system.progressionRequirements, { level: 12 }, ctx)], [false, true]);
  equal("C …and the feat is stamped when it arrives", ap.archetypeTakenAtStamp(F["Spell Duellist"], 7), { "flags.trg-prime.archetypeTakenAt": 7 });
  equal("C …Spellwarden's Arcana +10 ranks parses", ap.parseProgressionClause(F.Spellwarden.system.progressionRequirements)?.type ?? null, "skillAny");

  const cond = await quiet(() => import(sys("module", "conditionals.mjs")));
  const duel = cond.normaliseConditional(fl("Spell Duellist").conditionals[0], { name: "Spell Duellist" }, 0);
  equal("C Spell Duellist's row matches Spell Recognition, not another skill check", [cond.matchesCheck(duel, { checkType: "skill", subject: "arcana", actionKey: "spellRecognition" }), cond.matchesCheck(duel, { checkType: "skill", subject: "arcana", actionKey: "recallKnowledge" })], [true, false]);

  const dd = await quiet(() => import(sys("module", "combat", "defence-dc.mjs")));
  const shadow = { items: [{ id: "f", name: "Shadowmantle", flags: F.Shadowmantle.flags }], effects: [] };
  const db = (kind, light) => dd.defenceDCBonus(shadow, "defence", "", [], "x", [], [], { attackKind: kind, lightLevel: light }).total;
  equal("C Shadowmantle's DB: a spell attack at light 5 yes, 6 no, a Strike no, unknown light no", [db("spell", 5), db("spell", 6), db("weapon", 3), db("spell", null)], [1, 0, 0, 0]);
  // TYPED (0.9.1; TRG Prime 3.684.1 stacks defence rows by type): the book's
  // "+1-circumstance bonus to DB", so under a +2 circumstance already on the
  // DB it adds nothing, and beside a +1 status it still adds.
  const shadowWith = (entries) => ({ ...shadow, system: { combat: { defence: { breakdown: { entries } } } } });
  const dbWith = (entries) => dd.defenceDCBonus(shadowWith(entries), "defence", "", [], "x", [], [], { attackKind: "spell", lightLevel: 3 });
  equal("C …typed circumstance: under a +2 circumstance 0 (named as not counted), beside a +1 status +1",
    [dbWith([{ label: "Cover", value: 2, type: "circumstance" }]).total, dbWith([{ label: "Cover", value: 2, type: "circumstance" }]).notCounted.length, dbWith([{ label: "Bless", value: 1, type: "status" }]).total], [0, 1, 1]);

  capi.resetModuleRegistry();
  const fake = new Proxy({}, { get: (_, k) => (typeof capi[k] === "function" ? (...a) => capi[k](...a) : () => {}) });
  auto.registerBlock6B2(fake, "test");
  equal("C every registration is accepted by the core", capi.registrationProblems(), []);
  const eu = await quiet(() => import(sys("module", "extra-uses.mjs")));
  equal("C G21: Deep Weave +1, Extra Reservoir +2, to the Magical Reservoir only", [eu.extraUsesBonus(["Deep Weave"], "Magical Reservoir"), eu.extraUsesBonus(["Deep Weave", "Extra Reservoir"], "Magical Reservoir"), eu.extraUsesBonus(["Extra Reservoir"], "Counter Channel")], [1, 3, 0]);
  const mm = capi.registeredMetamagic();
  equal("C G1: the four options, Spell Weaver's in one group, paid in a charge; Wellspring a Focus option", mm.map((s) => [s.key, s.feats, s.group, s.payment.kind, s.focus]),
    [[auto.MM.discount, ["Spell Weaver"], auto.WEAVER_GROUP, "resource", false], [auto.MM.dieStep, ["Spell Weaver"], auto.WEAVER_GROUP, "resource", false], [auto.MM.extend, ["Spell Weaver"], auto.WEAVER_GROUP, "resource", false], [auto.MM.wellspring, ["Wellspring Conduit"], "", "pp", true]]);
  const mmlib = await quiet(() => import(sys("module", "magic", "module-metamagic.mjs")));
  equal("C …the discount answer is −2 PP floored at 0 (payment only, Q93); the step one die", [mmlib.cleanMetamagicAnswer(mm[0].effects).discount, mmlib.cleanMetamagicAnswer(mm[1].effects).dieStep], [{ pp: 2, floor: 0, label: "Magical Reservoir" }, 1]);
  equal("C …the ×1.5 answers by the choice", ["duration", "range", "area"].map((c) => { const a = mmlib.cleanMetamagicAnswer(mm[2].apply({ choice: c })); return [a.durationFactor, a.rangeFactor, a.areaFactor]; }), [[1.5, 1, 1], [1, 1.5, 1], [1, 1, 1.5]]);
  const shape = await import(sys("module", "magic", "cast-reaction-shape.mjs"));
  equal("C G17: Counter Channel's answers fold as the core reads them", ["critical", "success", "failure", "fumble"].map((d) => { const a = auto.counterChannelAnswer(d); return a?.stop ? "stop" : shape.castReactionShape([a]); }),
    // TRG Prime 3.685.0 (H5) adds `exclude` and `turnBack` to every fold, empty when unanswered.
    ["stop", { scale: 0.5, saveBias: "advantage", retargetCaster: false, exclude: [], turnBack: null, ignored: 0 }, { scale: 1, saveBias: "", retargetCaster: false, exclude: [], turnBack: null, ignored: 0 }, { scale: 2, saveBias: "disadvantage", retargetCaster: false, exclude: [], turnBack: null, ignored: 0 }]);
  equal("C …Reflective Warding's Critical retargets", shape.castReactionShape([auto.counterChannelAnswer("critical", { reflect: true })]).retargetCaster, true);
  const dm = await quiet(() => import(sys("module", "combat", "dispel-modifiers.mjs")));
  const breaker = { name: "B", items: [{ type: "feat", name: "Runebreaker" }], uuid: "Actor.B", getFlag: () => null };
  const offers = await dm.offeredDispelModifiers({ actor: breaker });
  const setup = { pp: 5, ...dm.combinedDispelModifiers(dm.appliedDispelOffers(offers, [])) };
  const setup2 = { pp: 2, ...dm.combinedDispelModifiers(dm.appliedDispelOffers(offers, [])) };
  equal("C Runebreaker's Dispel: 5 declared pays 3, 2 pays 1 (min 1); the counteract value stays the PP declared", [dm.dispelPPPaid("success", setup).pp, dm.dispelPPPaid("success", setup2).pp, dm.dispelCounteractValue(setup)], [3, 1, 5]);
  equal("C …nothing for a creature without it", (await dm.offeredDispelModifiers({ actor: { items: [], getFlag: () => null } })).length, 0);
  const sorc = (name) => ({ items: [{ type: "ability", name, system: { active: true }, flags: { [SYS]: { eaBirthright: name } } }] });
  equal("C G9: Runebreaker for a Rune Sorcerer, not a Storm one; Stormcaller and Shade Master likewise", [capi.featEligibilityBlock("Runebreaker", sorc("Rune")), Boolean(capi.featEligibilityBlock("Runebreaker", sorc("Storm"))), capi.featEligibilityBlock("Stormcaller", sorc("Storm")), Boolean(capi.featEligibilityBlock("Shade Master", sorc("Rune"))), capi.featEligibilityBlock("Shade Master", sorc("Umbral"))], [null, true, null, true, null]);
  equal("C the Shade Master warp: Shadow Shift, +3 PP, its unlock", capi.registeredSpellWarps("Shade Master").map((e) => [e.match.name, e.warp.ppCost, e.warp.mods.unlocks]), [["shadow shift", 3, [auto.SHADE_UNLOCK]]]);
  ok("C the cast reactions, in order: Absolute Denial first", capi.registeredCastReactions().length === 3 && capi.registeredCastReactions()[0] === auto.REACTIONS_B6_B2.absoluteDenial);
  ok("C the steps reach the core's registry", [auto.ABSORB_STEP, auto.COUNTER_STEP, auto.RIPOSTE_STEP].every((s) => capi.registeredReactionStep(s)));
  capi.resetModuleRegistry();

  const ss = await import(sys("module", "magic", "spell-storing.mjs"));
  const b3 = await import(new URL("./content/block3-spells.mjs", import.meta.url));
  const row = ss.normaliseSpellStoring(b3.BLOCK3_SPECIALIST.find((s) => s.name === "Storing Rune").system.effects[0]);
  equal("C G16: the core reads Storing Rune's host as the spell, and finds it by the spell's id", [row.host, ss.spellStoreHostOf([{ id: "rune1" }, { id: "x", flags: { [SYS]: { arcaneBond: true } } }], { host: row.host, spellId: "rune1" })?.id], ["spell", "rune1"]);

  const uses = await import(sys("module", "uses.mjs"));
  equal("C the Focus abilities and feats have one use each; the Reservoir its Intelligence", [...C.ABILITIES_B6_B2.slice(0, 3), F["Overflow Casting"], F["Runic Overload"], F["Wellspring Conduit"]].map((f) => uses.focusDefaultUses(f.system, f.type)).concat([uses.resolveUsesPerDay(A["Magical Reservoir"].system.usesPerDay, { intelligence: 4 })]), [1, 1, 1, 1, 1, 1, 4]);
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  equal("D shadow is light 5 or less; unknown is not", [1, 5, 6, null].map(auto.inShadow), [true, true, false, false]);
  equal("D 1d6 per 2 PP: 1 → none, 2 → 1d6, 7 → 3d6", [1, 2, 7].map((n) => auto.perTwoPP(n)), ["", "1d6", "3d6"]);
  const me = {}, foe = {};
  equal("D Q115: the sole target only; not an area, not two targets, not your own", [auto.absorbable({ targets: [me], reactor: me, caster: foe }), auto.absorbable({ targets: [me, foe], reactor: me, caster: foe }), auto.absorbable({ targets: [me], reactor: me, caster: foe, spellData: { area: "20-foot burst" } }), auto.absorbable({ targets: [me], reactor: me, caster: me })], [true, false, false, false]);
  equal("D Counter Channel: 30 ft, 60 Improved; DC 10 + PP + ability with a save, else the Spell DC", [auto.counterChannelFeet(false), auto.counterChannelFeet(true), auto.counterChannelDC({ hasSave: true, pp: 4, castingAbility: 3, spellDC: 19 }), auto.counterChannelDC({ hasSave: false, pp: 4, castingAbility: 3, spellDC: 19 })], [30, 60, 17, 19]);
  equal("D Absolute Denial: an enemy's 8 PP from within 20 ft yes; 9 PP no; an ally no; a target inside yes; suppressed no; unconscious no",
    [auto.denialStops({ pp: 8, enemy: true, casterFeet: 20 }), auto.denialStops({ pp: 9, enemy: true, casterFeet: 5 }), auto.denialStops({ pp: 2, enemy: false, casterFeet: 5 }), auto.denialStops({ pp: 2, enemy: true, casterFeet: 60, targetFeet: [15] }), auto.denialStops({ pp: 2, enemy: true, casterFeet: 5, suppressed: true }), auto.denialStops({ pp: 2, enemy: true, casterFeet: 5, conscious: false }), auto.denialStops({ pp: 2, enemy: true, casterFeet: 25 })],
    [true, false, false, true, false, false, false]);
  const g = auto.graspingSpec(17);
  equal("D Grasping Shadows: Reflex vs the Spell DC; Slowed 1, Immobilised (Partial as Failure, m42), a round", [g.save, g.basic, g.dc, g.conditions.critical, g.conditions.success, g.conditions.partial, g.conditions.failure, g.conditions.blunder], ["reflex", false, 17, [], [{ key: "slowed", value: 1, rounds: 1 }], [{ key: "immobilised", rounds: 1 }], [{ key: "immobilised", rounds: 1 }], [{ key: "immobilised", rounds: 1 }]]);
  equal("D …the Blunder's tear: 1d6 per 2 character levels", [auto.graspingTear(9), auto.graspingTear(10)], ["4d6", "5d6"]);
  equal("D Spell Weaver's ×1.5 by choice", ["duration", "range", "area", ""].map(auto.weaverExtend), [{ durationFactor: 1.5 }, { rangeFactor: 1.5 }, { areaFactor: 1.5 }, null]);
  equal("D the Reservoir's minimum 1: Int 3 nothing, Int 0 or −1 one", [3, 1, 0, -1].map(auto.reservoirFloorBonus), [0, 0, 1, 1]);
  equal("D Overflow: 2d6 per missing charge", [auto.overflowDice(0), auto.overflowDice(1), auto.overflowDice(2)], ["", "2d6", "4d6"]);
  equal("D Wellspring: +1d6 per 2 PP of its first damage type; healing instead; nothing under 2 PP", [auto.wellspringAnswer({ basePP: 5, damageTypes: ["fire", "cold"] })?.addedDamage, auto.wellspringAnswer({ basePP: 4, healing: true })?.mods, auto.wellspringAnswer({ basePP: 1, damageTypes: ["fire"] })], [[{ dice: "2d6", type: "fire", label: "Wellspring Conduit" }], { healDice: "2d6" }, null]);
  equal("D Stormcaller's discount: Storm Bolt and its burst, not an item's cast, not another spell", [{ spell: { name: "Storm Bolt" } }, { spell: { name: "Storm Bolt (Burst)", flags: { [SYS]: { eaVariantOf: "Storm Bolt" } } } }, { spell: { name: "Storm Bolt" }, itemCast: true }, { spell: { name: "Shock Bolt" } }].map(auto.stormDiscountApplies), [true, true, false, false]);
  equal("D Duellist's Focus: +1, +2 against a spell attack", [auto.duellistFocusBonus(false), auto.duellistFocusBonus(true)], [1, 2]);
  equal("D the riposte's PP: 1; none once a round with Supremacy", [auto.ripostePP({}), auto.ripostePP({ supremacy: true }), auto.ripostePP({ supremacy: true, freeUsedThisRound: true })], [1, 0, 1]);
  equal("D a spell attack's check names its spell; Touch is melee", [auto.spellNameOfCheck("Shocking Grasp — Cast a Spell"), auto.touchRange("Touch"), auto.touchRange("30 feet")], ["Shocking Grasp", true, false]);
  equal("D Fade Step's modes: 1 AP alone; with Eclipse Step free (in combat, once a round) and the 120 ft (once a day)",
    [auto.fadeModes({}).map((m) => m.key), auto.fadeModes({ eclipse: true, inCombat: true }).map((m) => [m.key, m.feet, m.ap]), auto.fadeModes({ eclipse: true, inCombat: true, freeUsedThisRound: true, longUsedToday: true }).map((m) => m.key), auto.fadeModes({ eclipse: true, inCombat: false }).map((m) => m.key)],
    [["ap"], [["ap", 30, 1], ["free", 30, 0], ["long", 120, 1]], ["ap"], ["ap", "long"]]);
  equal("D the reach and numbers: Fade 30, Eclipse 120, Grasp 10, Glyph 10, Denial 20 / 8 PP, Eye 30 / 3, Overload +2, Dispel −2, Shade +3", [auto.FADE_FEET, auto.ECLIPSE_FEET, auto.GRASP_FEET, auto.GLYPH_FEET, auto.DENIAL_FEET, auto.DENIAL_MAX_PP, auto.EYE_FEET, auto.EYE_PULSES, auto.OVERLOAD_PP, auto.DISPEL_REDUCTION, auto.SHADE_HIDDEN_PP], [30, 120, 10, 10, 20, 8, 30, 3, 2, 2, 3]);
  equal("D the PP as cast: castPP when given, else pp", [auto.castPPOf({ pp: 0, castPP: 7 }), auto.castPPOf({ pp: 5 }), auto.castPPOf({ pp: 5, castPP: 0 })], [7, 5, 0]);
  equal("D a spell-forced save: by another, with a source", [auto.spellForcedSave({ type: "save", saveSource: "Fireball", sourceUuid: "Actor.ZZ Wizard" }, ["Actor.me"]), auto.spellForcedSave({ type: "save", saveSource: "", sourceUuid: "Actor.X" }, []), auto.spellForcedSave({ type: "save", saveSource: "Fireball", sourceUuid: "Actor.me" }, ["Actor.me"]), auto.spellForcedSave({ type: "skill", saveSource: "Fireball" }, [])], [true, false, false, false]);
  equal("D the Glyph bonus lasts its minute", [auto.glyphBonusLive({ until: 100 }, 100), auto.glyphBonusLive({ until: 100 }, 101), auto.glyphBonusLive(null, 0)], [true, false, false]);
  const markE = (uuid, source = "spellbladesMark") => ({ effects: [{ name: "Spellblade’s Mark: X", flags: { [MOD]: { source, markUuid: uuid } } }] });
  equal("D the Mark is mine when my Mark effect (group C's) names it", [auto.isMarkOf({ uuid: "Actor.Orc" }, markE("Actor.Orc")), auto.isMarkOf({ uuid: "Actor.Elf" }, markE("Actor.Orc")), auto.isMarkOf({ uuid: "Actor.Orc" }, markE("Actor.Orc", "other"))], [true, false, false]);
}

/* ----------------------------------------------------------------- */
/* E — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const got = {};
  const api = new Proxy({}, { get: (_, k) => (...a) => { (got[k] ??= []).push(a); } });
  auto.registerBlock6B2(api, MOD);
  equal("E the Uses, by their items' names (Gale Step replacing Block 3's)", (got.registerFeatAutomation ?? []).map((a) => a[0]), ["Fade Step", "Counter Channel", "Absolute Denial", "Eye of the Storm", "Gale Step"]);
  ok("E …Counter Channel's toggle owns its Focus use (spends nothing)", got.registerFeatAutomation.find((a) => a[0] === "Counter Channel")[1].ownsFocusUse === true);
  equal("E the eligibilities, extra uses, Dispel modifiers, cast and check reactions, cost, warps, refusal, option, steps",
    [(got.registerFeatEligibility ?? []).map((a) => a[0]), (got.registerExtraUses ?? []).map((a) => [a[0], a[1].perCopy]), (got.registerDispelModifier ?? []).map((a) => a[0]), (got.registerCastReaction ?? []).map((a) => a[0]), (got.registerCheckReaction ?? []).map((a) => a[0]), (got.registerMetamagic ?? []).length, (got.registerCastCostModifier ?? []).map((a) => a[0]), (got.registerSpellWarps ?? []).map((a) => a[0]), (got.registerCastRefusal ?? []).length, (got.registerCastOption ?? []).map((a) => a[0]), (got.registerReactionStep ?? []).map((a) => a[0])],
    [["Runebreaker", "Shade Master", "Stormcaller"], [["Deep Weave", 1], ["Extra Reservoir", 2]], ["eaRunebreaker", "eaGlyphShatter"], ["eaAbsoluteDenial", "eaRunebreakerAbsorb", "eaCounterChannel"], ["eaSaveWards", "eaRiposteSpell"], 4, ["eaStormcaller"], ["Shade Master"], 1, [auto.OVERLOAD_KEY], [auto.ABSORB_STEP, auto.COUNTER_STEP, auto.RIPOSTE_STEP]]);
  const src = fs.readFileSync(path.join(ROOT, "module", "block6b2-automations.mjs"), "utf8");
  ok("E the hook handlers the lead wires are exported and say their event", ["onSpellSettledB6B2", "onStrikeResolvedB6B2", "onCombatTurnB6B2", "onItemCreatedB6B2", "onDailyPreparationB6B2"].every((n) => typeof auto[n] === "function" && new RegExp(`Hooks\\.on\\("[A-Za-z]+"[^\\n]*\\n(?:[^\\n]*\\n){0,3}?export async function ${n}\\(`).test(src)));
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side, with fakes                                    */
/* ----------------------------------------------------------------- */
const item = (doc, extra = {}) => ({ ...JSON.parse(JSON.stringify(doc)), _id: `id-${doc.name.replace(/\W/g, "")}`, ...extra });
const feat = (name, sys2 = {}) => item(F[name], { system: { ...F[name].system, ...sys2 } });
const abil = (name, sys2 = {}) => item(A[name], { system: { ...A[name].system, usesValue: 1, ...sys2 } });
const spellItem = (name, system = {}, flags = {}) => ({ _id: `sp-${name.replace(/\W/g, "")}`, name, type: "spell", system: { ppCost: 1, traits: "", ...system }, flags });
const warned = (re) => re.test(cards.filter((c) => c.warn).at(-1)?.warn ?? "");
const reset = () => { answers.length = 0; confirms.length = 0; game.user.targets.clear(); canvas.tokens.placeables = []; game.combat = null; lightQueue = []; lightDefault = 3; checkDegree = "success"; reactionRefused = ""; };
{
  // FADE STEP
  const sm = makeActor("ZZ Shade", { items: [abil("Fade Step"), feat("Eclipse Step"), feat("Shadowmantle"), feat("Grasping Shadows")] });
  const ts = makeToken("ts", sm, { x: 50, y: 50 });
  const foe = makeActor("ZZ Foe"); const tf = makeToken("tf", foe, { x: 750, y: 50, disposition: -1 });
  canvas.tokens.placeables = [ts, tf];
  startCombat(sm);
  const use = auto.AUTOMATIONS_B6_B2["Fade Step"].use;
  lightQueue = [7];
  answers.push("ap");
  ok("F Fade Step: refused from light above 5", (await use(sm, sm.items[0])) === false && warned(/start in light 5 or less/));
  answers.push("ap"); lightQueue = [3, 8]; clicked = { x: 650, y: 50 };
  ok("F …landing in light above 5: put back, nothing spent", (await use(sm, sm.items[0])) === false && ts.document._source.x === 0 && sm.system.resources.ap.value === 3 && warned(/put back/));
  answers.push("ap"); lightQueue = [3, 2]; clicked = { x: 650, y: 50 }; confirms.push(false); answers.push(null);
  ok("F …shadow to shadow within 30 ft: lands, 1 AP", (await use(sm, sm.items[0])) === true && ts.document._source.x === 600 && sm.system.resources.ap.value === 2);
  answers.push("free"); lightQueue = [3, 2]; clicked = { x: 50, y: 50 }; confirms.push(false);
  await use(sm, sm.items[0]);
  equal("F …the modes offered with Eclipse Step in combat: 1 AP, free, 120 ft", helpers.lastOptions?.map((o) => o[0]), ["ap", "free", "long"]);
  equal("F …free (Eclipse Step): no AP, the round marked", [sm.system.resources.ap.value, sm.items[1].flags[MOD]?.[auto.ECLIPSE_FREE_FLAG]], [2, "c1:1"]);
  answers.push("long"); lightQueue = [3, 2]; clicked = { x: 1250, y: 50 }; confirms.push(true);
  calls.conditions.length = 0;
  await use(sm, sm.items[0]);
  equal("F …the 120-ft step: Concealed to the next turn, the day marked; Shadowmantle's Hidden taken, its day marked", [calls.conditions.map((c) => c.tags[0].key), calls.conditions[0]?.opts, sm.items[1].flags[MOD]?.[auto.ECLIPSE_DAY_FLAG], sm.items[2].flags[MOD]?.[auto.MANTLE_DAY_FLAG]], [["concealed", "hidden"], { expiresRound: 2 }, true, true]);
  lightQueue = [3, 2]; clicked = { x: 1050, y: 50 }; confirms.push(true); calls.conditions.length = 0;
  equal("F …Shadowmantle's Hidden is not asked twice a day (only the 1 AP step is left this round)", [await use(sm, sm.items[0]), calls.conditions.length], [true, 0]);
  confirms.length = 0;
  equal("F …the 120 ft is not offered again today", auto.fadeModes({ eclipse: true, inCombat: true, longUsedToday: Boolean(sm.items[1].flags[MOD][auto.ECLIPSE_DAY_FLAG]) }).map((m) => m.key), ["ap", "free"]);
  // Grasping Shadows after the landing: foe within 10 ft of where it landed.
  game.combat = null; ts.document._source.x = 650; calls.area.length = 0;
  answers.push("tf"); helpers.areaDegree = "blunder";
  const gsr = await auto.offerGraspingShadows(sm, ts, "Fade Step");
  ok("F Grasping Shadows: offered on a creature within 10 ft of the landing, 1 PP, Reflex ladder, then the Blunder's tear", gsr === true && sm.system.resources.pp.value === 9 && calls.area[0]?.spec?.save === "reflex" && calls.area[0]?.spec?.dc === 18 && calls.area[1]?.spec?.damage?.formula === "5d6" && calls.area[1]?.spec?.save === "fortitude");
  ts.document._source.x = 650; calls.area.length = 0; helpers.areaDegree = "failure"; answers.push("tf");
  await auto.onSpellSettledB6B2({ actor: sm, cast: true, spellData: { traits: "Shadow, Utility" }, warpMods: {} });
  equal("F …offered after a Shadow-trait spell too, within 10 ft of you", [calls.area.length, calls.area[0]?.opts?.targets?.[0]?.name], [1, "ZZ Foe"]);
  calls.area.length = 0;
  await auto.onSpellSettledB6B2({ actor: sm, cast: true, spellData: { traits: "Fire" }, warpMods: {} });
  equal("F …not after another spell", calls.area.length, 0);
  ts.document._source.x = 0; calls.area.length = 0;
  ok("F …no creature within 10 ft: not asked", (await auto.offerGraspingShadows(sm, ts, "Fade Step")) === false && calls.area.length === 0);
  await auto.onDailyPreparationB6B2({ actor: sm });
  equal("F daily preparation clears the day's 120 ft and Hidden", [sm.items[1].flags[MOD]?.[auto.ECLIPSE_DAY_FLAG], sm.items[2].flags[MOD]?.[auto.MANTLE_DAY_FLAG]], [undefined, undefined]);
  clicked = null; reset();

  // GALE STEP (Stormcaller)
  const sc = makeActor("ZZ Storm", { items: [feat("Stormcaller")] });
  const st = makeToken("st", sc, { x: 50, y: 50 }); startCombat(sc);
  clicked = { x: 250, y: 50 };
  await auto.AUTOMATIONS_B6_B2["Gale Step"].use(sc);
  equal("F Gale Step: 0 AP for a Stormcaller", [st.document._source.x, sc.system.resources.ap.value], [200, 3]);
  const plain = makeActor("ZZ Plain"); const tp = makeToken("tp", plain, { x: 50, y: 50 }); startCombat(plain);
  await auto.AUTOMATIONS_B6_B2["Gale Step"].use(plain);
  equal("F …1 AP for anyone else", [tp.document._source.x, plain.system.resources.ap.value], [200, 2]);
  clicked = null; reset();

  // RUNEBREAKER'S ABSORB (+ Rune Rend)
  const rb = makeActor("ZZ Runebreaker", { items: [feat("Runebreaker"), feat("Rune Rend"), spellItem("Storing Rune")] });
  const wiz = makeActor("ZZ Wizard", { dc: 19 });
  const tr = makeToken("tr", rb, { x: 0, y: 0 }), tw = makeToken("tw", wiz, { x: 500, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tr, tw];
  const bolt = makeItem(spellItem("Fire Bolt", { ppCost: 4 }), wiz);
  const absorb = auto.REACTIONS_B6_B2.runebreakerAbsorb;
  game.user.targets.add(tr); game.user.targets.add(tw);
  equal("F Runebreaker: not with two targets", await absorb({ actor: wiz, token: tw, spell: bolt, spellData: bolt.system, pp: 6 }), null);
  game.user.targets.delete(tw);
  checkDegree = "failure";
  const fail = await absorb({ actor: wiz, token: tw, spell: bolt, spellData: bolt.system, pp: 6 });
  equal("F …a failed Will: not stopped; the reaction and the rune's 1 PP spent", [fail?.stop, rb.system.resources.pp.value, calls.rollCheck.at(-1)?.subject, calls.rollCheck.at(-1)?.dc], [false, 9, "will", 19]);
  checkDegree = "success"; confirms.push(true);
  const win = await absorb({ actor: wiz, token: tw, spell: bolt, spellData: bolt.system, pp: 6 });
  equal("F …a Success: stopped, stored foreign in the Storing Rune at the PP its caster paid", [win?.stop, calls.store.at(-1)?.spell, calls.store.at(-1)?.opts.ppPaid, calls.store.at(-1)?.opts.host?.name, calls.store.at(-1)?.opts.from?.name], [true, "Fire Bolt", 6, "Storing Rune", "ZZ Wizard"]);
  equal("F …Rune Rend: 1 PP, the caster's basic Will against your Spell DC for 3d6 force", [rb.system.resources.pp.value, calls.area.at(-1)?.spec?.save, calls.area.at(-1)?.spec?.damage, calls.area.at(-1)?.opts?.targets?.[0]?.name], [7, "will", { formula: "3d6", type: "force" }, "ZZ Wizard"]);
  checkDegree = "success"; confirms.push(false);
  await absorb({ actor: wiz, token: tw, spell: bolt, spellData: bolt.system, pp: 0, castPP: 9, innate: true });
  equal("F …an innate spell is stored at its PP as cast (castPP), not 0", calls.store.at(-1)?.opts.ppPaid, 9);
  equal("F …not for an area spell", await absorb({ actor: wiz, token: tw, spell: bolt, spellData: { area: "20-foot burst" }, pp: 6 }), null);
  rb.system.resources.pp.value = 0; calls.spendReaction.length = 0;
  equal("F …the step with the PP short spends nothing (checked before the reaction)", [(await auto.STEPS_B6_B2.absorbStep(rb, "yes", { runeId: rb.items[2].id, dc: 19, spellName: "Fire Bolt" })).rolled, calls.spendReaction.length], [false, 0]);
  equal("F …not without the rune's PP", await absorb({ actor: wiz, token: tw, spell: bolt, spellData: bolt.system, pp: 6 }), null);
  reset();

  // ABSOLUTE DENIAL
  const sw = makeActor("ZZ Warden", { items: [feat("Absolute Denial")] });
  const tsw = makeToken("tsw", sw, { x: 0, y: 0 }), tc = makeToken("tc", wiz, { x: 300, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tsw, tc];
  const deny = auto.REACTIONS_B6_B2.absoluteDenial;
  equal("F Absolute Denial: an enemy's 8 PP spell from 15 ft is stopped", (await deny({ actor: wiz, token: tc, spell: bolt, pp: 8 }))?.stop, true);
  equal("F …9 PP gets through (Q119)", await deny({ actor: wiz, token: tc, spell: bolt, pp: 9 }), null);
  equal("F …an innate spell is read at its PP as cast (castPP 10 gets through, though pp is 0; castPP 6 is stopped)", [await deny({ actor: wiz, token: tc, spell: bolt, pp: 0, castPP: 10, innate: true }), (await deny({ actor: wiz, token: tc, spell: bolt, pp: 0, castPP: 6, innate: true }))?.stop], [null, true]);
  tc.document.disposition = 1;
  equal("F …an ally's is not", await deny({ actor: wiz, token: tc, spell: bolt, pp: 4 }), null);
  tc.document.disposition = -1;
  await auto.AUTOMATIONS_B6_B2["Absolute Denial"].use(sw, sw.items[0]);
  equal("F …suppressed with Use, nothing stopped; resumed again", [await deny({ actor: wiz, token: tc, spell: bolt, pp: 4 }), (await auto.AUTOMATIONS_B6_B2["Absolute Denial"].use(sw, sw.items[0])) && (await deny({ actor: wiz, token: tc, spell: bolt, pp: 4 }))?.stop], [null, true]);
  sw.conditions.add("unconscious");
  equal("F …nothing while unconscious", await deny({ actor: wiz, token: tc, spell: bolt, pp: 4 }), null);
  reset();

  // COUNTER CHANNEL (Improved, Instinctive, Reflective Warding)
  const cw = makeActor("ZZ Counter", { items: [abil("Counter Channel"), feat("Reflective Warding")] });
  const tcw = makeToken("tcw", cw, { x: 0, y: 0 }), tcast = makeToken("tcast", wiz, { x: 900, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tcw, tcast];
  const cc = auto.REACTIONS_B6_B2.counterChannel;
  const save = makeItem(spellItem("Fireball", { ppCost: 6, defence: "basic Reflex" }), wiz);
  equal("F Counter Channel: not at 45 ft without Improved", await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }), null);
  tcast.center.x = 500; tcast.document._source.x = 450;
  checkDegree = "success";
  const half = await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 });
  equal("F …a Success within 25 ft halves it; DC 10 + 6 + Cha 2; the reaction, Focus use and 1 PP spent", [half?.scale, half?.saveBias, calls.rollCheck.at(-1)?.subject, calls.rollCheck.at(-1)?.dc, cw.items[0].system.usesValue, cw.system.resources.pp.value, calls.spendReaction.at(-1)?.[1]], [0.5, "advantage", "powerManipulation", 18, 0, 9, "Counter Channel"]);
  equal("F …not again with its Focus use spent", await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }), null);
  cw.items[0].system.usesValue = 1; checkDegree = "critical"; answers.push("reflect");
  equal("F …a Critical with Reflective Warding: turned on its caster when chosen", (await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }))?.retargetCaster, true);
  cw.items[0].system.usesValue = 1; checkDegree = "fumble";
  cw.items[0].system.usesValue = 1; checkDegree = "success";
  await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 0, castPP: 6, innate: true });
  equal("F …an innate spell's Save DC is its innate save DC (G25), not 10 + 0 PP", calls.rollCheck.at(-1)?.dc, 21);
  cw.items[0].system.usesValue = 1;
  await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 2, castPP: 8 });
  equal("F …a learned spell's Save DC reads the PP as cast (castPP 8: 10 + 8 + 2)", calls.rollCheck.at(-1)?.dc, 20);
  cw.items[0].system.usesValue = 1; checkDegree = "fumble";
  equal("F …a Fumble doubles it", (await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }))?.scale, 2);
  cw.items[0].system.usesValue = 1; tcast.document.disposition = 1;
  equal("F …an ally's spell is not asked unless allies are on", await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }), null);
  await auto.AUTOMATIONS_B6_B2["Counter Channel"].use(cw, cw.items[0]);
  checkDegree = "success";
  equal("F …with Use, allies are asked too", (await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }))?.scale, 0.5);
  cw.items[0].system.usesValue = 1;
  const improved = makeActor("ZZ Improved", { items: [abil("Counter Channel"), feat("Improved Counter Channel"), feat("Instinctive Counter Channel")] });
  const ti = makeToken("ti", improved, { x: 0, y: 0 }); tcast.center.x = 1100; tcast.document._source.x = 1050; tcast.document.disposition = -1;
  canvas.tokens.placeables = [ti, tcast]; reactionRefused = "no reaction left";
  calls.spendReaction.length = 0;
  const inst = await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 });
  equal("F …Improved reaches 55 ft; Instinctive asks with no reaction, spends none, marks the round", [inst?.scale, calls.spendReaction.length, Boolean(improved.items[0].flags[MOD]?.instinctiveRound)], [0.5, 0, true]);
  improved.items[0].system.usesValue = 1;
  equal("F …once a round: with no reaction left, not asked again", await cc({ actor: wiz, token: tcast, spell: save, spellData: save.system, pp: 6 }), null);
  reset();

  // SPELLWARDEN, SHADOWMANTLE, DEEP WEAVE (check reactions)
  const warden = makeActor("ZZ Wardsave", { items: [feat("Spellwarden"), feat("Shadowmantle")] });
  const twd = makeToken("twd", warden, { x: 0, y: 0 });
  const wards = auto.REACTIONS_B6_B2.saveWards;
  wiz.items.push(makeItem(spellItem("Fireball", { ppCost: 6 }), wiz));
  lightDefault = 4;
  equal("F Spellwarden +2 class and Shadowmantle +1 circumstance on a spell's save in light 4", (await wards.before({ actor: warden, token: twd, type: "save", saveSource: "Fireball", sourceUuid: "Actor.ZZ Wizard" }))?.modifiers?.map((m) => [m.value, m.type]), [[2, "class"], [1, "circumstance"]]);
  lightDefault = 7;
  equal("F …in light 7 only the Spellwarden's", (await wards.before({ actor: warden, token: twd, type: "save", saveSource: "Fireball", sourceUuid: "Actor.ZZ Wizard" }))?.modifiers?.map((m) => m.value), [2]);
  equal("F …nothing on a save no spell forced, nor on your own spell", [await wards.before({ actor: warden, token: twd, type: "save", saveSource: "", sourceUuid: "" }), await wards.before({ actor: warden, token: twd, type: "save", saveSource: "Fireball", sourceUuid: warden.uuid })], [null, null]);
  equal("F …nor on an area save that is not a spell (basicSaveHit's label: Glyph Shatter, a breath)", [await wards.before({ actor: warden, token: twd, type: "save", saveSource: "Glyph Shatter", sourceUuid: "Actor.ZZ Wizard" }), await wards.before({ actor: warden, token: twd, type: "save", saveSource: "Fireball", sourceUuid: "Actor.Nobody" })], [null, null]);
  const weaver = makeActor("ZZ Weaver", { int: 2, items: [feat("Deep Weave"), abil("Magical Reservoir", { usesValue: 1 })] });
  makeToken("tww", weaver, { x: 0, y: 0 });
  await wards.after({ actor: weaver, token: weaver.token, type: "save", degree: "critical", saveSource: "Fireball", sourceUuid: "Actor.ZZ Wizard" });
  equal("F Deep Weave: a critical save against a spell regains a charge", weaver.items[1].system.usesValue, 2);
  weaver.items[1].system.usesValue = 1;
  await wards.after({ actor: weaver, token: weaver.token, type: "save", degree: "critical", saveSource: "Fireball", sourceUuid: "Actor.ZZ Wizard" });
  equal("F …once a round", weaver.items[1].system.usesValue, 1);
  weaver.items[0].flags[MOD].regainRound = "old";
  await wards.after({ actor: weaver, token: weaver.token, type: "save", degree: "success", saveSource: "Fireball", sourceUuid: "Actor.ZZ Wizard" });
  equal("F …not on a Success", weaver.items[1].system.usesValue, 1);
  await auto.onSpellSettledB6B2({ actor: weaver, cast: true, spellHits: [{ target: wiz, critical: true }], spellData: {}, warpMods: {} });
  equal("F …a critical spell attack regains one too", weaver.items[1].system.usesValue, 2);
  weaver.items[0].flags[MOD].regainRound = "old";
  await auto.onSpellSettledB6B2({ actor: weaver, cast: true, spellHits: [{ target: wiz, critical: true }], spellData: {}, warpMods: {} });
  equal("F …never above the maximum (Int 2)", weaver.items[1].system.usesValue, 2);
  reset();

  // SPELLSTRIKE RIPOSTE (Focus, Supremacy, Rippling Counter)
  const sd = makeActor("ZZ Duellist", { items: [abil("Spellstrike Riposte"), feat("Duellist’s Focus"), feat("Duellist’s Supremacy"), feat("Rippling Counter"), { _id: "w1", name: "Rapier", type: "weapon", system: { equipped: true, attackMode: "melee" } }, spellItem("Shock", { ppCost: 0, damage: { formula: "1d6", type: "electricity" } })] });
  const orc = makeActor("ZZ Orc"); sd.effects.push(makeEffect({ name: "Spellblade’s Mark: ZZ Orc", flags: { [MOD]: { source: "spellbladesMark", markUuid: orc.uuid } } }, sd));
  const tsd = makeToken("tsd", sd, { x: 0, y: 0 }), tor = makeToken("tor", orc, { x: 100, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tsd, tor];
  await auto.onStrikeResolvedB6B2({ attacker: orc, target: sd, melee: false, missed: true });
  equal("F Riposte: not on a ranged miss", asked.filter((q) => q.step === auto.RIPOSTE_STEP).length, 0);
  await auto.onStrikeResolvedB6B2({ attacker: orc, target: sd, melee: true, missed: true, noReactions: true });
  equal("F …nor on a Strike that forbids reactions", asked.filter((q) => q.step === auto.RIPOSTE_STEP).length, 0);
  answers.push("sp-Shock"); strikeOutcome = { hits: true, critical: { severity: "minor" } }; confirms.push(true);
  await auto.onStrikeResolvedB6B2({ attacker: orc, target: sd, melee: true, missed: true });
  const s1 = calls.strikes[0];
  equal("F …a melee miss: a Strike at the attacker ignoring MAP, Duellist's Focus +1, the cantrip as secondary, no PP once a round (Supremacy)",
    [s1?.targets, s1?.opts.mapOverride, s1?.opts.extraModifiers, s1?.opts.extraTypedDamage, sd.system.resources.pp.value, sd.items[0].system.usesValue], [["tor"], 0, [{ label: "Duellist’s Focus", value: 1, type: "circumstance" }], [{ dice: "1d6", type: "electricity", label: "Shock (channelled)" }], 10, 0]);
  ok("F …advantage against your Mark: a one-shot row on that target", sd.effects.some((e) => e.flags?.[SYS]?.conditionals?.[0]?.kind === "advantage" && e.flags[SYS].conditionals[0].when.targetUuids[0] === orc.uuid && e.flags[SYS].conditionals[0].oneShot));
  equal("F …a critical: Rippling Counter arms a Step and makes a second Strike, no cantrip", [calls.armMove.at(-1)?.leg?.maxFeet, calls.strikes.length, calls.strikes[1]?.opts?.extraTypedDamage, calls.strikes[1]?.opts?.mapOverride], [5, 2, undefined, undefined]);
  sd.items[0].system.usesValue = 1; strikeOutcome = { hits: false, critical: null }; answers.push(null);
  await auto.onStrikeResolvedB6B2({ attacker: orc, target: sd, melee: true, missed: true });
  equal("F …the second this round costs 1 PP", sd.system.resources.pp.value, 9);
  sd.items[0].system.usesValue = 1; answers.push(null); helpers.refuseStrike = true; calls.spendReaction.length = 0;
  await auto.onStrikeResolvedB6B2({ attacker: orc, target: sd, melee: true, missed: true });
  equal("F …a Strike the core refuses spends nothing (reaction, PP, use)", [calls.spendReaction.length, sd.system.resources.pp.value, sd.items[0].system.usesValue], [0, 9, 1]);
  helpers.refuseStrike = false;
  const stranger = makeActor("ZZ Stranger"); makeToken("tstr", stranger, { x: 100, y: 100, disposition: -1 });
  sd.items[0].system.usesValue = 1; sd.effects = sd.effects.filter((e) => e.flags?.[MOD]?.source === "spellbladesMark"); strikeOutcome = { hits: true, critical: null }; answers.push(null);
  const n0 = calls.strikes.length;
  await auto.onStrikeResolvedB6B2({ attacker: stranger, target: sd, melee: true, missed: true });
  equal("F …no advantage against a creature that is not your Mark; a plain hit makes no second Strike", [sd.effects.filter((e) => e.flags?.[MOD]?.source !== "spellbladesMark").length, calls.strikes.length - n0], [0, 1]);
  sd.items[0].system.usesValue = 1; answers.push(null);
  const sp = makeItem(spellItem("Shocking Grasp", { range: "Touch" }), orc);
  orc.items.push(sp);
  await auto.REACTIONS_B6_B2.riposteSpell.after({ type: "attack", failed: true, actor: orc, target: sd, label: "Shocking Grasp — Cast a Spell", check: { reactionAs: "attack" } });
  equal("F …a Touch spell attack that missed: +2 Duellist's Focus", calls.strikes.at(-1)?.opts?.extraModifiers?.[0]?.value, 2);
  const before = calls.strikes.length; sd.items[0].system.usesValue = 1;
  orc.items.push(makeItem(spellItem("Ray", { range: "60 feet" }), orc));
  await auto.REACTIONS_B6_B2.riposteSpell.after({ type: "attack", failed: true, actor: orc, target: sd, label: "Ray — Cast a Spell", check: { reactionAs: "attack" } });
  equal("F …a ranged spell attack: not asked", calls.strikes.length, before);
  reset();

  // GLYPH SHATTER, RUNEBREAKER'S DISPEL
  const gs = makeActor("ZZ Glyph", { items: [feat("Glyph Shatter")], dc: 17 });
  const vic = makeActor("ZZ Warded"); const tg = makeToken("tg", gs, { x: 0, y: 0 }), tv = makeToken("tv", vic, { x: 600, y: 0, disposition: -1 }), tn = makeToken("tn", wiz, { x: 700, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tg, tv, tn];
  const glyph = auto.glyphShatterDispel;
  equal("F Glyph Shatter: offered to its owner (no bonus yet)", glyph.offer({ actor: gs })?.modifiers, undefined);
  confirms.push(true, true); calls.area.length = 0;
  const res = await glyph.onResult({ actor: gs, degree: "success", counterSpell: false, target: vic, dispel: { effectValue: 6 } });
  equal("F …a Success: 3d6 force, basic Reflex vs the Spell DC (Reflex), every creature within 10 ft of the effect; the ward's +1 kept a minute", [calls.area[0]?.spec?.save, calls.area[0]?.spec?.damage, calls.area[0]?.spec?.dc, calls.area[0]?.opts?.targets?.map((a) => a.name), gs.flags[MOD]?.[auto.GLYPH_BONUS_FLAG]?.until, res?.lines?.length > 0], ["reflex", { formula: "3d6", type: "force" }, 17, ["ZZ Warded", "ZZ Wizard"], 1060, true]);
  const o2 = glyph.offer({ actor: gs });
  equal("F …the next Dispel takes +1 circumstance, then it is spent", [o2?.modifiers?.[0]?.value, o2?.modifiers?.[0]?.type, (await glyph.onResult({ actor: gs, degree: "failure", target: vic, dispel: {} })), gs.flags[MOD]?.[auto.GLYPH_BONUS_FLAG]], [1, "circumstance", null, undefined]);
  calls.area.length = 0;
  equal("F …a failed Dispel shatters nothing", [await glyph.onResult({ actor: gs, degree: "failure", target: vic, dispel: { effectValue: 6 } }), calls.area.length], [null, 0]);
  equal("F Runebreaker's offer: −2 PP for its owner", [auto.runebreakerDispel.offer({ actor: { items: [{ type: "feat", name: "Runebreaker" }] } })?.ppReduction, auto.runebreakerDispel.offer({ actor: gs })], [2, null]);
  reset();

  // THE RESERVOIR, OVERFLOW CASTING, WELLSPRING
  const ov = makeActor("ZZ Overflow", { int: 2, hp: 6, items: [abil("Magical Reservoir", { usesValue: 1 }), feat("Overflow Casting", { usesValue: 1 }), feat("Wellspring Conduit", { usesValue: 1 })] });
  equal("F the Reservoir: its charges are available; with Overflow ready, any", [auto.reservoirCharges(ov), (await auto.reservoirAvailable({ actor: ov })) > 100], [1, true]);
  await auto.reservoirPay({ actor: ov, amount: 1 });
  equal("F …a charge paid from the Reservoir, no damage", [ov.items[0].system.usesValue, calls.damage.length], [0, 0]);
  ov.getConditionValue = () => 3;
  const paid = await auto.reservoirPay({ actor: ov, amount: 1 });
  equal("F Overflow Casting: the missing charge costs 2d6 ignoring defences, its Focus use; 5 Soul Drain at 0 HP or less", [calls.damage.at(-1)?.amount, calls.damage.at(-1)?.ignoreDefences, ov.items[1].system.usesValue, calls.conditions.at(-1)?.tags?.[0], paid.lines.length], [8, true, 0, { key: "soulDrain", label: "Soul Drain", value: 5 }, 2]);
  const cr = await import(sys("module", "conditions", "condition-rules.mjs"));
  equal("F …the core adds it: Soul Drain 3 becomes 8, not 11", cr.combinedConditionValue("soulDrain", 3, calls.conditions.at(-1)?.tags?.[0]?.value), 8);
  equal("F …without its Focus use, only the charges", await auto.reservoirAvailable({ actor: ov }), 0);
  const ws = auto.WEAVER_METAMAGIC[auto.MM.wellspring];
  {
    const wsx = auto.WEAVER_METAMAGIC[auto.MM.wellspring];
    ov.items[0].system.usesValue = 0; ov.items[2].system.usesValue = 1;
    equal("F Wellspring reads the PP cast: base 3 + warps and metamagic 4 (castPP 7) → +3d6, not the base's 1d6; base alone without castPP", [wsx.apply({ actor: ov, basePP: 3, castPP: 7, damageTypes: ["fire"] })?.addedDamage?.[0]?.dice, wsx.apply({ actor: ov, basePP: 3, damageTypes: ["fire"] })?.addedDamage?.[0]?.dice], ["3d6", "1d6"]);
    equal("F …a 1-PP spell warped to 2 is offered (castPP 2); unwarped it is not", [wsx.applies({ actor: ov, basePP: 1, castPP: 2, damageTypes: ["fire"] }), wsx.applies({ actor: ov, basePP: 1, castPP: 1, damageTypes: ["fire"] })], [true, false]);
    equal("F …healing reads it too", wsx.apply({ actor: ov, basePP: 2, castPP: 6, traits: "Healing" })?.mods, { healDice: "3d6" });
  }
  equal("F Wellspring: offered at 0 charges for a damaging spell; not with a charge left", [ws.applies({ actor: ov, basePP: 4, damageTypes: ["fire"] }), (ov.items[0].system.usesValue = 1) && ws.applies({ actor: ov, basePP: 4, damageTypes: ["fire"] })], [true, false]);
  const floor = makeActor("ZZ Dim", { int: 0, items: [abil("Magical Reservoir", { usesValue: 0 })] });
  await auto.onItemCreatedB6B2(floor.items[0]);
  equal("F the Reservoir's minimum 1: an Int 0 Weaver has one charge", [floor.items[0].system.bonusUses, floor.items[0].system.usesValue], [1, 1]);
  reset();

  // STORMCALLER'S DISCOUNT, SHADE MASTER'S REFUSAL AND WARP, RUNIC OVERLOAD, EYE OF THE STORM
  const stc = makeActor("ZZ Caller", { items: [feat("Stormcaller")] });
  equal("F Stormcaller: −1 PP to pay on Storm Bolt, floor 0; nothing for another's", [auto.stormcallerDiscount({ actor: stc, spell: { name: "Storm Bolt" } }), auto.stormcallerDiscount({ actor: plain, spell: { name: "Storm Bolt" } })].map((x) => x && [x.ppDelta, x.floor]), [[-1, 0], null]);
  const shade = makeActor("ZZ Shade2", { items: [feat("Shade Master")] }); makeToken("tsh", shade, { x: 0, y: 0 });
  const dw = makeItem(spellItem("Dark Whispers", { ppCost: 4 }, { [SYS]: { grantedBy: { sourceName: "Shade Master" } } }), shade);
  lightDefault = 7;
  ok("F Shade Master's Dark Whispers refused in light 7, cast in light 4; another's copy is not refused", Boolean(await auto.darkWhispersRefusal({ actor: shade, spell: dw })) && !(lightDefault = 4, await auto.darkWhispersRefusal({ actor: shade, spell: dw })) && !(lightDefault = 7, await auto.darkWhispersRefusal({ actor: shade, spell: { ...dw, flags: {} } })));
  shade.items.push(dw);
  await auto.onItemCreatedB6B2(dw);
  equal("F …and it is made a specialist spell", dw.system.specialist, true);
  calls.conditions.length = 0;
  await auto.onSpellSettledB6B2({ actor: shade, cast: true, spellData: {}, warpMods: { unlocks: [auto.SHADE_UNLOCK] } });
  equal("F Shadow Shift's Shade Master option lays Hidden", calls.conditions.at(-1)?.tags?.[0]?.key, "hidden");
  calls.conditions.length = 0;
  await auto.onSpellSettledB6B2({ actor: shade, cast: true, spellData: {}, warpMods: {} });
  equal("F …not without it", calls.conditions.length, 0);
  const ro = makeActor("ZZ Overload", { items: [feat("Runic Overload", { usesValue: 1 })], dc: 16 });
  equal("F Runic Overload: offered on a stored release with its Focus use, not on a cast", [Boolean(auto.runicOverloadOption.offer({ actor: ro, stored: true })), auto.runicOverloadOption.offer({ actor: ro, stored: false })], [true, null]);
  equal("F …Q116 on the spell: its Save DC +2 and Casting DC +3, no warp", [auto.runicOverloadOption.apply().saveDC, auto.runicOverloadOption.apply().castingDC, auto.runicOverloadOption.apply().mods], [2, 3, undefined]);
  calls.area.length = 0;
  await auto.onSpellSettledB6B2({ actor: ro, cast: true, stored: true, castPP: 4, castOptions: [auto.OVERLOAD_KEY.toLowerCase()], spellHits: [{ target: wiz }], saveResults: [{ target: orc }, { target: wiz }], spellData: {}, warpMods: {} });
  equal("F …taken: effective PP 6 → 3d6 force, basic Will on those hit or saving, then the basic Fortitude backlash; its Focus use", [calls.area.map((c) => [c.spec.save, c.spec.damage.formula, c.opts.targets.map((a) => a.name)]), ro.items[0].system.usesValue], [[["will", "3d6", ["ZZ Wizard", "ZZ Orc"]], ["fortitude", "3d6", ["ZZ Overload"]]], 0]);
  const eye = makeActor("ZZ Eye", { level: 6, items: [feat("Eye of the Storm", { usesValue: 1 })] });
  await auto.AUTOMATIONS_B6_B2["Eye of the Storm"].use(eye, eye.items[0]);
  const ee = auto.EYE_SOURCE && eye.effects[0];
  equal("F Eye of the Storm: the use spent, electricity immunity, three pulses", [eye.items[0].system.usesValue, ee?.changes, ee?.flags?.[MOD]?.pulsesLeft], [0, [{ key: "system.combat.immunities", mode: 2, value: ", electricity", priority: 20 }], 3]);
  ok("F …refused once spent", (await auto.AUTOMATIONS_B6_B2["Eye of the Storm"].use(eye, eye.items[0])) === false && eye.effects.length === 1);
  calls.area.length = 0;
  const combat = { combatant: { actor: eye } };
  for (let i = 0; i < 3; i += 1) await auto.onCombatTurnB6B2(combat, { turn: i });
  equal("F …each of its owner's next three turns: 6d6 electricity, basic Reflex, enemies within 30 ft; then it ends", [calls.area.length, calls.area[0]?.spec, eye.effects.length], [3, { save: "reflex", basic: true, dc: 18, damage: { formula: "6d6", type: "electricity" }, scope: "area", radiusFeet: 30, enemiesOnly: true }, 0]);
  await auto.onCombatTurnB6B2({ combatant: { actor: plain } }, { turn: 1 });
  equal("F …nothing for anyone else", calls.area.length, 3);
}

/* ----------------------------------------------------------------- */
console.log(failures.length ? `verify-block6b2: ${checks} checks, ${failures.length} failure(s):\n  ${failures.join("\n  ")}` : `verify-block6b2: ${checks} checks, 0 failure(s).`);
if (failures.length) process.exitCode = 1;
