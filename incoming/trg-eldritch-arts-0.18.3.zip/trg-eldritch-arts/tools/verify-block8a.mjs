#!/usr/bin/env node
/**
 * verify-block8a — Eldritch Arts 0.11.0 (Block 8a, on TRG Prime 3.686.0): the
 * second half of Chapter 8's Grimoire, first part — the eight Bindings, the
 * three new Symbols (Death and Fear rebuilt on their model), the eleven
 * exploration and utility spells, Versatile Binder rebuilt, and Ley Line
 * Effects 25–27 (docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2 and §4; Graham,
 * 8 November 2026, 17:22: "As recommended" — Q167–Q184, H12, H17, H18).
 *
 *   A  every spell against the book: name, PP, traits, tradition (all → the
 *      four), uncommon, the printed text, the grade and its card, the key; no
 *      Binding or Symbol carries the core's cast save (the audit's §5)
 *   B  the data through the core's own readers: the warps, the PP lock (Q170),
 *      the wall, the conditional, the object target, the deferred teleport,
 *      core Remove Curse against a symbol's curse, core Insanity's table
 *   C  the pure rules (module/block8a-rules.mjs)
 *   D  registration
 *   E  the Foundry side with fakes, the control register and the curse's end
 *      being the REAL core's: the Bindings, the Symbols, the utilities,
 *      Versatile Binder, Ley Line Effects 25–27, the buttons
 *   F  the wiring
 *
 *   TRG_PRIME_ROOT=../trpg-prime EA_BOOK_MD=… node tools/verify-block8a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const readCore = (...p) => fs.readFileSync(path.join(SYSTEM_ROOT, ...p), "utf8");
const tick = () => new Promise((r) => setTimeout(r, 0));

/* ----------------------------------------------------------------- */
/* Fakes (before any import that reads them)                          */
/* ----------------------------------------------------------------- */
const cards = [], messages = [], warns = [], answers = [];
const calls = { checks: [], effects: [], conditions: [], ended: [], crits: [], saves: [], tables: [], arrivals: [] };
const degreeFor = new Map();
let teleportFails = false, nextClick = [], dialogPick = null;
const pending = [];
let gmSide = 0;
const flush = async () => { while (pending.length) { const job = pending.shift(); gmSide++; try { await job(); } finally { gmSide--; } } };
const guard = (doc, what = "update") => { if (doc && doc.isOwner === false && !gmSide) throw new Error(`User Player lacks permission to ${what} ${doc.uuid ?? doc.name}`); };
const uuidMap = new Map();
const hookList = new Map();
const fired = [];
let nextId = 0;

const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => (answers.length ? answers.shift() : null),
  rollCheck: async (cfg) => {
    const d = degreeFor.get(cfg.actor?.name) ?? "failure";
    const [key, margin] = Array.isArray(d) ? d : [d, d === "failure" ? -5 : 2];
    calls.checks.push({ actor: cfg.actor?.name, type: cfg.type, subject: cfg.subject, dc: cfg.dc, sourceUuid: cfg.sourceUuid ?? "" });
    return { outcome: { degree: { key, label: key }, total: 10, margin } };
  },
  createEffectsOn: async (target, list) => { calls.effects.push({ target: target.name, list }); gmSide++; try { return await target.createEmbeddedDocuments("ActiveEffect", list); } finally { gmSide--; } },
  applyConditionTagsTo: async (target, tags, options = {}) => {
    calls.conditions.push({ target: target.name, tags, options });
    for (const t of tags) { const was = target.conditions.rawValues.get(t.key) ?? 0; const adds = ["injured", "bleeding", "fatigued", "soulDrain"].includes(t.key); target.conditions.rawValues.set(t.key, adds ? was + Number(t.value ?? 1) : Math.max(was, Number(t.value ?? 1))); }
  },
  endSpellOf: async (caster, castId) => {
    calls.ended.push({ caster: caster.name, castId });
    const entries = Array.from(caster.flags?.[SYS]?.activeSpells ?? []);
    if (!entries.some((e) => e.id === castId)) return null;
    caster.flags[SYS].activeSpells = entries.filter((e) => e.id !== castId);
    const gone = caster.effects.filter((e) => e.flags?.[SYS]?.castId === castId);
    caster.effects = caster.effects.filter((e) => !gone.includes(e));
    for (const e of gone) for (const fn of hookList.get("deleteActiveEffect") ?? []) await fn(e);
    return { id: castId };
  },
  rollCriticalInjury: async (attacker, o) => { calls.crits.push({ attacker: attacker?.name, target: o.targetActor?.name, severity: o.severity, type: o.damageType, ...(o.attackBonus !== undefined ? { attackBonus: o.attackBonus } : {}) }); },
  isDead: async (actor) => Number(actor?.conditions?.rawValues?.get?.("dying") ?? 0) > 5,
  markTurnTable: async (target, row, o) => { calls.tables.push({ target: target.name, row, margin: o.margin, dc: o.dc }); return { marked: true, rounds: 2, line: `${target.name} is insane` }; },
  basicSaveHit: async (o) => { calls.saves.push({ target: o.target?.name, save: o.save, dc: o.dc, formula: o.formula, type: o.type }); return { line: "<strong>Failure</strong>: 9 sonic", degree: "failure" }; },
  regionContains: async (region, p) => regionHas(region, p),
  teleportationFails: async () => teleportFails,
  teleportationArrives: async (caster, spell, moved) => { calls.arrivals.push({ caster: caster?.name, spell: spell?.name, moved: moved.map((m) => m.name) }); return ["Teleported — Spatial Awareness"]; },
  itemUsesMax: () => null, itemUsesRemaining: () => 0
};
// THE REAL CORE'S CONTROL REGISTER (H12), its hook captured.
const CRW = await import(sys("module", "magic", "control-register-workflow.mjs"));
Object.assign(helpers, {
  recordControlled: (...a) => CRW.recordControlled(...a), releaseControlled: (...a) => CRW.releaseControlled(...a),
  controlledOf: async (a) => CRW.controlledOf(a), controlledCreature: (e) => CRW.controlledCreature(e)
});

globalThis.Roll = class { constructor(f) { this.formula = String(f); } async evaluate() { this.total = 1; return this; } };
globalThis.Hooks = { on(name, fn) { if (!hookList.has(name)) hookList.set(name, []); hookList.get(name).push(fn); return fn; }, off() {}, once(name, fn) { return Hooks.on(name, fn); }, call() { return true }, callAll(name, payload) { fired.push({ name, payload }); } };
globalThis.foundry = {
  applications: { api: { DialogV2: { wait: async (cfg) => (typeof dialogPick === "function" ? dialogPick(cfg) : dialogPick), confirm: async () => true, prompt: async () => null } }, ux: {} },
  utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, hasProperty: () => false, mergeObject: (a, b) => Object.assign(a ?? {}, b ?? {}), isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => `id${++nextId}`, deepClone: (x) => JSON.parse(JSON.stringify(x)), fromUuid: async (u) => uuidMap.get(u) ?? null }
};
globalThis.fromUuidSync = (u) => uuidMap.get(u) ?? null;
globalThis.fromUuid = async (u) => uuidMap.get(u) ?? null;
globalThis.ui = { notifications: { warn: (t) => { warns.push(t); }, info: () => ({ id: 1 }), error() {}, remove() {} } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 }, REGION_VISIBILITY: { LAYER: 0, GAMEMASTER: 1, ALWAYS: 2 } };
const blocked = new Set();
globalThis.CONFIG = { statusEffects: [], specialStatusEffects: {}, Canvas: { polygonBackends: { sight: { testCollision: (a, b) => blocked.has(`${Math.round(b.x)},${Math.round(b.y)}`) } } } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };
globalThis.ChatMessage = { getSpeaker: () => ({}), create: async (d) => { messages.push(d); return d; } };

function setFlagPath(obj, dotted, value) {
  const ks = dotted.split(".");
  if (ks.at(-1).startsWith("-=")) { let at = obj; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); delete at[ks.at(-1).slice(2)]; return; }
  globalThis.foundry.utils.setProperty(obj, dotted, value);
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a, disabled: false };
  e.flags = e.flags ?? {};
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.setFlag = async (s, k, v) => { guard(a); (e.flags[s] ??= {})[k] = JSON.parse(JSON.stringify(v)); };
  e.update = async (u) => { guard(a); for (const [k, v] of Object.entries(u)) setFlagPath(e, k, v); };
  e.delete = async () => { guard(a, "delete"); a.effects = a.effects.filter((x) => x !== e); for (const fn of hookList.get("deleteActiveEffect") ?? []) await fn(e); };
  return e;
}
function makeActor(name, { level = 5, cap = 10, pp = 30, hpMax = 24, str = 2, size = "medium", type = "", traits = "", owner = true } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name.replace(/\s/g, "")}`, isOwner: owner, effects: [], flags: { [SYS]: {}, [MOD]: {} }, documentName: "Actor", img: `${name}.png` };
  a.system = { identity: { level, size }, traits, resources: { pp: { value: pp }, hp: { value: hpMax, max: hpMax } }, attributes: { strength: { total: str } }, encumbrance: { max: 0 }, magic: { controlLevels: cap }, combat: { deathState: 5, saves: { will: { total: 2 } } } };
  a.items = type ? [{ type: "creature-type", name: type }] : [];
  a.conditions = { rawValues: new Map() };
  a.getConditionValue = (k) => a.conditions.rawValues.get(k) ?? 0;
  a.hasCondition = (k) => (a.conditions.rawValues.get(k) ?? 0) > 0;
  a.getFlag = (s, k) => a.flags?.[s]?.[k];
  a.setFlag = async (s, k, v) => { guard(a); (a.flags[s] ??= {})[k] = JSON.parse(JSON.stringify(v)); };
  a.unsetFlag = async (s, k) => { guard(a); delete a.flags?.[s]?.[k]; };
  a.update = async (u) => { guard(a); for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, docs) => { guard(a, "create in"); const made = docs.map((d) => makeEffect(d, a)); a.effects.push(...made); return made; };
  a.deleteEmbeddedDocuments = async (type, ids) => {
    guard(a, "delete in");
    const gone = a.effects.filter((e) => ids.includes(e.id));
    a.effects = a.effects.filter((e) => !ids.includes(e.id));
    for (const e of gone) for (const fn of hookList.get("deleteActiveEffect") ?? []) await fn(e);
  };
  a.toggleStatusEffect = async (k, o = {}) => { if (o.active === false) a.conditions.rawValues.delete(k); else a.conditions.rawValues.set(k, Number(o.value ?? 1)); };
  a.testUserPermission = () => owner;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
const scene = { id: "s1", regions: [] };
function makeToken(actor, { x = 0, y = 0, disposition = 1, width = 1 } = {}) {
  const t = { id: `t-${actor.name}`, name: actor.name, actor };
  t.document = { actor, disposition, width, height: width, x, y, hidden: false, uuid: `Scene.s1.Token.t-${actor.name}`, parent: scene, _source: { x, y, width, height: width }, size: actor.system.identity.size, texture: { src: `${actor.name}.png` } };
  t.document.update = async (u, o) => { Object.assign(t.document, u); Object.assign(t.document._source, u); t.lastUpdateOptions = o; return t.document; };
  t.document.object = t;
  Object.defineProperty(t, "center", { get: () => ({ x: t.document.x + 50 * t.document.width, y: t.document.y + 50 * t.document.width }) });
  actor.token = t;
  uuidMap.set(t.document.uuid, t.document);
  canvas.tokens.placeables.push(t);
  return t;
}
/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y, regions) and the placeable still hold
 * the OLD position; its `_source` and `change` carry the new. The hook runs on
 * that; the getters catch up only afterwards (unless the hook itself moved the
 * token — the rift's own teleport).
 */
async function moveV14(doc, change, options = {}) {
  const from = { x: doc.x, y: doc.y };
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
  const out = await A.onTokenMovedB8a(doc, change, options);
  if (doc.x === from.x && doc.y === from.y) Object.assign(doc, change);
  return out;
}
function regionHas(region, p) {
  for (const s of region?.shapes ?? []) {
    if (s.type === "rectangle" && p.x >= s.x && p.x < s.x + s.width && p.y >= s.y && p.y < s.y + s.height) return true;
    if (s.type === "ellipse" && Math.hypot(p.x - s.x, p.y - s.y) <= s.radiusX) return true;
  }
  return false;
}
scene.createEmbeddedDocuments = async (type, docs) => docs.map((d) => {
  const r = { ...JSON.parse(JSON.stringify(d)), id: `r${++nextId}`, parent: scene };
  r.uuid = `Scene.s1.Region.${r.id}`;
  r.update = async (u) => { for (const [k, v] of Object.entries(u)) setFlagPath(r, k, v); };
  r.delete = async () => { scene.regions = scene.regions.filter((x) => x !== r); uuidMap.delete(r.uuid); };
  r.setFlag = async (s, k, v) => { (r.flags[s] ??= {})[k] = v; };
  scene.regions.push(r);
  uuidMap.set(r.uuid, r);
  return r;
});
scene.deleteEmbeddedDocuments = async (type, ids) => { scene.regions = scene.regions.filter((r) => !ids.includes(r.id)); };
globalThis.canvas = {
  stage: { on(evt, fn) { const at = nextClick.shift(); queueMicrotask(() => fn({ data: { getLocalPosition: () => at } })); }, off() {} },
  tokens: { placeables: [], controlled: [] }, scene, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) }
};
globalThis.game = {
  socket: { emit: (channel, data) => { if (game.user.isGM) pending.push(() => B7.onBlock7Socket(data)); }, on() {} },
  trgPrime: { modules: { helpers } }, user: { id: "gm", isGM: true, targets: new Set() }, combat: null, actors: [], packs: [],
  time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: SYS, version: "3.686.0" }
};
game.users = Object.assign([game.user], { activeGM: game.user });
const reset = () => { cards.length = 0; messages.length = 0; warns.length = 0; answers.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; degreeFor.clear(); canvas.tokens.placeables = []; canvas.tokens.controlled = []; scene.regions = []; fired.length = 0; nextClick = []; dialogPick = null; teleportFails = false; blocked.clear(); game.time.worldTime = 1000; game.user.isGM = true; game.users.activeGM = game.user; };

const C = await import(new URL("./content/block8a-spells.mjs", import.meta.url));
const B3S = await import(new URL("./content/block3-spells.mjs", import.meta.url));
const R = await import(new URL("../module/block8a-rules.mjs", import.meta.url));
const A = await quiet(() => import(new URL("../module/block8a-automations.mjs", import.meta.url)));
const B7 = await quiet(() => import(new URL("../module/block7-automations.mjs", import.meta.url)));
const B6D = await quiet(() => import(new URL("../module/block6d-automations.mjs", import.meta.url)));
const B2 = await quiet(() => import(new URL("../module/block2-automations.mjs", import.meta.url)));
const T7 = await import(new URL("../module/chapter7-tables.mjs", import.meta.url));
const S = Object.fromEntries([...C.SPELLS_B8A, ...B3S.BLOCK3_GRIMOIRE].map((s) => [s.name, s]));
for (const fn of [A.onEffectDeletedB8a]) Hooks.on("deleteActiveEffect", fn);
// TRG Prime 3.686.2+: a lone GM tab is its account's writer only once the
// connection election has settled (about 400 ms after load). A real game
// is long past that before any spell is cast; the harness waits for it,
// as the core's own harnesses do. Older cores have no election: no wait.
{
  const GC = await import(sys("module", "gm-connection.mjs")).catch(() => null);
  if (GC?.gmConnectionReady) await GC.gmConnectionReady();
}

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
{
  const audit = read("docs", "ELDRITCH_ARTS_BLOCK8_AUDIT.md");
  const rows = [...audit.matchAll(/^\| \d+ \| ([^|]+) \| \d+ \| \d+ \| [^|]+ \| [^|]+ \| [A-D] \| [A-D] \| 8a \|$/gm)].map((m) => m[1].trim());
  equal("A the 22 are the audit's 8a, in the book's names", C.SPELLS_B8A.map((s) => s.name).sort(), rows.sort());
  equal("A …22 of them", [C.SPELLS_B8A.length, rows.length], [22, 22]);
  const grim = new Map(book.grimoire.map((e) => [e.name, e]));
  for (const [i, name] of C.BLOCK8A_NAMES.entries()) {
    const s = C.SPELLS_B8A[i], b = grim.get(name);
    ok(`A ${s.name}: in the book`, Boolean(b));
    if (!b) continue;
    equal(`A ${s.name}: PP, type, uncommon`, [s.system.ppCost, s.type, s.system.availability], [b.pp, "spell", "uncommon"]);
    const trad = String(b.fields.Tradition ?? "").trim().toLowerCase();
    equal(`A ${s.name}: tradition (all → the four)`, s.system.tradition, trad === "all" ? "arcane, divinity, ethereal, verdant" : trad);
    ok(`A ${s.name}: traits as printed`, s.system.traits.split(", ").map((t) => t.toUpperCase()).join(" ") === b.traits.join(" "));
    ok(`A ${s.name}: the card prints the book's text`, b.lines.every((l) => s.system.description.replace(/<[^>]+>/g, "").includes(l.replace(/\*\*/g, "").replace(/\*/g, "").slice(0, 40))));
    const g = C.SPELL_AUTOMATION_B8A[s.name].grade;
    const opens = /<em>(Automated, with a choice|Automated|Partly automated|Not automated)/.exec(s.system.description)?.[1];
    equal(`A ${s.name}: its card opens with its grade (${g})`, opens, { A: "Automated", B: "Automated, with a choice", C: "Partly automated", D: "Not automated" }[g]);
    if (g === "C" || g === "B" && R.isBinding(s.flags[SYS].eaGrimoire)) ok(`A ${s.name}: the card names what is by hand`, /By hand:/.test(s.system.description));
    equal(`A ${s.name}: its key`, s.flags[SYS].eaGrimoire, C.SPELL_AUTOMATION_B8A[s.name].key);
  }
  const grade = (n) => C.SPELL_AUTOMATION_B8A[n]?.grade;
  equal("A grades: B 12, C 6, D 4 (the audit's §3.2: the 8 Summons B, Insanity B with H18, Pain and Weakness B with H17, Harmonic Rift B)", ["A", "B", "C", "D"].map((l) => Object.values(C.SPELL_AUTOMATION_B8A).filter((r) => r.grade === l).length), [0, 12, 6, 4]);
  equal("A the D spells are the audit's: Farsight, Phase Door, Rippling Gaze, Traveller's Charm", C.SPELLS_B8A.filter((s) => grade(s.name) === "D").map((s) => s.name).sort(), ["Farsight", "Phase Door", "Rippling Gaze", "Traveller’s Charm"]);
  const savesLater = [...Object.values(R.BINDINGS).map((b) => b.name), "Symbol of Insanity", "Symbol of Pain", "Symbol of Weakness", "Symbol of Death", "Symbol of Fear", "Blood Biography"];
  equal("A §5: no Binding, Symbol or Blood Biography takes the core's cast save (utility, no defence, no target)", savesLater.map((n) => [S[n].system.category, S[n].system.defence, S[n].system.targets]), savesLater.map(() => ["utility", "", ""]));
  equal("A Undead Binding: SAVE SOUL SUMMONS, no Translocation, as printed", S["Undead Binding"].system.traits, "Save, Soul, Summons");
  equal("A the durations: four 'Until dismissed', four 'Until dismissed or broken' (Q169: all alike)", Object.values(R.BINDINGS).map((b) => S[b.name].system.duration).sort(), ["Until dismissed", "Until dismissed", "Until dismissed", "Until dismissed", "Until dismissed or broken", "Until dismissed or broken", "Until dismissed or broken", "Until dismissed or broken"]);
  for (const n of ["Symbol of Death", "Symbol of Fear"]) {
    ok(`A ${n} (Q184): rebuilt on the Symbol model — keyed, Automated with a choice, no longer 'Not automated'`, S[n].flags[SYS].eaGrimoire === R.keyOf(S[n]) && R.isSymbol(R.keyOf(S[n])) && /<em>Automated, with a choice/.test(S[n].system.description) && !/Not automated/.test(S[n].system.description));
  }
  equal("A Block 3a's automation record says so", [B3S.SPELL_AUTOMATION["Symbol of Death"].level, B3S.SPELL_AUTOMATION["Symbol of Fear"].level], ["automated", "automated"]);
  // 0.12.0: Riserune too ("one surface"; the 0.11.2 live test's cosmetic finding).
  equal("A the objects: Arcane Pouch, Argent Mark, Riserune, Traveller's Charm aim at no creature (targetsObject)", C.SPELLS_B8A.filter((s) => s.flags[SYS].targetsObject).map((s) => s.name).sort(), ["Arcane Pouch", "Argent Mark", "Riserune", "Traveller’s Charm"]);
  equal("A the placed areas print no template of the core's (Archway, Harmonic Rift)", [S["Archway of Ants"].system.area, S["Harmonic Rift"].system.area], ["", ""]);
  ok("A no card claims Automated for a C or D", Object.entries(C.SPELL_AUTOMATION_B8A).every(([n, r]) => !["C", "D"].includes(r.grade) || !/<em>Automated/.test(S[n].system.description)));
  equal("A keys are unique", new Set(C.SPELLS_B8A.map((s) => s.flags[SYS].eaGrimoire)).size, 22);
}

/* ----------------------------------------------------------------- */
/* B — the data, through the core's own readers                       */
/* ----------------------------------------------------------------- */
{
  const W = await quiet(() => import(sys("module", "magic", "spell-warp.mjs")));
  const AS = await quiet(() => import(sys("module", "magic", "active-spells.mjs")));
  for (const b of Object.values(R.BINDINGS)) {
    const s = S[b.name].system;
    const mods = W.aggregateWarpSelection(s.warps, { "warp-0": 3 }).mods;
    equal(`B ${b.name}: "+1 PP: increase the level of the creature by 1" is a count (no ceiling but the cap): three bought, level ${b.max + 3}`, [s.warps.length, s.warps[0].ppCost, W.warpMaxTimes(s.warps[0]) > 3 || W.warpMaxTimes(s.warps[0]) === Infinity || W.warpMaxTimes(s.warps[0]) === null, R.bindingMaxLevel(R.keyOf(S[b.name]), mods.bonusValue)], [1, 1, true, b.max + 3]);
    equal(`B ${b.name}: Q170 — its duration locks the PP as unlimited, and the cast registers`, [AS.ppLockCondition(s.duration), AS.castWillRegister({ durationText: s.duration })], ["unlimited", true]);
  }
  equal("B Q170: Symbol of Death's \"Permanent\" locks; the others' \"varies\" does not", ["Symbol of Death", "Symbol of Fear", "Symbol of Pain", "Symbol of Weakness", "Symbol of Insanity"].map((n) => AS.ppLockCondition(S[n].system.duration)), ["unlimited", null, null, null, null]);
  equal("B Argent Mark: permanent locks (Q170), a year does not; Arcane Pouch's warp locks to the daily preparation", [AS.ppLockCondition(W.aggregateWarpSelection(S["Argent Mark"].system.warps, { "warp-2": 1 }).mods.durationText), AS.ppLockCondition(W.aggregateWarpSelection(S["Argent Mark"].system.warps, { "warp-1": 1 }).mods.durationText), AS.ppLockCondition(W.aggregateWarpSelection(S["Arcane Pouch"].system.warps, { "warp-0": 1 }).mods.durationText)], ["unlimited", null, "dailyPrep"]);
  const WS0 = await quiet(() => import(sys("module", "magic", "wall-spell.mjs")));
  const unread = [];
  for (const s of C.SPELLS_B8A) for (const [i, w] of s.system.warps.entries()) for (const k of Object.keys(w.mods ?? {})) if (JSON.stringify(W.aggregateWarpSelection([w], { "warp-0": 1 }).mods[k]) === JSON.stringify(W.aggregateWarpSelection([], {}).mods[k])) unread.push(`${s.name} #${i} ${k}`);
  equal("B every warp mod key is read by the core's aggregator", unread, []);
  equal("B the warps' mods, as built: the Bindings' count; the pouch's preparation; the archway's square; the mark's three durations; Farsight's hour; the rift's 1d8 and 10 minutes; the wall's HP, and its length or height (one printed option, its two choices)",
    Object.fromEntries(C.SPELLS_B8A.filter((s) => s.system.warps.some((w) => Object.keys(w.mods ?? {}).length)).map((s) => [s.name, s.system.warps.map((w) => w.mods)])),
    { "Animal Binding": [{ bonusValue: 1 }], "Elemental Binding": [{ bonusValue: 1 }], "Entity Binding": [{ bonusValue: 1 }], "Eternal Binding": [{ bonusValue: 1 }], "Fey Binding": [{ bonusValue: 1 }], "Plant Binding": [{ bonusValue: 1 }], "Undead Binding": [{ bonusValue: 1 }], "Wyrm Binding": [{ bonusValue: 1 }],
      "Arcane Pouch": [{ durationText: "until next daily preparation" }], "Archway of Ants": [{ bonusValue: 1 }], "Argent Mark": [{ durationText: "1 month" }, { durationText: "1 year" }, { durationText: "permanent" }], Farsight: [{ durationText: "1 hour" }],
      "Harmonic Rift": [{ damageDice: "1d8" }, { durationText: "10 minutes" }], "Wall of Sand": [{ wallHp: 5 }, { wallLength: 10 }, { wallHeight: 5 }] });
  equal("B every printed warp is built, in order (Wall of Sand's length-or-height option as its two choices)", C.SPELLS_B8A.map((s) => s.system.warps.length), C.BLOCK8A_NAMES.map((n) => book.grimoire.find((e) => e.name === n).lines.filter((l) => /^\*\*\+\d+ PP:?\*\*/.test(l)).length + (n === "WALL OF SAND" ? 1 : 0)));
  {
    const ws = S["Wall of Sand"].system.warps;
    const printed = book.grimoire.find((e) => e.name === "WALL OF SAND").lines.filter((l) => /^\*\*\+\d+ PP:?\*\*/.test(l));
    equal("B Wall of Sand: the book prints \"+2 PP: increase the length of the wall by 10 feet or its height by 5 feet\"; both choices are offered at +2 PP", [/length of the wall by 10 feet or its height by 5 feet/.test(printed[1] ?? ""), ws.map((w) => w.ppCost), /length/.test(ws[1].text), /height/.test(ws[2].text)], [true, [2, 2, 2], true, true]);
    const high = WS0.normaliseWall(S["Wall of Sand"].system.effects.find((e) => e.kind === "wall"), W.aggregateWarpSelection(ws, { "warp-2": 2 }).mods);
    equal("B …the height choice twice: 20 ft long, 20 ft high (TRG Prime 3.686.0's wallHeight)", [high?.lengthFeet, high?.heightFeet], [20, 20]);
  }
  const WS = WS0;
  const wall = WS.normaliseWall(S["Wall of Sand"].system.effects.find((e) => e.kind === "wall"), W.aggregateWarpSelection(S["Wall of Sand"].system.warps, { "warp-0": 1, "warp-1": 1 }).mods);
  equal("B Wall of Sand, as the core's wall reads it: 20 ft (30 warped) × 10, border, sight limited, movement not blocked, DB 0 / Hardness 5 / HP 20 (25 warped)", [wall?.lengthFeet, wall?.heightFeet, wall?.snap, wall?.block?.sight, wall?.block?.move, wall?.sections], [30, 10, "border", 10, 0, { sizeFeet: 5, db: 0, hardness: 5, hp: 25 }]);
  const { normaliseConditional } = await quiet(() => import(sys("module", "conditionals.mjs")));
  const SC = await quiet(() => import(sys("module", "magic", "spell-conditional.mjs")));
  const pouch = SC.normaliseSpellConditional(S["Arcane Pouch"].system.effects.find((e) => e.kind === "conditional"), normaliseConditional)?.grants?.[0];
  equal("B Arcane Pouch's +1 circumstance reaches Conceal an Object only (the core's conditional, which compares action keys in lower case), on you", [pouch?.value, pouch?.type, pouch?.when?.actions, S["Arcane Pouch"].system.effects[0].target], [1, "circumstance", ["concealanobject"], "self"]);
  const CASTING = await quiet(() => import(sys("module", "magic", "casting.mjs")));
  equal("B the core reads the object targets as object targets", ["Arcane Pouch", "Argent Mark", "Traveller’s Charm", "Animal Binding"].map((n) => CASTING.targetsObject?.(S[n]) ?? Boolean(S[n].flags[SYS].targetsObject)), [true, true, true, false]);
  // CORE REMOVE CURSE AGAINST A SYMBOL'S CURSE (H17): the declared row, the core's own reader.
  const { BLOCK8A_CORE_FIXES } = await import(sys("tools", "ea-block8a-core-fixes.mjs"));
  const CR = await quiet(() => import(sys("module", "magic", "counteract-row.mjs")));
  const removeCurse = CR.normaliseCounteract(BLOCK8A_CORE_FIXES.find((f) => f.name === "Remove Curse").to[0]);
  equal("B core Remove Curse (3.686.0) finds a symbol's curse by its traits, not a Symbol of Fear's fear", CR.counteractCandidates(removeCurse, () => false, [{ id: "pain", name: "Symbol of Pain (curse)", statuses: [], sourceTraits: S["Symbol of Pain"].system.traits }, { id: "fear", name: "Frightened", statuses: ["frightened"], sourceTraits: S["Symbol of Fear"].system.traits }]).map((c) => c.key), ["pain"]);
  const TT = await quiet(() => import(sys("module", "magic", "turn-table.mjs")));
  equal("B core Insanity's table (H18) is the one Symbol of Insanity reaches ('insanity'): 1d10, per 2", [TT.INSANITY_TURN_TABLE.die, TT.INSANITY_TURN_TABLE.per], ["1d10", 2]);
  equal("B Ley Line Effects 25–27 (Q184): +1 AB / stunned 1 on the caster's summoned creatures (generated)", [T7.LEY_LINE_EFFECTS.find((r) => r.min === 25).e, T7.LEY_LINE_EFFECTS.find((r) => r.min === 25).b], [{ kind: "summons", row: { kind: "cond", mod: { kind: "modifier", value: 1, type: "untyped" }, when: { checkTypes: ["attack"] }, label: "+1 AB" } }, { kind: "summons", row: { kind: "condition", tag: { key: "stunned", value: 1 } } }]);
}

/* ----------------------------------------------------------------- */
/* C — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  equal("C the eight, as printed: animal 1, elemental 2, aberration 8, eternal 6, fey 1, plant 2, undead 4, wyrm 6", Object.values(R.BINDINGS).map((b) => `${b.type} ${b.max}`), ["animal 1", "elemental 2", "aberration 8", "eternal 6", "fey 1", "plant 2", "undead 4", "wyrm 6"]);
  equal("C the ladder (m42): Heroic/Critical hostile, Success free, Partial/Failure bound, Fumble/Blunder loyal", R.DEGREES.map((d) => R.bindingOutcome(d)), ["hostile", "hostile", "free", "bound", "bound", "loyal", "loyal"]);
  equal("C a Fumble circle: hostile whatever it rolls", ["fumble", "success", "failure"].map((d) => R.bindingOutcome(d, { circleFumble: true })), ["hostile", "hostile", "hostile"]);
  equal("C only bound and loyal count against Control Levels (Q168)", ["hostile", "free", "bound", "loyal"].map(R.bindingControls), [false, false, true, true]);
  equal("C a true name: hostile on a Success or better", ["heroic", "critical", "success", "partial", "failure"].map(R.trueNameHostile), [true, true, true, false, false]);
  const traits = R.creatureTraitsOf({ typeName: "Animal", traits: "Minion, Beast" });
  equal("C the refusals: its trait, its level, its distance, not the caster; none when all hold",
    [R.bindingRefusal("animalBinding", { traits: R.creatureTraitsOf({ typeName: "Plant" }), level: 1, feet: 5 }, 1) !== "", R.bindingRefusal("animalBinding", { traits, level: 3, feet: 5 }, 2) !== "", R.bindingRefusal("animalBinding", { traits, level: 2, feet: 35 }, 2) !== "", R.bindingRefusal("animalBinding", { traits, level: 2, feet: null }, 2) !== "", R.bindingRefusal("animalBinding", { traits, level: 1, feet: 0, isCaster: true }, 1) !== "", R.bindingRefusal("animalBinding", { traits, level: 2, feet: 30 }, 2)],
    [true, true, true, true, true, ""]);
  equal("C a trait read from the trait line too", R.bindingRefusal("undeadBinding", { traits: R.creatureTraitsOf({ traits: "Undead, Mindless" }), level: 4, feet: 10 }, 4), "");
  equal("C the Symbols' rungs by m42: Death (Partial → deadly critical, Blunder → dies), Fear, Pain, Weakness",
    [["symbolOfDeath", "heroic"], ["symbolOfDeath", "partial"], ["symbolOfDeath", "blunder"], ["symbolOfFear", "partial"], ["symbolOfFear", "blunder"], ["symbolOfPain", "partial"], ["symbolOfPain", "critical"], ["symbolOfWeakness", "heroic"], ["symbolOfWeakness", "partial"], ["symbolOfWeakness", "blunder"]].map(([k, d]) => R.symbolRung(k, d).at),
    ["success", "failure", "fumble", "partial", "fumble", "failure", "success", "critical", "partial", "fumble"]);
  equal("C the printed values: Pain injured 2/4; Weakness 1/2/4/6; Fear frightened 2/4/6 with fleeing 1 round", [R.SYMBOLS.symbolOfPain.rungs.failure.hold, R.SYMBOLS.symbolOfPain.rungs.fumble.hold, ...["success", "partial", "failure", "fumble"].map((k) => R.SYMBOLS.symbolOfWeakness.rungs[k].hold), ...["partial", "failure", "fumble"].map((k) => R.SYMBOLS.symbolOfFear.rungs[k].conditions.map((c) => `${c.key}${c.value ?? ""}${c.rounds ? `/${c.rounds}r` : ""}`).join("+"))], [2, 4, 1, 2, 4, 6, "frightened2", "frightened4+fleeing/1r", "frightened6+fleeing/1r"]);
  equal("C Insanity: a Partial or worse is a failed save", R.DEGREES.map(R.insanityFails), [false, false, false, true, true, true, true]);
  equal("C a worse result replaces (injured adds the difference; weakened keeps the higher), an equal one leaves it",
    [R.heldStep({ adds: true, current: 3, held: 2, contributed: 2, next: 4 }), R.heldStep({ adds: false, current: 4, held: 4, contributed: 3, next: 6 }), R.heldStep({ adds: true, current: 3, held: 4, contributed: 4, next: 2 }).worse, R.heldStep({ adds: true, current: 1, held: 0, contributed: 0, next: 2 }), R.heldStep({ adds: true, current: 4, held: 4, contributed: 4, next: 4 })],
    [{ apply: 2, after: 5, held: 4, contributed: 4, worse: true }, { apply: 6, after: 6, held: 6, contributed: 5, worse: true }, false, { apply: 2, after: 3, held: 2, contributed: 2, worse: true }, { apply: 0, after: 4, held: 4, contributed: 4, worse: false }]);
  equal("C m135's hour: starts past 60 ft, stops back within it, else unchanged", [R.holdClock(65, false), R.holdClock(65, true), R.holdClock(60, true), R.holdClock(30, false), R.holdClock(null, false)], ["start", "unchanged", "stop", "unchanged", "unchanged"]);
  equal("C the glow: 10 minutes of world time unseen", [R.glowLapsed(0, 599), R.glowLapsed(0, 600)], [false, true]);
  equal("C the utilities' numbers: archway 6 (+warps), 10 × allowance, 50 + Str × 10; rift 3d8 (+1d8 a warp); riserune Small+; mark durations", [R.archwaySquares(2), R.archwayLoad(R.weightAllowance(3)), R.riftDice(""), R.riftDice("2d8"), R.riseruneTriggeredBy("tiny"), R.riseruneTriggeredBy("small"), R.markSeconds("1 week"), R.markSeconds("1 month"), R.markSeconds("1 year"), R.markSeconds("permanent")], [8, 800, "3d8", "5d8", false, true, 604800, 2592000, 31536000, null]);
  equal("C Ley Line Effects' summoned creatures: bound and conjured entries", ["bound", "conjured", "aligned", "undead"].map((s) => R.isSummonedEntry({ source: s })), [true, true, false, false]);
}

/* ----------------------------------------------------------------- */
/* D — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const registered = [];
  const api = new Proxy({}, { get: (_, name) => (...args) => { registered.push([name, ...args]); return true; } });
  A.registerBlock8a(api, MOD);
  const deferred = registered.filter(([n]) => n === "registerDeferredTeleport");
  equal("D Arcane Pouch and Harmonic Rift register their teleports as later than their casts (the audit's §5)", deferred.map(([, key, , mod]) => [key, mod]), [["eaArcanePouch", MOD], ["eaHarmonicRift", MOD]]);
  const CORE_API = await quiet(() => import(sys("module", "module-api.mjs")));
  const TRW = await quiet(() => import(sys("module", "trait-rules-workflow.mjs")));
  for (const [, key, fn] of deferred) CORE_API.registerDeferredTeleport(key, fn, MOD);
  equal("D the core, asked of the shipped spells: the pouch and the rift deferred; a Binding (no Teleportation) is not", [await TRW.teleportDeferred({ spell: S["Arcane Pouch"], spellData: S["Arcane Pouch"].system }), await TRW.teleportDeferred({ spell: S["Harmonic Rift"], spellData: S["Harmonic Rift"].system }), await TRW.teleportDeferred({ spell: S["Animal Binding"], spellData: S["Animal Binding"].system })], [true, true, false]);
  const reg = read("module", "registration.mjs");
  ok("D registration calls registerBlock8a", /registerBlock8a\(api, moduleId\);/.test(reg));
}

/* ----------------------------------------------------------------- */
/* E — the Foundry side                                                */
/* ----------------------------------------------------------------- */
const castCtx = (actor, name, extra = {}) => ({ actor, spell: S[name], spellData: S[name].system, cast: true, refunded: false, saveDC: 21, castPP: S[name].system.ppCost, warpMods: {}, castOptions: [], metamagic: [], ...extra });
function binder(name, opts = {}) { const a = makeActor(name, opts); makeToken(a, { x: 0, y: 0 }); return a; }
const markerOf = (caster) => caster.effects.find((e) => e.flags?.[MOD]?.source === R.BINDING_FLAG);
const recordOfMarker = (caster) => markerOf(caster)?.flags?.[MOD]?.[R.BINDING_FLAG] ?? null;
{
  // E1 the settled cast
  reset();
  const mage = binder("Mage", { cap: 4 });
  mage.flags[SYS].activeSpells = [{ id: "cast1", name: "Animal Binding", lock: "unlimited" }];
  const rec = await A.onSpellSettledB8a(castCtx(mage, "Animal Binding", { warpMods: { bonusValue: 2 }, castOptions: ["truename"] }));
  const m = markerOf(mage);
  equal("E1 settled: a record on the caster — the cast's id (so Dismiss ends it), its Save DC, level 1 + 2 warps, the true name", [m?.flags?.[SYS]?.castId, rec?.saveDC, rec?.maxLevel, rec?.type, rec?.trueName, rec?.state], ["cast1", 21, 3, "animal", true, "pending"]);
  const msg = messages.at(-1);
  ok("E1 …and a card whispered to the GM with the button", Array.isArray(msg?.whisper) && msg.whisper.includes("gm") && /data-ea8a="bindCreature"/.test(msg.content) && new RegExp(`data-ea8a-ref="${rec.id}"`).test(msg.content));
  equal("E1 a refunded or failed cast leaves nothing", [await A.onSpellSettledB8a(castCtx(mage, "Animal Binding", { cast: false })), await A.onSpellSettledB8a(castCtx(mage, "Animal Binding", { refunded: true })), mage.effects.filter((e) => e.flags?.[MOD]?.source === R.BINDING_FLAG).length], [null, null, 1]);

  // E2 the refusals
  const plant = makeActor("Shrub", { level: 1, type: "Plant" }); const pt = makeToken(plant, { x: 100, y: 0 });
  const bigWolf = makeActor("Dire Wolf", { level: 4, type: "Animal" }); const bt = makeToken(bigWolf, { x: 200, y: 0 });
  const farWolf = makeActor("Far Wolf", { level: 1, type: "Animal" }); const ft = makeToken(farWolf, { x: 1000, y: 0 });
  for (const t of [pt, bt, ft]) { canvas.tokens.controlled = [t]; await A.bindCreature(mage, rec.id); }
  canvas.tokens.controlled = [];
  await A.bindCreature(mage, rec.id);
  equal("E2 refused, each said, no save rolled: a plant, a level-4 animal (max 3), one 50 ft away, none selected", [warns.length, calls.checks.length, warns.map((w) => /animal trait|level 3 or lower|within 30 feet|select the creature/.test(w))], [4, 0, [true, true, true, true]]);

  // E3 bound (Failure), recorded in the REAL core register
  const wolf = makeActor("Wolf", { level: 2, type: "Animal", owner: false }); const wt = makeToken(wolf, { x: 100, y: 100 });
  canvas.tokens.controlled = [wt];
  degreeFor.set("Wolf", "failure");
  const bound = await A.bindCreature(mage, rec.id);
  const entry = CRW.controlledOf(mage)[0];
  const boundFx = wolf.effects.find((e) => e.flags?.[MOD]?.source === R.BOUND_FLAG);
  equal("E3 Failure: the Will save at the cast's DC, by the creature; bound — the core's register holds it as \"bound\", with the cast and the module", [calls.checks.at(-1), bound?.state, entry?.source, entry?.castId, entry?.data?.module, entry?.level], [{ actor: "Wolf", type: "save", subject: "will", dc: 21, sourceUuid: mage.uuid }, "bound", "bound", "cast1", MOD, 2]);
  ok("E3 …a \"Bound to Mage\" effect on it (relayed: the GM's creature), naming the minion trait and the 1 AP command (Q169)", Boolean(boundFx) && /minion/.test(boundFx.description) && /1 AP verbal command \(auditory, concentrate; Q169\)/.test(boundFx.description) && !(boundFx.flags?.[SYS]?.conditionals?.length));
  ok("E3 …and the card gives the control levels", cards.some((c) => c.lines.some((l) => /Control Levels: <strong>2 of 4<\/strong>/.test(l))));
  equal("E3 a second press is refused (already bound)", [await A.bindCreature(mage, rec.id), warns.at(-1)?.includes("already")], [false, true]);

  // E4 Dismissed: the core ends the cast; the binding releases and the creature returns
  fired.length = 0;
  mage.isOwner = true; wolf.isOwner = false;
  await helpers.endSpellOf(mage, "cast1");
  await flush();
  equal("E4 dismissed: the entry released (the core's hook fires, reason \"ended\"), the bound effect deleted through the GM, the card says it returns", [CRW.controlledOf(mage).length, fired.find((f) => f.name === "trgPrimeControlReleased")?.payload?.reason, wolf.effects.some((e) => e.flags?.[MOD]?.source === R.BOUND_FLAG), cards.some((c) => c.lines.some((l) => /returns to where it was summoned from/.test(l)))], [0, "ended", false, true]);
}
{
  // E5 Critical: hostile, the spell ends, nothing recorded; the true name
  reset();
  const mage = binder("Mage2");
  mage.flags[SYS].activeSpells = [{ id: "c2", name: "Fey Binding" }];
  const rec = await A.onSpellSettledB8a(castCtx(mage, "Fey Binding", { castOptions: ["truename"] }));
  const sprite = makeActor("Sprite", { level: 1, type: "Fey" }); canvas.tokens.controlled = [makeToken(sprite, { x: 100, y: 0 })];
  degreeFor.set("Sprite", "critical");
  const out = await A.bindCreature(mage, rec.id);
  equal("E5 Critical: enraged and hostile, the spell ends (Dismiss's path), nothing against control levels; the true name's permanent hostility", [out?.state, calls.ended.map((e) => e.castId), CRW.controlledOf(mage).length, sprite.effects.some((e) => e.flags?.[MOD]?.source === R.HOSTILE_FLAG), sprite.effects.some((e) => e.flags?.[MOD]?.source === "trueNameHostility"), Boolean(markerOf(mage))], ["hostile", ["c2"], 0, true, true, false]);
  ok("E5 …its end posts nothing more (it stays; the GM runs it)", !cards.some((c) => c.lines.some((l) => /returns to where/.test(l))));
}
{
  // E6 Success: free; dismissing sends it back. E7 Fumble: loyal, +2. E8 a Fumble circle.
  reset();
  const mage = binder("Mage3");
  mage.flags[SYS].activeSpells = [{ id: "c3", name: "Plant Binding" }, { id: "c4", name: "Wyrm Binding" }];
  const r1 = await A.onSpellSettledB8a(castCtx(mage, "Plant Binding"));
  const vine = makeActor("Vine", { level: 2, type: "Plant" }); canvas.tokens.controlled = [makeToken(vine, { x: 100, y: 0 })];
  degreeFor.set("Vine", "success");
  const free = await A.bindCreature(mage, r1.id);
  equal("E6 Success: free, not recorded, no bound effect (Q168)", [free?.state, CRW.controlledOf(mage).length, vine.effects.length], ["free", 0, 0]);
  await helpers.endSpellOf(mage, "c3");
  ok("E6 …dismissed, it is sent back", cards.some((c) => c.lines.some((l) => /Plant Binding ends: Vine returns to where it was summoned from/.test(l))));
  const r2 = await A.onSpellSettledB8a(castCtx(mage, "Wyrm Binding"));
  const drake = makeActor("Drake", { level: 6, type: "Wyrm" }); canvas.tokens.controlled = [makeToken(drake, { x: 100, y: 100 })];
  degreeFor.set("Drake", "blunder");
  const loyal = await A.bindCreature(mage, r2.id);
  const fx = drake.effects.find((e) => e.flags?.[MOD]?.source === R.BOUND_FLAG);
  equal("E7 Blunder → Fumble (m42): loyal — bound, and +2 circumstance to all its checks (always) while it serves", [loyal?.state, CRW.controlledOf(mage).length, fx?.flags?.[SYS]?.conditionals], ["loyal", 1, [{ kind: "modifier", value: 2, type: "circumstance", label: "Unusually loyal", scope: "all checks while serving Mage3", auto: true, always: true }]]);
  const circle = binder("Mage4");
  circle.effects.push(makeEffect({ name: "circle", flags: { [MOD]: { circle: { degree: "fumble" } } } }, circle));
  circle.flags[SYS].activeSpells = [{ id: "c5", name: "Undead Binding" }];
  const r3 = await A.onSpellSettledB8a(castCtx(circle, "Undead Binding"));
  const ghoul = makeActor("Ghoul", { level: 3, type: "Undead" }); canvas.tokens.controlled = [makeToken(ghoul, { x: 100, y: 0 })];
  degreeFor.set("Ghoul", "fumble");
  equal("E8 a Fumble circle (Block 2b): hostile and unbound, whatever it rolled", [r3.circleFumble, (await A.bindCreature(circle, r3.id))?.state], [true, "hostile"]);
}
{
  // E9 broken: the REAL core sweep frees it; the hook ends the binding (Q169)
  reset();
  const mage = binder("Lich", { cap: 1 });
  mage.flags[SYS].activeSpells = [{ id: "c6", name: "Entity Binding" }];
  const rec = await A.onSpellSettledB8a(castCtx(mage, "Entity Binding"));
  const horror = makeActor("Horror", { level: 6, type: "Aberration" }); canvas.tokens.controlled = [makeToken(horror, { x: 100, y: 0 })];
  degreeFor.set("Horror", "failure");
  await A.bindCreature(mage, rec.id);
  // FIRST, WHILE THE BINDING STANDS: a release the module must not answer.
  const entryNow = CRW.controlledOf(mage)[0];
  equal("E9 another module's overflow release, or this module's by another reason, is not answered (the binding stands)",
    [await A.onControlReleasedB8a({ controller: mage, entry: { ...entryNow, data: { module: "other" } }, reason: "overflow" }), await A.onControlReleasedB8a({ controller: mage, entry: entryNow, reason: "released" }), recordOfMarker(mage)?.state, calls.ended.length], [null, null, "bound", 0]);
  const { TRGCheck } = await quiet(() => import(sys("module", "dice", "check.mjs")));
  TRGCheck.roll = async () => ({ outcome: { degree: { key: "success" } } });
  fired.length = 0;
  await quiet(() => CRW.sweepControlOverflow(mage));
  const payload = fired.find((f) => f.name === "trgPrimeControlReleased")?.payload;
  equal("E9 over the cap, the core's DC 20 Will frees it: the hook says \"overflow\"", [payload?.reason, payload?.entry?.data?.module], ["overflow", MOD]);
  await A.onControlReleasedB8a(payload);
  equal("E9 …the binding is broken: the spell ends, the card says it broke free and returns", [calls.ended.map((e) => e.castId), Boolean(markerOf(mage)), cards.some((c) => c.lines.some((l) => /broke free \(DC 20 Will\): the binding is broken/.test(l)))], [["c6"], false, true]);
}
{
  // E10 one client: a binding's end is done by the client that acts for the caster
  reset();
  const mage = binder("Solo");
  mage.flags[SYS].activeSpells = [{ id: "c7", name: "Animal Binding" }];
  await A.onSpellSettledB8a(castCtx(mage, "Animal Binding"));
  const m = markerOf(mage);
  game.users.activeGM = { id: "another-gm" };
  mage.effects = [];
  const r = await A.onEffectDeletedB8a(m);
  game.users.activeGM = game.user;
  equal("E10 on a client that does not act for the caster, a binding's end does nothing", [r, cards.length], [null, 0]);
}
{
  // E11 Versatile Binder (Q133, Q184): no save of its own; the binding's save, the binding's checks
  reset();
  const mage = binder("Binder");
  mage.flags[SYS].activeSpells = [{ id: "c8", name: "Animal Binding" }];
  const bear = makeActor("Bear", { level: 1, type: "Animal" }); const bt = makeToken(bear, { x: 100, y: 0 });
  const after = B6D.METAMAGIC_B6_D?.versatilebinder?.after ?? Object.values(B6D.METAMAGIC_B6_D ?? {}).find((m) => m.label === "Versatile Binder")?.after;
  const said = await after({ cast: true, eaBound: bt.document.uuid, actor: mage, spell: S["Animal Binding"], spellData: S["Animal Binding"].system });
  equal("E11 Versatile Binder on a Binding rolls nothing itself and hands the creature over", [calls.checks.length, /is the creature/.test(said?.lines?.[0] ?? "")], [0, true]);
  const rec = await A.onSpellSettledB8a(castCtx(mage, "Animal Binding", { metamagic: ["versatilebinder"] }));
  degreeFor.set("Bear", "failure");
  const out = await A.bindCreature(mage, rec.id);
  equal("E11 …the binding binds that creature by its own save (no selection needed)", [rec.binder, out?.state, out?.creatureName, calls.checks.length], [bt.document.uuid, "bound", "Bear", 1]);
  await helpers.endSpellOf(mage, "c8");
  ok("E11 …and on the end it is released where it stands (Q168)", cards.some((c) => c.lines.some((l) => /released where it stands/.test(l))));
  const B6C = await import(new URL("./content/block6-d.mjs", import.meta.url));
  const vbFeat = B6C.FEATS_B6_D.find((f) => f.name === "Versatile Binder");
  equal("E11 …graded B (C → B at 0.11.0), its card says the binding binds it on the control register (Q184)", [B6C.AUTOMATION_B6_D["Versatile Binder"]?.level, /Automated \(0\.11\.0, TRG Prime 3\.686\.0\)/.test(vbFeat?.system?.description ?? ""), /Q184/.test(vbFeat?.system?.description ?? "") && /Control Levels/.test(vbFeat?.system?.description ?? ""), /until they ship/.test(vbFeat?.system?.description ?? "")], ["B", true, true, false]);
  reset();
  const other = binder("Binder2");
  const fox = makeActor("Fox", { level: 1, type: "Animal" }); const fxT = makeToken(fox, { x: 100, y: 0 });
  const said2 = await after({ cast: true, eaBound: fxT.document.uuid, actor: other, spell: { name: "Summon Beast", flags: {} }, spellData: { defence: "Will" } });
  equal("E11 a Summons spell that is not a Binding keeps 0.9.0's own save", [calls.checks.length, /resists|fails/.test(said2?.lines?.[0] ?? "")], [1, true]);
}
{
  // E12 the buttons: a GM's is the GM's, a caster's the caster's owner's
  reset();
  const mage = binder("Btn");
  game.user.isGM = false;
  equal("E12 a player cannot press a GM's button", [await A.onCardButton("bindCreature", mage.uuid, "x"), /only the GM/.test(warns.at(-1) ?? "")], [false, true]);
  game.user.isGM = true;
  mage.isOwner = false;
  equal("E12 …nor anyone the caster's own", [await A.onCardButton("markWhere", mage.uuid, "x"), /only Btn's player/.test(warns.at(-1) ?? "")], [false, true]);
  mage.isOwner = true;
  equal("E12 an unknown button does nothing", await A.onCardButton("nope", mage.uuid, "x"), false);
}

/* --- the Symbols --- */
const symbolOf = () => scene.regions.find((r) => r.flags?.[MOD]?.[R.SYMBOL_FLAG]);
{
  reset();
  const mage = binder("Carver");
  nextClick = [{ x: 260, y: 40 }];
  await A.onSpellSettledB8a(castCtx(mage, "Symbol of Fear"));
  equal("E13 a symbol is carved by touch: a click 10 ft away is refused, no Region", [scene.regions.length, cards.some((c) => c.lines.some((l) => /carved by touch/.test(l)))], [0, true]);
  nextClick = [{ x: 150, y: 40 }];
  mage.flags[SYS].activeSpells = [];
  await A.onSpellSettledB8a(castCtx(mage, "Symbol of Fear", { castPP: 12 }));
  const reg = symbolOf();
  const rec = reg?.flags?.[MOD]?.[R.SYMBOL_FLAG];
  equal("E13 within reach: a GM-hidden one-square Region with the stamped DC, the PP, the traits", [reg?.visibility, reg?.shapes?.[0], rec?.saveDC, rec?.pp, rec?.traits, rec?.glowing], [1, { type: "rectangle", x: 100, y: 0, width: 100, height: 100, rotation: 0, hole: false }, 21, 12, S["Symbol of Fear"].system.traits, false]);
  ok("E13 …and a GM card with The symbol flashes and Remove the symbol", /data-ea8a="flashSymbol"/.test(messages.at(-1)?.content ?? "") && /data-ea8a="removeSymbol"/.test(messages.at(-1)?.content ?? "") && messages.at(-1)?.whisper?.includes("gm"));
  // line of sight, and the GM's checklist
  const a1 = makeActor("Orc"); makeToken(a1, { x: 500, y: 0 });
  const a2 = makeActor("Goblin"); makeToken(a2, { x: 0, y: 500 });
  const a3 = makeActor("Hidden"); const t3 = makeToken(a3, { x: 900, y: 900 });
  blocked.add(`${t3.center.x},${t3.center.y}`);
  equal("E14 every token with line of sight (a wall-blocked one left out)", A.tokensInSight(reg, { x: rec.x, y: rec.y }).map((t) => t.name).sort(), ["Carver", "Goblin", "Orc"]);
  dialogPick = (cfg) => cfg.buttons[0].callback(null, { form: { elements: Object.fromEntries(["t0", "t1", "t2"].map((k, i) => [k, { checked: i !== 0 }])) } });
  degreeFor.set("Goblin", "failure"); degreeFor.set("Orc", "partial");
  await A.flashSymbol(mage, reg.uuid);
  const tagsOf = (n) => calls.conditions.filter((c) => c.target === n).flatMap((c) => c.tags.map((t) => `${t.key}${t.value ?? ""}${t.expiresTime ? "@" + (t.expiresTime - 1000) : ""}`));
  equal("E14 the GM untick the caster; the others roll Will at the stamped DC; Partial frightened 2, Failure frightened 4 and fleeing 1 round", [calls.checks.map((c) => `${c.actor}:${c.subject}:${c.dc}`).sort(), tagsOf("Orc"), tagsOf("Goblin")], [["Goblin:will:21", "Orc:will:21"], ["frightened2"], ["frightened4", "fleeing@6"]]);
  equal("E14 …the fear carries the spell's traits; the symbol glows (shown to the players)", [calls.conditions[0]?.options?.sourceTraits, reg.visibility, reg.flags[MOD][R.SYMBOL_FLAG].glowing, reg.flags[MOD][R.SYMBOL_FLAG].lastSeen], [S["Symbol of Fear"].system.traits, 2, true, 1000]);
  // the glow
  game.time.worldTime = 1300;
  await A.refreshSymbolGlow(scene);
  equal("E15 seen: the glow's clock is kept", reg.flags[MOD][R.SYMBOL_FLAG].lastSeen, 1300);
  canvas.tokens.placeables = [];
  game.time.worldTime = 1800;
  await A.refreshSymbolGlow(scene);
  const still = reg.flags[MOD][R.SYMBOL_FLAG].glowing;
  game.time.worldTime = 1900;
  game.users.activeGM = { id: "other" };
  await A.refreshSymbolGlow(scene);
  const otherClient = reg.flags[MOD][R.SYMBOL_FLAG].glowing;
  game.users.activeGM = game.user;
  await A.refreshSymbolGlow(scene);
  equal("E15 unseen for 10 minutes it stops glowing (hidden again) — on the acting GM's client only", [still, otherClient, reg.flags[MOD][R.SYMBOL_FLAG].glowing, reg.visibility], [true, true, false, 1]);
  await A.removeSymbol(mage, reg.uuid);
  equal("E15 Remove the symbol", scene.regions.length, 0);
}
{
  // E16 Pain: the curse holds (H17); a worse flash replaces in place; Remove Curse; the hour
  reset();
  const mage = binder("Painter");
  nextClick = [{ x: 150, y: 40 }];
  await A.onSpellSettledB8a(castCtx(mage, "Symbol of Pain", { castPP: 12, saveDC: 22 }));
  const reg = symbolOf();
  const ogre = makeActor("Ogre", { owner: true }); const ot = makeToken(ogre, { x: 300, y: 0 });
  ogre.conditions.rawValues.set("injured", 1);
  degreeFor.set("Ogre", "failure");
  await A.flashSymbol(mage, reg.uuid, { reached: [ot] });
  const hold = () => ogre.effects.find((e) => e.flags?.[MOD]?.source === R.SYMBOL_HOLD_FLAG);
  equal("E16 Failure: injured 2 (added to its 1), held by the curse — heldConditions with its share, the spell's Curse traits, counteractAs the symbol's PP and DC", [ogre.getConditionValue("injured"), hold()?.flags?.[SYS]?.heldConditions, /Curse/.test(hold()?.flags?.[SYS]?.sourceTraits), hold()?.flags?.[SYS]?.counteractAs], [3, { keys: ["injured"], values: { injured: 2 }, endWith: true, label: "Symbol of Pain" }, true, { pp: 12, dc: 22 }]);
  ok("E16 …the injury itself is laid with no curse trait (Remove Curse finds the hold, never the plain condition)", calls.conditions.filter((c) => c.target === "Ogre").every((c) => !c.options?.sourceTraits));
  degreeFor.set("Ogre", "fumble");
  await A.flashSymbol(mage, reg.uuid, { reached: [ot] });
  equal("E16 a later Fumble (injured 4) replaces it in place: +2 more, the hold's share 4, one hold", [ogre.getConditionValue("injured"), hold()?.flags?.[SYS]?.heldConditions?.values, ogre.effects.filter((e) => e.flags?.[MOD]?.source === R.SYMBOL_HOLD_FLAG).length], [5, { injured: 4 }, 1]);
  degreeFor.set("Ogre", "failure");
  await A.flashSymbol(mage, reg.uuid, { reached: [ot] });
  equal("E16 an equal or better one leaves it", [ogre.getConditionValue("injured"), hold()?.flags?.[SYS]?.heldConditions?.values], [5, { injured: 4 }]);
  // THE REAL CORE: nothing else lowers it while held; the hold's end takes its share off
  const FW = await quiet(() => import(sys("module", "feats-workflow.mjs")));
  const r = await FW.MODULE_HELPERS.reduceCondition(ogre, "injured", 3);
  equal("E17 the core (H17) refuses to reduce it while the hold stands", [r.held, ogre.getConditionValue("injured")], [true, 5]);
  // the hour (m135): 65 ft away starts it; back within 60 stops it
  await moveV14(ot.document, { x: 1400 });
  const started = hold()?.flags?.[SYS]?.spellEffectEnd;
  await moveV14(ot.document, { x: 300 });
  equal("E18 the hour starts once it is farther than 60 ft, and stops when it comes back", [started, hold()?.flags?.[SYS]?.spellEffectEnd], [1000 + 3600, undefined]);
  ogre.isOwner = false;
  game.users.activeGM = { id: "other" };
  await moveV14(ot.document, { x: 1400 });
  game.users.activeGM = game.user; ogre.isOwner = true;
  equal("E18 …on the client that acts for the creature only", hold()?.flags?.[SYS]?.spellEffectEnd, undefined);
  // Remove Curse's counteract deletes the hold: the core's H17 end hook lowers by its share
  const HW = await quiet(() => import(sys("module", "conditions", "held-conditions-workflow.mjs")));
  const coreHooks = [];
  const realOn = Hooks.on;
  Hooks.on = (n, fn) => { if (n === "deleteActiveEffect") coreHooks.push(fn); return fn; };
  HW.registerHeldConditionHooks();
  Hooks.on = realOn;
  hookList.get("deleteActiveEffect").push(...coreHooks);
  await hold().delete();
  await tick(); await tick();
  equal("E19 Remove Curse's counteract (or the hour's end) deletes the hold: the core takes its share off (5 → 1)", ogre.getConditionValue("injured"), 1);
  hookList.set("deleteActiveEffect", (hookList.get("deleteActiveEffect") ?? []).filter((f) => !coreHooks.includes(f)));
}
{
  // E20 Weakness keeps the higher; Death; Insanity
  reset();
  const mage = binder("Weak");
  nextClick = [{ x: 150, y: 40 }];
  await A.onSpellSettledB8a(castCtx(mage, "Symbol of Weakness"));
  const reg = symbolOf();
  const elf = makeActor("Elf"); const et = makeToken(elf, { x: 300, y: 0 });
  elf.conditions.rawValues.set("weakened", 3);
  degreeFor.set("Elf", "partial");
  await A.flashSymbol(mage, reg.uuid, { reached: [et] });
  const share = () => elf.effects.find((e) => e.flags?.[MOD]?.source === R.SYMBOL_HOLD_FLAG)?.flags?.[SYS]?.heldConditions?.values?.weakened;
  equal("E20 Weakness, Partial: weakened 2 against its 3 — it stays 3 (the higher), the hold's share 0", [elf.getConditionValue("weakened"), share()], [3, 0]);
  const farOne = makeActor("Archer"); const fa = makeToken(farOne, { x: 1600, y: 0 });
  degreeFor.set("Archer", "failure");
  await A.flashSymbol(mage, reg.uuid, { reached: [fa] });
  equal("E20 a creature already farther than 60 ft at the flash: its hour starts now (m135)", farOne.effects.find((e) => e.flags?.[MOD]?.source === R.SYMBOL_HOLD_FLAG)?.flags?.[SYS]?.spellEffectEnd, 1000 + 3600);
  equal("E20 …one within 60 ft waits", elf.effects.find((e) => e.flags?.[MOD]?.source === R.SYMBOL_HOLD_FLAG)?.flags?.[SYS]?.spellEffectEnd, undefined);
  degreeFor.set("Elf", "failure");
  await A.flashSymbol(mage, reg.uuid, { reached: [et] });
  equal("E20 …Failure: weakened 4, the share 1", [elf.getConditionValue("weakened"), share()], [4, 1]);
  degreeFor.set("Elf", "critical");
  const before = elf.effects.length;
  await A.flashSymbol(mage, reg.uuid, { reached: [et] });
  equal("E20 …Critical: unaffected", [elf.getConditionValue("weakened"), elf.effects.length], [4, before]);
  reset();
  const necro = binder("Necro");
  necro.flags[SYS].activeSpells = [{ id: "d1", name: "Symbol of Death", lock: "unlimited" }];
  nextClick = [{ x: 150, y: 40 }];
  await A.onSpellSettledB8a(castCtx(necro, "Symbol of Death"));
  const dreg = symbolOf();
  equal("E21 Symbol of Death's Region carries its registered cast (Permanent: Q170)", dreg.flags[MOD][R.SYMBOL_FLAG].castId, "d1");
  const k1 = makeActor("Knight"); const k1t = makeToken(k1, { x: 300, y: 0 });
  const k2 = makeActor("Squire"); const k2t = makeToken(k2, { x: 0, y: 300 });
  degreeFor.set("Knight", "partial"); degreeFor.set("Squire", "success");
  const out1 = await A.flashSymbol(necro, dreg.uuid, { reached: [k1t, k2t] });
  equal("E21 Partial → a deadly essence critical (by the caster, the symbol's DC as its attack bonus, as the core's save criticals); Success unaffected; no death, it glows on", [calls.crits, out1?.faded, scene.regions.length], [[{ attacker: "Necro", target: "Knight", severity: "deadly", type: "essence", attackBonus: dreg.flags[MOD][R.SYMBOL_FLAG].saveDC }], false, 1]);
  ok("E21b …and that DC is a real number (not the Fatal save's DC 10)", Number(dreg.flags[MOD][R.SYMBOL_FLAG].saveDC) > 10);
  degreeFor.set("Squire", "blunder");
  const out2 = await A.flashSymbol(necro, dreg.uuid, { reached: [k2t] });
  equal("E21 Blunder → the creature dies (Dying past its Death State); a death fades the symbol and ends the spell (m132)", [k2.getConditionValue("dying"), out2?.faded, scene.regions.length, calls.ended.map((e) => e.castId)], [6, true, 0, ["d1"]]);
  reset();
  const mad = binder("Mad");
  nextClick = [{ x: 150, y: 40 }];
  await A.onSpellSettledB8a(castCtx(mad, "Symbol of Insanity", { saveDC: 25 }));
  const ireg = symbolOf();
  const g1 = makeActor("Guard"); const g1t = makeToken(g1, { x: 300, y: 0 });
  const g2 = makeActor("Captain"); const g2t = makeToken(g2, { x: 0, y: 300 });
  degreeFor.set("Guard", ["failure", -7]); degreeFor.set("Captain", "success");
  await A.flashSymbol(mad, ireg.uuid, { reached: [g1t, g2t] });
  equal("E22 Insanity (m134): Will at the symbol's DC; a failure is core Insanity (H18) from the margin; a success unaffected", [calls.checks.map((c) => `${c.actor}:${c.subject}:${c.dc}`), calls.tables], [["Guard:will:25", "Captain:will:25"], [{ target: "Guard", row: "insanity", margin: -7, dc: 25 }]]);
}

/* --- the utilities --- */
{
  reset();
  const mage = binder("Util", { hpMax: 31, str: 3 });
  // Arcane Pouch: a new casting ends the last
  const pouch = S["Arcane Pouch"];
  mage.effects.push(makeEffect({ name: "Arcane Pouch", origin: pouch.uuid ?? "pouch-uuid", flags: {} }, mage), makeEffect({ name: "Arcane Pouch", origin: pouch.uuid ?? "pouch-uuid", flags: {} }, mage));
  await A.onSpellSettledB8a(castCtx(mage, "Arcane Pouch", { spell: { ...pouch, uuid: pouch.uuid ?? "pouch-uuid" } }));
  equal("E23 Arcane Pouch: a new casting ends the last pouch's bonus", mage.effects.filter((e) => e.name === "Arcane Pouch").length, 1);
  // Archway of Ants
  nextClick = [{ x: 150, y: 50 }, { x: 900, y: 50 }, { x: 250, y: 50 }, { x: 250, y: 50 }, null];
  await A.onSpellSettledB8a(castCtx(mage, "Archway of Ants", { warpMods: { bonusValue: 1 } }));
  const arch = scene.regions.find((r) => r.flags?.[MOD]?.[R.AREA8A_FLAG]?.key === "archwayOfAnts");
  equal("E24 Archway: the squares clicked within 30 ft (one 40 ft away refused, a repeat skipped), DB 10, the caster's HP, 10 × (50 + Str × 10)", [arch?.shapes?.length, arch?.flags?.[MOD]?.[R.AREA8A_FLAG]?.db, arch?.flags?.[MOD]?.[R.AREA8A_FLAG]?.hp, arch?.flags?.[MOD]?.[R.AREA8A_FLAG]?.load, arch?.flags?.[MOD]?.[R.AREA8A_FLAG]?.until], [2, 10, 31, 800, 1600]);
  await A.onCardButton("crumbleArchway", mage.uuid, arch.uuid);
  equal("E24 the GM's button crumbles it", scene.regions.some((r) => r === arch), false);
  // Argent Mark
  const friend = makeActor("Friend", { owner: false }); const frT = makeToken(friend, { x: 100, y: 0 });
  answers.push(frT.document.uuid);
  const m1 = await A.onSpellSettledB8a(castCtx(mage, "Argent Mark"));
  const mfx = friend.effects.find((e) => e.flags?.[MOD]?.source === "argentMark");
  equal("E25 Argent Mark on a creature within reach: the mark (1 week, relayed), recorded on the caster", [m1?.name, Boolean(mfx), mfx?.flags?.[SYS]?.spellEffectEnd, mage.flags[MOD].argentMarks8a?.length], ["Friend", true, 1000 + 604800, 1]);
  frT.document.x = 2000; frT.document._source.x = 2000;
  await A.markWhere(mage, m1.id);
  ok("E25 Where is the mark?: its distance and direction on the scene", cards.at(-1)?.lines?.[0]?.includes("ft, east"));
  mage.flags[SYS].activeSpells = [{ id: "pm", name: "Argent Mark", lock: "unlimited" }];
  answers.push("object");
  const m2 = await A.onSpellSettledB8a(castCtx(mage, "Argent Mark", { warpMods: { durationText: "permanent" } }));
  equal("E25 an object, permanent: no end, its registered cast kept", [m2?.name, m2?.until, m2?.castId], ["an object", null, "pm"]);
  await A.markWhere(mage, m2.id);
  ok("E25 …not on the map: the GM's", /the GM's/.test(cards.at(-1)?.lines?.[0] ?? ""));
  // Blood Biography
  const bid = await A.onSpellSettledB8a(castCtx(mage, "Blood Biography", { saveDC: 19 }));
  const victim = makeActor("Victim"); const vt = makeToken(victim, { x: 400, y: 0 });
  canvas.tokens.controlled = [vt];
  degreeFor.set("Victim", "success");
  await A.onCardButton("bloodSave", mage.uuid, bid);
  equal("E26 Blood Biography: the owner's Will at the cast's DC; a Success blocks it (M35)", [calls.checks.at(-1)?.dc, /blocked/.test(cards.at(-1)?.lines?.[0] ?? "")], [19, true]);
  equal("E26 …the card cannot be answered twice", [await A.onCardButton("bloodDead", mage.uuid, bid), /already answered/.test(warns.at(-1) ?? "")], [false, true]);
  const bid2 = await A.onSpellSettledB8a(castCtx(mage, "Blood Biography"));
  await A.onCardButton("bloodDead", mage.uuid, bid2);
  ok("E26 dead: no save, the four questions for the GM", cards.at(-1)?.lines?.length === 6 && cards.at(-1).lines.some((l) => /When was your blood shed/.test(l)));
}
{
  // Harmonic Rift
  reset();
  const mage = binder("Rifter");
  nextClick = [{ x: 15000, y: 50 }, { x: 550, y: 50 }, { x: 50, y: 750 }];
  await A.onSpellSettledB8a(castCtx(mage, "Harmonic Rift", { saveDC: 23, warpMods: { damageDice: "1d8", durationText: "10 minutes" } }));
  const ends = scene.regions.filter((r) => r.flags?.[MOD]?.[R.AREA8A_FLAG]?.key === "harmonicRift");
  equal("E27 the rift: an opening beyond 500 ft refused; two paired 5-ft openings, 4d8, 10 minutes", [ends.length, ends.map((r) => r.flags[MOD][R.AREA8A_FLAG].pair).every(Boolean), ends[0]?.flags[MOD][R.AREA8A_FLAG]?.dice, ends[0]?.flags[MOD][R.AREA8A_FLAG]?.until], [2, true, "4d8", 1600]);
  const foe = makeActor("Foe"); const ft = makeToken(foe, { x: 300, y: 300, disposition: -1 });
  const pal = makeActor("Pal"); const pt = makeToken(pal, { x: 300, y: 400, disposition: 1 });
  await moveV14(ft.document, { x: 500, y: 0 });
  equal("E28 a foe ending its move in one opening steps out of the other: a teleport (the core's card, asked by the caster's spell), and basic Fortitude against 4d8 sonic at the cast's DC", [ft.document.x, ft.document.y, ft.lastUpdateOptions?.eaRift, calls.arrivals, calls.saves], [0, 700, true, [{ caster: "Rifter", spell: "Harmonic Rift", moved: ["Foe"] }], [{ target: "Foe", save: "fortitude", dc: 23, formula: "4d8", type: "sonic" }]]);
  calls.saves.length = 0;
  await moveV14(pt.document, { x: 500, y: 0 });
  equal("E28 an ally passes with no save", [pt.document.y, calls.saves.length], [700, 0]);
  await moveV14(ft.document, { x: 0, y: 700 }, { eaRift: true });
  equal("E28 the arrival itself is not a passage (no ping-pong)", ft.document.y, 700);
  teleportFails = true;
  ft.document.x = 300; ft.document.y = 300; ft.document._source.x = 300; ft.document._source.y = 300;
  await moveV14(ft.document, { x: 0, y: 700 });
  equal("E28 a second teleport this turn fails: it stays", [ft.document.x, ft.document.y], [0, 700]);
  teleportFails = false;
  game.time.worldTime = 1700;
  await A.expireAreas8a(scene);
  equal("E29 its time run, the acting GM removes the openings", scene.regions.length, 0);
}
{
  // Riserune
  reset();
  const mage = binder("Watcher");
  nextClick = [{ x: 150, y: 50 }];
  await A.onSpellSettledB8a(castCtx(mage, "Riserune"));
  const rune = scene.regions.find((r) => r.flags?.[MOD]?.[R.AREA8A_FLAG]?.key === "riserune");
  equal("E30 Riserune: a hidden 10-ft Region where it is inscribed, for the hour", [rune?.visibility, rune?.flags?.[MOD]?.[R.AREA8A_FLAG]?.until, rune?.shapes?.[0]?.type], [1, 1000 + 3600, "ellipse"]);
  const mouse = makeActor("Mouse", { size: "tiny" }); const mt = makeToken(mouse, { x: 2000, y: 0 });
  await moveV14(mt.document, { x: 200, y: 0 });
  const rec = () => rune.flags[MOD][R.AREA8A_FLAG].records;
  equal("E30 a Tiny creature does not trigger it", rec().length, 0);
  const names = ["Thief1", "Thief2", "Thief3", "Thief4"];
  // V14: each starts far off and ENDS its move within 10 ft; one starts within 10 ft and ends far away (not recorded: its end is what counts).
  const leaver = makeActor("Leaver"); const lt = makeToken(leaver, { x: 200, y: 0 });
  await moveV14(lt.document, { x: 2000, y: 0 });
  for (const n of names) { const a = makeActor(n); const t = makeToken(a, { x: 2000, y: 0 }); await moveV14(t.document, { x: 200, y: 0 }); }
  const far = makeActor("Far"); const farT = makeToken(far, { x: 2000, y: 0 });
  equal("E30 Small or larger ENDING a move within 10 ft: recorded, up to 3; one that started within 10 ft and ended far away is not (V14: its end is in `change`)", rec().map((r) => r.name), ["Thief1", "Thief2", "Thief3"]);
  game.users.activeGM = { id: "x" };
  const before = rec().length;
  game.users.activeGM = game.user;
  await A.replayRune(mage, rune.uuid);
  ok("E30 Replay the rune: within reach, the echoes shown to the caster alone", /Thief1/.test(messages.at(-1)?.content ?? "") && Array.isArray(messages.at(-1)?.whisper));
  mage.token.document.x = 3000; mage.token.document._source.x = 3000;
  await A.replayRune(mage, rune.uuid);
  ok("E30 …out of reach, refused", /touch the rune/.test(warns.at(-1) ?? "") && before === 3);
  void farT;
}
{
  // Ley Line Effects 25–27 through Block 2's real row applier
  reset();
  const caster = binder("LeyMage", { cap: 10 });
  const imp1 = makeActor("Imp", { level: 1 }); makeToken(imp1, { x: 100, y: 0 });
  await CRW.recordControlled(caster, { target: imp1, level: 1, source: "bound" });
  await CRW.recordControlled(caster, { level: 2, name: "A level only", source: "conjured" });
  const dom = makeActor("Thrall"); await CRW.recordControlled(caster, { target: dom, level: 1, source: "dominated" });
  const row = T7.LEY_LINE_EFFECTS.find((r) => r.min === 25);
  const lines = await B2.applyRow(caster, row.e, { level: 3, text: row.effect, title: "Ley line", source: "leyLineEffect", expiry: null });
  equal("E31 row 25 (effect): +1 AB on the caster's bound creature, not on the dominated one; the level-only entry said", [imp1.effects.length, dom.effects.length, lines.some((l) => /recorded without a token/.test(l))], [1, 0, true]);
  await B2.applyRow(caster, row.b, { level: 3, text: row.backlash, title: "Ley line", source: "leyLineEffect", expiry: null });
  equal("E31 row 25 (backlash): Summons are Stunned 1", calls.conditions.filter((c) => c.target === "Imp").map((c) => c.tags.map((t) => `${t.key}${t.value}`).join()), ["stunned1"]);
  const lonely = binder("Lonely");
  equal("E31 with none held: said, nothing applied", (await B2.applyRow(lonely, row.e, { level: 3, text: row.effect, title: "Ley line", source: "x" }))[0].includes("No summoned creature"), true);
}

/* ----------------------------------------------------------------- */
/* G — the review's findings (5, 11, 12)                               */
/* ----------------------------------------------------------------- */
function makeScene(id) {
  const sc = { id, name: `Scene ${id}`, regions: [], tokens: [] };
  sc.createEmbeddedDocuments = async (type, docs) => docs.map((d) => {
    const r = { ...JSON.parse(JSON.stringify(d)), id: `r${++nextId}`, parent: sc };
    r.uuid = `Scene.${id}.Region.${r.id}`;
    r.update = async (u) => { for (const [k, v] of Object.entries(u)) setFlagPath(r, k, v); };
    r.delete = async () => { sc.regions = sc.regions.filter((x) => x !== r); uuidMap.delete(r.uuid); };
    sc.regions.push(r); uuidMap.set(r.uuid, r); return r;
  });
  sc.deleteEmbeddedDocuments = async (type, ids) => { sc.regions = sc.regions.filter((r) => !ids.includes(r.id)); };
  return sc;
}
{
  // G1–G4: a dismissed Symbol of Death (finding 5)
  reset();
  const necro = binder("Necro2");
  necro.flags[SYS].activeSpells = [{ id: "d9", name: "Symbol of Death", lock: "unlimited" }];
  nextClick = [{ x: 150, y: 40 }];
  await A.onSpellSettledB8a(castCtx(necro, "Symbol of Death"));
  const dreg = symbolOf();
  necro.flags[SYS].activeSpells = [];
  const k = makeActor("Knight2"); const kt = makeToken(k, { x: 300, y: 0 }); degreeFor.set("Knight2", "fumble");
  const out = await A.flashSymbol(necro, dreg.uuid, { reached: [kt] });
  equal("G1 dismissed (its cast gone from the caster's active spells): the flash is refused, rolls nothing, and the Region goes", [out?.refused, calls.checks.length, scene.regions.includes(dreg), /has ended/.test(cards.at(-1)?.lines?.[0] ?? "")], ["ended", 0, false, true]);
  // the sweep on updateActor, on every scene
  reset();
  const other = makeScene("s2");
  game.scenes = [scene, other];
  const n2 = binder("Necro3");
  n2.flags[SYS].activeSpells = [{ id: "d10", name: "Symbol of Death", lock: "unlimited" }];
  nextClick = [{ x: 150, y: 40 }];
  await A.onSpellSettledB8a(castCtx(n2, "Symbol of Death"));
  const [far] = await other.createEmbeddedDocuments("Region", [{ name: "far symbol", flags: { [MOD]: { [R.SYMBOL_FLAG]: { key: "symbolOfDeath", spellName: "Symbol of Death", casterUuid: n2.uuid, castId: "d10", x: 0, y: 0 } } } }]);
  const [pain] = await other.createEmbeddedDocuments("Region", [{ name: "pain", flags: { [MOD]: { [R.SYMBOL_FLAG]: { key: "symbolOfPain", spellName: "Symbol of Pain", casterUuid: n2.uuid, castId: "", x: 0, y: 0 } } } }]);
  equal("G2 an unrelated change to the caster removes nothing", [await A.onActorUpdatedB8a(n2, { name: "x" }), scene.regions.length + other.regions.length], [0, 3]);
  n2.flags[SYS].activeSpells = [];
  game.users.activeGM = { id: "other" };
  const notActing = await A.onActorUpdatedB8a(n2, { flags: { [SYS]: { activeSpells: [] } } });
  game.users.activeGM = game.user;
  const swept = await A.onActorUpdatedB8a(n2, { flags: { [SYS]: { activeSpells: [] } } });
  equal("G3 its cast ended, the acting GM removes its symbol on every scene; another GM's client does nothing; a \"varies\" symbol (no cast to dismiss) stays", [notActing, swept, symbolOf() ?? null, other.regions.includes(far), other.regions.includes(pain)], [0, 2, null, false, true]);
  delete game.scenes;
}
{
  // G4–G7: an unviewed scene and a token with no placeable (finding 11)
  reset();
  const other = makeScene("s3");
  game.scenes = [scene, other];
  // the rift's passage, on a scene this client is not viewing (no placeable)
  const [a] = await other.createEmbeddedDocuments("Region", [{ name: "o1", shapes: [{ type: "rectangle", x: 500, y: 0, width: 100, height: 100 }], flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "harmonicRift", casterUuid: "Actor.nobody", spellName: "Harmonic Rift", dc: 20, dice: "3d8", until: 99999, end: 0 } } } }]);
  const [b] = await other.createEmbeddedDocuments("Region", [{ name: "o2", shapes: [{ type: "rectangle", x: 0, y: 700, width: 100, height: 100 }], flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "harmonicRift", casterUuid: "Actor.nobody", spellName: "Harmonic Rift", dc: 20, dice: "3d8", until: 99999, end: 1, pair: a.id } } } }]);
  a.flags[MOD][R.AREA8A_FLAG].pair = b.id;
  const walker = makeActor("Walker");
  const doc = { actor: walker, x: 300, y: 300, width: 1, height: 1, disposition: 1, parent: other, uuid: "Scene.s3.Token.w", object: null, _source: { x: 300, y: 300 } };
  doc.update = async (u, o) => { Object.assign(doc, u); doc._source = { ...(doc._source ?? {}), ...u }; doc.lastOptions = o; return doc; };
  const moved = await moveV14(doc, { x: 500, y: 0 });
  equal("G4 a rift's passage reads the token's document: no placeable on this client's canvas, and it still steps through", [moved?.moved, doc.x, doc.y, doc.lastOptions?.eaRift], [true, 0, 700, true]);
  // the curse's hour, by the document
  const ogre = makeActor("Ogre2");
  const [sym] = await other.createEmbeddedDocuments("Region", [{ name: "pain2", flags: { [MOD]: { [R.SYMBOL_FLAG]: { key: "symbolOfPain", x: 50, y: 50 } } } }]);
  ogre.effects.push(makeEffect({ name: "curse", flags: { [SYS]: { heldConditions: { keys: ["injured"], values: { injured: 2 }, endWith: true } }, [MOD]: { source: R.SYMBOL_HOLD_FLAG, [R.SYMBOL_HOLD_FLAG]: { regionUuid: sym.uuid, x: 50, y: 50, key: "symbolOfPain", held: 2 } } } }, ogre));
  const odoc = { actor: ogre, x: 100, y: 0, width: 1, height: 1, parent: other, object: null };
  await moveV14(odoc, { x: 1500, y: 0 });
  equal("G5 the curse's hour starts from the move's end (no placeable): farther than 60 ft", ogre.effects.at(-1).flags[SYS].spellEffectEnd, 1000 + 3600);
  // G5c V14: the old square far, the end within 60 ft: the hour stops (and starts only on an end beyond 60 ft)
  const ogre3 = makeActor("Ogre3");
  ogre3.effects.push(makeEffect({ name: "curse", flags: { [SYS]: { heldConditions: { keys: ["injured"], values: { injured: 2 }, endWith: true } }, [MOD]: { source: R.SYMBOL_HOLD_FLAG, [R.SYMBOL_HOLD_FLAG]: { regionUuid: sym.uuid, x: 50, y: 50, key: "symbolOfPain", held: 2 } } } }, ogre3));
  const near = { actor: ogre3, x: 1500, y: 0, width: 1, height: 1, parent: other, object: null };
  await moveV14(near, { x: 100, y: 0 });
  const afterNear = ogre3.effects.at(-1).flags[SYS].spellEffectEnd ?? null;
  near.x = 100; await moveV14(near, { x: 1500, y: 0 });
  equal("G5c the hour reads the move's END: from far to within 60 ft, no hour; from within to beyond 60 ft, it starts", [afterNear, ogre3.effects.at(-1).flags[SYS].spellEffectEnd], [null, 1000 + 3600]);
  equal("G5b …the distance from the document, on its scene's grid, to its nearest edge (65 ft, 30 ft; a Large token's centre is 67.5 ft away, its edge 65)", [A.feetFromPointDoc({ x: 50, y: 50 }, { x: 1300, y: 0, width: 1, height: 1, parent: other }), A.feetFromPointDoc({ x: 50, y: 50 }, { x: 600, y: 0, width: 1, height: 1, parent: other }), A.feetFromPointDoc({ x: 50, y: 50 }, { x: 1300, y: 0, width: 2, height: 2, parent: other })], [65, 30, 65]);
  // expiry and the glow, on every scene
  const [old] = await other.createEmbeddedDocuments("Region", [{ name: "old", flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "archwayOfAnts", until: 1 } } } }]);
  await A.expireAreas8a();
  equal("G6 the areas' expiry sweeps every scene, not only the one on the canvas", [other.regions.includes(old), other.regions.includes(a)], [false, true]);
  const [glow] = await other.createEmbeddedDocuments("Region", [{ name: "glow", visibility: 2, flags: { [MOD]: { [R.SYMBOL_FLAG]: { key: "symbolOfPain", x: 0, y: 0, glowing: true, lastSeen: 0 } } } }]);
  other.tokens = [{ id: "someone" }];
  game.time.worldTime = 5000;
  await A.refreshSymbolGlow();
  const kept = glow.flags[MOD][R.SYMBOL_FLAG].glowing;
  other.tokens = [];
  await A.refreshSymbolGlow();
  equal("G7 the glow is swept on every scene: an unviewed scene with a token on it is left as it is (its sight cannot be read); with none, 10 minutes unseen ends it", [kept, glow.flags[MOD][R.SYMBOL_FLAG].glowing, glow.visibility], [true, false, 1]);
  delete game.scenes;
}
{
  // G8–G9: two GMs, one binding (finding 12)
  reset();
  const mage = binder("Twin");
  mage.flags[SYS].activeSpells = [{ id: "c77", name: "Animal Binding", lock: "unlimited" }];
  const rec = await A.onSpellSettledB8a(castCtx(mage, "Animal Binding"));
  const wolf = makeActor("Wolf", { level: 1, type: "Animal" }); const wt = makeToken(wolf, { x: 100, y: 0 });
  degreeFor.set("Wolf", "failure");
  game.users.activeGM = { id: "other-gm" };
  const refused = await A.bindCreature(mage, rec.id, { token: wt });
  game.users.activeGM = game.user;
  equal("G8 a GM who is not the acting GM binds nothing (with two GMs, one presses for both)", [refused, calls.checks.length, /acting GM/.test(warns.at(-1) ?? "")], [false, 0, true]);
  // A WRITE IS A ROUND TRIP in Foundry: the record's own "binding" lands only after the server answers.
  const mk = markerOf(mage); const writeNow = mk.setFlag.bind(mk);
  const claims = [];
  mk.setFlag = async (...args) => { if (args[2]?.state === "binding") claims.push(args[2].claim); await new Promise((r) => setTimeout(r, 5)); return writeNow(...args); };
  const [one, two] = await Promise.all([A.bindCreature(mage, rec.id, { token: wt }), A.bindCreature(mage, rec.id, { token: wt })]);
  const entries = (mage.flags[SYS].controlled ?? mage.flags[SYS].controlRegister ?? []);
  equal("G9b the claim on the record names the GM who pressed, and when (so a stale one can be taken over)", [claims.length, claims[0]?.user, typeof claims[0]?.at === "number" && claims[0].at > 0], [1, game.user.id, true]);
  equal("G9 two presses at once: the record is claimed before the save, so one save, one binding", [calls.checks.length, one?.state ?? two?.state, [one, two].filter((x) => x?.state === "bound").length, mage.effects.filter((e) => e.flags?.[MOD]?.source === R.BINDING_FLAG).length], [1, "bound", 1, 1]);
}

{
  // G10: the rift's destination on the scene's own grid (re-review D)
  reset();
  const big = makeScene("s4"); big.grid = { size: 200, distance: 5 };
  const [a] = await big.createEmbeddedDocuments("Region", [{ name: "o1", shapes: [{ type: "rectangle", x: 1000, y: 0, width: 200, height: 200 }], flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "harmonicRift", casterUuid: "Actor.nobody", spellName: "Harmonic Rift", dc: 20, dice: "3d8", until: 99999, end: 0 } } } }]);
  const [b] = await big.createEmbeddedDocuments("Region", [{ name: "o2", shapes: [{ type: "rectangle", x: 0, y: 1400, width: 200, height: 200 }], flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "harmonicRift", casterUuid: "Actor.nobody", spellName: "Harmonic Rift", dc: 20, dice: "3d8", until: 99999, end: 1, pair: a.id } } } }]);
  a.flags[MOD][R.AREA8A_FLAG].pair = b.id;
  const w = makeActor("Walker2");
  const doc = { actor: w, x: 600, y: 600, width: 1, height: 1, disposition: 1, parent: big, uuid: "Scene.s4.Token.w", object: null };
  doc.update = async (u) => { Object.assign(doc, u); doc._source = { ...(doc._source ?? {}), ...u }; return doc; };
  await moveV14(doc, { x: 1000, y: 0 });
  equal("G10 a rift on a scene with 200-px squares (not the canvas's 100) puts the token square in the far opening", [doc.x, doc.y], [0, 1400]);
}
{
  // G11–G13: a stale claim (re-review E)
  reset();
  const mage = binder("Claimer");
  mage.flags[SYS].activeSpells = [{ id: "c88", name: "Animal Binding", lock: "unlimited" }];
  const rec = await A.onSpellSettledB8a(castCtx(mage, "Animal Binding"));
  const fox = makeActor("Fox", { level: 1, type: "Animal" }); const ft = makeToken(fox, { x: 100, y: 0 });
  degreeFor.set("Fox", "failure");
  const mk = markerOf(mage);
  const users = game.users; const get = users.get;
  users.get = (id) => (id === game.user.id ? { id, active: true } : undefined);
  await mk.setFlag(MOD, R.BINDING_FLAG, { ...rec, state: "binding", claim: { user: game.user.id, at: Date.now() } });
  const fresh = await A.bindCreature(mage, rec.id, { token: ft });
  equal("G11 a fresh claim by a connected GM stands: nothing is rolled", [fresh, calls.checks.length], [false, 0]);
  await mk.setFlag(MOD, R.BINDING_FLAG, { ...rec, state: "binding", claim: { user: "dropped-gm", at: Date.now() } });
  game.users.activeGM = { id: "other" };
  const notActing = await A.bindCreature(mage, rec.id, { token: ft });
  game.users.activeGM = game.user;
  const took = await A.bindCreature(mage, rec.id, { token: ft });
  equal("G12 a claim whose GM has dropped: only the acting GM takes it over, binds once, and says so; the record keeps no claim", [notActing, took?.state, calls.checks.length, cards.some((c) => c.lines.some((l) => /never finished/.test(l))), "claim" in (recordOfMarker(mage) ?? {})], [false, "bound", 1, true, false]);
  equal("G13 the rule: no claim, a disconnected claimer, or older than two minutes is stale; a fresh one by a connected user is not", [R.claimIsStale(null), R.claimIsStale({ user: "u", at: 0 }, { now: 1, isActive: () => false }), R.claimIsStale({ user: "u", at: 0 }, { now: R.BINDING_CLAIM_STALE_MS + 1, isActive: () => true }), R.claimIsStale({ user: "u", at: 0 }, { now: R.BINDING_CLAIM_STALE_MS, isActive: () => true }), R.BINDING_CLAIM_STALE_MS], [true, true, true, false, 120000]);
  users.get = get;
}

{
  // G14–G16: the live test of 0.11.0 (Graham's world, 9 November): a token
  // walking OUT of an opening was sent through, and the save line was escaped.
  reset();
  const sc = makeScene("s5");
  const caster = makeActor("RiftMage");
  sc.tokens = [{ actor: caster, actorId: caster.id, disposition: 1 }];
  const [a] = await sc.createEmbeddedDocuments("Region", [{ name: "o1", shapes: [{ type: "rectangle", x: 0, y: 0, width: 100, height: 100 }], flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "harmonicRift", casterUuid: caster.uuid, spellName: "Harmonic Rift", dc: 22, dice: "3d8", until: 99999, end: 0 } } } }]);
  const [b] = await sc.createEmbeddedDocuments("Region", [{ name: "o2", shapes: [{ type: "rectangle", x: 1000, y: 0, width: 100, height: 100 }], flags: { [MOD]: { [R.AREA8A_FLAG]: { key: "harmonicRift", casterUuid: caster.uuid, spellName: "Harmonic Rift", dc: 22, dice: "3d8", until: 99999, end: 1, pair: a.id } } } }]);
  a.flags[MOD][R.AREA8A_FLAG].pair = b.id;
  uuidMap.set(caster.uuid, caster);
  const foe = makeActor("RiftFoe");
  // V14, as logged live: it stands in opening 1 (doc still says so, doc.regions too) and moves to (300, 800) — the new position only in `change`
  const out = { actor: foe, x: 0, y: 0, width: 1, height: 1, disposition: -1, parent: sc, uuid: "Scene.s5.Token.f", object: null, regions: new Set([a]) };
  out.update = async (u) => { Object.assign(out, u); out._source = { ...(out._source ?? {}), ...u }; return out; };
  const left = await moveV14(out, { x: 300, y: 800 });
  equal("G14 a token walking OUT of an opening (doc.regions still holding it, as V14's updateToken does) is not sent through: not moved, no card, no save", [left ?? null, out.x, out.y, cards.length, calls.saves.length], [null, 300, 800, 0, 0]);
  teleportFails = true;
  out.x = 0; out.y = 0;
  await moveV14(out, { x: 300, y: 800 });
  equal("G14b …and with a teleport already made this turn, no \"second teleport fails\" card either", cards.length, 0);
  teleportFails = false;
  // it walks INTO opening 2 from outside (doc still at the old square, outside; doc.regions empty)
  const into = { actor: foe, x: 600, y: 400, width: 1, height: 1, disposition: -1, parent: sc, uuid: "Scene.s5.Token.f2", object: null, regions: new Set() };
  into.update = async (u) => { Object.assign(into, u); into._source = { ...(into._source ?? {}), ...u }; return into; };
  const moved = await moveV14(into, { x: 1000, y: 0 });
  equal("G15 a token that ends its move in an opening still passes, from its new position alone", [moved?.moved, into.x, into.y], [true, 0, 0]);
  // G17 A MOVE PAUSED PARTWAY (V14 splits it into several updates): an update with waypoints still to go does not pass.
  const mid = { id: "tMid", actor: foe, x: 600, y: 400, width: 1, height: 1, disposition: -1, parent: sc, uuid: "Scene.s5.Token.m", object: null };
  mid.update = async (u) => { Object.assign(mid, u); mid._source = { ...(mid._source ?? {}), ...u }; return mid; };
  const paused = await moveV14(mid, { x: 1000, y: 0 }, { _movement: { tMid: { pending: { waypoints: [{ x: 1400, y: 0 }] } } } });
  equal("G17 an update ending inside an opening with waypoints still pending (V14's `_movement`) does not pass (it stops there)", [paused ?? null, mid.x, mid.y], [null, 1000, 0]);
  mid.x = 600; mid.y = 400;
  const done = await moveV14(mid, { x: 1000, y: 0 }, { _movement: { tMid: { pending: { waypoints: [] } } } });
  equal("G17b …the final update (no pending waypoints) passes; no movement record at all passes too", [done?.moved, mid.x, mid.y], [true, 0, 0]);
  const said = cards.at(-1)?.lines?.join(" ") ?? "";
  // G18c AN UPDATE THAT RESOLVES WITH THE DOCUMENT BUT DID NOT MOVE IT (review): occupied too.
  calls.saves.length = 0; calls.arrivals.length = 0;
  const stuck = { id: "tS", actor: foe, x: 600, y: 400, width: 1, height: 1, disposition: -1, parent: sc, uuid: "Scene.s5.Token.s", object: null, _source: { x: 600, y: 400 } };
  stuck.update = async () => stuck;
  const notLanded = await moveV14(stuck, { x: 1000, y: 0 });
  equal("G18c an update resolving with the document while its source stays put is not a passage: \"occupied\", no save, no Spatial Awareness card", [notLanded?.moved, notLanded?.occupied, /far opening is occupied/.test(cards.at(-1)?.lines?.join(" ") ?? ""), calls.saves.length, calls.arrivals.length], [false, true, true, 0, 0]);
  // G18 THE FAR OPENING OCCUPIED (found live): the core refuses the move, the update returns nothing.
  calls.saves.length = 0; calls.arrivals.length = 0;
  const blockedFoe = { id: "tB", actor: foe, x: 600, y: 400, width: 1, height: 1, disposition: -1, parent: sc, uuid: "Scene.s5.Token.b", object: null };
  blockedFoe.update = async () => undefined;
  const refused = await moveV14(blockedFoe, { x: 1000, y: 0 });
  const refusedCard = cards.at(-1)?.lines?.join(" ") ?? "";
  equal("G18 the far opening occupied (the core refuses the move): the card says so, and no save is rolled and no Spatial Awareness card posted", [refused?.moved, refused?.occupied, /far opening is occupied/.test(refusedCard), /steps through/.test(refusedCard), calls.saves.length, calls.arrivals.length], [false, true, true, false, 0, 0]);
  equal("G16 the sonic save's line is the core's HTML, not escaped (found live: \"&lt;strong&gt;Failure\")", [/<strong>Failure<\/strong>: 9 sonic/.test(said), /&lt;strong&gt;/.test(said)], [true, false]);
  // G19 THE GLOW reads the mover at its END: a wall blocks its old square, not its new one.
  {
    const sym = scene.regions;
    const viewer = makeActor("Viewer"); const vt = makeToken(viewer, { x: 600, y: 600 });
    blocked.add(`${vt.center.x},${vt.center.y}`);
    const reg = { parent: canvas.scene, flags: {} };
    const before = A.tokensInSight(reg, { x: 0, y: 0 }).includes(vt);
    const after = A.tokensInSight(reg, { x: 0, y: 0 }, { doc: vt.document, at: A.endPositionOf(vt.document, { x: 100, y: 100 }) }).includes(vt);
    blocked.clear();
    equal("G19 line of sight for the glow reads the moving token's end position (V14: the placeable is still at the old square)", [before, after], [false, true]);
    equal("G19b the end position: x and y (and size) from `change`, else the document's", [A.endPositionOf({ x: 1, y: 2, width: 1, height: 1 }, { x: 5 }), A.endPositionOf({ x: 1, y: 2, width: 1, height: 1 }, {})].map((p) => [p.x, p.y, p.width]), [[5, 2, 1], [1, 2, 1]]);
  }
  ok("G16b no esc() is wrapped round a core-built line in Block 8a (the save's, a marker's, a check's)", !/esc\(\s*(hit|out|said|marked|result)\?*\.line/.test(read("module", "block8a-automations.mjs")) && !/doc\.regions\?\.has/.test(read("module", "block8a-automations.mjs")));
}

{
  // G20 THE MODULE'S OLDER updateToken HANDLERS read the move's end through the stored `_source`
  // (0.11.2, review): both token-centre helpers read it first, as V14 holds the end there in the hook.
  const TM = await import(new URL("../module/token-moves.mjs", import.meta.url));
  const AR = await import(new URL("../module/areas.mjs", import.meta.url));
  const sc = makeScene("s6");
  sc.regions.push({ id: "ley", name: "Ley", parent: sc, shapes: [{ type: "rectangle", x: 1000, y: 0, width: 100, height: 100 }], behaviors: [{ type: AR.AREA_TYPES.suppression, system: { level: 2 } }] });
  const walker = makeActor("Walker3");
  // V14 as logged: the getters at the old square (0, 0), the source at the end (1000, 0)
  const tk = { actor: walker, document: { id: "w3", actor: walker, x: 0, y: 0, width: 1, height: 1, parent: sc, _source: { x: 0, y: 0, width: 1, height: 1 }, toObject() { return { x: this.x, y: this.y, width: 1, height: 1 }; } } };
  const before = (await AR.areasAt(tk)).length;
  tk.document._source = { x: 1000, y: 0, width: 1, height: 1 };
  const after = (await AR.areasAt(tk)).length;
  equal("G20 an area check (areas.mjs: Ley Tap's distance, the antimagic sweep) reads the stored `_source` (the move's end), not the document's old getters", [before, after], [0, 1]);
  equal("G20b the end position: `change` first, then `_source`, then the document", [TM.endPositionOf({ x: 1, y: 2, _source: { x: 7, y: 8 } }, { x: 5 }), TM.endPositionOf({ x: 1, y: 2, _source: { x: 7, y: 8 } }, {}), TM.endPositionOf({ x: 1, y: 2 }, {})].map((p) => [p.x, p.y]), [[5, 8], [7, 8], [1, 2]]);
  const B1 = await import(new URL("../module/block1-automations.mjs", import.meta.url));
  const t5 = { actor: walker, center: { x: 50, y: 550 }, document: { id: "w5", x: 0, y: 500, width: 1, height: 1, _source: { x: 900, y: 0, width: 1, height: 1 } } };
  equal("G20c block1's tokenCentre (every feetBetween: the familiar's range, Shard Cloud, Chronoweave) reads `_source` before the document's getters and the drawn centre", B1.tokenCentre(t5), { x: 950, y: 50 });
  const t6 = { actor: walker, center: { x: 50, y: 50 }, document: { x: 300, y: 0, width: 1, height: 1 } };
  equal("G20d …with no source, the document, then the drawn centre", [B1.tokenCentre(t6), B1.tokenCentre({ center: { x: 7, y: 9 }, document: {} })], [{ x: 350, y: 50 }, { x: 7, y: 9 }]);
  ok("G20e no registry of move ends: no updateToken hook records them, no helper reads one", !/noteMoveEnd|knownEndOf/.test(read("scripts", "eldritch-arts.mjs") + read("module", "block1-automations.mjs") + read("module", "areas.mjs") + read("module", "token-moves.mjs")));
}

/* ----------------------------------------------------------------- */
/* F — the wiring                                                      */
/* ----------------------------------------------------------------- */
{
  const script = read("scripts", "eldritch-arts.mjs");
  for (const [hook, fn] of [["trgPrimeSpellSettled", "onSpellSettledB8a"], ["deleteActiveEffect", "onEffectDeletedB8a"], ["trgPrimeControlReleased", "onControlReleasedB8a"], ["updateToken", "onTokenMovedB8a"], ["updateWorldTime", "onWorldTimeB8a"], ["updateActor", "onActorUpdatedB8a"]]) {
    ok(`F ${fn} is wired on ${hook}`, new RegExp(`Hooks\\.on\\("${hook}", \\([^)]*\\) => \\{ ${fn}\\(`).test(script));
  }
  ok("F the card buttons are registered at ready", /Hooks\.once\("ready", \(\) => registerBlock8aCards\(\)\);/.test(script));
  const manifest = JSON.parse(read("module.json"));
  equal("F the manifest: 0.15.0 on TRG Prime 3.690.0; the entry script asks for 3.690.0", [manifest.version, manifest.relationships.systems[0].compatibility.minimum, /REQUIRED_SYSTEM = "3\.694\.0"/.test(script), manifest.download.includes("v0.18.3")], ["0.18.3", "3.694.0", true, true]); // RE-PINNED 0.12.0
  const packs = await import(new URL("./content/packs.mjs", import.meta.url));
  const spells = packs.PACKS.find((p) => p.name === "ea-spells").docs;
  equal("F the spells pack holds the 22 (130 in all, Block 8b's 17 with them)", [C.SPELLS_B8A.every((s) => spells.includes(s)), spells.length], [true, 130]); // RE-PINNED 0.12.0
  const dir = path.join(ROOT, "packs-source", "ea-spells");
  const built = fs.readdirSync(dir).map((f) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8")));
  if (process.env.EA_MUTATING !== "1") equal("F packs-source is the build (run build-packs)", [...C.SPELLS_B8A, S["Symbol of Death"], S["Symbol of Fear"]].every((s) => JSON.stringify(built.find((b) => b._id === s._id)?.system ?? null) === JSON.stringify(s.system) && JSON.stringify(built.find((b) => b._id === s._id)?.flags ?? null) === JSON.stringify(s.flags)), true);
  ok("F Versatile Binder hands a Binding to the model (no save of its own)", /if \(isBinding\(String\(ctx\.spell\?\.flags\?\.\[SYSTEM_ID\]\?\.eaGrimoire \?\? ""\)\)\) \{\n\s+setBinderChoice\(ctx\.actor, ctx\.eaBound\);/.test(read("module", "block6d-automations.mjs")));
  ok("F Block 2b's Fumble-circle card is not posted for a Binding (its own card says it)", /const binding = \/Binding\$\/\.test\(String\(ctx\.spell\?\.flags\?\.\[SYSTEM_ID\]\?\.eaGrimoire \?\? ""\)\);\n\s+if \(ctx\.cast && !ctx\.refunded && !binding/.test(read("module", "block2b-automations.mjs")));
  ok("F Block 7's GM relay deletes a bound effect (one of this module's own)", B7.OWN_SOURCES.includes("bound8a"));
  ok("F Ley Line Effects 25–27 are generated, not hand-written", /25: \('\{ kind: "summons", row:/.test(read("tools", "content", "gen-tables.py")));
  ok("F the Bindings' settle reads the core's registry entry (activeEntryFor)", /const entry = activeEntryFor\(actor, ctx\.spell\?\.name\);/.test(read("module", "block8a-automations.mjs")));
  const core = readCore("module", "module-api-workflow.mjs");
  ok("F the core this needs: the control register, the held conditions and the turn table on the module API (TRG Prime 3.686.0)", ["recordControlled", "releaseControlled", "controlledOf", "controlledCreature", "markTurnTable"].every((k) => new RegExp(`\\b${k}: async`).test(core)));
}

if (failures.length) {
  console.log(`verify-block8a: ${checks} checks, ${failures.length} failure(s).`);
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exitCode = 1;
} else console.log(`verify-block8a: ${checks} checks, 0 failure(s).`);
