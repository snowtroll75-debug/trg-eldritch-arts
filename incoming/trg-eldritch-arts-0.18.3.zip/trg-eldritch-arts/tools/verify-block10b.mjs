#!/usr/bin/env node
/**
 * verify-block10b — Eldritch Arts 0.17.1 (Block 10b, on TRG Prime 3.694.0):
 * the sentient-item roll tables (`ea-tables`) and the rules reference journal
 * (`ea-rules`), against the book (book-text.json and the book's markdown when
 * EA_BOOK_MD is set) and Graham's rulings (Q219: the Senses table rolled as a
 * d8; Q221: the journal, each page quoting the book).
 *
 *   A  the tables, row by row as printed
 *   B  the journal, page by page as printed
 *   C  the packs and the build
 *   D  the version
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let checks = 0;
const failures = [];
const ok = (label, cond, detail = "") => { checks += 1; if (!cond) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); };
const equal = (label, a, e) => ok(label, JSON.stringify(a) === JSON.stringify(e), `expected ${JSON.stringify(e)}, got ${JSON.stringify(a)}`);
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const plain = (html) => String(html).replace(/<\/?(strong|em|sup)>/g, "").replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\s+/g, " ").trim();
const words = (md) => String(md).replace(/<sup>(.*?)<\/sup>/g, "$1").replace(/\*\*|\*/g, "").replace(/^[#\-|\s]+/, "").replace(/\|/g, " ").replace(/\s+/g, " ").trim();

const BOOK = JSON.parse(read("tools", "content", "book-text.json"));
const B = await import(path.join(ROOT, "tools", "content", "block10b.mjs"));
const { PACKS } = await import(path.join(ROOT, "tools", "content", "packs.mjs"));
const manifest = JSON.parse(read("module.json"));

/* ================================================================== A */
const T = BOOK.chapter9.tables;
equal("A ten tables: the nine printed, and the mental arrays", B.ALL_TABLES.map((t) => [t.name, t.formula]), [
  ["Sentient Item: Item Type", "1d10"], ["Sentient Item: Personality", "1d12"], ["Sentient Item: Motivation", "1d12"], ["Sentient Item: Ethics", "1d100"],
  ["Sentient Item: Communication", "1d8"], ["Sentient Item: Senses", "1d8"], ["Sentient Item: Mental Arrays", "1d8"],
  ["Sentient Item: Special Powers", "1d8"], ["Sentient Item: Aligned Trait", "1d8"], ["Sentient Item: Quirks", "1d20"]]);
equal("A Q219: Senses is printed d6 over eight entries, rolled as a d8", [T.first[5].name, T.first[5].die, T.first[5].rows.length, B.ALL_TABLES[5].formula, B.ALL_TABLES[5].flags["trg-eldritch-arts"].printedDie], ["SENSES", "d6", 8, "1d8", "d6"]);
{
  const printed = [...T.first, ...T.second];
  const ours = B.ALL_TABLES.filter((t) => t.name !== "Sentient Item: Mental Arrays");
  equal("A every printed row is a result, word for word", ours.map((t) => t.results.map((r) => r.name)), printed.map((g) => g.rows.map((r) => r.text)));
  equal("A …at its printed range", ours.map((t) => t.results.map((r) => r.range.join("-"))), printed.map((g) => g.rows.map((r) => String(r.range).replace(/–/g, "-").replace(/^(\d+)$/, "$1-$1"))));
  const gaps = B.ALL_TABLES.map((t) => {
    const top = Number(t.formula.replace("1d", ""));
    const faces = [];
    for (let f = 1; f <= top; f += 1) if (t.results.filter((r) => f >= r.range[0] && f <= r.range[1]).length !== 1) faces.push(f);
    return [t.name, faces];
  });
  equal("A every face of every die is exactly one result", gaps, B.ALL_TABLES.map((t) => [t.name, []]));
  equal("A the d20 under the second \"Aligned Trait\" header is the quirks", [T.second[2].name, T.second[2].die, T.second[2].rows[0].text, T.second[2].rows[19].text], ["ALIGNED TRAIT", "d20", "Demands a name be spoken each dawn", "Occasionally swaps memories with wielder in dreams"]);
  equal("A the aligned traits as printed, 6–8 None", T.second[1].rows.map((r) => `${r.range} ${r.text}`), ["1 Balance", "2 Chaos", "3 Evil", "4 Good", "5 Order", "6-8 None"]);
  equal("A the mental arrays: Int, Wis, Cha and the note, as printed", B.ALL_TABLES[6].results.map((r) => r.name), T.arrays.rows.map((r) => `Int +${r.cells[1]}, Wis +${r.cells[2]}, Cha +${r.cells[3]}. ${r.cells[4]}`));
  equal("A …row 4 an even spread", B.ALL_TABLES[6].results[3].name, "Int +4, Wis +4, Cha +4. A rare even spread of intellect, willpower, and charisma.");
  ok("A a result's text is its name only, so a drawn card shows it once (0.17.2, found live)", B.ALL_TABLES.every((t) => t.results.every((r) => r.description === "" && r.name)));
  ok("A every result is a text result, drawn from replacement, weighted by its faces", B.ALL_TABLES.every((t) => t.replacement === true && t.results.every((r) => r.type === "text" && r.weight === r.range[1] - r.range[0] + 1 && r.drawn === false)));
  ok("A …so the weights total the die", B.ALL_TABLES.every((t) => t.results.reduce((n, r) => n + r.weight, 0) === Number(t.formula.replace("1d", ""))));
  ok("A the ethics run 1-7 to 99-100", B.ALL_TABLES[3].results[0].range.join() === "1,7" && B.ALL_TABLES[3].results.at(-1).range.join() === "99,100" && B.ALL_TABLES[3].results.length === 15);
}
if (process.env.EA_BOOK_MD && fs.existsSync(process.env.EA_BOOK_MD)) {
  const md = fs.readFileSync(process.env.EA_BOOK_MD, "utf8");
  ok("A the book prints the Senses header over \"d6\"", /\| \*\*SENSES\*\*\s+\|[^\n]*\n\| \*\*d6\*\*/.test(md));
  ok("A the book prints \"True Seeing\" as its eighth sense", /\| 8\s+\| True Seeing\s+\|/.test(md));
}

/* ================================================================== B */
const J = B.RULES_JOURNAL;
equal("B the journal's pages, in the book's order (Q221), with the table page after Sentient Items", J.pages.map((p) => p.name), ["Chapter 7: Magic", "High Magic", "Ley Lines", "Wild Magic Areas", "Magic Suppression Areas", "Mundane Ritual Casting", "Summoning Circles", "Wondrous Items & Relics", "Sentient Items", "Design a Sentient Item", "New Traits", "Planes of Existence"]);
{
  const missing = [];
  for (const p of BOOK.rulesPages) {
    const page = J.pages.find((x) => x.name === p.title);
    const text = plain(page?.text?.content ?? "");
    for (const l of p.lines) {
      const w = words(l);
      if (!w || /^:?-+:?$/.test(w.replace(/\s/g, "")) || w === "<!-- -->") continue;
      for (const cell of l.trim().startsWith("|") ? l.split("|").map(words).filter(Boolean) : [w]) if (!text.includes(cell)) missing.push(`${p.title}: ${cell.slice(0, 60)}`);
    }
  }
  equal("B every printed line of every page is in its page, word for word", missing, []);
  equal("B the pages start where the book's sections do", BOOK.rulesPages.map((p) => p.lines[0]), ["# CHAPTER 7 - MAGIC", "## HIGH MAGIC", "## LEY LINES", "## WILD MAGIC AREAS", "## MAGIC SUPPRESSION AREAS", "## MUNDANE RITUAL CASTING", "## SUMMONING CIRCLES", "WONDROUS ITEMS", "**SENTIENT ITEMS**", "**NEW TRAITS**", "PLANES OF EXISTENCE"]);
  ok("B the ley line, wild surge and suppression backlash tables are tables", /LEY LINE EFFECTS TABLE/.test(J.pages[2].text.content) && /<table>/.test(J.pages[2].text.content) && /<td>WILD SURGE<\/td>|<th>WILD SURGE<\/th>/.test(J.pages[3].text.content) && /<th>SUPPRESSION BACKLASH TABLE<\/th>/.test(J.pages[4].text.content));
  ok("B the relic rules, the GM's notes, ego and influence, hidden powers and growth are there", ["RULES FOR RELICS", "CREATING RELICS", "RELICS &amp; INVESTMENT", "GM BALANCE NOTES"].every((h) => J.pages[7].text.content.includes(h)) && ["EGO &amp; CONFLICT", "INFLUENCE", "HIDDEN POWERS", "GROWTH &amp; ADVANCEMENT"].every((h) => J.pages[8].text.content.includes(h)));
  ok("B the RELIC and SENTIENT traits; the planes and their languages", /<h3>RELIC<\/h3>/.test(J.pages[10].text.content) && /<h3>SENTIENT<\/h3>/.test(J.pages[10].text.content) && /Asgard: Aesirian/.test(J.pages[11].text.content) && /<td>Maelstrum<\/td>/.test(J.pages[11].text.content));
  ok("B no specific relic, no table grid and no index on any page", J.pages.every((p) => !/<h3>THE AEGIS OF VALTEA<\/h3>|<h3>DAWNSHIELD<\/h3>|<h3>INDEX<\/h3>|archetype feats 40/.test(p.text.content)) && !/True Seeing/.test(J.pages[8].text.content));
}
{
  const design = J.pages.find((p) => p.name === "Design a Sentient Item").text.content;
  const linked = [...design.matchAll(/@UUID\[Compendium\.trg-eldritch-arts\.ea-tables\.RollTable\.([A-Za-z0-9]{16})\]\{([^}]+)\}/g)].map((m) => [m[1], m[2]]);
  equal("B \"Design a Sentient Item\" links every table, by its id", linked, B.ALL_TABLES.map((t) => [t._id, t.name.replace(/^Sentient Item: /, "")]));
  ok("B …with the book's own words around them, and the d8 for Senses", [T.intro[0], T.after, T.arraysNote].every((l) => plain(design).includes(l)) && /Senses\}<\/a>|Senses\} \(1d8\)/.test(design));
}
equal("B the book's bullets set a blank line apart are one list (found in review)", ["Magic Suppression Areas", "Planes of Existence"].map((n) => (J.pages.find((p) => p.name === n).text.content.match(/<\/ul>\s*<ul>/g) ?? []).length), [0, 0]);
ok("B …and the planar languages are one list of twelve", /<ul>(<li>[^<]+<\/li>){12}<\/ul>/.test(J.pages.find((p) => p.name === "Planes of Existence").text.content));
equal("B every page is a text page; its title is shown only where the book's heading does not open it (0.17.2, found live)", J.pages.map((p) => [p.name, p.type, p.title.show, p.text.format]), J.pages.map((p) => [p.name, "text", p.name === "Design a Sentient Item", 1]));
ok("B …every hidden-title page does open with a heading", J.pages.filter((p) => !p.title.show).every((p) => /^<h[234]>/.test(p.text.content.trim())));
ok("B what is automated is said where it is", /Relic Bonding Ritual/.test(J.pages[7].text.content) && /Influence button/.test(J.pages[8].text.content));

/* ================================================================== C */
equal("C the packs: the tables as RollTables, the journal as a JournalEntry", PACKS.filter((p) => ["ea-tables", "ea-rules"].includes(p.name)).map((p) => [p.name, p.type, p.docs.length]), [["ea-tables", "RollTable", 10], ["ea-rules", "JournalEntry", 1]]);
equal("C …declared in module.json, in the folder", ["ea-tables", "ea-rules"].map((n) => [manifest.packs.find((p) => p.name === n)?.type, manifest.packFolders[0].packs.includes(n)]), [["RollTable", true], ["JournalEntry", true]]);
{
  const src = (n) => fs.readdirSync(path.join(ROOT, "packs-source", n)).map((f) => JSON.parse(read("packs-source", n, f)));
  const tables = src("ea-tables");
  ok("C the tables are keyed as Foundry keys them, with their results", tables.length === 10 && tables.every((t) => t._key === `!tables!${t._id}` && t.results.every((r) => r._key === `!tables.results!${t._id}.${r._id}`)));
  const j = src("ea-rules");
  ok("C the journal is keyed with its pages", j.length === 1 && j[0]._key === `!journal!${j[0]._id}` && j[0].pages.every((p) => p._key === `!journal.pages!${j[0]._id}.${p._id}`) && j[0].pages.length === 12);
  ok("C both are compiled", fs.existsSync(path.join(ROOT, "packs", "ea-tables")) && fs.existsSync(path.join(ROOT, "packs", "ea-rules")));
}
ok("C build-packs keys a RollTable", /if \(type === "RollTable"\) \{\n\s*return \{ \.\.\.doc, _key: `!tables!\$\{doc\._id\}`, results: \(doc\.results \?\? \[\]\)\.map\(\(r\) => \(\{ \.\.\.r, _key: `!tables\.results!\$\{doc\._id\}\.\$\{r\._id\}` \}\)\) \};/.test(read("tools", "build-packs.mjs")));
ok("C ids are unique", new Set([...B.ALL_TABLES.flatMap((t) => [t._id, ...t.results.map((r) => r._id)]), J._id, ...J.pages.map((p) => p._id)]).size === B.ALL_TABLES.length + B.ALL_TABLES.reduce((n, t) => n + t.results.length, 0) + 1 + J.pages.length);

if (process.env.EA_BOOK_MD && fs.existsSync(process.env.EA_BOOK_MD)) {
  // The cut itself, re-made from the book: the tables and pages book-text.json holds are the extractor's.
  const { execFileSync } = await import("node:child_process");
  const os = await import("node:os");
  const out = path.join(os.tmpdir(), `ea-10b-${process.pid}.json`);
  const sidebars = process.env.EA_SIDEBARS_MD ?? path.join(path.dirname(process.env.EA_BOOK_MD), "ea-sidebars.md");
  execFileSync(process.execPath, [path.join(ROOT, "tools", "content", "extract-book.mjs"), process.env.EA_BOOK_MD, sidebars, out], { stdio: "pipe" });
  const fresh = JSON.parse(fs.readFileSync(out, "utf8"));
  fs.rmSync(out, { force: true });
  equal("C the extractor re-cuts the same tables and pages from the book", [JSON.stringify(fresh.chapter9.tables) === JSON.stringify(T), JSON.stringify(fresh.rulesPages) === JSON.stringify(BOOK.rulesPages)], [true, true]);
}

/* ================================================================== D */
equal("D the manifest: 0.17.2, needs TRG Prime 3.694.0", [manifest.version, manifest.relationships.systems[0].compatibility.minimum, /REQUIRED_SYSTEM = "3\.694\.0"/.test(read("scripts", "eldritch-arts.mjs"))], ["0.18.3", "3.694.0", true]);

console.log(`verify-block10b: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exitCode = failures.length ? 1 : 0;
