#!/usr/bin/env node
/**
 * mutate-block6a — the mutation half of verify-block6a. Each mutation breaks
 * one printed number, one reading or one wire of Block 6's group A;
 * verify-block6a must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block6-a.mjs"), A = f("module", "block6a-automations.mjs"), S3 = f("tools", "content", "block3-spells.mjs"), B3C = f("tools", "content", "block3.mjs");

const MUTATIONS = [
  // Graham's ruling of 4 November 2026: every Witch spell is High Magic.
  { name: "the Witch's Pact spell is ordinary again (her class Ethereal and Verdant only)", file: B3C, from: "    highMagicCaster: true,\n    repertoire: { firstPicks: 2,", to: "    highMagicCaster: [\"ethereal\", \"verdant\"],\n    repertoire: { firstPicks: 2," },
  { name: "the Pact cards say nothing of a Witch's High Magic", file: C, from: "outside her picks, cast as High Magic as every spell of hers is (Graham's ruling, 4 November 2026) (delete it", to: "outside her picks (delete it" },
  // The content
  { name: "Q90 undone: the Pacts do not opt in to \"+10 levels\"", file: C, from: "const SINCE = { progressionSinceTaken: true };", to: "const SINCE = {};" },
  { name: "High Mage's progression left as printed", file: C, from: "    progression: \"Gained class skill +10 ranks\",\n", to: "" },
  { name: "Bloodmage's prerequisite stored as printed (fails open)", file: C, from: "    prerequisites: \"Con +2, Level 2\",\n", to: "" },
  { name: "Blood of the Wyrm keeps the unparseable Dragon Birthright", file: C, from: "    prerequisites: \"Intimidate 2 ranks\",\n", to: "" },
  { name: "Angelic Pact grants Bless", file: C, from: "grantedSpells: \"Sanctuary\",", to: "grantedSpells: \"Bless\"," },
  { name: "Angelic Pact's saves are class bonuses", file: C, from: "savesVsTraits(\"Angelic Pact\", 2, \"circumstance\", [\"fear\", \"soul\"])", to: "savesVsTraits(\"Angelic Pact\", 2, \"class\", [\"fear\", \"soul\"])" },
  { name: "Angelic Pact forgets Soul", file: C, from: "savesVsTraits(\"Angelic Pact\", 2, \"circumstance\", [\"fear\", \"soul\"])", to: "savesVsTraits(\"Angelic Pact\", 2, \"circumstance\", [\"fear\"])" },
  { name: "the tick fires on a named trait", file: C, from: "auto: false, when: { checkTypes: [\"save\"], not: { traits } } })", to: "auto: false, when: { checkTypes: [\"save\"] } })" },
  { name: "Angelic Pact heals 2 per PP", file: C, from: "healingRider: { label: \"Angelic Pact\", perPP: 1, traits: [\"healing\"] }", to: "healingRider: { label: \"Angelic Pact\", perPP: 2, traits: [\"healing\"] }" },
  { name: "Angelic Pact heals on any spell", file: C, from: "healingRider: { label: \"Angelic Pact\", perPP: 1, traits: [\"healing\"] }", to: "healingRider: { label: \"Angelic Pact\", perPP: 1 }" },
  { name: "Demonic Pact's rider is cold", file: C, from: "spellDamageRider: { label: \"Demonic Pact\", perPP: 1, damageType: \"fire\" }", to: "spellDamageRider: { label: \"Demonic Pact\", perPP: 1, damageType: \"cold\" }" },
  { name: "Demonic Pact gives +1 Intimidate", file: C, from: "classSkillEffect(id, n, [\"Intimidate\"], 2)", to: "classSkillEffect(id, n, [\"Intimidate\"], 1)" },
  { name: "Fey Pact forgets Diplomacy", file: C, from: "classSkillEffect(id, n, [\"Deception\", \"Diplomacy\"], 2)", to: "classSkillEffect(id, n, [\"Deception\"], 2)" },
  { name: "Fey Pact's DC reads enchantment", file: C, from: "spellDCBonus: { label: \"Fey Pact\", value: 1, type: \"untyped\", traits: [\"mental\"] }", to: "spellDCBonus: { label: \"Fey Pact\", value: 1, type: \"untyped\", traits: [\"enchantment\"] }" },
  { name: "Grave Pact's DC +2", file: C, from: "spellDCBonus: { label: \"Grave Pact\", value: 1, type: \"untyped\", traits: [\"soul\"] }", to: "spellDCBonus: { label: \"Grave Pact\", value: 2, type: \"untyped\", traits: [\"soul\"] }" },
  { name: "Grave Pact's saves circumstance", file: C, from: "savesVsTraits(\"Grave Pact\", 2, \"class\", [\"soul\"])", to: "savesVsTraits(\"Grave Pact\", 2, \"circumstance\", [\"soul\"])" },
  { name: "Void Pact grants no Darkvision", file: C, from: "    grantedAbilities: \"Darkvision\",\n", to: "" },
  { name: "Hex Weaver has no familiar", file: C, from: "    grantedFeats: \"Familiar\",\n", to: "" },
  { name: "Birthrager cannot cast while raging", file: C, from: "flags: { eaAutomation: \"birthrager\", castsWhileRaging: true },", to: "flags: { eaAutomation: \"birthrager\" }," },
  { name: "Birthrager is not instinctive", file: C, from: "ARCHETYPES_B6_A.find((f) => f.name === \"Birthrager\").system.casterStyle = \"instinctive\";", to: "" },
  { name: "Exhalation's compound prerequisite not opted in", file: C, from: "flags: { eaAutomation: \"elementalExhalation\", compoundSkillPrerequisites: true },", to: "flags: { eaAutomation: \"elementalExhalation\" }," },
  { name: "Wyrm Ascendant's compound prerequisite not opted in", file: C, from: "flags: { eaAutomation: \"wyrmAscendant\", compoundSkillPrerequisites: true },", to: "flags: { eaAutomation: \"wyrmAscendant\" }," },
  { name: "High Mage opens no Adept tier", file: C, from: "\"High Mage\": Object.freeze({ classGrants: [\"Sorcerer\"], tierGrants: [\"Adept\"] }),", to: "\"High Mage\": Object.freeze({ classGrants: [\"Sorcerer\"] })," },
  { name: "Birthrager opens the Witch", file: C, from: "Birthrager: Object.freeze({ classGrants: [\"Sorcerer\"], tierGrants: [\"Adept\"] })", to: "Birthrager: Object.freeze({ classGrants: [\"Witch\"], tierGrants: [\"Adept\"] })" },
  { name: "the docs grade Sanguine Channel C", file: C, from: "\"Sanguine Channel\": { level: \"B\",", to: "\"Sanguine Channel\": { level: \"C\"," },
  { name: "Blood of the Wyrm's card forgets the Infusion die", file: C, from: "Your Draconic Infusion's claw damage gains one more d6", to: "Your Draconic Infusion's claw damage is unchanged" },
  { name: "Draconic Infusion's +1d6 warp is uncounted again", file: S3, from: "warpMods: [{ durationText: \"10 minutes\" }, { bonusValue: 1, bonusMax: 4 }, {}],", to: "warpMods: [{ durationText: \"10 minutes\" }, {}, {}]," },
  { name: "Draconic Infusion's card still says by hand", file: S3, from: "level: \"partly\", what: \"the claws' extra 1d6 by dragon type, +1d6 a warp", to: "level: \"not\", what: \"the claws' extra 1d6 by dragon type, +1d6 a warp" },
  // The data the rules carry
  { name: "Wild becomes borrowable", file: A, from: "  Umbral: Object.freeze({ ability: \"charisma\", tradition: \"ethereal\", skills: [\"planes\", \"stealth\"], specialist: \"Shadow Shift\", cantrip: \"Ghost Sound\" })\n", to: "  Umbral: Object.freeze({ ability: \"charisma\", tradition: \"ethereal\", skills: [\"planes\", \"stealth\"], specialist: \"Shadow Shift\", cantrip: \"Ghost Sound\" }),\n  Wild: Object.freeze({ ability: \"charisma\", tradition: \"\", skills: [\"perform\", \"acrobatics\"], specialist: \"\", cantrip: \"\" })\n" },
  { name: "Storm's cantrip is Shock Bolt (Q15 undone)", file: A, from: "specialist: \"Storm Bolt\", cantrip: \"Orb Of Lightning\"", to: "specialist: \"Storm Bolt\", cantrip: \"Shock Bolt\"" },
  { name: "Dragon's skills misread", file: A, from: "skills: [\"arcana\", \"intimidate\"], specialist: \"Draconic Infusion\"", to: "skills: [\"arcana\", \"linguistics\"], specialist: \"Draconic Infusion\"" },
  { name: "High Mage's minimum is +3", file: A, from: "export const BIRTHRIGHT_MINIMUM = 2;", to: "export const BIRTHRIGHT_MINIMUM = 3;" },
  { name: "water is fire", file: A, from: "earth: \"acid\", fire: \"fire\", water: \"cold\" });", to: "earth: \"acid\", fire: \"fire\", water: \"fire\" });" },
  { name: "Draconic Pact offers sonic", file: A, from: "export const DRACONIC_ENERGIES = Object.freeze([\"acid\", \"cold\", \"electricity\", \"fire\", \"poison\"]);", to: "export const DRACONIC_ENERGIES = Object.freeze([\"acid\", \"cold\", \"electricity\", \"fire\", \"poison\", \"sonic\"]);" },
  { name: "Void Pact's DB +1", file: A, from: "export const VOID_DB = 2;", to: "export const VOID_DB = 1;" },
  { name: "Void Pact's Darkvision +60", file: A, from: "export const VOID_DARKVISION_FEET = 30;", to: "export const VOID_DARKVISION_FEET = 60;" },
  { name: "Crimson Rite's suppression costs 2 PP", file: A, from: "export const CRIMSON_SUPPRESS_PP = 1;", to: "export const CRIMSON_SUPPRESS_PP = 2;" },
  { name: "Exhalation costs 1 PP", file: A, from: "export const EXHALATION_PP = 2;", to: "export const EXHALATION_PP = 1;" },
  { name: "Exhalation's cave breath is a cone", file: A, from: "export const EXHALATION_LINE_TYPES = Object.freeze([\"cave\", \"light\"]);", to: "export const EXHALATION_LINE_TYPES = Object.freeze([\"light\"]);" },
  { name: "Wyrm Ascendant lasts 1 minute", file: A, from: "export const ASCENDANT_SECONDS = 600;", to: "export const ASCENDANT_SECONDS = 60;" },
  { name: "the wyrm warp costs 4 PP", file: A, from: "export const WYRM_WARP_PP = 2;", to: "export const WYRM_WARP_PP = 4;" },
  { name: "the wyrm warp forgets Elemental", file: A, from: "export const WYRM_WARP_TRAITS = Object.freeze([\"elemental\", ", to: "export const WYRM_WARP_TRAITS = Object.freeze([" },
  { name: "Draconic Claws deal 1d8", file: A, from: "export const DRACONIC_CLAWS_DICE = \"1d6\";", to: "export const DRACONIC_CLAWS_DICE = \"1d8\";" },
  // The rules
  { name: "Bloodmage may reduce a spell to 0 PP", file: A, from: "export const bloodmageMax = (payable) => Math.max(0, int(payable) - 1);", to: "export const bloodmageMax = (payable) => Math.max(0, int(payable));" },
  { name: "Q105 undone: a fumble without Bleed drawn bleeds", file: A, from: "  if (!(int(drawn) > 0) || refunded) return { paid: base, extra: 0, total: base };", to: "  if (refunded) return { paid: base, extra: 0, total: base };" },
  { name: "a fumble's Bleed rounds up", file: A, from: ": d === \"fumble\" ? Math.floor(Math.max(0, int(totalPP)) / 2) : 0;", to: ": d === \"fumble\" ? Math.ceil(Math.max(0, int(totalPP)) / 2) : 0;" },
  { name: "a blunder bleeds as a fumble", file: A, from: "const extra = d === \"blunder\" ? Math.max(0, int(totalPP)) :", to: "const extra = d === \"blunder\" ? Math.floor(Math.max(0, int(totalPP)) / 2) :" },
  { name: "Elemental Pact counts a pool twice", file: A, from: "damageTypes: DAMAGE_TYPE_KEYS.filter((t) => t !== energy), type: \"untyped\" }", to: "type: \"untyped\" }" },
  { name: "Elemental Pact reads only the trait", file: A, from: "    { label: \"Elemental Pact\", perDie: 1, damageTypes: [energy], type: \"untyped\" },\n", to: "" },
  { name: "the roar on a plain hit", file: A, from: "(ctx.spellHits ?? []).some((hit) => hit?.critical);", to: "(ctx.spellHits ?? []).length > 0;" },
  { name: "the roar on a refund", file: A, from: "export const roarDue = (ctx = {}) => Boolean(ctx.cast) && !ctx.refunded &&", to: "export const roarDue = (ctx = {}) => Boolean(ctx.cast) &&" },
  { name: "the roar's advantage is never spent", file: A, from: "auto: true, oneShot: true, when: { checkTypes: [\"skill\"], actions: [\"demoralise\"] } }];", to: "auto: true, when: { checkTypes: [\"skill\"], actions: [\"demoralise\"] } }];" },
  { name: "the roar helps any skill", file: A, from: "when: { checkTypes: [\"skill\"], actions: [\"demoralise\"] } }];", to: "when: { checkTypes: [\"skill\"] } }];" },
  { name: "Void Pact on a Success", file: A, from: "const DEGREES_CRITICAL = Object.freeze([\"critical\", \"heroic\"]);", to: "const DEGREES_CRITICAL = Object.freeze([\"critical\", \"heroic\", \"success\"]);" },
  { name: "Void Pact's DB is status", file: A, from: "[{ key: \"system.combat.defence.circumstance\", type: \"custom\", value: String(VOID_DB), priority: 20 }]", to: "[{ key: \"system.combat.defence.status\", type: \"custom\", value: String(VOID_DB), priority: 20 }]" },
  { name: "Void Pact's +30 also on its own Darkvision", file: A, from: "isDarkvisionSource(i) && i.flags?.[SYSTEM_ID]?.grantedBy?.sourceId !== pact.id);", to: "isDarkvisionSource(i));" },
  { name: "Void Pact's +30 for any sense", file: A, from: "return norm(String(sense.name ?? item.name).replace(/\\(.*\\)\\s*$/, \"\")) === \"darkvision\";", to: "return true;" },
  { name: "Crimson Rite's crit on a plain hit", file: A, from: "(ctx.spellHits ?? []).filter((hit) => hit?.critical && hit.target)", to: "(ctx.spellHits ?? []).filter((hit) => hit.target)" },
  { name: "Crimson Rite's bonus is untyped", file: A, from: "({ label: \"Crimson Rite\", perDie: 1, type: \"circumstance\" })", to: "({ label: \"Crimson Rite\", perDie: 1, type: \"untyped\" })" },
  { name: "Crimson Rite's bonus kept while suppressed", file: A, from: "owns && bleeding && !suppressed;", to: "owns && bleeding;" },
  { name: "Hex Weaver reaches level + 2", file: A, from: "return int(sys.ppCost) <= int(level) + 1;", to: "return int(sys.ppCost) <= int(level) + 2;" },
  { name: "Hex Weaver takes Arcane", file: A, from: "if (!trads.some((t) => t === \"ethereal\" || t === \"verdant\")) return false;", to: "if (!trads.some((t) => t === \"ethereal\" || t === \"verdant\" || t === \"arcane\")) return false;" },
  { name: "Hex Weaver takes hexes", file: A, from: "  if (sys.specialist || entry?.flags?.[SYSTEM_ID]?.eaHex) return false;\n  const trads", to: "  if (sys.specialist) return false;\n  const trads" },
  { name: "the Highmagic trait is not added", file: A, from: "  return [...list, \"Highmagic\"].join(\", \");", to: "  return list.join(\", \");" },
  { name: "Hex Weaver opens every specialist spell", file: A, from: "export const hexWeaverAllows = (owns, spell) => Boolean(owns) && Boolean(spell?.flags?.[SYSTEM_ID]?.eaHex);", to: "export const hexWeaverAllows = (owns, spell) => Boolean(owns);" },
  { name: "the Bloodmage hexes open to anyone", file: A, from: "export const bloodmageAllows = (owns, spell) => Boolean(owns) && ", to: "export const bloodmageAllows = (owns, spell) => " },
  { name: "the wyrm warp offered to every type", file: A, from: "    when: (actor) => typeOf(actor) === type,\n", to: "" },
  { name: "the wyrm warp on a spell without damage", file: A, from: "match: { anyTraits: [...WYRM_WARP_TRAITS], damaging: true },", to: "match: { anyTraits: [...WYRM_WARP_TRAITS] }," },
  { name: "Draconic Claws on every weapon", file: A, from: ", weaponNames: [DRAGON_CLAWS_NAME.toLowerCase()], once: false };", to: ", once: false };" },
  { name: "Draconic Claws spent on a Strike", file: A, from: ", weaponNames: [DRAGON_CLAWS_NAME.toLowerCase()], once: false };", to: ", weaponNames: [DRAGON_CLAWS_NAME.toLowerCase()] };" },
  { name: "Exhalation rounds up", file: A, from: "const n = Math.floor(Math.max(0, int(level)) / 2);", to: "const n = Math.ceil(Math.max(0, int(level)) / 2);" },
  { name: "Sanguine Channel earned without Bleed", file: A, from: "norm(s?.key) === \"bloodmage\" && int(s?.paid) > 0);", to: "norm(s?.key) === \"bloodmage\");" },
  { name: "the fly speed is 20 ft", file: A, from: "export const wingsDerives = (on) => (on ? { movement: { key: \"fly\", orLand: true } } : null);", to: "export const wingsDerives = (on) => (on ? { movement: { key: \"fly\", feet: 20 } } : null);" },
  { name: "a borrowed birthright does not count (Q100)", file: A, from: "  return String(borrowedBirthrightFeat(actor)?.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG] ?? \"\");", to: "  return \"\";" },
  { name: "Blood of the Wyrm open to all", file: A, from: "export const wyrmEligibility = (actor) => (norm(birthrightNameOf(actor)) === \"dragon\" ? null :", to: "export const wyrmEligibility = (actor) => (true ? null :" },
  // The Foundry side
  { name: "Draconic Pact keeps no energy", file: A, from: "    await item.setFlag(SYSTEM_ID, \"eaEnergy\", pick);\n", to: "" },
  { name: "Elemental Pact lays no per-die rows", file: A, from: "changes: resistanceChanges(energy), flags: { [SYSTEM_ID]: { spellDamageBonus: elementalPactRows(pick) } }", to: "changes: resistanceChanges(energy)" },
  { name: "Elemental Pact resists the element's name", file: A, from: "description: `Elemental Pact (${pick}): resistance to ${energy}; +1 damage per die on spells of your element.`,\n      changes: resistanceChanges(energy)", to: "description: `Elemental Pact (${pick}): resistance to ${energy}; +1 damage per die on spells of your element.`,\n      changes: resistanceChanges(pick)" },
  { name: "the roar is not asked", file: A, from: "if (featOf(actor, \"Draconic Pact\") && roarDue(ctx) && (await confirm(", to: "if (featOf(actor, \"Draconic Pact\") && roarDue(ctx) && (true || await confirm(" },
  { name: "the roar lasts for ever", file: A, from: "      system: { conditionals: roarConditionals() }, expiry: expiryFor(\"endOfNextTurn\", actor)", to: "      system: { conditionals: roarConditionals() }" },
  { name: "Void Pact's DB stacks", file: A, from: "    const old = ownEffects(actor, SRC.voidDB);\n    if (old.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", old.map((e) => e.id));\n", to: "    const old = ownEffects(actor, SRC.voidDB);\n" },
  { name: "Void Pact's DB lasts for ever", file: A, from: "      changes: voidDBChanges(), expiry: expiryFor(\"startOfNextTurn\", actor)", to: "      changes: voidDBChanges()" },
  { name: "Void Pact's +30 never laid", file: A, from: "  if (due && !has) await pact.setFlag(SYSTEM_ID, \"senseRangeBonus\", voidSenseBonus());", to: "" },
  { name: "Void Pact's +30 never lifted", file: A, from: "  else if (!due && has) await pact.unsetFlag(SYSTEM_ID, \"senseRangeBonus\");", to: "" },
  { name: "a Warlock's Pact spell stays learned", file: A, from: "  await warlockPactSpell(item);\n", to: "" },
  { name: "every class's Pact spell turns innate", file: A, from: "  if (item?.type !== \"spell\" || className(actor) !== \"warlock\" || item.system?.innate) return false;", to: "  if (item?.type !== \"spell\" || item.system?.innate) return false;" },
  { name: "any granted spell turns innate", file: A, from: "  if (!PACT_NAMES.map(norm).includes(norm(item.flags?.[SYSTEM_ID]?.grantedBy?.sourceName))) return false;\n", to: "" },
  { name: "the Warlock's copy is cast with Intelligence", file: A, from: "[`flags.${SYSTEM_ID}.castingAbilityOverride`]: \"charisma\", [`flags.${SYSTEM_ID}.innatePPAllowance`]: 1, [`flags.${MODULE_ID}.warlockPick`]: \"pact\"", to: "[`flags.${SYSTEM_ID}.castingAbilityOverride`]: \"intelligence\", [`flags.${SYSTEM_ID}.innatePPAllowance`]: 1, [`flags.${MODULE_ID}.warlockPick`]: \"pact\"" },
  { name: "Hex Weaver's pick is not High Magic", file: A, from: "{ [HEX_WEAVER_SPELL_FLAG]: item.id }, { highMagic: true });", to: "{ [HEX_WEAVER_SPELL_FLAG]: item.id }, { highMagic: false });" },
  { name: "Hex Weaver's second pick adds rather than replaces", file: A, from: "    await removeFlaggedSpells(actor, HEX_WEAVER_SPELL_FLAG, item.id);\n", to: "" },
  { name: "the granted spell names no source (uncastable)", file: A, from: "[SYSTEM_ID]: { ...(out.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: source.id, sourceName: source.name, requested: data.name } },", to: "[SYSTEM_ID]: { ...(out.flags?.[SYSTEM_ID] ?? {}) }," },
  { name: "High Mage's spell is not High Magic", file: A, from: "label: \"High Mage\", choices: highMageChoices(actor.system?.attributes), highMagic: true, cantrip: false", to: "label: \"High Mage\", choices: highMageChoices(actor.system?.attributes), highMagic: false, cantrip: false" },
  { name: "High Mage's minimum is not asked", file: A, from: "choices: highMageChoices(actor.system?.attributes)", to: "choices: Object.keys(BORROWABLE_BIRTHRIGHTS)" },
  { name: "High Mage writes no class skill", file: A, from: "      await actor.setFlag(SYSTEM_ID, HIGH_MAGE_GRANT.flag, { skill, written: 0 });\n", to: "" },
  { name: "High Mage's skill from any birthright", file: A, from: "    if (got.br.skills.includes(skill)) {", to: "    if (skill) {" },
  { name: "a new pick keeps the old spells", file: A, from: "  await removeFlaggedSpells(actor, BORROWED_SPELL_FLAG, item.id);\n  const added = [];", to: "  const added = [];" },
  { name: "a non-Dragon pick keeps the old dragon type", file: A, from: "  else if (item.flags?.[SYSTEM_ID]?.[BORROWED_DRAGON_FLAG]) await item.unsetFlag(SYSTEM_ID, BORROWED_DRAGON_FLAG);\n", to: "" },
  { name: "the borrowed pick is not recorded", file: A, from: "  await item.setFlag(SYSTEM_ID, BORROWED_BIRTHRIGHT_FLAG, pick);\n", to: "" },
  { name: "Birthrager gets no cantrip", file: A, from: "label: \"Birthrager\", choices: Object.keys(BORROWABLE_BIRTHRIGHTS), highMagic: false, cantrip: true", to: "label: \"Birthrager\", choices: Object.keys(BORROWABLE_BIRTHRIGHTS), highMagic: false, cantrip: false" },
  { name: "Birthrager's spells are High Magic", file: A, from: "label: \"Birthrager\", choices: Object.keys(BORROWABLE_BIRTHRIGHTS), highMagic: false,", to: "label: \"Birthrager\", choices: Object.keys(BORROWABLE_BIRTHRIGHTS), highMagic: true," },
  { name: "Birthrager sets no tradition", file: A, from: "      await actor.update({ \"system.magic.tradition\": got.br.tradition });\n", to: "" },
  { name: "Birthrager overwrites the sheet's tradition", file: A, from: "    if (!stored) {\n      await actor.update", to: "    if (true) {\n      await actor.update" },
  { name: "Blood of the Wyrm resists the type's name", file: A, from: "      changes: resistanceChanges(energy), flags: { [MODULE_ID]: { wyrmType: type } }", to: "      changes: resistanceChanges(type), flags: { [MODULE_ID]: { wyrmType: type } }" },
  { name: "the wyrm effects re-laid every sync", file: A, from: "if (wyrm && energy && featEffect(actor, wyrm)?.getFlag?.(MODULE_ID, \"wyrmType\") !== type) {", to: "if (wyrm && energy) {" },
  { name: "Draconic Claws never laid", file: A, from: "  if (claws && energy && featEffect(actor, claws)?.getFlag?.(MODULE_ID, \"wyrmType\") !== type) {", to: "  if (false) {" },
  { name: "a new dragon type is not followed", file: A, from: "  if (touched) await syncWyrm(actor);", to: "" },
  { name: "the dragon type is not stored", file: A, from: "  if (own && norm(own.name) === \"dragon\") await own.setFlag(MODULE_ID, \"dragonType\", choice);", to: "" },
  { name: "Exhalation spends no PP", file: A, from: "    if (!(await spendPP(actor, EXHALATION_PP, \"Elemental Exhalation\"))) return false;\n", to: "" },
  { name: "Exhalation spends no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    const bonus", to: "    const bonus" },
  { name: "Exhalation without its use", file: A, from: "    if (usesLeft(item) <= 0) return warn(\"Elemental Exhalation: its Focus use is spent", to: "    if (false) return warn(\"Elemental Exhalation: its Focus use is spent" },
  { name: "Exhalation ignores the per-die bonus", file: A, from: "    const formula = bonus?.total ? `${dice} + ${bonus.total}` : dice;", to: "    const formula = dice;" },
  { name: "Exhalation is a Fortitude save", file: A, from: "      save: \"reflex\", basic: true, scope: \"targets\", damage: { formula, type: energy },", to: "      save: \"fortitude\", basic: true, scope: \"targets\", damage: { formula, type: energy }," },
  { name: "Exhalation's save is not basic", file: A, from: "      save: \"reflex\", basic: true,", to: "      save: \"reflex\", basic: false," },
  { name: "Exhalation with nobody targeted", file: A, from: "    if (!targets.length) return warn(`Elemental Exhalation: target", to: "    if (false) return warn(`Elemental Exhalation: target" },
  { name: "Wyrm Ascendant spends no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    await actor.createEmbeddedDocuments(\"ActiveEffect\", [effectData(SRC.wings", to: "    await actor.createEmbeddedDocuments(\"ActiveEffect\", [effectData(SRC.wings" },
  { name: "Wyrm Ascendant gives no fly speed", file: A, from: "    await syncWings(actor);\n    await card(actor, \"Wyrm Ascendant\", [line(\"Scaled wings", to: "    await card(actor, \"Wyrm Ascendant\", [line(\"Scaled wings" },
  { name: "the wings fold without a fall", file: A, from: "    await landIfAloft(actor);\n", to: "" },
  { name: "the fall is from the ground", file: A, from: "  await h().rollFalling(actor, { distance: height,", to: "  await h().rollFalling(actor, { distance: 0," },
  { name: "Bloodmage offered to anyone", file: A, from: "    if (!featOf(ctx.actor, \"Bloodmage\")) return null;\n", to: "" },
  { name: "Bloodmage's Bleed is never taken", file: A, from: "    await h().applyConditionTags(actor, [{ key: \"bleeding\", value: got.total, label: \"Bleeding\" }]);", to: "" },
  { name: "Sanguine Channel without Bloodmage", file: A, from: "    if (!featOf(actor, \"Sanguine Channel\") || !featOf(actor, \"Bloodmage\")) return null;", to: "    if (!featOf(actor, \"Sanguine Channel\")) return null;" },
  { name: "Sanguine Channel on an innate cast", file: A, from: "    if (ctx.innate || ctx.itemCast || ctx.stored || ctx.ritual) return null;", to: "    if (ctx.itemCast || ctx.stored || ctx.ritual) return null;" },
  { name: "Sanguine Channel's attack +2", file: A, from: "if (mode === \"attack\") return { attack: 1,", to: "if (mode === \"attack\") return { attack: 2," },
  { name: "Sanguine Channel's DC to the first target", file: A, from: "      token = targets.find((t) => t.id === id) ?? null;", to: "      token = targets[0];" },
  { name: "Sanguine Channel's Bleed never added", file: A, from: "    await h().applyConditionTags(actor, [{ key: \"bleeding\", value: 1, label: \"Bleeding\" }]);\n    await card(actor, \"Sanguine Channel\"", to: "    await card(actor, \"Sanguine Channel\"" },
  { name: "Crimson Rite's window never opens", file: A, from: "  if (want && !have.length) {\n    await actor.createEmbeddedDocuments(\"ActiveEffect\", [effectData(SRC.crimson,", to: "  if (false) {\n    await actor.createEmbeddedDocuments(\"ActiveEffect\", [effectData(SRC.crimson," },
  { name: "Crimson Rite's window never closes", file: A, from: "  } else if (!want && have.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", have.map((e) => e.id));", to: "  }" },
  { name: "Crimson Rite's suppression costs nothing", file: A, from: "    if (!(await spendPP(actor, CRIMSON_SUPPRESS_PP, \"Crimson Rite\"))) return false;\n", to: "" },
  { name: "Crimson Rite's suppression lowers nothing", file: A, from: "      system: { bleedReduction: CRIMSON_SUPPRESSION },", to: "      system: {}," },
  { name: "Crimson Rite's target does not bleed", file: A, from: "    for (const target of crits) await h().applyConditionTagsTo(target, [{ key: \"bleeding\", value: 1, label: \"Bleeding\" }]);\n", to: "" },
  { name: "the Bleeding hooks ignore the bleed", file: A, from: "  if (statusList(effect).includes(\"bleeding\") || effect.getFlag?.(MODULE_ID, \"source\") === SRC.crimsonOff) await syncCrimson(actor);", to: "  if (effect.getFlag?.(MODULE_ID, \"source\") === SRC.crimsonOff) await syncCrimson(actor);" },
  { name: "Sanguine Channel offered without a draw", file: A, from: "    if (int(ctx.spell?.system?.ppCost) < 1 || !sanguineDrawn(ctx)) return null;", to: "    if (int(ctx.spell?.system?.ppCost) < 1) return null;" },
  { name: "Sanguine Channel's draw reads any source", file: A, from: "export const sanguineDrawn = (ctx = {}) => (ctx.ppSources ?? []).some((s) => norm(s?.key) === \"bloodmage\" && int(s?.drawn) > 0);", to: "export const sanguineDrawn = (ctx = {}) => (ctx.ppSources ?? []).some((s) => int(s?.drawn) > 0);" },
  { name: "Sanguine Channel bleeds on a refund", file: A, from: "includes(\"sanguinechannel\") && !ctx.refunded && sanguineEarned(ctx)) {", to: "includes(\"sanguinechannel\") && sanguineEarned(ctx)) {" },
  { name: "High Mage open to a Sorcerer", file: A, from: "export const highMageEligibility = (actor) => (className(actor) === \"sorcerer\" ?", to: "export const highMageEligibility = (actor) => (false ?" },
  { name: "High Mage's eligibility not registered", file: A, from: "  api.registerFeatEligibility?.(\"High Mage\", highMageEligibility, moduleId);\n", to: "" },
  { name: "Draconic Infusion past 5d6", file: A, from: "export const INFUSION_MAX_EXTRA = 4;", to: "export const INFUSION_MAX_EXTRA = 5;" },
  { name: "Draconic Infusion ignores its warps", file: A, from: "  const extra = Math.min(INFUSION_MAX_EXTRA, Math.max(0, int(warpMods?.bonusValue)));", to: "  const extra = 0;" },
  { name: "Blood of the Wyrm's die not added", file: A, from: "  const dice = 1 + extra + (wyrm ? 1 : 0);", to: "  const dice = 1 + extra;" },
  { name: "Draconic Infusion always 1 minute", file: A, from: "INFUSION_SECONDS.warped : INFUSION_SECONDS.base;", to: "INFUSION_SECONDS.base : INFUSION_SECONDS.base;" },
  { name: "Draconic Infusion on a sword", file: A, from: "scope: \"melee\", weaponNames: [...INFUSION_CLAW_NAMES], once: false } };", to: "scope: \"melee\", once: false } };" },
  { name: "Draconic Infusion forgets natural Claws (Q100)", file: A, from: "export const INFUSION_CLAW_NAMES = Object.freeze([\"dragon claws\", \"claw\", \"claws\", \"claws (tiny)\", \"claws (small)\", \"claws (medium)\", \"claws (large)\"]);", to: "export const INFUSION_CLAW_NAMES = Object.freeze([\"dragon claws\"]);" },
  { name: "Draconic Infusion on a refund", file: A, from: "&& Boolean(ctx.cast) && !ctx.refunded && !ctx.itemCast;", to: "&& Boolean(ctx.cast) && !ctx.itemCast;" },
  { name: "Draconic Infusion's riders stack", file: A, from: "      const old = ownEffects(actor, SRC.infusion);\n      if (old.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", old.map((e) => e.id));\n", to: "" },
  { name: "Draconic Infusion's rider never laid", file: A, from: "        system: { strikeRider: got.rider }, expiry: forSeconds(got.seconds)", to: "        system: {}, expiry: forSeconds(got.seconds)" },
  // Registration
  { name: "Q92 undone: no Pact group", file: A, from: "  api.registerExclusiveFeats?.(\"Pact\", [...PACT_NAMES], moduleId);\n", to: "" },
  { name: "Hex Weaver's access not registered", file: A, from: "  api.registerSpecialistAccess?.(\"hexWeaver\", hexWeaverAccess, moduleId);\n", to: "" },
  { name: "the Bloodmage source not registered", file: A, from: "  api.registerCastPPSource?.(\"bloodmage\", bloodmageSource, moduleId);\n", to: "" },
  { name: "Sanguine Channel's option not registered", file: A, from: "  api.registerCastOption?.(\"sanguineChannel\", sanguineOption, moduleId);\n", to: "" },
  { name: "Birthrager not gated by Frenzy", file: A, from: "  api.registerFeatGate?.(\"Berserker\", [\"Frenzy\"], moduleId);\n", to: "" },
  { name: "Birthrager's BSB rounds down", file: A, from: "{ stat: \"bsb\", halfLevel: \"up\", types: [\"feat\"],", to: "{ stat: \"bsb\", halfLevel: \"down\", types: [\"feat\"]," },
  { name: "the wyrm warps not registered", file: A, from: "  api.registerSpellWarps?.(\"Blood of the Wyrm\", wyrmWarpEntries(wyrmTypeOf), moduleId);\n", to: "" },
  { name: "the wyrm eligibility not registered", file: A, from: "  api.registerFeatEligibility?.(\"Blood of the Wyrm\", wyrmEligibility, moduleId);\n", to: "" },
  { name: "High Mage's class-skill grant not registered", file: A, from: "  api.registerClassSkillGrant?.({ ...HIGH_MAGE_GRANT, options: [...HIGH_MAGE_GRANT.options] }, moduleId);\n", to: "" },
  { name: "Wyrm Ascendant's Use not registered", file: A, from: "  \"Wyrm Ascendant\": wyrmAscendant\n", to: "" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6a.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6a: verify-block6a already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6a: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6a: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
