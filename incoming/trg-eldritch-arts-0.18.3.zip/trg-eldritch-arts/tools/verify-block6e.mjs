#!/usr/bin/env node
/**
 * verify-block6e — Eldritch Arts 0.9.0 (Block 6, group E, on TRG Prime
 * 3.684.0): the 21 Warlock and Witch class feats, and the Warlock's Charisma
 * pool (Q97, Q98; Block 4's soul).
 *
 *   A  every feat against the book: name, category, traits as stored,
 *      prerequisites, repeatable, uses, the printed text and the automation
 *      paragraph, the docs' table
 *   B  the data: grants, declarations
 *   C  the core, run with the content: prerequisites, Focus extra uses, the
 *      extra-uses table, the cost modifier (G4), the death guard (G7), the
 *      hex's conditional axis, immunities as the core reads them, the pool
 *      (Q97, Q98), the aura, registration
 *   D  the pure rules
 *   F  the Foundry side with fakes: every Use, offer, prelude and hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6e.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y) and the placeable keep the OLD
 * position; the document's `_source` and `change` carry the NEW one.
 */
function placeEnd(doc, change) {
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
}
async function moveV14(token, change, handler, ...rest) {
  placeEnd(token.document, change);
  return handler(token.document, change, ...rest);
}


const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const confirms = [];
const reactorAnswers = [];
const asked = [];
const calls = { replace: [], casts: [], saves: [], checks: [], conditions: [], damage: [], sustain: [], gate: [], rolls: [] };
let saveDegree = "failure";
let checkDegree = "failure";
let familiarList = [];
let deadSet = new Set();
let castableAll = true;
let gateAllows = true;
const STEPS = {};
const uuidMap = new Map();
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; helpers.lastTitle = title; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  replaceFeatEffect: async (actor, item, data) => {
    calls.replace.push({ item: item.name, data });
    actor.effects = actor.effects.filter((e) => e.flags?.[SYS]?.featSource !== item.id);
    data.flags ??= {}; data.flags[SYS] = { ...(data.flags[SYS] ?? {}), featSource: item.id };
    return (await actor.createEmbeddedDocuments("ActiveEffect", [data]))[0];
  },
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title, step: q.step, data: q.data }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; if (a !== "yes") return { answer: a, result: null }; return { answer: a, result: await STEPS[q.step](actor, a, q.data) }; },
  isDead: async (a) => deadSet.has(a?.id),
  familiarsOf: async () => familiarList,
  levelDC: (level) => 10 + Number(level),
  innateSaveDCFor: async (actor) => ({ value: 10 + Number(actor.system.attributes.charisma.total) + Number(actor.system.identity.level), printed: false, level: Number(actor.system.identity.level), ability: "charisma" }),
  basicSaveHit: async (o) => { calls.saves.push({ caster: o.caster?.name, target: o.target?.name, save: o.save, dc: o.dc, label: o.label, amount: o.amount, type: o.type }); return { line: `${o.target.name} saved`, degree: "failure", taken: o.amount }; },
  rollCheck: async (cfg) => { calls.checks.push({ actor: cfg.actor?.name, type: cfg.type, subject: cfg.subject, dc: cfg.dc, sourceUuid: cfg.sourceUuid }); return { outcome: { degree: { key: checkDegree, label: checkDegree } } }; },
  applyConditionTagsTo: async (target, tags) => { calls.conditions.push({ target: target.name, tags }); },
  applyTypedDamage: async (target, o) => { calls.damage.push({ target: target.name, ...o }); return { packet: { taken: o.amount }, applied: o.amount }; },
  traitGate: async (actor, action) => { calls.gate.push(action); return gateAllows; },
  recordTraitUsage: async () => true,
  setSpellSustainer: async (caster, id, s) => { calls.sustain.push({ id, s }); const list = caster.flags[SYS].activeSpells; const e = list.find((x) => x.id === id); if (!e) return null; if (s) e.sustainedBy = s; else delete e.sustainedBy; return e; },
  spellCastable: async () => castableAll,
  castRefusal: async () => "",
  castSpell: async (actor, spell, options) => { calls.casts.push({ actor: actor.name, spell: spell.name, options }); return "cast"; }
};
class FakeRoll {
  constructor(formula) { this.formula = String(formula); }
  async evaluate() {
    // Deterministic: every die shows its highest face, so a d8 is told from a d6.
    let total = 0;
    for (const m of this.formula.matchAll(/(\d+)d(\d+)/g)) total += Number(m[1]) * Number(m[2]);
    for (const m of this.formula.replace(/\d+d\d+/g, "").matchAll(/[+-]\s*\d+/g)) total += Number(m[0].replace(/\s/g, ""));
    this.total = total; calls.rolls.push(this.formula); return this;
  }
}
globalThis.Roll = FakeRoll;
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => (confirms.length ? confirms.shift() : true) } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => "r1", deepClone: (x) => JSON.parse(JSON.stringify(x)), fromUuid: async (u) => uuidMap.get(u) ?? null } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id && !parent?.items?.some?.((i) => i.id === data._id) ? data._id : `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.system = it.system ?? {};
  it.uuid = `${parent?.uuid ?? "X"}.Item.${it.id}`;
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.toObject = () => JSON.parse(JSON.stringify({ ...it, parent: undefined, getFlag: undefined }));
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.flags = e.flags ?? {};
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.update = async (u) => { Object.assign(e, u); };
  e.delete = async () => { a.effects = a.effects.filter((x) => x !== e); };
  e.toObject = () => JSON.parse(JSON.stringify({ ...e, parent: undefined }));
  return e;
}
function makeActor(name, { level = 5, items = [], pp = 10, ap = 3, hp = 10, cha = 3, cl = null, tradition = "" } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: { [SYS]: {} }, items: [], documentName: "Actor", conditions: new Set() };
  a.system = { identity: { level }, resources: { pp: { value: pp }, ap: { value: ap }, hp: { value: hp } }, attributes: { charisma: { total: cha } }, magic: { tradition, casterLevelValue: cl ?? level }, combat: {} };
  const list = [];
  list.get = function (id) { return this.find((i) => i.id === id); };
  a.items = list;
  for (const d of items) a.items.push(makeItem(d, a));
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, docs) => {
    if (type === "Item") { const made = docs.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = docs.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => {
    if (type === "Item") { for (const id of ids) { const i = a.items.findIndex((x) => x.id === id); if (i >= 0) a.items.splice(i, 1); } return; }
    a.effects = a.effects.filter((e) => !ids.includes(e.id));
  };
  a.hasCondition = (k) => a.conditions.has(k);
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100, isTargeted: false, scene: "s1" };
  t.document = { actor, disposition, width: 1, height: 1, uuid: `Scene.s1.Token.${id}` };
  actor.token = t;
  return t;
}
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.684.0" }, messages: []
};
// 5 ft a square of 100 px (measurePath: px / 20).
globalThis.canvas = { tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 }, grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) } };

const C = await import(new URL("./content/block6-e.mjs", import.meta.url));
const common = await import(new URL("./content/block6-common.mjs", import.meta.url));
const auto = await import(new URL("../module/block6e-automations.mjs", import.meta.url));
const B4 = await import(new URL("./content/block4.mjs", import.meta.url));
const B4S = await import(new URL("./content/block4-spells.mjs", import.meta.url));
const auto4 = await import(new URL("../module/block4-automations.mjs", import.meta.url));
Object.assign(STEPS, { [auto.HEX_STEP]: auto.STEPS_B6_E.hexStep });
const F = Object.fromEntries(C.FEATS_B6_E.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS] ?? {};
const feat = (name, extra = {}) => ({ ...JSON.parse(JSON.stringify(F[name])), ...extra });

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
// printed name: [stored traits, prerequisites, repeatable, usesPerDay]
const LIST = {
  "ELEMENTAL BLAST": ["Warlock", "", false, ""], "ENHANCED BLAST": ["Warlock", "Level 2", false, ""], "ETHEREAL INSIGHT": ["Witch", "BSB +10", false, ""],
  "EXTRA BOND": ["Witch", "Level 4", true, ""], "EXTRA COMMUNION": ["Witch", "Level 8", false, ""], "FORBIDDEN LORE": ["Witch", "BSB +10", false, ""],
  "HEX BINDERS CURSE": ["Concentrate, Warlock, Witch", "Level 5", false, ""], "HEX MASTERY": ["Adept, Witch", "", false, ""], "HIGH SORCERY": ["Sorcerer, Witch", "BSB +4", true, ""],
  "MALEVOLENT BLAST": ["Focus, Warlock", "", false, ""], "PACT ASCENDANT": ["Warlock, Witch", "Level 16, Pact Boon", false, ""], "PACT BOON": ["Warlock, Witch", "Level 10, Pact Channeler", false, ""],
  "RITUAL OF BORROWED POWER": ["Witch", "BSB +8", false, ""], "SHADOWED GRIMOIRE": ["Warlock", "Level 3", true, ""], "SOUL-BOUND GRIMOIRE": ["Witch", "BSB +4", false, ""],
  "SYMBIOTIC WITCH": ["Witch", "BSB +4", false, "1"], "WARDING SIGIL": ["Focus, Warlock", "Level 6", false, ""], "WARLOCK’S HEX": ["Focus, Warlock", "Level 2", false, ""],
  "XITHRA CONE": ["Warlock", "Level 10", false, ""], "XITHRA RECOVERY": ["Warlock", "Level 4", false, ""], "XITHRA SPEAR": ["Warlock", "Level 5", false, ""]
};
{
  const classFeats = new Map(book.sections.classFeats.map((f) => [f.name, f]));
  equal("A twenty-one feats, in the book's names", C.FEATS_B6_E.map((f) => f.name), Object.keys(LIST).map(common.titleCase));
  const mine = book.sections.classFeats.filter((f) => f.traits.some((t) => ["WARLOCK", "WITCH"].includes(t)) && f.name !== "PACT CHANNELER").map((f) => f.name).sort();
  equal("A …every WARLOCK or WITCH class feat but Pact Channeler (group D's)", mine, Object.keys(LIST).sort());
  for (const [key, [traits, prereq, repeatable, uses]] of Object.entries(LIST)) {
    const f = F[common.titleCase(key)];
    const b = classFeats.get(key);
    ok(`A ${f?.name}: the book has it`, Boolean(f && b));
    if (!f || !b) continue;
    equal(`A ${f.name}: class feat, traits, prerequisites, repeatable, uses`, [f.type, f.system.category, f.system.traits, f.system.prerequisites, f.system.repeatable, f.system.usesPerDay], ["feat", "Class", traits, prereq, repeatable, uses]);
    equal(`A ${f.name}: the prerequisite is the book's`, f.system.prerequisites, b.fields?.Prerequisites ?? "");
    ok(`A ${f.name}: the card prints the book's text`, b.lines.every((l) => f.system.description.replace(/<[^>]+>/g, "").includes(l.replace(/\*\*/g, "").slice(0, 40))));
    ok(`A ${f.name}: the card says what is automated`, /(\*|<em>)(Automated|Partly automated|Not automated)/.test(f.system.description));
    equal(`A ${f.name}: Block 6 and its book line`, [f.flags[SYS].eaBlock, f.flags[SYS].eaBookLine], [6, b.line]);
  }
  equal("A the docs' table: every feat, by its item's name", Object.keys(C.AUTOMATION_B6_E), C.FEATS_B6_E.map((f) => f.name));
  equal("A …graded A 6, B 13, C 2, D 0", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B6_E).filter((r) => r.level === l).length), [6, 13, 2, 0]);
  ok("A the rulings are cited where they decided it", [["Warlock’s Hex", "Q134"], ["Hex Binders Curse", "Q135"], ["Malevolent Blast", "Q136"], ["Symbiotic Witch", "Q137"], ["Soul-Bound Grimoire", "Q138"], ["Warding Sigil", "Q139"], ["Ethereal Insight", "Q140"], ["Pact Ascendant", "Q141"], ["Hex Mastery", "Q93"], ["Forbidden Lore", "Q99"]].every(([n, q]) => F[n].system.description.includes(q)));
  ok("A a C feat's card opens *Partly automated*, an A or B feat's *Automated*", Object.entries(C.AUTOMATION_B6_E).every(([n, r]) => (r.level === "C") === (/(?:<em>|\*)(Automated|Partly automated|Not automated)/.exec(F[n].system.description)?.[1] === "Partly automated")));
  ok("A Pact Ascendant's card names Grave's Hand of the Reaper", /Grave:\*\*[^*]*Hand of the Reaper/.test(F["Pact Ascendant"].system.description.replace(/<\/?strong>/g, "**")));
  // FROM 0.10.0 Dragon Wings is built (Block 7).
  ok("A Pact Boon names Dragon Wings as built, and no longer says it waits", /Dragon Wings, a Grimoire spell \(0\.10\.0\)/.test(F["Pact Boon"].system.description) && !/Blocks 7–8/.test(F["Pact Boon"].system.description));
  ok("A the curly apostrophe is kept (Warlock’s Hex)", F["Warlock’s Hex"].name === "Warlock’s Hex");
  ok("A the cadence is printed, not enforced, and said so", ["Extra Bond", "High Sorcery", "Shadowed Grimoire"].every((n) => /Printed, not enforced/.test(F[n].system.description)));
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
{
  equal("B Ethereal Insight: Darkvision, and See Invisible innate once a day", [F["Ethereal Insight"].system.grantedAbilities, F["Ethereal Insight"].system.grantedSpells, fl("Ethereal Insight").grantInnate, fl("Ethereal Insight").grantedSpellUses], ["Darkvision", "See Invisible", true, { "See Invisible": "1" }]);
  equal("B Xithra Recovery: one extra use of Xithra, all restored by Refocus", F["Xithra Recovery"].effects.map((e) => [e.transfer, e.flags[SYS].focusExtraUses]), [[true, [{ value: 1, names: ["Xithra"], restoresAll: true }]]]);
  equal("B Symbiotic Witch: the conduit once a day", [F["Symbiotic Witch"].system.usesPerDay, F["Symbiotic Witch"].system.usesValue], ["1", 1]);
  equal("B the module's own flags are ea-prefixed", C.FEATS_B6_E.flatMap((f) => Object.keys(f.flags[SYS]).filter((k) => !["eaBlock", "eaBookLine", "eaAutomation", "grantInnate", "grantedSpellUses"].includes(k))), []);
  equal("B every Use is registered for a feat with an automation key, and back", Object.keys(auto.AUTOMATIONS_B6_E).every((n) => F[n]), true);
}

/* ----------------------------------------------------------------- */
/* C — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
{
  const pr = await quiet(() => import(sys("module", "prerequisites.mjs")));
  const known = new Set(["pact channeler", "pact boon"].map(pr.prerequisiteNameKey));
  equal("C Pact Boon: level 10 and Pact Channeler; Pact Ascendant: 16 and Pact Boon", [
    pr.meetsParseablePrerequisites(F["Pact Boon"].system.prerequisites, { level: 10, knownNames: known, ownedNames: new Set([pr.prerequisiteNameKey("Pact Channeler")]) }),
    pr.meetsParseablePrerequisites(F["Pact Boon"].system.prerequisites, { level: 10, knownNames: known, ownedNames: new Set() }),
    pr.meetsParseablePrerequisites(F["Pact Boon"].system.prerequisites, { level: 9, knownNames: known, ownedNames: new Set([pr.prerequisiteNameKey("Pact Channeler")]) }),
    pr.meetsParseablePrerequisites(F["Pact Ascendant"].system.prerequisites, { level: 16, knownNames: known, ownedNames: new Set([pr.prerequisiteNameKey("Pact Boon")]) })
  ], [true, false, false, true]);
  equal("C the level prerequisites parse: Xithra Cone at 10, not 9", [pr.meetsParseablePrerequisites(F["Xithra Cone"].system.prerequisites, { level: 10 }), pr.meetsParseablePrerequisites(F["Xithra Cone"].system.prerequisites, { level: 9 })], [true, false]);

  const fd = await import(sys("module", "focus-declarations.mjs"));
  const xithra = { name: "Xithra", system: { traits: "Attack, Focus, Magical, Mental" } };
  equal("C Xithra Recovery: the core counts one extra use for Xithra, none for another Focus spell", [fd.focusExtraUses(xithra, F["Xithra Recovery"].effects), fd.focusExtraUses({ name: "Gale Step", system: { traits: "Focus" } }, F["Xithra Recovery"].effects)], [1, 0]);

  capi.resetModuleRegistry();
  const api = new Proxy({}, { get: (_, k) => (typeof capi[k] === "function" ? (...a) => capi[k](...a) : () => {}) });
  auto.registerBlock6E(api, "test");
  const eu = await import(sys("module", "extra-uses.mjs"));
  equal("C Extra Communion: +1 Verdant Communion a copy, nothing else (G21)", [eu.extraUsesBonus(["Extra Communion"], "Verdant Communion"), eu.extraUsesBonus(["Extra Communion"], "Lay on Hands"), eu.extraUsesBonus([], "Verdant Communion")], [1, 0, 0]);
  ok("C the cost modifier, the prelude and the hex's step reach the core's registry", capi.registeredCastCostModifiers().some((r) => r.key === "hexmastery") && capi.registeredCastPreludes().length === 1 && Boolean(capi.registeredReactionStep(auto.HEX_STEP)));
  equal("C …with nothing the core refused", capi.registrationProblems(), []);
  const mm = await quiet(() => import(sys("module", "magic", "module-metamagic-workflow.mjs")));
  const witch = makeActor("ZZ Hex Witch", { items: [feat("Hex Mastery")] });
  const hex = { name: "Evil Eye", flags: { [SYS]: { eaHex: true } } };
  const paid = async (ctx) => (await mm.castCostDiscount({ actor: witch, spell: hex, innate: false, itemCast: false, cantrip: false, ...ctx })).payable;
  equal("C Hex Mastery through the core (G4): 3 PP → 2, 1 PP stays 1, an innate hex untouched, another spell untouched", [await paid({ totalPP: 3 }), await paid({ totalPP: 1 }), await paid({ totalPP: 3, innate: true }), await paid({ totalPP: 3, spell: { name: "Fireball", flags: {} } })], [2, 1, 3, 3]);
  capi.resetModuleRegistry();

  const dg = await import(sys("module", "combat", "death-guard.mjs"));
  const demonic = auto.ascendantPassive("demonic");
  const guards = dg.declaredDeathGuards([{ flags: { [SYS]: demonic.flags } }]);
  equal("C Pact Ascendant (Demonic): the core reads an automatic zero-HP guard, once a day, half HP, not on an outright kill (G7, Q141)", guards.map((g) => [g.label, g.auto, g.frequency, g.heal, g.notOutright, g.trigger ?? "zeroHp"]), [[auto.DEMONIC_GUARD_LABEL, true, "daily", "half", true, "zeroHp"]]);

  const cond = await quiet(() => import(sys("module", "conditionals.mjs")));
  const row = cond.normaliseConditional(auto.hexConditionals("Actor.W", -2)[0], { name: "Warlock’s Hex" }, 0);
  equal("C Warlock's Hex's row: a save the Warlock forced, not another's, not a skill; −2 circumstance", [cond.matchesCheck(row, { checkType: "save", sourceUuid: "Actor.W" }), cond.matchesCheck(row, { checkType: "save", sourceUuid: "Actor.Other" }), cond.matchesCheck(row, { checkType: "skill", sourceUuid: "Actor.W" }), row.value, row.type], [true, false, false, -2, "circumstance"]);

  const def = await quiet(() => import(sys("module", "defences.mjs")));
  const immOf = (pact, el) => def.resolveDefenceField(auto.ascendantPassive(pact, el).changes.map((c) => c.value).join(""));
  equal("C the immunities as the core reads them: Demonic fire, Fey and Void mental (trait and damage), Grave essence, Elemental water → cold", [[...immOf("demonic").damageTypes], [...immOf("fey").traits], [...immOf("void").damageTypes], [...immOf("grave").damageTypes], [...immOf("elemental", "water").damageTypes]], [["fire"], ["mental"], ["mental"], ["essence"], ["cold"]]);
  equal("C …Draconic: a fly base of 40, upgraded (not added)", auto.ascendantPassive("draconic").changes, [{ key: "system.combat.movement.fly.base", mode: 4, value: "40", priority: 20 }]);
  equal("C …an Elemental Pact with no element yet gives no effect", auto.ascendantPassive("elemental", ""), null);

  const ca = await quiet(() => import(sys("module", "creature-auras.mjs")));
  const a = ca.aurasOf([{ id: "f", name: "Pact Ascendant", type: "feat", flags: { [SYS]: { auras: auto.ascendantPassive("angelic").auras } } }], 16)[0];
  equal("C Pact Ascendant (Angelic): the core reads an ally aura of 10 ft with the fear rows", [a?.kind, a?.radius, a?.allyEffect?.conditionals?.length], ["ally", 10, 2]);
  const fear = cond.normaliseConditional(a.allyEffect.conditionals[0], { name: "Pact Ascendant" }, 0);
  ok("C …its row: advantage on a save against fear, not a skill", fear.kind === "advantage" && cond.matchesCheck(fear, { checkType: "save", traits: "Fear" }) && !cond.matchesCheck(fear, { checkType: "skill", traits: "Fear" }));

  const cp = await import(sys("module", "class-progression.mjs"));
  equal("C Q97: a Warlock's pool is Charisma once a tradition is set, 0 while blank", [cp.powerPointAbilityBonus({ tradition: "arcane", abilityTotal: 3 }), cp.powerPointAbilityBonus({ tradition: "", abilityTotal: 3 }), cp.powerPointMax(0, { pp: 0 }, 3)], [3, 0, 3]);
  equal("C Q98: a Nyrinn's −1 a level as printed, floored at 0 (level 5, Cha 3; level 2, Cha 3)", [cp.powerPointMax(-5, { pp: 0 }, 3), cp.powerPointMax(-2, { pp: 0 }, 3)], [0, 1]);
  equal("C …the Warlock's class table adds no PP", B4.WARLOCK.system.progression.map((r) => r.pp).every((p) => p === 0), true);
  ok("C the Warlock class card says the Charisma pool, not \"no PP pool\" (Q97, Q98)", /a pool of Charisma PP that your spells never spend/.test(B4.WARLOCK.system.description) && !/no PP pool/.test(B4.WARLOCK.system.description) && /Q98/.test(B4.WARLOCK.system.description));
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  const ember = { damageType: "fire", traditions: ["arcane", "divinity"] };
  equal("D Xithra's offer: mental; + the soul; + the element; no repeats", [auto.xithraOffer(), auto.xithraOffer({ soul: ember }), auto.xithraOffer({ soul: ember, element: "cold" }), auto.xithraOffer({ soul: ember, element: "fire" }), auto.xithraOffer({ element: "poison" })], [["mental"], ["mental", "fire"], ["mental", "fire", "cold"], ["mental", "fire"], ["mental"]]);
  const xs = JSON.parse(JSON.stringify(B4S.XITHRA.system));
  const p = auto.xithraPatch(xs, { spear: true, enhanced: true, types: ["mental", "fire", "cold"] });
  equal("D Xithra's patch: 60 ft, d8s throughout, the offer", [p["system.range"], p["system.damage.formula"], p["system.casterLevelMods"]?.[0]?.damageDice, p["system.effects"]], ["60 feet", "1d8", "1d8", [{ kind: "damageTypeChoice", damageTypes: ["mental", "fire", "cold"] }]]);
  equal("D …and nothing to write when it is right; back to 30 ft and d6", [Object.keys(auto.xithraPatch(xs, { spear: false, enhanced: false, types: ["mental"] })), auto.xithraPatch({ ...xs, range: "60 feet", damage: { formula: "1d8" } }, { types: ["mental"] })["system.range"], auto.xithraPatch({ ...xs, damage: { formula: "1d8" } }, { types: ["mental"] })["system.damage.formula"]], [[], "30 feet", "1d6"]);
  equal("D Xithra's dice by level: 1, 2 at 4th, 3 at 8th", [1, 3, 4, 8, 20].map(auto.xithraDiceCount), [1, 1, 2, 3, 6]);
  equal("D Hex Binders Curse's dice: none before 5th; 1d6, 2d6 at 10th, 3d6 at 15th, 4d6 at 20th", [4, 5, 9, 10, 15, 20].map(auto.curseDice), ["", "1d6", "1d6", "2d6", "3d6", "4d6"]);
  equal("D Warlock's Hex: −1, −2 from 10th; Cha rounds, at least 1", [auto.hexPenalty(9), auto.hexPenalty(10), auto.hexRounds(0), auto.hexRounds(4)], [-1, -2, 1, 4]);
  const T = { uuid: "Actor.T" };
  equal("D Warlock's Hex is asked after a spell's packet or area save, not a Strike, a curse, nothing, or oneself", [
    auto.hexWanted({ actor: T, amount: 3, sourceUuid: "Actor.W", context: { kind: "spell" } }), auto.hexWanted({ actor: T, amount: 3, sourceUuid: "Actor.W", context: { kind: "areaSave" } }),
    auto.hexWanted({ actor: T, amount: 3, sourceUuid: "Actor.W", context: { kind: "strike" } }), auto.hexWanted({ actor: T, amount: 3, sourceUuid: "Actor.W", context: { kind: "hexBindersCurse" } }),
    auto.hexWanted({ actor: T, amount: 0, sourceUuid: "Actor.W", context: { kind: "spell" } }), auto.hexWanted({ actor: T, amount: 3, sourceUuid: "", context: { kind: "spell" } }),
    auto.hexWanted({ actor: { uuid: "Actor.W" }, amount: 3, sourceUuid: "Actor.W", context: { kind: "spell" } })
  ], [true, true, false, false, false, false, false]);
  equal("D Hex Binders Curse answers a Strike or a spell, never recurring damage (no source) or its own dice", [
    auto.curseWanted({ amount: 2, sourceUuid: "x", context: { kind: "strike" } }), auto.curseWanted({ amount: 2, sourceUuid: "x", context: { kind: "spell" } }),
    auto.curseWanted({ amount: 2, sourceUuid: "", context: null }), auto.curseWanted({ amount: 2, sourceUuid: "x", context: { kind: "hexBindersCurse" } })
  ], [true, true, false, false]);
  equal("D the blow's type: the payload's damage types, else the Strike's", [auto.blowType({ damageTypes: ["Fire"] }), auto.blowType({ context: { damageType: "slashing" } }), auto.blowType({})], ["fire", "slashing", ""]);
  equal("D Malevolent Blast (Q136): Failure or worse 1, 2 on a critical; a Partial or better nothing", [["failure", false], ["fumble", true], ["blunder", false], ["partial", true], ["success", false]].map(([d, c]) => auto.malevolentStun(d, c)), [1, 2, 1, 0, 0]);
  const e = (tradition, ppCost, extra = {}) => ({ name: "S", system: { tradition, ppCost, traits: "", ...extra }, flags: {} });
  equal("D Forbidden Lore: Arcane or Divinity, PP ≤ CL + 1; not Verdant, a cantrip, a specialist spell or a hex", [auto.forbiddenLoreMay(e("arcane", 11), 10), auto.forbiddenLoreMay(e("divinity", 12), 10), auto.forbiddenLoreMay(e("verdant", 2), 10), auto.forbiddenLoreMay(e("arcane", 0, { traits: "Cantrip" }), 10), auto.forbiddenLoreMay(e("arcane", 2, { specialist: true }), 10), auto.forbiddenLoreMay({ ...e("arcane", 2), flags: { [SYS]: { eaHex: true } } }, 10)], [true, false, false, false, false, false]);
  equal("D High Sorcery: a Witch's Ethereal or Verdant; a Sorcerer's any; PP ≤ CL + 1", [auto.highSorceryMay(e("ethereal", 3), { cls: "witch", cl: 4 }), auto.highSorceryMay(e("arcane", 3), { cls: "witch", cl: 4 }), auto.highSorceryMay(e("arcane", 5), { cls: "sorcerer", cl: 4 }), auto.highSorceryMay(e("arcane", 6), { cls: "sorcerer", cl: 4 }), auto.highSorceryMay(e("arcane", 3), { cls: "wizard", cl: 4 })], [true, false, true, false, false]);
  equal("D Ritual of Borrowed Power: any tradition, PP ≤ CL + 1", [auto.borrowedMay(e("divinity", 9), 8), auto.borrowedMay(e("divinity", 10), 8)], [true, false]);
  equal("D Soul-Bound Grimoire: Ethereal or Verdant scrolls only", [auto.grimoireScrollOk("ethereal"), auto.grimoireScrollOk("arcane, verdant"), auto.grimoireScrollOk("arcane")], [true, true, false]);
  equal("D Symbiotic Witch: base PP 4 or less", [auto.conduitAllows({ type: "spell", system: { ppCost: 4 } }), auto.conduitAllows({ type: "spell", system: { ppCost: 5 } }), auto.conduitAllows({ type: "feat", system: { ppCost: 1 } })], [true, false, false]);
  equal("D Q99: the Highmagic trait for a Witch's spell outside Ethereal and Verdant", [auto.witchNeedsHighmagic("witch", "arcane"), auto.witchNeedsHighmagic("witch", "arcane, verdant"), auto.witchNeedsHighmagic("sorcerer", "arcane")], [true, false, false]);
  const copy = auto.repertoireCopy({ _id: "x", name: "Fireball", system: { traits: "Fire" }, flags: {} }, { source: { id: "f1", name: "Forbidden Lore" }, highMagic: true, flags: { eaPick: { feat: "f1" } } });
  equal("D the copy: no id, prepared, Highmagic added, granted by the feat, the module's pick", [copy._id, copy.system.prepared, copy.system.traits, copy.flags[SYS].grantedBy.sourceId, copy.flags[MOD].eaPick.feat], [undefined, true, "Fire, Highmagic", "f1", "f1"]);
  equal("D Extra Bond's offer leaves out what is taken", auto.extraBondOptions(["will", "hp"]).map((b) => b.key).includes("will") || auto.extraBondOptions(["will", "hp"]).map((b) => b.key).includes("hp"), false);
  equal("D the pact tables: Boon and Ascendant by the book", [auto.BOON_SPELL, auto.ASCENDANT_SPELL], [
    { angelic: "Restoration", demonic: "Fireball", draconic: "Dragon Wings", elemental: "Conjure Elemental", fey: "Confusion", grave: "Create Undead", void: "Long Sense" },
    { angelic: "Resurrection", demonic: "", draconic: "Shape Of The Wyrm", elemental: "Conjure Elemental", fey: "Dominate", grave: "Hand Of The Reaper", void: "Maze" }]);
  equal("D the element map, the burst, the reaches", [auto.ELEMENT_DAMAGE, auto.DEMONIC_BURST.dice, auto.DEMONIC_BURST.radiusFeet, auto.XITHRA_CONE_FEET, auto.CURSE_FEET, auto.CONDUIT_MAX_PP], [{ air: "electricity", earth: "acid", fire: "fire", water: "cold" }, "10d6", 20, 30, 30, 4]);
  equal("D the pact read off the archetype feat", [auto.pactKeyOf({ items: [{ type: "feat", name: "Grave Pact" }] }), auto.pactKeyOf({ items: [{ type: "feat", name: "Pact Boon" }] })], ["grave", ""]);
  equal("D Hex Mastery: a learned hex only, with the feat", [auto.hexMasteryModifier({ actor: { items: [{ type: "feat", name: "Hex Mastery" }] }, spell: { flags: { [SYS]: { eaHex: true } } } })?.ppDelta, auto.hexMasteryModifier({ actor: { items: [] }, spell: { flags: { [SYS]: { eaHex: true } } } }), auto.hexMasteryModifier({ actor: { items: [{ type: "feat", name: "Hex Mastery" }] }, spell: { flags: { [SYS]: { eaHex: true } } }, itemCast: true })], [-1, null, null]);
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side, with fakes                                    */
/* ----------------------------------------------------------------- */
const spellsPack = (docs) => ({ collection: "trg-prime.spells", documentName: "Item", metadata: {}, getIndex: async () => new Map(docs.map((d) => [d._id, d])), getDocument: async (id) => { const d = docs.find((x) => x._id === id); return d ? { ...d, toObject: () => JSON.parse(JSON.stringify(d)) } : null; } });
const INDEX = [
  { _id: "fb", type: "spell", name: "Fireball", system: { tradition: "arcane, verdant", ppCost: 6, traits: "Fire, Invocation" }, flags: {} },
  { _id: "rs", type: "spell", name: "Restoration", system: { tradition: "divinity", ppCost: 2, traits: "Healing" }, flags: {} },
  { _id: "rz", type: "spell", name: "Resurrection", system: { tradition: "divinity", ppCost: 12, traits: "Healing" }, flags: {} },
  { _id: "cu", type: "spell", name: "Create Undead", system: { tradition: "divinity, ethereal", ppCost: 4, traits: "Necromancy" }, flags: {} },
  { _id: "ce", type: "spell", name: "Conjure Elemental", system: { tradition: "arcane, verdant", ppCost: 4, traits: "Translocation" }, flags: {} },
  { _id: "si", type: "spell", name: "See Invisible", system: { tradition: "arcane, divinity, ethereal", ppCost: 4, traits: "Insight" }, flags: {} },
  { _id: "en", type: "spell", name: "Entangle", system: { tradition: "verdant", ppCost: 1, traits: "Plant" }, flags: {} },
  { _id: "bo", type: "spell", name: "Bolt", system: { tradition: "arcane", ppCost: 2, traits: "Evocation" }, flags: {} },
  { _id: "ca", type: "spell", name: "Spark", system: { tradition: "arcane", ppCost: 0, traits: "Cantrip" }, flags: {} }
];
game.packs = [spellsPack(INDEX)];
const reset = () => { cards.length = 0; answers.length = 0; confirms.length = 0; asked.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; game.user.targets = new Set(); canvas.tokens.placeables = []; };
const soulItem = (i = 2) => ({ ...JSON.parse(JSON.stringify(B4.BONDED_SOULS[i])), type: "ability" });
const xithraItem = () => ({ ...JSON.parse(JSON.stringify(B4S.XITHRA)), type: "spell", system: { ...JSON.parse(JSON.stringify(B4S.XITHRA.system)), usesValue: 1 } });
const warlockClass = () => ({ ...JSON.parse(JSON.stringify(B4.WARLOCK)), type: "class" });
const witchClass = () => ({ type: "class", name: "Witch", system: {}, flags: {} });
const X = (a) => a.items.find((i) => i.flags?.[SYS]?.eaXithra);
{
  // Q97: the soul's arrival asks the tradition when the sheet is blank, and writes it.
  reset();
  const wl = makeActor("ZZ Pool Warlock", { items: [warlockClass(), xithraItem()] });
  answers.push("verdant");
  const [soul] = await wl.createEmbeddedDocuments("Item", [soulItem(2)]);
  await auto4.onItemCreatedB4(soul);
  equal("F Q97: a tradition not the soul's is not written", wl.system.magic.tradition, "");
  answers.push("divinity");
  await auto4.onItemCreatedB4(soul);
  equal("F Q97: the Emberlord's arrival offers its two traditions, and writes the one chosen", [helpers.lastOptions?.map((o) => o[0]), wl.system.magic.tradition], [["arcane", "divinity"], "divinity"]);
  answers.push("arcane");
  await auto4.onItemCreatedB4(soul);
  equal("F …asked no more once the sheet names one", [wl.system.magic.tradition, answers.length], ["divinity", 1]);
  answers.length = 0;
  const blank = makeActor("ZZ Old Warlock", { level: 1, items: [warlockClass(), soulItem(6)] });
  for (const [slot, n] of [["spell", 1], ["cantrip", 2]]) for (let i = 0; i < n; i += 1) blank.items.push(makeItem({ type: "spell", name: `${slot}${i}`, system: {}, flags: { [MOD]: { warlockPick: slot } } }, blank));
  answers.push("ethereal");
  await auto4.AUTOMATIONS_B4["The Void Seer"].use(blank, blank.items[1]);
  equal("F …a soul chosen before 0.9.0: its Use asks, even with every pick made", blank.system.magic.tradition, "ethereal");
  const notWl = makeActor("ZZ Pool Witch", { items: [witchClass()] });
  equal("F …only a Warlock", auto4.warlockTraditionOwed(notWl, { traditions: ["arcane"] }), false);

  // The Xithra sync.
  reset();
  const xa = makeActor("ZZ Xithra", { items: [warlockClass(), xithraItem(), soulItem(2)] });
  const [spear] = await xa.createEmbeddedDocuments("Item", [feat("Xithra Spear")]);
  await auto.onItemCreatedB6E(spear);
  const [enh] = await xa.createEmbeddedDocuments("Item", [feat("Enhanced Blast")]);
  await auto.onItemCreatedB6E(enh);
  equal("F Xithra Spear and Enhanced Blast: 60 ft, d8 base and per level, the soul's offer kept", [X(xa).system.range, X(xa).system.damage.formula, X(xa).system.casterLevelMods[0].damageDice, X(xa).system.effects], ["60 feet", "1d8", "1d8", [{ kind: "damageTypeChoice", damageTypes: ["mental", "fire"] }]]);
  const [blast] = await xa.createEmbeddedDocuments("Item", [feat("Elemental Blast")]);
  answers.push("cold");
  await auto.AUTOMATIONS_B6_E["Elemental Blast"].use(xa, blast);
  equal("F Elemental Blast's Use: the element joins Xithra's offer", X(xa).system.effects, [{ kind: "damageTypeChoice", damageTypes: ["mental", "fire", "cold"] }]);
  answers.push("sonic");
  await auto.onDailyPreparationB6E({ actor: xa });
  equal("F …asked again at daily preparation", X(xa).system.effects[0].damageTypes, ["mental", "fire", "sonic"]);
  answers.push("poison");
  await auto.AUTOMATIONS_B6_E["Elemental Blast"].use(xa, blast);
  equal("F …poison is not one of the five", X(xa).system.effects[0].damageTypes, ["mental", "fire", "sonic"]);
  xa.items.splice(xa.items.indexOf(spear), 1);
  await auto.onItemDeletedB6E(spear);
  xa.items.splice(xa.items.indexOf(enh), 1);
  await auto.onItemDeletedB6E(enh);
  equal("F …the feats' leaving puts Xithra back: 30 ft, d6", [X(xa).system.range, X(xa).system.damage.formula, X(xa).system.casterLevelMods[0].damageDice], ["30 feet", "1d6", "1d6"]);

  // Warding Sigil.
  reset();
  const [sigil] = await xa.createEmbeddedDocuments("Item", [{ ...feat("Warding Sigil"), system: { ...feat("Warding Sigil").system, usesValue: 1 } }]);
  game.combat = { started: true, id: "c1", round: 2, turn: 0, combatants: [{ actor: xa, actorId: xa.id }], turns: [{ actor: xa, actorId: xa.id }] };
  game.combat.combatant = game.combat.turns[0];
  await auto.AUTOMATIONS_B6_E["Warding Sigil"].use(xa, sigil);
  const ward = xa.effects.find((e2) => e2.flags[MOD]?.source === "wardingSigil");
  equal("F Warding Sigil: 1 AP, its Focus use, resistance to Xithra's types until the end of the next turn", [xa.system.resources.ap.value, sigil.system.usesValue, ward?.changes, Boolean(ward?.flags?.[MOD]?.endsAfterTurn)], [2, 0, [{ key: "system.combat.resistances", mode: 2, value: ", mental, fire, sonic", priority: 20 }], true]);
  await auto.AUTOMATIONS_B6_E["Warding Sigil"].use(xa, sigil);
  ok("F …once until Refocus", /Focus use is spent/.test(cards.at(-1)?.warn ?? "") && xa.system.resources.ap.value === 2);
  game.combat = null;

  // Xithra Cone.
  reset();
  const cw = makeActor("ZZ Cone", { level: 10, cha: 4, items: [warlockClass(), xithraItem(), soulItem(2), feat("Enhanced Blast")] });
  equal("F Xithra Cone: no prelude without the feat", await auto.xithraConePrelude({ actor: cw, spell: X(cw) }), null);
  cw.items.push(makeItem(feat("Xithra Cone"), cw));
  answers.push("bolt");
  equal("F …the bolt is the core's cast", await auto.xithraConePrelude({ actor: cw, spell: X(cw) }), null);
  const o1 = makeActor("ZZ Orc 1"), o2 = makeActor("ZZ Orc 2");
  game.user.targets = new Set([makeToken("t1", o1), makeToken("t2", o2)]);
  answers.push("cone", "fire");
  const out = await auto.xithraConePrelude({ actor: cw, spell: X(cw) });
  equal("F …the cone: one roll (3d8 + Cha at 10th), a basic Reflex for each target at the innate DC, the type chosen, the Focus use spent", [out?.handled, calls.rolls.at(-1), calls.saves.map((s) => [s.target, s.save, s.dc, s.amount, s.type, s.caster]), X(cw).system.usesValue], [true, "3d8 + 4", [["ZZ Orc 1", "reflex", 24, 28, "fire", "ZZ Cone"], ["ZZ Orc 2", "reflex", 24, 28, "fire", "ZZ Cone"]], 0]);
  answers.push("cone");
  await auto.xithraConePrelude({ actor: cw, spell: X(cw) });
  ok("F …refused with Xithra's use spent", /Focus use is spent/.test(cards.at(-1)?.warn ?? "") && calls.saves.length === 2);
  X(cw).system.usesValue = 1; game.user.targets = new Set(); answers.push("cone");
  await auto.xithraConePrelude({ actor: cw, spell: X(cw) });
  ok("F …and with nothing targeted", /target the creatures/.test(cards.at(-1)?.warn ?? "") && X(cw).system.usesValue === 1);

  // Warlock's Hex.
  reset();
  const hw = makeActor("ZZ Hexer", { level: 10, cha: 3, pp: 2, items: [warlockClass(), { ...feat("Warlock’s Hex"), system: { ...feat("Warlock’s Hex").system, usesValue: 1 } }] });
  const foe = makeActor("ZZ Foe");
  await auto.onDamageAppliedB6E({ actor: foe, amount: 5, sourceUuid: hw.uuid, context: { kind: "spell", spellName: "Xithra" } });
  const hx = foe.effects.find((e2) => e2.flags[MOD]?.source === "warlocksHex");
  equal("F Warlock's Hex: asked of the Warlock after its spell's damage; 1 PP and the use; −2 at 10th on saves against it, Cha rounds", [asked.length, hw.system.resources.pp.value, hw.items[1].system.usesValue, hx?.flags?.[SYS]?.conditionals?.[0]?.value, hx?.flags?.[SYS]?.conditionals?.[0]?.when?.sourceUuids, hx?.flags?.[SYS]?.spellEffectEnd], [1, 1, 0, -2, [hw.uuid], 18]);
  await auto.onDamageAppliedB6E({ actor: foe, amount: 5, sourceUuid: hw.uuid, context: { kind: "spell", spellName: "Bolt" } });
  equal("F …not asked again with the use spent", asked.length, 1);
  hw.items[1].system.usesValue = 1; hw.system.resources.pp.value = 0;
  await auto.onDamageAppliedB6E({ actor: foe, amount: 5, sourceUuid: hw.uuid, context: { kind: "spell", spellName: "Zap" } });
  equal("F …nor at 0 PP", asked.length, 1);
  hw.system.resources.pp.value = 3;
  await auto.onDamageAppliedB6E({ actor: foe, amount: 5, sourceUuid: hw.uuid, context: { kind: "strike", weaponName: "Dagger" } });
  equal("F …nor after a Strike", asked.length, 1);
  const foe2 = makeActor("ZZ Foe 2");
  await auto.onDamageAppliedB6E({ actor: foe2, amount: 5, sourceUuid: hw.uuid, context: { kind: "areaSave", label: "Xithra Cone" } });
  await auto.onDamageAppliedB6E({ actor: foe2, amount: 2, sourceUuid: hw.uuid, context: { kind: "areaSave", label: "Xithra Cone" } });
  equal("F …after Xithra Cone's save, once a blow (two packets)", asked.length, 2);
  const foe4 = makeActor("ZZ Foe 4");
  hw.items[1].system.usesValue = 1; reactorAnswers.push("no");
  await auto.onDamageAppliedB6E({ actor: foe4, amount: 5, sourceUuid: hw.uuid, context: { kind: "spell", spellName: "Bolt" } });
  await auto.onDamageAppliedB6E({ actor: foe4, amount: 1, sourceUuid: hw.uuid, context: { kind: "spell", spellName: "Bolt" } });
  equal("F …declined, the same blow's next packet does not ask again", asked.length, 3);
  const low = makeActor("ZZ Low Hexer", { level: 4, cha: 0, pp: 2, items: [{ ...feat("Warlock’s Hex"), system: { ...feat("Warlock’s Hex").system, usesValue: 1 } }] });
  game.combat = { started: true, id: "c2", round: 3, combatants: [], turns: [] };
  await auto.onDamageAppliedB6E({ actor: foe2, amount: 5, sourceUuid: low.uuid, context: { kind: "spell", spellName: "Bolt" } });
  const lx = foe2.effects.find((e2) => e2.flags[MOD]?.hexer === low.uuid);
  equal("F …below 10th −1, at least 1 round (Cha 0), the combat round stamped", [lx?.flags?.[SYS]?.conditionals?.[0]?.value, lx?.flags?.[SYS]?.conditionExpiresRound], [-1, 4]);
  game.combat = null;
  reactorAnswers.push("no");
  const foe3 = makeActor("ZZ Foe 3");
  hw.items[1].system.usesValue = 1;
  await auto.onDamageAppliedB6E({ actor: foe3, amount: 5, sourceUuid: hw.uuid, context: { kind: "spell", spellName: "Bolt" } });
  equal("F …declined, nothing is spent", [hw.items[1].system.usesValue, foe3.effects.length], [1, 0]);

  // Hex Binders Curse.
  reset();
  const cu = makeActor("ZZ Curser", { level: 10, items: [{ ...feat("Hex Binders Curse") }, { type: "spell", name: "Ray", system: { damage: { type: "cold" } }, flags: {} }] });
  const me = makeToken("me", cu, { x: 0, y: 0, disposition: 1 });
  const v1 = makeActor("ZZ Victim"), v2 = makeActor("ZZ Victim 2"), pal = makeActor("ZZ Pal");
  const t1 = makeToken("v1", v1, { x: 200, y: 0, disposition: -1 }), t2 = makeToken("v2", v2, { x: 300, y: 0, disposition: -1 }), tp = makeToken("pal", pal, { x: 100, y: 0, disposition: 1 });
  const far = makeActor("ZZ Far"); const tf = makeToken("far", far, { x: 2000, y: 0, disposition: -1 });
  canvas.tokens.placeables = [me, t1, t2, tp, tf];
  game.user.targets = new Set([tp]);
  await auto.AUTOMATIONS_B6_E["Hex Binders Curse"].use(cu, cu.items[0]);
  ok("F Hex Binders Curse: not an ally", /not an ally/.test(cards.at(-1)?.warn ?? ""));
  game.user.targets = new Set([tf]);
  await auto.AUTOMATIONS_B6_E["Hex Binders Curse"].use(cu, cu.items[0]);
  ok("F …not beyond 30 feet", /30 at most/.test(cards.at(-1)?.warn ?? ""));
  game.user.targets = new Set([t1]);
  game.combat = { started: true, id: "c3", round: 1, turn: 0, combatants: [{ actor: cu, actorId: cu.id }], turns: [] };
  await auto.AUTOMATIONS_B6_E["Hex Binders Curse"].use(cu, cu.items[0]);
  equal("F …a curse on the targeted enemy, 1 AP, the Concentrate gate asked", [v1.effects.length, cu.effects.filter((x) => x.flags[MOD]?.source === "hexBindersCurse").map((x) => x.flags[MOD].targetUuid), cu.getFlag(MOD, "hexCurse")?.targetUuid, cu.system.resources.ap.value, calls.gate.at(-1)?.traits], [0, [v1.uuid], v1.uuid, 2, "Concentrate, Warlock, Witch"]);
  game.combat = null;
  await auto.onDamageAppliedB6E({ actor: v1, amount: 6, sourceUuid: cu.uuid, damageTypes: ["slashing"], context: { kind: "strike", weaponName: "Sword" } });
  await auto.onDamageAppliedB6E({ actor: v1, amount: 2, sourceUuid: cu.uuid, damageTypes: ["fire"], context: { kind: "strike", weaponName: "Sword" } });
  equal("F …a Strike that damages it adds 2d6 at 10th, of the blow's type, once a Strike, named as the curse", calls.damage.map((d) => [d.target, d.amount, d.type, d.context.kind, d.sourceUuid]), [["ZZ Victim", 12, "slashing", "hexBindersCurse", cu.uuid]]);
  await auto.onDamageAppliedB6E({ actor: v1, amount: 12, sourceUuid: cu.uuid, context: { kind: "hexBindersCurse" } });
  equal("F …its own dice do not trigger it", calls.damage.length, 1);
  await auto.onDamageAppliedB6E({ actor: v1, amount: 3, sourceUuid: cu.uuid, context: { kind: "spell", spellName: "Ray" } });
  equal("F …a spell's packet with no type: the spell's own type", calls.damage.at(-1)?.type, "cold");
  await auto.onDamageAppliedB6E({ actor: v2, amount: 3, sourceUuid: cu.uuid, damageTypes: ["fire"], context: { kind: "strike", weaponName: "Axe" } });
  equal("F …another creature is not cursed", calls.damage.length, 2);
  game.user.targets = new Set([t2]);
  await auto.AUTOMATIONS_B6_E["Hex Binders Curse"].use(cu, cu.items[0]);
  equal("F …cursing another lifts the first, on the curser's own sheet (nothing on either target)", [cu.effects.filter((x) => x.flags[MOD]?.source === "hexBindersCurse").map((x) => x.flags[MOD].targetUuid), v1.effects.length + v2.effects.length, cu.getFlag(MOD, "hexCurse")?.targetUuid], [[v2.uuid], 0, v2.uuid]);
  await auto.onDailyPreparationB6E({ actor: cu });
  equal("F …daily preparation ends it, marker and all", [cu.getFlag(MOD, "hexCurse"), cu.effects.filter((x) => x.flags[MOD]?.source === "hexBindersCurse").length], [undefined, 0]);
  await auto.onDamageAppliedB6E({ actor: v2, amount: 3, sourceUuid: cu.uuid, damageTypes: ["fire"], context: { kind: "strike", weaponName: "Mace" } });
  equal("F …and no more dice", calls.damage.length, 2);
  gateAllows = false; game.user.targets = new Set([t1]);
  equal("F …a trait gate that refuses stops it", await auto.AUTOMATIONS_B6_E["Hex Binders Curse"].use(cu, cu.items[0]), false);
  gateAllows = true;

  // The picks.
  reset();
  const wi = makeActor("ZZ Witch", { level: 10, cl: 5, items: [witchClass(), feat("Forbidden Lore"), feat("High Sorcery"), feat("Ritual of Borrowed Power")] });
  answers.push("fb|trg-prime.spells");
  await auto.AUTOMATIONS_B6_E["Forbidden Lore"].use(wi, wi.items[1]);
  equal("F Forbidden Lore offers Arcane and Divinity spells to CL + 1 only", helpers.lastOptions.map((o) => o[1]), ["Bolt (PP 2)", "Conjure Elemental (PP 4)", "Create Undead (PP 4)", "Fireball (PP 6)", "Restoration (PP 2)", "See Invisible (PP 4)"]);
  const fbCopy = wi.items.find((i) => i.name === "Fireball");
  equal("F …the copy: High Magic, outside the picks, granted by the feat", [fbCopy?.system?.traits, fbCopy?.flags?.[MOD]?.eaPick?.kind, fbCopy?.flags?.[SYS]?.grantedBy?.sourceId], ["Fire, Invocation, Highmagic", "forbiddenLore", wi.items[1].id]);
  answers.push("bo|trg-prime.spells");
  await auto.AUTOMATIONS_B6_E["Forbidden Lore"].use(wi, wi.items[1]);
  answers.length = 0;
  equal("F …a single spell", wi.items.filter((i) => i.flags?.[MOD]?.eaPick?.kind === "forbiddenLore").length, 1);
  answers.push("en|trg-prime.spells");
  await auto.AUTOMATIONS_B6_E["High Sorcery"].use(wi, wi.items[2]);
  equal("F High Sorcery: a Witch's Ethereal and Verdant spells, no Highmagic added (already High Magic)", [helpers.lastOptions.map((o) => o[1]), wi.items.find((i) => i.name === "Entangle")?.system?.traits], [["Conjure Elemental (PP 4)", "Create Undead (PP 4)", "Entangle (PP 1)", "See Invisible (PP 4)"], "Plant"]);
  answers.push("rs|trg-prime.spells");
  await auto.onDailyPreparationB6E({ actor: wi });
  equal("F Ritual of Borrowed Power: today's spell, any tradition, with Highmagic", wi.items.filter((i) => i.flags?.[MOD]?.eaBorrowed).map((i) => [i.name, /Highmagic/.test(i.system.traits)]), [["Restoration", true]]);
  answers.push("bo|trg-prime.spells");
  await auto.onDailyPreparationB6E({ actor: wi });
  equal("F …replaced at the next preparation", wi.items.filter((i) => i.flags?.[MOD]?.eaBorrowed).map((i) => i.name), ["Bolt"]);

  reset();
  const sg = makeActor("ZZ Grimoire", { level: 3, items: [warlockClass(), soulItem(2), feat("Shadowed Grimoire")] });
  answers.push("bo|trg-prime.spells");
  await auto.AUTOMATIONS_B6_E["Shadowed Grimoire"].use(sg, sg.items[2]);
  const pick = sg.items.find((i) => i.name === "Bolt");
  equal("F Shadowed Grimoire: the soul's traditions, PP ≤ level + 1; innate, Focus, Charisma", [helpers.lastOptions.map((o) => o[1]), pick?.system?.innate, /Focus/.test(pick?.system?.traits), pick?.flags?.[SYS]?.castingAbilityOverride, pick?.flags?.[MOD]?.eaPick?.level], [["Bolt (PP 2)", "Conjure Elemental (PP 4)", "Create Undead (PP 4)", "Restoration (PP 2)", "See Invisible (PP 4)"], true, true, "charisma", 3]);
  await auto.AUTOMATIONS_B6_E["Shadowed Grimoire"].use(sg, sg.items[2]);
  ok("F …no swap at the same level", /once you gain a level/.test(JSON.stringify(cards.at(-1))));
  sg.system.identity.level = 4; confirms.push(true); answers.push("rs|trg-prime.spells");
  await auto.AUTOMATIONS_B6_E["Shadowed Grimoire"].use(sg, sg.items[2]);
  equal("F …after a level, the swap", sg.items.filter((i) => i.flags?.[MOD]?.eaPick?.kind === "shadowedGrimoire").map((i) => [i.name, i.flags[MOD].eaPick.level]), [["Restoration", 4]]);

  // Pact Boon and Pact Ascendant.
  reset();
  const pw = makeActor("ZZ Pact Warlock", { level: 16, items: [warlockClass(), { type: "feat", name: "Demonic Pact", system: {}, flags: {} }] });
  const [boon] = await pw.createEmbeddedDocuments("Item", [feat("Pact Boon")]);
  await auto.onItemCreatedB6E(boon);
  const fire = pw.items.find((i) => i.name === "Fireball");
  equal("F Pact Boon (Demonic): Fireball, the Warlock's innate Focus copy", [fire?.system?.innate, /Focus/.test(fire?.system?.traits), fire?.flags?.[SYS]?.castingAbilityOverride], [true, true, "charisma"]);
  const [asc] = await pw.createEmbeddedDocuments("Item", [feat("Pact Ascendant")]);
  await auto.onItemCreatedB6E(asc);
  const ascFx = pw.effects.find((x) => x.flags?.[SYS]?.featSource === asc.id);
  equal("F Pact Ascendant (Demonic): fire immunity and the guard on the feat's effect; no spell", [ascFx?.changes, ascFx?.flags?.[SYS]?.deathGuard?.heal, pw.items.filter((i) => i.type === "spell").length], [[{ key: "system.combat.immunities", mode: 2, value: ", fire", priority: 20 }], "half", 1]);
  const wt = makeActor("ZZ Pact Witch", { level: 16, cl: 16, items: [witchClass(), { type: "feat", name: "Angelic Pact", system: {}, flags: {} }] });
  const [asc2] = await wt.createEmbeddedDocuments("Item", [feat("Pact Ascendant")]);
  await auto.onItemCreatedB6E(asc2);
  const rez = wt.items.find((i) => i.name === "Resurrection");
  equal("F Pact Ascendant (Angelic) for a Witch: the aura on the feat, Resurrection in her repertoire as High Magic (Q99)", [asc2.flags[SYS].auras?.[0]?.radius, rez?.system?.innate, rez?.system?.traits], [10, undefined, "Healing, Highmagic"]);
  // GRAHAM'S RULING OF 4 NOVEMBER 2026 ("All Witch spells are considered to be
  // High Magic"): the real Witch class makes the Pact spell High Magic by
  // itself — the Q99 trait is kept beside it (a pre-0.9.1 class on a sheet).
  {
    const hm = await import(sys("module", "magic", "high-magic.mjs"));
    const B3 = await import(new URL("./content/block3.mjs", import.meta.url));
    const real = { items: [B3.WITCH], system: { magic: { tradition: "ethereal" } } };
    equal("F …and by her class alone (ruling of 4 Nov 2026): Resurrection with the trait stripped, Pact Boon's Fireball, Ritual of Borrowed Power's arcane pick",
      [hm.highMagicCast(real, { tradition: rez?.system?.tradition ?? "divinity", traits: "Healing" }).highMagic, hm.highMagicCast(real, { tradition: "arcane", traits: "Fire, Save" }).highMagic, hm.highMagicCast(real, { tradition: "arcane" }).source], [true, true, "caster"]);
  }
  // FROM 0.10.0: the built Dragon Wings (Block 7) is in the packs, for this case only.
  game.packs = [spellsPack([...INDEX, (await import(new URL("./content/block7-spells.mjs", import.meta.url))).SPELLS_B7.find((d) => d.name === "Dragon Wings")])];
  const dr = makeActor("ZZ Draconic", { level: 16, items: [witchClass(), { type: "feat", name: "Draconic Pact", system: {}, flags: {} }] });
  const [boon3] = await dr.createEmbeddedDocuments("Item", [feat("Pact Boon")]);
  await auto.onItemCreatedB6E(boon3);
  // FROM 0.10.0 (Block 7): the built Dragon Wings is granted, and no card says it waits.
  ok("F Pact Boon (Draconic): the built Dragon Wings joins her repertoire, and no card says Blocks 7–8", !/Blocks 7–8/.test(JSON.stringify(cards)) && dr.items.some((i) => i.type === "spell" && i.name === "Dragon Wings" && i.flags?.[SYS]?.eaGrimoire === "dragonWings"));
  game.packs = [spellsPack(INDEX)];
  const el = makeActor("ZZ Elemental", { level: 16, items: [witchClass(), { type: "feat", name: "Elemental Pact", system: {}, flags: { [SYS]: { eaElement: "earth" } } }] });
  const [asc3] = await el.createEmbeddedDocuments("Item", [feat("Pact Ascendant")]);
  await auto.onItemCreatedB6E(asc3);
  equal("F Pact Ascendant (Elemental): the pact's element read (earth → acid), Conjure Elemental with its note", [el.effects.find((x) => x.flags?.[SYS]?.featSource === asc3.id)?.changes?.[0]?.value, el.items.some((i) => i.name === "Conjure Elemental"), /your element only/i.test(JSON.stringify(cards))], [", acid", true, true]);
  const nop = makeActor("ZZ No Pact", { level: 16, items: [witchClass()] });
  equal("F …with no pact, nothing", await auto.AUTOMATIONS_B6_E["Pact Boon"].use(nop, makeItem(feat("Pact Boon"), nop)), false);

  // The Demonic burst.
  reset();
  const dm = makeActor("ZZ Demon", { level: 16 });
  const dmt = makeToken("dm", dm, { x: 0, y: 0 });
  const near = makeActor("ZZ Near Ally"), farA = makeActor("ZZ Far Foe");
  canvas.tokens.placeables = [dmt, makeToken("n", near, { x: 400, y: 0, disposition: 1 }), makeToken("f", farA, { x: 600, y: 0, disposition: -1 })];
  await auto.onDeathGuardHeldB6E({ actor: dm, label: "Some other guard" });
  equal("F the burst answers only its own guard", calls.saves.length, 0);
  await auto.onDeathGuardHeldB6E({ actor: dm, label: auto.DEMONIC_GUARD_LABEL, trigger: "zeroHp" });
  equal("F Pact Ascendant (Demonic): 10d6 fire once, basic Reflex at the Level DC for everyone within 20 ft, allies too, not the caster", [calls.rolls.at(-1), calls.saves.map((s) => [s.target, s.save, s.dc, s.amount, s.type])], ["10d6", [["ZZ Near Ally", "reflex", 26, 60, "fire"]]]);

  // Malevolent Blast.
  reset();
  const mb = makeActor("ZZ Malevolent", { level: 6, cha: 4, items: [{ ...feat("Malevolent Blast"), system: { ...feat("Malevolent Blast").system, usesValue: 1 } }] });
  const vic = makeActor("ZZ Struck");
  checkDegree = "failure";
  await auto.onSpellSettledB6E({ actor: mb, spell: { name: "Xithra", flags: { [SYS]: { eaXithra: true } } }, cast: true, spellHits: [{ target: vic, critical: true }] });
  equal("F Malevolent Blast: the target's Will at the innate DC, the Warlock named; a critical hit Stunned 2; the use spent", [calls.checks[0], calls.conditions[0], mb.items[0].system.usesValue], [{ actor: "ZZ Struck", type: "save", subject: "will", dc: 20, sourceUuid: mb.uuid }, { target: "ZZ Struck", tags: [{ key: "stunned", value: 2 }] }, 0]);
  await auto.onSpellSettledB6E({ actor: mb, spell: { name: "Xithra", flags: { [SYS]: { eaXithra: true } } }, cast: true, spellHits: [{ target: vic }] });
  equal("F …once until Refocus", calls.checks.length, 1);
  mb.items[0].system.usesValue = 1;
  await auto.onSpellSettledB6E({ actor: mb, spell: { name: "Bolt", flags: {} }, cast: true, spellHits: [{ target: vic }] });
  await auto.onSpellSettledB6E({ actor: mb, spell: { name: "Xithra", flags: { [SYS]: { eaXithra: true } } }, cast: true, spellHits: [] });
  equal("F …not on another spell, nor on a miss", calls.checks.length, 1);
  checkDegree = "partial";
  await auto.onSpellSettledB6E({ actor: mb, spell: { name: "Xithra", flags: { [SYS]: { eaXithra: true } } }, cast: true, spellHits: [{ target: vic }] });
  equal("F …a Partial save is not stunned", calls.conditions.length, 1);

  // The familiar: Extra Bond, Ethereal Insight, Soul-Bound Grimoire, Symbiotic Witch.
  reset();
  const fw = makeActor("ZZ Familiar Witch", { level: 10, cl: 10, items: [witchClass(), { type: "ability", name: "Soulbound Familiar", system: {}, flags: {} }, feat("Extra Bond"), feat("Extra Bond")] });
  const fam = makeActor("ZZ Cat");
  fam.flags[MOD] = { soulbound: { masterId: fw.id } };
  familiarList = [fam];
  game.actors = [fw, fam];
  game.actors.get = (id) => game.actors.find((a2) => a2.id === id);
  const fwt = makeToken("fw", fw, { x: 0, y: 0 }), famt = makeToken("cat", fam, { x: 200, y: 0 });
  canvas.tokens.placeables = [fwt, famt];
  const [bonus] = await fw.createEmbeddedDocuments("ActiveEffect", [{ name: "b", flags: { [MOD]: { source: "soulboundBonus", bonus: "will" } } }]);
  answers.push("reflex", "hp");
  await auto.onEffectCreatedB6E(bonus);
  equal("F Extra Bond: after the daily bonus, one more a copy, never the one taken", [helpers.lastOptions.map((o) => o[0]).includes("will") || helpers.lastOptions.map((o) => o[0]).includes("reflex"), fw.effects.filter((x) => x.flags[MOD].source === "extraBond").map((x) => [x.flags[MOD].bonus, x.disabled ?? false])], [false, [["reflex", false], ["hp", false]]]);
  await moveV14(famt, { x: 1000 }, auto.onTokenMovedB6E);
  equal("F …switched off beyond 30 feet, as the familiar moves", fw.effects.filter((x) => x.flags[MOD].source === "extraBond").map((x) => x.disabled), [true, true]);
  await moveV14(famt, { x: 200 }, auto.onTokenMovedB6E);
  equal("F …and on again within", fw.effects.filter((x) => x.flags[MOD].source === "extraBond").map((x) => x.disabled), [false, false]);
  fw.items[1].flags[MOD] = { soulboundSevered: { why: "x" } };
  await auto.refreshFamiliarRange(fw);
  equal("F …off while the bond is severed", fw.effects.filter((x) => x.flags[MOD].source === "extraBond").map((x) => x.disabled), [true, true]);
  fw.items[1].flags[MOD] = {};

  // Ethereal Insight's Darkvision and sight.
  const abilities = { collection: "trg-prime.abilities", documentName: "Item", metadata: {}, getIndex: async () => new Map([["dv", { _id: "dv", name: "Darkvision" }]]), getDocument: async () => ({ toObject: () => ({ _id: "dv", name: "Darkvision", type: "ability", system: {}, flags: {} }) }) };
  game.packs = [spellsPack(INDEX), abilities];
  const [ins] = await fw.createEmbeddedDocuments("Item", [feat("Ethereal Insight")]);
  await auto.onItemCreatedB6E(ins);
  equal("F Ethereal Insight: the familiar within 30 ft carries the core's Darkvision", fam.items.map((i) => [i.name, i.flags[MOD]?.etherealInsightOf]), [["Darkvision", fw.id]]);
  await moveV14(famt, { x: 1000 }, auto.onTokenMovedB6E);
  equal("F …and loses it beyond", fam.items.length, 0);
  await moveV14(famt, { x: 200 }, auto.onTokenMovedB6E);
  const si = makeItem({ type: "spell", name: "See Invisible", system: {}, flags: { [SYS]: { grantedBy: { sourceName: "Ethereal Insight" } } } }, fw);
  await fw.createEmbeddedDocuments("ActiveEffect", [{ name: "See Invisible", origin: si.uuid, flags: { [SYS]: { seeInvisible: "concealed", castId: "k", endsWithCast: true, spellEffectEnd: 600 } } }]);
  await auto.onSpellSettledB6E({ actor: fw, spell: si, cast: true });
  const famSight = fam.effects.find((x) => x.flags?.[MOD]?.source === "etherealInsightSight");
  equal("F …her daily See Invisible: its sight on the familiar too, for its duration, not bound to her cast", [famSight?.flags?.[SYS]?.seeInvisible, famSight?.flags?.[SYS]?.spellEffectEnd, famSight?.flags?.[SYS]?.endsWithCast], ["concealed", 600, undefined]);
  const otherSI = makeItem({ type: "spell", name: "See Invisible", system: {}, flags: {} }, fw);
  await fw.createEmbeddedDocuments("ActiveEffect", [{ name: "See Invisible", origin: otherSI.uuid, flags: { [SYS]: { seeInvisible: "concealed" } } }]);
  await auto.onSpellSettledB6E({ actor: fw, spell: otherSI, cast: true });
  equal("F …only the one Ethereal Insight grants", fam.effects.length, 1);
  fw.items.splice(fw.items.indexOf(ins), 1);
  await auto.onItemDeletedB6E(ins);
  equal("F …the feat's leaving takes the familiar's Darkvision", fam.items.length, 0);

  // Soul-Bound Grimoire.
  reset();
  const [gr] = await fw.createEmbeddedDocuments("Item", [feat("Soul-Bound Grimoire")]);
  fw.items.push(makeItem({ type: "consumable", name: "Scroll of Entangle", system: { quantity: 2 }, flags: { [SYS]: { consumable: { kind: "scroll", spell: { name: "Entangle" } } } } }, fw));
  fw.items.push(makeItem({ type: "consumable", name: "Scroll of Bolt", system: { quantity: 1 }, flags: { [SYS]: { consumable: { kind: "scroll", spell: { name: "Bolt" } } } } }, fw));
  fw.items.push(makeItem({ type: "consumable", name: "Scroll of See Invisible", system: { quantity: 1 }, flags: { [SYS]: { consumable: { kind: "scroll", spell: "See Invisible" } } } }, fw));
  const scrollIds = fw.items.filter((i) => i.type === "consumable").map((i) => i.id);
  answers.push(scrollIds[0], scrollIds[2], "1");
  await auto.onDailyPreparationB6E({ actor: fw });
  equal("F Soul-Bound Grimoire: Ethereal and Verdant scrolls only, each used up, stored on the feat", [gr.flags[MOD].stored.map((s) => s.name), fw.items.find((i) => i.name === "Scroll of Entangle")?.system?.quantity, fw.items.some((i) => i.name === "Scroll of See Invisible"), fw.items.some((i) => i.name === "Scroll of Bolt")], [["Entangle", "See Invisible"], 1, false, true]);
  equal("F …one imprinted for the day as a copy", fw.items.filter((i) => i.flags?.[MOD]?.eaImprint).map((i) => i.name), ["See Invisible"]);
  fw.items.push(makeItem({ type: "spell", name: "Entangle", system: {}, flags: { [SYS]: { warpDiscount: 1 } } }, fw));
  answers.push("0");
  await auto.onDailyPreparationB6E({ actor: fw });
  const ent = fw.items.find((i) => i.type === "spell" && i.name === "Entangle");
  equal("F …the next day: yesterday's copy gone; a known spell takes −1 warp PP (on top of its own)", [fw.items.filter((i) => i.flags?.[MOD]?.eaImprint).length, ent.flags[SYS].warpDiscount], [0, 2]);
  answers.push(null);
  await auto.onDailyPreparationB6E({ actor: fw });
  equal("F …and the day after it is put back", ent.flags[SYS].warpDiscount, 1);
  answers.push("0");
  await auto.AUTOMATIONS_B6_E["Soul-Bound Grimoire"].use(fw, gr);
  equal("F …the Use erases a stored spell", gr.flags[MOD].stored.map((s) => s.name), ["See Invisible"]);
  fw.items[1].flags[MOD] = { soulboundSevered: { why: "x" } };
  answers.push(null, "0");
  await auto.onDailyPreparationB6E({ actor: fw });
  answers.length = 0;
  equal("F …with the bond severed, nothing is imprinted", fw.items.filter((i) => i.flags?.[MOD]?.eaImprint).length, 0);
  fw.items[1].flags[MOD] = {};
  deadSet = new Set([fam.id]);
  await auto.onDailyPreparationB6E({ actor: fw });
  equal("F …the familiar's death loses them (Q138)", gr.flags[MOD].stored, []);
  deadSet = new Set();

  // Symbiotic Witch.
  reset();
  const [sym] = await fw.createEmbeddedDocuments("Item", [feat("Symbiotic Witch")]);
  fw.items.push(makeItem({ type: "spell", name: "Cheap", system: { ppCost: 3 }, flags: {} }, fw), makeItem({ type: "spell", name: "Dear", system: { ppCost: 6 }, flags: {} }, fw));
  canvas.tokens.placeables = [fwt, famt];
  answers.push("conduit", fw.items.find((i) => i.name === "Cheap").id);
  await auto.AUTOMATIONS_B6_E["Symbiotic Witch"].use(fw, sym);
  equal("F Symbiotic Witch's conduit: spells of base PP 4 or less, cast from the familiar's token; the day's use", [helpers.lastOptions.map((o) => o[1]).filter((n) => /Cheap|Dear/.test(n)), calls.casts.at(-1)?.options, sym.system.usesValue], [["Cheap (PP 3)"], { rangeFrom: famt.document.uuid }, 0]);
  answers.push("conduit");
  await auto.AUTOMATIONS_B6_E["Symbiotic Witch"].use(fw, sym);
  ok("F …once a day", /today's conduit is spent/.test(cards.at(-1)?.warn ?? "") && calls.casts.length === 1);
  fw.flags[SYS].activeSpells = [{ id: "as1", name: "Hold Person", sustained: true }, { id: "as2", name: "Light", sustained: false }];
  answers.push("sustain", "as1");
  await auto.AUTOMATIONS_B6_E["Symbiotic Witch"].use(fw, sym);
  equal("F …the familiar sustains one sustained spell (G24)", [helpers.lastOptions.map((o) => o[0]), calls.sustain.at(-1)], [["as1"], { id: "as1", s: { uuid: fam.uuid, label: "ZZ Cat (Symbiotic Witch)" } }]);
  confirms.push(true); answers.push("sustain");
  await auto.AUTOMATIONS_B6_E["Symbiotic Witch"].use(fw, sym);
  equal("F …and Use hands it back", calls.sustain.at(-1), { id: "as1", s: null });
  fw.items[1].flags[MOD] = { soulboundSevered: { why: "x" } };
  answers.push("conduit");
  await auto.AUTOMATIONS_B6_E["Symbiotic Witch"].use(fw, sym);
  ok("F …not while the bond is severed", /bond must hold/.test(cards.at(-1)?.warn ?? ""));
  fw.items[1].flags[MOD] = {};

  // The load-time refresh touches the familiar only (review): Xithra and Pact Ascendant are left as the GM set them.
  const gm = makeActor("ZZ Hand Edited", { items: [warlockClass(), xithraItem(), feat("Xithra Spear"), { type: "feat", name: "Demonic Pact", system: {}, flags: {} }, feat("Pact Ascendant")] });
  X(gm).system.range = "45 feet";
  game.actors = [gm]; game.actors.get = (id) => game.actors.find((a2) => a2.id === id);
  await auto.refreshFamiliarsB6E();
  equal("F refreshFamiliarsB6E rewrites no Xithra and lays no Pact Ascendant effect", [X(gm).system.range, gm.effects.length], ["45 feet", 0]);

  // Registration through a fake API.
  const got = [];
  const fake = new Proxy({}, { get: (_, k) => (...a) => { got.push([k, a[0]]); return true; } });
  auto.registerBlock6E(fake, "trg-eldritch-arts");
  equal("F registerBlock6E: twelve Uses, the extra uses, the cost modifier, the prelude, the step", got.map(([k, n]) => `${k}:${n}`), [...Object.keys(auto.AUTOMATIONS_B6_E).map((n) => `registerFeatAutomation:${n}`), "registerExtraUses:Extra Communion", "registerCastCostModifier:hexMastery", "registerCastPrelude:xithraCone", `registerReactionStep:${auto.HEX_STEP}`]);
  equal("F the hook handlers are exported", ["onSpellSettledB6E", "onDamageAppliedB6E", "onDailyPreparationB6E", "onItemCreatedB6E", "onItemDeletedB6E", "onEffectCreatedB6E", "onTokenMovedB6E", "onDeathGuardHeldB6E", "refreshFamiliarsB6E"].every((n) => typeof auto[n] === "function"), true);
}

console.log(`verify-block6e: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
