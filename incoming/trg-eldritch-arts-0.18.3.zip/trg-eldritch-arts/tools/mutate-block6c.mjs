#!/usr/bin/env node
/**
 * mutate-block6c — the mutation half of verify-block6c. Each mutation breaks
 * one printed number, one reading or one wire of Block 6's group C;
 * verify-block6c must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6c.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block6-c.mjs"), A = f("module", "block6c-automations.mjs");

const MUTATIONS = [
  // The content
  { name: "Combat Inscription keeps the +2", file: C, from: "Object.freeze({ defensiveIncrease: 0, roomNote:", to: "Object.freeze({ defensiveIncrease: 2, roomNote:" },
  { name: "Combat Inscription's room note is lost", file: C, from: "roomNote: \"a hand-sized space suffices (Combat Inscription)\" });", to: "roomNote: \"\" });" },
  { name: "Clever Strike reads Wisdom", file: C, from: "{ label: \"Clever Strike\", attack: [\"intelligence\"] }", to: "{ label: \"Clever Strike\", attack: [\"wisdom\"] }" },
  { name: "Clever Damage declares the attack instead", file: C, from: "{ label: \"Clever Damage\", damage: [\"intelligence\"] }", to: "{ label: \"Clever Damage\", attack: [\"intelligence\"] }" },
  { name: "Q146 undone: Dangerous Sorcery reaches spells with a duration", file: C, from: "valueFrom: \"spellPP\", instantOnly: true, type: \"status\"", to: "valueFrom: \"spellPP\", type: \"status\"" },
  { name: "Dangerous Sorcery's bonus is untyped", file: C, from: "valueFrom: \"spellPP\", instantOnly: true, type: \"status\"", to: "valueFrom: \"spellPP\", instantOnly: true, type: \"untyped\"" },
  { name: "Considered Attack keeps CLASS as a trait", file: C, from: "consideredAttack.system.traits = \"Martial\";", to: "" },
  { name: "the docs grade Magical Retribution A", file: C, from: "\"Magical Retribution\": { level: \"C\",", to: "\"Magical Retribution\": { level: \"A\"," },
  { name: "Metamagic Adept's card forgets the Flourish is recorded", file: C, from: ", and a cast that took it records this turn's Flourish when it settles (the core's trait record)", to: "" },
  { name: "Considered Attack's card forgets its ruling", file: C, from: "*Automated (0.9.0; Graham's Q145):*", to: "*Automated (0.9.0):*" },
  // Prepared Sigil, Runic Reservoir, Living Script
  { name: "Runic Reservoir gives two sigils", file: A, from: "export const RESERVOIR_SIGILS = 3;", to: "export const RESERVOIR_SIGILS = 2;" },
  { name: "Living Script reforms in 30 s", file: A, from: "export const SIGIL_REFORM_SECONDS = 60;", to: "export const SIGIL_REFORM_SECONDS = 30;" },
  { name: "Living Script reforms in 5 rounds", file: A, from: "export const SIGIL_REFORM_ROUNDS = 10;", to: "export const SIGIL_REFORM_ROUNDS = 5;" },
  { name: "a Heroic does not keep the sigil", file: A, from: "  if (norm(degree) === \"heroic\") return { ...sigil, state: \"ready\" };\n", to: "" },
  { name: "Living Script's reform reads another combat's rounds", file: A, from: "if (r && combat && String(r.combatId) === String(combat.id) && int(combat.round) >= int(r.round)) return true;", to: "if (r && combat && int(combat.round) >= int(r.round)) return true;" },
  { name: "the round lock is never held in combat", file: A, from: "  if (combat) return String(lock.combatId ?? \"\") === String(combat.id) && int(lock.round) === int(combat.round);", to: "  if (combat) return false;" },
  { name: "an innate spell takes a sigil", file: A, from: "  if (!runemage || innate || spellData?.innate) return false;", to: "  if (!runemage) return false;" },
  { name: "a somatic-only spell has a Symbol", file: A, from: "  return Boolean(c.verbal || c.material || c.focus);", to: "  return Boolean(c.verbal || c.material || c.focus || c.somatic);" },
  { name: "the sigil's pick ignores today's availability", file: A, from: "if (sigilSpellEligible(s) && (await h().spellCastable(actor, s))) castable.push(s);", to: "if (sigilSpellEligible(s)) castable.push(s);" },
  { name: "the sigils may be inscribed twice a day", file: A, from: "    if (mflag(item, SIGILS_INSCRIBED_FLAG)) return warn(", to: "    if (false) return warn(" },
  { name: "the prelude casts without the prepared Symbol", file: A, from: "{ preparedSymbol: { label: \"Prepared Sigil\" } }", to: "{}" },
  { name: "the prelude ignores the round lock", file: A, from: "  if (sigilLockHeld(mflag(feat, SIGIL_LOCK_FLAG), now)) return null;\n", to: "" },
  { name: "the prelude does not ask", file: A, from: "  if (!(await confirm(\"Prepared Sigil\", `Activate", to: "  if (false && !(await confirm(\"Prepared Sigil\", `Activate" },
  { name: "a sigil cast does not spend the sigil", file: A, from: "  if (!ctx.preparedSymbol || !spell || ctx.refunded) return;", to: "  if (true) return;" },
  { name: "daily preparation keeps yesterday's sigils", file: A, from: "    await sigil.unsetFlag(MODULE_ID, SIGILS_FLAG);\n", to: "" },
  // Ley-Etched Symbol
  { name: "Q93 undone: Ley-Etched lowers 2 PP", file: A, from: "({ discount: { pp: 1, floor: 1 }, lines:", to: "({ discount: { pp: 2, floor: 1 }, lines:" },
  { name: "Ley-Etched needs no ley benefit", file: A, from: "  if (!owned || !runemage || !marker) return false;", to: "  if (!owned || !runemage) return false;" },
  { name: "Ley-Etched reaches an item's cast", file: A, from: "  if (ctx.innate || ctx.itemCast || ctx.cantrip) return false;", to: "  if (ctx.innate || ctx.cantrip) return false;" },
  { name: "Ley-Etched is not once a round", file: A, from: "  return !sigilLockHeld(lock, { combat, worldTime });\n}", to: "  return true;\n}" },
  { name: "Ley-Etched's backlash on a Failure", file: A, from: "export const leyBacklashDue = (degree) => [\"fumble\", \"blunder\"].includes(norm(degree));", to: "export const leyBacklashDue = (degree) => [\"failure\", \"fumble\", \"blunder\"].includes(norm(degree));" },
  { name: "Ley-Etched's backlash lasts 1 minute", file: A, from: "level, expiry: expiryFor(\"endOfNextTurn\", actor), source: \"leyLineBacklash\" });", to: "level, expiry: forSeconds(60), source: \"leyLineBacklash\" });" },
  { name: "the marker stacks", file: A, from: "  if (old.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", old);\n  return h().createEffectsOn(actor, [leyBenefitMarkerData", to: "  return h().createEffectsOn(actor, [leyBenefitMarkerData" },
  // Arcane Study
  { name: "Arcane Study scribes any tradition", file: A, from: "  return traitList(sys.tradition).includes(\"arcane\");", to: "  return true;" },
  { name: "Arcane Study scribes above caster level + 1", file: A, from: "if (!Number.isFinite(pp) || pp < 1 || pp > int(casterLevel) + 1) return false;", to: "if (!Number.isFinite(pp) || pp < 1 || pp > int(casterLevel) + 4) return false;" },
  { name: "Arcane Study's check is Occultism", file: A, from: "subject: TRADITION_SKILL.arcane,", to: "subject: TRADITION_SKILL.ethereal," },
  { name: "a failed scribe is learned", file: A, from: "  const learned = Boolean(outcome?.learned);\n  if (learned) await feat.setFlag(MODULE_ID, ARCANE_BOOK_FLAG", to: "  const learned = true;\n  if (learned) await feat.setFlag(MODULE_ID, ARCANE_BOOK_FLAG" },
  { name: "Q142 undone: the discount is 2", file: A, from: "await known.setFlag(SYSTEM_ID, \"warpDiscount\", int(known.getFlag?.(SYSTEM_ID, \"warpDiscount\") ?? known.flags?.[SYSTEM_ID]?.warpDiscount) + 1);", to: "await known.setFlag(SYSTEM_ID, \"warpDiscount\", int(known.getFlag?.(SYSTEM_ID, \"warpDiscount\") ?? known.flags?.[SYSTEM_ID]?.warpDiscount) + 2);" },
  { name: "the day's spell outlives the day", file: A, from: "  if (day.length) await actor.deleteEmbeddedDocuments(\"Item\", day.map((i) => i.id));", to: "" },
  { name: "the discount is never taken back", file: A, from: "  if (today?.mode === \"discount\") {", to: "  if (false) {" },
  { name: "the day's spell is not granted by the feat", file: A, from: "grantedBy: { sourceId: feat.id, sourceName: feat.name, requested: doc.name } }, [MODULE_ID]", to: "}, [MODULE_ID]" },
  // Bespell Weapon
  { name: "Bespell's die is 1d8", file: A, from: "export const BESPELL_DICE = \"1d6\";", to: "export const BESPELL_DICE = \"1d8\";" },
  { name: "Soul gives force", file: A, from: "invocation: \"dealt\", soul: \"essence\", warding: \"force\"", to: "invocation: \"dealt\", soul: \"force\", warding: \"force\"" },
  { name: "Alteration offers the weapon's own type", file: A, from: "  if (kind === \"physical\") return PHYSICAL_TYPES.filter((t) => !traitList(weaponType).includes(t));", to: "  if (kind === \"physical\") return [...PHYSICAL_TYPES];" },
  { name: "Bespell's rider reaches every weapon", file: A, from: "scope: \"any\", weaponScoped: true, weaponId, once: false });", to: "scope: \"any\", weaponId, once: false });" },
  { name: "Q143 undone: Bespell on any earlier turn", file: A, from: "&& int(last.round) === int(combat.round) && int(last.turn) === int(combat.turn);", to: ";" },
  { name: "sustaining costs no AP", file: A, from: "  if (!(await spendAP(actor, \"Bespell Weapon (sustain)\", 1))) return false;\n", to: "" },
  { name: "Bespell lasts past the turn", file: A, from: "    expiry: expiryFor(\"endOfTurn\", actor)\n", to: "" },
  // Bonded Infusion
  { name: "Q144 undone: +1 from the infused focus", file: A, from: "export const BONDED_FOCUS_BONUS = 2;", to: "export const BONDED_FOCUS_BONUS = 1;" },
  { name: "Bonded Infusion's bonus is circumstance", file: A, from: "value: BONDED_FOCUS_BONUS, type: \"item\" };", to: "value: BONDED_FOCUS_BONUS, type: \"circumstance\" };" },
  { name: "Bonded Infusion holds without the weapon in hand", file: A, from: "  if (!held || innate || itemCast || focusSetAside) return null;", to: "  if (innate || itemCast || focusSetAside) return null;" },
  { name: "the spell adder is not given", file: A, from: "    spellAdder: infused ? BONDED_ADDER : 0,", to: "    spellAdder: 0," },
  { name: "the weapon never stands in for somatic", file: A, from: "    freeSomatic: held ? { traditions:", to: "    freeSomatic: false ? { traditions:" },
  { name: "the freeSomatic needs a pouch", file: A, from: "needsPouch: false, label: \"Bonded Infusion (the infused weapon)\"", to: "needsPouch: true, label: \"Bonded Infusion (the infused weapon)\"" },
  { name: "Bonded Infusion is not synced at equip", file: A, from: "  if (globalThis.foundry?.utils?.getProperty?.(change, \"system.equipped\") === undefined) return;\n  await syncBondedInfusion(actor);", to: "  return;" },
  { name: "ready writes to the world again", file: A, from: " * ready handler.\n */\n", to: " * ready handler.\n */\nexport async function onReadyB6C() { for (const a of Array.from(globalThis.game?.actors ?? [])) await syncBondedInfusion(a); }\n" },
  // Call Bonded Weapon, Considered Attack
  { name: "Call Bonded Weapon costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Call Bonded Weapon\", 1))) return false;\n", to: "" },
  { name: "Call Bonded Weapon ignores the Blade Ally", file: A, from: "  if (allyId) out.push({ kind: \"Blade Ally\"", to: "  if (false) out.push({ kind: \"Blade Ally\"" },
  { name: "Q145 undone: Considered Attack gives +1", file: A, from: "export const CONSIDERED_BONUS = 2;", to: "export const CONSIDERED_BONUS = 1;" },
  { name: "Considered Attack costs no extra AP", file: A, from: "    await spendAP(actor, \"Considered Attack\", CONSIDERED_EXTRA_AP);\n", to: "" },
  // High Mage's Focus
  { name: "High Mage's Focus lowers the DC by 1", file: A, from: "export const HMF_BONUS = 2;", to: "export const HMF_BONUS = 1;" },
  { name: "High Mage's Focus reaches the spell attack", file: A, from: "value: HMF_BONUS, type: \"untyped\", castingOnly: true });", to: "value: HMF_BONUS, type: \"untyped\" });" },
  { name: "the second pick at BSB +8", file: A, from: "export const HMF_SECOND_BSB = 10;", to: "export const HMF_SECOND_BSB = 8;" },
  { name: "High Mage's Focus takes any spell", file: A, from: "items(actor).filter((s) => s.type === \"spell\" && isHighMagicSpell(s.system) && !picks", to: "items(actor).filter((s) => s.type === \"spell\" && !picks" },
  { name: "High Mage's Focus applies to every spell", file: A, from: "  if (!picksOf(feat).some((p) => p.id === ctx.spell.id)) return null;\n", to: "" },
  // High Magic Resonance
  { name: "High Magic Resonance lifts no disadvantage", file: A, from: "return { single: true, label: \"High Magic Resonance\"", to: "return { single: false, label: \"High Magic Resonance\"" },
  { name: "High Magic Resonance's single roll on any cast", file: A, from: "    if (!ctx.highMagic || !ownedFeat(ctx.actor, \"High Magic Resonance\")) return null;", to: "    if (!ownedFeat(ctx.actor, \"High Magic Resonance\")) return null;" },
  { name: "Q147 undone: a Blunder is eased", file: A, from: "export const hmrRemapDue = ({ degree = \"\", itemCast = false, used = false } = {}) => norm(degree) === \"fumble\" &&", to: "export const hmrRemapDue = ({ degree = \"\", itemCast = false, used = false } = {}) => [\"fumble\", \"blunder\"].includes(norm(degree)) &&" },
  { name: "every Fumble is eased", file: A, from: "  await feat.setFlag(MODULE_ID, HMR_EASED_FLAG, true);\n", to: "" },
  { name: "the eased Fumble is not restored", file: A, from: "  if (hmr && mflag(hmr, HMR_EASED_FLAG)) await hmr.unsetFlag(MODULE_ID, HMR_EASED_FLAG);\n", to: "" },
  { name: "the Wild bar is lifted", file: A, from: "export const highMagicResonanceBlock = (actor) => (birthrightNames(actor).has(\"wild\") ?", to: "export const highMagicResonanceBlock = (actor) => (false ?" },
  { name: "Q100 undone: a High Mage's pick is not read", file: A, from: "    const pick = i.type === \"feat\" ? i.flags?.[SYSTEM_ID]?.[BORROWED_BIRTHRIGHT_FLAG] : null;", to: "    const pick = null;" },
  { name: "a switched-off birthright counts", file: A, from: "  const own = birthrightOf(actor);\n  if (own) out.add(norm(own.name));", to: "  const own = items(actor).find((i) => i.type === \"ability\" && i.flags?.[SYSTEM_ID]?.eaBirthright);\n  if (own) out.add(norm(own.name));" },
  // Metamagic Adept
  { name: "Metamagic Adept covers Empower", file: A, from: "export const ADEPT_OPTIONS = Object.freeze([\"extend\", \"reach\", \"silent\", \"still\"]);", to: "export const ADEPT_OPTIONS = Object.freeze([\"extend\", \"reach\", \"silent\", \"still\", \"empower\"]);" },
  { name: "Metamagic Adept's DC is not raised", file: A, from: "  ap: 1,\n  dcAsIfPP: true,", to: "  ap: 1,\n  dcAsIfPP: false," },
  { name: "Metamagic Adept on a 3 AP spell", file: A, from: "export const adeptCastTimeOk = (castAP) => { const ap = castTimeAPOf(castAP); return ap === 1 || ap === 2; };", to: "export const adeptCastTimeOk = (castAP) => { const ap = castTimeAPOf(castAP); return ap >= 1 && ap <= 3; };" },
  { name: "Metamagic Adept ignores the Flourish", file: A, from: "      if (blocked?.blocked) return false;", to: "      if (false) return false;" },
  { name: "Metamagic Adept on an item cast", file: A, from: "    if (!ownedFeat(ctx.actor, \"Metamagic Adept\") || ctx.itemCast) return false;", to: "    if (!ownedFeat(ctx.actor, \"Metamagic Adept\")) return false;" },
  // Resonance Surge
  { name: "Resonance Surge buys 3 PP", file: A, from: "export const SURGE_FREE_PP = 2;", to: "export const SURGE_FREE_PP = 3;" },
  { name: "the surge's credit is not required (it would wait for a tick)", file: A, from: "  required: true,\n  needsSpell: true,\n  scope: { innate: false, item: false },\n  applies(ctx = {}) { return ownEffects", to: "  needsSpell: true,\n  scope: { innate: false, item: false },\n  applies(ctx = {}) { return ownEffects" },
  { name: "the surge's credit applies unarmed", file: A, from: "  applies(ctx = {}) { return ownEffects(ctx.actor, SURGE_SOURCE).length > 0 && surgeConsumes(ctx); },", to: "  applies(ctx = {}) { return surgeConsumes(ctx); }," },
  { name: "the surge's credit is an always-on flag again", file: A, from: "      system: {}\n    })]);\n    await card(actor, \"Resonance Surge\"", to: "      system: { warpFreeSchool: { school: \"*\", value: SURGE_FREE_PP, label: \"Resonance Surge\" } }\n    })]);\n    await card(actor, \"Resonance Surge\"" },
  { name: "a stored release spends the surge", file: A, from: "ctx.threaded || ctx.stored || ctx.cantrip) return false;", to: "ctx.threaded || ctx.cantrip) return false;" },
  { name: "the force answers a cast that did not take the surge", file: A, from: "!surgeConsumes(ctx) || !surgeTaken(ctx)) return null;", to: "!surgeConsumes(ctx)) return null;" },
  { name: "a refunded cast disarms the surge", file: A, from: "if (!armed.length || ctx.refunded || !surgeConsumes(ctx)", to: "if (!armed.length || !surgeConsumes(ctx)" },
  { name: "a refunded cast spends the sigil", file: A, from: "  if (!ctx.preparedSymbol || !spell || ctx.refunded) return;", to: "  if (!ctx.preparedSymbol || !spell) return;" },
  { name: "Metamagic Adept's Flourish is never recorded", file: A, from: "  await h().recordTraitUsage(ctx.actor, { key: ADEPT_KEY, traits: \"Flourish\" });", to: "" },
  { name: "Metamagic Adept's Flourish recorded out of combat", file: A, from: "if (!adeptPaid(ctx) || !ownedFeat(ctx.actor, \"Metamagic Adept\") || !combatFor(ctx.actor)) return;", to: "if (!adeptPaid(ctx) || !ownedFeat(ctx.actor, \"Metamagic Adept\")) return;" },
  { name: "Metamagic Adept's Flourish recorded on any cast", file: A, from: "export const adeptPaid = (ctx = {}) => (Array.isArray(ctx.metamagicPayments) ? ctx.metamagicPayments : []).some((k) => norm(k) === norm(ADEPT_KEY));", to: "export const adeptPaid = (ctx = {}) => true;" },
  { name: "the surge's G1 option is not registered", file: A, from: "  api.registerMetamagic?.(SURGE_KEY, RESONANCE_SURGE_METAMAGIC, moduleId);\n", to: "" },
  { name: "Resonance Surge forces no Resonance", file: A, from: "    return { reason: \"Resonance Surge\", line: \"the surge's cost\" };", to: "    return null;" },
  { name: "a cantrip spends the surge", file: A, from: "  return int(ctx.spellData?.ppCost ?? ctx.spell?.system?.ppCost) > 0;", to: "  return true;" },
  { name: "the surge is never spent", file: A, from: "  await ctx.actor.deleteEmbeddedDocuments(\"ActiveEffect\", armed.map((e) => e.id));", to: "" },
  { name: "the surge arms twice", file: A, from: "    if (ownEffects(actor, SURGE_SOURCE).length) return warn(\"Resonance Surge: a surge is already armed", to: "    if (false) return warn(\"Resonance Surge: a surge is already armed" },
  // Spellblade's Mark
  { name: "the Mark reaches 30 ft", file: A, from: "export const MARK_FEET = 60;", to: "export const MARK_FEET = 30;" },
  { name: "the Mark's die is 1d4", file: A, from: "export const MARK_DICE = \"1d6\";", to: "export const MARK_DICE = \"1d4\";" },
  { name: "the Mark's rider is fire", file: A, from: "strikeRider: { label: MARK_LABEL, dice: MARK_DICE, damageType: \"force\"", to: "strikeRider: { label: MARK_LABEL, dice: MARK_DICE, damageType: \"fire\"" },
  { name: "the Mark's +1 reaches ranged Strikes", file: A, from: "when: { checkTypes: [\"attack\"], attackModes: [\"melee\"], attackForms:", to: "when: { checkTypes: [\"attack\"], attackForms:" },
  { name: "the Mark's +1 is a status bonus", file: A, from: "conditionals: [{ kind: \"modifier\", value: 1, type: \"circumstance\", label: MARK_LABEL", to: "conditionals: [{ kind: \"modifier\", value: 1, type: \"status\", label: MARK_LABEL" },
  { name: "the Mark's spell rider reaches save spells", file: A, from: "when: { targetUuids: [u], attackOnly: true } },", to: "when: { targetUuids: [u] } }," },
  { name: "the Mark's DB row is against everyone", file: A, from: "scope: \"against your Mark's attacks\", when: { sourceUuids: [u] } }]", to: "scope: \"against your Mark's attacks\" }]" },
  { name: "the Mark's spell-attack row is on the casting check", file: A, from: "return { label: MARK_LABEL, value: 1, type: \"circumstance\", attackOnly: true };", to: "return { label: MARK_LABEL, value: 1, type: \"circumstance\" };" },
  { name: "the Mark lands on an ally", file: A, from: "    if (me && t.document?.disposition === me.document?.disposition) return warn(", to: "    if (false) return warn(" },
  { name: "the Mark costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Spellblade’s Mark\", 1))) return false;\n", to: "" },
  { name: "Marks stack", file: A, from: "    const old = ownEffects(actor, MARK_SOURCE).map((e) => e.id);\n    if (old.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", old);\n    const uuid", to: "    const uuid" },
  { name: "the Mark outlives its encounter", file: A, from: "map((e) => e.id);\n    if (ids.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", ids).catch(() => {});\n  }\n}", to: "map((e) => e.id);\n    void ids;\n  }\n}" },
  { name: "any combat's end removes the Mark", file: A, from: "return !at || at === String(combat.id); }", to: "return true; }" },
  // Magical Retribution
  { name: "Magical Retribution answers a ranged Strike", file: A, from: "export const retributionWants = (ctx = {}) => Boolean(ctx.sourceUuid) && ctx.context?.kind === \"strike\" && ctx.context?.melee === true;", to: "export const retributionWants = (ctx = {}) => Boolean(ctx.sourceUuid) && ctx.context?.kind === \"strike\";" },
  { name: "Magical Retribution spends no reaction", file: A, from: "  if (!(await h().spendReaction?.(actor, \"Magical Retribution\", { traits: \"Attack\" }))) return { done: false };\n", to: "" },
  { name: "Magical Retribution's attack is not a reaction", file: A, from: "{ isReaction: true, skipTargetPrompt: true, reachAlreadyEstablished: true }", to: "{ skipTargetPrompt: true, reachAlreadyEstablished: true }" },
  { name: "Magical Retribution's Use ignores a spent reaction", file: A, from: "    if (refused) return warn(`Magical Retribution: ${refused}.`);", to: "" },
  // Registration
  { name: "the prelude is not registered", file: A, from: "  api.registerCastPrelude?.(\"preparedSigil\", preparedSigilPrelude, moduleId);\n", to: "" },
  { name: "Ley-Etched Symbol is not registered", file: A, from: "  api.registerMetamagic?.(LEY_ETCHED_KEY, LEY_ETCHED_METAMAGIC, moduleId);\n", to: "" },
  { name: "Metamagic Adept is not registered", file: A, from: "  api.registerMetamagicPayment?.(ADEPT_KEY, METAMAGIC_ADEPT_PAYMENT, moduleId);\n", to: "" },
  { name: "the remap is not registered", file: A, from: "  api.registerCastDegreeRemap?.(\"highMagicResonance\", highMagicResonanceRemap, moduleId);\n", to: "" },
  { name: "the Mark's gate is not registered", file: A, from: "  api.registerSpellCheckGate?.(\"spellbladesMark\", spellbladesMarkGate, moduleId);\n", to: "" },
  { name: "the pending-cast step is not registered", file: A, from: "  api.registerPendingCastStep?.(\"magicalRetribution\", magicalRetributionStep, moduleId);\n", to: "" },
  { name: "Arcane Study's eligibility is not registered", file: A, from: "  api.registerFeatEligibility?.(\"Arcane Study\", arcaneStudyBlock, moduleId);\n", to: "" },
  { name: "Resonance Surge's force is not registered", file: A, from: "  api.registerResonanceModifier?.(\"resonanceSurge\", RESONANCE_SURGE, moduleId);\n", to: "" },
  { name: "the reaction step is not registered", file: A, from: "  api.registerReactionStep?.(RETRIBUTION_STEP, retributionStep, moduleId);\n", to: "" },
  // 0.9.1: the Mark's DB row is typed as the book prints it
  { name: "the Mark's DB row is untyped again", file: A, from: "defenceDC: [{ dc: \"defence\", value: 1, type: \"circumstance\", label: MARK_LABEL,", to: "defenceDC: [{ dc: \"defence\", value: 1, label: MARK_LABEL," },
  { name: "the Mark's DB row is typed status", file: A, from: "defenceDC: [{ dc: \"defence\", value: 1, type: \"circumstance\", label: MARK_LABEL,", to: "defenceDC: [{ dc: \"defence\", value: 1, type: \"status\", label: MARK_LABEL," },
  { name: "the Mark's card says its DB row is summed again", file: C, from: "(a circumstance bonus: it does not stack with another circumstance bonus to your DB, and only the higher applies, as the core stacks defence rows by type)", to: "(summed with your other defence rows, as the core sums them)" },
  { name: "the Mark's table entry drops the row's type", file: C, from: "ward DB row typed circumstance (G20; TRG Prime 3.684.1 stacks it by type);", to: "ward DB row (G20);" },
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6c.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6c: verify-block6c already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6c: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6c: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
