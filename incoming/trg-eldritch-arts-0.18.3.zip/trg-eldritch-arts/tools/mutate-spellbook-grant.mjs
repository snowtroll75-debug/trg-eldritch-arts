#!/usr/bin/env node
/**
 * mutate-spellbook-grant — each mutation must turn verify-spellbook-grant red.
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-spellbook-grant.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CHECK = path.join(ROOT, "tools", "verify-spellbook-grant.mjs");
const ARCH = path.join(ROOT, "packs-source", "ea-classes", "Archmage_3ccBj9Vt15uoUynS.json");
const BLADE = path.join(ROOT, "packs-source", "ea-classes", "Spellblade_3QlKJcvQ8OstPEt1.json");
const SORC = path.join(ROOT, "packs-source", "ea-classes", "Sorcerer_eqHFA6v44TB4PHtL.json");
const MANIFEST = path.join(ROOT, "module.json");

const MUTATIONS = [
  { name: "the Archmage grants no book", file: ARCH, from: '"grantedGear": "Spellbook"', to: '"grantedGear": ""' },
  { name: "the Spellblade grants no book", file: BLADE, from: '"grantedGear": "Spellbook"', to: '"grantedGear": ""' },
  { name: "the Archmage grants the old name", file: ARCH, from: '"grantedGear": "Spellbook"', to: '"grantedGear": "Wizard\'s Spellbook"' },
  { name: "a non-book class grants the Spellbook", file: SORC, from: '"grantedGear": ""', to: '"grantedGear": "Spellbook"' },
  { name: "the version is not raised", file: MANIFEST, from: '"version": "0.18.3"', to: '"version": "0.17.2"' }
];
const run = () => { try { execFileSync(process.execPath, [CHECK], { stdio: "pipe", env: process.env }); return true; } catch { return false; } };
if (!run()) { process.stderr.write("mutate-spellbook-grant: verify fails on an unmodified tree.\n"); process.exit(2); }
const results = [];
for (const m of MUTATIONS) {
  const original = fs.readFileSync(m.file, "utf8");
  if (original.split(m.from).length !== 2) { results.push([m.name, "ANCHOR"]); continue; }
  try { fs.writeFileSync(m.file, original.replace(m.from, m.to)); results.push([m.name, run() ? "SURVIVED" : "caught"]); }
  finally { fs.writeFileSync(m.file, original); }
}
for (const [n, s] of results) process.stdout.write(`  ${s.padEnd(8)}  ${n}\n`);
const bad = results.filter(([, s]) => s !== "caught").length;
process.stdout.write(bad ? `\nmutate-spellbook-grant: FAILED — ${bad} not caught.\n` : `\nmutate-spellbook-grant: OK — all ${results.length} caught, tree restored.\n`);
process.exit(bad ? 1 : 0);
