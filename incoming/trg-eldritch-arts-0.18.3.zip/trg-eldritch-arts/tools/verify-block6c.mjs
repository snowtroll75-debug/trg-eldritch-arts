#!/usr/bin/env node
/**
 * verify-block6c — Eldritch Arts 0.9.0 (Block 6, group C, on TRG Prime
 * 3.684.0): the five Runemage class feats and the fourteen Sorcerer,
 * Spellblade and Martial class feats (Appendices C and F).
 *
 *   A  every feat against the book: name, category, traits as stored,
 *      prerequisites, the printed text and the automation paragraph, the
 *      docs' table
 *   B  the data: the declarations the core reads
 *   C  the core, run with the content: Runemage adjustments, prerequisites,
 *      the archetype gate, melee abilities, the spell damage bonus, strike
 *      and spell riders, the Mark's conditional and ward row, gate rows, the
 *      module metamagic spec, the AP payment, the Resonance modifiers, the
 *      free warp, free somatic, the spell adder, eligibility, Focus uses,
 *      the pending-cast step, registration problems
 *   D  the pure rules
 *   E  registration
 *   F  the Foundry side with fakes: every Use, prelude, seam and hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6c.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const reactorAnswers = [];
const confirms = [];
const asked = [];
const calls = { casts: [], attacks: [], spendReaction: [], traitGate: [], recordTrait: [], rollCheck: [], gold: [] };
let castable = () => true;
let traitBlocked = false;
let traitGateOk = true;
let reactionRefused = "";
let checkDegree = "success";
let rollTotal = 47;
let purse = 100;
const STEPS = {};
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  spellCastable: async (actor, spell) => castable(spell),
  castSpell: async (actor, spell, options) => { calls.casts.push({ actor: actor.name, spell: spell.name, options, targets: [...(globalThis.game.user.targets ?? [])].map((t) => t.id) }); return "cast"; },
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title, step: q.step, data: q.data }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; if (a !== "yes") return { answer: a, result: null }; return { answer: a, result: await STEPS[q.step](actor, a, q.data) }; },
  spendReaction: async (actor, label, opts) => { calls.spendReaction.push([actor.name, label, opts?.traits]); return true; },
  reactionRefusal: async () => reactionRefused,
  isDead: async () => false,
  rollWeaponAttack: async (actor, weapon, opts) => { calls.attacks.push({ actor: actor.name, weapon: weapon.name, opts, targets: [...(globalThis.game.user.targets ?? [])].map((t) => t.id) }); return { total: 20 }; },
  traitGate: async (actor, action, name) => { calls.traitGate.push([action.key, action.traits]); return traitGateOk; },
  traitCheck: async (actor, action) => ({ blocked: traitBlocked, reason: traitBlocked ? "Flourish" : "" }),
  recordTraitUsage: async (actor, action) => { calls.recordTrait.push([action.key, action.traits]); },
  learnSpellTerms: async (pp) => ({ gp: 10 * pp, dc: 15 + pp, hours: pp }),
  learnSpellDC: async (spell) => 15 + Number(spell?.system?.ppCost ?? 0),
  goldOf: async () => purse,
  deductGold: async (actor, gp) => { calls.gold.push(gp); return { paid: true }; },
  rollCheck: async (cfg) => { calls.rollCheck.push(cfg); return { outcome: { degree: { key: checkDegree } } }; },
  learnSpellOutcome: async (degree) => ({ learned: ["heroic", "critical", "success"].includes(degree), materialsConsumed: ["heroic", "critical", "success"].includes(degree) ? "full" : degree === "failure" ? "half" : "none" }),
  rollResonanceEvent: async () => null,
  applyConditionTags: async () => null
};
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
const uuidMap = new Map();
globalThis.foundry = {
  applications: { api: { DialogV2: { confirm: async (o) => { confirms.push(o); return confirms.answer ?? true; }, prompt: async () => null } } },
  utils: {
    getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o),
    setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); const last = ks.at(-1); if (last.startsWith("-=")) delete at[last.slice(2)]; else at[last] = v; },
    isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => "r1", deepClone: (x) => JSON.parse(JSON.stringify(x)),
    fromUuid: async (u) => uuidMap.get(u) ?? null
  }
};
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.Item = { implementation: class { constructor(d) { Object.assign(this, JSON.parse(JSON.stringify(d))); } } };
globalThis.Roll = class { constructor(f) { this.formula = f; } async evaluate() { this.total = rollTotal; return this; } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.system = it.system ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = JSON.parse(JSON.stringify(v)); };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.toObject = () => JSON.parse(JSON.stringify({ ...data }));
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.delete = async () => { a.effects = a.effects.filter((x) => x !== e); };
  return e;
}
function makeActor(name, { level = 8, items = [], pp = 10, ap = 3, hp = 10, int = 4, casterLevel = 6, bsb = 4 } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [], documentName: "Actor", conditions: new Set() };
  a.system = { identity: { level }, resources: { pp: { value: pp }, ap: { value: ap }, hp: { value: hp } }, attributes: { strength: { total: 1 }, dexterity: { total: 2 }, intelligence: { total: int } }, magic: { casterLevelValue: casterLevel, bsb: 0, focusCasting: false }, progression: { bsb } };
  const list = items.map((d) => makeItem(d, a));
  a.items = Object.assign(list, { get(id) { return this.find((i) => i.id === id); } });
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = JSON.parse(JSON.stringify(v)); };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, docs) => {
    if (type === "Item") { const made = docs.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = docs.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => {
    if (type === "Item") { for (const id of ids) { const i = a.items.findIndex((x) => x.id === id); if (i >= 0) a.items.splice(i, 1); } return; }
    a.effects = a.effects.filter((e) => !ids.includes(e.id));
  };
  a.hasCondition = (k) => a.conditions.has(k);
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100, isTargeted: false };
  t.document = { actor, disposition, width: 1, height: 1, _source: { x: x - 50, y: y - 50, width: 1, height: 1 } };
  t.setTarget = (on) => { t.isTargeted = on; if (on) game.user.targets.add(t); else game.user.targets.delete(t); };
  actor.token = t;
  return t;
}
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.684.0" }
};
// 5 ft a square of 100 px.
globalThis.canvas = {
  tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }), getSnappedPoint: (p) => p }
};
const startCombat = (actor, { round = 1, turn = 0 } = {}) => {
  const turns = [{ actor, actorId: actor.id }];
  game.combat = { id: "c1", started: true, round, turn, combatants: turns, turns, combatant: turns[turn] };
};

const C = await import(new URL("./content/block6-c.mjs", import.meta.url));
const common = await import(new URL("./content/block6-common.mjs", import.meta.url));
const auto = await import(new URL("../module/block6c-automations.mjs", import.meta.url));
Object.assign(STEPS, { [auto.RETRIBUTION_STEP]: auto.STEPS_B6_C.retributionStep });
const F = Object.fromEntries(C.FEATS_B6_C.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS];

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
const LIST = {
  "PREPARED SIGIL": ["Runemage", "Linguistics 4 ranks"], "RUNIC RESERVOIR": ["Runemage", "Linguistics 8 ranks, Prepared Sigil"],
  "LIVING SCRIPT": ["Runemage", "Linguistics 14 ranks, Runic Reservoir"], "COMBAT INSCRIPTION": ["Runemage", "Linguistics 6 ranks"],
  "LEY-ETCHED SYMBOL": ["Runemage", "Linguistics 8 ranks, Power Manipulation 4 ranks"],
  "ARCANE STUDY": ["Sorcerer", "Arcanum Birthright, BSB +4"], "BESPELL WEAPON": ["Magical, Spellblade", "Ability to cast spells, level 5"],
  "BONDED INFUSION": ["Spellblade", ""], "CALL BONDED WEAPON": ["Crusader, Spellblade", "Blade Ally or Infuse Weapon, Weapon Focus, BAB +8"],
  "CLEVER DAMAGE": ["Spellblade", "Int +3, BAB +4"], "CLEVER STRIKE": ["Spellblade", "Int +3, BAB +2"], "CONSIDERED ATTACK": ["Martial", "Int +2, BAB +6"],
  "DANGEROUS SORCERY": ["Sorcerer", ""], "HIGH MAGE’S FOCUS": ["Sorcerer", ""], "HIGH MAGIC RESONANCE": ["Sorcerer", ""],
  "MAGICAL RETRIBUTION": ["Spellblade", "BAB +6"], "METAMAGIC ADEPT": ["Flourish, Sorcerer", "BSB +4"], "RESONANCE SURGE": ["Focus, Sorcerer", "BSB +3, Wild Birthright"],
  "SPELLBLADE’S MARK": ["Concentrate, Focus, Invocation, Spellblade", "Level 6"]
};
{
  const cf = new Map(book.sections.classFeats.map((f) => [f.name, f]));
  equal("A nineteen feats: the five Runemage and fourteen Sorcerer/Spellblade, in the brief's order and the book's names", C.FEATS_B6_C.map((f) => f.name), Object.keys(LIST).map(common.titleCase));
  equal("A …five Runemage, fourteen others", [C.RUNEMAGE_FEATS_B6_C.length, C.SORCERY_FEATS_B6_C.length], [5, 14]);
  for (const [key, [traits, prereq]] of Object.entries(LIST)) {
    const f = F[common.titleCase(key)];
    const b = cf.get(key);
    ok(`A ${key}: the book has it, and so does the content`, Boolean(f && b));
    if (!f || !b) continue;
    equal(`A ${f.name}: a Class feat, its traits as stored, its prerequisites`, [f.type, f.system.category, f.system.traits, f.system.prerequisites], ["feat", "Class", traits, prereq]);
    equal(`A ${f.name}: the prerequisite is the book's`, f.system.prerequisites, b.fields?.Prerequisites ?? "");
    const plain = f.system.description.replace(/<[^>]+>/g, "").replace(/\s+/g, " ");
    ok(`A ${f.name}: the card prints the book's text`, b.lines.every((l) => plain.includes(l.replace(/^- /, "").replace(/\*+/g, "").replace(/\s+/g, " ").trim().slice(0, 50))));
    ok(`A ${f.name}: the card prints the book's fields`, Object.values(b.fields ?? {}).every((v) => f.system.description.includes(v)));
    ok(`A ${f.name}: the card says what is automated`, /(Automated|Partly automated|Not automated)/.test(f.system.description));
    equal(`A ${f.name}: Block 6 and its book line`, [f.flags[SYS].eaBlock, f.flags[SYS].eaBookLine], [6, b.line]);
  }
  ok("A Runemage is authored as the core's archetype trait, not hyphenated, and not one Block 6 registers", C.RUNEMAGE_FEATS_B6_C.every((f) => f.system.traits === "Runemage") && !common.EA_ARCHETYPE_NAMES.includes("Runemage"));
  ok("A Considered Attack keeps the printed CLASS MARTIAL on its card, Martial alone stored", /\*\*CLASS MARTIAL\*\*|CLASS MARTIAL/.test(F["Considered Attack"].system.description) && F["Considered Attack"].system.traits === "Martial");
  ok("A Ley-Etched Symbol's Requirements stays on the card (a use-time condition, not a prerequisite)", F["Ley-Etched Symbol"].system.description.includes("You are currently gaining the benefits of a ley line.") && !/ley line/.test(F["Ley-Etched Symbol"].system.prerequisites));
  ok("A Spellblade’s Mark's card and table entry: its DB +1 is circumstance and does not stack with another circumstance bonus (0.9.1)",
    /\+1 circumstance to your DB against its attacks/.test(F["Spellblade’s Mark"].system.description) && /does not stack with another circumstance bonus to your DB/.test(F["Spellblade’s Mark"].system.description) && !/summed with your other defence rows/.test(F["Spellblade’s Mark"].system.description) && /ward DB row typed circumstance/.test(C.AUTOMATION_B6_C["Spellblade’s Mark"].what));
  ok("A the curly apostrophe is kept (the core matches feat names exactly)", ["High Mage’s Focus", "Spellblade’s Mark"].every((n) => F[n]));
  equal("A the docs' table: every feat, by its item's name", Object.keys(C.AUTOMATION_B6_C), C.FEATS_B6_C.map((f) => f.name));
  equal("A …graded A 8, B 10, C 1, D 0", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B6_C).filter((r) => r.level === l).length), [8, 10, 1, 0]);
  ok("A the C and the partly automated cards say what is the table's", /table's call/.test(F["Magical Retribution"].system.description) && /Partly automated/.test(F["Magical Retribution"].system.description) && /Partly automated/.test(F["Call Bonded Weapon"].system.description));
  ok("A Metamagic Adept's card says its Flourish is checked and recorded, and no longer that it is not", /records this turn's Flourish when it settles/.test(F["Metamagic Adept"].system.description) && !/does not report/.test(F["Metamagic Adept"].system.description));
  ok("A the rulings are cited where they decided a card", [["Prepared Sigil", "Q123"], ["Ley-Etched Symbol", "Q125"], ["Arcane Study", "Q142"], ["Bespell Weapon", "Q143"], ["Bonded Infusion", "Q144"], ["Considered Attack", "Q145"], ["Dangerous Sorcery", "Q146"], ["High Magic Resonance", "Q147"], ["Resonance Surge", "Q148"], ["Magical Retribution", "Q149"]].every(([n, q]) => F[n].system.description.includes(q)));
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
{
  equal("B Combat Inscription declares no defensive +2 and the hand-sized room", fl("Combat Inscription").runemage, { defensiveIncrease: 0, roomNote: "a hand-sized space suffices (Combat Inscription)" });
  equal("B Clever Strike declares Intelligence for the attack, Clever Damage for the damage", [fl("Clever Strike").meleeAbility, fl("Clever Damage").meleeAbility], [{ label: "Clever Strike", attack: ["intelligence"] }, { label: "Clever Damage", damage: ["intelligence"] }]);
  const ds = F["Dangerous Sorcery"].effects;
  equal("B Dangerous Sorcery: one passive effect, a status bonus valued at the spell's PP, instant spells only", [ds.length, ds[0]?.transfer, ds[0]?.flags?.[SYS]?.spellDamageBonus], [1, true, { label: "Dangerous Sorcery", valueFrom: "spellPP", instantOnly: true, type: "status" }]);
  equal("B the module's own flags are ea-prefixed", C.FEATS_B6_C.flatMap((f) => Object.keys(f.flags[SYS]).filter((k) => !["eaBlock", "eaBookLine", "eaAutomation", "runemage", "meleeAbility"].includes(k))), []);
  equal("B no feat carries a placeholder use count (Focus is the core's default)", C.FEATS_B6_C.map((f) => f.system.usesPerDay).filter(Boolean), []);
}

/* ----------------------------------------------------------------- */
/* C — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
const it = (n) => ({ ...JSON.parse(JSON.stringify(F[n])), id: `id-${n}` });
{
  const rm = await quiet(() => import(sys("module", "magic", "runemage.mjs")));
  const adj = rm.runemageAdjustments([it("Combat Inscription")]);
  equal("C Combat Inscription: the core reads defensive +0, named, and the room note", [adj.defensiveIncrease, adj.label, adj.roomNote], [0, "Combat Inscription", "a hand-sized space suffices (Combat Inscription)"]);
  equal("C …without it, +2", rm.runemageAdjustments([]).defensiveIncrease, 2);
  ok("C …the room line says the hand-sized space", /hand-sized space/.test(rm.symbolRoomLine({ symbol: true }, { roomNote: adj.roomNote }) ?? ""));
  equal("C the module's Symbol test agrees with the core's symbolComponents", [{ verbal: true }, { somatic: true }, { material: true, somatic: true }, { focus: true }, {}].map((c) => [auto.usesSymbol({ components: c }), Boolean(rm.symbolComponents(c, true).symbol)]), [[true, true], [false, false], [true, true], [true, true], [false, false]]);

  const pr = await quiet(() => import(sys("module", "prerequisites.mjs")));
  const known = new Set(C.FEATS_B6_C.map((f) => pr.prerequisiteNameKey(f.name)));
  const mp = (n, stats) => pr.meetsParseablePrerequisites(F[n].system.prerequisites, { knownNames: known, ownedNames: new Set(), ...stats });
  equal("C prerequisites the core reads: Runic Reservoir needs Linguistics 8 and Prepared Sigil",
    [mp("Runic Reservoir", { skillRanks: { linguistics: 8 }, ownedNames: new Set([pr.prerequisiteNameKey("Prepared Sigil")]) }), mp("Runic Reservoir", { skillRanks: { linguistics: 8 } }), mp("Runic Reservoir", { skillRanks: { linguistics: 7 }, ownedNames: new Set([pr.prerequisiteNameKey("Prepared Sigil")]) })], [true, false, false]);
  equal("C …Ley-Etched Symbol: Linguistics 8 and Power Manipulation 4", [mp("Ley-Etched Symbol", { skillRanks: { linguistics: 8, powerManipulation: 4 } }), mp("Ley-Etched Symbol", { skillRanks: { linguistics: 8, powerManipulation: 3 } })], [true, false]);
  equal("C …Clever Strike Int +3 and BAB +2; Spellblade’s Mark level 6; Metamagic Adept BSB +4", [mp("Clever Strike", { abilities: { intelligence: 3 }, bab: 2 }), mp("Clever Strike", { abilities: { intelligence: 2 }, bab: 2 }), mp("Spellblade’s Mark", { level: 6 }), mp("Spellblade’s Mark", { level: 5 }), mp("Metamagic Adept", { bsb: 4 }), mp("Metamagic Adept", { bsb: 3 })], [true, false, true, false, true, false]);
  equal("C …Call Bonded Weapon gated by BAB +8 (its \"or\" clause passes open)", [mp("Call Bonded Weapon", { bab: 8, ownedNames: new Set(["weapon focus"]), knownNames: new Set([...known, "weapon focus"]) }), mp("Call Bonded Weapon", { bab: 7, ownedNames: new Set(["weapon focus"]), knownNames: new Set([...known, "weapon focus"]) })], [true, false]);
  const pf = fs.readFileSync(new URL(sys("module", "picker-filters.mjs")), "utf8");
  ok("C the core's own archetype list names \"runemage\", so the trait gates these five", /"runemage"/.test(pf));

  const ma = await import(sys("module", "combat", "melee-ability.mjs"));
  const attrs = { strength: { total: 1 }, dexterity: { total: 3 }, intelligence: { total: 5 } };
  const att = ma.declaredMeleeAbilities([it("Clever Strike"), it("Clever Damage")], "attack"), dmg = ma.declaredMeleeAbilities([it("Clever Strike"), it("Clever Damage")], "damage");
  equal("C the core reads Clever Strike for the attack, Clever Damage for the damage", [att.map((a) => [a.ability, a.label]), dmg.map((a) => [a.ability, a.label])], [[["intelligence", "Clever Strike"]], [["intelligence", "Clever Damage"]]]);
  equal("C …the best of the current (Finesse Dex 3) and Int 5: +2 over it; none when Int is lower", [ma.bestMeleeAbility(att, attrs, 3)?.delta, ma.bestMeleeAbility(att, { intelligence: { total: 2 } }, 3)], [2, null]);

  const sdb = await import(sys("module", "magic", "spell-damage-bonus.mjs"));
  const eff = F["Dangerous Sorcery"].effects;
  equal("C Dangerous Sorcery: a PP 3 instant spell +3 status; a spell with a Duration, nothing; a cantrip, nothing (Q146)",
    [sdb.declaredSpellDamageBonuses(eff, { spellPP: 3, noDuration: true }), sdb.declaredSpellDamageBonuses(eff, { spellPP: 3, noDuration: false }), sdb.declaredSpellDamageBonuses(eff, { spellPP: 0, noDuration: true })],
    [[{ label: "Dangerous Sorcery", value: 3, type: "status" }], [], []]);

  const sr = await quiet(() => import(sys("module", "magic", "strike-riders.mjs")));
  const mark = auto.markFlags("Actor.Foe");
  const ms = sr.normaliseStrikeRider(mark.strikeRider);
  equal("C the Mark's strike rider is a 1d6 force packet on any Strike at the Mark, and none at another", [ms?.dice, ms?.damageType, ms?.once, sr.riderPacketsFor([ms], { attackMode: "melee" }, { targetUuid: "Actor.Foe" })[0]?.applies, sr.riderPacketsFor([ms], { attackMode: "missile" }, { targetUuid: "Actor.Other" })[0]?.applies], ["1d6", "force", false, true, false]);
  const bs = sr.normaliseStrikeRider(auto.bespellRider({ type: "mental", weaponId: "w1" }));
  equal("C Bespell's rider: 1d6 mental, that weapon only, every Strike this turn", [bs?.dice, bs?.damageType, bs?.weaponScoped, bs?.once, sr.riderPacketsFor([bs], { weaponId: "w1" }).length, sr.riderPacketsFor([bs], { weaponId: "w2" }).length], ["1d6", "mental", true, false, 1, 0]);
  ok("C …every Bespell type the table offers is a rider the core accepts", ["bludgeoning", "piercing", "slashing", "mental", "essence", "force", "fire"].every((t) => sr.normaliseStrikeRider(auto.bespellRider({ type: t, weaponId: "w" }))));

  const cdr = await import(sys("module", "magic", "caster-damage-riders.mjs"));
  const riders = cdr.declaredSpellDamageRiders([{ id: "m", name: "Mark", flags: { [SYS]: mark } }]);
  equal("C the Mark's spell rider: a spell ATTACK that damages the Mark, not a save spell, not another creature",
    [cdr.spellDamageRidersFor(riders, { damageType: "fire", taken: 4, targetUuid: "Actor.Foe", attack: true }).length, cdr.spellDamageRidersFor(riders, { damageType: "fire", taken: 4, targetUuid: "Actor.Foe", attack: false }).length, cdr.spellDamageRidersFor(riders, { damageType: "fire", taken: 4, targetUuid: "Actor.Other", attack: true }).length, riders[0]?.dice, riders[0]?.damageType], [1, 0, 0, "1d6", "force"]);

  const cond = await quiet(() => import(sys("module", "conditionals.mjs")));
  const mc = cond.normaliseConditional(mark.conditionals[0], { name: "Mark" }, 0);
  equal("C the Mark's +1: a melee weapon Strike at the Mark yes; a ranged one, an unarmed one, a spell attack (no form), another target",
    [cond.matchesCheck(mc, { checkType: "attack", attackMode: "melee", attackForm: "weapon", targetUuid: "Actor.Foe" }), cond.matchesCheck(mc, { checkType: "attack", attackMode: "ranged", attackForm: "weapon", targetUuid: "Actor.Foe" }), cond.matchesCheck(mc, { checkType: "attack", attackMode: "melee", attackForm: "unarmed", targetUuid: "Actor.Foe" }), cond.matchesCheck(mc, { checkType: "attack", attackMode: "melee", targetUuid: "Actor.Foe" }), cond.matchesCheck(mc, { checkType: "attack", attackMode: "melee", attackForm: "weapon", targetUuid: "Actor.Other" })],
    [true, false, true, false, false]);
  equal("C …+1 circumstance, automatic", [mc.value, mc.type, mc.auto], [1, "circumstance", true]);

  const dd = await quiet(() => import(sys("module", "combat", "defence-dc.mjs")));
  const marked = { items: [], effects: [{ id: "m", name: "Mark", flags: { [SYS]: mark } }] };
  equal("C the Mark's DB row: +1 against the Mark's attacks (a spell attack too), nothing against another",
    [dd.defenceDCBonus(marked, "defence", "", [], "Actor.Foe").total, dd.defenceDCBonus(marked, "defence", "", [], "Actor.Foe", [], [], { attackKind: "spell" }).total, dd.defenceDCBonus(marked, "defence", "", [], "Actor.Other").total], [1, 1, 0]);
  // TYPED (0.9.1; Graham, 4 November 2026; TRG Prime 3.684.1 stacks the rows
  // by type): the book prints "+1 circumstance bonus to DB", so the row is a
  // circumstance one — under a +2 circumstance already on the DB it adds
  // nothing, beside a +1 status it still adds.
  const markedWith = (entries) => ({ ...marked, system: { combat: { defence: { breakdown: { entries } } } } });
  equal("C …typed circumstance, as the book prints it: under a +2 circumstance it adds 0 (and is named), beside a +1 status +1",
    [mark.defenceDC[0].type, dd.defenceDCBonus(markedWith([{ label: "Cover", value: 2, type: "circumstance" }]), "defence", "", [], "Actor.Foe").total, dd.defenceDCBonus(markedWith([{ label: "Cover", value: 2, type: "circumstance" }]), "defence", "", [], "Actor.Foe").notCounted.length, dd.defenceDCBonus(markedWith([{ label: "Bless", value: 1, type: "status" }]), "defence", "", [], "Actor.Foe").total],
    ["circumstance", 0, 1, 1]);

  const scg = await import(sys("module", "magic", "spell-check-gates.mjs"));
  const g = scg.normaliseGateAnswer({ modifiers: [auto.markGateRow({ markUuid: "Actor.Foe", targetUuids: ["Actor.Foe"], attack: true }), auto.bondedInfusionRow({ held: true }), auto.highMagesFocusRow()] });
  equal("C the gate rows as the core reads them: the Mark attack-only, Bonded Infusion +2 item, High Mage’s Focus casting-only",
    g.modifiers.map((m) => [m.value, m.type, Boolean(m.attackOnly), Boolean(m.castingOnly)]), [[1, "circumstance", true, false], [2, "item", false, false], [2, "untyped", false, true]]);
  equal("C …split: the Mark's row is off the casting check", scg.splitGateRows(g.modifiers).check.length, 2);

  const mm = await import(sys("module", "magic", "module-metamagic.mjs"));
  const spec = mm.normaliseMetamagicSpec(auto.LEY_ETCHED_KEY, auto.LEY_ETCHED_METAMAGIC);
  equal("C Ley-Etched Symbol is a valid module metamagic: its feat, no PP, learned casts only", [spec.problem ?? null, spec.spec?.feats, spec.spec?.ppCost, spec.spec?.scope, typeof spec.spec?.after], [null, ["Ley-Etched Symbol"], 0, { innate: false, item: false }, "function"]);
  const ans = mm.cleanMetamagicAnswer(auto.leyEtchedAnswer());
  equal("C …its answer is a 1 PP discount, floor 1 (Q93: payment, not the DC)", [ans.discount?.pp, ans.discount?.floor, ans.dcDelta ?? 0], [1, 1, 0]);

  capi.resetModuleRegistry();
  await quiet(async () => auto.registerBlock6C(new Proxy({}, { get: (_, k) => (typeof capi[k] === "function" ? (...a) => capi[k](...a) : () => {}) }), "test"));
  equal("C everything group C registers is accepted by the core", capi.registrationProblems(), []);
  const pay = capi.registeredMetamagicPayments().find((p) => p.key === "metamagicadept");
  equal("C Metamagic Adept's payment: Extend, Reach, Silent, Still; 1 AP; the DC as if paid; one a cast", [pay?.options, pay?.ap, pay?.dcAsIfPP, pay?.max], [["extend", "reach", "silent", "still"], 1, true, 1]);
  const ap = mm.metamagicAPPayments({ coreOptions: [{ id: "extend", label: "Extend Spell", ppCost: 2, kind: "checkbox" }], form: { "mm-extend": true, "mmap-extend": true }, payments: [{ key: "metamagicadept", label: "Metamagic Adept", ap: 1, dcAsIfPP: true, max: 1, optionIds: ["extend"] }] });
  equal("C …Extend ticked and paid in AP: 2 PP off the payment, counted for the DC only, +1 AP", [ap.corePP, ap.dcPP, ap.apDelta], [2, 2, 1]);
  ok("C the High Magic Resonance remap and the pending-cast step reach the core's registry", capi.registeredCastDegreeRemaps().length === 1 && capi.registeredPendingCastSteps().some((s) => s.key === "magicalretribution") && capi.registeredCastPreludes().some((p) => p.key === "preparedsigil") && capi.registeredMetamagic().some((m) => m.key === "leyetchedsymbol") && capi.registeredMetamagic().some((m) => m.key === "resonancesurge" && m.required));
  ok("C …and the reaction step", Boolean(capi.registeredReactionStep(auto.RETRIBUTION_STEP)));

  const frm = await quiet(() => import(sys("module", "magic", "fumble-resonance-modifiers.mjs")));
  const sorc = makeActor("ZZ Core Sorc", { items: [it("High Magic Resonance")] });
  const res = await frm.resonanceModifiersFrom({ actor: sorc, highMagic: true });
  equal("C High Magic Resonance: the core's Resonance roll is single, so a High Magic cast loses only its disadvantage (Q147)", [res.single, frm.resonanceRollBias({ highMagic: true, single: res.single }), frm.resonanceRollBias({ highMagic: true, single: res.single, disadvantage: true })], [true, "normal", "disadvantage"]);
  equal("C …not on an ordinary cast, not without the feat", [(await frm.resonanceModifiersFrom({ actor: sorc, highMagic: false })).single, (await frm.resonanceModifiersFrom({ actor: makeActor("ZZ None"), highMagic: true })).single], [false, false]);
  const armed = makeActor("ZZ Core Wild");
  await armed.createEmbeddedDocuments("ActiveEffect", [{ name: "x", flags: { [MOD]: { source: auto.SURGE_SOURCE } } }]);
  const took = { metamagic: ["resonancesurge"] };
  const forced = await frm.forcedResonancesFrom({ actor: armed, spellData: { ppCost: 3 }, cast: true, ...took });
  equal("C Resonance Surge: an armed surge taken on a levelled spell forces one Resonance; not a cantrip, an item's, a ritual, a stored release, nor a cast that did not take it (Q148)",
    [forced.map((f) => f.key), (await frm.forcedResonancesFrom({ actor: armed, spellData: { ppCost: 0 }, ...took })).length, (await frm.forcedResonancesFrom({ actor: armed, spellData: { ppCost: 3 }, itemCast: true, ...took })).length, (await frm.forcedResonancesFrom({ actor: armed, spellData: { ppCost: 3 }, ritual: true, ...took })).length, (await frm.forcedResonancesFrom({ actor: armed, spellData: { ppCost: 3 }, stored: true, ...took })).length, (await frm.forcedResonancesFrom({ actor: armed, spellData: { ppCost: 3 }, metamagic: [] })).length, (await frm.forcedResonancesFrom({ actor: makeActor("ZZ Unarmed"), spellData: { ppCost: 3 }, ...took })).length], [["resonancesurge"], 0, 0, 0, 0, 0, 0]);
  const mmw = await quiet(() => import(sys("module", "magic", "module-metamagic-workflow.mjs")));
  const surger = makeActor("ZZ Core Surger", { items: [it("Resonance Surge")] });
  await surger.createEmbeddedDocuments("ActiveEffect", [{ name: "x", flags: { [MOD]: { source: auto.SURGE_SOURCE } } }]);
  const base6 = { spell: { system: { ppCost: 3 } }, spellData: { ppCost: 3 }, basePP: 3, scopeKind: "learned" };
  const offers = await quiet(() => mmw.offeredModuleMetamagic(surger, base6));
  const so = offers.find((o) => o.key === "resonancesurge");
  const taken = mm.readModuleMetamagicForm(offers, {}, []);
  const agg = await quiet(() => mmw.appliedModuleMetamagic(surger, offers, taken, base6));
  equal("C …its credit is a required G1 option on the armed caster's learned cast: applied untick'd, 2 free warp PP, no PP of its own", [so?.required, so?.hidden, so?.ppCost, taken.some((t) => t.key === "resonancesurge"), agg.freeWarpPP, agg.ppSpent], [true, false, 0, true, 2, 0]);
  equal("C …not offered unarmed, nor on an item's, ritual or stored cast (the scope and applies)", [(await quiet(() => mmw.offeredModuleMetamagic(makeActor("ZZ Core Unarmed", { items: [it("Resonance Surge")] }), base6))).some((o) => o.key === "resonancesurge" && !o.hidden), (await quiet(() => mmw.offeredModuleMetamagic(surger, { ...base6, scopeKind: "item", itemCast: true }))).some((o) => o.key === "resonancesurge" && !o.hidden), (await quiet(() => mmw.offeredModuleMetamagic(surger, { ...base6, ritual: true }))).some((o) => o.key === "resonancesurge" && !o.hidden), mm.moduleMetamagicScope({ stored: true }).allowed], [false, false, false, false]);

  equal("C Arcane Study, High Magic Resonance, Resonance Surge: the core asks the module's eligibility (G9)", [capi.featEligibilityBlock("Arcane Study", makeActor("ZZ None2")) !== null, capi.featEligibilityBlock("Resonance Surge", makeActor("ZZ None3")) !== null, capi.featEligibilityBlock("High Magic Resonance", makeActor("ZZ None4"))], [true, true, null]);

  equal("C …its answer is the core's freeWarpPP channel, 2 PP", mm.cleanMetamagicAnswer(auto.surgeAnswer()).freeWarpPP, 2);

  const cg = await quiet(() => import(sys("module", "magic", "component-gate.mjs")));
  const blade = { getFlag: () => null, items: [{ type: "feat", name: "Bonded Infusion", flags: { [SYS]: auto.bondedInfusionFlags({ infused: true, held: true }) } }], appliedEffects: [] };
  const decl = cg.declaredTraditionComponents(blade);
  equal("C Bonded Infusion's held weapon stands in for somatic, any tradition, no pouch (Q144)", [decl.length, decl[0]?.needsPouch, Boolean(cg.traditionComponentWaiver(decl, { tradition: "divinity" }, "arcane")), Boolean(cg.traditionComponentWaiver(decl, { tradition: "verdant" }, ""))], [1, false, true, true]);
  equal("C …not while put away", cg.declaredTraditionComponents({ getFlag: () => null, items: [{ type: "feat", name: "Bonded Infusion", flags: { [SYS]: auto.bondedInfusionFlags({ infused: true, held: false }) } }], appliedEffects: [] }).length, 0);
  const sa = await import(sys("module", "magic", "spell-adder.mjs"));
  equal("C …and a +1 spell adder while infused, the core's spell adder; none without", [sa.spellAdderSources({ items: [{ name: "Bonded Infusion", flags: { [SYS]: auto.bondedInfusionFlags({ infused: true }) } }] }).total, sa.spellAdderSources({ items: [{ name: "Bonded Infusion", flags: { [SYS]: auto.bondedInfusionFlags({ infused: false }) } }] }).total], [1, 0]);

  const uses = await import(sys("module", "uses.mjs"));
  equal("C the Focus feats (Resonance Surge, Spellblade’s Mark) have one use, the core's default", ["Resonance Surge", "Spellblade’s Mark"].map((n) => uses.focusDefaultUses(F[n].system, "feat")), [1, 1]);
  equal("C …and no other feat of the group is a Focus feat", C.FEATS_B6_C.filter((f) => uses.focusDefaultUses(f.system, "feat") !== null).map((f) => f.name), ["Resonance Surge", "Spellblade’s Mark"]);

  const pcs = await import(sys("module", "magic", "pending-cast-steps.mjs"));
  const sb = makeActor("ZZ Core Blade", { items: [it("Magical Retribution"), { name: "Longsword", type: "weapon", system: { equipped: true, attackMode: "melee" } }] });
  const foe = makeActor("ZZ Core Foe");
  makeToken("tfoe", foe, { x: 100, y: 0, disposition: -1 });
  canvas.tokens.placeables = [foe.token];
  reactorAnswers.push("yes");
  const stepLines = await pcs.pendingCastStepsBefore({ actor: sb, spellName: "Fireball", sourceUuid: foe.uuid, sourceName: foe.name, context: { kind: "strike", melee: true } });
  equal("C Magical Retribution: the core's pending-cast step asks, the reaction is spent, the AoO is made at the attacker before the window settles", [asked.at(-1)?.step, calls.spendReaction.at(-1)?.[1], calls.attacks.at(-1)?.targets, calls.attacks.at(-1)?.opts?.isReaction, stepLines.length], [auto.RETRIBUTION_STEP, "Magical Retribution", ["tfoe"], true, 1]);
  const before = asked.length;
  equal("C …not for a ranged Strike, nor a spell", [(await pcs.pendingCastStepsBefore({ actor: sb, sourceUuid: foe.uuid, context: { kind: "strike", melee: false } })).length, (await pcs.pendingCastStepsBefore({ actor: sb, sourceUuid: foe.uuid, context: { kind: "spell" } })).length, asked.length - before], [0, 0, 0]);
  canvas.tokens.placeables = [];
  capi.resetModuleRegistry();
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  const combat = { id: "c1", round: 3, turn: 0 };
  equal("D one sigil, three with Runic Reservoir", [auto.sigilCount({}), auto.sigilCount({ reservoir: true })], [1, 3]);
  equal("D a sigil: ready yes, spent no; reforming, ready after 10 rounds of that combat or 60 s",
    [auto.sigilReady({ state: "ready" }), auto.sigilReady({ state: "spent" }), auto.sigilReady({ state: "reforming", reformAt: 1060, reformRound: { combatId: "c1", round: 13 } }, { combat, worldTime: 1000 }), auto.sigilReady({ state: "reforming", reformAt: 1060, reformRound: { combatId: "c1", round: 13 } }, { combat: { ...combat, round: 13 }, worldTime: 1000 }), auto.sigilReady({ state: "reforming", reformAt: 1060, reformRound: null }, { worldTime: 1060 }), auto.sigilReady({ state: "reforming", reformAt: 1060, reformRound: { combatId: "c9", round: 1 } }, { combat, worldTime: 1000 })],
    [true, false, false, true, true, false]);
  equal("D one activation a round: the same round held, the next free; out of combat, 6 seconds",
    [auto.sigilLockHeld({ combatId: "c1", round: 3 }, { combat }), auto.sigilLockHeld({ combatId: "c1", round: 2 }, { combat }), auto.sigilLockHeld({ worldTime: 1000 }, { worldTime: 1005 }), auto.sigilLockHeld({ worldTime: 1000 }, { worldTime: 1006 }), auto.sigilLockHeld(null, { combat })], [true, false, true, false, false]);
  equal("D after its cast: spent; with Living Script reforming in 60 s / 10 rounds; a Heroic keeps it",
    [auto.sigilAfterCast({ state: "ready" }, { degree: "heroic" }).state, auto.sigilAfterCast({ state: "ready" }, { degree: "success", livingScript: true, combat, worldTime: 1000 }), auto.sigilAfterCast({ state: "ready" }, { degree: "heroic", livingScript: true }).state],
    ["spent", { state: "reforming", reformAt: 1060, reformRound: { combatId: "c1", round: 13 } }, "ready"]);
  equal("D a sigil's spell: a spell with a Symbol, not innate, not somatic-only", [auto.sigilSpellEligible({ type: "spell", system: { components: { verbal: true } } }), auto.sigilSpellEligible({ type: "spell", system: { innate: true, components: { verbal: true } } }), auto.sigilSpellEligible({ type: "spell", system: { components: { somatic: true } } }), auto.sigilSpellEligible({ type: "feat", system: { components: { verbal: true } } })], [true, false, false, false]);
  const base = { owned: true, runemage: true, marker: { level: 4 }, ctx: { spellData: { components: { verbal: true } } } };
  equal("D Ley-Etched Symbol offered: owned, a Runemage, the marker on, a Symbol cast, the round free",
    [auto.leyEtchedOffered(base), auto.leyEtchedOffered({ ...base, marker: null }), auto.leyEtchedOffered({ ...base, runemage: false }), auto.leyEtchedOffered({ ...base, ctx: { spellData: { components: { somatic: true } } } }), auto.leyEtchedOffered({ ...base, ctx: { ...base.ctx, innate: true } }), auto.leyEtchedOffered({ ...base, ctx: { ...base.ctx, itemCast: true } }), auto.leyEtchedOffered({ ...base, lock: { combatId: "c1", round: 3 }, combat }), auto.leyEtchedOffered({ ...base, owned: false })],
    [true, false, false, false, false, false, false, false]);
  equal("D its backlash: a Fumble or a Blunder", ["fumble", "blunder", "failure", "partial"].map(auto.leyBacklashDue), [true, true, false, false]);
  const sc = (tradition, ppCost, extra = {}) => auto.arcaneScribable({ system: { tradition, ppCost, ...extra } }, { casterLevel: 4 });
  equal("D Arcane Study's book: arcane, PP 1 to caster level + 1, no specialist, no cantrip", [sc("arcane", 1), sc("arcane, ethereal", 5), sc("arcane", 6), sc("divinity", 1), sc("arcane", 0), sc("arcane", 2, { specialist: true })], [true, true, false, false, false, false]);
  equal("D the school, by trait", [auto.schoolOf("Invocation, Fire"), auto.schoolOf("Cantrip"), auto.schoolOf(["Soul"])], ["invocation", "", "soul"]);
  equal("D Bespell's types by school (Q143)", [auto.bespellTypes({ school: "alteration", weaponType: "slashing" }), auto.bespellTypes({ school: "translocation", weaponType: "" }), auto.bespellTypes({ school: "insight" }), auto.bespellTypes({ school: "shadow" }), auto.bespellTypes({ school: "invocation", damageTypes: ["fire", "fire"] }), auto.bespellTypes({ school: "invocation" }), auto.bespellTypes({ school: "soul" }), auto.bespellTypes({ school: "warding" }), auto.bespellTypes({ school: "" })],
    [["bludgeoning", "piercing"], ["bludgeoning", "piercing", "slashing"], ["mental"], ["mental"], ["fire"], ["force"], ["essence"], ["force"], []]);
  equal("D Bespell: this turn's spell only; sustained the round after", [auto.bespellDue({ name: "x", combatId: "c1", round: 3, turn: 0 }, { combat }), auto.bespellDue({ name: "x", combatId: "c1", round: 2, turn: 0 }, { combat }), auto.bespellDue({ name: "x" }, {}), auto.bespellDue({ name: "x", combatId: "c1", round: 3, turn: 0 }, {}), auto.bespellSustainable({ bespelled: { combatId: "c1", round: 2 } }, { combat }), auto.bespellSustainable({ bespelled: { combatId: "c1", round: 1 } }, { combat })], [true, false, true, false, true, false]);
  equal("D Bonded Infusion's flags: the adder while infused, free somatic while held", [auto.bondedInfusionFlags({ infused: true, held: false }), auto.bondedInfusionFlags({})], [{ spellAdder: 1, freeSomatic: null }, { spellAdder: 0, freeSomatic: null }]);
  equal("D …its row: held, not innate, not an item's, not set aside", [auto.bondedInfusionRow({ held: true })?.value, auto.bondedInfusionRow({ held: false }), auto.bondedInfusionRow({ held: true, innate: true }), auto.bondedInfusionRow({ held: true, itemCast: true }), auto.bondedInfusionRow({ held: true, focusSetAside: true })], [2, null, null, null, null]);
  equal("D High Mage’s Focus: one pick, two at BSB +10", [9, 10].map(auto.focusPicksAllowed), [1, 2]);
  equal("D a High Magic spell is the Highmagic trait", [auto.isHighMagicSpell({ traits: "Highmagic, Fire" }), auto.isHighMagicSpell({ traits: "Fire" })], [true, false]);
  equal("D High Magic Resonance: the day's first Fumble; not a Blunder, an item's, or a second", [auto.hmrRemapDue({ degree: "fumble" }), auto.hmrRemapDue({ degree: "blunder" }), auto.hmrRemapDue({ degree: "fumble", itemCast: true }), auto.hmrRemapDue({ degree: "fumble", used: true })], [true, false, false, false]);
  equal("D Metamagic Adept: 1 or 2 AP casting times only", [1, 2, 3, "2", "1-3 AP", "1 minute", "Reaction", 0].map(auto.adeptCastTimeOk), [true, true, false, true, true, false, false, false]);
  equal("D Resonance Surge consumes on a levelled spell you cast", [auto.surgeConsumes({ spellData: { ppCost: 2 } }), auto.surgeConsumes({ spellData: { ppCost: 0 } }), auto.surgeConsumes({ spellData: { ppCost: 2 }, innate: true }), auto.surgeConsumes({ spellData: { ppCost: 2 }, threaded: true })], [true, false, false, false]);
  equal("D Magical Retribution: a melee Strike's damage, its striker known", [auto.retributionWants({ sourceUuid: "x", context: { kind: "strike", melee: true } }), auto.retributionWants({ context: { kind: "strike", melee: true } }), auto.retributionWants({ sourceUuid: "x", context: { kind: "strike", melee: false } })], [true, false, false]);
  equal("D the Mark's gate row: an attack at the Mark only", [Boolean(auto.markGateRow({ markUuid: "A", targetUuids: ["A"], attack: true })), auto.markGateRow({ markUuid: "A", targetUuids: ["B"], attack: true }), auto.markGateRow({ markUuid: "A", targetUuids: ["A"], attack: false })], [true, null, null]);
  const a6 = await import(new URL("../module/block6a-automations.mjs", import.meta.url)).catch(() => null);
  if (a6?.BORROWED_BIRTHRIGHT_FLAG) equal("D the borrowed birthright is read under group A's flag", auto.BORROWED_BIRTHRIGHT_FLAG, a6.BORROWED_BIRTHRIGHT_FLAG);
  equal("D the numbers: the Mark 60 ft and 1d6, Bespell 1d6, Considered +2 for 1 AP, Focus +2, Surge 2 PP, three sigils, 60 s / 10 rounds",
    [auto.MARK_FEET, auto.MARK_DICE, auto.BESPELL_DICE, auto.CONSIDERED_BONUS, auto.CONSIDERED_EXTRA_AP, auto.HMF_BONUS, auto.SURGE_FREE_PP, auto.RESERVOIR_SIGILS, auto.SIGIL_REFORM_SECONDS, auto.SIGIL_REFORM_ROUNDS], [60, "1d6", "1d6", 2, 1, 2, 2, 3, 60, 10]);
  const ab = (name, extra = {}) => ({ type: "ability", name, flags: { [SYS]: { eaBirthright: name } }, system: {}, ...extra });
  const who = (list) => ({ items: list });
  equal("D the birthrights: a Sorcerer's own; a High Mage's or Birthrager's pick (Q100); a switched-off one no",
    [auto.arcaneStudyBlock(who([ab("Arcanum")])), Boolean(auto.arcaneStudyBlock(who([ab("Dragon")]))), auto.arcaneStudyBlock(who([{ type: "feat", name: "High Mage", flags: { [SYS]: { eaBorrowedBirthright: "Arcanum" } } }])), auto.resonanceSurgeBlock(who([ab("Wild")])), Boolean(auto.resonanceSurgeBlock(who([ab("Wild", { system: { active: false } })]))), Boolean(auto.highMagicResonanceBlock(who([ab("Wild")]))), auto.highMagicResonanceBlock(who([ab("Storm")]))],
    [null, true, null, null, true, true, null]);
}

/* ----------------------------------------------------------------- */
/* E — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const got = { autos: {}, prelude: [], mm: [], pay: [], res: [], remap: [], gates: [], pending: [], elig: [], steps: [] };
  const api = new Proxy({}, { get: (_, k) => ({
    registerFeatAutomation: (n, e) => { got.autos[n] = e; }, registerCastPrelude: (n, f) => got.prelude.push([n, f]), registerMetamagic: (n, s) => got.mm.push([n, s]),
    registerMetamagicPayment: (n, s) => got.pay.push([n, s]), registerResonanceModifier: (n, s) => got.res.push([n, s]), registerCastDegreeRemap: (n, f) => got.remap.push([n, f]),
    registerSpellCheckGate: (n, f) => got.gates.push([n, f]), registerPendingCastStep: (n, f) => got.pending.push([n, f]), registerFeatEligibility: (n, f) => got.elig.push([n, f]), registerReactionStep: (n, f) => got.steps.push([n, f])
  })[k] ?? (() => {}) });
  auto.registerBlock6C(api, MOD);
  equal("E the Uses, by the items' names", Object.keys(got.autos), ["Prepared Sigil", "Arcane Study", "Bespell Weapon", "Call Bonded Weapon", "Considered Attack", "High Mage’s Focus", "Magical Retribution", "Resonance Surge", "Spellblade’s Mark"]);
  ok("E …each a feat of this group with a use()", Object.keys(got.autos).every((n) => F[n] && typeof got.autos[n].use === "function"));
  equal("E the prelude, the metamagic, the payment", [got.prelude.map(([n, f]) => [n, f === auto.preparedSigilPrelude]), got.mm.map(([n, s]) => [n, s === auto.LEY_ETCHED_METAMAGIC || s === auto.RESONANCE_SURGE_METAMAGIC]), got.pay.map(([n, s]) => [n, s === auto.METAMAGIC_ADEPT_PAYMENT])], [[["preparedSigil", true]], [["leyEtchedSymbol", true], ["resonanceSurge", true]], [["metamagicAdept", true]]]);
  equal("E two Resonance modifiers (High Magic Resonance's roll, Resonance Surge's force), one remap", [got.res.map(([n, s]) => [n, typeof s.roll, typeof s.force]), got.remap.map(([n, f]) => [n, f === auto.highMagicResonanceRemap])], [[["highMagicResonance", "function", "undefined"], ["resonanceSurge", "undefined", "function"]], [["highMagicResonance", true]]]);
  equal("E three gates, the pending step, three eligibilities, the reaction step", [got.gates.map(([n]) => n), got.pending.map(([n]) => n), got.elig.map(([n, f]) => [n, typeof f]), got.steps.map(([n]) => n)],
    [["bondedInfusion", "highMagesFocus", "spellbladesMark"], ["magicalRetribution"], [["Arcane Study", "function"], ["High Magic Resonance", "function"], ["Resonance Surge", "function"]], [auto.RETRIBUTION_STEP]]);
  ok("E the eligibility names are the items' names", got.elig.every(([n]) => F[n]));
  const src = fs.readFileSync(path.join(ROOT, "module", "block6c-automations.mjs"), "utf8");
  ok("E the hook handlers the lead wires are exported, each documented with its Hooks event", ["onSpellSettledB6C", "onDailyPreparationB6C", "onActorUpdatedB6C", "onItemUpdatedB6C", "onItemCreatedB6C", "onCombatDeletedB6C"].every((n) => typeof auto[n] === "function" && new RegExp(`Hooks\\.(on|once)\\("[A-Za-z]+"[^\\n]*\\n(?:[^\\n]*\\n){0,3}?export async function ${n}\\(`).test(src)));
  ok("E the ley-benefit marker helper is exported for Block 2's lead wiring", typeof auto.layLeyBenefitMarker === "function" && auto.leyBenefitMarkerData({ level: 3 }).flags[MOD].source === auto.LEY_BENEFIT_SOURCE);
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side, with fakes                                    */
/* ----------------------------------------------------------------- */
const item = (name, extra = {}) => ({ ...JSON.parse(JSON.stringify(F[name])), _id: `id-${name}`, ...extra });
const runemage = { name: "Runemage", type: "feat", system: {}, flags: {} };
const spell = (name, extra = {}) => ({ _id: `sp-${name}`, name, type: "spell", system: { ppCost: 2, components: { verbal: true, somatic: true }, traits: "Invocation, Fire", ...extra }, flags: {} });
{
  // Prepared Sigil: the Use.
  const rm = makeActor("ZZ Runemage", { items: [runemage, item("Prepared Sigil"), spell("Fireball"), spell("Shield", { components: { somatic: true } }), spell("Light", { innate: true }), spell("Haste")] });
  const feat = () => rm.items.find((i) => i.name === "Prepared Sigil");
  castable = (s) => s.name !== "Haste";
  answers.push("sp-Fireball");
  await auto.AUTOMATIONS_B6_C["Prepared Sigil"].use(rm, feat());
  equal("F Prepared Sigil: the Use offers castable non-innate Symbol spells only, and inscribes one", [helpers.lastOptions.map(([id]) => id), feat().flags[MOD][auto.SIGILS_FLAG]], [["sp-Fireball"], [{ spellId: "sp-Fireball", name: "Fireball", state: "ready" }]]);
  const again = await auto.AUTOMATIONS_B6_C["Prepared Sigil"].use(rm, feat());
  ok("F …once until the next daily preparation", again === false && /today's sigils are inscribed/.test(cards.at(-1)?.warn ?? ""));
  // The prelude.
  const fb = rm.items.find((i) => i.name === "Fireball");
  const out = await auto.preparedSigilPrelude({ actor: rm, spell: fb, options: {} });
  equal("F …casting it, the prelude asks and casts through the core's prepared Symbol (G25)", [out?.handled, calls.casts.at(-1)?.options, confirms.length > 0], [true, { preparedSymbol: { label: "Prepared Sigil" } }, true]);
  confirms.answer = false;
  equal("F …declined, the ordinary cast goes on", await auto.preparedSigilPrelude({ actor: rm, spell: fb, options: {} }), null);
  confirms.answer = true;
  const n = calls.casts.length;
  equal("F …another spell is not asked", [await auto.preparedSigilPrelude({ actor: rm, spell: rm.items.find((i) => i.name === "Shield") }), calls.casts.length], [null, n]);
  // Settled: spent.
  await auto.onSpellSettledB6C({ actor: rm, spell: fb, spellData: fb.system, degree: "success", cast: false, refunded: true, preparedSymbol: true });
  equal("F …a cast called off at the target picker (refunded) keeps it", feat().flags[MOD][auto.SIGILS_FLAG][0].state, "ready");
  await auto.onSpellSettledB6C({ actor: rm, spell: fb, spellData: fb.system, degree: "success", cast: true, preparedSymbol: true });
  equal("F …it fades when its cast settles", feat().flags[MOD][auto.SIGILS_FLAG][0].state, "spent");
  equal("F …and is not offered again", await auto.preparedSigilPrelude({ actor: rm, spell: fb }), null);
  await auto.onSpellSettledB6C({ actor: rm, spell: fb, spellData: fb.system, degree: "success", cast: true, preparedSymbol: false });
  // Daily preparation clears.
  await auto.onDailyPreparationB6C({ actor: rm });
  ok("F …daily preparation clears the sigils and says so", !feat().flags[MOD][auto.SIGILS_FLAG] && !feat().flags[MOD][auto.SIGILS_INSCRIBED_FLAG] && /inscribe today's/.test(cards.at(-1)?.lines?.[0] ?? ""));
  // Runic Reservoir and Living Script.
  const lv = makeActor("ZZ Living", { items: [runemage, item("Prepared Sigil"), item("Runic Reservoir"), item("Living Script"), spell("Fireball"), spell("Haste"), spell("Slow"), spell("Web")] });
  castable = () => true;
  const lf = () => lv.items.find((i) => i.name === "Prepared Sigil");
  answers.push("sp-Fireball", "sp-Haste", "sp-Slow", "sp-Web");
  const left = () => answers.length;
  await auto.AUTOMATIONS_B6_C["Prepared Sigil"].use(lv, lf());
  equal("F Runic Reservoir: three sigils, each a different spell, and no fourth asked", [lf().flags[MOD][auto.SIGILS_FLAG].map((s) => s.name), left()], [["Fireball", "Haste", "Slow"], 1]);
  answers.length = 0;
  startCombat(lv, { round: 2 });
  const lfb = lv.items.find((i) => i.name === "Fireball"), lh = lv.items.find((i) => i.name === "Haste");
  await auto.onSpellSettledB6C({ actor: lv, spell: lfb, spellData: lfb.system, degree: "success", cast: true, preparedSymbol: true });
  const rs = lf().flags[MOD][auto.SIGILS_FLAG][0];
  equal("F Living Script: reforming, after 10 rounds or 60 s", [rs.state, rs.reformAt, rs.reformRound], ["reforming", 1060, { combatId: "c1", round: 12 }]);
  equal("F …one activation a round: Haste is not offered this round", await auto.preparedSigilPrelude({ actor: lv, spell: lh }), null);
  game.combat.round = 3;
  ok("F …next round it is", (await auto.preparedSigilPrelude({ actor: lv, spell: lh }))?.handled === true);
  equal("F …Fireball still reforming", await auto.preparedSigilPrelude({ actor: lv, spell: lfb }), null);
  game.combat.round = 12;
  ok("F …ready again after 10 rounds", (await auto.preparedSigilPrelude({ actor: lv, spell: lfb }))?.handled === true);
  await auto.onSpellSettledB6C({ actor: lv, spell: lh, spellData: lh.system, degree: "heroic", cast: true, preparedSymbol: true });
  equal("F …a Heroic keeps the sigil ready", lf().flags[MOD][auto.SIGILS_FLAG][1].state, "ready");
  game.combat = null;

  // Ley-Etched Symbol.
  const ley = makeActor("ZZ Ley", { items: [runemage, item("Ley-Etched Symbol")] });
  const L = auto.LEY_ETCHED_METAMAGIC;
  const ctx = { actor: ley, spellData: { components: { verbal: true } } };
  equal("F Ley-Etched Symbol: not offered without the ley benefit", L.applies(ctx), false);
  await auto.layLeyBenefitMarker(ley, { level: 4, name: "Silverline", expiry: forSecondsFake(60) });
  equal("F …with the marker, offered on a Symbol cast, not a somatic-only one", [L.applies(ctx), L.applies({ ...ctx, spellData: { components: { somatic: true } } })], [true, false]);
  await auto.layLeyBenefitMarker(ley, { level: 4, name: "Silverline" });
  equal("F …one marker at a time", ley.effects.filter((e) => e.flags[MOD].source === auto.LEY_BENEFIT_SOURCE).length, 1);
  startCombat(ley, { round: 4 });
  await L.after({ ...ctx, degree: "success" });
  equal("F …once a round", L.applies(ctx), false);
  game.combat.round = 5;
  ok("F …next round again", L.applies(ctx) === true);
  rollTotal = 47;
  const said = await L.after({ ...ctx, degree: "fumble" });
  const bl = ley.effects.find((e) => e.flags[MOD].source === "leyLineBacklash");
  ok("F …a Fumble rolls the ley line's backlash at its level, to the end of your next turn", Boolean(bl) && /Weakened/.test(bl.name) && Boolean(bl.flags[MOD].endsAfterTurn) && /level 4/.test(said?.lines?.[0] ?? ""));
  game.combat = null;

  // Arcane Study.
  const arc = makeActor("ZZ Arcanum", { items: [item("Arcane Study"), spell("Magic Missile", { tradition: "arcane", ppCost: 1 })], casterLevel: 4 });
  const af = () => arc.items.find((i) => i.name === "Arcane Study");
  const packEntries = [["Magic Missile", "arcane", 1], ["Fireball", "arcane", 3], ["Wish", "arcane", 9], ["Cure", "divinity", 1], ["Prestidigitation", "arcane", 0]].map(([name, tradition, ppCost], i) => ({ _id: `p${i}`, name, uuid: `Compendium.trg-prime.spells.Item.p${i}`, system: { tradition, ppCost }, flags: {} }));
  const pack = { collection: "trg-prime.spells", documentName: "Item", metadata: {}, getIndex: async () => new Map(packEntries.map((e) => [e._id, e])), getDocument: async (id) => { const e = packEntries.find((x) => x._id === id); return e ? { name: e.name, toObject: () => ({ ...JSON.parse(JSON.stringify(e)), type: "spell", system: { ...e.system, components: {} } }) } : null; } };
  game.packs = [pack];
  for (const e of packEntries) uuidMap.set(e.uuid, { name: e.name, toObject: () => ({ ...JSON.parse(JSON.stringify(e)), type: "spell", system: { ...e.system } }) });
  answers.push("scribe", "1");
  checkDegree = "success";
  await auto.AUTOMATIONS_B6_C["Arcane Study"].use(arc, af());
  equal("F Arcane Study: scribing offers arcane PP 1 to caster level + 1 only, by Learn a Spell's Arcana check and price", [helpers.lastOptions.map(([, l]) => l), calls.rollCheck.at(-1)?.subject, calls.rollCheck.at(-1)?.dc, calls.gold.at(-1), af().flags[MOD][auto.ARCANE_BOOK_FLAG]?.map((b) => b.name)], [["Fireball (PP 3)", "Magic Missile (PP 1)"], "arcana", 16, 10, ["Magic Missile"]]);
  checkDegree = "failure";
  answers.push("scribe", "0");
  await auto.AUTOMATIONS_B6_C["Arcane Study"].use(arc, af());
  equal("F …a failed check scribes nothing (half the materials, as Learn a Spell)", [af().flags[MOD][auto.ARCANE_BOOK_FLAG].length, calls.gold.at(-1)], [1, 15]);
  checkDegree = "success";
  answers.push("scribe", "0");
  await auto.AUTOMATIONS_B6_C["Arcane Study"].use(arc, af());
  answers.push("1");
  await auto.onDailyPreparationB6C({ actor: arc });
  const day = arc.items.find((i) => i.name === "Fireball");
  equal("F …daily preparation: an unknown book spell joins the repertoire for the day, granted by the feat", [Boolean(day), day?.flags?.[MOD]?.[auto.ARCANE_DAILY_FLAG], day?.flags?.[SYS]?.grantedBy?.sourceName, day?.system?.prepared], [true, true, "Arcane Study", true]);
  answers.push("0");
  await auto.onDailyPreparationB6C({ actor: arc });
  const mm = arc.items.find((i) => i.name === "Magic Missile");
  equal("F …the next: yesterday's spell is gone; a known one is warped 1 cheaper (Q142)", [arc.items.some((i) => i.name === "Fireball"), mm.flags[SYS]?.warpDiscount, af().flags[MOD][auto.ARCANE_TODAY_FLAG]?.mode], [false, 1, "discount"]);
  answers.push(null);
  await auto.onDailyPreparationB6C({ actor: arc });
  equal("F …and the discount is taken back the day after", mm.flags[SYS]?.warpDiscount, 0);
  game.packs = [];

  // Bespell Weapon.
  const sb = makeActor("ZZ Bespeller", { items: [item("Bespell Weapon"), { _id: "w1", name: "Longsword", type: "weapon", system: { equipped: true, damageType: "slashing" } }] });
  startCombat(sb, { round: 2 });
  await auto.AUTOMATIONS_B6_C["Bespell Weapon"].use(sb, sb.items[0]);
  ok("F Bespell Weapon: refused with no spell cast this turn", /cast a spell this turn first/.test(cards.at(-1)?.warn ?? ""));
  await auto.onSpellSettledB6C({ actor: sb, spell: { name: "Blink" }, spellData: { traits: "Translocation" }, cast: true });
  answers.push("piercing");
  await auto.AUTOMATIONS_B6_C["Bespell Weapon"].use(sb, sb.items[0]);
  const be = sb.effects.find((e) => e.flags[MOD].source === auto.BESPELL_SOURCE);
  equal("F …a Translocation spell: a physical type other than the weapon's; a weapon-scoped 1d6 rider to the end of the turn", [helpers.lastOptions.map(([v]) => v), be?.flags?.[SYS]?.strikeRider, Boolean(be?.flags?.[MOD]?.endsAfterTurn), sb.system.resources.ap.value], [["bludgeoning", "piercing"], { label: "Bespell Weapon", dice: "1d6", damageType: "piercing", scope: "any", weaponScoped: true, weaponId: "w1", once: false }, true, 3]);
  game.combat.round = 3;
  await auto.AUTOMATIONS_B6_C["Bespell Weapon"].use(sb, sb.items[0]);
  equal("F …sustained next round: 1 AP, Concentrate, the same type", [sb.system.resources.ap.value, calls.traitGate.at(-1), sb.effects.find((e) => e.flags[MOD].source === auto.BESPELL_SOURCE)?.flags?.[SYS]?.strikeRider?.damageType], [2, ["bespellSustain", "Concentrate"], "piercing"]);
  game.combat.round = 5;
  await auto.AUTOMATIONS_B6_C["Bespell Weapon"].use(sb, sb.items[0]);
  ok("F …not after a round's gap", /cast a spell this turn first/.test(cards.at(-1)?.warn ?? ""));
  await auto.onSpellSettledB6C({ actor: sb, spell: { name: "Mystery" }, spellData: { traits: "Cantrip" }, cast: true });
  await auto.AUTOMATIONS_B6_C["Bespell Weapon"].use(sb, sb.items[0]);
  ok("F …a spell with no school gives no type", /no spell school/.test(cards.at(-1)?.warn ?? ""));
  game.combat = null;

  // Bonded Infusion.
  const bi = makeActor("ZZ Infuser", { items: [item("Bonded Infusion"), { _id: "w2", name: "Rapier", type: "weapon", system: { equipped: false } }] });
  const bf = () => bi.items.find((i) => i.name === "Bonded Infusion");
  await auto.syncBondedInfusion(bi);
  equal("F Bonded Infusion: nothing without an infusion", [bf().flags[SYS].spellAdder ?? 0, bf().flags[SYS].freeSomatic ?? null, await auto.bondedInfusionGate({ actor: bi })], [0, null, null]);
  bi.flags[SYS] = { infusedRunes: { weaponId: "w2", runes: "" } };
  await auto.onActorUpdatedB6C(bi, { flags: { [SYS]: { infusedRunes: {} } } });
  equal("F …infused: the +1 spell adder; not held, no free somatic and no +2", [bf().flags[SYS].spellAdder, bf().flags[SYS].freeSomatic ?? null, await auto.bondedInfusionGate({ actor: bi })], [1, null, null]);
  bi.items.find((i) => i.id === "w2").system.equipped = true;
  await auto.onItemUpdatedB6C(bi.items.find((i) => i.id === "w2"), { system: { equipped: true } });
  const gate = await auto.bondedInfusionGate({ actor: bi });
  equal("F …held: free somatic and +2 item on the casting check", [Boolean(bf().flags[SYS].freeSomatic), gate?.modifiers?.[0]], [true, { label: "Bonded Infusion (infused weapon)", value: 2, type: "item" }]);
  equal("F …not for an innate or item cast; set aside under High Magic", [await auto.bondedInfusionGate({ actor: bi, innate: true }), await auto.bondedInfusionGate({ actor: bi, itemCast: true }), (await auto.bondedInfusionGate({ actor: bi, highMagic: true }))?.modifiers], [null, null, undefined]);
  delete bi.flags[SYS].infusedRunes;
  await auto.onDailyPreparationB6C({ actor: bi });
  equal("F …the infusion over, both are lifted", [bf().flags[SYS].spellAdder, "freeSomatic" in bf().flags[SYS]], [0, false]);

  // Call Bonded Weapon.
  const cb = makeActor("ZZ Caller", { items: [item("Call Bonded Weapon"), { _id: "ally", name: "Divine Ally", type: "ability", system: {}, flags: { [SYS]: { bladeAlly: { weaponId: "w3", weaponName: "Mace" } } } }, { _id: "w3", name: "Mace", type: "weapon", system: { equipped: false } }] });
  startCombat(cb);
  await auto.AUTOMATIONS_B6_C["Call Bonded Weapon"].use(cb, cb.items[0]);
  equal("F Call Bonded Weapon: the Blade Ally's weapon is equipped, 1 AP, Manipulate", [cb.items.find((i) => i.id === "w3").system.equipped, cb.system.resources.ap.value, calls.traitGate.at(-1)], [true, 2, ["callBondedWeapon", "Manipulate"]]);
  await auto.AUTOMATIONS_B6_C["Call Bonded Weapon"].use(cb, cb.items[0]);
  ok("F …not again while in hand", /already in your hand/.test(cards.at(-1)?.warn ?? "") && cb.system.resources.ap.value === 2);
  game.combat = null;
  const lost = makeActor("ZZ Lost", { items: [item("Call Bonded Weapon"), { _id: "ally2", name: "Divine Ally", type: "ability", system: {}, flags: { [SYS]: { bladeAlly: { weaponId: "gone", weaponName: "Axe" } } } }] });
  equal("F …a weapon not on the sheet: the card says the GM moves it", [await auto.AUTOMATIONS_B6_C["Call Bonded Weapon"].use(lost, lost.items[0]), /GM moves it/.test(cards.at(-1)?.lines?.[0] ?? "")], [false, true]);

  // Considered Attack.
  const ca = makeActor("ZZ Considerer", { items: [item("Considered Attack"), { _id: "w4", name: "Spear", type: "weapon", system: { equipped: true } }] });
  startCombat(ca);
  await auto.AUTOMATIONS_B6_C["Considered Attack"].use(ca, ca.items[0]);
  equal("F Considered Attack: the core's Strike with +2 untyped, and 1 AP more", [calls.attacks.at(-1)?.opts?.extraModifiers, ca.system.resources.ap.value], [[{ label: "Considered Attack", value: 2, type: "untyped" }], 2]);
  ca.system.resources.ap.value = 1;
  const nAtt = calls.attacks.length;
  await auto.AUTOMATIONS_B6_C["Considered Attack"].use(ca, ca.items[0]);
  ok("F …refused with 1 AP left (2 needed)", calls.attacks.length === nAtt && /2 AP required/.test(cards.at(-1)?.warn ?? ""));
  game.combat = null;

  // High Mage's Focus.
  const hm = makeActor("ZZ High Mage", { items: [item("High Mage’s Focus"), spell("Meteor", { traits: "Highmagic, Invocation" }), spell("Bolt", { traits: "Highmagic" }), spell("Spark", { traits: "Invocation" })], bsb: 9 });
  const hf = () => hm.items.find((i) => i.name === "High Mage’s Focus");
  answers.push("sp-Meteor");
  await auto.AUTOMATIONS_B6_C["High Mage’s Focus"].use(hm, hf());
  equal("F High Mage’s Focus: the Use offers your High Magic spells, and keeps the pick", [helpers.lastOptions.map(([id]) => id), hf().flags[MOD][auto.HMF_PICKS_FLAG].map((p) => p.name)], [["sp-Meteor", "sp-Bolt"], ["Meteor"]]);
  equal("F …its casts take +2 on the casting check only; another spell nothing", [(await auto.highMagesFocusGate({ actor: hm, spell: hm.items.find((i) => i.name === "Meteor") }))?.modifiers?.[0]?.castingOnly, await auto.highMagesFocusGate({ actor: hm, spell: hm.items.find((i) => i.name === "Bolt") }), await auto.highMagesFocusGate({ actor: hm, spell: hm.items.find((i) => i.name === "Meteor"), innate: true })], [true, null, null]);
  await auto.AUTOMATIONS_B6_C["High Mage’s Focus"].use(hm, hf());
  ok("F …one pick below BSB +10", /chosen 1 of 1/.test(cards.at(-1)?.warn ?? ""));
  hm.system.progression.bsb = 10;
  await auto.onActorUpdatedB6C(hm, { system: { progression: { bsb: 10 } } });
  ok("F …at BSB +10 a card reminds you, once", /second High Magic spell/.test(cards.at(-1)?.lines?.[0] ?? "") && hf().flags[MOD][auto.HMF_NOTED_FLAG] === true);
  answers.push("sp-Bolt");
  await auto.AUTOMATIONS_B6_C["High Mage’s Focus"].use(hm, hf());
  equal("F …and the Use chooses the second", hf().flags[MOD][auto.HMF_PICKS_FLAG].map((p) => p.name), ["Meteor", "Bolt"]);

  // High Magic Resonance's remap.
  const hr = makeActor("ZZ HMR", { items: [item("High Magic Resonance")] });
  const r1 = await auto.highMagicResonanceRemap({ actor: hr, degree: "fumble" });
  equal("F High Magic Resonance: the day's first Fumble becomes a Failure, and only the first", [r1?.degree, await auto.highMagicResonanceRemap({ actor: hr, degree: "fumble" })], ["failure", null]);
  await auto.onDailyPreparationB6C({ actor: hr });
  equal("F …daily preparation restores it; a Blunder is not eased", [await auto.highMagicResonanceRemap({ actor: hr, degree: "blunder" }), (await auto.highMagicResonanceRemap({ actor: hr, degree: "fumble" }))?.degree], [null, "failure"]);

  // Metamagic Adept's applies.
  const ad = makeActor("ZZ Adept", { items: [item("Metamagic Adept")] });
  const ap = auto.METAMAGIC_ADEPT_PAYMENT.applies;
  traitBlocked = false;
  equal("F Metamagic Adept: a 1–2 AP spell yes; 3 AP no; an item cast no; without the feat no", [await ap({ actor: ad, castAP: 2 }), await ap({ actor: ad, castAP: 3 }), await ap({ actor: ad, castAP: 1, itemCast: true }), await ap({ actor: makeActor("ZZ No Adept"), castAP: 1 })], [true, false, false, false]);
  traitBlocked = true;
  equal("F …in combat, not once a Flourish has been used this turn", [await ap({ actor: ad, castAP: 2, inCombat: true }), await ap({ actor: ad, castAP: 2, inCombat: false })], [false, true]);
  traitBlocked = false;
  const nRec = calls.recordTrait.length;
  await auto.onSpellSettledB6C({ actor: ad, spell: { name: "Bolt" }, spellData: { ppCost: 2 }, cast: true, metamagicPayments: ["metamagicadept"] });
  equal("F …out of combat, a paid cast records no Flourish", calls.recordTrait.length, nRec);
  startCombat(ad);
  await auto.onSpellSettledB6C({ actor: ad, spell: { name: "Bolt" }, spellData: { ppCost: 2 }, cast: true, metamagicPayments: [] });
  equal("F …nor a cast that did not take the AP payment", calls.recordTrait.length, nRec);
  await auto.onSpellSettledB6C({ actor: ad, spell: { name: "Bolt" }, spellData: { ppCost: 2 }, cast: true, metamagicPayments: ["metamagicadept"] });
  equal("F …in combat, a cast that paid in AP records this turn's Flourish (the hooks' metamagicPayments)", calls.recordTrait.at(-1), ["metamagicAdept", "Flourish"]);
  game.combat = null;

  // Resonance Surge.
  const rsu = makeActor("ZZ Wild", { items: [item("Resonance Surge", { system: { ...F["Resonance Surge"].system, usesValue: 1 } })] });
  await auto.AUTOMATIONS_B6_C["Resonance Surge"].use(rsu, rsu.items[0]);
  const arm = rsu.effects.find((e) => e.flags[MOD].source === auto.SURGE_SOURCE);
  equal("F Resonance Surge: the Use arms a marker only — no always-on free-warp flag", [Boolean(arm), arm?.flags?.[SYS]?.warpFreeSchool ?? null], [true, null]);
  equal("F …its G1 option applies to the armed caster's levelled spell; not a cantrip, a ritual, an item's or a stored release", [auto.RESONANCE_SURGE_METAMAGIC.applies({ actor: rsu, spellData: { ppCost: 2 } }), auto.RESONANCE_SURGE_METAMAGIC.applies({ actor: rsu, spellData: { ppCost: 0 } }), auto.RESONANCE_SURGE_METAMAGIC.applies({ actor: rsu, spellData: { ppCost: 2 }, ritual: true }), auto.RESONANCE_SURGE_METAMAGIC.applies({ actor: rsu, spellData: { ppCost: 2 }, itemCast: true }), auto.RESONANCE_SURGE_METAMAGIC.applies({ actor: rsu, spellData: { ppCost: 2 }, stored: true }), auto.RESONANCE_SURGE_METAMAGIC.required], [true, false, false, false, false, true]);
  await auto.AUTOMATIONS_B6_C["Resonance Surge"].use(rsu, rsu.items[0]);
  ok("F …not twice", rsu.effects.filter((e) => e.flags[MOD].source === auto.SURGE_SOURCE).length === 1 && /already armed/.test(cards.at(-1)?.warn ?? ""));
  equal("F …the force answers for the levelled spell that took it", [Boolean(auto.RESONANCE_SURGE.force({ actor: rsu, spellData: { ppCost: 2 }, metamagic: ["resonancesurge"] })), auto.RESONANCE_SURGE.force({ actor: rsu, spellData: { ppCost: 0 }, metamagic: ["resonancesurge"] }), auto.RESONANCE_SURGE.force({ actor: rsu, spellData: { ppCost: 2 } })], [true, null, null]);
  await auto.onSpellSettledB6C({ actor: rsu, spell: { name: "Cantrip" }, spellData: { ppCost: 0 }, cast: true });
  equal("F …a cantrip does not spend it", rsu.effects.filter((e) => e.flags[MOD].source === auto.SURGE_SOURCE).length, 1);
  await auto.onSpellSettledB6C({ actor: rsu, spell: { name: "Bolt" }, spellData: { ppCost: 2 }, cast: false, refunded: true, metamagic: ["resonancesurge"] });
  equal("F …a refunded cast does not spend it", rsu.effects.filter((e) => e.flags[MOD].source === auto.SURGE_SOURCE).length, 1);
  await auto.onSpellSettledB6C({ actor: rsu, spell: { name: "Bolt" }, spellData: { ppCost: 2 }, cast: true, stored: true, metamagic: ["resonancesurge"] });
  equal("F …nor a stored release", rsu.effects.filter((e) => e.flags[MOD].source === auto.SURGE_SOURCE).length, 1);
  await auto.onSpellSettledB6C({ actor: rsu, spell: { name: "Bolt" }, spellData: { ppCost: 2 }, cast: false, metamagic: ["resonancesurge"] });
  equal("F …a levelled spell that took it does, whatever its degree", rsu.effects.filter((e) => e.flags[MOD].source === auto.SURGE_SOURCE).length, 0);
  await auto.AUTOMATIONS_B6_C["Resonance Surge"].use(rsu, rsu.items[0]);
  await auto.onDailyPreparationB6C({ actor: rsu });
  equal("F …daily preparation disarms an unused one", rsu.effects.filter((e) => e.flags[MOD].source === auto.SURGE_SOURCE).length, 0);

  // Spellblade's Mark.
  const mk = makeActor("ZZ Marker", { items: [item("Spellblade’s Mark")] });
  const enemy = makeActor("ZZ Enemy"), friend = makeActor("ZZ Friend"), far = makeActor("ZZ Far");
  const tm = makeToken("tm", mk, { x: 0, y: 0 }), te = makeToken("te", enemy, { x: 400, y: 0, disposition: -1 }), tf = makeToken("tf", friend, { x: 200, y: 0 }), tx = makeToken("tx", far, { x: 1500, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tm, te, tf, tx];
  startCombat(mk);
  game.user.targets = new Set([tf]);
  await auto.AUTOMATIONS_B6_C["Spellblade’s Mark"].use(mk, mk.items[0]);
  ok("F Spellblade’s Mark: not an ally", /must be an enemy/.test(cards.at(-1)?.warn ?? "") && !mk.effects.length);
  game.user.targets = new Set([tx]);
  await auto.AUTOMATIONS_B6_C["Spellblade’s Mark"].use(mk, mk.items[0]);
  ok("F …not beyond 60 ft", /within 60 feet/.test(cards.at(-1)?.warn ?? "") && !mk.effects.length);
  game.user.targets = new Set([te]);
  await auto.AUTOMATIONS_B6_C["Spellblade’s Mark"].use(mk, mk.items[0]);
  const me = mk.effects.find((e) => e.flags[MOD].source === auto.MARK_SOURCE);
  equal("F …an enemy within 60 ft: its four parts on one effect, by its uuid; 1 AP; Concentrate", [JSON.stringify(Object.fromEntries(["conditionals", "strikeRider", "spellDamageRider", "defenceDC"].map((k) => [k, me?.flags?.[SYS]?.[k]]))) === JSON.stringify(auto.markFlags(enemy.uuid)), me?.flags?.[MOD]?.markUuid, mk.system.resources.ap.value, /Concentrate/.test(calls.traitGate.at(-1)?.[1] ?? "")], [true, enemy.uuid, 2, true]);
  equal("F …its spell-attack row: an attack at the Mark; not a save spell, not another target", [(await auto.spellbladesMarkGate({ actor: mk, attack: true, targetUuids: [enemy.uuid] }))?.modifiers?.[0]?.attackOnly, await auto.spellbladesMarkGate({ actor: mk, attack: false, targetUuids: [enemy.uuid] }), await auto.spellbladesMarkGate({ actor: mk, attack: true, targetUuids: [far.uuid] })], [true, null, null]);
  game.user.targets = new Set([tx]);
  tx.center = { x: 300, y: 0 }; tx.document._source = { x: 250, y: -50, width: 1, height: 1 };
  await auto.AUTOMATIONS_B6_C["Spellblade’s Mark"].use(mk, mk.items[0]);
  equal("F …a new Mark replaces the old", mk.effects.filter((e) => e.flags[MOD].source === auto.MARK_SOURCE).map((e) => e.flags[MOD].markUuid), [far.uuid]);
  await auto.onCombatDeletedB6C({ id: "c9", combatants: [{ actor: mk }] });
  equal("F …another combat's end leaves it", mk.effects.filter((e) => e.flags[MOD].source === auto.MARK_SOURCE).length, 1);
  await auto.onCombatDeletedB6C({ id: "c1", combatants: [{ actor: mk }] });
  equal("F …its encounter's end removes it", mk.effects.filter((e) => e.flags[MOD].source === auto.MARK_SOURCE).length, 0);
  game.combat = null;
  game.user.targets = new Set();
  canvas.tokens.placeables = [];

  // Magical Retribution's Use (the table's call).
  const mr = makeActor("ZZ Retributor", { items: [item("Magical Retribution"), { _id: "w5", name: "Blade", type: "weapon", system: { equipped: true } }] });
  await auto.AUTOMATIONS_B6_C["Magical Retribution"].use(mr, mr.items[0]);
  ok("F Magical Retribution's Use: target your attacker first", /target the creature/.test(cards.at(-1)?.warn ?? ""));
  const att = makeActor("ZZ Attacker");
  const ta = makeToken("ta", att, { x: 100, y: 0, disposition: -1 });
  canvas.tokens.placeables = [ta];
  game.user.targets = new Set([ta]);
  await auto.AUTOMATIONS_B6_C["Magical Retribution"].use(mr, mr.items[0]);
  equal("F …your reaction, an attack of opportunity at it", [calls.spendReaction.at(-1)?.[0], calls.attacks.at(-1)?.actor, calls.attacks.at(-1)?.opts?.isReaction], ["ZZ Retributor", "ZZ Retributor", true]);
  reactionRefused = "your reaction is spent";
  const nA = calls.attacks.length;
  await auto.AUTOMATIONS_B6_C["Magical Retribution"].use(mr, mr.items[0]);
  ok("F …refused without a reaction", calls.attacks.length === nA && /reaction is spent/.test(cards.at(-1)?.warn ?? ""));
  reactionRefused = "";
  canvas.tokens.placeables = [];
  game.user.targets = new Set();

  // Ready: Bonded Infusion synced for a feat added before 0.9.0.
  const old = makeActor("ZZ Old Blade", { items: [item("Bonded Infusion"), { _id: "w6", name: "Sabre", type: "weapon", system: { equipped: true } }] });
  old.flags[SYS] = { infusedRunes: { weaponId: "w6" } };
  game.actors = [old];
  equal("F there is no ready handler: loading the world writes nothing (Bonded Infusion syncs on the actor and item events only)", [typeof auto.onReadyB6C, old.items[0].flags[SYS].spellAdder ?? 0, old.items[0].flags[SYS].freeSomatic ?? null], ["undefined", 0, null]);
  game.actors = [];
}
function forSecondsFake(s) { return { system: { spellEffect: true, spellEffectEnd: 1000 + s }, module: {} }; }

console.log(`verify-block6c: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
