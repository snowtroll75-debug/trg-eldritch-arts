#!/usr/bin/env node
/**
 * mutate-block6e — the mutation half of verify-block6e. Each mutation breaks
 * one printed number, one reading or one wire of Block 6's group E (and the
 * Warlock's pool in Block 4); verify-block6e must fail on every one. Files
 * are restored after each run, and on any exit. It rewrites files in place:
 * run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6e.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block6-e.mjs"), A = f("module", "block6e-automations.mjs");
const C4 = f("tools", "content", "block4.mjs"), A4 = f("module", "block4-automations.mjs"), B3C = f("tools", "content", "block3.mjs");

const MUTATIONS = [
  { name: "the Witch's class makes only Ethereal and Verdant High Magic again (ruling of 4 Nov 2026 undone)", file: B3C, from: "    highMagicCaster: true,\n    repertoire: { firstPicks: 2,", to: "    highMagicCaster: [\"ethereal\", \"verdant\"],\n    repertoire: { firstPicks: 2," },
  // The content
  { name: "Extra Bond is not repeatable", file: C, from: "  classFeat(\"EXTRA BOND\", {\n    repeatable: true,", to: "  classFeat(\"EXTRA BOND\", {" },
  { name: "Shadowed Grimoire is not repeatable", file: C, from: "  classFeat(\"SHADOWED GRIMOIRE\", {\n    repeatable: true,", to: "  classFeat(\"SHADOWED GRIMOIRE\", {" },
  { name: "Symbiotic Witch's conduit is unlimited", file: C, from: "  classFeat(\"SYMBIOTIC WITCH\", {\n    usesPerDay: \"1\",", to: "  classFeat(\"SYMBIOTIC WITCH\", {" },
  { name: "Ethereal Insight's See Invisible is Focus, not once a day", file: C, from: "grantInnate: true, grantedSpellUses: { \"See Invisible\": \"1\" } },", to: "grantInnate: true }," },
  { name: "Ethereal Insight grants no Darkvision", file: C, from: "    grantedAbilities: \"Darkvision\",\n    grantedSpells: \"See Invisible\",", to: "    grantedSpells: \"See Invisible\"," },
  { name: "Xithra Recovery adds two uses", file: C, from: "focusExtraUses: [{ value: 1, names: [\"Xithra\"], restoresAll: true }]", to: "focusExtraUses: [{ value: 2, names: [\"Xithra\"], restoresAll: true }]" },
  { name: "Xithra Recovery reaches every Focus spell", file: C, from: "focusExtraUses: [{ value: 1, names: [\"Xithra\"], restoresAll: true }]", to: "focusExtraUses: [{ value: 1, restoresAll: true }]" },
  { name: "Pact Ascendant's card forgets Q141", file: C, from: "allies included (Q141).", to: "allies included." },
  { name: "the docs grade Hex Mastery B", file: C, from: "\"Hex Mastery\": { level: \"A\",", to: "\"Hex Mastery\": { level: \"B\"," },
  { name: "Hex Binders Curse claims to be descriptive", file: C, from: "automation: \"*Automated (0.9.0, TRG Prime 3.684.0, G23):* **Use** (1 AP, Concentrate", to: "automation: \"*Described:* **Use** (1 AP, Concentrate" },
  // Xithra
  { name: "Xithra Spear reaches 90 ft", file: A, from: "export const XITHRA_SPEAR_RANGE = \"60 feet\";", to: "export const XITHRA_SPEAR_RANGE = \"90 feet\";" },
  { name: "Enhanced Blast keeps d6", file: A, from: "  const die = enhanced ? 8 : 6;\n  const out = {};", to: "  const die = 6;\n  const out = {};" },
  { name: "Enhanced Blast misses the level dice", file: A, from: "(m?.damageDice ? { ...m, damageDice: withDie(m.damageDice, die) } : m)", to: "m" },
  { name: "the element is never offered", file: A, from: "...(ELEMENTAL_BLAST_TYPES.includes(norm(element)) ? [norm(element)] : [])", to: "" },
  { name: "Elemental Blast takes poison", file: A, from: "export const ELEMENTAL_BLAST_TYPES = Object.freeze([\"acid\", \"cold\", \"electricity\", \"fire\", \"sonic\"]);", to: "export const ELEMENTAL_BLAST_TYPES = Object.freeze([\"acid\", \"cold\", \"electricity\", \"fire\", \"sonic\", \"poison\"]);" },
  { name: "Elemental Blast is not asked at daily preparation", file: A, from: "  if (blast) await chooseElement(", to: "  if (false) await chooseElement(" },
  { name: "the feats' leaving does not resync Xithra", file: A, from: "  if (item.type === \"feat\" && XITHRA_FEATS.includes(name)) await syncXithraB6E(actor);\n  if (item.type === \"feat\" && name === \"ethereal insight\") await refreshFamiliarRange(actor);\n  if (item.type === \"feat\" && name === \"pact ascendant\") {", to: "  if (item.type === \"feat\" && name === \"ethereal insight\") await refreshFamiliarRange(actor);\n  if (item.type === \"feat\" && name === \"pact ascendant\") {" },
  { name: "Xithra's dice climb every 5 levels", file: A, from: "export const xithraDiceCount = (level) => 1 + Math.floor(Math.max(0, int(level)) / 4);", to: "export const xithraDiceCount = (level) => 1 + Math.floor(Math.max(0, int(level)) / 5);" },
  // Warding Sigil, Xithra Cone
  { name: "Warding Sigil costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Warding Sigil\", 1))) return false;\n", to: "" },
  { name: "Warding Sigil spends no Focus use", file: A, from: "    if (!(await spendAP(actor, \"Warding Sigil\", 1))) return false;\n    await spendUse(item);", to: "    if (!(await spendAP(actor, \"Warding Sigil\", 1))) return false;" },
  { name: "Warding Sigil lasts to the start of the next turn", file: A, from: "expiry: fighting(actor) ? expiryFor(\"endOfNextTurn\", actor) : forSeconds(12)", to: "expiry: fighting(actor) ? expiryFor(\"startOfNextTurn\", actor) : forSeconds(12)" },
  { name: "Xithra Cone without the feat", file: A, from: "if (!spell?.flags?.[SYSTEM_ID]?.eaXithra || !featOf(actor, \"Xithra Cone\")) return null;", to: "if (!spell?.flags?.[SYSTEM_ID]?.eaXithra) return null;" },
  { name: "the cone spends no Focus use", file: A, from: "  await spendUse(spell);\n  const dc = await h().innateSaveDCFor(actor, spell);", to: "  const dc = await h().innateSaveDCFor(actor, spell);" },
  { name: "the cone's save is Fortitude", file: A, from: "save: \"reflex\", dc: dc.value, label: \"Xithra Cone\"", to: "save: \"fortitude\", dc: dc.value, label: \"Xithra Cone\"" },
  { name: "the cone forgets Charisma", file: A, from: "const formula = `${xithraDiceCount(dc.level)}d${die} + ${int(actor.system?.attributes?.charisma?.total)}`;", to: "const formula = `${xithraDiceCount(dc.level)}d${die}`;" },
  { name: "the cone ignores Enhanced Blast", file: A, from: "  const die = featOf(actor, \"Enhanced Blast\") ? 8 : 6;\n  const formula", to: "  const die = 6;\n  const formula" },
  { name: "the cone's damage names no caster (no Warlock's Hex)", file: A, from: "h().basicSaveHit({ caster: actor, target, save: \"reflex\"", to: "h().basicSaveHit({ target, save: \"reflex\"" },
  { name: "the cone is cast with a spent use", file: A, from: "  if (usesLeft(spell) <= 0) { warn(\"Xithra: its Focus use is spent — Refocus restores it.\"); return { handled: true, result: null }; }\n", to: "" },
  // Warlock's Hex
  { name: "Q134 undone: the hex costs no PP", file: A, from: "  await actor.update({ \"system.resources.pp.value\": pp - 1 });\n  await spendUse(item);\n  const penalty", to: "  await spendUse(item);\n  const penalty" },
  { name: "Q134 undone: the hex spends no Focus use", file: A, from: "  await actor.update({ \"system.resources.pp.value\": pp - 1 });\n  await spendUse(item);", to: "  await actor.update({ \"system.resources.pp.value\": pp - 1 });" },
  { name: "the hex is offered at 0 PP", file: A, from: "if (!feat || usesLeft(feat) <= 0 || int(source.system?.resources?.pp?.value) < 1) return;", to: "if (!feat || usesLeft(feat) <= 0) return;" },
  { name: "the hex is −2 from 5th", file: A, from: "export const hexPenalty = (level) => (int(level) >= 10 ? -2 : -1);", to: "export const hexPenalty = (level) => (int(level) >= 5 ? -2 : -1);" },
  { name: "the hex can last 0 rounds", file: A, from: "export const hexRounds = (charisma) => Math.max(1, int(charisma));", to: "export const hexRounds = (charisma) => Math.max(0, int(charisma));" },
  { name: "the hex reaches every save", file: A, from: "when: { checkTypes: [\"save\"], sourceUuids: [String(warlockUuid)] } }];", to: "when: { checkTypes: [\"save\"] } }];" },
  { name: "the hex is a status penalty", file: A, from: "{ kind: \"modifier\", value: penalty, type: \"circumstance\", label: \"Warlock’s Hex\"", to: "{ kind: \"modifier\", value: penalty, type: \"status\", label: \"Warlock’s Hex\"" },
  { name: "the hex follows a Strike", file: A, from: "[\"spell\", \"areasave\"].includes(norm(payload.context?.kind)) && payload.actor?.uuid !== payload.sourceUuid;", to: "[\"spell\", \"areasave\", \"strike\"].includes(norm(payload.context?.kind)) && payload.actor?.uuid !== payload.sourceUuid;" },
  { name: "the hex is asked for every packet", file: A, from: "  if (!firstOfBlow(\"hex\", payload)) return;\n", to: "" },
  { name: "the hex keeps no round in combat", file: A, from: "  if (combat) expiry.system.conditionExpiresRound = int(combat.round) + rounds;\n", to: "" },
  // Hex Binders Curse
  { name: "Hex Binders Curse's dice climb every 4 levels", file: A, from: "export const curseDice = (level) => (int(level) >= 5 ? `${Math.floor(int(level) / 5)}d6` : \"\");", to: "export const curseDice = (level) => (int(level) >= 4 ? `${Math.floor(int(level) / 4)}d6` : \"\");" },
  { name: "the curse reaches 60 ft", file: A, from: "export const CURSE_FEET = 30;", to: "export const CURSE_FEET = 60;" },
  { name: "the curse may fall on an ally", file: A, from: "    if (me && allies(t.document?.disposition, me.document?.disposition)) return warn(\"Hex Binders Curse: you may curse an enemy, not an ally.\");\n", to: "" },
  { name: "the curse costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Hex Binders Curse\", 1))) return false;\n", to: "" },
  { name: "the curse skips the trait gate", file: A, from: "    if (h().traitGate && !(await h().traitGate(actor, action, \"Hex Binders Curse\"))) return false;\n", to: "" },
  { name: "the old curse's marker stays", file: A, from: "    await clearCurse(actor);\n    const curseId", to: "    const curseId" },
  { name: "the curse is laid on the target (a player cannot lift it)", file: A, from: "    await actor.createEmbeddedDocuments(\"ActiveEffect\", [effectData(\"hexBindersCurse\", {", to: "    await h().createEffectsOn(t.actor, [effectData(\"hexBindersCurse\", {" },
  { name: "the load-time refresh syncs Xithra again", file: A, from: "    if (!actor?.isOwner || !actsFor(actor)) continue;\n    await refreshFamiliarRange(actor);", to: "    if (!actor?.isOwner || !actsFor(actor)) continue;\n    await syncXithraB6E(actor);\n    await refreshFamiliarRange(actor);" },
  { name: "Symbiotic Witch's card says Automated", file: C, from: "automation: \"*Partly automated (0.9.0, TRG Prime 3.684.0, G24):*", to: "automation: \"*Automated (0.9.0, TRG Prime 3.684.0, G24):*" },
  { name: "Pact Ascendant's card forgets Hand of the Reaper", file: C, from: "; Hand of the Reaper added (the core's Hand Of The Reaper).", to: "." },
  { name: "the curse's dice trigger themselves", file: A, from: "[\"strike\", \"spell\", \"areasave\"].includes(norm(payload.context?.kind));", to: "[\"strike\", \"spell\", \"areasave\", \"hexbinderscurse\"].includes(norm(payload.context?.kind));" },
  { name: "the curse adds dice to every packet", file: A, from: "  if (!dice || !firstOfBlow(\"curse\", payload)) return;", to: "  if (!dice) return;" },
  { name: "the curse's dice are force, not the blow's", file: A, from: "  let type = blowType(payload);", to: "  let type = \"force\";" },
  { name: "the curse reaches anyone", file: A, from: "  if (!curse?.targetUuid || curse.targetUuid !== payload.actor?.uuid || !curseWanted(payload)) return;", to: "  if (!curse?.targetUuid || !curseWanted(payload)) return;" },
  { name: "the curse outlives the day", file: A, from: "  if (actor.getFlag?.(MODULE_ID, \"hexCurse\")) await clearCurse(actor);\n", to: "" },
  // Hex Mastery
  { name: "Hex Mastery discounts every spell", file: A, from: "  if (!ctx.spell?.flags?.[SYSTEM_ID]?.eaHex || ctx.innate || ctx.itemCast || ctx.cantrip) return null;", to: "  if (ctx.innate || ctx.itemCast || ctx.cantrip) return null;" },
  { name: "Hex Mastery reaches 0", file: A, from: "return { ppDelta: -1, floor: 1, label: \"Hex Mastery\"", to: "return { ppDelta: -1, floor: 0, label: \"Hex Mastery\"" },
  { name: "Hex Mastery takes 2 PP", file: A, from: "return { ppDelta: -1, floor: 1, label: \"Hex Mastery\"", to: "return { ppDelta: -2, floor: 1, label: \"Hex Mastery\"" },
  // Malevolent Blast
  { name: "Malevolent Blast stuns on a Partial", file: A, from: "return [\"failure\", \"fumble\", \"blunder\"].includes(norm(degree)) ? (critical ? 2 : 1) : 0;", to: "return [\"partial\", \"failure\", \"fumble\", \"blunder\"].includes(norm(degree)) ? (critical ? 2 : 1) : 0;" },
  { name: "Malevolent Blast ignores the critical", file: A, from: "return [\"failure\", \"fumble\", \"blunder\"].includes(norm(degree)) ? (critical ? 2 : 1) : 0;", to: "return [\"failure\", \"fumble\", \"blunder\"].includes(norm(degree)) ? 1 : 0;" },
  { name: "Malevolent Blast is a Fortitude save", file: A, from: "type: \"save\", subject: \"will\", label: `${hit.target.name} — Will Save`", to: "type: \"save\", subject: \"fortitude\", label: `${hit.target.name} — Will Save`" },
  { name: "Malevolent Blast spends no use", file: A, from: "  await spendUse(feat);\n  const dc = await h().innateSaveDCFor(actor, ctx.spell);", to: "  const dc = await h().innateSaveDCFor(actor, ctx.spell);" },
  { name: "Malevolent Blast on any spell", file: A, from: "  if (!ctx.spell?.flags?.[SYSTEM_ID]?.eaXithra || !ctx.cast) return;\n  const hit", to: "  if (!ctx.cast) return;\n  const hit" },
  { name: "Malevolent Blast's save names no Warlock", file: A, from: "saveSource: \"Malevolent Blast\", sourceUuid: actor.uuid, dc: dc.value", to: "saveSource: \"Malevolent Blast\", dc: dc.value" },
  // The picks
  { name: "Forbidden Lore offers Verdant", file: A, from: "tradsOf(e).some((t) => [\"arcane\", \"divinity\"].includes(t))", to: "tradsOf(e).some((t) => [\"arcane\", \"divinity\", \"verdant\"].includes(t))" },
  { name: "the picks reach CL + 2", file: A, from: "export const forbiddenLoreMay = (e, cl) => plainSpell(e) && tradsOf(e).some((t) => [\"arcane\", \"divinity\"].includes(t)) && int(e.system.ppCost) <= int(cl) + 1;", to: "export const forbiddenLoreMay = (e, cl) => plainSpell(e) && tradsOf(e).some((t) => [\"arcane\", \"divinity\"].includes(t)) && int(e.system.ppCost) <= int(cl) + 2;" },
  { name: "cantrips are offered", file: A, from: "!isCantrip(e?.system) && int(e?.system?.ppCost) >= 1;", to: "int(e?.system?.ppCost) >= 0;" },
  { name: "Q99 undone: Forbidden Lore's spell is not High Magic", file: A, from: "const made = await addCopy(actor, data, item, { highMagic: true, kind: \"forbiddenLore\" });", to: "const made = await addCopy(actor, data, item, { highMagic: false, kind: \"forbiddenLore\" });" },
  { name: "Forbidden Lore takes a second spell", file: A, from: "    if (have.length) return card(actor, \"Forbidden Lore\"", to: "    if (false) return card(actor, \"Forbidden Lore\"" },
  { name: "High Sorcery gives a Witch any tradition", file: A, from: "  if (cls === \"witch\") return tradsOf(e).some((t) => WITCH_TRADITIONS.includes(t));", to: "  if (cls === \"witch\") return true;" },
  { name: "Borrowed Power is not High Magic", file: A, from: "{ highMagic: true, kind: \"borrowed\", extra: { eaBorrowed: true } }", to: "{ highMagic: false, kind: \"borrowed\", extra: { eaBorrowed: true } }" },
  { name: "yesterday's borrowed spell stays", file: A, from: "  if (old.length) await actor.deleteEmbeddedDocuments(\"Item\", old.map((i) => i.id));\n  const cl = casterLevel(actor);", to: "  const cl = casterLevel(actor);" },
  { name: "Shadowed Grimoire swaps at the same level", file: A, from: "      if (level <= was) return card(", to: "      if (level < was) return card(" },
  { name: "Shadowed Grimoire's spell is not innate", file: A, from: "    const copy = warlockCopy(data, { source: item, slot: \"grimoire\" });", to: "    const copy = auto0(data);" },
  // Pacts
  { name: "Pact Boon (Demonic) gives Burning Hands", file: A, from: "demonic: \"Fireball\", draconic: \"Dragon Wings\"", to: "demonic: \"Burning Hands\", draconic: \"Dragon Wings\"" },
  { name: "Pact Ascendant (Grave) gives Maze", file: A, from: "grave: \"Hand Of The Reaper\", void: \"Maze\" });", to: "grave: \"Maze\", void: \"Maze\" });" },
  { name: "earth means fire", file: A, from: "export const ELEMENT_DAMAGE = Object.freeze({ air: \"electricity\", earth: \"acid\",", to: "export const ELEMENT_DAMAGE = Object.freeze({ air: \"electricity\", earth: \"fire\"," },
  { name: "Q141 undone: the Demonic guard leaves 1 HP", file: A, from: "deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, frequency: \"daily\", heal: \"half\", notOutright: true }", to: "deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, frequency: \"daily\", notOutright: true }" },
  { name: "the Demonic guard is not once a day", file: A, from: "deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, frequency: \"daily\", heal: \"half\", notOutright: true }", to: "deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, heal: \"half\", notOutright: true }" },
  { name: "the Demonic guard holds against an outright kill", file: A, from: "deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, frequency: \"daily\", heal: \"half\", notOutright: true }", to: "deathGuard: { label: DEMONIC_GUARD_LABEL, auto: true, frequency: \"daily\", heal: \"half\" }" },
  { name: "the burst reaches 30 ft", file: A, from: "radiusFeet: 20, label: \"Pact Ascendant (Demonic)\"", to: "radiusFeet: 30, label: \"Pact Ascendant (Demonic)\"" },
  { name: "the burst is 8d6", file: A, from: "dice: \"10d6\", type: \"fire\"", to: "dice: \"8d6\", type: \"fire\"" },
  { name: "the burst's DC is 10", file: A, from: "  const dc = h().levelDC(levelOf(actor));\n  const lines = [line(`You explode", to: "  const dc = 10;\n  const lines = [line(`You explode" },
  { name: "the burst answers any guard", file: A, from: "  if (ctx?.label !== DEMONIC_GUARD_LABEL || !ctx.actor) return;", to: "  if (!ctx.actor) return;" },
  { name: "Angelic's aura reaches 20 ft", file: A, from: "auras: [{ kind: \"ally\", radius: 10, name: \"Pact Ascendant (Angelic)\"", to: "auras: [{ kind: \"ally\", radius: 20, name: \"Pact Ascendant (Angelic)\"" },
  { name: "Draconic's wings add to a fly speed", file: A, from: "{ key: \"system.combat.movement.fly.base\", mode: 4, value: \"40\", priority: 20 }", to: "{ key: \"system.combat.movement.fly.base\", mode: 2, value: \"40\", priority: 20 }" },
  { name: "Q99 undone: a Witch's pact spell is not High Magic", file: A, from: "repertoireCopy(data, { source: item, highMagic: witchNeedsHighmagic(cls, data.system?.tradition) });\n  copy.flags[MODULE_ID]", to: "repertoireCopy(data, { source: item });\n  copy.flags[MODULE_ID]" },
  { name: "Pact Boon is not granted on arrival", file: A, from: "  if (item.type === \"feat\" && name === \"pact boon\") await pactBoonGrant(actor, item);\n", to: "" },
  { name: "the pact element is not read", file: A, from: "export const PACT_ELEMENT_KEYS = Object.freeze([[SYSTEM_ID, \"eaElement\"]]);", to: "export const PACT_ELEMENT_KEYS = Object.freeze([[SYSTEM_ID, \"element\"]]);" },
  // The familiar
  { name: "Extra Bond repeats the day's bonus", file: A, from: "  const taken = main ? [main] : [];", to: "  const taken = [];" },
  { name: "Extra Bond gives one, whatever the copies", file: A, from: "  const copies = featsNamed(actor, \"Extra Bond\").length;", to: "  const copies = Math.min(1, featsNamed(actor, \"Extra Bond\").length);" },
  { name: "Extra Bond ignores the range", file: A, from: "  for (const e of extra) if (Boolean(e.disabled) !== away) await e.update({ disabled: away });", to: "" },
  { name: "Extra Bond ignores a severed bond", file: A, from: "  const away = !bond.holds || familiarAway(actor, bond.familiar);", to: "  const away = familiarAway(actor, bond.familiar);" },
  { name: "Extra Bond is not asked after the daily bonus", file: A, from: "  if (effect.getFlag?.(MODULE_ID, \"source\") !== \"soulboundBonus\" || !featOf(actor, \"Extra Bond\")) return;", to: "  return;" },
  { name: "the familiar's Darkvision stays beyond 30 ft", file: A, from: "  } else if (!wants && mine.length) await fam.deleteEmbeddedDocuments(\"Item\", mine.map((i) => i.id));", to: "  }" },
  { name: "the familiar's Darkvision reaches 60 ft", file: A, from: "export const ETHEREAL_FAMILIAR_FEET = 30;", to: "export const ETHEREAL_FAMILIAR_FEET = 60;" },
  { name: "See Invisible's sight stays bound to her cast", file: A, from: "    if (data.flags?.[SYSTEM_ID]) { delete data.flags[SYSTEM_ID].endsWithCast; delete data.flags[SYSTEM_ID].castId; }\n", to: "" },
  { name: "any See Invisible is shared", file: A, from: " || norm(spell?.flags?.[SYSTEM_ID]?.grantedBy?.sourceName) !== \"ethereal insight\") return;", to: ") return;" },
  { name: "Soul-Bound Grimoire takes an Arcane scroll", file: A, from: "export const grimoireScrollOk = (tradition) => traitList(tradition).some((t) => WITCH_TRADITIONS.includes(t));", to: "export const grimoireScrollOk = (tradition) => Boolean(String(tradition ?? \"\").trim());" },
  { name: "the scroll is not used up", file: A, from: "    if (qty > 1) await s.item.update({ \"system.quantity\": qty - 1 });\n    else await actor.deleteEmbeddedDocuments(\"Item\", [s.item.id]);\n", to: "" },
  { name: "a known spell's discount is 2", file: A, from: "int(known.flags?.[SYSTEM_ID]?.warpDiscount) + 1, [`flags.${MODULE_ID}.grimoireDiscount`]: 1 });", to: "int(known.flags?.[SYSTEM_ID]?.warpDiscount) + 2, [`flags.${MODULE_ID}.grimoireDiscount`]: 2 });" },
  { name: "the day's discount is never put back", file: A, from: "    await s.update({ [`flags.${SYSTEM_ID}.warpDiscount`]: back, [`flags.${MODULE_ID}.grimoireDiscount`]: 0 });", to: "" },
  { name: "Q138 undone: a dead familiar keeps its spells", file: A, from: "    await item.setFlag(MODULE_ID, \"stored\", []);\n    return card(", to: "    return card(" },
  { name: "a severed bond still imprints", file: A, from: "  if (bond.severed) return card(actor, \"Soul-Bound Grimoire\"", to: "  if (false) return card(actor, \"Soul-Bound Grimoire\"" },
  { name: "the conduit takes a 6 PP spell", file: A, from: "export const CONDUIT_MAX_PP = 4;", to: "export const CONDUIT_MAX_PP = 6;" },
  { name: "the conduit measures from the caster", file: A, from: "result = await h().castSpell(actor, spell, { rangeFrom: ftoken.document?.uuid ?? \"\" });", to: "result = await h().castSpell(actor, spell, {});" },
  { name: "the conduit spends no daily use", file: A, from: "    if (!result) return false;\n    await spendUse(item);", to: "    if (!result) return false;" },
  { name: "the familiar sustains for the caster's uuid", file: A, from: "{ uuid: familiar.uuid, label: `${familiar.name} (Symbiotic Witch)` }", to: "{ uuid: actor.uuid, label: `${familiar.name} (Symbiotic Witch)` }" },
  { name: "Symbiotic Witch with the bond severed", file: A, from: "    if (!bond.holds) return warn(\"Symbiotic Witch: your Soulbound bond must hold (and your familiar live).\");\n", to: "" },
  // Registration
  { name: "Extra Communion is not registered", file: A, from: "  api.registerExtraUses?.(\"Extra Communion\", { ability: \"Verdant Communion\", perCopy: 1 }, moduleId);\n", to: "" },
  { name: "Extra Communion feeds Lay on Hands", file: A, from: "{ ability: \"Verdant Communion\", perCopy: 1 }", to: "{ ability: \"Lay on Hands\", perCopy: 1 }" },
  { name: "Hex Mastery is not registered", file: A, from: "  api.registerCastCostModifier?.(\"hexMastery\", hexMasteryModifier, moduleId);\n", to: "" },
  { name: "Xithra Cone's prelude is not registered", file: A, from: "  api.registerCastPrelude?.(\"xithraCone\", xithraConePrelude, moduleId);\n", to: "" },
  { name: "the hex's step is not registered", file: A, from: "  api.registerReactionStep?.(HEX_STEP, hexStep, moduleId);\n", to: "" },
  // The Warlock's pool (Block 4)
  { name: "Q97 undone: the soul's arrival writes no tradition", file: A4, from: "  if (item.type === \"ability\" && item.flags?.[SYSTEM_ID]?.eaBondedSoul) await writeWarlockTradition(actor);\n", to: "" },
  { name: "Q97: a Warlock's set tradition is overwritten", file: A4, from: "&& !String(actor?.system?.magic?.tradition ?? \"\").trim();", to: ";" },
  { name: "Q97: any tradition is accepted", file: A4, from: "  if (!soul.traditions.includes(pick)) return false;\n  await actor.update({ \"system.magic.tradition\": pick });", to: "  if (!pick) return false;\n  await actor.update({ \"system.magic.tradition\": pick });" },
  { name: "Q97: a soul chosen before 0.9.0 is never asked", file: A4, from: "    if (spells >= owed && cantrips >= WARLOCK_CANTRIPS && (await writeWarlockTradition(actor))) return true;\n", to: "" },
  { name: "Q97: a Witch is asked too", file: A4, from: "export const warlockTraditionOwed = (actor, soul) => className(actor) === \"warlock\" && ", to: "export const warlockTraditionOwed = (actor, soul) => " },
  { name: "the Warlock's card still says no PP pool", file: C4, from: "\"**a pool of Charisma PP that your spells never spend (C2; Q52, Q97), and no Spellcraft:", to: "\"**no PP pool (C2; Q52, Q97), and no Spellcraft:" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6e.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6e: verify-block6e already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6e: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6e: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
