#!/usr/bin/env node
/**
 * verify-packs-compiled — the compiled packs (packs/, the LevelDB the module
 * loads) hold exactly what packs-source/ holds.
 *
 * WHY (0.12.0's live test, 12 November 2026): 0.12.0 was first zipped after
 * `build-packs --json`, which writes packs-source/ only. Every harness reads
 * packs-source/ or the content modules, so all passed, while the zip carried
 * the 8 November spells pack: 113 spells, none of Block 8b's 17. build-zip
 * now runs this first and refuses a stale pack.
 *
 *   node tools/verify-packs-compiled.mjs
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "module.json"), "utf8"));
const { extractPack } = await import("@foundryvtt/foundryvtt-cli");

const failures = [];
let docs = 0;
// What a document means: everything but the bookkeeping the compiler may add.
// A RollTable's results and a journal's pages too (0.17.1, found in review), each without its LevelDB key.
const unkeyed = (list) => (list ?? []).map(({ _key, ...rest }) => rest);
const meaning = (d) => JSON.stringify({ _id: d._id, name: d.name, type: d.type, img: d.img, system: d.system ?? null, flags: d.flags ?? null, effects: (d.effects ?? []).map((e) => e._id ?? e.name), results: unkeyed(d.results), pages: unkeyed(d.pages), formula: d.formula ?? null });
const readDir = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith(".json")).map((f) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"))) : []);

for (const pack of manifest.packs) {
  const name = path.basename(pack.path);
  const source = readDir(path.join(ROOT, "packs-source", name));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), `ea-pack-${name}-`));
  try {
    await extractPack(path.join(ROOT, pack.path), tmp, { log: false });
    const compiled = readDir(tmp);
    const byId = new Map(compiled.map((d) => [d._id, d]));
    if (compiled.length !== source.length) failures.push(`${name}: ${compiled.length} compiled, ${source.length} in packs-source`);
    for (const d of source) {
      const c = byId.get(d._id);
      if (!c) failures.push(`${name}: "${d.name}" is not compiled`);
      else if (meaning(c) !== meaning(d)) failures.push(`${name}: "${d.name}" differs from packs-source`);
    }
    docs += source.length;
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

if (failures.length) {
  console.log(`verify-packs-compiled: ${failures.length} failure(s) — run \`node tools/build-packs.mjs\` (not --json).`);
  for (const f of failures.slice(0, 40)) console.log(`  ✗ ${f}`);
  process.exitCode = 1;
} else console.log(`verify-packs-compiled: OK — ${docs} documents in ${manifest.packs.length} packs, compiled as packs-source holds them.`);
