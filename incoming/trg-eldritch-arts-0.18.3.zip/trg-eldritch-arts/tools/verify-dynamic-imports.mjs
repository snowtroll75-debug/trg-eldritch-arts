#!/usr/bin/env node
/**
 * verify-dynamic-imports — every name the module takes from a dynamic import
 * is one that file exports (0.15.1).
 *
 * WHY: `const { rollTable, WILD_SURGE } = await import("./block2-automations.mjs")`
 * loads without complaint, and WILD_SURGE is simply `undefined`; block2 imports
 * the table but never exports it. The Orb's Resonant Flare (Block 9c), the Rod
 * of Wild Surges (Block 9c) and Warpflare's wild-magic 6 (Block 9b) each threw
 * inside `rowFor` when they rolled. Each block's verifier mocked `rollTable`, so
 * none of them saw it. Block 9c's live test found it on 14 November 2026.
 *
 * Static `import { … } from` needs no check: a missing name there stops the
 * module loading at all, in Foundry and in every verifier that imports it.
 *
 *   node tools/verify-dynamic-imports.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true })
  .flatMap((e) => e.isDirectory() ? walk(path.join(dir, e.name)) : e.name.endsWith(".mjs") ? [path.join(dir, e.name)] : []);

/** A source with its comments blanked (0.15.1, review): an `export` in a comment exports nothing. */
export function stripComments(src) {
  return String(src).replace(/\/\*[\s\S]*?\*\//g, " ").replace(/(^|[^:"'`\\])\/\/[^\n]*/g, "$1");
}

/** The names a source file exports (declarations, `export { a, b as c }`), and whether it re-exports `*`. */
export function exportedNames(raw) {
  const src = stripComments(raw);
  const names = new Set();
  for (const m of src.matchAll(/export\s+(?:async\s+)?(?:function\*?|const|let|var|class)\s+([A-Za-z_$][\w$]*)/g)) names.add(m[1]);
  for (const m of src.matchAll(/export\s*\{([^}]*)\}/g)) {
    for (const part of m[1].split(",")) {
      const name = part.trim().split(/\s+as\s+/).pop()?.trim();
      if (name) names.add(name);
    }
  }
  return { names, star: /export\s*\*\s*from/.test(src) };
}

/**
 * Every name a source takes from a relative dynamic import: [{ names, spec }].
 * Three shapes (the review's, 0.15.1):
 *   const|let|var { a, b: c } = await import("./x.mjs")
 *   (await import("./x.mjs")).a
 *   const ns = await import("./x.mjs"); … ns.a
 */
export function dynamicImports(raw) {
  const src = stripComments(raw);
  const out = [];
  const SPEC = `["'\`](\\.{1,2}\\/[^"'\`]+\\.mjs)["'\`]`;
  for (const m of src.matchAll(new RegExp(`(?:const|let|var)\\s*\\{([^}]*)\\}\\s*=\\s*await\\s+import\\(\\s*${SPEC}\\s*\\)`, "g"))) {
    const names = m[1].split(",").map((s) => s.trim().replace(/^\.\.\./, "").split(/\s*[:=]\s*/)[0].trim()).filter((n) => /^[A-Za-z_$][\w$]*$/.test(n));
    out.push({ names, spec: m[2] });
  }
  for (const m of src.matchAll(new RegExp(`\\(\\s*await\\s+import\\(\\s*${SPEC}\\s*\\)\\s*\\)\\s*\\.\\s*([A-Za-z_$][\\w$]*)`, "g"))) {
    out.push({ names: [m[2]], spec: m[1] });
  }
  for (const m of src.matchAll(new RegExp(`(?:const|let|var)\\s+([A-Za-z_$][\\w$]*)\\s*=\\s*await\\s+import\\(\\s*${SPEC}\\s*\\)`, "g"))) {
    const ns = m[1];
    const used = [...new Set([...src.matchAll(new RegExp(`(?<![\\w$.])${ns.replace(/\$/g, "\\$")}\\.([A-Za-z_$][\\w$]*)`, "g"))].map((u) => u[1]))];
    if (used.length) out.push({ names: used, spec: m[2] });
  }
  return out;
}

let checks = 0;
const failures = [];
const exportsOf = new Map();
const files = [...walk(path.join(ROOT, "module")), ...walk(path.join(ROOT, "scripts"))];
for (const file of files) {
  for (const { names, spec } of dynamicImports(fs.readFileSync(file, "utf8"))) {
    const target = path.resolve(path.dirname(file), spec);
    const where = path.relative(ROOT, file);
    checks += 1;
    if (!fs.existsSync(target)) { failures.push(`${where}: ${spec} does not exist`); continue; }
    if (!exportsOf.has(target)) exportsOf.set(target, exportedNames(fs.readFileSync(target, "utf8")));
    const { names: exported, star } = exportsOf.get(target);
    if (star) continue;
    for (const name of names) {
      checks += 1;
      if (!exported.has(name)) failures.push(`${where}: \`${name}\` is not exported by ${spec} — it would read as undefined`);
    }
  }
}

// The scanner itself, on the shapes it must read.
{
  const e = exportedNames("export const A = 1;\nexport async function b() {}\nconst c = 2; export { c, c as d };");
  checks += 1;
  if (!["A", "b", "c", "d"].every((n) => e.names.has(n)) || e.names.has("C")) failures.push("the export scanner misreads declarations or export lists");
  const d = dynamicImports('const { rollTable, WILD_SURGE: table } = await import("./block2-automations.mjs");');
  checks += 1;
  if (JSON.stringify(d) !== JSON.stringify([{ names: ["rollTable", "WILD_SURGE"], spec: "./block2-automations.mjs" }])) failures.push("the import scanner misreads a destructured dynamic import");
  const d2 = dynamicImports('const x = (await import("./a.mjs")).alpha;\nconst ns = await import("./b.mjs");\nns.beta(); ns.gamma;\n// const { delta } = await import("./c.mjs");');
  checks += 1;
  if (JSON.stringify(d2) !== JSON.stringify([{ names: ["alpha"], spec: "./a.mjs" }, { names: ["beta", "gamma"], spec: "./b.mjs" }])) failures.push(`the import scanner misses a property read or a namespace's names, or reads a comment: ${JSON.stringify(d2)}`);
  checks += 1;
  if (exportedNames("// export const WILD_SURGE = [];\n/* export function f() {} */").names.size) failures.push("the export scanner counts an export inside a comment");
}
// THE DEFECT, pinned: the Wild Surge table comes from its own file.
{
  const src = (rel) => fs.readFileSync(path.join(ROOT, "module", rel), "utf8");
  checks += 1;
  const sites = ["block9b-automations.mjs", "block9c-automations.mjs"].flatMap((f) => [...src(f).matchAll(/const \{ WILD_SURGE \} = await import\("\.\/chapter7-tables\.mjs"\);/g)]);
  if (sites.length !== 3) failures.push(`the Wild Surge table is read from chapter7-tables.mjs at ${sites.length} of the 3 sites (Warpflare, the Resonant Flare, the Rod of Wild Surges)`);
}

if (failures.length) {
  for (const f of failures) console.log(`  ✗ ${f}`);
  console.log(`verify-dynamic-imports: ${failures.length} failure(s) of ${checks}`);
  process.exit(1);
}
console.log(`verify-dynamic-imports: ${checks} checks, 0 failure(s) — ${files.length} files, every dynamically imported name is exported.`);
