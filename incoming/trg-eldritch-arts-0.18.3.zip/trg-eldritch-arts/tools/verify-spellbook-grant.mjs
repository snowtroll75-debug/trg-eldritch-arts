#!/usr/bin/env node
/**
 * verify-spellbook-grant — Eldritch Arts 0.18.0: the Archmage and the
 * Spellblade are granted the core's one Spellbook (Graham, 24 November 2026:
 * "keeping it to one item makes things much easier in the long run").
 *
 *   A  Both book-style classes name it in grantedGear, in packs-source AND in
 *      the compiled pack; no other class grants gear.
 *   B  The name resolves, through the REAL core grant matcher, to exactly one
 *      item in the core's gear pack, and that item is the spell book container.
 *   C  The manifest is 0.18.1.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-spellbook-grant.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { ClassicLevel } from "classic-level";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

let checks = 0;
const failures = [];
const ok = (label, cond, detail = "") => { checks += 1; if (!cond) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); };
const equal = (label, a, b) => ok(label, JSON.stringify(a) === JSON.stringify(b), `expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);

async function loadPack(dir) {
  const db = new ClassicLevel(dir, { valueEncoding: "json" });
  await db.open();
  const out = [];
  try { for await (const [k, v] of db.iterator()) if (k.startsWith("!items!") && !k.slice(7).includes("!")) out.push(v); }
  finally { await db.close(); }
  return out;
}

const BOOK_CLASSES = ["Archmage", "Spellblade"];
const sourceDir = path.join(ROOT, "packs-source", "ea-classes");
const sources = fs.readdirSync(sourceDir).filter((f) => f.endsWith(".json")).map((f) => JSON.parse(fs.readFileSync(path.join(sourceDir, f), "utf8")));
const compiled = await loadPack(path.join(ROOT, "packs", "ea-classes"));
for (const name of BOOK_CLASSES) {
  equal(`A1 ${name} (packs-source) is a book caster granted the Spellbook`,
    [sources.find((c) => c.name === name)?.system?.memorisationStyle, sources.find((c) => c.name === name)?.system?.grantedGear], ["book", "Spellbook"]);
  equal(`A2 ${name} (compiled pack) grants the Spellbook`, compiled.find((c) => c.name === name)?.system?.grantedGear, "Spellbook");
}
equal("A3 every book-style class grants it, and no other class grants gear",
  sources.filter((c) => c.system?.grantedGear).map((c) => c.name).sort(),
  sources.filter((c) => c.system?.memorisationStyle === "book").map((c) => c.name).sort());

const { matchGrants } = await import(new URL(`file://${path.join(SYSTEM_ROOT, "module", "grants.mjs")}`).href);
const gear = await loadPack(path.join(SYSTEM_ROOT, "packs", "gear"));
const index = gear.map((g) => ({ _id: g._id, name: g.name, type: g.type, system: g.system }));
const { resolved, unresolved } = matchGrants(["Spellbook"], index, { sourceClass: "Archmage", preferPackage: "trg-eldritch-arts" });
equal("B1 the grant resolves in the core gear pack", [resolved.length, unresolved.length], [1, 0]);
equal("B2 ...to the spell book container", gear.find((g) => g._id === resolved[0]?.entry?._id)?.system?.spellbookContainer, true);

const manifest = JSON.parse(read("module.json"));
equal("C the manifest is 0.18.3", manifest.version, "0.18.3");

if (failures.length) {
  process.stderr.write(`verify-spellbook-grant: FAILED ${failures.length} of ${checks}\n`);
  for (const f of failures) process.stderr.write(`  ✗ ${f}\n`);
  process.exit(1);
}
process.stdout.write(`verify-spellbook-grant: OK — ${checks} checks.\n`);
