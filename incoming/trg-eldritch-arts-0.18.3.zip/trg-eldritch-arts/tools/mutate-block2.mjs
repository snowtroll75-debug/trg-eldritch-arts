#!/usr/bin/env node
/**
 * mutate-block2 — the mutation half of verify-block2. Each mutation breaks
 * one printed number, one reading, one table row's automation, one casting
 * hook or one wire of Block 2a; verify-block2 must fail on every one. Files
 * are restored after each run, and on any exit.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block2.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const ACT = f("module", "block2-actions.mjs"), A = f("module", "block2-automations.mjs"), T = f("module", "chapter7-tables.mjs"),
  AREAS = f("module", "areas.mjs"), REG = f("module", "registration.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), MANIFEST = f("module.json"),
  CLOCK = f("module", "effects-clock.mjs");

const MUTATIONS = [
  // A — the book
  { name: "Tap is Very Hard", file: ACT, from: "    difficulty: \"hard\",", to: "    difficulty: \"veryHard\"," },
  { name: "Channel is Hard", file: ACT, from: "    difficulty: \"veryHard\",", to: "    difficulty: \"hard\"," },
  { name: "Tap Magical Energy needs 3 ranks", file: ACT, from: "    minRanks: 2,", to: "    minRanks: 3," },
  { name: "Tap's Failure lockout is retyped", file: ACT, from: "and cannot Tap the Ley Line again for 1 hour.\",", to: "and cannot Tap the Ley Line again for 10 minutes.\"," },
  { name: "a Sense DC is wrong (Prime 20)", file: AREAS, from: "title: \"Prime Ley Line\", senseDC: 18,", to: "title: \"Prime Ley Line\", senseDC: 20," },
  { name: "Channel's Greater band is 2d6", file: AREAS, from: "title: \"Greater Ley Current\", senseDC: 20, channelDice: 3 }", to: "title: \"Greater Ley Current\", senseDC: 20, channelDice: 2 }" },
  { name: "M8 undone: level 20 is a dead zone", file: AREAS, from: "  Object.freeze({ min: 16, max: 19, title: \"Dead zone\" }),", to: "  Object.freeze({ min: 16, max: 20, title: \"Dead zone\" })," },
  { name: "a table row's text is retyped", file: T, from: "effect: \"Gain a +1 bonus to AB\"", to: "effect: \"Gain a +2 bonus to AB\"" },
  // B — the pure rules
  { name: "per two levels rounds up", file: A, from: "export const perTwo = (level) => Math.floor(Math.max(0, int(level)) / 2);", to: "export const perTwo = (level) => Math.ceil(Math.max(0, int(level)) / 2);" },
  { name: "Channel's Fumble is ×3", file: A, from: "({ failure: 1, fumble: 2, blunder: 3 })", to: "({ failure: 1, fumble: 3, blunder: 3 })" },
  { name: "a Critical siphon costs the item it all", file: A, from: "return { siphon: s, itemLoses: Math.max(1, Math.floor(s / 2)) }; }", to: "return { siphon: s, itemLoses: s }; }" },
  { name: "a Partial siphon is per 2 levels", file: A, from: "if (degree === \"partial\") { const s = Math.floor(cl / 4);", to: "if (degree === \"partial\") { const s = Math.floor(cl / 2);" },
  { name: "a Partial does not surge", file: A, from: "[\"partial\", \"failure\", \"fumble\", \"blunder\"].includes(String(degree))", to: "[\"failure\", \"fumble\", \"blunder\"].includes(String(degree))" },
  { name: "chaos does not surge", file: A, from: "export const surges = (degree, chaos = false) => Boolean(chaos) ||", to: "export const surges = (degree, chaos = false) => false ||" },
  { name: "suppression leaves a Fumble alone", file: A, from: "partial: \"failure\", failure: \"failure\", fumble: \"failure\", blunder: \"fumble\" }", to: "partial: \"failure\", failure: \"failure\", fumble: \"fumble\", blunder: \"fumble\" }" },
  { name: "PP may exceed the maximum", file: A, from: "export const clampPP = (value, max) => Math.max(0, Math.min(Math.max(0, int(max)), int(value)));", to: "export const clampPP = (value, max) => Math.max(0, int(value));" },
  { name: "all the siphon dissipates, spent or not", file: A, from: "Math.max(0, Math.min(int(siphon), int(current) - int(before)))", to: "Math.max(0, int(siphon))" },
  { name: "the ley line search stops at 25 ft", file: AREAS, from: "  for (let r = 5; r <= Math.max(0, feet); r += 5) {", to: "  for (let r = 5; r < Math.max(0, feet); r += 5) {" },
  // C — the rows
  { name: "01–03 is +2 AB", file: T, from: "e: { kind: \"cond\", mod: { kind: \"modifier\", value: 1, type: \"untyped\" }, when: { checkTypes: [\"attack\"] }, label: \"+1 AB\" }", to: "e: { kind: \"cond\", mod: { kind: \"modifier\", value: 2, type: \"untyped\" }, when: { checkTypes: [\"attack\"] }, label: \"+1 AB\" }" },
  { name: "the next-skill bonus lasts the whole duration", file: T, from: "label: \"+2 to your next {skill} check\" }", to: "oneShot: false, label: \"+2 to your next {skill} check\" }" },
  { name: "Weakened is −1 DB", file: T, from: "{ kind: \"db\", value: -2, label: \"Weakened, −2 DB\" }", to: "{ kind: \"db\", value: -1, label: \"Weakened, −2 DB\" }" },
  { name: "40–42's backlash hits you, not your allies", file: T, from: "b: { kind: \"damage\", allies: 10, formula: \"4d6\"", to: "b: { kind: \"damage\", formula: \"4d6\"" },
  { name: "wild 02 spares the caster", file: T, from: "{ kind: \"damage\", radius: true, includeSelf: true, formula: \"1d10\"", to: "{ kind: \"damage\", radius: true, includeSelf: false, formula: \"1d10\"" },
  { name: "wild mental damage is 1d6 × level", file: T, from: "e: { kind: \"damage\", choose: 3, radius: true, formula: \"1d8 x level\"", to: "e: { kind: \"damage\", choose: 3, radius: true, formula: \"1d6 x level\"" },
  { name: "Dazed lasts 1 round, whatever the level", file: T, from: "{ kind: \"condition\", tag: { key: \"dazed\", value: 1 }, roundsPerLevel: true }", to: "{ kind: \"condition\", tag: { key: \"dazed\", value: 1 } }" },
  { name: "Chaos Backlash is rolled normally", file: T, from: "b: { kind: \"resonance\", disadvantage: true }", to: "b: { kind: \"resonance\", disadvantage: false }" },
  { name: "a ley line's damage is against a fixed DC 10, not your level DC", file: A, from: "save, dc: ownLevelDC(target) + int(shield?.dcStep), label,", to: "save, dc: 10, label," } /* RE-ANCHORED 0.12.0 (Chaos Shield's DC step) */,
  { name: "lose HP goes through resistance", file: A, from: "{ amount: int(amount), type: \"untyped\", ignoreDefences: true, sourceName: label }", to: "{ amount: int(amount), type: \"untyped\", sourceName: label }" },
  { name: "the DB row is a status bonus", file: A, from: "key: \"system.combat.defence.other\", type: \"custom\",", to: "key: \"system.combat.defence.status\", type: \"custom\"," },
  { name: "the surge surcharge counts every level", file: A, from: "const pp = perTwo(L) * spec.per2Levels;", to: "const pp = L * spec.per2Levels;" },
  // D — casting in the areas
  { name: "THE GAP: suppression's penalty is never asked", file: A, from: "  return { modifiers: [{ label: `Magic Suppression (level ${area.level})`, value: -area.level, type: \"untyped\" }],", to: "  return { modifiers: [],", },
  { name: "suppression penalises an innate cast", file: A, from: "export async function suppressionGate(ctx = {}) {\n  if (!ctx.rollsCheck) return null;", to: "export async function suppressionGate(ctx = {}) {" },
  { name: "the remap ignores the area", file: A, from: "  const next = SUPPRESSED_DEGREE[ctx.degree];\n  if (!next) return null;\n  const area = await strongestAreaAt(casterToken(ctx.actor), \"suppression\");\n  if (!area) return null;", to: "  const next = SUPPRESSED_DEGREE[ctx.degree];\n  if (!next) return null;\n  const area = true;" },
  { name: "antimagic at 19", file: AREAS, from: "export const ANTIMAGIC_LEVEL = 20;", to: "export const ANTIMAGIC_LEVEL = 19;" },
  { name: "antimagic suppresses the race's own effects", file: A, from: "  if (parent?.documentName === \"Item\") return !NOT_MAGIC_ITEMS.includes(parent.type);", to: "  if (parent?.documentName === \"Item\") return true;" },
  { name: "a refunded cast spends the next-spell surcharge", file: A, from: "  if (ctx.cast && !ctx.refunded) {", to: "  if (ctx.cast) {" },
  { name: "antimagic leaves a spell's effects on", file: A, from: "  return Boolean(f.spellBuff || f.castId);", to: "  return false;" },
  { name: "a disabled behaviour still counts", file: AREAS, from: "    if (!behaviour || behaviour.disabled) continue;", to: "    if (!behaviour) continue;" },
  { name: "Ley Line Connection lowers a low magic DC too", file: A, from: "  if (!ctx.highMagic || !ctx.rollsCheck) return null;", to: "  if (!ctx.rollsCheck) return null;" },
  { name: "Ley Line Connection reaches the attack", file: A, from: "value: 1, type: \"untyped\", castingOnly: true }] };", to: "value: 1, type: \"untyped\" }] };" },
  // E — the actions
  { name: "Tap's Success lasts to the end of your next turn", file: A, from: "if (k === \"success\") return leyBenefits(actor, L, expiryFor(\"endOfTurn\", actor), `${title}: until the end of your turn`);", to: "if (k === \"success\") return leyBenefits(actor, L, expiryFor(\"endOfNextTurn\", actor), `${title}: until the end of your next turn`);" },
  { name: "Tap's Failure is a Fortitude save", file: A, from: "type: \"force\", save: \"will\", label: `${title} — backfire", to: "type: \"force\", save: \"fortitude\", label: `${title} — backfire" },
  { name: "a Fumble is not 24 hours", file: A, from: "await lock(actor, \"tapLeyLine\", k === \"fumble\" ? 86400 : 3600);", to: "await lock(actor, \"tapLeyLine\", 3600);" },
  { name: "Channel adds no tradition ability", file: A, from: "    const amount = total + ability;", to: "    const amount = total;" },
  { name: "a Channel Blunder locks nothing", file: A, from: "        await lock(actor, lineLockKey(p.regionId), Math.max(1, tomorrow - now()));\n", to: "" },
  { name: "Tap Magical Energy's DC is the caster's level DC", file: A, from: "return { dc: h().levelDC(level), label: `${item.name}'s level DC", to: "return { dc: h().levelDC(levelOf(actor)), label: `${item.name}'s level DC" },
  { name: "a Blunder skips the depletion roll", file: A, from: "    if (k === \"blunder\") await h().rollItemDepletion(actor, item);\n", to: "" },
  { name: "the ranks are not checked", file: A, from: "    if (ranks < own.minRanks) return warn(", to: "    if (false) return warn(" },
  { name: "a lockout is not honoured", file: A, from: "  if (lockedRow && lockedUntil(lockedRow, now())) {\n    const minutes = Math.ceil((Number(lockedRow.until) - now()) / 60);\n    return warn(`${own.name}:", to: "  if (false) {\n    const minutes = Math.ceil((Number(lockedRow.until) - now()) / 60);\n    return warn(`${own.name}:" },
  { name: "the wild surge ignores whether a check was rolled", file: A, from: "  if (!rollsCheck || !surges(degree, chaos)) return null;", to: "  if (!surges(degree, chaos)) return null;" },
  // Found in review
  { name: "REVIEW 1: the siphon reads the manual caster level", file: A, from: "const cl = int(actor.system?.magic?.casterLevelValue ?? actor.system?.magic?.casterLevel);", to: "const cl = int(actor.system?.magic?.casterLevel);" },
  { name: "REVIEW 2: antimagic is keyed by the shared actor id", file: A, from: "  if (!actor?.uuid || !antimagicOccupants.has(actor.uuid)) return false;", to: "  if (!actor?.id || ![...antimagicOccupants].some((u) => u.endsWith(actor.id))) return false;" },
  { name: "REVIEW 3: antimagic switches off any timed effect", file: A, from: "  return Boolean(f.spellBuff || f.castId);", to: "  return Boolean(f.spellBuff || f.spellEffect || f.castId);" },
  { name: "REVIEW 3: an affliction counts as a magic item", file: A, from: "\"wizard-school\", \"affliction\", \"creature-type\"]", to: "\"wizard-school\", \"creature-type\"]" },
  { name: "REVIEW 6: the surge is not rolled at the settled cast", file: A, from: "  await wildSurgeFor(actor, { degree, chaos: ctx.chaos, rollsCheck: ctx.rollsCheck === true });\n", to: "" },
  { name: "REVIEW 7: conviction on the wrong path", file: A, from: "await actor.update({ \"system.resources.conviction.value\": to });", to: "await actor.update({ \"system.conviction.value\": to });" },
  { name: "REVIEW 8: a row's condition never expires", file: A, from: "const until = seconds ? now() + seconds : int(ctx.expiry?.system?.spellEffectEnd) || null;", to: "const until = seconds ? now() + seconds : null;" },
  { name: "REVIEW 9: the next-spell surcharge is never spent", file: A, from: "    if (next.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", next.map((e) => e.id));\n", to: "" },
  { name: "REVIEW 9: a refused casting spends it", file: A, from: "  if (ctx.cast && !ctx.refunded) {", to: "  if (true) {" },
  { name: "REVIEW 10: the DB row lands on a raw field (add)", file: A, from: "key: \"system.combat.defence.other\", type: \"custom\",", to: "key: \"system.combat.defence.other\", type: \"add\"," },
  { name: "REVIEW 11: Ley Sense ignores the map", file: REG, from: "...(a.key === \"leySense\" ? { resolveDC: (ctx) => resolveLeySenseDC(ctx) } : {})", to: "" },
  { name: "Ley Sense's DC names the line (gives it away)", file: A, from: "return { dc, label: \"Ley Sense DC (Chapter 7, from the map)\" };", to: "return { dc, label: `Ley Sense DC (${found[0]?.name ?? \"none\"})` };" },
  { name: "Ley Sense's Success reaches 1000 ft", file: A, from: "const near = lines.filter((l) => l.feet <= 500)", to: "const near = lines.filter((l) => l.feet <= 1000)" },
  { name: "\"× level\" rolls a die per level", file: A, from: "  if (x) return l > 0 ? `(${x[1]})*${l}` : \"\";", to: "  if (x) return l > 0 ? `${l}${x[1].slice(1)}` : \"\";" },
  { name: "half of level 1 still bleeds", file: A, from: "      if (value === 0) return [line(", to: "      if (value === -1) return [line(" },
  // F — wiring
  { name: "the High Magic rules are not declared", file: REG, from: "  api.registerHighMagicRules?.(moduleId);\n", to: "" },
  { name: "the actions are cloned (their DCs lost)", file: REG, from: "api.registerSkillActions(BLOCK2_ACTIONS.map((a) => ({ ...a, outcomes: { ...a.outcomes } })), moduleId);", to: "api.registerSkillActions(BLOCK2_ACTIONS.map((a) => JSON.parse(JSON.stringify(a))), moduleId);" },
  { name: "the remap is not registered", file: REG, from: "  api.registerCastDegreeRemap?.(\"magicSuppression\", suppressionRemap, moduleId);\n", to: "" },
  { name: "the refusal is not registered", file: REG, from: "  api.registerCastRefusal?.(\"antimagic\", antimagicRefusal, moduleId);\n", to: "" },
  { name: "a release check never surges", file: SCRIPT, from: "Hooks.on(\"trgPrimeReleaseRolled\", (ctx) => { onReleaseRolledB2(ctx)", to: "Hooks.on(\"trgPrimeReleaseRolledX\", (ctx) => { onReleaseRolledB2(ctx)" },
  { name: "the area types are never registered", file: SCRIPT, from: "Hooks.once(\"init\", () => { registerAreaTypes(); registerBlock3bSettings(); });", to: "Hooks.once(\"init\", () => { registerBlock3bSettings(); });" },
  { name: "the module still expects 3.677.0", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.677.0\";" },
  { name: "the manifest declares no Region Behaviours", file: MANIFEST, from: "\"documentTypes\": {", to: "\"documentTypesX\": {" },
  { name: "the manifest's version is not 0.3.0", file: MANIFEST, from: "\"version\": \"0.18.3\",", to: "\"version\": \"0.2.0\"," },
  { name: "the end of your turn is the end of your next", file: CLOCK, from: "const round = now.currentTurn ? Number(now.round ?? 0) : Number(now.nextRound);", to: "const round = Number(now.nextRound);" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block2.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block2: verify-block2 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block2: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block2: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
