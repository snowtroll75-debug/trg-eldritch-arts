#!/usr/bin/env node
/**
 * verify-block5b — Eldritch Arts 0.8.0, Block 5 group B (on TRG Prime
 * 3.683.0): the fourteen Emberkin and fourteen Nyrinn racial feats.
 *
 *   A  the feats against the book: name, race, traits, prerequisites, uses,
 *      grants, the card (the book's text, then an honest paragraph), the docs
 *   B  the core, run with the content: conditionals, defence DCs, the death
 *      guard and its healTo, the per-die bonus, uses, the Focus default, the
 *      granted fly speed and Hover, the typed keys, the C1 prerequisites
 *   C  the pure rules
 *   D  registration (a fake API)
 *   E  the core's own reaction, damage-reaction and Dispel runners with the
 *      module's registrations: Anchor, Voidbound, Tideweaver, Veilstride,
 *      Mindshroud, Eclipsed Form, Threadbreaker's Precision
 *   F  the Foundry side with fakes: the Uses, the hooks, flight and the fall
 *   G  integration the lead owns (reported, not failed)
 *
 *   TRG_PRIME_ROOT=/home/claude/core-3676/trg-prime node tools/verify-block5b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y) and the placeable keep the OLD
 * position; the document's `_source` and `change` carry the NEW one.
 */
function placeEnd(doc, change) {
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
}
async function moveV14(token, change, handler, ...rest) {
  placeEnd(token.document, change);
  return handler(token.document, change, ...rest);
}


const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
const pending = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const lower = (s) => String(s ?? "").trim().toLowerCase();

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const warnings = [];
const answers = [];
const confirms = [];
const asked = [];
const askAnswers = [];
const calls = { basicSave: [], area: [], falls: [], conditions: [], traitRecorded: [], reactionsSpent: [] };
const steps = new Map();
let lightAt = 4, underwater = false, moved = { feet: 0, apOnMovement: 0 }, traitAllowed = true, reactionRefused = "";
const usesMod = await import(sys("module", "uses.mjs"));
const dmgBonus = await import(sys("module", "magic", "spell-damage-bonus.mjs"));
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => {
    const s = item.system ?? {};
    if (String(s.usesPerDay ?? "").trim()) return usesMod.resolveUsesPerDay(s.usesPerDay, {}, item.parent?.system?.identity?.level ?? null);
    return usesMod.focusDefaultUses(s, item.type);
  },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  replaceFeatEffect: async (actor, item, data) => {
    actor.effects = actor.effects.filter((e) => e.flags?.["trg-prime"]?.featSource !== item.id);
    data.flags = { ...(data.flags ?? {}), "trg-prime": { ...(data.flags?.["trg-prime"] ?? {}), featSource: item.id } };
    return (await actor.createEmbeddedDocuments("ActiveEffect", [data]))[0];
  },
  traitGate: async () => traitAllowed,
  recordTraitUsage: async (actor, action) => { calls.traitRecorded.push(action.key); },
  askReactor: async (actor, q) => {
    asked.push({ actor: actor?.name, title: q.title, step: q.step, data: q.data });
    const answer = askAnswers.length ? askAnswers.shift() : "yes";
    if (!answer || answer === "no") return { answer, result: null };
    const run = steps.get(q.step);
    return { answer, result: run ? await run(actor, answer, q.data) : null };
  },
  spendReaction: async (actor, label) => { calls.reactionsSpent.push(label); return true; },
  reactionRefusal: async () => reactionRefused,
  levelDC: (level) => 10 + Number(level),
  basicSaveHit: async (args) => { calls.basicSave.push(args); return { line: `${args.target.name} saves`, degree: "failure", taken: 1 }; },
  spellDamagePerDieBonus: async (actor, { type = "", dice = 0, traits = [] } = {}) => dmgBonus.spellDamagePerDie(dice, dmgBonus.declaredSpellDamagePerDie(Array.from(actor?.appliedEffects ?? actor?.effects ?? []), { damageType: type, traits })),
  applyConditionTagsTo: async (target, tags) => { calls.conditions.push({ target: target.name, tags }); return tags; },
  isUnderwater: async () => underwater,
  lightLevelAt: async () => lightAt,
  movementThisTurn: async () => moved,
  rollFalling: async (actor, opts) => { calls.falls.push({ actor: actor.name, ...opts }); return null; },
  runAreaEffect: async (actor, spec, opts) => { calls.area.push({ spec, targets: opts.targets.map((t) => t.name) }); return ["area"]; }
};
globalThis.Hooks = { on() {}, off() {}, callAll() {}, once() {} };
globalThis.foundry = {
  applications: { api: { DialogV2: { confirm: async () => (confirms.length ? confirms.shift() : true) } } },
  utils: {
    getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o),
    setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; },
    fromUuid: async (uuid) => globalThis.game.actors.find((a) => a.uuid === uuid) ?? null,
    randomID: () => "r1"
  }
};
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { const m = /^(\d+)d(\d+)$/.exec(this.f); this.total = m ? Number(m[1]) * 3 : 3; return this; } };
globalThis.ui = { notifications: { warn: (t) => warnings.push(t), info() {}, error() {} } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
let clickAt = null;
const listeners = {};
globalThis.window = { addEventListener: (n, fn) => { listeners[n] = fn; }, removeEventListener: (n) => { delete listeners[n]; } };

let nextId = 0;
function makeEffect(d, parent) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent };
  e.statuses = new Set(d.statuses ?? []);
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.setFlag = async (s, k, v) => { ((e.flags ??= {})[s] ??= {})[k] = v; };
  e.delete = async () => { parent.effects = parent.effects.filter((x) => x !== e); };
  return e;
}
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  return it;
}
function makeActor(name, { level = 1, items = [], pp = 5, ap = 6, dex = 0, specialist = {}, heritage = null } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, documentName: "Actor", isOwner: true, effects: [], flags: {}, items: [], tokens: [] };
  a.system = { identity: { level }, resources: { pp: { value: pp }, ap: { value: ap } }, attributes: { dexterity: { total: dex }, wisdom: { total: 2 } }, combat: { movement: { land: { total: 25 }, fly: { total: 0 } } }, specialistSkills: specialist };
  a.items = [...items, ...(heritage ? [heritage] : [])].map((d) => makeItem(d, a));
  a.items.get = (id) => a.items.find((i) => i.id === id);
  Object.defineProperty(a, "appliedEffects", { get: () => [...a.effects, ...a.items.flatMap((i) => (i.effects ?? []).filter((e) => e.transfer))] });
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); return made; }
    const made = list.map((d) => makeEffect(d, a));
    a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => { a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.getActiveTokens = () => a.tokens;
  // A CONNECTED PLAYER OWNS a `playerOwned` actor (review, 0.8.0): `actsFor` is then theirs, not the GM's.
  a.testUserPermission = (u) => Boolean(u?.isGM || (a.playerOwned === true && u?.id === PLAYER.id));
  return a;
}
const clearBoard = () => { canvas.tokens.placeables.length = 0; };
function place(actor, x, y, elevation = 0) {
  const t = { id: `t-${actor.name}`, name: actor.name, actor, w: 100, h: 100 };
  t.document = { elevation, x, y, width: 1, height: 1, _source: { x, y, width: 1, height: 1 }, object: t, actor,
    update: async (u) => { Object.assign(t.document, u); Object.assign(t.document._source, u); } };
  actor.tokens = [t];
  canvas.tokens.placeables.push(t);
  return t;
}
globalThis.canvas = {
  tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.round(Math.hypot(a.x - b.x, a.y - b.y) / 100 * 5) }), getSnappedPoint: (p) => ({ x: Math.round(p.x / 100) * 100, y: Math.round(p.y / 100) * 100 }) },
  stage: { on: (n, fn) => { setTimeout(() => fn({ data: { getLocalPosition: () => clickAt } }), 0); }, off() {} }
};
const GM = { id: "gm", name: "GM", isGM: true, active: true, targets: new Set() };
const PLAYER = { id: "p1", name: "Player", isGM: false, active: true, targets: new Set() };
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: GM, users: { activeGM: GM, filter: (fn) => [GM, PLAYER].filter(fn), get: (id) => [GM, PLAYER].find((u) => u.id === id) },
  combat: null, actors: [], packs: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.683.0" }, messages: []
};
/** Run on the connected player's client (the GM's is the default). */
async function asPlayer(fn) { const was = game.user; game.user = PLAYER; try { return await fn(); } finally { game.user = was; } }
const combatOf = (...actors) => ({ id: "c1", started: true, round: 3, turn: 0, combatants: actors.map((actor) => ({ actor, actorId: actor.id })), combatant: { actor: actors[0] } });

const common = await import(new URL("./content/block5-common.mjs", import.meta.url));
const C = await import(new URL("./content/block5-b.mjs", import.meta.url));
const B1C = await import(new URL("./content/block1.mjs", import.meta.url));
const auto = await import(new URL("../module/block5b-automations.mjs", import.meta.url));
const b1 = await import(new URL("../module/block1-automations.mjs", import.meta.url));
const MODULE_ID = "trg-eldritch-arts", SYSTEM_ID = "trg-prime";
const sysFlags = (doc) => doc?.flags?.[SYSTEM_ID] ?? {};
const byName = new Map(C.FEATS_B5_B.map((f) => [lower(f.name), f]));
const F = (name) => byName.get(lower(name));
const plain = (d) => JSON.parse(JSON.stringify(d));

/* ----------------------------------------------------------------- */
/* A — the feats against the book                                      */
/* ----------------------------------------------------------------- */
const KEYS = {
  emberkin: ["ECHO OF THE ANCESTORS", "ELEMENTAL APOTHEOSIS", "ELEMENTAL BULWARK", "ELEMENTAL REPRISAL", "ELEMENTAL STEP", "EMBERBORN FURY", "EMBER EYED", "EMBERKIN SCHOLAR", "ETERNAL SCHOLAR", "MANTLE OF ESSENCE", "STONEBOUND BASTION", "STORMRUNNER’S ZEAL", "TIDEWEAVER’S RESILIENCE", "VEIN OF POWER"],
  nyrinn: ["ANCHOR IN NOTHING", "CRYSTAL PULSE", "ECLIPSED FORM", "MINDSHROUD", "NIGHT’S EMBRACE", "NYRINN SCHOLAR", "SHADOW INITIATE", "SILENT VEIL", "THREADBREAKER’S PRECISION", "VEILSTRIDE", "VOIDBORN GRACE", "VOIDBOUND RESOLVE", "VOIDBORN WINGS", "WHISPERS OF THE VOID"]
};
const ALL_KEYS = [...KEYS.emberkin, ...KEYS.nyrinn];
const racial = new Map(book.sections.racialFeats.map((f) => [f.name, f]));
{
  equal("A twenty-eight feats, fourteen Emberkin then fourteen Nyrinn", C.FEATS_B5_B.length, 28);
  equal("A …every one in the brief's list, by the book's name", C.FEATS_B5_B.map((f) => lower(f.name)), ALL_KEYS.map(lower));
  equal("A …each named as the module's own names say (case aside)", Object.values(auto.N).map(lower).sort(), ALL_KEYS.filter((k) => !["STONEBOUND BASTION", "EMBER EYED", "ETERNAL SCHOLAR", "NIGHT’S EMBRACE", "WHISPERS OF THE VOID"].includes(k)).map(lower).sort());
  ok("A every book entry is tagged EMBERKIN or NYRINN as listed", KEYS.emberkin.every((k) => racial.get(k)?.traits.includes("EMBERKIN")) && KEYS.nyrinn.every((k) => racial.get(k)?.traits.includes("NYRINN")));
  for (const key of ALL_KEYS) {
    const f = racial.get(key), doc = F(key);
    const races = f.traits.filter((t) => common.RACE_OF_TRAIT[t]).map((t) => common.RACE_OF_TRAIT[t]).join(", ");
    const traits = f.traits.filter((t) => !common.RACE_OF_TRAIT[t]).map(common.titleCase).join(", ");
    equal(`A ${key}: racial, its race, its other traits, its prerequisites`, [doc.type, doc.system.category, doc.system.sourceRace, doc.system.traits, doc.system.prerequisites], ["feat", "Racial", races, traits, f.fields?.Prerequisites ?? ""]);
    const desc = doc.system.description;
    const firstLine = String(f.lines[0]).replace(/\*\*/g, "").replace(/<sup>.*?<\/sup>/g, "").slice(0, 40);
    ok(`A ${key}: the card carries the book's text and the automation paragraph`, desc.replace(/<\/?strong>/g, "").includes(firstLine) && /<em>(Automated|Partly automated|Not yet automated)/.test(desc), firstLine);
    equal(`A ${key}: Block 5, the book's line`, [sysFlags(doc).eaBlock, sysFlags(doc).eaBookLine], [5, f.line]);
  }
  ok("A Eternal Scholar is offered to the Ascendan and the Emberkin; Shadow Initiate to the Kornargon and the Nyrinn", F("Eternal Scholar").system.sourceRace === "Ascendan, Emberkin" && F("Shadow Initiate").system.sourceRace === "Kornargon, Nyrinn");
  ok("A curly apostrophes kept (the prerequisite gate matches exactly)", ["Stormrunner’s Zeal", "Tideweaver’s Resilience", "Night’s Embrace", "Threadbreaker’s Precision"].every((n) => F(n) && F(n).name.includes("’")));
  // Uses.
  equal("A uses a day: Anchor 1, Mindshroud 1, Voidbound the class bonus; none else printed", C.FEATS_B5_B.filter((f) => f.system.usesPerDay).map((f) => [f.name, f.system.usesPerDay]), [[F("Anchor in Nothing").name, "1"], [F("Mindshroud").name, "1"], [F("Voidbound Resolve").name, "2, 3 at 5th, 4 at 10th, 5 at 15th, 6 at 20th"]]);
  equal("A …Anchor and Mindshroud arrive with their use", [F("Anchor in Nothing").system.usesValue, F("Mindshroud").system.usesValue], [1, 1]);
  equal("A the Focus feats (one use, Refocus or daily preparation: the core's default)", C.FEATS_B5_B.filter((f) => usesMod.focusDefaultUses(f.system, "feat") === 1).map((f) => lower(f.name)), ["echo of the ancestors", "elemental apotheosis", "elemental bulwark", "elemental reprisal", "elemental step", "mantle of essence", "eclipsed form", "voidborn wings"]);
  // Grants.
  equal("A Ember Eyed grants Darkvision", F("Ember Eyed").system.grantedAbilities, "Darkvision");
  equal("A Night's Embrace: Invisibility, innate (Focus)", [F("Night’s Embrace").system.grantedSpells, sysFlags(F("Night’s Embrace")).grantInnate], ["Invisibility", true]);
  equal("A Whispers of the Void: Fear, innate (Focus)", [F("Whispers of the Void").system.grantedSpells, sysFlags(F("Whispers of the Void")).grantInnate], ["Fear", true]);
  ok("A no other feat grants anything", C.FEATS_B5_B.filter((f) => f.system.grantedSpells || f.system.grantedAbilities || f.system.grantedFeats).length === 3);
  // Skill bonuses.
  const skillChanges = (doc) => doc.effects.flatMap((e) => e.changes).filter((c) => /^system\.skills\./.test(c.key)).map((c) => `${c.key.split(".")[2]} +${c.value}`).sort();
  equal("A Emberkin Scholar: Arcana and Nature +1 racial", skillChanges(F("Emberkin Scholar")), ["arcana +1", "nature +1"]);
  equal("A Eternal Scholar: Arcana, Linguistics and Occultism +1 racial", skillChanges(F("Eternal Scholar")), ["arcana +1", "linguistics +1", "occultism +1"]);
  equal("A Nyrinn Scholar: Occultism and Planes +1 racial", skillChanges(F("Nyrinn Scholar")), ["occultism +1", "planes +1"]);
  equal("A Shadow Initiate: Stealth +2 racial", skillChanges(F("Shadow Initiate")), ["stealth +2"]);
  equal("A Whispers of the Void: Deception and Intimidate +1 racial", skillChanges(F("Whispers of the Void")), ["deception +1", "intimidate +1"]);
  ok("A …every skill bonus is in the racial slot, ADD", C.FEATS_B5_B.flatMap((f) => f.effects.flatMap((e) => e.changes)).filter((c) => /^system\.skills\./.test(c.key)).every((c) => c.key.endsWith(".racial") && c.mode === 2));
  // Declarations.
  equal("A Emberborn Fury declares +1 a fire die (C6)", F("Emberborn Fury").effects[0].flags[SYSTEM_ID].spellDamageBonus, { label: "Emberborn Fury", perDie: 1, damageTypes: ["fire"], type: "untyped" });
  equal("A Vein of Power: a +1 Spell Adder in the pack", sysFlags(F("Vein of Power")).spellAdder, 1);
  equal("A Silent Veil: 5 ft more Null Aura", sysFlags(F("Silent Veil")).eaNullAuraBonus, 5);
  equal("A Stonebound Bastion: Critical Resistance 1", F("Stonebound Bastion").effects.flatMap((e) => e.changes), [{ key: "system.combat.criticalResistance", mode: 2, value: "1", priority: 20 }]);
  equal("A Tideweaver's Resilience: the 0 HP guard, offered, daily, healing to level + Wisdom, not outright (Q71)", F("Tideweaver’s Resilience").effects[0].flags[SYSTEM_ID].deathGuard, { label: "Tideweaver’s Resilience", offer: true, askOwner: true, frequency: "daily", notOutright: true, healTo: { level: true, ability: "wisdom" } });
  ok("A notes on the sheet for what stays the GM's: Night's Embrace, Silent Veil", F("Night’s Embrace").effects.some((e) => e.flags[SYSTEM_ID].featNote) && F("Silent Veil").effects.some((e) => e.flags[SYSTEM_ID].featNote));
  // The cards are honest.
  // Block 6 (0.9.0, block6d) built the echo as a module metamagic option (G1), as Q75 ruled.
  ok("A Echo of the Ancestors is automated by Block 6's metamagic, as Q75 ruled", /<em>Automated \(0\.9\.0, TRG Prime 3\.684\.0\):<\/em>/.test(F("Echo of the Ancestors").system.description) && /Block 6/.test(F("Echo of the Ancestors").system.description) && /Q75/.test(F("Echo of the Ancestors").system.description) && /half the damage, rounded down/.test(F("Echo of the Ancestors").system.description));
  ok("A the C feats say what is not automated", ["Eclipsed Form", "Night’s Embrace", "Silent Veil", "Voidborn Grace"].every((n) => /Partly automated/.test(F(n).system.description) && /Not automated:/.test(F(n).system.description)));
  ok("A the rulings are cited where they decided it", [["Threadbreaker’s Precision", "Q67"], ["Eclipsed Form", "Q68"], ["Crystal Pulse", "Q69"], ["Emberborn Fury", "Q70"], ["Elemental Apotheosis", "Q70"], ["Tideweaver’s Resilience", "Q71"], ["Veilstride", "Q72"], ["Voidbound Resolve", "Q73"], ["Nyrinn Scholar", "Q74"], ["Shadow Initiate", "Q61"]].every(([n, q]) => F(n).system.description.includes(q)));
  // The docs.
  const levels = Object.values(C.AUTOMATION_B5_B).map((r) => r.level);
  equal("A AUTOMATION_B5_B: every feat, a level and a sentence", Object.keys(C.AUTOMATION_B5_B).map(lower).sort(), ALL_KEYS.map(lower).sort());
  ok("A …levels are A–D, each with what", Object.values(C.AUTOMATION_B5_B).every((r) => ["A", "B", "C", "D"].includes(r.level) && r.what.length > 10));
  equal("A …counts A/B/C/D", ["A", "B", "C", "D"].map((l) => levels.filter((x) => x === l).length), [11, 13, 4, 0]);
  ok("A …a D feat's card claims no automation; a C feat's card is partial", Object.entries(C.AUTOMATION_B5_B).every(([n, r]) => (r.level === "D" ? /Not yet automated/.test(F(n).system.description) : r.level === "C" ? /Partly automated/.test(F(n).system.description) : /<em>Automated/.test(F(n).system.description))));
  ok("A ids are stable and unique", new Set(C.FEATS_B5_B.map((f) => f._id)).size === 28 && C.FEATS_B5_B.every((f) => /^[A-Za-z0-9]{16}$/.test(f._id)));
}

/* ----------------------------------------------------------------- */
/* B — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
{
  const cond = await import(sys("module", "conditionals.mjs"));
  const [mind] = sysFlags(F("Mindshroud")).conditionals.map((r, i) => cond.normaliseConditional(r, { id: "m", name: "Mindshroud" }, i));
  ok("B Mindshroud: advantage on a save against the Emotion trait, automatically", mind && mind.kind === "advantage" && mind.auto === true && cond.matchesCheck(mind, { checkType: "save", subject: "will", traits: ["emotion", "mental"] }));
  ok("B …not against Fear, nor on a skill check", !cond.matchesCheck(mind, { checkType: "save", traits: ["fear"] }) && !cond.matchesCheck(mind, { checkType: "skill", traits: ["emotion"] }));
  const [stone] = sysFlags(F("Stonebound Bastion")).conditionals.map((r, i) => cond.normaliseConditional(r, { id: "s", name: "Stonebound" }, i));
  ok("B Stonebound Bastion's tick: +2 racial on Fortitude saves, offered (not automatic)", stone && stone.type === "race" && stone.value === 2 && stone.auto === false && cond.matchesCheck(stone, { checkType: "save", subject: "fortitude" }) && !cond.matchesCheck(stone, { checkType: "save", subject: "reflex" }));
  const dd = await import(sys("module", "combat", "defence-dc.mjs"));
  const bastion = makeActor("ZZ Stonevein", { items: [F("Stonebound Bastion")] });
  equal("B …+2 on the Fortitude DC against a Shove and a Trip (Storgar's channel)", [dd.defenceDCBonus(bastion, "fortitudeDC", "shoveAttack").total, dd.defenceDCBonus(bastion, ["skillDC:acrobatics", "fortitudeDC"], "tripAttack").total], [2, 2]);
  equal("B …nothing against a Grapple, nor on the Reflex DC", [dd.defenceDCBonus(bastion, "fortitudeDC", "grappleAttack").total, dd.defenceDCBonus(bastion, "reflexDC", "shoveAttack").total], [0, 0]);
  const dg = await import(sys("module", "combat", "death-guard.mjs"));
  const [guard] = dg.declaredDeathGuards(F("Tideweaver’s Resilience").effects);
  equal("B Tideweaver's guard: an offer, daily, to its owner, not outright, healTo level + Wisdom", guard && [guard.offer, guard.frequency, guard.askOwner, guard.notOutright, guard.healTo], [true, "daily", true, true, { level: true, ability: "wisdom" }]);
  equal("B …a 7th-level Tidemarked with Wisdom 3 stays up on 10 HP; at least 1; never above the maximum", [dg.deathGuardHealTo(guard, 40, { level: 7, attributes: { wisdom: { total: 3 } } }), dg.deathGuardHealTo(guard, 40, { level: 1, attributes: { wisdom: { total: -3 } } }), dg.deathGuardHealTo(guard, 6, { level: 7, attributes: { wisdom: { total: 3 } } })], [10, 1, 6]);
  ok("B …not against massive damage, and once a day", Boolean(dg.deathGuardExcepted(guard, { massive: true })) && Boolean(dg.deathGuardExcepted(guard, { usedToday: { [guard.label]: true } })) && dg.deathGuardExcepted(guard, {}) === null);
  // The per-die bonus: Fury, Apotheosis.
  const fury = F("Emberborn Fury").effects[0];
  const apo = auto.apotheosisEffect("fire");
  const rows = dmgBonus.declaredSpellDamagePerDie([fury, apo], { damageType: "fire" });
  equal("B Emberborn Fury and Elemental Apotheosis stack: +2 a fire die (Q70) — 3d6 fire takes +6", dmgBonus.spellDamagePerDie("3d6", rows).total, 6);
  equal("B …cold takes nothing from Fury; Apotheosis as cold, +1 a cold die", [dmgBonus.declaredSpellDamagePerDie([fury], { damageType: "cold" }).length, dmgBonus.spellDamagePerDie("2d8", dmgBonus.declaredSpellDamagePerDie([auto.apotheosisEffect("cold")], { damageType: "cold" })).total], [0, 2]);
  equal("B …and the flat reader skips per-die rows", dmgBonus.declaredSpellDamageBonuses([fury, apo], {}).length, 0);
  // Uses.
  const cfg = await import(sys("module", "config.mjs"));
  ok("B Voidbound Resolve's count is the class bonus at every level 1–20", Array.from({ length: 20 }, (_, i) => i + 1).every((l) => usesMod.resolveUsesPerDay(C.CLASS_BONUS_USES, {}, l) === cfg.classBonusForLevel(l)));
  // Flight.
  const gs = await import(sys("module", "combat", "granted-speeds.mjs"));
  const car = await import(sys("module", "creature-ability-rules.mjs"));
  const wingItem = { flags: { [SYSTEM_ID]: { creatureAbility: { derives: auto.flightDerives(true, { hover: true }) } } } };
  equal("B a flying feat grants the core's fly speed equal to land", gs.grantedSpeeds([wingItem], ["land", "fly", "swim", "climb", "burrow"]), [{ key: "fly", feet: 0, orLand: true }]);
  ok("B …and Voidborn Grace's Hover is read by the core", car.abilitiesHover([wingItem]) && !car.abilitiesHover([{ flags: { [SYSTEM_ID]: { creatureAbility: { derives: auto.flightDerives(true) } } } }]));
  // Typed keys: routed into the typed pools.
  const reg = await import(sys("module", "bonuses", "registry.mjs"));
  const keys = [auto.bulwarkEffect(null), auto.mantleEffect(null, 2), auto.shadowInitiateEffect()].flatMap((e) => e.changes).map((c) => [reg.parseBonusKey(c.key), c.mode]);
  equal("B the module's effects write the typed pools (CUSTOM): DB and saves racial, DB circumstance, land speed racial", keys.map(([p, m]) => `${p?.target}:${p?.type}:${m}`), ["system.combat.defence:race:0", "system.combat.saves.fortitude:race:0", "system.combat.saves.reflex:race:0", "system.combat.saves.will:race:0", "system.combat.defence:circumstance:0", "system.combat.movement.land:race:0"]);
  // C1: the prerequisites the core gates.
  const pre = await import(sys("module", "prerequisites.mjs"));
  const known = new Set(C.FEATS_B5_B.map((f) => pre.prerequisiteNameKey(f.name)));
  const heritages = new Set(B1C.HERITAGES.map((h) => pre.heritageNameKey(h.name)));
  const gate = (name, { level = 20, owns = [], heritage = "" } = {}) => pre.meetsParseablePrerequisites(F(name).system.prerequisites, { level, knownNames: known, ownedNames: new Set(owns.map(pre.prerequisiteNameKey)), knownHeritages: heritages, heritageNames: new Set(heritage ? [pre.heritageNameKey(heritage)] : []) });
  ok("B C1: a heritage feat is its heritage's (Emberborn Fury: Cinderblood; Silent Veil: Vel-tharis)", gate("Emberborn Fury", { heritage: "Cinderblood" }) && !gate("Emberborn Fury", { heritage: "Stonevein" }) && gate("Silent Veil", { heritage: "Vel-tharis" }) && !gate("Silent Veil", { heritage: "Zhal-vryn" }));
  ok("B …and the other five heritage feats", [["Stonebound Bastion", "Stonevein"], ["Stormrunner’s Zeal", "Galeborne"], ["Tideweaver’s Resilience", "Tidemarked"], ["Crystal Pulse", "Vir-ellian"], ["Threadbreaker’s Precision", "Zhal-vryn"]].every(([n, her]) => gate(n, { heritage: her }) && !gate(n, { heritage: "Cinderblood" })));
  ok("B Ember Eyed: Level 1 only", gate("Ember Eyed", { level: 1 }) && !gate("Ember Eyed", { level: 2 }));
  ok("B the chains are gated by name: Bulwark → Reprisal (5) → Apotheosis (10)", !gate("Elemental Reprisal", { level: 5 }) && gate("Elemental Reprisal", { level: 5, owns: ["Elemental Bulwark"] }) && !gate("Elemental Reprisal", { level: 4, owns: ["Elemental Bulwark"] }) && gate("Elemental Apotheosis", { level: 10, owns: ["Elemental Reprisal"] }) && !gate("Elemental Apotheosis", { level: 9, owns: ["Elemental Reprisal"] }));
  ok("B …Mindshroud → Voidbound Resolve → Anchor in Nothing; Silent Veil → Veilstride → Night's Embrace; Wings → Grace", gate("Voidbound Resolve", { level: 5, owns: ["Mindshroud"] }) && !gate("Voidbound Resolve", { level: 5 }) && gate("Anchor in Nothing", { level: 10, owns: ["Voidbound Resolve"] }) && !gate("Anchor in Nothing", { level: 10 })
    && gate("Veilstride", { level: 5, owns: ["Silent Veil"] }) && !gate("Veilstride", { level: 5 }) && gate("Night’s Embrace", { level: 10, owns: ["Veilstride"] }) && !gate("Night’s Embrace", { level: 10 })
    && gate("Voidborn Grace", { level: 10, owns: ["Voidborn Wings"] }) && !gate("Voidborn Grace", { level: 10 }) && !gate("Voidborn Wings", { level: 4 }) && gate("Voidborn Wings", { level: 5 }));
}

/* ----------------------------------------------------------------- */
/* C — the pure rules                                                   */
/* ----------------------------------------------------------------- */
{
  equal("C 1d4 a two levels (Reprisal, Voidbound's backlash), at least one", [1, 2, 5, 10, 19, 20].map(auto.perTwoLevelsD4), ["1d4", "1d4", "2d4", "5d4", "9d4", "10d4"]);
  equal("C Mantle of Essence: +1, +1 at 5th and every 5", [1, 4, 5, 9, 10, 15, 20].map(auto.mantleBonus), [1, 1, 2, 2, 3, 4, 5]);
  equal("C Vein of Power: +1, +1 at 5th and every 5", [1, 4, 5, 10, 20].map(auto.veinAdder), [1, 1, 2, 3, 5]);
  equal("C Voidborn Wings: level + Dexterity rounds", [auto.wingsRounds(5, 4), auto.wingsRounds(10, 2), auto.wingsRounds(1, -3)], [9, 12, 0]);
  equal("C Voidborn Grace: 60 ft a round, not below the ground", [auto.glideStep(150), auto.glideStep(60), auto.glideStep(20)], [90, 0, 0]);
  equal("C Crystal Pulse: the release's d4s and one more (Q69)", [auto.crystalFormula(3), auto.crystalFormula(1)], ["4d4", "2d4"]);
  equal("C …force or electricity", [...auto.CRYSTAL_TYPES], ["force", "electricity"]);
  equal("C light 5 or less is dark enough; unknown light is not", [auto.darkEnough(1), auto.darkEnough(5), auto.darkEnough(6), auto.darkEnough(null)], [true, true, false, false]);
  equal("C Veilstride: 10 ft since the last advantage, in the dark (Q72)", [auto.veilstrideDue({ feet: 10, light: 5 }), auto.veilstrideDue({ feet: 5, light: 3 }), auto.veilstrideDue({ feet: 15, usedAt: 10, light: 3 }), auto.veilstrideDue({ feet: 20, usedAt: 10, light: 3 }), auto.veilstrideDue({ feet: 30, light: 6 })], [true, false, false, true, false]);
  equal("C Voidbound Resolve: the +2 made the difference (Q73)", [auto.voidboundCaused({ succeeded: true, total: 16, dc: 15 }), auto.voidboundCaused({ succeeded: true, total: 17, dc: 15 }), auto.voidboundCaused({ succeeded: false, total: 14, dc: 15 }), auto.voidboundCaused({ succeeded: true, total: 15, dc: null })], [true, false, false, false]);
  const me = { uuid: "Actor.me" };
  equal("C …asked of a targeted spell's Will save only", [
    auto.voidboundAsks({ type: "save", subject: "will", isArea: false, saveSource: "Charm Person", sourceUuid: "Actor.x", actor: me }),
    auto.voidboundAsks({ type: "save", subject: "will", isArea: true, saveSource: "Fear", sourceUuid: "Actor.x", actor: me }),
    auto.voidboundAsks({ type: "save", subject: "reflex", isArea: false, saveSource: "Ray", sourceUuid: "Actor.x", actor: me }),
    auto.voidboundAsks({ type: "save", subject: "will", isArea: false, saveSource: "", sourceUuid: "Actor.x", actor: me }),
    auto.voidboundAsks({ type: "save", subject: "will", isArea: false, saveSource: "Own", sourceUuid: "Actor.me", actor: me })
  ], [true, false, false, false, false]);
  equal("C Eclipsed Form (Q68): half of a non-magical physical weapon blow", [auto.eclipsedAnswer({ kind: "weapon", types: ["slashing"] }), auto.eclipsedAnswer({ kind: "weapon", types: ["fire"] }), auto.eclipsedAnswer({ kind: "spell", types: ["bludgeoning"] }), auto.eclipsedAnswer({ kind: "weapon", types: ["piercing"] }, () => true), auto.eclipsedAnswer({ kind: "weapon", types: ["piercing"], magical: true })], [{ resist: ["slashing"], scope: "instance" }, null, null, null, null]);
  const runed = { items: [{ type: "weapon", system: { equipped: true, damageType: "slashing", runeModifiers: { potency: 1 } } }] };
  const plainBlade = { items: [{ type: "weapon", system: { equipped: true, damageType: "slashing" } }, { type: "weapon", system: { equipped: true, damageType: "slashing", runeModifiers: { potency: 1 } } }] };
  equal("C …a Potency-runed blade is magical; a mundane one beside it is not read as magical; no weapon is not magical", [auto.attackerBlowMagical(runed, "slashing"), auto.attackerBlowMagical(plainBlade, "slashing"), auto.attackerBlowMagical({ items: [] }, "slashing"), auto.attackerBlowMagical({ items: [{ type: "weapon", system: { equipped: true, damageType: "piercing" }, flags: { [SYSTEM_ID]: { magicalStrike: true } } }] }, "piercing")], [true, false, false, true]);
  equal("C Silent Veil's feet, from feats only", [auto.nullAuraBonusFeet([F("Silent Veil")]), auto.nullAuraBonusFeet([{ type: "heritage", flags: { [SYSTEM_ID]: { eaNullAuraBonus: 5 } } }]), auto.nullAuraBonusFeet([])], [5, 0, 0]);
  equal("C Threadbreaker's Dazed 1 to the end of its next turn: two round boundaries, or 6 s", [auto.dazedTag({ inCombat: true, round: 4 }), auto.dazedTag({ worldTime: 100 })], [{ key: "dazed", value: 1, expiresRound: 6 }, { key: "dazed", value: 1, expiresTime: 106 }]);
  equal("C the fly declaration, with or without Hover, or none", [auto.flightDerives(true), auto.flightDerives(true, { hover: true }), auto.flightDerives(false)], [{ movement: { key: "fly", orLand: true } }, { movement: { key: "fly", orLand: true }, hover: true }, null]);
  const cinder = B1C.HERITAGES.find((h) => h.name === "Cinderblood");
  equal("C the heritage element is Block 1's eaElement", [auto.heritageElement([cinder]), auto.heritageElement([B1C.HERITAGES.find((h) => h.name === "Tidemarked")]), auto.heritageElement([])], ["fire", "cold", ""]);
  ok("C …met by damage of that type only", auto.elementTaken(["Fire", "slashing"], "fire") && !auto.elementTaken(["cold"], "fire") && !auto.elementTaken(["fire"], ""));
  equal("C Apotheosis: immunity to the element for a minute, and +1 a die of it", [auto.apotheosisEffect("acid").changes, auto.apotheosisEffect("acid").flags[SYSTEM_ID].spellDamageBonus, auto.apotheosisEffect("acid").flags[SYSTEM_ID].spellEffectEnd], [[{ key: "system.combat.immunities", mode: 2, value: ", acid", priority: 20 }], { label: "Elemental Apotheosis", perDie: 1, damageTypes: ["acid"], type: "untyped" }, 1060]);
}

/* ----------------------------------------------------------------- */
/* D — registration                                                     */
/* ----------------------------------------------------------------- */
const fakeApi = { calls: [], registerFeatAutomation(n, e) { this.calls.push(["feat", n, e]); }, registerCheckReaction(k, s) { this.calls.push(["check", k, s]); }, registerDamageReaction(k, s) { this.calls.push(["damage", k, s]); }, registerDispelModifier(k, s) { this.calls.push(["dispel", k, s]); }, registerReactionStep(k, s) { this.calls.push(["step", k, s]); steps.set(k, s); } };
auto.registerBlock5B(fakeApi, MODULE_ID);
{
  const of = (kind) => fakeApi.calls.filter((c) => c[0] === kind).map((c) => c[1]);
  equal("D the Uses", of("feat"), ["Elemental Apotheosis", "Elemental Step", "Emberkin Scholar", "Nyrinn Scholar", "Eclipsed Form", "Voidborn Wings", "Vir-ellian Release"]);
  ok("D …Vir-ellian Release keeps its own Focus use, as Block 1's did; Voidborn Wings owns its", fakeApi.calls.find((c) => c[1] === "Vir-ellian Release")[2].ownsFocusUse === true && fakeApi.calls.find((c) => c[1] === "Voidborn Wings")[2].ownsFocusUse === true && !fakeApi.calls.find((c) => c[1] === "Elemental Step")[2].ownsFocusUse);
  equal("D the check reactions, Anchor first", of("check"), ["anchorInNothing", "voidboundResolve", "tideweaversResilience", "veilstride", "mindshroud"]);
  ok("D …Voidbound before and after; Mindshroud after only", Boolean(fakeApi.calls.find((c) => c[1] === "voidboundResolve")[2].before && fakeApi.calls.find((c) => c[1] === "voidboundResolve")[2].after) && !fakeApi.calls.find((c) => c[1] === "mindshroud")[2].before);
  equal("D the damage reaction and the Dispel modifier", [of("damage"), of("dispel")], [["eclipsedForm"], ["threadbreakersPrecision"]]);
  equal("D the steps", of("step"), [auto.SPEND_STEP, auto.BULWARK_STEP, auto.REPRISAL_STEP]);
  ok("D every Use and reaction feat names an eaAutomation key on its item", ["Elemental Apotheosis", "Elemental Step", "Emberkin Scholar", "Nyrinn Scholar", "Eclipsed Form", "Voidborn Wings", "Anchor in Nothing", "Voidbound Resolve", "Veilstride", "Mindshroud", "Threadbreaker’s Precision", "Tideweaver’s Resilience", "Elemental Bulwark", "Elemental Reprisal", "Mantle of Essence", "Stormrunner’s Zeal", "Vein of Power", "Crystal Pulse", "Shadow Initiate", "Voidborn Grace"].every((n) => sysFlags(F(n)).eaAutomation));
}

/* ----------------------------------------------------------------- */
/* E — the core's runners with the module's registrations               */
/* ----------------------------------------------------------------- */
const api = await import(sys("module", "module-api.mjs"));
api.resetModuleRegistry();
const coreApi = { registerFeatAutomation: api.queueFeatAutomation, registerCheckReaction: api.registerCheckReaction, registerDamageReaction: api.registerDamageReaction, registerDispelModifier: api.registerDispelModifier, registerReactionStep: (k, s) => { api.registerReactionStep(k, s); steps.set(k, s); } };
auto.registerBlock5B(coreApi, MODULE_ID);
equal("E the core takes every registration without a problem", api.registrationProblems().length, 0);
const RW = await import(sys("module", "reactions", "reactions-workflow.mjs"));
const BIAS = { NORMAL: "normal", ADVANTAGE: "advantage", DISADVANTAGE: "disadvantage" };
let rerollTotal = 20;
const caster = makeActor("ZZ Caster", { level: 8 });
game.actors = [caster];
function saveCheck(actor, extra = {}) {
  return { type: "save", subject: "will", actor, modifiers: [], bias: "normal", dc: 15, label: "Will Save", traits: "", saveSource: "Charm Person", sourceUuid: caster.uuid, isArea: false, ...extra,
    async reroll() { this.outcome = { total: rerollTotal, degree: { key: rerollTotal >= this.dc ? "success" : "failure" } }; } };
}
{
  clearBoard();
  const ny = makeActor("ZZ Nyrinn", { level: 10, items: [F("Anchor in Nothing"), F("Voidbound Resolve"), F("Mindshroud")] });
  ny.items.find((i) => i.name.startsWith("Voidbound")).system.usesValue = 4;
  // Anchor in Nothing, yes.
  asked.length = 0; askAnswers.push("yes");
  let check = saveCheck(ny);
  await RW.checkReactionsBefore(check, BIAS);
  equal("E Anchor in Nothing: asked first, the save declared a Success, locked, the day's use spent; Voidbound not asked after it", [asked.map((a) => a.title.split(" — ")[0]), check.declaredDegree, Boolean(check.locked), ny.items.find((i) => lower(i.name) === "anchor in nothing").system.usesValue], [["Anchor In Nothing".replace("In", "in")], "success", true, 0]);
  // …a second Will save: Anchor is spent, Voidbound asked.
  asked.length = 0; askAnswers.push("yes");
  check = saveCheck(ny);
  await RW.checkReactionsBefore(check, BIAS);
  equal("E Voidbound Resolve: +2 racial before the dice, a use spent, Anchor not asked once spent", [asked.map((a) => a.title.split(" — ")[0]), check.modifiers.filter((m) => m.label === "Voidbound Resolve").map((m) => [m.value, m.type]), ny.items.find((i) => i.name.startsWith("Voidbound")).system.usesValue], [["Voidbound Resolve"], [[2, "race"]], 3]);
  // The backlash when the +2 made it.
  calls.basicSave.length = 0;
  check.outcome = { total: 16, degree: { key: "success" } };
  await RW.checkReactionsAfter(check);
  equal("E …a Success by the +2: the caster's basic Will against its own Level DC, 1d4 a two levels of mental", calls.basicSave.map((c) => [c.target.name, c.save, c.dc, c.formula, c.type]), [["ZZ Caster", "will", 18, "5d4", "mental"]]);
  calls.basicSave.length = 0;
  check = saveCheck(ny); askAnswers.push("yes");
  await RW.checkReactionsBefore(check, BIAS);
  check.outcome = { total: 19, degree: { key: "success" } };
  await RW.checkReactionsAfter(check);
  equal("E …a Success without it: no backlash", calls.basicSave.length, 0);
  // Not an area; declined; out of uses.
  asked.length = 0;
  check = saveCheck(ny, { isArea: true });
  await RW.checkReactionsBefore(check, BIAS);
  equal("E …not asked against an area spell (Q73)", asked.length, 0);
  asked.length = 0; askAnswers.push("no");
  check = saveCheck(ny);
  await RW.checkReactionsBefore(check, BIAS);
  equal("E …declined: nothing added, nothing spent", [check.modifiers.length, ny.items.find((i) => i.name.startsWith("Voidbound")).system.usesValue], [0, 2]);
  // In combat it spends the reaction.
  game.combat = combatOf(ny); calls.reactionsSpent.length = 0; askAnswers.push("yes");
  check = saveCheck(ny);
  await RW.checkReactionsBefore(check, BIAS);
  equal("E …in combat, its reaction too", calls.reactionsSpent, ["Voidbound Resolve"]);
  reactionRefused = "no reaction left"; asked.length = 0;
  await RW.checkReactionsBefore(saveCheck(ny), BIAS);
  equal("E …and is not asked with no reaction left", asked.length, 0);
  reactionRefused = ""; game.combat = null;
  // Anchor only on a Will save.
  asked.length = 0; ny.items.find((i) => lower(i.name) === "anchor in nothing").system.usesValue = 1;
  await RW.checkReactionsBefore(saveCheck(ny, { subject: "reflex" }), BIAS);
  equal("E Anchor in Nothing is not asked on a Reflex save", asked.length, 0);
  ny.items.find((i) => lower(i.name) === "anchor in nothing").system.usesValue = 0;
  // Mindshroud: a failed Will save rerolled, once a day.
  asked.length = 0; askAnswers.push("yes");
  check = saveCheck(ny, { checkReactionsBeforeAsked: true });
  check.outcome = { total: 9, degree: { key: "failure" } };
  const out = await RW.checkReactionsAfter(check);
  equal("E Mindshroud: a failed Will save is rerolled, locked, and the day's use spent", [out.rerolled, Boolean(check.locked), check.outcome.total, ny.items.find((i) => i.name === F("Mindshroud").name).system.usesValue], [true, true, 20, 0]);
  asked.length = 0;
  check = saveCheck(ny, { checkReactionsBeforeAsked: true }); check.outcome = { total: 9, degree: { key: "failure" } };
  await RW.checkReactionsAfter(check);
  equal("E …not asked again that day; nor on a Reflex save", asked.length, 0);
  // Voidbound's +2 carried onto Mindshroud's reroll (review, 0.8.0): the backlash is judged on the result that stands.
  const mindItem = ny.items.find((i) => i.name === F("Mindshroud").name), vbItem = ny.items.find((i) => i.name.startsWith("Voidbound"));
  for (const [what, second, want] of [["the reroll made it only by the +2: the backlash", 16, 1], ["the reroll made it without the +2: none", 19, 0], ["the reroll failed: none", 12, 0]]) {
    mindItem.system.usesValue = 1; vbItem.system.usesValue = 2; calls.basicSave.length = 0; rerollTotal = second;
    askAnswers.push("yes", "yes");
    check = saveCheck(ny);
    await RW.checkReactionsBefore(check, BIAS);
    check.outcome = { total: 12, degree: { key: "failure" } };
    const again = await RW.checkReactionsAfter(check);
    equal(`E Voidbound then Mindshroud — ${what}`, [again.rerolled, check.outcome.total, calls.basicSave.map((c) => [c.target.name, c.save, c.type])], [true, second, want ? [["ZZ Caster", "will", "mental"]] : []]);
  }
  rerollTotal = 20;
}
{
  clearBoard();
  // Tideweaver and Veilstride through the core's runner.
  const tide = makeActor("ZZ Tidemarked", { items: [F("Tideweaver’s Resilience")] });
  place(tide, 0, 0);
  underwater = true;
  let check = { type: "skill", subject: "athletics", actor: tide, modifiers: [], bias: "normal", dc: 12 };
  await RW.checkReactionsBefore(check, BIAS);
  equal("E Tideweaver's Resilience: +1 racial to a check while submerged", check.modifiers.map((m) => [m.value, m.type]), [[1, "race"]]);
  underwater = false;
  check = { type: "attack", actor: tide, modifiers: [], bias: "normal" };
  await RW.checkReactionsBefore(check, BIAS);
  equal("E …nothing on dry land", check.modifiers.length, 0);
  const vs = makeActor("ZZ Veilstrider", { level: 5, items: [F("Veilstride")] });
  place(vs, 200, 0);
  game.combat = combatOf(vs); moved = { feet: 15, apOnMovement: 1 }; lightAt = 4;
  check = { type: "attack", attackMode: "melee", actor: vs, modifiers: [], bias: "normal" };
  await RW.checkReactionsBefore(check, BIAS);
  equal("E Veilstride: advantage after 15 ft in light 4", check.bias, "advantage");
  check = { type: "attack", attackMode: "melee", actor: vs, modifiers: [], bias: "normal" };
  await RW.checkReactionsBefore(check, BIAS);
  equal("E …only the first melee attack after the move (Q72)", check.bias, "normal");
  moved = { feet: 25, apOnMovement: 2 };
  check = { type: "attack", attackMode: "melee", actor: vs, modifiers: [], bias: "normal" };
  await RW.checkReactionsBefore(check, BIAS);
  equal("E …another 10 ft, another", check.bias, "advantage");
  moved = { feet: 40, apOnMovement: 3 };
  for (const [what, setup] of [["a ranged attack", () => ({ attackMode: "ranged" })], ["light 6", () => { lightAt = 6; return {}; }], ["another's turn", () => { lightAt = 4; game.combat.combatant = { actor: caster }; return {}; }]]) {
    check = { type: "attack", attackMode: "melee", actor: vs, modifiers: [], bias: "normal", ...setup() };
    await RW.checkReactionsBefore(check, BIAS);
    equal(`E …none on ${what}`, check.bias, "normal");
  }
  game.combat = null;
}
{
  clearBoard();
  // Eclipsed Form through the core's damage runner.
  const DR = await import(sys("module", "combat", "granted-defences.mjs"));
  const ec = makeActor("ZZ Eclipsed", { level: 10, items: [F("Eclipsed Form")] });
  await ec.createEmbeddedDocuments("ActiveEffect", [auto.eclipsedEffect(ec)]);
  const brute = makeActor("ZZ Brute", { items: [{ type: "weapon", name: "Club", system: { equipped: true, damageType: "bludgeoning" } }] });
  await RW.damageReactionsBefore(ec, { kind: "weapon", types: ["bludgeoning"], magical: false, source: brute });
  equal("E Eclipsed Form: a non-magical club's blow is resisted (half)", DR.grantedDefencesOf(ec).resistances, ["bludgeoning"]);
  DR.clearInstanceGrants(ec);
  const knight = makeActor("ZZ Knight", { items: [{ type: "weapon", name: "Runed Sword", system: { equipped: true, damageType: "slashing", runeModifiers: { potency: 2 } } }] });
  await RW.damageReactionsBefore(ec, { kind: "weapon", types: ["slashing"], magical: false, source: knight });
  await RW.damageReactionsBefore(ec, { kind: "spell", types: ["bludgeoning"], magical: true });
  equal("E …not a Potency-runed blade's, nor a spell's", DR.grantedDefencesOf(ec).resistances, []);
  ec.effects = [];
  await RW.damageReactionsBefore(ec, { kind: "weapon", types: ["bludgeoning"], magical: false, source: brute });
  equal("E …and nothing once it has ended", DR.grantedDefencesOf(ec).resistances, []);
}
{
  clearBoard();
  // Threadbreaker's Precision through the core's Dispel modifiers.
  const DM = await import(sys("module", "combat", "dispel-modifiers.mjs"));
  const zv = makeActor("ZZ Zhal-vryn", { items: [F("Threadbreaker’s Precision")] });
  const offers = await DM.offeredDispelModifiers({ actor: zv, counterSpell: true });
  const setup = DM.combinedDispelModifiers(DM.appliedDispelOffers(offers, []));
  equal("E Threadbreaker's Precision: +2 racial on the Dispel, applied (not a tick), no PP change", [setup.modifiers, offers[0]?.optional, setup.ppFactor, setup.ppReplace], [[{ label: "Threadbreaker’s Precision", value: 2, type: "race" }], false, null, null]);
  equal("E …nothing for a Dispeller without it", (await DM.offeredDispelModifiers({ actor: caster })).length, 0);
  calls.conditions.length = 0; game.combat = combatOf(caster); game.combat.round = 5;
  const lines = await DM.dispelResultRiders({ actor: zv, countered: true, targetCaster: caster, degree: "success" }, setup.modifierKeys);
  equal("E …a counter: the caster Dazed 1 to the end of its next turn (Q67)", [calls.conditions, lines.length], [[{ target: "ZZ Caster", tags: [{ key: "dazed", value: 1, expiresRound: 7 }] }], 1]);
  calls.conditions.length = 0;
  await DM.dispelResultRiders({ actor: zv, countered: false, target: caster, degree: "failure" }, setup.modifierKeys);
  equal("E …not when it did not counter", calls.conditions.length, 0);
  const said = await DM.dispelResultRiders({ actor: zv, countered: true, targetCaster: null, presetDispel: { what: "Fireball" }, degree: "critical" }, setup.modifierKeys);
  ok("E …a counter that does not name its caster asks the GM, and dazes nobody", calls.conditions.length === 0 && /the GM applies it/.test(said.join(" ")));
  await DM.dispelResultRiders({ actor: zv, countered: true, targetCaster: null, target: zv, presetDispel: { what: "Fireball" }, degree: "success" }, setup.modifierKeys);
  equal("E …a Disrupting Magic's counter never dazes whoever happens to be targeted", calls.conditions.length, 0);
  await DM.dispelResultRiders({ actor: zv, countered: true, target: caster, degree: "success" }, setup.modifierKeys);
  equal("E …Counter Spell's Dispel names its caster as the target", calls.conditions.map((c) => c.target), ["ZZ Caster"]);
  game.combat = null;
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side with fakes                                      */
/* ----------------------------------------------------------------- */
const cinderblood = B1C.HERITAGES.find((h) => h.name === "Cinderblood");
const galeborne = B1C.HERITAGES.find((h) => h.name === "Galeborne");
const AUTO = auto.AUTOMATIONS_B5B;
const use = (actor, name) => AUTO[name].use(actor, actor.items.find((i) => lower(i.name) === lower(name)));
const itemOf = (actor, name) => actor.items.find((i) => lower(i.name) === lower(name));
const src = (actor, s) => actor.effects.filter((e) => e.flags?.[MODULE_ID]?.source === s);
{
  clearBoard();
  // Elemental Apotheosis.
  const em = makeActor("ZZ Cinder", { level: 10, items: [F("Elemental Apotheosis"), F("Emberborn Fury")], heritage: cinderblood });
  game.combat = combatOf(em);
  await use(em, "Elemental Apotheosis");
  const e = src(em, "elementalApotheosis")[0];
  equal("F Elemental Apotheosis: 1 AP, immune to fire for a minute, +1 a fire die", [em.system.resources.ap.value, e?.changes?.[0]?.value, e?.flags?.[SYSTEM_ID]?.spellDamageBonus?.damageTypes], [5, ", fire", ["fire"]]);
  const noEl = makeActor("ZZ Nobody", { items: [F("Elemental Apotheosis")] });
  warnings.length = 0;
  ok("F …refused without an Emberkin heritage", (await use(noEl, "Elemental Apotheosis")) === false && /names no element/.test(warnings.join()));
  game.combat = null;
}
{
  clearBoard();
  // Elemental Step.
  const st = makeActor("ZZ Stepper", { level: 5, items: [F("Elemental Step")] });
  place(st, 0, 0);
  game.combat = combatOf(st);
  clickAt = { x: 450, y: 50 };
  calls.traitRecorded.length = 0;
  const moved4 = await use(st, "Elemental Step");
  equal("F Elemental Step: teleports within land speed, 1 AP, the trait recorded", [moved4, st.tokens[0].document.x, st.system.resources.ap.value, calls.traitRecorded], [true, 400, 5, ["elementalStep"]]);
  clickAt = { x: 1050, y: 50 }; warnings.length = 0;
  ok("F …refused beyond its land speed, nothing spent", (await use(st, "Elemental Step")) === false && st.system.resources.ap.value === 5 && /up to 25 feet/.test(warnings.join()));
  traitAllowed = false; clickAt = { x: 650, y: 50 };
  ok("F …refused by the trait rules (Teleportation's once a turn)", (await use(st, "Elemental Step")) === false && st.tokens[0].document.x === 400);
  traitAllowed = true; game.combat = null;
}
{
  clearBoard();
  // The Scholars.
  const sch = makeActor("ZZ Scholar", { items: [], specialist: { elementalLore: { label: "Elemental Lore" }, history: { label: "History Lore" } } });
  const [made] = await sch.createEmbeddedDocuments("Item", [F("Emberkin Scholar")]);
  await auto.onItemCreatedB5B(made);
  equal("F Emberkin Scholar: +2 racial on Elemental Lore, found as the feat arrives", sch.effects.flatMap((e) => e.changes), [{ key: "system.specialistSkills.elementalLore.racial", mode: 2, value: "2", priority: 20 }]);
  const bare = makeActor("ZZ Bare", { specialist: {} });
  const [b] = await bare.createEmbeddedDocuments("Item", [F("Emberkin Scholar")]);
  cards.length = 0;
  await auto.onItemCreatedB5B(b);
  ok("F …without Elemental Lore, nothing applied and the card says to Use it later", bare.effects.length === 0 && /no <strong>Elemental Lore<\/strong>/.test(cards.flatMap((c) => c.lines).join()));
  const ny = makeActor("ZZ Lorekeeper", { items: [F("Nyrinn Scholar")], specialist: { spellLore: { label: "Spell Lore" }, nyrinnLore: { label: "Nyrinn Lore" }, other: { label: "Wyrm Lore" } } });
  answers.push("nyrinnLore");
  await use(ny, "Nyrinn Scholar");
  equal("F Nyrinn Scholar: you choose Spell Lore or Nyrinn Lore (Q74), and only those", [helpers.lastOptions.map(([k]) => k), ny.effects.flatMap((e) => e.changes).map((c) => c.key)], [["spellLore", "nyrinnLore"], ["system.specialistSkills.nyrinnLore.racial"]]);
  answers.push("spellLore");
  await use(ny, "Nyrinn Scholar");
  equal("F …and using it again moves it", ny.effects.flatMap((e) => e.changes).map((c) => c.key), ["system.specialistSkills.spellLore.racial"]);
}
{
  clearBoard();
  // Vein of Power, Voidbound's uses on arrival.
  const vp = makeActor("ZZ Vein", { level: 10 });
  const [v] = await vp.createEmbeddedDocuments("Item", [F("Vein of Power")]);
  await auto.onItemCreatedB5B(v);
  equal("F Vein of Power: +3 at 10th, written as the feat arrives", v.flags[SYSTEM_ID].spellAdder, 3);
  vp.system.identity.level = 15;
  await auto.onActorUpdatedB5B(vp, { system: { identity: { level: 15 } } });
  equal("F …+4 when the level reaches 15th", v.flags[SYSTEM_ID].spellAdder, 4);
  vp.system.identity.level = 20;
  await auto.onActorUpdatedB5B(vp, { name: "x" });
  equal("F …an update that is neither level nor XP leaves it", v.flags[SYSTEM_ID].spellAdder, 4);
  await auto.onActorUpdatedB5B(vp, { system: { identity: { xp: { value: 190000 } } } });
  equal("F …a character's level-up arrives as XP (its level is derived): +5 at 20th (review)", v.flags[SYSTEM_ID].spellAdder, 5);
  vp.system.identity.level = 15;
  await auto.onDailyPreparationB5B({ actor: vp });
  equal("F …and daily preparation trues it up (+4 at 15th)", v.flags[SYSTEM_ID].spellAdder, 4);
  const vr = makeActor("ZZ Resolute", { level: 10 });
  const [r] = await vr.createEmbeddedDocuments("Item", [F("Voidbound Resolve")]);
  await auto.onItemCreatedB5B(r);
  equal("F Voidbound Resolve arrives with its four uses at 10th (a levelled count would read 0)", r.system.usesValue, 4);
}
{
  clearBoard();
  // Elemental Bulwark and Reprisal, on damage of the element.
  const em = makeActor("ZZ Ember", { level: 7, items: [F("Elemental Bulwark"), F("Elemental Reprisal"), F("Emberborn Fury")], heritage: cinderblood });
  for (const i of em.items) if (i.type === "feat") i.system.usesValue = usesMod.focusDefaultUses(i.system, "feat") ?? 0;
  const foe = makeActor("ZZ Foe", { level: 4 });
  place(em, 0, 0); place(foe, 100, 0);
  game.combat = combatOf(em);
  asked.length = 0; calls.basicSave.length = 0;
  await auto.onDamageAppliedB5B({ actor: em, amount: 6, damageTypes: ["fire"] });
  const bul = src(em, "elementalBulwark")[0];
  equal("F Elemental Bulwark and Reprisal: each asked of the Emberkin, in that order", asked.map((a) => a.step), [auto.BULWARK_STEP, auto.REPRISAL_STEP]);
  equal("F …Bulwark: +1 racial to DB and the three saves, to the start of the next turn; its use spent", [bul?.changes?.map((c) => c.key), Boolean(bul?.flags?.[MODULE_ID]?.endsAtTurnStart), itemOf(em, "Elemental Bulwark").system.usesValue], [["system.combat.defence.racial", "system.combat.saves.fortitude.racial", "system.combat.saves.reflex.racial", "system.combat.saves.will.racial"], true, 0]);
  const hit = calls.basicSave[0];
  equal("F …Reprisal: the adjacent foe, basic Reflex against its Level DC, 3d4 fire and Fury's +3 (Q70)", hit && [hit.target.name, hit.save, hit.dc, hit.type, hit.amount, hit.baseDamage], ["ZZ Foe", "reflex", 14, "fire", 12, "3d4"]);
  asked.length = 0;
  await auto.onDamageAppliedB5B({ actor: em, amount: 6, damageTypes: ["fire"] });
  equal("F …not asked again with their uses spent", asked.length, 0);
  for (const i of em.items) if (i.type === "feat") i.system.usesValue = 1;
  await auto.onDamageAppliedB5B({ actor: em, amount: 6, damageTypes: ["cold", "slashing"] });
  await auto.onDamageAppliedB5B({ actor: em, amount: 0, damageTypes: ["fire"] });
  equal("F …nor by damage of another type, nor by none taken", asked.length, 0);
  foe.tokens[0].document.x = 900; canvas.tokens.placeables.find((t) => t.actor === foe).document._source.x = 900;
  calls.basicSave.length = 0; askAnswers.push("no");
  await auto.onDamageAppliedB5B({ actor: em, amount: 3, damageTypes: ["fire"] });
  equal("F …Reprisal with nobody adjacent keeps its use", [calls.basicSave.length, itemOf(em, "Elemental Reprisal").system.usesValue], [0, 1]);
  game.combat = null;
}
{
  clearBoard();
  // Mantle of Essence.
  const mm = makeActor("ZZ Mantle", { level: 10, items: [F("Mantle of Essence")] });
  itemOf(mm, "Mantle of Essence").system.usesValue = 1;
  game.combat = combatOf(mm); calls.reactionsSpent.length = 0; confirms.push(true);
  await auto.onSpellSettledB5B({ actor: mm, spell: { name: "Fireball" }, cast: true });
  const m = src(mm, "mantleOfEssence")[0];
  equal("F Mantle of Essence: +3 circumstance DB at 10th, to the start of the next turn; reaction and use spent", [m?.changes?.[0], calls.reactionsSpent, itemOf(mm, "Mantle of Essence").system.usesValue], [{ key: "system.combat.defence.circumstance", mode: 0, value: "3", priority: 20 }, ["Mantle of Essence"], 0]);
  itemOf(mm, "Mantle of Essence").system.usesValue = 1;
  await auto.onSpellSettledB5B({ actor: mm, spell: { name: "Fireball" }, cast: false });
  await auto.onSpellSettledB5B({ actor: mm, spell: { name: "Fireball" }, cast: true, refunded: true });
  equal("F …not for a cast that failed or was refunded", src(mm, "mantleOfEssence").length, 1);
  confirms.push(false);
  await auto.onSpellSettledB5B({ actor: mm, spell: { name: "Shield" }, cast: true });
  equal("F …declined: nothing spent", itemOf(mm, "Mantle of Essence").system.usesValue, 1);
  game.combat = null;
}
{
  clearBoard();
  // Crystal Pulse on the Vir-ellian release; and Block 1's release without it.
  const vir = makeActor("ZZ Vir", { level: 6, items: [F("Crystal Pulse"), B1C.ABILITIES.find((a) => a.name === "Vir-ellian Release")] });
  const foe = makeActor("ZZ Target", {});
  place(vir, 0, 0); place(foe, 200, 0);
  const energy = async (a) => a.createEmbeddedDocuments("ActiveEffect", [{ name: "energy", flags: { [MODULE_ID]: { source: "magicDrainEnergy", energy: 3 } } }]);
  await energy(vir);
  calls.area.length = 0; answers.push("electricity");
  await auto.virEllianReleaseB5B.use(vir, itemOf(vir, "Vir-ellian Release"));
  equal("F Crystal Pulse: the release in electricity, the energy's 3d4 and 1d4 more, Will DC by level; energy and use spent", [calls.area[0]?.spec?.damage, calls.area[0]?.spec?.dc, calls.area[0]?.targets, src(vir, "magicDrainEnergy").length, itemOf(vir, "Vir-ellian Release").system.usesValue], [{ formula: "4d4", type: "electricity" }, 16, ["ZZ Target"], 0, 0]);
  const plainVir = makeActor("ZZ Plain Vir", { level: 6, items: [B1C.ABILITIES.find((a) => a.name === "Vir-ellian Release")] });
  place(plainVir, 0, 300);
  await energy(plainVir);
  calls.area.length = 0;
  await auto.virEllianReleaseB5B.use(plainVir, itemOf(plainVir, "Vir-ellian Release"));
  equal("F …without Crystal Pulse it is Block 1's own release: force, 1d4 a PP", calls.area[0]?.spec?.damage, { formula: "3d4", type: "force" });
}
{
  clearBoard();
  // Eclipsed Form's Use.
  const ec = makeActor("ZZ Blur", { level: 10, items: [F("Eclipsed Form")] });
  game.combat = combatOf(ec);
  await use(ec, "Eclipsed Form");
  equal("F Eclipsed Form: 2 AP, an effect to the start of the next turn (not the Incorporeal trait, Q68)", [ec.system.resources.ap.value, src(ec, "eclipsedForm").length, Boolean(src(ec, "eclipsedForm")[0].flags[SYSTEM_ID].grantedTraits)], [4, 1, false]);
  ec.system.resources.ap.value = 1; warnings.length = 0;
  ok("F …refused with 1 AP", (await use(ec, "Eclipsed Form")) === false && src(ec, "eclipsedForm").length === 1);
  game.combat = null;
}
{
  clearBoard();
  // Stormrunner's Zeal: flight on, off, and the fall.
  const gz = makeActor("ZZ Gale", { level: 3, items: [F("Stormrunner’s Zeal")], heritage: galeborne });
  const tok = place(gz, 0, 0, 0);
  await auto.onDamageAppliedB5B({ actor: gz, amount: 4, damageTypes: ["electricity"] });
  const z = src(gz, "stormrunnersZeal")[0];
  await auto.onEffectCreatedB5B(z);
  equal("F Stormrunner's Zeal: electricity taken — fly = land, declared on the feat", itemOf(gz, "Stormrunner’s Zeal").flags[SYSTEM_ID].creatureAbility, { derives: { movement: { key: "fly", orLand: true } } });
  await auto.onDamageAppliedB5B({ actor: gz, amount: 4, damageTypes: ["electricity"] });
  tok.document.elevation = 30;
  const first = src(gz, "stormrunnersZeal")[0];
  await gz.deleteEmbeddedDocuments("ActiveEffect", [first.id]); calls.falls.length = 0;
  await auto.onEffectDeletedB5B(first);
  equal("F …hit again, the newer flight holds: no fall when the older ends", [calls.falls.length, Boolean(itemOf(gz, "Stormrunner’s Zeal").flags[SYSTEM_ID].creatureAbility)], [0, true]);
  const second = src(gz, "stormrunnersZeal")[0];
  await gz.deleteEmbeddedDocuments("ActiveEffect", [second.id]);
  await auto.onEffectDeletedB5B(second);
  equal("F …when the last ends 30 ft up: the fly speed goes, the token is lowered, the core's fall rolled for 30 ft", [itemOf(gz, "Stormrunner’s Zeal").flags[SYSTEM_ID].creatureAbility, tok.document.elevation, calls.falls.map((f) => f.distance)], [undefined, 0, [30]]);
  await auto.onDamageAppliedB5B({ actor: gz, amount: 4, damageTypes: ["electricity"] });
  const third = src(gz, "stormrunnersZeal")[0];
  tok.document.elevation = 20; gz.system.combat.movement.fly.total = 30; calls.falls.length = 0;
  await gz.deleteEmbeddedDocuments("ActiveEffect", [third.id]);
  await auto.onEffectDeletedB5B(third);
  equal("F …no fall for a creature with another fly speed", calls.falls.length, 0);
  gz.system.combat.movement.fly.total = 0;
}
{
  clearBoard();
  // Voidborn Wings and Voidborn Grace.
  const vw = makeActor("ZZ Wings", { level: 6, dex: 4, items: [F("Voidborn Wings")] });
  vw.playerOwned = true; // a connected player's PC: the turn end runs on the GM's client only (review, 0.8.0)
  itemOf(vw, "Voidborn Wings").system.usesValue = 1;
  const tok = place(vw, 0, 600, 0);
  await use(vw, "Voidborn Wings");
  const w = src(vw, "voidbornWings")[0];
  equal("F Voidborn Wings: level + Dex rounds (10), fly = land, no Hover, the use spent", [w?.flags?.[MODULE_ID]?.rounds, itemOf(vw, "Voidborn Wings").flags[SYSTEM_ID].creatureAbility, itemOf(vw, "Voidborn Wings").system.usesValue], [10, { derives: { movement: { key: "fly", orLand: true } } }, 0]);
  warnings.length = 0; confirms.push(false);
  await use(vw, "Voidborn Wings");
  equal("F …Use again asks to land; declined, it flies on", src(vw, "voidbornWings").length, 1);
  await asPlayer(() => moveV14(tok, { elevation: 0 }, auto.onTokenUpdatedB5B));
  equal("F …at ground level before taking off, it is not a landing", src(vw, "voidbornWings").length, 1);
  tok.document.elevation = 40;
  await asPlayer(() => moveV14(tok, { elevation: 40 }, auto.onTokenUpdatedB5B));
  game.combat = combatOf(vw);
  await asPlayer(() => auto.onTurnEndedB5B({ actor: vw, combat: game.combat }));
  equal("F …the turn end is the acting GM's (the core fires it there): nothing on the player's client", src(vw, "voidbornWings")[0]?.flags?.[MODULE_ID]?.rounds, 10);
  for (let i = 0; i < 9; i += 1) await auto.onTurnEndedB5B({ actor: vw, combat: game.combat });
  equal("F …a round spent at each of its turn ends, by the acting GM, for a connected player's PC", src(vw, "voidbornWings")[0]?.flags?.[MODULE_ID]?.rounds, 1);
  calls.falls.length = 0;
  await auto.onTurnEndedB5B({ actor: vw, combat: game.combat });
  equal("F …the last round ends it", src(vw, "voidbornWings").length, 0);
  await asPlayer(() => auto.onEffectDeletedB5B(w));
  equal("F …ending 40 ft up: lowered and the fall rolled", [tok.document.elevation, calls.falls.map((f) => f.distance), itemOf(vw, "Voidborn Wings").flags[SYSTEM_ID].creatureAbility], [0, [40], undefined]);
  game.combat = null;
  warnings.length = 0;
  ok("F …and Use again waits for a Refocus", (await use(vw, "Voidborn Wings")) === false && /Refocus/.test(warnings.join()));
  // Landing ends it.
  itemOf(vw, "Voidborn Wings").system.usesValue = 1;
  await use(vw, "Voidborn Wings");
  tok.document.elevation = 10;
  await asPlayer(() => moveV14(tok, { elevation: 10 }, auto.onTokenUpdatedB5B));
  tok.document.elevation = 0;
  await asPlayer(() => moveV14(tok, { elevation: 0 }, auto.onTokenUpdatedB5B));
  equal("F …landing after taking off ends the flight", src(vw, "voidbornWings").length, 0);
  // Voidborn Grace.
  const vg = makeActor("ZZ Grace", { level: 10, dex: 4, items: [F("Voidborn Wings"), F("Voidborn Grace")] });
  vg.playerOwned = true;
  itemOf(vg, "Voidborn Wings").system.usesValue = 1;
  const gt = place(vg, 0, 900, 0);
  await use(vg, "Voidborn Wings");
  equal("F Voidborn Grace: the wings' fly speed has Hover", itemOf(vg, "Voidborn Wings").flags[SYSTEM_ID].creatureAbility.derives.hover, true);
  gt.document.elevation = 150;
  game.combat = combatOf(vg); calls.falls.length = 0;
  const gw = src(vg, "voidbornWings")[0];
  await vg.deleteEmbeddedDocuments("ActiveEffect", [gw.id]);
  await asPlayer(() => auto.onEffectDeletedB5B(gw));
  equal("F …when the flight ends 150 ft up: a glide, no fall", [src(vg, "voidbornGlide").length, calls.falls.length, gt.document.elevation], [1, 0, 150]);
  await auto.onTurnEndedB5B({ actor: vg, combat: game.combat });
  equal("F …60 ft down at its turn end, by the acting GM, for a connected player's PC (review)", gt.document.elevation, 90);
  const prone = (await vg.createEmbeddedDocuments("ActiveEffect", [{ name: "Prone", statuses: ["prone"], flags: {} }]))[0];
  await asPlayer(() => auto.onEffectCreatedB5B(prone));
  equal("F …knocked prone mid-glide: the glide ends and it falls the 90 ft left", [src(vg, "voidbornGlide").length, calls.falls.map((f) => f.distance), gt.document.elevation], [0, [90], 0]);
  // Glide to the ground.
  itemOf(vg, "Voidborn Wings").system.usesValue = 1;
  await use(vg, "Voidborn Wings");
  gt.document.elevation = 100; calls.falls.length = 0;
  const gw2 = src(vg, "voidbornWings")[0];
  await vg.deleteEmbeddedDocuments("ActiveEffect", [gw2.id]);
  await asPlayer(() => auto.onEffectDeletedB5B(gw2));
  await auto.onTurnEndedB5B({ actor: vg, combat: game.combat });
  await auto.onTurnEndedB5B({ actor: vg, combat: game.combat });
  equal("F …or settles gently: 100 → 40 → 0, no damage", [gt.document.elevation, src(vg, "voidbornGlide").length, calls.falls.length], [0, 0, 0]);
  game.combat = null;
  itemOf(vg, "Voidborn Wings").system.usesValue = 1;
  await use(vg, "Voidborn Wings");
  gt.document.elevation = 80;
  const gw3 = src(vg, "voidbornWings")[0];
  await vg.deleteEmbeddedDocuments("ActiveEffect", [gw3.id]);
  await asPlayer(() => auto.onEffectDeletedB5B(gw3));
  equal("F …out of combat it settles at once", [gt.document.elevation, src(vg, "voidbornGlide").length, calls.falls.length], [0, 0, 0]);
}
{
  clearBoard();
  // Shadow Initiate.
  const si = makeActor("ZZ Initiate", { items: [F("Shadow Initiate")] });
  si.playerOwned = true;
  const tok = place(si, 0, 1200);
  lightAt = 3;
  await asPlayer(() => moveV14(tok, { x: 0 }, auto.onTokenUpdatedB5B));
  equal("F Shadow Initiate: +5 ft land speed (racial) in light 3", src(si, "shadowInitiate").flatMap((e) => e.changes), [{ key: "system.combat.movement.land.racial", mode: 0, value: "5", priority: 20 }]);
  await asPlayer(() => auto.refreshAllB5B());
  equal("F …once, however often it is checked", src(si, "shadowInitiate").length, 1);
  lightAt = 7;
  await auto.refreshAllB5B();
  equal("F …a light hook on the GM's client leaves a connected player's actor to its player", src(si, "shadowInitiate").length, 1);
  await asPlayer(() => auto.onTurnEndedB5B({}));
  equal("F …the turn end on the player's client does nothing", src(si, "shadowInitiate").length, 1);
  await auto.onTurnEndedB5B({});
  equal("F …gone in light 7 at the turn end, the acting GM acting for the player's PC (review)", src(si, "shadowInitiate").length, 0);
  lightAt = 5;
  await asPlayer(() => auto.refreshAllB5B());
  equal("F …back at Dim Light (5)", src(si, "shadowInitiate").length, 1);
  si.items = [];
  await asPlayer(() => auto.refreshAllB5B());
  equal("F …and gone with the feat", src(si, "shadowInitiate").length, 0);
}

/* ----------------------------------------------------------------- */
/* G — integration the lead owns (reported)                             */
/* ----------------------------------------------------------------- */
{
  clearBoard();
  const vel = B1C.HERITAGES.find((h) => h.name === "Vel-tharis");
  const nullAura = B1C.ABILITIES.find((a) => a.name === "Null Aura");
  const withVeil = b1.nullAuraFeet([{ ...nullAura, type: "ability" }, vel, F("Silent Veil")]);
  ok("G Block 1's Null Aura, unchanged without Silent Veil: 10 ft for a Vel-tharis", b1.nullAuraFeet([{ ...nullAura, type: "ability" }, vel]) === 10);
  if (withVeil !== 15) pending.push(`Silent Veil: Block 1's nullAuraFeet does not yet add eaNullAuraBonus (gives ${withVeil}, wants 15) — add \`+ nullAuraBonusFeet(list)\` (module/block5b-automations.mjs) to its return.`);
  if (!/registerBlock5B\(api, moduleId\)/.test(read("module", "registration.mjs"))) pending.push("registration.mjs does not yet call registerBlock5B(api, moduleId) (after Block 1's AUTOMATIONS).");
  const script = read("scripts", "eldritch-arts.mjs");
  for (const [hook, fn] of [["trgPrimeDamageApplied", "onDamageAppliedB5B"], ["trgPrimeSpellSettled", "onSpellSettledB5B"], ["createItem", "onItemCreatedB5B"], ["updateActor", "onActorUpdatedB5B"], ["trgPrimeDailyPreparation", "onDailyPreparationB5B"], ["createActiveEffect", "onEffectCreatedB5B"], ["deleteActiveEffect", "onEffectDeletedB5B"], ["updateToken", "onTokenUpdatedB5B"], ["trgPrimeTurnEnded", "onTurnEndedB5B"], ["canvasReady", "refreshAllB5B"]]) {
    if (!new RegExp(`Hooks\\.on\\("${hook}"[^\\n]*${fn}`).test(script)) pending.push(`scripts/eldritch-arts.mjs: Hooks.on("${hook}") → ${fn} not wired yet.`);
  }
  if (!/block5-b\.mjs/.test(read("tools", "content", "packs.mjs"))) pending.push("packs.mjs does not yet ship FEATS_B5_B (ea-feats).");
}

console.log(`verify-block5b: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
if (pending.length) { console.log(`  integration pending (${pending.length}, the lead's):`); for (const p of pending) console.log(`    · ${p}`); }
process.exit(failures.length ? 1 : 0);
