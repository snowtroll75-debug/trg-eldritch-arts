#!/usr/bin/env node
/**
 * mutate-block5c — the mutation half of verify-block5c. Each mutation breaks
 * one printed number, one reading or one wire of Block 5's Scaelyn feats;
 * verify-block5c must fail on every one. Files are restored after each run,
 * and on any exit.
 *
 * IT REWRITES FILES IN PLACE: run it on a copy of the module tree, never in
 * a shared working tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block5c.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block5-c.mjs"), A = f("module", "block5c-automations.mjs");

const MUTATIONS = [
  // A/B — the content
  { name: "Alchemical Purifier grants Stinking Cloud only", file: C, from: "grantedSpells: \"Stinking Cloud, Neutralise Poison\",", to: "grantedSpells: \"Stinking Cloud\"," },
  { name: "Alchemical Purifier's spells are not innate", file: C, from: "flags: innate(\"alchemicalPurifier\"),", to: "flags: auto(\"alchemicalPurifier\")," },
  { name: "Desert Wraith's advantage is on Sneak", file: C, from: "when: { checkTypes: [\"skill\"], actions: [\"hide\"] } })", to: "when: { checkTypes: [\"skill\"], actions: [\"sneak\"] } })" },
  { name: "Desert Wraith's advantage is not a tick (natural terrain is the table's)", file: C, from: "scope: \"Hide (Stealth) in natural terrain — tick if you are\", auto: false", to: "scope: \"Hide (Stealth) in natural terrain — tick if you are\", auto: true" },
  { name: "Draconic Immunity forgets paralysis", file: C, from: "value: \", sleep, paralysis\"", to: "value: \", sleep\"" },
  { name: "Draconic Wings flies at a flat 20 ft", file: C, from: "movement: { key: \"fly\", orLand: true }", to: "movement: { key: \"fly\", feet: 20 }" },
  { name: "Sandstrider burrows at the whole land Speed", file: C, from: "landFraction: 0.5", to: "landFraction: 1" },
  { name: "Ember Handed's Crafting bonus is +1", file: C, from: "value: 2, type: \"racial\", label: \"Ember Handed\"", to: "value: 1, type: \"racial\", label: \"Ember Handed\"" },
  { name: "Ghostscale conceals at Twilight (6)", file: C, from: "export const GHOSTSCALE_LIGHT = Object.freeze({ concealedAtOrBelow: 5 });", to: "export const GHOSTSCALE_LIGHT = Object.freeze({ concealedAtOrBelow: 6 });" },
  { name: "Ghostscale declares no light", file: C, from: "flags: { ...auto(\"ghostscale\"), creatureAbility: { derives: { light: { ...GHOSTSCALE_LIGHT } } } },", to: "flags: { ...auto(\"ghostscale\") }," },
  { name: "Pyrotechnic Flair grants the wrong spell", file: C, from: "grantedSpells: \"Burning Hands\",", to: "grantedSpells: \"Fire Bolt\"," },
  { name: "Runic Aptitude's tick misses Mysterious Script", file: C, from: "actions: [\"decipherWriting\", \"mysteriousScript\", \"identifyPower\"]", to: "actions: [\"decipherWriting\", \"identifyPower\"]" },
  { name: "Scaelyn Scholar forgets Crafting", file: C, from: "[\"Arcana\", \"Crafting\"], 1)", to: "[\"Arcana\"], 1)" },
  { name: "Scaled Trickster gives +1", file: C, from: "[\"Deception\", \"Thievery\"], 2)", to: "[\"Deception\", \"Thievery\"], 1)" },
  { name: "Silence Unbound's Silence is not innate", file: C, from: "flags: innate(\"silenceUnbound\"),", to: "flags: auto(\"silenceUnbound\")," },
  { name: "Sludge Blooded forgets ingested poisons", file: C, from: "traits: [\"disease\", \"ingested\"]", to: "traits: [\"disease\"]" },
  { name: "Sludge Blooded's save bonus is a tick", file: C, from: "scope: \"Saving throws against diseases and ingested poisons\", auto: true", to: "scope: \"Saving throws against diseases and ingested poisons\", auto: false" },
  { name: "Sludge Blooded's Subsist takes Planes", file: C, from: "subjects: [\"culture\", \"survival\"]", to: "subjects: [\"culture\", \"survival\", \"planes\"]" },
  { name: "Wyrm’s Cunning gives +1 Arcana", file: C, from: "[\"Arcana\"], 2)", to: "[\"Arcana\"], 1)" },
  { name: "Ghostscale is graded B", file: C, from: "\"Ghostscale\": { level: \"A\"", to: "\"Ghostscale\": { level: \"B\"" },
  { name: "Scaled Focus's card does not say it is automated", file: C, from: "automation: \"*Automated (0.8.0):* +1 Power Point per level", to: "automation: \"+1 Power Point per level" },
  { name: "Ghostscale's card claims Hide while observed", file: C, from: "*Not automated:* Hide while observed.", to: "Hide while observed." },
  { name: "Glyph Unleashed's card does not cite Q80", file: C, from: "(0.8.0, TRG Prime 3.683.0; Graham's Q80):*", to: "(0.8.0, TRG Prime 3.683.0):*" },
  // C/E — the module: Alchemical Purifier
  { name: "Q76 undone: no allowance", file: A, from: "export const PURIFIER_ALLOWANCE = 1;", to: "export const PURIFIER_ALLOWANCE = 0;" },
  { name: "the copies arrive without the allowance", file: A, from: "if (item.type === \"spell\" && isPurifierCopy(item)) { await givePurifierAllowance(item); return; }", to: "if (item.type === \"spell\" && isPurifierCopy(item)) { return; }" },
  { name: "every granted spell is taken for a Purifier copy", file: A, from: ": norm(grantedBy(spell)?.sourceName) === \"alchemical purifier\");", to: ": Boolean(grantedBy(spell)));" },
  // Ancestral Awakening
  { name: "Ancestral Awakening spends no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    const stale = ownEffects(actor, \"ancestralAwakening\")", to: "    const stale = ownEffects(actor, \"ancestralAwakening\")" },
  { name: "Ancestral Awakening lasts 10 minutes", file: A, from: "changes, system: flags, expiry: forSeconds(60)", to: "changes, system: flags, expiry: forSeconds(600)" },
  { name: "Ancestral Awakening raises every spell's DC", file: A, from: "value: 1, type: \"untyped\", traits: [element] } }", to: "value: 1, type: \"untyped\" } }" },
  { name: "Ancestral Awakening gives no resistance", file: A, from: "changes: [{ key: \"system.combat.resistances\", mode: 2, value: `, ${element}`, priority: 20 }],", to: "changes: []," },
  { name: "Ancestral Awakening spends the core's default use as well", file: A, from: "  hint: \"0 AP (Concentrate, Focus): for 1 minute, resistance to an element and +1 to its spell save DCs.\",\n  ownsFocusUse: true,", to: "  hint: \"0 AP (Concentrate, Focus): for 1 minute, resistance to an element and +1 to its spell save DCs.\"," },
  // Claws of the Wyrm
  { name: "the claw ignores size", file: A, from: "export const clawFor = (size) => CLAW_BY_SIZE[norm(size)] ?? null;", to: "export const clawFor = (size) => CLAW_BY_SIZE.medium;" },
  { name: "the claw is not granted when the feat lands", file: A, from: "if (key === \"claws of the wyrm\") await grantClaws(actor, item, { quiet: true });", to: "if (key === \"claws of the wyrm\") void 0;" },
  { name: "a resize keeps the old claw", file: A, from: "  if (mine.length) await actor.deleteEmbeddedDocuments(\"Item\", mine.map((i) => i.id));\n", to: "" },
  { name: "the claw is not stamped as the feat's", file: A, from: "data.flags = { ...(data.flags ?? {}), [SYSTEM_ID]: { ...(data.flags?.[SYSTEM_ID] ?? {}), grantedBy: { sourceId: item.id, sourceName: item.name, requested: name } } };", to: "data.flags = { ...(data.flags ?? {}) };" },
  // Elemental Breath
  { name: "the breath is 1d6 per two levels", file: A, from: "export const breathDice = (level) => `${Math.max(1, int(level))}d6`;", to: "export const breathDice = (level) => `${Math.max(1, Math.floor(int(level) / 2))}d6`;" },
  { name: "Q77 undone: any heritage's element", file: A, from: "(i) => i?.type === \"heritage\" && norm(i.name) === \"wyrmdral\"", to: "(i) => i?.type === \"heritage\"" },
  { name: "the breath is a Fortitude save", file: A, from: "save: \"reflex\", basic: true, scope: \"targets\"", to: "save: \"fortitude\", basic: true, scope: \"targets\"" },
  { name: "the breath's save is not basic", file: A, from: "save: \"reflex\", basic: true, scope: \"targets\"", to: "save: \"reflex\", basic: false, scope: \"targets\"" },
  { name: "the breather breathes on itself", file: A, from: ".map((t) => t.actor).filter((a) => a && a !== actor);", to: ".map((t) => t.actor).filter((a) => a);" },
  { name: "the breath costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Elemental Breath\", 2))) return false;\n", to: "" },
  { name: "the breath spends no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    const dice = breathDice", to: "    const dice = breathDice" },
  { name: "Elemental Breath is not registered", file: A, from: "  \"Elemental Breath\": elementalBreath,\n", to: "" },
  // Runic Aptitude
  { name: "Q79 undone: the cantrip is innate", file: A, from: "return h().chooseSpell(actor, item, { ppCost: 0, note:", to: "return h().chooseSpell(actor, item, { ppCost: 0, innate: true, note:" },
  { name: "Runic Aptitude offers any spell", file: A, from: "return h().chooseSpell(actor, item, { ppCost: 0, note:", to: "return h().chooseSpell(actor, item, { note:" },
  // Wyrm Lore
  { name: "Wyrm Lore takes +1", file: A, from: "export const wyrmLoreChange = (key, value = 2)", to: "export const wyrmLoreChange = (key, value = 1)" },
  { name: "the first specialist skill is taken for Wyrm Lore", file: A, from: "if (norm(skill?.label) === wanted) return key;", to: "return key;" },
  { name: "a client that does not own the actor writes", file: A, from: "if (!actor?.isOwner || !actsFor(actor)) return;", to: "if (!actsFor(actor)) return;" },
  { name: "Wyrm’s Cunning puts nothing on Wyrm Lore", file: A, from: "else if (key === \"scaelyn scholar\" || key === \"wyrm’s cunning\") await giveWyrmLore(actor, item);", to: "else if (key === \"scaelyn scholar\") await giveWyrmLore(actor, item);" },
  // Ember Handed
  { name: "Ember Handed fires on any damage type", file: A, from: " && Array.from(ctx.damageTypes ?? []).map(norm).includes(\"fire\");", to: ";" },
  { name: "Ember Handed fires on no damage", file: A, from: "return Number(ctx.amount ?? 0) > 0 &&", to: "return Number(ctx.amount ?? 0) >= 0 &&" },
  { name: "Ember Handed stacks", file: A, from: "  if (stale.length) {\n    if (!actor.isOwner) return;\n    await actor.deleteEmbeddedDocuments(\"ActiveEffect\", stale.map((e) => e.id)).catch(() => {});\n  }\n", to: "" },
  { name: "Ember Handed's +1 is not one-shot", file: A, from: "auto: true, oneShot: true, when: { checkTypes: [\"attack\", \"skill\"] } };", to: "auto: true, when: { checkTypes: [\"attack\", \"skill\"] } };" },
  { name: "Ember Handed's +1 reaches saves", file: A, from: "checkTypes: [\"attack\", \"skill\"] } };", to: "checkTypes: [\"attack\", \"skill\", \"save\"] } };" },
  { name: "Ember Handed's +1 does not last to the end of the next turn", file: A, from: "    expiry: expiryFor(\"endOfNextTurn\", actor)\n", to: "    expiry: forSeconds(6)\n" },
  // Ghostscale
  { name: "Ghostscale breaks in any light", file: A, from: "return Number.isFinite(n) && n <= GHOSTSCALE_LIGHT.concealedAtOrBelow;", to: "return Number.isFinite(n);" },
  { name: "an attack does not break Ghostscale", file: A, from: "  await breakGhostscale(ctx.attacker, \"attack\");\n", to: "" },
  { name: "a cast does not break Ghostscale", file: A, from: "  await breakGhostscale(ctx.actor, \"cast a spell\");\n", to: "" },
  { name: "Ghostscale returns at once out of combat", file: A, from: "return Number(worldTime) >= Number(record.at ?? 0) + GHOSTSCALE_SECONDS;", to: "return true;" },
  { name: "Ghostscale returns by the clock in combat", file: A, from: "if (!record || inCombat) return false;", to: "if (!record) return false;" },
  { name: "Ghostscale returns at anyone's turn", file: A, from: "  if (next) await restoreGhostscale(ghostscale(next));", to: "  for (const a of allActors()) await restoreGhostscale(ghostscale(a));" },
  { name: "any client restores Ghostscale at a turn", file: A, from: "  if (!isActingGM()) return;\n  const next =", to: "  const next =" },
  { name: "daily preparation leaves Ghostscale broken", file: A, from: "  if (!actor?.isOwner) return;\n  await restoreGhostscale(ghostscale(actor));", to: "  if (!actor?.isOwner) return;" },
  { name: "Ghostscale returns at the wrong light", file: A, from: "[`flags.${SYSTEM_ID}.creatureAbility.derives.light`]: { ...GHOSTSCALE_LIGHT } });", to: "[`flags.${SYSTEM_ID}.creatureAbility.derives.light`]: { concealedAtOrBelow: 6 } });" },
  // Glyph Unleashed
  { name: "the ward gives +1", file: A, from: "export const GLYPH_BONUS = 2;", to: "export const GLYPH_BONUS = 1;" },
  { name: "the ward's save bonus is circumstance", file: A, from: "[{ label: \"Glyph Unleashed\", value: GLYPH_BONUS, type: \"race\" }]", to: "[{ label: \"Glyph Unleashed\", value: GLYPH_BONUS, type: \"circumstance\" }]" },
  { name: "Q80 undone: area spells are excluded", file: A, from: "    if (ctx.type !== \"save\") return null;\n    const actor = ctx.actor;", to: "    if (ctx.type !== \"save\" || ctx.isArea) return null;\n    const actor = ctx.actor;" },
  { name: "the ward answers any caster", file: A, from: "norm(ward.spellName) === norm(spellName) && String(ward.sourceUuid ?? \"\") === String(sourceUuid ?? \"\")", to: "norm(ward.spellName) === norm(spellName)" },
  { name: "the ward is asked again for the same spell", file: A, from: "    if (wardUp(actor, spellName, sourceUuid)) {", to: "    if (false) {" },
  { name: "any save is taken for a spell's", file: A, from: "    if (!(await namesASpell(spellName, sourceUuid))) return null;\n", to: "" },
  { name: "a spell the caster does not hold is not recognised", file: A, from: "  return (await spellIndex()).some((e) => norm(e.name) === wanted);", to: "  return false;" },
  { name: "the ward spends no use", file: A, from: "  if (!(await spendUse(item))) return false;\n  const expiry = expiryFor(\"startOfNextTurn\", actor);", to: "  const expiry = expiryFor(\"startOfNextTurn\", actor);" },
  { name: "the ward spends no reaction", file: A, from: "  if (combatFor(actor) && !(await h().spendReaction(actor, \"Glyph Unleashed\", { traits: GLYPH_TRAITS }))) return false;\n", to: "" },
  { name: "the ward spends a reaction out of combat", file: A, from: "  if (combatFor(actor) && !(await h().spendReaction(", to: "  if (!(await h().spendReaction(" },
  { name: "the ward is asked with no reaction left", file: A, from: "  if (combatFor(actor)) return String((await h().reactionRefusal?.(actor, GLYPH_TRAITS)) ?? \"\");\n", to: "" },
  { name: "the ward outlasts the next turn's start", file: A, from: "  const expiry = expiryFor(\"startOfNextTurn\", actor);\n  const what", to: "  const expiry = forSeconds(60);\n  const what" },
  { name: "the ward's DB is not one attack", file: A, from: "changes: db.changes, system: { oneAttack: db.oneAttack }, expiry", to: "changes: db.changes, expiry" },
  { name: "the ward's DB is spent by a sword", file: A, from: "oneAttack: uuid ? { against: \"spell\", fromUuids: [uuid] } : { against: \"spell\" }", to: "oneAttack: true" },
  { name: "the ward's DB is a dodge bonus", file: A, from: "{ key: \"system.combat.defence.racial\", mode: 0", to: "{ key: \"system.combat.defence.dodge\", mode: 0" },
  { name: "C3 undone: the offer answers any attack", file: A, from: "  against: \"spell\",\n  find:", to: "  against: \"attack\",\n  find:" },
  { name: "the offer is open with the use spent", file: A, from: "requires: (actor, item) => (usesLeft(item) <= 0 ? \"its Focus use is spent — Refocus restores it\" : null),", to: "requires: () => null," },
  { name: "the offer lays no DB", file: A, from: "sourceUuid: String(attack?.attackerUuid ?? \"\"), attack: true })", to: "sourceUuid: String(attack?.attackerUuid ?? \"\"), attack: false })" },
  // D — registration
  { name: "Scaled Focus grants 2 PP a level", file: A, from: "api.registerPPGrant?.(\"Scaled Focus\", { perLevel: 1,", to: "api.registerPPGrant?.(\"Scaled Focus\", { perLevel: 2," },
  { name: "the check reaction is not registered", file: A, from: "  api.registerCheckReaction?.(\"glyphUnleashed\", glyphCheckReaction, moduleId);\n", to: "" },
  { name: "the defence offer is not registered", file: A, from: "  api.registerDefenceOffer?.(\"Glyph Unleashed\", glyphDefenceOffer, moduleId);\n", to: "" },
  { name: "the ward's step is not registered", file: A, from: "  api.registerReactionStep?.(GLYPH_STEP, glyphStep, moduleId);\n", to: "" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block5c.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block5c: verify-block5c already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block5c: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block5c: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
