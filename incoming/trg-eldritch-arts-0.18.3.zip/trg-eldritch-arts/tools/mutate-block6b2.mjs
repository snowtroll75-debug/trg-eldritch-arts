#!/usr/bin/env node
/**
 * mutate-block6b2 — the mutation half of verify-block6b2. Each mutation breaks
 * one printed number, one reading or one wire of Block 6's group B2;
 * verify-block6b2 must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6b2.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block6-b2.mjs"), A = f("module", "block6b2-automations.mjs"), S = f("tools", "content", "block3-spells.mjs");

const MUTATIONS = [
  { name: "Wellspring's card drops the 4 Nov 2026 ruling", file: C, from: "as Q101 reads them (Graham's ruling, 4 November 2026)", to: "as Q101 reads them" },
  { name: "the docs grade Wellspring C again", file: C, from: "\"Wellspring Conduit\": { level: \"B\",", to: "\"Wellspring Conduit\": { level: \"C\"," },
  { name: "Wellspring reads the printed PP again", file: A, from: "export const wellspringPP = (ctx = {}) => (ctx.castPP === undefined || ctx.castPP === null ? int(ctx.basePP) : int(ctx.castPP));", to: "export const wellspringPP = (ctx = {}) => int(ctx.basePP);" },
  { name: "Wellspring without castPP gives nothing", file: A, from: "export const wellspringPP = (ctx = {}) => (ctx.castPP === undefined || ctx.castPP === null ? int(ctx.basePP) : int(ctx.castPP));", to: "export const wellspringPP = (ctx = {}) => int(ctx.castPP);" },
  { name: "Wellspring's offer reads the base only", file: A, from: "reservoirCharges(ctx.actor) === 0 && Boolean(wellspringAnswer({ basePP: wellspringPP(ctx),", to: "reservoirCharges(ctx.actor) === 0 && Boolean(wellspringAnswer({ basePP: ctx.basePP," },
  // The content
  { name: "Q91 undone: Runebreaker progresses freely", file: C, from: "archetypeFeat(\"RUNEBREAKER\", {\n    progression: NO_LATER_ARCHETYPE,", to: "archetypeFeat(\"RUNEBREAKER\", {" },
  { name: "Q91 undone: Stormcaller progresses freely", file: C, from: "archetypeFeat(\"STORMCALLER\", {\n    progression: NO_LATER_ARCHETYPE,", to: "archetypeFeat(\"STORMCALLER\", {" },
  { name: "the stored line misreads \"cannot progress\"", file: C, from: "export const NO_LATER_ARCHETYPE = \"cannot progress\";", to: "export const NO_LATER_ARCHETYPE = \"no progression\";" },
  { name: "Q90 undone: Spell Duellist does not opt in", file: C, from: "      progressionSinceTaken: true,\n", to: "" },
  { name: "Shade Master grants no Fade Step", file: C, from: "    grantedAbilities: ABILITY_NAMES.fadeStep,\n    grantedSpells: \"Dark Whispers\",", to: "    grantedSpells: \"Dark Whispers\"," },
  { name: "Shade Master grants no Dark Whispers", file: C, from: "    grantedSpells: \"Dark Whispers\",\n", to: "" },
  { name: "Spellwarden grants no Counter Channel", file: C, from: "    grantedAbilities: ABILITY_NAMES.counterChannel,\n", to: "" },
  { name: "Stormcaller grants no burst", file: C, from: "    grantedSpells: STORM_BURST,\n", to: "" },
  { name: "Spell Duellist's +2 on another action", file: C, from: "when: { actions: [\"spellRecognition\"] } })]", to: "when: { actions: [\"recallKnowledge\"] } })]" },
  { name: "Spell Duellist's bonus is +1", file: C, from: "conditional({ kind: \"modifier\", value: 2, type: \"class\", label: \"Spell Duellist\"", to: "conditional({ kind: \"modifier\", value: 1, type: \"class\", label: \"Spell Duellist\"" },
  { name: "Spellwarden's other-magic tick is automatic", file: C, from: "do not tick it then)\", auto: false,", to: "do not tick it then)\", auto: true," },
  { name: "Shadowmantle's DB in Twilight", file: C, from: "export const DIM_OR_LESS = Object.freeze({ max: 5 });", to: "export const DIM_OR_LESS = Object.freeze({ max: 6 });" },
  { name: "Shadowmantle's DB against every attack", file: C, from: "when: { attackKinds: [\"spell\"], lightLevels: { ...DIM_OR_LESS } }", to: "when: { lightLevels: { ...DIM_OR_LESS } }" },
  { name: "Shadowmantle's DB is +2", file: C, from: "defenceDC: [{ dc: \"defence\", value: 1, type: \"circumstance\", label: \"Shadowmantle\"", to: "defenceDC: [{ dc: \"defence\", value: 2, type: \"circumstance\", label: \"Shadowmantle\"" },
  { name: "the Reservoir counts Wisdom", file: C, from: "    usesPerDay: \"intelligence\",", to: "    usesPerDay: \"wisdom\"," },
  { name: "the abilities file as racial", file: C, from: "  item.system.category = \"Archetype\";\n  return item;\n}\n\nexport const FADE_STEP", to: "  return item;\n}\n\nexport const FADE_STEP" },
  { name: "the burst is cast at 1 PP", file: C, from: "category: \"save\", ppCost: 3, area: \"10-foot radius\"", to: "category: \"save\", ppCost: 1, area: \"10-foot radius\"" },
  { name: "the burst keeps the attack", file: C, from: "category: \"save\", ppCost: 3,", to: "category: \"attack\", ppCost: 3," },
  { name: "the burst is 20 ft", file: C, from: "area: \"10-foot radius\", targets: \"\", defence: \"basic Reflex\"", to: "area: \"20-foot radius\", targets: \"\", defence: \"basic Reflex\"" },
  { name: "the burst is not marked a variant", file: C, from: "eaVariantOf: \"Storm Bolt\", eaBlock: 6", to: "eaBlock: 6" },
  { name: "Eye of the Storm is not once a day", file: C, from: "  classFeat(\"EYE OF THE STORM\", {\n    usesPerDay: \"1\",", to: "  classFeat(\"EYE OF THE STORM\", {" },
  { name: "Absolute Denial claims full automation", file: C, from: "automation: \"*Partly automated (0.9.0, TRG Prime 3.684.0):* while you are conscious", to: "automation: \"*Fully automated:* while you are conscious" },
  { name: "the docs grade Shadowmantle D", file: C, from: "\"Shadowmantle\": { level: \"A\",", to: "\"Shadowmantle\": { level: \"D\"," },
  { name: "Q115 uncited", file: C, from: "The absorb (G16, Q115):", to: "The absorb (G16):" },
  // Storing Rune's one line (G16)
  { name: "G16 undone: Storing Rune names no host", file: S, from: "target: \"self\", host: \"spell\" }],", to: "target: \"self\" }]," },
  // The rules
  { name: "Q61 undone: shadow at light 6", file: A, from: "export const SHADOW_LIGHT_MAX = 5;", to: "export const SHADOW_LIGHT_MAX = 6;" },
  { name: "unknown light read as shadow", file: A, from: "export const inShadow = (level) => level !== null && level !== undefined &&", to: "export const inShadow = (level) => level === null || level === undefined ||" },
  { name: "1d6 per PP", file: A, from: "  const n = Math.floor(Math.max(0, int(pp)) / 2);", to: "  const n = Math.floor(Math.max(0, int(pp)));" },
  { name: "Fade Step reaches 40 ft", file: A, from: "export const FADE_FEET = 30;", to: "export const FADE_FEET = 40;" },
  { name: "Eclipse Step reaches 60 ft", file: A, from: "export const ECLIPSE_FEET = 120;", to: "export const ECLIPSE_FEET = 60;" },
  { name: "Fade Step's origin is not checked", file: A, from: "    if (origin !== null && !inShadow(origin)) return warn(", to: "    if (false) return warn(" },
  { name: "Fade Step's landing is not checked", file: A, from: "    if (landing !== null && !inShadow(landing)) {", to: "    if (false) {" },
  { name: "Fade Step costs no AP", file: A, from: "    if (mode.ap > 0 && !(await spendAP(actor, \"Fade Step\", mode.ap))) return false;\n", to: "" },
  { name: "Eclipse Step's free use is not marked", file: A, from: "    if (mode.key === \"free\") await setMark(eclipse, ECLIPSE_FREE_FLAG, thisRound());\n", to: "" },
  { name: "Eclipse Step's free use any number a round", file: A, from: "  if (eclipse && fighting && !freeUsedThisRound) out.push(", to: "  if (eclipse && fighting) out.push(" },
  { name: "Eclipse Step's 120 ft every time", file: A, from: "  if (eclipse && !longUsedToday) out.push(", to: "  if (eclipse) out.push(" },
  { name: "Eclipse Step leaves no Concealed", file: A, from: "      await conditionToNextTurn(actor, \"concealed\", \"Concealed\");\n", to: "" },
  { name: "Shadowmantle's Hidden every time", file: A, from: "    if (mantle && !markFlag(mantle, MANTLE_DAY_FLAG) && await confirm(", to: "    if (mantle && await confirm(" },
  { name: "the day's marks never clear", file: A, from: "  if (eclipse && markFlag(eclipse, ECLIPSE_DAY_FLAG)) await eclipse.unsetFlag(MODULE_ID, ECLIPSE_DAY_FLAG);\n", to: "" },
  { name: "Grasping Shadows reaches 20 ft", file: A, from: "export const GRASP_FEET = 10;", to: "export const GRASP_FEET = 20;" },
  { name: "Grasping Shadows costs no PP", file: A, from: "  if (!(await spendPP(actor, GRASP_PP, \"Grasping Shadows\"))) return false;\n", to: "" },
  { name: "Grasping Shadows' Success immobilises", file: A, from: "  const slowed = [{ key: \"slowed\", value: 1, rounds: 1 }];", to: "  const slowed = [{ key: \"immobilised\", rounds: 1 }];" },
  { name: "m42 undone: a Partial only slows", file: A, from: "conditions: { heroic: [], critical: [], success: slowed, partial: held,", to: "conditions: { heroic: [], critical: [], success: slowed, partial: slowed," },
  { name: "Grasping Shadows' Blunder tears no flesh", file: A, from: "  if (FUMBLE_DOWN.includes(degree)) {\n    const dice = graspingTear(levelOf(actor));", to: "  if (false) {\n    const dice = graspingTear(levelOf(actor));" },
  { name: "Grasping Shadows not asked after a Shadow spell", file: A, from: "await offerGraspingShadows(actor, tokenOf(actor), ctx.spell?.name ?? \"A Shadow spell\");", to: "void 0;" },
  { name: "Stormcaller's Gale Step costs 1 AP", file: A, from: "export const galeStepAP = (actor) => (has(actor, \"Stormcaller\") ? 0 : 1);", to: "export const galeStepAP = (actor) => 1;" },
  { name: "Gale Step is free for everyone", file: A, from: "export const galeStepAP = (actor) => (has(actor, \"Stormcaller\") ? 0 : 1);", to: "export const galeStepAP = (actor) => 0;" },
  { name: "Q115 undone: Runebreaker absorbs any targeted spell", file: A, from: "  return list.length === 1 && list[0] === reactor;", to: "  return list.includes(reactor);" },
  { name: "Runebreaker absorbs an area", file: A, from: "  if (String(spellData?.area ?? \"\").trim()) return false;\n", to: "" },
  { name: "Runebreaker's absorb costs no PP", file: A, from: "  await spendPP(actor, int(rune.system?.ppCost), \"Storing Rune\");\n", to: "" },
  { name: "the absorb spends the reaction before checking the PP", file: A, from: "  if (ppOf(actor) < int(rune.system?.ppCost) || await reactionBlocked(actor, \"\")) return { rolled: false };\n", to: "" },
  { name: "innate casts read at 0 PP again", file: A, from: "export const castPPOf = (ctx = {}) => (ctx.castPP === undefined || ctx.castPP === null ? int(ctx.pp) : int(ctx.castPP));", to: "export const castPPOf = (ctx = {}) => int(ctx.pp);" },
  { name: "Counter Channel ignores the innate save DC", file: A, from: "    const innateDC = ctx.innate && hasSave ? int((await h().innateSaveDCFor?.(caster, ctx.spell))?.value) : 0;", to: "    const innateDC = 0;" },
  { name: "the absorbed spell stored at pp, not castPP", file: A, from: "pp: castPPOf(ctx), dc: spellDCOf(caster), casterUuid", to: "pp: int(ctx.pp), dc: spellDCOf(caster), casterUuid" },
  { name: "Soul Drain written as a total", file: A, from: "value: OVERFLOW_SOUL_DRAIN }], {});", to: "value: int(actor.getConditionValue?.(\"soulDrain\")) + OVERFLOW_SOUL_DRAIN }], {});" },
  { name: "any labelled save counts as a spell's", file: A, from: "  return isSpellOf(actorOf(await fromUuid(ctx.sourceUuid)), ctx.saveSource);", to: "  return true;" },
  { name: "the riposte spends before a refused Strike", file: A, from: "  if (!made) {\n    if (marked)", to: "  if (false) {\n    if (marked)" },
  { name: "Q116 undone: Overload leaves the Save DC", file: A, from: "apply: () => ({ label: \"Runic Overload\", saveDC: OVERLOAD_PP, castingDC:", to: "apply: () => ({ label: \"Runic Overload\", castingDC:" },
  { name: "Runebreaker's save is Fortitude", file: A, from: "type: \"save\", subject: \"will\", label: `Runebreaker", to: "type: \"save\", subject: \"fortitude\", label: `Runebreaker" },
  { name: "Runebreaker absorbs on a failure", file: A, from: "  if (succeeded(degree)) {\n    const spell = await fromUuid(data.spellUuid);", to: "  if (true) {\n    const spell = await fromUuid(data.spellUuid);" },
  { name: "the absorbed spell stored at no PP", file: A, from: "{ ppPaid: int(data.pp), mods: {}, host: rune,", to: "{ ppPaid: 0, mods: {}, host: rune," },
  { name: "the absorbed spell stored in the bond", file: A, from: "{ ppPaid: int(data.pp), mods: {}, host: rune,", to: "{ ppPaid: int(data.pp), mods: {}, host: null," },
  { name: "Rune Rend costs no PP", file: A, from: "  if (!(await spendPP(actor, REND_PP, \"Rune Rend\"))) return;\n", to: "" },
  { name: "Rune Rend's save is Reflex", file: A, from: "runAreaEffect(actor, { save: \"will\", basic: true, dc: spellDCOf(actor), damage: { formula: dice, type: \"force\" }, scope: \"targets\" }, { title: \"Rune Rend\"", to: "runAreaEffect(actor, { save: \"reflex\", basic: true, dc: spellDCOf(actor), damage: { formula: dice, type: \"force\" }, scope: \"targets\" }, { title: \"Rune Rend\"" },
  { name: "Q119 undone: Denial stops 10 PP", file: A, from: "export const DENIAL_MAX_PP = 8;", to: "export const DENIAL_MAX_PP = 10;" },
  { name: "Denial reaches 30 ft", file: A, from: "export const DENIAL_FEET = 20;", to: "export const DENIAL_FEET = 30;" },
  { name: "Denial stops allies' spells", file: A, from: "  if (!enemy || !conscious || suppressed) return false;", to: "  if (!conscious || suppressed) return false;" },
  { name: "Denial while unconscious", file: A, from: "conscious: !owner.actor.hasCondition?.(\"unconscious\") && !(await h().isDead?.(owner.actor)),", to: "conscious: true," },
  { name: "Denial ignores a target inside", file: A, from: "  return inside(casterFeet) || Array.from(targetFeet ?? []).some(inside);", to: "  return inside(casterFeet);" },
  { name: "Denial's suppression is not read", file: A, from: "      suppressed: Boolean(feat.getFlag?.(MODULE_ID, DENIAL_SUPPRESSED_FLAG)),", to: "      suppressed: false," },
  { name: "Counter Channel reaches 60 ft without Improved", file: A, from: "export const CC_FEET = 30;", to: "export const CC_FEET = 60;" },
  { name: "Improved Counter Channel reaches 30", file: A, from: "export const CC_IMPROVED_FEET = 60;", to: "export const CC_IMPROVED_FEET = 30;" },
  { name: "Counter Channel's Success doubles", file: A, from: "  if (d === \"success\") return { scale: 0.5, saveBias: \"advantage\" };", to: "  if (d === \"success\") return { scale: 2, saveBias: \"advantage\" };" },
  { name: "Counter Channel's Fumble does nothing", file: A, from: "  if (FUMBLE_DOWN.includes(d)) return { scale: 2, saveBias: \"disadvantage\" };", to: "" },
  { name: "Reflective Warding never redirects", file: A, from: "  if (CRITICAL_UP.includes(d)) return reflect ? { retargetCaster: true } : { stop: true };", to: "  if (CRITICAL_UP.includes(d)) return { stop: true };" },
  { name: "Counter Channel's DC forgets the PP", file: A, from: "  return hasSave ? 10 + Math.max(0, int(pp)) + int(castingAbility) : int(spellDC);", to: "  return hasSave ? 10 + int(castingAbility) : int(spellDC);" },
  { name: "Counter Channel's check is Arcana", file: A, from: "subject: \"powerManipulation\", label: `Counter Channel", to: "subject: \"arcana\", label: `Counter Channel" },
  { name: "Counter Channel costs no PP", file: A, from: "  await spendPP(actor, CC_PP, \"Counter Channel\");\n", to: "" },
  { name: "Counter Channel spends no Focus use", file: A, from: "  await spendUse(item);\n  await spendPP(actor, CC_PP, \"Counter Channel\");", to: "  await spendPP(actor, CC_PP, \"Counter Channel\");" },
  { name: "Counter Channel asks for allies' spells", file: A, from: "    if (allies(side(reactorToken), side(casterToken)) && !cc.getFlag?.(MODULE_ID, CC_ALLIES_FLAG)) continue;\n", to: "" },
  { name: "Instinctive Counter Channel is not once a round", file: A, from: "  if (data.instinctive) await setMark(item, \"instinctiveRound\", thisRound());", to: "  if (data.instinctive) void 0;" },
  { name: "Instinctive still spends the reaction", file: A, from: "    if (!instinctive && await reactionBlocked(reactor, cc.system?.traits ?? \"\")) continue;", to: "    if (await reactionBlocked(reactor, cc.system?.traits ?? \"\")) continue;" },
  { name: "Spellwarden's bonus is +1", file: A, from: "export const SPELLWARDEN_BONUS = 2;", to: "export const SPELLWARDEN_BONUS = 1;" },
  { name: "Spellwarden's bonus is circumstance", file: A, from: "value: SPELLWARDEN_BONUS, type: \"class\" }", to: "value: SPELLWARDEN_BONUS, type: \"circumstance\" }" },
  { name: "Shadowmantle's save bonus in any light", file: A, from: "if (has(actor, \"Shadowmantle\") && inShadow(await lightAt(ctx.token)))", to: "if (has(actor, \"Shadowmantle\"))" },
  { name: "a save no spell forced is warded", file: A, from: "export const spellForcedSave = (ctx = {}, self = []) => ctx.type === \"save\" && Boolean(String(ctx.saveSource ?? \"\").trim()) &&", to: "export const spellForcedSave = (ctx = {}, self = []) => ctx.type === \"save\" &&" },
  { name: "Deep Weave on any success", file: A, from: "    if (!CRITICAL_UP.includes(String(ctx.degree)) || !(await spellSourced(", to: "    if (!DEGREES_UP.includes(String(ctx.degree)) || !(await spellSourced(" },
  { name: "Deep Weave every time a round", file: A, from: "  if (markFlag(dw, \"regainRound\") === thisRound()) return false;\n", to: "" },
  { name: "Deep Weave above the maximum", file: A, from: "  if (!Number.isFinite(max) || left >= max) return false;", to: "  if (!Number.isFinite(max)) return false;" },
  { name: "Deep Weave not on a critical spell attack", file: A, from: "  if ((ctx.spellHits ?? []).some((x) => x?.critical)) await regainCharge(actor, \"a critical spell attack\");\n", to: "" },
  { name: "the riposte answers a ranged miss", file: A, from: "  if (!ctx.melee || !ctx.missed || ctx.noReactions", to: "  if (!ctx.missed || ctx.noReactions" },
  { name: "the riposte ignores noReactions", file: A, from: "  if (!ctx.melee || !ctx.missed || ctx.noReactions || ctx.held", to: "  if (!ctx.melee || !ctx.missed || ctx.held" },
  { name: "the riposte keeps the MAP", file: A, from: "skipTargetPrompt: true, mapOverride: 0, mapFrozen: true, optionLabel: \"Spellstrike Riposte\"", to: "skipTargetPrompt: true, optionLabel: \"Spellstrike Riposte\"" },
  { name: "the riposte's cantrip is lost", file: A, from: "extraTypedDamage: cantrip ? [{ dice: cantrip.dice, type: cantrip.type, label: `${cantrip.name} (channelled)` }] : [],", to: "extraTypedDamage: []," },
  { name: "the riposte always costs PP", file: A, from: "export const ripostePP = ({ supremacy = false, freeUsedThisRound = false } = {}) => (supremacy && !freeUsedThisRound ? 0 : RIPOSTE_PP);", to: "export const ripostePP = () => RIPOSTE_PP;" },
  { name: "Supremacy's free riposte every time", file: A, from: "  if (sup && !pp) await setMark(sup, \"freeRound\", thisRound());\n", to: "" },
  { name: "the riposte spends no Focus use", file: A, from: "  if (pp) await spendPP(actor, pp, \"Spellstrike Riposte\");\n  await spendUse(item);", to: "  if (pp) await spendPP(actor, pp, \"Spellstrike Riposte\");" },
  { name: "Duellist's Focus +2 always", file: A, from: "export const DUELLIST_FOCUS = Object.freeze({ strike: 1, spell: 2 });", to: "export const DUELLIST_FOCUS = Object.freeze({ strike: 2, spell: 2 });" },
  { name: "Supremacy's advantage on anyone", file: A, from: "  const marked = sup && isMarkOf(attacker, actor);", to: "  const marked = Boolean(sup);" },
  { name: "the Mark read for any creature", file: A, from: "&& String(e.flags?.[MODULE_ID]?.markUuid ?? \"\") === uuid);", to: ");" },
  { name: "Rippling Counter on any hit", file: A, from: "  if (outcome?.hits && outcome?.critical && has(actor, \"Rippling Counter\"))", to: "  if (outcome?.hits && has(actor, \"Rippling Counter\"))" },
  { name: "Rippling Counter arms no Step", file: A, from: "  await h().armMove(actor, { maxFeet: 5, speedKey: \"land\", provokes: false, note: \"Rippling Counter: a Step\" }, \"Rippling Counter\");\n", to: "" },
  { name: "a ranged spell attack is riposted", file: A, from: "    if (!spell || !touchRange(spell.system?.range)) return null;", to: "    if (!spell) return null;" },
  { name: "Runebreaker's Dispel −1", file: A, from: "export const DISPEL_REDUCTION = 2;", to: "export const DISPEL_REDUCTION = 1;" },
  { name: "Runebreaker's discount for anyone", file: A, from: "  offer: (ctx = {}) => (has(ctx.actor, \"Runebreaker\") ? {", to: "  offer: (ctx = {}) => (true ? {" },
  { name: "Glyph Shatter on a failed Dispel", file: A, from: "    const won = ctx.counterSpell ? Boolean(ctx.countered) : succeeded(ctx.degree);", to: "    const won = true;" },
  { name: "Glyph Shatter reaches 20 ft", file: A, from: "export const GLYPH_FEET = 10;", to: "export const GLYPH_FEET = 20;" },
  { name: "Glyph Shatter's save is Will", file: A, from: "runAreaEffect(actor, { save: \"reflex\", basic: true, dc: spellDCOf(actor), damage: { formula: dice, type: \"force\" }, scope: \"targets\" }, { title: \"Glyph Shatter\"", to: "runAreaEffect(actor, { save: \"will\", basic: true, dc: spellDCOf(actor), damage: { formula: dice, type: \"force\" }, scope: \"targets\" }, { title: \"Glyph Shatter\"" },
  { name: "Glyph Shatter's bonus is never spent", file: A, from: "    if (glyphBonusPending.delete(key)) await actor.unsetFlag?.(MODULE_ID, GLYPH_BONUS_FLAG);\n", to: "" },
  { name: "Glyph Shatter's bonus lasts 10 minutes", file: A, from: "export const GLYPH_SECONDS = 60;", to: "export const GLYPH_SECONDS = 600;" },
  { name: "Glyph Shatter's bonus is status", file: A, from: "value: GLYPH_BONUS, type: \"circumstance\" }] } : {})", to: "value: GLYPH_BONUS, type: \"status\" }] } : {})" },
  { name: "Spell Weaver's discount is 1", file: A, from: "export const RESERVOIR_DISCOUNT = 2;", to: "export const RESERVOIR_DISCOUNT = 1;" },
  { name: "Q93 undone: the discount floors at 1", file: A, from: "discount: { pp: RESERVOIR_DISCOUNT, floor: 0, label: \"Magical Reservoir\" }", to: "discount: { pp: RESERVOIR_DISCOUNT, floor: 1, label: \"Magical Reservoir\" }" },
  { name: "Spell Weaver's ×2", file: A, from: "export const RESERVOIR_FACTOR = 1.5;", to: "export const RESERVOIR_FACTOR = 2;" },
  { name: "Spell Weaver's options stack in one cast", file: A, from: "  [MM.discount]: { feat: \"Spell Weaver\", label: \"Magical Reservoir: −2 PP\", hint: \"1 charge: 2 PP less to pay (min 0); the DC reads the PP as cast (Q93).\", group: WEAVER_GROUP,", to: "  [MM.discount]: { feat: \"Spell Weaver\", label: \"Magical Reservoir: −2 PP\", hint: \"1 charge: 2 PP less to pay (min 0); the DC reads the PP as cast (Q93).\"," },
  { name: "Wellspring is not Focus", file: A, from: "hint: \"Reservoir empty: +1d6 per 2 PP (damage or healing).\", focus: true,", to: "hint: \"Reservoir empty: +1d6 per 2 PP (damage or healing).\"," },
  { name: "Wellspring with charges left", file: A, from: "Boolean(reservoirOf(ctx.actor)) && reservoirCharges(ctx.actor) === 0 &&", to: "Boolean(reservoirOf(ctx.actor)) &&" },
  { name: "Overflow costs 1d6 a charge", file: A, from: "export const OVERFLOW_DICE_PER_CHARGE = 2;", to: "export const OVERFLOW_DICE_PER_CHARGE = 1;" },
  { name: "Overflow respects resistances", file: A, from: "type: \"untyped\", ignoreDefences: true, sourceName: \"Overflow Casting\"", to: "type: \"untyped\", sourceName: \"Overflow Casting\"" },
  { name: "Overflow's Soul Drain is 3", file: A, from: "export const OVERFLOW_SOUL_DRAIN = 5;", to: "export const OVERFLOW_SOUL_DRAIN = 3;" },
  { name: "Overflow open without its Focus use", file: A, from: "const overflowReady = (actor) => { const o = ownedNamed(actor, \"Overflow Casting\"); return Boolean(o) && usesLeft(o) > 0; };", to: "const overflowReady = (actor) => Boolean(ownedNamed(actor, \"Overflow Casting\"));" },
  { name: "the Reservoir's minimum 1 lost", file: A, from: "export const reservoirFloorBonus = (intelligence) => (int(intelligence) >= 1 ? 0 : 1);", to: "export const reservoirFloorBonus = () => 0;" },
  { name: "Stormcaller's discount is 2", file: A, from: "export const STORM_DISCOUNT = 1;", to: "export const STORM_DISCOUNT = 2;" },
  { name: "Stormcaller's discount on an item's cast", file: A, from: "export const stormDiscountApplies = (ctx = {}) => !ctx.itemCast && (", to: "export const stormDiscountApplies = (ctx = {}) => (" },
  { name: "Stormcaller's discount on the burst lost", file: A, from: " || norm(ctx.spell?.flags?.[SYSTEM_ID]?.eaVariantOf) === norm(NAMES.stormBolt));", to: ");" },
  { name: "Shade Master's warp costs 5", file: A, from: "export const SHADE_HIDDEN_PP = 3;", to: "export const SHADE_HIDDEN_PP = 5;" },
  { name: "Shade Master's warp lays nothing", file: A, from: "  if (unlocks.includes(SHADE_UNLOCK) && has(actor, \"Shade Master\")) {", to: "  if (false) {" },
  { name: "Dark Whispers in any light", file: A, from: "  return level !== null && !inShadow(level) ? `Shade Master:", to: "  return false ? `Shade Master:" },
  { name: "every Dark Whispers is light-gated", file: A, from: "  if (norm(spell?.flags?.[SYSTEM_ID]?.grantedBy?.sourceName) !== \"shade master\") return null;\n  const level", to: "  const level" },
  { name: "Dark Whispers not made specialist", file: A, from: "&& !item.system?.specialist) await item.update({ \"system.specialist\": true });", to: "&& false) await item.update({ \"system.specialist\": true });" },
  { name: "Q116 undone: Overload adds no PP", file: A, from: "export const OVERLOAD_PP = 2;", to: "export const OVERLOAD_PP = 0;" },
  { name: "Overload offered on any cast", file: A, from: "    if (!ctx.stored) return null;\n    const feat = ownedNamed(ctx.actor, \"Runic Overload\");", to: "    const feat = ownedNamed(ctx.actor, \"Runic Overload\");" },
  { name: "Overload's backlash is lost", file: A, from: "    if (dice) lines.push(...(await h().runAreaEffect(actor, { save: \"fortitude\", basic: true, dc, damage: { formula: dice, type: \"force\" }, scope: \"targets\" }, { title: \"Runic Overload — backlash\", targets: [actor] }) ?? []));\n", to: "" },
  { name: "Overload spends no Focus", file: A, from: "    if (feat) await spendUse(feat);\n    const dice = perTwoPP", to: "    const dice = perTwoPP" },
  { name: "Overload misses the savers", file: A, from: "  for (const r of ctx.saveResults ?? []) if (r?.target && !out.includes(r.target)) out.push(r.target);\n", to: "" },
  { name: "Eye of the Storm reaches 20 ft", file: A, from: "export const EYE_FEET = 30;", to: "export const EYE_FEET = 20;" },
  { name: "Eye of the Storm pulses twice", file: A, from: "export const EYE_PULSES = 3;", to: "export const EYE_PULSES = 2;" },
  { name: "Eye of the Storm hits allies", file: A, from: "scope: \"area\", radiusFeet: EYE_FEET, enemiesOnly: true }", to: "scope: \"area\", radiusFeet: EYE_FEET }" },
  { name: "Eye of the Storm gives no immunity", file: A, from: "      changes: [{ key: \"system.combat.immunities\", mode: 2, value: \", electricity\", priority: 20 }],\n", to: "" },
  { name: "Eye of the Storm spends no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    await h().createEffectsOn(actor, [effectData(EYE_SOURCE", to: "    await h().createEffectsOn(actor, [effectData(EYE_SOURCE" },
  // Registration
  { name: "the birthright gates are not registered", file: A, from: "  for (const [name, bright] of [[\"Runebreaker\", \"Rune\"], [\"Shade Master\", \"Umbral\"], [\"Stormcaller\", \"Storm\"]]) api.registerFeatEligibility?.(name, birthrightGate(bright), moduleId);\n", to: "" },
  { name: "Extra Reservoir gives 1", file: A, from: "  api.registerExtraUses?.(\"Extra Reservoir\", { ability: NAMES.reservoir, perCopy: 2 }, moduleId);", to: "  api.registerExtraUses?.(\"Extra Reservoir\", { ability: NAMES.reservoir, perCopy: 1 }, moduleId);" },
  { name: "Deep Weave's use not registered", file: A, from: "  api.registerExtraUses?.(\"Deep Weave\", { ability: NAMES.reservoir, perCopy: 1 }, moduleId);\n", to: "" },
  { name: "Absolute Denial asked last", file: A, from: "  api.registerCastReaction?.(\"eaAbsoluteDenial\", absoluteDenial, moduleId);\n  api.registerCastReaction?.(\"eaRunebreakerAbsorb\", runebreakerAbsorb, moduleId);\n  api.registerCastReaction?.(\"eaCounterChannel\", counterChannel, moduleId);", to: "  api.registerCastReaction?.(\"eaRunebreakerAbsorb\", runebreakerAbsorb, moduleId);\n  api.registerCastReaction?.(\"eaCounterChannel\", counterChannel, moduleId);\n  api.registerCastReaction?.(\"eaAbsoluteDenial\", absoluteDenial, moduleId);" },
  { name: "the metamagic is not registered", file: A, from: "  for (const [key, spec] of Object.entries(WEAVER_METAMAGIC)) api.registerMetamagic?.(key, spec, moduleId);\n", to: "" },
  { name: "the riposte's step is not registered", file: A, from: "  api.registerReactionStep?.(RIPOSTE_STEP, riposteStep, moduleId);\n", to: "" },
  { name: "Counter Channel's toggle spends its Focus use", file: A, from: "  ownsFocusUse: true,\n  async use(actor, item) {\n    const on =", to: "  async use(actor, item) {\n    const on =" },
  // 0.9.1: Shadowmantle's DB row is typed as the book prints it; Wellspring's card on discounts
  { name: "Shadowmantle's DB row is untyped again", file: C, from: "defenceDC: [{ dc: \"defence\", value: 1, type: \"circumstance\", label: \"Shadowmantle\",", to: "defenceDC: [{ dc: \"defence\", value: 1, label: \"Shadowmantle\"," },
  { name: "Shadowmantle's card drops the stacking line", file: C, from: "+1 circumstance to your DB against spell attacks (a circumstance bonus: it does not stack with another circumstance bonus to your DB, and only the higher applies) and", to: "+1 circumstance to your DB against spell attacks and" },
  { name: "Shadowmantle's table entry drops the type", file: C, from: "\"Defence row +1 circumstance vs spell attacks in light ≤ 5 (G20; TRG Prime 3.684.1 stacks it by type);", to: "\"Defence row +1 vs spell attacks in light ≤ 5 (G20);" },
  { name: "Wellspring's card says no discount lowers the PP again", file: C, from: "Economic Spell and Signature Spell lower that figure (they lower what the spell is cast at); a PP discount from another feat or option (G4's) is taken off what you pay and does not.", to: "A PP discount does not lower them." },
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6b2.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6b2: verify-block6b2 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6b2: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6b2: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
