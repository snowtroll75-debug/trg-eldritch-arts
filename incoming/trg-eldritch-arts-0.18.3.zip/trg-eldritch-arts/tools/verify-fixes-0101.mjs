#!/usr/bin/env node
/**
 * verify-fixes-0101 — Eldritch Arts 0.10.1: the module half of the findings
 * from 0.10.0's live test (docs/LIVE_TESTING_REPORT_0.10.0.md), on TRG Prime
 * 3.685.1's seams. Driven with the REAL core where it decides: its deferral
 * registry and teleport rule, its target rule, its rider line and its spell
 * engine, fed the module's own registrations and pack documents.
 *
 *   T  The teleport card with the teleport (finding 1): Panic Transposition
 *      and Dimensional Assault register as deferred; no card at the cast; the
 *      card and `teleportedTurn` after the move, nothing on a cancelled one; a
 *      second teleport this turn fails before anything is asked. Mirror
 *      Reprise and Dimensional Step are not Teleportation casts.
 *   R  Spirit Arrow's cast card (finding 2).
 *   O  Spirit Arrow, Decoherence and Freshmark ask for no creature (finding 3).
 *   D  Distracted is one effect, refreshed (finding 6).
 *   P  The landing prompt stays until the click or Escape (finding 7).
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-fixes-0101.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ── the packs, as shipped ─────────────────────────────────────────── */
const pack = (name) => fs.readdirSync(path.join(ROOT, "packs-source", name)).map((f) => JSON.parse(fs.readFileSync(path.join(ROOT, "packs-source", name, f), "utf8")));
// Built from the content (so a content mutation is seen); packs-source for the
// spells this release did not touch, and a parity check that the build is current.
const C7 = await import(new URL("./content/block7-spells.mjs", import.meta.url));
const C4 = await import(new URL("./content/block4-spells.mjs", import.meta.url));
const SHIPPED = pack("ea-spells");
const BUILT = [...C7.SPELLS_B7, ...C4.BLOCK4_SPECIALIST];
const builtIds = new Set(BUILT.map((d) => d._id));
const SPELLS = Object.fromEntries([...SHIPPED.filter((d) => !builtIds.has(d._id)), ...BUILT].map((d) => [d.name, d]));
const ABILITIES = Object.fromEntries(pack("ea-abilities").map((d) => [d.name, d]));

/* ── fakes (before any import) ─────────────────────────────────────── */
const cards = [];          // the module's cards (helpers.postCard)
const messages = [];       // the core's own ChatMessages
const notices = [];        // ui.notifications.info, with its options
const removed = [];        // ui.notifications.remove
const keyListeners = new Set();
let nextClick = null;      // the next canvas click, or null for none (Escape is pressed instead)
let stageListens = 0;
const stageOn = new Set();
let nextId = 0;
globalThis.window = { addEventListener(t, fn) { if (t === "keydown") keyListeners.add(fn); }, removeEventListener(t, fn) { if (t === "keydown") keyListeners.delete(fn); } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info: (t, o = {}) => { const n = { id: ++nextId, message: t, options: o }; notices.push(n); return n; }, error() {}, remove: (n) => removed.push(n) } };
globalThis.canvas = {
  stage: { on(evt, fn) { stageListens++; stageOn.add(fn); const at = nextClick; if (at === "hang") return; if (at) queueMicrotask(() => fn({ data: { getLocalPosition: () => at } })); else queueMicrotask(() => { for (const k of [...keyListeners]) k({ key: "Escape" }); }); }, off(evt, fn) { stageOn.delete(fn); } },
  tokens: { placeables: [] }, scene: { regions: [] }, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) }
};
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.CONFIG = { statusEffects: [], specialStatusEffects: {} };
const onceHooks = new Map();
let hookId = 0;
globalThis.Hooks = { on() { return ++hookId; }, off(name, id) { if (onceHooks.get(name)?.id === id) onceHooks.delete(name); }, once(name, fn) { const id = ++hookId; onceHooks.set(name, { id, fn }); return id; }, callAll() {}, call() { return true; } };
globalThis.ChatMessage = { getSpeaker: () => ({}), create: async (d) => { messages.push(d); return d; } };
globalThis.foundry = { applications: { api: { DialogV2: { wait: async () => null, confirm: async () => true, prompt: async () => null }, ApplicationV2: class {}, HandlebarsApplicationMixin: (c) => c }, ux: {} },
  utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty() {}, hasProperty: () => false, mergeObject: (a, b) => Object.assign(a ?? {}, b ?? {}),
    isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => "r1", deepClone: (x) => structuredClone(x) } };
globalThis.fromUuid = async () => null;
globalThis.fromUuidSync = () => null;
class FakeRoll { constructor(f) { this.formula = f; } async evaluate() { this.total = 1; return this; } }
globalThis.Roll = FakeRoll;

/** A creature this client owns, with a token at (0, 0) on the map. */
function creature(name, { items = [], land = 30, veto = false } = {}) {
  const flags = { [SYS]: {}, [MOD]: {} };
  const a = { name, id: name, uuid: `Actor.${name}`, isOwner: true, flags, effects: [], items: [], documentName: "Actor",
    system: { skills: { athletics: {}, stealth: {} }, resources: { hp: { value: 20, max: 20 }, ap: { value: 3 }, pp: { value: 30 } }, combat: { movement: { land: { base: land, total: land } } } },
    getFlag: (s, k) => flags[s]?.[k] ?? null, setFlag: async (s, k, v) => { (flags[s] ??= {})[k] = v; }, unsetFlag: async (s, k) => { delete flags[s]?.[k]; },
    hasCondition: () => false,
    async createEmbeddedDocuments(type, data) { const made = data.map((d) => ({ ...structuredClone(d), id: `${name}-e${++nextId}` })); (type === "Item" ? a.items : a.effects).push(...made); return made; },
    async deleteEmbeddedDocuments(type, ids) { a.effects = a.effects.filter((e) => !ids.includes(e.id)); return ids; } };
  for (const d of items) a.items.push({ ...structuredClone(d), id: `${name}-i${++nextId}`, parent: a, getFlag: (s, k) => d.flags?.[s]?.[k] });
  const t = { id: `t-${name}`, name, actor: a, center: { x: 50, y: 50 }, w: 100, h: 100 };
  t.document = { actor: a, x: 0, y: 0, width: 1, height: 1, uuid: `Scene.s.Token.t-${name}`, update: async (u) => (veto ? t.document : Object.assign(t.document, u)) };
  a.getActiveTokens = () => [t];
  a.token = t;
  return a;
}

/* ── the real core ─────────────────────────────────────────────────── */
const CORE_API = await import(sys("module", "module-api.mjs"));
const TRW = await import(sys("module", "trait-rules-workflow.mjs"));
const CASTING = await import(sys("module", "magic", "casting.mjs"));
const SR = await import(sys("module", "magic", "strike-riders.mjs"));
const TRAITS = await import(sys("module", "traits.mjs"));
const arrivals = [];
const asked = [];
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => null,
  reactionRefusal: async () => "",
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title }); return { answer: "no", result: { cast: false } }; },
  itemUsesMax: () => null, itemUsesRemaining: () => 0,
  // THE CORE'S OWN, recorded: where the token stood when the teleport was carded.
  teleportationArrives: async (caster, spell, moved) => { arrivals.push({ caster: caster?.name, spell: spell?.name, moved: moved.map((m) => m.name), x: caster?.token?.document?.x }); return TRW.teleportationArrives(caster, spell, moved); },
  teleportationFails: async (actor) => TRW.teleportationFails(actor)
};
globalThis.game = { trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] }, combat: null, actors: [], packs: [], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: SYS, version: "3.685.1" }, socket: { emit() {}, on() {} }, modules: new Map(), i18n: { localize: (s) => s } };
game.users.activeGM = game.user;

const B7 = await quiet(() => import(new URL("../module/block7-automations.mjs", import.meta.url)));
const B4 = await quiet(() => import(new URL("../module/block4-automations.mjs", import.meta.url)));
const B3 = await quiet(() => import(new URL("../module/block3-automations.mjs", import.meta.url)));
const DZ = await import(new URL("../module/distracted.mjs", import.meta.url));

/* ── T: the teleport card with the teleport ────────────────────────── */
{
  const registered = [];
  const api = new Proxy({}, { get: (_, name) => (...args) => { registered.push([name, ...args]); return true; } });
  await quiet(async () => { B7.registerBlock7(api, MOD); B4.registerBlock4(api, MOD); });
  const deferred = registered.filter(([n]) => n === "registerDeferredTeleport");
  equal("T1 Blocks 7 and 4 register Panic Transposition's and Dimensional Assault's teleports as later than their casts (TRG Prime 3.685.1)",
    deferred.map(([, key, fn, mod]) => [key, typeof fn, mod]), [["eaPanicTransposition", "function", MOD], ["eaDimensionalAssault", "function", MOD]]);
  for (const [, key, fn] of deferred) CORE_API.registerDeferredTeleport(key, fn, MOD);
  const asks = async (name) => TRW.teleportDeferred({ spell: SPELLS[name], spellData: SPELLS[name].system });
  equal("T2 the core, asked of the shipped spells: Panic and Dimensional Assault deferred; Ley Walker (Teleportation, carded at its cast) is not",
    [await asks("Panic Transposition"), await asks("Dimensional Assault"), await asks("Ley Walker")], [true, true, false]);
  equal("T3 Mirror Reprise's cast carries no Teleportation trait (the core never carded it), nor does Dimensional Step cast (it is an ability's Use): neither had the early card",
    [TRAITS.hasTrait(SPELLS["Mirror Reprise"].system.traits, "teleportation"), ABILITIES["Dimensional Step"]?.type, TRAITS.hasTrait(SPELLS["Panic Transposition"].system.traits, "teleportation"), TRAITS.hasTrait(SPELLS["Dimensional Assault"].system.traits, "teleportation")],
    [false, "ability", true, true]);

  // Panic's teleport, on the bearer's client, in a running combat.
  game.combat = { started: true, id: "c1", round: 1, turn: 2, combatants: [] };
  const bearer = creature("Bearer", { items: [SPELLS["Panic Transposition"]] });
  canvas.tokens.placeables = [bearer.token];
  cards.length = 0; messages.length = 0; arrivals.length = 0;
  nextClick = { x: 250, y: 50 };   // 10 ft
  await quiet(() => B7.OWNER_TASKS_B7.panicTeleport(bearer, { unlocks: [], dc: 18 }));
  equal("T4 after the move, the core's card and record: \"Teleported — Spatial Awareness\" for the bearer, its turn stamped, carded with the token already moved",
    [bearer.token.document.x, arrivals.map((a) => [a.caster, a.spell, a.moved, a.x]), messages.filter((m) => /Teleported — Spatial Awareness/.test(m.content)).length, bearer.getFlag(SYS, "teleportedTurn"), cards.at(-1)?.title],
    [200, [["Bearer", "Panic Transposition", ["Bearer"], 200]], 1, { combatId: "c1", round: 1, turn: 2 }, "Panic Transposition"]);
  // The same turn again: it fails before anything is asked.
  const listens = stageListens;
  messages.length = 0; arrivals.length = 0;
  await quiet(() => B7.OWNER_TASKS_B7.panicTeleport(bearer, { unlocks: [], dc: 18 }));
  equal("T5 a second teleport this turn: no square asked, no move, no second card; the card says it fails",
    [stageListens - listens, bearer.token.document.x, messages.length, arrivals.length, /automatically fails/.test(cards.at(-1)?.lines?.join(" ") ?? "")], [0, 200, 0, 0, true]);
  // A cancelled pick (Escape): nothing carded or recorded.
  game.combat = { started: true, id: "c1", round: 1, turn: 3, combatants: [] };
  const other = creature("Other", { items: [SPELLS["Panic Transposition"]] });
  messages.length = 0; arrivals.length = 0; nextClick = null;
  await quiet(() => B7.OWNER_TASKS_B7.panicTeleport(other, { unlocks: [], dc: 18 }));
  equal("T6 a pick cancelled with Escape: no move, no card, no record", [other.token.document.x, messages.length, arrivals.length, other.getFlag(SYS, "teleportedTurn")], [0, 0, 0, null]);
  // REVIEW: a move the core vetoes (an occupied or walled square) is no teleport.
  const stuck = creature("Stuck", { items: [SPELLS["Panic Transposition"]], veto: true });
  messages.length = 0; arrivals.length = 0; cards.length = 0; nextClick = { x: 250, y: 50 };
  await quiet(() => B7.OWNER_TASKS_B7.panicTeleport(stuck, { unlocks: [], dc: 18 }));
  equal("T6b a vetoed move: no Panic card, no Spatial Awareness card, no record; the refusal is said", [stuck.token.document.x, messages.length, arrivals.length, stuck.getFlag(SYS, "teleportedTurn"), cards.some((c) => c.title === "Panic Transposition"), cards.some((c) => /teleport was refused/.test(c.warn ?? ""))], [0, 0, 0, null, false, true]);
  // RE-REVIEW: your own square (0 ft) is no teleport, said as such.
  const still = creature("Still", { items: [SPELLS["Panic Transposition"]] });
  messages.length = 0; arrivals.length = 0; cards.length = 0; nextClick = { x: 50, y: 50 };   // the token's own centre
  await quiet(() => B7.OWNER_TASKS_B7.panicTeleport(still, { unlocks: [], dc: 18 }));
  equal("T6c Panic onto its own square: no card, no record, and \"you stay where you are; no teleport is made\" (not the refusal)", [messages.length, arrivals.length, still.getFlag(SYS, "teleportedTurn"), cards.some((c) => c.title === "Panic Transposition"), cards.some((c) => /you stay where you are; no teleport is made/.test(c.warn ?? "")), cards.some((c) => /refused/.test(c.warn ?? ""))], [0, 0, null, false, true, false]);
  // REVIEW: Panic is not offered when its teleport would fail (no PP or reaction spent on it).
  const after = registered.find(([n, key]) => n === "registerCheckReaction" && key === "eaPanicTransposition")?.[2]?.after;
  const attacker = creature("Attacker");
  const fresh = creature("Fresh", { items: [SPELLS["Panic Transposition"]] });
  asked.length = 0;
  await quiet(() => after({ type: "attack", succeeded: true, target: fresh, actor: attacker }));
  const offeredFresh = asked.length;
  await quiet(() => after({ type: "attack", succeeded: true, target: bearer, actor: attacker }));   // teleported in turn 2…
  const offeredTeleportedOtherTurn = asked.length - offeredFresh;
  game.combat = { started: true, id: "c1", round: 1, turn: 2, combatants: [] };
  await quiet(() => after({ type: "attack", succeeded: true, target: bearer, actor: attacker }));   // …and it is turn 2
  equal("T9 Panic is offered to a bearer who can teleport (and to one teleported in an earlier turn), not to one already teleported this turn", [offeredFresh, offeredTeleportedOtherTurn, asked.length - offeredFresh - offeredTeleportedOtherTurn], [1, 1, 0]);

  // Dimensional Assault, after its cast (its post-cast step).
  const blade = creature("Blade", { items: [SPELLS["Dimensional Assault"]] });
  game.combat = { started: true, id: "c2", round: 1, turn: 0, combatants: [{ actor: blade }] };
  cards.length = 0; messages.length = 0; arrivals.length = 0; nextClick = { x: 250, y: 50 };
  const ctx = { actor: blade, spell: blade.items[0], cast: true, refunded: false, warpMods: { unlocks: ["eaSpatialAwareness5"] }, spellData: blade.items[0].system };
  const plus5 = () => blade.effects.filter((e) => /\+5 Spatial Awareness/.test(e.name ?? "")).length;
  await quiet(() => B4.onSpellSettledB4(ctx));
  equal("T7 Dimensional Assault: the hop, then the core's card and record with the token moved; its own card says to roll it",
    [blade.token.document.x, arrivals.map((a) => [a.spell, a.x]), messages.filter((m) => /Teleported — Spatial Awareness/.test(m.content)).length, blade.getFlag(SYS, "teleportedTurn")?.combatId, /Roll the Spatial Awareness check/.test(cards.filter((c) => c.title === "Dimensional Assault").at(-1)?.lines?.join(" ") ?? "")],
    [250, [["Dimensional Assault", 250]], 1, "c2", true]);   // Block 4 snaps to the click itself (no grid snap in the harness)
  equal("T7b the warp's +5 to Spatial Awareness is laid once the hop has happened", plus5(), 1);
  const listens2 = stageListens;
  arrivals.length = 0;
  await quiet(() => B4.onSpellSettledB4(ctx));
  equal("T8 …a second in the same turn: no hop asked, no second +5; the card says it fails", [stageListens - listens2, arrivals.length, plus5(), /automatically fails/.test(cards.filter((c) => c.title === "Dimensional Assault").at(-1)?.lines?.join(" ") ?? "")], [0, 0, 1, true]);
  // REVIEW: no +5 on an Escape or a click too far.
  const blade2 = creature("Blade2", { items: [SPELLS["Dimensional Assault"]] });
  game.combat = { started: true, id: "c3", round: 1, turn: 0, combatants: [{ actor: blade2 }] };
  const ctx2 = { ...ctx, actor: blade2, spell: blade2.items[0] };
  nextClick = null;
  await quiet(() => B4.onSpellSettledB4(ctx2));
  nextClick = { x: 50 + 20 * 40, y: 50 };   // 40 ft: beyond its 15
  await quiet(() => B4.onSpellSettledB4(ctx2));
  equal("T8b an Escape or an out-of-range click: no hop and no +5 effect left waiting", [blade2.token.document.x, blade2.effects.filter((e) => /\+5 Spatial Awareness/.test(e.name ?? "")).length], [0, 0]);
  cards.length = 0; arrivals.length = 0; nextClick = { x: 0, y: 0 };   // Block 4 takes the click as the corner: its own square
  await quiet(() => B4.onSpellSettledB4(ctx2));
  equal("T8c Dimensional Assault onto its own square: no hop, no card or record, no +5, and the stay message", [arrivals.length, blade2.getFlag(SYS, "teleportedTurn"), blade2.effects.filter((e) => /\+5 Spatial Awareness/.test(e.name ?? "")).length, cards.some((c) => /you stay where you are; no teleport is made/.test(c.warn ?? "")), cards.some((c) => /refused/.test(c.warn ?? ""))], [0, null, 0, true, false]);
  game.combat = null;
}

/* ── R and O: Spirit Arrow's card, and the object targets ──────────── */
{
  const row = SPELLS["Spirit Arrow"].system.effects.find((e) => e.kind === "strikeRider");
  equal("R1 Spirit Arrow's cast card, by the core's line for its shipped row: the arrow's 6d6 in place of the Strike's damage, nothing added",
    SR.riderCastLine(SR.normaliseStrikeRider(row)), "your next ranged Strike deals <strong>6d6 piercing</strong> in place of its damage, with nothing added");
  if (process.env.EA_MUTATING !== "1") {
    const shipped = new Map(SHIPPED.map((d) => [d._id, d]));
    ok("O0 packs-source is the build for the spells 0.10.1 changes (run build-packs)", ["Spirit Arrow", "Decoherence", "Freshmark", "Animate Moustache", "Bubble Buffet", "Dimensional Assault"]
      .every((n) => JSON.stringify({ s: shipped.get(SPELLS[n]._id)?.system, f: shipped.get(SPELLS[n]._id)?.flags }) === JSON.stringify({ s: SPELLS[n].system, f: SPELLS[n].flags })));
  }
  const marked = Object.values(SPELLS).filter((d) => d.flags?.[SYS]?.targetsObject === true).map((d) => d.name).sort();
  // RE-SCOPED 0.11.0: Block 8a's three object spells join them (Arcane Pouch, Argent Mark, Traveller's Charm).
  // 0.12.0: Block 8a's Riserune joins its three; Block 8b's Alter Corpse ("1 corpse") and Leyline Anchor ("1 Leyline").
  // (0.12.0's live test: Rite of Binding Oath and Soul Confluence take their creatures from the module, so the core asks for none.)
  equal("O1 the 0.10.0 spells aimed at an object (not a creature) say so, and no other spell does but Block 8a's four and Block 8b's four", marked, ["Alter Corpse", "Arcane Pouch", "Argent Mark", "Decoherence", "Freshmark", "Leyline Anchor", "Riserune", "Rite of Binding Oath", "Soul Confluence", "Spirit Arrow", "Traveller’s Charm"]);
  equal("O2 the core asks them for no creature; the object-or-creature and creature-held targets still ask (Drearlight: the token carrying the object; Feltwarp: the wearer; Leyline Burst: \"1 creature or object\")",
    ["Spirit Arrow", "Decoherence", "Freshmark", "Drearlight", "Feltwarp", "Leyline Burst"].map((n) => CASTING.spellNeedsTarget(SPELLS[n].system, SPELLS[n])), [false, false, false, true, true, true]);
  ok("O3 …and those three land nothing on a target: their rows are the caster's or notes", ["Spirit Arrow", "Decoherence", "Freshmark"].every((n) => SPELLS[n].system.effects.every((e) => e.target === "self" || e.kind === "note")));
}

/* ── D: Distracted, one effect ─────────────────────────────────────── */
{
  const SE = await quiet(() => import(sys("module", "magic", "spell-effects.mjs")));
  const moustache = SPELLS["Animate Moustache"];
  const rows = moustache.system.effects.filter(DZ.isDistractedRow);
  equal("D1 Animate Moustache: one Distracted row, on a Failure or Fumble; Bubble Buffet's Success and Partial one each", [moustache.system.effects.length, rows.length, rows[0]?.onSave,
    SPELLS["Bubble Buffet"].system.effects[0].degrees.success.rows.length, SPELLS["Bubble Buffet"].system.effects[0].degrees.partial.rows.filter(DZ.isDistractedRow).length], [1, 1, ["failure", "fumble"], 1, 1]);
  const foe = creature("Foe");
  const caster = creature("Caster");
  const spell = { ...moustache, uuid: "Item.am" };
  const bare = rows.map(({ onSave, ...r }) => r);
  const lines = [];
  await quiet(() => SE.applySpellEffects(caster, spell, { targets: [foe], effects: bare, lines, castId: "cast1" }));
  const fx = foe.effects[0];
  equal("D2 the real spell engine lays ONE \"Distracted\": −1 status to attacks, each skill, the three saves and Spellcraft, with the cast's id and the spell's timing",
    [foe.effects.length, fx?.name, fx?.changes?.map((c) => [c.key, c.value]), fx?.flags?.[SYS]?.castId, fx?.flags?.[SYS]?.spellEffect],
    [1, "Distracted", [["system.combat.attack.status", "-1"], ["system.skills.athletics.status", "-1"], ["system.skills.stealth.status", "-1"], ["system.combat.saves.fortitude.status", "-1"], ["system.combat.saves.reflex.status", "-1"], ["system.combat.saves.will.status", "-1"], ["system.magic.spellcraft.status", "-1"]], "cast1", true]);
  await quiet(() => SE.applySpellEffects(caster, { ...SPELLS["Bubble Buffet"], uuid: "Item.bb" }, { targets: [foe], effects: SPELLS["Bubble Buffet"].system.effects[0].degrees.partial.rows, lines: [], castId: "cast2" }));
  equal("D3 another spell's Distracted (Bubble Buffet's) stands beside it: one effect per spell, so Animate Moustache's minute is not cut short (review)", [foe.effects.length, foe.effects.map((e) => [e.name, e.flags[SYS].castId])], [2, [["Distracted", "cast1"], ["Distracted", "cast2"]]]);
  await quiet(() => SE.applySpellEffects(caster, spell, { targets: [foe], effects: bare, lines: [], castId: "cast3" }));
  equal("D3b Animate Moustache again refreshes only its own: still one per spell, every change −1 (two status −1s apply as one, Appendix 1)", [foe.effects.map((e) => e.flags[SYS].castId), [...new Set(foe.effects.flatMap((e) => e.changes.map((c) => c.value)))]], [["cast2", "cast3"], ["-1"]]);
  ok("D4 the card says it once", lines.length === 1 && /Foe: <strong>Distracted<\/strong>, -1 status penalty to attacks, every skill check, Fortitude saves, Reflex saves, Will saves and Spellcraft/.test(lines[0]), lines.join(" | "));
  ok("D5 Animate Moustache's card text names the one effect", /shown on its sheet as one effect, "Distracted"/.test(moustache.system.description) && !/\(Distracted\)"/.test(moustache.system.description));
}

/* ── P: the landing prompt ─────────────────────────────────────────── */
{
  notices.length = 0; removed.length = 0;
  nextClick = { x: 10, y: 10 };
  const picked = await B3.pickPoint(B3.landingPrompt("Panic Transposition", 30));
  equal("P1 the prompt is a permanent notification naming the spell, the range in feet and Escape; removed once the square is picked",
    [notices.length, notices[0]?.message, notices[0]?.options?.permanent, removed.map((r) => r), Boolean(picked)],
    [1, "Panic Transposition: click the square where you land, up to 30 ft away. Escape cancels.", true, [notices[0]?.id], true]);
  notices.length = 0; removed.length = 0; nextClick = null;
  const cancelled = await B3.pickPoint(B3.landingPrompt("Dimensional Step", 15));
  equal("P2 …and removed when Escape cancels", [cancelled, notices.length, removed, keyListeners.size], [null, 1, [notices[0]?.id], 0]);
  notices.length = 0; removed.length = 0; nextClick = "hang";
  const torn = B3.pickPoint(B3.landingPrompt("Panic Transposition", 30));
  const listening = [stageOn.size, keyListeners.size, onceHooks.has("canvasTearDown")];
  onceHooks.get("canvasTearDown")?.fn();
  equal("P2b a scene change (canvasTearDown) ends the pick: null, the notice removed, the click and key listeners gone", [listening, await torn, removed, stageOn.size, keyListeners.size], [[1, 1, true], null, [notices[0]?.id], 0, 0]);
  nextClick = { x: 10, y: 10 };
  await B3.pickPoint(B3.landingPrompt("Gale Step", 15));
  equal("P2c …and a pick that ended normally leaves no teardown hook behind", onceHooks.has("canvasTearDown"), false);
  const b4 = read("module", "block4-automations.mjs"), b7 = read("module", "block7-automations.mjs");
  ok("P3 Block 7's and Block 4's own teleportWithin ask through it (Panic, Mirror Reprise; Dimensional Step and Assault)",
    /export async function teleportWithin\(token, feet, label\) \{\n\s+const point = await pickPoint\(landingPrompt\(label, feet\)\);/.test(b7)
    && /async function teleportWithin\(actor, feet, label\) \{\n\s+const token = tokenOf\(actor\);\n.*\n\s+const point = await pickPoint\(landingPrompt\(label, feet\)\);/.test(b4));
}

if (failures.length) {
  process.stdout.write(failures.map((f) => `  ✗ ${f}`).join("\n") + "\n");
  process.stdout.write(`verify-fixes-0101: ${checks} checks, ${failures.length} failure(s).\n`);
  process.exitCode = 1;
} else {
  process.stdout.write(`verify-fixes-0101: ${checks} checks, 0 failure(s).\n`);
}
