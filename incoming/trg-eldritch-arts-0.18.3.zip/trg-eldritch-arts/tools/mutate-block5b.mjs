#!/usr/bin/env node
/**
 * mutate-block5b — the mutation half of verify-block5b. Each mutation breaks
 * one printed number, one reading or one wire of Block 5's group B (the
 * Emberkin and Nyrinn racial feats); verify-block5b must fail on every one.
 * Files are rewritten IN PLACE and restored after each run, and on any exit:
 * run it on a copy of the module tree, never the shared one.
 *
 *   TRG_PRIME_ROOT=/home/claude/core-3676/trg-prime node tools/mutate-block5b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block5-b.mjs"), A = f("module", "block5b-automations.mjs");

const MUTATIONS = [
  // A — the content
  { name: "Anchor in Nothing is twice a day", file: C, from: "  racialFeat(\"ANCHOR IN NOTHING\", {\n    usesPerDay: \"1\",", to: "  racialFeat(\"ANCHOR IN NOTHING\", {\n    usesPerDay: \"2\"," },
  { name: "Mindshroud's reroll has no daily count", file: C, from: "  racialFeat(\"MINDSHROUD\", {\n    usesPerDay: \"1\",", to: "  racialFeat(\"MINDSHROUD\", {" },
  { name: "Voidbound Resolve's uses stop at 4", file: C, from: "\"2, 3 at 5th, 4 at 10th, 5 at 15th, 6 at 20th\"", to: "\"2, 3 at 5th, 4 at 10th\"" },
  { name: "Ember Eyed grants Nightvision", file: C, from: "    grantedAbilities: \"Darkvision\"", to: "    grantedAbilities: \"Nightvision\"" },
  { name: "Night's Embrace's Invisibility is not innate", file: C, from: "    effects: [(id, n) => noteEffect(id, `${n}: no tracks`, \"While invisible using this spell, you leave no tracks or scent.\")],\n    flags: innate()", to: "    effects: [(id, n) => noteEffect(id, `${n}: no tracks`, \"While invisible using this spell, you leave no tracks or scent.\")]" },
  { name: "Whispers of the Void grants Charm Person", file: C, from: "    grantedSpells: \"Fear\",", to: "    grantedSpells: \"Charm Person\"," },
  { name: "Emberkin Scholar's +1 is on Occultism", file: C, from: "    effects: [skills([\"Arcana\", \"Nature\"])],", to: "    effects: [skills([\"Arcana\", \"Occultism\"])]," },
  { name: "Eternal Scholar forgets Linguistics", file: C, from: "    effects: [skills([\"Arcana\", \"Occultism\", \"Linguistics\"])]", to: "    effects: [skills([\"Arcana\", \"Occultism\"])]" },
  { name: "Nyrinn Scholar's +1 is on Arcana", file: C, from: "    effects: [skills([\"Occultism\", \"Planes\"])],", to: "    effects: [skills([\"Occultism\", \"Arcana\"])]," },
  { name: "Shadow Initiate's Stealth is +1", file: C, from: "    effects: [skills([\"Stealth\"], 2)],", to: "    effects: [skills([\"Stealth\"], 1)]," },
  { name: "Whispers of the Void's Intimidate is gone", file: C, from: "    effects: [skills([\"Deception\", \"Intimidate\"])],", to: "    effects: [skills([\"Deception\"])]," },
  { name: "Emberborn Fury is +1 a cold die", file: C, from: "perDie: 1, damageTypes: [\"fire\"], type: \"untyped\" } })]", to: "perDie: 1, damageTypes: [\"cold\"], type: \"untyped\" } })]" },
  { name: "Emberborn Fury is flat, not per die", file: C, from: "{ spellDamageBonus: { label: \"Emberborn Fury\", perDie: 1,", to: "{ spellDamageBonus: { label: \"Emberborn Fury\", value: 1," },
  { name: "Stonebound Bastion's CR is 2", file: C, from: "[{ key: \"system.combat.criticalResistance\", mode: 2, value: \"1\", priority: 20 }]", to: "[{ key: \"system.combat.criticalResistance\", mode: 2, value: \"2\", priority: 20 }]" },
  { name: "Stonebound Bastion's DC row is on the Reflex DC", file: C, from: "defenceDC: [{ dc: \"fortitudeDC\", value: 2,", to: "defenceDC: [{ dc: \"reflexDC\", value: 2," },
  { name: "Stonebound Bastion forgets the Trip", file: C, from: "export const FORCED_MOVEMENT_ACTIONS = Object.freeze([\"shoveAttack\", \"tripAttack\"]);", to: "export const FORCED_MOVEMENT_ACTIONS = Object.freeze([\"shoveAttack\"]);" },
  { name: "Stonebound's Fortitude tick applies by itself", file: C, from: "moved against your will — tick if this save is one\", auto: false,", to: "moved against your will — tick if this save is one\", auto: true," },
  { name: "Tideweaver's guard leaves 1 HP (no healTo)", file: C, from: "notOutright: true, healTo: { level: true, ability: \"wisdom\" } } })]", to: "notOutright: true } })]" },
  { name: "Tideweaver's guard heals on Constitution", file: C, from: "healTo: { level: true, ability: \"wisdom\" } } })]", to: "healTo: { level: true, ability: \"constitution\" } } })]" },
  { name: "Tideweaver's guard answers massive damage", file: C, from: "frequency: \"daily\", notOutright: true, healTo", to: "frequency: \"daily\", healTo" },
  { name: "Tideweaver's guard is every time", file: C, from: "askOwner: true, frequency: \"daily\", notOutright", to: "askOwner: true, notOutright" },
  { name: "Vein of Power ships as +2", file: C, from: "    flags: { spellAdder: 1, eaAutomation: \"veinOfPower\" }", to: "    flags: { spellAdder: 2, eaAutomation: \"veinOfPower\" }" },
  { name: "Mindshroud's advantage is against Fear", file: C, from: "auto: true, when: { checkTypes: [\"save\"], traits: [\"emotion\"] } })]", to: "auto: true, when: { checkTypes: [\"save\"], traits: [\"fear\"] } })]" },
  { name: "Silent Veil adds 10 ft", file: C, from: "    flags: { eaNullAuraBonus: 5 }", to: "    flags: { eaNullAuraBonus: 10 }" },
  { name: "Echo of the Ancestors forgets Q75's half damage", file: C, from: "takes half the damage, rounded down, and the spell's other effects. The core's limits", to: "takes the damage and the spell's other effects. The core's limits" },
  { name: "Eclipsed Form's card hides what is the GM's", file: C, from: "*Not automated:* moving through solid objects", to: "Moving through solid objects" },
  { name: "the docs grade Eclipsed Form A", file: C, from: "  \"Eclipsed Form\": { level: \"C\",", to: "  \"Eclipsed Form\": { level: \"A\"," },
  { name: "the docs lose Veilstride", file: C, from: "  \"Veilstride\": { level: \"A\", what:", to: "  \"Veilstride X\": { level: \"A\", what:" },
  // C — the pure rules
  { name: "Reprisal is 1d4 a level", file: A, from: "export const perTwoLevelsD4 = (level) => `${Math.max(1, Math.floor(Math.max(0, int(level)) / 2))}d4`;", to: "export const perTwoLevelsD4 = (level) => `${Math.max(1, int(level))}d4`;" },
  { name: "Mantle climbs every 4", file: A, from: "export const mantleBonus = (level) => 1 + Math.floor(Math.max(0, int(level)) / 5);", to: "export const mantleBonus = (level) => 1 + Math.floor(Math.max(0, int(level)) / 4);" },
  { name: "Vein of Power never climbs", file: A, from: "export const veinAdder = (level) => 1 + Math.floor(Math.max(0, int(level)) / 5);", to: "export const veinAdder = () => 1;" },
  { name: "the wings forget Dexterity", file: A, from: "export const wingsRounds = (level, dexterity) => Math.max(0, int(level) + int(dexterity));", to: "export const wingsRounds = (level) => Math.max(0, int(level));" },
  { name: "the glide is 30 ft", file: A, from: "export const GLIDE_FEET = 60;", to: "export const GLIDE_FEET = 30;" },
  { name: "Q69 undone: Crystal Pulse adds nothing", file: A, from: "export const crystalFormula = (energy) => `${Math.max(0, int(energy)) + 1}d4`;", to: "export const crystalFormula = (energy) => `${Math.max(0, int(energy))}d4`;" },
  { name: "Crystal Pulse offers cold", file: A, from: "export const CRYSTAL_TYPES = Object.freeze([\"force\", \"electricity\"]);", to: "export const CRYSTAL_TYPES = Object.freeze([\"force\", \"cold\"]);" },
  { name: "Dim Light is not dark enough", file: A, from: "Number.isFinite(Number(level)) && Number(level) <= 5;", to: "Number.isFinite(Number(level)) && Number(level) < 5;" },
  { name: "Q61 undone: unknown light is dark", file: A, from: "export const darkEnough = (level) => level !== null && level !== undefined && Number.isFinite", to: "export const darkEnough = (level) => level === null || level === undefined || Number.isFinite" },
  { name: "Q72 undone: Veilstride every melee attack", file: A, from: "darkEnough(light) && Number(feet) - Number(usedAt) >= 10;", to: "darkEnough(light) && Number(feet) >= 10;" },
  { name: "Veilstride after 5 ft", file: A, from: "darkEnough(light) && Number(feet) - Number(usedAt) >= 10;", to: "darkEnough(light) && Number(feet) - Number(usedAt) >= 5;" },
  { name: "Q73 undone: any Voidbound success lashes back", file: A, from: "  return Number.isFinite(t) && Number.isFinite(d) && t - Number(bonus) < d;", to: "  return Number.isFinite(t) && Number.isFinite(d);" },
  { name: "Q73 undone: Voidbound asked against an area", file: A, from: "export const voidboundAsks = (ctx = {}) => ctx.type === \"save\" && norm(ctx.subject) === \"will\" && !ctx.isArea", to: "export const voidboundAsks = (ctx = {}) => ctx.type === \"save\" && norm(ctx.subject) === \"will\"" },
  { name: "Voidbound asked on a Reflex save", file: A, from: "export const voidboundAsks = (ctx = {}) => ctx.type === \"save\" && norm(ctx.subject) === \"will\" && !ctx.isArea", to: "export const voidboundAsks = (ctx = {}) => ctx.type === \"save\" && !ctx.isArea" },
  { name: "Q68 undone: Eclipsed Form halves every type", file: A, from: ".filter((t) => PHYSICAL.includes(t) && !magicalFor(t));", to: ".filter((t) => !magicalFor(t));" },
  { name: "Eclipsed Form halves a spell's blow", file: A, from: "  if (ctx.kind !== \"weapon\" || ctx.magical) return null;", to: "  if (ctx.magical) return null;" },
  { name: "a Potency rune is not magical", file: A, from: "export const weaponIsMagical = (w) => Boolean(w?.system?.runeModifiers?.potency) || w?.flags?.[SYSTEM_ID]?.magicalStrike === true;", to: "export const weaponIsMagical = (w) => w?.flags?.[SYSTEM_ID]?.magicalStrike === true;" },
  { name: "one runed weapon makes every blow magical", file: A, from: "  return wielded.length > 0 && wielded.every(weaponIsMagical);", to: "  return wielded.some(weaponIsMagical);" },
  { name: "Silent Veil's feet read off the heritage", file: A, from: "Array.from(list ?? []).filter((i) => i?.type === \"feat\").reduce(", to: "Array.from(list ?? []).reduce(" },
  { name: "Q67 undone: Dazed until the next round only", file: A, from: "{ key: \"dazed\", value: 1, expiresRound: int(round) + 2 }", to: "{ key: \"dazed\", value: 1, expiresRound: int(round) + 1 }" },
  { name: "Voidborn Grace's Hover is lost", file: A, from: "  return { movement: { key: \"fly\", orLand: true }, ...(hover ? { hover: true } : {}) };", to: "  return { movement: { key: \"fly\", orLand: true } };" },
  { name: "the flight is a flat 20 ft", file: A, from: "  return { movement: { key: \"fly\", orLand: true }, ...(hover", to: "  return { movement: { key: \"fly\", feet: 20 }, ...(hover" },
  { name: "Bulwark's DB bonus is not racial", file: A, from: "changes: [custom(\"system.combat.defence.racial\", 1),", to: "changes: [custom(\"system.combat.defence.status\", 1)," },
  { name: "Bulwark forgets the Will save", file: A, from: "...[\"fortitude\", \"reflex\", \"will\"].map((s) => custom(", to: "...[\"fortitude\", \"reflex\"].map((s) => custom(" },
  { name: "Bulwark lasts to the end of the next turn", file: A, from: "    changes: [custom(\"system.combat.defence.racial\", 1), ...[\"fortitude\", \"reflex\", \"will\"].map((s) => custom(`system.combat.saves.${s}.racial`, 1))],\n    expiry: expiryFor(\"startOfNextTurn\", actor)", to: "    changes: [custom(\"system.combat.defence.racial\", 1), ...[\"fortitude\", \"reflex\", \"will\"].map((s) => custom(`system.combat.saves.${s}.racial`, 1))],\n    expiry: expiryFor(\"endOfNextTurn\", actor)" },
  { name: "Mantle's bonus is status", file: A, from: "changes: [custom(\"system.combat.defence.circumstance\", bonus)],", to: "changes: [custom(\"system.combat.defence.status\", bonus)]," },
  { name: "Apotheosis grants resistance, not immunity", file: A, from: "changes: [{ key: \"system.combat.immunities\", mode: 2, value: `, ${element}`, priority: 20 }],\n    system: { spellDamageBonus", to: "changes: [{ key: \"system.combat.resistances\", mode: 2, value: `, ${element}`, priority: 20 }],\n    system: { spellDamageBonus" },
  { name: "Apotheosis lasts 10 minutes", file: A, from: "    module: { element },\n    expiry: forSeconds(60)", to: "    module: { element },\n    expiry: forSeconds(600)" },
  { name: "Apotheosis adds nothing per die", file: A, from: "    system: { spellDamageBonus: { label: \"Elemental Apotheosis\", perDie: 1, damageTypes: [element], type: \"untyped\" } },", to: "    system: {}," },
  { name: "Shadow Initiate's speed is +10", file: A, from: "changes: [custom(\"system.combat.movement.land.racial\", 5)]", to: "changes: [custom(\"system.combat.movement.land.racial\", 10)]" },
  // D — registration
  { name: "Voidbound is asked before Anchor", file: A, from: "  api.registerCheckReaction?.(\"anchorInNothing\", { before: anchorBefore }, moduleId);\n  api.registerCheckReaction?.(\"voidboundResolve\", { before: voidboundBefore, after: voidboundAfter }, moduleId);", to: "  api.registerCheckReaction?.(\"voidboundResolve\", { before: voidboundBefore, after: voidboundAfter }, moduleId);\n  api.registerCheckReaction?.(\"anchorInNothing\", { before: anchorBefore }, moduleId);" },
  { name: "Crystal Pulse's release is not registered", file: A, from: "  api.registerFeatAutomation(\"Vir-ellian Release\", virEllianReleaseB5B, moduleId);", to: "" },
  { name: "the release loses its own Focus use", file: A, from: "Crystal Pulse: force or electricity, and 1d4 more.\",\n  ownsFocusUse: true,", to: "Crystal Pulse: force or electricity, and 1d4 more.\"," },
  { name: "Voidbound's backlash is not registered", file: A, from: "{ before: voidboundBefore, after: voidboundAfter }", to: "{ before: voidboundBefore }" },
  { name: "Eclipsed Form's damage reaction is not registered", file: A, from: "  api.registerDamageReaction?.(\"eclipsedForm\", eclipsedReaction, moduleId);", to: "" },
  { name: "Threadbreaker's modifier is not registered", file: A, from: "  api.registerDispelModifier?.(\"threadbreakersPrecision\", threadbreakerModifier, moduleId);", to: "" },
  { name: "the reprisal step is not registered", file: A, from: "  api.registerReactionStep?.(REPRISAL_STEP, reprisalStep, moduleId);", to: "" },
  // E — the reactions
  { name: "Anchor declares on any save", file: A, from: "  if (ctx?.type !== \"save\" || norm(ctx.subject) !== \"will\") return null;\n  const item = featOf(actor, N.anchor);", to: "  const item = featOf(actor, N.anchor);" },
  { name: "Anchor declares a Critical", file: A, from: "  return { declare: \"success\", label: N.anchor,", to: "  return { declare: \"critical\", label: N.anchor," },
  { name: "Anchor is free (no use spent)", file: A, from: "buttons: yesNo(\"Anchor in Nothing\"), step: SPEND_STEP, data: { itemId: item.id, label: N.anchor }", to: "buttons: yesNo(\"Anchor in Nothing\"), data: { itemId: item.id, label: N.anchor }" },
  { name: "Voidbound's +2 is untyped", file: A, from: "  return { modifiers: [{ label: N.voidbound, value: 2, type: \"race\" }]", to: "  return { modifiers: [{ label: N.voidbound, value: 2, type: \"untyped\" }]" },
  { name: "Voidbound spends no reaction", file: A, from: "data: { itemId: item.id, label: N.voidbound, reaction: true }", to: "data: { itemId: item.id, label: N.voidbound }" },
  { name: "Voidbound asked with no reaction left", file: A, from: "  if (fighting(actor) && await h().reactionRefusal?.(actor, \"\")) return null;\n", to: "" },
  { name: "the backlash is a Fortitude save", file: A, from: "save: \"will\", dc: cdc, label: N.voidbound, formula: dice, type: \"mental\"", to: "save: \"fortitude\", dc: cdc, label: N.voidbound, formula: dice, type: \"mental\"" },
  { name: "the backlash is against the Nyrinn's Level DC", file: A, from: "  const cdc = await h().levelDC(levelOf(caster));", to: "  const cdc = await h().levelDC(levelOf(saver));" },
  { name: "Tideweaver works on dry land", file: A, from: "  if (!(await h().isUnderwater(ctx.token))) return null;\n", to: "" },
  { name: "Veilstride on a ranged attack", file: A, from: "  if (ctx?.type !== \"attack\" || norm(ctx.attackMode) !== \"melee\") return null;", to: "  if (ctx?.type !== \"attack\") return null;" },
  { name: "Veilstride on another's turn", file: A, from: "  if (!featOf(actor, N.veilstride) || !ownTurn(actor) || !ctx.token) return null;", to: "  if (!featOf(actor, N.veilstride) || !ctx.token) return null;" },
  { name: "Mindshroud rerolls a success", file: A, from: "  if (ctx?.type !== \"save\" || norm(ctx.subject) !== \"will\" || !ctx.failed) return null;", to: "  if (ctx?.type !== \"save\" || norm(ctx.subject) !== \"will\") return null;" },
  { name: "Mindshroud's reroll costs nothing", file: A, from: "buttons: yesNo(\"Reroll\"), step: SPEND_STEP,", to: "buttons: yesNo(\"Reroll\")," },
  { name: "Eclipsed Form holds after it ends", file: A, from: "  if (!actor || !ownEffects(actor, SRC.eclipsed).length) return null;", to: "  if (!actor) return null;" },
  { name: "Threadbreaker's +2 is 1", file: A, from: "modifiers: [{ label: N.threadbreaker, value: 2, type: \"race\" }] };", to: "modifiers: [{ label: N.threadbreaker, value: 1, type: \"race\" }] };" },
  { name: "Threadbreaker's +2 is a tick", file: A, from: "hint: \"+2 racial to the Dispel check; a countered spell's caster is Dazed 1\", modifiers", to: "hint: \"+2 racial to the Dispel check; a countered spell's caster is Dazed 1\", optional: true, modifiers" },
  { name: "Threadbreaker dazes on a failed counter", file: A, from: "  async onResult(ctx = {}) {\n    if (!ctx.countered) return null;", to: "  async onResult(ctx = {}) {" },
  { name: "Threadbreaker dazes whoever is targeted on a Disrupting Magic", file: A, from: "const raw = ctx.targetCaster ?? (ctx.presetDispel ? null : ctx.target);", to: "const raw = ctx.targetCaster ?? ctx.target;" },
  // F — the Foundry side
  { name: "Apotheosis costs no AP", file: A, from: "    if (!(await spendAP(actor, \"Elemental Apotheosis\", 1))) return false;", to: "" },
  { name: "Elemental Step reaches double the land speed", file: A, from: "    const feet = Math.max(0, int(actor.system?.combat?.movement?.land?.total));", to: "    const feet = 2 * Math.max(0, int(actor.system?.combat?.movement?.land?.total));" },
  { name: "Elemental Step ignores the trait rules", file: A, from: "    if (!(await h().traitGate(actor, action, \"Elemental Step\"))) return false;\n", to: "" },
  { name: "Emberkin Scholar asks instead of finding Elemental Lore", file: A, from: "const lore = entries.find(([, label]) => norm(label) === \"elemental lore\");", to: "const lore = null;" },
  { name: "Nyrinn Scholar offers any specialist skill", file: A, from: "const lores = specialistEntries(actor).filter(([, label]) => NYRINN_LORES.includes(norm(label)));", to: "const lores = specialistEntries(actor);" },
  { name: "Eclipsed Form costs 1 AP", file: A, from: "    if (!(await spendAP(actor, \"Eclipsed Form\", 2))) return false;", to: "    if (!(await spendAP(actor, \"Eclipsed Form\", 1))) return false;" },
  { name: "the wings spend no use", file: A, from: "    if (!(await spendUse(item))) return false;\n    await h().createEffectsOn(actor, [wingsEffect(rounds)]);", to: "    await h().createEffectsOn(actor, [wingsEffect(rounds)]);" },
  { name: "Crystal Pulse's release keeps the energy", file: A, from: "  await actor.deleteEmbeddedDocuments(\"ActiveEffect\", stored.map((e) => e.id)).catch(() => {});\n  await card(actor, \"Vir-ellian Release\", [\n    line(`You release <strong>${energy} PP</strong> of drained energy with Crystal Pulse", to: "  await card(actor, \"Vir-ellian Release\", [\n    line(`You release <strong>${energy} PP</strong> of drained energy with Crystal Pulse" },
  { name: "Reprisal's burst ignores Fury and Apotheosis", file: A, from: "  const amount = int(roll.total) + int(bonus?.total);", to: "  const amount = int(roll.total);" },
  { name: "Reprisal is against the Emberkin's own Level DC", file: A, from: "  const dc = await h().levelDC(levelOf(target));\n  const out = await h().basicSaveHit({ caster: actor, target, save: \"reflex\"", to: "  const dc = await h().levelDC(levelOf(actor));\n  const out = await h().basicSaveHit({ caster: actor, target, save: \"reflex\"" },
  { name: "Reprisal spends its use with nobody adjacent", file: A, from: "  if (!near.length) { await card(actor, N.reprisal, [line(\"<em>No creature is adjacent to you: the burst finds no target, and the use is kept.</em>\")]); return { done: false }; }", to: "  if (!near.length) { await spendUse(item); return { done: false }; }" },
  { name: "Bulwark spends no use", file: A, from: "  if (!item || !(await spendUse(item))) return { done: false };\n  await h().createEffectsOn(actor, [bulwarkEffect(actor)]);", to: "  if (!item) return { done: false };\n  await h().createEffectsOn(actor, [bulwarkEffect(actor)]);" },
  { name: "Bulwark and Reprisal asked with uses spent", file: A, from: "    if (!item || usesLeft(item) <= 0) continue;\n    await h().askReactor(actor, {\n      title: `${name} — ${actor.name}`,", to: "    if (!item) continue;\n    await h().askReactor(actor, {\n      title: `${name} — ${actor.name}`," },
  { name: "Bulwark answers any damage", file: A, from: "  if (!elementTaken(types, element)) return;", to: "" },
  { name: "Zeal takes wing on fire", file: A, from: "  if (types.includes(\"electricity\") && featOf(actor, N.zeal)) await zealTakesWing(actor);", to: "  if (types.includes(\"fire\") && featOf(actor, N.zeal)) await zealTakesWing(actor);" },
  { name: "Mantle answers a failed cast", file: A, from: "  if (!actor?.isOwner || !ctx.cast || ctx.refunded) return;\n  const item = featOf(actor, N.mantle);", to: "  if (!actor?.isOwner) return;\n  const item = featOf(actor, N.mantle);" },
  { name: "Mantle spends no reaction", file: A, from: "  if (fighting(actor) && !(await h().spendReaction(actor, N.mantle, { traits }))) return;\n", to: "" },
  { name: "Vein of Power is not written on arrival", file: A, from: "  if (name === norm(N.vein)) await syncVeinOfPower(actor);", to: "" },
  { name: "Vein of Power ignores a level change", file: A, from: "export const levelMayHaveChanged = (change = {}) => change?.system?.identity?.level !== undefined || ", to: "export const levelMayHaveChanged = (change = {}) => " },
  { name: "Voidbound arrives spent", file: A, from: "    if (Number.isFinite(max) && int(item.system?.usesValue) < max) await item.update({ \"system.usesValue\": max });", to: "" },
  { name: "the fly speed outlives its effect", file: A, from: "    else await item.unsetFlag(SYSTEM_ID, \"creatureAbility\");", to: "" },
  { name: "a flight ending in the air does not fall", file: A, from: "  await fallFrom(actor, token, height, `${label}: the flight ended in the air.`);", to: "" },
  { name: "a flight ending falls despite another fly speed", file: A, from: "  if (Number(actor.system?.combat?.movement?.fly?.total ?? 0) > 0) return;\n", to: "" },
  { name: "Voidborn Grace does not glide", file: A, from: "  if (source === SRC.wings && featOf(actor, N.grace)) {", to: "  if (false) {" },
  { name: "the glide is not interrupted by prone", file: A, from: "statuses.some((s) => [\"prone\", \"grappled\"].includes(s))", to: "statuses.some((s) => [\"grappled\"].includes(s))" },
  { name: "landing does not end the wings", file: A, from: "  if (wings && elevation <= 0 && wings.getFlag(MODULE_ID, \"tookOff\")) {", to: "  if (false) {" },
  { name: "the wings end at take-off height 0", file: A, from: "  if (wings && elevation <= 0 && wings.getFlag(MODULE_ID, \"tookOff\")) {", to: "  if (wings && elevation <= 0) {" },
  { name: "the wings' rounds are not counted", file: A, from: "      const rounds = int(wings.getFlag(MODULE_ID, \"rounds\")) - 1;", to: "      const rounds = int(wings.getFlag(MODULE_ID, \"rounds\"));" },
  { name: "Shadow Initiate's speed stays in the light", file: A, from: "  if (!dark && up.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", up.map((e) => e.id)).catch(() => {});", to: "" },
  // Review of 0.8.0
  { name: "review undone: the turn end acts only for the creature's own client", file: A, from: "  if (!isActingGM()) return;\n  const actor = ctx.actor ?? ctx.combatant?.actor ?? null;\n  if (actor) {", to: "  const actor = ctx.actor ?? ctx.combatant?.actor ?? null;\n  if (actor && actsFor(actor)) {" },
  { name: "the turn end runs on every client", file: A, from: "  if (!isActingGM()) return;\n  const actor = ctx.actor ?? ctx.combatant?.actor ?? null;", to: "  const actor = ctx.actor ?? ctx.combatant?.actor ?? null;" },
  { name: "the turn end's light check skips players' PCs", file: A, from: "  await refreshAllB5B({ asActingGM: true });", to: "  await refreshAllB5B();" },
  { name: "a light hook on the GM's client acts for a player's PC", file: A, from: "  if (!actor || !(asActingGM ? isActingGM() : actsFor(actor))) return;", to: "  if (!actor || !(asActingGM ? isActingGM() : true)) return;" },
  { name: "review undone: Mindshroud's reroll loses Voidbound's backlash", file: A, from: "  judgeVoidboundAfterReroll(actor, ctx.check);\n", to: "" },
  { name: "the rerolled backlash ignores whether the +2 made it", file: A, from: "    await voidboundBacklash(saver, check, { succeeded: SUCCESS_DEGREES.includes(String(o.degree?.key ?? \"\")), total: o.total ?? null, dc: check.dc ?? null });", to: "    await voidboundBacklash(saver, check, { succeeded: true, total: 0, dc: 99 });" },
  { name: "review undone: Vein of Power ignores an XP level-up", file: A, from: " || change?.system?.identity?.xp !== undefined;", to: ";" },
  { name: "Shadow Initiate's speed stacks on every check", file: A, from: "  if (dark && !up.length) await h().createEffectsOn(actor, [shadowInitiateEffect()]);", to: "  if (dark) await h().createEffectsOn(actor, [shadowInitiateEffect()]);" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block5b.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block5b: verify-block5b already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block5b: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block5b: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
