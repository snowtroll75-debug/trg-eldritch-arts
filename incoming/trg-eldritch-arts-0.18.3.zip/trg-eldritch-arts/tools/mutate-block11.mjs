#!/usr/bin/env node
/**
 * mutate-block11 — each mutation is a plausible wrong reading of the Feat
 * Additions or a broken seam, and each must turn verify-block11 red.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block11.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CHECK = path.join(ROOT, "tools", "verify-block11.mjs");
const RULES = path.join(ROOT, "module", "block11-rules.mjs");
const AUTO = path.join(ROOT, "module", "block11-automations.mjs");
const REG = path.join(ROOT, "module", "registration.mjs");
const MANIFEST = path.join(ROOT, "module.json");
const FEAT = (name) => {
  const dir = path.join(ROOT, "packs-source", "ea-feats");
  return path.join(dir, fs.readdirSync(dir).find((f) => f.startsWith(`${name}_`)));
};

const MUTATIONS = [
  { name: "Advanced Design allows +3, not +2", file: RULES, from: "return { budget: 2, maxPerItem: 2, maxItems: 2, split: false, by: FEATS.advanced };", to: "return { budget: 3, maxPerItem: 2, maxItems: 2, split: false, by: FEATS.advanced };" },
  { name: "Modular Design allows two items", file: RULES, from: "return { budget: 1, maxPerItem: 1, maxItems: 1, split: false, by: FEATS.modular };", to: "return { budget: 1, maxPerItem: 1, maxItems: 2, split: false, by: FEATS.modular };" },
  { name: "an item may carry two upgrades", file: RULES, from: '    if (seen.has(key)) return allowance.split ? "an item may carry one upgrade to each bonus" : "an item may carry one modular upgrade";', to: "" },
  { name: "a weapon may take DB", file: RULES, from: 'weapon: Object.freeze([["attack", "Attack rolls (item bonus)"], ["damage", "Damage (item bonus)"]]),', to: 'weapon: Object.freeze([["attack", "Attack rolls (item bonus)"], ["damage", "Damage (item bonus)"], ["db", "DB"]]),' },
  { name: "armour DB written as a status bonus", file: RULES, from: 'return { key: "system.combat.defence.item", mode: 0,', to: 'return { key: "system.combat.defence.status", mode: 0,' },
  { name: "armour DR written into the actor directly (ADD, not the pool)", file: RULES, from: 'return { key: "system.combat.dr.item", mode: 0,', to: 'return { key: "system.combat.dr.item", mode: 2,' },
  { name: "a tool's bonus is circumstance", file: RULES, from: 'kind: "modifier", value: Math.max(1, int(value)), type: "item",', to: 'kind: "modifier", value: Math.max(1, int(value)), type: "circumstance",' },
  { name: "a tool's bonus reaches every skill", file: RULES, from: "auto: true, when: { checkTypes: [\"skill\"], subjects: [norm(skill)] }", to: "auto: true, when: { checkTypes: [\"skill\"] }" },
  { name: "a weapon upgrade's attack is untyped (stacks)", file: RULES, from: 'attack: value, attackType: "item" });', to: 'attack: value, attackType: "untyped" });' },
  { name: "a weapon upgrade's damage is untyped (stacks)", file: RULES, from: 'damage: value, damageType: "item" });', to: 'damage: value, damageType: "untyped" });' },
  { name: "a move duplicates the bonus", file: RULES, from: "allocations: allocations.map((a) => (a === at ? moved : a)) };", to: "allocations: [...allocations, moved] };" },
  { name: "Plasma Edge is 1d6", file: RULES, from: 'packets: [{ dice: "1d4", type: norm(state.element), label: "Plasma Edge" }]', to: 'packets: [{ dice: "1d6", type: norm(state.element), label: "Plasma Edge" }]' },
  { name: "Plasma Edge allows cold", file: RULES, from: 'export const OVERCLOCK_ELEMENTS = Object.freeze(["acid", "fire", "electricity"]);', to: 'export const OVERCLOCK_ELEMENTS = Object.freeze(["acid", "fire", "electricity", "cold"]);' },
  { name: "Gyroscopic Repeater reduces reload by 2", file: RULES, from: 'return { label: "Overclocked: Gyroscopic Repeater", reloadReduction: 1 };', to: 'return { label: "Overclocked: Gyroscopic Repeater", reloadReduction: 2 };' },
  { name: "Gyroscopic Repeater on any weapon", file: RULES, from: 'return OVERCLOCK_MODES.filter(([k]) => k !== "gyro" || weaponReloads(weapon));', to: "return OVERCLOCK_MODES.slice();" },
  { name: "Impact Amplifier is an item bonus", file: RULES, from: 'return { label: "Overclocked: Impact Amplifier", damage: 1, damageType: "untyped" };', to: 'return { label: "Overclocked: Impact Amplifier", damage: 1, damageType: "item" };' },
  { name: "Prepared recharges in one minute", file: RULES, from: "export const PREPARED_RECHARGE_SECONDS = 600;", to: "export const PREPARED_RECHARGE_SECONDS = 60;" },
  { name: "Prepared's recharge costs 2 AP", file: RULES, from: "export const PREPARED_RECHARGE_AP = 3;", to: "export const PREPARED_RECHARGE_AP = 2;" },
  { name: "a Partial recharges a Prepared ability", file: RULES, from: 'Object.freeze(["heroic", "critical", "success"]);\n\nexport const hasPreparedTrait', to: 'Object.freeze(["heroic", "critical", "success", "partial"]);\n\nexport const hasPreparedTrait' },
  { name: "Prepared read as Focus", file: RULES, from: 'export const hasPreparedTrait = (traits) => traitList(traits).includes("prepared");', to: 'export const hasPreparedTrait = (traits) => traitList(traits).some((t) => t === "prepared" || t === "focus");' },
  { name: "Power Sink fires on a Fumble without the Harness", file: RULES, from: 'return harness ? ["failure", "fumble", "blunder"] : ["failure"];', to: 'return harness ? ["failure", "fumble", "blunder"] : ["failure", "fumble"];' },
  { name: "Power Sink reaches 60 ft", file: RULES, from: "export const POWER_SINK_FEET = 30;", to: "export const POWER_SINK_FEET = 60;" },
  { name: "Power Sink takes an unequipped item", file: RULES, from: "if (!(sys.equipped || sys.invested)) return false;", to: "" },
  { name: "Flash of Insight fires on a Blunder", file: RULES, from: 'export const INSIGHT_DEGREES = Object.freeze(["failure", "fumble"]);', to: 'export const INSIGHT_DEGREES = Object.freeze(["failure", "fumble", "blunder"]);' },
  { name: "Emergency Contraption gives +1", file: RULES, from: "export const CONTRAPTION_BONUS = 2;", to: "export const CONTRAPTION_BONUS = 1;" },
  { name: "the contraption's bonus is never pushed", file: AUTO, from: 'ctx.check?.modifiers?.push?.({ label: `${FEATS.contraption} (${owner.name})`, value: R.CONTRAPTION_BONUS, type: "item" });', to: "" },
  { name: "Flash of Insight does not spend today's use", file: AUTO, from: '  await feat.update({ "system.usesValue": Math.max(0, h().itemUsesRemaining(feat) - 1) });\n  return { spent: true, told };', to: "  return { spent: true, told };" },
  { name: "Tinkerer Precision halves the value", file: RULES, from: "export const TINKERER_VALUE_FACTOR = 0.75;", to: "export const TINKERER_VALUE_FACTOR = 0.5;" },
  { name: "Tinkerer Precision adds 4 ranks", file: RULES, from: "export const TINKERER_RANKS = 2;", to: "export const TINKERER_RANKS = 4;" },
  { name: "the assistant's Small Dexterity mod is 0", file: RULES, from: "export const SMALL_SIZE_MODS = Object.freeze({ strength: -1, dexterity: 1 });", to: "export const SMALL_SIZE_MODS = Object.freeze({ strength: -1, dexterity: 0 });" },
  { name: "the assistant improves every 3 levels", file: RULES, from: "export const assistantImprovements = (level) => Math.max(0, Math.floor(int(level) / 4));", to: "export const assistantImprovements = (level) => Math.max(0, Math.floor(int(level) / 3));" },
  { name: "Storage holds 20 lbs", file: RULES, from: "export const STORAGE_LBS = 10;", to: "export const STORAGE_LBS = 20;" },
  { name: "the rebuild takes its gold after the old assistant is gone", file: AUTO, from: "  if (familiar) await familiar.delete();\n  const built = await buildAssistant(master, feat);", to: "  if (familiar) await familiar.delete();\n  await h().deductGold?.(master, cost);\n  const built = await buildAssistant(master, feat);" },
  { name: "Grand Inscription adds +2 (stacking to +3)", file: RULES, from: "export const GRAND_SAVE_DC_EXTRA = 1;", to: "export const GRAND_SAVE_DC_EXTRA = 2;" },
  { name: "Grand Inscription's identify stacks (+6)", file: RULES, from: "export const GRAND_IDENTIFY_VALUE = 4;", to: "export const GRAND_IDENTIFY_VALUE = 6;" },
  { name: "retraining leaves the +4", file: RULES, from: "return { ...p, value: RUNEMAGE_IDENTIFY_VALUE, label: RUNEMAGE_IDENTIFY_LABEL };", to: "return { ...p };" },
  { name: "Runic Anchor gives +1", file: RULES, from: "export const RUNIC_ANCHOR_BONUS = 2;", to: "export const RUNIC_ANCHOR_BONUS = 1;" },
  { name: "Triggered Sigil allows 3 AP spells", file: RULES, from: "export const TRIGGERED_MAX_AP = 2;", to: "export const TRIGGERED_MAX_AP = 3;" },
  { name: "a Triggered Sigil skips the one-a-round lock", file: AUTO, from: '  if (sigilLockHeld(mflag(feat, SIGIL_LOCK_FLAG), t)) return warn(`${FEATS.triggered}: a Prepared Sigil was already activated this round.`);\n  const spell', to: "  const spell" },
  { name: "Ley Resonance may cast for 0 PP", file: RULES, from: "const off = Math.max(0, Math.min(int(reduction), pp - 1));", to: "const off = Math.max(0, Math.min(int(reduction), pp));" },
  { name: "Ley Resonance leaves the casting DC alone", file: RULES, from: "return { discount: { pp: off, floor: 1 }, dcDelta: dc(pp - off) - dc(pp), pp: off };", to: "return { discount: { pp: off, floor: 1 }, dcDelta: 0, pp: off };" },
  { name: "Perfected Arcane Memory leaves Ley Resonance at 1", file: RULES, from: "export const leyResonancePP = (featNames = []) => (featNames.some((n) => norm(n) === norm(FEATS.memory)) ? 2 : 1);", to: "export const leyResonancePP = () => 1;" },
  { name: "Heritage of the First Weave on arcane saves too", file: RULES, from: 'const FIRST_WEAVE_TRADITIONS = Object.freeze(["divine", "divinity", "verdant"]);', to: 'const FIRST_WEAVE_TRADITIONS = Object.freeze(["divine", "divinity", "verdant", "arcane"]);' },
  { name: "traces read for 48 hours", file: RULES, from: "export const TRACE_SECONDS = 86400;", to: "export const TRACE_SECONDS = 172800;" },
  { name: "a Success reveals the time too", file: RULES, from: 'if (d === "critical" || d === "heroic") {', to: "if (true) {" },
  { name: "the trace DC rises by 3", file: RULES, from: "export const TRACE_DC_INCREASE = 5;", to: "export const TRACE_DC_INCREASE = 3;" },
  { name: "an upgrade counts while unequipped", file: AUTO, from: "if (R.modularKind(item) && !item.system?.equipped) return true;", to: "" },
  { name: "a broken weapon keeps its upgrade", file: AUTO, from: "if (!weapon || broken(weapon)) return null;", to: "if (!weapon) return null;" },
  { name: "Block 11 is not registered", file: REG, from: "  registerBlock11(api, moduleId);\n", to: "" },
  { name: "Flash of Insight has no daily use", file: FEAT("Flash-of-Insight"), from: '"usesPerDay": "1",', to: '"usesPerDay": "",' },
  { name: "Integrated Modularity grants no Quick Swap", file: FEAT("Integrated-Modularity"), from: '"grantedAbilities": "Quick Swap",', to: '"grantedAbilities": "",' },
  { name: "Ley Resonance is open to every race", file: FEAT("Ley-Resonance"), from: '"sourceRace": "Ascendan",', to: '"sourceRace": "",' },
  { name: "Power Sink loses the Prepared trait", file: FEAT("Power-Sink"), from: '"traits": "Artificer, Chance, Prepared",', to: '"traits": "Artificer, Chance",' },
  { name: "the version is not raised", file: MANIFEST, from: '"version": "0.18.3"', to: '"version": "0.18.2"' },
  // FOUND IN LIVE TESTING (0.18.1)
  { name: "the compendium lookup goes back to the helpers (undefined)", file: AUTO, from: "for (const pack of (await api?.contentPacksFor?.(logical)) ?? []) {", to: "for (const pack of (await h().contentPacksFor?.(logical)) ?? []) {" },
  { name: "a wondrous ring is not magical again", file: RULES, from: "if (f.wondrous || f.chargedItem || f.specificItem) return true;", to: "" },
  { name: "traits split on commas only again", file: RULES, from: '.split(/[\\s,;]+/).map(norm).filter(Boolean);\n  return words.includes("magical")', to: '.split(/[,;]+/).map(norm).filter(Boolean);\n  return words.includes("magical")' },
  { name: "a blank self spell is refused as a sigil again", file: RULES, from: "const blankSelf = !range && !targets && !area;", to: "const blankSelf = false;" },
  { name: "the prompt prints the degree with an s again", file: RULES, from: 'return ({ failure: "fails",', to: 'return ({ failure: "failures",' },
  { name: "broken at half HP again", file: AUTO, from: "  return Math.floor(Number(hp.value) || 0) <= 0;\n};", to: "  return Number(hp.value) <= Math.floor(Number(hp.max) / 2);\n};" },
  { name: "the Frame declares no class skills", file: path.join(ROOT, "tools", "content", "block11.mjs"), from: ', classSkills: ["Crafting", "Perception"] },', to: " }," },
  { name: "Darkvision is not stamped as the Nightvision grant", file: AUTO, from: 'add.push(asGrantOf(dark.toObject(), "Nightvision"));', to: "add.push(dark.toObject());" },
  { name: "a trace per target, not per cast", file: AUTO, from: "if (trace.castId && held.some((t) => t.castId === trace.castId)) return;", to: "" },
  { name: "the trace chooser names the spell to a player", file: AUTO, from: "${globalThis.game?.user?.isGM ? ` (GM: ${t.spellName})` : ` (trace ${i + 1})`}", to: " (GM: ${t.spellName})" },
  { name: "Grand Inscription on a spell with no save again", file: AUTO, from: "    if (!/fort|reflex|will|save/.test(norm(spellData?.defence))) return null;\n", to: "" },
  { name: "a tool's skill list from CONFIG again", file: AUTO, from: "const skills = Object.entries(actor?.system?.skills ?? {})", to: "const skills = Object.entries(globalThis.CONFIG?.TRG_PRIME?.skills ?? {})" },
  // GRAHAM'S RULINGS (0.18.2)
  { name: "Integrated Modularity may not split an item's bonus", file: RULES, from: "return { budget: 3, maxPerItem: 3, maxItems: 3, split: true, by: FEATS.integrated };", to: "return { budget: 3, maxPerItem: 3, maxItems: 3, split: false, by: FEATS.integrated };" },
  { name: "Advanced Design may split", file: RULES, from: "return { budget: 2, maxPerItem: 2, maxItems: 2, split: false, by: FEATS.advanced };", to: "return { budget: 2, maxPerItem: 2, maxItems: 2, split: true, by: FEATS.advanced };" },
  // (A split item's per-item cap equals Integrated's whole budget, so "exceed the cap" is not observable; not a mutation.)
  { name: "a weapon reads only its first upgrade", file: RULES, from: "const list = Array.isArray(flag?.upgrades) ? flag.upgrades : [flag];", to: "const list = Array.isArray(flag?.upgrades) ? flag.upgrades.slice(0, 1) : [flag];" },
  { name: "Flash of Insight waits on a Prepared state again", file: AUTO, from: "      if (!feat || h().itemUsesRemaining(feat) <= 0) continue;\n      if (t !== here) {\n        if (!(here && allies(side(t), side(here)))) continue;\n        const d = feetBetween(t, here);\n        if (d === null || d > R.INSIGHT_FEET) continue;", to: "      if (!feat || !preparedReadyNow(feat) || h().itemUsesRemaining(feat) <= 0) continue;\n      if (t !== here) {\n        if (!(here && allies(side(t), side(here)))) continue;\n        const d = feetBetween(t, here);\n        if (d === null || d > R.INSIGHT_FEET) continue;" },
  { name: "the rebuild is free again", file: AUTO, from: "  const cost = R.rebuildCost(level);", to: "  const cost = 0;" },
  { name: "the cost table is off by a level", file: RULES, from: "export const rebuildCost = (level) => EQUIPMENT_COST[Math.max(0, Math.min(20, int(level)))] ?? 0;", to: "export const rebuildCost = (level) => EQUIPMENT_COST[Math.max(0, Math.min(20, int(level) + 1))] ?? 0;" },
  { name: "the assistant takes any ability again", file: AUTO, from: "    if (options?.eaAssistant === true || item.flags?.[SYSTEM_ID]?.grantedBy) return true;", to: "    return true;" },
  { name: "Scout Optics' Tracking read as Perception", file: RULES, from: 'export const SCOUT_CLASS_SKILL = "Survival";', to: 'export const SCOUT_CLASS_SKILL = "Perception";' },
  { name: "Triggered Sigil designated any time again", file: RULES, from: "  if (!window || window.closed || inCombat) return false;", to: "  return true;" },
  { name: "Scout Optics' Survival hidden by Codex inheritance again", file: AUTO, from: "[`flags.${SYSTEM_ID}.classSkills`]: list, [`flags.${SYSTEM_ID}.codexInherit`]: false });", to: "[`flags.${SYSTEM_ID}.classSkills`]: list });" },
  { name: "the preparation window never closes", file: RULES, from: "export const PREP_WINDOW_SECONDS = 3600;", to: "export const PREP_WINDOW_SECONDS = 86400;" }
];

const run = () => { try { execFileSync(process.execPath, [CHECK], { stdio: "pipe", env: process.env }); return true; } catch { return false; } };
if (!run()) { process.stderr.write("mutate-block11: verify-block11 fails on an unmodified tree.\n"); process.exit(2); }
const results = [];
for (const m of MUTATIONS) {
  const original = fs.readFileSync(m.file, "utf8");
  if (original.split(m.from).length !== 2) { results.push([m.name, "ANCHOR"]); continue; }
  try { fs.writeFileSync(m.file, original.replace(m.from, m.to)); results.push([m.name, run() ? "SURVIVED" : "caught"]); }
  finally { fs.writeFileSync(m.file, original); }
}
for (const [n, s] of results) process.stdout.write(`  ${s.padEnd(8)}  ${n}\n`);
const bad = results.filter(([, s]) => s !== "caught").length;
process.stdout.write(bad ? `\nmutate-block11: FAILED — ${bad} of ${results.length} not caught.\n` : `\nmutate-block11: OK — all ${results.length} caught, tree restored.\n`);
process.exit(bad ? 1 : 0);
