#!/usr/bin/env node
/**
 * mutate-dynamic-imports — does verify-dynamic-imports catch a name taken
 * from a file that does not export it (0.15.1)? Each mutation puts back the
 * shipped defect, or one like it, and the verifier must fail.
 *
 *   node tools/mutate-dynamic-imports.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const B9B = f("module", "block9b-automations.mjs");
const B9C = f("module", "block9c-automations.mjs");
const B2 = f("module", "block2-automations.mjs");

const MUTATIONS = [
  { name: "THE DEFECT: Warpflare takes the table from block2", file: B9B,
    from: "  const { rollTable } = await import(\"./block2-automations.mjs\");\n  const { WILD_SURGE } = await import(\"./chapter7-tables.mjs\");",
    to: "  const { rollTable, WILD_SURGE } = await import(\"./block2-automations.mjs\");" },
  { name: "THE DEFECT: the Resonant Flare takes the table from block2", file: B9C,
    from: "  const { rollTable } = await import(\"./block2-automations.mjs\");\n  const { WILD_SURGE } = await import(\"./chapter7-tables.mjs\");\n  await rollTable(actor, { table: WILD_SURGE, column: \"e\", title: `${item.name} — Resonant Flare`",
    to: "  const { rollTable, WILD_SURGE } = await import(\"./block2-automations.mjs\");\n  await rollTable(actor, { table: WILD_SURGE, column: \"e\", title: `${item.name} — Resonant Flare`" },
  { name: "THE DEFECT: the Rod of Wild Surges takes the table from block2", file: B9C,
    from: "      const { rollTable } = await import(\"./block2-automations.mjs\");\n      const { WILD_SURGE } = await import(\"./chapter7-tables.mjs\");",
    to: "      const { rollTable, WILD_SURGE } = await import(\"./block2-automations.mjs\");" },
  { name: "a misspelt name is taken", file: B9C,
    from: "  const { rollTable } = await import(\"./block2-automations.mjs\");\n  const { WILD_SURGE } = await import(\"./chapter7-tables.mjs\");\n  await rollTable(actor, { table: WILD_SURGE, column: \"e\", title: `${item.name} — Resonant Flare`",
    to: "  const { rollTabel: rollTable } = await import(\"./block2-automations.mjs\");\n  const { WILD_SURGE } = await import(\"./chapter7-tables.mjs\");\n  await rollTable(actor, { table: WILD_SURGE, column: \"e\", title: `${item.name} — Resonant Flare`" },
  { name: "REVIEW: a property read off an import names nothing exported", file: B9B,
    from: "      expiry: (await import(\"./effects-clock.mjs\")).expiryFor(\"endOfNextTurn\", attacker)",
    to: "      expiry: (await import(\"./effects-clock.mjs\")).expiryForX(\"endOfNextTurn\", attacker)" },
  { name: "REVIEW: a namespace's name is not exported", file: B2,
    from: "    if (await weaver.leylineWeaverTap(actor,", to: "    if (await weaver.leylineWeaverTapX(actor," },
  { name: "REVIEW: an export left only in a comment", file: B2,
    from: "export async function rollTable(", to: "// export async function rollTable(\nasync function rollTable(" },
  { name: "an export is dropped from the file read", file: B2,
    from: "export async function rollTable(", to: "async function rollTable(" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-dynamic-imports.mjs")], { stdio: ["ignore", "pipe", "pipe"] }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-dynamic-imports: verify-dynamic-imports already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally {
  restore();
}
for (const r of results) console.log(`  ${r.state.padEnd(9)} ${r.name}`);
const bad = results.filter((r) => r.state !== "caught");
if (bad.length) { console.log(`\nmutate-dynamic-imports: FAILED — ${bad.length} of ${results.length} not caught.`); process.exit(1); }
console.log(`\nmutate-dynamic-imports: OK — all ${results.length} mutations caught, tree restored.`);
