#!/usr/bin/env node
/**
 * mutate-book-extract — the mutation half of verify-book-extract. Each
 * mutation undoes one part of the 0.10.0 extractor fix (Block 7 audit §6) or
 * of the two shipped corrections (Q166); verify-book-extract must fail on
 * every one. An extractor mutation is run twice: as is (the verify's re-cut
 * from the source must differ), and re-cut into book-text.json with the
 * source hidden (the extract's own checks must catch it). Files are restored
 * after each run, and on any exit. It rewrites files in place: run it on a
 * copy of the tree.
 *
 *   EA_BOOK_MD=/path/to/v16/ea.md TRG_PRIME_ROOT=../trpg-prime node tools/mutate-book-extract.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const X = f("tools", "content", "extract-book.mjs"), BT = f("tools", "content", "book-text.json");
const S3 = f("tools", "content", "block3-spells.mjs"), B1 = f("tools", "content", "block1.mjs"), C6 = f("tools", "content", "block6-common.mjs");
const SRC = process.env.EA_BOOK_MD ?? path.resolve(ROOT, "..", "..", "ea-src", "v16", "ea.md");
const SIDEBARS = path.join(path.dirname(SRC), "ea-sidebars.md");
if (!fs.existsSync(SRC) || !fs.existsSync(SIDEBARS)) { console.error(`mutate-book-extract: needs the v1.6 source (EA_BOOK_MD); ${SRC} not found.`); process.exit(2); }

const EXTRACTOR = [
  { name: "\"Target\" is not a label again", file: X, from: "\"Targets\", \"Target\", \"Area\"", to: "\"Targets\", \"Area\"" },
  { name: "\"Requirement\" is not a label (Rippling Gaze)", file: X, from: "\"Requirements\", \"Requirement\", \"Progression", to: "\"Requirements\", \"Progression" },
  { name: "a bold comma cuts the Tradition again (EA-m127)", file: X, from: "  .replace(/\\*\\*([,;.])\\*\\*/g, \"$1\")\n", to: "" },
  { name: "a separator opening a bold run hides the label (Steelbinding, m45)", file: X, from: "\n  .replace(/\\*\\*([,;]\\s*)([^*]+?)\\*\\*/g, \"$1**$2**\");", to: ";" },
  { name: "the field lines' labels are not recorded", file: X, from: "      cur.labels.push(...boldLabelsOf(t));\n", to: "" },
  // Equivalent while every label is known, so paired with a dropped one: "Target" is lost and hidden.
  { name: "\"Target\" is dropped and only known labels are recorded (hidden from A)", file: X, from: "      cur.labels.push(...boldLabelsOf(t));", to: "      cur.labels.push(...boldLabelsOf(t).filter((l) => LABELS.includes(l)));", also: [{ from: "\"Targets\", \"Target\", \"Area\"", to: "\"Targets\", \"Area\"" }] }
];
const MUTATIONS = [
  ...EXTRACTOR.map((m) => ({ ...m, name: `${m.name} (source re-cut)` })),
  ...EXTRACTOR.map((m) => ({ ...m, name: `${m.name} (re-extracted, no source)`, extract: true, noSource: true })),
  { name: "book-text.json loses Paradox Weave's Target (no source)", file: BT, from: "    \"Target\": \"1 willing creature\",\n", to: "", noSource: true },
  { name: "book-text.json loses Paradox Weave's Target (with source)", file: BT, from: "    \"Target\": \"1 willing creature\",\n", to: "" },
  { name: "Paradox Weave targets 1 creature again", file: S3, from: "    targets: \"1 willing creature\",\n    effects: [\n      { kind: \"condition\", target: \"targets\", condition: \"quickened\" },", to: "    targets: \"1 creature\",\n    effects: [\n      { kind: \"condition\", target: \"targets\", condition: \"quickened\" }," },
  { name: "the five Block 3 Grimoire spells are not uncommon", file: S3, from: "  doc.system.availability = GRIMOIRE_AVAILABILITY;\n", to: "" },
  { name: "the Grimoire tier is rare", file: S3, from: "export const GRIMOIRE_AVAILABILITY = \"uncommon\";", to: "export const GRIMOIRE_AVAILABILITY = \"rare\";" },
  { name: "Orb of Water is not uncommon", file: B1, from: "SPELLS[0].system.availability = \"uncommon\";\n", to: "" },
  { name: "the specialist spells are marked uncommon too", file: S3, from: "  if (specialist) {\n    doc.system.specialist = true;", to: "  doc.system.availability = \"uncommon\";\n  if (specialist) {\n    doc.system.specialist = true;" },
  { name: "Steelbinding's repair drifts from the extract", file: C6, from: "Requirements: \"your spell targets a creature wearing metal armour who is within 30-ft.\"", to: "Requirements: \"your spell targets a creature wearing metal armour.\"" }
];

const originals = new Map();
for (const file of [BT, ...MUTATIONS.map((m) => m.file)]) if (!originals.has(file)) originals.set(file, fs.readFileSync(file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run({ noSource = false } = {}) {
  const env = { ...process.env, EA_BOOK_MD: noSource ? path.join(ROOT, "no-such-source", "ea.md") : SRC };
  try { execFileSync(process.execPath, [f("tools", "verify-book-extract.mjs")], { stdio: ["ignore", "pipe", "pipe"], env }); return true; }
  catch { return false; }
}
function extract() {
  try { execFileSync(process.execPath, [X, SRC, SIDEBARS], { stdio: ["ignore", "pipe", "pipe"] }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-book-extract: verify-book-extract already fails on an unmodified tree."); process.exit(2); }
  if (!run({ noSource: true })) { console.error("mutate-book-extract: verify-book-extract fails on an unmodified tree without the source."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    let text = original.replace(m.from, m.to);
    for (const a of m.also ?? []) {
      if (text.split(a.from).length !== 2) { results.push({ name: m.name, state: "ANCHOR MISSING (also)" }); text = null; break; }
      text = text.replace(a.from, a.to);
    }
    if (text === null) continue;
    fs.writeFileSync(m.file, text);
    // An extractor that throws is caught too: the extract is then the old one, and the source re-cut fails.
    if (m.extract && !extract()) { restore(); results.push({ name: m.name, state: "caught" }); continue; }
    const survived = run({ noSource: m.noSource });
    restore();
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-book-extract: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-book-extract: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
