#!/usr/bin/env node
/**
 * verify-block2 — Eldritch Arts Block 2a (0.3.0): High Magic as the system
 * runs it (TRG Prime 3.678.0), Chapter 7's areas, Tap and Channel Ley Line,
 * Tap Magical Energy, and the three d100 tables.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block2.mjs
 *
 *   A  The book: the three actions' rows and text, the three tables row by
 *      row, the ley line bands and Sense DCs, the suppression bands — read
 *      from the extract (tools/content/book-text.json), never retyped.
 *   B  The pure rules: scaling by level, Channel's dice, the siphon, the
 *      surge trigger, the suppression reading, the siphon's dissipation.
 *   C  The tables' automation: every spec handled; damage types the
 *      system's; what is applied for a sample of every kind.
 *   D  Registration in the system's own registry, and the casting hooks
 *      against a fake map (areas, tokens, Regions).
 *   E  The actions end to end on fakes.
 *   F  Wiring: the script, the manifest, the versions.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }

const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const CH7 = book.chapter7;
const CH4 = book.chapter4;

// The fakes every Foundry-side function below reaches for.
let worldTime = 1000;
const cards = [];
const calls = { createEffectsOn: [], basicSaveHit: [], applyTypedDamage: [], applyConditionTagsTo: [], grantTempHP: [], healActor: [], rollResonanceEvent: [], rollItemDepletion: [] };
const answers = [];
let nextRoll = [];
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => answers.shift() ?? null,
  createEffectsOn: async (target, list) => { calls.createEffectsOn.push({ target: target.name, list }); return target.createEmbeddedDocuments("ActiveEffect", list); },
  levelDC: (level) => Number(level) + 14,
  basicSaveHit: async (spec) => { calls.basicSaveHit.push({ target: spec.target.name, save: spec.save, dc: spec.dc, amount: spec.amount ?? null, formula: spec.formula ?? "", type: spec.type }); return { line: `${spec.target.name} saves` }; },
  applyTypedDamage: async (target, spec) => { calls.applyTypedDamage.push({ target: target.name, ...spec }); return { applied: spec.amount }; },
  applyConditionTagsTo: async (target, tags) => { calls.applyConditionTagsTo.push({ target: target.name, tags }); },
  grantTempHP: async (actor, n) => { calls.grantTempHP.push([actor.name, n]); },
  healActor: async (actor, n) => { calls.healActor.push([actor.name, n]); },
  rollResonanceEvent: async (actor, opts) => { calls.rollResonanceEvent.push({ actor: actor.name, ...opts }); },
  rollItemDepletion: async (actor, item) => { calls.rollItemDepletion.push(item.name); },
  chargedItemLevelOf: async (item) => Number(item.system?.itemLevel ?? 0),
  regionContains: async (region, point) => region.testPoint(point)
};
globalThis.game = { trgPrime: { modules: { helpers } }, time: { get worldTime() { return worldTime; } }, combat: null, user: { isGM: true }, users: { activeGM: null }, actors: { get: () => null } };
const tokens = [];
const regions = [];
const scene = { regions, id: "scene" };
globalThis.canvas = { scene, tokens: { placeables: tokens }, dimensions: { size: 100, distance: 5 }, grid: { measurePath: (pts) => ({ distance: Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y) / 20 }) } };
globalThis.Roll = class { constructor(f) { this.f = f; } async evaluate() { const n = nextRoll.length ? nextRoll.shift() : 3; this.total = n; return this; } };
globalThis.ui = { notifications: { warn: (t) => { warnings.push(t); } } };
const warnings = [];

const actions = await import("../module/block2-actions.mjs");
const auto = await import("../module/block2-automations.mjs");
const areas = await import("../module/areas.mjs");
const tables = await import("../module/chapter7-tables.mjs");
const reg = await import("../module/registration.mjs");
const api = await import(sys("module", "module-api.mjs"));

/* ------------------------------------------------------------------ *
 * A. The book
 * ------------------------------------------------------------------ */

const rowsOf = (name) => {
  const out = {};
  for (const l of CH4[name].lines) { const m = /^\*\*(Heroic|Critical|Success|Partial|Failure|Fumble|Blunder)\*\* (.*)$/.exec(l); if (m) out[m[1].toLowerCase()] = m[2]; }
  return out;
};
const nonEmpty = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v));
for (const [key, name] of [["tapLeyLine", "TAP LEY LINE"], ["channelLeyLine", "CHANNEL LEY LINE"], ["tapMagicalEnergy", "TAP MAGICAL ENERGY"]]) {
  const a = actions.SKILL_ACTIONS.find((x) => x.key === key);
  equal(`A ${a.name}: every printed degree, as printed, and no other`, nonEmpty(a.outcomes), rowsOf(name));
  const prose = CH4[name].lines.filter((l) => !/^\*\*/.test(l) || /^\*\*Minor\*\*/.test(l)).map((l) => l.replace(/\*\*/g, ""));
  ok(`A ${a.name}: every printed paragraph is in its description`, prose.every((p) => a.description.includes(p)), prose.filter((p) => !a.description.includes(p)).join(" | "));
  equal(`A ${a.name}: Concentrate, as printed`, a.traits, "Concentrate");
}
ok("A Tap is Hard (+2), Channel Very Hard (+5), as printed", /Hard \(\+2\)/.test(CH4["TAP LEY LINE"].lines.join(" ")) && /Very Hard \(\+5\)/.test(CH4["CHANNEL LEY LINE"].lines.join(" "))
  && actions.SKILL_ACTIONS.find((a) => a.key === "tapLeyLine").difficulty === "hard" && actions.SKILL_ACTIONS.find((a) => a.key === "channelLeyLine").difficulty === "veryHard");
equal("A the action costs as printed: Tap 1 AP, Channel 10 minutes, Tap Magical Energy 1 AP (2 ranks)",
  [["TAP LEY LINE", "tapLeyLine"], ["CHANNEL LEY LINE", "channelLeyLine"], ["TAP MAGICAL ENERGY", "tapMagicalEnergy"]].map(([n, k]) => [/\*\*Action\*\* (.+)$/.exec(CH4[n].lines.find((l) => l.startsWith("**Action**")))?.[1], actions.SKILL_ACTIONS.find((a) => a.key === k).apCost]),
  [["1 AP", "1"], ["10 minutes", "10 minutes"], ["1 AP", "1"]]);
equal("A Tap Magical Energy needs 2 ranks, as printed", [CH4["TAP MAGICAL ENERGY"].lines.includes("**Ranks** 2"), actions.SKILL_ACTIONS.find((a) => a.key === "tapMagicalEnergy").minRanks], [true, 2]);

// The tables, row by row.
for (const [label, mine, printed, cols] of [
  ["Ley Line Effects", tables.LEY_LINE_EFFECTS, CH7.leyLines.effects.rows, ["effect", "backlash"]],
  ["Wild Surge", tables.WILD_SURGE, CH7.wildMagic.surge.rows, ["effect"]],
  ["Suppression Backlash", tables.SUPPRESSION_BACKLASH, CH7.suppression.backlash.rows, ["effect"]]
]) {
  equal(`A ${label}: the printed rows, ranges and text`, mine.map((r) => [r.min, r.max, ...cols.map((c) => r[c])]), printed.map((r) => [r.min, r.max, ...cols.map((c) => r[c])]));
}
equal("A the ley line bands and Sense DCs are the printed table's", areas.LEY_BANDS.map((b) => [`${b.min}${b.max === Infinity ? "+" : `-${b.max}`}`, b.senseDC]), CH7.leyLines.levels.map((l) => [l.band.replace(/\s/g, ""), l.senseDC]));
ok("A the bands' names are the printed ones", areas.LEY_BANDS.every((b, i) => CH7.leyLines.levels[i].description.startsWith(b.title)));
ok("A Channel's dice are the printed bands' (Minor 1d6 … Legendary 5d6)", /\*\*Minor\*\* 1d6 PP; \*\*Lesser\*\* 2d6 PP; \*\*Greater\*\* 3d6; \*\*Prime\*\* 4d6; \*\*Legendary\*\* 5d6/.test(CH4["CHANNEL LEY LINE"].lines.join(" "))
  && areas.LEY_BANDS.map((b) => `${b.name} ${b.channelDice}d6`).join(", ") === "Minor 1d6, Lesser 2d6, Greater 3d6, Prime 4d6, Legendary 5d6");
const levelsText = CH7.suppression.paragraphs.map((p) => p.text).join(" ");
ok("A the suppression bands are the printed ones, with Graham's M8 (dead zones 16–19)",
  /\*\*Level 1–4:\*\* Flickering zones/.test(levelsText) && /\*\*Level 5–10:\*\* Strong suppression/.test(levelsText) && /\*\*Level 11–15:\*\* Heavy suppression/.test(levelsText) && /\*\*Level 16-20:\*\* Dead zones/.test(levelsText) && /\*\*Level 20\+:\*\* Antimagic Zones/.test(levelsText)
  && JSON.stringify(areas.SUPPRESSION_BANDS.map((b) => [b.min, b.max === Infinity ? "+" : b.max])) === JSON.stringify([[1, 4], [5, 10], [11, 15], [16, 19], [20, "+"]]));
ok("A the wild surge scaling is the printed one (M7)", /\*\*Damage:\*\* 1d8 × area level/.test(CH7.wildMagic.paragraphs.map((p) => p.text).join(" ")) && /\*\*Range:\*\* 5 ft\. × area level/.test(CH7.wildMagic.paragraphs.map((p) => p.text).join(" ")));
ok("A the surge trigger is the printed one", CH7.wildMagic.paragraphs.some((p) => p.text === "If the result is a Partial, Failure, Fumble, Blunder, or Chaos, roll on the Wild Surge Table."));
ok("A the suppression reading is the printed one", CH7.suppression.paragraphs.some((p) => /results of partial, failure and fumble are all classed as a failure whereas blunder results are treated as fumbles/.test(p.text)));
ok("A ley line damage is force with a basic Fortitude save unless stated", CH7.leyLines.paragraphs.some((p) => p.text === "Any damage inflicted by a ley line effect is force and requires a basic fortitude saving throw unless stated otherwise."));

/* ------------------------------------------------------------------ *
 * B. The pure rules
 * ------------------------------------------------------------------ */
const row = (t, min) => t.find((r) => r.min === min);

equal("B scaled: level, per two levels, dice per level, one die × level", [auto.scaled("level", 7), auto.scaled("halfLevel", 7), auto.scaled("level d8", 3), auto.scaled("halfLevel d6", 5), auto.scaled("halfLevel d6", 1), auto.scaled("4d6", 9), auto.scaled("1d8 x level", 4)], ["7", "3", "3d8", "2d6", "", "4d6", "(1d8)*4"]);
ok("B \"× area level\" rows multiply one die; \"per … level\" rows roll a die per level", [26, 91].every((m) => /[×x] area level/.test(row(tables.SUPPRESSION_BACKLASH, m).effect) && / x level$/.test(row(tables.SUPPRESSION_BACKLASH, m).e.formula)) && /per ley line level/.test(row(tables.LEY_LINE_EFFECTS, 76).backlash) && row(tables.LEY_LINE_EFFECTS, 76).b.formula === "level d6");
equal("B Channel's dice by level", [1, 4, 5, 8, 9, 12, 13, 16, 17, 30].map(auto.channelDice), ["1d6", "1d6", "2d6", "2d6", "3d6", "3d6", "4d6", "4d6", "5d6", "5d6"]);
equal("B Channel's failure ×1, fumble ×2, blunder ×3, nothing else", ["success", "partial", "failure", "fumble", "blunder"].map(auto.channelDamageMultiplier), [0, 0, 1, 2, 3]);
equal("B the siphon at CL 7: Critical 3 (item −1), Success 3 (−3), Partial 1 (−1), Failure 0 (−1), Fumble 0 (−1d4)",
  ["critical", "success", "partial", "failure", "fumble"].map((d) => auto.siphonFor(d, 7)),
  [{ siphon: 3, itemLoses: 1 }, { siphon: 3, itemLoses: 3 }, { siphon: 1, itemLoses: 1 }, { siphon: 0, itemLoses: 1 }, { siphon: 0, itemLoses: "1d4" }]);
equal("B …a Critical's item loses half, minimum 1", [auto.siphonFor("critical", 2).itemLoses, auto.siphonFor("critical", 10).itemLoses], [1, 2]);
equal("B a wild surge on Partial or worse, or chaos; never on Success", [["heroic", false], ["success", false], ["partial", false], ["failure", false], ["fumble", false], ["blunder", false], ["success", true]].map(([d, c]) => auto.surges(d, c)), [false, false, true, true, true, true, true]);
equal("B the suppression reading", auto.SUPPRESSED_DEGREE, { partial: "failure", failure: "failure", fumble: "failure", blunder: "fumble" });
{
  const clock = await import("../module/effects-clock.mjs");
  const at = (currentTurn) => clock.expiryFlags("endOfTurn", { inCombat: true, combatId: "c", round: 3, nextRound: 4, currentTurn, worldTime: 100 }).module.endsAfterTurn.round;
  equal("B \"until the end of your turn\": this turn if it is yours, else your next", [at(true), at(false), clock.expiryFlags("endOfTurn", { inCombat: false, worldTime: 100 }).system.spellEffectEnd], [3, 4, 106]);
}
equal("B PP never below 0 or over the maximum", [auto.clampPP(12, 10), auto.clampPP(-3, 10), auto.clampPP(5, 10)], [10, 0, 5]);
equal("B unspent siphon: what is left above the pool before it", [auto.unspentSiphon({ siphon: 3, before: 4, current: 7 }), auto.unspentSiphon({ siphon: 3, before: 4, current: 5 }), auto.unspentSiphon({ siphon: 3, before: 4, current: 2 })], [3, 1, 0]);
equal("B a table row by d100, a total over 100 reading as 100", [tables.rowFor(tables.LEY_LINE_EFFECTS, 3).min, tables.rowFor(tables.LEY_LINE_EFFECTS, 4).min, tables.rowFor(tables.WILD_SURGE, 66).min, tables.rowFor(tables.WILD_SURGE, 140).min, tables.rowFor(tables.SUPPRESSION_BACKLASH, 25).min], [1, 4, 66, 100, 1]);
equal("B band lookups", [areas.leyBand(0).name, areas.leyBand(16).name, areas.leyBand(17).name, areas.suppressionBand(19).title, areas.suppressionBand(20).title, areas.isAntimagic(19), areas.isAntimagic(20)], ["Minor", "Prime", "Legendary", "Dead zone", "Antimagic zone", false, true]);
// Within 30 feet of a line: a 5 ft strip found at 25 ft and 28 ft, not at 35 ft.
{
  const strip = (fromFt) => (p) => p.x >= 1000 + fromFt * 20 && p.x <= 1000 + (fromFt + 5) * 20;
  const at = async (ft) => areas.nearestFeet({ x: 1000, y: 1000 }, 30, 20, strip(ft));
  equal("B a ley line within 30 ft is found, to 5 ft; one further is not", [await at(25), await at(28), await at(35), await at(-2)], [25, 30, null, 0]);
}

/* ------------------------------------------------------------------ *
 * C. The tables' automation
 * ------------------------------------------------------------------ */

const HANDLED = ["cond", "db", "dr", "spellDC", "defence", "tempHP", "heal", "loseHP", "pp", "ppFull", "ppEmpty", "lostPP", "nextSpellPP", "surcharge", "condition", "damage", "parity", "ability", "direction", "resonance", "reroll", "manual", "summons"];
const specs = [...tables.LEY_LINE_EFFECTS.flatMap((r) => [r.e, r.b]), ...tables.WILD_SURGE.map((r) => r.e), ...tables.SUPPRESSION_BACKLASH.map((r) => r.e)];
ok("C every row has a spec of a handled kind", specs.every((s) => s && HANDLED.includes(s.kind)), specs.filter((s) => !s || !HANDLED.includes(s.kind)).map((s) => s?.kind).join(", "));
const appliedSrc = fs.readFileSync(path.join(ROOT, "module", "block2-automations.mjs"), "utf8");
ok("C every kind but reroll is a case of applyRow", HANDLED.filter((k) => k !== "reroll").every((k) => appliedSrc.includes(`case "${k}"`)));
const DAMAGE_TYPES = new Set(auto.DAMAGE_TYPES);
ok("C every damage row names a type the system has, or a choice", specs.filter((s) => s.kind === "damage").every((s) => DAMAGE_TYPES.has(s.type) || /^choose:/.test(s.type)));
ok("C ley line damage is force with a basic Fortitude save unless the row says otherwise", tables.LEY_LINE_EFFECTS.flatMap((r) => [r.e, r.b]).filter((s) => s.kind === "damage").every((s) => s.save === "fortitude" && (s.type === "force" || /essence|choose/.test(s.type))));
equal("C what is automated (the rest is posted as the book's text)", [tables.LEY_LINE_EFFECTS.filter((r) => r.e.kind !== "manual").length, tables.LEY_LINE_EFFECTS.filter((r) => r.b.kind !== "manual").length, tables.WILD_SURGE.filter((r) => r.e.kind !== "manual").length, tables.SUPPRESSION_BACKLASH.filter((r) => r.e.kind !== "manual").length], [16, 24, 17, 7]); // 0.11.0: 25–27 both columns (Q184)
// Row texts the specs read: the printed numbers.
ok("C 01–03: +1 AB untyped; backlash force equal to the level", /\+1 bonus to AB/.test(row(tables.LEY_LINE_EFFECTS, 1).effect) && row(tables.LEY_LINE_EFFECTS, 1).e.mod.value === 1 && row(tables.LEY_LINE_EFFECTS, 1).e.mod.type === "untyped" && row(tables.LEY_LINE_EFFECTS, 1).b.amount === "level");
ok("C 46–48: +2 DB; backlash Weakened −2 DB", row(tables.LEY_LINE_EFFECTS, 46).e.value === 2 && row(tables.LEY_LINE_EFFECTS, 46).b.value === -2 && /–2 DB/.test(row(tables.LEY_LINE_EFFECTS, 46).backlash));
ok("C 85–87: save DC +2 / −2", row(tables.LEY_LINE_EFFECTS, 85).e.value === 2 && row(tables.LEY_LINE_EFFECTS, 85).b.value === -2);
ok("C 40–42: allies within 10 ft (both columns), 4d6", row(tables.LEY_LINE_EFFECTS, 40).e.allies === 10 && row(tables.LEY_LINE_EFFECTS, 40).b.allies === 10 && row(tables.LEY_LINE_EFFECTS, 40).b.formula === "4d6");
ok("C wild 02: 1d10 force, basic Fort, the radius, you included", row(tables.WILD_SURGE, 2).e.formula === "1d10" && row(tables.WILD_SURGE, 2).e.includeSelf === true && row(tables.WILD_SURGE, 2).e.save === "fortitude");
ok("C wild 48–52 and 53–57: mental 1d8 × level (M7), basic Will", [48, 53].every((m) => row(tables.WILD_SURGE, m).e.formula === "1d8 x level" && row(tables.WILD_SURGE, m).e.type === "mental" && row(tables.WILD_SURGE, m).e.save === "will"));
ok("C backlash 51–65: Dazed 1 for 1 round per level", row(tables.SUPPRESSION_BACKLASH, 51).e.tag.key === "dazed" && row(tables.SUPPRESSION_BACKLASH, 51).e.roundsPerLevel === true);

/* ------------------------------------------------------------------ *
 * D. Registration, and casting in the areas
 * ------------------------------------------------------------------ */

api.resetModuleRegistry();
const real = {
  registerSourcebook: api.registerSourcebook, registerRacialPP: api.registerRacialPP, registerFeatAccess: api.registerFeatAccess,
  registerTraits: api.registerTraits, registerWeaponTraitRule: api.registerWeaponTraitRule, registerSkillActions: api.queueSkillActions,
  registerFeatAutomation: api.queueFeatAutomation, registerSpellCheckGate: api.registerSpellCheckGate,
  registerCastSurcharge: api.registerCastSurcharge, registerReleasePath: api.registerReleasePath,
  registerHighMagicRules: api.registerHighMagicRules, registerCastRefusal: api.registerCastRefusal, registerCastDegreeRemap: api.registerCastDegreeRemap,
  registerResonanceSuppressor: api.registerResonanceSuppressor, registerEffectSuppressor: api.registerEffectSuppressor
};
reg.registerContent(real, "trg-eldritch-arts");
equal("D the system's registry took everything without a problem", api.registrationProblems(), []);
equal("D Eldritch Arts' High Magic rules are declared (M4)", api.registeredHighMagicRules(), "trg-eldritch-arts");
const queued = api.queuedSkillActions().filter((a) => actions.SKILL_ACTION_KEYS.includes(a.key));
equal("D the three actions are queued after Block 1's", queued.map((a) => a.key), ["tapLeyLine", "channelLeyLine", "tapMagicalEnergy"]);
ok("D …each keeps its own DC (not cloned away)", queued.every((a) => typeof a.resolveDC === "function"));
// BY KEY (0.4.0): Block 2b registers its own gate and refusal beside these.
const registryNow = api.moduleRegistry();
const keysOf = (m) => Array.from(m?.keys?.() ?? []);
ok("D the gates: Null Aura, suppression, Ley Line Connection", ["nullaura", "magicsuppression", "leylineconnection"].every((k) => keysOf(registryNow.spellCheckGates).includes(k)), JSON.stringify(keysOf(registryNow.spellCheckGates)));
equal("D the remap, the Resonance suppressor, the antimagic refusal, the effect suppressor, the Chapter 7 surcharge",
  // Block 5 (0.8.0) adds Runic Stabiliser's remap; verify-block5d holds it.
  // Block 6 (0.9.0) adds High Magic Resonance's and Spellthread's; verify-block6c and 6d hold them.
  // Block 9b (0.14.0) adds Nullflare's effect suppressor; verify-block9b holds it.
  // Block 11 (0.18.0) adds Power Sink's Resonance suppressor and its own effect suppressor; verify-block11 holds them.
  [keysOf(registryNow.castDegreeRemaps).filter((k) => !["runicstabiliser", "highmagicresonance", "spellthread"].includes(k)), keysOf(registryNow.resonanceSuppressors).filter((k) => k !== "powersink"), keysOf(registryNow.castRefusals).includes("antimagic"), keysOf(registryNow.effectSuppressors).filter((k) => !["eanullflare", "eablock11"].includes(k)), keysOf(registryNow.castSurcharges).includes("chapter7")],
  [["magicsuppression"], ["magicsuppression"], true, ["antimagic"], true]);

// A map: a caster's token, a suppression area and an antimagic one.
function makeActor(name, extra = {}) {
  const actor = { name, id: name, uuid: `Actor.${name}`, isOwner: true, flags: {}, effects: [], items: [], system: { identity: { level: 4 }, resources: { pp: { value: 5, max: 10, abilityBonus: 3 } }, skills: { powerManipulation: { ranks: 3 } }, magic: { casterLevel: 7 }, conviction: { value: 1, max: 3 } }, ...extra };
  actor.items.get = (id) => actor.items.find((i) => i.id === id);
  actor.getFlag = (s, k) => actor.flags?.[s]?.[k];
  actor.setFlag = async (s, k, v) => { actor.flags[s] ??= {}; actor.flags[s][k] = v; };
  actor.unsetFlag = async (s, k) => { delete actor.flags?.[s]?.[k]; };
  actor.update = async (diff) => { for (const [k, v] of Object.entries(diff)) { const keys = k.split("."); let o = actor; while (keys.length > 1) { const kk = keys.shift(); o[kk] ??= {}; o = o[kk]; } o[keys[0]] = v; } };
  actor.createEmbeddedDocuments = async (_t, list) => list.map((d) => { const e = { id: `e${actor.effects.length + 1}`, parent: actor, ...structuredClone(d) }; e.getFlag = (s, k) => e.flags?.[s]?.[k]; actor.effects.push(e); return e; });
  actor.deleteEmbeddedDocuments = async (_t, ids) => { actor.effects = actor.effects.filter((e) => !ids.includes(e.id)); };
  actor.getActiveTokens = () => tokens.filter((t) => t.actor === actor);
  return actor;
}
function place(actor, gx, gy, disposition = 1) {
  const t = { actor, name: actor.name, id: `t${actor.name}`, document: { x: gx * 100, y: gy * 100, width: 1, height: 1, elevation: 0, disposition, parent: scene }, center: { x: gx * 100 + 50, y: gy * 100 + 50 } };
  t.document.toObject = () => ({ ...t.document });
  tokens.push(t);
  return t;
}
const rect = (x0, y0, x1, y1) => (p) => p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1;
function region(name, testPoint, behaviors) { const r = { id: `r${regions.length}`, name, testPoint, behaviors }; regions.push(r); return r; }
const caster = makeActor("Caster");
place(caster, 5, 5);
const supp = region("Grey Hollow", rect(400, 400, 700, 700), [{ type: areas.AREA_TYPES.suppression, disabled: false, system: { level: 6, backlash: true } }]);
equal("D a Region's areas", areas.areasOfRegion(supp).map((a) => [a.kind, a.level, a.backlash]), [["suppression", 6, true]]);
equal("D a disabled behaviour is no area", areas.areasOfRegion({ behaviors: [{ type: areas.AREA_TYPES.wildMagic, disabled: true, system: { level: 3 } }] }), []);
equal("D suppression: −level on the casting check, for a cast that rolls one", [await auto.suppressionGate({ actor: caster, rollsCheck: true }).then((g) => g.modifiers), await auto.suppressionGate({ actor: caster, rollsCheck: false })],
  [[{ label: "Magic Suppression (level 6)", value: -6, type: "untyped" }], null]);
equal("D suppression: the degree read", await Promise.all(["heroic", "success", "partial", "failure", "fumble", "blunder"].map(async (d) => (await auto.suppressionRemap({ actor: caster, degree: d }))?.degree ?? d)), ["heroic", "success", "failure", "failure", "failure", "fumble"]);
ok("D suppression: no Resonance", /Resonance events simply do not exist/.test(await auto.suppressionResonance({ actor: caster })));
equal("D a level 6 area refuses nothing", await auto.antimagicRefusal({ actor: caster }), null);
supp.behaviors[0].system.level = 20;
ok("D at 20 it is antimagic: every casting refused, innate included (Q6)", /antimagic zone/.test(await auto.antimagicRefusal({ actor: caster, innate: true }) ?? ""));
supp.behaviors[0].system.level = 6;
const outside = makeActor("Outside");
place(outside, 15, 15);
equal("D outside the area: no gate, no remap, Resonance as usual", [await auto.suppressionGate({ actor: outside, rollsCheck: true }), await auto.suppressionRemap({ actor: outside, degree: "partial" }), await auto.suppressionResonance({ actor: outside })], [null, null, null]);
// Antimagic's effect suppressor.
{
  auto.antimagicOccupants.clear();
  const rune = { parent: { documentName: "Item", type: "weapon", parent: caster }, flags: {} };
  const raceFx = { parent: { documentName: "Item", type: "race", parent: caster }, flags: {} };
  const spellFx = { parent: caster, flags: { "trg-prime": { spellBuff: true } } };
  const plain = { parent: caster, flags: {} };
  equal("D nobody inside: nothing suppressed", [rune, raceFx, spellFx, plain].map(auto.antimagicSuppresses), [false, false, false, false]);
  auto.antimagicOccupants.add(caster.uuid);
  const poison = { parent: { documentName: "Item", type: "affliction", parent: caster }, flags: {} };
  const timed = { parent: caster, flags: { "trg-prime": { spellEffect: true, spellEffectEnd: 99 } } };
  equal("D inside: a magic item's effect and a spell's are off; the creature's own (race), an affliction, a plain or merely timed effect are not", [rune, raceFx, spellFx, plain, poison, timed].map(auto.antimagicSuppresses), [true, false, true, false, false, false]);
  const twin = { ...caster, uuid: "Scene.s.Token.t2.Actor.Caster" };
  equal("D keyed by the token's actor, not the shared id: another token of the same actor is unaffected", auto.antimagicSuppresses({ parent: twin, flags: { "trg-prime": { spellBuff: true } } }), false);
  auto.antimagicOccupants.clear();
}
// Ley Line Connection.
{
  const scaelyn = makeActor("Scaelyn");
  scaelyn.items.push({ type: "ability", name: "Ley Line Connection", system: {} });
  equal("D Ley Line Connection: +1 on a High Magic casting check, the casting DC only; nothing on low magic",
    [(await auto.leyLineConnectionGate({ actor: scaelyn, highMagic: true, rollsCheck: true }))?.modifiers, await auto.leyLineConnectionGate({ actor: scaelyn, highMagic: false, rollsCheck: true }), await auto.leyLineConnectionGate({ actor: caster, highMagic: true, rollsCheck: true })],
    [[{ label: "Ley Line Connection (High Magic casting DC −1)", value: 1, type: "untyped", castingOnly: true }], null, null]);
}
// The surcharges from the tables.
{
  const a = makeActor("Surcharged");
  await a.createEmbeddedDocuments("ActiveEffect", [{ flags: { "trg-eldritch-arts": { source: "leyLineBacklash", nextSpellSurcharge: 1 } } }, { flags: { "trg-eldritch-arts": { source: "wildSurge", spellSurcharge: 2 } } }]);
  equal("D the next spell pays the backlash's +1 and the surge's +2", await auto.chapter7Surcharge({ actor: a }), { pp: 3, label: "Chapter 7 (ley line or wild surge)" });
  equal("D …asking does not spend it (a refused casting costs nothing)", a.effects.length, 2);
  await auto.onSpellSettledB2({ actor: a, degree: "success", cast: false, refunded: false });
  equal("D …a spell that was not cast does not spend it", a.effects.length, 2);
  await auto.onSpellSettledB2({ actor: a, degree: "success", cast: true, refunded: true });
  equal("D …nor does a cast whose PP were refunded", a.effects.length, 2);
  await auto.onSpellSettledB2({ actor: a, degree: "success", cast: true, refunded: false });
  equal("D …a spell cast spends it; the minute's stays", [a.effects.length, await auto.chapter7Surcharge({ actor: a }).then((s) => s.pp)], [1, 2]);
}

/* ------------------------------------------------------------------ *
 * C2. applyRow on a sample of every kind
 * ------------------------------------------------------------------ */
{
  const a = makeActor("Row");
  place(a, 20, 20);
  const ally = makeActor("Ally"); place(ally, 21, 20);
  const foe = makeActor("Foe"); place(foe, 22, 20, -1);
  const ctx = { level: 6, text: "x", title: "T", expiry: { system: { spellEffectEnd: 1012 }, module: {} }, source: "test" };
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 1).e, ctx);
  equal("C2 +1 AB: a conditional on attacks, untyped", a.effects.at(-1).flags["trg-prime"].conditionals[0], { kind: "modifier", label: "+1 AB", scope: "+1 AB", auto: true, value: 1, type: "untyped", when: { checkTypes: ["attack"] } });
  answers.push("occultism");
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 4).e, ctx);
  equal("C2 +2 to the next chosen skill check, once", a.effects.at(-1).flags["trg-prime"].conditionals[0], { kind: "modifier", label: "+2 to your next Occultism check", scope: "+2 to your next Occultism check", auto: true, value: 2, type: "untyped", when: { checkTypes: ["skill"], subjects: ["occultism"] }, oneShot: true });
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 88).b, ctx);
  equal("C2 disadvantage on all checks: always", [a.effects.at(-1).flags["trg-prime"].conditionals[0].kind, a.effects.at(-1).flags["trg-prime"].conditionals[0].always], ["disadvantage", true]);
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 46).b, ctx);
  equal("C2 Weakened −2 DB, into the bonus pool (custom)", a.effects.at(-1).changes, [{ key: "system.combat.defence.other", type: "custom", value: "-2", priority: 20 }]);
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 85).e, ctx);
  equal("C2 spells' save DC +2", a.effects.at(-1).flags["trg-prime"].spellDCBonus, { label: "T", value: 2, type: "untyped" });
  calls.basicSaveHit.length = 0;
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 1).b, ctx);
  equal("C2 force = level, basic Fort against your own level DC (C3)", calls.basicSaveHit.at(-1), { target: "Row", save: "fortitude", dc: 18, amount: 6, formula: "", type: "force" });
  nextRoll = [9];
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 40).b, ctx);
  equal("C2 allies within 10 ft take 4d6 (one roll), each its own save", calls.basicSaveHit.slice(-1).map((c) => [c.target, c.amount, c.dc]), [["Ally", 9, 18]]);
  calls.applyTypedDamage.length = 0;
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 10).b, ctx);
  equal("C2 lose HP equal to the level: untyped, nothing reduces it", calls.applyTypedDamage.at(-1), { target: "Row", amount: 6, type: "untyped", ignoreDefences: true, sourceName: "T" });
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 22).b, ctx);
  equal("C2 bleed equal to half the level, for the row's duration", calls.applyConditionTagsTo.at(-1), { target: "Row", tags: [{ key: "bleeding", value: 3, expiresTime: 1012 }] });
  const quiet = calls.applyConditionTagsTo.length;
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 22).b, { ...ctx, level: 1 });
  equal("C2 …nothing at level 1 (half of 1, rounded down)", calls.applyConditionTagsTo.length, quiet);
  a.system.resources.pp.value = 8;
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 43).e, ctx);
  equal("C2 recover 1 PP per level, capped at the maximum", a.system.resources.pp.value, 10);
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 43).b, ctx);
  equal("C2 lose 1 PP per level", a.system.resources.pp.value, 4);
  await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 66).b, ctx);
  equal("C2 Chaos Backlash: Resonance with disadvantage", calls.rollResonanceEvent.at(-1)?.disadvantage, true);
  await auto.applyRow(a, row(tables.WILD_SURGE, 67).e, ctx);
  equal("C2 power surge: +1 PP per 2 levels for a minute", [a.effects.at(-1).flags["trg-eldritch-arts"].spellSurcharge, a.effects.at(-1).flags["trg-prime"].spellEffectEnd - worldTime], [3, 60]);
  nextRoll = [4];
  await auto.applyRow(a, row(tables.WILD_SURGE, 28).e, ctx);
  equal("C2 d10 even: PP gained", a.system.resources.pp.value, 8);
  a.system.resources.conviction = { value: 1, max: 3 };
  nextRoll = [12];
  await auto.applyRow(a, row(tables.WILD_SURGE, 79).e, ctx);
  equal("C2 d20 even: conviction to its maximum (system.resources.conviction)", a.system.resources.conviction.value, 3);
  await auto.applyRow(a, row(tables.WILD_SURGE, 83).e, ctx);
  equal("C2 confused, for the surge's duration", calls.applyConditionTagsTo.at(-1).tags[0], { key: "confused", expiresTime: 1012 });
  await auto.applyRow(a, row(tables.SUPPRESSION_BACKLASH, 51).e, ctx);
  equal("C2 Dazed 1 for 1 round per level", calls.applyConditionTagsTo.at(-1).tags[0].key + ":" + calls.applyConditionTagsTo.at(-1).tags[0].value + ":" + (calls.applyConditionTagsTo.at(-1).tags[0].expiresTime - worldTime), "dazed:1:36");
  await auto.applyRow(a, row(tables.SUPPRESSION_BACKLASH, 100).e, ctx);
  equal("C2 drained of all PP", a.system.resources.pp.value, 0);
  const before = cards.length;
  const lines = await auto.applyRow(a, row(tables.LEY_LINE_EFFECTS, 55).e, ctx);
  ok("C2 a manual row says it is for the table, and does nothing", /Apply at the table/.test(lines.join(" ")) && cards.length === before);
}

/* ------------------------------------------------------------------ *
 * E. The actions end to end
 * ------------------------------------------------------------------ */
{
  regions.length = 0; tokens.length = 0;
  const tapper = makeActor("Tapper");
  place(tapper, 5, 5);
  const line = region("Moonspire Line", rect(0, 1000, 2000, 1100), [{ type: areas.AREA_TYPES.leyLine, disabled: false, system: { level: 9 } }]);
  void line;
  // The line is 20–25 ft away (y 1000 at 20 px per foot from the centre at 550).
  const dc = await auto.resolveTapDC({ actor: tapper });
  equal("E Tap's DC: the line's level DC, named", [dc.dc, /level 9, Greater Ley Current/.test(dc.label)], [23, true]);
  const far = makeActor("Far"); place(far, 5, 40);
  ok("E no line within 30 ft: refused before anything is rolled", /no ley line within 30 feet/.test((await auto.resolveTapDC({ actor: far })).refused ?? ""));
  nextRoll = [2];
  cards.length = 0;
  await auto.onActionResolvedB2({ actor: tapper, action: { key: "tapLeyLine" }, degree: "success" });
  ok("E Tap's Success rolls the Effect column, to the end of your turn", cards.some((c) => /until the end of your turn/.test(c.title) && /d100 <strong>2<\/strong>: Gain a \+1 bonus to AB/.test(c.lines[0])));
  await auto.resolveTapDC({ actor: tapper });
  calls.basicSaveHit.length = 0;
  nextRoll = [3];
  await auto.onActionResolvedB2({ actor: tapper, action: { key: "tapLeyLine" }, degree: "failure" });
  equal("E Tap's Failure: 1d6 × the level force, basic Will, and an hour's lockout", [calls.basicSaveHit.at(-1)?.formula, calls.basicSaveHit.at(-1)?.save, tapper.flags["trg-eldritch-arts"].lockouts.tapLeyLine.until - worldTime], ["(1d6)*9", "will", 3600]);
  equal("E …and the next attempt is refused", auto.onActionAttemptB2({ actor: tapper, action: { key: "tapLeyLine" } }), false);
  delete tapper.flags["trg-eldritch-arts"].lockouts;
  await auto.resolveTapDC({ actor: tapper });
  nextRoll = [70];
  cards.length = 0;
  await auto.onActionResolvedB2({ actor: tapper, action: { key: "tapLeyLine" }, degree: "blunder" });
  ok("E a Blunder reads as the printed Fumble: the backlash column too, and 24 hours", tapper.flags["trg-eldritch-arts"].lockouts.tapLeyLine.until - worldTime === 86400 && cards.some((c) => /backlash/.test(c.title) && /Next spell affects you as well/.test(c.lines[0])));
  // Channel.
  delete tapper.flags["trg-eldritch-arts"].lockouts;
  tapper.system.resources.pp.value = 2;
  await auto.resolveChannelDC({ actor: tapper });
  nextRoll = [7];
  await auto.onActionResolvedB2({ actor: tapper, action: { key: "channelLeyLine" }, degree: "success" });
  equal("E Channel's Success: 3d6 (Greater) + the tradition ability, capped at the maximum", tapper.system.resources.pp.value, 10);
  await auto.resolveChannelDC({ actor: tapper });
  nextRoll = [4];
  calls.basicSaveHit.length = 0;
  await auto.onActionResolvedB2({ actor: tapper, action: { key: "channelLeyLine" }, degree: "blunder" });
  equal("E Channel's Blunder: the amount ×3 as essence, basic Fort; this line locked until tomorrow",
    [calls.basicSaveHit.at(-1)?.amount, calls.basicSaveHit.at(-1)?.type, calls.basicSaveHit.at(-1)?.save, Object.keys(tapper.flags["trg-eldritch-arts"].lockouts)[0]], [21, "essence", "fortitude", `leyLine:${regions[0].id}`]);
  ok("E …and that line is no longer offered", /no ley line within 30 feet/.test((await auto.resolveChannelDC({ actor: tapper })).refused ?? ""));
  // Tap Magical Energy.
  const siphoner = makeActor("Siphoner");
  siphoner.system.magic = { casterLevel: 0, casterLevelValue: 7 };
  const wand = { id: "w1", name: "Wand of Sparks", type: "equipment", system: { uses: 6, itemLevel: 5 }, flags: { "trg-prime": { chargedItem: { kind: "wand" } } }, update: async (d) => { wand.system.uses = d["system.uses"]; } };
  siphoner.items.push(wand);
  equal("E Tap Magical Energy's DC: the item's level DC (C3)", (await auto.resolveSiphonDC({ actor: siphoner })).dc, 19);
  siphoner.system.resources.pp.value = 5;
  await auto.onActionResolvedB2({ actor: siphoner, action: { key: "tapMagicalEnergy" }, degree: "success" });
  equal("E Success at CL 7: +3 PP, the wand −3, the essence marked to dissipate", [siphoner.system.resources.pp.value, wand.system.uses, siphoner.effects.at(-1)?.flags["trg-eldritch-arts"]?.siphon], [8, 3, 3]);
  await auto.resolveSiphonDC({ actor: siphoner });
  nextRoll = [3];
  await auto.onActionResolvedB2({ actor: siphoner, action: { key: "tapMagicalEnergy" }, degree: "blunder" });
  equal("E Blunder: 1d6 × item level force (basic Fort), the item −1d4, the depletion roll", [calls.basicSaveHit.at(-1)?.formula, wand.system.uses, calls.rollItemDepletion.at(-1)], ["5d6", 0, "Wand of Sparks"]);
  equal("E Tap Magical Energy needs 2 ranks", [auto.onActionAttemptB2({ actor: { ...makeActor("Low"), system: { skills: { powerManipulation: { ranks: 1 } } } }, action: { key: "tapMagicalEnergy" } }), auto.onActionAttemptB2({ actor: siphoner, action: { key: "tapMagicalEnergy" } })], [false, true]);
  // A wild surge.
  const wild = makeActor("Wild"); place(wild, 30, 30);
  region("Shimmer", rect(2900, 2900, 3200, 3200), [{ type: areas.AREA_TYPES.wildMagic, disabled: false, system: { level: 4 } }]);
  cards.length = 0;
  nextRoll = [83];
  await auto.onSpellSettledB2({ actor: wild, degree: "success", chaos: false, rollsCheck: true, cast: true });
  equal("E a Success does not surge", cards.length, 0);
  await auto.onSpellSettledB2({ actor: wild, degree: "partial", chaos: false, rollsCheck: true, cast: false });
  ok("E a Partial in a Wild Magic area surges once the casting is settled (83: confused)", cards.some((c) => /Wild Surge — Shimmer \(level 4\)/.test(c.title) && /83/.test(c.lines[0])) && calls.applyConditionTagsTo.at(-1)?.tags?.[0]?.key === "confused");
  cards.length = 0;
  await auto.onSpellSettledB2({ actor: wild, degree: "failure", chaos: false, rollsCheck: false, innate: true });
  equal("E no casting check, no surge (an innate cast, or a released spell)", cards.length, 0);
  nextRoll = [91];
  await auto.onSpellSettledB2({ actor: wild, degree: "success", chaos: true, rollsCheck: true, cast: true });
  ok("E chaos surges, even on a Success", cards.some((c) => /Wild Surge/.test(c.title)));
  cards.length = 0;
  nextRoll = [93];
  await auto.onReleaseRolledB2({ actor: wild, degree: "failure", chaos: false, kind: "scroll" });
  ok("E a scroll's failed release check in the area surges (Q7)", cards.some((c) => /Wild Surge/.test(c.title) && /93/.test(c.lines[0])));
  cards.length = 0;
  await auto.onReleaseRolledB2({ actor: wild, degree: "success", chaos: false, kind: "wand" });
  equal("E …a successful one does not", cards.length, 0);
  // Ley Sense reads the map.
  regions.length = 0; tokens.length = 0;
  const senser = makeActor("Senser"); place(senser, 5, 5);
  region("Old Road", rect(0, 2000, 4000, 2100), [{ type: areas.AREA_TYPES.leyLine, disabled: false, system: { level: 14 } }]).shapes = [{ type: "rectangle", x: 0, y: 2000, width: 4000, height: 100, rotation: 0 }];
  region("Far Spring", rect(0, 30000, 100, 30100), [{ type: areas.AREA_TYPES.leyLine, disabled: false, system: { level: 6 } }]).shapes = [{ type: "rectangle", x: 0, y: 30000, width: 100, height: 100, rotation: 0 }];
  const sense = await auto.resolveLeySenseDC({ actor: senser });
  equal("E Ley Sense's DC: the easiest Sense DC within 1000 ft (Prime, 18), named neutrally", [sense.dc, sense.label], [18, "Ley Sense DC (Chapter 7, from the map)"]);
  cards.length = 0;
  await auto.onActionResolvedB2({ actor: senser, action: { key: "leySense" }, degree: "success" });
  ok("E …a Success names the nearest line within 500 ft and its direction", cards.some((c) => /The nearest ley line: <strong>Old Road<\/strong>, 73 ft south/.test(c.lines[0])), JSON.stringify(cards.at(-1)));
  const mid = makeActor("Mid"); place(mid, 5, 160);
  await auto.resolveLeySenseDC({ actor: mid });
  cards.length = 0;
  await auto.onActionResolvedB2({ actor: mid, action: { key: "leySense" }, degree: "success" });
  ok("E …a line 700 ft away is beyond a Success's 500 ft", cards.some((c) => c.lines[0] === "No ley line within 500 feet."));
  await auto.resolveLeySenseDC({ actor: mid });
  cards.length = 0;
  await auto.onActionResolvedB2({ actor: mid, action: { key: "leySense" }, degree: "critical" });
  ok("E …but within a Critical's 1000 ft, with its strength", cards.some((c) => c.lines.some((l) => /Old Road<\/strong>: 698 ft north, Prime Ley Line \(level 14\)/.test(l))), JSON.stringify(cards.at(-1)?.lines));
  const loner = makeActor("Loner"); place(loner, 400, 400);
  equal("E …with no line within 1000 ft, the hardest band's DC (30)", (await auto.resolveLeySenseDC({ actor: loner })).dc, 30);
}

/* ------------------------------------------------------------------ *
 * F. Wiring
 * ------------------------------------------------------------------ */

const script = fs.readFileSync(path.join(ROOT, "scripts", "eldritch-arts.mjs"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "module.json"), "utf8"));
const systemJson = JSON.parse(fs.readFileSync(path.join(SYSTEM_ROOT, "system.json"), "utf8"));
for (const hook of ["trgPrimeActionAttempt", "trgPrimeActionResolved", "deleteActiveEffect", "trgPrimeReleaseRolled", "trgPrimeSpellSettled", "canvasReady", "updateToken"]) ok(`F the script listens for ${hook} (Block 2)`, new RegExp(`Hooks\\.on\\("${hook}"[^\\n]*(B2|antimagicSweep|refreshAntimagic)`).test(script));
ok("F Ley Sense is registered with its DC from the map", typeof api.queuedSkillActions().find((a) => a.key === "leySense")?.resolveDC === "function");
// At init beside Block 3b's setting (0.6.0).
ok("F the area types are registered at init", /Hooks\.once\("init", \(\) => \{ registerAreaTypes\(\); registerBlock3bSettings\(\); \}\);/.test(script));
equal("F the manifest declares the three Region Behaviours", manifest.documentTypes?.RegionBehavior, { leyLine: {}, wildMagic: {}, suppression: {} });
equal("F …and the module names them the same", Object.values(areas.AREA_TYPES), ["trg-eldritch-arts.leyLine", "trg-eldritch-arts.wildMagic", "trg-eldritch-arts.suppression"]);
const atLeast = (v, min) => { const a = String(v).split(".").map(Number), b = String(min).split(".").map(Number); for (let i = 0; i < 3; i++) { if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0); } return true; };
ok("F versions: module 0.3.0 or later, needing TRG Prime 3.678.0 or later", atLeast(manifest.version, "0.3.0") && atLeast(/REQUIRED_SYSTEM = "([\d.]+)"/.exec(script)?.[1], "3.678.0") && atLeast(manifest.relationships.systems[0].compatibility.minimum, "3.678.0"));
ok("F the system at TRG_PRIME_ROOT is 3.678.0 or later", atLeast(systemJson.version, "3.678.0"), systemJson.version);
ok("F the download names the version", manifest.download.includes(`v${manifest.version}/`));
const coreApi = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "module-api.mjs"), "utf8");
ok("F the system offers every registration this block calls", ["registerHighMagicRules", "registerCastRefusal", "registerCastDegreeRemap", "registerResonanceSuppressor", "registerEffectSuppressor"].every((n) => coreApi.includes(`export function ${n}(`)));

if (failures.length) {
  console.log(`verify-block2: ${checks} checks, ${failures.length} failure(s).`);
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exitCode = 1;
} else {
  console.log(`verify-block2: ${checks} checks, 0 failure(s).`);
}
