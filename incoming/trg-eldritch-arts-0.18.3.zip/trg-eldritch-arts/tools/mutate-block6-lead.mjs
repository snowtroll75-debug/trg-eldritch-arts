#!/usr/bin/env node
/**
 * mutate-block6-lead — the mutation half of verify-block6-lead. Each mutation
 * breaks one wire of the lead's Block 6 integration; verify-block6-lead must
 * fail on every one. Files are restored after each run, and on any exit.
 *
 * IT REWRITES FILES IN PLACE: run it on a copy of the module tree, never in a
 * shared one.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6-lead.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "registration.mjs"), S = f("scripts", "eldritch-arts.mjs"), B2 = f("module", "block2-automations.mjs");
const E = f("module", "block6e-automations.mjs"), D = f("module", "block6d-automations.mjs"), P = f("tools", "content", "packs.mjs"), M = f("module.json"), BLD = f("tools", "content", "builders.mjs");

const MUTATIONS = [
  { name: "an archetype is left unregistered", file: R, from: "\"Stormcaller\", \"Void Pact\"\n]);", to: "\"Stormcaller\"\n]);" },
  { name: "High Mage opens no tier", file: R, from: "  \"High Mage\": Object.freeze({ classGrants: [\"Sorcerer\"], tierGrants: [\"Adept\"] }),", to: "  \"High Mage\": Object.freeze({ classGrants: [\"Sorcerer\"] })," },
  { name: "the archetypes are never registered", file: R, from: "  for (const name of ARCHETYPES_B6) api.registerArchetype?.(name, structuredClone(ARCHETYPE_OPTIONS_B6[name] ?? {}), moduleId);\n", to: "" },
  { name: "6E is not registered", file: R, from: "  registerBlock6E(api, moduleId);\n", to: "" },
  { name: "6D is not registered (no metamagic)", file: R, from: "  registerBlock6D(api, moduleId);\n", to: "" },
  { name: "the module asks for the old core", file: S, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.683.0\";" },
  { name: "Symbiotic Witch's token hook is not wired", file: S, from: "Hooks.on(\"updateToken\", (doc, change) => { onTokenMovedB6E(doc, change).catch(warnB6(\"Symbiotic Witch\")); });\n", to: "" },
  { name: "Chronostasis's death-guard hook is not wired", file: S, from: "Hooks.on(\"trgPrimeDeathGuardHeld\", (ctx) => { onDeathGuardHeldB6B1(ctx).catch(warnB6(\"Eternal Vigil\")); });\n", to: "" },
  { name: "Block 4's createItem no longer runs before 6E's", file: S, from: "Hooks.on(\"createItem\", (item) => { onItemCreatedB4(item).catch((err) => console.warn(\"Eldritch Arts | Xithra or hex\", err)); });\n", to: "" },
  { name: "Tap Ley Line skips Leyline Weaver's ladder", file: B2, from: "    if (await weaver.leylineWeaverTap(actor, { degree: k, level: L, title })) {", to: "    if (false) {" },
  { name: "the ley benefits lay no marker", file: B2, from: "  await markLeyBenefit(actor, { level, name: title, expiry });\n", to: "" },
  { name: "every tapper's sheet gains the marker", file: B2, from: "  if (!Array.from(actor?.items ?? []).some((i) => i?.type === \"feat\" && String(i.name ?? \"\").trim().toLowerCase() === \"ley-etched symbol\")) return;\n", to: "" },
  { name: "the load-time refresh is the old world-wide sync", file: S, from: "Hooks.on(\"canvasReady\", () => { refreshFamiliarsB6E().catch(warnB6(\"Familiar range\")); });", to: "Hooks.on(\"canvasReady\", () => { refreshAllB6E().catch(warnB6(\"Familiar range\")); });" },
  { name: "Spell Surge's copies are rewritten at load again", file: D, from: "/* ------------------------------------------------------------------ */\n/* Registration", to: "export async function onReadyB6D() {}\n\n/* ------------------------------------------------------------------ */\n/* Registration" },
  { name: "Block 6's packs are not built", file: P, from: "export const PACKS = merged(BLOCK1_PACKS, BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK6_PACKS, BLOCK7_PACKS, BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);", to: "export const PACKS = merged(BLOCK1_PACKS, BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK7_PACKS, BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);" },
  { name: "one group's feats are left out of the pack", file: P, from: "...FEATS_B6_D, ...FEATS_B6_E];", to: "...FEATS_B6_D];" },
  { name: "the spells' image is V14's missing holy-symbol.svg again", file: BLD, from: "    img: img || spellImg(traits),", to: "    img: img || \"icons/svg/holy-symbol.svg\"," },
  { name: "a feat's default image is an icon the core never uses", file: BLD, from: "flags = {}, effects = [], img = \"icons/svg/upgrade.svg\" }) {", to: "flags = {}, effects = [], img = \"icons/svg/feat-star.svg\" }) {" },
  { name: "a note effect's image is an icon the core never uses", file: BLD, from: "{ description, img: \"icons/svg/book.svg\" });", to: "{ description, img: \"icons/svg/tome.svg\" });" },
  { name: "every spell takes the fallback image (no school picture)", file: BLD, from: "  return school ? `systems/trg-prime/assets/spells/${school}.svg` : SPELL_FALLBACK_IMG;", to: "  return SPELL_FALLBACK_IMG;" },
  { name: "the version is not raised", file: M, from: "\"version\": \"0.18.3\"", to: "\"version\": \"0.8.0\"" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6-lead.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6-lead: verify-block6-lead already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6-lead: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6-lead: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
