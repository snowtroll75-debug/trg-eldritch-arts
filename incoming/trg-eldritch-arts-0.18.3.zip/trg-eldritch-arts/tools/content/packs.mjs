/**
 * The packs the module ships: [{name, label, extends, type?, docs}].
 * build-packs.mjs checks each against module.json. Blocks add their packs
 * here as they are built; a block adding to a pack an earlier block made
 * appends its documents to it.
 */
import { BLOCK1_PACKS } from "./block1.mjs";
import { CLASS_ITEMS, CLASS_ABILITIES, BIRTHRIGHTS, BIRTHRIGHT_ABILITIES } from "./block3.mjs";
import { BLOCK3_SPECIALIST, BLOCK3_GRIMOIRE } from "./block3-spells.mjs";
import { CLASS_ITEMS_B4, CLASS_ABILITIES_B4, SUBCLASSES_B4 } from "./block4.mjs";
import { BLOCK4_SPECIALIST, XITHRA } from "./block4-spells.mjs";
import { FEATS_B5_A } from "./block5-a.mjs";
import { FEATS_B5_B, ABILITIES_B5_B } from "./block5-b.mjs";
import { FEATS_B5_C } from "./block5-c.mjs";
import { FEATS_B5_D } from "./block5-d.mjs";
import { FEATS_B6_A } from "./block6-a.mjs";
import { FEATS_B6_B1, ABILITIES_B6_B1, SPELLS_B6_B1 } from "./block6-b1.mjs";
import { FEATS_B6_B2, ABILITIES_B6_B2, SPELLS_B6_B2 } from "./block6-b2.mjs";
import { FEATS_B6_C } from "./block6-c.mjs";
import { FEATS_B6_D } from "./block6-d.mjs";
import { FEATS_B6_E } from "./block6-e.mjs";
import { SPELLS_B7, ABILITIES_B7 } from "./block7-spells.mjs";
import { SPELLS_B8A } from "./block8a-spells.mjs";
import { SPELLS_B8B } from "./block8b-spells.mjs";
import { BLOCK9A_PACKS } from "./block9a.mjs";
import { BLOCK9B_PACKS } from "./block9b.mjs";
import { BLOCK9C_PACKS } from "./block9c.mjs";
import { BLOCK10_PACKS } from "./block10.mjs";
import { BLOCK10B_PACKS } from "./block10b.mjs";
import { BLOCK11_PACKS } from "./block11.mjs";

const BLOCK3_PACKS = [
  { name: "ea-classes", label: "Eldritch Arts: Classes", extends: "classes", docs: CLASS_ITEMS },
  { name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: [...CLASS_ABILITIES, ...BIRTHRIGHTS, ...BIRTHRIGHT_ABILITIES] },
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: [...BLOCK3_SPECIALIST, ...BLOCK3_GRIMOIRE] }
];

// Block 4 (0.7.0): the Spellblade and the Warlock.
const BLOCK4_PACKS = [
  { name: "ea-classes", label: "Eldritch Arts: Classes", extends: "classes", docs: CLASS_ITEMS_B4 },
  { name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: [...CLASS_ABILITIES_B4, ...SUBCLASSES_B4] },
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: [...BLOCK4_SPECIALIST, XITHRA] }
];

// Block 5 (0.8.0): Chapter 5's racial and general feats.
const BLOCK5_PACKS = [
  { name: "ea-feats", label: "Eldritch Arts: Feats", extends: "feats", docs: [...FEATS_B5_A, ...FEATS_B5_B, ...FEATS_B5_C, ...FEATS_B5_D] },
  ...(ABILITIES_B5_B.length ? [{ name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: ABILITIES_B5_B }] : [])
];

// Block 6 (0.9.0): Chapter 5's archetypes and class feats, the abilities
// the archetypes print, and the specialist spells they grant.
export const FEATS_B6 = [...FEATS_B6_A, ...FEATS_B6_B1, ...FEATS_B6_B2, ...FEATS_B6_C, ...FEATS_B6_D, ...FEATS_B6_E];
const BLOCK6_PACKS = [
  { name: "ea-feats", label: "Eldritch Arts: Feats", extends: "feats", docs: FEATS_B6 },
  { name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: [...ABILITIES_B6_B1, ...ABILITIES_B6_B2] },
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: [...SPELLS_B6_B1, ...SPELLS_B6_B2] }
];

// Block 7 (0.10.0): the first half of Chapter 8's Grimoire, and the ability Elemental Strike grants.
const BLOCK7_PACKS = [
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: SPELLS_B7 },
  { name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: ABILITIES_B7 }
];

// Block 8a (0.11.0): the second half of the Grimoire, first part — the Bindings, Symbols and utilities.
const BLOCK8A_PACKS = [
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: SPELLS_B8A }
];

// Block 8b (0.12.0): the second half's second part — the rituals and Chapter 7's High Magic spells.
const BLOCK8B_PACKS = [
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: SPELLS_B8B }
];

// Block 9a (0.13.0): Chapter 6's catalysts (the materials join TRG Prime's own list).
// BLOCK9A_PACKS: [ea-consumables].
// BLOCK9B_PACKS (0.14.0): [ea-runes, ea-specific-items].
// BLOCK9C_PACKS (0.15.0): [ea-charged-items].
// BLOCK10_PACKS (0.17.0): [ea-relics].
// BLOCK10B_PACKS (0.17.1): [ea-tables (RollTable), ea-rules (JournalEntry)].
// BLOCK11_PACKS (0.18.0): the Feat Additions — [ea-feats, ea-abilities].

function merged(...lists) {
  const out = [];
  for (const pack of lists.flat()) {
    const at = out.find((p) => p.name === pack.name);
    if (at) at.docs = [...at.docs, ...pack.docs];
    else out.push({ ...pack, docs: [...pack.docs] });
  }
  return out;
}

export const PACKS = merged(BLOCK1_PACKS, BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK6_PACKS, BLOCK7_PACKS, BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS, BLOCK11_PACKS);
