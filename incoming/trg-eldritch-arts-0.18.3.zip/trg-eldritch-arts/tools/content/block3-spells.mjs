/**
 * Eldritch Arts — Block 3a (0.5.0): the specialist spells of the Archmage,
 * the Sorcerer (its "Birthright Any" spells and the six birthright spells) and
 * the Witch (Life Boost and the 21 hexes), and the five Grimoire spells the
 * birthrights grant before Blocks 7–8 build the rest of the Grimoire.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.specialist`, `book.grimoire`; cut from v1.6 by extract-book.mjs),
 * never retyped. Each description is that text followed by one paragraph
 * saying what TRG Prime does with it: *Automated*, *Partly automated*, *Not
 * automated*, or (until 0.6.0) *Waits for Block 3b* (the reactions that need TRG Prime
 * 3.681.0's seams).
 *
 * THE SHAPE IS THE CORE SPELLS PACK'S: each spell is modelled on the nearest
 * core spell (Force Bolt, Fireball, Cure, Regenerate, Haste, Blur, Bane, Spell
 * Storing, Energy Bolt, Hurling, Zealous Conviction), and uses only effect
 * kinds and warp `mods` the core reads. What no kind carries is a `note` row,
 * as the core's own Barkskin and Resist Energy carry theirs.
 *
 * SPECIALIST SPELLS carry no tradition ("a magical tradition is not provided
 * as this will always be based upon your primary tradition", Chapter 8) and
 * `specialistClass` from the class trait they print; a birthright spell with
 * none takes its Birthright field's name; a hex takes none (it is picked
 * through the Witch's Hexes), except the two Bloodmage hexes. These classes
 * cast them as High Magic as well as specialist (Q16) — the core's and the
 * classes' work, not this file's.
 *
 * FLAGS under the system's scope: the module's own keys, prefixed `ea`:
 * `eaHex` (the 21 hexes) and `eaBirthright` (a birthright's name, or "Any").
 */
import fs from "node:fs";
import { spell } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { symbolText } from "./symbol-text.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));

const printed = (lines) => md((lines ?? []).join("\n\n"));
const note = (text) => md(text);
const SMALL = new Set(["of", "the"]);
/** "CLOAK OF THE DECEIVER" → "Cloak of the Deceiver". */
const titleCase = (s) => String(s).toLowerCase().split(" ").map((w, i) => (i && SMALL.has(w) ? w : w[0].toUpperCase() + w.slice(1))).join(" ");
const traitWords = (traits) => traits.map((t) => t[0] + t.slice(1).toLowerCase()).join(", ");

/** "2 AP (somatic, verbal)" → castAP and components, as the core writes them. */
function castOf(text) {
  const t = String(text ?? "").trim();
  const words = (t.match(/\(([^)]*)\)/)?.[1] ?? "").toLowerCase();
  const components = {
    somatic: /somatic/.test(words) && !/somatic or verbal/.test(words),
    verbal: /verbal/.test(words),
    material: /material/.test(words),
    focus: /focus/.test(words)
  };
  const head = t.replace(/\s*\(.*$/, "").trim();
  let castAP = head;
  if (/^R$/i.test(head)) castAP = "Reaction";
  else if (/^Free$/i.test(head)) castAP = "Free";
  else if (/^\d+ AP$/.test(head)) castAP = Number(head.split(" ")[0]);
  return { castAP, components };
}

/** The printed warps, in order: "**+2 PP:** text" (Hex Ward prints one without the colon). */
function printedWarps(lines) {
  const out = [];
  for (const l of lines) {
    const m = /^\*\*\+(\d+) PP:?\*\*:?\s*(.*)$/.exec(l);
    if (m) out.push({ ppCost: Number(m[1]), text: m[2].replace(/\*\*/g, "").trim() });
  }
  return out;
}

/** The description: traits, fields and lines as printed, then the automation paragraph. */
function describe(entry, automation) {
  const fields = Object.entries(entry.fields).map(([k, v]) => md(`**${k}** ${v}`)).join("\n");
  return [md(`**${entry.traits.join(" ")}**`), fields, printed(entry.lines), note(automation)].filter(Boolean).join("\n");
}

const sustainedDuration = (d) => /sustain|\(S\)/i.test(String(d ?? ""));

/**
 * Each spell's automation: the cast fields the book does not print in a field
 * of its own, its effect rows, the `mods` of each printed warp by position,
 * its level for the docs and harness, and the paragraph its card shows.
 */
const SPEC = {
  /* ----------------------------- Archmage ----------------------------- */
  "ARCANE SINGULARITY": {
    category: "save", damage: { formula: "2d8", type: "force" },
    effects: [{ kind: "condition", target: "targets", condition: "prone", onSave: ["fumble"] }],
    level: "automated", what: "basic Reflex against 2d8 force in the burst; prone on a Fumble",
    text: "*Automated (TRG Prime 3.680.0):* every creature in the 10-foot burst rolls a basic Reflex save against 2d8 force damage, and a creature that fumbles is knocked prone."
  },
  "LEY SEVER": {
    targets: "1 creature, object, or magical effect",
    effects: [{ kind: "note", text: "Your casting check's total is the Counteract DC against one ongoing spell or effect: Critical, it collapses and cannot be recast for 1 minute; Success, one variable (duration, area …) is halved; Failure, it persists. Applied by hand." }],
    warpMods: [{}],
    level: "not", what: "counteracting an ongoing effect: read off the casting check by hand",
    text: "*Not automated:* the spell is cast and its check rolled, but TRG Prime has no counteract against an ongoing spell or effect that halves one of its variables; read the result off the casting check and apply it by hand (the +2 PP option likewise)."
  },
  "PARADOX WEAVE": {
    // v1.6 L8525 prints "**Target** 1 willing creature"; the extractor lost the
    // line until 0.10.0 (Block 7 audit §6, Graham's Q166).
    targets: "1 willing creature",
    effects: [
      { kind: "condition", target: "targets", condition: "quickened" },
      { kind: "note", text: "The extra action may only be used for Strike, Stride or Step." },
      { kind: "note", text: "When the spell ends the target rolls a Will save against your Spell DC: Failure, slowed 1 for as many rounds as it was quickened; Fumble, also 2d6 essence damage and a minor essence critical. Applied by hand." }
    ],
    warpMods: [{ extraTargets: 1 }],
    level: "partly", what: "quickened (Strike, Stride or Step), +1 target warp; the closing Will save by hand",
    text: "*Partly automated:* the target is quickened (Strike, Stride or Step only, as Haste's note), and the +2 PP option adds a target. *Not automated:* renewing it each round you sustain, and the Will save when the spell ends (slowed 1 for as many rounds; on a Fumble 2d6 essence and a minor essence critical) — roll and apply them by hand."
  },
  /* -------------------------- Sorcerer, any -------------------------- */
  "ANCIENT AEGIS": {
    effects: [
      { kind: "tempHP", target: "self", formula: "20" },
      { kind: "note", text: "Once the barrier runs out of HP it is destroyed and the spell cannot be cast again for 10 minutes." }
    ],
    warpMods: [{}, { tempHPBonus: 5 }, {}],
    level: "partly", what: "the 20 HP barrier as temporary HP (+5 per warp); the lockout and the ally by hand",
    text: "*Partly automated:* the barrier's 20 HP are temporary hit points on you, so damage is taken from them first; each +1 PP \"increase the HP\" option adds 5. *Not automated:* the temporary hit points absorb any damage, not only attacks that hit; the 10-minute lockout once the barrier is destroyed; the +1 PP extra minute; and the +2 PP option's ally, who shares the one pool — keep these by hand."
  },
  "EVERSHADE VEIL": {
    effects: [
      { kind: "condition", target: "self", condition: "concealed" },
      { kind: "note", text: "A creature that strikes you through the veil takes 1d8 mental damage (basic Will). Rolled by hand." }
    ],
    warpMods: [{}, {}, {}, {}],
    level: "partly", what: "concealed for the duration; the backlash and the four warps by hand",
    text: "*Partly automated:* you are concealed while you sustain the veil. *Not automated:* the 1d8 mental backlash (basic Will) on a creature that strikes through it, and all four warping options — roll and apply them by hand."
  },
  "LEY BOLT": {
    category: "attack", targets: "1 creature", damage: { formula: "2d6", type: "force" },
    warpMods: [{ damageDice: "1d6" }, { rangeOverride: "90 feet" }, {}, {}, {}],
    level: "partly", what: "spell attack, 2d6 force; +1d6 and +30 ft warps; ricochet, ley sensitivity and stun by hand",
    text: "*Partly automated:* a spell attack for 2d6 force damage (Base Damage 1d6 is the step the first warp adds), and the +2 PP range option (90 feet). *Not automated:* the ricochet (half damage, −2 to the original attack per extra target, at most three), the ley-sensitive bolt against concealed and hidden targets, and the stunning Fortitude save — apply them by hand."
  },
  /* ------------------------ Sorcerer birthrights ------------------------ */
  "DISRUPTING MAGIC": {
    effects: [{ kind: "note", text: "Your casting check is a Dispel (Power Manipulation) check against the incoming spell, and the PP spent are the Dispel's (Q23: they replace the spell's own 1 PP)." }],
    level: "3b", what: "a reaction to a spell cast within 120 ft: the casting check as a Dispel",
    text: "*Automated (0.6.0, TRG Prime 3.681.0):* when a creature within 120 feet that is not your ally casts a spell that would land, you are asked (your player, else the GM; 30 seconds). Not while you could not cast it (a Rage, an antimagic zone or a Magic Suppression area, a critical injury), nor when you could not roll the Dispel (it is a Trained action, in Power Manipulation, and a Concentrate one, which a Fixated creature cannot take). Yes makes the core's Dispel (Power Manipulation) check against it, at the PP you declare, opened on the spell's PP and its caster's spell DC, and spends your reaction once it is rolled (a dialog closed unrolled costs nothing); the PP spent are the Dispel's, in place of this spell's 1 PP (Q23). On a Success or better the spell is stopped before it resolves, and resolves as a failure for its caster (Q33); if not, the next creature in reach who has it may try."
  },
  "DRACONIC INFUSION": {
    effects: [{ kind: "note", text: "Your Claw attacks deal an extra 1d6 secondary damage of your dragon type for the duration." }],
    // 0.9.0 (Block 6, group A, Appendix A note 15): the "+1d6 (max 5d6)" warp is
    // counted as `bonusValue` (no row of this spell reads it), so the claw
    // rider (module/block6a-automations.mjs) can read how many were bought.
    warpMods: [{ durationText: "10 minutes" }, { bonusValue: 1, bonusMax: 4 }, {}],
    level: "partly", what: "the claws' extra 1d6 by dragon type, +1d6 a warp (max 5d6), as a strike rider for the duration (Block 6); the weapon-trait warp by hand",
    text: "*Partly automated (0.9.0, TRG Prime 3.684.0):* once the cast succeeds, your Claw attacks (the Dragon Claws, or any natural attack named Claw or Claws, Q100) deal 1d6 secondary damage of your dragon type's energy for 1 minute (10 minutes with the +2 PP option), +1d6 for each \"+2 PP: +1d6\" option (max 5d6), +1 die more with Blood of the Wyrm. Without a dragon type chosen (Dragon Claws' Use), the card says so and nothing is laid. *Not automated:* the +4 PP weapon-trait option — add the trait by hand."
  },
  "TOUCH OF HEALING": {
    targets: "1 willing creature",
    effects: [
      { kind: "heal", target: "targets", formula: "2d6" },
      { kind: "note", text: "When targeting yourself, the casting component becomes verbal and the AP is 1." }
    ],
    warpMods: [{ healDice: "1d6" }],
    level: "automated", what: "heals 2d6, +1d6 per warp",
    text: "*Automated (TRG Prime 3.680.0):* the target heals 2d6 hit points, and each +1 PP option adds 1d6. On yourself it is a 1 AP verbal casting: the card says so, and the AP is yours to count."
  },
  "STORING RUNE": {
    effects: [{ kind: "spellStoring", label: "Storing Rune", target: "self", host: "spell" }],
    warpMods: [{ durationText: "1 hour" }, { durationText: "until next daily preparation" }, {}, { storedReleaseReaction: true }, { storedReleaseFree: true }],
    level: "partly", what: "the core's spell storing: the next spell is stored and released later",
    text: "*Partly automated (TRG Prime 3.680.0):* the core's spell storing, as Spell Storing: the next spell you cast is stored and released later, and the duration, reaction and free-action options apply. *Not automated:* the +2 PP option's additional stored spell."
  },
  "STORM BOLT": {
    category: "attack", targets: "1 creature", damage: { formula: "1d12", type: "electricity" },
    effects: [{ kind: "damageTypeChoice", damageTypes: ["acid", "cold", "electricity", "fire"], label: "Storm Bolt", printSource: true }],
    level: "automated", what: "spell attack, 1d12 of a type chosen at the cast (GM's call by location)",
    text: "*Automated (TRG Prime 3.680.0):* a spell attack for 1d12 damage; the type is chosen at the cast from cold, acid, fire and electricity, as Energy Bolt's is. Which fits your location is the GM's call."
  },
  "SHADOW SHIFT": {
    effects: [
      { kind: "condition", target: "self", condition: "concealed" },
      { kind: "note", text: "Against the incoming attack only; remove it once that attack is resolved (or at the end of your next turn with the +2 PP option)." }
    ],
    warpMods: [{ durationText: "until the end of your next turn" }, {}],
    level: "partly", what: "cast as your reaction: concealed; removed after the attack by hand; hidden warp by hand",
    text: "*Partly automated:* cast it as your reaction when a melee attack comes: you become concealed. *Not automated:* it is not yet offered by the attack itself (Block 3b), and the condition is removed by hand once the attack is resolved, or at the end of your next turn with the +2 PP option; the +5 PP option's hidden is applied by hand."
  },
  /* ------------------------------ Witch ------------------------------ */
  "LIFE BOOST": {
    targets: "1 creature",
    effects: [{ kind: "healingRate", target: "targets", rate: "fastHealing", value: 1, label: "Life Boost" }],
    warpMods: [{ healingRateBump: 1, healingRateMax: 5 }, { extraTargets: 1 }],
    level: "automated", what: "fast healing 1 (+1 per warp, max 5), +1 target warp",
    text: "*Automated (TRG Prime 3.680.0):* the target gains fast healing 1 for the duration (each +2 PP option adds 1, to a maximum of 5), and the other +2 PP option adds a target."
  },
  "ABSORBENT BEARD": {
    effects: [{ kind: "note", text: "Storing a potion is a 1 AP manipulate action; drinking it a 0 AP action. Kept by hand." }],
    warpMods: [{}],
    level: "not", what: "storing and drinking liquids: by hand",
    text: "*Not automated:* storing a potion or liquid and drinking it are kept by hand; the hex lasts until your next daily preparation."
  },
  "ARMOURING": {
    effects: [
      { kind: "bonus", target: "self", slot: "naturalArmourFlat", bonusType: "naturalArmour", value: 2 },
      { kind: "bonus", target: "self", slot: "athletics", bonusType: "status", value: -2 },
      { kind: "bonus", target: "self", slot: "acrobatics", bonusType: "status", value: -2 }
    ],
    warpMods: [{ bonusValue: 1, bonusMax: 5 }],
    level: "automated", what: "natural armour DR 2, −2 status Athletics and Acrobatics; each warp +1 and −1 (max 5)",
    text: "*Automated (TRG Prime 3.680.0):* a +2 natural armour DR and a −2 status penalty to Athletics and Acrobatics for the duration; each +2 PP option raises both by 1, to a +5 bonus and a −5 penalty."
  },
  "BANEFUL MAGIC": {
    effects: [{ kind: "note", text: "In the area, Spellcraft checks (and other checks to cast spells) are Hard (DC +2), and every creature has a −2 status penalty to saving throws against magic. Applied by hand." }],
    warpMods: [{ durationText: "1 day" }, {}, { durationText: "permanent" }],
    level: "not", what: "the area's Hard casting and save penalty: by hand",
    text: "*Not automated:* TRG Prime has no area that makes casting Hard and lowers saves against magic for whoever stands in it; apply both by hand. The duration options set the spell's duration."
  },
  "BANEFUL WEAPON": {
    targets: "one weapon",
    effects: [{ kind: "note", text: "The weapon gains the Bane weapon rune against the creature type chosen when the hex is invoked. Applied by hand." }],
    warpMods: [{}, { durationText: "1 hour" }],
    level: "not", what: "the Bane rune on a weapon: by hand",
    text: "*Not automated:* the Bane rune against a chosen creature type is added to the weapon by hand (the core's rune grant has no creature-type choice)."
  },
  "BULGING EYES": {
    effects: [
      { kind: "bonus", target: "self", slot: "perception", bonusType: "status", value: 4, note: "visual" },
      { kind: "bonus", target: "self", slot: "diplomacy", bonusType: "status", value: -4 },
      { kind: "bonus", target: "self", slot: "deception", bonusType: "status", value: -4 },
      { kind: "bonus", target: "self", slot: "intimidate", bonusType: "status", value: -4 }
    ],
    warpMods: [{ durationText: "1 hour" }],
    level: "partly", what: "+4 Perception, −4 Diplomacy, Deception, Intimidate; the visual-only limit by hand",
    text: "*Partly automated:* +4 status to Perception and −4 status to Diplomacy, Deception and Intimidate for the duration, and the +2 PP hour. *Not automated:* the +4 is for visual Perception checks only — leave it off a check made by hearing or smell."
  },
  "CACKLE": {
    effects: [{ kind: "note", text: "Sustain one of your spells: use its Sustain button." }],
    level: "not", what: "a free sustain: sustain the spell from its own card",
    text: "*Not automated:* casting Cackle does not sustain anything by itself; sustain the spell you choose from its own Sustain button, and count the hex's PP."
  },
  "CLOAK OF THE DECEIVER": {
    effects: [
      { kind: "bonus", target: "self", slot: "deception", bonusType: "status", value: 6, note: "to keep your disguise" },
      { kind: "note", text: "Your appearance, voice and scent are disguised as another creature of the same body shape." }
    ],
    warpMods: [{ durationText: "10 minutes" }, {}, {}],
    level: "partly", what: "+6 status Deception while sustained; the disguise itself by hand",
    text: "*Partly automated:* +6 status to Deception while the hex lasts (for checks to keep the disguise — leave it off any other), and the +2 PP 10 minutes. *Not automated:* the disguise itself and the two +4 PP shapes are the table's."
  },
  "DELAY AFFLICTION": {
    targets: "1 creature",
    effects: [{ kind: "note", text: "Choose fatigued, frightened or sickened: the target ignores it until the hex ends, once per daily preparation. Applied by hand." }],
    warpMods: [{ durationText: "10 minutes" }, {}, {}, { durationText: "1 hour" }],
    level: "not", what: "delaying one chosen condition: by hand",
    text: "*Not automated:* TRG Prime has no delay of a chosen condition; keep it by hand. The duration options set the spell's duration."
  },
  "FAMILIAR SENSES": {
    targets: "your familiar",
    effects: [{ kind: "note", text: "One of your senses is linked to your familiar's; checks with it use the familiar's skill bonus, and you may Aid. Kept by hand." }],
    warpMods: [{}, {}],
    level: "not", what: "sharing a sense with the familiar: by hand",
    text: "*Not automated:* the linked sense is the table's; roll its checks on the familiar's sheet. The duration is 10 minutes (S) (m150)."
  },
  "HEMOCOVENANT": {
    // The 1 AP version is the one modelled: a touch, somatic (the 2 AP
    // version's 30 feet and verbal component are in the note).
    castAP: 1, range: "touch", components: { somatic: true, verbal: false, material: false, focus: false },
    targets: "1 willing creature",
    effects: [
      { kind: "heal", target: "targets", formula: "1d8" },
      { kind: "note", text: "You lose the HP the target recovers, but not below 1 HP. The 2 AP version is 1d8 + Charisma, within 30 feet. Each Sustain repeats the transfer." }
    ],
    warpMods: [{ healDice: "1d8" }, { extraTargets: 1 }],
    level: "partly", what: "the target heals 1d8 (+1d8, +1 target warps); your HP loss, the 2 AP mode and sustains by hand",
    text: "*Partly automated:* the target heals 1d8 (the 1 AP version), +1d8 per +1 PP option, and the +2 PP option adds a target. *Not automated:* the HP you lose (not below 1), the 2 AP version's 1d8 + Charisma at 30 feet, and the repeat each time you sustain — apply them by hand. The printed \"1d8 + Charisma HP +\" is read as \"1d8 + Charisma HP\" (Q22: the stray \"+\" is a typo)."
  },
  "HEX WARD": {
    targets: "1 creature",
    effects: [{ kind: "note", text: "+1 status to DB (and, with the +2 PP option, to saving throws) against creatures of the type you designate. Applied by hand." }],
    warpMods: [{}, {}, { extraTargets: 1 }],
    level: "not", what: "a DB bonus against one creature type: by hand",
    text: "*Not automated:* the bonus counts against one creature type only, and TRG Prime has no chooser for it; add it by hand against those creatures. The +2 PP option for another target applies."
  },
  "MALICIOUS SHADOW": {
    category: "attack", targets: "1 creature", damage: { formula: "1d10", type: "bludgeoning", addAbility: "casting" },
    effects: [
      { kind: "damageTypeChoice", damageTypes: ["bludgeoning", "piercing", "slashing"], label: "Malicious Shadow" },
      { kind: "note", text: "Each time you sustain the hex the shadow Strikes again, and it uses and adds to your multiple attack penalty." }
    ],
    warpMods: [{ damageDice: "1d10" }],
    level: "partly", what: "a melee spell attack for 1d10 + magical ability, type chosen; the Strike on each sustain by hand",
    text: "*Partly automated:* when you invoke the hex the shadow makes a spell attack for 1d10 plus your magical ability score, bludgeoning, piercing or slashing as you choose, and each +2 PP option adds 1d10. *Not automated:* the Strike each time you sustain it (cast its attack again from the card), the multiple attack penalty it shares with you, and the shadow vanishing in darkness or all-round light."
  },
  "MISSED CHANCE": {
    targets: "one enemy",
    effects: [{ kind: "note", text: "An enemy within 30 feet that succeeds at an attack check, saving throw or skill check rerolls and takes the second result; not if the d20 exploded. Immune for 1 hour after." }],
    level: "3b", what: "a reaction reroll of an enemy's success",
    text: "*Automated (0.6.0, TRG Prime 3.681.0):* when an enemy within 30 feet hits with an attack, or succeeds (Success or better, Q26) at a saving throw or skill check, you are asked (your player, else the GM; 30 seconds). Yes casts this hex as your reaction, with its casting check and PP; once it is cast they reroll: fresh dice under the same modifiers less any Conviction die (Q27), and the second result is locked against every other effect. Not if the d20 exploded (Q29). They are then immune to Missed Chance for an hour (Q30)."
  },
  "PHASE FAMILIAR": {
    targets: "your familiar",
    effects: [{ kind: "note", text: "Against the triggering damage only, your familiar gains resistance to all damage and immunity to precision damage (immunity with the +10 PP option)." }],
    warpMods: [{}],
    level: "3b", what: "a reaction to the familiar taking damage",
    text: "*Automated (0.6.0, TRG Prime 3.681.0):* when your familiar within 60 feet is about to take damage (a weapon's, a spell's or typed damage), you are asked. Yes casts this hex as your reaction, and against that damage the familiar has resistance to all damage and immunity to its precision part; take the +10 PP warp in the cast for immunity instead. A spell's damage is covered for that whole casting, and a weapon's for the whole strike, its runes and riders included. Damage a spell goes on dealing on a later turn (a wall, a storm, an emanation, a hazard) is asked about too, for that blow. *Not offered:* a turn's bleeding or burning, or damage of no type."
  },
  "PREHENSILE TAIL": {
    effects: [
      { kind: "bonus", target: "self", slot: "climbing", bonusType: "circumstance", value: 4 },
      { kind: "note", text: "The tail carries an extra item, and may Trip using your Spellcraft bonus in place of your attack bonus." }
    ],
    warpMods: [{ durationText: "10 minutes" }],
    level: "partly", what: "+4 circumstance Climbing; the trip with Spellcraft by hand",
    text: "*Partly automated:* +4 circumstance to Climbing for the duration, and the +2 PP 10 minutes. *Not automated:* the third limb and the Trip made with your Spellcraft bonus — roll it by hand."
  },
  "PROPHETIC WARNING": {
    effects: [{ kind: "note", text: "Before an attack check, saving throw or skill check, the check gains advantage. Immune for 1 hour after." }],
    level: "3b", what: "a reaction giving advantage before a check",
    text: "*Automated (0.6.0, TRG Prime 3.681.0):* before your own attack check, saving throw or skill check that has a DC, you are asked. Yes casts this hex as your reaction, and the check gains advantage (a disadvantage cancels it, as any advantage). You are then immune to it for an hour. With the module setting \"Prophetic Warning: offer before each check\" off (it is the table's, since a check is often rolled on another client), cast it from the sheet instead: your next attack check, save or skill check gains advantage (Q31)."
  },
  "PURITY HEX": {
    effects: [{ kind: "note", text: "Creatures within 10 feet of you are immune to poison effects of PP (or level) no higher than the hex's, and gain +2 circumstance to resist stronger ones. Applied by hand." }],
    warpMods: [{ durationText: "1 hour" }],
    level: "not", what: "poison immunity by PP around you: by hand",
    text: "*Not automated:* immunity to poison by the effect's PP or level is judged at the table; the +2 PP hour sets the duration."
  },
  "SECOND CHANCE": {
    targets: "one ally",
    effects: [{ kind: "note", text: "An ally within 60 feet that fails an attack check, saving throw or skill check rerolls and takes the second result. Immune for 1 hour after." }],
    level: "3b", what: "a reaction reroll of an ally's failure",
    text: "*Automated (0.6.0, TRG Prime 3.681.0):* when an ally within 60 feet misses with an attack, or fails (Failure or worse, Q26) a saving throw or skill check, you are asked (your player, else the GM; 30 seconds). Yes casts this hex as your reaction, with its casting check and PP; once it is cast they reroll: fresh dice under the same modifiers less any Conviction die (Q27), and the second result is locked against every other effect. They are then immune to Second Chance for an hour (Q30)."
  },
  "SIPHON VITAE": {
    // The 2 AP version is the one modelled (somatic, verbal; a basic save).
    castAP: 2, components: { somatic: true, verbal: true, material: false, focus: false },
    category: "save", targets: "1 creature", defence: "Basic Fortitude", damage: { formula: "1d8", type: "essence", addAbility: "charisma" },
    effects: [{ kind: "note", text: "You heal the full damage dealt (half, rounded up, with the 1 AP ranged spell attack version). Applied by hand." }],
    warpMods: [{ damageDice: "1d8" }, { extraTargets: 1 }, {}],
    level: "partly", what: "the 2 AP version: basic Fortitude against 1d8 + Charisma essence; the healing and the 1 AP version by hand",
    text: "*Partly automated:* the 2 AP version — a basic Fortitude save against 1d8 + Charisma essence damage, +1d8 and +1 target per +2 PP option. *Not automated:* the healing you gain (the full amount; half with the 1 AP version), the 1 AP ranged spell attack version, and the +3 PP Soul Drain — apply them by hand."
  },
  "TENTACLE": {
    effects: [{ kind: "note", text: "The tentacles make grapple attacks using your Spellcraft bonus in place of your attack bonus." }],
    warpMods: [{ durationText: "10 minutes" }],
    level: "not", what: "grapples with Spellcraft: by hand",
    text: "*Not automated:* roll the grapple attacks with your Spellcraft bonus by hand; the +2 PP option sets the duration."
  },
  "WEAKENED ELEMENT": {
    targets: "1 creature",
    effects: [{ kind: "note", text: "The target gains weakness to acid, cold, electricity or fire (sonic or force with the warps) while you sustain the hex. Applied by hand." }],
    warpMods: [{}, {}],
    level: "not", what: "a chosen weakness: by hand",
    text: "*Not automated:* TRG Prime's defence rail grants a named type and has no chooser (as Resist Energy's note says); add the weakness to the target by hand."
  }
};

const GRIMOIRE_SPEC = {
  "OBSERVE THE WEAVE": {
    // Triggered or chosen later: no save is rolled at the cast.
    category: "utility", defence: "",
    text: "*Not automated (a Grimoire spell, built early for the Arcanum birthright):* the tracking sight and the unwilling target's Will save are the table's.",
    level: "not", what: "scrying sight: by hand"
  },
  "MESSAGE RUNE": {
    text: "*Not automated (a Grimoire spell, built early for the Rune birthright):* the rune's message and its condition are the table's.",
    level: "not", what: "a recorded message: by hand"
  },
  // REBUILT IN 0.11.0 ON BLOCK 8a'S SYMBOL MODEL (Q184: D → B). The save is
  // still never the core's cast save (no defence): it is rolled when the GM
  // flashes the symbol (module/block8a-automations.mjs, by its key).
  "SYMBOL OF FEAR": {
    category: "utility", defence: "", key: "symbolOfFear",
    effects: [{ kind: "note", text: "Symbol of Fear: click where you carve it; the GM's card flashes it." }],
    text: symbolText("symbolOfFear"),
    level: "automated", what: "a hidden Region where it is carved; the GM flashes it: Will — unaffected / frightened 2 / frightened 4 and fleeing 1 round / frightened 6 and fleeing 1 round (Block 8a's Symbol model, 0.11.0)"
  },
  "SYMBOL OF DEATH": {
    category: "utility", defence: "", key: "symbolOfDeath",
    effects: [{ kind: "note", text: "Symbol of Death: click where you carve it; the GM's card flashes it." }],
    text: symbolText("symbolOfDeath"),
    level: "automated", what: "a hidden Region where it is carved; the GM flashes it: Fortitude — unaffected / a deadly essence critical / death; a death ends it (m132); its PP locked while it lasts (Q170) (Block 8a's Symbol model, 0.11.0)"
  },
  "DARK WHISPERS": {
    text: "*Not automated (a Grimoire spell, built early for the Umbral birthright):* the whispered conversation is the table's; the warps set the targets and duration.",
    level: "not", what: "speech through a shadow: by hand",
    warpMods: [{ extraTargets: 1 }, { durationText: "10 minutes" }]
  }
};

/** specialistClass, by the rule in the header. */
function specialistClassOf(entry) {
  const traits = entry.traits.map((t) => t.toUpperCase());
  // The Spellblade's since Block 4 (0.7.0).
  for (const [trait, cls] of [["ARCHMAGE", "Archmage"], ["SORCERER", "Sorcerer"], ["WITCH", "Witch"], ["SPELLBLADE", "Spellblade"]]) if (traits.includes(trait)) return cls;
  if (entry.name === "STORING RUNE") return "Rune, Runemage";
  if (traits.includes("BLOODMAGE")) return "Bloodmage";
  const br = String(entry.fields.Birthright ?? "").trim();
  if (br && br !== "Any") return br.split(/\s/)[0];
  return "";
}

/** One spell from its book entry and its spec. Exported for Block 4 (0.7.0). */
export function build(entry, spec, { specialist }) {
  const parsed = castOf(entry.fields.Cast);
  const castAP = spec.castAP ?? parsed.castAP;
  const components = spec.components ?? parsed.components;
  const duration = String(entry.fields.Duration ?? "");
  const warps = printedWarps(entry.lines).map((w, i) => ({ ...w, mods: { ...(spec.warpMods?.[i] ?? {}) } }));
  const flags = {};
  if (entry.traits.includes("HEX")) flags.eaHex = true;
  if (entry.fields.Birthright) flags.eaBirthright = String(entry.fields.Birthright).split(/\s/)[0];
  const doc = spell({
    name: titleCase(entry.name),
    description: describe(entry, spec.text),
    tradition: specialist ? "" : String(entry.fields.Tradition ?? "").split(",").map((t) => t.trim().toLowerCase()).filter(Boolean).map((t) => (t === "divine" ? "divinity" : t)).join(", "),
    category: spec.category ?? (/\bSAVE\b/.test(entry.traits.join(" ")) && entry.fields["Saving Throw"] ? "save" : "utility"),
    ppCost: entry.pp,
    castAP,
    range: spec.range ?? String(entry.fields.Range ?? ""),
    area: String(entry.fields.Area ?? ""),
    targets: spec.targets ?? String(entry.fields.Targets ?? entry.fields.Target ?? ""),
    duration,
    defence: spec.defence ?? String(entry.fields["Saving Throw"] ?? ""),
    traits: traitWords(entry.traits),
    effects: spec.effects ?? [],
    components,
    flags,
    baseDamage: String(entry.fields["Base Damage"] ?? ""),
    damage: spec.damage ?? null,
    sustained: sustainedDuration(duration),
    sustainType: sustainedDuration(duration) ? "duration" : "",
    warps
  });
  if (specialist) {
    doc.system.specialist = true;
    doc.system.specialistClass = specialistClassOf(entry);
  }
  return doc;
}

const BY_NAME = new Map(BOOK.specialist.map((e) => [e.name, e]));
const GRIM = new Map(BOOK.grimoire.map((e) => [e.name, e]));

export const BLOCK3_SPECIALIST = Object.keys(SPEC).map((name) => {
  const entry = BY_NAME.get(name);
  if (!entry) throw new Error(`Block 3: no specialist spell "${name}" in the book`);
  return build(entry, SPEC[name], { specialist: true });
});

/**
 * Every Grimoire (Chapter 8) spell is uncommon (ruling m84 "as proposed";
 * marked on the built ones from 0.10.0, Graham's Q166): the core's
 * `system.availability`, which its level-up picks warn on (page 235).
 */
export const GRIMOIRE_AVAILABILITY = "uncommon";

export const BLOCK3_GRIMOIRE = Object.keys(GRIMOIRE_SPEC).map((name) => {
  const entry = GRIM.get(name);
  if (!entry) throw new Error(`Block 3: no Grimoire spell "${name}" in the book`);
  const doc = build(entry, { effects: [], ...GRIMOIRE_SPEC[name] }, { specialist: false });
  doc.system.availability = GRIMOIRE_AVAILABILITY;
  // THE SYMBOLS' KEY (0.11.0): Block 8a's automations find them by it.
  if (GRIMOIRE_SPEC[name].key) doc.flags = { ...doc.flags, "trg-prime": { ...(doc.flags?.["trg-prime"] ?? {}), eaGrimoire: GRIMOIRE_SPEC[name].key } };
  return doc;
});

/** What each of the 39 does in TRG Prime, for the docs and the harness. */
export const SPELL_AUTOMATION = Object.freeze(Object.fromEntries([
  ...Object.entries(SPEC).map(([n, s]) => [titleCase(n), Object.freeze({ level: s.level, what: s.what })]),
  ...Object.entries(GRIMOIRE_SPEC).map(([n, s]) => [titleCase(n), Object.freeze({ level: s.level, what: s.what })])
]));

if (BLOCK3_SPECIALIST.length !== 34) throw new Error(`Block 3: ${BLOCK3_SPECIALIST.length} specialist spells, expected 34`);
if (BLOCK3_SPECIALIST.filter((s) => s.flags?.["trg-prime"]?.eaHex).length !== 21) throw new Error("Block 3: expected 21 hexes");
