/**
 * Eldritch Arts — Block 6 (0.9.0), group C: the five Runemage class feats
 * (the core's own archetype; Appendix C) and the fourteen Sorcerer,
 * Spellblade and Martial class feats (Appendix F).
 *
 * The spec is docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md as Graham answered it on
 * 4 November 2026 (Q89–Q149: as proposed; Q89, one release), on TRG Prime
 * 3.684.0's seams as built (b6-contracts.md: G3, G5, G9, G12, G14, G20, G25,
 * G26, and G1 for Ley-Etched Symbol's discount).
 *
 * Every feat is built with block6-common.mjs's `classFeat`, so its card is
 * the book's text followed by one paragraph saying what TRG Prime does with
 * it. What is data lives here (declarations the core reads); the Uses,
 * registrations and hooks are module/block6c-automations.mjs.
 *
 * RUNEMAGE IS THE CORE'S ARCHETYPE: the trait is authored "Runemage" and is
 * not registered (the core's own gate opens these five to its owners).
 *
 * FLAGS under the system's scope are TRG Prime's declarations (runemage,
 * meleeAbility, spellDamageBonus), except the module's own `ea…` keys.
 */
import { classFeat } from "./block6-common.mjs";
import { declaredEffect } from "./builders.mjs";

/** Combat Inscription's declaration (G25): no defensive +2, and the room line's words. */
export const COMBAT_INSCRIPTION_RUNEMAGE = Object.freeze({ defensiveIncrease: 0, roomNote: "a hand-sized space suffices (Combat Inscription)" });

/* ------------------------------------------------------------------ */
/* Runemage (Appendix C)                                                */
/* ------------------------------------------------------------------ */

export const RUNEMAGE_FEATS_B6_C = [
  classFeat("PREPARED SIGIL", {
    flags: { eaAutomation: "preparedSigil" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0; Graham's Q123, Q124):* daily preparation clears yesterday's sigil and says so; then **Use** (once until your next daily preparation) inscribes it: choose one spell you can cast today (the core's own availability), not an innate spell, and one with a component the Symbol replaces (verbal, material or focus). When you cast that spell from the sheet you are asked \"Activate your Prepared Sigil?\": yes casts it through the core's prepared-Symbol cast — no free hand for the Symbol and no room to draw, 1 AP less casting time (never below 1 AP; it stacks with Quicken), PP and the Runemage DCs as usual, a Somatic component still needs its hand, focus or implement. The sigil fades when that cast settles (a Fumble too); a cast cancelled or refused before it settles, or called off at the target picker, keeps it. A cast made through another route (a reaction, a ritual, a Strike, an item) is not asked."
  }),
  classFeat("RUNIC RESERVOIR", {
    flags: { eaAutomation: "runicReservoir" },
    automation: "*Automated (0.9.0):* Prepared Sigil's Use inscribes up to three sigils, each a different spell, each spent separately. Only one sigil may be activated a round: in combat, one a round; out of combat, one in any 6 seconds of world time. A second activation is not offered."
  }),
  classFeat("LIVING SCRIPT", {
    flags: { eaAutomation: "livingScript" },
    automation: "*Automated (0.9.0):* an activated sigil is not lost: it is unusable for 1 minute, then ready again — after 10 rounds of the same combat or 60 seconds of world time, whichever comes first. A Heroic result on the sigil's cast keeps it ready at once. The one-a-round limit still holds."
  }),
  classFeat("COMBAT INSCRIPTION", {
    flags: { runemage: { ...COMBAT_INSCRIPTION_RUNEMAGE } },
    automation: "*Automated (TRG Prime 3.684.0, G25):* when you cast defensively, the Runemage's +2 to the Casting DC is not added: the DC part reads \"Runemage, defensive (Combat Inscription)\" at −1 (the Runemage −1 stands). The cast card's room line says a hand-sized space suffices; the room is still the table's call, as the core leaves it. The free hand the Symbol needs, and Somatic components, are unchanged."
  }),
  classFeat("LEY-ETCHED SYMBOL", {
    flags: { eaAutomation: "leyEtchedSymbol" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G1; Graham's Q125, Q93):* while you are gaining a benefit of Tap or Channel Ley Line (the module's ley-benefit marker, for that benefit's printed duration — standing in a ley-line area alone does not count), the Warp? dialog of a spell you cast with a Symbol (not an innate spell) offers **Ley-Etched Symbol**: 1 PP off what the cast pays, never below 1 PP. The Casting DC, the cap and the save DC still read the PP as cast (Q93). Once a round: in combat, one cast a round; out of combat, one in any 6 seconds. If that cast's check is a Fumble or Blunder, you also roll the Ley Line Effects table's Backlash column at that line's level, lasting to the end of your next turn."
  })
];

/* ------------------------------------------------------------------ */
/* Sorcerer, Spellblade and Martial (Appendix F)                        */
/* ------------------------------------------------------------------ */

const consideredAttack = classFeat("CONSIDERED ATTACK", {
  flags: { eaAutomation: "consideredAttack" },
  automation: "*Automated (0.9.0; Graham's Q145):* **Use** (Considered Strike): choose the weapon and strike your target as the core's Strike, paying 1 AP more (2 AP for an ordinary Strike) for +2 untyped to that attack. Once a Strike. Your ordinary Strike buttons are unchanged. Built with the Martial trait only: \"Class\" is the feat's category, not a trait."
});
// "CLASS MARTIAL": Class is the category (Appendix F, Minor). The card keeps the printed line.
consideredAttack.system.traits = "Martial";

export const SORCERY_FEATS_B6_C = [
  classFeat("ARCANE STUDY", {
    flags: { eaAutomation: "arcaneStudy" },
    automation: "*Automated (0.9.0; Graham's Q142, Q100):* offered only to a Sorcerer with the Arcanum birthright, or a High Mage or Birthrager who chose it. Your book starts empty. **Use** → *Scribe a spell*: an arcane spell of PP 1 to your caster level + 1, not a specialist spell, at Learn a Spell's time, materials and Arcana check, the degree's outcome as the core's. The book is a list on this feat, so nothing in it is castable by itself. At daily preparation you choose one book spell: one you do not know is added to your repertoire for the day (removed at the next preparation; it does not count against your repertoire); one you know has its warping cost lowered by 1 (taken off the spell's total warp, minimum 1, the core's per-spell warp discount) until the next preparation. If you missed the question, **Use** → *Today's pick* makes it once."
  }),
  classFeat("BESPELL WEAPON", {
    flags: { eaAutomation: "bespellWeapon" },
    automation: "*Automated (0.9.0; Graham's Q143):* **Use** (free) on the turn you cast a spell (cantrips included; out of combat, after your last cast): choose a weapon you are wielding; it deals 1d6 secondary damage until the end of your turn, typed by the spell's school — Alteration or Translocation a physical type other than the weapon's (you choose), Enchantment, Insight or Shadow mental, Invocation a type the spell dealt (or force), Soul essence, Warding force. A spell with no school gives no type, and the Use says so. On a later turn, while the last one ran to the end of your previous turn, **Use** → *Sustain* (1 AP, Concentrate) keeps the same weapon and type for this turn. Casting a new spell and using it again replaces it."
  }),
  classFeat("BONDED INFUSION", {
    flags: { eaAutomation: "bondedInfusion" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0; Graham's Q144):* while you wield today's infused weapon (Infuse Weapon's), your casting checks take +2 item (the core's highest-only item stacking: it replaces the Casting Focus +1 rather than adding to it), whether or not you cast with a focus; not for innate or item casts, and set aside under High Magic as a focus is. While you wield it the weapon stands in for a Somatic component (the core's free-somatic declaration). While the infusion lasts this feat is a +1 spell adder (the core's spell adder: one spell a day at no PP). A focus caster still ticks Focus in hand on the sheet: the core's −2 for casting without a focus is not lifted by this feat. With no Infuse Weapon (an archetype's route in), nothing happens."
  }),
  classFeat("CALL BONDED WEAPON", {
    flags: { eaAutomation: "callBondedWeapon" },
    automation: "*Partly automated (0.9.0):* **Use** (1 AP, Manipulate): your Blade Ally's weapon or today's infused weapon (you choose if you have both) is equipped, regardless of range. It must be on your sheet; if another creature holds it, the card says so and the GM moves it. The two-hand limit is not checked by the Use (the core checks it only when you equip from the sheet): if your hands are full, unequip something."
  }),
  classFeat("CLEVER DAMAGE", {
    flags: { meleeAbility: { label: "Clever Damage", damage: ["intelligence"] } },
    automation: "*Automated (TRG Prime 3.684.0, G25):* a melee weapon Strike's damage uses the best of Strength, Weapon Finesse's Dexterity (where it applies) and Intelligence, never two at once. A Hand-and-a-Half grip's ×1.5 applies to whichever is used, as for Dexterity; Proper Hardman and Rage's Strength bonuses stay Strength's."
  }),
  classFeat("CLEVER STRIKE", {
    flags: { meleeAbility: { label: "Clever Strike", attack: ["intelligence"] } },
    automation: "*Automated (TRG Prime 3.684.0, G25):* a melee Strike's attack roll uses the best of Strength, Weapon Finesse's Dexterity (where it applies) and Intelligence, never two at once. Not a ranged Strike, and not a maneuver (Trip, Shove)."
  }),
  consideredAttack,
  classFeat("DANGEROUS SORCERY", {
    effects: [declaredEffect("spell damage + the spell's PP", "A damage-dealing spell without a duration gains a status bonus to damage equal to its PP cost.",
      { spellDamageBonus: { label: "Dangerous Sorcery", valueFrom: "spellPP", instantOnly: true, type: "status" } })],
    automation: "*Automated (TRG Prime 3.684.0, G12; Graham's Q146):* a damaging spell that prints no Duration adds its printed PP as a status bonus to its damage roll, once a cast (the primary pool; not a second pool, splash or recurring damage), named on the card. Warps and metamagic do not raise it; a cantrip adds 0."
  }),
  classFeat("HIGH MAGE’S FOCUS", {
    flags: { eaAutomation: "highMagesFocus" },
    automation: "*Automated (0.9.0):* **Use** chooses one High Magic spell you know (a spell with the Highmagic trait on your sheet), kept on this feat; when your BSB reaches +10 a card reminds you, and the Use chooses a second. Casting a chosen spell, its casting check takes +2 against its Casting DC (the DC lowered by 2): the casting's degree only, not the spell attack's total. Not for an innate or item cast."
  }),
  classFeat("HIGH MAGIC RESONANCE", {
    flags: { eaAutomation: "highMagicResonance" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G5, G9; Graham's Q147, Q100):* a Resonance event from your High Magic cast is rolled once: High Magic's disadvantage is lifted, and no other (Absolute Chaos still rolls twice more). The first casting check each day whose degree is a Fumble becomes a Failure (half PP, no fumble roll), by itself, said on the card; a Blunder is not eased, and an item's release is not a casting check. Daily preparation restores it. Not offered to a character with the Wild birthright (a High Mage's or Birthrager's pick counts)."
  }),
  classFeat("MAGICAL RETRIBUTION", {
    flags: { eaAutomation: "magicalRetribution" },
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0, G26; Graham's Q149):* while a spell's extra casting time holds your casting open, a melee Strike that damages you asks you (your reaction ready): yes spends it and makes an attack of opportunity at the attacker, resolved before the interruption's Failure or Fumble is rolled. An ordinary cast resolves in one moment, so there the provoked attack is the table's call: **Use** (your reaction) makes the attack of opportunity at your targeted attacker when the GM rules it landed during your casting."
  }),
  classFeat("METAMAGIC ADEPT", {
    flags: { eaAutomation: "metamagicAdept" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G3):* on a spell whose casting time is 1 or 2 AP, the Warp? dialog puts a \"pay in 1 AP instead\" tick on Extend, Reach, Silent and Still Spell — each only when you own that feat (the core offers the row only then). One option a cast: its PP are not paid, not capped and not in the save DC, while the Casting DC still counts them, and the cast costs 1 AP more. Not on an item cast. A Flourish: in combat the tick is not offered once you have used a Flourish this turn, and a cast that took it records this turn's Flourish when it settles (the core's trait record)."
  }),
  classFeat("RESONANCE SURGE", {
    flags: { eaAutomation: "resonanceSurge" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G5, G9, G25; Graham's Q148, Q100):* offered only to a Sorcerer with the Wild birthright. **Use** (its Focus use, spent as it is armed) arms your next levelled spell (not a cantrip, an innate spell, an item's, a ritual or a stored spell's release): the Warp? dialog applies **Resonance Surge** to it without a tick, so up to 2 PP of that spell's own warping options are free and add nothing to the Casting DC (the core's free-warp credit, through module metamagic); metamagic is not covered, an excess is paid as usual and an unused part is lost. Once that spell has resolved, a Resonance event is rolled as that cast's own (a High Magic cast's disadvantage and the suppressors apply), and the surge is spent; a cast called off at the target picker keeps it. Daily preparation disarms an unused surge."
  }),
  classFeat("SPELLBLADE’S MARK", {
    flags: { eaAutomation: "spellbladesMark" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G14, G20, G25):* **Use** (1 AP, Concentrate; its Focus use) marks your targeted enemy within 60 feet, replacing any earlier Mark. Against it: +1 circumstance to your melee Strikes' attacks, and to your spell attacks' totals against DB (not the casting check); 1d6 secondary force damage on your Strikes and spell attacks that damage it (not save spells); +1 circumstance to your DB against its attacks, weapons and spell attacks (a circumstance bonus: it does not stack with another circumstance bonus to your DB, and only the higher applies, as the core stacks defence rows by type). The Mark ends when the combat ends (a Mark made outside combat, when your next combat ends) or when you Mark another."
  })
];

export const FEATS_B6_C = [...RUNEMAGE_FEATS_B6_C, ...SORCERY_FEATS_B6_C];

/**
 * The docs' table: what each feat does in 0.9.0. A full, B automated with a
 * normal choice, C partial (the rest a card or the GM's), D descriptive.
 */
export const AUTOMATION_B6_C = Object.freeze({
  "Prepared Sigil": { level: "B", what: "Daily-prep reset; Use inscribes one castable non-innate Symbol spell; a prelude offers the sigil cast (castSpell preparedSymbol, G25: no hand or room for the Symbol, −1 AP); spent on settle, not on a refunded cast (Q123, Q124)." },
  "Runic Reservoir": { level: "A", what: "Three distinct sigils; one activation a round (combat round, or 6 s of world time)." },
  "Living Script": { level: "A", what: "A sigil reforms after 10 rounds or 60 s; a Heroic keeps it ready; the round lock holds." },
  "Combat Inscription": { level: "A", what: "Declares runemage { defensiveIncrease: 0, roomNote } (G25): no defensive +2; the room line's wording." },
  "Ley-Etched Symbol": { level: "B", what: "G1 option: −1 PP paid (floor 1, Q93) on a Symbol cast while the ley-benefit marker is on, once a round; Fumble/Blunder rolls the Ley Line backlash at that level (Q125). Needs the Block 2 marker wired (layLeyBenefitMarker)." },
  "Arcane Study": { level: "B", what: "Eligibility (Arcanum, Q100); Use scribes arcane spells by Learn a Spell (book on the feat); daily pick adds a day spell or a +1 warpDiscount (Q142)." },
  "Bespell Weapon": { level: "B", what: "Free Use after this turn's cast: a weapon-scoped 1d6 strikeRider typed by school, to the end of the turn; Sustain 1 AP Concentrate (Q143)." },
  "Bonded Infusion": { level: "A", what: "Spell-check gate +2 item while the infused weapon is held (not innate/item, set aside under High Magic); feat flags synced: spellAdder 1 while infused, freeSomatic while held (Q144)." },
  "Call Bonded Weapon": { level: "B", what: "1 AP Manipulate Use equips the Blade Ally or infused weapon; the hand budget is not checked (no core helper) and a weapon on another sheet is the GM's." },
  "Clever Damage": { level: "A", what: "Declares meleeAbility { damage: [intelligence] } (G25)." },
  "Clever Strike": { level: "A", what: "Declares meleeAbility { attack: [intelligence] } (G25)." },
  "Considered Attack": { level: "B", what: "Use: the core's Strike with +2 untyped, 1 extra AP (Q145)." },
  "Dangerous Sorcery": { level: "A", what: "Declared spellDamageBonus { valueFrom: spellPP, instantOnly, status } (G12, Q146)." },
  "High Mage’s Focus": { level: "B", what: "Use picks a known Highmagic spell (a second at BSB +10, with a reminder); gate +2 castingOnly on its casts." },
  "High Magic Resonance": { level: "A", what: "Resonance modifier single:true on High Magic (G5); daily Fumble → Failure remap (Q147); Wild barred (G9, Q100)." },
  "Magical Retribution": { level: "C", what: "Pending-cast step (G26): AoO offered before the interruption settles; elsewhere a reaction Use against the targeted attacker (Q149)." },
  "Metamagic Adept": { level: "B", what: "registerMetamagicPayment (G3): Extend/Reach/Silent/Still paid 1 AP, DC as if paid, 1–2 AP spells, one a cast; Flourish checked when offered, recorded on settle from the hooks' metamagicPayments." },
  "Resonance Surge": { level: "B", what: "Eligibility (Wild); Focus Use arms a marker; a required G1 metamagic answers freeWarpPP 2 on the next levelled learned cast (not ritual, item, stored, innate, threaded); that key forces the Resonance (G5, Q148) and spends the surge on settle (not refunded)." },
  "Spellblade’s Mark": { level: "B", what: "1 AP Concentrate Focus Use on a targeted enemy ≤ 60 ft: melee conditional, attack-only gate row (G14), strikeRider and spellDamageRider by uuid (G25), ward DB row typed circumstance (G20; TRG Prime 3.684.1 stacks it by type); ends with the combat." }
});
