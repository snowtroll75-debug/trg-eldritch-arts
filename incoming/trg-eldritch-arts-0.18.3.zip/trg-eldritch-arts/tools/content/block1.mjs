/**
 * Eldritch Arts — Block 1 (0.1.0): Chapter 2's four races, their eighteen
 * heritages and racial abilities, the twelve backgrounds and the nine
 * Eldritch Arts General feats they grant, Orb of Water (the Tidemarked's
 * cantrip, a Grimoire spell), and Chapter 6's exotic weapons and goods.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json (cut
 * from the v1.4 docx by extract-book.mjs, sidebars included), never retyped.
 * Each item's description is that text followed by what TRG Prime does with
 * it: *Automated*, *Partly automated* or *Not automated*, and why.
 *
 * As proposed in docs/ELDRITCH_ARTS_BLOCK1_AUDIT.md (B1-1 to B1-16), on TRG
 * Prime 3.675.0. Where a proposal is applied, the item says so.
 *
 * FLAGS under the system's scope (`flags.trg-prime`) are TRG Prime's
 * declarations. The module's own keys there are prefixed `ea`
 * (`eaElement`, `eaNullAuraFeet`, `eaAutomation`), which the system does not
 * read.
 */
import fs from "node:fs";
import {
  race, heritage, background, ability, feat, spell, weapon, gear,
  changesEffect, declaredEffect, racialSkillEffect, resistanceEffect, noteEffect, conditional, stableId
} from "./builders.mjs";
import { md } from "./markdown.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const CH2 = BOOK.chapter2;

/* ------------------------------------------------------------------ */
/* Shared                                                               */
/* ------------------------------------------------------------------ */

/** "AETHERIAL" → "Aetherial"; "VEL-THARIS" → "Vel-tharis" (the book's own casing in prose). */
export const RACE_NAME = Object.freeze({ AETHERIAL: "Aetherial", EMBERKIN: "Emberkin", NYRINN: "Nyrinn", SCAELYN: "Scaelyn" });
export const HERITAGE_NAME = Object.freeze({
  AERALIS: "Aeralis", ASTRYN: "Astryn", CAELARI: "Caelari", NERATHIS: "Nerathis", UMBRYTH: "Umbryth",
  STONEVEIN: "Stonevein", GALEBORNE: "Galeborne", CINDERBLOOD: "Cinderblood", TIDEMARKED: "Tidemarked",
  "VEL-THARIS": "Vel-tharis", "VIR-ELLIAN": "Vir-ellian", "ZHAL-VRYN": "Zhal-vryn",
  SPARKTAIL: "Sparktail", GLYPHWEAVE: "Glyphweave", DUSTSCALE: "Dustscale", IRONMUK: "Ironmuk", WISPERFIN: "Wisperfin", WYRMDRAL: "Wyrmdral"
});

/** The book's text as HTML, each printed line a paragraph. */
const printed = (lines) => md((lines ?? []).join("\n\n"));
const note = (text) => md(text);

/** A Base DR, in the shape the core companions carry it (scaled by your BDB). */
const baseDR = (value, label) => (id, n) => changesEffect(id, `${n}: Base DR ${value}`,
  [{ key: "system.combat.naturalArmourBase.natural", mode: 5, value: String(value), priority: 20 }],
  `${label} grants a base natural DR of ${value} (scaled by your BDB like any Base DR).`);

/** A burrow Speed; UPGRADE on `.base`, as Inner Tempest's swim and climb Speeds. */
const otherSpeed = (kind, value) => (id, n) => changesEffect(id, `${n}: ${kind[0].toUpperCase()}${kind.slice(1)} ${value} ft`,
  [{ key: `system.combat.movement.${kind}.base`, mode: 4, value: String(value), priority: 20 }],
  `A ${kind} Speed of ${value} feet.`);

/** Size and the attribute line, for the heritage that replaces the race's (Wyrmdral). */
const sizeOverride = (size) => (id, n) => changesEffect(id, `${n}: size`,
  [{ key: "system.identity.size", mode: 5, value: size, priority: 20 }],
  `${size[0].toUpperCase()}${size.slice(1)} size, instead of the race's.`);

/* ------------------------------------------------------------------ */
/* Elements                                                             */
/* ------------------------------------------------------------------ */

/**
 * The Emberkin's "elemental type (see below)": the element each heritage's
 * resistance names. Elemental Symbiosis reads it, and the heritage's own
 * language is that element's tongue (B1-1, as proposed; the Tianzhi
 * precedent of Graham's 21 October ruling for Inner Tempest).
 */
export const EMBERKIN_ELEMENTS = Object.freeze({
  Stonevein: Object.freeze({ damageType: "acid", language: "Gaian" }),
  Galeborne: Object.freeze({ damageType: "electricity", language: "Aeolian" }),
  Cinderblood: Object.freeze({ damageType: "fire", language: "Ignic" }),
  Tidemarked: Object.freeze({ damageType: "cold", language: "Aqualis" })
});

/** Wyrmdral: "acid, cold, electricity, fire or poison". */
export const WYRMDRAL_ELEMENTS = Object.freeze(["acid", "cold", "electricity", "fire", "poison"]);

/* ------------------------------------------------------------------ */
/* Racial abilities                                                     */
/* ------------------------------------------------------------------ */

const raceAbilityText = (raceKey, name) => {
  const text = CH2.races[raceKey]?.abilities?.[name];
  if (!text) throw new Error(`Block 1: the book has no ${raceKey} ability "${name}"`);
  return md(`**${name}:** ${text}`);
};
const sidebar = (title) => {
  const s = BOOK.sidebars.find((x) => x.title === title);
  if (!s) throw new Error(`Block 1: no sidebar "${title}"`);
  return s;
};

export const ABILITIES = [
  // AETHERIAL
  ability({
    name: "Ethereal Form", sourceRace: "Aetherial", usesPerDay: "1",
    description: `${raceAbilityText("AETHERIAL", "Ethereal Form")}\n${note("*Automated:* **Use** spends the day's use and puts a 1-minute effect on you that grants the **incorporeal** trait. That is the core's Incorporeal: immune to non-magical attack forms and precision damage, and resistant to all damage except force. It ends by itself after the minute; delete it to end it early. Daily preparation restores the use.")}`
  }),
  ability({
    name: "Aetherial Magic", sourceRace: "Aetherial",
    description: `${raceAbilityText("AETHERIAL", "Aetherial Magic")}\n${note("*Granted by the race:* Mage Hand and Read Aura are added as spells you cast with a Spellcraft check (not innate), as the core's racial cantrips are.")}`
  }),
  ability({
    name: "Aetherial Resonance", sourceRace: "Aetherial",
    description: `${raceAbilityText("AETHERIAL", "Aetherial Resonance")}\n${note("*Automated:* +1 racial to the save DC of every spell you cast, innate spells included, named on the cast card.")}`,
    effects: [declaredEffect("spell save DCs +1", "All of your Spell Save DCs are increased by 1.",
      { spellDCBonus: { label: "Aetherial Resonance", value: 1, type: "race" } })]
  }),
  // EMBERKIN
  ability({
    name: "Elemental Surge", sourceRace: "Emberkin",
    description: `${raceAbilityText("EMBERKIN", "Elemental Surge")}\n${note("*Automated (TRG Prime 3.675.0):* your Charisma total is added as a racial bonus to each spell's damage roll, named on the card. A spell's second pool, splash and recurring damage are not its damage roll and take nothing; healing is not damage.")}`,
    effects: [declaredEffect("spell damage + Charisma", "You add your Charisma ability score as a racial bonus to all spell damage rolls.",
      { spellDamageBonus: { label: "Elemental Surge", valueFrom: "charisma", type: "race" } })]
  }),
  ability({
    name: "Elemental Symbiosis", sourceRace: "Emberkin", traits: "Reaction",
    description: `${raceAbilityText("EMBERKIN", "Elemental Symbiosis")}\n${note("*Automated:* **Use** spends your reaction in combat. You are immune to your heritage's element (Stonevein acid, Galeborne electricity, Cinderblood fire, Tidemarked cold) until the end of your next turn. When that ends you have weakness to it for 1 minute, and the Use is refused until the weakness ends. The book prints no trigger, so it is yours to use when you choose: normally as you are about to take damage of your element (B1-10).")}`
  }),
  ability({
    name: "Magical Instinct", sourceRace: "Emberkin",
    description: `${raceAbilityText("EMBERKIN", "Magical Instinct")}\n${note("*Granted by the race:* the core's Charismatic Caster feat. A grant ignores the feat's prerequisites, as every grant does.")}`
  }),
  // NYRINN
  ability({
    name: "Magic Drain", sourceRace: "Nyrinn", traits: "Concentrate, Focus, Warding", usesPerDay: "1",
    description: `${raceAbilityText("NYRINN", "Magic Drain")}\n${printed(sidebar("MAGIC DRAIN").lines.slice(1))}\n${note("*Automated:* **Use** (2 AP) first asks what you are draining (a magical effect or a charged item) and where the energy's +1 racial bonus will go (AB, DB, saving throws or skill checks). Then it rolls Magic Drain, a Power Manipulation check against the DC of the effect or item, which the GM sets. The Focus use is spent whatever the result. On a Critical or Success the effect's PP is entered (the GM knows it), or 1d4 PP is rolled and taken off the charged item (or the GM is told to, when it is not yours to change). You gain the energy, capped at your level × 2, for 1 minute per PP drained. The energy is a pool, not PP you can cast with (B1-8); a Vir-ellian's release spends it. Refocus restores the use.")}`,
    flags: { eaAutomation: "magicDrain" }
  }),
  ability({
    name: "Null Aura", sourceRace: "Nyrinn",
    description: `${raceAbilityText("NYRINN", "Null Aura")}\n${note("*Automated:* your class bonus is added to your saves and your DB against spells and spell attacks, named **Null Aura** on the card (the core's Spell Resilience rule, under its own name; TRG Prime 3.675.0). Any Spellcraft check made within 5 feet of you (10 feet for a Vel-tharis), yours included, takes your class bonus as a penalty against its casting DC. That is the same as raising the casting DC by that much (B1-5), and the card says so. An attack spell's attack against DB is not lowered (TRG Prime 3.675.0), nor is an innate spell's roll, which is not a Spellcraft check. *Automated (TRG Prime 3.677.0; Graham's C1):* when another caster casts a beneficial spell on you, you make a Will save against their Spell Save DC first; on a failure the spell has no effect on you. Your own spells on yourself are not disrupted. A beneficial spell is the system's own reading, as for the Ascendan's forbidden traditions: one aimed at allies, or one that only heals, grants temporary HP, a bonus or a ward, with no save of its own.")}`,
    flags: { creatureAbility: { derives: { spellResilience: { label: "Null Aura", type: "untyped" } } }, eaNullAuraFeet: 5, beneficialSpellSave: { label: "Null Aura", otherCastersOnly: true } }
  }),
  // SCAELYN
  ability({
    name: "Natural Armour", sourceRace: "Scaelyn",
    description: `${raceAbilityText("SCAELYN", "Natural Armour")}\n${note("*Automated:* a base natural DR of 1, scaled by your BDB like any Base DR.")}`,
    effects: [baseDR(1, "Natural Armour")]
  }),
  ability({
    name: "Ley Line Connection", sourceRace: "Scaelyn",
    description: `${raceAbilityText("SCAELYN", "Ley Line Connection")}\n${note("*Partly automated (0.3.0, TRG Prime 3.678.0):* the −1 to the Casting DC of a High Magic cast is applied (as +1 on the check against it, not on a spell attack's attack). *Not yet automated:* the permanent Ley Bond arrives with the Archmage's Ley Bond (Block 3).")}`
  }),
  ability({
    name: "Innate Magic", sourceRace: "Scaelyn",
    description: `${raceAbilityText("SCAELYN", "Innate Magic")}\n${note("*Automated:* **Use** chooses today's cantrip, from any tradition. It is added as a spell you cast with Spellcraft, not innate. Using it again replaces the pick, and daily preparation reminds you that you may choose again.")}`,
    flags: { eaAutomation: "innateMagic" }
  }),
  // VIR-ELLIAN: the heritage's release, an item of its own so its Focus use is tracked.
  ability({
    name: "Vir-ellian Release", sourceRace: "Nyrinn", traits: "Concentrate, Focus", usesPerDay: "1",
    description: `${printed(CH2.heritages["VIR-ELLIAN"].text.slice(-1))}\n${note("*The Vir-ellian heritage's release, as its own item so that its Focus use can be tracked; the book gives it no name.* *Automated:* **Use** (1 AP) releases the energy you hold from Magic Drain: 1d4 force damage per PP to every creature within 30 feet of you, allies included, with a basic Will save against your Level DC. That is Magic Drain's 30-foot range, because the book calls it an aura without defining one (B1-7). The energy is spent.")}`,
    flags: { eaAutomation: "virEllianRelease" }
  })
];

/* ------------------------------------------------------------------ */
/* Races                                                                */
/* ------------------------------------------------------------------ */

const raceDescription = (key, granted) => `${printed(CH2.races[key].text)}\n${note(granted)}`;

export const RACES = [
  race({
    name: "Aetherial",
    description: raceDescription("AETHERIAL", "*Granted when the race is added:* Ethereal Form, Aetherial Magic and Aetherial Resonance as ability items; Mage Hand and Read Aura as spells cast with Spellcraft; Astral Lore as a specialist skill. Power Points +1 per level."),
    abilityModifiers: "Con -1, Int +2, Wis +1", speed: 30,
    coreLanguages: "Low Tongue, Faechant", additionalLanguages: "common, regional",
    specialistSkills: "Astral Lore",
    racialAbilities: "Ethereal Form, Aetherial Magic, Aetherial Resonance",
    grantedSpells: "Mage Hand, Read Aura"
  }),
  race({
    name: "Emberkin",
    description: raceDescription("EMBERKIN", "*Granted when the race is added:* Elemental Surge, Elemental Symbiosis, Magical Instinct and Nightvision as ability items; Charismatic Caster as a bonus feat; Elemental Lore as a specialist skill. Power Points +1 per level. *Languages:* Low Tongue from the race. The \"Elemental Language\" is your heritage's elemental tongue (B1-1, as proposed): Gaian (Stonevein), Aeolian (Galeborne), Ignic (Cinderblood) or Aqualis (Tidemarked)."),
    abilityModifiers: "Con +1, Cha +1", speed: 25,
    coreLanguages: "Low Tongue", additionalLanguages: "common, regional",
    specialistSkills: "Elemental Lore",
    racialAbilities: "Elemental Surge, Elemental Symbiosis, Magical Instinct, Nightvision",
    grantedFeats: "Charismatic Caster"
  }),
  race({
    name: "Nyrinn",
    description: raceDescription("NYRINN", "*Granted when the race is added:* Magic Drain, Null Aura and Darkvision as ability items; Spell Lore and Nyrinn Lore as specialist skills. Power Points −1 per level. *Size:* Tiny. The race item carries Str −1 and Dex +2, and the core's Tiny row adds −2 and +2, so your sheet shows the printed Str −3 and Dex +4."),
    abilityModifiers: "Str -3, Con -1, Dex +4, Cha +2", effectModifiers: "Str -1, Con -1, Dex +2, Cha +2",
    size: "tiny", speed: 25,
    coreLanguages: "Low Tongue, Nyxian", additionalLanguages: "common, regional",
    specialistSkills: "Spell Lore, Nyrinn Lore",
    racialAbilities: "Magic Drain, Null Aura, Darkvision"
  }),
  race({
    name: "Scaelyn",
    description: raceDescription("SCAELYN", "*Granted when the race is added:* Natural Armour, Darkvision, Ley Line Connection and Innate Magic as ability items; Wyrm Lore as a specialist skill. Power Points +1 per level. *Size:* Small. The race item carries Str 0 and Dex +1, and the core's Small row adds −1 and +1, so your sheet shows the printed Str −1 and Dex +2."),
    abilityModifiers: "Str -1, Con -1, Dex +2, Int +2", effectModifiers: "Con -1, Dex +1, Int +2",
    size: "small", speed: 25,
    coreLanguages: "Low Tongue, Wyrmish", additionalLanguages: "common, regional",
    specialistSkills: "Wyrm Lore",
    racialAbilities: "Natural Armour, Darkvision, Ley Line Connection, Innate Magic"
  })
];

/* ------------------------------------------------------------------ */
/* Heritages                                                            */
/* ------------------------------------------------------------------ */

const heritageText = (key, extra) => `${printed(CH2.heritages[key].text)}\n${note(extra)}`;
const innate = (ability = null) => ({ grantInnate: true, ...(ability ? { grantedSpellAbility: ability } : {}) });
const resist = (type) => (id, n) => resistanceEffect(id, n, type);
const emberkin = (key, damageType, mods, cantrip) => {
  const name = HERITAGE_NAME[key];
  const el = EMBERKIN_ELEMENTS[name];
  return heritage({
    name, sourceRace: "Emberkin", coreLanguages: el.language,
    description: heritageText(key, `*Applied automatically:* resistance to ${damageType}; the adjustment ${mods}. *Granted:* ${cantrip}, cast with Spellcraft (the book's "learn"). Your element, for Elemental Symbiosis, is ${damageType}. *Language:* ${el.language}, your heritage's elemental tongue (B1-1).${key === "TIDEMARKED" ? " Galeborne prints the same adjustment (EA-m3), built as printed." : ""}`),
    abilityModifiers: mods, grantedSpells: cantrip,
    effects: [resist(damageType)],
    flags: { eaElement: damageType }
  });
};

export const HERITAGES = [
  // AETHERIAL
  heritage({ name: "Aeralis", sourceRace: "Aetherial", grantedSpells: "Gust", flags: innate(),
    description: heritageText("AERALIS", "*Applied automatically:* resistance to electricity. *Granted:* Gust as an innate spell with the Focus trait. An innate spell cannot be cast above its PP's level, so Gust (PP 2) waits for 2nd level."),
    effects: [resist("electricity")] }),
  heritage({ name: "Astryn", sourceRace: "Aetherial", grantedSpells: "Guiding Bolt", flags: innate(),
    description: heritageText("ASTRYN", "*Applied automatically:* resistance to force. *Granted:* Guiding Bolt as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    effects: [resist("force")] }),
  heritage({ name: "Caelari", sourceRace: "Aetherial", grantedSpells: "Shield", flags: innate(),
    description: heritageText("CAELARI", "*Applied automatically:* resistance to essence. *Granted:* Shield as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    effects: [resist("essence")] }),
  heritage({ name: "Nerathis", sourceRace: "Aetherial", grantedSpells: "Anticipate Attack",
    description: heritageText("NERATHIS", "*Applied automatically:* advantage on a save against an effect with the Mental trait, and offered as a tick on a save whose source the roll cannot see. *Granted:* Anticipate Attack as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    flags: {
      ...innate(),
      conditionals: [
        conditional({ kind: "advantage", label: "Nerathis", scope: "Saving throws against effects with the mental trait", auto: true, when: { checkTypes: ["save"], traits: ["mental"] } }),
        conditional({ kind: "advantage", label: "Nerathis", scope: "Saving throws against an effect with the mental trait — tick if this save is one", auto: false, when: { checkTypes: ["save"], not: { traits: ["mental"] } } })
      ]
    } }),
  heritage({ name: "Umbryth", sourceRace: "Aetherial", grantedSpells: "Cloak of Greying", flags: innate(),
    description: heritageText("UMBRYTH", "*Applied automatically:* resistance to cold (book v1.6; EA-m4). *Granted:* Cloak of Greying as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    effects: [resist("cold")] }),
  // EMBERKIN
  emberkin("STONEVEIN", "acid", "Wis +1, Int -1", "Orb of Acid"),
  emberkin("GALEBORNE", "electricity", "Dex +1, Str -1", "Orb of Lightning"),
  emberkin("CINDERBLOOD", "fire", "Str +1, Wis -1", "Orb of Fire"),
  emberkin("TIDEMARKED", "cold", "Dex +1, Str -1", "Orb of Water"),
  // NYRINN
  heritage({ name: "Vel-tharis", sourceRace: "Nyrinn", grantedSpells: "Silence",
    description: heritageText("VEL-THARIS", "*Applied automatically:* your Null Aura reaches 10 feet. *Granted:* Silence as an innate spell with the Focus trait (PP 4, from 4th level), cast on yourself only, as printed."),
    flags: { ...innate(), eaNullAuraFeet: 10 } }),
  heritage({ name: "Vir-ellian", sourceRace: "Nyrinn", racialAbilities: "Vir-ellian Release",
    description: heritageText("VIR-ELLIAN", "*Automated:* Magic Drain drains your class bonus in PP more. *Granted:* the release, as the **Vir-ellian Release** ability (B1-7, B1-8)."),
    flags: { eaMagicDrainBonus: "classBonus" } }),
  heritage({ name: "Zhal-vryn", sourceRace: "Nyrinn", grantedSpells: "Cancel Magic",
    description: heritageText("ZHAL-VRYN", "*Automated (TRG Prime 3.675.0):* a creature casting within 5 feet of you pays 1 PP more, cantrips included. You and your allies pay it too, as printed (EA-M22). It is a surcharge on top of the spell's own PP: it does not raise the casting DC or count toward the per-cast cap (B1-6). A spell cast from an item is not surcharged. *Granted:* Cancel Magic as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    flags: { ...innate(), eaCastSurcharge: 1 } }),
  // SCAELYN
  heritage({ name: "Sparktail", sourceRace: "Scaelyn", grantedSpells: "Orb of Fire",
    description: heritageText("SPARKTAIL", "*Applied automatically:* resistance to fire. *Granted:* Orb of Fire as an innate spell with the Focus trait. The +2 racial is offered as a tick on Create (Crafting) and Disable a Device checks; tick it when you are crafting or disarming a mechanical trap."),
    effects: [resist("fire")],
    flags: {
      ...innate(),
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Sparktail", scope: "Crafting a mechanical trap — tick if this check is one", auto: false, when: { checkTypes: ["skill"], actions: ["create"] } }),
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Sparktail", scope: "Disarming a mechanical trap — tick if this check is one", auto: false, when: { checkTypes: ["skill"], actions: ["disableADevice", "disablePeril"] } })
      ]
    } }),
  heritage({ name: "Glyphweave", sourceRace: "Scaelyn", grantedSpells: "Scribers Chant",
    description: heritageText("GLYPHWEAVE", "*Granted:* Scribers Chant as an innate spell with the Focus trait. *Automated:* the \"additional innate cantrip\" (book v1.6; EA-m5): this heritage's **Use** chooses any cantrip, added as an innate spell with the Focus trait. Using it again replaces the pick."),
    flags: { ...innate(), eaAutomation: "glyphweave" } }),
  heritage({ name: "Dustscale", sourceRace: "Scaelyn",
    description: heritageText("DUSTSCALE", "*Applied automatically:* a burrow Speed of 10 feet. Advantage is offered as a tick on Hide and Sneak; tick it in natural terrain."),
    effects: [otherSpeed("burrow", 10)],
    flags: {
      conditionals: [
        conditional({ kind: "advantage", label: "Dustscale", scope: "Hiding or moving silently in natural terrain — tick if you are", auto: false, when: { checkTypes: ["skill"], actions: ["hide", "sneak"] } })
      ]
    } }),
  heritage({ name: "Ironmuk", sourceRace: "Scaelyn", grantedSpells: "Purify",
    description: heritageText("IRONMUK", "*Applied automatically:* resistance to poison, and twice the breath when you hold it. *Granted:* Purify as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    effects: [resist("poison")],
    flags: { ...innate(), creatureAbility: { derives: { breathMultiplier: 2 } } } }),
  heritage({ name: "Wisperfin", sourceRace: "Scaelyn", grantedSpells: "Cloak of Greying",
    description: heritageText("WISPERFIN", "*Applied automatically:* +2 racial to Stealth. *Granted:* Cloak of Greying as an innate spell with the Focus trait (PP 2, from 2nd level)."),
    effects: [(id, n) => racialSkillEffect(id, n, ["Stealth"], 2)],
    flags: innate() }),
  heritage({ name: "Wyrmdral", sourceRace: "Scaelyn",
    description: heritageText("WYRMDRAL", "*Applied automatically:* Medium size and the Wyrmdral's own line, **instead of** the Scaelyn's. The heritage's effect sets Medium and adds Str +1, Dex −2, Con +1, Int −1, Cha +1, so race and heritage together give the printed Str +1, Dex −1, Int +1, Cha +1. The race's Power Points (+1) stand; the heritage adds none. *Automated:* this heritage's **Use** chooses your element (acid, cold, electricity, fire or poison). You gain resistance to it, +1 to the Spellcraft check of a spell with that trait (a learned spell's attack is that check), and +1 to that spell's save DC (B1-11)."),
    abilityModifiers: "Str +1, Dex -1, Int +1, Cha +1", effectModifiers: "Str +1, Dex -2, Con +1, Int -1, Cha +1",
    effects: [sizeOverride("medium")],
    flags: { eaAutomation: "wyrmdral" } })
];

/* ------------------------------------------------------------------ */
/* The General feats the backgrounds grant (Chapter 5)                  */
/* ------------------------------------------------------------------ */

const FEAT_BY_NAME = new Map(BOOK.sections.generalFeats.map((f) => [f.name, f]));
const titleCase = (s) => s.toLowerCase().replace(/(^|[\s(\-–])([a-z’'])/g, (m, a, b) => a + b.toUpperCase()).replace(/’S\b/g, "’s");

function featText(key) {
  const f = FEAT_BY_NAME.get(key);
  if (!f) throw new Error(`Block 1: the book has no General feat "${key}"`);
  const out = [];
  if (f.traits.length) out.push(md(`**${f.traits.join(" ")}**`));
  for (const [label, value] of Object.entries(f.fields)) out.push(md(`**${label}** ${value}`));
  out.push(printed(f.lines));
  return { html: out.join("\n"), fields: f.fields, traits: f.traits.map((t) => titleCase(t)).join(", "), line: f.line };
}

function generalFeat(key, { automation, flags = {}, effects = [], usesPerDay = "", repeatable = false }) {
  const t = featText(key);
  return feat({
    name: titleCase(key), category: "General", prerequisites: t.fields.Prerequisites ?? "", traits: t.traits,
    usesPerDay, repeatable,
    description: `${t.html}\n${note(automation)}`,
    flags, effects
  });
}

export const LEY_SENSE_LADDER = Object.freeze({
  options: [
    { key: "tenMinutes", label: "10 minutes", modifier: 0, apCost: "10 minutes" },
    { key: "minute", label: "1 minute", modifier: -2, apCost: "1 minute" },
    { key: "round", label: "1 round", modifier: -5, apCost: "1 round" },
    { key: "action", label: "1 AP", modifier: -10, apCost: "1" }
  ],
  defaultKey: "tenMinutes",
  hint: "How long do you spend sensing ley? Less time costs accuracy."
});
/** Focused Ley Sense: "10 minutes (+2), 1 minute (+0), 1 round (-2), 1 AP (-5), 0 AP (-10)". */
export const FOCUSED_LEY_SENSE_LADDER = Object.freeze({
  options: [
    { key: "tenMinutes", label: "10 minutes", modifier: 2, apCost: "10 minutes" },
    { key: "minute", label: "1 minute", modifier: 0, apCost: "1 minute" },
    { key: "round", label: "1 round", modifier: -2, apCost: "1 round" },
    { key: "action", label: "1 AP", modifier: -5, apCost: "1" },
    { key: "free", label: "0 AP", modifier: -10, apCost: "0" }
  ],
  defaultKey: "tenMinutes",
  hint: "Focused Ley Sense: how long do you spend sensing ley?"
});

export const BACKGROUND_FEATS = [
  generalFeat("DISRUPT MAGIC", {
    automation: "*Automated:* +2 class on your Dispel checks.",
    flags: { conditionals: [conditional({ kind: "modifier", value: 2, type: "class", label: "Disrupt Magic", scope: "Dispel checks", auto: true, when: { actions: ["dispel"] } })] }
  }),
  generalFeat("ELEMENTAL AFFINITY", {
    repeatable: true,
    automation: "*Automated:* **Use** chooses the element: fire, cold, electricity, acid or sonic, a different one for each copy of the feat. A spell with that element's trait gets +1 on its Spellcraft check and +1 to its save DC. *Read as:* \"a spell that deals damage of your chosen element\" is a spell carrying its trait.",
    flags: { eaAutomation: "elementalAffinity" }
  }),
  generalFeat("ESOTERIC INSIGHT", {
    usesPerDay: "1",
    automation: "*Automated:* the +2 circumstance is offered as a tick on Identify Power and Recall Knowledge; tick it when the spell, effect or rune is uncommon or rare. The once-a-day reroll is offered when an Arcana or Occultism check comes out a Failure, Fumble or Blunder (book v1.6: \"a failure or fumble result\"); it is not a reaction, and you must use the new result (TRG Prime 3.677.0). Advantage is offered as a tick on Spell Recognition's roll: tick it when the spell has the Uncommon or Rare trait (TRG Prime 3.683.0: the roll names itself, C11, so the tick and the reroll both reach it).",
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Esoteric Insight", scope: "Identifying a rare or uncommon spell, magical effect or rune — tick if so", auto: false, when: { actions: ["identifyPower", "recallKnowledge"] } }),
        conditional({ kind: "advantage", label: "Esoteric Insight", scope: "Spell Recognition on a spell with the Uncommon or Rare trait — tick if so", auto: false, when: { actions: ["spellRecognition"] } })
      ],
      fumbleReroll: { checkTypes: ["skill"], reaction: false, subjects: ["arcana", "occultism"], degrees: ["failure", "fumble", "blunder"], label: "Esoteric Insight" }
    }
  }),
  generalFeat("FOCUSED LEY SENSE", {
    automation: "*Automated (TRG Prime 3.675.0):* Ley Sense offers you this feat's five rungs instead of its own four."
  }),
  generalFeat("RITUAL EXPERT", {
    automation: "*Automated (0.4.0, TRG Prime 3.679.0):* as the primary caster you count as two: the Magic Ritual dialog counts one more caster for the one-secondary requirement and the 2 PP headroom. As a secondary, enter the Ritual Experts among the secondaries in the dialog. Your secondary degree's modifier is not doubled, and it does not stack with Rune-Binder's Precision (Graham's Q13, M21)."
  }),
  generalFeat("SPELL PENETRATION", {
    automation: "*Automated (TRG Prime 3.675.0):* against your spells, a target's **Spell Resilience** (the core creature ability) is 2 lower, never below 0. Other abilities of the same shape under other names (a Nyrinn's Null Aura) are not lowered, because the feat names Spell Resilience.",
    flags: { spellResilienceReduction: { value: 2, labels: ["Spell Resilience"], label: "Spell Penetration" } }
  }),
  // SPELL SURGE (Block 6, 0.9.0; Q132): "(which has the focus trait)" — one
  // surge, one Focus use until Refocus. The book prints no trait line, so the
  // stored trait is added here. A copy made before 0.9.0 must be re-added
  // from the compendium to get its Focus use (owned items are not rewritten).
  ((f) => { f.system.traits = "Focus"; return f; })(generalFeat("SPELL SURGE", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* an option in the spell's own **Warp?** dialog (Block 6's module metamagic, G1): **+1 PP**, one Focus use (Q132: one surge, one effect, until Refocus or daily preparation), choose one — range +50% (a range in feet), duration +50% (a number of rounds, minutes or hours), +2 class bonus to the Save DC (a spell with a save; it does not stack with another class bonus to it), or +1 die of damage (one die of the spell's damage). That cast's Spell Fumble and Resonance rolls have disadvantage (EA-M20: the higher kept). Offered only where the choice can apply; learned and innate casts, never an item's spell or a cantrip (Q94). The Focus use is spent when the cast pays its PP (Q96). A copy taken before 0.9.0 has no Focus trait: re-add it from the compendium to get its use. Its prerequisite is a High Magic caster; a background grant ignores prerequisites."
  })),
  generalFeat("SPIRIT WHISPER", {
    automation: "*Not automated:* communication. It is listed on your sheet.",
    effects: [(id, n) => noteEffect(id, `${n}: telepathy`, "You may communicate telepathically with willing spirits or undead within 30 feet, even if you do not share a language.")]
  }),
  generalFeat("WANDERER’S INSTINCT", {
    usesPerDay: "1",
    automation: "*Automated:* the +2 circumstance is offered as a tick on Survival checks, and the +1 on checks to detect hidden magical disturbances. The +1 applies by itself to Ley Sense. **Use** (once a day) readies advantage, offered as a tick on your Survival checks: tick it on the check to navigate or track in an area infused with magical energy, and it is spent.",
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Wanderer’s Instinct", scope: "Survival checks to avoid natural hazards, magical anomalies and environmental effects — tick if so", auto: false, when: { checkTypes: ["skill"], subjects: ["survival"] } }),
        conditional({ kind: "modifier", value: 1, type: "untyped", label: "Wanderer’s Instinct", scope: "Ley Sense: detecting hidden magical disturbances", auto: true, when: { actions: ["leySense"] } }),
        conditional({ kind: "modifier", value: 1, type: "untyped", label: "Wanderer’s Instinct", scope: "Detecting hidden magical disturbances (ley lines, wild magic zones, suppressed areas) — tick if so", auto: false, when: { checkTypes: ["skill"], not: { actions: ["leySense"] } } })
      ],
      eaAutomation: "wanderersInstinct"
    }
  })
];

/* ------------------------------------------------------------------ */
/* Backgrounds (Chapter 2; wealth from Chapter 6's table)               */
/* ------------------------------------------------------------------ */

/** Chapter 6, BACKGROUND WEALTH (v1.6, L4746): every background, Spirit Binder 0 included. */
export const BACKGROUND_WEALTH = Object.freeze({
  "Arcane Investigator": 1, "Arcane Wayfarer": 2, "Cabal Exile": -1, "Elemental Adept": 0, "Enigmatic Scholar": 1,
  "Leyline Tracker": 0, "Magical Artisan": 1, "Ritualist Initiate": 0, "Shadowed Seer": -1, "Spirit Binder": 0,
  "Voidborn Outsider": -1, "Wild Mage Survivor": -1
});
// v1.6 prints every background's wealth (EA-m58; B1-14 settled by the book).
export const WEALTH_NOT_PRINTED = Object.freeze([]);

export const BACKGROUNDS = Object.values(CH2.backgrounds).map((b) => {
  const name = titleCase(b.name);
  if (!(name in BACKGROUND_WEALTH)) throw new Error(`Block 1: no wealth for background "${name}"`);
  const wealthNote = `*Applied automatically:* the bonus feat, the skill bonuses and the specialist skill are granted when the background is added, as the core's backgrounds' are; the wealth is Chapter 6's Background Wealth.${WEALTH_NOT_PRINTED.includes(name) ? " *Wealth:* the Background Wealth table has no row for it (B1-14); 0 until ruled." : ""}`;
  return background({
    name,
    description: `${printed(b.description)}\n${md(`**BONUS FEAT**\n\n${b.feat}\n\n**SKILL BONUSES**\n\n${b.skills}\n\n**SPECIALIST SKILL**\n\n${b.specialist}\n\n**WEALTH**\n\n${BACKGROUND_WEALTH[name]}`)}\n${note(wealthNote)}`,
    grantedFeats: b.feat.replace(/'/g, "’"),
    skillBonuses: b.skills,
    specialistSkill: b.specialist,
    wealth: String(BACKGROUND_WEALTH[name])
  });
});

/* ------------------------------------------------------------------ */
/* Orb of Water (Chapter 8, the Grimoire): the Tidemarked's cantrip      */
/* ------------------------------------------------------------------ */

const ORB = BOOK.grimoire.find((s) => s.name === "ORB OF WATER");
export const SPELLS = [
  spell({
    name: "Orb of Water", tradition: "arcane, verdant", category: "attack", ppCost: 0, castAP: 2, range: "30 feet", targets: "1 creature",
    traits: "Attack, Cantrip, Cold, Invocation, Water", baseDamage: "1d6",
    damage: { formula: "1d6", type: "bludgeoning" },
    components: { somatic: true, verbal: true, material: false, focus: false },
    description: `${md(`**${ORB.traits.join(" ")}**`)}\n${Object.entries(ORB.fields).map(([k, v]) => md(`**${k}** ${v}`)).join("\n")}\n${printed(ORB.lines)}\n${note("*Automated (TRG Prime 3.675.0):* the spell attack; on a hit, 1d6 bludgeoning and then 1 secondary cold damage, each against its own defences. At CL 4 and every 4 levels after, +1d6 and +1 secondary (the core's recurring caster-level step, as Orb of Fire's).")}`
  })
];
// A Grimoire spell: uncommon (ruling m84; marked from 0.10.0, Graham's Q166).
SPELLS[0].system.availability = "uncommon";
// The secondary packet and its caster-level step (core 3.675.0, C9).
SPELLS[0].system.secondaryDamage = { formula: "1", type: "cold" };
SPELLS[0].system.casterLevelMods = [{ threshold: 4, recurring: true, damageDice: "1d6", secondary: 1, saveDC: 0, attack: 0, persistent: 0, text: "The damage increases by 1d6 & the secondary by 1." }];

/* ------------------------------------------------------------------ */
/* Chapter 6: exotic weapons                                            */
/* ------------------------------------------------------------------ */

const DAMAGE_TYPE = { B: "bludgeoning", P: "piercing", S: "slashing" };
const SIZE = { T: "tiny", S: "small", M: "medium", L: "large" };
/** The nearest of TRG Prime's own weapon images (the module ships no art). */
const ICON = {
  "Bachall Fáistine": "staff", "Brikail Naomhtha": "staff", "Claidheamh Dubh": "scimitar", "Claíomh Draíochta": "scimitar",
  Clamhscrios: "greatsword", "Corrán Fola": "sickle", "Draic-Ghiorraigh": "spear", "Éitear-Lann": "rapier",
  "Gaoth Bhioráin": "glaive", "Ord ua na Tuama": "warhammer", "Scáthfán": "dagger", "Sleábhra": "flail",
  "Tuagh na nScáth": "battleaxe", "Tuagh Tairngire": "halberd", "Saighead Draíochta": "longbow", "Piorra Ceangail": "dart",
  "Bogha Tuama": "longbow", "Gaoth Shlánaithe": "javelin"
};
/** The three Chapter 6 traits, as printed (L4931 onward). */
const TRAIT_TEXT = Object.freeze({
  Adept: "A weapon with the Adept trait is treated as a Simple weapon for any character with this class trait.",
  Brace: "A weapon with the Brace trait is designed to counter charging or fast-approaching enemies. If a foe moves into your reach using a Stride, Charge, or similar movement ability, you may use a Reaction to make a melee Strike with this weapon against that creature.",
  Ritualist: "A weapon with the Ritualist trait is also recognized as a valid focus for ritual magic. When wielding or placing the weapon at the centre of a magical ritual, you reduce the ritual’s DC by 1 (to a minimum of DC 0). Some rituals may also specifically require a weapon with the Ritualist trait, especially in cultures where martial and mystical traditions intertwine."
});
const TRAIT_AUTOMATION = Object.freeze({
  Adept: "*Automated (TRG Prime 3.675.0):* an Adept-class character uses it as a Simple weapon.",
  Brace: "*Not yet automated — B1-12:* Inner Tempest also prints a Brace trait, with a different rule, and TRG Prime applies that one to every weapon carrying the trait. Until you rule which applies, the Brace trait is printed here but kept out of the weapon's trait line.",
  Ritualist: "*Automated (0.4.0, TRG Prime 3.679.0):* offered as a tick in the Magic Ritual dialog while you carry the weapon: −1 to the ritual's DC."
});
/** Racial traits in the table, and the race or heritage each names (v1.6 spells Nyrinn, closing B1-13). */
const RACIAL_TRAIT = Object.freeze({ Emberkin: "Emberkin", Wyrmdral: "Wyrmdral", Scaelyn: "Scaelyn", Aetherial: "Aetherial", Nyrinn: "Nyrinn" });

function weaponDescription(name) {
  const entry = BOOK.sections.weaponEntries.find((e) => e.name.replace(/\s*\(.*\)$/, "").toLowerCase() === name.toLowerCase());
  if (!entry) throw new Error(`Block 1: no description for weapon ${name}`);
  return { heading: entry.name, lines: entry.lines };
}

function buildWeapon(row, ranged) {
  const [name, price, level, damage, size, fdc, weightText, group, traitsText] = row.cells;
  const dmg = /^(\d+d\d+) ([BPS])$/.exec(damage);
  if (!dmg) throw new Error(`Block 1 weapons: cannot read damage "${damage}" (${name})`);
  if (!SIZE[size]) throw new Error(`Block 1 weapons: unknown size "${size}" (${name})`);
  // "Piercing. Range 120" is printed with a full stop (Bogha Tuama); read as two traits.
  const printedTraits = traitsText.replace(/\.\s+/g, ", ").split(",").map((t) => t.trim()).filter(Boolean);
  const out = [];
  let reachFeet = null;
  let rangeIncrement = 0;
  for (const t of printedTraits) {
    const reach = /^Reach (\d+) ft$/.exec(t);
    if (reach) { reachFeet = Number(reach[1]); out.push("Reach"); continue; }
    const range = /^Range (\d+)$/.exec(t);
    if (range) rangeIncrement = Number(range[1]);
    if (t === "Brace") continue; // B1-12
    out.push(t);
  }
  if (!out.includes("Exotic")) out.push("Exotic");
  const thrown = printedTraits.some((t) => /^Thrown/.test(t));
  const attackMode = rangeIncrement ? "missile" : (ranged && thrown ? "thrown" : "melee");
  const own = printedTraits.filter((t) => TRAIT_TEXT[t]);
  const desc = weaponDescription(name);
  const racial = printedTraits.filter((t) => RACIAL_TRAIT[t]);
  const notes = [`*Traits as printed:* ${traitsText}.`];
  // ONE CATEGORY EASIER FOR ITS RACE (Graham's m64; TRG Prime 3.677.0): every
  // Block 1 racial weapon is exotic, so martial for its race.
  if (racial.length) notes.push(`*Racial:* one category easier for a ${RACIAL_TRAIT[racial[0]]}, so martial${racial[0] === "Wyrmdral" ? " (a Scaelyn heritage; TRG Prime reads the heritage too)" : ""}.`);
  return weapon({
    name,
    description: [md(`**${desc.heading}**`), printed(desc.lines), ...own.flatMap((t) => [md(`**${t}:** ${TRAIT_TEXT[t]}`), md(TRAIT_AUTOMATION[t])]), ...notes.map((n) => md(n))].join("\n"),
    price: Number(price.replace(/[^\d.]/g, "")),
    weight: weightText.trim() === "-" ? 0 : Number(weightText.replace(/[^\d.]/g, "")),
    damage: dmg[1], damageType: DAMAGE_TYPE[dmg[2]], size: SIZE[size], fumbleDC: Number(fdc), group, category: "Exotic",
    traits: out.join(", "), itemLevel: Number(level), reachFeet, attackMode, rangeIncrement,
    img: `systems/trg-prime/assets/weapons/${ICON[name] ?? "longsword"}.png`
  });
}

export const WEAPONS = [
  ...BOOK.sections.meleeWeapons.rows.slice(2).map((r) => buildWeapon(r, false)),
  ...BOOK.sections.rangedWeapons.rows.slice(2).map((r) => buildWeapon(r, true))
];

/* ------------------------------------------------------------------ */
/* Chapter 6: goods & tools                                             */
/* ------------------------------------------------------------------ */

/**
 * Each good's bonus as the core's `goodsConditionals`: offered as a tick on
 * the roll while the good is carried (TRG Prime's goods.mjs offers every
 * such row unticked, because whether the situation applies is the table's).
 * Those that need a later block's subsystem (rituals, summoning circles,
 * wild magic zones) say so. Rows with no rolled effect are text only (the
 * matrix's D rows).
 */
const M = (value, label, scope, when, type = "item") => ({ kind: "modifier", value, type, label, scope, when });
const A = (label, scope, when) => ({ kind: "advantage", label, scope, when });
const OFFERED = "*Offered while carried:* a tick on the roll; tick it when the situation fits.";
export const GOODS_AUTOMATION = Object.freeze({
  "Aetherglass Lens": { rows: [M(1, "identifying magic", "Identifying ongoing spells or magical effects within 30 ft", { actions: ["identifyPower"] })], note: `${OFFERED} +1 item on Identify Power.` },
  "Astral Compass": { rows: [M(2, "Ley Sense", "Ley Sense checks", { actions: ["leySense"] })], note: `${OFFERED} +2 item on Ley Sense.` },
  "Astral Lodestone": { rows: [M(1, "toward ley lines", "Navigating toward ley lines or wild magic areas", { checkTypes: ["skill"], subjects: ["survival"] })], note: `${OFFERED} +1 item on Survival.` },
  "Bloodscribe’s Bowl": { rows: [], note: "*Automated (0.4.0, TRG Prime 3.679.0):* offered as a tick in the Magic Ritual dialog while carried: +1 to the primary caster's ritual check when blood is offered." },
  "Bone Dice of Fate": { rows: [A("once a day", "Once per day: an Arcana, Occultism or Religion check", { checkTypes: ["skill"], subjects: ["arcana", "occultism", "religion"] })], note: `${OFFERED} Advantage on Arcana, Occultism or Religion; once a day is yours to keep.` },
  "Bone Quills": { rows: [M(1, "scribing", "Scribing (Create)", { checkTypes: ["skill"], actions: ["create"] })], note: `${OFFERED} +1 item on Create, scrolls and ritual texts alike: tick it when scribing either.` },
  "Camel Pouch": { rows: [], note: "*Not automated:* drawing a small item from it costs 0 AP; the system does not charge for the draw." },
  "Channel Rod": { rows: [M(1, "disruption", "Avoiding disruption while casting or performing a ritual (wielded)", { actions: ["spellConcentration"] }, "circumstance")], note: `${OFFERED} +1 circumstance on Spell Concentration while wielded, the check that avoids disruption.` },
  "Chime of Stillness": { rows: [A("enchantments", "Perception to detect enchantments within 20 ft", { checkTypes: ["skill"], subjects: ["perception"] })], note: `${OFFERED} Advantage on Perception.` },
  "Crystal Phials": { rows: [], note: "*Not automated:* protecting contents from magical interference has no rolled effect." },
  "Diviner’s Sand": { rows: [M(2, "tradition or school", "Determining the tradition or school of an active spell effect", { actions: ["identifyPower"] })], note: `${OFFERED} +2 item on Identify Power.` },
  "Eclipse Veil": { rows: [M(1, "concealing magic", "Concealing magical intent or spellcasting", { checkTypes: ["skill"], subjects: ["deception"] })], note: `${OFFERED} +1 item on Deception.` },
  "Etheric Ink": { rows: [], note: "*Not automated:* the −5 applies to a forger's check the GM calls." },
  "Etherveil Cloak": { rows: [M(1, "dim light", "Hiding in dim light or shadows", { checkTypes: ["skill"], actions: ["hide"] })], note: `${OFFERED} +1 item on Hide.` },
  "Gilded Censor Chains": { rows: [], note: "*Not automated:* a censer's smoke reaching 20 feet instead of 10 has no rolled effect; the radius is the table's." },
  "Harbinger’s Bell": { rows: [M(1, "undead or summoned", "Diplomacy with undead or summoned creatures", { checkTypes: ["skill"], subjects: ["diplomacy"] })], note: `${OFFERED} +1 item on Diplomacy.` },
  "Leybraid Rope": { rows: [A("magical areas", "Climbing or securing the rope in a magical area", { checkTypes: ["skill"], subjects: ["climbing"] })], note: `${OFFERED} Advantage on Climbing.` },
  "Leyline Satchel": { rows: [], note: "*Not automated:* shielding carried items from ley interference has no rolled effect." },
  "Resonant Crystals": { rows: [A("ongoing magic", "Noticing ongoing magic", { checkTypes: ["skill"], subjects: ["perception"] })], note: `${OFFERED} Advantage on Perception.` },
  "Ritual Censor": { rows: [], note: "*Automated (0.4.0, TRG Prime 3.679.0; 0.13.2):* offered as a tick in the Magic Ritual dialog while carried: −1 to the ritual's DC. The purse must hold 5 gp to tick it, and the 5 gp of incense is taken from it automatically once the ritual's roll is made — a ritual refused before its roll costs nothing." },
  "Runestone Chalkboard": { rows: [], note: "*Automated (0.4.0, TRG Prime 3.679.0):* offered as a tick in the Magic Ritual dialog while carried: +1 to the primary caster's ritual check (one only)." },
  "Seer’s Hourglass": { rows: [A("wild magic", "Initiative in a Wild Magic or Suppression zone", { checkTypes: ["initiative"] })], note: `${OFFERED} Advantage on initiative: tick it when you stand in a Wild Magic or Magic Suppression area (Chapter 7's areas, placed on the map since 0.3.0).` },
  "Spellbinder’s Cord": { rows: [M(1, "sustaining", "Concentration checks to sustain a spell", { actions: ["spellConcentration"] })], note: `${OFFERED} +1 item on Spell Concentration.` },
  "Talisman Pouch": { rows: [M(1, "divination rituals", "Religion or Occultism checks for divination rituals", { checkTypes: ["skill"], subjects: ["religion", "occultism"] })], note: `${OFFERED} +1 item on Religion and Occultism.` },
  "Twilight Prism": { rows: [M(1, "dim light", "Concentration in dim light or darkness", { actions: ["spellConcentration"] })], note: `${OFFERED} +1 item on Spell Concentration.` },
  "Umbral Lantern": { rows: [], note: "*Not yet automated:* seeing invisible creatures as silhouettes and ignoring illusions is revealed by the GM." },
  "Veilbound Mirror": { rows: [M(1, "illusions and spirits", "Occultism to identify illusions or spirit manifestations", { checkTypes: ["skill"], subjects: ["occultism"] })], note: `${OFFERED} +1 item on Occultism.` },
  "Void Chalk": { rows: [], note: "*Automated (0.4.0, TRG Prime 3.679.0):* a summoning circle drawn in it (ticked when you Inscribe Summoning Circle while carrying it) lasts 24 hours, or 1 hour per caster level if longer. That it resists scuffing is the table's." },
  "Warding Spikes": { rows: [], note: "*Not automated:* +1 DB against summoned or extraplanar creatures inside the perimeter; the perimeter is the table's." },
  "Ward Twine": { rows: [], note: "*Automated (0.4.0, TRG Prime 3.679.0):* a summoning circle outlined with it (ticked when you Inscribe Summoning Circle while carrying it) adds +1 to the Save DC of Summons spells cast from it — its \"effective DC\" (Graham's Q12)." },
  "Whisper Jar": { rows: [M(1, "spirits", "Diplomacy or Deception with spirits", { checkTypes: ["skill"], subjects: ["diplomacy", "deception"] })], note: `${OFFERED} +1 item on Diplomacy and Deception.` }
});

/** Where the description's heading is not the table's name in capitals (both as printed). */
// v1.6 prints every heading as the table's name in capitals (EA-m65, EA-m68 corrected).
const GOODS_HEADING = Object.freeze({});

/** Size letters → the core's item size; "-" → T (the core's smallest goods). */
const ITEM_SIZE = { T: "T", S: "S", M: "M", L: "L", "-": "T", "\\-": "T" };

function buildGood(row) {
  const [name, cost, size, level, weight, effect] = row.cells;
  const auto = GOODS_AUTOMATION[name];
  if (!auto) throw new Error(`Block 1 goods: no automation entry for ${name}`);
  const heading = GOODS_HEADING[name] ?? name.toUpperCase();
  const entry = BOOK.sections.goodsEntries.find((e) => e.name === heading);
  if (!entry) throw new Error(`Block 1 goods: no description for ${name}`);
  const qty = /\((\d+)\)/.exec(cost);
  const flags = auto.rows.length ? { goodsConditionals: auto.rows.map((r) => ({ ...r })) } : {};
  return gear({
    name,
    description: `${md(`**${entry.name}**`)}\n${printed(entry.lines)}\n${md(`*Table:* ${cost}, size ${size.replace(/\\/g, "")}, level ${level}, ${weight.replace(/\\/g, "")}. ${effect}`)}\n${note(auto.note)}`,
    price: Number(cost.replace(/\(.*\)/, "").replace(/[^\d.]/g, "")),
    weight: /lb/.test(weight) ? Number(weight.replace(/½/, "0.5").replace(/[^\d.]/g, "")) : 0,
    flags,
    system: { itemSize: ITEM_SIZE[size] ?? "T", itemLevel: Number(level), quantity: qty ? Number(qty[1]) : 1 }
  });
}

export const GOODS = BOOK.sections.goods.rows.slice(2).map(buildGood);

/* ------------------------------------------------------------------ */
/* The pack layout                                                      */
/* ------------------------------------------------------------------ */

export const BLOCK1_PACKS = [
  { name: "ea-races", label: "Eldritch Arts: Races", extends: "races", docs: RACES },
  { name: "ea-heritages", label: "Eldritch Arts: Heritages", extends: "heritages", docs: HERITAGES },
  { name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: ABILITIES },
  { name: "ea-backgrounds", label: "Eldritch Arts: Backgrounds", extends: "backgrounds", docs: BACKGROUNDS },
  { name: "ea-feats", label: "Eldritch Arts: Feats", extends: "feats", docs: BACKGROUND_FEATS },
  { name: "ea-spells", label: "Eldritch Arts: Spells", extends: "spells", docs: SPELLS },
  { name: "ea-weapons", label: "Eldritch Arts: Weapons", extends: "weapons", docs: WEAPONS },
  { name: "ea-gear", label: "Eldritch Arts: Gear", extends: "gear", docs: GOODS }
];

// Keep `stableId` reachable for the harness's id checks.
export { stableId };
