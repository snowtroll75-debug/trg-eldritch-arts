/**
 * Eldritch Arts — Block 6 (0.9.0), group A: Chapter 5's archetypes, part 1 —
 * the seven Pacts, Hex Weaver, Bloodmage, High Mage, Birthrager and Blood of
 * the Wyrm — and the five class feats whose traits name one of them
 * (Sanguine Channel and Crimson Rite: BLOODMAGE; Draconic Claws, Elemental
 * Exhalation and Wyrm Ascendant: BLOOD-OF-THE-WYRM).
 *
 * The spec is docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md, Appendix A, as Graham
 * answered it on 4 November 2026 (Q89–Q149: as proposed; Q89 one release),
 * on TRG Prime 3.684.0's seams as built (b6-contracts: G2, G8–G15).
 *
 * Every feat is built with block6-common.mjs's `archetypeFeat` / `classFeat`,
 * so its card is the book's text followed by one paragraph saying what TRG
 * Prime does with it. What is data lives here (effects, conditionals,
 * declarations); the Uses, registrations and hooks are
 * module/block6a-automations.mjs.
 *
 * FLAGS under the system's scope are TRG Prime's declarations
 * (`progressionSinceTaken`, `compoundSkillPrerequisites`, `castsWhileRaging`),
 * except the module's own `ea…` keys, which the system does not read.
 */
import { archetypeFeat, classFeat } from "./block6-common.mjs";
import { changesEffect, classSkillEffect, declaredEffect, conditional } from "./builders.mjs";

const AUTO = "*Automated (0.9.0, TRG Prime 3.684.0):*";
/** Q90: "+10 levels" read as levels gained since the archetype was taken (G8, opt-in). */
const SINCE = { progressionSinceTaken: true };
const PROGRESSION_LINE = "The progression line \"+10 levels\" is read as ten levels gained since you took this archetype (Q90): until then no other archetype is offered. A character who took it before 0.9.0 carries no stamp and passes open.";
const ONE_PACT = "You may hold only one Pact (Q92).";

/** The book's Pact names, as stored (the exclusive group and the Warlock's copies read them). */
export const PACT_NAMES = Object.freeze(["Angelic Pact", "Demonic Pact", "Draconic Pact", "Elemental Pact", "Fey Pact", "Grave Pact", "Void Pact"]);

/** Note 1: the Pact's spell, by class. */
const PACT_SPELL = (spell) => `**${spell}** is granted on taking the Pact: a Warlock's copy becomes an innate spell with the Focus trait, cast with Charisma (the Warlock's own picks' rule, Q37), counted as High Magic; a Witch's is a repertoire spell outside her picks, cast as High Magic as every spell of hers is (Graham's ruling, 4 November 2026) (delete it if you do not want it: "may").`;

const effect = (name, changes, description, flags = {}) => (id, n) => changesEffect(id, `${n}: ${name}`, changes, description, flags);

/** "+2-circumstance … saving throws against effects with the Fear or Soul traits" (Angelic). */
const savesVsTraits = (label, value, type, traits) => [
  conditional({ kind: "modifier", value, type, label, scope: `Saving throws against effects with the ${traits.join(" or ")} trait`, auto: true, when: { checkTypes: ["save"], traits } }),
  conditional({ kind: "modifier", value, type, label, scope: `Saving throws against an effect with the ${traits.join(" or ")} trait — tick if this save is one`, auto: false, when: { checkTypes: ["save"], not: { traits } } })
];

/* ------------------------------------------------------------------ */
/* The archetypes                                                       */
/* ------------------------------------------------------------------ */

export const ARCHETYPES_B6_A = [
  archetypeFeat("ANGELIC PACT", {
    grantedSpells: "Sanctuary",
    flags: { ...SINCE, eaAutomation: "pact", conditionals: savesVsTraits("Angelic Pact", 2, "circumstance", ["fear", "soul"]) },
    effects: [declaredEffect("+1 HP healed per PP", "A spell you cast with the Healing trait heals each creature it heals 1 more HP per PP the spell is cast at.",
      { healingRider: { label: "Angelic Pact", perPP: 1, traits: ["healing"] } })],
    automation: `${AUTO} ${PACT_SPELL("Sanctuary")} +2 circumstance to saves against an effect with the Fear or Soul trait, applied by itself when the roll names the trait and offered as a tick when it cannot tell. A spell you cast with the Healing trait heals every creature it heals +1 HP per PP (G12): the PP the spell is cast at — base + warps and metamagic, a Warlock's innate spell its own PP, not lowered by a Partial's refund, a cantrip 0 (Q101). ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("DEMONIC PACT", {
    grantedSpells: "Burning Hands",
    flags: { ...SINCE, eaAutomation: "pact" },
    effects: [
      (id, n) => classSkillEffect(id, n, ["Intimidate"], 2),
      declaredEffect("+1 secondary fire per PP", "A creature your spell damages takes 1 more point of secondary fire damage per PP the spell is cast at.",
        { spellDamageRider: { label: "Demonic Pact", perPP: 1, damageType: "fire" } })
    ],
    automation: `${AUTO} ${PACT_SPELL("Burning Hands")} +2 class to Intimidate. Each creature a spell of yours damages takes secondary fire damage of 1 per PP the spell is cast at (G12; Q101's PP, as Angelic Pact's), resolved against its own fire resistance; a cantrip adds nothing. ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("DRACONIC PACT", {
    flags: { ...SINCE, eaAutomation: "draconicPact" },
    automation: `${AUTO} **Use** chooses your energy (acid, cold, electricity, fire or poison), kept on the feat: you gain resistance to it. When a spell attack of yours scores a Critical or better on a creature (the spell attack is the casting check; a Warlock's innate attack too), you are asked whether to roar: yes gives advantage on your next Demoralise (Intimidate) check, applied by itself and spent, ending at the end of your next turn. **Dragon’s Breath** of your energy joins your repertoire with the Use (granted by the feat; a Warlock's is innate and Focus), and takes a new energy if you Use it again (0.10.0). ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("ELEMENTAL PACT", {
    flags: { ...SINCE, eaAutomation: "elementalPact" },
    automation: `${AUTO} **Use** chooses your element (air, earth, fire or water), kept on the feat: resistance to its energy (air electricity, earth acid, fire fire, water cold), and +1 damage per die on each damage pool of a spell of your element — a spell carrying the element's trait, or a pool of the mapped energy type, either counts, never twice (Q102, the per-die rows of C6). Not on recurring damage. **Elemental Strike** of your element's energy joins your repertoire with the Use (granted by the feat; a Warlock's is innate and Focus), and takes the new type if you Use it again (0.10.0). ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("FEY PACT", {
    grantedSpells: "Charm Kind",
    flags: { ...SINCE, eaAutomation: "pact" },
    effects: [
      (id, n) => classSkillEffect(id, n, ["Deception", "Diplomacy"], 2),
      declaredEffect("Save DC +1 (mental)", "The Save DC of a spell you cast with the mental trait is increased by 1.",
        { spellDCBonus: { label: "Fey Pact", value: 1, type: "untyped", traits: ["mental"] } })
    ],
    automation: `${AUTO} ${PACT_SPELL("Charm Kind")} +2 class to Deception and Diplomacy. A spell you cast with the Mental trait has its Save DC +1, your innate spells included (as printed: Charm Kind itself carries Emotion and Enchantment, not Mental). ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("GRAVE PACT", {
    grantedSpells: "Dead Tongue",
    flags: { ...SINCE, eaAutomation: "pact", conditionals: savesVsTraits("Grave Pact", 2, "class", ["soul"]) },
    effects: [declaredEffect("Save DC +1 (soul)", "The Save DC of a spell you cast with the soul trait is increased by 1.",
      { spellDCBonus: { label: "Grave Pact", value: 1, type: "untyped", traits: ["soul"] } })],
    automation: `${AUTO} ${PACT_SPELL("Dead Tongue")} +2 class to saves against an effect with the Soul trait (auto when the roll names it, a tick otherwise). A spell you cast with the Soul trait has its Save DC +1, your innate spells included. ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("VOID PACT", {
    grantedSpells: "Dark Tendrils",
    grantedAbilities: "Darkvision",
    flags: { ...SINCE, eaAutomation: "voidPact" },
    automation: `${AUTO} ${PACT_SPELL("Dark Tendrils")} The core's **Darkvision** is granted. If you already have Darkvision from anything else (now or later), the feat adds 30 ft to it (G13), and not to the copy it granted itself. When a creature's save against one of your spells is a Critical or better, you gain +2 circumstance to DB until the start of your next turn (1 round out of combat). ${ONE_PACT} ${PROGRESSION_LINE}`
  }),
  archetypeFeat("HEX WEAVER", {
    grantedFeats: "Familiar",
    flags: { ...SINCE, eaAutomation: "hexWeaver" },
    automation: `${AUTO} You are granted the core's **Familiar** feat (its Use makes the familiar). The Witch's hexes are opened to you: the core's Specialist Spell feat offers them, cast as specialist spells (Q103: opened, not granted). **Use** chooses one spell of the Ethereal or Verdant tradition, base PP no higher than your level + 1 (not a specialist spell, not one you know): it is added as a spell you know permanently, outside your picks and memorisation, carrying the Highmagic trait — cast with Spellcraft as High Magic (the Hard step, High Magic fumble and Resonance). Using it again replaces the pick. Your other spells are not made High Magic. ${PROGRESSION_LINE}`
  }),
  archetypeFeat("BLOODMAGE", {
    // "Con 2+" is the core's "Con +2" (audit, Minor); the card keeps the print.
    prerequisites: "Con +2, Level 2",
    flags: { ...SINCE, eaAutomation: "bloodmage" },
    automation: `${AUTO} When you cast a spell that costs PP (not a cantrip, innate, item or stored cast), you are asked how many of its PP to pay as Bleed (G2): up to all but 1, so the spell still costs you at least 1 PP; the cap and the Casting DC read the spell's full PP. The Bleed pays first as the degree spends (a Partial's smaller spend substitutes less), and you gain Bleeding equal to the PP it paid once the cast settles. If a cast that used the Bleed Fumbles, your Bleeding rises by 1 per 2 PP it was cast at (rounded down); a Blunder, by 1 per PP (Q105); a cast paid wholly from your pool gains nothing. The two Bloodmage hexes (Hemocovenant, Siphon Vitae) are opened to the core's Specialist Spell feat (Q21). The prerequisite "Con 2+" is read as Con +2. ${PROGRESSION_LINE}`
  }),
  archetypeFeat("HIGH MAGE", {
    // Note 11: the core's own shape for "the class skill this archetype granted".
    progression: "Gained class skill +10 ranks",
    flags: { eaAutomation: "highMage" },
    automation: `${AUTO} Not offered to a Sorcerer ("Non-Sorcerer", a registered check). **Use** chooses one Sorcerer birthright whose first key ability you have at +2 or more (Wild is not offered: it has no fixed spell, Q100), then one of its two birthright skills, which becomes a class skill. The birthright's specialist spell is added to your spells with the Highmagic trait, cast as High Magic. The pick counts as having that Birthright for the Sorcerer feats that ask for it (Blood of the Wyrm, Q100); a Dragon pick also asks your dragon type. You may take feats open to the Sorcerer (Adept). The progression line "Birthright skill +10 ranks" is read as the class skill this archetype granted at 10 ranks (the core's "Gained class skill"): until you have chosen it, no other archetype is offered. Using the Use again changes the pick.`
  }),
  archetypeFeat("BIRTHRAGER", {
    flags: { eaAutomation: "birthrager", castsWhileRaging: true },
    automation: `${AUTO} Offered only to a character with the Frenzy feat (BERSERKER). You become an instinctive caster, with a BSB of at least half your level rounded up (G11; a higher BSB is kept). **Use** chooses one Sorcerer birthright (not Wild, Q100): its specialist spell and its PP 0 cantrip are added to your spells, and if your sheet names no magical tradition the birthright's is set, so its first key ability is your magical ability and your PP pool is that tradition's (Q100). A Dragon pick also asks your dragon type, and the pick counts as that Birthright for the Sorcerer feats that ask for it. You may take feats open to the Sorcerer (Adept). While raging you may cast spells and sustain them (G10, Q104); other Concentrate actions stay barred. The specialist spell is not High Magic.`
  })
];

// Birthrager: "You become an instinctive caster" — the field a class declares
// (magic/caster-style.mjs, Enigma's precedent).
ARCHETYPES_B6_A.find((f) => f.name === "Birthrager").system.casterStyle = "instinctive";

/* ------------------------------------------------------------------ */
/* Blood of the Wyrm, and its class feats                               */
/* ------------------------------------------------------------------ */

export const WYRM_FEATS_B6_A = [
  archetypeFeat("BLOOD OF THE WYRM", {
    // Q100: the Dragon Birthright is checked by a registered eligibility (a
    // High Mage's or Birthrager's pick counts); the skill stays parsed.
    prerequisites: "Intimidate 2 ranks",
    flags: { ...SINCE, eaAutomation: "bloodOfTheWyrm" },
    automation: `${AUTO} Offered to a character with the Dragon Birthright (yours, or a High Mage's or Birthrager's Dragon pick, Q100) and Intimidate 2 ranks. You gain resistance to your dragon type's energy, laid when the feat arrives (its **Use** asks the dragon type if you have not chosen it). Your Draconic Infusion's claw damage gains one more d6 (after its 5d6 maximum), laid with the spell's own rider. The warp **+2 PP: the spell's damage type changes to your dragon type's** is offered on any damaging spell with the Elemental trait or an element or energy trait (Air, Earth, Fire, Water, Acid, Cold, Electricity, Sonic, Poison), once a cast; all its damage becomes that type (G15, Q106). ${PROGRESSION_LINE}`
  })
];

export const CLASS_FEATS_B6_A = [
  classFeat("SANGUINE CHANNEL", {
    flags: { eaAutomation: "sanguineChannel" },
    automation: `${AUTO} when you have drawn Bleed for a cast through Bloodmage, the casting prompt offers **Sanguine Channel** (not otherwise). Ticked, you choose +1 to the spell's attack (against DB only, never the casting check) or +1 to one target's Save DC (the one you name if several are targeted) (G14). When the cast settles, if the Bleed paid any of it, your Bleeding rises by 1 more (a refunded cast adds none).`
  }),
  classFeat("CRIMSON RITE", {
    flags: { eaAutomation: "crimsonRite" },
    automation: `${AUTO} While you are Bleeding, each damage die of your spells (and of a magical ability whose damage the core counts as yours, Q70) deals +1 circumstance (C6), laid and lifted with the condition. When a spell attack of yours is a Critical hit on a creature, that creature gains Bleeding 1 and your Bleeding rises by 1. **Use** (1 PP, a free action) suppresses your Bleed until the start of your next turn (1 round out of combat): no Bleeding damage, and no bonus while it lasts. Its value and its flat check are kept.`
  }),
  classFeat("DRACONIC CLAWS", {
    flags: { eaAutomation: "draconicClaws" },
    automation: `${AUTO} Strikes with your Dragon Claws deal 1d6 secondary damage of your dragon type's energy (Q107: the die the book no longer prints), resolved against the target's own resistance, whenever the claws are grown; it stacks with Draconic Infusion's. Laid when the feat arrives (its **Use** asks the dragon type if you have not chosen it). Only the Dragon birthright's claws (a weapon named Dragon Claws).`
  }),
  classFeat("ELEMENTAL EXHALATION", {
    flags: { eaAutomation: "elementalExhalation", compoundSkillPrerequisites: true },
    automation: `${AUTO} Offered with Arcana or Nature at 8 ranks (G9). **Use** (2 AP, 2 PP, its Focus use): target the creatures in your breath first — a 60-ft line for cave (acid) or light (electricity), a 30-ft cone for cold, fire, forest (poison) or sea (sonic) (Q107). Each takes 1d6 per two levels (rounded down) of your dragon type's energy, plus your per-die spell damage bonuses (Q70), with a basic Reflex save against your Level DC (it is not a spell, so spell DC bonuses do not reach it). Refocus or daily preparation restores the use.`
  }),
  classFeat("WYRM ASCENDANT", {
    flags: { eaAutomation: "wyrmAscendant", compoundSkillPrerequisites: true },
    automation: `${AUTO} Offered with Arcana or Nature at 12 ranks (G9). **Use** (1 AP: the book prints no action) spends its Focus use: a fly speed equal to your land speed for 10 minutes of world time. When it ends with your token in the air (elevation above 0) you fall, by the core's Falling from Height. Use it again to fold your wings early. Refocus or daily preparation restores the use.`
  })
];

export const FEATS_B6_A = [...ARCHETYPES_B6_A, ...WYRM_FEATS_B6_A, ...CLASS_FEATS_B6_A];

/**
 * The lead's `registerArchetype` options (Q100, the core's 13 Aug ruling:
 * "feats available to the Sorcerer (Adept) class" opens the list and the tier).
 */
export const ARCHETYPE_OPTIONS_B6_A = Object.freeze({
  "High Mage": Object.freeze({ classGrants: ["Sorcerer"], tierGrants: ["Adept"] }),
  Birthrager: Object.freeze({ classGrants: ["Sorcerer"], tierGrants: ["Adept"] })
});

/** The docs' table: A full, B automated with a normal choice, C partial, D descriptive. */
export const AUTOMATION_B6_A = Object.freeze({
  "Angelic Pact": { level: "A", what: "Sanctuary granted (Warlock innate Focus copy); +2 circ saves vs Fear/Soul (auto, tick); healingRider perPP 1 on Healing spells (G12, Q101); one Pact (Q92); +10 levels since taken (G8)." },
  "Demonic Pact": { level: "A", what: "Burning Hands granted; +2 class Intimidate; spellDamageRider perPP 1 fire (G12, Q101); one Pact; G8." },
  "Draconic Pact": { level: "B", what: "Use picks the energy: resistance; a Critical spell-attack hit asks for the roar (one-shot advantage on Demoralise to end of next turn). Dragon’s Breath of the energy granted by the Use (0.10.0); one Pact; G8." },
  "Elemental Pact": { level: "B", what: "Use picks the element: mapped resistance; +1 per die on element-trait or mapped-type pools, never twice (C6, Q102). Elemental Strike of the element granted by the Use (0.10.0); one Pact; G8." },
  "Fey Pact": { level: "A", what: "Charm Kind granted; +2 class Deception and Diplomacy; spellDCBonus +1 mental (innate too); one Pact; G8." },
  "Grave Pact": { level: "A", what: "Dead Tongue granted; +2 class saves vs Soul (auto, tick); spellDCBonus +1 soul; one Pact; G8." },
  "Void Pact": { level: "A", what: "Dark Tendrils and Darkvision granted; senseRangeBonus +30 ft synced only when Darkvision comes from elsewhere (G13); a Critical+ save vs your spell gives +2 circ DB to the start of your next turn; one Pact; G8." },
  "Hex Weaver": { level: "B", what: "Familiar granted; hexes opened to Specialist Spell (Q103); Use picks an Ethereal/Verdant spell (base PP ≤ level + 1) added with the Highmagic trait; G8." },
  "Bloodmage": { level: "B", what: "Cast PP source (G2): up to total − 1 PP paid as Bleed, Bleeding = PP it paid; Fumble +1 per 2 PP, Blunder +1 per PP on a cast that drew Bleed (Q105); Bloodmage hexes opened (Q21); prereq stored Con +2, Level 2; G8." },
  "High Mage": { level: "B", what: "Non-Sorcerer eligibility (G9); Use picks a birthright (first key ability +2, not Wild) and one of its two skills (class-skill grant); its specialist spell added with the Highmagic trait; counts as that Birthright (Q100); Sorcerer (Adept) feats opened; progression as Gained class skill +10 ranks." },
  "Birthrager": { level: "B", what: "Frenzy feat gate; instinctive (casterStyle); BSB floor ⌈level/2⌉ (G11); Use picks a birthright (not Wild): specialist spell and PP 0 cantrip, tradition set if blank (Q100); castsWhileRaging (G10, Q104); Sorcerer (Adept) feats opened." },
  "Blood of the Wyrm": { level: "B", what: "Dragon Birthright eligibility (own or borrowed, Q100); resistance to the dragon type's energy; +1 die on Draconic Infusion's claw rider (after the 5d6 cap, note 16); +2 PP warp turning the damage to the dragon type on elemental/energy-trait damaging spells (G15, Q106)." },
  "Sanguine Channel": { level: "B", what: "Cast option offered only when the cast-option ctx's ppSources show a Bloodmage draw: +1 attack (G14) or +1 one target's Save DC (saveDCTarget); +1 Bleed at settle when the Bleed paid." },
  "Crimson Rite": { level: "B", what: "C6 +1 circumstance per die while Bleeding (toggled effect); a Critical spell-attack hit gives the target Bleeding 1 and you +1; Use (1 PP) suppresses Bleed (bleedReduction) and the bonus to the start of your next turn." },
  "Draconic Claws": { level: "A", what: "Permanent strike rider on Dragon Claws: 1d6 secondary of the dragon type's energy (Q107), synced with the dragon type." },
  "Elemental Exhalation": { level: "B", what: "Compound prereq (G9); Use 2 AP, 2 PP, Focus: ⌊level/2⌋d6 of the dragon type + per-die bonuses (Q70), basic Reflex vs Level DC on the targeted creatures; line or cone by type (Q107)." },
  "Wyrm Ascendant": { level: "A", what: "Compound prereq (G9); Use 1 AP, Focus: fly speed = land speed for 10 minutes; falls if aloft when it ends." }
});
