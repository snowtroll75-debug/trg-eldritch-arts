/**
 * Eldritch Arts — Block 6 (0.9.0), group B1: Chapter 5's archetypes Eternal
 * Vigil, Fatespinner, Ferromancer, Leyline Weaver and Runeblade, and every
 * class feat whose stored trait names one of them (Steelbinding, FERROMANCER
 * METAMAGIC, is group D's). Book v1.6, ea.md L2980–4208.
 *
 * The spec is docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md, Appendix B, as Graham
 * answered it on 4 November 2026 (Q89–Q149 as proposed; one release), on
 * TRG Prime 3.684.0's seams as built (b6-contracts.md): G7 (the 0 HP moment:
 * Eternal Vigil, Last Horizon), G8 (progression: "cannot progress", "+10
 * levels", "Tradition skill +10 ranks"), G18 (Fate's Favour), G19 (Runeforge
 * Mastery), G22 (Ferromancer).
 *
 * Every feat is built with block6-common's `archetypeFeat` / `classFeat`, so
 * its card is the book's text followed by one paragraph saying exactly what
 * TRG Prime does with it. What is data lives here; the Uses, reactions and
 * hooks are module/block6b1-automations.mjs.
 *
 * Also built: the two sidebar abilities the archetypes grant (Foreseen Danger,
 * sidebar 10; Leyline Power, sidebar 11) and the two specialist spells
 * (Shard Cloud L8723 for the Ferromancer; Ley Walker L8437 for Leywalk,
 * EA-C7), from book-text.json, never retyped.
 */
import fs from "node:fs";
import { archetypeFeat, classFeat, note } from "./block6-common.mjs";
import { ability, changesEffect, declaredEffect, conditional } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { build } from "./block3-spells.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const printed = (lines) => md((lines ?? []).join("\n\n"));

/** Q109: Eternal Vigil's 0 HP Touch of Healing, once a day. */
export const VIGIL_DAILY = "1";
/** Eternal Vigil's "additional +2 bonus to your Death State" (stacks with Eternity Resilience's). */
export const VIGIL_DEATH_STATE = 2;
/** Chronostasis's guard: offered once a day, not against an outright kill. */
export const CHRONOSTASIS_GUARD = Object.freeze({ label: "Chronostasis", offer: true, askOwner: true, frequency: "daily", notOutright: true });
/** Fate's Favour, read literally (Q110): the point comes back on a Partial or worse, saves and skills, once a day. */
export const FATES_FAVOUR_REFUND = Object.freeze({ label: "Fate’s Favour", skills: [], degrees: ["partial", "failure", "fumble", "blunder"], checkTypes: ["save", "skill"], frequency: "daily" });
/** Ferromancer (Q112): the shards stand in for somatic and material on an arcane cast, a pouch use each. */
export const FERROMANCER_SOMATIC = Object.freeze({ traditions: ["arcane"], needsPouch: true, label: "Ferromancer" });
/** Leyline Weaver's "+2-circumstance bonus to Ley Sense and Tap Ley Line". */
export const LEYLINE_WEAVER_ACTIONS = Object.freeze(["leySense", "tapLeyLine"]);

/* ------------------------------------------------------------------ */
/* The two sidebar abilities                                            */
/* ------------------------------------------------------------------ */

const sidebar = (title) => {
  const s = BOOK.sidebars.find((x) => x.title === title);
  if (!s) throw new Error(`Block 6 B1: no sidebar "${title}"`);
  return s;
};
const traitWords = (line) => line.split(/\s+/).filter(Boolean).map((t) => t[0] + t.slice(1).toLowerCase()).join(", ");

/** An archetype's granted ability, its traits as the sidebar prints them (its second line). */
function sidebarAbility(title, name, automation, extra = {}) {
  const s = sidebar(title);
  const doc = ability({
    name, traits: traitWords(s.lines[1]),
    description: `${md(`**${s.lines[1]}**`)}\n${printed(s.lines.slice(2))}\n${note(automation)}`,
    flags: { eaBlock: 6, eaSidebar: s.n, ...(extra.flags ?? {}) }
  });
  doc.system.category = "Class";
  return doc;
}

export const FORESEEN_DANGER = sidebarAbility("FORESEEN DANGER", "Foreseen Danger",
  "*Automated (0.9.0, TRG Prime 3.684.0):* when an ally within 30 feet of you (not you) is about to roll an attack check, a saving throw or a skill check, and your reaction and this ability's Focus use are ready (not while you are blinded), you are asked (your player, else the GM; 30 seconds). Yes spends both, rolls 1d6 at once, and adds it to their check as an untyped bonus before their dice are rolled, as printed. *Not offered:* a casting check of a spell that is not an attack (the core asks reactions of attack checks, saves and skill checks only). **Use** turns the asking off or on for your character (it spends nothing). Destiny's Embrace spends this same Focus use. A Focus ability: one use, restored by Refocus or daily preparation.",
  { flags: { eaAutomation: "foreseenDanger" } });

export const LEYLINE_POWER = sidebarAbility("LEYLINE POWER", "Leyline Power",
  "*Automated (0.9.0):* when your Tap Ley Line comes out a Success or better, and your reaction and this ability's Focus use are ready, you are asked. Yes spends both and you regain 1d8 PP (2d8 on a Critical), capped at your maximum; it stacks with the Tap's own results and Ley Channeler's (EA-M25), and Confluence Master adds 1d8 when you tapped two lines. **Use** (while Leyline Anchor holds a line): Leyline Power without re-tapping, once a round — still your reaction and the Focus use (Q114). A Focus ability: one use, restored by Refocus or daily preparation.",
  { flags: { eaAutomation: "leylinePower" } });

export const ABILITIES_B6_B1 = [FORESEEN_DANGER, LEYLINE_POWER];

/* ------------------------------------------------------------------ */
/* The two specialist spells                                            */
/* ------------------------------------------------------------------ */

const SPECIALIST = new Map(BOOK.specialist.map((e) => [e.name, e]));
const specialistEntry = (name) => {
  const e = SPECIALIST.get(name);
  if (!e) throw new Error(`Block 6 B1: no specialist spell "${name}" in the book`);
  return e;
};

export const SHARD_CLOUD = build(specialistEntry("SHARD CLOUD"), {
  // The cloud bites at turn start and on entering, not at the cast: the cast
  // rolls nothing (module/block6b1-automations.mjs runs the bites).
  category: "utility", defence: "",
  // "2 AP (metal)": the metal shards are a material component (a pouch use).
  components: { somatic: false, verbal: false, material: true, focus: false },
  effects: [{ kind: "note", text: "Each round, a creature other than you that starts its turn within the shard aura, or enters it for the first time that round, takes 1d6 slashing damage (basic Reflex against your Spell DC). It bypasses non-magical DR. The shards follow you; you are unaffected." }],
  warpMods: [{ damageDice: "1d6" }, { areaGrowth: 5, areaMax: 30 }],
  text: "*Partly automated (0.9.0):* the cast rolls nothing. While you sustain the spell, each creature other than you whose turn starts within the cloud's radius of your token takes 1d6 slashing damage on a basic Reflex save against your Spell DC; in combat, a creature that moves into it takes the same, once a round. The +1 PP option adds 1d6 and the +2 PP option 5 feet of radius (to 30), each as many times as you buy it. A creature the cloud reaches only because you moved is not bitten until its turn starts (the GM's, if the table reads that as \"entering\"). The damage is a spell's, so magical; DR that is not \"non-magical\" is the GM's to judge. Ferromancer's pouch is the spell's (metal) component."
}, { specialist: true });

export const LEY_WALKER = build(specialistEntry("LEY WALKER"), {
  effects: [{ kind: "note", text: "Travel along the same ley line to a point you have visited and detected with Ley Sense, emerging in a safe space within 30 feet of it; at most 10 miles per caster level. Applied by the GM." }],
  warpMods: [{ extraTargets: 1 }, {}, {}],
  text: "*Partly automated (0.9.0):* the cast is refused unless a ley line on the map is within 30 feet of your token, or Leyline Anchor holds one for you (the GM's if you have no token). The journey itself — which point, how far (10 miles per caster level), the shifted or severed line — is the GM's; the +1 PP option adds a willing creature as a target, the other two options are the GM's."
}, { specialist: true });

export const SPELLS_B6_B1 = [SHARD_CLOUD, LEY_WALKER];

/* ------------------------------------------------------------------ */
/* The archetypes                                                       */
/* ------------------------------------------------------------------ */

export const ARCHETYPES_B6_B1 = [
  archetypeFeat("ETERNAL VIGIL", {
    // "Eternity Birthright" names no item: the birthright is the ability
    // "Eternity" (block3.mjs BIRTHRIGHT_NAMES), which the core's named-clause
    // check then gates. The card keeps the printed line.
    prerequisites: "Eternity, Medicine 2 ranks",
    usesPerDay: VIGIL_DAILY,
    flags: { eaAutomation: "eternalVigil" },
    effects: [(id, n) => changesEffect(id, `${n}: Death State +${VIGIL_DEATH_STATE}`, [{ key: "system.combat.deathState", mode: 2, value: String(VIGIL_DEATH_STATE), priority: 20 }], `Eternal Vigil: an additional +${VIGIL_DEATH_STATE} to Death State.`)],
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* +2 to your Death State, on top of Eternity Resilience's (+4 in all). **At 0 HP** (G7, Q109): once a day, when damage would take you to 0 HP (lethal or subdual; not a blow that kills outright), while you know Touch of Healing and have the PP to cast it, you are asked (your player, else the GM). Yes casts Touch of Healing on yourself as a free action — its check, PP and warps as normal — healing from 0, and spends the day's use only if the spell is cast; cancelled, refused or failed, the use is kept and you fall as normal. Above 0 HP afterwards, you neither fall nor gain Dying. Daily preparation restores the use. **The warp** (Q108): every spell with the Healing trait offers \"+2 PP (Eternal Vigil): fast healing 5\"; bought, each of the spell's targets (you, if none was targeted) gains fast healing 5 for as many rounds as the PP the spell was cast at, less these 2. *Progression:* \"cannot progress\" — no later archetype (G8, EA-M3)."
  }),
  archetypeFeat("FATESPINNER", {
    grantedAbilities: "Foreseen Danger",
    flags: { eaAutomation: "fatespinner", convictionPool: 1 },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* your conviction pool's maximum is 1 higher (the core's declared `convictionPool`; the point arrives with the feat). When one of your skill checks fails (Failure or Fumble; not a Blunder, and not when the d20 showed an unmodified 1) and you may spend a conviction point (one a round in combat), you are asked: yes spends it and the check is rerolled, and the second result stands (the core's rule for every reroll). *Granted:* Foreseen Danger. The DIVINER trait names no class and opens nothing. *Progression:* Sense Motive +10 ranks."
  }),
  archetypeFeat("FERROMANCER", {
    grantedSpells: "Shard Cloud",
    flags: { eaAutomation: "ferromancer", freeSomatic: { ...FERROMANCER_SOMATIC, traditions: [...FERROMANCER_SOMATIC.traditions] } },
    automation: "*Automated (TRG Prime 3.684.0, G22; Graham's Q112):* when you cast an arcane spell (your tradition and the spell's both arcane), your shards stand in for its somatic and material components: no free hand is needed, but an equipped material component pouch with a use is, and one use is spent each such cast (topping it up is the pouch's own uses and purchase). Not on a scroll's cast; a Sorcerer whose birthright tradition is not arcane gains nothing on those casts. *Granted:* the Shard Cloud specialist spell (its own card says what is automated). The prerequisite's Metal Lore Specialty skill is not checked by the picker (the GM's). *Progression:* Arcana & Crafting +10 ranks (both)."
  }),
  archetypeFeat("LEYLINE WEAVER", {
    grantedAbilities: "Leyline Power",
    flags: {
      eaAutomation: "leylineWeaver",
      conditionals: [conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Leyline Weaver", scope: "Ley Sense and Tap Ley Line (Power Manipulation)", auto: true, when: { actions: [...LEYLINE_WEAVER_ACTIONS] } })]
    },
    automation: "*Automated (0.9.0):* +2 circumstance to Ley Sense and Tap Ley Line, applied by itself (it stacks with Ley Scholar's; EA-M25). **Your Tap's results replace the action's:** a Critical rolls the Ley Line Effects table with every number in the result doubled (Q113: bonus, temporary HP, healing, PP, DB, DR; a result with no number, such as advantage, is gained once) until the end of your next turn, and you regain 1d8 PP; a Success rolls it until the end of your next turn; a Partial until the end of your current turn. Failure and Fumble are the action's own. A table result the system cannot apply says so on its card, as for anyone. *Granted:* Leyline Power. The prerequisite's \"any one tradition skill 2 ranks\" is not checked by the picker (the GM's). *Progression:* any one tradition skill (Arcana, Nature, Occultism or Religion) +10 ranks (G8, Q91)."
  }),
  archetypeFeat("RUNEBLADE", {
    // G8 (Q90): "+10 levels" is levels gained since the archetype was taken.
    flags: { eaAutomation: "runeblade", progressionSinceTaken: true },
    automation: "*Automated (0.9.0):* when the feat is added you are asked which Runeblade Rune goes into your Book of Infusions, beside Weapon Potency I (added too); Bane is not offered there, because the Book of Infusions (Block 4) keeps no creature kind — it is offered for the day's runes below. Each time you infuse a weapon (Infuse Weapon, at daily preparation) you are then asked for your Runeblade Rune — two with Twinflare Rune, three with Living Sigil — from Acidic I, Bane (its creature kind asked), Flaming I, Frost I, Returning, Shock I and Thundering I; they are added to that weapon's infused runes, outside your rune levels, for the day. **Use** chooses them again (or for the first time today). **Defending I is left off** (Q117): no such rune exists in TRG Prime or this book, until Graham names the one intended. *Progression:* +10 levels — ten levels gained since you took Runeblade (G8, Q90; a character who took it before 0.9.0 passes open)."
  })
];

/* ------------------------------------------------------------------ */
/* The class feats                                                      */
/* ------------------------------------------------------------------ */

export const CLASS_FEATS_B6_B1 = [
  classFeat("CHRONOSTASIS", {
    flags: { eaAutomation: "chronostasis" },
    effects: [declaredEffect("Chronostasis", "Chronostasis: once a day, instead of gaining Dying, hold at 1 HP until your next turn.", { deathGuard: { ...CHRONOSTASIS_GUARD } })],
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* once a day, when damage would take you to 0 HP (not a blow that kills outright), you are asked (your player, else the GM): yes holds you at 1 HP instead (the core's death guard). Until the start of your next turn you cannot be reduced below 1 HP and you have resistance to all damage. As your next turn starts, unless you have been healed above 1 HP, your HP becomes 0 and you gain Dying 1 as normal. Daily preparation restores the use. Removing the Chronostasis effect by hand ends it the same way."
  }),
  classFeat("CONFLUENCE MASTER", {
    flags: { eaAutomation: "confluenceMaster" },
    automation: "*Partly automated (0.9.0):* when you Tap Ley Line with two or more ley lines on the map within 30 feet of you, you are asked whether you tap both (that they overlap is the GM's call, as printed): yes gives the Tap Ley Line check advantage, and on a Success or better your Leyline Power, if you use it on that Tap, regains 1d8 PP more."
  }),
  classFeat("DAMAGING GAMBIT", {
    flags: { eaAutomation: "damagingGambit" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* when you cast a spell with an attack (its casting check is its attack) and you may spend a conviction point (one a round in combat), you are asked before the roll: yes spends it and the check has advantage — the one roll, so it helps the casting degree too (Q111)."
  }),
  classFeat("DESTINY’S EMBRACE", {
    flags: { eaAutomation: "destinysEmbrace" },
    automation: "*Automated (0.9.0):* when a creature that is not your ally hits one of your allies within 30 feet of you with an attack, and your reaction and Foreseen Danger's Focus use are ready, you are asked: yes spends both and the attacker rerolls; the second result stands (Q114: the Focus use is still spent). Not offered on a miss, nor for an attack on you."
  }),
  classFeat("FATE’S FAVOUR", {
    flags: { convictionRefund: { ...FATES_FAVOUR_REFUND, skills: [], degrees: [...FATES_FAVOUR_REFUND.degrees], checkTypes: [...FATES_FAVOUR_REFUND.checkTypes] } },
    automation: "*Automated (TRG Prime 3.684.0, G18; Graham's Q110, read literally):* the first time each day you spend a conviction point for advantage on a saving throw or a skill check, the point is not expended if the result is a Partial or worse; a Success or better spends it as normal. Either way that was the day's first time. Daily preparation renews it. Inner Tempest's like-worded Adaptive Mind is unchanged (Q110)."
  }),
  classFeat("IRON WARD", {
    flags: { eaAutomation: "ironWard" },
    automation: "*Automated (0.9.0):* **Use** (1 AP in combat; Manipulate, its trait asked of the core and recorded): +2 circumstance to DB until the start of your next turn (1 round out of combat). A Focus feat: one use, restored by Refocus or daily preparation."
  }),
  classFeat("LAST HORIZON", {
    flags: { eaAutomation: "lastHorizon" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G7):* when you gain the Dying condition and this feat's Focus use is ready (and you have not used it in the last minute), you are asked. Yes spends the use: you stay conscious while Dying, and the Dying check at the start of your next turn is not rolled — that turn you act normally. At the end of that turn, if you are still Dying, Dying acts as normal (you fall unconscious and the next checks are rolled). Healed above 0 HP before then, Dying ends as usual. A Focus feat: one use, restored by Refocus or daily preparation."
  }),
  classFeat("LEYLINE ANCHOR", {
    usesPerDay: "1",
    flags: { eaAutomation: "leylineAnchor" },
    automation: "*Partly automated (0.9.0):* once a day, when your Tap Ley Line succeeds (Success or better; M45), you are asked whether you anchor that line: yes spends the day's use and anchors it for 1 minute. While it is anchored, Leyline Power's **Use** regains 1d8 PP without re-tapping, once a round (still your reaction and its Focus use; Q114), and Ley Walker counts you within 30 feet of a ley line. *Not automated:* Tap and Channel Ley Line still offer only the lines within 30 feet of your token on the map; that the anchored line counts as within 30 feet for them is the GM's."
  }),
  classFeat("LEYWALK", {
    grantedSpells: "Ley Walker",
    flags: { eaAutomation: "leywalk" },
    automation: "*Automated (0.9.0):* *Granted:* the Ley Walker specialist spell (its own card says what is automated), and +2 status to the casting check whenever you cast it, applied by itself."
  }),
  classFeat("LIVING IRON", {
    flags: { eaAutomation: "livingIron" },
    automation: "*Automated (0.9.0):* while you have at least 2 PP, slashing and piercing damage that reaches you is resisted (halved) — asked of every blow by the core's damage reactions, read at that moment. Below 2 PP, nothing."
  }),
  classFeat("LIVING SIGIL", {
    flags: { eaAutomation: "livingSigil", eaRunebladeRunes: 3 },
    automation: "*Automated (0.9.0):* Runeblade asks for three Runeblade Runes each time you infuse a weapon, instead of two."
  }),
  classFeat("RUNEFORGE MASTERY", {
    flags: { eaAutomation: "runeforgeMastery" },
    automation: "*Automated (TRG Prime 3.684.0, G19):* the Runeblade Runes Runeblade adds to your infused weapon are declared to the core each time they are chosen: on your Strikes with that weapon, their damage ignores the target's resistance to its type, and an immunity to it counts as resistance instead. A category resistance (to all damage, to mundane damage) still applies. The weapon's other runes are not affected."
  }),
  classFeat("TEMPORAL REPRIEVE", {
    flags: { eaAutomation: "temporalReprieve" },
    automation: "*Automated (0.9.0; Graham's Q122):* **Use** (0 AP; Flourish and Open, as the core reads them): choose how many PP to expend — any number up to your level and your current PP — and you heal 1d8 HP for each. It provokes no reactions. A Focus feat: one use, restored by Refocus or daily preparation."
  }),
  classFeat("TWINFLARE RUNE", {
    flags: { eaAutomation: "twinflareRune", eaRunebladeRunes: 2 },
    automation: "*Automated (0.9.0):* Runeblade asks for two Runeblade Runes each time you infuse a weapon, instead of one."
  })
];

export const FEATS_B6_B1 = [...ARCHETYPES_B6_B1, ...CLASS_FEATS_B6_B1];

/** No archetype here needs more than its name registered (no class or tier grants). */
export const ARCHETYPE_OPTIONS_B6_B1 = Object.freeze({});

/**
 * The docs' table: what each feat does in 0.9.0. A full, B automated with a
 * normal choice, C partial (a clause is the GM's), D descriptive.
 */
export const AUTOMATION_B6_B1 = Object.freeze({
  "Eternal Vigil": { level: "B", what: "Death State +2 (stacks); once a day at 0 HP Touch of Healing cast on self as a free action from 0 (G7 offer, Q109; the use spent only on a real cast); a +2 PP Healing warp: fast healing 5 for (cast PP − 2) rounds on the targets (Q108); cannot progress (G8)." },
  "Fatespinner": { level: "B", what: "Conviction max +1 (convictionPool); a conviction point rerolls a failed skill check (not a Blunder, not a natural 1), asked after the roll; Foreseen Danger granted; Sense Motive +10 ranks." },
  "Ferromancer": { level: "B", what: "freeSomatic for arcane casts with the pouch spent (G22, Q112); Shard Cloud granted (C on its own card: the turn and entry bites are the module's)." },
  "Leyline Weaver": { level: "B", what: "+2 circumstance Ley Sense and Tap Ley Line; the replaced Tap ladder (Critical ×2 numbers + 1d8 PP, Success to end of next turn, Partial to end of turn; Q113) through Block 2's Tap branch; Leyline Power granted; Tradition skill +10 ranks (G8)." },
  "Runeblade": { level: "B", what: "Book gets Potency I + a chosen Runeblade Rune (not Bane: the book keeps no kind); 1/2/3 Runeblade Runes added to the day's infusion outside the budget (Bane asks its kind); Defending I left off (Q117); +10 levels since taken (G8)." },
  "Chronostasis": { level: "B", what: "Daily offered zero-HP guard (1 HP, not outright); then an auto guard and resist-all until your next turn starts; then HP 0 and Dying 1 unless healed." },
  "Confluence Master": { level: "B", what: "Two ley lines within 30 ft: asked to tap both (overlap the GM's) → advantage on the Tap; Leyline Power +1d8 on that Tap." },
  "Damaging Gambit": { level: "B", what: "Before a spell attack's check: a conviction point for advantage on the one roll (Q111)." },
  "Destiny’s Embrace": { level: "B", what: "An enemy's hit on an ally within 30 ft: reaction + Foreseen Danger's Focus use → the attacker rerolls (Q114)." },
  "Fate’s Favour": { level: "A", what: "convictionRefund: Partial or worse refunds, saves and skills, the first spend each day (G18, Q110 literal)." },
  "Iron Ward": { level: "A", what: "Use, 1 AP, Manipulate (traitGate), Focus: +2 circumstance DB until the start of your next turn." },
  "Last Horizon": { level: "B", what: "On gaining Dying (Focus, once a minute): conscious while Dying and the next Dying check waived, act normally (G7); Dying as normal from the end of that turn." },
  "Leyline Anchor": { level: "C", what: "1/day on a successful Tap: a 1-minute anchor; Leyline Power's Use once a round while anchored; Ley Walker's range. The Tap's own 30-ft line chooser is not extended (the GM's)." },
  "Leywalk": { level: "B", what: "Ley Walker granted (its card: Partly automated); +2 status on its casting check (spell-check gate)." },
  "Living Iron": { level: "A", what: "Damage reaction: resistance to slashing and piercing while PP ≥ 2." },
  "Living Sigil": { level: "A", what: "Runeblade asks for three Runeblade Runes." },
  "Runeforge Mastery": { level: "A", what: "runeDamageBypass on the infused weapon's Runeblade Runes, immunity as resistance (G19)." },
  "Temporal Reprieve": { level: "B", what: "Use, 0 AP, Flourish/Open, Focus: spend up to level PP, heal 1d8 per PP (Q122)." },
  "Twinflare Rune": { level: "A", what: "Runeblade asks for two Runeblade Runes." }
});

/** The two abilities and two spells, for the docs. */
export const AUTOMATION_B6_B1_EXTRA = Object.freeze({
  "Foreseen Danger": { level: "B", what: "Before an ally's attack, save or skill check within 30 ft: reaction + Focus → +1d6 untyped before the dice; Use toggles the asking." },
  "Leyline Power": { level: "B", what: "After a Tap Success+: reaction + Focus → 1d8 PP (2d8 Critical); anchored Use once a round." },
  "Shard Cloud": { level: "C", what: "Turn-start and entry bites (basic Reflex, 1d6 slashing, +1d6 / +5 ft warps) while sustained; entering because the caster moved is the GM's." },
  "Ley Walker": { level: "C", what: "Refused away from a ley line (30 ft or anchored); the journey is the GM's." }
});
