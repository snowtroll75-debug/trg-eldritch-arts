/**
 * Eldritch Arts — Block 6 (0.9.0), group B2: Appendix B's second half. The
 * archetypes Runebreaker, Shade Master, Spellwarden, Spell Duellist, Spell
 * Weaver and Stormcaller, and every Appendix B class feat that names one of
 * them (Glyph Shatter included; Lightning Rod and Thunderclap Aura are group
 * D's metamagic): 6 archetypes and 18 class feats, 24 in all.
 *
 * The spec is docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md, Appendix B, as Graham
 * answered it on 4 November 2026 (Q89: one release; Q90–Q149 as proposed),
 * on TRG Prime 3.684.0's seams as built (b6-contracts: G1, G4, G8, G9, G16,
 * G17, G20, G21). Every feat is built with block6-common.mjs's builders, so
 * its card is the book's text and then one paragraph saying what TRG Prime
 * does with it. The Uses, reactions and hooks are
 * module/block6b2-automations.mjs.
 *
 * ALSO HERE: the four abilities the archetypes grant (Fade Step, Counter
 * Channel and Spellstrike Riposte from sidebars 12–14; the Magical Reservoir
 * from Spell Weaver's own text) and the Stormcaller's burst Storm Bolt, a
 * variant spell (the audit's N9: no warp mod turns an attack into a save).
 *
 * Q91: Runebreaker, Shade Master and Stormcaller print no progression line;
 * ruled "no later archetype", as Eternal Vigil's "cannot progress", so that is
 * the stored line (G8 reads it) and the card keeps the print. Q90: Spell
 * Duellist's "+10 levels." opts in to G8 (`progressionSinceTaken`).
 */
import { archetypeFeat, classFeat, note } from "./block6-common.mjs";
import { ability, conditional, stableId } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { BLOCK3_SPECIALIST } from "./block3-spells.mjs";
import fs from "node:fs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const sidebar = (title) => {
  const s = BOOK.sidebars.find((x) => x.title === title);
  if (!s) throw new Error(`Block 6 B2: no sidebar "${title}"`);
  return s;
};

/** Q91 / Q90: the stored progression lines. */
export const NO_LATER_ARCHETYPE = "cannot progress";
/** Shade Master, Shadowmantle, Fade Step: "dim light or darkness", Q61's ambient light 5 or less. */
export const DIM_OR_LESS = Object.freeze({ max: 5 });
/** Light-gated lists, and the module's own flag keys the automations read. */
export const ABILITY_NAMES = Object.freeze({ fadeStep: "Fade Step", counterChannel: "Counter Channel", riposte: "Spellstrike Riposte", reservoir: "Magical Reservoir" });
export const STORM_BURST = "Storm Bolt (Burst)";

/* ------------------------------------------------------------------ */
/* The archetypes' abilities                                            */
/* ------------------------------------------------------------------ */

/** A sidebar's ability: its trait line, its action line and its text, then the automation paragraph. */
function sidebarAbility(title, name, automation, extra = {}) {
  const s = sidebar(title);
  const [, traitLine, ...rest] = s.lines;
  const item = ability({
    name,
    description: `${md(`**${traitLine}**`)}\n${md(rest.join("\n\n"))}\n${note(automation)}`,
    traits: traitLine.split(/\s+/).map((t) => t[0] + t.slice(1).toLowerCase()).join(", "),
    ...extra,
    flags: { eaBlock: 6, eaBookSidebar: s.n, ...(extra.flags ?? {}) }
  });
  // AN ARCHETYPE'S ABILITY files under the archetype feats (the core's sheet,
  // 3.586.3: Death Mark, Agile Display, Sense Weakness carry this category).
  item.system.category = "Archetype";
  return item;
}

export const FADE_STEP = sidebarAbility("FADE STEP", ABILITY_NAMES.fadeStep,
  "*Automated (0.9.0, TRG Prime 3.684.0):* press **Use** (1 AP) while the light where your token stands is 5 (Dim) or less (Q61's ambient light), and click where you land, up to 30 feet away. If the light where you land is above 5, your token is put back and nothing is spent (\"from one area of shadow to another\"). A Focus ability: one use, restored by Refocus or daily preparation. With **Eclipse Step** the Use also offers the free use once a round (Q114/m81: the Focus use is still spent; it must land in light 5 or less, Q120) and the once-a-day 120-foot step, which leaves you Concealed until the start of your next turn. With **Shadowmantle** you are asked once a day whether to take Hidden too; with **Grasping Shadows**, whether to spend 1 PP on the hands, within 10 feet of where you land (Q121). Unknown light (no token light data) is said on the card and left to the GM.");

export const COUNTER_CHANNEL = sidebarAbility("COUNTER CHANNEL", ABILITY_NAMES.counterChannel,
  "*Automated (0.9.0, TRG Prime 3.684.0, G17):* when a creature within 30 feet of you (60 with Improved Counter Channel) casts a spell that would land, you are asked (your player, else the GM; 30 seconds), while your reaction (none with Instinctive Counter Channel, once a round), this Focus use and 1 PP are ready. Not for an ally's spell unless you have pressed **Use** to turn allies on (Q118); Use again turns them off, spending nothing. Yes spends them and rolls Power Manipulation against the spell's Save DC (10 + its PP as cast + its caster's casting ability; an innate spell's own innate save DC), or its caster's Spell DC when it has no save (m79). Critical or better: the spell is stopped (with Reflective Warding you may turn it on its caster instead). Success: its area (to 5 ft), duration, number of targets and damage dice are halved, or, with none of those, its targets save with advantage (Q118). Fumble or worse: doubled, or disadvantage. Failure: it resolves normally.",
  { flags: { eaAutomation: "counterChannel" } });

export const SPELLSTRIKE_RIPOSTE = sidebarAbility("SPELLSTRIKE RIPOSTE", ABILITY_NAMES.riposte,
  "*Automated (0.9.0, TRG Prime 3.684.0):* when a creature misses you with a melee Strike, or with a Touch-range spell attack, from within your melee reach, you are asked while your reaction, this Focus use and 1 PP are ready (no PP once a round with Duellist's Supremacy, Q114: the Focus use is still spent). Yes: you choose one of your known damaging cantrips to channel (or none) and a melee weapon, and make a Strike at it that ignores the Multiple Attack Penalty; the reaction, Focus use and PP are spent once the Strike is made (a Strike the core refuses costs nothing). The cantrip is not cast: if the Strike hits, the cantrip's printed damage is added as secondary damage of its type (M26). Duellist's Focus adds its +1 (+2 against a spell attack); Duellist's Supremacy gives advantage against your Spellblade's Mark; Rippling Counter follows a critical hit. A reach weapon's reach is the core Strike's own check.",
  { flags: { eaAutomation: "spellstrikeRiposte" } });

export const MAGICAL_RESERVOIR = (() => {
  const f = BOOK.sections.archetypeFeats.find((x) => x.name === "SPELL WEAVER");
  const item = ability({
    name: ABILITY_NAMES.reservoir,
    usesPerDay: "intelligence",
    description: `${md(f.lines.join("\n\n"))}\n${note("*Automated (0.9.0, TRG Prime 3.684.0, G1):* the charges are this ability's daily uses: your Intelligence (at least 1: the module adds the use an Intelligence of 0 or less would leave out), with Deep Weave's +1 and Extra Reservoir's +2 (G21), restored at daily preparation. When you cast a learned or innate spell (Q94; never a cantrip, scroll, potion or stored spell), the Warp? dialog offers the three options (Spell Weaver), each 1 charge, one a cast: −2 PP off what you pay (to 0; payment only, Q93), every damage die one size up (the core's die step: not caster-level dice or a second pool; a healing warp's dice too), or ×1.5 duration, range or area (chosen; area rounded down to 5 ft). The charge is spent when the cast pays its PP (Q96).")}`
  });
  item.system.category = "Archetype";
  item.flags = { ...item.flags, "trg-prime": { ...(item.flags?.["trg-prime"] ?? {}), eaBlock: 6, eaAutomation: "magicalReservoir" } };
  return item;
})();

export const ABILITIES_B6_B2 = [FADE_STEP, COUNTER_CHANNEL, SPELLSTRIKE_RIPOSTE, MAGICAL_RESERVOIR];

/* ------------------------------------------------------------------ */
/* The Stormcaller's burst (a variant of Storm Bolt)                    */
/* ------------------------------------------------------------------ */

export const STORM_BOLT_BURST = (() => {
  const base = BLOCK3_SPECIALIST.find((s) => s.name === "Storm Bolt");
  if (!base) throw new Error("Block 6 B2: Block 3's Storm Bolt is missing");
  const doc = JSON.parse(JSON.stringify(base));
  doc._id = stableId(`spells:${STORM_BURST}`);
  doc.name = STORM_BURST;
  const st = BOOK.sections.archetypeFeats.find((x) => x.name === "STORMCALLER");
  Object.assign(doc.system, {
    category: "save", ppCost: 3, area: "10-foot radius", targets: "", defence: "basic Reflex",
    traits: "Elemental, Invocation, Save, Utility", warps: [],
    description: `${md(`**${st.lines[2]}**`)}\n${note("*The Stormcaller's warp, as a spell of its own* (the audit's N9: no warp turns an attack into a save): Storm Bolt with its +2 PP option taken, so it is cast at **3 PP** (1 + 2) — the Casting DC and the per-cast cap read 3 (Q93) — and the Stormcaller pays 1 less (2 PP, G4). *Automated (0.9.0, TRG Prime 3.684.0):* every creature in a 10-foot radius at a point within 30 feet rolls a basic Reflex save against 1d12 damage of the type you choose at the cast (cold, acid, fire or electricity; the GM's call by location, as Storm Bolt's). It is granted by the Stormcaller archetype, and it is not a spell known of its own.")}`
  });
  doc.flags = { ...(doc.flags ?? {}), "trg-prime": { ...(doc.flags?.["trg-prime"] ?? {}), eaVariantOf: "Storm Bolt", eaBlock: 6 } };
  return doc;
})();

export const SPELLS_B6_B2 = [STORM_BOLT_BURST];

/* ------------------------------------------------------------------ */
/* The archetypes                                                       */
/* ------------------------------------------------------------------ */

const ARCHETYPES = [
  archetypeFeat("RUNEBREAKER", {
    progression: NO_LATER_ARCHETYPE,
    flags: { eaAutomation: "runebreaker" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* **Dispel (Power Manipulation)** costs you 2 PP less, never below 1, by every route (the action, a counter, Disrupting Magic). **The absorb (G16, Q115):** when a creature casts a spell whose sole target is you, you are asked while your reaction is ready, Storing Rune is on your sheet and you have its 1 PP. Yes spends both and rolls your Will save against the caster's Spell DC; on a Success or better the spell is stopped and copied into your Storing Rune at the PP it was cast at (an innate spell's printed PP and warps), to be released with Storing Rune's own release (1 AP concentrate) as your casting (your check and DC; no PP moves). The caster's warps are not carried (the reaction does not see them): the card says so. Area and multi-target spells are not absorbed. *Gated (G9):* offered only to a Sorcerer whose birthright is Rune; *no later archetype* after it (Q91)."
  }),
  archetypeFeat("SHADE MASTER", {
    progression: NO_LATER_ARCHETYPE,
    grantedAbilities: ABILITY_NAMES.fadeStep,
    grantedSpells: "Dark Whispers",
    flags: { eaAutomation: "shadeMaster" },
    automation: "*Granted:* **Fade Step** (see its card) and **Dark Whispers**, cast as a specialist spell (its cap your level, its casting Very Easy). *Automated (0.9.0, TRG Prime 3.684.0):* that Dark Whispers is refused while the light where your token stands is above 5 (Q61); unknown light is the GM's. **Shadow Shift** gains a +3 PP option, the +5 PP hidden option less 2: on the cast you are Hidden until the start of your next turn (\"against the incoming attack\": remove it once the attack is resolved, as the concealed). *Gated (G9):* offered only to a Sorcerer whose birthright is Umbral; *no later archetype* after it (Q91). The Umbral birthright's own Dark Whispers, when it arrives, is unrestricted."
  }),
  archetypeFeat("SPELLWARDEN", {
    grantedAbilities: ABILITY_NAMES.counterChannel,
    flags: {
      eaAutomation: "spellwarden",
      conditionals: [conditional({ kind: "modifier", value: 2, type: "class", label: "Spellwarden", scope: "A saving throw against magic that is not a spell's (a spell's +2 is applied by itself — do not tick it then)", auto: false, when: { checkTypes: ["save"] } })]
    },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* +2 class to every saving throw a spell forces on you (another creature's spell, any tradition: the creature that forced the save holds a spell of that name), applied by itself before the dice. Against other magic (a magic item, a magical effect that is not a spell's save) it is a tick on the save's dialog. *Granted:* **Counter Channel** (see its card). Progression: Arcana +10 ranks (parsed by the core)."
  }),
  archetypeFeat("SPELL DUELLIST", {
    grantedAbilities: ABILITY_NAMES.riposte,
    flags: {
      progressionSinceTaken: true,
      eaAutomation: "spellDuellist",
      conditionals: [conditional({ kind: "modifier", value: 2, type: "class", label: "Spell Duellist", scope: "Spell Recognition (Identify Spells) checks", auto: true, when: { actions: ["spellRecognition"] } })]
    },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* +2 class to the core's Spell Recognition (identify a spell as it is cast), applied by itself. *Granted:* **Spellstrike Riposte** (see its card). Progression \"+10 levels.\": ten levels gained since you took this archetype (Q90, G8: the level is stamped when the feat is added; a character made before 0.9.0 passes open)."
  }),
  archetypeFeat("SPELL WEAVER", {
    grantedAbilities: ABILITY_NAMES.reservoir,
    flags: { eaAutomation: "spellWeaver" },
    automation: "*Granted:* the **Magical Reservoir** (its charges are its daily uses). *Automated (0.9.0, TRG Prime 3.684.0, G1):* its three options in the Warp? dialog, each for 1 charge, one a cast (the book's \"When you cast a spell, you may spend 1 charge to\"): −2 PP off what you pay (min 0; payment only, Q93), every damage die one step up, or duration, range or area ×1.5. Progression: Arcana +10 ranks (parsed by the core)."
  }),
  archetypeFeat("STORMCALLER", {
    progression: NO_LATER_ARCHETYPE,
    grantedSpells: STORM_BURST,
    flags: { eaAutomation: "stormcaller" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* **Gale Step** is 0 AP for you (the Use asks no AP). **Storm Bolt** costs you 1 PP less to pay (G4; the Casting DC, cap and save DC read its PP as cast, Q93; to 0, as no minimum is printed). *Granted:* the warp as **Storm Bolt (Burst)**, a variant spell cast at 3 PP (1 + 2), which you pay 2: a basic Reflex save in a 10-foot radius (the audit's N9). *Gated (G9):* offered only to a Sorcerer whose birthright is Storm; *no later archetype* after it (Q91)."
  })
];

/* ------------------------------------------------------------------ */
/* The class feats                                                      */
/* ------------------------------------------------------------------ */

const CLASS_FEATS = [
  classFeat("ABSOLUTE DENIAL", {
    flags: { eaAutomation: "absoluteDenial" },
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0):* while you are conscious and the aura is not suppressed, an enemy's spell (a hostile token's, Q28) cast at 8 PP or less as cast, warps included (Q119; an innate spell at its printed PP), is stopped and resolves as a failure when its caster stands within 20 feet of you, or one of its targets does. **Use** (0 AP, on your own turn in combat) suppresses or resumes the aura. *The GM's:* an area spell placed into the aura from outside it with no target inside (the cast does not yet know its area when it is asked)."
  }),
  classFeat("DEEP WEAVE", {
    flags: { eaAutomation: "deepWeave" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* the Magical Reservoir has 1 more charge a day (G21). When your spell attack critically hits, or you critically succeed (or better) on a saving throw a spell forces, you regain 1 charge, up to your maximum, once a round (once a minute of world time out of combat)."
  }),
  classFeat("DUELLIST’S FOCUS", {
    automation: "*Automated (0.9.0):* Spellstrike Riposte's Strike takes +1 circumstance, or +2 when the attack that missed you was a spell attack."
  }),
  classFeat("DUELLIST’S SUPREMACY", {
    automation: "*Automated (0.9.0):* once a round, Spellstrike Riposte costs no PP (still your reaction and its Focus use, Q114). When the creature that missed you is your Spellblade's Mark, the riposte's Strike has advantage (read off your Spellblade's Mark effect)."
  }),
  classFeat("ECLIPSE STEP", {
    flags: { eaAutomation: "eclipseStep" },
    automation: "*Automated (0.9.0):* Fade Step's Use offers **free (0 AP)** once a round, still spending its Focus use (Q114, m81), which must land in light 5 or less (Q120; ending your turn there is the GM's to police), and, once a day, a **120-foot** step from shadow to shadow, after which you are Concealed until the start of your next turn. The day's 120-foot step returns at daily preparation."
  }),
  classFeat("EXTRA RESERVOIR", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* the Magical Reservoir has 2 more charges a day (G21)."
  }),
  classFeat("EYE OF THE STORM", {
    usesPerDay: "1",
    flags: { eaAutomation: "eyeOfTheStorm" },
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0):* **Use** (once a day) expands the aura to 30 feet for 3 rounds: at the start of each of your turns, every enemy within 30 feet rolls a basic Reflex save against your Spell DC for 1d6 electricity per level, and you are immune to electricity while it lasts. Daily preparation restores the use. *The GM's:* the 10-foot aura's difficult terrain for enemies while you have 1 PP or more (no region follows a token; the card says when it is up)."
  }),
  classFeat("GLYPH SHATTER", {
    flags: { eaAutomation: "glyphShatter" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* after your Dispel (Power Manipulation) succeeds (Success or better; a counter that stops the spell), you are asked whether to fracture it: every creature within 10 feet of the dispelled effect (its caster's token for a counter, the target's for a Dispel on a creature) rolls a basic Reflex save against your Spell DC for 1d6 force per 2 PP of the dispelled spell or effect (its counteract value). You are then asked whether it was a ward or barrier: if so your next Dispel within 1 minute takes +1 circumstance, applied by itself and spent. Open to a core Runemage too (any of its traits)."
  }),
  classFeat("GRASPING SHADOWS", {
    flags: { eaAutomation: "graspingShadows" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* after you cast a spell with the Shadow trait (one that resolves), or after a Fade Step, you are asked whether to spend 1 PP on the hands, and which creature: within 10 feet of you for a spell, of where you landed for Fade Step (Q121). It rolls Reflex against your Spell DC: Critical, nothing; Success, Slowed 1; Failure or Partial, Immobilised (m42); Fumble or worse, Immobilised and a basic Fortitude save against 1d6 essence per 2 character levels. Each condition lasts until the end of its next turn (a round's clock)."
  }),
  classFeat("IMPROVED COUNTER CHANNEL", {
    automation: "*Automated (0.9.0):* Counter Channel is offered against casters within 60 feet."
  }),
  classFeat("INSTINCTIVE COUNTER CHANNEL", {
    automation: "*Automated (0.9.0):* Counter Channel is offered without your reaction, once a round (marked when used); its Focus use and 1 PP are still spent (Q114)."
  }),
  classFeat("OVERFLOW CASTING", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* while this feat's Focus use is ready, the Magical Reservoir's options are offered with no charges left. When the cast pays (Q96) and a charge is missing, the Focus use is spent and you take 2d6 per missing charge, ignoring your defences (the damage type is not printed, so it is untyped); if that leaves you at 0 HP or less, you gain 5 Soul Drain. Refocus or daily preparation restores the use."
  }),
  classFeat("REFLECTIVE WARDING", {
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0, G17):* on a Critical (or better) Counter Channel you are asked: negate the spell, or turn it back on its caster — its sole target, at its own DC. An area spell cannot be turned by the core: the card leaves its placement to the GM."
  }),
  classFeat("RIPPLING COUNTER", {
    automation: "*Automated (0.9.0):* when Spellstrike Riposte's Strike is a critical hit, a 5-foot Step is armed (drag your token; no AP, no reactions), and you are asked to make another melee Strike: no cantrip, your weapon's runes and traits as normal, at your own Multiple Attack Penalty."
  }),
  classFeat("RUNE REND", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* after Runebreaker absorbs a spell, you are asked whether to spend 1 PP: its caster rolls a basic Will save against your Spell DC for 1d6 force per 2 PP of the spell as its caster cast it."
  }),
  classFeat("RUNIC OVERLOAD", {
    flags: { eaAutomation: "runicOverload" },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G16):* releasing a spell from your Storing Rune offers **Overload** on the Casting Conditions prompt while this Focus use is ready. Taken, the released spell counts 2 PP higher (Q116; it buys no warp): its Save DC +2 and its Casting DC +3; once it has settled, every creature it hit (its spell attack) or made save rolls a basic Will save against your Spell DC for 1d6 force per 2 PP, and you roll a basic Fortitude save against your own Spell DC for the same backlash. The Focus use is spent; Refocus restores it. *Not reached:* a per-PP rider of the spell itself (a damage or healing rider that reads its PP) still reads its PP as stored — the core has no cast-option PP shift for a stored release."
  }),
  classFeat("SHADOWMANTLE", {
    flags: {
      eaAutomation: "shadowmantle",
      defenceDC: [{ dc: "defence", value: 1, type: "circumstance", label: "Shadowmantle", scope: "spell attacks, in light 5 or less", when: { attackKinds: ["spell"], lightLevels: { ...DIM_OR_LESS } } }]
    },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G20):* while the light where your token stands is 5 or less (Q61), +1 circumstance to your DB against spell attacks (a circumstance bonus: it does not stack with another circumstance bonus to your DB, and only the higher applies) and to the saving throws a spell forces on you (read as Spellwarden's: the creature that forced the save holds a spell of that name; a breath or a feat's area is not a spell). Once a day, Fade Step asks whether you also become Hidden until the start of your next turn; daily preparation restores it."
  }),
  classFeat("WELLSPRING CONDUIT", {
    automation: "*Automated (0.9.1, TRG Prime 3.684.1, G1):* while the Magical Reservoir has 0 charges and this feat's Focus use is ready, the Warp? dialog offers **Wellspring Conduit**: a damaging spell gains +1d6 per 2 PP expended in its casting (a new pool of its first damage type, on each creature it damages); a healing spell instead heals +1d6 per 2 PP. The PP are those the spell is cast at — its base (an innate spell's printed PP), the warps and every metamagic option taken, as Q101 reads them (Graham's ruling, 4 November 2026). Economic Spell and Signature Spell lower that figure (they lower what the spell is cast at); a PP discount from another feat or option (G4's) is taken off what you pay and does not. Its Focus use is spent when the cast pays (Q96)."
  })
];

export const FEATS_B6_B2 = [...ARCHETYPES, ...CLASS_FEATS];

/** The docs' table: A full · B with a normal choice · C partial · D descriptive. */
export const AUTOMATION_B6_B2 = Object.freeze({
  "Runebreaker": { level: "B", what: "Dispel −2 PP (min 1, registerDispelModifier); cast reaction on a spell whose sole target is you: reaction + Storing Rune's 1 PP, Will vs the caster's Spell DC, stopped and stored foreign (G16, Q115); Rune birthright gate (G9); no later archetype (Q91)." },
  "Shade Master": { level: "B", what: "Fade Step and Dark Whispers granted (specialist); Dark Whispers refused in light > 5; +3 PP Shadow Shift hidden warp; Umbral gate (G9); no later archetype (Q91)." },
  "Spellwarden": { level: "B", what: "+2 class on spell-forced saves (check reaction, before; the source must hold that spell); a ticked row for other magic; Counter Channel granted." },
  "Spell Duellist": { level: "A", what: "+2 class Spell Recognition (conditional on the action); Spellstrike Riposte granted; +10 levels opted in to G8 (Q90)." },
  "Spell Weaver": { level: "B", what: "Magical Reservoir granted (Int uses, floor 1); three G1 options paid in a charge, one a cast: −2 PP discount (floor 0), die step, ×1.5 duration/range/area." },
  "Stormcaller": { level: "B", what: "Gale Step at 0 AP (Block 3's Use replaced for owners); Storm Bolt −1 PP paid (G4, floor 0); the burst warp as a granted variant spell; Storm gate (G9); no later archetype (Q91)." },
  "Absolute Denial": { level: "C", what: "Cast reaction: an enemy's spell ≤ 8 PP as cast (Q119; ctx.castPP, so an innate spell's printed PP) with its caster or a target within 20 ft is stopped; Use toggles suppression; an area placed from outside is the GM's." },
  "Deep Weave": { level: "A", what: "+1 Reservoir use (G21); a critical spell attack hit or critical save against a spell regains 1 charge, once a round." },
  "Duellist’s Focus": { level: "A", what: "Riposte +1 circumstance, +2 against a spell attack." },
  "Duellist’s Supremacy": { level: "A", what: "Riposte without PP once a round (Focus still spent, Q114); advantage against your Spellblade's Mark." },
  "Eclipse Step": { level: "B", what: "Fade Step's free use once a round (Focus spent, Q114), landing in light ≤ 5 (Q120); 1/day 120 ft, then Concealed to the start of the next turn." },
  "Extra Reservoir": { level: "A", what: "+2 Reservoir uses (G21)." },
  "Eye of the Storm": { level: "C", what: "1/day Use: 30-ft expansion for 3 rounds, turn-start basic Reflex 1d6/level electricity on enemies, electricity immunity; the 10-ft difficult terrain is a card." },
  "Glyph Shatter": { level: "B", what: "Dispel onResult on Success+: asked; 10-ft basic Reflex, 1d6 force per 2 PP of the counteract value; ward/barrier asked → +1 circumstance to the next Dispel within 1 minute." },
  "Grasping Shadows": { level: "B", what: "After a Shadow spell or a Fade Step: 1 PP, a creature within 10 ft (Q121), Reflex ladder (Slowed 1 / Immobilised; Blunder + basic Fort 1d6 per 2 levels essence)." },
  "Improved Counter Channel": { level: "A", what: "Counter Channel at 60 ft." },
  "Instinctive Counter Channel": { level: "A", what: "Counter Channel without the reaction, once a round; Focus and PP still spent (Q114)." },
  "Overflow Casting": { level: "B", what: "Reservoir options offered at 0 charges while its Focus use is ready; 2d6 per missing charge ignoring defences, 5 Soul Drain at 0 HP or less." },
  "Reflective Warding": { level: "C", what: "On a Counter Channel Critical: negate or retargetCaster (G17); an area spell is the GM's." },
  "Rippling Counter": { level: "B", what: "After a critical riposte: a 5-ft Step armed and a second melee Strike asked (no cantrip)." },
  "Rune Rend": { level: "B", what: "After an absorb: 1 PP, the caster's basic Will vs your Spell DC, 1d6 force per 2 PP of the spell." },
  "Runic Overload": { level: "B", what: "A cast option on a stored release (G16 ctx.stored), Focus: Save DC +2 and Casting DC +3 (Q116); on settled, basic Will 1d6 force per 2 (PP+2) on the creatures hit or saving, and the basic Fortitude backlash on you. The spell's own per-PP riders are not shifted (no core seam for a stored release)." },
  "Shadowmantle": { level: "A", what: "Defence row +1 circumstance vs spell attacks in light ≤ 5 (G20; TRG Prime 3.684.1 stacks it by type); check reaction +1 circumstance on spell-forced saves in light ≤ 5; 1/day Hidden with Fade Step." },
  "Wellspring Conduit": { level: "B", what: "A G1 option at 0 charges, Focus: +1d6 per 2 PP as cast (ctx.castPP, TRG Prime 3.684.1: base + warps + metamagic; Graham, 4 Nov 2026) as an added damage pool, or healing dice." }
});
