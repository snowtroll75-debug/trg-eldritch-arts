/**
 * Block 10b (0.17.1, on TRG Prime 3.694.0): the sentient-item roll tables
 * (`ea-tables`, TB-004–006) and the rules reference journal (`ea-rules`, Q221).
 * THE TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`chapter9.tables`, `rulesPages`). Nothing is reworded; the tables are cut
 * apart from the printed grids, and the Senses table is rolled as a d8 (Q219).
 */
import fs from "node:fs";
import { stableId, SYSTEM_ID, MODULE_ID } from "./builders.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));

const STATS = Object.freeze({
  coreVersion: "14", systemId: SYSTEM_ID, systemVersion: "3.694.0",
  createdTime: 1789516800000, modifiedTime: 1789516800000, lastModifiedBy: null,
  compendiumSource: null, duplicateSource: null
});
const title = (s) => String(s).toLowerCase().replace(/(^|[\s/-])([a-z])/g, (m, a, b) => a + b.toUpperCase());
const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/** Inline markdown: bold, italics, superscripts kept. */
const inline = (s) => esc(s)
  .replace(/&lt;sup&gt;(.*?)&lt;\/sup&gt;/g, "<sup>$1</sup>")
  .replace(/\*\*([^*]+?)\*\*/g, "<strong>$1</strong>")
  .replace(/\*([^*]+?)\*/g, "<em>$1</em>");

/**
 * The book's markdown, as it occurs in these sections: "#"/"##"/"###"
 * headings, bold-only and all-capitals headings, "- " bullets, pipe tables
 * and paragraphs.
 */
export function bookHtml(lines) {
  const out = [];
  let list = null;
  let rows = null;
  const flush = () => {
    if (list) { out.push(`<ul>${list.map((l) => `<li>${inline(l)}</li>`).join("")}</ul>`); list = null; }
    if (rows) {
      const body = rows.filter((r) => !r.every((c) => /^:?-+:?$/.test(c)));
      out.push(`<table>${body.map((r, i) => `<tr>${r.map((c) => (i === 0 ? `<th>${inline(c)}</th>` : `<td>${inline(c)}</td>`)).join("")}</tr>`).join("")}</table>`);
      rows = null;
    }
  };
  for (const raw of lines) {
    const l = raw.trim();
    if (l.startsWith("|")) { if (list) flush(); rows ??= []; rows.push(l.replace(/^\||\|$/g, "").split("|").map((c) => c.trim())); continue; }
    if (rows) flush();
    // A blank line inside a list keeps it open (found in review): the book sets its bullets a blank line apart.
    if (!l || l === "<!-- -->") continue;
    if (/^- /.test(l)) { if (rows) flush(); list ??= []; list.push(l.slice(2)); continue; }
    flush();
    const h = /^(#{1,3})\s*(.*)$/.exec(l);
    if (h) { const text = h[2].replace(/\*\*/g, "").trim(); if (text) out.push(`<h${h[1].length + 1}>${inline(text)}</h${h[1].length + 1}>`); continue; }
    if (/^\*\*[^*]+\*\*$/.test(l) && /^[^a-z]+$/.test(l)) { out.push(`<h3>${inline(l.replace(/\*\*/g, ""))}</h3>`); continue; }
    if (/^[A-Z][A-Z0-9’' ,&()\-–.:]+$/.test(l) && l.length < 60) { out.push(`<h3>${inline(l)}</h3>`); continue; }
    out.push(`<p>${inline(l)}</p>`);
  }
  flush();
  return out.join("\n");
}

/* ------------------------------------------------------------------ */
/* The roll tables                                                      */
/* ------------------------------------------------------------------ */

const rangeOf = (s) => {
  const [a, b] = String(s).split(/[–-]/).map((x) => Number(x.trim()));
  return [a, Number.isFinite(b) ? b : a];
};

/** The printed tables, named for their contents; the d20 under the second "ALIGNED TRAIT" header is the quirks (audit §5.3). */
const NAMES = [
  ["ITEM TYPE", "d10", "Sentient Item: Item Type"],
  ["PERSONALITY", "d12", "Sentient Item: Personality"],
  ["MOTIVATION", "d12", "Sentient Item: Motivation"],
  ["ETHICS", "d100", "Sentient Item: Ethics"],
  ["COMMUNICATION", "d8", "Sentient Item: Communication"],
  ["SENSES", "d6", "Sentient Item: Senses"],
  ["SPECIAL POWERS", "d8", "Sentient Item: Special Powers"],
  ["ALIGNED TRAIT", "d8", "Sentient Item: Aligned Trait"],
  ["ALIGNED TRAIT", "d20", "Sentient Item: Quirks"]
];

/** Q219: the Senses table prints "d6" over eight entries; it is rolled as a d8. */
export const ROLLED_AS = Object.freeze({ "Sentient Item: Senses": "1d8" });

function rollTable(name, printedDie, column, rows, note = "") {
  const tid = stableId(`tables:${name}`);
  const formula = ROLLED_AS[name] ?? `1${printedDie}`;
  const top = Number(formula.replace(/^1d/, ""));
  const covered = rows.map((r) => rangeOf(r.range));
  // Every face is a result, once (a table that rolls into a gap shows nothing).
  for (let f = 1; f <= top; f += 1) if (covered.filter(([a, b]) => f >= a && f <= b).length !== 1) throw new Error(`Block 10b: ${name} covers face ${f} ${covered.filter(([a, b]) => f >= a && f <= b).length} times`);
  return {
    _id: tid, name, img: "icons/svg/d20-grey.svg",
    description: `<p>${esc(column)}, as printed in Eldritch Arts, Chapter 9 (Sentient Item Tables).${note ? ` ${esc(note)}` : ""}</p>`,
    formula, replacement: true, displayRoll: true,
    results: rows.map((r, i) => ({
      _id: stableId(`tables:${name}:${i}`), type: "text", name: r.text, description: "", img: "icons/svg/d20-black.svg",
      // Its faces (found in review): Foundry's "Normalize Results" rebuilds the ranges from the weights.
      weight: rangeOf(r.range)[1] - rangeOf(r.range)[0] + 1, range: rangeOf(r.range), drawn: false, flags: {}
    })),
    folder: null, sort: 0, ownership: { default: 0 }, flags: { [MODULE_ID]: { printedDie, line: rows[0]?.line ?? 0 } }, _stats: { ...STATS }
  };
}

const T = BOOK.chapter9.tables;
const printed = [...T.first, ...T.second];
if (printed.length !== NAMES.length) throw new Error(`Block 10b: ${printed.length} printed tables, expected ${NAMES.length}`);
export const SENTIENT_TABLES = printed.map((g, i) => {
  const [head, die, name] = NAMES[i];
  if (g.name !== head || g.die !== die) throw new Error(`Block 10b: table ${i} prints ${g.name} ${g.die}, expected ${head} ${die}`);
  const note = name === "Sentient Item: Senses" ? "Printed as a d6 over eight entries; rolled as a d8 (Q219)." : name === "Sentient Item: Quirks" ? "Printed under a second \"Aligned Trait\" header; its entries are quirks." : "";
  return rollTable(name, die, g.column, g.rows, note);
});

/** The mental arrays: a d8 whose result is a row of three modifiers and a note. */
export const MENTAL_ARRAYS = rollTable("Sentient Item: Mental Arrays", "d8", "Int, Wis and Cha modifiers",
  T.arrays.rows.map((r) => ({ line: r.line, range: r.cells[0], text: `Int +${r.cells[1]}, Wis +${r.cells[2]}, Cha +${r.cells[3]}. ${r.cells[4]}` })),
  T.arraysNote);

export const ALL_TABLES = [...SENTIENT_TABLES.slice(0, 6), MENTAL_ARRAYS, ...SENTIENT_TABLES.slice(6)];

/* ------------------------------------------------------------------ */
/* The rules reference journal                                          */
/* ------------------------------------------------------------------ */

/** Whether a page's first printed line renders as a heading (bookHtml's rules). */
export function opensWithHeading(lines) {
  const first = (lines ?? []).map((l) => l.trim()).find((l) => l && l !== "<!-- -->") ?? "";
  return /^#{1,3}\s*\S/.test(first) || (/^\*\*[^*]+\*\*$/.test(first) && /^[^a-z]+$/.test(first)) || (/^[A-Z][A-Z0-9’' ,&()\-–.:]+$/.test(first) && first.length < 60);
}

const link = (t) => `@UUID[Compendium.${MODULE_ID}.ea-tables.RollTable.${t._id}]{${t.name.replace(/^Sentient Item: /, "")}}`;

function designPage() {
  const rows = ALL_TABLES.map((t) => `<li>${link(t)} (${esc(ROLLED_AS[t.name] ?? `1${t.flags[MODULE_ID].printedDie}`)})</li>`).join("");
  return [
    `<p>${esc(T.intro[0])}</p>`,
    `<p>${esc(T.intro[1])}</p>`,
    `<ul>${rows}</ul>`,
    `<p>${esc(T.after)}</p>`,
    `<p>${esc(T.arraysNote)}</p>`,
    "<p><em>The tables are in the Eldritch Arts: Sentient Item Tables compendium. The Senses table is printed as a d6 over eight entries and is rolled as a d8 (Q219). The second table printed under \"Aligned Trait\" (d20) holds the quirks.</em></p>"
  ].join("\n");
}

const PAGE_NOTES = Object.freeze({
  "Wondrous Items & Relics": "Automated in Eldritch Arts 0.17.0: the Relic Bonding Ritual (a skill action), awakening at the daily preparation, the tier asked at Invest Item and its slots, and the four relics in the Relics & Sentient Items compendium.",
  "Sentient Items": "Automated in Eldritch Arts 0.17.0: two investment slots, the SENTIENT trait one-invested, and Dawnshield's Influence button (the GM's). Hidden powers and growth are the GM's."
});

function journal() {
  const pages = BOOK.rulesPages.map((p, i) => ({
    _id: stableId(`rules:${p.title}`), name: p.title, type: "text", sort: (i + 1) * 100000,
    // The book's own heading opens the page (0.17.2, found live): the page's title is not shown above it as well.
    title: { show: !opensWithHeading(p.lines), level: 1 },
    text: { format: 1, content: `${bookHtml(p.lines)}${PAGE_NOTES[p.title] ? `\n<p><em>${esc(PAGE_NOTES[p.title])}</em></p>` : ""}` },
    flags: { [MODULE_ID]: { line: p.line } }
  }));
  pages.splice(pages.findIndex((p) => p.name === "Sentient Items") + 1, 0, {
    _id: stableId("rules:Design a Sentient Item"), name: "Design a Sentient Item", type: "text", sort: 0,
    title: { show: true, level: 1 }, text: { format: 1, content: designPage() }, flags: { [MODULE_ID]: { line: T.line } }
  });
  pages.forEach((p, i) => { p.sort = (i + 1) * 100000; });
  return {
    _id: stableId("rules:Eldritch Arts Rules Reference"), name: "Eldritch Arts: Rules Reference",
    pages, folder: null, sort: 0, ownership: { default: 0 }, flags: {}, _stats: { ...STATS }
  };
}

export const RULES_JOURNAL = journal();

export const BLOCK10B_PACKS = [
  { name: "ea-tables", label: "Eldritch Arts: Sentient Item Tables", type: "RollTable", docs: ALL_TABLES },
  { name: "ea-rules", label: "Eldritch Arts: Rules Reference", type: "JournalEntry", docs: [RULES_JOURNAL] }
];
