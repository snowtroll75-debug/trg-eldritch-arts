#!/usr/bin/env python3
"""
extract-sidebars — the text boxes of the Eldritch Arts docx, which pandoc
drops, as ea-sidebars.md for extract-book.mjs.

    python3 -I tools/content/extract-sidebars.py <book.docx> <ea.md> > ea-sidebars.md

Each text box (w:txbxContent) is written once — Word stores a drawing twice,
as mc:Choice and mc:Fallback, and only the Choice copy is read — in document
order, headed "## SIDEBAR n: TITLE (after Lnnnn)", where Lnnnn is the ea.md
line of the last body paragraph before it. Its paragraphs follow, one per
line, as plain text. A box nested in another is read as part of its parent.
"""
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
MC = "http://schemas.openxmlformats.org/markup-compatibility/2006"
q = lambda ns, tag: f"{{{ns}}}{tag}"


def para_text(p):
    out = []
    for node in p.iter():
        if node.tag == q(W, "t") and node.text:
            out.append(node.text)
        elif node.tag == q(W, "tab"):
            out.append("\t")
        elif node.tag in (q(W, "br"), q(W, "cr")):
            out.append(" ")
    return re.sub(r"[ \t]+", " ", "".join(out)).strip()


def body_text(p):
    """A body paragraph's own text, leaving out any text box it anchors."""
    out = []

    def walk(node):
        if node.tag == q(W, "txbxContent") or node.tag == q(MC, "Fallback"):
            return
        if node.tag == q(W, "t") and node.text:
            out.append(node.text)
        for child in node:
            walk(child)

    walk(p)
    return re.sub(r"\s+", " ", "".join(out)).strip()


def boxes_in(p):
    """The text boxes a body paragraph anchors, each once (mc:Choice only)."""
    found = []

    def walk(node, in_fallback=False, in_box=False):
        if node.tag == q(MC, "Fallback"):
            return
        if node.tag == q(W, "txbxContent"):
            if not in_box:
                found.append(node)
            in_box = True
        for child in node:
            walk(child, in_fallback, in_box)

    walk(p)
    return found


def norm(s):
    s = re.sub(r"[*_`#>\\]", "", s)
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip().lower()


def main():
    docx, md = sys.argv[1], sys.argv[2]
    lines = [norm(l) for l in open(md, encoding="utf-8").read().split("\n")]
    with zipfile.ZipFile(docx) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    body = root.find(q(W, "body"))

    last_text = None
    cursor = 0
    n = 0
    out = ["# SIDEBARS (text boxes in the docx; pandoc does not export them)", "",
           "Each sidebar is placed by the line it follows in the body above.", ""]

    def locate(text):
        nonlocal cursor
        if not text:
            return None
        key = norm(text)[:80]
        # A short paragraph ("Critical", a table cell) matches anywhere; only
        # a phrase long enough to be the paragraph moves the cursor, and only
        # within the next 800 lines, so a phrase repeated in the index at the
        # back of the book cannot pull it there.
        if len(key) < 25:
            return None
        for i in range(cursor, min(len(lines), cursor + 800)):
            if key in lines[i]:
                cursor = i
                return i + 1
        # Never backwards: a phrase that recurs earlier in the book is not
        # where this paragraph is.
        return None

    after = None
    # Walk top-level blocks (paragraphs and tables) in order.
    def blocks(parent):
        for child in parent:
            if child.tag == q(W, "p"):
                yield child
            elif child.tag == q(W, "tbl"):
                for p in child.iter(q(W, "p")):
                    yield p
            elif child.tag == q(W, "sdt"):
                content = child.find(q(W, "sdtContent"))
                if content is not None:
                    yield from blocks(content)

    for p in blocks(body):
        for box in boxes_in(p):
            paras = [para_text(bp) for bp in box.iter(q(W, "p"))]
            paras = [t for t in paras if t]
            if not paras:
                continue
            n += 1
            title = paras[0]
            where = f" (after L{after})" if after else ""
            out.append(f"## SIDEBAR {n}: {title}{where}")
            out.append("")
            for t in paras:
                out.append(t)
                out.append("")
        own = body_text(p)
        if own:
            found = locate(own)
            if found:
                after = found
    sys.stdout.write("\n".join(out).rstrip() + "\n")


if __name__ == "__main__":
    main()
