/**
 * Block 9a (0.13.0, on TRG Prime 3.688.0): Chapter 6's 24 catalysts, as
 * consumables. THE PRINTED TEXT IS THE BOOK'S, read from
 * tools/content/book-text.json (its entry: flavour, Effect, Backlash; and its
 * row of the Catalysts table); the automation note says what the module
 * does with it (module/block9a-rules.mjs, module/block9a-automations.mjs).
 *
 * The special materials have no documents: they join TRG Prime's material
 * list (H20), and the core's item sheet shows them.
 */
import fs from "node:fs";
import { md } from "./markdown.mjs";
import { stableId, SYSTEM_ID, MODULE_ID } from "./builders.mjs";
import { CATALYSTS, catalystKey, CATALYST_FLAG } from "../../module/block9a-rules.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));

const STATS = Object.freeze({
  coreVersion: "14", systemId: SYSTEM_ID, systemVersion: "3.688.0",
  createdTime: 1785600000000, modifiedTime: 1785600000000, lastModifiedBy: null,
  compendiumSource: null, duplicateSource: null
});

const ON_FAIL = "Backlash on a Failure, Fumble or Blunder of the Spellcraft check";

/**
 * What the module does with each, beyond what every catalyst shares (the
 * offer, the spend, Affinity, Mastery and Conservation: COMMON below).
 */
export const CATALYST_NOTES = Object.freeze({
  arcanitePowder: { grade: "A", note: `Offered on an Arcane spell: advantage on its Spellcraft check. ${ON_FAIL}: −2 to Arcana checks for 1 hour (an effect, applied by itself).` },
  ashenLotusBloom: { grade: "A", note: `Offered on a damaging spell with the Essence or Fire trait: the cast's damage ignores resistance to its type. ${ON_FAIL}: Soul Drain 1 per PP of the spell.` },
  bloodEtchedVellum: { grade: "A", note: "Offered to a ritual's primary, before the ritual check (and on no other cast): +2 item to the ritual check. Consumed once the ritual is settled, whatever its degree and whether or not the spell is cast. Backlash on a Failure, Fumble or Blunder of the ritual check: Bleeding equal to the spell's PP as cast, at most 10 (Graham's Q202)." },
  celestialDewdrop: { grade: "B", note: `Offered on a damaging spell: +1d6 secondary essence damage per PP of the spell, rolled for each creature the spell damages and scaled by its save (or added on a hit); essence damage from the cast ignores resistance — the whole cast's, where the core cannot split one damage type from another. ${ON_FAIL}: Blinded for 1 minute.` },
  chainedObsidianBead: { grade: "A", note: `Offered on a spell attack: +2 item to the attack. ${ON_FAIL}: Immobilised until the end of your next turn.` },
  cindersOfTheFirstFlame: { grade: "A", note: `Offered on a spell with damage dice: they step up one size (a d12 stays a d12, Graham's Q188). ${ON_FAIL}: 1d6 recurring fire damage (Catalyst Affinity's cut taken from it).` },
  dragonboneDust: { grade: "A", note: "Offered on a spell with damage dice: one more die of the spell's own size. Backlash on a Fumble or Blunder only (the entry's own rule, M10): Weakened 1 for 1d4 rounds per PP of the spell." },
  eclipseResin: { grade: "C", note: `Its effect — disadvantage on attempts to identify the spell — is a line on the cast's card for the GM (the identifying check is another creature's). ${ON_FAIL}: 1d6 essence damage per 2 PP of the spell.` },
  frozenMarrowShard: { grade: "A", note: `Offered on a damaging spell whose damage type no warp has already changed: the damage becomes cold, and once the spell is cast you gain +1 DR until the end of your next turn (an effect). ${ON_FAIL}: 1d6 cold damage per 2 PP of the spell, and Slowed 1 for 1 round.` },
  glimmercoal: { grade: "A", note: `Offered on a damaging spell of 2 PP or more: +1d6 fire damage per 2 PP, rolled for each creature the spell damages and scaled by its save (or added on a hit). ${ON_FAIL}: 1d6 fire damage per 2 PP of the spell.` },
  graveSoil: { grade: "A", note: `Offered on an Essence spell with damage dice: one more die of the spell's own size. ${ON_FAIL}: Frightened 1 for 1d6 rounds, and −2 to Spellcraft checks for as long (one roll for both, each 1 round shorter with Catalyst Affinity).` },
  incenseOfStillness: { grade: "A", note: `Offered on any cast: advantage on its Spellcraft check. ${ON_FAIL}: disadvantage on Spellcraft checks for 1 minute (an effect).` },
  leydust: { grade: "A", note: `Offered on any cast: +2 item to its Spellcraft check. ${ON_FAIL}: 1d6 force damage per 2 PP of the spell.` },
  moonveilDust: { grade: "A", note: `Offered on a Shadow (illusion) or Enchantment spell with a save: +2 item to its Save DC (Graham, 13 November 2026: illusion is Shadow). ${ON_FAIL}: Dazzled for 1 minute.` },
  phoenixFeatherAsh: { grade: "A", note: `Offered on a Healing spell: +1d6 HP healed per PP of the spell. ${ON_FAIL}: 1d6 essence damage per PP of the spell.` },
  resonantCrystalShard: { grade: "A", note: `Offered on a spell of 2 PP or more (not a ritual variant, whose PP are substituted): you pay 1 PP less (at least 1); its Casting DC, cap and Save DC read the PP as cast (Graham's Q189). ${ON_FAIL}: 1d6 piercing and 1d6 force damage per 2 PP of the spell.` },
  sanctifiedMyrrh: { grade: "A", note: `Offered on a Divinity spell: advantage on its Spellcraft check. ${ON_FAIL}: −2 to Religion checks for 1 hour (an effect).` },
  sandsOfTheHourglass: { grade: "A", note: `Offered in combat: +1 AP this turn, given once the cast has settled. ${ON_FAIL}: Slowed 1 for 1d4 rounds (it costs its AP at the start of each of those turns).` },
  spellIncense: { grade: "A", note: `Offered on any cast: +1 item to its Spellcraft check. ${ON_FAIL}: −1 to Spellcraft checks for 1 minute (an effect).` },
  starpetalOil: { grade: "B", note: `Offered on a spell whose range is in feet or whose duration is timed (not the duration of a ritual claiming Duration unaltered): its range or its duration ×1.5 (asked when both could be). ${ON_FAIL}: a card — the spell takes effect on you instead of its target, at half strength (Graham's Q190); applying it is the GM's.` },
  stormglassPhial: { grade: "A", note: `Offered on a damaging spell: it gains the Electricity trait, and +1d6 secondary electricity damage per 2 PP, rolled for each creature the spell damages and scaled by its save (or added on a hit). ${ON_FAIL}: Stunned 3.` },
  verdantSap: { grade: "A", note: `Offered on a Verdant spell: advantage on its Spellcraft check. ${ON_FAIL}: −2 to Nature checks for 1 hour (an effect).` },
  voidAsh: { grade: "A", note: `Offered on a damaging spell whose damage type no warp has already changed: the damage becomes essence. ${ON_FAIL}: Soul Drain 1d4 per 2 PP of the spell.` },
  whisperglassShard: { grade: "A", note: `Offered on an Ethereal spell: advantage on its Spellcraft check. ${ON_FAIL}: Confused for 1d4 minutes.` }
});

const OFFER = "When you cast a spell, TRG Prime asks which catalyst to use (one per spell), offering only those that fit the spell; it is consumed whether the spell succeeds or fails (a cast called off and refunded spends nothing). Also offered to a ritual's primary, before the ritual check. Not offered on a cast from an item, a stored or threaded spell, an innate spell, a cast whose check is a Strike's roll, or a cantrip with no attack. A catalyst's added damage on a spell with neither an attack nor a save lands in full (no basic Reflex).";
const COMMON = "Catalyst Affinity (the backlash's HP damage, recurring damage and Bleeding included, −2 per level in all; Soul Drain unchanged; condition rounds −1 to at least 1; Stunned 3 → 2), Catalyst Mastery (no backlash on a Failure) and Catalyst Conservation (a DC 15 flat check to keep it; never on a Fumble or Blunder) are read by themselves. Backlash damage is applied to you, conditions with their clocks.";

const RARITY = { COMMON: "", UNCOMMON: "Uncommon", RARE: "Rare", UNIQUE: "Unique" };

function buildCatalyst(row) {
  const [name, cost, level, effect, backlash] = row.cells;
  const key = catalystKey(name);
  if (!key) throw new Error(`Block 9a: no catalyst rules for ${name}`);
  const notes = CATALYST_NOTES[key];
  if (!notes) throw new Error(`Block 9a: no automation note for ${name}`);
  const entry = BOOK.sections.catalystEntries.find((e) => e.name === name.toUpperCase());
  if (!entry) throw new Error(`Block 9a: no entry for ${name}`);
  const rarity = RARITY[entry.traits?.[0] ?? "COMMON"] ?? "";
  const printed = [
    md(`**${entry.name}** (${entry.traits.join(", ")})`),
    md(entry.lines.join("\n\n")),
    md(`**Effect:** ${entry.fields.Effect}`),
    md(`**Backlash:** ${entry.fields.Backlash}`),
    md(`*Table:* ${cost}, level ${level}. ${effect} *Backlash:* ${backlash.replace(/^--/, "−")}`),
    md(`*Automated (0.13.1, TRG Prime 3.688.1)${notes.grade === "C" ? " — in part" : ""}:* ${notes.note} ${key === "bloodEtchedVellum" ? "" : `${OFFER} `}${COMMON}`)
  ].join("\n");
  return {
    _id: stableId(`consumables:${name}`),
    name,
    img: "icons/svg/item-bag.svg",
    type: "consumable",
    system: {
      quantity: 1, weight: 0, price: Number(cost.replace(/[^\d.]/g, "")), equipped: false, invested: false,
      hp: { value: 0, max: 0 },
      traits: ["Consumable", rarity].filter(Boolean).join(" "),
      description: printed,
      uses: { value: 1, max: 1 },
      activation: "",
      itemLevel: Number(level)
    },
    effects: [],
    folder: null,
    sort: 0,
    ownership: { default: 0 },
    flags: {
      [SYSTEM_ID]: { consumable: { kind: "other" } },
      [MODULE_ID]: { [CATALYST_FLAG]: key }
    },
    _stats: { ...STATS }
  };
}

const ROWS = BOOK.sections.catalysts.rows.filter((r) => r.cells[0] && !["CATALYSTS", "Catalyst"].includes(r.cells[0]));
export const CATALYST_ITEMS = ROWS.map(buildCatalyst);

if (CATALYST_ITEMS.length !== Object.keys(CATALYSTS).length) throw new Error(`Block 9a: ${CATALYST_ITEMS.length} catalysts built, ${Object.keys(CATALYSTS).length} in the rules`);

export const BLOCK9A_PACKS = [
  { name: "ea-consumables", label: "Eldritch Arts: Consumables", extends: "consumables", docs: CATALYST_ITEMS }
];
