/**
 * Eldritch Arts — Block 11 (0.18.0): the Feat Additions.
 *
 *   Ten Artificer class feats   Modular Design, Advanced Design, Integrated
 *                               Modularity, Mechanised Assistant, Overclocked
 *                               Weaponry, Power Sink, Instability Harness,
 *                               Emergency Contraption, Flash of Insight,
 *                               Tinkerer Precision
 *   Three Runemage class feats  Runic Anchor, Triggered Sigil, Grand Inscription
 *   Four Ascendan racial feats  Ley Resonance, Arcane Preparation, Heritage of
 *                               the First Weave, Perfected Arcane Memory
 *   Supporting abilities        Quick Swap (granted by Integrated Modularity);
 *                               the Mechanised Assistant Frame and its three own
 *                               improvements (placed on the assistant, never
 *                               offered as feats)
 *
 * THE TEXT IS GRAHAM'S, CUT, NEVER RETYPED. tools/content/feat-additions.md is
 * pandoc's markdown of "TRG Prime Eldritch Arts Feat Additions — Exact Format";
 * `additionEntries` cuts it into entries here, and verify-block11 checks every
 * card's printed half against the same cut. A card is the printed traits,
 * fields, flavour and text, then one paragraph saying what TRG Prime does with
 * it (the Block 6 shape).
 *
 * NOTHING EXISTING IS REPLACED. The core's Artificer and Runemage archetypes
 * stay the core's (the class feats are gated on them by trait, as Block 6's
 * Runemage feats are); the five Runemage class feats v1.6 prints are Block 6's
 * and untouched. The Ascendan is the core's race: its racial feats name it in
 * `sourceRace`, as the core's own Ascendan feats do.
 *
 * Artwork: Eldritch Arts' own recolour of the core's category medallions
 * (assets/feats/), the convention Inner Tempest set with its own.
 */
import fs from "node:fs";
import { feat, ability, stableId } from "./builders.mjs";
import { md } from "./markdown.mjs";
import {
  USE_FEATS, FEATS, QUICK_SWAP, ASSISTANT_FRAME, ASSISTANT_ABILITIES, ASSISTANT_PROFILE, PREPARED_RECHARGE_AP, assistantBaseAbilities,
  PREPARED_RECHARGE_SECONDS, STORAGE_LBS
} from "../../module/block11-rules.mjs";

export const EA_FEAT_ART = Object.freeze({
  class: "modules/trg-eldritch-arts/assets/feats/class.png",
  racial: "modules/trg-eldritch-arts/assets/feats/racial.png",
  general: "modules/trg-eldritch-arts/assets/feats/general.png",
  archetype: "modules/trg-eldritch-arts/assets/feats/archetype.png"
});

const SOURCE_MD = fs.readFileSync(new URL("./feat-additions.md", import.meta.url), "utf8");

/** A heading line: capitals, digits, spaces, an em dash or hyphen. */
const isHeading = (l) => /^[A-Z][A-Z0-9 —–'-]+$/.test(l.trim()) && l.trim().length > 2;
/** A trait line: capital words only. */
const isTraitLine = (l) => /^[A-Z]+( [A-Z]+)*$/.test(l.trim());

/**
 * The document cut into entries: `{ name, traits, lines }` for each feat or
 * ability (a heading followed by its trait line), and the Prepared trait's own
 * entry ("PREPARED — TRAIT"). Sub-headings inside an entry (PROGRESSION, IF
 * DESTROYED, the COMPANION PROFILE, SPECIALTIES) stay in its lines, in bold.
 */
export function additionEntries(source = SOURCE_MD) {
  const lines = source.replace(/<!--[\s\S]*?-->/g, "").split("\n").map((l) => l.replace(/\s+$/, "").replace(/^>\s?/, ""));
  const nonBlank = (i) => { for (let j = i + 1; j < lines.length; j += 1) if (lines[j].trim()) return j; return -1; };
  const entries = [];
  let current = null;
  for (let i = 0; i < lines.length; i += 1) {
    const l = lines[i];
    if (!l.trim()) { if (current) current.lines.push(""); continue; }
    const next = nonBlank(i);
    if (isHeading(l) && next >= 0 && isTraitLine(lines[next]) && !isHeading(lines[next]) === false && lines[next].trim() !== l.trim()) {
      // A heading followed by a trait line opens an entry. (A trait line is
      // itself capitals, so `isHeading` is true of it too; the order decides.)
      current = { name: l.trim(), traits: lines[next].trim().split(/\s+/), lines: [] };
      entries.push(current);
      i = next;
      continue;
    }
    if (/^PREPARED — TRAIT$/.test(l.trim())) {
      current = { name: "PREPARED", traits: ["TRAIT"], lines: [] };
      entries.push(current);
      continue;
    }
    if (current) current.lines.push(isHeading(l) && !l.includes("**") ? `**${l.trim()}**` : l);
  }
  for (const e of entries) e.text = e.lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  return entries;
}

const ENTRIES = new Map(additionEntries().map((e) => [e.name, e]));

/** The printed entry, by its printed (capitals) name. */
export function additionEntry(key) {
  const e = ENTRIES.get(key);
  if (!e) throw new Error(`Block 11: the Feat Additions have no entry "${key}"`);
  return e;
}
export const additionNames = () => [...ENTRIES.keys()];

/** "MODULAR DESIGN" → "Modular Design"; "OF", "THE" lower-case inside. */
export function titleCase(name) {
  const small = new Set(["of", "the", "and", "a", "an", "to", "in", "on", "with"]);
  return String(name).toLowerCase().split(/\s+/).map((w, i) => (i > 0 && small.has(w) ? w : w.charAt(0).toUpperCase() + w.slice(1))).join(" ");
}

/** A printed field ("**Prerequisites** Crafting 4 ranks") read off the entry's text. */
export function printedField(entry, label) {
  const m = new RegExp(`\\*\\*${label}\\*\\*\\s*([^\\n;]+?)(?:;|\\n|$)`).exec(entry.text);
  return m ? m[1].trim() : "";
}

/** The card's printed half: traits as printed, then the text as printed. */
export function printedCard(entry) {
  return [md(`**${entry.traits.join(" ")}**`), md(entry.text)].join("\n");
}

const PREPARED_NOTE = (() => {
  const e = additionEntry("PREPARED");
  return md(`**PREPARED (trait)** ${e.text}`);
})();

/** Stored traits: the printed words less CLASS (the category says it) and less the race (its `sourceRace` says it). */
function storedTraits(entry, drop = []) {
  const skip = new Set(["CLASS", ...drop]);
  return entry.traits.filter((t) => !skip.has(t)).map((t) => titleCase(t)).join(", ");
}

const AUTOMATION = Object.freeze({
  [FEATS.modular]: "*Automated (0.18.0, TRG Prime 3.713.0; audit A11-1, A11-11):* daily preparation clears yesterday's upgrades and asks for today's. **Use** applies them: pick a weapon or armour you are proficient with, a shield, or a tool (gear), and its bonus. Armour and shields: +1 item bonus to DB or DR, an effect on that item that counts only while it is equipped and not broken. Tools: +1 item bonus to one skill, pre-ticked on that skill's checks only while the tool is held. Weapons: +1 item bonus to that weapon's attack rolls or damage, through the core's weapon-enhancement seam — that weapon only, never another. Item bonuses do not stack (the higher applies). The upgrade ends at your next daily preparation, or when the item breaks (it stops counting) or leaves your inventory (it is gone). On a core older than 3.713.0 a weapon upgrade is recorded and printed, and the GM applies it.",
  [FEATS.advanced]: "*Automated (0.18.2; Graham's ruling A11-1 — the printed \"+1 bonus to items\" was a typo for \"+1 bonus to two items\"):* Modular Design's Use allows +2 in all — +1 on each of two items, or +2 on one item — one bonus per item. **Use** (once a day, out of combat, 10 minutes) moves one upgrade to another eligible item: the old effect is removed before the new one is placed, so the bonus is never doubled.",
  [FEATS.integrated]: "*Automated (0.18.2; Graham's ruling A11-2):* Modular Design's Use allows any combination of +3 — three +1s, a +2 and a +1, or a +3 — and an item's share may be split between its two bonuses (a weapon's attack and damage, armour's DB and DR) or put on one. You also gain **Quick Swap** (granted, not a feat): its own Use moves an upgrade between two items you are wielding or wearing for 2 AP, a Prepared ability.",
  [FEATS.assistant]: "*Automated with GM steps (0.18.0, TRG Prime 3.713.0; audit A11-7, A11-8, A11-13):* **Use** builds the assistant through the core's familiar machinery (a linked familiar actor that mirrors your level, saves, BAB, BDB and skills) and then applies the printed profile through its **Mechanised Assistant Frame**: Small, speed 20, Darkvision, its ability scores, Base DR 2, the Slam (Small) in place of the familiar's Bite, Crafting and Perception as class skills, hands. You choose its specialty once: Tool Armature (+2 item to your Crafting while it is adjacent — kept on and off as tokens move), Injector Limb, Scout Optics (a sense of your choice) or Spell Relay Node (offered at the cast of a line or area spell when it is within 60 ft and in sight). Scout Optics also makes Survival a class skill (Graham's ruling: the printed Tracking is Survival). At 4th level and every 4 levels you choose an improvement from the printed list; it takes no other familiar abilities, and nothing else may add one to it (Graham's ruling A11-8). Magical healing is refused on it; repair it with Crafting. **Use** again rebuilds it after 8 hours of work, paying the Core Rulebook's Equipment Cost Table (p. 173) for your level from your purse (Graham's ruling A11-7). Its DB is worked out as any familiar's (10 + its Dexterity + your BDB) and its Base DR 2 scales as a familiar's does. Ordinary familiars and animal companions are not touched.",
  [FEATS.overclock]: "*Automated (0.18.0, TRG Prime 3.713.0; audit A11-12):* **Use** (out of combat, 1 minute) overclocks one weapon you are proficient with and say you crafted or modified: Plasma Edge (1d4 acid, fire or electricity, resolved as a rune's secondary packet against the target's defences), Gyroscopic Repeater (that weapon's reload costs 1 AP less, never below 0; offered only on a weapon that reloads) or Impact Amplifier (+1 damage, untyped). One weapon at a time; it lasts until your next daily preparation. On a core older than 3.713.0 the choice is recorded and printed, and the GM applies it.",
  [FEATS.powerSink]: "*Automated (0.18.0; audit A11-5, A11-14):* when you or an ally within 30 ft fails (a Failure) a saving throw against a magical effect, you are asked: your reaction and Power Sink's Prepared use redirect it into a magical item you hold or wear, which is **overloaded** until the end of your next turn (its effects stop counting; its own use buttons and its runes' bonuses are not stopped — the core has no seam for that), and the save is rerolled — the second result stands, even if worse. When a Resonance Event is due for you or an ally within 30 ft, you are asked the same: yes redirects the event into the item and it is not rolled. The item is never destroyed or discharged.",
  [FEATS.harness]: "*Automated (0.18.0):* Power Sink is also offered on a saving throw that Fumbles or Blunders. Everything else about Power Sink is unchanged.",
  [FEATS.contraption]: "*Automated with GM steps (0.18.0; audit A11-10):* when you or an ally fails a Disable Device check, you are asked: your reaction and the Prepared use give a reroll with a +2 item bonus on that reroll only (item bonuses do not stack); the second result stands. A trap that springs without a failed check to reroll is not reversed: Use posts the contraption for the GM, who decides what it changes.",
  [FEATS.insight]: "*Automated with GM steps (0.18.2; Graham's rulings A11-3, A11-4):* when you or an ally within 30 ft Fails or Fumbles a skill check or saving throw, you are asked (a free action). You describe your inventive help — it is posted for the GM — and the roll's die becomes a natural 20, open-ended as the core rolls it (so the chain continues), with the same modifiers. Once a day; it is not a Prepared ability and has no recharge.",
  [FEATS.tinkerer]: "*Automated (0.18.0, TRG Prime 3.713.0):* a Create project's daily work is priced at your Crafting ranks +2, and the value it must reach is 75% of the item's (rounded up). The check, its DC and the gold the materials cost are unchanged, and no other Crafting check gains ranks. On a core older than 3.713.0 the time is not changed: the GM applies it by hand.",
  [FEATS.anchor]: "*Automated (0.18.0):* every spell you cast with a Symbol is remembered for a day. When you make a Spell Concentration check and such a spell is still yours to retain, sustain or recover, you are asked which spell the check is for: a Symbol-cast spell gains +2 class; any other gains nothing.",
  [FEATS.triggered]: "*Automated with a manual trigger (0.18.2; Graham's ruling A11-9):* during your daily preparation — once today's Prepared Sigils are inscribed, and before you cast a spell, enter combat or an hour passes — **Use** designates one as triggered: a spell of 2 AP or less that can target you or a creature, and a trigger. Being struck and becoming the target of an attack are detected, and you are asked; falling, entering fire and any other trigger are activated from the Use when they happen. Activation is your reaction and the sigil's cast — the spell's PP, range, line of sight and targets as normal — and respects the one-sigil-a-round rule. The sigil then fades as any sigil does (Living Script may reform it as a plain Prepared Sigil). An unused designation ends at your next daily preparation.",
  [FEATS.grand]: "*Automated (0.18.0):* when you cast with the Symbol component, the cast adds one more to the Save DC so the Runemage's +1 becomes +2 (one labelled part; never +1 and +2). The Runemage's queued +2 class bonus to identify runic symbols is rewritten to +4 while you hold this feat, and back to +2 if you retrain it. Casting DC, Defensive Casting and components are unchanged.",
  [FEATS.leyResonance]: "*Automated (0.18.0):* while you are within 60 ft of a ley line or are gaining a ley line's benefit (linked), the Warp? dialog of your spell offers **Ley Resonance**: pay 1 PP less (2 with Perfected Arcane Memory; never below 1 PP), and the Casting DC falls to match; the Save DC is read from the PP as cast and does not change. A Focus use, spent when the cast pays.",
  [FEATS.arcanePrep]: "*Automated (0.18.0):* **Use** (1 AP in combat) picks an arcane or ethereal spell you know. Your next Spellcraft check to cast it gains +2 circumstance, once. The preparation ends when you cast another spell, fall unconscious or reach the end of your next turn without casting it.",
  [FEATS.firstWeave]: "*Automated (0.18.0):* before you roll a saving throw against a divine or verdant effect you are asked: your reaction and the Focus use give +2 circumstance to that save. Forbidden Magic's penalty, and its requirement to resist beneficial divine and verdant magic, are untouched. Refocus restores the use.",
  [FEATS.memory]: "*Automated with GM steps (0.18.0):* Ley Resonance's reduction becomes 2 PP. Arcane and ethereal spells that end are recorded (name, tradition, when cast, when ended, where cast). **Use** examines the traces still readable (ended within 24 hours): the GM confirms which trace is present and sets the normal identification DC; +5 is added, and you roll Arcana or Occultism. A Success names the spell and its tradition; a Critical also gives roughly how long ago it was cast and the direction of its origin when that was recorded. The caster is never named."
});

/** One Artificer class feat. */
function artificerFeat(key, { usesPerDay = "", grantedAbilities = "", flags = {} } = {}) {
  const e = additionEntry(key);
  const name = titleCase(key);
  const prepared = e.traits.includes("PREPARED");
  return feat({
    name, category: "Class",
    prerequisites: printedField(e, "Prerequisites"),
    traits: storedTraits(e),
    usesPerDay, grantedAbilities,
    description: `${printedCard(e)}${prepared ? `\n${PREPARED_NOTE}` : ""}\n${md(AUTOMATION[name])}`,
    flags: { ...flags, eaBlock: 11, eaSource: "Feat Additions", ...(USE_FEATS.includes(name) ? { eaAutomation: true } : {}) },
    img: EA_FEAT_ART.class
  });
}

/** One Runemage class feat. */
function runemageFeat(key, { flags = {} } = {}) {
  const e = additionEntry(key);
  const name = titleCase(key);
  return feat({
    name, category: "Class",
    prerequisites: printedField(e, "Prerequisites"),
    traits: storedTraits(e),
    description: `${printedCard(e)}\n${md(AUTOMATION[name])}`,
    flags: { ...flags, eaBlock: 11, eaSource: "Feat Additions", ...(USE_FEATS.includes(name) ? { eaAutomation: true } : {}) },
    img: EA_FEAT_ART.class
  });
}

/** One Ascendan racial feat (the core's race: `sourceRace`, as its own racial feats carry it). */
function ascendanFeat(key, { usesPerDay = "" } = {}) {
  const e = additionEntry(key);
  const name = titleCase(key);
  return feat({
    name, category: "Racial",
    prerequisites: printedField(e, "Prerequisites"),
    traits: storedTraits(e, ["ASCENDAN"]),
    sourceRace: "Ascendan",
    usesPerDay,
    description: `${printedCard(e)}\n${md(AUTOMATION[name])}`,
    flags: { eaBlock: 11, eaSource: "Feat Additions", ...(USE_FEATS.includes(name) ? { eaAutomation: true } : {}) },
    img: EA_FEAT_ART.racial
  });
}

export const FEATS_B11 = Object.freeze([
  artificerFeat("MODULAR DESIGN"),
  artificerFeat("ADVANCED DESIGN"),
  artificerFeat("INTEGRATED MODULARITY", { grantedAbilities: QUICK_SWAP }),
  artificerFeat("MECHANISED ASSISTANT"),
  artificerFeat("OVERCLOCKED WEAPONRY"),
  artificerFeat("POWER SINK"),
  artificerFeat("INSTABILITY HARNESS"),
  artificerFeat("EMERGENCY CONTRAPTION"),
  // "Once per day", and not Prepared (Graham's ruling A11-3, 25 Nov 2026).
  artificerFeat("FLASH OF INSIGHT", { usesPerDay: "1" }),
  artificerFeat("TINKERER PRECISION"),
  runemageFeat("RUNIC ANCHOR"),
  runemageFeat("TRIGGERED SIGIL"),
  runemageFeat("GRAND INSCRIPTION"),
  // FOCUS feats: one use a day, which Refocus restores (the core's Focus path).
  ascendanFeat("LEY RESONANCE", { usesPerDay: "1" }),
  ascendanFeat("ARCANE PREPARATION"),
  ascendanFeat("HERITAGE OF THE FIRST WEAVE", { usesPerDay: "1" }),
  ascendanFeat("PERFECTED ARCANE MEMORY")
]);

/** An ability shaped as a class ability (category "Class"), with the Eldritch Arts art. */
function classAbilityItem({ name, description, traits = "", flags = {}, effects = [] }) {
  const item = ability({ name, description, traits, flags, effects, img: EA_FEAT_ART.class });
  item.system.category = "Class";
  return item;
}

/** Quick Swap: granted by Integrated Modularity, never a selectable feat. */
export const QUICK_SWAP_ABILITY = (() => {
  const e = additionEntry("QUICK SWAP");
  return classAbilityItem({
    name: QUICK_SWAP,
    traits: storedTraits(e),
    description: `${printedCard(e)}\n${PREPARED_NOTE}\n${md(`*Automated (0.18.0):* **Use** (${2} AP in combat) moves one modular upgrade from an item you wield or wear to another eligible item you wield or wear — the old bonus is removed before the new one is placed. A Prepared ability: expended on use; **Use** offers the ${PREPARED_RECHARGE_AP} AP Crafting recharge (level DC), and it recharges by itself ${PREPARED_RECHARGE_SECONDS / 60} minutes after it was spent.`)}`,
    flags: { eaBlock: 11, eaSource: "Feat Additions", grantedBy: FEATS.integrated }
  });
})();

/**
 * THE MECHANISED ASSISTANT'S FRAME: the printed companion profile, placed on
 * the assistant (a familiar actor) by the feat's Use. Its effects carry what an
 * effect can carry and it declares the class skills; the Use writes the size and the attack.
 */
export const ASSISTANT_FRAME_ABILITY = (() => {
  const e = additionEntry("MECHANISED ASSISTANT");
  const profile = e.text.slice(e.text.indexOf("**MECHANISED ASSISTANT — COMPANION PROFILE**"));
  const id = stableId(`abilities:${ASSISTANT_FRAME}`);
  const p = ASSISTANT_PROFILE;
  return classAbilityItem({
    name: ASSISTANT_FRAME,
    traits: "Construct",
    description: `${md(profile.split("**SPECIALTIES**")[0])}\n${md("*Automated (0.18.0): placed on the assistant by Mechanised Assistant's Use. Its size, ability scores, speed and Base DR are this ability's effect (over the familiar stat block's); Darkvision replaces Nightvision, the Slam (Small) replaces the Bite when it is built, and Crafting and Perception are class skills while it carries this frame. Magical healing is refused while it carries this frame.*")}`,
    // classSkills (0.18.1, found live): the core derives a familiar's class skills,
    // so they are declared here (class-skills.mjs, 2b) rather than written.
    flags: { eaBlock: 11, eaSource: "Feat Additions", assistantFrame: true, classSkills: ["Crafting", "Perception"] },
    effects: [(ownerId) => ({
      _id: stableId(`${id}:frame`), name: `${ASSISTANT_FRAME}: profile`, img: EA_FEAT_ART.class,
      transfer: true, disabled: false, type: "base", system: {}, origin: null, duration: {}, statuses: [], tint: "#ffffff",
      description: `Small; Str 0, Dex 1, Con 1, Int 0, Wis 2, Cha -2; speed ${p.speed}; Base DR ${p.dr}.`,
      // PRIORITY 30, OVER THE FAMILIAR STAT BLOCK'S 10: its abilities, size,
      // speed and Base DR are overridden by the printed profile.
      changes: [
        ...Object.entries(assistantBaseAbilities()).map(([k, v]) => ({ key: `system.attributes.${k}.base`, mode: 5, value: String(v), priority: 30 })),
        { key: "system.identity.size", mode: 5, value: p.size, priority: 30 },
        { key: "system.combat.movement.land.base", mode: 5, value: String(p.speed), priority: 30 },
        { key: "system.combat.naturalArmourBase.natural", mode: 5, value: String(p.dr), priority: 30 }
      ],
      flags: { "trg-prime": { featPassive: true } },
      _stats: { coreVersion: "14", systemId: "trg-prime", systemVersion: "3.674.2", createdTime: 1789000000000, modifiedTime: 1789000000000, lastModifiedBy: null, compendiumSource: null, duplicateSource: null }
    })]
  });
})();

/** The three improvements only an assistant may take (the feat's own list). */
export const ASSISTANT_IMPROVEMENTS = (() => {
  const e = additionEntry("MECHANISED ASSISTANT");
  const say = (n) => md(`*Mechanised Assistant improvement:* ${n}`);
  const frameId = stableId(`abilities:${ASSISTANT_ABILITIES.frame}`);
  void e;
  return Object.freeze([
    classAbilityItem({
      name: ASSISTANT_ABILITIES.frame, traits: "Construct",
      description: `${say("Reinforced Frame (DR +1).")}\n${md("*Automated (0.18.0): Base DR +1, an effect on the assistant.*")}`,
      flags: { eaBlock: 11, eaSource: "Feat Additions", assistantImprovement: true },
      effects: [() => ({
        _id: stableId(`${frameId}:dr`), name: `${ASSISTANT_ABILITIES.frame}: DR +1`, img: EA_FEAT_ART.class,
        transfer: true, disabled: false, type: "base", system: {}, origin: null, duration: {}, statuses: [], tint: "#ffffff",
        description: "Reinforced Frame: DR +1.",
        changes: [{ key: "system.combat.dr.untyped", mode: 0, value: "1", priority: 20 }],
        flags: { "trg-prime": { featPassive: true } },
        _stats: { coreVersion: "14", systemId: "trg-prime", systemVersion: "3.674.2", createdTime: 1789000000000, modifiedTime: 1789000000000, lastModifiedBy: null, compendiumSource: null, duplicateSource: null }
      })]
    }),
    classAbilityItem({
      name: ASSISTANT_ABILITIES.storage, traits: "Construct",
      description: `${say(`Storage (can carry up to ${STORAGE_LBS} lbs of items and retrieve them as part of your command).`)}\n${md(`*Automated (0.18.0): items moved onto the assistant are refused past ${STORAGE_LBS} lbs; the master's Use retrieves one as part of a command.*`)}`,
      flags: { eaBlock: 11, eaSource: "Feat Additions", assistantImprovement: true, storageLbs: STORAGE_LBS }
    }),
    classAbilityItem({
      name: ASSISTANT_ABILITIES.reactive, traits: "Construct",
      description: `${say("Reactive Protocol (can use a Reaction once per round to Aid your checks).")}\n${md("*Automated (0.18.0): before your check, while the assistant is adjacent and its reaction is unspent this round, you are asked whether it Aids (the core's Aid, its reaction spent).*")}`,
      flags: { eaBlock: 11, eaSource: "Feat Additions", assistantImprovement: true }
    })
  ]);
})();

export const ABILITIES_B11 = Object.freeze([QUICK_SWAP_ABILITY, ASSISTANT_FRAME_ABILITY, ...ASSISTANT_IMPROVEMENTS]);

export const BLOCK11_PACKS = Object.freeze([
  { name: "ea-feats", label: "Eldritch Arts: Feats", extends: "feats", docs: FEATS_B11 },
  { name: "ea-abilities", label: "Eldritch Arts: Abilities", extends: "abilities", docs: ABILITIES_B11 }
]);
