/**
 * Eldritch Arts — Block 5, group B (0.8.0, on TRG Prime 3.683.0): the
 * fourteen EMBERKIN and fourteen NYRINN racial feats of Chapter 5.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix B, as Graham answered
 * it on 3 November 2026 (Q67–Q75 as proposed), on the core's seams C1–C19.
 * Every feat is made with block5-common's `racialFeat`, so its card is the
 * book's traits, fields and text, then one paragraph saying what TRG Prime
 * does with it. What is data (effects, conditionals, declarations the core
 * reads) is here; what is a choice or an activation is in
 * module/block5b-automations.mjs.
 *
 * BLOCK 1'S FLAGS ARE REUSED, NOT COPIED: the Emberkin heritage's element is
 * its `eaElement` (Stonevein acid, Galeborne electricity, Cinderblood fire,
 * Tidemarked cold); the Null Aura's reach is Block 1's `nullAuraFeet`, which
 * Silent Veil's `eaNullAuraBonus` adds to; the Vir-ellian release and Magic
 * Drain are Block 1's abilities.
 *
 * FLAGS under the system's scope: the core's names for what the core reads
 * (`conditionals`, `defenceDC`, `deathGuard`, `spellDamageBonus`,
 * `spellAdder`, `grantInnate`); the module's own are prefixed `ea`.
 */
import { racialFeat } from "./block5-common.mjs";
import { changesEffect, declaredEffect, racialSkillEffect, noteEffect, conditional } from "./builders.mjs";

/* ------------------------------------------------------------------ */
/* Shared                                                               */
/* ------------------------------------------------------------------ */

const AUTO = "*Automated (0.8.0, TRG Prime 3.683.0):*";
const PART = "*Partly automated (0.8.0, TRG Prime 3.683.0):*";
const innate = () => ({ grantInnate: true });
const skills = (list, value = 1) => (id, n) => racialSkillEffect(id, n, list, value);

/** Voidbound Resolve's "a number of times per day equal to your class bonus" (2/3/4/5/6 at 1/5/10/15/20). */
export const CLASS_BONUS_USES = "2, 3 at 5th, 4 at 10th, 5 at 15th, 6 at 20th";

/** Stonebound Bastion: the two actions resolved against your Fortitude DC that move you (data/basic-actions.mjs). */
export const FORCED_MOVEMENT_ACTIONS = Object.freeze(["shoveAttack", "tripAttack"]);

/* ------------------------------------------------------------------ */
/* Emberkin                                                             */
/* ------------------------------------------------------------------ */

const EMBERKIN = [
  racialFeat("ECHO OF THE ANCESTORS", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* an option in the spell's own **Warp?** dialog (Block 6's module metamagic, G1), offered when the spell's damage type — its own, or Elemental Spell's — is your heritage's element (Stonevein acid, Galeborne electricity, Cinderblood fire, Tidemarked cold): **+2 PP**, one Focus use. On Elemental Spell's type, tick Elemental Spell with it: taken without it, the cast goes on, the card says there is no echo, and its PP and Focus use are still paid. As ruled (Q75): one casting and one check; choose one more creature within the spell's range, not already affected — it makes its own save (or is compared with the same attack roll), takes half the damage, rounded down, and the spell's other effects. The core's limits: on an attack spell that creature's damage is rolled again and only the damage lands; on a save spell its ladder and conditions are not halved. Learned and innate casts (an innate cast's 2 PP come from your PP pool, Q95); never an item's spell or a cantrip (Q94). The Focus use is spent when the cast pays its PP (Q96)."
  }),
  racialFeat("ELEMENTAL APOTHEOSIS", {
    automation: `${AUTO} **Use** (1 AP in combat; its Focus use, restored by Refocus or daily preparation) makes you immune to your heritage's element (Stonevein acid, Galeborne electricity, Cinderblood fire, Tidemarked cold) for 1 minute. While it lasts, every pool of that type your spells roll takes +1 a die rolled — cantrips, innate and item casts included, on every pool of the type after warps — and so does Elemental Reprisal's burst (Q70). Weapons, rune riders and recurring damage take nothing. It stacks with Emberborn Fury (a Cinderblood with both adds +2 a fire die).`,
    flags: { eaAutomation: "elementalApotheosis" }
  }),
  racialFeat("ELEMENTAL BULWARK", {
    automation: `${AUTO} when you take damage of your heritage's element (any amount after your resistances), you are asked — your own screen, else the GM's — whether to use it. Yes spends its Focus use and gives you +1 racial to DB and to every saving throw until the start of your next turn. It costs no AP and no reaction. Refocus or daily preparation restores the use.`,
    flags: { eaAutomation: "elementalBulwark" }
  }),
  racialFeat("ELEMENTAL REPRISAL", {
    automation: `${AUTO} when you take damage of your heritage's element you are asked whether to use it (after Elemental Bulwark, each with its own Focus use). Yes asks which adjacent creature, and deals 1d4 a two levels of your element to it, a basic Reflex save against its own Level DC (no DC is printed). Emberborn Fury's and Elemental Apotheosis's +1 a die are added (Q70). No AP and no reaction; Refocus or daily preparation restores the use.`,
    flags: { eaAutomation: "elementalReprisal" }
  }),
  racialFeat("ELEMENTAL STEP", {
    automation: `${AUTO} **Use** (1 AP in combat; its Focus use) asks you to click where you teleport, up to your land speed. The core refuses an occupied end square, and a refused teleport spends nothing. The Teleportation trait's once a turn is the core's. A teleport provokes no attacks of opportunity; that the space is one you can see is yours to keep.`,
    flags: { eaAutomation: "elementalStep" }
  }),
  racialFeat("EMBERBORN FURY", {
    automation: `${AUTO} every pool of fire damage your spells roll takes +1 a die rolled, named on the cast card — cantrips, innate and item casts included, every pool of fire after warps (TRG Prime's per-die spell damage bonus). Elemental Reprisal's fire burst takes it too (Q70). Weapons, rune riders and recurring damage take nothing. It stacks with Elemental Apotheosis.`,
    effects: [declaredEffect("+1 per fire die", "Whenever you deal fire damage with a spell or effect, you add +1 damage per die rolled.",
      { spellDamageBonus: { label: "Emberborn Fury", perDie: 1, damageTypes: ["fire"], type: "untyped" } })]
  }),
  racialFeat("EMBER EYED", {
    automation: `${AUTO} the core's **Darkvision** ability is granted with the feat; your sight uses the better of it and your race's Nightvision. "Level 1 only" is gated by the Racial Feat picker (Q57).`,
    grantedAbilities: "Darkvision"
  }),
  racialFeat("EMBERKIN SCHOLAR", {
    automation: `${AUTO} +1 racial to Arcana and Nature. The +2 racial goes on your racial specialist skill, **Elemental Lore**, found on your sheet when the feat is added; if the sheet has no Elemental Lore yet, **Use** asks which specialist skill once it has. The "+2 bonus" prints no type, and is racial as the core's Scholar feats' is.`,
    effects: [skills(["Arcana", "Nature"])],
    flags: { eaAutomation: "emberkinScholar" }
  }),
  racialFeat("ETERNAL SCHOLAR", {
    automation: `${AUTO} +1 racial to Arcana, Occultism and Linguistics. Offered to the Ascendan and the Emberkin alike; racial bonuses from different feats stack (an Emberkin with Emberkin Scholar has +2 Arcana).`,
    effects: [skills(["Arcana", "Occultism", "Linguistics"])]
  }),
  racialFeat("MANTLE OF ESSENCE", {
    automation: `${AUTO} when a spell you cast lands (Success or better; cantrips, innate and item casts included), you are asked whether to use it. Yes spends your reaction in combat and its Focus use, and gives you +1 circumstance to DB until the start of your next turn, +1 more at 5th level and every 5 levels after (+2 at 5th, +5 at 20th). Refocus or daily preparation restores the use.`,
    flags: { eaAutomation: "mantleOfEssence" }
  }),
  racialFeat("STONEBOUND BASTION", {
    automation: `${AUTO} Critical Resistance 1. Shove and Trip are rolled against your Fortitude DC, not by you, so the +2 is on that DC against them (as the core's Storgar). A Trip is against the higher of your Acrobatics DC and your Fortitude DC, so the +2 counts only when the Fortitude DC is the one it meets. *Offered:* a tick on your Fortitude saves, +2 racial: tick it when the save resists being moved against your will.`,
    effects: [(id, n) => changesEffect(id, `${n}: Critical Resistance 1`, [{ key: "system.combat.criticalResistance", mode: 2, value: "1", priority: 20 }], "Critical Resistance 1.")],
    flags: {
      defenceDC: [{ dc: "fortitudeDC", value: 2, label: "Stonebound Bastion", scope: "Shove and Trip against your Fortitude DC", when: { actions: [...FORCED_MOVEMENT_ACTIONS] } }],
      conditionals: [conditional({ kind: "modifier", value: 2, type: "racial", label: "Stonebound Bastion", scope: "A Fortitude save against being shoved, tripped or otherwise moved against your will — tick if this save is one", auto: false, when: { checkTypes: ["save"], subjects: ["fortitude"] } })]
    }
  }),
  racialFeat("STORMRUNNER’S ZEAL", {
    automation: `${AUTO} whenever you take electricity damage (any amount after your resistances; an immunity takes none), you gain a fly speed equal to your land speed until the end of your next turn. Taking electricity damage again lengthens it. If it ends while you are in the air and you have no other fly speed, your token is lowered and the core's Falling from Height is rolled for the height you fell.`,
    flags: { eaAutomation: "stormrunnersZeal" }
  }),
  racialFeat("TIDEWEAVER’S RESILIENCE", {
    automation: `${AUTO} +1 racial to your attack checks, saving throws and skill checks while your token stands in a Region the core counts as water. Once a day, when damage would take you to 0 HP (Q71: TRG Prime clamps at 0), you are asked whether to use it: you stay conscious at HP equal to your level + your Wisdom (at least 1), and gain no Dying. It does not answer a blow that kills outright (massive damage). Daily preparation restores it.`,
    effects: [(id, n) => changesEffect(id, `${n}: once a day at 0 HP`, [], "Once per day when damage would reduce you to 0 HP: heal to your level + Wisdom, without the dying condition.",
      { deathGuard: { label: "Tideweaver’s Resilience", offer: true, askOwner: true, frequency: "daily", notOutright: true, healTo: { level: true, ability: "wisdom" } } })],
    flags: { eaAutomation: "tideweaversResilience" }
  }),
  racialFeat("VEIN OF POWER", {
    automation: `${AUTO} a +1 Spell Adder (one spell a day cast at no PP, the core's rule), +1 at 5th level and every 5 levels after: the rating on this feat follows your level, written when the feat is added, when your level changes and at daily preparation. It stacks with your other Spell Adders (R7).`,
    flags: { spellAdder: 1, eaAutomation: "veinOfPower" }
  })
];

/* ------------------------------------------------------------------ */
/* Nyrinn                                                               */
/* ------------------------------------------------------------------ */

const NYRINN = [
  racialFeat("ANCHOR IN NOTHING", {
    usesPerDay: "1",
    automation: `${AUTO} before the dice of any Will save, you are asked — your own screen, else the GM's — whether to use it. Yes spends the day's use, and the save is a Success: the card says the dice do not count, and nothing rerolls or changes it. No AP and no reaction. Daily preparation restores it.`,
    flags: { eaAutomation: "anchorInNothing" }
  }),
  racialFeat("CRYSTAL PULSE", {
    automation: `${AUTO} your **Vir-ellian Release** asks force or electricity each time you release, and deals 1d4 more (Q69: part of the same 1 AP Focus release, with no extra AP or use).`,
    flags: { eaAutomation: "crystalPulse" }
  }),
  racialFeat("ECLIPSED FORM", {
    automation: `${PART} **Use** (2 AP in combat; its Focus use) blurs you into the Void until the start of your next turn. While it lasts, a non-magical bludgeoning, piercing or slashing weapon blow deals you half damage. Q68: the printed effects only — not the core's Incorporeal trait, whose immunity is stronger. *Read as non-magical:* the attacker's wielded weapons of that damage type carry no Potency rune and are not magical strikes; magical ammunition or a declared magical attack is the GM's to see (the core does not tell the reaction). *Not automated:* moving through solid objects (walls are Foundry's), and not ending your turn inside one, are the GM's.`,
    flags: { eaAutomation: "eclipsedForm" }
  }),
  racialFeat("MINDSHROUD", {
    usesPerDay: "1",
    automation: `${AUTO} advantage on a save against an effect with the Emotion trait (the core Fear spell carries Fear, not Emotion). Once a day, when you fail a Will save, you are asked whether to reroll it; the second result stands and nothing changes it further (the core's reaction reroll). Daily preparation restores it.`,
    flags: {
      conditionals: [conditional({ kind: "advantage", label: "Mindshroud", scope: "Saving throws against effects with the emotion trait", auto: true, when: { checkTypes: ["save"], traits: ["emotion"] } })],
      eaAutomation: "mindshroud"
    }
  }),
  racialFeat("NIGHT’S EMBRACE", {
    grantedSpells: "Invisibility",
    automation: `${PART} the core's **Invisibility** is granted as an innate spell with the Focus trait (PP 4, within your level). *Not automated:* that you leave no tracks or scent while invisible by it is the GM's (tracking is the GM's).`,
    effects: [(id, n) => noteEffect(id, `${n}: no tracks`, "While invisible using this spell, you leave no tracks or scent.")],
    flags: innate()
  }),
  racialFeat("NYRINN SCHOLAR", {
    automation: `${AUTO} +1 racial to Occultism and Planes. The Nyrinn has two racial specialist skills, so **Use** asks which one takes the +2 racial: Spell Lore or Nyrinn Lore (Q74); using it again moves it. The "+2 bonus" prints no type, and is racial as the core's Scholar feats' is.`,
    effects: [skills(["Occultism", "Planes"])],
    flags: { eaAutomation: "nyrinnScholar" }
  }),
  racialFeat("SHADOW INITIATE", {
    automation: `${AUTO} +2 racial to Stealth. While the ambient light where your token stands is 5 (Dim Light) or less — light sources, Darkness, regions and weather, not raised by your own Darkvision (Q61) — your land speed is 5 ft higher; it is rechecked as you move, as the light changes and as turns end. Offered to the Kornargon and the Nyrinn alike. The printed Flourish trait limits actions, and this feat is not one.`,
    effects: [skills(["Stealth"], 2)],
    flags: { eaAutomation: "shadowInitiate" }
  }),
  racialFeat("SILENT VEIL", {
    automation: `${PART} your Null Aura reaches 5 ft further (15 ft for a Vel-tharis): its casting-DC rise, the Zhal-vryn surcharge and every rule that reads its reach. *Not automated:* hiding while directly observed in light 5 or less — the core's Hide does not refuse an observed hider, so there is nothing to lift; whether you are observed is the GM's.`,
    effects: [(id, n) => noteEffect(id, `${n}: hide while observed`, "You may make a Stealth check to hide even when being directly observed, as long as the light level is 5 (Dim Light) or less.")],
    flags: { eaNullAuraBonus: 5 }
  }),
  racialFeat("THREADBREAKER’S PRECISION", {
    automation: `${AUTO} "Cancel Magic" is read as the Dispel action (Q67): every Dispel check you make has +2 racial, shown on the Dispel prompt — Counter Spell's free Dispel and Disrupting Magic's included, Magic Drain's not (B1-22). When a Dispel of yours counters a spell (Success or better), its caster is Dazed 1 until the end of its next turn. Where the Dispel does not name the caster, the card asks the GM to apply it.`,
    flags: { eaAutomation: "threadbreakersPrecision" }
  }),
  racialFeat("VEILSTRIDE", {
    automation: `${AUTO} on your own turn, a melee attack you make after moving at least 10 ft of your own movement (a teleport is not moving), while the ambient light where you stand is 5 or less (Q61), has advantage, named on the roll. Only the first melee attack after that move (Q72): another needs another 10 ft.`,
    flags: { eaAutomation: "veilstride" }
  }),
  racialFeat("VOIDBORN GRACE", {
    automation: `${PART} your Voidborn Wings' fly speed carries the Hover trait while it lasts. When the wings' flight ends in the air, you drift down 60 ft at the end of each of your turns, taking no damage (out of combat you settle at once). If you are grappled or knocked prone mid-glide, you fall the height left, rolled as the core's Falling from Height. *Not automated:* any other interruption is the GM's call.`,
    flags: { eaAutomation: "voidbornGrace" }
  }),
  racialFeat("VOIDBOUND RESOLVE", {
    usesPerDay: CLASS_BONUS_USES,
    automation: `${AUTO} before the dice of a Will save against a spell that targets you (not an area, Q73), you are asked whether to use it. Yes spends your reaction in combat and one of the day's uses (your class bonus a day), and the save has +2 racial. If the +2 made the difference — a Success that would have failed without it — the caster takes 1d4 mental a two of your levels, a basic Will save against its own Level DC. A save forced by something other than a spell is yours to decline.`,
    flags: { eaAutomation: "voidboundResolve" }
  }),
  racialFeat("VOIDBORN WINGS", {
    automation: `${AUTO} **Use** (its Focus use) gives you a fly speed equal to your land speed for your level + your Dexterity rounds, counted at the end of each of your turns (6 seconds each out of combat). Landing ends it, and so does **Use** again. If its rounds run out while you are in the air, your token is lowered and the core's Falling from Height is rolled (Voidborn Grace glides instead). Refocus or daily preparation restores the use.`,
    flags: { eaAutomation: "voidbornWings" }
  }),
  racialFeat("WHISPERS OF THE VOID", {
    grantedSpells: "Fear",
    automation: `${AUTO} +1 racial to Deception and Intimidate. The core's **Fear** is granted as an innate spell with the Focus trait (PP 2).`,
    effects: [skills(["Deception", "Intimidate"])],
    flags: innate()
  })
];

export const FEATS_B5_B = [...EMBERKIN, ...NYRINN];
export const ABILITIES_B5_B = [];

/** For the docs: each feat's level (A full · B with a normal choice · C partial · D descriptive) and what is automated. */
export const AUTOMATION_B5_B = Object.freeze({
  "Echo of the Ancestors": { level: "B", what: "Block 6's module metamagic (G1, registered by block6d): +2 PP, Focus, on the heritage's element; a second creature at half damage (targets.extra, Q75)." },
  "Elemental Apotheosis": { level: "A", what: "Use: 1 AP, Focus; immunity to the heritage's element for 1 minute and +1 per die of that type on spell pools (C6) and Reprisal." },
  "Elemental Bulwark": { level: "B", what: "Offered on damage of the heritage's element (askReactor); Focus; +1 racial DB and saves to the start of the next turn." },
  "Elemental Reprisal": { level: "B", what: "Offered on damage of the heritage's element; pick an adjacent creature; 1d4 per 2 levels, basic Reflex vs its Level DC, per-die bonuses added; Focus." },
  "Elemental Step": { level: "B", what: "Use: 1 AP, Focus; click a point within land speed; Teleportation's once a turn." },
  "Emberborn Fury": { level: "A", what: "Per-die fire spell damage bonus (C6); Reprisal adds it." },
  "Ember Eyed": { level: "A", what: "Grants the core's Darkvision; Level 1 only gated by C1." },
  "Emberkin Scholar": { level: "A", what: "+1 racial Arcana, Nature; +2 racial on Elemental Lore, found when the feat is added (Use if missing)." },
  "Eternal Scholar": { level: "A", what: "+1 racial Arcana, Occultism, Linguistics; Ascendan and Emberkin." },
  "Mantle of Essence": { level: "B", what: "Offered after a cast lands; reaction and Focus; +1 + 1 per 5 levels circumstance DB to the start of the next turn." },
  "Stonebound Bastion": { level: "B", what: "CR 1; +2 on the Fortitude DC against Shove and Trip; a ticked +2 racial on Fortitude saves against forced movement." },
  "Stormrunner’s Zeal": { level: "A", what: "On electricity damage taken: fly = land speed until the end of the next turn (extended on a new hit); a fall rolled if it ends airborne (C5)." },
  "Tideweaver’s Resilience": { level: "B", what: "+1 racial to attack, save and skill checks while underwater (C2, C5); once-a-day 0 HP death guard offered, healing to level + Wisdom (C7)." },
  "Vein of Power": { level: "A", what: "Spell Adder 1 + ⌊level/5⌋, kept in step with the level." },
  "Anchor in Nothing": { level: "B", what: "Offered before every Will save, 1/day: the save is declared a Success (C2)." },
  "Crystal Pulse": { level: "B", what: "Vir-ellian Release asks force or electricity and adds 1d4 (Q69)." },
  "Eclipsed Form": { level: "C", what: "Use: 2 AP, Focus; to the start of the next turn, resistance to non-magical B/P/S weapon blows (Q68). Passing through objects is the GM's." },
  "Mindshroud": { level: "B", what: "Advantage on saves vs the Emotion trait (auto); 1/day reroll of a failed Will save, offered." },
  "Night’s Embrace": { level: "C", what: "Invisibility as an innate Focus spell; no tracks or scent is the GM's." },
  "Nyrinn Scholar": { level: "B", what: "+1 racial Occultism, Planes; Use picks Spell Lore or Nyrinn Lore for the +2 (Q74)." },
  "Shadow Initiate": { level: "A", what: "+2 racial Stealth; +5 ft land speed while the ambient light at the token is 5 or less (C4), kept up to date." },
  "Silent Veil": { level: "C", what: "Null Aura +5 ft (eaNullAuraBonus, read by Block 1's nullAuraFeet); hiding while observed is the GM's." },
  "Threadbreaker’s Precision": { level: "B", what: "Dispel modifier (C9): +2 racial on every Dispel; a countered caster Dazed 1 to the end of its next turn (Q67)." },
  "Veilstride": { level: "A", what: "Check reaction: advantage on the first melee attack after 10 ft of own movement this turn in ambient light 5 or less (C2, C4, C17)." },
  "Voidborn Grace": { level: "C", what: "Hover while the wings fly; a 60 ft a turn glide when they end airborne; prone or grappled mid-glide falls. Other interruptions are the GM's." },
  "Voidbound Resolve": { level: "B", what: "Offered before a targeted spell's Will save: reaction and a use (class bonus a day), +2 racial; backlash 1d4 per 2 levels, basic Will vs the caster's Level DC, when the +2 made the difference (Q73)." },
  "Voidborn Wings": { level: "A", what: "Use: Focus; fly = land speed for level + Dex rounds; ends on landing; a fall rolled if the rounds run out airborne (C5)." },
  "Whispers of the Void": { level: "A", what: "+1 racial Deception, Intimidate; Fear as an innate Focus spell." }
});
