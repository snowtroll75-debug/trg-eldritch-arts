/**
 * Eldritch Arts — Block 4 (0.7.0): Chapter 3's last two classes, the
 * Spellblade with its four paths and the Warlock with its eight bonded souls,
 * on TRG Prime 3.682.0. Their spells are in block4-spells.mjs.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.classes`, cut from v1.6 by extract-book.mjs), never retyped. Each
 * item's description is that text followed by what TRG Prime does with it.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK4_AUDIT.md, answered by Graham on
 * 3 November 2026 (17:14): Q36 (the paths' Focus abilities, one use each),
 * Q37 (every Warlock spell innate and Focus, the cantrips too), Q43 (Natural
 * Resilience halves damage from poison and from a disease), Q45 (infused runes
 * outside the weapon's allowance), Q46 (a rune learned as a spell), Q48
 * (Thunderous Strike). Q38–Q42, Q44, Q47 and Q49–Q52 as proposed.
 *
 * FLAGS under the system's scope are TRG Prime's declarations (`classMagic`,
 * `abilityChoices`, `classSkills`, `spellAttackBase`, `highMagicCaster`,
 * `grantInnate`); the module's own keys there are prefixed `ea`.
 */
import fs from "node:fs";
import { classItem, classAbility, changesEffect } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { CLASS_WEALTH } from "./block3.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const CLASSES = BOOK.classes;

const printed = (lines) => md((lines ?? []).join("\n\n"));
const note = (text) => md(text);
/** "PATH OF THE ARCANE DUELLIST" → "Path of the Arcane Duellist". */
const title = (caps) => caps.toLowerCase().replace(/(^|[\s(-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()).replace(/\b(Of|The)\b/g, (w, _x, at) => (at === 0 ? w : w.toLowerCase()));
const traitWords = (traits) => traits.map((t) => t[0] + t.slice(1).toLowerCase()).join(", ");

/** A class's section by heading (the nth of that name). */
export function section(cls, name, nth = 0) {
  const found = CLASSES[cls].sections.filter((s) => s.name === name)[nth];
  if (!found) throw new Error(`Block 4: no "${name}" (#${nth + 1}) in the ${cls}`);
  return found;
}
const one = (cls, name, nth = 0) => section(cls, name, nth).lines.join(" ");
const block = (s) => `${md(`**${s.name}**${s.traits.length ? ` ${s.traits.join(" ")}` : ""}`)}\n${printed(s.lines)}`;

/** "4 + Con per level" → 4. */
const leading = (text) => {
  const n = Number(/^(\d+)/.exec(String(text).trim())?.[1]);
  if (!Number.isFinite(n)) throw new Error(`Block 4: no number in "${text}"`);
  return n;
};

/**
 * The class table, as builders.classItem takes it: [bab, bdb, fort, ref, will,
 * bonusFeats, CL, PP, BSB]. The Warlock's prints no caster level, PP or BSB
 * ("you do not possess a pool of PP"): those columns are 0.
 */
export function classTable(cls) {
  const tbl = CLASSES[cls].sections.flatMap((s) => s.tables).find((t) => /TABLE$/.test(t.rows[0]?.cells?.[0] ?? ""));
  const heads = tbl.rows[1].cells.map((c) => c.toLowerCase());
  const col = (row, ...names) => {
    const i = heads.findIndex((h) => names.includes(h));
    return i < 0 ? null : Number(row.cells[i]);
  };
  const need = (row, ...names) => {
    const v = col(row, ...names);
    if (v === null) throw new Error(`Block 4: the ${cls} table has no ${names.join("/")} column`);
    return v;
  };
  return tbl.rows.slice(2).map((row) => [
    need(row, "bab", "bab/bdb"), need(row, "bdb", "bab/bdb"), need(row, "fort"), need(row, "ref"), need(row, "will"),
    need(row, "bonus feats"), col(row, "caster level") ?? 0, col(row, "pp") ?? 0, col(row, "bsb") ?? 0
  ]);
}

/* ------------------------------------------------------------------ */
/* The two classes                                                      */
/* ------------------------------------------------------------------ */

const PROFICIENCY = {
  Spellblade: { weaponCategories: ["Simple", "Martial"], weaponNames: [], armourCategories: ["Light"] },
  Warlock: { weaponCategories: ["Simple"], weaponNames: [], armourCategories: ["Light"] }
};

/** registerClass specs: proficiency as printed, and Chapter 6's class wealth (Spellblade 2, Warlock 1). */
export const CLASS_REGISTRATIONS_B4 = Object.fromEntries(["Spellblade", "Warlock"].map((name) => [name, {
  wealth: CLASS_WEALTH[name],
  proficiency: {
    label: name,
    armourCategories: PROFICIENCY[name].armourCategories, armourNames: [], otherTiers: [], armourExclude: [],
    shieldCategories: [], shieldNames: [],
    weaponCategories: PROFICIENCY[name].weaponCategories, weaponNames: PROFICIENCY[name].weaponNames,
    weaponRules: [],
    deityWeapons: false
  }
}]));

const SPELLBLADE_NOTE = [
  "*Automated (TRG Prime 3.682.0):*",
  "**a semi-learned caster of one tradition, your path's.** Press Use on **Spellblade Path** to choose it: it sets your tradition and magical ability, two class skills, your special ability and your path spell.",
  "Your Book of Infusions is the core's spell book: four PP 2 spells of your tradition at 1st, then one a level that you can cast (PP no higher than your CL + 1); memorise **level + 1** each day (TRG Prime 3.682.0's `memorisedPerDay`). The path spell is a specialist spell, always ready. No cantrips.",
  "**Transcend Armour** and a class feat at 1st, then a class feat at 5th and every 5 (Spellblade or Martial). Chapter 6's class wealth is 2.",
  "*The book's runes* are learned with Infuse Weapon's Use (\"Learn a rune\")."
].join(" ");

const WARLOCK_NOTE = [
  "*Automated (TRG Prime 3.682.0; the pool 0.9.0, TRG Prime 3.684.0):*",
  "**a pool of Charisma PP that your spells never spend (C2; Q52, Q97), and no Spellcraft: every spell you have is innate, with the Focus trait** (one use each, restored by Refocus or daily preparation; Q37). The pool is read once your sheet names a tradition: choosing your bonded soul asks which of its two is yours, if the sheet names none (Q97). It is spent only by Warlock’s Hex, Pact Channeler and what any character may pay PP for (Dispel); a Nyrinn's racial −1 PP a level applies as printed, never below 0 (Q98). Charisma is your magical ability: your innate attack is Charisma + level, your DC 10 + Charisma + level. Every spell you cast is High Magic (nothing about a casting check applies, as none is rolled; Q40).",
  "**Xithra** is granted at 1st. Press Use on **Bonded Soul** to choose yours: it sets two class skills, Xithra's other damage type and its once-a-day power, and the traditions your spells come from. Then press Use on your soul to choose the spells you are owed — one at 1st and one more at 3rd and every 3 levels (PP no higher than your level + 1, sidebar 8), and your two cantrips of any tradition, Focus too (Q37). **Hexes:** one at 1st, innate and Focus.",
  "A class feat at 3rd and every 3 (Warlock, Adept or Expert). Chapter 6's class wealth is 1.",
  "*Not given:* the Magical Discovery feat (the class's own line bars it). The Shadowed Grimoire's spells are its own Use (0.9.0)."
].join(" ");

export const SPELLBLADE = classItem({
  name: "Spellblade", classType: one("spellblade", "CLASS TYPE"),
  description: `${printed(section("spellblade", "DESCRIPTION").lines)}\n${["BONUS FEATS", "MAGICAL TRADITION", "MAGICAL ABILITY SCORE", "SPECIALIST SPELLS"].map((n) => block(section("spellblade", n))).join("\n")}\n${md(`**${BOOK.sidebars.find((s) => s.title === "BOOK OF INFUSIONS").title}**`)}\n${printed(BOOK.sidebars.find((s) => s.title === "BOOK OF INFUSIONS").lines.slice(1))}\n${note(SPELLBLADE_NOTE)}`,
  keyAbilityScores: one("spellblade", "KEY ABILITY SCORES"),
  // The printed line, without its parenthesis (the path's skills are the path's).
  classSkills: section("spellblade", "CLASS SKILLS").lines[0],
  proficiencies: one("spellblade", "PROFICIENCIES"), hitPoints: leading(one("spellblade", "HIT POINTS")), skillPoints: leading(one("spellblade", "SKILL POINTS")),
  grantedFeats: "1: Transcend Armour", classAbilities: "1: Infuse Weapon, 1: Battle Mage, 1: Spellblade Path",
  // The path supplies both (as a birthright does); until then the class does not cast.
  magicalTradition: "", magicalAbility: "", casterStyle: "learned", memorisationStyle: "book",
  spellBookFirstPicks: 4, wealth: String(CLASS_WEALTH.Spellblade),
  // The core's one Spellbook, free with the class (Graham, 24 Nov 2026, 0.17.3).
  grantedGear: "Spellbook",
  table: classTable("spellblade"),
  flags: { classMagic: { bookPerLevel: 1, memorisedPerDay: "L+1" } }
});

export const WARLOCK = classItem({
  name: "Warlock", classType: one("warlock", "CLASS TYPE"),
  description: `${printed(section("warlock", "DESCRIPTION").lines)}\n${["BONUS FEATS", "MAGICAL TRADITION", "MAGICAL ABILITY SCORE", "HEXES", "CANTRIPS"].map((n) => block(section("warlock", n))).join("\n")}\n${["SELECTING SPELLS", "NYRRIN WARLOCKS"].map((t) => { const s = BOOK.sidebars.find((x) => x.title === t); return `${md(`**${s.title}**`)}\n${printed(s.lines.slice(1))}`; }).join("\n")}\n${note(WARLOCK_NOTE)}`,
  keyAbilityScores: one("warlock", "KEY ABILITY SCORES"), classSkills: one("warlock", "CLASS SKILLS"),
  proficiencies: one("warlock", "PROFICIENCIES"), hitPoints: leading(one("warlock", "HIT POINTS")), skillPoints: leading(one("warlock", "SKILL POINTS")),
  classAbilities: "1: Bonded Soul, 1: Hexes",
  grantedSpells: "1: Xithra",
  magicalTradition: "", magicalAbility: "charisma", casterStyle: "",
  wealth: String(CLASS_WEALTH.Warlock),
  table: classTable("warlock"),
  // Xithra arrives innate (grants-workflow's `grantInnate`), and every cast is High Magic.
  flags: { highMagicCaster: true, grantInnate: true }
});

export const CLASS_ITEMS_B4 = [SPELLBLADE, WARLOCK];

/* ------------------------------------------------------------------ */
/* The Spellblade's abilities and paths                                 */
/* ------------------------------------------------------------------ */

const sb = (heading, nth = 0) => section("spellblade", heading, nth);

export const INFUSE_WEAPON = classAbility({
  name: "Infuse Weapon", sourceClass: "Spellblade", level: 1,
  description: `${md("**MAGIC**")}\n${printed(sb("MAGIC").lines)}\n${note("*Automated (0.7.0, TRG Prime 3.682.0):* at each daily preparation you are asked which melee weapon you infuse (or press Use: \"Infuse a weapon\"). That weapon's strikes are magical for overcoming resistances and DR while you wield it, for the day (Q44). From 2nd level you also choose runes from your Book of Infusions, their total level no more than your Spellblade level (M14); they work only on your own Strikes with it, outside the weapon's rune allowance and potency rule, and where a rune is both etched and infused the higher tier applies (Q45). **Learn a rune** (Use): pick a weapon rune and tier; it is learned as a spell is (Q46) — Learn a Spell's hours, materials price and DC for the rune's level as its PP, and a check with your tradition's skill. A Success or better writes it into your Book of Infusions, and the materials consumed are Learn a Spell's for that degree. *Not offered:* runes that take a parameter (Aligned, Bane, Energy Resistance) and Spell Effect — add those by hand.")}`,
  traits: "Magic"
});

export const BATTLE_MAGE = classAbility({
  name: "Battle Mage", sourceClass: "Spellblade", level: 1,
  description: `${printed(sb("BATTLE MAGE").lines)}\n${note("*Automated (TRG Prime 3.682.0; maneuver spells 3.682.2):* a spell attack with the Attack trait adds your BAB less your BSB as one named row when your BAB is the higher; the casting check and its degree are untouched. So does the Spellcraft check of a spell that performs a maneuver (Tanglefoot, Spectral Grasp, Telekinetic Manoeuvre, Tangling Creepers' vine), which is its attack (Q53). Not Spiritual Weapon's strikes, which have no Attack trait (Q54).")}`,
  flags: { spellAttackBase: "bab" }
});

export const PATHS = Object.freeze([
  { heading: "PATH OF THE ARCANE DUELLIST", ability: "intelligence", tradition: "arcane", special: "ARCANE ECHO", spell: "Shooting Star" },
  { heading: "PATH OF THE DIVINE ARM", ability: "wisdom", tradition: "divinity", special: "SACRED CHANNEL", spell: "Shielding Strike" },
  { heading: "PATH OF THE ETHEREAL STRIDER", ability: "charisma", tradition: "ethereal", special: "DIMENSIONAL STEP", spell: "Dimensional Assault" },
  { heading: "PATH OF THE VERDANT WARDEN", ability: "constitution", tradition: "verdant", special: "NATURAL RESILIENCE", spell: "Thunderous Strike" }
]);
export const PATH_NAMES = Object.freeze(PATHS.map((p) => title(p.heading)));

/** The sections from one path's heading to the next. */
function pathSections(heading) {
  const all = CLASSES.spellblade.sections;
  const start = all.findIndex((s) => s.name === heading);
  const next = all.findIndex((s, i) => i > start && /^PATH OF /.test(s.name));
  return all.slice(start, next < 0 ? undefined : next);
}
const psec = (heading, name) => {
  const s = pathSections(heading).find((x) => x.name === name);
  if (!s) throw new Error(`Block 4: ${heading} has no ${name}`);
  return s;
};
const ABILITY_WORD = { intelligence: "Intelligence", wisdom: "Wisdom", charisma: "Charisma", constitution: "Constitution" };

export const SPELLBLADE_PATH = classAbility({
  name: "Spellblade Path", sourceClass: "Spellblade", level: 1,
  description: `${printed(sb("SPELLBLADE PATH").lines)}\n${["KEY ABILITY SCORE", "BONUS SKILLS", "SPECIAL ABILITY", "PATH SPELL"].map((n) => block(sb(n))).join("\n")}\n${note("*Automated:* press Use to choose the Arcane Duellist, the Divine Arm, the Ethereal Strider or the Verdant Warden. The path is added to your sheet with everything it grants. It is a one-off choice; to change it, delete the path.")}`,
  flags: { abilityChoices: [...PATH_NAMES] }
});

function pathOf(p) {
  const name = title(p.heading);
  const sections = pathSections(p.heading);
  const key = psec(p.heading, "KEY ABILITY SCORE").lines[0];
  if (!key.startsWith(ABILITY_WORD[p.ability])) throw new Error(`Block 4: ${name}'s key ability is "${key}"`);
  const skills = /^([A-Z][\w ]+?) & ([A-Z][\w ]+?)\.?$/.exec(psec(p.heading, "BONUS SKILLS").lines[0]);
  if (!skills) throw new Error(`Block 4: ${name}'s bonus skills`);
  const spellLine = psec(p.heading, "PATH SPELL").lines[0];
  if (!spellLine.includes(p.spell)) throw new Error(`Block 4: ${name}'s path spell is not ${p.spell}`);
  const special = title(p.special);
  const automation = `*Automated (0.7.0, TRG Prime 3.682.0):* ${ABILITY_WORD[p.ability]} is your magical ability and ${p.tradition[0].toUpperCase()}${p.tradition.slice(1)} your tradition (your Spellcraft, your PP's static bonus, your book's spells). ${skills[1]} and ${skills[2]} are class skills. **${special}** and **${p.spell}** (a specialist spell, always ready) are granted at 1st.`;
  return classAbility({
    name, sourceClass: "Spellblade", level: 1,
    description: `${printed(sections[0].lines)}\n${sections.slice(1).map(block).join("\n")}\n${note(automation)}`,
    grantedAbilities: special,
    grantedSpells: `1: ${p.spell}`,
    flags: {
      classMagic: { ability: p.ability, tradition: p.tradition },
      classSkills: [skills[1], skills[2]],
      eaSpellbladePath: name
    }
  });
}
export const SPELLBLADE_PATHS = PATHS.map(pathOf);

/** A path's special ability, its traits as printed. */
const special = (p, automation, extra = {}) => {
  const s = psec(p.heading, p.special);
  return classAbility({
    name: title(p.special), sourceClass: "Spellblade", level: 1,
    description: `${s.traits.length ? md(`**${s.traits.join(" ")}**`) + "\n" : ""}${printed(s.lines)}\n${note(automation)}`,
    traits: traitWords(s.traits),
    ...extra,
    flags: { eaSpellbladePath: title(p.heading), ...(extra.flags ?? {}) }
  });
};

export const ARCANE_ECHO = special(PATHS[0],
  "*Automated (0.7.0):* when you cast a spell successfully (a cantrip too; Q50) and Arcane Echo has its use, the use is spent and your next melee attack before the start of your next turn gains +1 circumstance to the attack and +1 to its damage. It is spent on that attack, hit or miss. A Focus ability: one use, restored by Refocus or daily preparation (Q36).");
export const SACRED_CHANNEL = special(PATHS[1],
  "*Automated (0.7.0):* when you hit with a weapon attack and Sacred Channel has its use, you are asked: spend 1 PP and the use to heal 1d8 HP (2d8 at 5th, 3d8 at 10th, 4d8 at 15th, 5d8 at 20th). A Focus ability: one use, restored by Refocus or daily preparation (Q36).");
export const DIMENSIONAL_STEP = special(PATHS[2],
  "*Automated (0.7.0):* press Use (1 AP) and click where you teleport: up to 10 feet per 2 Spellblade levels, at least 10 (Q51). No Spatial Awareness check (it is not a spell; as Gale Step). A Focus ability: one use, restored by Refocus or daily preparation (Q36).");
export const NATURAL_RESILIENCE = special(PATHS[3],
  "*Automated (0.7.0, TRG Prime 3.682.0):* resistance to poison damage and to damage from a disease, whatever its type (Q43): each is halved. +1 maximum HP per level, trued up as you level (the core's stored grant).",
  { effects: [(id, n) => changesEffect(id, `${n}: resistance to poison and disease`, [{ key: "system.combat.resistances", mode: 2, value: ", poison, disease", priority: 20 }], "Natural Resilience: poison damage, and damage from a disease, are halved.")] });

/* ------------------------------------------------------------------ */
/* The Warlock's abilities and bonded souls                             */
/* ------------------------------------------------------------------ */

const wl = (heading, nth = 0) => section("warlock", heading, nth);

export const SOULS = Object.freeze([
  // "good damage" is the core's aligned type (its DAMAGE_TYPES have no "good").
  { heading: "THE CELESTIAL SENTINEL", special: "JUDGEMENT OF THE RIGHTEOUS", damageType: "aligned", printedType: "good", traditions: ["arcane", "divinity"], levelTraits: ["aligned", "healing"], rider: { kind: "cast", spell: "Cure", onHit: false } },
  { heading: "THE CRYSTAL ARCHON", special: "PRISMATIC STRIKE", damageType: "essence", traditions: ["arcane", "divinity"], levelTraits: ["light", "warding"], rider: { kind: "cast", spell: "Blindness", onHit: true } },
  { heading: "THE EMBERLORD", special: "DRACONIC FLAME", damageType: "fire", traditions: ["arcane", "divinity"], levelTraits: ["fire", "healing"], rider: { kind: "recurring", dice: "1d6", type: "fire", onHit: true } },
  { heading: "THE INFERNAL TEMPTER", special: "HELLISH BARGAIN", damageType: "fire", traditions: ["arcane", "ethereal"], levelTraits: ["emotion", "fire"], rider: { kind: "cast", spell: "Idiocy", onHit: true } },
  { heading: "THE PALE REAPER", special: "REAPER’S TOUCH", damageType: "essence", traditions: ["divinity", "ethereal"], levelTraits: ["fear", "soul"], rider: { kind: "cast", spell: "Fear", onHit: true } },
  { heading: "THE VERDANT SPIRIT WALKER", special: "VERDANT PULSE", damageType: "poison", traditions: ["ethereal", "verdant"], levelTraits: ["animal", "plant"], gmTraits: true, rider: { kind: "cast", spell: "Slow", onHit: true } },
  { heading: "THE VOID SEER", special: "VOID GAZE", damageType: "force", traditions: ["arcane", "ethereal"], levelTraits: ["insight"], rider: null },
  { heading: "THE WHISPERED SAGE", special: "SHADOWSTEP ECHO", damageType: "cold", traditions: ["arcane", "ethereal"], levelTraits: ["shadow"], rider: { kind: "cast", spell: "Misty Step", onHit: false, self: true } }
]);
export const SOUL_NAMES = Object.freeze(SOULS.map((s) => title(s.heading)));

/** The sections from one soul's heading to the next. */
function soulSections(heading) {
  const all = CLASSES.warlock.sections;
  const start = all.findIndex((s) => s.name === heading);
  const next = all.findIndex((s, i) => i > start && SOULS.some((x) => x.heading === s.name));
  return all.slice(start, next < 0 ? undefined : next);
}
const ssec = (heading, name) => {
  const s = soulSections(heading).find((x) => x.name === name);
  if (!s) throw new Error(`Block 4: ${heading} has no ${name}`);
  return s;
};

export const BONDED_SOUL = classAbility({
  name: "Bonded Soul", sourceClass: "Warlock", level: 1,
  description: `${printed(wl("BONDED SOUL", 0).lines)}\n${printed(wl("BONDED SOUL", 1).lines)}\n${["BONUS SKILLS", "SPECIAL ABILITY", "AVAILABLE SPELLS"].map((n) => block(wl(n))).join("\n")}\n${note("*Automated:* press Use to choose one of the eight. The soul is added to your sheet; press Use on it to choose the spells and cantrips you are owed. It is a one-off choice; to change it, delete the soul.")}`,
  flags: { abilityChoices: [...SOUL_NAMES] }
});

export const WARLOCK_HEXES = classAbility({
  name: "Hexes", sourceClass: "Warlock", level: 1,
  description: `${printed(wl("HEXES").lines)}\n${note("*Automated (0.7.0):* press Use to choose your hex (one, at 1st): any hex the module knows, added as an innate spell with the Focus trait (one use until Refocus), cast with Charisma at your level; its base PP may be up to your level + 1, as your spells'. More hexes come through the core's Specialist Spell feat (M28).")}`
});

function soulOf(s) {
  const name = title(s.heading);
  const sections = soulSections(s.heading);
  const skills = /^([A-Z][\w ]+?) & ([A-Z][\w ]+?)\.?$/.exec(ssec(s.heading, "BONUS SKILLS").lines[0]);
  if (!skills) throw new Error(`Block 4: ${name}'s bonus skills`);
  const specialLine = ssec(s.heading, s.special).lines.join(" ");
  if (!new RegExp(`inflict ${s.printedType ?? s.damageType} damage instead of mental`).test(specialLine)) throw new Error(`Block 4: ${name}'s Xithra type is not ${s.printedType ?? s.damageType}`);
  const spells = ssec(s.heading, "AVAILABLE SPELLS").lines.join(" ");
  for (const t of s.traditions) if (!new RegExp(t === "divinity" ? "Divinity" : t[0].toUpperCase() + t.slice(1)).test(spells)) throw new Error(`Block 4: ${name} lists no ${t}`);
  const rider = !s.rider ? "It prints no once-a-day power."
    : s.rider.kind === "recurring" ? `Once a day, when Xithra hits, you are asked: the target takes ${s.rider.dice} recurring ${s.rider.type} damage (the core's Recurring condition).`
      : s.rider.self ? `Once a day, when you use Xithra, you are asked: cast ${s.rider.spell} at 0 AP, as an innate spell.`
        : s.rider.onHit ? `Once a day, when Xithra hits, you are asked: cast ${s.rider.spell} on the target at 0 AP, as an innate spell at your innate level and DC (its save as the spell's).`
          : `Once a day, when you use Xithra, you are asked: cast ${s.rider.spell} at 0 AP on a target within 30 feet, as an innate spell.`;
  const automation = [
    "*Automated (0.7.0, TRG Prime 3.682.0):*",
    `${skills[1]} and ${skills[2]} are class skills. Xithra may deal ${s.printedType ? `${s.printedType} damage (the core's ${s.damageType} type; the alignment is not read)` : `${s.damageType} damage`} instead of mental, chosen at each use. ${rider} The rider is spent until your next daily preparation, and its spell is cast at its base PP (Q41); the innate level limit does not refuse it.`,
    `**Your spells** (press Use): from the ${s.traditions.map((t) => t[0].toUpperCase() + t.slice(1)).join(" and ")} traditions, base PP no higher than your level + 1.`,
    s.gmTraits
      ? "**+1 level:** with a spell carrying the Animal or Plant trait. *GM's call:* any other spell that \"directly affects\" animals or plants — the innate level is not raised for it."
      : `**+1 level** (TRG Prime 3.682.0's innate level bonus) with a spell carrying the ${s.levelTraits.map((t) => t[0].toUpperCase() + t.slice(1)).join(" or ")} trait or school${s.levelTraits.includes("aligned") ? " (*the alignment is not read:* any Aligned spell)" : ""}: its innate attack, DC, free warp budget and PP limit.`
  ].join(" ");
  return classAbility({
    name, sourceClass: "Warlock", level: 1,
    description: `${printed(sections[0].lines)}\n${sections.slice(1).map(block).join("\n")}\n${note(automation)}`,
    flags: {
      classSkills: [skills[1], skills[2]],
      eaBondedSoul: { name, damageType: s.damageType, traditions: [...s.traditions], levelTraits: [...s.levelTraits], rider: s.rider ? { ...s.rider } : null }
    }
  });
}
export const BONDED_SOULS = SOULS.map(soulOf);

export const CLASS_ABILITIES_B4 = [INFUSE_WEAPON, BATTLE_MAGE, SPELLBLADE_PATH, ARCANE_ECHO, SACRED_CHANNEL, DIMENSIONAL_STEP, NATURAL_RESILIENCE, BONDED_SOUL, WARLOCK_HEXES];
export const SUBCLASSES_B4 = [...SPELLBLADE_PATHS, ...BONDED_SOULS];

/** Sidebar 16: the core class feats Chapter 3's classes gain, as printed. */
export const EXISTING_CLASS_FEATS = (() => {
  const s = BOOK.sidebars.find((x) => x.title === "EXISTING FEATS");
  const out = {};
  for (let i = 1; i + 1 < s.lines.length; i += 1) {
    if (/^[A-Z/]+$/.test(s.lines[i])) {
      for (const cls of s.lines[i].split("/")) out[cls[0] + cls.slice(1).toLowerCase()] = s.lines[i + 1].split(/,\s*/).map((f) => f.trim());
    }
  }
  return out;
})();
