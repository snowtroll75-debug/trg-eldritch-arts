/**
 * Eldritch Arts — Block 5 (0.8.0), group A: Chapter 5's 18 Aetherial racial
 * feats, and the 9 racial feats for other races (Elf, Human, Gnome,
 * Kornargon, Ascendan and the Quiliesh Heritage feat).
 *
 * The spec is docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix A, as Graham
 * answered it on 3 November 2026: as proposed (Q57, Q60–Q66) except Q58 and
 * Q59. Built on TRG Prime 3.683.0's seams (C1, C2, C4, C8, C9, C16–C19).
 *
 * Every feat is built with block5-common.mjs's `racialFeat`, so its card is
 * the book's text followed by one paragraph saying what TRG Prime does with
 * it. What is data lives here (effects, conditionals, auras, declarations);
 * the Uses, reactions and hooks are module/block5a-automations.mjs.
 *
 * FLAGS under the system's scope are TRG Prime's declarations, except the
 * module's own `ea…` keys (`eaAutomation`), which the system does not read.
 */
import { racialFeat } from "./block5-common.mjs";
import { changesEffect, racialSkillEffect, conditional } from "./builders.mjs";

const effect = (name, changes, description) => (id, n) => changesEffect(id, `${n}: ${name}`, changes, description);
const skills = (list, value = 1) => (id, n) => racialSkillEffect(id, n, list, value);

/** Graham's Q61: the ambient light where your token stands; "Dim or less" is 1–5. */
export const DIM_OR_LESS = Object.freeze({ max: 5 });
/** Moonlight Precision: "light levels 5 & 6". */
export const DIM_OR_TWILIGHT = Object.freeze([5, 6]);

/** Radiant Presence's light (registered by the automations; the light's key is shared). */
export const RADIANT_LIGHT_KEY = "radiantPresence";

/* ------------------------------------------------------------------ */
/* The Aetherial feats                                                  */
/* ------------------------------------------------------------------ */

export const AETHERIAL_FEATS = [
  racialFeat("AETHERIAL CONCORD", {
    flags: { eaAutomation: "aetherialConcord" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* when a spell you cast settles at Success or better (a cantrip or an innate spell too; Q26; not a spell released from an item) and this feat's Focus use is ready, you are asked which ally within 30 feet to grant. That ally gains +2 circumstance to its next saving throw or skill check before the end of its next turn: applied by itself to that roll, then spent (out of combat, it lasts 1 round). The Focus use is spent; Refocus or daily preparation restores it. Declining spends nothing."
  }),
  racialFeat("AETHERIAL SCHOLAR", {
    flags: { eaAutomation: "aetherialScholar" },
    effects: [skills(["Arcana", "Occultism"])],
    automation: "*Automated:* +1 racial to Arcana and Occultism. **Use** (once) puts the +2 on **Astral Lore**, the Aetherial's racial specialist skill, in its racial slot (read as racial, as the core's Scholar feats). If your sheet has no Astral Lore yet, the Use says so."
  }),
  racialFeat("ASTRAL CROSSING", {
    flags: { eaAutomation: "astralCrossing" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* **Use** (0 AP) at the start of your turn, before you have spent any AP (refused after), makes you **incorporeal** until the start of your next turn (1 round out of combat): the core's Incorporeal trait. While it lasts you may move through occupied squares, though not end your move in one (C18). Walls and solid objects are the GM's: the map's walls still block the token. A Focus feat: one use, restored by Refocus or daily preparation."
  }),
  racialFeat("ASTRAL DRIFT", {
    flags: { ignoresDifficultTerrain: "magical", eaAutomation: "astralDrift" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* difficult terrain made by a spell or a magical effect costs you nothing extra (C16); ground the GM drew, or a path that mixes the two kinds, is not eased. When 3 AP of your turn have gone on actions with the Movement trait (Stride, Step, Sneak …; a teleport is not one; C17), your free Step is armed: drag your token up to 5 feet on land, at no AP and provoking no reactions, as a Step. The card says so."
  }),
  racialFeat("ASTRAL STEP", {
    flags: { eaAutomation: "astralStep" },
    automation: "*Automated (0.8.0):* **Use** (1 AP; Graham's Q62) and click where you teleport: up to your land speed, to an unoccupied space (the core refuses an occupied one). No Spatial Awareness check (it is not a spell; Q51's reading). A Focus feat: one use, restored by Refocus or daily preparation."
  }),
  racialFeat("CHRONAL AWARENESS", {
    effects: [effect("+20 initiative", [{ key: "system.combat.initiative.race", mode: 0, value: "20", priority: 20 }], "+20 racial bonus to Initiative checks.")],
    automation: "*Automated:* +20 racial to Initiative (the core's Swift Reflexes key). Offered only to a Nerathis (TRG Prime 3.683.0 gates the heritage prerequisite; Q57)."
  }),
  racialFeat("CHRONAL ECHO", {
    flags: { eaAutomation: "chronalEcho" },
    automation: "*Automated (0.8.0):* when an attack hits you (a weapon or a spell attack) and this feat's Focus use and your reaction are ready, you are asked. Yes spends both and the attacker rerolls; the second result stands and cannot be modified or rerolled (the core's rule for every reaction reroll; the book says only \"reroll\"). One reroll a check, so it does not combine with another reaction's."
  }),
  racialFeat("RADIANT BULWARK", {
    flags: {
      auras: [{ kind: "ally", radius: 10, name: "Radiant Bulwark", allyEffect: { changes: [{ key: "system.combat.defence.circumstance", value: "1" }] } }]
    },
    automation: "*Automated:* each ally within 10 feet of you (Radiant Presence's aura) carries +1 circumstance to DB while inside, laid as it enters and lifted as it leaves (the core's ally auras). You are not your own ally."
  }),
  racialFeat("RADIANT PRESENCE", {
    flags: {
      eaAutomation: "radiantPresence",
      auras: [{
        kind: "ally", radius: 10, name: "Radiant Presence",
        allyEffect: {
          conditionals: [
            conditional({ kind: "modifier", value: 1, type: "circumstance", label: "Radiant Presence", scope: "Saving throws against effects with the fear trait", auto: true, when: { checkTypes: ["save"], traits: ["fear"] } }),
            conditional({ kind: "modifier", value: 1, type: "circumstance", label: "Radiant Presence", scope: "Saving throws against an effect with the fear trait — tick if this save is one", auto: false, when: { checkTypes: ["save"], not: { traits: ["fear"] } } })
          ]
        }
      }]
    },
    automation: "*Automated (0.8.0):* you shed light in a 10-foot radius, raising the light level 2 steps (a light source of the module's, on your token), always on as printed (Graham's Q64). Each ally within 10 feet gains +1 circumstance to saves against an effect with the fear trait, applied by itself when the roll names the trait, and offered as a tick when it cannot tell. Offered only to a Caelari (C1)."
  }),
  racialFeat("RESONANT ASCENDANCE", {
    flags: { eaAutomation: "resonantAscendance" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* when another creature within 30 feet casts a spell you can see (Q28: not while you are blinded), you are asked after its casting check, as for Disrupting Magic (Q33), while this feat's Focus use and your reaction are ready and you are trained in Power Manipulation. Yes rolls the core's Dispel against the spell at the PP you declare, at no AP; Success or better stops it. You pay half the PP you declared, rounded up, whatever the degree, never halved twice (Q63); the counteract roll uses the PP declared. The reaction and the Focus use are spent once the Dispel is rolled. Allies' casts are asked too: decline them."
  }),
  racialFeat("RESONANT HARMONY", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* an option in the spell's own **Warp?** dialog (Block 6's module metamagic, G1; Q66), offered when the spell's range is Self and it has no area: **0 PP**, and choose one adjacent ally, who receives the spell's effect on you as well (the core shares the spell's self rows with it). Rows the core cannot share (a form, a move or a teleport, a note) are the GM's. Learned and innate casts; never an item's spell, a scroll, a potion, a stored spell or a cantrip (Q94). A Focus feat: its use is spent when the cast pays its PP (Q96), restored by Refocus or daily preparation."
  }),
  racialFeat("RESONANT PULSE", {
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* an option in the spell's own **Warp?** dialog (Block 6's module metamagic, G1; Q66), offered on a spell with a saving throw: **0 PP**, Save DC +1 (untyped). It reaches learned and innate casts; not a charged item's spell (only Metamagic Conduit opens those), and never a scroll, a potion, a stored spell or a cantrip (Q94 — this card said \"item casts too\" before the ruling). A Focus feat: its use is spent when the cast pays its PP (Q96), restored by Refocus or daily preparation."
  }),
  racialFeat("SKYBORNE AGILITY", {
    flags: { eaAutomation: "skyborneAgility" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* once your own moves on your turn reach 15 feet (measured feet, not terrain cost; a teleport is not a move; C17), you gain +2 circumstance to DB until the start of your next turn. Once a turn. Offered only to an Aeralis (C1)."
  }),
  racialFeat("SKYBORNE WALTZ", {
    grantedSpells: "Feather Fall",
    flags: { grantInnate: true },
    automation: "*Granted:* the core's Feather Fall, as an innate spell with the Focus trait (one use, restored by Refocus or daily preparation), cast as a reaction as the spell prints."
  }),
  racialFeat("STARSEER’S INTUITION", {
    effects: [skills(["Sense Motive"])],
    flags: {
      conditionals: [conditional({ kind: "modifier", value: 1, type: "racial", label: "Starseer’s Intuition", scope: "Spellcraft checks to cast spells of the Insight school", auto: true, when: { checkTypes: ["spellcraft"], traits: ["insight"] } })]
    },
    automation: "*Automated:* +1 racial to Sense Motive, and +1 racial to the Spellcraft check of a spell of the Insight school (a learned spell's attack is that check; an innate spell rolls none). Offered only to an Astryn (C1)."
  }),
  racialFeat("STARSEER’S SIGHT", {
    flags: {
      conditionals: [
        conditional({ kind: "advantage", label: "Starseer’s Sight", scope: "Saving throws against effects with the mental trait", auto: true, when: { checkTypes: ["save"], traits: ["mental"] } }),
        conditional({ kind: "advantage", label: "Starseer’s Sight", scope: "Saving throws against an effect with the mental trait — tick if this save is one", auto: false, when: { checkTypes: ["save"], not: { traits: ["mental"] } } })
      ]
    },
    automation: "*Automated:* advantage on a save against an effect with the mental trait, applied by itself when the roll names the trait, and offered as a tick when it cannot tell (as the Nerathis heritage's)."
  }),
  racialFeat("VEIL OF DUSK", {
    grantedSpells: "Darkness",
    flags: { grantInnate: true },
    automation: "*Granted:* the core's Darkness, as an innate spell with the Focus trait (one use, restored by Refocus or daily preparation). Its PP 4 is within an innate spell's limit from 5th level, the feat's own."
  }),
  racialFeat("VEIL OF SILENCE", {
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Veil of Silence", scope: "Stealth checks while the light is Dim or less", auto: true, when: { checkTypes: ["skill"], subjects: ["stealth"], lightLevels: DIM_OR_LESS } }),
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Veil of Silence", scope: "Reflex saves while the light is Dim or less", auto: true, when: { checkTypes: ["save"], subjects: ["reflex"], lightLevels: DIM_OR_LESS } })
      ]
    },
    automation: "*Automated (TRG Prime 3.683.0, C4):* +2 racial to Stealth checks and Reflex saves while the light where your token stands is level 5 (Dim Light) or less: the ambient light (sources, Darkness, regions and weather), not raised by your own Darkvision (Graham's Q61). A roll made with no token on the map takes nothing. Offered only to an Umbryth (C1)."
  })
];

/* ------------------------------------------------------------------ */
/* The feats for other races                                            */
/* ------------------------------------------------------------------ */

export const OTHER_RACE_FEATS = [
  racialFeat("ANCESTRAL REVERIE", {
    flags: { eaAutomation: "ancestralReverie" },
    automation: "*Automated (0.8.0):* at daily preparation you are asked for one Intelligence- or Wisdom-based skill (the 17 the core keys to either; specialist Lore skills carry no ability and are not offered). It takes +2 racial until your next daily preparation, which sweeps it. **Use** makes or changes the pick if you missed the question."
  }),
  racialFeat("ENDLESS ADAPTATION", {
    usesPerDay: "1",
    flags: { eaAutomation: "endlessAdaptation" },
    automation: "*Automated (0.8.0):* **Use** (once a day) and choose the skill: your next check with it takes a class bonus, applied by itself and then spent. A skill that is not a class skill takes your class bonus + 2; one that already is takes +2 (Graham's Q65). Class bonuses from different sources stack. Daily preparation restores the use and sweeps an unspent bonus."
  }),
  racialFeat("FEYBLOOD GLAMOUR", {
    effects: [skills(["Deception", "Perform"])],
    automation: "*Automated:* +1 racial to Deception and Perform."
  }),
  racialFeat("MOONLIGHT PRECISION", {
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 1, type: "racial", label: "Moonlight Precision", scope: "Ranged attacks in Dim Light or Twilight", auto: true, when: { checkTypes: ["attack"], attackModes: ["ranged"], lightLevels: DIM_OR_TWILIGHT } }),
        conditional({ kind: "modifier", value: 1, type: "racial", label: "Moonlight Precision", scope: "Spellcraft checks in Dim Light or Twilight", auto: true, when: { checkTypes: ["spellcraft"], lightLevels: DIM_OR_TWILIGHT } })
      ]
    },
    automation: "*Automated (TRG Prime 3.683.0, C4):* +1 racial to ranged attacks and Spellcraft checks (a learned spell's attack is its Spellcraft check) while the light where you stand is level 5 or 6: the ambient light at the attacker's square, not raised by your Nightvision (Graham's Q61). A roll made with no token on the map takes nothing."
  }),
  racialFeat("QUILIESH", {
    sourceRace: "Human",
    grantedAbilities: "Forbidden Magic",
    effects: [skills(["Arcana", "Occultism"])],
    flags: { eaAutomation: "quiliesh" },
    automation: "*A Human Heritage feat* (Graham's Q60; the Heritage trait keeps it to 1st level, as the core's Half-Elf). *Automated (0.8.0):* +1 racial to Arcana and Occultism. **Use** chooses your cantrip from the Arcane or Ethereal traditions, added as a spell you cast with Spellcraft (not innate); using it again replaces the pick. You may take the racial feats open to the Ascendan, and the heritage picker offers the Ascendan heritages too (the core's Half-Elf rule). *Granted:* the core's Forbidden Magic ability: you cannot cast divine or verdant spells, and take −2 on saves against them, and must save against beneficial ones. Against a High Magic cast, which counts as every tradition, it applies too (Graham's Q58), unless you hold Unbound."
  }),
  racialFeat("RELENTLESS WILL", {
    usesPerDay: "1",
    flags: { eaAutomation: "relentlessWill" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0, C8):* the first time each day you gain the Dying condition, the day's use is spent and that Dying is marked. Leaving it, by any route (healing, a recovery check, stabilising), costs no point of Fatigued, said on the card. When your HP is next above 0 after it, you gain advantage on your next saving throw within 1 minute: applied by itself, then spent. A fatal injury that holds you in Dying still holds you. Daily preparation restores the use."
  }),
  racialFeat("SHADOW’S DISCIPLINE", {
    flags: { eaAutomation: "shadowsDiscipline" },
    automation: "*Automated (0.8.0):* while your Shadow Stance is up, +2 racial to Reflex saves, laid and lifted with the stance. *Partly automated:* once you have moved 10 feet on your turn in the stance (C17), a card says you may Hide without cover or concealment. The core asks for neither (cover for Hide is the GM's), except that it refuses Hide from Lesser Cover, which this feat does not lift: the GM allows that one."
  }),
  racialFeat("UNBOUND", {
    flags: { forbiddenSparesHighMagic: true },
    automation: "*Automated (TRG Prime 3.683.0; Graham's Q59):* against a High Magic cast, your Forbidden Magic does not apply at all: no −2 on the save from that cast's traditions, and no Will save against a beneficial one. Against an ordinary cast it applies as before. Your own High Magic casting already ignores the tradition gate (TRG Prime 3.680.0). Offered at 1st level only (C1)."
  }),
  racialFeat("VEIL OF HONOUR", {
    flags: { eaAutomation: "veilOfHonour" },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0, C19):* when a melee Strike damages you and this feat's Focus use and your reaction are ready, you are asked. Yes spends both, then enters Shadow Stance as a reaction (no AP; the Open trait is not asked; the Stance trait's wait still is), Concealed until the start of your next turn; if you are already in the stance, Concealed is renewed as if you had moved. Then an innate Daze is cast at your attacker, at no AP, PP or further use; it saves as the spell prints."
  })
];

export const FEATS_B5_A = [...AETHERIAL_FEATS, ...OTHER_RACE_FEATS];

/**
 * The docs' table: what each feat does in 0.8.0. A full, B automated with a
 * normal choice, C partial (the rest a card or the GM's), D descriptive.
 */
export const AUTOMATION_B5_A = Object.freeze({
  "Aetherial Concord": { level: "B", what: "On a Success+ cast with the Focus use ready, choose an ally within 30 ft: +2 circumstance to its next save or skill check before the end of its next turn (one-shot effect); the use is spent." },
  "Aetherial Scholar": { level: "A", what: "+1 racial Arcana and Occultism; a one-click Use writes +2 racial on Astral Lore." },
  "Astral Crossing": { level: "B", what: "0 AP Use before any AP is spent: incorporeal until the start of the next turn; passes occupied squares (C18); walls are the GM's." },
  "Astral Drift": { level: "B", what: "Magical difficult terrain eased (C16); after 3 AP of Movement actions, a free 5-ft Step armed (C17, armMove)." },
  "Astral Step": { level: "B", what: "1 AP Use (Q62): click a square within land speed and teleport; Focus." },
  "Chronal Awareness": { level: "A", what: "+20 racial initiative." },
  "Chronal Echo": { level: "B", what: "Reaction on being hit: the attacker rerolls (locked), reaction and Focus spent." },
  "Radiant Bulwark": { level: "A", what: "Ally aura, 10 ft: +1 circumstance DB." },
  "Radiant Presence": { level: "A", what: "A registered light (2 steps, 10 ft) on the actor; ally aura +1 circumstance to saves vs fear (auto, tick when unknown)." },
  "Resonant Ascendance": { level: "B", what: "Cast reaction within 30 ft: the core's Dispel at half the declared PP whatever the degree (C9, Q63); reaction and Focus spent." },
  "Resonant Harmony": { level: "B", what: "Block 6's module metamagic (G1, registered by block6d): 0 PP, Focus; on a self-only spell an adjacent ally receives its self rows (targets.share)." },
  "Resonant Pulse": { level: "B", what: "Block 6's module metamagic (G1, registered by block6d): 0 PP, Focus; Save DC +1 on a spell with a save; learned and innate casts (Q94)." },
  "Skyborne Agility": { level: "A", what: "15 ft moved on your turn: +2 circumstance DB until the start of your next turn (C17)." },
  "Skyborne Waltz": { level: "A", what: "Feather Fall granted innate (Focus)." },
  "Starseer’s Intuition": { level: "A", what: "+1 racial Sense Motive; +1 racial Spellcraft for Insight spells." },
  "Starseer’s Sight": { level: "A", what: "Advantage on saves vs mental (auto; tick when unknown)." },
  "Veil of Dusk": { level: "A", what: "Darkness granted innate (Focus)." },
  "Veil of Silence": { level: "A", what: "+2 racial Stealth and Reflex while the ambient light at your token is 5 or less (C4, Q61)." },
  "Ancestral Reverie": { level: "B", what: "Daily-preparation pick of an Int/Wis skill: +2 racial until the next preparation; Use as fallback." },
  "Endless Adaptation": { level: "B", what: "1/day Use: the next check of the chosen skill takes class bonus + 2 (or +2 for a class skill; Q65)." },
  "Feyblood Glamour": { level: "A", what: "+1 racial Deception and Perform." },
  "Moonlight Precision": { level: "A", what: "+1 racial ranged attacks and Spellcraft in light 5–6 at your token (C4, Q61)." },
  "Quiliesh": { level: "B", what: "Human Heritage feat (Q60): +1 racial Arcana/Occultism; Use picks an Arcane/Ethereal cantrip (Spellcraft); Ascendan feats opened (registerHeritageRaceGrant); Forbidden Magic granted." },
  "Relentless Will": { level: "A", what: "First Dying of the day: leaving it costs no Fatigued (C8); then advantage on the next save within 1 minute once above 0 HP." },
  "Shadow’s Discipline": { level: "C", what: "+2 racial Reflex while in Shadow Stance (companion effect); the Hide clause is a card, Lesser Cover's refusal not lifted." },
  "Unbound": { level: "A", what: "Declares forbiddenSparesHighMagic (Q59): the core spares Forbidden Magic against High Magic casts." },
  "Veil of Honour": { level: "B", what: "On melee Strike damage: reaction and Focus; Shadow Stance entered at 0 AP (C19) or Concealed renewed; innate Daze cast at the attacker." }
});
