/**
 * Eldritch Arts — Block 6 (0.9.0), group E: Chapter 5's 21 Warlock and
 * Witch class feats (Appendix E), on TRG Prime 3.684.0. The Warlock's
 * Charisma pool (Q97, Q98) is Block 4's (block4.mjs, block4-automations.mjs).
 *
 * The spec is docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md, Appendix E, as Graham
 * answered it on 4 November 2026 (Q89: one release; Q90–Q149 as proposed):
 * Q93 (a cheaper spell is payment only), Q97, Q98, Q99 (spells a Witch gains
 * outside Ethereal and Verdant are High Magic: since Graham's ruling of
 * 4 November 2026 every Witch spell is, through her class's
 * `highMagicCaster: true`, and the trait Q99 adds is kept beside it), Q134–Q141. The seams are
 * TRG Prime 3.684.0's as built (b6-contracts.md): G4 (Hex Mastery), G7
 * (Pact Ascendant's Demonic guard), G21 (Extra Communion), G23 (Warlock's
 * Hex, Hex Binders Curse), G24 (Symbiotic Witch), G25 (the innate save DC).
 *
 * Every feat is built with block6-common.mjs's `classFeat`, so its card is
 * the book's text followed by one paragraph saying what TRG Prime does with
 * it. What is data lives here; the Uses, offers and hooks are
 * module/block6e-automations.mjs.
 *
 * FLAGS under the system's scope are TRG Prime's declarations, except the
 * module's own `ea…` keys (`eaAutomation`), which the system does not read.
 */
import { classFeat } from "./block6-common.mjs";
import { declaredEffect } from "./builders.mjs";

const auto = (key) => ({ eaAutomation: key });

export const FEATS_B6_E = [
  classFeat("ELEMENTAL BLAST", {
    flags: auto("elementalBlast"),
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* at each daily preparation you are asked for today's element — acid, cold, electricity, fire or sonic (or press **Use** to choose it). Xithra then offers that type at each use beside mental and your bonded soul's type (the core's damage-type choice on the spell). The choice holds until you choose again."
  }),
  classFeat("ENHANCED BLAST", {
    flags: auto("enhancedBlast"),
    automation: "*Automated (0.9.0):* Xithra's dice are d8s: its base die and every die it gains at 4th and every 4 levels (its critical dice follow the spell's own), and Xithra Cone's too. Written onto your Xithra when the feat arrives, and put back to d6 if it leaves."
  }),
  classFeat("ETHEREAL INSIGHT", {
    grantedAbilities: "Darkvision",
    grantedSpells: "See Invisible",
    flags: { ...auto("etherealInsight"), grantInnate: true, grantedSpellUses: { "See Invisible": "1" } },
    automation: "*Automated (0.9.0, TRG Prime 3.684.0):* you are granted the core's **Darkvision**, and **See Invisible** as an innate spell once a day (daily preparation restores it). *Your familiar* (the Soulbound one): while its token is within 30 feet of yours it carries Darkvision (the core ability, added and removed as either moves); when you cast your daily See Invisible and it is within 30 feet, the spell's sight is laid on it too, from the one casting, for the spell's duration (Q140). Off the map, the familiar's Darkvision stays as it was last found."
  }),
  classFeat("EXTRA BOND", {
    repeatable: true,
    flags: auto("extraBond"),
    automation: "*Automated (0.9.0):* each time you choose your Soulbound Familiar's daily bonus (at daily preparation or with its Use), you are asked for one more bonus per copy of this feat, each different from the others (two of one bonus would not stack; minor 6). Each is its own effect, switched on and off with the familiar's 30-foot range as the first is, and gone when the bond is severed or at the next choice. **Use** asks them again. *Printed, not enforced:* \"no more than once every four levels\" (the core keeps no feat cadence)."
  }),
  classFeat("EXTRA COMMUNION", {
    automation: "*Automated (TRG Prime 3.684.0, G21):* **Verdant Communion** has one more use a day (the core's declared extra uses: the sheet's maximum and the daily top-up both read it)."
  }),
  classFeat("FORBIDDEN LORE", {
    flags: auto("forbiddenLore"),
    automation: "*Automated (0.9.0):* press **Use** once to choose your spell: any Arcane or Divinity spell (not a specialist spell, a hex or a cantrip) whose base PP is no higher than your caster level + 1. It is added to your repertoire outside your picks and leaves with the feat. It is cast as High Magic (Graham's Q99): the copy carries the Highmagic trait. To change it, delete the spell and press Use again."
  }),
  classFeat("HEX BINDERS CURSE", {
    flags: auto("hexBindersCurse"),
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G23):* **Use** (1 AP, Concentrate: the core's trait rules) with one enemy targeted within 30 feet: it is cursed, and the creature you cursed before loses its curse. The curse is kept on your sheet (an effect naming the creature), not on the creature's. The curse lasts until you curse another, it dies, or your next daily preparation (Q135). Each Strike or spell of yours that damages it deals 1d6 more (2d6 at 10th, 3d6 at 15th, 4d6 at 20th), once a Strike or spell, of the triggering damage's type and through its defences; recurring damage does not trigger it. *The GM's:* \"that you can see\"."
  }),
  classFeat("HEX MASTERY", {
    automation: "*Automated (TRG Prime 3.684.0, G4):* a hex you cast with PP costs 1 PP less to pay, never below 1. The casting DC, the cap and the save DC read the PP as cast (Graham's Q93). A Warlock's hexes are innate and cost nothing, so for a Warlock this feat does nothing."
  }),
  classFeat("HIGH SORCERY", {
    repeatable: true,
    flags: auto("highSorcery"),
    automation: "*Automated (0.9.0):* press **Use** on each copy to choose its spell: one your class could pick (a Witch: Ethereal or Verdant; a Sorcerer: any tradition), not a specialist spell, a hex or a cantrip, base PP no higher than your caster level + 1. It is added to your repertoire outside your picks, cast as High Magic, and leaves with that copy. *Printed, not enforced:* \"no more than once every four levels\"."
  }),
  classFeat("MALEVOLENT BLAST", {
    flags: auto("malevolentBlast"),
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G25):* when Xithra hits and this feat's Focus use is ready, you are asked. Yes spends the use and the target rolls a Will save against your innate save DC for Xithra (10 + Charisma + level, with your soul's +1 where it applies; Q136): on a Failure or worse it is **Stunned 1**, or **Stunned 2** if the hit was critical. Not on Xithra Cone, which rolls no attack (minor 8). Refocus or daily preparation restores the use."
  }),
  classFeat("PACT ASCENDANT", {
    flags: auto("pactAscendant"),
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0):* read from your Pact archetype feat when this arrives (press **Use** if your pact changes). **Angelic:** an ally aura of 10 feet: advantage on saves against effects with the fear trait (automatic when the roll names the trait, a tick otherwise); Resurrection added. **Demonic:** immune to fire; once a day, when damage would take you to 0 HP (not a blow that kills outright), you stay up at half your maximum HP with no Dying (the core's death guard) and explode: 10d6 fire, a basic Reflex save against your Level DC for every creature within 20 feet, allies included (Q141). **Draconic:** a fly speed of 40 feet; Shape of the Wyrm added (the printed \"Shape of the Dragon\", minor 1). **Elemental:** immune to your element's damage type (air electricity, earth acid, fire fire, water cold); Conjure Elemental added. **Fey, Void:** immune to the mental trait and mental damage, as the core reads the word (m47: both as printed); Dominate or Maze added. **Grave:** immune to essence, as the core reads that word; Hand of the Reaper added (the core's Hand Of The Reaper). A Warlock's added spell is innate and Focus, cast with Charisma (Q37); a Witch's joins her repertoire outside her picks, as High Magic (Q99). *The GM's:* the Demonic burst's Evil trait (the core's basic save carries one damage type and no trait); Conjure Elemental's \"your element only\"; an Essence-trait healing effect the Grave immunity would refuse."
  }),
  classFeat("PACT BOON", {
    flags: auto("pactBoon"),
    automation: "*Automated (0.9.0):* read from your Pact archetype feat when this arrives (press **Use** to try again): Angelic Restoration, Demonic Fireball, Elemental Conjure Elemental, Fey Confusion, Grave Create Undead, Void Long Sense. A Warlock's is innate and Focus, cast with Charisma (Q37); a Witch's joins her repertoire outside her picks, as High Magic (Q99). The Draconic pact's is Dragon Wings, a Grimoire spell (0.10.0). *The GM's:* Conjure Elemental's \"your element only\"."
  }),
  classFeat("RITUAL OF BORROWED POWER", {
    flags: auto("borrowedPower"),
    automation: "*Automated (0.9.0):* at each daily preparation you are asked for one spell of any tradition (not a specialist spell, a hex or a cantrip; base PP no higher than your caster level + 1, minor 7), or press **Use** to choose it. It is added to your repertoire with the Highmagic trait, so it is cast as High Magic, and is removed at your next daily preparation."
  }),
  classFeat("SHADOWED GRIMOIRE", {
    repeatable: true,
    flags: auto("shadowedGrimoire"),
    automation: "*Automated (0.9.0):* press **Use** on each copy to choose its spell: from your bonded soul's traditions, base PP no higher than your level + 1 (one more where the soul's +1 applies), as your other spells (minor 5). It is innate with the Focus trait, cast with Charisma (Q37), and leaves with that copy. After you gain a level, the Use offers to replace it. *Printed, not enforced:* \"no more than once every three levels\"."
  }),
  classFeat("SOUL-BOUND GRIMOIRE", {
    flags: auto("soulBoundGrimoire"),
    automation: "*Automated (0.9.0):* at each daily preparation, while your Soulbound bond holds, you are offered the Ethereal and Verdant scrolls you carry: each one chosen is used up (one of its quantity) and its spell is stored in your familiar, outside your repertoire, with no limit (Q138). Then you choose one stored spell for the day: a copy joins your repertoire until the next daily preparation; if you already know it, it instead takes −1 PP off its warping cost (minimum 1) for the day (the core's warp discount). **Use** erases a stored spell. With the bond severed, nothing is imprinted; if the familiar dies, its stored spells are lost."
  }),
  classFeat("SYMBIOTIC WITCH", {
    usesPerDay: "1",
    flags: auto("symbioticWitch"),
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0, G24):* **Use**, then choose: **Cast through your familiar** (once a day) — one of your spells of base PP 4 or less, cast as usual, its range and area measured from your familiar's token, seen or not. **Sustain** — hand one sustained spell to your familiar: you no longer Sustain it and may recover PP; damage to the familiar asks your Spell Concentration check; its death ends the spell at your next turn (Q137). One spell at a time; Use again takes it back. *Partly:* warps that take the conduit's cast above 4 PP are not refused by the system (it checks the base PP only); the card names a cast that went over, for the GM."
  }),
  classFeat("WARDING SIGIL", {
    flags: auto("wardingSigil"),
    automation: "*Automated (0.9.0):* **Use** (1 AP, Graham's Q139; Focus): until the end of your next turn you have resistance to every damage type your Xithra can deal — mental, your bonded soul's type and today's Elemental Blast element. Refocus or daily preparation restores the use."
  }),
  classFeat("WARLOCK’S HEX", {
    flags: auto("warlocksHex"),
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G23):* when a spell of yours (Xithra and Xithra Cone included) damages a creature and this feat's Focus use is ready and you have 1 PP, you are asked (Q134: both are paid). Yes spends the use and 1 PP from your pool, and the creature takes −1 circumstance on saves against your spells and Xithra (−2 from 10th level) for rounds equal to your Charisma (at least 1). Once a cast. Refocus or daily preparation restores the use."
  }),
  classFeat("XITHRA CONE", {
    flags: auto("xithraCone"),
    automation: "*Automated (0.9.0, TRG Prime 3.684.0, G25):* when you cast Xithra you are asked: a bolt, or a 30-foot cone. The cone spends Xithra's AP and Focus use, and each creature you have targeted in it rolls a basic Reflex save against your innate save DC for Xithra (Q136), for one roll of Xithra's damage (its dice by level, + Charisma), of the type you choose. No attack is rolled, so nothing that needs a hit applies (Malevolent Blast, your soul's on-hit power); Warlock's Hex does. *Not offered on the cone:* your soul's once-a-day power (Block 4 asks it after a cast of Xithra). *The GM's:* that the creatures you target are in the cone."
  }),
  classFeat("XITHRA RECOVERY", {
    effects: [declaredEffect("Xithra twice", "You may use your Xithra Blast twice before having to use the Focus action to restore it.", { focusExtraUses: [{ value: 1, names: ["Xithra"], restoresAll: true }] })],
    automation: "*Automated (TRG Prime's Focus declarations):* Xithra has two uses before it is expended, and a Refocus restores both."
  }),
  classFeat("XITHRA SPEAR", {
    flags: auto("xithraSpear"),
    automation: "*Automated (0.9.0):* Xithra's range is 60 feet, written onto your Xithra when the feat arrives and put back to 30 if it leaves."
  })
];

/**
 * The docs' table: what each feat does in 0.9.0. A full, B automated with a
 * normal choice, C partial (a clause the GM's), D descriptive.
 */
export const AUTOMATION_B6_E = Object.freeze({
  "Elemental Blast": { level: "B", what: "Daily-preparation (or Use) element; Xithra's damage-type offer becomes mental + soul + element." },
  "Enhanced Blast": { level: "A", what: "Xithra's base and level dice written as d8 (and back on removal); the cone reads them." },
  "Ethereal Insight": { level: "B", what: "Darkvision granted; See Invisible innate 1/day; the Soulbound familiar within 30 ft carries Darkvision and the day's See Invisible sight (Q140)." },
  "Extra Bond": { level: "B", what: "After each Soulbound daily bonus, one more distinct bonus per copy, range-switched as the first; Use re-asks." },
  "Extra Communion": { level: "A", what: "registerExtraUses: Verdant Communion +1 use a day (G21)." },
  "Forbidden Lore": { level: "B", what: "One Use pick: an Arcane or Divinity spell, PP ≤ CL + 1, added outside the picks with the Highmagic trait (Q99)." },
  "Hex Binders Curse": { level: "B", what: "1 AP Concentrate Use on one targeted enemy within 30 ft, kept on the curser (nothing written on the target); your Strikes and spells that damage it add 1d6 (+1d6 at 10/15/20) of the blow's type, once each (G23, Q135)." },
  "Hex Mastery": { level: "A", what: "registerCastCostModifier: a learned/specialist hex −1 PP paid, min 1; DC and cap unchanged (G4, Q93)." },
  "High Sorcery": { level: "B", what: "One Use pick per copy: a spell the class could pick, PP ≤ CL + 1, added outside the picks as High Magic." },
  "Malevolent Blast": { level: "B", what: "After a Xithra hit, Focus: Will vs the innate DC (G25); Failure or worse Stunned 1, 2 on a critical hit (Q136)." },
  "Pact Ascendant": { level: "C", what: "By the pact: aura, immunities, fly 40, the Demonic death guard at half HP with its 20-ft burst (G7, Q141), the pact's spell (Grave: Hand of the Reaper); synced on create, delete and Use only; the burst's Evil trait and Conjure Elemental's element are the GM's." },
  "Pact Boon": { level: "B", what: "By the pact, the spell added (Warlock innate Focus, Witch High Magic repertoire); Draconic's Dragon Wings (0.10.0)." },
  "Ritual of Borrowed Power": { level: "B", what: "Daily-preparation (or Use) pick of any spell, PP ≤ CL + 1, with the Highmagic trait; removed at the next preparation." },
  "Shadowed Grimoire": { level: "B", what: "One Use pick per copy, as the soul's picks (innate Focus Charisma); after a level gained, the Use offers the swap." },
  "Soul-Bound Grimoire": { level: "B", what: "Daily preparation: E/V scrolls scribed into the familiar (used up), one stored spell imprinted (a day's copy, or −1 warp PP if known); Use erases; lost with the familiar (Q138)." },
  "Symbiotic Witch": { level: "C", what: "1/day cast of a base-PP ≤ 4 spell measured from the familiar (G24 rangeFrom); a sustained spell handed to the familiar (setSpellSustainer). The warped total over 4 PP is carded, not refused." },
  "Warding Sigil": { level: "A", what: "1 AP Focus Use (Q139): resistance to Xithra's types until the end of your next turn." },
  "Warlock’s Hex": { level: "B", what: "After your spell's damage (G23): Focus and 1 PP from the Charisma pool; −1 (−2 at 10+) circumstance to saves against your spells for Cha rounds (Q134)." },
  "Xithra Cone": { level: "B", what: "Xithra's prelude asks bolt or cone; the cone spends AP and the Focus use, basic Reflex vs the innate DC for each targeted creature (G25, Q136)." },
  "Xithra Recovery": { level: "A", what: "focusExtraUses on Xithra: two uses, both restored by Refocus." },
  "Xithra Spear": { level: "A", what: "Xithra's range written as 60 ft (and back on removal)." }
});

if (FEATS_B6_E.length !== 21) throw new Error(`Block 6 group E: ${FEATS_B6_E.length} feats, expected 21`);
