/**
 * Block 9c (0.15.0, on TRG Prime 3.690.0): Chapter 9's charged items — five
 * orbs, nine rods and five staves — as TRG Prime charged items (its
 * `chargedItem` flag), with an orb's and a staff's abilities in TRG Prime's
 * wondrous channel and as item conditionals. THE PRINTED TEXT IS THE BOOK'S,
 * read from tools/content/book-text.json (its orbs, rods and staves
 * sections); every level, price, PP, recharge, weight and spell list in
 * module/block9c-rules.mjs is checked against it here, so a figure that
 * disagrees with the book stops the build.
 */
import fs from "node:fs";
import { md } from "./markdown.mjs";
import { stableId, SYSTEM_ID, MODULE_ID } from "./builders.mjs";
import { ORBS_9C, RODS_9C, STAVES_9C } from "../../module/block9c-rules.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));

const STATS = Object.freeze({
  coreVersion: "14", systemId: SYSTEM_ID, systemVersion: "3.690.0",
  createdTime: 1785700000000, modifiedTime: 1785700000000, lastModifiedBy: null,
  compendiumSource: null, duplicateSource: null
});
const STAMP = "0.15.0, TRG Prime 3.690.0";
const num = (text) => Number(String(text ?? "").replace(/[^\d]/g, "")) || 0;

/** The entry's printed text, as the book has it. */
function printed(e) {
  const fields = Object.entries(e.fields).map(([k, v]) => `**${k}** ${v}`).join("; ");
  return [
    md(`**${e.name}** (${e.traits.join(", ")})`),
    fields ? md(fields) : "",
    e.flavour ? md(`*${e.flavour}*`) : "",
    md(e.lines.join("\n\n"))
  ].filter(Boolean).join("\n");
}

/** What the book's own lines print: PP, recharge and the spell list. */
function printedCharge(e) {
  const all = e.lines.join("\n");
  const pp = /\*\*Power Points\*\* (\d+)/.exec(all);
  const recharge = /\*\*Recharge\*\* (\d+) per day/.exec(all);
  const spells = /\*\*Spells\*\* \*([^*]+)\*/.exec(all);
  return {
    pp: pp ? Number(pp[1]) : null,
    recharge: recharge ? Number(recharge[1]) : null,
    spells: spells ? spells[1].split(/,\s*/).map((s) => { const m = /^(.*?)\s*\((\d+)\)$/.exec(s.trim()); return m ? { name: m[1].trim(), pp: Number(m[2]) } : null; }).filter(Boolean) : []
  };
}

function check(upper, spec, e, { pp, recharge }) {
  const got = printedCharge(e);
  const say = (what, book, rules) => { throw new Error(`Block 9c: ${upper} prints ${what} ${JSON.stringify(book)}, the rules ${JSON.stringify(rules)}`); };
  if (num(e.fields.Level) !== spec.level) say("level", e.fields.Level, spec.level);
  if (num(e.fields.Price) !== spec.price) say("price", e.fields.Price, spec.price);
  if (num(e.fields.Weight) !== spec.weight) say("weight", e.fields.Weight, spec.weight);
  if (got.pp !== pp) say("Power Points", got.pp, pp);
  if (got.recharge !== recharge) say("Recharge", got.recharge, recharge);
  const spells = (spec.spells ?? []).map((s) => `${s.name} ${s.pp}`);
  const book = got.spells.map((s) => `${s.name} ${s.pp}`);
  if (JSON.stringify(book) !== JSON.stringify(spells)) say("spells", book, spells);
}

function chargedItem(upper, spec, section, { kind, recharge }) {
  const e = BOOK.sections[section].find((x) => x.name === upper);
  if (!e) throw new Error(`Block 9c: no ${section} entry ${upper}`);
  const pp = spec.pp ?? 10;
  check(upper, spec, e, { pp, recharge });
  const description = [printed(e), spec.note ? md(`*Automated (${STAMP}):* ${spec.note}`) : ""].filter(Boolean).join("\n");
  const flags = {
    [SYSTEM_ID]: {
      chargedItem: {
        kind, maximumPP: pp, flexible: false, recharge: recharge ?? 0, printedRecharge: recharge ?? 0, printedPowerPoints: pp,
        correctedFromPrinted: false, spells: (spec.spells ?? []).map((s) => ({ name: s.name, pp: s.pp })),
        ...(spec.metamagic ? { metamagic: { ...spec.metamagic } } : {})
      },
      ...(spec.wondrous?.length ? { wondrous: { abilities: spec.wondrous.map((a) => ({ ...a })) } } : {}),
      ...(spec.conditionals?.length ? { conditionals: spec.conditionals.map((c) => ({ ...c, when: { ...c.when } })) } : {})
    },
    [MODULE_ID]: { charged9c: upper }
  };
  return {
    _id: stableId(`charged-items:${spec.name}`), name: spec.name,
    // TRG Prime's own charged items' icon (its Charged Items pack).
    img: "icons/svg/lightning.svg",
    type: "gear",
    system: {
      quantity: 1, weight: spec.weight, price: spec.price, equipped: false, invested: false,
      hp: { value: 0, max: 0 }, traits: spec.traits, description, slot: "", uses: pp,
      itemSize: "medium", itemLevel: spec.level, heldHands: 1, formulae: "", spellbookContainer: false
    },
    effects: [], folder: null, sort: 0, ownership: { default: 0 }, flags, _stats: { ...STATS }
  };
}

export const CHARGED_ITEMS_9C = [
  ...Object.entries(ORBS_9C).map(([upper, spec]) => chargedItem(upper, spec, "orbs", { kind: "orb", recharge: null })),
  ...Object.entries(RODS_9C).map(([upper, spec]) => chargedItem(upper, spec, "rods", { kind: "rod", recharge: 1 })),
  ...Object.entries(STAVES_9C).map(([upper, spec]) => chargedItem(upper, spec, "staves", { kind: "staff", recharge: spec.recharge }))
];
for (const section of ["orbs", "rods", "staves"]) {
  for (const e of BOOK.sections[section]) {
    if (!CHARGED_ITEMS_9C.some((d) => d.flags[MODULE_ID].charged9c === e.name)) throw new Error(`Block 9c: the book's ${e.name} is not in the rules`);
  }
}

export const BLOCK9C_PACKS = [
  { name: "ea-charged-items", label: "Eldritch Arts: Charged Items", extends: "charged-items", docs: CHARGED_ITEMS_9C }
];
