/**
 * Eldritch Arts — Block 4 (0.7.0): the Spellblade's five specialist spells
 * (its four path spells and Spinning Weapon) and the Warlock's Xithra.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.specialist`, `book.classes.warlock`), never retyped. Each description
 * is that text followed by one paragraph saying what TRG Prime does with it.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK4_AUDIT.md as Graham answered it on
 * 3 November 2026: Q36, Q37 (every Warlock spell innate and Focus), Q42
 * (Xithra's dice), Q47 (a path spell's Strike follows its casting check),
 * Q48 (Thunderous Strike: one roll, the Strike) and Q49 (Shooting Star's
 * trail). The Strikes, the trail, the shield, the hop and the spinning
 * weapon's rider are the module's work on the spell's settled cast
 * (module/block4-automations.mjs); the cards here say so.
 *
 * FLAGS: `eaSpellbladeSpell` (the module's own, under the system's scope)
 * names which of the five a spell is, for the automations.
 */
import fs from "node:fs";
import { spell } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { build } from "./block3-spells.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const BY_NAME = new Map(BOOK.specialist.map((e) => [e.name, e]));

const SPEC = {
  "SHOOTING STAR": {
    key: "shootingStar",
    // No range is printed; the Strike reaches as far as its weapon (or 30 ft). Blank read as
    // "self", and the core refused the cast whenever a creature was targeted (live test, 0.7.0).
    range: "see text",
    category: "utility",
    effects: [{ kind: "note", text: "On a Success or better, the Strike is made with your wielded weapon: at a creature within 30 feet with a melee weapon, ignoring concealment and stepping its cover down one degree. On a hit, your allies' attacks against that creature gain the same until the start of your next turn." }],
    level: "automated", what: "the Strike at 30 ft for a melee weapon, through concealment and one degree of cover; the trail for allies",
    text: "*Automated (0.7.0, TRG Prime 3.682.0):* cast it (2 AP); on a Success or better you are asked for the weapon and the target (your current target, if you have one), and the Strike is made as part of the spell, at no further AP (Q47). A melee weapon reaches any creature within 30 feet. The Strike ignores the target's concealment and steps its cover down a degree (greater → standard → lesser → none: its Take Cover, or the cover of firing into melee). If it hits, every ally of yours gains the same against that creature until the start of your next turn (Q49)."
  },
  "SHIELDING STRIKE": {
    key: "shieldingStrike",
    // No range is printed; the Strike reaches as far as its weapon (or 30 ft). Blank read as
    // "self", and the core refused the cast whenever a creature was targeted (live test, 0.7.0).
    range: "see text",
    category: "utility",
    effects: [{ kind: "note", text: "On a Success or better, a melee Strike is made as part of the spell, and you gain a +2 status bonus to DB until the start of your next turn (+1 per warp, max +5)." }],
    warpMods: [{ bonusValue: 1, bonusMax: 5 }],
    level: "automated", what: "the melee Strike, then +2 status DB until your next turn (+1 a warp, max +5)",
    text: "*Automated (0.7.0, TRG Prime 3.682.0):* cast it (2 AP); on a Success or better a melee Strike is made as part of the spell at no further AP (Q47), and you gain a +2 status bonus to DB until the start of your next turn, whatever the Strike does. Each +2 PP option adds +1, to +5."
  },
  "DIMENSIONAL ASSAULT": {
    key: "dimensionalAssault",
    category: "utility",
    effects: [{ kind: "note", text: "On a Success or better you click a square within half your land speed, teleport there, and make a 0 AP melee Strike against a creature in your reach. The Spatial Awareness check is rolled from its card after the attack." }],
    warpMods: [{ unlocks: ["eaSpatialAwareness5"] }],
    level: "automated", what: "the teleport within half your land speed, then a 0 AP melee Strike; +5 to Spatial Awareness with the warp",
    text: "*Automated (0.7.0, TRG Prime 3.682.0):* cast it (2 AP); on a Success or better you click where you teleport (any square within half your land speed), then make a 0 AP melee Strike at a creature within your reach (your current target, if it is). Teleportation's Spatial Awareness (Mental Focus) check is on its own card, to roll once the attack has been resolved. With the +1 PP option, that check has a +5 status bonus. *Not checked:* that the square you choose is within reach of a creature — the GM's eye."
  },
  "THUNDEROUS STRIKE": {
    key: "thunderousStrike",
    category: "save",
    defence: "basic Fortitude",
    targets: "each creature in a 15-foot cone behind the target",
    // NO RANGE IS PRINTED, and the cone reaches 15 ft past the Strike's target
    // (a bow's may be far away): "see text", which the core does not gate.
    // Left blank it read as "self", and the cone was refused (live test, 0.7.0).
    range: "see text",
    damage: { formula: "1d6", type: "sonic" },
    effects: [],
    warpMods: [{ damageDice: "1d6" }],
    level: "automated", what: "the Strike as the casting check; the cone behind the target saves against 1d6 sonic",
    text: "*Automated (0.7.0, TRG Prime 3.682.0):* press Cast and you are asked for the weapon and the target, and the Strike is made first. Its roll is also your casting check (Q48): the same die and modifiers, read against the casting DC. On a Success or better, each creature in a 15-foot cone (TRG Prime's 90°) behind the target, away from you, rolls a basic Fortitude save against 1d6 sonic damage, at your spell save DC; the target is not in it. Each +2 PP option adds 1d6 (the book's maximum is 5d6, four options: the cast does not stop you buying more)."
  },
  "SPINNING WEAPON": {
    key: "spinningWeapon",
    // No range is printed; the Strike reaches as far as its weapon (or 30 ft). Blank read as
    // "self", and the core refused the cast whenever a creature was targeted (live test, 0.7.0).
    range: "see text",
    category: "utility",
    effects: [{ kind: "note", text: "On a Success or better you choose acid, bludgeoning, cold, electricity or fire (force or sonic too, with the warp), and your next melee Strike this turn deals 1d6 secondary damage of it (+1d6 a warp, max 4d6)." }],
    warpMods: [{ damageDice: "1d6" }, { unlocks: ["eaForceSonic"] }],
    level: "automated", what: "the next melee Strike this turn: 1d6 secondary damage of a chosen type (warps: dice, force or sonic)",
    text: "*Automated (0.7.0, TRG Prime 3.682.0):* cast it (1 AP); on a Success or better you choose the damage type, and your next melee Strike before the end of your turn deals 1d6 secondary damage of that type (the core's strike rider, spent on that Strike, hit or miss). Each +2 PP dice option adds 1d6 (the book's maximum is 4d6); the other +2 PP option adds force and sonic to the choice."
  }
};

export const BLOCK4_SPECIALIST = Object.entries(SPEC).map(([name, spec]) => {
  const entry = BY_NAME.get(name);
  if (!entry) throw new Error(`Block 4: no specialist spell "${name}" in the book`);
  const doc = build(entry, spec, { specialist: true });
  doc.flags = { ...doc.flags, "trg-prime": { ...(doc.flags?.["trg-prime"] ?? {}), eaSpellbladeSpell: spec.key } };
  return doc;
});

/* ------------------------------------------------------------------ */
/* Xithra                                                               */
/* ------------------------------------------------------------------ */

const warlock = BOOK.classes.warlock.sections;
const XITHRA_SECTION = warlock.find((s) => s.name === "XITHRA");
if (!XITHRA_SECTION) throw new Error("Block 4: the Warlock has no XITHRA");

/**
 * "You release a bolt of psychic energy at a target you can see within 30
 * feet, inflicting 1d6 base mental damage. You add bonus damage equal to your
 * Cha. This attack is considered to be an innate spell for casting purposes.
 * At 4th level and then every 4 levels thereafter, you add an additional die."
 *
 * An innate attack spell (the core's innate attack, Charisma + level), Focus
 * (Q37): one use until Refocus. Its dice climb as a cantrip's do, by the
 * innate level (Q42). Its damage type is chosen at each use, mental or the
 * bonded soul's (the row is written when the soul is chosen).
 */
export const XITHRA = spell({
  name: "Xithra",
  description: [
    md(`**${XITHRA_SECTION.traits.join(" ")}**`),
    md(XITHRA_SECTION.lines.join("\n\n")),
    md("*Automated (0.7.0, TRG Prime 3.682.0):* an innate attack spell with the Focus trait, granted at 1st: your innate attack (Charisma + level) against the target's DB, 1d6 + Charisma mental damage, +1d6 at 4th and every 4 levels (Q42). One use, restored by Refocus or daily preparation (Q37). Once your bonded soul is chosen you pick, at each use, mental or the soul's damage type. Your soul's once-a-day power is offered after Xithra settles (Q41).")
  ].join("\n"),
  tradition: "",
  category: "attack",
  ppCost: 0,
  castAP: 1,
  range: "30 feet",
  targets: "1 creature you can see",
  traits: "Attack, Focus, Magical, Mental",
  innate: true,
  baseDamage: "1d6",
  damage: { formula: "1d6", type: "mental", persistent: "", addAbility: "charisma" },
  effects: [],
  components: { somatic: false, verbal: false, material: false, focus: false },
  flags: { eaXithra: true, castingAbilityOverride: "charisma" }
});
XITHRA.system.casterLevelMods = [{ threshold: 4, recurring: true, damageDice: "1d6", saveDC: 0, attack: 0, text: "At 4th level and then every 4 levels thereafter, an additional die." }];

/** What each does in TRG Prime, for the docs and the harness. */
export const SPELL_AUTOMATION_B4 = Object.freeze({
  ...Object.fromEntries(Object.entries(SPEC).map(([n, s]) => [BLOCK4_SPECIALIST.find((d) => d.flags["trg-prime"].eaSpellbladeSpell === s.key).name, Object.freeze({ level: s.level, what: s.what })])),
  Xithra: Object.freeze({ level: "automated", what: "an innate Focus attack: 1d6 + Cha mental (or the soul's type), +1d6 every 4 levels" })
});

if (BLOCK4_SPECIALIST.length !== 5) throw new Error(`Block 4: ${BLOCK4_SPECIALIST.length} specialist spells, expected 5`);
