/**
 * Eldritch Arts — Block 5, group C (0.8.0, on TRG Prime 3.683.0): the
 * nineteen SCAELYN racial feats (book v1.6, ea.md L2148–2862).
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix C, as Graham
 * answered it on 3 November 2026 (Q76–Q80 as proposed):
 *   Q76  Alchemical Purifier's two PP 6 spells carry `innatePPAllowance: 1`,
 *        so they can be cast from 5th level, when the feat is taken;
 *   Q77  Elemental Breath breathes the Wyrmdral heritage's own element
 *        (the heritage item's `eaElement`), with no separate pick;
 *   Q78  the Dustscale chain (Sandstrider, Desert Wraith) built as printed;
 *   Q79  Runic Aptitude's cantrip is chosen with its Use, kept until chosen
 *        again, and cast with Spellcraft (not innate);
 *   Q80  Glyph Unleashed covers area spells: any spell whose save you roll
 *        (the core's C2 check-reaction `modifiers` answer) or whose attack is
 *        against your DB (the C3 spell-only defence offer).
 *
 * Every card carries the book's text (from book-text.json, through
 * block5-common's `racialFeat`) and one paragraph saying exactly what TRG
 * Prime does with it. The Foundry side is module/block5c-automations.mjs.
 *
 * Block 1's Scaelyn heritages are read, never edited: Wyrmdral's element is
 * the heritage item's `flags.trg-prime.eaElement` (written by its Use).
 */
import { racialFeat } from "./block5-common.mjs";
import { changesEffect, racialSkillEffect, conditional } from "./builders.mjs";

/** The flag every module-owned automation on these items carries. */
const auto = (key, more = {}) => ({ eaAutomation: key, ...more });
const innate = (key) => auto(key, { grantInnate: true });

/** Ghostscale's light declaration: concealed at light level 5 (Dim) or lower. Restored by the module after a break. */
export const GHOSTSCALE_LIGHT = Object.freeze({ concealedAtOrBelow: 5 });

const immunities = (id, n) => changesEffect(id, `${n}: immunities`,
  [{ key: "system.combat.immunities", mode: 2, value: ", sleep, paralysis", priority: 20 }],
  "Immune to sleep and paralysis.");

export const FEATS_B5_C = [
  racialFeat("ALCHEMICAL PURIFIER", {
    grantedSpells: "Stinking Cloud, Neutralise Poison",
    flags: innate("alchemicalPurifier"),
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* Stinking Cloud and Neutralise Poison are added as innate spells with the Focus trait when the feat lands, each with its own Focus use (Refocus or daily preparation restores it). Both are PP 6, so each copy carries an innate allowance of one PP above your level (Graham's Q76): both can be cast from 5th level, when the feat is taken. **Use** puts that allowance back on the two copies if either has lost it. Both spells leave with the feat."
  }),
  racialFeat("ANCESTRAL AWAKENING", {
    flags: auto("ancestralAwakening"),
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* **Use** (0 AP, read as a free action on your turn) chooses acid, cold, electricity, fire or poison and spends the Focus use (Refocus or daily preparation restores it). For 1 minute you resist that element, and the save DC of every spell you cast with that element's trait is +1, named on the cast card. The +1 is untyped, so it adds to a Wyrmdral's own +1 on the same element; a resistance you already have adds nothing."
  }),
  racialFeat("CLAWS OF THE WYRM", {
    flags: auto("clawsOfTheWyrm"),
    automation: "*Automated (0.8.0):* when the feat lands you gain the system's natural claw for your size, from the companions compendium: Claws (Tiny) 1d4, Claws (Small) 1d5 or Claws (Medium) 1d6 slashing, Agile, Finesse, Versatile (P). A Scaelyn is Small, a Wyrmdral Medium. If your size changes, press **Use** to resize it. The claw leaves with the feat. The system has no claw for a creature larger than Medium; the card says so, and that claw is the GM's."
  }),
  racialFeat("DESERT WRAITH", {
    grantedSpells: "Pass Without Trace",
    flags: {
      ...innate("desertWraith"),
      conditionals: [
        conditional({ kind: "advantage", label: "Desert Wraith", scope: "Hide (Stealth) in natural terrain — tick if you are", auto: false, when: { checkTypes: ["skill"], actions: ["hide"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* Pass Without Trace is added as an innate spell with the Focus trait (PP 2), with its own Focus use; it leaves with the feat. Advantage is offered as a tick on Hide; tick it in natural terrain. Built as printed (Graham's Q78): advantage does not stack, so with the Dustscale's own advantage on the same Hide it adds nothing."
  }),
  racialFeat("DRACONIC IMMUNITY", {
    effects: [immunities],
    automation: "*Automated (0.8.0):* immunity to sleep (the Sleep trait: Sleep-trait spells and effects are refused) and to paralysis (the Paralyzed condition is refused)."
  }),
  racialFeat("DRACONIC WINGS", {
    flags: { creatureAbility: { derives: { movement: { key: "fly", orLand: true } } } },
    automation: "*Automated (0.8.0):* a fly Speed equal to your land Speed, recalculated whenever your land Speed changes. It never lowers a better fly Speed you already have."
  }),
  racialFeat("ELEMENTAL BREATH", {
    flags: auto("elementalBreath"),
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* **Use** (2 AP in combat; the Focus use, which Refocus or daily preparation restores). Target the creatures in your 20-foot line first: the line is yours to measure, and the creatures you target are the ones it reaches. Each takes 1d6 per character level of your element, with a basic Reflex save against your Level DC (none is printed; as the module's other breath and area abilities). The element is your Wyrmdral heritage's, chosen with the heritage's **Use**, with no separate pick (Graham's Q77). The breath is not a spell, so spell DC bonuses do not reach it."
  }),
  racialFeat("EMBER HANDED", {
    flags: {
      ...auto("emberHanded"),
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Ember Handed", scope: "Crafting related to alchemy or engineering — tick if this check is", auto: false, when: { checkTypes: ["skill"], subjects: ["crafting"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* the +2 racial is offered as a tick on Crafting checks; tick it when the check is for alchemy or engineering. Whenever fire damage reduces your HP, +1 (untyped; no type is printed) is put on your next attack roll or skill check before the end of your next turn, and spent by it. A second fire hit refreshes the +1; it does not stack. The harmless sparks are yours to describe: no rule of the system reads them."
  }),
  racialFeat("GHOSTSCALE", {
    flags: { ...auto("ghostscale"), creatureAbility: { derives: { light: { ...GHOSTSCALE_LIGHT } } } },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* while the ambient light where you stand is level 5 (Dim Light) or lower, attacks against you meet concealment, read at each attack as the system's Shadowy rule is. When you attack or cast a spell in that light, the concealment is broken until the start of your next turn (out of combat, after 6 seconds of world time), and a card says so. *Not automated:* Hide while observed. The system's Hide does not test whether you are observed, so nothing refuses it; that permission is the GM's to honour in Dim Light or darker."
  }),
  racialFeat("GLYPH UNLEASHED", {
    flags: auto("glyphUnleashed"),
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; Graham's Q80):* a reaction, with the Focus use (Refocus or daily preparation restores it). When a spell forces you to save, area spells included, you are asked (your player, else the GM) before the dice: the ward spends your reaction in combat and the Focus use, and gives +2 racial to that save. Until the start of your next turn every save you make against the same spell from the same caster takes the +2 with no question. When a spell attack is made against your DB you are offered the ward before the attack is rolled: +2 racial to your DB against that attack, and the same +2 to your saves against that spell from that caster until the start of your next turn. *Not automated:* a further attack roll of the same spell against you before your next turn is the GM's to adjust; the DB bonus lasts for the attack you reacted to."
  }),
  racialFeat("PYROTECHNIC FLAIR", {
    grantedSpells: "Burning Hands",
    flags: innate("pyrotechnicFlair"),
    automation: "*Automated (0.8.0):* Burning Hands is added as an innate spell with the Focus trait (PP 2), with its own Focus use (Refocus or daily preparation restores it). It leaves with the feat."
  }),
  racialFeat("RUNIC APTITUDE", {
    flags: {
      ...auto("runicAptitude"),
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Runic Aptitude", scope: "Analysing magical symbols — tick if this check is", auto: false, when: { checkTypes: ["skill"], actions: ["decipherWriting", "mysteriousScript", "identifyPower"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; Graham's Q79):* **Use** chooses one cantrip of any tradition, added as a spell you cast with a Spellcraft check (not innate); it is kept until you choose again, when the new pick replaces it. The +2 racial is offered as a tick on Decipher Writing, Mysterious Script and Identify Power; tick it when the check analyses magical symbols."
  }),
  racialFeat("SANDSTRIDER", {
    flags: { creatureAbility: { derives: { movement: { key: "burrow", orLand: true, landFraction: 0.5 } } } },
    automation: "*Automated (0.8.0; built as printed, Graham's Q78):* a burrow Speed of half your land Speed, rounded down to 5 feet. It grows with your land Speed and never lowers a better burrow Speed: at a 25-foot land Speed it is the Dustscale's own 10 feet."
  }),
  racialFeat("SCAELYN SCHOLAR", {
    flags: auto("wyrmLore"),
    effects: [(id, n) => racialSkillEffect(id, n, ["Arcana", "Crafting"], 1)],
    automation: "*Automated (0.8.0):* +1 racial to Arcana and Crafting. The +2 bonus is read as racial, as the core reads the same words on its Elven and Dwarven Scholar, and goes to Wyrm Lore, the Scaelyn's racial specialist skill, found by its label when the feat lands. If you have no Wyrm Lore yet, the card says so: add it, then press **Use**. Racial bonuses from different feats stack (with Wyrm's Cunning, Arcana +3 and Wyrm Lore +4)."
  }),
  racialFeat("SCALED FOCUS", {
    automation: "*Automated (0.8.0):* +1 Power Point per level, through TRG Prime's PP grant: trued up as you level, and returned if the feat is removed."
  }),
  racialFeat("SCALED TRICKSTER", {
    effects: [(id, n) => racialSkillEffect(id, n, ["Deception", "Thievery"], 2)],
    automation: "*Automated (0.8.0):* +2 racial to Deception and Thievery."
  }),
  racialFeat("SILENCE UNBOUND", {
    grantedSpells: "Silence",
    flags: innate("silenceUnbound"),
    automation: "*Automated (0.8.0):* Silence is added as an innate spell with the Focus trait (PP 4), with its own Focus use (Refocus or daily preparation restores it), at the core spell's own touch range (the Vel-tharis's \"self only\" is that heritage's, not this feat's). It leaves with the feat."
  }),
  racialFeat("SLUDGE BLOODED", {
    flags: {
      conditionals: [
        // ONE ROW FOR BOTH (an affliction that is both, a disease drunk, takes +2 once).
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Sludge Blooded", scope: "Saving throws against diseases and ingested poisons", auto: true, when: { checkTypes: ["save"], traits: ["disease", "ingested"] } }),
        conditional({ kind: "modifier", value: 2, type: "racial", label: "Sludge Blooded", scope: "Subsist in an urban or subterranean environment — tick if you are", auto: false, when: { checkTypes: ["skill"], actions: ["subsist"], subjects: ["culture", "survival"] } })
      ]
    },
    automation: "*Automated (0.8.0):* +2 racial on saving throws against an affliction with the Disease or Ingested trait, applied by itself (once, if it has both). The +2 racial to Subsist is offered as a tick when Subsist is made with Culture or Survival; tick it in an urban or subterranean environment. *Not automated:* spoiled food and stagnant water. The system models no spoilage, so there is nothing to lift."
  }),
  racialFeat("WYRM’S CUNNING", {
    flags: auto("wyrmLore"),
    effects: [(id, n) => racialSkillEffect(id, n, ["Arcana"], 2)],
    automation: "*Automated (0.8.0):* +2 racial to Arcana, and +2 racial to Wyrm Lore, the Scaelyn's racial specialist skill, found by its label when the feat lands. If you have no Wyrm Lore yet, the card says so: add it, then press **Use**. Racial bonuses from different feats stack (with Scaelyn Scholar, Arcana +3 and Wyrm Lore +4)."
  })
];

/**
 * For the docs. A full · B automated with a normal choice (a tick, a pick, a
 * target) · C partial · D descriptive. As the audit graded Appendix C (12 A, 7 B).
 */
export const AUTOMATION_B5_C = Object.freeze({
  "Alchemical Purifier": { level: "A", what: "Stinking Cloud and Neutralise Poison as innate Focus spells, castable from 5th level (innatePPAllowance 1, Q76)." },
  "Ancestral Awakening": { level: "B", what: "Use (0 AP, Focus): pick an element; 1 minute of resistance and +1 to that element's spell save DCs." },
  "Claws of the Wyrm": { level: "A", what: "The core's sized natural Claws from the companions pack, granted when the feat lands; Use resizes." },
  "Desert Wraith": { level: "B", what: "Pass Without Trace as an innate Focus spell; advantage offered as a tick on Hide (natural terrain)." },
  "Draconic Immunity": { level: "A", what: "Immunity to sleep and paralysis (the system's immunities field)." },
  "Draconic Wings": { level: "A", what: "A granted fly Speed equal to the land Speed." },
  "Elemental Breath": { level: "B", what: "Use (2 AP, Focus): the targeted creatures save (basic Reflex, Level DC) against 1d6/level of the Wyrmdral element (Q77)." },
  "Ember Handed": { level: "B", what: "+2 racial Crafting offered as a tick; fire damage taken puts a one-shot +1 on the next attack or skill check before the end of the next turn." },
  "Ghostscale": { level: "A", what: "Concealment at light level 5 or lower, broken by attacking or casting until the start of the next turn; Hide while observed is the GM's." },
  "Glyph Unleashed": { level: "B", what: "Reaction + Focus: +2 racial to saves against a spell (offered before the dice, areas included) and to DB against a spell attack (Q80)." },
  "Pyrotechnic Flair": { level: "A", what: "Burning Hands as an innate Focus spell." },
  "Runic Aptitude": { level: "B", what: "Use picks a Spellcraft cantrip of any tradition (Q79); +2 racial offered as a tick when analysing magical symbols." },
  "Sandstrider": { level: "A", what: "A granted burrow Speed of half the land Speed (Q78, as printed)." },
  "Scaelyn Scholar": { level: "A", what: "+1 racial Arcana and Crafting; +2 racial Wyrm Lore, found by label when the feat lands." },
  "Scaled Focus": { level: "A", what: "+1 PP per level (registerPPGrant)." },
  "Scaled Trickster": { level: "A", what: "+2 racial Deception and Thievery." },
  "Silence Unbound": { level: "A", what: "Silence as an innate Focus spell." },
  "Sludge Blooded": { level: "B", what: "+2 racial on saves against Disease or Ingested afflictions (automatic); +2 racial Subsist offered as a tick (urban or subterranean)." },
  "Wyrm’s Cunning": { level: "A", what: "+2 racial Arcana and Wyrm Lore (found by label)." }
});
