<!-- Source: "TRG Prime Eldritch Arts Feat Additions — Exact Format" (Graham, November 2026), converted with `pandoc -t gfm --wrap=none`. Cut verbatim; never retyped. tools/content/block11.mjs reads it at build time and the harness checks every card against it. -->

ADVANCED DESIGN

ARTIFICER CLASS

*Your devices are more advanced and more versatile.*

**Prerequisites** Crafting 8 ranks, Modular Design

When applying your bonus, you may apply either a +1 bonus to two items or a +2 bonus to a single item. Furthermore, once per day, you may spend 10 minutes swapping a single bonus to another item.

EMERGENCY CONTRAPTION

ARTIFICER CLASS PREPARED

*You excel at whipping up field tools from broken parts, duct tape, and sheer panic.*

**Prerequisites** Crafting 6 ranks

**Action** R; **Trigger** A trap is sprung or you or an ally fail a disable device check.

You produce a hasty gadget, granting the target (or yourself) a reroll on the triggering check with a +2 item bonus.

FLASH OF INSIGHT

ARTIFICER CHANCE CLASS

*You have a near-supernatural gift for spotting elegant solutions at the last possible moment.*

**Prerequisites** Crafting 14 ranks, Emergency Contraption

**Action** Free (0 AP); **Trigger** You or an ally that you are aware of within fails or fumbles a skill check or saving throw.

Once per day, you may declare a flash of insight. To do this you must describe an inventive way your tools, knowledge or the environment can help. The target treats their roll as a natural 20.

INSTABILITY HARNESS

ARTIFICER CHANCE CLASS

*You've fine-tuned your gear to sense arcane volatility and engineered a way to bleed off excess magical energy. What others fear as critical failure; you convert into opportunity—or at least manageable disaster.*

**Prerequisites** Crafting 12 ranks, Power Sink

**Action** R; **Trigger** You or an ally that you are aware of within 30 ft fails, fumbles or blunders a saving throw against a magical effect or suffers a Resonance Event.

You may use Power Sink in the event of a fumble or blunder.

INTEGRATED MODULARITY

ARTIFICER CLASS

*You’ve mastered the art of on-the-fly augmentation, incorporating socketed tuning arrays, magnetic slot-latches, and flexible glyph matrices into your tools and weapons. Your gear evolves as fast as the battlefield changes.*

**Prerequisites** Crafting 12 ranks, Modular Design

You can now reconfigure your modular upgrades in the field. You gain the Quick Swap ability.

Furthermore, you may also maintain any combination of +3 amongst your bonus.

QUICK SWAP

MANIPULATE PREPARED

**Action** 2 AP

You may transfer a Modular Design bonus from one item you are wielding or wearing to another eligible item you are currently wielding or wearing (e.g., swap +1 attack bonus from a crossbow to a sword, or from armour to a shield). The effect persists until your next daily prep or another swap.

MECHANISED ASSISTANT

ARTIFICER CLASS

*You’ve built an automaton to assist you with tasks both mundane and mystical.*

**Prerequisites** Crafting 4 ranks

You gain a Mechanised Assistant companion, a construct you personally built. This assistant is treated as a familiar unless noted otherwise below:

PROGRESSION

At 4th level and then every 4 levels thereafter, you may improve your assistant with one of the following familiar abilities: Ability Enhancement, Amphibious, Burrower, Climber, Evasion, Fast Movement, Flier, General Adeptness, Improved Evasion, Resilience, Speak with Master, Spell Battery, Tough.

Your assistant may also select from the following abilities instead: Reinforced Frame (DR +1); Storage (can carry up to 10 lbs of items and retrieve them as part of your command); Reactive Protocol (can use a Reaction once per round to Aid your checks).

IF DESTROYED

You may rebuild your assistant over the course of 8 hours of uninterrupted work. The GP cost is that of a mundane item (CRB 171).

MECHANISED ASSISTANT — COMPANION PROFILE

**Size** Small; Initiative +15

**Speed** 20

**Senses** Darkvision

**Abilities** Str 0, Dex 1, Con 1, Int 0, Wis 2, Cha -2

**Defence** DB 15 (BDB 10, Stat +3, Class +2); DR 2

**Skills** Crafting & Perception as class skills

Slam (Small) +1 (1d6 bludgeoning)

**Special** Cannot be healed by magical healing, but may be repaired with a Crafting check as any other construct.

Unlike a familiar, your assistant begins play with hands which allows it to carry out manual tasks for you.

SPECIALTIES

A mechanised assistant does not gain abilities in the same way as a familiar and instead begins play with one of the following specialties:

> • Tool Armature +2 item bonus to your Crafting checks while it is adjacent to you.
>
> • Injector Limb: Can deliver touch-range alchemical items or spells on your behalf.
>
> • Scout Optics: Gains an additional sense (scent, tremorsense etc) and also gains Tracking as a class skill.
>
> • Spell Relay Node: Can serve as the origin point for line- or area-based spell effects (must be within 60 ft and LOS).

MODULAR DESIGN

ARTIFICER CLASS

*Your devices and gear are designed with universal sockets, rail clamps, and expansion slots, allowing you to rapidly insert custom augmentations to push your tools beyond their normal limits.*

**Prerequisites** Crafting 4 ranks

Once per day during your daily preparation, you may apply a temporary modular upgrade to any one piece of armour, equipment or weapon. If the item is armour or a weapon, you must be proficient in its use. This upgrade grants a bonus to one of the following, depending on the item:

**Weapon** +1 item bonus to attack rolls or +1 to damage (choose one).

**Armour** +1 item bonus to DB or DR.

**Equipment** +1 item bonus to a skill check when using the tool.

The bonus lasts until your next daily preparation or until the item is broken or lost.

OVERCLOCKED WEAPONRY

ARTIFICER CLASS

*Through copper coils, runic relays, or volatile ether cores—you’ve upgraded your weapons for extra punch.*

**Prerequisites** Crafting 6 ranks, Weapon Focus

Choose one weapon you are proficient with and have crafted or modified. You can spend one minute overclocking it for one of the following effects:

Plasma Edge: +1d4 secondary elemental damage (choose acid, fire, or electricity)

Gyroscopic Repeater: Reduces reload AP by 1

Impact Amplifier: Increase the weapon’s base damage by 1

This effect lasts until your next daily preparation.

POWER SINK

ARTIFICER CHANCE CLASS PREPARED

*You’ve engineered a resonant stabilizer that draws arcane overloads away from you or your allies.*

**Prerequisites** Crafting 8 ranks, Use Magic Device

**Action** R; **Trigger** You or an ally that you are aware of within 30 ft fails a saving throw against a magical effect or suffers a Resonance Event.

You may redirect the effect to a magical item you are holding or wearing. That item becomes overloaded and cannot be used again until the end of your next turn. The target may reroll the failed check but must keep the second result (even if it is worse).

TINKERER PRECISION

ARTIFICER CLASS

*Fine-tuned machinery, micro-arcane lenses, and you at the workbench for 14 hours? Welcome to master-level invention.*

**Prerequisites** Crafting 10 ranks

You may treat your Crafting skill as 2 ranks higher when determining creation time. Furthermore, you reduce the raw materials cost used to determine how long the item takes by 25% (not the actual cost).

PREPARED — TRAIT

An ability with this trait can be replenished and used again if you take a 3 AP (manipulate) Crafting action (level based DC). Such an ability will recharge within ten minutes if the action is not taken.

GRAND INSCRIPTION

CLASS RUNEMAGE

*Your symbols are written with such authority that reality accepts them before the spell is finished.*

**Prerequisites** Linguistics 16 ranks, Combat Inscription, Living Script

When using the Symbol component, the +1 increase to your spell Save DC granted by the Runemage archetype increases to +2.

In addition, your +2-class bonus on checks made to identify runic symbols increases to +4. These increases replace, rather than stack with, the original Runemage bonuses.

RUNIC ANCHOR

CLASS RUNEMAGE

*Your script gives a spell something firmer than flesh to cling to.*

**Prerequisites** Linguistics 10 ranks

You gain a +2-class bonus to Spell Concentration checks made to retain, sustain or recover a spell that you cast using a Symbol component.

This bonus applies only to the spell whose casting used your Runemage Symbol; it does not apply to unrelated Concentration checks.

TRIGGERED SIGIL

CLASS RUNEMAGE

*The rune waits in silence until the exact instant for which it was written.*

**Prerequisites** Linguistics 12 ranks, Runic Reservoir

During your daily preparation, you may designate one of your Prepared Sigils as a Triggered Sigil and define a simple, observable trigger involving you, such as being struck, becoming the target of an attack, falling, or entering an area of fire.

The stored spell must have a normal casting time of 2 AP or less and must be capable of legally targeting you or the creature responsible for the trigger. When the trigger occurs, you may activate the sigil as a Reaction. You still expend the spell’s normal PP and must satisfy its normal range, line of sight, target and other requirements.

After activation the sigil fades normally. A Triggered Sigil that has not activated expires at your next daily preparation.

ARCANE PREPARATION

ASCENDAN CONCENTRATE

*You have learned that even the most complex magical workings become easier when their essential structure is understood before the first words are spoken.*

**Prerequisites** Level 5, Spellcraft 5 ranks

**Action** 1 AP

Choose an arcane or ethereal spell you know and intend to cast before the end of your next turn.

You gain a +2 circumstance bonus to your next Spellcraft check to cast that spell.

This preparation is lost if you cast a different spell, become unconscious or fail to cast the chosen spell before the end of your next turn.

You may benefit from Arcane Preparation only once per spellcasting attempt.

HERITAGE OF THE FIRST WEAVE

ASCENDAN FOCUS WARDING

*Your ancestry remembers the primal currents of magic, and your spirit can briefly shelter itself against powers that reject your bloodline.*

**Prerequisites** Level 10

**Action** Reaction

**Trigger** You attempt a saving throw against a divine or verdant magical effect.

You gain a +2 circumstance bonus to the triggering saving throw.

This does not remove your racial penalty against divine or verdant magic, nor does it allow you to cast spells from those traditions.

LEY RESONANCE

ASCENDAN FOCUS

*The currents of magic speak to you through subtle changes in temperature, colour and sensation, allowing you to draw upon focused ley energy.*

**Prerequisites** Arcana 2 ranks

Whenever you are within 60 foot of or linked to a ley line, you may reduce the casting cost of a spell by 1 PP (the casting DC is also affected).

This does not affect any associated Save DC.

PERFECTED ARCANE MEMORY

ASCENDAN

*Centuries of magical observation have taught you to recognise the signature of a spell long after its visible effects have disappeared.*

**Prerequisites** Level 15, Ley Resonance, Arcana 10 ranks

Your bonus from Ley Resonance increases to 2.

Furthermore, when examining the residual magical traces of an arcane or ethereal spell that ended within the previous 24 hours, you may attempt to identify the spell using Arcana or Occultism, even if the spell itself is no longer active.

Use the normal identification difficulty, increased by 5 because of the weakened traces.

On a success, you identify the spell and its magical tradition. On a critical success, you also determine approximately how long ago it was cast and the general direction of its point of origin, if those details can be established from the remaining traces.

This ability does not reveal the caster’s identity or reconstruct information that the magical residue does not contain.
