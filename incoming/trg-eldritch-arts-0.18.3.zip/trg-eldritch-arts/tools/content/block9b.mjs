/**
 * Block 9b (0.14.0, on TRG Prime 3.689.0): Chapter 9's 34 runes and 9
 * specific items. THE PRINTED TEXT IS THE BOOK'S, read from
 * tools/content/book-text.json (its armourRunes, weaponRunes, specificArmour
 * and specificWeapons sections, with each rune's sidebar tiers); the
 * automation note says what the module does with it (module/block9b-rules.mjs,
 * module/block9b-automations.mjs).
 *
 * A rune is browsed as one item per tier, as TRG Prime's own Runes pack holds
 * them ("Shadow III"): it is inscribed through the core's rune picker, which
 * knows it by name once `registerRunes` has it.
 */
import fs from "node:fs";
import { md } from "./markdown.mjs";
import { stableId, SYSTEM_ID, MODULE_ID } from "./builders.mjs";
import { RUNES_9B, SPECIFIC_9B, runeKey, runeName } from "../../module/block9b-rules.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));

const STATS = Object.freeze({
  coreVersion: "14", systemId: SYSTEM_ID, systemVersion: "3.689.0",
  createdTime: 1785600000000, modifiedTime: 1785600000000, lastModifiedBy: null,
  compendiumSource: null, duplicateSource: null
});
const STAMP = "0.14.0, TRG Prime 3.689.0";
const ROMAN = ["I", "II", "III", "IV", "V"];
const title = (s) => String(s).toLowerCase().replace(/(^|[\s-])([a-z])/g, (m, a, b) => a + b.toUpperCase());

const entryOf = (section, name) => {
  const e = BOOK.sections[section].find((x) => x.name === name);
  if (!e) throw new Error(`Block 9b: no ${section} entry ${name}`);
  return e;
};

/** The entry's printed text: traits, fields, flavour and lines, as the book has them. */
function printed(e) {
  const fields = Object.entries(e.fields).map(([k, v]) => `**${k}** ${v}`).join("; ");
  return [
    md(`**${e.name}** (${e.traits.join(", ")})`),
    fields ? md(fields) : "",
    e.flavour ? md(`*${e.flavour}*`) : "",
    md(e.lines.join("\n\n"))
  ].filter(Boolean).join("\n");
}

/* ------------------------------------------------------------------ */
/* Runes                                                                */
/* ------------------------------------------------------------------ */

function runeItems(upper, section) {
  const spec = RUNES_9B[upper];
  const e = entryOf(section, upper);
  const name = runeName(upper);
  const key = runeKey(name);
  const tiers = spec.tiers ?? [{ level: spec.level, price: spec.price ?? spec.armourPrice }];
  if (spec.tiers && (e.tiers ?? []).length !== spec.tiers.length) throw new Error(`Block 9b: ${upper} has ${e.tiers?.length} printed tiers, the rules ${spec.tiers.length}`);
  return tiers.map((t, i) => {
    const tierName = spec.tiers ? `${name} ${ROMAN[i]}` : name;
    const box = spec.tiers ? e.tiers[i] : null;
    if (box && (box.level !== t.level)) throw new Error(`Block 9b: ${tierName} prints level ${box.level}, the rules ${t.level}`);
    const lines = [
      printed(e),
      box ? md(`**${box.name}** — Level ${box.level}; ${/\//.test(box.price) ? "Armour/Shield " : ""}Price ${box.price}. ${box.text}`) : "",
      md(`*Automated (${STAMP})${spec.grade === "C" ? " — in part" : ""}:* ${spec.note}`)
    ].filter(Boolean).join("\n");
    return {
      _id: stableId(`runes:${tierName}`),
      name: tierName,
      img: "icons/svg/book.svg",
      type: "gear",
      system: {
        quantity: 1, weight: 0, price: t.price, equipped: false, invested: false,
        hp: { value: 0, max: 0 },
        traits: spec.traits,
        slot: "", uses: 0, itemSize: "medium", itemLevel: t.level, heldHands: 0, formulae: "", spellbookContainer: false,
        description: lines
      },
      effects: [], folder: null, sort: 0, ownership: { default: 0 },
      flags: { [SYSTEM_ID]: { rune: { key, tier: spec.tiers ? i + 1 : 1, on: [...spec.on], automation: "declared" } }, [MODULE_ID]: { rune9b: key } },
      _stats: { ...STATS }
    };
  });
}

const ARMOUR_RUNE_NAMES = BOOK.sections.armourRunes.map((e) => e.name);
const WEAPON_RUNE_NAMES = BOOK.sections.weaponRunes.map((e) => e.name);
for (const n of [...ARMOUR_RUNE_NAMES, ...WEAPON_RUNE_NAMES]) if (!RUNES_9B[n]) throw new Error(`Block 9b: no rules for the rune ${n}`);
if (Object.keys(RUNES_9B).length !== ARMOUR_RUNE_NAMES.length + WEAPON_RUNE_NAMES.length) throw new Error("Block 9b: the rules hold a rune the book does not");

export const RUNE_ITEMS_9B = [
  ...ARMOUR_RUNE_NAMES.flatMap((n) => runeItems(n, "armourRunes")),
  ...WEAPON_RUNE_NAMES.flatMap((n) => runeItems(n, "weaponRunes"))
];

/* ------------------------------------------------------------------ */
/* Specific items                                                       */
/* ------------------------------------------------------------------ */

/** The core items they are made from: the fields a specific item keeps. */
const BASES = Object.freeze({
  "Chain Shirt": { category: "Medium", coversTorso: true, coversArms: false, coversLegs: false, isHelmet: false, speedPenalty: 0 },
  "Reinforced Leather Breastplate": { category: "Light", coversTorso: true, coversArms: false, coversLegs: false, isHelmet: false, speedPenalty: 0 },
  "Full Leather": { category: "Light", coversTorso: true, coversArms: true, coversLegs: true, isHelmet: false, speedPenalty: 0 },
  Scalemail: { category: "Medium", coversTorso: true, coversArms: true, coversLegs: true, isHelmet: false, speedPenalty: 0 },
  "Light Steel Shield": { category: "light", metal: true, shieldBashDamage: "1d4", shieldBashFumbleDC: 6, shieldBashDamageType: "bludgeoning", defenceBonus: 1, brokenThreshold: 0 },
  "Battle Axe": { group: "Axe", category: "Martial", size: "medium", hands: 1, attackMode: "melee" },
  Bardiche: { group: "Polearm", category: "Martial", size: "large", hands: 1, attackMode: "melee" },
  Dagger: { group: "Knife", category: "Simple", size: "tiny", hands: 1, attackMode: "melee" },
  "Tel'dorin": { group: "Sword", category: "Exotic", size: "large", hands: 1, attackMode: "melee" }
});

/** A runes field's parts, as TRG Prime's specific items record them. */
function runeParts(field) {
  return field.split(/,\s*(?![^()]*\))/).map((p) => p.trim()).filter(Boolean).map((p) => {
    const m = /^(.*?)(?:\s+([IVX]+))?(?:\s*\(.*\))?$/.exec(p);
    const label = m[1].trim();
    const tier = m[2] ? ROMAN.indexOf(m[2]) + 1 : 1;
    const key = label === "Potency" ? "potency" : label === "Shadow" ? "shadow" : /^Spell Effect/.test(label) ? "spellEffect" : runeKey(label);
    return { key, label, tier, printed: p };
  });
}

function specificItem(upper, section) {
  const spec = SPECIFIC_9B[upper];
  const e = entryOf(section, upper);
  const name = spec.name ?? title(upper);
  const base = BASES[spec.base];
  if (!base) throw new Error(`Block 9b: no base ${spec.base}`);
  if (Number(String(e.fields.Level).replace(/\D/g, "")) !== spec.level && upper !== "RITUALISTS EDGE") throw new Error(`Block 9b: ${upper} prints level ${e.fields.Level}`);
  if (Number(String(e.fields.Price).replace(/[^\d]/g, "")) !== spec.price) throw new Error(`Block 9b: ${upper} prints price ${e.fields.Price}`);
  const s = spec.stats;
  const traits = spec.printedTraits.join(", ");
  const description = [printed(e), md(`*Automated (${STAMP}):* ${spec.note}`)].join("\n");
  const flags = {
    [SYSTEM_ID]: {
      specificItem: {
        runes: runeParts(spec.runes), runeText: spec.runes, traits: [...spec.printedTraits],
        quality: spec.quality, material: spec.material, printedItemBonus: Math.max(...runeParts(spec.runes).filter((r) => r.key === "potency").map((r) => r.tier), 0)
      },
      ...(spec.perception ? { conditionals: [{ kind: "modifier", value: spec.perception, type: "item", label: `${name} (printed)`, scope: "Perception, while worn", when: { checkTypes: ["skill"], subjects: ["perception"] }, auto: true }] } : {})
    },
    [MODULE_ID]: { specific9b: upper }
  };
  let system;
  if (spec.type === "armour") {
    system = {
      quantity: 1, weight: spec.weight, price: spec.price, equipped: false, invested: false,
      hp: { value: s.hp, max: s.hp }, traits, ...base, material: spec.material, dr: s.dr, hardness: 0, penalty: s.penalty,
      proficiency: "", maxDexBonus: s.maxDexBonus, itemLevel: spec.level, quality: spec.quality, superiorTraits: "", runes: spec.runes, description
    };
  } else if (spec.type === "shield") {
    system = {
      quantity: 1, weight: spec.weight, price: spec.price, equipped: false, invested: false,
      hp: { value: s.hp, max: s.hp }, traits, ...base, dr: s.dr, hardness: 0, proficiency: "", penalty: s.penalty,
      itemLevel: spec.level, quality: spec.quality, material: spec.material, superiorTraits: "", runes: spec.runes, description
    };
  } else {
    system = {
      quantity: 1, weight: spec.weight, price: spec.price, equipped: false, invested: false,
      hp: { value: 0, max: 0 }, traits: spec.printedTraits.filter((t) => !/^(Expert|Master|Potency|Aetherfang|Essencebreaker|Sanguine|Summoner|Chrono)/.test(t)).join(", "),
      attackBonus: 0, damage: s.damage, damageType: s.damageType, baseDamage: s.damage, damageTypeOverride: "", ...base,
      twoHandedGrip: false, range: 0, armourRending: 0, proficiency: "", fumbleDC: s.fumbleDC, rangeIncrement: 0,
      itemLevel: spec.level, quality: spec.quality, material: spec.material, superiorTraits: "", runes: spec.runes,
      loaded: false, magazine: 0, reloadProgress: 0, usedQuickLoadThisRound: false, spinBonus: 0, attackedThisTurn: false, natural: false, description
    };
  }
  return {
    _id: stableId(`specific-items:${name}`), name, img: spec.type === "weapon" ? "icons/svg/sword.svg" : spec.type === "shield" ? "icons/svg/shield.svg" : "icons/svg/statue.svg",
    type: spec.type, system, effects: [], folder: null, sort: 0, ownership: { default: 0 }, flags, _stats: { ...STATS }
  };
}

export const SPECIFIC_ITEMS_9B = [
  ...BOOK.sections.specificArmour.map((e) => specificItem(e.name, "specificArmour")),
  ...BOOK.sections.specificWeapons.map((e) => specificItem(e.name, "specificWeapons"))
];
if (SPECIFIC_ITEMS_9B.length !== Object.keys(SPECIFIC_9B).length) throw new Error("Block 9b: a specific item in the rules is not in the book");

export const BLOCK9B_PACKS = [
  { name: "ea-runes", label: "Eldritch Arts: Runes", extends: "runes", docs: RUNE_ITEMS_9B },
  { name: "ea-specific-items", label: "Eldritch Arts: Specific Items", extends: "specific-items", docs: SPECIFIC_ITEMS_9B }
];
