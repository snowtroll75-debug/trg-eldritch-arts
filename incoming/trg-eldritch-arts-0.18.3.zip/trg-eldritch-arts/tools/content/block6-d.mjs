/**
 * Eldritch Arts — Block 6 (0.9.0), group D: Chapter 5's metamagic and Adept
 * class feats (Appendix D of docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md), on TRG
 * Prime 3.684.0's seams G1 (module metamagic), G5 (fumble modifiers), G6
 * (charged-item rules), G7 (the 0 HP moment), G9 (compound prerequisites,
 * eligibility) and G25 (the weapon on a check reaction, declared cantrips).
 *
 * Graham answered the audit on 4 November 2026: "proposed except Q89: One
 * release". The rulings this file builds on: Q94 (which casts take module
 * metamagic: learned and innate; charged items only through Metamagic
 * Conduit; never scrolls, potions, stored spells or cantrips), Q95 (an innate
 * cast's metamagic is paid from the PP pool and raises no Casting DC), Q96
 * (a Focus metamagic's use is spent when the cast pays its PP), Q126–Q133.
 *
 * Group D also owns the metamagic of the five feats Block 5 and Block 1
 * deferred (Echo of the Ancestors, Resonant Pulse, Resonant Harmony, Spell
 * Surge, Piercing Insight). Their items stay in their own files; their
 * options are registered by module/block6d-automations.mjs.
 *
 * Every feat is built with block6-common.mjs's `classFeat`, so its card is the
 * book's text followed by one paragraph saying what TRG Prime does with it.
 * The rules are module/block6d-automations.mjs.
 */
import { classFeat } from "./block6-common.mjs";

const AUTO = "*Automated (0.9.0, TRG Prime 3.684.0):*";
const PART = "*Partly automated (0.9.0, TRG Prime 3.684.0):*";
const AUTO8A = "*Automated (0.11.0, TRG Prime 3.686.0):*";
const WARP = "an option in the spell's own **Warp?** dialog";

export const FEATS_B6_D = [
  classFeat("ARCANE FENCER", {
    flags: { eaAutomation: "arcaneFencer" },
    automation: `${AUTO} when you make a melee Strike with a one-handed weapon (not one with the Two-Handed trait, and not one held in two hands), you are asked before the dice how many PP to burn: 0 up to your caster level, and no more than your pool holds. Each PP is +1 status to that Strike's attack, so it does not stack with another status bonus to attack. The PP are spent hit or miss. A free action: no AP and no reaction. It modifies a Strike, so it is never offered in a spell's Warp? dialog. Weapon Focus and BAB +2 are checked by the feat picker.`
  }),
  classFeat("CONDUIT MASTERY", {
    flags: { eaAutomation: "conduitMastery" },
    automation: `${AUTO} you may wield three charged items (the sheet's warning reads three). Every activation of a charged item — Cast from Item, a rod's own power, a metamagic rod's spend — costs the item 1 PP less, never below 1 and never more than was due; applied by itself, as it is always to your benefit. Drawing your own spell's PP from a PP-source rod (Rod of the Magi) is not an activation and is not reduced.`
  }),
  classFeat("DUAL CHANNEL", {
    flags: { eaAutomation: "dualChannel" },
    automation: `${AUTO} you may wield two charged items (the sheet's warning reads two), each activated separately. When a Cast from Item release check comes out a Fumble or a Blunder, every charged item you wield loses 1 more PP once the item's own spend is written; another wielded item taken below 0 rolls Charge Depletion, as the core does; the released item's own depletion stays the core's, so it is never rolled twice (when its own spend left it exactly empty, the card leaves that roll to the GM).`
  }),
  classFeat("EXTRA CANTRIP", {
    repeatable: true,
    flags: { eaAutomation: "extraCantrip", cantripBonus: 1 },
    automation: `${AUTO} each copy raises your cantrip allowance by one (G25): a caster who memorises cantrips memorises one more each day, and a class that learns a set of cantrips picks one more in its cantrip panel. A class with neither pool uses **Use**: choose one PP 0 spell of your class's tradition, kept as yours and cast with your Spellcraft (Using it again replaces it). "No more than once every four levels": the Use refuses a copy beyond one for every four levels you have, and says why; the feat picker does not gate the spacing.`
  }),
  classFeat("FOCUSED SPELL", {
    flags: { eaAutomation: "focusedSpell" },
    automation: `${AUTO} ${WARP}: **+3 PP**, advantage on the Spellcraft check (a spell attack's check is its attack, so the one roll has advantage). Its PP raise the Casting DC, count against your maximum PP per cast and are refunded by degree, as any metamagic's. Not offered on a cast that rolls no Spellcraft check (an innate or a charged item's spell) nor on a cantrip (Q94). The Rods of Focused Spell are Block 9.`
  }),
  classFeat("LIGHTNING ROD", {
    flags: { eaAutomation: "lightningRod", compoundSkillPrerequisites: true },
    automation: `${AUTO} ${WARP} on a spell that deals electricity damage (its own type or Elemental Spell's): **+2 PP**. On Elemental Spell's electricity, tick Elemental Spell with it: taken without it, the cast goes on, the card says nothing is marked, and its 2 PP are still paid. Once the cast has gone off you choose one creature it hit (a spell attack's hit, or a creature that saved against it and took the electricity), which is **marked** until the end of your next turn; one mark at a time, a new one replacing the old. The next time you cast a spell with the electricity trait before then, as it settles every enemy within 10 feet of the marked creature (not the creature itself) takes half that spell's damage dice, rounded down, as electricity damage with no save (Q127); the mark then ends. While marked, the creature takes −2 on its save against a spell with the electricity trait: applied by itself when it wears metal armour, offered as a tick when it only holds metal (the GM's). "Arcana or Survival 10 ranks" is read by the feat picker (G9).`
  }),
  classFeat("MANA BOUND", {
    flags: { eaAutomation: "manaBound" },
    automation: `${AUTO} after a Fumble on a Spellcraft check — a cast's, a ritual's, or a charged item released by Spellcraft — your Spell Fumble roll takes −20 circumstance (G5). Never on a Blunder, on a release by a tradition skill, on a concentration fumble, or on a Resonance (Chaos) roll.`
  }),
  classFeat("METAMAGIC CONDUIT", {
    flags: { eaAutomation: "metamagicConduit" },
    automation: `${AUTO} a spell you cast from a charged item (Cast from Item) opens its Warp? dialog to your Eldritch Arts metamagic options (G6). The item pays what it releases the spell at; the metamagic's PP come from your own pool. The total may not exceed double the PP the item releases that spell at (Q130); a heavier choice is refused, not trimmed. The release check is rolled at the item's PP, before the dialog. The core's own metamagic table is not offered on an item's spell (a core limit), nor is anything on a scroll or potion (Q94). "At least any one metamagic feat" is checked when the feat is taken.`
  }),
  classFeat("PACT CHANNELER", {
    flags: { eaAutomation: "pactChanneler" },
    automation: `${AUTO} ${WARP} while you own a Pact archetype: **+1 PP**, your patron's channel, read from the archetype — Angelic: the Healing trait, and +2d6 to a spell that heals; Demonic: the Fire trait, and +2d6 fire on each creature a damaging spell damages; Draconic and Elemental: your chosen type's trait (Elemental: the element's), and +2d6 to that damage type's pool; Fey: the Enchantment trait, and Save DC +1 on a Will save (−1 to the target's save); Grave: the Essence trait, and +2d6 essence on each creature a damaging spell damages; Void: the Mental trait, and once the cast has gone off each target makes a Will save against your spell's save DC (the cast's own) — Failure or worse, Flat-Footed until the start of your next turn. From 14th level the dice are 4d6 and Fey's −2. The added trait reaches the check and the cast's hooks, not the saves (a core limit). A Warlock's spells are innate: the 1 PP is paid from the PP pool and raises no Casting DC (Q95). Draconic and Elemental are offered once the archetype's type is chosen. "Pact Archetype feat" is checked when the feat is taken; one Pact ever (Q92).`
  }),
  classFeat("SENSORY SPELL", {
    flags: { eaAutomation: "sensorySpell" },
    automation: `${AUTO} ${WARP}: **+1 PP**. The visual, auditory, olfactory or ambient change is yours to describe, and has no mechanical effect. Once the cast has gone off, your next Deception, Intimidate or Perform check before the end of your turn has +2, applied by itself and then spent.`
  }),
  classFeat("SPELLTHREAD", {
    flags: { eaAutomation: "spellthread" },
    automation: `${PART} ${WARP} on the first spell: **+2 PP**, and choose the spell woven into it — one you can cast now, of the same tradition, not a cantrip. Its base PP join the first spell's base, so the one casting check is rolled at the Casting DC of the total and the total counts against your maximum PP per cast (Q126); the casting time is the longer of the two. Sidebar 15 applies: a Heroic saves only half the base PP and a Critical saves none; a Partial is treated as a Failure and a Failure as a Fumble; that casting's Spell Fumble and Resonance rolls have disadvantage. On a Success or better the woven spell resolves straight after the first, under the same check and degree, at the targets already chosen, paying nothing more. You choose the order by casting first the spell you want resolved first. A reaction that stops the casting stops both. *Not automated:* the woven spell's own warps (it resolves as printed: add them by hand), and the one concentration check for both sustained spells (the GM's).`
  }),
  classFeat("SPELLTHREAD MASTERY", {
    flags: { eaAutomation: "spellthreadMastery" },
    automation: `${PART} Spellthread's option lets you weave a third spell into the casting, by the same rules: each woven spell's base PP join the total, which still costs +2 once, and each resolves in turn after the first on a Success or better. What Spellthread leaves to the GM is the GM's here too.`
  }),
  classFeat("SPELLTHREAD UNBOUND", {
    flags: { eaAutomation: "spellthreadUnbound" },
    automation: `${PART} Spellthread's option offers spells of any tradition to weave, not only the first spell's. What Spellthread leaves to the GM is the GM's here too.`
  }),
  classFeat("STEELBINDING", {
    flags: { eaAutomation: "steelbinding" },
    automation: `${AUTO} ${WARP}, offered when one of the creatures you target is within 30 feet and wears metal armour (equipped armour with the Metal trait, as the core tests it): **+2 PP**. Once the cast has gone off, that creature (you choose, if several) makes a Fortitude save against your spell's save DC (the one the cast's own saves used): Heroic or Critical, no effect; Success, Slowed 1 until the end of its next turn; Partial, Failure or Fumble, Immobilised until the end of your next turn; Blunder, Immobilised and it drops one held metal weapon of your choice (you are asked which; it is unequipped). The durations are the core's reading of "until the end of the next turn". The book's "Requirements" clause, lost in extraction, is restored on this card (m45).`
  }),
  classFeat("SUBCONSCIOUS CASTING", {
    flags: { eaAutomation: "subconsciousCasting" },
    automation: `${AUTO} when damage, lethal or subdual, would take you to 0 HP (not a blow that kills outright, nor sleep or another condition; Q128) and this feat's Focus use is ready, you are asked — your player, else the GM. Yes: choose a prepared or known spell you can cast now, of 1 AP, with the Self or Touch range; it is cast at once as a 0 AP action with **+6 PP**, its normal check, Casting DC and costs. The Focus use is spent when the cast pays its PP (Q96). If the spell leaves you above 0 HP you do not fall unconscious and do not gain Dying (G7); otherwise you fall as normal.`
  }),
  classFeat("THUNDERCLAP AURA", {
    flags: { eaAutomation: "thunderclapAura" },
    automation: `${AUTO} ${WARP} on a spell with the Air or Electricity trait: **+2 PP**. When the cast succeeds (Success or better), every creature within 10 feet of you — allies included, you excepted — takes 1d6 electricity damage for every 2 PP the cast cost in all (base, warps and metamagic, this feat's +2 included; Q129), a basic Fortitude save against your spell's save DC (the one the cast's own saves used).`
  }),
  classFeat("UNFETTERED MASTERY", {
    flags: { eaAutomation: "unfetteredMastery" },
    automation: `${AUTO} ${WARP} on a High Magic cast of 2 AP or more: **0 PP**, the spell takes 1 AP less to cast, as Quicken Spell (EA-R4: as printed, free). It is a Quicken, so it never stacks with Quicken Spell or a Quicken rod. Not a Flourish. A Focus feat: one use, spent when the cast pays its PP (Q96), restored by Refocus or daily preparation.`
  }),
  classFeat("VERSATILE BINDER", {
    flags: { eaAutomation: "versatileBinder" },
    automation: `${AUTO8A} ${WARP} on a spell with the Summons trait (the eight Bindings): **+1 PP**, and choose a creature already in the world, within the spell's range, in place of a new summons. Once the cast has gone off the binding's own card binds it (Q133, Q184): the binding's own trait, level and range checks, then the binding's Will save against your spell's save DC, the cast's own, with a circle's and a true name's bonuses in. On a Failure or worse it is bound as the summoned creature would be: recorded against your Control Levels (TRG Prime 3.686.0), loyal on a Fumble, broken by the DC 20 Will release, and released where it stands when the spell ends, not sent anywhere. *By hand:* commanding it, as for any bound creature. A Summons spell from outside Eldritch Arts (no core spell has the trait) still rolls its own save on the card, and its control is the GM's. The prerequisite is not read and passes.`
  }),
  classFeat("WEAVE INFUSION", {
    flags: { eaAutomation: "weaveInfusion" },
    automation: `${AUTO} Cast from Item offers a tick, "pay from your own PP": ticked, the degree's price leaves your own pool and the item is untouched. An item with no PP left may be used so; then Charge Depletion is rolled once the spell has been cast, with disadvantage — two d100, the lower kept, because low is worse on that table (Q131).`
  }),
  classFeat("RESONANT CONDUIT", {
    flags: { eaAutomation: "resonantConduit" },
    automation: `${AUTO} while you wield two or more charged items, the first activation you make each day (Cast from Item, a rod's power) costs the item nothing; the day's free activation is spent then and returns at daily preparation. Drawing your own spell's PP from a PP-source rod is not an activation.`
  })
];

/** The book's order is not kept: the docs' table and the harness read the names. */
export const FEAT_NAMES_B6_D = Object.freeze(FEATS_B6_D.map((f) => f.name));

/** For the docs: each feat's level (A full · B with a normal choice · C partial · D descriptive) and what is automated. */
export const AUTOMATION_B6_D = Object.freeze({
  "Arcane Fencer": { level: "B", what: "Check reaction before a one-handed melee Strike (G25 weapon on the ctx): burn 0…min(caster level, pool) PP for +1 status attack each." },
  "Conduit Mastery": { level: "A", what: "Charged-item rule (G6): wield limit 3; every activation −1 PP (minimum 1), not a Rod of the Magi draw." },
  "Dual Channel": { level: "A", what: "Charged-item rule (G6): wield limit 2; a Fumble or Blunder release costs every wielded charged item 1 more PP (Charge Depletion below 0, never rolled twice for the released item)." },
  "Extra Cantrip": { level: "B", what: "Declared cantripBonus 1 per copy (G25) on the memorised or known allowance; Use picks a PP 0 spell of the tradition for a class with neither; the once-every-four-levels limit checked by the Use." },
  "Focused Spell": { level: "B", what: "Module metamagic (G1): +3 PP, advantage on the casting check; learned casts only." },
  "Lightning Rod": { level: "B", what: "Module metamagic (G1): +2 PP on an electricity spell; after: mark a creature hit (to the end of your next turn); next electricity-trait cast splashes enemies within 10 ft for half the dice, no save (Q127); −2 save row on the mark (auto in metal armour, tick otherwise); G9 compound prerequisite." },
  "Mana Bound": { level: "A", what: "Fumble modifier (G5): −20 when not a Blunder and the check is Spellcraft." },
  "Metamagic Conduit": { level: "B", what: "Charged-item rule (G6) metamagic: an item cast offers the module's metamagic, the wielder paying it, ceiling double the release PP (Q130); eligibility: owns a metamagic feat (G9)." },
  "Pact Channeler": { level: "B", what: "Module metamagic (G1): +1 PP, the patron's channel (traits, +2d6/4d6 healing or typed damage, Fey Save DC +1/+2, Void's Will save → Flat-Footed); innate casts paid from the pool (Q95); eligibility: a Pact archetype (G9)." },
  "Sensory Spell": { level: "B", what: "Module metamagic (G1): +1 PP; after a cast that went off, a one-shot +2 on the next Deception, Intimidate or Perform check this turn." },
  "Spellthread": { level: "C", what: "Module metamagic (G1): +2 PP, a woven spell's base PP joined (basePPAdd), longer casting time, savingStep 1, Partial→Failure and Failure→Fumble remap, fumble/Resonance disadvantage; the woven spell resolved by castSpell's thread on Success+. Its warps and the shared concentration are the GM's." },
  "Spellthread Mastery": { level: "C", what: "Spellthread's picker takes a third spell." },
  "Spellthread Unbound": { level: "C", what: "Spellthread's picker offers any tradition." },
  "Steelbinding": { level: "B", what: "Module metamagic (G1): +2 PP when a target within 30 ft wears metal armour; after a cast that went off, its Fortitude save vs the cast's own Save DC (the settled facts' saveDC): Slowed 1 / Immobilised / Immobilised and a held metal weapon dropped." },
  "Subconscious Casting": { level: "B", what: "Unconscious offer (G7): at 0 HP, a 1 AP Self/Touch prepared or known spell cast at 0 AP with the preset +6 PP option (G1 preset); Focus spent when the PP are paid; HP re-read." },
  "Thunderclap Aura": { level: "B", what: "Module metamagic (G1): +2 PP on an Air/Electricity spell; on Success+, ⌊total PP / 2⌋d6 electricity to every creature within 10 ft but you, basic Fortitude vs the cast's Save DC (Q129)." },
  "Unfettered Mastery": { level: "B", what: "Module metamagic (G1) of kind quicken: 0 PP, 1 AP less on a High Magic cast of 2+ AP; Focus." },
  "Versatile Binder": { level: "B", what: "Module metamagic (G1): +1 PP on a Summons spell, an existing creature chosen; on an Eldritch Arts Binding it is bound by the binding's own checks and save, on the control register (0.11.0, Q184); the command by hand." },
  "Weave Infusion": { level: "B", what: "Charged-item rule (G6) payment: a tick on Cast from Item to pay from your own PP; an empty item allowed, then Charge Depletion with disadvantage (lower d100, Q131)." },
  "Resonant Conduit": { level: "A", what: "Charged-item rule (G6) cost: free while 2+ charged items are wielded and the day's stamp is unset; stamped on release; cleared at daily preparation." }
});

/**
 * THE FIVE FEATS DEFERRED TO HERE (items in their own files; their options are
 * registered by block6d-automations.mjs). For the docs: their 0.9.0 levels.
 */
export const DEFERRED_B6_D = Object.freeze({
  "Echo of the Ancestors": { file: "tools/content/block5-b.mjs", level: "B", what: "Module metamagic (G1): +2 PP, Focus, on the heritage's element; a second creature at half damage (targets.extra, Q75)." },
  "Resonant Pulse": { file: "tools/content/block5-a.mjs", level: "B", what: "Module metamagic (G1): 0 PP, Focus, Save DC +1 on a spell with a save; learned and innate casts (Q94)." },
  "Resonant Harmony": { file: "tools/content/block5-a.mjs", level: "B", what: "Module metamagic (G1): 0 PP, Focus, on a self-only spell an adjacent ally receives its self rows (targets.share)." },
  "Spell Surge": { file: "tools/content/block1.mjs", level: "B", what: "Module metamagic (G1): +1 PP, Focus (the trait added, Q132), one of range ×1.5, duration ×1.5, +2 class Save DC, +1 damage die; fumble and Resonance at disadvantage." },
  "Piercing Insight": { file: "tools/content/block5-d.mjs", level: "C", what: "On Sense Magic (both actions): choose metamagic from the catalogue (G1), discount-only options left out; PP and a Focus option's use spent (Q96), no check; the card says what each changes, the GM applies it." }
});
