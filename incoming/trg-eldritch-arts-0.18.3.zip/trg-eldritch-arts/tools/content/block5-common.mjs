/**
 * Eldritch Arts — Block 5 (0.8.0): the shared builders for Chapter 5's racial
 * and general feats. Each group's file (block5-aetherial.mjs,
 * block5-emberkin-nyrinn.mjs, block5-scaelyn.mjs, block5-general.mjs) builds
 * its feats with these, so every feat's card has the same shape: the book's
 * traits, fields and text (from book-text.json, never retyped), then one
 * paragraph saying what TRG Prime does with it.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md as Graham answered it on
 * 3 November 2026 (Q57–Q88: as proposed, Q58 and Q59 changed), on TRG Prime
 * 3.683.0's seams (C1–C19).
 *
 * RACE TRAITS ARE NOT TRAITS. As every core racial feat is built, the race a
 * feat belongs to goes in `sourceRace` (the Racial Feat picker matches it
 * against the actor's effective races), and the remaining printed traits
 * (FOCUS, METAMAGIC, TELEPORTATION …) go in `traits`. The Quiliesh prints only
 * HERITAGE: it is a Human Heritage feat (Q60).
 *
 * HERITAGE PREREQUISITES ("Wyrmdral Heritage") and "Level 1 only" are gated
 * by the core's picker from 3.683.0 (C1, Q57), so they are printed and not
 * registered.
 *
 * NAMES KEEP THE BOOK'S CURLY APOSTROPHE (’): the core's prerequisite gate
 * matches feat names exactly, so "Starseer’s Intuition" in Starseer’s Sight's
 * prerequisite must match the item's name.
 */
import fs from "node:fs";
import { feat } from "./builders.mjs";
import { md } from "./markdown.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const printed = (lines) => md((lines ?? []).join("\n\n"));
export const note = (text) => md(text);

/**
 * The book's capitals in the feats' own casing: "STARSEER’S SIGHT" →
 * "Starseer’s Sight", "CLAWS OF THE WYRM" → "Claws of the Wyrm". Small words
 * stay lower case after the first word, as the core's own feats are named
 * ("Voice of the Beast", "Schooled in Secrets").
 */
const SMALL_WORDS = new Set(["of", "the", "in", "and", "a", "an", "to", "for", "on", "with", "by", "from", "at"]);
export const titleCase = (s) => s.toLowerCase()
  .replace(/(^|[\s(\-–])([a-z’'])/g, (m, a, b) => a + b.toUpperCase())
  .replace(/’S\b/g, "’s")
  .split(" ")
  .map((word, i) => (i > 0 && SMALL_WORDS.has(word.toLowerCase()) ? word.toLowerCase() : word))
  .join(" ");

const RACIAL = new Map(BOOK.sections.racialFeats.map((f) => [f.name, f]));
const GENERAL = new Map(BOOK.sections.generalFeats.map((f) => [f.name, f]));

/** The trait that names a race (or the Heritage), and the race the picker matches. */
export const RACE_OF_TRAIT = Object.freeze({
  AETHERIAL: "Aetherial", EMBERKIN: "Emberkin", NYRINN: "Nyrinn", SCAELYN: "Scaelyn",
  ELF: "Elf", HUMAN: "Human", GNOME: "Gnome", KORNARGON: "Kornargon", ASCENDAN: "Ascendan"
});

/** The book's entry for a racial or general feat, by its printed (capitals) name. */
export function bookFeat(key, list = "racial") {
  const f = (list === "general" ? GENERAL : RACIAL).get(key);
  if (!f) throw new Error(`Block 5: the book has no ${list} feat "${key}"`);
  return f;
}

/** The card's printed half: traits, the printed fields, the flavour and the text. */
export function printedCard(f) {
  const out = [];
  if (f.traits.length) out.push(md(`**${f.traits.join(" ")}**`));
  for (const [label, value] of Object.entries(f.fields ?? {})) out.push(md(`**${label}** ${value}`));
  if (f.flavour) out.push(md(`*${f.flavour}*`));
  out.push(printed(f.lines));
  return out.join("\n");
}

/**
 * A RACIAL FEAT. `automation` is the paragraph saying what TRG Prime does
 * ("*Automated (0.8.0, TRG Prime 3.683.0):* …", "*Partly automated:* …",
 * "*Not automated:* …"); the rest is the builder's.
 *
 * `sourceRace` is derived from the printed race trait unless given (the
 * Quiliesh, Q60, gives "Human").
 */
export function racialFeat(key, { automation, flags = {}, effects = [], usesPerDay = "", repeatable = false, grantedSpells = "", grantedAbilities = "", sourceRace = null, extraTraits = [] } = {}) {
  const f = bookFeat(key, "racial");
  const raceTraits = f.traits.filter((t) => RACE_OF_TRAIT[t]);
  const race = sourceRace ?? raceTraits.map((t) => RACE_OF_TRAIT[t]).join(", ");
  if (!race) throw new Error(`Block 5: "${key}" names no race; give its sourceRace`);
  const traits = [...f.traits.filter((t) => !RACE_OF_TRAIT[t]).map(titleCase), ...extraTraits].join(", ");
  if (!automation) throw new Error(`Block 5: "${key}" needs its automation paragraph`);
  return feat({
    name: titleCase(key), category: "Racial", prerequisites: f.fields?.Prerequisites ?? "", traits,
    sourceRace: race, usesPerDay, repeatable, grantedSpells, grantedAbilities,
    description: `${printedCard(f)}\n${note(automation)}`,
    flags: { ...flags, eaBlock: 5, eaBookLine: f.line }, effects
  });
}

/** A GENERAL FEAT, as Block 1's background feats are built. */
export function generalFeat(key, { automation, flags = {}, effects = [], usesPerDay = "", repeatable = false, grantedSpells = "", grantedAbilities = "" } = {}) {
  const f = bookFeat(key, "general");
  if (!automation) throw new Error(`Block 5: "${key}" needs its automation paragraph`);
  return feat({
    name: titleCase(key), category: "General", prerequisites: f.fields?.Prerequisites ?? "",
    traits: f.traits.map(titleCase).join(", "), usesPerDay, repeatable, grantedSpells, grantedAbilities,
    description: `${printedCard(f)}\n${note(automation)}`,
    flags: { ...flags, eaBlock: 5, eaBookLine: f.line }, effects
  });
}
