/**
 * Eldritch Arts — Block 5, group D (0.8.0, on TRG Prime 3.683.0): the
 * GENERAL feats of Chapter 5 (book v1.6, ea.md L4322–4706).
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK5_AUDIT.md, Appendix D, as Graham
 * answered it on 3 November 2026 (Q81–Q88 as proposed):
 *   Q81  Esoteric Insight Master: every failed Arcana or Occultism check may
 *        be rerolled, once, with no daily limit;
 *   Q82  Rune-Binder's Precision as Ritual Expert (they do not stack);
 *        Archsage Command adds one seat on top;
 *   Q83  Ley Channeler rerolls a Failure or a Fumble (a Blunder as a Fumble);
 *   Q84  Dispel Power: no PP, the caster level as the counteract value, Very
 *        Hard, its own ladder, a Focus use; through Counter Spell too;
 *   Q85  Mirrored Rebuke: the reflection is cast by you, no check and none of
 *        your PP, your DC and spell attack; a Fumble's rebound is the GM's;
 *   Q86  Silent Spellstrike: a spell attack's critical within the spell's range;
 *   Q87  Runespeaker lowers both of Lingual Casting's rank requirements;
 *   Q88  Dispel Power, Mirrored Rebuke and Silent Spellstrike are built now
 *        (seams C9 and C15).
 *
 * THIRTY-FOUR OF THE FORTY-THREE. Nine already exist in block1.mjs
 * (`BACKGROUND_FEATS`: Disrupt Magic, Elemental Affinity, Esoteric Insight,
 * Focused Ley Sense, Ritual Expert, Spell Penetration, Spell Surge, Spirit
 * Whisper, Wanderer's Instinct) and are not rebuilt here: their ids come
 * from the name. The four Catalyst feats and Piercing Insight were items with
 * an honest card ("arrives with Block 9 / Block 6"), so the prerequisite
 * chains and the picker worked; Block 9a (0.13.0) automated three of the
 * Catalyst feats, and says why Catalyst Crafting stays a card.
 *
 * Every card carries the book's text (block5-common's `generalFeat`) and
 * one paragraph saying exactly what TRG Prime does with it. The Foundry side
 * is module/block5d-automations.mjs.
 */
import { generalFeat } from "./block5-common.mjs";
import { conditional } from "./builders.mjs";

/** The flag every module-owned Use on these items carries. */
const auto = (key, more = {}) => ({ eaAutomation: key, ...more });

/** Esoteric Insight's reroll shape (Block 1), for Expert's extra use and Master's unlimited one. */
const esotericReroll = (label) => ({ checkTypes: ["skill"], reaction: false, subjects: ["arcana", "occultism"], degrees: ["failure", "fumble", "blunder"], label });

/**
 * A FOCUS FEAT (Dispel Power: "this action has the Focus trait"). The book
 * prints the trait in the text, not the trait line, so the builder's traits
 * are empty: the item carries Focus itself, and, as every tracked item the
 * module ships, arrives with its one use (the core's Focus default, one use
 * restored by Refocus or daily preparation).
 */
function withFocus(doc) {
  doc.system.traits = doc.system.traits ? `${doc.system.traits}, Focus` : "Focus";
  doc.system.usesValue = 1;
  return doc;
}

/** The four Catalyst feats: read by Block 9a's catalysts (0.13.0, TRG Prime 3.688.0). */
const B9A = "*Automated (0.13.0, TRG Prime 3.688.0):* ";

/** Wanderer's Sense's +2 for you and allies within 10 feet: a tick on saves (the environment is the table's). */
const WANDERERS_SENSE_SAVE = Object.freeze({ kind: "modifier", value: 2, type: "circumstance", label: "Wanderer’s Sense", scope: "Saving throws against environmental effects in magical areas (wild surges, corrupted ground, magical storms) — tick if so", auto: false, when: { checkTypes: ["save"] } });

export const FEATS_B5_D = [
  generalFeat("ARCHSAGE COMMAND", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* leading a ritual as its primary caster, the Magic Ritual dialog counts one more caster for you, on top of Ritual Expert's or Rune-Binder's Precision's: a primary with both counts as three (Graham's Q82). Like Ritual Expert's seat, it counts for the one-secondary requirement and the 2 PP headroom. When one of your Arcana checks, or a ritual you lead, comes out a Critical (or Heroic), you gain an effect for 1 hour: advantage on your next saving throw against a magical effect, offered as a tick on your saves (tick it on one against a magical effect, and it is spent). A secondary caster's check is entered by the primary as a degree, so a Critical there is the GM's to grant; so is a Critical reached by a reroll (a rerolled check is locked, and its result is not read again)."
  }),
  generalFeat("CATALYST AFFINITY", {
    automation: B9A + "read by every catalyst's backlash (Graham's Q191): the backlash's damage is reduced by 2 per character level in all (to no less than 0), each condition's duration in rounds is 1 round shorter (at least 1), and Stunned 3 becomes Stunned 2. Durations in minutes or hours are as printed. The backlash card shows each reduction."
  }),
  generalFeat("CATALYST CONSERVATION", {
    automation: B9A + "when a cast (or a ritual) has settled, a DC 15 flat check is rolled and shown on the catalyst's card: on a 15 or better the catalyst is not consumed. On a Fumble or Blunder of the Spellcraft check it is always consumed, and no check is rolled."
  }),
  generalFeat("CATALYST CRAFTING", {
    automation: "*Not automated:* TRG Prime's Create action has a fixed list of item types, and a catalyst is not one of them: make one as a Mundane Item through Crafting, at the catalyst's level and price (the Catalysts table). Holding this feat, the formula and any rare materials is the table's to check."
  }),
  generalFeat("CATALYST MASTERY", {
    automation: B9A + "read by every catalyst's backlash: on a Failure of the Spellcraft check (or of the ritual check, in a ritual) no backlash is applied, and the card says so. A Fumble or Blunder still brings it. Its Catalyst Affinity prerequisite is checked."
  }),
  generalFeat("CHANNEL SIPHONER", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* a Partial on Tap Magical Energy is treated as a Success: the action's card prints the Success, and you siphon a Success's PP (TRG Prime's degree upgrade, C10). *Not yet automated:* halving a Fumble's (or Blunder's) damage — Block 2's Tap resolver rolls it; until it reads this feat, take half of the damage the card shows (the GM heals the rest back)."
  }),
  generalFeat("CIRCLE ADEPT", {
    automation: "*Automated (0.8.0):* after Inscribe Summoning Circle, a card says the circle took half the normal time to draw: 5 minutes × the creature's level (10 with meticulous care). Its DC, its bonus and how long it lasts are unchanged."
  }),
  withFocus(generalFeat("DISPEL POWER", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; Graham's Q84):* offered as a tick on your Dispel prompt — the Dispel action, and Counter Spell's free Dispel — while its Focus use remains. Ticked, no PP is spent and the counteract value is your caster level in place of the PP declared, compared as Dispel compares. The check is Very Hard (+5), Disrupt Magic's +2 still applies, and the results are this feat's, not Dispel's: a Heroic reads as the Critical, a Partial as the Failure, a Blunder as the Fumble. On a Fumble a Resonance event is rolled. Dispelling, the 1-minute suppression and \"you cannot attempt to dispel this effect again\" are said on the card and are the GM's to apply, as Dispel's own results are. Focus: one use, restored by Refocus or daily preparation."
  })),
  generalFeat("ESOTERIC INSIGHT EXPERT", {
    usesPerDay: "1",
    flags: {
      fumbleReroll: esotericReroll("Esoteric Insight (Expert's additional use)"),
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Esoteric Insight Expert", scope: "Saving throws against magical effects with the Shadow or Emotion trait", auto: true, when: { checkTypes: ["save"], traits: ["shadow", "emotion"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* Esoteric Insight's reroll is offered once more each day: when an Arcana or Occultism check (Spell Recognition included) comes out a Failure, Fumble or Blunder, this feat's use is offered beside Esoteric Insight's; the new result stands. Daily preparation restores it. +2 circumstance on saving throws against effects with the Shadow or Emotion trait, applied by itself when the effect names the trait. When you use Spell Recognition, its card says that you know the spell's tradition, whatever the result: the GM tells you which (the roll is not told the spell)."
  }),
  generalFeat("ESOTERIC INSIGHT MASTER", {
    flags: {
      fumbleReroll: esotericReroll("Esoteric Insight Master"),
      conditionals: [
        conditional({ kind: "advantage", label: "Esoteric Insight Master", scope: "Recognising a magical effect with the Rare or Unique trait — tick if so", auto: false, when: { actions: ["identifyPower", "spellRecognition"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; Graham's Q81):* every Arcana or Occultism check that comes out a Failure, Fumble or Blunder may be rerolled, once, with no daily limit; the new result stands (Esoteric Insight's and Expert's daily rerolls are offered first while they last). A Critical (or Heroic) on Spell Recognition gives you +2 circumstance on your next saving throw against that caster's spells before the end of your next turn: applied by itself against the creature you have targeted, or offered as a tick when you have targeted none. Advantage is offered as a tick on Identify Power and Spell Recognition: tick it when the effect has the Rare or Unique trait. A Spell Recognition Critical reached by a reroll is not read again (a rerolled check is locked): the GM grants the +2."
  }),
  generalFeat("ESSENCE RESERVOIR", {
    automation: "*Automated (0.8.0):* PP you siphon with Tap Magical Energy are held for 1 minute instead of to the end of your next turn, up to your Power Manipulation ranks in all (PP already held this way count). Siphoned PP beyond that keep the normal end of your next turn. Unspent siphoned PP still dissipate when their time runs out."
  }),
  generalFeat("HYPNOTIC SAVANT", {
    automation: "*Automated (0.8.0):* after Hypnotism: Implant Suggestion, a card gives the suggestion's duration with this feat, in place of the one above it: Success 11 minutes (the Suggestion spell's 1 minute, +10), Partial 15 minutes, Critical 1 hour (instead of 30 minutes), Heroic 1 hour 10 minutes. After Memory Recall at Success or better, a subject with a caster level regains 1 PP, up to its maximum (said for the GM when the subject is not yours to change)."
  }),
  generalFeat("LEY CHANNELER", {
    usesPerDay: "1",
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* when Tap Ley Line comes out a Success you regain 1d4 PP, on a Critical (or Heroic) 2d4, up to your maximum, beside the ley line's effect (they stack, EA-M25). Once a day, when a Tap Ley Line check comes out a Failure or a Fumble (a Blunder reads as the Fumble; Graham's Q83), you are asked whether to reroll it: the use is spent and the new result stands. Daily preparation restores it."
  }),
  generalFeat("LEY SCHOLAR", {
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Ley Scholar", scope: "Manipulating a ley line (Tap or Channel Ley Line)", auto: true, when: { actions: ["tapLeyLine", "channelLeyLine"] } }),
        conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Ley Scholar", scope: "Stabilising a magical anomaly — tick if this check is one", auto: false, when: { checkTypes: ["skill"], not: { actions: ["tapLeyLine", "channelLeyLine"] } } })
      ]
    },
    automation: "*Automated (0.8.0):* +2 circumstance on Tap Ley Line and Channel Ley Line, applied by itself. Stabilising a magical anomaly has no action of its own, so the +2 is offered as a tick on your other skill checks: tick it on one that does."
  }),
  generalFeat("LOREKEEPER’S INSIGHT", {
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "class", label: "Lorekeeper’s Insight", scope: "A specialist Lore skill check — tick if this one is a Lore", auto: false, when: { checkTypes: ["specialist"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* +2 class on your ritual check as the primary caster, from the Magic Ritual dialog. Offered as a tick on your specialist skill checks: tick it on a Lore (every specialist skill in the book is a Lore; n6). As a secondary caster your check is entered by the primary as a degree: add your +2 before it is entered. Inscribe Summoning Circle is its own check, not a ritual's (n6)."
  }),
  generalFeat("MAGIC SENSE", {
    flags: { creatureAbility: { derives: { sense: { category: "tertiary", name: "Magic Sense", finds: "active magical auras (spells, magical traps, magical creatures, warded items)", rollWith: "Sense Magic (Power Manipulation)", note: "Detects active magical auras (spells, magical traps, magical creatures, warded items). Roll Sense Magic (Power Manipulation) in place of Perception." } } } },
    automation: "*Partly automated (0.8.0):* Magic Sense is on your sheet's senses: a tertiary sense, 30 feet + 5 per point of Wisdom (a granted sense is not halved, Graham's ruling of 25 August 2026; n7), finding active magical auras, rolled with Sense Magic (Power Manipulation). *The GM's:* when you enter an area with an active magical aura within its range, the GM may call for a secret Sense Magic check, as printed."
  }),
  generalFeat("MAGUS APPRAISER", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* Appraise Magic offers you this feat's four rungs instead of its own: 10 minutes (+2), 1 minute (+0), 1 round (−2), 1 AP (−5). On a Critical (or Heroic), a card whispered to the GM says that you also learn whether the item is cursed or has unusual activation requirements; what you learn is the GM's to tell."
  }),
  generalFeat("MASKED CASTER", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* Spell Trickery's tick on your Casting Conditions prompt raises the casting DC by +1 instead of +2. When someone's See Through Spell Trickery against you comes out a Blunder, a card says that you may plant two false details (e.g. “it’s harmless” and “it’s divine”); what they then believe is yours and the GM's to say."
  }),
  generalFeat("MASTER BINDER", {
    flags: {
      controlLevelBonus: 2,
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "untyped", label: "Master Binder", scope: "Asserting control over a creature with the Summons trait — tick if this check or save is one", auto: false, when: { checkTypes: ["skill", "save"] } })
      ]
    },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; C12):* +2 control levels, added on your sheet after the cap. The +2 on skill checks and saving throws made to assert control over a creature with the Summons trait is offered as a tick on your skill checks and saves: tick it on one."
  }),
  generalFeat("MIRRORED REBUKE", {
    automation: "*Partly automated (0.8.0, TRG Prime 3.683.0; Graham's Q85):* when a creature on the scene that is not your ally casts a spell and you hold Counter Spell, you are asked whether to counter it with Counter Spell's free Dispel (Power Manipulation), at the PP you declare (as Disrupting Magic is asked). On the Dispel prompt Mirrored Rebuke is offered as a tick. Countered at Success or better with it ticked, the spell is negated for its targets and resolves as though cast by you at its caster: released from you at the PP it was cast at, with no casting check and none of your PP, at your save DC and spell attack, its range and targeting measured from you. Its warps are not carried over (the GM adds them). Without the tick the counter only stops it. Only Counter Spell's own counters offer it: not Disrupting Magic's Dispel nor another feat's. If you also hold Disrupting Magic and could use it, you are asked once, for Disrupting Magic (which does not reflect); Counter Spell's Use on your sheet remains. *The GM's:* on a Fumble the spell partly rebounds on you and one ally within its range; the card says so and the GM resolves it. A counter made from Counter Spell's Use on the sheet (after Spell Recognition) has no spell in hand: its card says the reflection is the GM's."
  }),
  generalFeat("MNEMONIC GRASP", {
    automation: "*Not automated:* TRG Prime's Learn a Spell already lets you name where the spell comes from, so learning straight from a spell you identified needs no gate opened. The halved learning time after a Critical identification is yours and the GM's to apply."
  }),
  generalFeat("PIERCING INSIGHT", {
    automation: "*Partly automated (0.9.0, TRG Prime 3.684.0):* once you resolve either Sense Magic (Power Manipulation) action, you are asked which of your metamagic options to apply — the core's and Eldritch Arts' (Block 6's catalogue, G1), less those that need a spell (Spellthread, Echo of the Ancestors, Resonant Harmony) and Subconscious Casting. Options that only lower a price (Ley-Etched Symbol, the Reservoir's −2) are left out. Their PP are spent from your pool, and a Focus option (Resonant Pulse, Spell Surge, Unfettered Mastery) is offered only while its feat has its use, which is then spent (Q96); no further check is made. The card names what each changes (Reach: range ×2, Widen: area ×2, Extend: duration ×2 …); *the GM applies it* to the detection, which the GM adjudicates."
  }),
  generalFeat("RAPID BINDER", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0):* Quickbind offers you its \"outside daily preparation\" rung at +0 instead of Very Hard (−5). On a Success or better, a card says that the item is invested and you may activate it this round."
  }),
  generalFeat("RUNE-BINDER’S PRECISION", {
    automation: "*Automated (0.4.0 and 0.8.0, TRG Prime 3.679.0):* as the primary caster you count as two in the Magic Ritual dialog: one more caster for the one-secondary requirement and the 2 PP headroom. It does not stack with Ritual Expert (Graham's M21, Q13, Q82); Archsage Command adds one more on top. As a secondary, the primary enters you among the Ritual Experts."
  }),
  generalFeat("RUNESPEAKER", {
    flags: {
      conditionals: [
        conditional({ kind: "modifier", value: 2, type: "circumstance", label: "Runespeaker", scope: "Deciphering magical writing, glyphs or runes — tick if so", auto: false, when: { actions: ["decipherWriting", "identifyPower"] } })
      ]
    },
    automation: "*Partly automated (0.8.0):* +2 circumstance offered as a tick on Decipher Writing and Identify Power: tick it when the writing, glyph or rune is magical. *Not yet automated:* lowering both of Lingual Casting's rank requirements by 1, minimum 1 (Graham's Q87): in TRG Prime 3.683.0 a scroll's reading path is not told who is reading, so it cannot see this feat. Until it is, the path is still offered when a rank falls short, and the GM may allow the attempt. *The GM's:* on a Critical reading, casting the scroll as if heightened by +1 per 4 Linguistics ranks (a reading path cannot heighten its spell)."
  }),
  generalFeat("RUNIC STABILISER", {
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; C14):* on a High Magic cast, your Casting Conditions prompt offers a tick: inscribe a stabilising rune for 1 AP, charged with the cast's AP (in an encounter only). Ticked, a Partial casting result is treated as a Success."
  }),
  generalFeat("SILENT SPELLSTRIKE", {
    flags: { spellSniping: true },
    automation: "*Automated (0.8.0, TRG Prime 3.683.0; C15, Graham's Q86):* a critical on a spell attack (a spell with the Attack trait) against a creature within the spell's range opens Sniping (Stealth), as a ranged weapon's critical within its first range increment does. Sniping's other requirements are as for weapons: the target's state is the GM's to judge."
  }),
  generalFeat("SPELL FEEDBACK", {
    automation: "*Not automated:* TRG Prime's cast card already shows every caster each target's save result (resisted, partly, or fully affected), so there is nothing to add. The feat matters only at a table that hides those rolls, where the GM tells you the outcome."
  }),
  generalFeat("SPELL THIEF", {
    automation: "*Partly automated (0.8.0, TRG Prime 3.683.0; C13):* a Critical (or Heroic) on Borrow Spell makes the borrowed copy a free preparation: it is prepared and fills no memorisation slot, until it leaves your book at your next daily preparation. One at a time: a new free copy clears the last, which then counts again and is unprepared. *Not yet automated:* borrowing from a scroll or a magical text — Borrow Spell lists only other casters' spellbooks; until it reads this feat, the GM adjudicates such a borrowing."
  }),
  generalFeat("SPELL TRANSCRIPTION", {
    automation: "*Not automated:* Create (Scribe Scroll) does not ask whether you know the spell, so there is no gate to open. The 24 hours, and the halved creation time after a Critical identification, are notes for you and the GM."
  }),
  generalFeat("SPIRIT RESOURCES", {
    automation: "*Automated (0.8.0):* Gather Information, Make an Impression and Request are offered from your Occultism skill as well as Diplomacy. Use Occultism only when dealing with spirits (yours to judge)."
  }),
  generalFeat("THREADCUTTER", {
    repeatable: true,
    flags: auto("threadcutter"),
    automation: "*Automated (0.8.0):* **Use** chooses this copy's tradition skill: Arcana, Nature, Occultism or Religion, a different one for each copy. It adds an ability, Threadcutter (that skill), and the Dispel action is then offered from that skill. Use it only against effects within that tradition's domain (yours and the GM's to judge). Using it again changes this copy's skill."
  }),
  generalFeat("WANDERER’S MASTERY", {
    flags: auto("wanderersMastery"),
    automation: "*Partly automated (0.8.0):* **Use** either lists every ley line on the map within 1 mile of you, with its level and direction; or, once a week, completes the 8-hour ritual journey: you and the companions you tick gain a +2 luck bonus on saving throws against magical effects for 24 hours, applied by itself to a save against a spell and offered as a tick on other saves. *The GM's:* your immunity to becoming magically lost, and your companions' Survival checks to endure an environment counting as at least a 10 on the die (TRG Prime has no die floor; n9)."
  }),
  generalFeat("WANDERER’S SENSE", {
    usesPerDay: "1",
    flags: {
      ...auto("wanderersSense"),
      conditionals: [
        conditional({ kind: "advantage", label: "Wanderer’s Sense", scope: "Survival checks to resist fatigue, starvation or exhaustion from harsh or magically charged environments — tick if so", auto: false, when: { checkTypes: ["skill"], subjects: ["survival"] } }),
        conditional({ ...WANDERERS_SENSE_SAVE })
      ],
      // "you and allies within 10 feet": the core's ally aura lays the same
      // tick on each ally inside it (the owner carries its own, above).
      auras: [{ kind: "ally", radius: 10, text: "Wanderer’s Sense: allies within 10 feet gain a +2 circumstance bonus on saving throws against environmental effects in magical areas.", allyEffect: { conditionals: [{ ...WANDERERS_SENSE_SAVE }] } }]
    },
    automation: "*Automated (0.8.0):* advantage offered as a tick on your Survival checks: tick it on one to resist fatigue, starvation or exhaustion in a harsh or magically charged place. You, and each ally within 10 feet of your token (the core's ally aura), are offered +2 circumstance as a tick on saving throws: tick it against an environmental effect in a magical area. **Use**, once a day: your Survival check to avoid becoming lost in magically active or distorted terrain succeeds, and the card says so. Daily preparation restores it."
  })
];

/**
 * What each feat's automation is, for the docs (A full · B automated with a
 * normal choice · C partial, the rest a card or the GM's · D descriptive).
 * Graded on what 0.8.0 does, not on what a later block will.
 */
export const AUTOMATION_B5_D = Object.freeze({
  "Archsage Command": { level: "B", what: "+1 ritual seat as primary (ritual rules); a 1-hour advantage tick on the next save vs magic after a Critical Arcana check or ritual" },
  "Catalyst Affinity": { level: "A", what: "read by every catalyst's backlash (0.13.0)" },
  "Catalyst Conservation": { level: "A", what: "its DC 15 flat check, rolled at the settle (0.13.0)" },
  "Catalyst Crafting": { level: "D", what: "card only: Create has no catalyst item type (0.13.0)" },
  "Catalyst Mastery": { level: "A", what: "read by every catalyst's backlash (0.13.0); its Catalyst Affinity prerequisite is gated" },
  "Channel Siphoner": { level: "B", what: "Partial→Success on Tap Magical Energy (registerDegreeUpgrades, C10); the Fumble's half damage waits on Block 2's resolver" },
  "Circle Adept": { level: "A", what: "card: the circle took half the time" },
  "Dispel Power": { level: "B", what: "Dispel modifier (C9): optional, no PP, CL as counteract value, Very Hard, own ladder, Focus use; Fumble rolls Resonance" },
  "Esoteric Insight Expert": { level: "B", what: "a second daily reroll row; +2 circ saves vs Shadow/Emotion (auto); Spell Recognition card line (tradition)" },
  "Esoteric Insight Master": { level: "B", what: "unlimited Arcana/Occultism reroll row (Q81); Spell Recognition Critical: +2 next save vs that caster; Rare/Unique advantage tick" },
  "Essence Reservoir": { level: "A", what: "siphoned essence held 1 minute, up to Power Manipulation ranks; the excess keeps its normal end" },
  "Hypnotic Savant": { level: "A", what: "Suggestion duration card (+10 min, Critical 1 h); Memory Recall +1 PP to a caster subject" },
  "Ley Channeler": { level: "B", what: "+1d4/2d4 PP on Tap Ley Line; 1/day asked reroll of a Failure or Fumble (check reaction)" },
  "Ley Scholar": { level: "B", what: "+2 circ auto on Tap/Channel Ley Line; a tick elsewhere for anomalies" },
  "Lorekeeper’s Insight": { level: "B", what: "+2 class on the primary's ritual check (ritual rules); a tick on specialist Lore checks" },
  "Magic Sense": { level: "C", what: "tertiary sense on the sheet; the GM's secret check" },
  "Magus Appraiser": { level: "A", what: "Appraise Magic time ladder +2/+0/−2/−5 (timeLadderByFeat, wired by the lead); Critical whisper to the GM" },
  "Masked Caster": { level: "A", what: "Spell Trickery's option +1 instead of +2; Blunder card line on See Through Spell Trickery" },
  "Master Binder": { level: "B", what: "controlLevelBonus 2 (C12); +2 tick on control checks and saves" },
  "Mirrored Rebuke": { level: "C", what: "cast reaction offering Counter Spell's Dispel; Dispel modifier tick; Success+ reflects as an item-style cast from you (no check, no PP); Fumble rebound is the GM's" },
  "Mnemonic Grasp": { level: "D", what: "card: Learn a Spell already takes any source" },
  "Piercing Insight": { level: "C", what: "Block 6 (block6d): on Sense Magic, the metamagic catalogue (G1) offered, PP spent, no check; the card says what each changes, the GM applies it" },
  "Rapid Binder": { level: "A", what: "Quickbind's outside rung at +0 (timeLadderByFeat, wired by the lead); Success card line" },
  "Rune-Binder’s Precision": { level: "A", what: "counts as two in a ritual (Block 2b's countsAsTwo reads it)" },
  "Runespeaker": { level: "C", what: "+2 circ tick on Decipher Writing / Identify Power; rank reduction not built (release path has no reader); heighten is the GM's" },
  "Runic Stabiliser": { level: "B", what: "cast option on High Magic (1 AP, C14) and a Partial→Success remap" },
  "Silent Spellstrike": { level: "B", what: "spellSniping flag (C15)" },
  "Spell Feedback": { level: "D", what: "card: the cast card already shows each save" },
  "Spell Thief": { level: "C", what: "Critical Borrow Spell → memorisationFree prepared copy, one at a time (C13); scroll lenders not built" },
  "Spell Transcription": { level: "D", what: "card: Create does not gate on the spell" },
  "Spirit Resources": { level: "B", what: "three Occultism skill substitutions" },
  "Threadcutter": { level: "B", what: "Use picks a tradition skill; an ability carries its Dispel substitution" },
  "Wanderer’s Mastery": { level: "C", what: "Use: ley lines within a mile; weekly 24 h +2 luck on saves vs magic; immunity and die floor are the GM's" },
  "Wanderer’s Sense": { level: "B", what: "advantage tick on Survival; +2 save tick for you and an ally aura (10 ft); 1/day Use: lost check succeeds" }
});

/** The nine Block 1 already ships, by name (not rebuilt here). */
export const BUILT_IN_BLOCK1 = Object.freeze(["Disrupt Magic", "Elemental Affinity", "Esoteric Insight", "Focused Ley Sense", "Ritual Expert", "Spell Penetration", "Spell Surge", "Spirit Whisper", "Wanderer’s Instinct"]);
