/**
 * Eldritch Arts — Block 6 (0.9.0): the shared builders for Chapter 5's
 * archetypes (L2892–3192) and class feats (L3210–4310). Each group's file
 * builds its feats with these, so every card has the same shape: the book's
 * traits, fields and text (from book-text.json, never retyped), then one
 * paragraph saying what TRG Prime does with it.
 *
 * Built from docs/ELDRITCH_ARTS_BLOCK6_AUDIT.md as Graham answered it on
 * 4 November 2026 (Q89–Q149: as proposed; Q89, one release), on TRG Prime
 * 3.684.0's seams (G1–G26).
 *
 * HYPHENATED ARCHETYPE TRAITS ARE STORED WITH SPACES. The book prints a class
 * feat's archetype as one hyphenated word (ETERNAL-VIGIL, BLOOD-OF-THE-WYRM)
 * so that the trait line splits on spaces. The core's class-feat slot
 * recognises a trait as an archetype gate only when it equals a core
 * archetype's name or a `registerArchetype` name (lower-cased), and
 * "eternal-vigil" equals neither: built as printed, the feat would be open to
 * every character (audit, "What the reviewers found"). So the stored trait is
 * "Eternal Vigil", as Inner Tempest stores "Zen Archer", and the card keeps
 * the printed line. Each Eldritch Arts archetype is registered by
 * registration.mjs; the core's own Runemage is not (it would duplicate the
 * core's gate).
 *
 * THE PRINTED CARD IS THE BOOK'S. Where the stored prerequisite or
 * progression line must differ from the print so the core's parser reads it
 * ("Con 2+" is stored "Con +2"), the builder takes `prerequisites` /
 * `progression` and the card still shows the printed line.
 */
import fs from "node:fs";
import { feat } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { titleCase } from "./block5-common.mjs";

export { titleCase };

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const printed = (lines) => md((lines ?? []).join("\n\n"));
export const note = (text) => md(text);

/**
 * BOOK-TEXT REPAIRS, each a slip in the extraction (not a rule change), read
 * from ea.md at the line given. Steelbinding (L4150): the book sets
 * "**PP Cost** +2**; Requirements** your spell targets …" with the bold
 * misplaced (audit m45), so book-text.json kept "+2" and lost the clause.
 * From 0.10.0 the extractor moves the "; " out of the bold run and reads the
 * clause itself; the repair is kept, and now writes what the extract holds
 * (verify-book-extract checks that it does).
 */
const REPAIRS = Object.freeze({
  STEELBINDING: (f) => ({
    ...f,
    fields: { ...f.fields, "PP Cost": "+2", Requirements: "your spell targets a creature wearing metal armour who is within 30-ft." }
  })
});

const repaired = (f) => (REPAIRS[f.name] ? REPAIRS[f.name](f) : f);
const ARCHETYPES = new Map(BOOK.sections.archetypeFeats.map((f) => [f.name, repaired(f)]));
const CLASS_FEATS = new Map(BOOK.sections.classFeats.map((f) => [f.name, repaired(f)]));

/** The book's entry, by its printed (capitals) name. */
export function bookFeat(key, list = "class") {
  const f = (list === "archetype" ? ARCHETYPES : CLASS_FEATS).get(key);
  if (!f) throw new Error(`Block 6: the book has no ${list} feat "${key}"`);
  return f;
}

/** Every printed name of the list, for the harness's completeness check. */
export const bookNames = (list = "class") => [...(list === "archetype" ? ARCHETYPES : CLASS_FEATS).keys()];

/**
 * A printed trait as stored: "ETERNAL-VIGIL" → "Eternal Vigil",
 * "BLOOD-OF-THE-WYRM" → "Blood of the Wyrm", "METAMAGIC" → "Metamagic".
 */
export const storedTrait = (t) => titleCase(String(t).replace(/-/g, " "));

/** The card's printed half: traits as printed, the printed fields, the flavour and the text. */
export function printedCard(f) {
  const out = [];
  if (f.traits.length) out.push(md(`**${f.traits.join(" ")}**`));
  for (const [label, value] of Object.entries(f.fields ?? {})) out.push(md(`**${label}** ${value}`));
  if (f.flavour) out.push(md(`*${f.flavour}*`));
  out.push(printed(f.lines));
  return out.join("\n");
}

const need = (key, automation) => {
  if (!automation) throw new Error(`Block 6: "${key}" needs its automation paragraph`);
};

/**
 * AN ARCHETYPE (category "Archetype"). Its printed traits are the classes it
 * is open to ("WARLOCK WITCH" → "Warlock, Witch"). `progression` overrides
 * the stored `system.progressionRequirements` (default: the printed line);
 * `prerequisites` the stored prerequisite (default: the printed one).
 */
export function archetypeFeat(key, { automation, prerequisites, progression, flags = {}, effects = [], usesPerDay = "", grantedSpells = "", grantedAbilities = "", grantedFeats = "" } = {}) {
  const f = bookFeat(key, "archetype");
  need(key, automation);
  const item = feat({
    name: titleCase(key), category: "Archetype",
    prerequisites: prerequisites ?? f.fields?.Prerequisites ?? "",
    traits: f.traits.map(storedTrait).join(", "),
    usesPerDay, grantedSpells, grantedAbilities, grantedFeats,
    description: `${printedCard(f)}\n${note(automation)}`,
    flags: { ...flags, eaBlock: 6, eaBookLine: f.line }, effects
  });
  item.system.progressionRequirements = progression ?? f.fields?.["Progression Requirements"] ?? "";
  return item;
}

/**
 * A CLASS FEAT (category "Class"). Its traits are stored with the archetype
 * names spaced (see the header); `extraTraits` adds a stored trait the print
 * lacks, and `prerequisites` overrides the stored prerequisite.
 */
export function classFeat(key, { automation, prerequisites, flags = {}, effects = [], usesPerDay = "", repeatable = false, grantedSpells = "", grantedAbilities = "", grantedFeats = "", extraTraits = [] } = {}) {
  const f = bookFeat(key, "class");
  need(key, automation);
  return feat({
    name: titleCase(key), category: "Class",
    prerequisites: prerequisites ?? f.fields?.Prerequisites ?? "",
    traits: [...f.traits.map(storedTrait), ...extraTraits].join(", "),
    usesPerDay, repeatable, grantedSpells, grantedAbilities, grantedFeats,
    description: `${printedCard(f)}\n${note(automation)}`,
    flags: { ...flags, eaBlock: 6, eaBookLine: f.line }, effects
  });
}

/** The archetypes Block 6 registers with the core (`registerArchetype`), by stored name. */
export const EA_ARCHETYPE_NAMES = Object.freeze(BOOK.sections.archetypeFeats.map((f) => titleCase(f.name)));
