/**
 * The Symbols' card text (0.11.0, Block 8a, §4.3): shared by the three new
 * Symbols (tools/content/block8a-spells.mjs) and the two rebuilt from Block 3a
 * (tools/content/block3-spells.mjs, Q184), kept apart so neither imports the other.
 */
import { SYMBOL_HOLD_FEET } from "../../module/block8a-rules.mjs";

export const SINCE_8A = "0.11.0, TRG Prime 3.686.0";
const CHOICE = `*Automated, with a choice (${SINCE_8A}):*`;

const SYMBOL_COMMON = "The cast places a small hidden Region where you carve the symbol, its Save DC stamped. The GM's card has **The symbol flashes**: it finds every token with line of sight to the symbol (walls that block sight block it), lets the GM untick any the symbol does not reach (\"the GM determines that it looks in its direction\"), and rolls each one's save at the stamped DC. Every flash is a new save, with no immunity and no range but line of sight (M57). A later, worse result replaces a better one. After a flash the symbol shows as glowing until no character has had line of sight to it for 10 minutes of world time.";

export function symbolText(key) {
  switch (key) {
    case "symbolOfInsanity": return `${CHOICE} ${SYMBOL_COMMON} Each creature it reaches is targeted with an Insanity spell at the symbol's Save DC (m134): it rolls Will, and on a failed save it is insane for 1 round per 2 points it failed by, rolling core Insanity's d10 at the start of each of its turns (TRG Prime 3.686.0, H18): 1 unaffected, 2–4 stunned 1d3, 5–7 slowed 1d3, 8–10 confused. *By hand:* only the GM's judgement that the symbol "looks in its direction".`;
    case "symbolOfPain": return `${CHOICE} ${SYMBOL_COMMON} Fortitude: Success (and better) unaffected; Failure (and Partial) injured 2; Fumble (and Blunder) injured 4 (m42, m131). The injury is held by the curse (TRG Prime 3.686.0, H17): while the creature is within ${SYMBOL_HOLD_FEET} feet of the symbol, and for 1 hour after it moves farther (m135), no rest, recovery or relief spell reduces it; only Remove Curse ends it sooner, counteracting against this cast (Q183). When the hold ends, the injury it added goes with it.`;
    case "symbolOfWeakness": return `${CHOICE} ${SYMBOL_COMMON} Fortitude: Critical (and Heroic) unaffected; Success weakened 1; Partial weakened 2; Failure weakened 4; Fumble (and Blunder) weakened 6. The weakness is held by the curse (TRG Prime 3.686.0, H17): while the creature is within ${SYMBOL_HOLD_FEET} feet of the symbol, and for 1 hour after it moves farther (m135), no rest, recovery or relief spell reduces it; only Remove Curse ends it sooner, counteracting against this cast (Q183). When the hold ends, the weakness it added goes with it.`;
    case "symbolOfDeath": return `${CHOICE} ${SYMBOL_COMMON} Fortitude: Success (and better) unaffected; Failure (and Partial) a deadly essence critical injury; Fumble (and Blunder) the creature dies (m42). After any creature dies from the symbol, it fades and the spell ends (m132). "Permanent": its PP stay locked until it ends (Q170). The glow counts only living characters, as printed. *Rebuilt in 0.11.0 on the Symbol model (Q184); a copy already on a sheet keeps its old card until re-added from the pack.*`;
    case "symbolOfFear": return `${CHOICE} ${SYMBOL_COMMON} Will: Success (and better) unaffected; Partial frightened 2; Failure frightened 4 and fleeing for 1 round; Fumble (and Blunder) frightened 6 and fleeing for 1 round (m42). The fear carries the spell's traits, so a spell that counteracts fear reaches it. *Rebuilt in 0.11.0 on the Symbol model (Q184); a copy already on a sheet keeps its old card until re-added from the pack.*`;
    default: return "";
  }
}
