/**
 * Block 10a (0.17.0, on TRG Prime 3.693.0): Chapter 9's four relics and the
 * example sentient item, Dawnshield. THE PRINTED TEXT IS THE BOOK'S, read
 * from tools/content/book-text.json (`chapter9.relics`, `chapter9.sentient`);
 * the automation note says what the module does with it
 * (module/block10-rules.mjs, module/block10-automations.mjs).
 *
 * A relic ships as its plain Dormant item: unbonded, uninvested, without
 * powers (Q215). Bonding, awakening and investing it rewrite it.
 */
import fs from "node:fs";
import { md } from "./markdown.mjs";
import { stableId, SYSTEM_ID, MODULE_ID } from "./builders.mjs";
import { RELICS_10, DAWNSHIELD, TIERS, relicStateAt } from "../../module/block10-rules.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));

const STATS = Object.freeze({
  coreVersion: "14", systemId: SYSTEM_ID, systemVersion: "3.693.0",
  createdTime: 1789430400000, modifiedTime: 1789430400000, lastModifiedBy: null,
  compendiumSource: null, duplicateSource: null
});
export const STAMP = "0.17.1, TRG Prime 3.694.0";
const title = (s) => String(s).toLowerCase().replace(/(^|[\s-])([a-z])/g, (m, a, b) => a + b.toUpperCase());

/** The base items' own figures, as TRG Prime's packs print them (the customisation's base). */
const BASES = Object.freeze({
  "Light Steel Shield": {
    system: { category: "light", metal: true, defenceBonus: 1, penalty: -1, dr: 0, hardness: 0, brokenThreshold: 0, shieldBashDamage: "1d4", shieldBashFumbleDC: 6, shieldBashDamageType: "bludgeoning", proficiency: "" },
    base: { level: 0, price: 20, hp: 12, weight: 6, category: "light", metal: true }
  },
  "Heavy Steel Shield": {
    system: { category: "heavy", metal: true, defenceBonus: 2, penalty: -2, dr: 1, hardness: 0, brokenThreshold: 0, shieldBashDamage: "1d6", shieldBashFumbleDC: 8, shieldBashDamageType: "bludgeoning", proficiency: "" },
    base: { level: 0, price: 40, hp: 20, weight: 15, category: "heavy", metal: true }
  },
  Broadsword: {
    system: { damage: "1d8", damageType: "slashing", baseDamage: "1d8", damageTypeOverride: "", hands: 1, range: 0, armourRending: 0, proficiency: "", fumbleDC: 10, attackMode: "melee", rangeIncrement: 0, group: "Sword", category: "Martial", size: "medium", attackBonus: 0, twoHandedGrip: false, loaded: false, magazine: 0, reloadProgress: 0, usedQuickLoadThisRound: false, spinBonus: 0, attackedThisTurn: false, natural: false },
    base: { level: 0, price: 10, hp: 0, weight: 4, category: "Martial" }
  }
});

/** A relic's printed text: traits, fields, flavour, requirement and the five tiers. */
function printedRelic(e) {
  const fields = Object.entries(e.fields).map(([k, v]) => `**${k}** ${v}`).join("; ");
  return [
    md(`**${e.name}** (${e.traits.join(", ")})`),
    md(fields),
    md(e.flavour.map((p) => `*${p}*`).join("\n\n")),
    e.requirement ? md(`**Requirement** ${e.requirement}`) : "",
    ...e.tiers.map((t) => md(`**${title(t.name)} (Levels ${t.from}–${t.to})**\n\n${t.bullets.map((b) => `- ${b}`).join("\n")}`))
  ].filter(Boolean).join("\n");
}

const NOTE = [
  "Bond it with the Relic Bonding Ritual (a general skill action: the performer's trained Arcana, Nature, Occultism or Religion against the Level DC of the wielder's level; the performer pays 1 PP and 250 gp).",
  "It then awakens one tier at each of the wielder's daily preparations, up to the tier of the wielder's level.",
  "Invest Item asks the tier to invest it at (up to its awakened tier, as the free slots pay: 1 to 5 slots), and only its bonded wielder may invest it; RELIC is one-invested.",
  "Invested, its quality, superior trait and runes are rewritten to that tier, its innate spells are granted (focus trait), and its powers are granted as abilities. Uninvested, it is the plain Dormant item without powers."
].join(" ");

/**
 * THE DORMANT ITEM'S OWN FIGURES (0.17.1, found live): TRG Prime's
 * customisation of the base at the Dormant tier, so the item off the shelf is
 * the item an uninvested relic is rewritten to. A shield's HP only (the weights
 * are printed). verify-block10 holds them against computeFullCustomisation.
 */
export const DORMANT_HP = Object.freeze({ aegisOfValtea: 44 });

const BY_HAND = Object.freeze({
  aegisOfValtea: "Shield of Dawn's denial of concealment and invisibility to Evil-aligned enemies is by hand.",
  emberfang: "",
  obsidianCodex: "The blood sacrifice is the table's (the ritual asks whether it is made). Detect Undead is granted at will (its constant effect, Graham's ruling of 15 November 2026). The +2 HP per level of undead you create or bind, and their advantage on attacks against the living, are card notes (Q217). The whispering lore and the Necrolord's recognition are the GM's.",
  veilshroud: "Tracking you at disadvantage is the tracker's roll, by hand. The planar ripples, the Shadescape disguise and the cloak's semi-sentience (communication only, Q216) are the GM's. Gate is once a day."
});

function relicItem(upper) {
  const spec = RELICS_10[upper];
  const e = BOOK.chapter9.relics.find((r) => r.name === upper);
  if (!e) throw new Error(`Block 10: no relic ${upper} in the book`);
  if (e.tiers.length !== 5) throw new Error(`Block 10: ${upper} prints ${e.tiers.length} tiers`);
  e.tiers.forEach((t, i) => { if (t.from !== TIERS[i].from || t.to !== TIERS[i].to) throw new Error(`Block 10: ${upper}'s ${t.name} prints ${t.from}–${t.to}`); });
  const weight = Number(String(e.fields.Weight).replace(/[^\d.]/g, ""));
  const dormant = relicStateAt(spec, -1);
  const traits = e.traits.map(title).join(", ");
  const description = [printedRelic(e), md(`*Automated (${STAMP}):* ${NOTE}${BY_HAND[spec.key] ? ` ${BY_HAND[spec.key]}` : ""}`)].join("\n");
  const relic = { key: spec.key, wielderUuid: "", wielderName: "", awakened: 0, investedTier: null, refusedUntil: 0 };
  const flags = { [MODULE_ID]: { relic } };
  let system;
  let type = spec.type;
  if (spec.base) {
    const b = BASES[spec.base];
    if (!b) throw new Error(`Block 10: no base ${spec.base}`);
    flags[SYSTEM_ID] = { baseCustomisation: { ...b.base } };
    system = {
      quantity: 1, weight, price: 0, equipped: false, invested: false, hp: { value: DORMANT_HP[spec.key] ?? b.base.hp, max: DORMANT_HP[spec.key] ?? b.base.hp }, traits, description,
      ...b.system, itemLevel: 0, quality: dormant.quality, material: "", superiorTraits: dormant.superior ? dormant.superior.toLowerCase() : "", runes: dormant.runes
    };
  } else {
    type = "gear";
    const held = /held/.test(e.fields.Usage);
    system = {
      quantity: 1, weight, price: 0, equipped: false, invested: false, hp: { value: 0, max: 0 }, traits, description,
      slot: held ? "" : "cloak", uses: { value: 0, max: 0 }, itemSize: "T", itemLevel: 0, heldHands: held ? 1 : 0, formulae: "",
      gearCategory: "Goods", gearCategoryInferred: false, runes: ""
    };
  }
  return {
    _id: stableId(`relics:${spec.name}`), name: spec.name,
    img: type === "weapon" ? "icons/svg/sword.svg" : type === "shield" ? "icons/svg/shield.svg" : spec.key === "veilshroud" ? "icons/svg/mystery-man.svg" : "icons/svg/book.svg",
    type, system, effects: [], folder: null, sort: 0, ownership: { default: 0 }, flags, _stats: { ...STATS }
  };
}

export const RELIC_ITEMS_10 = Object.keys(RELICS_10).map(relicItem);
if (RELIC_ITEMS_10.length !== BOOK.chapter9.relics.length) throw new Error("Block 10: a relic in the book is not in the rules");

/* ------------------------------------------------------------------ */
/* Dawnshield (L10636–10690)                                            */
/* ------------------------------------------------------------------ */

const DAWN_FEAR = { kind: "modifier", value: 2, type: "untyped", label: "Dawnshield", scope: "Saving throws vs fear", auto: true, when: { checkTypes: ["save"], traits: ["fear"] } };

function dawnshieldItem() {
  const lines = BOOK.chapter9.sentient.map((l) => l.text);
  const at = (needle) => {
    const t = lines.find((x) => x.includes(needle));
    if (!t) throw new Error(`Block 10: Dawnshield prints no "${needle}"`);
    return t;
  };
  if (!at("**Level** 15").includes("38,500")) throw new Error("Block 10: Dawnshield's price");
  if (!at("**Ego** 24").includes("Ego DC 34")) throw new Error("Block 10: Dawnshield's Ego");
  if (!at("**ACP** 0").includes("**HP** 110")) throw new Error("Block 10: Dawnshield's statistics");
  const body = lines.slice(lines.indexOf("DAWNSHIELD")).map((l) => (l === "DAWNSHIELD" ? "**DAWNSHIELD**" : l));
  const note = [
    "Sentient: investing it costs two slots (L10441), and SENTIENT is one-invested.",
    "Invested, it grants its wielder the fear aura (you and allies within 10 ft, +2 to saves vs fear; Q214) and Cure once a day as an innate spell (cast at the shield's level 15), and puts an Influence button on the wielder: only the GM presses it (Q218), rolling the wielder's Will save against Ego DC 34 with Dawnshield's own Success, Failure and Fumble. A Failure dims it: its powers are withdrawn until the GM, on the same button, restores them after a protective act.",
    "Its printed +2 DB vs fire is TRG Prime's own Dragonhide shield bonus (a fire dragon's hide). By hand: the constant Light, the revealing light, the darkness-dispelling flare, its senses and its voice."
  ].join(" ");
  const description = [md(body.join("\n\n")), md(`*Automated (${STAMP}):* ${note}`)].join("\n");
  const b = BASES[DAWNSHIELD.base];
  const s = DAWNSHIELD.stats;
  const sentient = {
    key: DAWNSHIELD.key, ego: DAWNSHIELD.ego, egoDC: DAWNSHIELD.egoDC, overrides: { ...DAWNSHIELD.overrides }, dimsOnFailure: true, dimmed: false,
    influenceBlockedUntil: 0, blockedBy: "",
    powers: [{ key: "dawnFear", name: "Dawnshield: Morale-Steadying Light", text: "Wielder and allies within 10 ft gain +2 to saves vs fear (morale-steadying light).", self: [DAWN_FEAR], auras: [{ kind: "ally", radius: 10, name: "Dawnshield", allyEffect: { conditionals: [DAWN_FEAR] } }] }],
    spells: [{ name: "Cure", perDay: 1 }]
  };
  return {
    _id: stableId("relics:Dawnshield"), name: DAWNSHIELD.name, img: "icons/svg/shield.svg", type: "shield",
    system: {
      quantity: 1, weight: DAWNSHIELD.weight, price: DAWNSHIELD.price, equipped: false, invested: false,
      hp: { value: s.hp, max: s.hp }, traits: "Invested, Light, Sentient, Warding", description,
      ...b.system, dr: s.dr, defenceBonus: s.db, penalty: s.penalty,
      itemLevel: DAWNSHIELD.level, quality: DAWNSHIELD.quality, material: "dragonhide", dragonType: "fire", superiorTraits: "", runes: DAWNSHIELD.runes
    },
    effects: [], folder: null, sort: 0, ownership: { default: 0 },
    flags: {
      [SYSTEM_ID]: { specificItem: { runes: [{ key: "potency", label: "Potency", tier: 2, printed: "Potency II" }], runeText: DAWNSHIELD.runes, traits: ["Dragonhide", "Organic", "Master", "Potency II", "+2 DB vs Fire", "Constant Light Spell"], quality: DAWNSHIELD.quality, material: "dragonhide", printedItemBonus: 2 } },
      [MODULE_ID]: { sentient }
    },
    _stats: { ...STATS }
  };
}

export const DAWNSHIELD_ITEM = dawnshieldItem();

export const BLOCK10_PACKS = [
  { name: "ea-relics", label: "Eldritch Arts: Relics & Sentient Items", extends: "specific-items", docs: [...RELIC_ITEMS_10, DAWNSHIELD_ITEM] }
];
