/**
 * Eldritch Arts — Block 8a (0.11.0): the second half of Chapter 8's Grimoire,
 * first part — 22 spells (book v1.6, ea.md): the eight Bindings, three
 * Symbols, and eleven exploration and utility spells.
 *
 * THE SPEC IS docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2 and §4, as Graham
 * answered it on 8 November 2026 (17:22): "As recommended" — Q167–Q184 as
 * each row recommends; seams H12 (the control register for modules), H17
 * (curse-held conditions, and core Remove Curse) and H18 (core Insanity's
 * turn table) built in TRG Prime 3.686.0.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.grimoire`), never retyped. Each card is that text followed by one
 * paragraph saying what TRG Prime does with it, opening with its grade:
 * *Automated, with a choice* (B), *Partly automated* (C: the clause left to
 * the table is named), *Not automated* (D: a card).
 *
 * THE SHAPE IS THE CORE SPELLS PACK'S. The Bindings and Symbols are authored
 * as utility spells with no defence (the audit's §5): their saves are the
 * module's, after the creature appears or the symbol flashes, never the
 * core's cast save against whoever happens to be targeted. What is not data
 * is module/block8a-automations.mjs, found by `flags.trg-prime.eaGrimoire`;
 * the pure rules are module/block8a-rules.mjs.
 *
 * EVERY CHAPTER 8 SPELL IS UNCOMMON (m84). TRADITION "ALL" is the four
 * traditions (as Block 7); the card keeps "all".
 */
import fs from "node:fs";
import { stableId } from "./builders.mjs";
import { build } from "./block3-spells.mjs";
import { ALL_TRADITIONS, GRIMOIRE_AVAILABILITY } from "../../module/block7-rules.mjs";
import {
  BINDINGS, BINDING_RANGE_FEET, LOYAL_BONUS, POUCH_CONCEAL_BONUS, POUCH_CAPACITY_LB, POUCH_WEIGHT_LB, ARCHWAY_SQUARES, ARCHWAY_DB,
  RIFT_DICE, RISERUNE_TRIGGERS
} from "../../module/block8a-rules.mjs";
import { symbolText, SINCE_8A } from "./symbol-text.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const GRIM = new Map(BOOK.grimoire.map((e) => [e.name, e]));

export { SINCE_8A };
const CHOICE = `*Automated, with a choice (${SINCE_8A}):*`;
const PARTLY = `*Partly automated (${SINCE_8A}):*`;
const NOT = "*Not automated:*";
const note = (text, extra = {}) => ({ kind: "note", text, ...extra });

/* ------------------------------------------------------------------ */
/* The Bindings: one model (§4.1)                                       */
/* ------------------------------------------------------------------ */

function binding(key) {
  const b = BINDINGS[key];
  const broken = /broken/i.test(String(GRIM.get(b.name.toUpperCase())?.fields?.Duration ?? ""));
  return {
    key, grade: "B", category: "utility", defence: "",
    effects: [note(`${b.name}: once the cast is settled, the GM places or selects the creature (${b.type}, level ${b.max} or lower, +1 a warp, within ${BINDING_RANGE_FEET} ft) and its Will save is rolled at this cast's Save DC.`)],
    warpMods: [{ bonusValue: 1 }],
    what: `the GM places or selects a creature with the ${b.type} trait, level ${b.max} + warps or lower, within ${BINDING_RANGE_FEET} ft; its Will save at the cast's Save DC (circle and true name in): Critical hostile and the spell ends, Success free, Failure bound (control levels, H12), Fumble bound and +${LOYAL_BONUS} circumstance to its checks; the PP stay locked until it ends (Q170); broken by the DC 20 Will release`,
    text: `${CHOICE} the creature is not invented: TRG Prime ships no stat blocks, so once the cast is settled the GM's card asks for it. The GM places a token for a creature with the ${b.type} trait (the Creature Codex builds one from a type, a class and a level; Fiends & Fables has many) and selects it, or selects one already within ${BINDING_RANGE_FEET} feet. Its trait, its level (${b.max} or lower, +1 per warp bought, no ceiling but your maximum PP per cast, Q169) and the distance are checked, then it rolls its Will save against this cast's Save DC, with a summoning circle's and Ward Twine's bonuses and a true name's +4 in. **Critical** (and Heroic, m42): it arrives enraged and hostile and the spell ends; it stays, and the GM runs it (Q168). **Success**: it appears but acts freely, counts against no control levels, and is sent back when you dismiss the spell. **Failure** (and Partial): it is bound and serves as your minion — recorded against your Control Levels as "Bound" (H12) with a "Bound to you" effect. **Fumble** (and Blunder): bound, and +${LOYAL_BONUS} circumstance to all its checks while it serves you (Q169). A true name invoked and a Success or better: it is permanently hostile to you (Block 2b). A Fumble circle: it arrives hostile and unbound, whatever it rolls. The duration is "Until dismissed${broken ? " or broken" : ""}": the PP stay locked until the spell ends (Q170, TRG Prime 3.686.0). Over your Control Levels, the highest-level creature rolls a DC 20 Will save at the start of each of your turns to break free; breaking free, being dismissed (1 AP), dispelled or counteracted ends the spell, and a bound creature returns to where it was summoned from (Q168, Q169: all eight alike). With Versatile Binder the creature already there is bound instead, by the same save and checks, and released where it stands. *By hand:* the command — a 1 AP verbal command with the auditory and concentrate traits (Q169), spent from your sheet — and the GM removing a returned creature's token.`
  };
}

/* ------------------------------------------------------------------ */
/* The Symbols: one model (§4.3)                                        */
/* ------------------------------------------------------------------ */

const symbolNote = (key) => note(`${key === "symbolOfInsanity" ? "Symbol of Insanity" : key === "symbolOfPain" ? "Symbol of Pain" : "Symbol of Weakness"}: click where you carve it; the GM's card flashes it.`);
const symbolWhat = {
  symbolOfInsanity: "a hidden Region where it is carved; the GM flashes it: every token with line of sight (the GM may untick) is targeted with core Insanity at the symbol's DC — Will, and the d10 each turn for 1 round per 2 failed by (H18); glows for 10 minutes after the last sight",
  symbolOfPain: "a hidden Region where it is carved; the GM flashes it: Fortitude — unaffected / injured 2 / injured 4, held by the curse while within 60 ft and 1 hour after (H17), only Remove Curse ends it sooner (Q183)",
  symbolOfWeakness: "a hidden Region where it is carved; the GM flashes it: Fortitude — unaffected / weakened 1 / 2 / 4 / 6, held by the curse while within 60 ft and 1 hour after (H17), only Remove Curse ends it sooner (Q183)"
};

/* ------------------------------------------------------------------ */
/* The 22                                                               */
/* ------------------------------------------------------------------ */

const SPEC = {
  "ANIMAL BINDING": binding("animalBinding"),
  "ELEMENTAL BINDING": binding("elementalBinding"),
  "ENTITY BINDING": binding("entityBinding"),
  "ETERNAL BINDING": binding("eternalBinding"),
  "FEY BINDING": binding("feyBinding"),
  "PLANT BINDING": binding("plantBinding"),
  "UNDEAD BINDING": binding("undeadBinding"),
  "WYRM BINDING": binding("wyrmBinding"),

  "SYMBOL OF INSANITY": { key: "symbolOfInsanity", grade: "B", category: "utility", defence: "", effects: [symbolNote("symbolOfInsanity")], what: symbolWhat.symbolOfInsanity, text: symbolText("symbolOfInsanity") },
  "SYMBOL OF PAIN": { key: "symbolOfPain", grade: "B", category: "utility", defence: "", effects: [symbolNote("symbolOfPain")], what: symbolWhat.symbolOfPain, text: symbolText("symbolOfPain") },
  "SYMBOL OF WEAKNESS": { key: "symbolOfWeakness", grade: "B", category: "utility", defence: "", effects: [symbolNote("symbolOfWeakness")], what: symbolWhat.symbolOfWeakness, text: symbolText("symbolOfWeakness") },

  "ARCANE POUCH": {
    key: "arcanePouch", grade: "C", category: "utility", targetsObject: true,
    effects: [
      { kind: "conditional", label: "Arcane Pouch", target: "self", grants: [{ kind: "modifier", value: POUCH_CONCEAL_BONUS, type: "circumstance", label: "Arcane Pouch", scope: "Conceal an Object checks to conceal the pouch's contents", when: { checkTypes: ["skill"], actions: ["concealAnObject"] } }] },
      note(`The pouch holds up to ${POUCH_CAPACITY_LB} pounds and always weighs ${POUCH_WEIGHT_LB} pounds — by hand. It spills its contents if it leaves your possession, the duration expires, or you create a new arcane pouch.`)
    ],
    warpMods: [{ durationText: "until next daily preparation" }],
    what: `an object, not a creature; +${POUCH_CONCEAL_BONUS} circumstance to your Conceal an Object checks (a tick) for the duration; a new casting ends the last; it teleports nobody (no Spatial Awareness card); the 50 lb and 3 lb by hand`,
    text: `${PARTLY} the spell targets the pouch, not a creature (TRG Prime 3.685.1's object target). For 8 hours (to your next daily preparation with the +2 PP option, which locks the PP until then as the core reads it), your Conceal an Object checks offer a +${POUCH_CONCEAL_BONUS} circumstance bonus as a tick — tick it when concealing the pouch's contents. Casting a new arcane pouch ends the last one's bonus. It carries the Teleportation trait but moves nobody, so no Spatial Awareness card is posted at the cast. *By hand:* what the pouch holds (${POUCH_CAPACITY_LB} pounds, always weighing ${POUCH_WEIGHT_LB} pounds — TRG Prime's inventory has no containers) and its spilling when it leaves your possession.`
  },
  "ARCHWAY OF ANTS": {
    key: "archwayOfAnts", grade: "C", category: "utility", area: "",
    effects: [note("Click each 5-ft square of the archway in turn (within 30 ft); Escape ends early.")],
    warpMods: [{ bonusValue: 1 }],
    what: `you click its ${ARCHWAY_SQUARES} squares (+1 a warp) within 30 ft: a Region labelled DB ${ARCHWAY_DB}, HP equal to your maximum HP, and the load (10 × your Weight Allowance), for 10 minutes; a GM button crumbles it; moving it and the load by hand`,
    text: `${PARTLY} after the cast you click the archway's squares one at a time, ${ARCHWAY_SQUARES} of them (+1 for each +2 PP option bought), each within 30 feet. They make one Region for the 10 minutes, labelled with its DB ${ARCHWAY_DB}, its HP (your maximum HP at the cast) and the load it bears (10 × your Weight Allowance, the core's 50 + Strength × 10). The GM's card has **The archway crumbles**, which removes it. *By hand:* its shape (bridge, wall, ladder, stairs), moving it, the weight on it and the damage it takes.`
  },
  "ARGENT MARK": {
    key: "argentMark", grade: "C", category: "utility", targetsObject: true,
    effects: [note("Choose what you brand: a creature within reach (willing, m96) or an object you name.")],
    warpMods: [{ durationText: "1 month" }, { durationText: "1 year" }, { durationText: "permanent" }],
    what: "a creature within touch (willing only, m96) or a named object; 1 week, 1 month, 1 year or permanent (permanent locks the PP until dismissed, Q170); a button on your card gives its direction and distance on the same scene",
    text: `${PARTLY} after the cast you choose what you brand: a creature within reach (willing only: "a Utility spell so no unwilling targets", m96), which carries an "Argent Mark" effect for the duration, or an object, which you name. The mark lasts 1 week (1 month, 1 year or permanent by the warps; take one — the longest bought applies; a permanent mark locks the PP until it is dismissed, Q170). Your card has **Where is the mark?**: on the same scene it gives the mark's direction and distance from you. *By hand:* a creature's willingness, the mark's direction and distance on another scene or map ("while on the same plane"), and the silvery glyph seen only under moonlight or by you.`
  },
  "BLOOD BIOGRAPHY": {
    key: "bloodBiography", grade: "C", category: "utility", defence: "",
    effects: [note("The GM's card rolls the blood's owner's Will save, if it is living or undead; the four answers are the GM's.")],
    what: "the GM's card: when the blood's owner is living or undead, its Will save at your Save DC (Success or better blocks the spell; M35); otherwise no save; the four answers are the GM's",
    text: `${PARTLY} once cast, the GM's card asks about the blood's owner. If it is living or undead, the GM selects its token and its Will save is rolled against this cast's Save DC: Success or better blocks the spell (M35). If it is dead (and not undead), there is no save. Otherwise the four questions appear on your card for the GM to answer. *By hand:* the answers, and a save rolled by hand when the creature is not on the map.`
  },
  FARSIGHT: {
    key: "farsight", grade: "D", category: "utility",
    effects: [note("You see details clearly up to 1 mile away; walls and dense foliage still block your vision — the table's.")],
    warpMods: [{ durationText: "1 hour" }],
    what: "card only (the 1-hour warp sets the duration)",
    text: `${NOT} seeing up to a mile is the table's. The +2 PP option sets the duration to 1 hour.`
  },
  "HARMONIC RIFT": {
    key: "harmonicRift", grade: "B", category: "utility", area: "",
    effects: [note("Click the two openings, each within 500 ft and in your sight.")],
    warpMods: [{ damageDice: "1d8" }, { durationText: "10 minutes" }],
    what: `you click two 5-ft openings within 500 ft in your line of sight: a token ending a move in one steps out of the other; each passage is a teleport (the Spatial Awareness card; a second in a turn fails); an enemy of yours passing rolls basic Fortitude against ${RIFT_DICE} sonic (+1d8 a warp); 1 minute (10 warped)`,
    text: `${CHOICE} after the cast you click the two 5-foot openings, each within 500 feet and in your line of sight. For 1 minute (10 minutes with the +2 PP option), a token that ends a move in one opening steps out of the other: each passage is a teleportation effect on whoever passes (the core's "Teleported — Spatial Awareness" card; a second teleport in a turn fails). An enemy of yours passing rolls a basic Fortitude save at this cast's Save DC against ${RIFT_DICE} sonic damage (+1d8 per +1 PP option). The cast itself teleports nobody, so no card is posted for you at the cast.`
  },
  "PHASE DOOR": {
    key: "phaseDoor", grade: "D", category: "utility",
    effects: [note("The passage, who may use it, and its dispelling are the table's.")],
    what: "card only",
    text: `${NOT} the ethereal passage, who passes through it and its dispelling are the table's (R12).`
  },
  "RIPPLING GAZE": {
    key: "ripplingGaze", grade: "D", category: "utility",
    effects: [note("Requirement: you are touching a body of water. Scrying through flowing water is the table's; shifting your viewpoint is a 1 AP Concentrate action (m125).")],
    what: "card only (the Requirement shown on the cast)",
    text: `${NOT} the scrying is the table's. The Requirement ("you are touching a body of water") is shown on the cast. "Sustain the spell to shift your viewpoint" is read as a 1 AP Concentrate action (m125); a Search (Perception) against your Save DC spots your face in the water.`
  },
  RISERUNE: {
    key: "riserune", grade: "C", category: "utility", targetsObject: true,
    effects: [note("Click the surface you inscribe (within reach).")],
    what: `a hidden 10-ft Region where you inscribe it, for 1 hour: a Small or larger token ending a move within it is recorded (name, image, time; up to ${RISERUNE_TRIGGERS}); your card's button replays them when you are within reach; disarming by hand`,
    text: `${PARTLY} after the cast you click the surface you inscribe, within reach. For the hour, a hidden 10-foot Region records each Small or larger creature whose token ends a move within it — its name, image and the world time — up to ${RISERUNE_TRIGGERS} triggers, after which the rune stores no more. Your card has **Replay the rune**: within reach of it, the stored echoes are shown to you alone. *By hand:* the "brief image and sound echo" itself, magical detection of the rune, and disarming it (Spellcraft or Thievery against your Save DC).`
  },
  "TRAVELLER’S CHARM": {
    key: "travellersCharm", grade: "D", category: "utility", targetsObject: true,
    effects: [note("The wearer travels at twice normal speed on long journeys without fatigue, and needs no food or water — the table's.")],
    what: "card only (an object target; one charm per warp)",
    text: `${NOT} TRG Prime has no overland travel; the doubled journey speed and going without food or water are the table's. The spell targets the item (an object). One more charm per +2 PP option.`
  },
  "WALL OF SAND": {
    key: "wallOfSand", grade: "C", category: "utility",
    effects: [
      { kind: "wall", target: "area", length: 20, height: 10, thickness: "1 inch", snap: "border", block: { move: "none", sight: "limited", light: "none", sound: "none" }, unobstructed: true, sections: { size: 5, db: 0, hardness: 5, hp: 20 } },
      note("Crossing costs double movement and obscures vision; it blocks line of effect and mundane projectiles; immune to critical hits and precision damage; a destroyed part reforms at the start of your next turn — by hand.")
    ],
    warpMods: [{ wallHp: 5 }, { wallLength: 10 }],
    // "+2 PP: increase the length of the wall by 10 feet OR its height by 5
    // feet" (the Block 8a review): the one printed option, offered as its two
    // choices — each +2 PP, each bought as often as the option (TRG Prime
    // 3.686.0's wallHeight).
    splitWarp: { index: 1, choices: [
      { text: "increase the length of the wall by 10 feet (this option's first choice)", mods: { wallLength: 10 } },
      { text: "increase the height of the wall by 5 feet (this option's other choice, in place of the length)", mods: { wallHeight: 5 } }
    ] },
    what: "the core's wall: 20 × 10 ft along the borders, sight limited (concealment behind it), not blocking movement; sections DB 0, Hardness 5, HP 20 (+5 a warp); +10 ft long or +5 ft high a warp, the caster's choice; crossing cost, line of effect, projectiles and reforming by hand",
    text: `${PARTLY} the core's wall (as Wall Of Stone): 20 feet long and 10 high, drawn along the borders between squares, limiting sight (concealment for those behind it) and not blocking movement. Each 5-foot section has DB 0, Hardness 5 and 20 HP (+5 per +2 PP option). The other +2 PP option is offered as its two choices: 10 feet more length, or 5 feet more height. *By hand:* crossing it costs double movement and obscures vision, it blocks line of effect and mundane projectiles, it is immune to critical hits and precision damage, its HP (tracked by hand, R9), and a destroyed part reforming at the start of your next turn.`
  }
};

/** One spell, from its book entry and its spec, in Block 3a's `build()` (as Block 7). */
function buildGrimoire(name) {
  const entry = GRIM.get(name);
  if (!entry) throw new Error(`Block 8a: no Grimoire spell "${name}" in the book`);
  const spec = SPEC[name];
  const doc = build(entry, { effects: [], ...spec }, { specialist: false });
  const sys = doc.system;
  if (spec.area !== undefined) sys.area = spec.area;
  // ONE PRINTED OPTION, TWO CHOICES (Wall of Sand): the option's cost, once per choice.
  if (spec.splitWarp) {
    const w = sys.warps[spec.splitWarp.index];
    if (!w) throw new Error(`Block 8a: ${doc.name} has no warp ${spec.splitWarp.index} to split`);
    sys.warps.splice(spec.splitWarp.index, 1, ...spec.splitWarp.choices.map((c) => ({ ppCost: w.ppCost, text: c.text, mods: { ...c.mods } })));
  }
  if (/^all$/i.test(String(entry.fields.Tradition ?? "").trim())) sys.tradition = ALL_TRADITIONS;
  sys.availability = GRIMOIRE_AVAILABILITY;
  doc.flags = { ...doc.flags, "trg-prime": { ...(doc.flags?.["trg-prime"] ?? {}), eaGrimoire: spec.key, ...(spec.targetsObject ? { targetsObject: true } : {}) } };
  if (doc._id !== stableId(`spells:${doc.name}`)) throw new Error(`Block 8a: ${doc.name}'s id drifted`);
  return doc;
}

export const BLOCK8A_NAMES = Object.freeze(Object.keys(SPEC));
export const SPELLS_B8A = BLOCK8A_NAMES.map(buildGrimoire);

/** What each of the 22 does in TRG Prime, for the docs and the harness. */
export const SPELL_AUTOMATION_B8A = Object.freeze(Object.fromEntries(BLOCK8A_NAMES.map((n, i) => [SPELLS_B8A[i].name, Object.freeze({ grade: SPEC[n].grade, what: SPEC[n].what, key: SPEC[n].key })])));

if (SPELLS_B8A.length !== 22) throw new Error(`Block 8a: ${SPELLS_B8A.length} spells, expected 22`);
