/**
 * Eldritch Arts — Block 8b (0.12.0): the second half of Chapter 8's Grimoire,
 * second part — 17 spells (book v1.6, ea.md): the ten rituals and the seven
 * High Magic spells tied to Chapter 7.
 *
 * THE SPEC IS docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md §3.2, §4.2 and §4.4, as Graham
 * answered it on 8 November 2026 (17:22): "As recommended" — Q170–Q182 as each
 * row recommends; seams H13 (a ritual's Partial casts), H14 (a ritual by its
 * primary alone), H15 (rest rates) and H16 (a rolled, turn-start, following
 * storm) built in TRG Prime 3.687.0.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.grimoire`, its Cost now a field: the extractor reads "Cost" from
 * 0.12.0), never retyped. Each card is that text followed by one paragraph
 * saying what TRG Prime does with it, opening with its grade.
 *
 * THE RITUALS ARE UTILITY SPELLS WITH NO CORE EFFECT ROWS: what each rung does
 * is module/block8b-automations.mjs, applied once the ritual's casting is
 * settled. Storm of Unmaking is the core's `storm` row (H16). Every Chapter 8
 * spell is uncommon (m84).
 */
import fs from "node:fs";
import { stableId } from "./builders.mjs";
import { build } from "./block3-spells.mjs";
import { ALL_TRADITIONS, GRIMOIRE_AVAILABILITY } from "../../module/block7-rules.mjs";
import { UNLOCK, UNMAKING_STORM, MIMIC_PP, CONFLUENCE_WILL_BONUS, ANCHOR_BONUS } from "../../module/block8b-rules.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const GRIM = new Map(BOOK.grimoire.map((e) => [e.name, e]));

export const SINCE_8B = "0.12.0, TRG Prime 3.687.0";
const CHOICE = `*Automated, with a choice (${SINCE_8B}):*`;
const FULL = `*Automated (${SINCE_8B}):*`;
const PARTLY = `*Partly automated (${SINCE_8B}):*`;
const NOT = "*Not automated:*";
const note = (text) => ({ kind: "note", text });
const RITUAL = "Performed as a Magic Ritual (Magic Ritual on the spell; never as a standard casting, Q8), its cap at Success lifted (M30).";
const PARTIAL = "Its printed Partial takes effect with no PP lost (Q171, H13)";
const COST = "Its Cost is checked before the roll and taken whatever the degree (Q174)";
const TICK = "The ritual dialog ticks who takes part: the secondary casters entered (they share a failure's damage, each at its own level DC — C3, Q173)";

const SPEC = {
  /* ------------------------------ rituals ------------------------------ */
  "ARMY OF THE GRAVE": {
    key: "armyOfTheGrave", area: "", grade: "B", category: "utility", defence: "",
    effects: [note("Once settled, the GM places the undead and selects them; they are counted (one per corpse, levels to the PP) and controlled.")],
    warpMods: [{ unlocks: [UNLOCK.armyHalf] }, { unlocks: [UNLOCK.armyPermanent], durationText: "permanent" }],
    what: "a ritual; the GM selects the undead within 300 ft: one per corpse (PP ÷ 2), levels ≤ PP (halved with +4 PP), recorded on your Control Levels; 1 month / 1 week / Partial half for 1 day (the GM ticks which); Failure or worse all hostile and 2d10 / 4d10 / 8d10 essence to every caster; +6 PP permanent, the site marked Evil and tainted",
    text: `${CHOICE} ${RITUAL} ${TICK}. ${COST}: the corpses are counted on the card (one intact corpse per 2 PP spent, consumed — removed by hand). Once settled, the GM places the undead within 300 feet and selects them; the module checks each has the undead trait, that there is no more than one per corpse, and that their levels total no more than the PP expended (each counted at half with the +4 PP option, level 0 counting nothing — Q175). **Critical** (and Heroic, m42): all are recorded against your Control Levels for 1 month; **Success** 1 week; **Partial** ("replaces the normal partial result", ${PARTIAL.toLowerCase()}): half of them (rounded down, the GM ticks which) for 1 day, the rest uncontrolled and hostile. **Failure**, **Fumble**, **Blunder**: none rise under control; every caster takes 2d10 / 4d10 / 8d10 essence (basic Fortitude). The +6 PP option makes it permanent (the PP stay locked until it ends, Q170) and marks the ritual site Evil and tainted by the Shadescape. *By hand:* which undead you have studied (skeletons and zombies are free), the corpses, and the command — one 1 AP command (auditory, concentrate) gives them all the same action (Q175).`
  },
  "CALL OF THE ANCESTORS": {
    key: "callOfTheAncestors", area: "", grade: "C", category: "utility", defence: "",
    effects: [note("The shades' answers are the GM's; the card says how many questions and how clear.")],
    warpMods: [{ bonusValue: 1 }],
    what: "a ritual; the card gives the number of questions (3, +1 a warp, max 10) and how they come; Critical: one participant's held advantage on one check within 24 hours; Partial: one answer misleading; Failure or worse: 1d6 / 2d6 / 4d6 mental to every caster (basic Fortitude), a Blunder's possession the GM's",
    text: `${PARTLY} ${RITUAL} ${TICK}, and the other creatures taking part. ${COST} (200 gp). The card gives the number of questions — 3, +1 for each +2 PP option, at most 10 — and how the answers come: **Critical** (and Heroic) clear, and one participant you choose gains advantage on a single check within 24 hours (an effect, ticked on the check); **Success** truthful but symbolic; **Partial** one answer is misleading (${PARTIAL.toLowerCase()}). **Failure**, **Fumble**, **Blunder**: every caster takes 1d6 / 2d6 / 4d6 mental damage (basic Fortitude, as printed — m101). *By hand:* the questions and the answers, and the Blunder's hostile spirit possessing a participant.`
  },
  "CONCORD OF STONE": {
    key: "concordOfStone", area: "", grade: "C", category: "utility", defence: "",
    effects: [note("Once settled, a Region around the ritual site: allies inside +2 circumstance to DB; structures' DR by hand.")],
    warpMods: [{ unlocks: [UNLOCK.concordDouble] }, { unlocks: [UNLOCK.concordPermanent], durationText: "permanent" }],
    what: "a ritual; a 120-ft Region around the site (240 with +4 PP): your allies inside +2 circumstance to DB while inside; structures DR 5 (Critical 10, Partial 2) labelled, by hand; 1 month / 6 months / 1 week, permanent with +6 PP; Failure 2d6 and Blunder 8d6 essence to the primary; Cost 100 gp per PP as cast",
    text: `${PARTLY} ${RITUAL} ${TICK}. ${COST}: 100 gp per PP as cast, warps included. Once settled, a Region of a 120-foot radius around the ritual site (your token; 240 feet with the +4 PP option): your allies (and you) defending within it gain +2 circumstance to DB while they stand there. **Success** (the base, M38): structures DR 5, for 1 month; **Critical** (and Heroic): DR 10, 6 months; **Partial**: DR 2, 1 week (${PARTIAL.toLowerCase()}); the +6 PP option makes it permanent (the PP stay locked until it ends, Q170). **Failure** (and Fumble, m42): the primary takes 2d6 essence (basic Fortitude; "primary casters", M38); **Blunder** 8d6. *By hand:* the structures' DR — TRG Prime gives objects no DR row; the Region's name carries it.`
  },
  "ELEMENTAL CONVERGENCE": {
    key: "elementalConvergence", area: "", grade: "B", category: "utility", defence: "",
    effects: [note("Once settled, the zone: each creature within chooses an element — resistance, and a strike rider of it.")],
    warpMods: [{ unlocks: [UNLOCK.convergenceMile] }, { durationText: "1 week" }],
    what: "a ritual the primary may perform alone (H14); a 500-ft emanation (1 mile with +4 PP), 24 hours (1 week): each creature within picks fire, cold, electricity or acid — resistance and +1d6 (Critical 2d6) secondary damage of it on weapon and unarmed Strikes, an effect it may switch off; Failure (and Partial) or worse 2d6 / 4d6 / 8d6 basic Reflex to every caster, of the element each chose; the weather the GM's",
    text: `${CHOICE} ${RITUAL} It prints no secondary casters, so the primary may perform it alone (with no PP over the maximum; Q172, H14); secondaries may still join. Once settled, the Elemental Convergence Zone: a 500-foot emanation from you (1 mile with the first +4 PP option) for 24 hours (1 week with the second). Each creature within is asked, through its owner, for an element — fire, cold, electricity or acid — and gains resistance to it and +1d6 secondary damage of it on its weapon and unarmed Strikes (**Critical** and Heroic: 2d6), as an effect it may switch off ("can choose"); leaving the zone switches it off, coming back on. **Failure** (and Partial — no Partial is printed, so m42 makes it the Failure, with no PP lost, Q171), **Fumble**, **Blunder**: every caster takes 2d6 / 4d6 / 8d6 damage of the element that caster chose (basic Reflex, M42). *By hand:* the offerings and altar, and the volatile weather (GM discretion).`
  },
  "ESSENCE REFORGING": {
    key: "essenceReforging", grade: "C", category: "utility", defence: "",
    effects: [note("Once settled, choose the use: remove a curse or transformation (the GM confirms), restore life, or change race (both by hand).")],
    what: "a High Magic ritual the primary may perform alone (H14) on one willing creature within 30 ft; Success works, failure does not (M45); remove a permanent curse or transformation of equal or lower PP (picked from its effects, the GM's button removes it); restore life as Resurrection and change race by hand (Q176); a Fumble or Blunder: 1d8 force per target level to you and the target; Cost 200 gp × its level",
    text: `${PARTLY} ${RITUAL} A High Magic ritual (Hard, Q14) the primary may perform alone (Q172, H14). Target the one creature before the ritual: its level sets the Cost (200 gp × its level), checked before the roll and taken whatever the degree (Q174). It has no ladder: Success (or better) works, and anything less does not (M45). Once it works, choose the use. **Remove**: its effects of PP no higher than this casting's are listed; pick the permanent curse or transformation, and the GM's button removes it (it is counteracted automatically). **Restore life** (Q176, as Resurrection, without its level limit and Cost): dead no longer than 7 days, it returns with 1 HP and 0 PP, injured 2 for a week (which nothing reduces) and its Death State 1 lower, and a failed attempt cannot be retried — *by hand*: TRG Prime applies Resurrection's consequences only from Resurrection's own effect row. **Change race**: *by hand* — the GM rebuilds its race as for a new character. A **Fumble** or **Blunder**: after the ritual's own failure, you and the target take 1d8 force damage per its level.`
  },
  "ETERNAL INVOCATION": {
    key: "eternalInvocation", area: "", grade: "B", category: "utility", defence: "",
    effects: [note("Once settled, place the flame; creatures within a mile sharing or opposing your aligned traits are marked.")],
    what: "a ritual the primary may perform alone (H14); Success works (M45); you place the 10-ft flame (a light); within 1 mile, creatures sharing your aligned traits: HP and PP recovery doubled (H15), advantage on crafting and Spellcraft (casting checks too, Q177), and a save tick; opposed: halved, and disadvantage on the same; permanent until dispelled (the PP locked, Q170); Cost 10,000 gp",
    text: `${CHOICE} ${RITUAL} It prints no secondary casters, so the primary may perform it alone (Q172, H14). ${COST} (10,000 gp; the brazier and the holy or unholy water by hand). It has no ladder: Success works, anything less does not (M45). Once it works you place the 10-foot eternal flame (a light on the map); it lasts "permanent until dispelled", and its PP stay locked until it is (Q170). Every creature within a mile is marked as it is found there, and unmarked when it leaves. One that shares your aligned traits: double natural HP recovery and double PP recovery (TRG Prime 3.687.0's rest rates, H15), advantage on crafting checks and on Spellcraft checks (casting checks too, Q177), and advantage on saving throws against creatures with an opposed aligned trait (offered as a tick on the save). One of an opposed aligned trait: half recovery and disadvantage on the same three. *By hand:* that the flame cannot be extinguished.`
  },
  "RITE OF BINDING OATH": {
    // targetsObject: the core asks for no creature; the participants are taken from the rite (found live).
    key: "riteOfBindingOath", grade: "B", category: "utility", defence: "", targetsObject: true,
    effects: [note("Once settled, the oath on its targets; the GM's card has Oath broken for each.")],
    warpMods: [{ extraTargets: 1 }, { damageDice: "1d6" }],
    what: "a ritual; its targets (up to 10 willing, +1 a warp) are sworn for 1 year (Critical, double damage) / 1 month / Partial half (the GM ticks) 1 month; the GM's Oath broken: 2d6 (+1d6 a warp) essence, basic Fortitude at your Save DC, and disadvantage on all rolls for 24 hours; Failure or worse 2d6 / 4d6 / 8d6 essence to every caster",
    text: `${CHOICE} ${RITUAL} ${TICK}; the participants are its targets (up to 10 willing creatures, +1 for each first +1 PP option — Q173): the casters and the creatures ticked in the ritual dialog, with nothing to target when casting. ${COST} (250 gp). **Critical** (and Heroic): the oath lasts 1 year, and an oath breaker takes double damage; **Success**: 1 month; **Partial**: half the targets (rounded down, the GM ticks which) for 1 month (${PARTIAL.toLowerCase()}). Each sworn creature carries the oath as an effect, and the GM's card has **Oath broken** for each: 2d6 essence (+1d6 per second +1 PP option; the whole doubled on a Critical), basic Fortitude at this cast's Save DC, and disadvantage on all rolls for 24 hours. **Failure**, **Fumble**, **Blunder**: the ritual collapses, and every caster takes 2d6 / 4d6 / 8d6 essence (basic Fortitude). *By hand:* the oath's words, and whether it was broken.`
  },
  "RITE OF ECHOED SHADOWS": {
    key: "riteOfEchoedShadows", area: "", grade: "B", category: "utility", defence: "",
    effects: [note("Once settled, the echo: participants within have advantage on Stealth; an enemy's first entry, a penalty to attacks.")],
    warpMods: [{ durationText: "1 week" }, { unlocks: [UNLOCK.echoInvisible] }],
    what: "a ritual; a 60-ft Region (Critical 300 ft, Partial 30 ft) for 1 day (Partial 1 hour; 1 week with +4 PP): participants inside have advantage on Stealth (invisible with +6 PP, and 4d6 essence on leaving); an enemy's first entry −2 circumstance to attacks for 1 minute (Critical −4); Failure a Shadow per caster, a Blunder's entity, the GM's",
    text: `${CHOICE} ${RITUAL} ${TICK}, and the other creatures taking part (the participants, with the casters). ${COST} (50 gp). Once settled, a Region of a 60-foot radius around the ritual site for 1 day (1 week with the +4 PP option): each participant within it has advantage on Stealth checks (an effect while inside); an enemy of yours entering it for the first time takes −2 circumstance to attack checks for 1 minute. **Critical** (and Heroic): 300 feet, −4; **Partial**: 30 feet, 1 hour (${PARTIAL.toLowerCase()}). The +6 PP option: participants are invisible while within it, and one leaving takes 4d6 essence (basic Fortitude, at its own level DC). **Failure** (and Fumble, m42): "one Shadow appears for every ritual caster and attacks" — a card with the count (a Shadow is Fiends & Fables', M54); **Blunder**: a card naming the entity's level (the ritual's PP + 4). *By hand:* placing the Shadows or the entity.`
  },
  "SUN’S BENEDICTION": {
    key: "sunsBenediction", area: "", grade: "B", category: "utility", defence: "",
    effects: [note("Once settled, up to 6 (20) participants within 30 ft heal, lower a condition and are blessed against fear.")],
    warpMods: [{ bonusValue: 1 }, { unlocks: [UNLOCK.sunInjured] }, { unlocks: [UNLOCK.sunTwenty] }, { unlocks: [UNLOCK.sunLong] }],
    what: "a ritual; up to 6 participants within 30 ft of you (20 with +6 PP) regain 2d8+3 HP (Critical 4d8+6; +1d8+1 a warp), each lowering one of dazed, fatigued, sickened or weakened by 1 (+1 a warp; injured with +4 PP), and +2 status to saves against fear for 1 hour (Critical 24 hours; 1 week / 1 month with +6 PP); Partial half healing only; Failure or worse no healing, 1d6 / 2d6 / 4d6 essence to every caster",
    text: `${CHOICE} ${RITUAL} ${TICK}, and the other creatures taking part (the participants, with the casters; Q173). ${COST} (250 gp). Up to 6 participants within 30 feet of the ritual focus (you; 20 with the first +6 PP option) each regain 2d8+3 HP (**Critical** and Heroic: 4d8+6; +1d8+1 for each first +4 PP option), lower one of dazed, fatigued, sickened or weakened by 1 (asked of each; +1 for each first +4 PP option; injured joins the list with the second; a condition held by a curse does not lower), and gain +2 status to saving throws against fear for 1 hour (**Critical**: 24 hours; with the second +6 PP option 1 week, or 1 month on a Critical). **Partial** (${PARTIAL.toLowerCase()}): "Half healing only" — half the healing, and no condition lowered and no blessing. **Failure**, **Fumble**, **Blunder**: no healing, and every caster takes 1d6 / 2d6 / 4d6 essence (basic Fortitude).`
  },
  "VEIL SEVERING": {
    key: "veilSevering", area: "", grade: "C", category: "utility", defence: "",
    effects: [note("Once settled, the portal is marked on the map for the degree's duration; travel through it is the table's.")],
    warpMods: [{ unlocks: [UNLOCK.veilLarger] }, { unlocks: [UNLOCK.veilLong] }],
    what: "a ritual; a 30-ft portal marker for 1 year / 1 month / 1 week / Partial 1 day (with +2 PP: permanent / 1 year / 1 month / 1 week); it teleports nobody at the cast; Failure or worse 4d6 / 8d6 / 12d6 essence to every caster, a Blunder's entity the GM's; travel by hand",
    text: `${PARTLY} ${RITUAL} ${TICK}. ${COST} (2,000 gp). Once settled, the two-way portal is marked on the map (a 30-foot radius around the ritual focus) for its degree's duration: **Heroic** 1 year, **Critical** 1 month, **Success** 1 week, **Partial** 1 day (${PARTIAL.toLowerCase()}); with the second +2 PP option permanent, 1 year, 1 month and 1 week. It carries the Teleportation trait but teleports nobody at the cast (no Spatial Awareness card). **Failure**, **Fumble**, **Blunder**: every caster takes 4d6 / 8d6 / 12d6 essence (basic Fortitude); a Blunder's hostile planar entity (at least EL 18) is the GM's. *By hand:* the plane or Luminex it opens on, who steps through, and the larger creatures of the first +2 PP option.`
  },

  /* ------------------------------ High Magic --------------------------- */
  "ALTER CORPSE": {
    key: "alterCorpse", grade: "D", category: "utility", targetsObject: true,
    effects: [note("Decompose or Restore, chosen as it is cast; the corpse is the table's.")],
    what: "card only: the use (Decompose or Restore) chosen at the cast; an object target",
    text: `${NOT} the spell targets the corpse (an object). The use — Decompose or Restore — is chosen as it is cast and said on the card; the corpse itself is the table's.`
  },
  "CHAOS SHIELD": {
    key: "chaosShield", grade: "B", category: "utility",
    effects: [note("While you sustain it: a surge within the aura may be nullified (2 PP, a reaction, once a round); else allies roll twice and pick, its damage to them halved, its saves at DC −2.")],
    warpMods: [{ areaOverride: "60-foot emanation" }],
    what: "a 30-ft aura (60 with +2 PP) while sustained: a wild surge within it offers you 2 PP as a reaction to nullify it (once per round); else an ally (you too) rolls the Wild Surge table twice and picks, the row's damage to allies inside halved and its saves at DC −2 (Q178); Wild Power's area disadvantage cancels against it",
    text: `${CHOICE} for the minute you sustain it, a 30-foot aura around you (60 feet with the +2 PP option). When a wild surge would occur within it — a Wild Magic area's, the Wild birthright's or Wild Power's — you are offered a reaction: spend 2 PP to nullify it entirely, once per round. If you do not, a surging ally of yours (you included, Q178) rolls the Wild Surge table twice and takes the result it prefers; the row's damage to your allies inside is halved ("resistance to wild surge backlash", Q178) and its saves are made at DC −2. Wild Power's disadvantage in a Wild Magic area and the shield's two rolls cancel out: one roll. *By hand:* "hostile spell warp effects", which name no rule (Q178).`
  },
  "LEYLINE ANCHOR": {
    key: "leylineAnchor", grade: "B", category: "utility", targetsObject: true,
    effects: [note("Choose the ley line within 1 mile; casters within 300 ft of you gain the bonus; High Magic costs 1 PP less there; another's Tap or Channel must beat your Save DC + 5.")],
    warpMods: [{ durationText: "1 hour" }, { durationText: "24 hours" }],
    what: "a ley line Region within 1 mile is anchored for 10 minutes (1 hour / 24 hours): casters within 300 ft of you +1 circumstance to Spellcraft and Power Recovery (Meditation); High Magic spells cast there pay 1 PP less (min 1; payment only, Q179); another caster's Tap or Channel Ley Line on it first rolls Power Manipulation against your Save DC + 5, a failure stopping it (Tap's 1 AP spent)",
    text: `${CHOICE} you choose the ley line, one of Block 2's within 1 mile (that you are aware of: the GM's say). For 10 minutes (1 hour or 24 hours with the options), casters within 300 feet of you (a circle that moves with you) gain +${ANCHOR_BONUS} circumstance to Spellcraft checks and to Power Recovery (Meditation) checks. A High Magic spell cast within that radius pays 1 PP less, never below 1; its casting DC, Save DC and cap read the PP as cast (payment only, Q179). Another caster's Tap Ley Line or Channel Ley Line on the anchored line first rolls Power Manipulation against your Save DC + 5: a failure stops the attempt and spends its action (Tap's 1 AP in combat; M45, Q179). *By hand:* "fixed in its current state" — Block 2's ley lines have a level and nothing else to fix.`
  },
  "MIMIC SPELL": {
    key: "mimicSpell", grade: "B", category: "utility",
    effects: [note("A reaction: offered when a spellcaster you can see within 60 ft begins casting. Spellcraft against its casting DC; an imprint to cast with your own PP.")],
    warpMods: [{ unlocks: [UNLOCK.mimicHold] }],
    what: `a cast reaction, offered when a caster you can see within 60 ft casts (you need ${MIMIC_PP} PP and a reaction; never stops the cast): Spellcraft against its casting DC (10 + 1.5 × its PP); Critical an imprint for 1 minute (10 with +2 PP), Success for your next turn (1 minute), Fumble 1d6 essence per PP (basic Will); the imprint is cast from your sheet with your own PP — below 0 allowed, at 5 Soul Drain each; no imprint above your maximum PP per cast (M48) or of a Ritual spell; the original's warps and metamagic by hand`,
    text: `${CHOICE} it is not cast from your sheet: when a spellcaster you can see within 60 feet begins casting, you are offered it as your reaction (with ${MIMIC_PP} PP and a reaction to spend; the +2 PP option as a second button). It never stops, shrinks or turns the cast. Your Spellcraft check is rolled against that spell's casting DC (10 + 1.5 × its PP as cast, M48), and Mimic Spell's PP are spent by its degree. **Critical** (and Heroic): the spell is imprinted — a copy on your sheet for 1 minute (10 minutes with the option); cast it with any targets, adding or dropping metamagic you know. **Success**: imprinted for your next turn only (1 minute with the option), with the original targets or those still in range. **Failure**: nothing. **Fumble**: 1d6 essence per PP of that spell (basic Will at your own level DC, C3). The imprint is your own casting — your check, Save DC and cap; a specialist spell cast as a non-specialist one (Q180) — paid from your PP; short of PP, it offers PP below 0, at 5 Soul Drain for each (Negative PP). It is lost once cast or when its time is up. It is not offered for a spell whose PP exceed your maximum PP per cast (M48), nor for a Ritual spell (Q8), since no imprint could be made of either. *By hand:* taking the warps and metamagic it was cast with — TRG Prime cannot hand a cast a warp already chosen.`
  },
  "SOUL CONFLUENCE": {
    // targetsObject: the module asks which allies (found live: the core read the blank range as "self").
    key: "soulConfluence", area: "", grade: "B", category: "utility", targetsObject: true,
    effects: [note("Choose the willing allies within 30 ft; the shared pool takes their damage first; +2 status to Will saves; Soul Drain at the end.")],
    what: `you and the willing allies within 30 ft you pick are linked for 10 minutes (dismissible): a shared pool of the sum of their Constitution modifiers × 5 takes any of their damage first (after temporary HP) until empty (Q181); +${CONFLUENCE_WILL_BONUS} status to Will saves; at the end each takes 1d6 Soul Drain per 2 rounds it lasted`,
    text: `${CHOICE} once cast, you pick the willing allies within 30 feet; with you, they are linked for the spell's 10 minutes (or until you dismiss it, C4), wherever they go. The shared pool is the sum of your Constitution modifiers × 5 (made once, never below 0; Q181). Damage to any participant comes off the pool first — after temporary HP, before its own HP — until the pool is empty. While linked, each has +${CONFLUENCE_WILL_BONUS} status to Will saves. When the spell ends, each participant takes 1d6 Soul Drain per 2 rounds it lasted (rounded down, m128).`
  },
  "STORM OF UNMAKING": {
    key: "stormOfUnmaking", grade: "A", category: "save", defence: "",
    effects: [{ ...UNMAKING_STORM, modes: UNMAKING_STORM.modes.map((m) => ({ ...m })) }, note("A Fumble or Blunder: the storm appears above you and follows you, for 1 minute.")],
    what: "the core's storm (H16): a 60-ft radius within 200 ft for 1 minute, rolling 1d6 at the cast and at the start of each of your turns — 20d6 fire, 10d12 electricity, 30d4 cold, 15d8 acid (basic Reflex), 20d8 bludgeoning, 12d10 force (basic Fortitude) at your Save DC; a Fumble or Blunder raises it on you, following you (Q182)",
    text: `${FULL} the storm is TRG Prime 3.687.0's (H16): a 60-foot radius you place within 200 feet, lasting 1 minute (not sustained, M56). At the cast and at the start of each of your turns it rolls 1d6: 1 fire 20d6, 2 electricity 10d12, 3 cold 30d4, 4 acid 15d8 (basic Reflex), 5 bludgeoning 20d8, 6 force 12d10 (basic Fortitude), against your Save DC, for everyone under it. A **Fumble** or **Blunder**: after the failure's own PP loss and fumble roll, the storm appears above you and follows you for the minute, striking at once and at the start of each of your turns — you included (Q182).`
  },
  VEILFRACTURE: {
    key: "veilfracture", area: "", grade: "C", category: "utility",
    effects: [note("Click where the rift opens; the plane is the GM's. A Fumble or Blunder: the GM's card rolls who is pulled in.")],
    what: "a rift 10 ft wide per 2 caster levels marked where you click, while sustained; the plane the GM's; a Fumble or Blunder: the GM selects the 1d4 creatures nearby and their Reflex saves (and yours) against your Save DC are rolled — a failure pulled in, a Fumble lost there",
    text: `${PARTLY} you click where the rift opens (within 30 feet); a rift 10 feet wide per 2 caster levels is marked there while you sustain it. The coterminous plane — the Shadescape, an Elemental Plane or the Abyss — is the GM's choice. A **Fumble** or **Blunder**: after the failure's own rules, the GM's card rolls 1d4 for the creatures nearby (the GM selects them); you and they roll Reflex against your Save DC: a failure is pulled into the plane, a Fumble on it is lost there (m137). *By hand:* the travel, and what being pulled in means for the table.`
  }
};

/** One spell, from its book entry and its spec, in Block 3a's `build()` (as Blocks 7 and 8a). */
function buildGrimoire(name) {
  const entry = GRIM.get(name);
  if (!entry) throw new Error(`Block 8b: no Grimoire spell "${name}" in the book`);
  const spec = SPEC[name];
  const doc = build(entry, { effects: [], ...spec }, { specialist: false });
  const sys = doc.system;
  // THE MODULE DRAWS THESE AREAS ITSELF (a ritual's zone around its site, Soul
  // Confluence's allies picked once, Veilfracture's rift): the core places no
  // template for them. The card keeps the printed Area.
  if (spec.area !== undefined) sys.area = spec.area;
  if (/^all$/i.test(String(entry.fields.Tradition ?? "").trim())) sys.tradition = ALL_TRADITIONS;
  // "Basic (varies)" and "varies" (Storm of Unmaking): the storm's modes carry the saves and dice.
  if (spec.key === "stormOfUnmaking") sys.baseDamage = "";
  sys.availability = GRIMOIRE_AVAILABILITY;
  doc.flags = { ...doc.flags, "trg-prime": { ...(doc.flags?.["trg-prime"] ?? {}), eaGrimoire: spec.key, ...(spec.targetsObject ? { targetsObject: true } : {}) } };
  if (doc._id !== stableId(`spells:${doc.name}`)) throw new Error(`Block 8b: ${doc.name}'s id drifted`);
  return doc;
}

export const BLOCK8B_NAMES = Object.freeze(Object.keys(SPEC));
export const SPELLS_B8B = BLOCK8B_NAMES.map(buildGrimoire);

/** What each of the 17 does in TRG Prime, for the docs and the harness. */
export const SPELL_AUTOMATION_B8B = Object.freeze(Object.fromEntries(BLOCK8B_NAMES.map((n, i) => [SPELLS_B8B[i].name, Object.freeze({ grade: SPEC[n].grade, what: SPEC[n].what, key: SPEC[n].key })])));

if (SPELLS_B8B.length !== 17) throw new Error(`Block 8b: ${SPELLS_B8B.length} spells, expected 17`);
