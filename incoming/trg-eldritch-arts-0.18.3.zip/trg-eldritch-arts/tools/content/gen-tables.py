import json, sys
b = json.load(open(sys.argv[1]))['chapter7']
S = {}  # specs, JS source strings, keyed by table and min
# ---- Ley line effects: [effect spec, backlash spec]
L = {
 1: ('{ kind: "cond", mod: { kind: "modifier", value: 1, type: "untyped" }, when: { checkTypes: ["attack"] }, label: "+1 AB" }',
     '{ kind: "damage", amount: "level", type: "force", save: "fortitude" }'),
 4: ('{ kind: "cond", choose: "leySkill", mod: { kind: "modifier", value: 2, type: "untyped" }, oneShot: true, label: "+2 to your next {skill} check" }',
     '{ kind: "cond", choose: "leySkill", mod: { kind: "modifier", value: -2, type: "untyped" }, seconds: 6, label: "−2 to {skill} for 1 round" }'),
 7: ('{ kind: "manual" }', '{ kind: "nextSpellPP", pp: 1 }'),
 10: ('{ kind: "tempHP", amount: "level" }', '{ kind: "loseHP", amount: "level" }'),
 13: ('{ kind: "cond", mod: { kind: "advantage" }, when: { checkTypes: ["save"] }, oneShot: true, label: "Advantage on your next saving throw" }',
      '{ kind: "cond", mod: { kind: "disadvantage" }, when: { checkTypes: ["save"] }, oneShot: true, label: "Disadvantage on your next saving throw" }'),
 16: ('{ kind: "manual" }', '{ kind: "damage", formula: "halfLevel d6", half: true, type: "force", save: "fortitude" }'),
 19: ('{ kind: "manual" }', '{ kind: "condition", tag: { key: "blinded" }, seconds: 6 }'),
 22: ('{ kind: "heal", amount: "level" }', '{ kind: "condition", tag: { key: "bleeding", value: "halfLevel" } }'),
 # 0.11.0 (Block 8a, Q184): the caster's summoned creatures — its "bound" and "conjured" control-register entries (TRG Prime 3.686.0, H12).
 25: ('{ kind: "summons", row: { kind: "cond", mod: { kind: "modifier", value: 1, type: "untyped" }, when: { checkTypes: ["attack"] }, label: "+1 AB" } }',
     '{ kind: "summons", row: { kind: "condition", tag: { key: "stunned", value: 1 } } }'),
 28: ('{ kind: "manual" }', '{ kind: "condition", tag: { key: "stunned", value: 1 } }'),
 31: ('{ kind: "manual" }', '{ kind: "manual" }'),
 34: ('{ kind: "manual" }', '{ kind: "manual" }'),
 37: ('{ kind: "manual" }', '{ kind: "damage", formula: "halfLevel d4", type: "choose:element", save: "fortitude" }'),
 40: ('{ kind: "cond", allies: 10, mod: { kind: "modifier", value: 1, type: "untyped" }, when: { checkTypes: ["save"] }, label: "+1 to saving throws" }',
      '{ kind: "damage", allies: 10, formula: "4d6", type: "force", save: "fortitude" }'),
 43: ('{ kind: "pp", amount: "level" }', '{ kind: "pp", amount: "level", sign: -1 }'),
 46: ('{ kind: "db", value: 2, label: "+2 DB" }', '{ kind: "db", value: -2, label: "Weakened, −2 DB" }'),
 49: ('{ kind: "manual" }', '{ kind: "manual" }'),
 52: ('{ kind: "heal", amount: "level", ally: 30 }', '{ kind: "damage", ally: 30, formula: "halfLevel d6", type: "force", save: "fortitude" }'),
 55: ('{ kind: "manual" }', '{ kind: "manual" }'),
 58: ('{ kind: "manual" }', '{ kind: "manual" }'),
 61: ('{ kind: "cond", mod: { kind: "advantage" }, when: { checkTypes: ["spellcraft"] }, label: "Advantage on spell checks" }',
      '{ kind: "cond", mod: { kind: "disadvantage" }, when: { checkTypes: ["spellcraft"] }, label: "Disadvantage on spell checks" }'),
 64: ('{ kind: "manual" }', '{ kind: "manual" }'),
 66: ('{ kind: "reroll", times: 2, column: "effect", skip: 66 }', '{ kind: "resonance", disadvantage: true }'),
 67: ('{ kind: "cond", mod: { kind: "advantage" }, when: { checkTypes: ["save"] }, label: "Advantage on all saving throws" }',
      '{ kind: "cond", mod: { kind: "disadvantage" }, when: { checkTypes: ["save"] }, label: "Disadvantage on all saving throws" }'),
 70: ('{ kind: "manual" }', '{ kind: "manual" }'),
 73: ('{ kind: "defence", list: "resistances", choose: "damageType" }', '{ kind: "defence", list: "weaknesses", choose: "damageType" }'),
 76: ('{ kind: "manual" }', '{ kind: "damage", formula: "level d6", type: "essence", save: "fortitude" }'),
 79: ('{ kind: "manual" }', '{ kind: "manual" }'),
 82: ('{ kind: "manual" }', '{ kind: "condition", tag: { key: "slowed", value: 2 } }'),
 85: ('{ kind: "spellDC", value: 2 }', '{ kind: "spellDC", value: -2 }'),
 88: ('{ kind: "cond", mod: { kind: "advantage" }, always: true, label: "Advantage on all checks" }',
      '{ kind: "cond", mod: { kind: "disadvantage" }, always: true, label: "Disadvantage on all checks" }'),
 91: ('{ kind: "manual" }', '{ kind: "manual" }'),
 94: ('{ kind: "manual" }', '{ kind: "manual" }'),
 97: ('{ kind: "manual" }', '{ kind: "damage", formula: "level d10", type: "force", save: "fortitude" }'),
 100: ('{ kind: "manual" }', '{ kind: "manual" }'),
}
W = {
 1: '{ kind: "manual" }',
 2: '{ kind: "damage", radius: true, includeSelf: true, formula: "1d10", type: "force", save: "fortitude" }',
 3: '{ kind: "manual" }',
 6: '{ kind: "direction" }',
 9: '{ kind: "dr", value: 2, minutes: "1d4" }',
 12: '{ kind: "manual" }',
 16: '{ kind: "manual" }',
 20: '{ kind: "manual" }',
 24: '{ kind: "manual" }',
 28: '{ kind: "parity", die: 10, what: "pp" }',
 33: '{ kind: "manual" }',
 34: '{ kind: "parity", die: 20, what: "hp" }',
 37: '{ kind: "parity", die: 20, what: "physical", seconds: 3600 }',
 40: '{ kind: "manual" }',
 44: '{ kind: "manual" }',
 48: '{ kind: "damage", choose: 3, radius: true, formula: "1d8 x level", type: "mental", save: "will" }',
 53: '{ kind: "damage", randomAllies: 3, radius: true, formula: "1d8 x level", type: "mental", save: "will", fallbackSelfStun: 1 }',
 58: '{ kind: "ability", sign: 1, formula: "1d4" }',
 62: '{ kind: "ability", sign: -1, formula: "1d4" }',
 66: '{ kind: "reroll", times: 2, column: "effect", resonanceOn: 66 }',
 67: '{ kind: "surcharge", per2Levels: 1, seconds: 60 }',
 71: '{ kind: "manual" }',
 75: '{ kind: "manual" }',
 79: '{ kind: "parity", die: 20, what: "conviction" }',
 83: '{ kind: "condition", tag: { key: "confused" } }',
 85: '{ kind: "manual" }',
 87: '{ kind: "manual" }',
 89: '{ kind: "manual" }',
 91: '{ kind: "condition", tag: { key: "quickened" } }',
 93: '{ kind: "condition", tag: { key: "slowed", value: 1 } }',
 95: '{ kind: "manual" }',
 97: '{ kind: "manual" }',
 99: '{ kind: "manual" }',
 100: '{ kind: "ppFull" }',
}
SB = {
 1: '{ kind: "lostPP" }',
 26: '{ kind: "damage", formula: "1d6 x level", type: "force" }',
 51: '{ kind: "condition", tag: { key: "dazed", value: 1 }, roundsPerLevel: true }',
 66: '{ kind: "manual" }',
 67: '{ kind: "loseHP", amount: "level" }',
 76: '{ kind: "pp", amount: "level", sign: -1 }',
 91: '{ kind: "damage", formula: "1d8 x level", type: "mental" }',
 100: '{ kind: "ppEmpty" }',
}
def js(s): return json.dumps(s, ensure_ascii=False)
out = []
out.append('''/**
 * Eldritch Arts Block 2 — Chapter 7's three d100 tables, each row's printed
 * text (verbatim; verify-block2 holds every one against the book extract)
 * and what this module does with it.
 *
 * GENERATED by tools/content/gen-tables.py from tools/content/book-text.json
 * and the specs in that script. Edit the script, not this file.
 *
 * A row's `kind: "manual"` is posted as the book's text for the table to
 * apply: the system has no channel for it yet (a metamagic feat, a spell's
 * range or targets, the GM's choice). Nothing here is called automated that
 * only posts text.
 */
''')
out.append('export const LEY_LINE_EFFECTS = Object.freeze([')
for r in b['leyLines']['effects']['rows']:
    e, bl = L[r['min']]
    out.append(f'  Object.freeze({{ min: {r["min"]}, max: {r["max"]}, effect: {js(r["effect"])}, backlash: {js(r["backlash"])}, e: {e}, b: {bl} }}),')
out.append(']);\n')
out.append('export const WILD_SURGE = Object.freeze([')
for r in b['wildMagic']['surge']['rows']:
    out.append(f'  Object.freeze({{ min: {r["min"]}, max: {r["max"]}, effect: {js(r["effect"])}, e: {W[r["min"]]} }}),')
out.append(']);\n')
out.append('export const SUPPRESSION_BACKLASH = Object.freeze([')
for r in b['suppression']['backlash']['rows']:
    out.append(f'  Object.freeze({{ min: {r["min"]}, max: {r["max"]}, effect: {js(r["effect"])}, e: {SB[r["min"]]} }}),')
out.append(']);\n')
out.append('''/** The row a d100 result lands on (1–100; a higher open-ended total reads as 100). */
export function rowFor(table, roll) {
  const n = Math.min(100, Math.max(1, Math.floor(Number(roll) || 0)));
  return table.find((r) => n >= r.min && n <= r.max) ?? null;
}
''')
open(sys.argv[2], 'w').write("\n".join(out))
print("ok", len(b['leyLines']['effects']['rows']), len(b['wildMagic']['surge']['rows']), len(b['suppression']['backlash']['rows']))
