/**
 * Cuts Eldritch Arts v1.4 (pandoc gfm of TRG_Prime_Eldritch_Arts_1_4.docx,
 * <img> tags stripped) into tools/content/book-text.json.
 *
 *   pandoc -t gfm --wrap=none TRG_Prime_Eldritch_Arts_1_4.docx -o ea-raw.md
 *   sed -E 's/<img[^>]*>//g' ea-raw.md > ea.md
 *   node tools/content/extract-book.mjs ea.md ea-sidebars.md [out.json]
 *
 * The current cut is from v1.6 (/home/claude/ea-src/v16/ea.md and
 * ea-sidebars.md). Since 0.10.0 tools/verify-book-extract.mjs re-cuts it
 * into a scratch file and checks it.
 *
 * pandoc drops docx text boxes, so the 37 sidebars (rune tiers, Distracted,
 * Counter Channel and the rest) were recovered from word/document.xml into
 * ea-sidebars.md, each headed "## SIDEBAR n: TITLE (after Lnnnn)". They are
 * read into book.sidebars with the ea.md line they follow.
 *
 * Nothing is reworded: every entry keeps its printed lines. Each entry
 * records the line it starts on in ea.md so the inventory and the audit
 * can cite it. The script fails loudly when a section's shape changes.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SRC = process.argv[2];
if (!SRC) throw new Error("usage: node tools/content/extract-book.mjs <ea.md>");
const LINES = fs.readFileSync(SRC, "utf8").split("\n");
const at = (n) => LINES[n - 1] ?? "";

/** The line number of the first line at/after `from` matching `re`. */
function find(re, from = 1) {
  for (let n = from; n <= LINES.length; n += 1) if (re.test(at(n))) return n;
  throw new Error(`extract: no line matches ${re} after ${from}`);
}

const PLAIN_HEADING = /^[A-Z][A-Z0-9’'‘ ,&()\-–.]+$/;
const BOLD_ONLY = /^\*\*([^*]+)\*\*$/;
const LABELS = ["Birthright", "Prerequisites", "Action", "Trigger", "Frequency", "PP Cost", "Cost", "Requirements", "Requirement", "Progression Requirements", "Cast", "Range", "Targets", "Target", "Area", "Duration", "Saving Throw", "Base Damage", "Tradition", "Activate", "Effect", "Backlash", "Price", "Level", "Usage", "Bulk",
  // Block 9b (0.14.0): the runes' and specific items' own.
  "Armour/Shield Price", "Weight"];

/**
 * Punctuation set bold in the docx is not a label. A bold comma
 * ("**Tradition** arcane**,** ethereal", EA-m127) is folded back into the
 * text, so the value is not cut at the comma; a separator that opens a bold
 * run ("**PP Cost** +2**; Requirements** …", Steelbinding, audit m45) is
 * moved out of it, so the label after it is read.
 */
const unboldPunctuation = (line) => String(line)
  .replace(/\*\*([,;.])\*\*/g, "$1")
  .replace(/\*\*([,;]\s*)([^*]+?)\*\*/g, "$1**$2**");

/** The bold labels of a field line, as printed (bold punctuation folded away). */
function boldLabelsOf(line) {
  return [...unboldPunctuation(line).matchAll(/\*\*([^*]+?)\*\*/g)].map((m) => m[1].trim().replace(/[:;]$/, "").trim());
}

/** Split "**A** x; **B** y" field lines into {A: x, B: y}. */
function fieldsOf(line) {
  line = unboldPunctuation(line);
  const out = {};
  const re = /\*\*([^*]+?)\*\*:?\s*([^*]*?)(?=\s*;?\s*\*\*|$)/g;
  let m;
  while ((m = re.exec(line))) {
    const label = m[1].trim().replace(/:$/, "").replace(/;$/, "").trim();
    if (LABELS.includes(label)) out[label] = m[2].trim().replace(/^:\s*/, "").replace(/;$/, "").trim();
  }
  return out;
}

/**
 * Entries in a feat-style section: a plain ALL-CAPS heading line, then an
 * optional bold traits line, an optional italic flavour line, labelled
 * fields and body paragraphs, until the next heading.
 */
function entries(from, to, { headingRe = PLAIN_HEADING, skip = [] } = {}) {
  const out = [];
  let cur = null;
  for (let n = from; n < to; n += 1) {
    const t = at(n).trim();
    if (!t) continue;
    if (headingRe.test(t) && !skip.includes(t) && at(n - 1).trim() === "") {
      cur = { line: n, name: t, traits: [], fields: {}, labels: [], flavour: "", lines: [] };
      out.push(cur);
      continue;
    }
    if (!cur) continue;
    const bold = BOLD_ONLY.exec(t);
    if (bold && !cur.lines.length && !Object.keys(cur.fields).length && !cur.traits.length && !/:/.test(bold[1]) && !LABELS.includes(bold[1].trim())) {
      cur.traits = bold[1].trim().split(/\s+/);
      continue;
    }
    if (/^\*[^*].*\*$/.test(t) && !cur.flavour && !cur.lines.length) { cur.flavour = t.replace(/^\*|\*$/g, ""); continue; }
    const f = fieldsOf(t);
    if (Object.keys(f).length && t.startsWith("**")) {
      Object.assign(cur.fields, f);
      // Every bold label the field line prints, kept or not, so verify-book-extract
      // can see one the parse dropped (EA Block 7 audit §6: "Target", "Requirement").
      cur.labels.push(...boldLabelsOf(t));
      continue;
    }
    cur.lines.push(t);
  }
  return out;
}

const book = { source: "TRG_Prime_Eldritch_Arts_1_4.docx (v1.4), pandoc gfm, img tags stripped", sections: {} };

/*
 * Chapter 2 (Block 1): the four races, their heritages and abilities, and
 * the backgrounds. Each race runs from its plain heading to the next race's
 * (or "## BACKGROUNDS"); its heritages from "**<RACE> HERITAGES**" to its
 * end. A racial ability is a "**Name:** text" line under OTHER ABILITIES.
 */
{
  const RACE_NAMES = ["AETHERIAL", "EMBERKIN", "NYRINN", "SCAELYN"];
  const BG = find(/^## BACKGROUNDS$/);
  const starts = RACE_NAMES.map((r) => find(new RegExp(`^${r}$`)));
  const races = {};
  const heritages = {};
  RACE_NAMES.forEach((race, i) => {
    const from = starts[i];
    const to = starts[i + 1] ?? BG;
    const hStart = find(new RegExp(`^\\*\\*${race} HERITAGES\\*\\*$`), from);
    if (hStart > to) throw new Error(`extract: ${race} heritages heading out of range`);
    const text = [];
    for (let n = from + 1; n < hStart; n += 1) if (at(n).trim()) text.push(at(n).trim());
    const abilities = {};
    const other = text.indexOf("**OTHER ABILITIES**");
    if (other < 0) throw new Error(`extract: ${race} has no OTHER ABILITIES`);
    for (const l of text.slice(other + 1)) {
      const m = /^\*\*([^*:]+):\*\*\s*(.+)$/.exec(l);
      if (m) abilities[m[1].trim()] = m[2].trim();
    }
    races[race] = { line: from, text, abilities };
    // Heritages: a bold-only line is a heritage's name (Wyrmdral's own
    // mechanics lines are bold-led but not bold-only).
    let cur = null;
    for (let n = hStart + 1; n < to; n += 1) {
      const l = at(n).trim();
      if (!l || l === "##") continue;
      const b = BOLD_ONLY.exec(l);
      if (b && /^[A-Z][A-Z\- ]+$/.test(b[1].trim())) {
        cur = { line: n, race, name: b[1].trim(), text: [] };
        heritages[cur.name] = cur;
        continue;
      }
      if (cur) cur.text.push(l);
      else if (!/^Once you have selected/.test(l)) throw new Error(`extract: stray line before ${race}'s first heritage: ${l}`);
    }
  });
  const backgrounds = {};
  const CH3 = find(/^# CHAPTER 3 - CLASSES$/);
  let cur = null;
  let field = null;
  for (let n = find(/^The below backgrounds follow/, BG) + 1; n < CH3; n += 1) {
    const l = at(n).trim();
    if (!l) continue;
    const b = BOLD_ONLY.exec(l);
    if (b && ["BONUS FEAT", "SKILL BONUSES", "SPECIALIST SKILL"].includes(b[1].trim())) { field = b[1].trim(); continue; }
    if (b) { cur = { line: n, name: b[1].trim(), description: [], feat: "", skills: "", specialist: "" }; backgrounds[cur.name] = cur; field = null; continue; }
    if (!cur) continue;
    if (field === "BONUS FEAT") cur.feat = l;
    else if (field === "SKILL BONUSES") cur.skills = l;
    else if (field === "SPECIALIST SKILL") cur.specialist = l;
    else cur.description.push(l);
  }
  if (Object.keys(backgrounds).length !== 12) throw new Error(`extract: ${Object.keys(backgrounds).length} backgrounds, expected 12`);
  if (Object.keys(heritages).length !== 18) throw new Error(`extract: ${Object.keys(heritages).length} heritages, expected 18`);
  book.chapter2 = { races, heritages, backgrounds };
}

/*
 * Chapter 4 (Block 1): an action's printed block, from its bold heading to
 * the next bold ALL-CAPS heading or "### " subsection.
 */
{
  const CH4 = find(/^# CHAPTER 4 - SKILLS & ACTIONS$/);
  const CH5 = find(/^# CHAPTER 5 - FEATS$/);
  const actions = {};
  // Block 2 adds the three Power Manipulation actions on ley lines and charged items.
  const WANT = ["LEY SENSE", "APPRAISE MAGIC", "HYPNOTISM", "LINGUAL CASTING", "MYSTERIOUS SCRIPT", "QUICKBIND",
    "CHANNEL LEY LINE", "TAP LEY LINE", "TAP MAGICAL ENERGY",
    // Block 2b: the two it did not take (m14 as rewritten).
    "BORROW SPELL", "SPELL TRICKERY",
    // Block 10 (0.17.0): the Relic Bonding Ritual.
    "RELIC BONDING RITUAL"];
  for (const name of WANT) {
    let from = 0;
    for (let n = CH4; n < CH5; n += 1) if (new RegExp(`^\\*\\*${name}( [A-Z ]+)?\\*\\*$`).test(at(n).trim())) { from = n; break; }
    if (!from) throw new Error(`extract: no Chapter 4 action ${name}`);
    const lines = [];
    for (let n = from + 1; n < CH5; n += 1) {
      const l = at(n).trim();
      if (!l) continue;
      if (/^### /.test(l) || /^\*\*[A-Z][A-Z ]+ \([A-Za-z]+\)\*\*$/.test(l) || (/^\*\*[A-Z][A-Z ]+( [A-Z]+)*\*\*$/.test(l) && !/^\*\*(CONCENTRATE|SECRET|EMOTION|MENTAL|FOCUS)( [A-Z]+)*\*\*$/.test(l))) break;
      lines.push(l);
    }
    actions[name] = { line: from, heading: at(from).trim(), lines };
  }
  book.chapter4 = actions;
}

// Chapter 5 feats.
const RACIAL = find(/^## RACIAL FEATS$/);
const EXISTING_R = find(/^\*\*EXISTING FEATS\*\*$/, RACIAL);
const ARCH = find(/^## ARCHETYPE FEATS$/);
const CLASSF = find(/^## CLASS FEATS$/);
const GENERAL = find(/^## GENERAL FEATS$/);
const CH6 = find(/^# CHAPTER 6 - GEAR$/);
book.sections.racialFeats = entries(RACIAL + 1, EXISTING_R);
book.sections.archetypeFeats = entries(ARCH + 1, CLASSF);
book.sections.classFeats = entries(CLASSF + 1, GENERAL);
book.sections.generalFeats = entries(GENERAL + 1, CH6);
book.sections.existingRacialFeats = (() => {
  const out = {};
  let race = null;
  for (let n = EXISTING_R + 1; n < ARCH; n += 1) {
    const t = at(n).trim();
    if (!t || /^The races in this sourcebook/.test(t)) continue;
    if (PLAIN_HEADING.test(t)) { race = t; continue; }
    if (race) out[race] = t.split(",").map((s) => s.trim()).filter(Boolean);
  }
  return out;
})();


/** A markdown table starting at/after `from`: {line, header[], rows[{line, cells[]}]} */
function table(from) {
  let n = from;
  while (!at(n).trim().startsWith("|")) n += 1;
  const start = n;
  const rows = [];
  for (; at(n).trim().startsWith("|"); n += 1) {
    const cells = at(n).trim().replace(/^\||\|$/g, "").split("|").map((c) => c.replace(/\*\*/g, "").trim());
    if (cells.every((c) => /^-*$/.test(c))) continue;
    rows.push({ line: n, cells });
  }
  return { line: start, rows };
}

// Chapter 6 tables and entries.
const WEAPONS_M = find(/^\| MELEE EXOTIC WEAPONS/, CH6);
const WEAPONS_R = find(/^\| RANGED EXOTIC WEAPONS/, CH6);
const GOODS_T = find(/^\| \*\*GOODS & TOOLS\*\*/, CH6);
const CATALYSTS = find(/^\*\*CATALYSTS\*\*$/, CH6);
const CATALYST_T = find(/^\| CATALYSTS /, CATALYSTS);
const MATERIALS = find(/^\*\*SPECIAL MATERIALS\*\*$/, CH6);
const WEAPONS_H = find(/^WEAPONS$/, MATERIALS);
const GOODS = find(/^\*\*GOODS & TOOLS\*\*$/, CH6);
const CH7 = find(/^# CHAPTER 7 - MAGIC$/);
book.sections.materials = entries(MATERIALS + 1, WEAPONS_H, { headingRe: /^\*\*[A-Z][A-Z ]+\*\*$/, skip: ["**UNCOMMON**", "**RARE**", "**COMMON**"] }).map((e) => ({ ...e, name: e.name.replace(/\*\*/g, "") }));
book.sections.meleeWeapons = table(WEAPONS_M);
book.sections.rangedWeapons = table(WEAPONS_R);
book.sections.weaponEntries = entries(find(/^Below you will find a brief description of each weapon/, CH6) + 1, find(/^\*\*GOODS & TOOLS\*\*$/, CH6), { headingRe: /^[A-ZÁÉÍÓÚ][A-ZÁÉÍÓÚ’' \-]+(\([A-Z’' \-]+\))?$/, skip: ["EQUIPMENT"] }).filter((e) => e.name !== "EQUIPMENT");
book.sections.goodsEntries = entries(find(/^All of the equipment in this section/, GOODS) + 1, GOODS_T);
book.sections.goods = table(GOODS_T);
book.sections.catalystEntries = entries(find(/^Each catalyst is listed/, CATALYSTS) + 1, CATALYST_T);
book.sections.catalysts = table(CATALYST_T);
/*
 * Block 9b (0.14.0): Chapter 9's armour and shield runes, specific armour,
 * weapon runes and specific weapons. Each entry as the others are cut; a
 * rune's tiers are its sidebar's ("AEGISFLOW I" … after the entry), read into
 * `tiers` as { name, level, price, text }.
 */
{
  const ARMOUR_RUNES = find(/^\*\*ARMOUR & SHIELD RUNES\*\*$/, CH7);
  const SPECIFIC_ARMOUR = find(/^\*\*SPECIFIC ARMOUR\*\*$/, ARMOUR_RUNES);
  const CHARGED = find(/^CHARGED ITEMS$/, SPECIFIC_ARMOUR);
  const WEAPON_RUNES = find(/^\*\*WEAPON RUNES\*\*$/, CHARGED);
  const SPECIFIC_WEAPONS = find(/^\*\*SPECIFIC WEAPONS\*\*$/, WEAPON_RUNES);
  const WONDROUS = find(/^WONDROUS ITEMS$/, SPECIFIC_WEAPONS);
  book.sections.armourRunes = entries(ARMOUR_RUNES + 1, SPECIFIC_ARMOUR);
  book.sections.specificArmour = entries(SPECIFIC_ARMOUR + 1, CHARGED);
  book.sections.weaponRunes = entries(WEAPON_RUNES + 1, SPECIFIC_WEAPONS);
  book.sections.specificWeapons = entries(SPECIFIC_WEAPONS + 1, WONDROUS);
  /*
   * Block 9c (0.15.0): the specific orbs, rods and staves, each entry as the
   * others are cut. Their "Power Points", "Recharge", "Spells" and "Craft
   * Requirements" lines stay body lines (no new LABELS, so no other section's
   * cut moves); tools/content/block9c.mjs reads them.
   */
  const ORBS = find(/^\*\*SPECIFIC ORBS\*\*$/, CHARGED);
  const RODS = find(/^\*\*SPECIFIC RODS\*\*$/, ORBS);
  const STAVES = find(/^\*\*SPECIFIC STAVES\*\*$/, RODS);
  const WEAPONS_HEAD = find(/^WEAPONS$/, STAVES);
  book.sections.orbs = entries(ORBS + 1, RODS);
  book.sections.rods = entries(RODS + 1, STAVES);
  book.sections.staves = entries(STAVES + 1, WEAPONS_HEAD);
}
/*
 * Block 10 (0.17.0): Chapter 9's specific relics and its one specific sentient
 * item. A relic is its heading, its traits, its Usage line, its flavour, any
 * Requirement, then five tier headings ("DORMANT (LEVELS 1–4)") each with its
 * "- " bullets. Dawnshield is cut whole, as printed, with its bold sub-heads.
 */
{
  const RELICS = find(/^\*\*SPECIFIC RELICS\*\*$/);
  const SENTIENT = find(/^\*\*SENTIENT ITEMS\*\*$/, RELICS);
  const SPECIFIC_SENTIENT = find(/^\*\*SPECIFIC SENTIENT ITEMS\*\*$/, SENTIENT);
  const APPENDIX = find(/^THE APPENDIX$/, SPECIFIC_SENTIENT);
  const TIER = /^(DORMANT|AWAKENED|EMPOWERED|TRANSCEND[AE]NT|LEGENDARY) \(LEVELS? ([0-9]+)(?:[–-]([0-9]+)|\+)\)$/;
  const relics = [];
  let cur = null, tier = null;
  for (let n = RELICS + 1; n < SENTIENT; n += 1) {
    const l = at(n).trim();
    if (!l || l === "<!-- -->" || l === "-") continue;
    const t = TIER.exec(l);
    if (t && cur) { tier = { name: t[1], from: Number(t[2]), to: t[3] ? Number(t[3]) : 20, line: n, bullets: [] }; cur.tiers.push(tier); continue; }
    if (PLAIN_HEADING.test(l) && !t && l !== "The item progresses as follows:") { cur = { line: n, name: l, traits: [], fields: {}, flavour: [], requirement: "", tiers: [] }; tier = null; relics.push(cur); continue; }
    if (!cur) continue;
    if (tier) { tier.bullets.push(l.replace(/^- /, "")); continue; }
    const bold = BOLD_ONLY.exec(l);
    if (bold && !cur.traits.length && !/:/.test(bold[1])) { cur.traits = bold[1].trim().split(/\s+/); continue; }
    if (/^\*\*Usage\*\*/.test(l)) { Object.assign(cur.fields, fieldsOf(l)); continue; }
    if (/^\*\*Requirement\*\*/.test(l)) { cur.requirement = l.replace(/^\*\*Requirement\*\*\s*/, ""); continue; }
    if (/^\*[^*].*\*$/.test(l)) { cur.flavour.push(l.replace(/^\*|\*$/g, "")); continue; }
  }
  if (relics.length !== 4) throw new Error(`extract: ${relics.length} relics, expected 4`);
  for (const r of relics) if (r.tiers.length !== 5) throw new Error(`extract: ${r.name} has ${r.tiers.length} tiers`);
  const sentient = [];
  for (let n = SPECIFIC_SENTIENT + 1; n < APPENDIX; n += 1) {
    const l = at(n).trim();
    if (!l) continue;
    sentient.push({ line: n, text: l });
  }
  book.chapter9 = { relics, sentient };

  /*
   * Block 10b (0.17.1): the sentient-item tables (TB-004–006). Two printed
   * grids hold several tables each, their headers first and their rows run
   * together (m216, "as printed"); a table's rows end where the next starts
   * again at 1. The mental arrays are a table of their own.
   */
  const grid = (from) => {
    const t = table(from);
    const heads = [];
    const rows = [];
    for (let i = 0; i < t.rows.length; i += 1) {
      const c = t.rows[i].cells;
      if (/^d\d+$/i.test(c[0])) { heads[heads.length - 1].die = c[0].toLowerCase(); heads[heads.length - 1].column = c[1]; continue; }
      if (c[0] && /^[A-Z][A-Z ]+$/.test(c[0]) && !c[1]) { heads.push({ name: c[0], line: t.rows[i].line }); continue; }
      rows.push({ line: t.rows[i].line, range: c[0], text: c[1] });
    }
    const groups = [];
    for (const r of rows) {
      const start = Number(String(r.range).split(/[–-]/)[0]);
      if (start === 1 || !groups.length) groups.push([]);
      groups.at(-1).push(r);
    }
    if (groups.length !== heads.length) throw new Error(`extract: a sentient grid has ${heads.length} headers and ${groups.length} tables`);
    return heads.map((h, i) => ({ ...h, rows: groups[i] }));
  };
  const TABLES = find(/^\*\*SENTIENT ITEM TABLES\*\*$/, SENTIENT);
  const first = grid(TABLES);
  const ARRAYS = find(/^\| \*\*MENTAL ARRAYS\*\*/, TABLES);
  const arrays = table(ARRAYS);
  const POWERS = find(/^\| \*\*SPECIAL POWERS\*\*/, ARRAYS);
  const second = grid(POWERS);
  book.chapter9.tables = {
    line: TABLES,
    intro: [at(TABLES + 2), at(TABLES + 4)].map((l) => l.trim()),
    first, second,
    arrays: { line: arrays.line, columns: arrays.rows[1].cells, rows: arrays.rows.slice(2).map((r) => ({ line: r.line, cells: r.cells })) },
    after: at(find(/^Feel free to use the above tables/, TABLES)).trim(),
    arraysNote: at(find(/^Based upon the power level of the sentient entity/, ARRAYS)).trim()
  };
}
/*
 * Block 10b (0.17.1): the rules reference journal (Q221), as printed. Each
 * page is a run of the book's own markdown lines, from its heading to the
 * next page's; tools/content/block10b.mjs renders them.
 */
{
  const page = (title, from, to) => ({ title, line: from, lines: LINES.slice(from - 1, to - 1).map((l) => l.replace(/\s+$/, "")) });
  const C7 = find(/^# CHAPTER 7 - MAGIC$/);
  const HIGH = find(/^## HIGH MAGIC$/, C7);
  const LEY = find(/^## LEY LINES$/, HIGH);
  const WILD = find(/^## WILD MAGIC AREAS$/, LEY);
  const SUPP = find(/^## MAGIC SUPPRESSION AREAS$/, WILD);
  const RITUAL = find(/^## MUNDANE RITUAL CASTING$/, SUPP);
  const SUMMON = find(/^## SUMMONING CIRCLES$/, RITUAL);
  const C8 = find(/^# CHAPTER 8 - GRIMOIRE$/, SUMMON);
  const WOND = find(/^WONDROUS ITEMS$/, find(/^CHAPTER 9 – MAGIC ITEMS$/));
  const RELICS = find(/^\*\*SPECIFIC RELICS\*\*$/, WOND);
  const SENT = find(/^\*\*SENTIENT ITEMS\*\*$/, RELICS);
  const TABLES = find(/^\*\*SENTIENT ITEM TABLES\*\*$/, SENT);
  const APPX = find(/^THE APPENDIX$/, TABLES);
  const TRAITS = find(/^\*\*NEW TRAITS\*\*$/, APPX);
  const PLANES = find(/^PLANES OF EXISTENCE$/, TRAITS);
  const INDEX = find(/^INDEX$/, PLANES);
  book.rulesPages = [
    page("Chapter 7: Magic", C7, HIGH),
    page("High Magic", HIGH, LEY),
    page("Ley Lines", LEY, WILD),
    page("Wild Magic Areas", WILD, SUPP),
    page("Magic Suppression Areas", SUPP, RITUAL),
    page("Mundane Ritual Casting", RITUAL, SUMMON),
    page("Summoning Circles", SUMMON, C8),
    page("Wondrous Items & Relics", WOND, RELICS),
    page("Sentient Items", SENT, TABLES),
    page("New Traits", TRAITS, PLANES),
    page("Planes of Existence", PLANES, INDEX)
  ];
}
// Block 3: Chapter 6's Class Wealth table (L4754).
book.sections.classWealth = table(find(/^\| \*\*CLASS WEALTH\*\*/, CH6));
/*
 * Chapter 7 (Block 2): High Magic's casting rules, the ley line table, and
 * the three d100 tables, each row read off the printed table.
 */
{
  const CH8 = find(/^# CHAPTER 8 - GRIMOIRE$/);
  const paragraphs = (from, to) => {
    const out = [];
    for (let n = from; n < to; n += 1) { const l = at(n).trim(); if (l && !l.startsWith("|")) out.push({ line: n, text: l }); }
    return out;
  };
  const d100 = (start, columns) => {
    const t = table(start);
    // Row 0 is the title row, row 1 the column headings.
    const rows = t.rows.filter((r) => /^\d+(\s*[–-]\s*\d+)?$/.test(r.cells[0].trim())).map((r) => {
      const m = /^(\d+)(?:\s*[–-]\s*(\d+))?$/.exec(r.cells[0].trim());
      if (!m) throw new Error(`extract: Chapter 7 row "${r.cells[0]}" (L${r.line})`);
      const min = Number(m[1]), max = Number(m[2] ?? m[1]);
      const row = { line: r.line, min, max };
      columns.forEach((c, i) => { row[c] = r.cells[i + 1]; });
      return row;
    });
    for (let i = 1; i < rows.length; i += 1) if (rows[i].min !== rows[i - 1].max + 1) throw new Error(`extract: Chapter 7 table at L${start} skips from ${rows[i - 1].max} to ${rows[i].min}`);
    if (rows[0].min !== 1 || rows.at(-1).max !== 100) throw new Error(`extract: Chapter 7 table at L${start} does not run 1–100`);
    return { line: t.line, rows };
  };
  const HM = find(/^## HIGH MAGIC$/, CH7);
  const LEY = find(/^## LEY LINES$/, CH7);
  const WILD = find(/^## WILD MAGIC AREAS$/, CH7);
  const SUPP = find(/^## MAGIC SUPPRESSION AREAS$/, CH7);
  const RIT = find(/^## MUNDANE RITUAL CASTING$/, CH7);
  const SUMM = find(/^## SUMMONING CIRCLES$/, CH7);
  const levels = table(find(/^\| \*\*Ley Line Level\*\*/, LEY));
  book.chapter7 = {
    highMagic: { line: HM, paragraphs: paragraphs(HM + 1, LEY), fumbleTable: table(find(/^\| HIGH MAGIC SPELL FAILURE MODIFIERS/, HM)) },
    leyLines: {
      line: LEY, paragraphs: paragraphs(LEY + 1, WILD),
      levels: levels.rows.slice(1).map((r) => ({ line: r.line, band: r.cells[0], description: r.cells[1], examples: r.cells[2], senseDC: Number(r.cells[3]) })),
      effects: d100(find(/^\| \*\*LEY LINE EFFECTS TABLE\*\*/, LEY), ["effect", "backlash"])
    },
    wildMagic: { line: WILD, paragraphs: paragraphs(WILD + 1, SUPP), surge: d100(find(/^\| WILD SURGE/, WILD), ["effect"]) },
    suppression: { line: SUPP, paragraphs: paragraphs(SUPP + 1, RIT), backlash: d100(find(/^\| SUPPRESSION BACKLASH TABLE/, SUPP), ["effect"]) },
    rituals: { line: RIT, paragraphs: paragraphs(RIT + 1, SUMM), materials: table(find(/^\| RITUAL MATERIAL SACRIFICE COSTS/, RIT)) },
    summoning: { line: SUMM, paragraphs: paragraphs(SUMM + 1, CH8), modifiers: table(find(/^\| SUMMONING CIRCLE MODIFIERS/, SUMM)) }
  };
  if (book.chapter7.leyLines.levels.length !== 5) throw new Error("extract: Chapter 7 ley line levels are not five bands");
  if (book.chapter7.leyLines.effects.rows.length !== 35) throw new Error(`extract: ${book.chapter7.leyLines.effects.rows.length} ley line effect rows, expected 35`);
  if (book.chapter7.wildMagic.surge.rows.length !== 34) throw new Error(`extract: ${book.chapter7.wildMagic.surge.rows.length} wild surge rows, expected 34`);
  if (book.chapter7.suppression.backlash.rows.length !== 8) throw new Error(`extract: ${book.chapter7.suppression.backlash.rows.length} suppression backlash rows, expected 8`);
}

const SIDEBARS = process.argv[3];
if (!SIDEBARS) throw new Error("usage: node tools/content/extract-book.mjs <ea.md> <ea-sidebars.md>");
book.sidebars = [];
{
  let cur = null;
  for (const raw of fs.readFileSync(SIDEBARS, "utf8").split("\n")) {
    const h = /^## SIDEBAR (\d+): (.+?)(?: \(after L(\d+)\))?$/.exec(raw);
    if (h) { cur = { n: Number(h[1]), title: h[2], after: h[3] ? Number(h[3]) : null, lines: [] }; book.sidebars.push(cur); continue; }
    if (cur && raw.trim()) cur.lines.push(raw.trim());
  }
  // By title, not by count: v1.6 drops the cover boxes and adds a note.
  for (const t of ["MAGIC DRAIN", "SPELLSTRIKE RIPOSTE", "DISTRACTED", "VEIL I"]) {
    if (!book.sidebars.some((x) => x.title === t)) throw new Error(`extract: no sidebar "${t}"`);
  }
}

for (const [k, v] of Object.entries(book.sections)) {
  if (Array.isArray(v)) for (const e of v) if (!e.lines.length && !Object.keys(e.fields).length) throw new Error(`extract: ${k} entry ${e.name} (line ${e.line}) has no text`);
}

/*
 * Grimoire spells by name (Block 1 needs Orb of Water; Blocks 7–8 the rest):
 * "**NAME PP n**", then the bold traits line, the labelled fields, the body,
 * up to the next spell heading.
 */
{
  const CH8 = find(/^# CHAPTER 8 - GRIMOIRE$|^CHAPTER 8 - GRIMOIRE$|^# CHAPTER 8/);
  const SPECIALIST = find(/^SPECIALIST SPELLS$|^\*\*SPECIALIST SPELLS\*\*$|^## SPECIALIST SPELLS$/, CH8);
  book.grimoire = entries(CH8 + 1, SPECIALIST, { headingRe: /^\*\*[A-Z’' ,\-]+ PP \d+\*\*$/ })
    .map((e) => { const m = /^\*\*(.+?) PP (\d+)\*\*$/.exec(e.name); return { ...e, name: m[1].trim(), pp: Number(m[2]) }; });
  // v1.6: 87 (Dragon Wings added, Graham's M2 response).
  if (book.grimoire.length !== 87) throw new Error(`extract: ${book.grimoire.length} Grimoire spells, expected 87`);
}

/*
 * The Specialist Spells chapter (Block 3: the Archmage's, the Sorcerer's and
 * the Witch's): a plain "NAME PP n" heading, the bold traits line, the
 * labelled fields (Birthright among them), the body and its warps, up to the
 * next spell or Chapter 9.
 */
{
  const CH8 = find(/^# CHAPTER 8/);
  const SPECIALIST = find(/^SPECIALIST SPELLS$|^\*\*SPECIALIST SPELLS\*\*$|^## SPECIALIST SPELLS$/, CH8);
  const CH9 = find(/^CHAPTER 9 [–-] MAGIC ITEMS$|^# CHAPTER 9/, SPECIALIST);
  book.specialist = entries(SPECIALIST + 1, CH9, { headingRe: /^[A-Z][A-Z’' ,\-]+ PP \d+$/ })
    .map((e) => { const m = /^(.+?) PP (\d+)$/.exec(e.name); return { ...e, name: m[1].trim(), pp: Number(m[2]) }; });
  if (book.specialist.length !== 41) throw new Error(`extract: ${book.specialist.length} specialist spells, expected 41`);
}

/*
 * Chapter 3's three High Magic classes (Block 3a). Each class is cut into its
 * sections: a heading (a bold-only or plain capitals line), an optional traits
 * line straight after it (Gale Step's "AIR FOCUS TELEPORTATION TRANSLOCATION"),
 * its paragraphs, and any table under it, as printed rows.
 */
{
  const isCaps = (t) => /^[A-Z][A-Z0-9 ’'&()\-–.,]+$/.test(t);
  const sectionsOf = (from, to) => {
    const out = [];
    let cur = null;
    let rows = null;
    for (let n = from; n < to; n += 1) {
      const t = at(n).trim();
      if (!t) { rows = null; continue; }
      if (t.startsWith("|")) {
        if (!cur) continue;
        const cells = t.replace(/^\||\|$/g, "").split("|").map((c) => c.replace(/\*\*/g, "").replace(/<\/?sup>/g, "").trim());
        if (cells.every((c) => /^-*$/.test(c))) continue;
        if (!rows) { rows = { line: n, rows: [] }; cur.tables.push(rows); }
        rows.rows.push({ line: n, cells });
        continue;
      }
      rows = null;
      const bold = BOLD_ONLY.exec(t);
      const name = bold ? bold[1].trim() : t;
      const heading = (bold && isCaps(name)) || (!bold && isCaps(t) && at(n - 1).trim() === "" && t.length < 40);
      if (heading && cur && !cur.lines.length && !cur.tables.length && !cur.traits.length && bold && cur.name !== name && /^[A-Z]+( [A-Z]+)+$/.test(name) && TRAIT_WORDS.test(name)) {
        cur.traits = name.split(/\s+/);
        continue;
      }
      if (heading) { cur = { line: n, name, traits: [], lines: [], tables: [] }; out.push(cur); continue; }
      if (cur) cur.lines.push(t);
    }
    return out;
  };
  // Traits lines that would otherwise read as headings: they follow a heading
  // straight away and are made of the book's trait words.
  const TRAIT_WORDS = /^(?:(?:AIR|FOCUS|TELEPORTATION|TRANSLOCATION|CONCENTRATE|MENTAL|INVOCATION|HEALING|SOUL|ATTACK|MAGICAL)\s?)+$/;
  const cls = (startRe, endRe) => {
    const from = find(startRe);
    const to = find(endRe, from + 1);
    return { line: from, end: to, sections: sectionsOf(from + 1, to) };
  };
  book.classes = {
    archmage: cls(/^## ARCHMAGE$/, /^## \*\*SORCERER\*\*$/),
    sorcerer: cls(/^## \*\*SORCERER\*\*$/, /^## SPELLBLADE$/),
    // Block 4 (0.7.0): the last two.
    spellblade: cls(/^## SPELLBLADE$/, /^## WARLOCK$/),
    warlock: cls(/^## WARLOCK$/, /^## WITCH$/),
    witch: cls(/^## WITCH$/, /^# CHAPTER 4 - SKILLS & ACTIONS$/)
  };
  for (const [k, c] of Object.entries(book.classes)) {
    const tbl = c.sections.flatMap((x) => x.tables).find((t) => /TABLE$/.test(t.rows[0]?.cells?.[0] ?? ""));
    if (!tbl || tbl.rows.length !== 22) throw new Error(`extract: the ${k} table has ${tbl?.rows?.length} rows, expected a title, a heading and 20 levels`);
  }
}

// Block 9b (0.14.0): each rune's tiers, from its sidebar (the sidebars are read above).
for (const key of ["armourRunes", "weaponRunes"]) {
  for (const e of book.sections[key] ?? []) {
    const box = book.sidebars.find((b) => b.title === `${e.name} I`);
    if (!box) continue;
    const tiers = [];
    let cur = null;
    for (const raw of box.lines) {
      const l = raw.trim();
      if (!l) continue;
      if (new RegExp(`^${e.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} [IVX]+$`).test(l)) { cur = { name: l, level: 0, price: "", text: "" }; tiers.push(cur); continue; }
      if (!cur) continue;
      const lv = /^Level (\d+); (?:Armour\/Shield )?Price (.+)$/.exec(l);
      if (lv) { cur.level = Number(lv[1]); cur.price = lv[2]; continue; }
      cur.text = cur.text ? `${cur.text} ${l}` : l;
    }
    e.tiers = tiers;
  }
}

// An optional third argument writes elsewhere (verify-book-extract re-cuts into a scratch file).
const OUT = process.argv[4] ? path.resolve(process.argv[4]) : path.join(HERE, "book-text.json");
fs.writeFileSync(OUT, JSON.stringify(book, null, 1) + "\n");
console.log("sidebars", book.sidebars.length);
console.log("grimoire", book.grimoire.length);
console.log("specialist", book.specialist.length);
for (const [k, c] of Object.entries(book.classes)) console.log(k, c.sections.length, "sections");
for (const [k, v] of Object.entries(book.sections)) console.log(k, Array.isArray(v) ? v.length : v.rows ? `table ${v.rows.length - 1} rows` : Object.keys(v).length);
