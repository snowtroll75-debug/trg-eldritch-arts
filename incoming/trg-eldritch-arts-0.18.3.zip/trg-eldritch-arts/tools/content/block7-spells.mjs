/**
 * Eldritch Arts — Block 7 (0.10.0): the first half of Chapter 8's Grimoire,
 * 42 spells (book v1.6, ea.md L6022–8047), and the Elemental Strike ability
 * the spell of that name grants.
 *
 * THE SPEC IS docs/ELDRITCH_ARTS_BLOCK7_AUDIT.md §5.2, as Graham answered it on
 * 7 November 2026: Q150 changed (recurring damage stacks by type: the core's
 * rule in TRG Prime 3.685.0, `layRecurring`), Q151–Q166 as proposed, seams
 * H1–H11 approved and built in TRG Prime 3.685.0.
 *
 * THE PRINTED TEXT IS THE BOOK'S, read from tools/content/book-text.json
 * (`book.grimoire`, cut from v1.6 by extract-book.mjs), never retyped. Each
 * card is that text followed by one paragraph saying what TRG Prime does with
 * it, opening with its grade: *Automated* (A), *Automated, with a choice* (B),
 * *Partly automated* (C: the clause left to the table is named), *Not
 * automated* (D: a card).
 *
 * THE SHAPE IS THE CORE SPELLS PACK'S: each spell uses only effect kinds and
 * warp `mods` the core reads (the nearest core spell is named in each spec).
 * What is not data is module/block7-automations.mjs, found by the item's
 * `flags.trg-prime.eaGrimoire` key; the pure rules and the two open readings
 * are module/block7-rules.mjs.
 *
 * EVERY CHAPTER 8 SPELL IS UNCOMMON (m84; Q166): `system.availability`.
 * TRADITION "ALL" is authored as the four traditions (audit §6); the card
 * keeps "all". HIGH MAGIC spells print no tradition and carry HIGHMAGIC (M29).
 */
import fs from "node:fs";
import { ability, stableId } from "./builders.mjs";
import { md } from "./markdown.mjs";
import { build } from "./block3-spells.mjs";
import { distractedRows } from "../../module/distracted.mjs";
import {
  ANY_MELEE_FEET, ALL_TRADITIONS, GRIMOIRE_AVAILABILITY, DRAGON_WINGS_BASE_FEET, DRAGON_WINGS_STEP_FEET, DRAGON_WINGS_FLY_CAP,
  SPIRIT_ARROW_DICE, SPIRIT_ARROW_REPLACES, SPIRIT_ARROW_FLAT, SPIRIT_ARROW_MAX_ARROWS, TRUE_NAME_MARK, ANCHOR_MARK, ANCHOR_VEIL_UNLOCK,
  ZONE_EXEMPT_MARK, ZONE_AFFECTED_MARK, ZONE_FUMBLE_UNLOCK, ARGENT_ABSORB_UNLOCK, ARGENT_MAX_ATTEMPTS, MIRROR_SPELL_UNLOCK,
  MIRROR_TELEPORT_UNLOCK, PANIC_UNSEEN_UNLOCK, PANIC_RESIST_UNLOCK, PANIC_FAR_UNLOCK, RESONANCE_HALF_UNLOCK, RESONANCE_FREE_UNLOCK,
  RESONANCE_SWAP_UNLOCK, MYCELIUM_REACTIVE_UNLOCK, CHRONO_SLOW_UNLOCK, EAOG_COLDFIRE_UNLOCK, GLYPH_TYPE_UNLOCK, GLYPH_TYPES, ELEMENTAL_STRIKE_ABILITY,
  BASTION_MAX_STEPS, MODULE_ID
} from "../../module/block7-rules.mjs";

const BOOK = JSON.parse(fs.readFileSync(new URL("./book-text.json", import.meta.url), "utf8"));
const GRIM = new Map(BOOK.grimoire.map((e) => [e.name, e]));

const SINCE = "0.10.0, TRG Prime 3.685.0";
const AUTO = `*Automated (${SINCE}):*`;
const CHOICE = `*Automated, with a choice (${SINCE}):*`;
const PARTLY = `*Partly automated (${SINCE}):*`;
// THE FIVE BLOCK 7 SEAMS (0.16.0, TRG Prime 3.692.0; Graham, 15 November 2026: "All five").
const SINCE16 = "0.16.0, TRG Prime 3.692.0";
const AUTO16 = `*Automated (${SINCE16}):*`;
const CHOICE16 = `*Automated, with a choice (${SINCE16}):*`;
const PARTLY16 = `*Partly automated (${SINCE16}):*`;
const NOT = "*Not automated:*";

/** The Elemental Strike ability's compendium uuid, for the spell's `grantAbility` row. */
const ELEMENTAL_STRIKE_ID = stableId(`abilities:${ELEMENTAL_STRIKE_ABILITY}`);
export const ELEMENTAL_STRIKE_UUID = `Compendium.${MODULE_ID}.ea-abilities.Item.${ELEMENTAL_STRIKE_ID}`;

const mark = (key, label, extra = {}) => ({ kind: "moduleMark", target: "targets", module: MODULE_ID, key, label, ...extra });
const cond = (condition, extra = {}) => ({ kind: "condition", target: "targets", condition, ...extra });
const cl = (threshold, text, extra = {}, recurring = true) => ({ threshold, recurring, damageDice: "", saveDC: 0, attack: 0, text, ...extra });

/**
 * Each spell: the cast fields the book does not print in a field of its own,
 * its effect rows, the `mods` of each printed warp by position, its caster
 * level steps, its key for the automations, its grade for the docs and the
 * harness, and the paragraph its card shows.
 */
const SPEC = {
  /* ============================== Cantrips ============================== */
  BRITTLESKIN: {
    key: "brittleskin", grade: "A",
    // The Saving Throw line is not printed (EA-m99): "1d4 piercing damage (basic Fort)" is read from the prose.
    defence: "", category: "utility",
    effects: [
      { kind: "bonus", target: "self", slot: "dr", bonusType: "status", value: 1, duration: "until the start of your next turn" },
      { kind: "thorns", target: "self", label: "Brittleskin", damage: "1d4", damageType: "piercing", save: { key: "fortitude", dc: "spell" }, reachFeet: ANY_MELEE_FEET, duration: "until the start of your next turn" }
    ],
    casterLevelMods: [cl(4, "the DR increases by 1 and the damage increases by 1d4.", { rows: [{ match: { kind: "bonus", slot: "dr" }, add: { value: 1 } }, { match: { kind: "thorns" }, add: { damage: "1d4" } }] })],
    what: "+1 status DR to the start of your next turn; a melee hit on you costs the attacker 1d4 piercing (basic Fort at your Save DC); CL 4 and every 4: +1 DR, +1d4",
    text: `${AUTO} until the start of your next turn you gain +1 DR (a status bonus, as the core's Iron Body writes DR), and any creature that hits you with a melee Strike, at any reach, rolls a basic Fortitude save at your Save DC against 1d4 piercing damage (the core's thorns, H1). At CL 4 and every 4 levels after, the DR rises by 1 and the damage by 1d4 (H2).`
  },
  DECOHERENCE: {
    key: "decoherence", grade: "B", category: "utility", targetsObject: true,
    effects: [{ kind: "heldBonus", target: "self", label: "Decoherence", value: 1, bonusType: "circumstance", checkTypes: ["skill"], actions: ["identifyPower", "recallKnowledge", "dispel", "disableADevice"], duration: "until the end of your next turn", spentNote: "Spent on a check to interact with, identify or suppress that object or aura." }],
    casterLevelMods: [cl(4, "the bonus increases by +1.", { rows: [{ match: { kind: "heldBonus" }, add: { value: 1 } }] })],
    what: "a held +1 circumstance (one-shot) for your next Identify Power, Recall Knowledge, Dispel or Disable a Device check, to the end of your next turn; +1 at CL 4 and every 4",
    text: `${CHOICE} you hold a +1 circumstance bonus (Guidance's shape), offered as a tick on your next Identify Power, Recall Knowledge, Dispel or Disable a Device check and spent on it, until the end of your next turn. Tick it only on a check made to interact with, identify or suppress the object or aura you targeted — which object is the table's. At CL 4 and every 4 levels after, +1 (H2).`
  },
  DREADMOTE: {
    key: "dreadmote", grade: "A", category: "attack", targets: "1 creature",
    damage: { formula: "1d4", type: "essence" },
    casterLevelMods: [cl(4, "the damage increases by 1d4.", { damageDice: "1d4" })],
    what: "spell attack (1 AP, multiple attack penalty as M39), 1d4 essence; +1d4 at CL 4 and every 4",
    text: `${AUTO} a spell attack for 1d4 essence damage (Orb of Force's shape), cast for 1 AP; as Graham ruled (M39) it takes your multiple attack penalty. At CL 4 and every 4 levels after, +1d4. The Fear trait adds no effect of its own, as printed.`
  },
  DREARLIGHT: {
    key: "drearlight", grade: "C", category: "utility",
    effects: [
      { kind: "lightShift", target: "targets", label: "Drearlight", steps: 1, radiusFeet: 10, follows: true },
      { kind: "note", text: "The light suppresses magical darkness of PP 2 or lower (4 at CL 4; +2 at CL 8 and every 4 CL after) within its radius — applied by hand: no core darkness places darkness to suppress." }
    ],
    what: "dim light (+1 illumination step) in 10 ft around the targeted object's bearer; the darkness suppression and a cast on a bare square by hand",
    text: `${PARTLY} target the token carrying the object: a 10-foot circle of dim light (one illumination step, the core's light shift) moves with it for the minute. *By hand:* a cast on an empty 5-foot square (place the light yourself), and the suppression of magical darkness (PP 2 or lower; 4 at CL 4, +2 at CL 8 and every 4 CL after) — the core's Darkness places no darkness for it to suppress.`
  },
  FELTWARP: {
    key: "feltwarp", grade: "B", category: "utility", targets: "the creature wearing the item",
    effects: [{ kind: "conditional", label: "Feltwarp", target: "targets", grants: [{ kind: "modifier", value: 1, type: "item", label: "Feltwarp", scope: "Sneak (Stealth) checks involving worn soft gear", when: { checkTypes: ["skill"], subjects: ["stealth"] } }] }],
    casterLevelMods: [cl(4, "the duration increases by 1 hour.", { duration: { amount: 1, unit: "hours" } })],
    what: "the wearer (Q165): +1 item to Sneak (Stealth) checks involving worn soft gear, a tick; +1 hour at CL 4 and every 4",
    text: `${CHOICE} target the creature wearing the item (Q165: it gets the bonus while it wears it). Its Stealth checks offer a +1 item bonus as a tick — tick it on a Sneak check involving worn soft gear. 1 hour, +1 hour at CL 4 and every 4 levels after (H2). The item's look is the table's.`
  },
  FRESHMARK: {
    key: "freshmark", grade: "D", category: "utility", targetsObject: true,
    effects: [{ kind: "note", text: "Cleans and freshens one object or 5-ft square (another at CL 4). The table's." }],
    casterLevelMods: [cl(4, "affect another object or area.", {}, false)],
    what: "card only",
    text: `${NOT} cleaning and freshening an object or square is the table's.`
  },
  "INVOKE TRUE NAME": {
    key: "invokeTrueName", grade: "B", category: "utility",
    effects: [mark(TRUE_NAME_MARK, "Invoke True Name")],
    // Q164: once, at CL 8 (not recurring); the penalty is read off the mark's caster level.
    casterLevelMods: [cl(8, "The penalty increases to -4.", {}, false)],
    what: "a mark to the end of your turn: your spell attacks treat it as flat-footed, −2 circumstance (−4 at CL 8) on its saves against your spells, weakness to the first damage it takes from your spells this turn",
    text: `${CHOICE} the creature is marked until the end of your turn. While it is: your spell attacks against it add what flat-footed takes from its DB (its Dexterity and dodge); it takes a −2 circumstance penalty to saving throws against your spells (−4 from CL 8, once: Q164); and the first time this turn it takes damage from one of your spells, it has weakness to that damage (TRG Prime 3.685.0's damage-reaction weakness). *By hand:* that you know its true name — the cast is not refused on a creature whose name you do not know.`
  },
  "NECROTIC WHISPER": {
    key: "necroticWhisper", grade: "A", category: "attack",
    damage: { formula: "1d4", type: "essence" }, secondary: { formula: "1", type: "sonic" },
    casterLevelMods: [cl(4, "the damage increases by 1d4 and 1 respectively.", { damageDice: "1d4", secondary: 1, persistent: 0 })],
    what: "spell attack, 1d4 essence + 1 secondary sonic; +1d4 and +1 at CL 4 and every 4; \"living\" by hand",
    text: `${AUTO} a spell attack; on a hit, 1d4 essence and then 1 secondary sonic damage, each against its own defences (Orb of Water's shape). At CL 4 and every 4 levels after, +1d4 and +1 secondary. *By hand:* "1 living creature" — the cast is not refused on an undead or construct.`
  },
  "ORB OF DUSK": {
    key: "orbOfDusk", grade: "A", category: "attack",
    damage: { formula: "1d4", type: "essence" }, secondary: { formula: "1", type: "cold" },
    casterLevelMods: [cl(4, "the damage increases by 1d4 and 1 respectively.", { damageDice: "1d4", secondary: 1, persistent: 0 })],
    what: "spell attack, 1d4 essence + 1 secondary cold, 60 ft; +1d4 and +1 at CL 4 and every 4",
    text: `${AUTO} a spell attack; on a hit, 1d4 essence and then 1 secondary cold damage, each against its own defences (Orb of Water's shape). At CL 4 and every 4 levels after, +1d4 and +1 secondary.`
  },
  "RECKONING GLANCE": {
    key: "reckoningGlance", grade: "D", category: "utility",
    effects: [{ kind: "note", text: "Name a type of visible item: the GM gives the rough count within the emanation (20 ft; +20 ft at CL 4)." }],
    casterLevelMods: [cl(4, "the emanation increases by 20 feet.", {}, false)],
    what: "card only",
    text: `${NOT} the count is the GM's.`
  },

  /* ===================== Attack, save and area spells ===================== */
  "ACIDIC BURST": {
    key: "acidicBurst", grade: "A", category: "save",
    damage: { formula: "3d6", type: "acid" },
    warpMods: [{ areaGrowth: 5 }],
    what: "basic Reflex against 3d6 acid in 5 ft around you (you are not caught); +5 ft a warp",
    text: `${AUTO} drawn around you (no range is printed), every creature in the 5-foot radius but you rolls a basic Reflex save against 3d6 acid damage (Burning Hands' shape; the core leaves a hostile area centred on its caster out). Each +2 PP option adds 5 feet.`
  },
  "ANIMATE MOUSTACHE": {
    key: "animateMoustache", grade: "A", category: "save", targets: "1 creature (one moustache or eyebrow)",
    effects: distractedRows({ onSave: ["failure", "fumble"] }),
    what: "Will; on a Failure or worse (a Partial reads Failure, m42), Distracted for 1 minute",
    text: `${AUTO} the creature rolls a Will save. On a Failure or worse it is **Distracted** for the minute: −1 status to attack checks, skill checks, saving throws and casting checks (Q157; not to DB or damage), shown on its sheet as one effect, "Distracted" (your second casting replaces your first; another caster's, or another spell's, stands beside it, and the penalty stays −1). A Partial reads as a Failure (m42).`
  },
  "ARCANE FEEDBACK": {
    key: "arcaneFeedback", grade: "B", category: "save", castAP: "Reaction", targets: "the triggering enemy",
    damage: { formula: "", type: "force" },
    effects: [{ kind: "saveLadder", target: "targets", damageType: "force", ladder: { critical: "", success: "2d8", partial: "4d8", failure: "4d8", fumble: "8d8" } }],
    warpMods: [{ bonusValue: 1, bonusMax: 2 }],
    what: "offered when an enemy within 30 ft casts: Will ladder 2d8/4d8/4d8 + Minor/8d8 + Serious force, the damage taken a penalty to its casting check; +1 step a warp (max deadly)",
    text: `${CHOICE} when an enemy within 30 feet of you casts a spell, you are asked (your player, else the GM) before its casting check is rolled. Yes casts this spell as your reaction, with its own casting check and PP, at that enemy: a Will save — Critical nothing; Success 2d8 force; Partial 4d8; Failure 4d8 and a Minor force critical; Fumble (and Blunder, m42) 8d8 and a Serious force critical. The damage it takes is a penalty to its casting check (Q158). An innate spell rolls no check, so it only takes the damage. Each +2 PP option makes the critical a step worse (Minor → Serious → Deadly).`
  },
  "ARCANE MYCELIUM": {
    key: "arcaneMycelium", grade: "A", category: "utility",
    effects: [
      { kind: "difficultTerrain", target: "area", label: "Arcane Mycelium" },
      {
        kind: "entryCheck", target: "area", label: "Arcane Mycelium", save: "reflex", atTurnStart: true,
        degrees: {
          heroic: { unaffected: true }, critical: { unaffected: true }, success: { unaffected: true },
          // m42: no Partial is printed, so a Partial is a Failure.
          partial: { text: "is slowed 1 until the end of its next turn", rows: [cond("slowed", { value: 1, duration: "until the end of its next turn" })] },
          failure: { text: "is slowed 1 until the end of its next turn", rows: [cond("slowed", { value: 1, duration: "until the end of its next turn" })] },
          fumble: { text: "is slowed 2 until the end of its next turn", rows: [cond("slowed", { value: 2, duration: "until the end of its next turn" })] }
        }
      }
    ],
    warpMods: [{ unlocks: [MYCELIUM_REACTIVE_UNLOCK] }],
    what: "difficult terrain; dim light inside (at least light level 5, as a light source); Reflex on entering or starting a turn inside (slowed 1 / 2 to the end of its next turn); the +2 PP reactive threads (2d6 essence, basic Fort, on a cast inside)",
    text: `${AUTO16} the 10-foot radius is difficult terrain, and a creature that enters it or begins its turn in it rolls a Reflex save at your Save DC: Failure (and Partial, m42) slowed 1, Fumble slowed 2, until the end of its next turn (H3a). With the +2 PP option, a creature that casts a spell while inside takes 2d6 essence damage (a basic Fortitude save at your Save DC) as its casting check is about to be rolled. The area emits dim light: inside it the light level is at least Dim Light (5), as a light source gives (TRG Prime 3.692.0's Region light), so it brightens darkness and never dims a brighter place. The colour of your tradition is cosmetic and is not drawn.`
  },
  "BUBBLE BUFFET": {
    key: "bubbleBuffet", grade: "A", category: "utility",
    // The Will save is the turn ladder's (rolled at the cast and at each of your turns), not the cast's own.
    defence: "",
    effects: [{
      kind: "turnLadder", target: "area", save: "will", on: "casterTurnStart", atCast: true, replace: "worse", stopAt: "failure",
      degrees: {
        heroic: { unaffected: true }, critical: { unaffected: true },
        success: { rows: distractedRows({ duration: "until the end of its next turn" }) },
        partial: { rows: distractedRows() },
        failure: { rows: [cond("fixated")] },
        fumble: { rows: [cond("fixated"), cond("slowed", { value: 1 })] }
      }
    }],
    warpMods: [{ durationText: "10 minutes" }],
    what: "Will at the cast and at the start of each of your turns for everyone in it: Distracted (to its next turn's end / the duration), fixated, + slowed 1; a failure rolls no more, a worse result replaces a better (m100)",
    text: `${AUTO} at the cast and at the start of each of your turns, every creature in the 10-foot radius rolls a Will save at your Save DC (H3b): Critical unaffected; Success **Distracted** until the end of its next turn; Partial Distracted for the spell's duration; Failure fixated for the duration; Fumble fixated and slowed 1. As ruled (m100), a creature that has failed rolls no more, and a later worse result replaces a better one. Distracted is −1 status to attack checks, skill checks, saving throws and casting checks (Q157). The +4 PP option: 10 minutes.`
  },
  "DRAGON’S BREATH": {
    key: "dragonsBreath", grade: "A", category: "save",
    damage: { formula: "2d6", type: "fire" },
    // Until a type is chosen the area is the cone's; the module writes the chosen type, area and range step.
    area: "15-foot cone",
    warpMods: [{ damageDice: "1d6" }, { areaGrowth: 5, areaMax: 60 }],
    what: "the type chosen when learned (a Draconic Pact's is its energy): basic Reflex, 2d6, a 30-ft line (acid, electricity) or 15-ft cone; +1d6 and +10 ft line / +5 ft cone warps",
    text: `${AUTO} when the spell is added to your sheet you choose acid, cold, electricity, fire or poison (a Draconic Pact's Dragon's Breath takes the Pact's energy); the spell keeps it, with its trait (m104). Acid and electricity breathe a 30-foot line, the others a 15-foot cone: every creature in it rolls a basic Reflex save against 2d6 of that type. +1 PP: +1d6. +1 PP: the line +10 feet (to 120) or the cone +5 feet (to 60). Blood of the Wyrm's dragon-type warp still applies. A spell with no type yet asks for one when you first cast it.`
  },
  "EAOG BALLS": {
    key: "eaogBalls", grade: "C", category: "save", targets: "1 creature",
    effects: [
      cond("immobilised", { onSave: ["failure"], note: "(speed 0)" }),
      { kind: "conditional", label: "Eaog Balls", target: "targets", onSave: ["success"], grants: [{ kind: "disadvantage", label: "Eaog Balls", scope: "attack rolls until the spell ends", when: { checkTypes: ["attack"] }, auto: true }] },
      { kind: "conditional", label: "Eaog Balls", target: "targets", onSave: ["failure"], grants: [{ kind: "disadvantage", label: "Eaog Balls", scope: "skill checks and attack rolls until the spell ends", when: { checkTypes: ["attack", "skill"] }, auto: true }] },
      cond("stunned", { onSave: ["fumble"], value: 3 }),
      cond("immobilised", { onSave: ["fumble"] }),
      cond("recurring", { onSave: ["success"], formula: "1d6", damageType: "force" }),
      cond("recurring", { onSave: ["failure"], formula: "2d6", damageType: "force" }),
      cond("recurring", { onSave: ["fumble"], formula: "3d6", damageType: "force" }),
      cond("recurring", { onSave: ["success", "failure", "fumble"], formula: "2d8", damageType: "coldfire", unlockedBy: EAOG_COLDFIRE_UNLOCK }),
      { kind: "speedHalve", target: "targets", onSave: ["critical"], note: "speed halved", duration: "until the end of its next turn" },
      { kind: "speedHalve", target: "targets", onSave: ["success"], note: "speed halved" },
      { kind: "note", onSave: ["fumble"], text: "It automatically fails Strength- and Dexterity-based checks while affected — by hand." },
      { kind: "note", text: "The cracking and collapsing ground is the GM's." }
    ],
    warpMods: [{ unlocks: [EAOG_COLDFIRE_UNLOCK] }],
    what: "Fortitude ladder: disadvantage on attacks / attacks and skills, speed 0 (immobilised), stunned 3 + immobilised; 1d6/2d6/3d6 recurring force and the warp's 2d8 coldfire, each type its own total and flat check (Q150); dispels at disadvantage (a tick); speed halved on a Critical (to the end of its next turn) and a Success (the spell's length); the auto-failed Str/Dex checks by hand",
    text: `${PARTLY16} the target rolls a Fortitude save. Critical — its speed is halved until the end of its next turn. While you sustain the spell: Success — its speed is halved, disadvantage on attack rolls and 1d6 recurring force damage; Failure — speed 0 (immobilised), disadvantage on skill checks and attack rolls, 2d6 recurring force; Fumble — stunned 3 and immobilised, 3d6 recurring force. With the +2 PP option, a Success or worse also gives 2d8 recurring coldfire damage. As Graham ruled (Q150, now TRG Prime 3.685.0's rule), the force and the coldfire are two totals of two types, each with its own flat check; the recurring damage is dealt in the end phase, as all recurring damage is. A Dispel aimed at this spell offers a tick for disadvantage (the core's dispel bias). A halved speed is each of its speeds, after armour and load, rounded down to 5 feet (TRG Prime 3.692.0), as the Failure's speed 0 is the immobilised condition that stops every kind of movement; two halvings do not quarter it. *By hand:* the Fumble's automatic failure of Strength- and Dexterity-based checks; the cracking ground.`
  },
  "ELEMENTAL STRIKE": {
    key: "elementalStrike", grade: "B", category: "utility", defence: "",
    damage: { formula: "", type: "fire" },
    effects: [{ kind: "grantAbility", target: "self", uuid: ELEMENTAL_STRIKE_UUID, label: ELEMENTAL_STRIKE_ABILITY }],
    warpMods: [{ damageDice: "1d6" }],
    what: "the type chosen when learned (an Elemental Pact's: its element's); for the minute, an Elemental Strike Use (1 AP, any number, no multiple attack penalty; 'a Strike' for other rules by hand): basic Reflex at the cast's Save DC against 1d6 + casting ability (+1d6 a warp)",
    text: `${CHOICE} when the spell is added to your sheet you choose acid, cold, electricity or fire (an Elemental Pact's takes its element's: air electricity, earth acid, fire fire, water cold). Casting it gives you the **${ELEMENTAL_STRIKE_ABILITY}** ability for the minute, its Save DC fixed at the cast's (warps included). Each **Use** (1 AP, a melee weapon wielded) picks a creature within your weapon's reach, which rolls a basic Reflex save against 1d6 + your casting ability of that type, +1d6 per +4 PP option, Base Damage 1d6 on a critical (Q155). Any number in the minute; each takes and adds no multiple attack penalty, and deals no weapon damage. *By hand:* that each counts as a Strike for rules that count Strikes (Q155) — the Use fires no Strike and no Strike count.`
  },
  "FLESH TO BLOSSOM": {
    key: "fleshToBlossom", grade: "B", category: "save",
    damage: { formula: "", type: "acid" },
    effects: [
      { kind: "saveLadder", target: "targets", damageType: "", ladder: { critical: "", success: "1d12", failure: "2d12", fumble: "4d12" } },
      cond("immobilised", { onSave: ["failure"] }),
      cond("petrified", { onSave: ["fumble"] }),
      {
        kind: "turnLadder", target: "targets", save: "fortitude", on: "targetTurnStart", onSave: ["success", "failure", "fumble"],
        degrees: {
          heroic: { endsSpell: true }, critical: { endsSpell: true },
          success: { dice: "1d12", rows: [] },
          failure: { dice: "2d12", rows: [cond("immobilised")] },
          fumble: { dice: "4d12", rows: [cond("petrified")] }
        }
      },
      { kind: "note", onSave: ["fumble"], text: "Petrified (Plant Form) until the spell ends or Remove Curse ends it." }
    ],
    warpMods: [{ extraTargets: 1 }],
    what: "acid or poison chosen at the cast; Fortitude ladder 1d12 / 2d12 + immobilised / 4d12 + petrified, saved again at the start of each of its turns while sustained, each result replacing the last; +1 target a warp",
    text: `${CHOICE} as you cast you choose acid or poison. The target rolls a Fortitude save: Critical, no effect and it saves no more; Success 1d12; Failure 2d12 and immobilised; Fumble 4d12 and petrified (Plant Form). While you sustain it, it saves again at the start of each of its turns, and each result replaces the last (Q156, H3c): a Critical ends the spell, a Success is 1d12 and ends the immobilised, a Failure 2d12 and immobilised, a Fumble 4d12 and petrified. A Partial reads as a Failure (m42). Each +2 PP option adds a target within 30 feet of the first. Remove Curse ends it, as the core's Remove Curse counteracts a curse.`
  },
  "GLYPH OF RETRIBUTION": {
    key: "glyphOfRetribution", grade: "B", category: "utility", defence: "",
    effects: [
      { kind: "bonus", target: "self", slot: "defence", bonusType: "status", value: 2 },
      { kind: "thorns", target: "self", label: "Glyph of Retribution", damage: "1d6", damageType: "sonic", save: { key: "fortitude", dc: "spell" }, casterLevelBonus: { max: 15 }, reachFeet: ANY_MELEE_FEET, supersededBy: GLYPH_TYPE_UNLOCK },
      // THE +4 PP TYPE CHANGE (TRG Prime 3.692.0's thorns `typeChoices`): asked of you each time you are struck.
      { kind: "thorns", target: "self", label: "Glyph of Retribution", damage: "1d6", damageType: "sonic", typeChoices: GLYPH_TYPES, save: { key: "fortitude", dc: "spell" }, casterLevelBonus: { max: 15 }, reachFeet: ANY_MELEE_FEET, unlockedBy: GLYPH_TYPE_UNLOCK }
    ],
    warpMods: [{ durationText: "1 hour" }, { unlocks: [GLYPH_TYPE_UNLOCK] }],
    what: "+2 status DB; a melee hit on you: basic Fortitude at your Save DC against 1d6 + caster level (max +15) sonic; with the +4 PP option you choose acid, cold, electricity or fire each time you are struck",
    text: `${CHOICE16} for the duration you gain a +2 status bonus to DB, and any creature that hits you with a melee attack rolls a basic Fortitude save at your Save DC against 1d6 sonic damage + 1 per caster level (maximum +15), fixed at the cast (H1). +4 PP: 1 hour. +4 PP: each time you are struck you are asked which of acid, cold, electricity or fire the glyph deals this time (TRG Prime 3.692.0's thorns \`typeChoices\`, asked of your player); unanswered, it stays sonic and the card says so.`
  },
  "LEYLINE BURST": {
    key: "leylineBurst", grade: "A", category: "save",
    damage: { formula: "4d6", type: "force" },
    effects: [{ kind: "forcedMove", target: "targets", label: "Leyline Burst", feet: 10, direction: "away", onSave: ["failure", "fumble"] }],
    warpMods: [{ damageDice: "1d6" }, { areaOverride: "10-foot radius" }],
    what: "basic Reflex against 4d6 force; pushed 10 ft away on a Failure or worse; +1d6 and a 10-ft burst on the target warps; High Magic",
    text: `${AUTO} a High Magic spell (cast as Block 2's High Magic). The target rolls a basic Reflex save against 4d6 force damage, and on a Failure or worse is pushed 10 feet away from you (Gust's row). +1 PP: +1d6. +3 PP: every creature in a 10-foot burst centred on the target.`
  },
  "MEMORY ECLIPSE": {
    key: "memoryEclipse", grade: "A", category: "save", defence: "Will",
    effects: [
      cond("dazed", { onSave: ["success"], value: 1, duration: "1 round" }),
      cond("dazed", { onSave: ["failure"], value: 2, duration: "10 minutes" }),
      cond("dazed", { onSave: ["fumble"], value: 2, duration: "10 minutes" }),
      cond("frightened", { onSave: ["fumble"], value: 2 }),
      { kind: "note", onSave: ["failure", "fumble"], text: "It forgets the last minute." },
      { kind: "note", onSave: ["fumble"], text: "It cannot recognise allies and treats every creature as a potential threat." }
    ],
    warpMods: [{ extraTargets: 1 }],
    what: "Will (read from the prose): dazed 1 for 1 round / dazed 2 for 10 minutes / + frightened 2; +1 target within 10 ft a warp; High Magic",
    text: `${AUTO} a High Magic spell. The target rolls a Will save (no Saving Throw line is printed; the prose names it): Critical no effect; Success dazed 1 for 1 round; Failure dazed 2 for 10 minutes; Fumble that and frightened 2. A Partial reads as a Failure (m42). The forgotten minute and the threats it sees in its allies are the table's, named on the card. Each +2 PP option adds a target within 10 feet of the first.`
  },
  "PLANAR ANCHOR": {
    key: "planarAnchor", grade: "B", category: "save",
    effects: [
      mark(ANCHOR_MARK, "Planar Anchor", { onSave: ["success"], duration: "1 minute" }),
      mark(ANCHOR_MARK, "Planar Anchor", { onSave: ["partial"], duration: "10 minutes" }),
      mark(ANCHOR_MARK, "Planar Anchor", { onSave: ["failure", "fumble"], duration: "1 hour" }),
      cond("slowed", { onSave: ["fumble"], value: 1, duration: "1 minute" })
    ],
    warpMods: [{ areaOverride: "20-foot radius" }, { unlocks: [ANCHOR_VEIL_UNLOCK] }],
    what: "Will: anchored 1 minute / 10 minutes / 1 hour (Fumble + slowed 1 for 1 minute); a Teleportation spell cast by or on it is counteracted; the veil warp adds invisibility and incorporeality",
    text: `${CHOICE} the target rolls a Will save: Critical no effect; Success anchored for 1 minute; Partial 10 minutes; Failure 1 hour; Fumble 1 hour and slowed 1 for 1 minute. While anchored, any spell with the Teleportation trait cast by it, or at it, is counteracted (m121 as proposed: the casting is refused). +2 PP: every creature in a 20-foot burst. +4 PP: a spell that would make it invisible or incorporeal is counteracted too. *By hand:* abilities that teleport or move it between planes and are not spells.`
  },
  "PRIMAL SNAP": {
    key: "primalSnap", grade: "B", category: "utility",
    // The basic Fortitude is at the start of a turn inside, not at the cast.
    defence: "",
    effects: [
      { kind: "zone", target: "area", label: "Primal Snap", condition: "concealed", obscuresOutward: true },
      { kind: "note", text: "A creature that begins its turn in the fog rolls a basic Fortitude save against 6d8 cold damage; on a Failure or worse, −10 status to its Speeds until it regains HP. Moving the fog 10 ft on a Sustain: drag its Region." }
    ],
    warpMods: [{ damageDice: "1d8" }],
    what: "concealed both ways in the fog; a creature beginning its turn in it: basic Fortitude against 6d8 cold (+1d8 a warp), and on a Failure or worse −10 status Speeds until it regains HP (H11); moving the fog by hand",
    text: `${CHOICE} the 20-foot fog conceals every creature in it, and everything outside from those within (Solid Fog's zone). A creature that begins its turn in it rolls a basic Fortitude save at your Save DC against 6d8 cold damage (+1d8 per +1 PP option); on a Failure or worse it also takes a −10 status penalty to its Speeds until it regains any HP (Q160, H11), not stacking with itself. It lasts 1 minute either way (Q160). *By hand:* moving the fog — a Sustain (1 AP) moves it 10 feet: drag its Region.`
  },
  "PRISMATIC GUARD": {
    key: "prismaticGuard", grade: "A", category: "utility", defence: "",
    // "you … and any creatures within the spells area at the time of casting": a placed radius, so who it
    // caught at the cast keeps it (the printed emanation would follow you and change who it covers).
    area: "10-foot radius",
    effects: [
      { kind: "defence", target: "targets", field: "resistance", value: "acid, cold, electricity, fire, sonic, essence, force" },
      { kind: "defence", target: "targets", field: "immunity", value: "blinded, dazzled" },
      {
        kind: "thorns", target: "targets", label: "Prismatic Guard", damage: "", damageType: "", save: { key: "fortitude", dc: "spell" }, reachFeet: ANY_MELEE_FEET,
        ladder: {
          critical: [],
          success: [cond("dazzled", { duration: "until the end of its turn" })],
          partial: [cond("dazzled", { duration: "until the end of its next turn" })],
          failure: [cond("blinded", { duration: "until the end of its next turn" })],
          fumble: [cond("blinded", { duration: "permanent" })]
        }
      }
    ],
    warpMods: [{ durationText: "1 hour" }, { durationText: "until your next daily preparations" }],
    what: "you and everyone in 10 ft at the cast: resistance to acid, cold, electricity, fire, sonic, essence and force (M53), immune to blinded and dazzled; a melee attacker that damages one rolls Fortitude: dazzled / dazzled / blinded / permanently blinded",
    text: `${AUTO} you and every creature within 10 feet of you when you cast it (only those: M53's energy is acid, cold, electricity, fire, sonic, essence and force) gain resistance to those types and immunity to blinded and dazzled for the duration. A creature that damages one of them with a melee strike rolls a Fortitude save at your Save DC once the attack is resolved (H1): Critical unaffected; Success dazzled until the end of its turn; Partial dazzled until the end of its next turn; Failure blinded until the end of its next turn; Fumble permanently blinded. +1 PP: 1 hour. +2 PP: until your next daily preparations.`
  },
  "SPIRIT ARROW": {
    key: "spiritArrow", grade: "B", category: "utility", defence: "", targets: "one arrow or bolt (you, the archer)", targetsObject: true,
    effects: [{ kind: "strikeRider", target: "self", label: "Spirit Arrow", dice: SPIRIT_ARROW_DICE, damageType: "piercing", scope: "ranged", once: true, ...(SPIRIT_ARROW_REPLACES ? { replacesDamage: true } : {}), ...(SPIRIT_ARROW_FLAT ? { flat: true } : {}) }],
    warpMods: [{ durationText: "10 minutes" }, { bonusValue: 1, bonusMax: SPIRIT_ARROW_MAX_ARROWS - 1 }],
    what: "your next ranged Strike's arrow deals exactly 6d6 piercing, nothing added (H10 flat; ruled \"Flat 6d6\"; it doubles on a critical); on a hit the target saves Will at your spell DC or is frightened half the margin (min 1, Q161); up to 5 arrows; the chosen Feint, Grapple (1 round), Shove or Trip resolved at the attack total",
    text: `${CHOICE16} your next ranged Strike within the duration fires the arrow: its damage is exactly 6d6 piercing in place of the arrow's damage — nothing else adds, no BAB, attribute or feat (Graham's ruling, "Flat 6d6") — and it doubles on a critical as weapon damage does (H10, \`flat\`). On a hit you choose Feint, Grapple (1 round), Shove or Trip, and it is resolved at your attack total as that action (TRG Prime 3.692.0): against the action's own DC, at its printed difficulty (a Feint is Hard) and size penalty, landing its conditions, a Shove's push and the action's clock (the Grapple lasts 1 round), on the GM's client when the target is not yours. As the action's own rules come with it (Graham's Tanglefoot ruling), a Fumble lands the action's own fumble on you. Then the target rolls a Will save against your spell DC: on a failure it is frightened by half the amount it failed by, rounded down, at least 1 (Q161). Each +2 PP option imbues one more arrow (max 5), each fired by its own Strike. +2 PP: 10 minutes.`
  },
  "WORD OF PAIN": {
    key: "wordOfPain", grade: "A", category: "save",
    effects: [
      cond("weakened", { onSave: ["critical"], value: 1, duration: "1 round" }),
      cond("weakened", { onSave: ["success"], value: 1, duration: "1 minute" }),
      cond("weakened", { onSave: ["failure"], value: 2, duration: "10 minutes" }),
      cond("weakened", { onSave: ["fumble"], value: 4, duration: "1 hour" })
    ],
    warpMods: [{ areaOverride: "20-foot radius" }],
    what: "Fortitude: weakened 1 for 1 round / 1 for 1 minute / 2 for 10 minutes / 4 for 1 hour; a 20-ft radius warp",
    text: `${AUTO} the target rolls a Fortitude save: Critical weakened 1 for 1 round; Success weakened 1 for 1 minute; Failure weakened 2 for 10 minutes; Fumble weakened 4 for 1 hour (Word of Fatigue's shape; M58). +4 PP: every creature in a 20-foot radius.`
  },
  "ZONE DISRUPTION": {
    key: "zoneDisruption", grade: "B", category: "save",
    effects: [
      mark(ZONE_EXEMPT_MARK, "Zone Disruption: ignores the zone", { onSave: ["heroic", "critical"] }),
      mark(ZONE_AFFECTED_MARK, "Zone Disruption", { onSave: ["success", "partial", "failure", "fumble", "blunder"] }),
      {
        kind: "entryCheck", target: "area", label: "Zone Disruption", save: "will",
        degrees: {
          heroic: { text: "ignores the zone's penalties", rows: [mark(ZONE_EXEMPT_MARK, "Zone Disruption: ignores the zone")] },
          critical: { text: "ignores the zone's penalties", rows: [mark(ZONE_EXEMPT_MARK, "Zone Disruption: ignores the zone")] },
          success: { text: "is subject to the zone", rows: [mark(ZONE_AFFECTED_MARK, "Zone Disruption")] },
          partial: { text: "is subject to the zone", rows: [mark(ZONE_AFFECTED_MARK, "Zone Disruption")] },
          failure: { text: "is subject to the zone", rows: [mark(ZONE_AFFECTED_MARK, "Zone Disruption")] },
          fumble: { text: "is subject to the zone", rows: [mark(ZONE_AFFECTED_MARK, "Zone Disruption")] }
        }
      }
    ],
    warpMods: [{ areaOverride: "40-foot radius" }, { unlocks: [ZONE_FUMBLE_UNLOCK] }],
    what: "Will on first entering (and for those inside at the cast); a Critical ignores it; inside: casting checks at disadvantage, Spell Concentration DC +2, innate spells roll Spellcraft (Q154); the fumble warp rolls the table twice, the higher",
    text: `${CHOICE} each creature in the zone when you cast it, and each that first enters it after, rolls a Will save; on a Critical (or Heroic) it ignores the zone, and only its first result counts. For the others, while inside: every casting check is rolled at disadvantage; a Spell Concentration check's DC rises by 2; an innate spell (the Warlock's included, and a creature's ability that is an innate spell) rolls a Spellcraft check — innate ability + level against 10 + ⌊1.5 × PP⌋ — and a failure is a failed casting with the use spent, a Fumble rolling the fumble table (Q154, H8). +2 PP: a 40-foot radius. +2 PP: a creature that fumbles a casting inside rolls the fumble table twice and takes the higher (G5's disadvantage). *By hand:* "sustain actions" — the core's Sustain rolls nothing but the Concentration check an interruption asks (which takes the +2); magical effects that are not spells.`
  },

  /* ===================== Wards, buffs and reactions ===================== */
  "AIR BUBBLE": {
    key: "airBubble", grade: "B", category: "utility", castAP: "Reaction",
    effects: [
      { kind: "marker", target: "targets", marker: "waterBreathing" },
      { kind: "conditionRemove", target: "targets", conditions: ["suffocating"], note: "Air Bubble: it breathes normally." }
    ],
    what: "cast from the sheet as your reaction: the target breathes normally (the core's water-breathing marker) and stops suffocating; ending it early on breathable air by hand",
    text: `${CHOICE} cast it from the sheet as your reaction when a creature within 60 feet enters a place where it cannot breathe (the table says when). For the minute it breathes normally — the core's water-breathing marker, so drowning does not run — and suffocating is removed. *By hand:* ending the bubble as soon as it is back in breathable air (dismiss the spell).`
  },
  "ARCANE BASTION": {
    key: "arcaneBastion", grade: "B", category: "utility",
    effects: [
      { kind: "defence", target: "self", field: "resistance", value: "all damage" },
      { kind: "declare", target: "self", label: "Arcane Bastion", flags: { deathGuard: { label: "Arcane Bastion", auto: true, once: true } } }
    ],
    warpMods: [{ bonusValue: 1, bonusMax: BASTION_MAX_STEPS - 1 }],
    what: "resistance to all damage; damage that would take you to 0 HP leaves you on 1 and ends the spell; a critical injury that would leave you dying or incapacitated is read a severity lower (a further step per warp, max 3) and ends the spell",
    text: `${CHOICE} for the duration you have resistance to all damage. If damage would reduce you to 0 HP, the shield shatters and you are left on 1 HP instead (the core's death guard), and the spell ends. If a critical injury you are dealt would leave you dying or incapacitated, the shield shatters, the same d100 is read one severity lower — Minor becomes no injury — and the spell ends (Q151, H7). Each +2 PP option lowers it a further step, to 3 in all. "Incapacitated" is read as unconscious, paralysed, petrified or helpless (not stunned: for Graham).`
  },
  "ARGENT REVERSAL": {
    key: "argentReversal", grade: "B", category: "utility",
    effects: [{ kind: "note", text: "The sigil hovers for the hour: when a creature you can see casts a spell of PP no greater than your maximum PP per cast, you may use your reaction to redirect it." }],
    warpMods: [{ bonusValue: 1, bonusMax: ARGENT_MAX_ATTEMPTS - 1 }, { unlocks: [ARGENT_ABSORB_UNLOCK] }],
    what: "a charge for an hour: offered on a spell whose caster you can see (PP up to your maximum per cast); Spellcraft against that cast's Save DC — Critical/Success turned back at your check and Save DC (a Critical may choose another target), Fumble 4d10 / Blunder 8d10 essence (basic Fort); absorb warp; +1 attempt a warp",
    text: `${CHOICE} the sigil hovers for an hour. When a creature you can see casts a spell of PP no greater than your maximum PP per cast (Q153), you are asked (your player, else the GM): yes spends your reaction and rolls Spellcraft against that cast's own Save DC (H5). Critical — the spell is turned back on its caster, or on one other creature within its range that you choose; Success — turned back on its caster; either way it resolves at your Spellcraft total (its attack) and your Save DC (its saves). Failure (and Partial, m42) — it resolves as cast. Fumble — as Failure, and you roll a basic Fortitude save against 4d10 essence; Blunder 8d10. The attempt ends the spell; each +2 PP option allows one more (max 5). +2 PP: on a Critical or Success you absorb it instead — it lands on everyone but you — and regain half its PP, rounded down. *By hand:* magical abilities that are not spells.`
  },
  "BOUNCY BODY": {
    key: "bouncyBody", grade: "B", category: "utility", targets: "1 willing creature",
    effects: [
      { kind: "conditional", label: "Bouncy Body", target: "targets", grants: [{ kind: "modifier", value: 2, type: "circumstance", label: "Bouncy Body", scope: "Escape and grapple checks", when: { actions: ["escape", "grappleAttack"] }, auto: true }] },
      { kind: "note", text: "On a fall against a hard surface it may roll Acrobatics (DC = feet fallen + 10) to bounce up half the distance — by hand." }
    ],
    warpMods: [{ durationText: "1 hour" }],
    what: "a willing creature (M43): +2 circumstance to Escape and grapple checks; falls count 20 ft shorter; the bounce (Acrobatics, DC feet fallen + 10) by hand",
    text: `${CHOICE} a willing creature (M43) gains a +2 circumstance bonus to Escape and grapple checks, added by itself, and treats any fall as 20 feet shorter for its damage (the core's fall reduction, laid by the module on the cast). +2 PP: 1 hour. *By hand:* the bounce off a hard surface — an Acrobatics check (DC = the distance fallen + 10), up half the fall on a success.`
  },
  CHRONOWEAVE: {
    key: "chronoweave", grade: "A", category: "utility", targets: "you and willing allies in the emanation",
    areaTargeting: "allies",
    // WHOEVER IS INSIDE, WHILE INSIDE (Q159): the module keeps the membership (a plain condition row
    // lands only on those caught at the cast and stays), so the spell carries no condition row of its own.
    effects: [{ kind: "note", text: "You and willing allies inside the 20-ft emanation are quickened while inside (kept by the module as creatures move)." }],
    warpMods: [{ durationText: "10 minutes" }, { unlocks: [CHRONO_SLOW_UNLOCK] }],
    what: "you and allies inside the 20-ft emanation are quickened while inside (the module keeps who is in), the extra AP unrestricted (M37); the warp: each enemy inside saves Fortitude once (slowed 1 / 2 while inside, for the duration), then is immune to that casting",
    text: `${AUTO} a High Magic spell. You and every ally inside the 20-foot emanation are quickened while inside (Q159): the module gives it to whoever comes within 20 feet of you and takes it back from whoever leaves, until the spell's duration ends; the extra AP may be used for anything (M37). +2 PP: 10 minutes. +2 PP: every enemy in it when you cast it rolls a Fortitude save at your Save DC — Failure slowed 1, Fumble slowed 2 — slowed while it is inside, for the duration, and is then immune to this casting (Q159). *Not checked:* that an ally is willing (M43); an enemy who first comes in after the cast is the GM's to ask.`
  },
  "DRAGON WINGS": {
    key: "dragonWings", grade: "A", category: "utility",
    effects: [
      { kind: "speedGrant", target: "self", key: "fly", landPlus: DRAGON_WINGS_BASE_FEET },
      { kind: "note", text: "The wings cannot be used while bound, restrained or otherwise unable to move freely. If you are airborne when the spell ends, you fall." }
    ],
    warpMods: [{ bonusValue: DRAGON_WINGS_STEP_FEET, bonusMax: DRAGON_WINGS_FLY_CAP }, { durationText: "1 hour" }, { durationText: "until your next daily preparations" }],
    what: `a fly Speed of your land Speed + 10 ft (H4), +10 ft a warp to land + ${DRAGON_WINGS_FLY_CAP} in all (ruled: four warps); 1 hour or to the next daily preparation`,
    text: `${AUTO} you gain a fly Speed equal to your land Speed + 10 feet, read against your land Speed as it is (H4). Each +2 PP option adds 10 feet, to at most your land Speed + ${DRAGON_WINGS_FLY_CAP} in all: four options (Graham's ruling, "Max +50, four warps"; a fifth adds nothing). +2 PP: 1 hour. +6 PP: until your next daily preparation. If you are airborne when it ends, you fall (the core's falling rules). *By hand:* wings that are bound or have no room to beat.`
  },
  "ELDRITCH MANTLE": {
    key: "eldritchMantle", grade: "A", category: "utility",
    effects: [
      { kind: "defence", target: "self", field: "resistance", value: "physical" },
      { kind: "thorns", target: "self", label: "Eldritch Mantle", damage: "1d6", damageType: "force", save: { key: "fortitude", dc: "spell" }, reachFeet: ANY_MELEE_FEET, warpStep: { damage: "1d6" } }
    ],
    warpMods: [{ bonusValue: 1 }, { durationText: "10 minutes" }, { defenceField: "immunity" }],
    what: "physical resistance (immunity with +10 PP); a melee attacker: basic Fortitude at your Save DC against 1d6 force, +1d6 a warp; 10 minutes",
    text: `${AUTO} you gain resistance to physical damage (Stoneskin's row), and a creature that strikes you with a melee attack rolls a basic Fortitude save at your Save DC against 1d6 force damage (H1). +2 PP: +1d6. +2 PP: 10 minutes. +10 PP: physical immunity instead.`
  },
  "MANA SURGE": {
    key: "manaSurge", grade: "A", category: "utility", targets: "1 willing creature",
    effects: [{ kind: "freeWarp", target: "targets", trait: "*", value: 1, raisesSaveDC: true }],
    warpMods: [{ durationText: "10 minutes" }, { bonusValue: 1, bonusMax: 2 }],
    what: "a willing creature (M43): the first 1 PP (2 with +4 PP) of warping on each of its spells is free and raises the Save DC; not the casting DC, not the cap (Q162)",
    text: `${AUTO} for the duration, the first 1 PP of warping on each spell the willing creature casts is free (the core's free warp, every spell); it does not raise the casting DC or count against its maximum PP per cast, and it does raise the Save DC "as normal" (Q162, H9b). The spell's own warps only, not metamagic; a cantrip cannot be warped. +2 PP: 10 minutes. +4 PP: 2 PP.`
  },
  "METAMAGIC RESONANCE": {
    key: "metamagicResonance", grade: "B", category: "utility", targets: "willing allies in the emanation",
    areaTargeting: "allies",
    effects: [{ kind: "note", text: "Willing allies within the aura may apply the chosen metamagic feat to one spell a round, from their own PP." }],
    warpMods: [{ endsSustain: true }, { unlocks: [RESONANCE_SWAP_UNLOCK] }, { areaOverride: "60-foot emanation" }, { unlocks: [RESONANCE_HALF_UNLOCK] }, { unlocks: [RESONANCE_FREE_UNLOCK] }],
    what: "you choose a metamagic feat you have; allies within 30 ft (60 with the warp) may apply it to one spell a round from their own PP — full, half (rounded down) or none by the warps; the 1-minute warp ends sustaining (M47); with the change warp you may choose again each time you sustain",
    text: `${CHOICE} as it is cast you choose one metamagic feat you have (the core's or Eldritch Arts'). For the duration, each ally within 30 feet of you may apply it to one spell a round (H9), with no requirement but yours (Q163), paying its extra PP from their own pool. +2 PP: the duration is 1 minute and the spell is not sustained (M47). +2 PP: 60 feet. +3 PP: half the extra PP, rounded down; +6 PP: none (it replaces the +3, m114). Allies are given it as they come within the aura, and lose it as they leave. With the +2 PP change option, each time you sustain the spell you are asked whether to choose another metamagic feat (TRG Prime 3.692.0's Sustain hook; since 0.16.0). *By hand:* that an ally is willing (M43).`
  },
  "MIRROR REPRISE": {
    key: "mirrorReprise", grade: "B", category: "utility",
    effects: [{ kind: "note", text: "The first time you take damage from a melee or ranged attack, three duplicates appear." }],
    warpMods: [{ unlocks: [MIRROR_SPELL_UNLOCK] }, { unlocks: [MIRROR_TELEPORT_UNLOCK] }],
    what: "the first damage from an attack (or, warped, a hostile spell) makes three images; each later attack that hits you rolls d100 (26+/34+/51+ for 3/2/1) and on a success is a miss that destroys one (H6); the teleport warp",
    text: `${CHOICE} the spell waits. The first time you take damage from a melee or ranged attack (with the +2 PP option, from a hostile spell too), three duplicates appear. After that, each attack that hits you rolls a d100: with three duplicates 26 or higher, two 34 or higher, one 51 or higher, and the attack hit a duplicate instead — it is a miss against you (H6) and that duplicate is destroyed. The spell ends when all three are gone. +2 PP: when a duplicate is destroyed you may teleport up to 10 feet as a reaction (you click where). *Read so (for the release notes):* the d100 is rolled for an attack that would hit; a miss already misses.`
  },
  "PANIC TRANSPOSITION": {
    key: "panicTransposition", grade: "B", category: "utility", castAP: "Reaction",
    effects: [{ kind: "note", text: "After the triggering attack is resolved, you teleport up to 30 feet (60 with the warp) to a safe square you can see. This movement does not provoke reactions." }],
    warpMods: [{ unlocks: [PANIC_UNSEEN_UNLOCK] }, { unlocks: [PANIC_RESIST_UNLOCK] }, { unlocks: [PANIC_FAR_UNLOCK] }],
    what: "offered when a melee or ranged attack hits you (M50): cast as your reaction; once the attack is resolved you teleport 30 ft (60 warped); resistance to that attack (warp); an occupied unseen square: 2d6 essence (basic Fort)",
    text: `${CHOICE} when a melee or ranged attack hits you, you are asked (your player, else the GM; M50). Yes casts this spell as your reaction; once the attack has been resolved (its damage dealt), your player's client asks you to click a square up to 30 feet away and you teleport there, provoking nothing. +2 PP: the square may be one you know but cannot see; if it is occupied you take 2d6 essence damage (a basic Fortitude save at your Save DC) and must move to the nearest safe square (by hand). +4 PP: resistance to the triggering attack's damage. +4 PP: 60 feet. *By hand:* that the square is visible and safe.`
  },
  PLEDGESHROUD: {
    key: "pledgeshroud", grade: "C", category: "utility", targets: "1 willing creature",
    effects: [
      { kind: "conditional", label: "Pledgeshroud", target: "targets", grants: [{ kind: "modifier", value: -2, type: "untyped", label: "Pledgeshroud", scope: "Deception checks hinting at the protected information", when: { checkTypes: ["skill"], subjects: ["deception"] } }] },
      { kind: "note", text: "The target cannot speak or write the protected information. Undetectable by Sense Magic or spells below PP 8." }
    ],
    warpMods: [{}],
    what: "a willing creature (M43, M51): −2 to Deception when implying the secret, a tick; the binding itself by hand",
    text: `${PARTLY} the willing target (M43, M51) carries a −2 penalty on Deception checks, offered as a tick — tick it when it tries to imply the protected information. *By hand:* the binding itself (it cannot speak or write the information), its concealment from Sense Magic and spells below PP 8, and the +2 PP option's further secret.`
  },
  "SPECTRAL AEGIS": {
    key: "spectralAegis", grade: "B", category: "utility",
    effects: [{ kind: "defence", target: "targets", field: "resistance", value: "all damage" }],
    warpMods: [{ declareUses: 1 }, { heldUses: 1 }, { extraTargets: 1 }, { durationText: "until your next daily preparations" }],
    what: "resistance to all damage; absorbs the first hostile spell of PP 10 or lower (+1 a warp) whose targets or area include it — a targeted one is negated, an area spares it — then the Aegis ends; more absorbs, more targets, to the next preparation",
    text: `${CHOICE} the creature gains resistance to all damage. The first hostile spell of 10 PP or lower whose targets include it is absorbed (Q152): a spell aimed at it is negated for it, and it is left out of an area spell's area (H5). For an area spell, its player (else the GM) is asked whether it stands in the area as aimed. Then the Aegis, and its resistance, end. A beneficial spell passes. +1 PP: one more spell. +1 PP: the PP limit +1. +1 PP: one more creature. +2 PP: until your next daily preparation.`
  },
  "VEIL OF MIST": {
    key: "veilOfMist", grade: "A", category: "utility",
    effects: [{ kind: "zone", target: "area", label: "Veil of Mist", condition: "concealed", obscuresOutward: false }],
    warpMods: [{ durationText: "10 minutes" }, { durationText: "1 hour" }],
    what: "a 20-ft emanation that follows you: everyone in it is concealed and sees out clearly",
    text: `${AUTO} a 20-foot fog that moves with you: every creature in it, you included, is concealed, and sees what is outside clearly (the core's zone, not obscured outward). +2 PP: 10 minutes. +4 PP: 1 hour.`
  }
};

/** One spell, from its book entry and its spec, in Block 3a's `build()`. */
function buildGrimoire(name) {
  const entry = GRIM.get(name);
  if (!entry) throw new Error(`Block 7: no Grimoire spell "${name}" in the book`);
  const spec = SPEC[name];
  const doc = build(entry, { effects: [], ...spec }, { specialist: false });
  // "FLESH TO BLOSSOM": Block 3a's title case keeps only "of" and "the" small; the book's name is "Flesh to Blossom".
  const named = doc.name.replace(/ To /g, " to ");
  if (named !== doc.name) { doc.name = named; doc._id = stableId(`spells:${named}`); }
  const sys = doc.system;
  if (spec.area !== undefined) sys.area = spec.area;
  if (/^all$/i.test(String(entry.fields.Tradition ?? "").trim())) sys.tradition = ALL_TRADITIONS;
  if (spec.casterLevelMods) sys.casterLevelMods = spec.casterLevelMods;
  if (spec.secondary) sys.secondaryDamage = { ...spec.secondary };
  if (spec.areaTargeting) sys.areaTargeting = spec.areaTargeting;
  if (spec.castAP !== undefined) sys.castAP = spec.castAP;
  sys.availability = GRIMOIRE_AVAILABILITY;
  // AN OBJECT, NOT A CREATURE (0.10.1; 0.10.0's live test, finding 3): TRG
  // Prime 3.685.1's `targetsObject` asks for no creature target.
  doc.flags = { ...doc.flags, "trg-prime": { ...(doc.flags?.["trg-prime"] ?? {}), eaGrimoire: spec.key, ...(spec.targetsObject ? { targetsObject: true } : {}) } };
  return doc;
}

export const BLOCK7_NAMES = Object.freeze(Object.keys(SPEC));
export const SPELLS_B7 = BLOCK7_NAMES.map(buildGrimoire);

/**
 * THE ELEMENTAL STRIKE ABILITY (Q155), copied onto the caster by the spell's
 * `grantAbility` row for the minute and taken back when it ends. Its Use is
 * module/block7-automations.mjs's.
 */
export const ELEMENTAL_STRIKE_ITEM = ability({
  name: ELEMENTAL_STRIKE_ABILITY,
  description: [
    md("**ELEMENTAL STRIKE** (granted by the spell for its minute)"),
    md("As a 1 AP Strike against a creature within your weapon's reach, the target instead makes a basic Reflex save against 1d6 + casting attribute damage of the chosen type (no weapon damage; does not count toward your multiple attack penalty)"),
    md(`*Automated (${SINCE}):* **Use** (1 AP; a melee weapon wielded) asks for a creature within your weapon's reach (your current target, if it is one). It rolls a basic Reflex save at the Save DC the spell was cast with, against the spell's dice (1d6, +1d6 per +4 PP option) + your casting ability, of the spell's type; Base Damage 1d6 adds to a critical. Any number of Uses in the minute (Q155), each taking and adding no multiple attack penalty. *By hand:* that each counts as a Strike for rules that count Strikes — the Use fires no Strike hook and no Strike count.`)
  ].join("\n"),
  traits: "Attack, Elemental",
  flags: { eaGrimoireAbility: "elementalStrike" }
});
ELEMENTAL_STRIKE_ITEM.system.sourceRace = "";
ELEMENTAL_STRIKE_ITEM.system.category = "Spell";
if (ELEMENTAL_STRIKE_ITEM._id !== ELEMENTAL_STRIKE_ID) throw new Error("Block 7: the Elemental Strike ability's id drifted from its uuid");

export const ABILITIES_B7 = [ELEMENTAL_STRIKE_ITEM];

/** What each of the 42 does in TRG Prime, for the docs and the harness. */
export const SPELL_AUTOMATION_B7 = Object.freeze(Object.fromEntries(BLOCK7_NAMES.map((n, i) => [SPELLS_B7[i].name, Object.freeze({ grade: SPEC[n].grade, what: SPEC[n].what, key: SPEC[n].key })])));

if (SPELLS_B7.length !== 42) throw new Error(`Block 7: ${SPELLS_B7.length} spells, expected 42`);
