#!/usr/bin/env node
/**
 * verify-block11 — Eldritch Arts 0.18.0, the Feat Additions.
 *
 *   A  Content: the seventeen feats and their supporting abilities, cut from
 *      Graham's text (tools/content/feat-additions.md) verbatim; categories,
 *      traits, prerequisites, race, uses, ids, artwork; nothing duplicated; the
 *      five existing Runemage feats untouched; Quick Swap and the assistant's
 *      items are abilities, never feats.
 *   B  The modular allowance (Modular Design, Advanced Design, Integrated
 *      Modularity, Quick Swap) — against the REAL core bonus pool, conditional
 *      normaliser, stacking and the weapon-enhancement seam (C-EA11-1).
 *   C  Overclocked Weaponry through the same seam; reload never below 0.
 *   D  The Prepared trait's clock and recharge degrees.
 *   E  Power Sink, Instability Harness, Emergency Contraption, Flash of Insight.
 *   F  Tinkerer Precision through the REAL core crafting-time seam (C-EA11-2)
 *      and createPerDay: time falls; the cost, the check and the DC do not.
 *   G  The Mechanised Assistant's profile, the size round trip, improvements,
 *      Storage, specialties.
 *   H  Runemage: Runic Anchor, Triggered Sigil, Grand Inscription (save DC
 *      through the core's assembledSaveDC; identify replaced, not stacked, and
 *      restored on retraining).
 *   I  Ascendan: Ley Resonance (core castingDC), Arcane Preparation, Heritage of
 *      the First Weave, Perfected Arcane Memory's traces.
 *   J  Registration with a recording API; ordinary familiars and weapons are not
 *      touched; the manifest is 0.18.1; the art ships.
 *   K  What live testing found (0.18.1): the helpers named, the wondrous ring,
 *      Shield as a sigil, the prompts' verbs, broken at 0 HP, the assistant's
 *      class skills and grants, spell traces, Grand Inscription's save.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block11.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const core = (...p) => import(new URL(`file://${path.join(SYSTEM_ROOT, "module", ...p)}`).href);
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

let checks = 0;
const failures = [];
const ok = (label, cond, detail = "") => { checks += 1; if (!cond) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); };
const equal = (label, a, b) => ok(label, JSON.stringify(a) === JSON.stringify(b), `expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);

const R = await import("../module/block11-rules.mjs");
const C = await import("./content/block11.mjs");
const { stableId } = await import("./content/builders.mjs");
const { md } = await import("./content/markdown.mjs");

/* ------------------------------------------------------------------ */
/* A  Content                                                           */
/* ------------------------------------------------------------------ */

const sourceDir = (pack) => path.join(ROOT, "packs-source", pack);
const loadSource = (pack) => fs.readdirSync(sourceDir(pack)).filter((f) => f.endsWith(".json")).map((f) => JSON.parse(fs.readFileSync(path.join(sourceDir(pack), f), "utf8")));
const feats = loadSource("ea-feats");
const abilities = loadSource("ea-abilities");
const byName = (list, n) => list.filter((d) => d.name === n);

const EXPECT = Object.freeze({
  "Modular Design": { cat: "Class", traits: "Artificer", pre: "Crafting 4 ranks" },
  "Advanced Design": { cat: "Class", traits: "Artificer", pre: "Crafting 8 ranks, Modular Design" },
  "Integrated Modularity": { cat: "Class", traits: "Artificer", pre: "Crafting 12 ranks, Modular Design", grants: "Quick Swap" },
  "Mechanised Assistant": { cat: "Class", traits: "Artificer", pre: "Crafting 4 ranks" },
  "Overclocked Weaponry": { cat: "Class", traits: "Artificer", pre: "Crafting 6 ranks, Weapon Focus" },
  "Power Sink": { cat: "Class", traits: "Artificer, Chance, Prepared", pre: "Crafting 8 ranks, Use Magic Device" },
  "Instability Harness": { cat: "Class", traits: "Artificer, Chance", pre: "Crafting 12 ranks, Power Sink" },
  "Emergency Contraption": { cat: "Class", traits: "Artificer, Prepared", pre: "Crafting 6 ranks" },
  "Flash of Insight": { cat: "Class", traits: "Artificer, Chance", pre: "Crafting 14 ranks, Emergency Contraption", uses: "1" },
  "Tinkerer Precision": { cat: "Class", traits: "Artificer", pre: "Crafting 10 ranks" },
  "Runic Anchor": { cat: "Class", traits: "Runemage", pre: "Linguistics 10 ranks" },
  "Triggered Sigil": { cat: "Class", traits: "Runemage", pre: "Linguistics 12 ranks, Runic Reservoir" },
  "Grand Inscription": { cat: "Class", traits: "Runemage", pre: "Linguistics 16 ranks, Combat Inscription, Living Script" },
  "Ley Resonance": { cat: "Racial", traits: "Focus", pre: "Arcana 2 ranks", race: "Ascendan", uses: "1" },
  "Arcane Preparation": { cat: "Racial", traits: "Concentrate", pre: "Level 5, Spellcraft 5 ranks", race: "Ascendan" },
  "Heritage of the First Weave": { cat: "Racial", traits: "Focus, Warding", pre: "Level 10", race: "Ascendan", uses: "1" },
  "Perfected Arcane Memory": { cat: "Racial", traits: "", pre: "Level 15, Ley Resonance, Arcana 10 ranks", race: "Ascendan" }
});
equal("A0 seventeen new feats, as the brief counts them", Object.keys(EXPECT).length, 17);
for (const [name, e] of Object.entries(EXPECT)) {
  const found = byName(feats, name);
  equal(`A1 ${name}: exactly one entry in ea-feats`, found.length, 1);
  const f = found[0];
  if (!f) continue;
  equal(`A2 ${name}: category, traits, prerequisites, race, uses`, [f.system.category, f.system.traits, f.system.prerequisites, f.system.sourceRace, f.system.usesPerDay, f.system.grantedAbilities], [e.cat, e.traits, e.pre, e.race ?? "", e.uses ?? "", e.grants ?? ""]);
  equal(`A3 ${name}: the deterministic id`, f._id, stableId(`feats:${name}`));
  equal(`A4 ${name}: Eldritch Arts art for its category`, f.img, e.cat === "Racial" ? C.EA_FEAT_ART.racial : C.EA_FEAT_ART.class);
  const entry = C.additionEntry(name.toUpperCase());
  ok(`A5 ${name}: the card carries the printed text verbatim`, f.system.description.includes(md(entry.text)));
  ok(`A6 ${name}: and its printed trait line`, f.system.description.includes(md(`**${entry.traits.join(" ")}**`)));
  ok(`A7 ${name}: and one automation paragraph`, /<em>(Automated|Partly automated)[^<]*<\/em>/.test(f.system.description) || /\*Automated/.test(f.system.description) || /<p><em>Automated/.test(f.system.description));
  equal(`A8 ${name}: the Prepared trait's definition is on the card exactly when it has the trait`, f.system.description.includes("PREPARED (trait)"), e.traits.includes("Prepared"));
  equal(`A9 ${name}: source and block flags`, [f.system.source, f.flags?.["trg-prime"]?.eaBlock], ["Eldritch Arts", 11]);
}
equal("A10 the pack holds 237 + 17 feats", feats.length, 254);
const names = feats.map((f) => f.name.toLowerCase());
equal("A11 no feat name is duplicated in ea-feats", names.length, new Set(names).size);
for (const n of R.EXISTING_RUNEMAGE_FEATS) {
  const now = byName(feats, n)[0];
  ok(`A12 ${n} is still present`, Boolean(now));
  const was = (() => {
    try { return JSON.parse(execFileSync("git", ["-C", ROOT, "show", `HEAD:packs-source/ea-feats/${n.replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "")}_${now?._id}.json`], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] })); } catch { return null; }
  })();
  if (was) equal(`A13 ${n} is byte-for-byte unchanged by Block 11`, now, was);
  else ok(`A13 ${n}: the baseline copy is readable in git`, false, "no HEAD copy (run from the module's git checkout)");
}
const qs = byName(abilities, "Quick Swap");
equal("A14 Quick Swap: one ability, not a feat", [qs.length, byName(feats, "Quick Swap").length], [1, 0]);
equal("A15 Quick Swap: its traits and category", [qs[0]?.system?.traits, qs[0]?.system?.category, qs[0]?.type], ["Manipulate, Prepared", "Class", "ability"]);
for (const n of [R.ASSISTANT_FRAME, ...R.ASSISTANT_OWN_CHOICES]) {
  equal(`A16 ${n}: an ability, never a feat`, [byName(abilities, n).length, byName(feats, n).length], [1, 0]);
}
const frame = byName(abilities, R.ASSISTANT_FRAME)[0];
const frameChanges = frame?.effects?.[0]?.changes ?? [];
const base = R.assistantBaseAbilities();
for (const [k, v] of Object.entries(base)) ok(`A17 the frame authors ${k} ${v}`, frameChanges.some((c) => c.key === `system.attributes.${k}.base` && c.value === String(v) && c.mode === 5 && c.priority > 10));
ok("A18 the frame makes it Small, speed 20, Base DR 2 (over the stat block's priority 10)", ["system.identity.size:small", "system.combat.movement.land.base:20", "system.combat.naturalArmourBase.natural:2"].every((kv) => frameChanges.some((c) => `${c.key}:${c.value}` === kv && c.priority > 10)));
equal("A19 the source cuts into the 17 feats, Quick Swap and the trait", C.additionNames().length, 19);
for (const art of Object.values(C.EA_FEAT_ART)) ok(`A20 ${art} ships`, fs.existsSync(path.join(ROOT, art.replace("modules/trg-eldritch-arts/", ""))));

/* ------------------------------------------------------------------ */
/* B  Modular Design, Advanced Design, Integrated Modularity, Quick Swap */
/* ------------------------------------------------------------------ */

const allow = (...f) => R.modularAllowance(f);
equal("B1 Modular Design: +1 on one item", allow(R.FEATS.modular), { budget: 1, maxPerItem: 1, maxItems: 1, split: false, by: R.FEATS.modular });
equal("B2 Advanced Design: +2, on one or two items, one bonus each (A11-1, ruled)", allow(R.FEATS.modular, R.FEATS.advanced), { budget: 2, maxPerItem: 2, maxItems: 2, split: false, by: R.FEATS.advanced });
equal("B3 Integrated Modularity: +3, any combination, splittable on an item (A11-2, ruled)", allow(R.FEATS.modular, R.FEATS.advanced, R.FEATS.integrated), { budget: 3, maxPerItem: 3, maxItems: 3, split: true, by: R.FEATS.integrated });
equal("B4 nothing without Modular Design", allow(R.FEATS.advanced).budget, 0);
const w = (id, target = "attack", value = 1) => ({ itemId: id, itemName: id, kind: "weapon", target, value });
const a = (id, target = "db", value = 1) => ({ itemId: id, itemName: id, kind: "armour", target, value });
const g = (id, skill = "crafting", value = 1) => ({ itemId: id, itemName: id, kind: "equipment", target: "skill", skill, value });
equal("B5 MD: one +1 is allowed", R.modularRefusal([w("s")], allow(R.FEATS.modular)), "");
ok("B6 MD: two items are refused", R.modularRefusal([w("s"), a("p")], allow(R.FEATS.modular)) !== "");
ok("B7 MD: +2 on one item is refused", R.modularRefusal([w("s", "attack", 2)], allow(R.FEATS.modular)) !== "");
equal("B8 AD: +1 and +1 on two items", R.modularRefusal([w("s"), a("p")], allow(R.FEATS.modular, R.FEATS.advanced)), "");
equal("B9 AD: +2 on one item", R.modularRefusal([a("p", "dr", 2)], allow(R.FEATS.modular, R.FEATS.advanced)), "");
ok("B10 AD: +2 and +1 is refused (both, never)", R.modularRefusal([w("s", "attack", 2), a("p")], allow(R.FEATS.modular, R.FEATS.advanced)) !== "");
equal("B11 IM: +2 and +1", R.modularRefusal([w("s", "damage", 2), g("k")], allow(R.FEATS.modular, R.FEATS.integrated)), "");
equal("B12 IM: +3 on one item", R.modularRefusal([a("p", "db", 3)], allow(R.FEATS.modular, R.FEATS.integrated)), "");
ok("B13 IM: +4 in all is refused", R.modularRefusal([a("p", "db", 3), w("s")], allow(R.FEATS.modular, R.FEATS.integrated)) !== "");
ok("B14 one item, one upgrade — under Modular and Advanced Design", R.modularRefusal([w("s"), w("s", "damage")], allow(R.FEATS.modular, R.FEATS.advanced)) !== "");
equal("B14b Integrated Modularity: one item's +3 split between attack and damage; never the same bonus twice (A11-2, ruled)", [
  R.modularRefusal([w("s", "attack", 2), w("s", "damage", 1)], allow(R.FEATS.modular, R.FEATS.integrated)),
  R.modularRefusal([w("s", "attack", 3)], allow(R.FEATS.modular, R.FEATS.integrated)),
  R.modularRefusal([w("s", "attack", 1), w("s", "attack", 1)], allow(R.FEATS.modular, R.FEATS.integrated)) !== "",
  R.modularRefusal([w("s", "attack", 2), w("s", "damage", 2)], allow(R.FEATS.modular, R.FEATS.integrated)) !== ""
], ["", "", true, true]);
ok("B15 a weapon cannot take DB", R.modularRefusal([w("s", "db")], allow(R.FEATS.modular)) !== "");
ok("B16 armour cannot take attack", R.modularRefusal([a("p", "attack")], allow(R.FEATS.modular)) !== "");
ok("B17 a tool must name its skill", R.modularRefusal([g("k", "")], allow(R.FEATS.modular)) !== "");
equal("B18 the kinds: weapon, armour (and shield), equipment; a natural attack takes none", ["weapon", "armour", "shield", "gear", "feat"].map((t) => R.modularKind({ type: t, system: {} })).concat(R.modularKind({ type: "weapon", system: { natural: true } })), ["weapon", "armour", "armour", "equipment", null, null]);
const moved = R.modularMoved([w("s"), a("p")], "s", { itemId: "x", itemName: "x", kind: "weapon" });
equal("B19 a move leaves one upgrade — never two", moved.allocations.map((m) => m.itemId), ["x", "p"]);
equal("B20 a move keeps the value and the target", [moved.allocations[0].value, moved.allocations[0].target], [1, "attack"]);
ok("B21 a move onto an item that has one is refused", !R.modularMoved([w("s"), a("p")], "s", { itemId: "p", kind: "armour" }).ok);
ok("B22 a weapon's attack bonus cannot move onto armour as attack", !R.modularMoved([w("s")], "s", { itemId: "p", kind: "armour", target: "attack" }).ok);
equal("B23 ...but moves to armour as DB when chosen", R.modularMoved([w("s")], "s", { itemId: "p", kind: "armour", target: "db" }).allocations[0].target, "db");

const { parseBonusKey } = await core("bonuses", "registry.mjs");
equal("B24 armour DB goes into the core's typed pool as an item bonus", parseBonusKey(R.modularArmourChange("db", 1).key), { target: "system.combat.defence", type: "item" });
equal("B25 armour DR goes into the core's always-adding DR pool as an item bonus", parseBonusKey(R.modularArmourChange("dr", 2).key), { target: "system.combat.dr", type: "item" });
equal("B26 ...in CUSTOM mode (the pool), at the value", [R.modularArmourChange("dr", 2).mode, R.modularArmourChange("dr", 2).value], [0, "2"]);
const { normaliseConditional, matchesCheck } = await core("conditionals.mjs");
const cond = normaliseConditional(R.modularSkillConditional("Crafting", 1, "Tinker's Tools"), { id: "t", name: "Tinker's Tools", kind: "item" });
equal("B27 a tool's upgrade: an item bonus, pre-ticked", [cond?.value, cond?.type, cond?.auto], [1, "item", true]);
ok("B28 ...on that skill's checks", matchesCheck(cond, { checkType: "skill", subject: "crafting" }));
ok("B29 ...and no other skill", !matchesCheck(cond, { checkType: "skill", subject: "thievery" }));
ok("B30 ...and no save or attack", !matchesCheck(cond, { checkType: "save", subject: "will" }) && !matchesCheck(cond, { checkType: "attack" }));

const { weaponEnhancementsFor, enhancedLoad } = await core("weapon-enhancements.mjs");
const provider = (flags) => [{ key: "eaBlock11", fn: () => {
  const out = [R.modularWeaponAnswer(flags.up), R.overclockAnswer(flags.oc)].filter(Boolean);
  return out.length ? out : null;
} }];
const atk = weaponEnhancementsFor({ id: "s", name: "Sword" }, {}, provider({ up: { kind: "weapon", target: "attack", value: 1 } }));
equal("B31 a weapon's attack upgrade: one item row", atk.attackRows, [{ label: "Modular upgrade +1 (attack)", value: 1, type: "item" }]);
equal("B32 ...and no damage", [atk.itemDamage, atk.flatDamage], [0, 0]);
const dmg = weaponEnhancementsFor({ id: "s" }, {}, provider({ up: { kind: "weapon", target: "damage", value: 2 } }));
equal("B33 a damage upgrade is an item bonus to damage, not attack", [dmg.attackRows.length, dmg.itemDamage, dmg.flatDamage], [0, 2, 0]);
equal("B34 another weapon (no flag) gains nothing", weaponEnhancementsFor({ id: "b" }, {}, provider({})).labels, []);
const { applyStacking } = await core("dice", "resolution.mjs");
equal("B35 stacking: a +1 upgrade beside the weapon's own +1 item bonus is +1", applyStacking([{ label: "Sword", value: 1, type: "item" }, ...atk.attackRows]).total, 1);
equal("B36 stacking: +2 upgrade beside +1 is +2 (the higher), never +3", applyStacking([{ label: "Sword", value: 1, type: "item" }, { label: "Modular upgrade +2", value: 2, type: "item" }]).total, 2);
equal("B37 stacking: the upgrade adds to an untyped bonus", applyStacking([{ label: "x", value: 1, type: "untyped" }, ...atk.attackRows]).total, 2);
const { itemDamageExcess } = await core("combat", "attack.mjs");
equal("B38 damage: a +1 item upgrade on a +1 potency weapon adds nothing (R3)", itemDamageExcess(1, 1), 0);
equal("B39 damage: a +2 upgrade on a +1 weapon adds 1", itemDamageExcess(2, 1), 1);
equal("B40 Quick Swap costs 2 AP; Advanced's swap 10 minutes", [R.QUICK_SWAP_AP, R.ADVANCED_SWAP_SECONDS], [2, 600]);

/* ------------------------------------------------------------------ */
/* C  Overclocked Weaponry                                              */
/* ------------------------------------------------------------------ */

const plasma = weaponEnhancementsFor({ id: "s" }, {}, provider({ oc: { mode: "plasma", element: "fire" } }));
equal("C1 Plasma Edge: one 1d4 fire packet, resolved as a rune's", plasma.packets, [{ label: "Plasma Edge", dice: "1d4", type: "fire", secondaryCritical: null }]);
equal("C2 Plasma Edge's element is acid, fire or electricity", ["acid", "fire", "electricity", "cold"].map((e) => Boolean(R.overclockAnswer({ mode: "plasma", element: e }))), [true, true, true, false]);
const gyro = weaponEnhancementsFor({ id: "s" }, {}, provider({ oc: { mode: "gyro" } }));
equal("C3 Gyroscopic Repeater: reload −1", gyro.reloadReduction, 1);
equal("C4 ...Load 2 becomes 1, Load 1 becomes 0, never below 0", [enhancedLoad(2, 1), enhancedLoad(1, 1), enhancedLoad(0, 1)], [1, 0, 0]);
const impact = weaponEnhancementsFor({ id: "s" }, {}, provider({ oc: { mode: "impact" } }));
equal("C5 Impact Amplifier: +1 untyped damage (A11-12)", [impact.flatDamage, impact.itemDamage], [1, 0]);
equal("C6 Gyroscopic Repeater is offered only on a weapon that reloads", [R.overclockModesFor({ system: { traits: "Load 2" } }).map(([k]) => k), R.overclockModesFor({ system: { traits: "Finesse" } }).map(([k]) => k)], [["plasma", "gyro", "impact"], ["plasma", "impact"]]);
const both = weaponEnhancementsFor({ id: "s" }, {}, provider({ up: { kind: "weapon", target: "attack", value: 1 }, oc: { mode: "plasma", element: "acid" } }));
equal("C7 an upgrade and an overclock on one weapon both apply", [both.attackRows.length, both.packets.length], [1, 1]);
{
  const quiet = console.error; console.error = () => {};
  try { equal("C8 a provider that throws costs its own answer only", weaponEnhancementsFor({}, {}, [{ key: "bad", fn: () => { throw new Error("x"); } }, ...provider({ oc: { mode: "impact" } })]).flatDamage, 1); }
  finally { console.error = quiet; }
}

/* ------------------------------------------------------------------ */
/* D  The Prepared trait                                                */
/* ------------------------------------------------------------------ */

equal("D1 Prepared: 3 AP, ten minutes, Crafting", [R.PREPARED_RECHARGE_AP, R.PREPARED_RECHARGE_SECONDS, R.PREPARED_RECHARGE_SKILL], [3, 600, "crafting"]);
ok("D2 an unspent ability is ready", R.preparedReady(null, 0));
const spent = R.preparedExpended(1000);
ok("D3 spent at 1000: not ready at 1599", !R.preparedReady(spent, 1599));
ok("D4 ...ready at 1600 (by itself, on the world clock)", R.preparedReady(spent, 1600));
equal("D5 seconds left", R.preparedSecondsLeft(spent, 1300), 300);
equal("D6 the recharge restores on Success or better only (A11-6)", ["heroic", "critical", "success", "partial", "failure", "fumble", "blunder"].map(R.preparedRestores), [true, true, true, false, false, false, false]);
ok("D7 the Prepared trait is read off the trait list", R.hasPreparedTrait("Artificer, Chance, Prepared") && !R.hasPreparedTrait("Artificer, Chance"));
ok("D8 Prepared is not Focus", !R.hasPreparedTrait("Focus"));

/* ------------------------------------------------------------------ */
/* E  Power Sink, Instability Harness, Emergency Contraption, Insight  */
/* ------------------------------------------------------------------ */

equal("E1 Power Sink: a Failure only (A11-5)", R.powerSinkDegrees(), ["failure"]);
equal("E2 Instability Harness adds Fumble and Blunder", R.powerSinkDegrees({ harness: true }), ["failure", "fumble", "blunder"]);
equal("E3 Power Sink's range is 30 ft", R.POWER_SINK_FEET, 30);
equal("E4 a save against a spell is magical; one against a pit is not", [R.saveIsMagical({ traditions: "arcane" }), R.saveIsMagical({ traits: "magical" }), R.saveIsMagical({ saveSource: "spell" }), R.saveIsMagical({ traits: "poison" })], [true, true, true, false]);
equal("E5 the item must be held or worn, and magical", [
  R.isMagicalHeldItem({ type: "weapon", system: { equipped: true, runes: "Potency I" } }),
  R.isMagicalHeldItem({ type: "weapon", system: { equipped: false, runes: "Potency I" } }),
  R.isMagicalHeldItem({ type: "weapon", system: { equipped: true, runes: "" } }),
  R.isMagicalHeldItem({ type: "wondrous", system: { invested: true } })
], [true, false, false, true]);
equal("E6 Emergency Contraption: +2 item, on a Disable Device check", [R.CONTRAPTION_BONUS, R.isDisableDevice({ check: { actionKey: "disableDevice" } }), R.isDisableDevice({ label: "Disable Device" }), R.isDisableDevice({ check: { actionKey: "climb" } })], [2, true, true, false]);
equal("E7 Flash of Insight: a failed or fumbled skill check or save (not a Blunder, A11-3)", [
  R.insightWants({ type: "skill", degree: "failure" }), R.insightWants({ type: "save", degree: "fumble" }),
  R.insightWants({ type: "save", degree: "blunder" }), R.insightWants({ type: "attack", degree: "failure" }), R.insightWants({ type: "skill", degree: "partial" })
], [true, true, false, false, false]);
equal("E8 Flash of Insight's missing range is read as 30 ft (A11-4)", R.INSIGHT_FEET, 30);
const contraptionSrc = read("module", "block11-automations.mjs");
ok("E9 the contraption's +2 is pushed before the reroll, so only the reroll has it", /ctx\.check\?\.modifiers\?\.push\?\.\(\{ label: `\$\{FEATS\.contraption\}[\s\S]{0,120}type: "item" \}\);\s*return \{ reroll: true/.test(contraptionSrc));
{
  const step = contraptionSrc.slice(contraptionSrc.indexOf("async function insightStep"), contraptionSrc.indexOf("async function naturalTwenty"));
  ok("E10 Flash of Insight spends today's use and has no Prepared state (A11-3, ruled)", /system\.usesValue/.test(step) && !/expendPrepared|preparedReadyNow/.test(step));
}
ok("E11 the natural 20 is the core's open-ended chain: first face 20, continuing on 20s", /const faces = \[20\];[\s\S]{0,200}if \(next < 20\) break;/.test(contraptionSrc));

/* ------------------------------------------------------------------ */
/* F  Tinkerer Precision                                                */
/* ------------------------------------------------------------------ */

const { craftingTimeModifiers, timeValueFor } = await core("crafting-feats.mjs");
const { createPerDay, createSuccessModifier } = await core("create-crafting.mjs");
const tinker = [{ key: "tinkererPrecision", fn: (ctx) => R.tinkererAnswer({ featNames: ctx.featNames }) }];
equal("F1 without the feat: nothing changes", craftingTimeModifiers({ featNames: ["Artificer"] }, tinker), { ranks: 0, valueFactor: 1, labels: [] });
const tm = craftingTimeModifiers({ featNames: [R.FEATS.tinkerer] }, tinker);
equal("F2 with it: +2 ranks for time, 75% of the value", [tm.ranks, tm.valueFactor], [2, 0.75]);
equal("F3 two providers do not compound the factor", craftingTimeModifiers({ featNames: [R.FEATS.tinkerer] }, [...tinker, { key: "again", fn: () => ({ valueFactor: 0.75 }) }]).valueFactor, 0.75);
equal("F4 the time value of a 400 gp item is 300; the cost stays 400", [timeValueFor(400, tm.valueFactor), 400], [300, 400]);
const perDay = (ranks) => createPerDay("success", ranks, 2, 0).perDay;
const mod = createSuccessModifier(0);
equal("F5 a day's work at 10 ranks, level 2, a bare Success: 10 × 2 × m → at 12 ranks: 12 × 2 × m", [perDay(10), perDay(10 + tm.ranks)], [20 * mod, 24 * mod]);
const daysWithout = Math.ceil(400 / perDay(10));
const daysWith = Math.ceil(timeValueFor(400, tm.valueFactor) / perDay(10 + tm.ranks));
ok("F6 days for a 400 gp item fall with the feat", daysWith < daysWithout, `${daysWithout} → ${daysWith}`);
equal("F7 the rules' own days arithmetic agrees with the core's", [R.createDaysFor({ value: 400, ranks: 10, level: 2, modifier: mod }), R.createDaysFor({ value: 400, ranks: 10, level: 2, modifier: mod, timeRanks: 2, valueFactor: 0.75 })], [daysWithout, daysWith]);
equal("F8 a factor outside (0, 1] is ignored, never applied twice", [timeValueFor(400, 0), timeValueFor(400, 1.5), timeValueFor(timeValueFor(400, 0.75), 1)], [400, 400, 300]);
const workflow = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "create-crafting-workflow.mjs"), "utf8");
ok("F9 the core prices a day at the time ranks, the check's ranks untouched", /createPerDay\(\s*degreeKey, mods\.ranks \+ timeMods\.ranks/.test(workflow) && /project\.ranks = Math\.max\(0, Math\.trunc\(Number\(ranks\) \|\| 0\)\)/.test(workflow));
ok("F10 ...and completes at the time value, not the cost", (workflow.match(/completionOf\(project\.progress, project\.timeValue \?\? project\.itemValue\)/g) ?? []).length === 2 && !/project\.itemValue\s*=\s*[^=]/.test(workflow.replace(/itemValue: setup\.itemValue/, "")));

/* ------------------------------------------------------------------ */
/* G  The Mechanised Assistant                                          */
/* ------------------------------------------------------------------ */

const { SIZE_TABLE } = await core("config.mjs");
equal("G1 the core's Small: Str −1, Dex +1", [SIZE_TABLE.small.strMod, SIZE_TABLE.small.dexMod], [R.SMALL_SIZE_MODS.strength, R.SMALL_SIZE_MODS.dexterity]);
const printed = Object.fromEntries(Object.entries(base).map(([k, v]) => [k, v + (k === "strength" ? SIZE_TABLE.small.strMod : k === "dexterity" ? SIZE_TABLE.small.dexMod : 0)]));
equal("G2 the round trip: authored + size = the printed scores", printed, { ...R.ASSISTANT_PROFILE.abilities });
equal("G3 the printed profile", [R.ASSISTANT_PROFILE.size, R.ASSISTANT_PROFILE.speed, R.ASSISTANT_PROFILE.dr, R.ASSISTANT_PROFILE.initiative, R.ASSISTANT_PROFILE.db, R.ASSISTANT_PROFILE.senses], ["small", 20, 2, 15, 15, "Darkvision"]);
equal("G4 the Slam (Small): 1d6 bludgeoning", [R.ASSISTANT_PROFILE.attack.name, R.ASSISTANT_PROFILE.attack.damage, R.ASSISTANT_PROFILE.attack.damageType], ["Slam (Small)", "1d6", "bludgeoning"]);
equal("G5 improvements: at 4th level and every 4 after", [1, 3, 4, 7, 8, 12, 16, 20].map(R.assistantImprovements), [0, 0, 1, 1, 2, 3, 4, 5]);
equal("G6 the printed familiar list (13) and its own three", [R.ASSISTANT_FAMILIAR_CHOICES.length, R.ASSISTANT_OWN_CHOICES], [13, ["Reinforced Frame", "Storage", "Reactive Protocol"]]);
equal("G7 an improvement once; Ability Enhancement again", [R.improvementOpen("Tough", ["Tough"]), R.improvementOpen("Ability Enhancement", ["Ability Enhancement"]), R.improvementOpen("Storage", [])], [false, true, true]);
equal("G8 Storage: 10 lbs", [R.storageFits([4, 5], 1), R.storageFits([4, 5], 2)], [true, false]);
equal("G9 four specialties", R.ASSISTANT_SPECIALTIES.map(([k]) => k), ["toolArmature", "injectorLimb", "scoutOptics", "relayNode"]);
equal("G10 Spell Relay Node: line or area spells, 60 ft", [R.relayEligible({ area: "20-ft radius" }), R.relayEligible({ traits: "Line" }), R.relayEligible({ area: "", range: "60 ft" }), R.RELAY_NODE_FEET], [true, true, false, 60]);
equal("G11 Injector Limb: touch spells", [R.isTouchSpell({ range: "Touch" }), R.isTouchSpell({ range: "30 ft" })], [true, false]);
equal("G12 Tool Armature: +2", R.TOOL_ARMATURE_BONUS, 2);
ok("G13 the assistant is a familiar: built through the core's createFamiliarFor", /h\(\)\.createFamiliarFor\(master, feat\)/.test(contraptionSrc));
{
  const rb = contraptionSrc.slice(contraptionSrc.indexOf("async function rebuildAssistant"), contraptionSrc.indexOf("const mechanisedAssistant"));
  ok("G14 rebuilding pays the Equipment Cost Table at the master's level (A11-7, ruled)", /R\.rebuildCost\(level\)/.test(rb) && /deductGold\?\.\(master, cost\)/.test(rb) && rb.lastIndexOf("deductGold") < rb.indexOf("familiar.delete()") && (rb.match(/deductGold/g) ?? []).length === 1);
  equal("G14b the Equipment Cost Table (Core Rulebook p. 173)", [R.rebuildCost(0), R.rebuildCost(1), R.rebuildCost(6), R.rebuildCost(10), R.rebuildCost(20), R.EQUIPMENT_COST.length], [0, 50, 1000, 4000, 250000, 21]);
}
ok("G15 magical healing is taken back only on an assistant", /if \(!isAssistant\(target\) \|\| !isActingGM\(\)\) return;/.test(contraptionSrc));

/* ------------------------------------------------------------------ */
/* H  Runemage                                                          */
/* ------------------------------------------------------------------ */

equal("H1 Runic Anchor: +2 class", R.RUNIC_ANCHOR_BONUS, 2);
equal("H2 a Symbol cast: verbal, material or focus; not an innate spell or a somatic-only one", [
  R.usesSymbol({ components: { verbal: true } }), R.usesSymbol({ components: { somatic: true } }), R.usesSymbol({ components: { material: true } }, { innate: true })
], [true, false, false]);
const { symbolComponents } = await core("magic", "runemage.mjs");
equal("H3 ...agreeing with the core's own Symbol rule", [{ verbal: true }, { somatic: true }, { focus: true, somatic: true }].map((c) => Boolean(symbolComponents(c, true).symbol)), [true, false, true]);
equal("H4 the remembered casts last a day", R.liveSymbolCasts({ a: { at: 0, name: "A" }, b: { at: 90000, name: "B" } }, 90001).map((c) => c.key), ["b"]);
equal("H5 Triggered Sigil: 2 AP or less", [R.triggeredSpellEligible({ castAP: 2, targets: "one creature" }).ok, R.triggeredSpellEligible({ castAP: 3, targets: "one creature" }).ok], [true, false]);
equal("H6 ...that can target you or a creature", [R.triggeredSpellEligible({ castAP: 1, range: "Personal" }).ok, R.triggeredSpellEligible({ castAP: 1, area: "20-ft burst", targets: "" }).ok], [true, false]);
equal("H7 the default cast time is the core's 2", R.spellCastAP({}), 2);
equal("H8 struck and targeted are detected; the rest are manual", R.DETECTED_TRIGGERS, ["struck", "targeted"]);
ok("H9 a triggered activation spends the reaction and takes the one-a-round lock before it casts", /spendReaction\?\.\(actor, FEATS\.triggered[\s\S]{0,200}SIGIL_LOCK_FLAG, roundStamp\(t\)\)[\s\S]{0,400}castSpell\(actor, spell, \{ preparedSymbol: \{ label: FEATS\.triggered \}, reaction: \{[^}]*\}, apPaid: true \}\)/.test(contraptionSrc));
ok("H10 ...refusing when a sigil was already activated this round", /sigilLockHeld\(mflag\(feat, SIGIL_LOCK_FLAG\), t\)\) return warn/.test(contraptionSrc));
const { assembledSaveDC } = await core("magic", "casting-dc.mjs");
const plain = assembledSaveDC({ baseDC: 15, runemage: true });
const grand = assembledSaveDC({ baseDC: 15, runemage: true, warpSaveDC: R.GRAND_SAVE_DC_EXTRA });
equal("H11 Grand Inscription: the Runemage's +1 becomes +2 — 16 → 17, never 18", [plain.dc, grand.dc], [16, 17]);
const pend = [{ label: "Runemage (runic symbols)", value: 2, type: "class", oneShot: true }, { label: "Other", value: 1 }];
const up = R.grandIdentifyRewrite(pend);
equal("H12 the queued identify bonus becomes +4 — replaced, one entry", [up.changed, up.pending.length, up.pending[0].value, up.pending[0].type, up.pending[1]], [true, 2, 4, "class", { label: "Other", value: 1 }]);
equal("H13 rewriting twice changes nothing more", R.grandIdentifyRewrite(up.pending).changed, false);
const back = R.grandIdentifyRestore(up.pending);
equal("H14 retraining Grand Inscription restores the +2", [back.changed, back.pending[0].value, back.pending[0].label], [true, 2, "Runemage (runic symbols)"]);

/* ------------------------------------------------------------------ */
/* I  Ascendan                                                          */
/* ------------------------------------------------------------------ */

const { castingDC } = await core("magic", "casting.mjs");
const lr = R.leyResonanceAnswer(4, 1);
equal("I1 Ley Resonance: pay 1 PP less; the casting DC is castingDC(3) − castingDC(4)", [lr.discount, lr.dcDelta], [{ pp: 1, floor: 1 }, castingDC(3) - castingDC(4)]);
equal("I2 with Perfected Arcane Memory: 2 PP", [R.leyResonancePP([R.FEATS.memory]), R.leyResonanceAnswer(4, 2).dcDelta], [2, castingDC(2) - castingDC(4)]);
equal("I3 never below 1 PP", [R.leyResonanceAnswer(1, 1), R.leyResonanceAnswer(2, 2).pp], [null, 1]);
ok("I4 the Save DC is not touched (a discount, not a lower cast PP)", !("saveDC" in lr));
equal("I5 Ley Resonance: 60 ft", R.LEY_RESONANCE_FEET, 60);
equal("I6 Arcane Preparation: arcane or ethereal spells only, +2 circumstance", [R.arcanePrepSpell({ tradition: "arcane" }), R.arcanePrepSpell({ tradition: "Ethereal" }), R.arcanePrepSpell({ tradition: "divinity" }), R.ARCANE_PREP_BONUS], [true, true, false, 2]);
equal("I7 Heritage of the First Weave: divine or verdant saves only", [
  R.firstWeaveWants({ type: "save", check: { traditions: "divinity" } }), R.firstWeaveWants({ type: "save", check: { traditions: "verdant" } }),
  R.firstWeaveWants({ type: "save", check: { traditions: "arcane" } }), R.firstWeaveWants({ type: "skill", check: { traditions: "verdant" } })
], [true, true, false, false]);
ok("I8 Heritage of the First Weave touches no Forbidden Magic flag", !/forbiddenTraditions|beneficialTraditionSave/.test(contraptionSrc));
const traces = [{ spellName: "Fireball", tradition: "arcane", castAt: 1000, endedAt: 1000, origin: { x: 200, y: 0 } }, { spellName: "Bless", tradition: "divinity", endedAt: 1000 }, { spellName: "Old", tradition: "ethereal", endedAt: 0 }];
equal("I9 traces: arcane or ethereal, ended within 24 hours", R.readableTraces(traces, 86500).map((t) => t.spellName), ["Fireball"]);
equal("I10 a Failure reveals nothing", R.traceReveals(traces[0], "failure"), { identified: false });
equal("I11 a Success: the spell and its tradition, no time or place", R.traceReveals(traces[0], "success", { worldTime: 5000, from: { x: 0, y: 0 } }), { identified: true, spell: "Fireball", tradition: "arcane" });
equal("I12 a Critical: also how long ago and the direction", R.traceReveals(traces[0], "critical", { worldTime: 5000, from: { x: 0, y: 0 } }), { identified: true, spell: "Fireball", tradition: "arcane", agoSeconds: 4000, direction: "east" });
ok("I13 no reveal ever names a caster", !JSON.stringify(R.traceReveals({ ...traces[0], caster: "Zed" }, "heroic", { worldTime: 5000, from: { x: 0, y: 0 } })).includes("Zed"));
equal("I14 nothing invented: a trace with no origin gives no direction", "direction" in R.traceReveals({ spellName: "X", tradition: "arcane", castAt: 1, endedAt: 1 }, "critical", { worldTime: 10, from: { x: 0, y: 0 } }), false);
equal("I15 the DC rises by 5", R.TRACE_DC_INCREASE, 5);

/* ------------------------------------------------------------------ */
/* J  Registration, isolation, the manifest                             */
/* ------------------------------------------------------------------ */

globalThis.game = globalThis.game ?? {};
const A = await import("../module/block11-automations.mjs");
const calls = [];
const recorder = new Proxy({}, { get: (t, name) => (...args) => { calls.push([String(name), String(args[0])]); return true; } });
A.registerBlock11(recorder, "trg-eldritch-arts");
const called = (fn, key) => calls.some(([f, k]) => f === fn && k === key);
for (const n of ["Modular Design", "Advanced Design", "Integrated Modularity", "Quick Swap", "Overclocked Weaponry", "Mechanised Assistant", "Power Sink", "Emergency Contraption", "Flash of Insight", "Triggered Sigil", "Grand Inscription", "Arcane Preparation", "Perfected Arcane Memory"]) {
  ok(`J1 ${n} has a Use`, called("registerFeatAutomation", n));
}
for (const n of ["Instability Harness", "Tinkerer Precision", "Runic Anchor", "Ley Resonance", "Heritage of the First Weave"]) ok(`J2 ${n} says what it does automatically`, called("registerPassiveAutomation", n));
for (const [fn, key] of [["registerWeaponEnhancement", "eaBlock11"], ["registerCraftingWorkModifier", "tinkererPrecision"], ["registerEffectSuppressor", "eaBlock11"],
  ["registerCheckReaction", "powerSink"], ["registerCheckReaction", "emergencyContraption"], ["registerCheckReaction", "flashOfInsight"], ["registerCheckReaction", "runicAnchor"], ["registerCheckReaction", "firstWeave"],
  ["registerResonanceSuppressor", "powerSink"], ["registerSpellCheckGate", "arcanePreparation"], ["registerCastOption", "grandInscription"], ["registerCastOption", "spellRelayNode"],
  ["registerMetamagic", "leyResonance"], ["registerDefenceOffer", "triggeredSigilTargeted"]]) ok(`J3 ${fn}("${key}")`, called(fn, key));
ok("J4 the Prepared trait is registered", calls.some(([f]) => f === "registerTraits"));
equal("J4b the feats with a Use are exactly those flagged for one", [...R.USE_FEATS].sort(), Object.keys(A.AUTOMATIONS_B11).filter((n) => n !== R.QUICK_SWAP).sort());
for (const n of Object.keys(EXPECT)) equal(`J4c ${n}: flagged for a Use exactly when it has one`, Boolean(byName(feats, n)[0]?.flags?.["trg-prime"]?.eaAutomation), R.USE_FEATS.includes(n));
const regSrc = read("module", "registration.mjs");
ok("J5 registerContent calls registerBlock11", /registerBlock11\(api, moduleId\)/.test(regSrc));
const plainWeapon = { id: "x", name: "Sword", flags: {}, system: { hp: { value: 10, max: 10 } }, getFlag: () => undefined };
equal("J6 an ordinary weapon: no enhancement", A.weaponEnhancementB11(plainWeapon), null);
const upgraded = { ...plainWeapon, flags: { "trg-eldritch-arts": { [R.MODULAR_ITEM_FLAG]: { target: "attack", value: 1 } } } };
equal("J7 an upgraded weapon: its +1", A.weaponEnhancementB11(upgraded), [{ label: "Modular upgrade +1 (attack)", attack: 1, attackType: "item" }]);
equal("J7b a weapon carrying attack and damage (Integrated Modularity): both answers", A.weaponEnhancementB11({ ...upgraded, flags: { "trg-eldritch-arts": { [R.MODULAR_ITEM_FLAG]: { upgrades: [{ target: "attack", value: 2 }, { target: "damage", value: 1 }], kind: "weapon" } } } }), [{ label: "Modular upgrade +2 (attack)", attack: 2, attackType: "item" }, { label: "Modular upgrade +1 (damage)", damage: 1, damageType: "item" }]);
equal("J8 ...not while broken (the core's broken: 0 HP or less)", A.weaponEnhancementB11({ ...upgraded, system: { hp: { value: 0, max: 10 } } }), null);
ok("J8b ...but still at half HP, which the core does not call broken", A.weaponEnhancementB11({ ...upgraded, system: { hp: { value: 4, max: 10 } } }) !== null);
equal("J9 an ordinary effect is never suppressed by Block 11", A.effectSuppressedB11({ parent: { documentName: "Item", type: "armour", system: { equipped: false }, parent: { effects: [] } }, getFlag: () => undefined }), false);
const upgradeEffect = (equipped) => ({ parent: { documentName: "Item", id: "p", type: "armour", system: { equipped }, parent: { effects: [] } }, getFlag: (m, k) => (k === "source" ? R.MODULAR_EFFECT : undefined) });
equal("J10 an armour upgrade counts only while equipped", [A.effectSuppressedB11(upgradeEffect(true)), A.effectSuppressedB11(upgradeEffect(false))], [false, true]);
equal("J11 an ordinary familiar's items are not refused", A.onPreCreateItemB11({ type: "gear", parent: { flags: {}, getFlag: () => undefined, items: [] }, system: {} }), true);
const manifest = JSON.parse(read("module.json"));
equal("J12 the manifest is 0.18.3, verified on 3.713.1, minimum unchanged", [manifest.version, manifest.relationships.systems[0].compatibility.minimum, manifest.relationships.systems[0].compatibility.verified, manifest.download.includes("v0.18.3")], ["0.18.3", "3.694.0", "3.713.1", true]);
ok("J13 the entry script wires Block 11's hooks", /onDailyPreparationB11|onSpellSettledB11/.test(read("scripts", "eldritch-arts.mjs")));
ok("J14 the module ids of every pack are unchanged", ["ea-feats", "ea-abilities"].every((n) => manifest.packs.some((p) => p.name === n && p.path === `packs/${n}`)));

/* ------------------------------------------------------------------ */
/* K  Found in live testing (0.18.1)                                    */
/* ------------------------------------------------------------------ */

// K1 THE HELPERS ARE THE CORE'S OWN NAMES. 0.18.0 called h().contentPacksFor,
// which is on the API, not its helpers: undefined, so the assistant was built
// with no Frame, Darkvision or Slam. Every h().name must be a key of the core's
// helpers object (MODULE_HELPERS, spread into it, and its own keys).
{
  const coreText = (...p) => fs.readFileSync(path.join(SYSTEM_ROOT, "module", ...p), "utf8");
  const block = (text, start) => {
    const i = text.indexOf(start);
    if (i < 0) return "";
    let depth = 0;
    for (let j = text.indexOf("{", i); j < text.length; j += 1) {
      if (text[j] === "{") depth += 1;
      else if (text[j] === "}") { depth -= 1; if (depth === 0) return text.slice(i, j + 1); }
    }
    return "";
  };
  const keysOf = (body) => new Set([...body.matchAll(/^\s{2,8}(?:get\s+|async\s+)?([A-Za-z_$][\w$]*)\s*(?:[,:(]|$)/gm)].map((m) => m[1]));
  const helperKeys = new Set([
    ...keysOf(block(coreText("module-api-workflow.mjs"), "helpers: Object.freeze({")),
    ...keysOf(block(coreText("feats-workflow.mjs"), "export const MODULE_HELPERS = Object.freeze({"))
  ]);
  const used = [...new Set([...read("module", "block11-automations.mjs").matchAll(/h\(\)\.([A-Za-z_$][\w$]*)/g)].map((m) => m[1]))];
  const missing = used.filter((n) => !helperKeys.has(n));
  ok("K1 every h().name Block 11 calls is a core helper", helperKeys.size > 20 && missing.length === 0, `not helpers: ${missing.join(", ")} (of ${helperKeys.size} keys)`);
  ok("K1b contentPacksFor is read from the API itself", /api\?\.contentPacksFor/.test(read("module", "block11-automations.mjs")));
}

// K2 a worn wondrous ring (gear with the core's wondrous flag, space-separated traits) is magical; plain gear is not
equal("K2 Power Sink's magical items: flags and both trait spellings", [
  R.isMagicalHeldItem({ type: "gear", system: { equipped: true, traits: "Invested Warding" }, flags: {} }),
  R.isMagicalHeldItem({ type: "gear", system: { equipped: true, traits: "" }, flags: { "trg-prime": { wondrous: { base: "Ring of Protection" } } } }),
  R.isMagicalHeldItem({ type: "gear", system: { equipped: true, traits: "" }, flags: { "trg-prime": { chargedItem: {} } } }),
  R.isMagicalHeldItem({ type: "gear", system: { equipped: true, traits: "Light, Simple" }, flags: {} }),
  R.isMagicalHeldItem({ type: "gear", system: { equipped: false, traits: "Magical" }, flags: {} })
], [true, true, true, false, false]);

// K3 Shield (no range, no targets, no area) can be a Triggered Sigil; a cone cannot
equal("K3 Triggered Sigil: a self spell written blank is eligible", [
  R.triggeredSpellEligible({ castAP: 2, range: "", targets: "", area: "" }).ok,
  R.triggeredSpellEligible({ castAP: 1, range: "Touch", targets: "" }).ok,
  R.triggeredSpellEligible({ castAP: 2, range: "", targets: "", area: "15-foot cone" }).ok
], [true, true, false]);

// K4 the prompts' verbs
equal("K4 degreeVerb", ["failure", "fumble", "blunder"].map(R.degreeVerb), ["fails", "fumbles", "blunders"]);
ok("K4b no prompt prints a degree with an s added", !/\$\{esc\((?:ctx\.)?degree\)\}s /.test(read("module", "block11-automations.mjs")));

// K5 broken is the core's broken: 0 HP or below, not half
{
  const src = read("module", "block11-automations.mjs");
  ok("K5 broken() reads the core's 0 HP, not half", /<= 0;\s*\n\};/.test(src.slice(src.indexOf("const broken ="), src.indexOf("const broken =") + 600)) && !/Math\.floor\(Number\(hp\.max\)\s*\/\s*2\)/.test(src));
}

// K6 the assistant: class skills declared on the Frame; the replaced grants stamped as the race's
{
  const frame = abilities.find((d) => d.name === R.ASSISTANT_FRAME);
  equal("K6 the Frame declares Crafting and Perception as class skills (the pack, and its source)", [frame?.flags?.["trg-prime"]?.classSkills, C.ASSISTANT_FRAME_ABILITY?.flags?.["trg-prime"]?.classSkills], [["Crafting", "Perception"], ["Crafting", "Perception"]]);
  const src = read("module", "block11-automations.mjs");
  ok("K6b Darkvision and the Slam are stamped as the race's Nightvision and Bite", /asGrantOf\(dark\.toObject\(\), "Nightvision"\)/.test(src) && /asGrantOf\(data, "Bite \(Tiny\)"\)/.test(src));
  ok("K6c the core's pending grant pass is awaited before the fit-out", /queueGrantPass\(familiar\)/.test(src));
  ok("K6d no classSkill is written to the familiar", !/skills\.\$\{s\}\.classSkill/.test(src));
}

// K7 traces from the core's spell effects (spellEffect, castId, origin), one per cast, multi-tradition
{
  const src = read("module", "block11-automations.mjs");
  ok("K7 a lasting spell's trace is read from its origin item", /fromUuidSync\?\.\(effect\.origin\)/.test(src) && /sys\.spellEffect/.test(src));
  ok("K7b one trace a cast", /held\.some\(\(t\) => t\.castId === trace\.castId\)/.test(src));
  ok("K7c 'arcane, ethereal' counts as arcane", /function arcaneTradition/.test(src));
  ok("K7d the spell's name is shown to a GM only", /game\?\.user\?\.isGM \? ` \(GM: \$\{t\.spellName\}\)`/.test(src));
}

// K8 Grand Inscription only on a spell with a save; re-gaining it restores the +4
{
  const src = read("module", "block11-automations.mjs");
  ok("K8 Grand Inscription's option needs a save", /fort\|reflex\|will\|save/.test(src));
  ok("K8b Grand Inscription gained rewrites a queued +2", /export async function onItemCreatedB11/.test(src) && /onItemCreatedB11\(item, options, userId\)/.test(read("scripts", "eldritch-arts.mjs")));
}

// K9 the tool's skill is asked from the actor's own skills
ok("K9 a tool's skill list is the actor's", /Object\.entries\(actor\?\.system\?\.skills/.test(read("module", "block11-automations.mjs")) && !/CONFIG\?\.TRG_PRIME\?\.skills/.test(read("module", "block11-automations.mjs")));

/* ------------------------------------------------------------------ */
/* L  Graham's rulings of 25 November 2026 (0.18.2)                     */
/* ------------------------------------------------------------------ */
{
  const adv = feats.find((d) => d.name === "Advanced Design");
  ok("L1 Advanced Design's text reads '+1 bonus to two items' (A11-1, a typo corrected)", /\+1 bonus to two items or a \+2 bonus to a single item/.test(adv?.system?.description ?? ""));
  const fi = feats.find((d) => d.name === "Flash of Insight");
  ok("L2 Flash of Insight: once a day, no Prepared trait or card (A11-3)", fi?.system?.usesPerDay === "1" && !/Prepared/.test(fi?.system?.traits ?? "") && !fi?.system?.description?.includes("PREPARED (trait)"));
  const src = read("module", "block11-automations.mjs");
  const reaction = src.slice(src.indexOf("export const insightReaction"), src.indexOf("const insightUse"));
  ok("L2b Flash of Insight's reaction asks only for today's use", /itemUsesRemaining\(feat\) <= 0/.test(reaction) && !/preparedReadyNow/.test(reaction));
  // A11-9: designated during daily preparation
  equal("L3 the daily preparation window: open after preparation; shut by a cast, combat or an hour", [
    R.prepWindowOpen({ at: 100 }, { worldTime: 100 }),
    R.prepWindowOpen({ at: 100 }, { worldTime: 100 + 3600 }),
    R.prepWindowOpen({ at: 100 }, { worldTime: 100 + 3601 }),
    R.prepWindowOpen({ at: 100, closed: true }, { worldTime: 150 }),
    R.prepWindowOpen({ at: 100 }, { worldTime: 150, inCombat: true }),
    R.prepWindowOpen(null, { worldTime: 150 })
  ], [true, true, false, false, false, false]);
  ok("L3b designation refuses outside the window; daily preparation opens it; a cast closes it",
    /if \(!R\.prepWindowOpen\(mflag\(actor, R\.PREP_WINDOW_FLAG\)/.test(src.slice(src.indexOf("async function designateTrigger")))
    && /setFlag\(MODULE_ID, R\.PREP_WINDOW_FLAG, \{ at: worldTime\(\), closed: false \}\)/.test(src)
    && /setFlag\(MODULE_ID, R\.PREP_WINDOW_FLAG, \{ \.\.\.win, closed: true \}\)/.test(src));
  // A11-8: only its own improvements
  const assistant = { flags: { "trg-eldritch-arts": { [R.ASSISTANT_FLAG]: { masterId: "m" } } }, getFlag: () => undefined, items: [] };
  const ability = (flags = {}) => ({ type: "ability", name: "Cunning", parent: assistant, flags, system: {} });
  equal("L4 the assistant refuses another ability; takes its Use's and the core's race grant (A11-8)", [
    A.onPreCreateItemB11(ability(), {}, {}),
    A.onPreCreateItemB11(ability(), {}, { eaAssistant: true }),
    A.onPreCreateItemB11(ability({ "trg-prime": { grantedBy: { sourceId: "r", requested: "Empathic Link" } } }), {}, {}),
    A.onPreCreateItemB11({ type: "ability", name: "Cunning", parent: { flags: {}, getFlag: () => undefined, items: [] }, flags: {}, system: {} }, {}, {})
  ], [false, true, true, true]);
  ok("L4b the Use's own items are created with { eaAssistant: true }", (src.match(/\{ eaAssistant: true \}/g) ?? []).length >= 3);
  ok("L4c the entry script passes preCreateItem's options", /onPreCreateItemB11\(item, data, options\)/.test(read("scripts", "eldritch-arts.mjs")));
  equal("L5 Scout Optics' Tracking is Survival (A11-8)", R.SCOUT_CLASS_SKILL, "Survival");
  ok("L5b Scout Optics adds Survival to the Frame's declared class skills", /async function scoutClassSkill/.test(src) && /\[\.\.\.have, R\.SCOUT_CLASS_SKILL\]/.test(src));
  ok("L5c …on a copy that opts out of the core's Codex inheritance, read from its stored flags (found live, 0.18.3)",
    /\[`flags\.\$\{SYSTEM_ID\}\.codexInherit`\]: false/.test(src) && /frame\._source\?\.flags\?\.\[SYSTEM_ID\]\?\.classSkills/.test(src));
  {
    const ci = fs.readFileSync(path.join(SYSTEM_ROOT, "module", "codex-inheritance.mjs"), "utf8");
    ok("L5d the core's opt-out is still codexInherit: false", /codexInherit/.test(ci));
  }
  // A11-16 lives in the core (3.713.1): the save is told the caster's tradition
  equal("L6 a multi-tradition spell cast by an arcane caster: First Weave not asked (the core narrows the save's traditions)",
    [R.firstWeaveWants({ type: "save", check: { traditions: "arcane" } }), R.firstWeaveWants({ type: "save", check: { traditions: "verdant" } })], [false, true]);
}

if (failures.length) {
  console.error(`verify-block11: ${failures.length} of ${checks} failed:`);
  for (const f of failures) console.error(`  ✗ ${f}`);
  process.exit(1);
}
console.log(`verify-block11: OK — ${checks} checks.`);
