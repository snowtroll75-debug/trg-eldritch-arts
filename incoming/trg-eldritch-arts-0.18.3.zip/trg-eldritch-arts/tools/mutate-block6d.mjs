#!/usr/bin/env node
/**
 * mutate-block6d — the mutation half of verify-block6d. Each mutation breaks
 * one printed number, one reading or one wire of Block 6's group D;
 * verify-block6d must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block6d.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block6-d.mjs"), A = f("module", "block6d-automations.mjs");
const B5A = f("tools", "content", "block5-a.mjs"), B5B = f("tools", "content", "block5-b.mjs"), B5D = f("tools", "content", "block5-d.mjs"), B1 = f("tools", "content", "block1.mjs");

const MUTATIONS = [
  { name: "LIVE TEST F3 REVERTED: Lightning Rod's mark is deleted before the marked creature's effect, unguarded", file: A, from: "  await deleteIfPresent(target);\n  await deleteIfPresent(mark);\n}", to: "  await mark.delete?.();\n  await target?.delete?.();\n}" },
  { name: "a vanished effect's delete error is thrown", file: A, from: "if (!/does not exist/i.test(String(err?.message ?? err))) throw err;", to: "throw err;" },
  // The content
  { name: "Extra Cantrip declares no bonus cantrip", file: C, from: "flags: { eaAutomation: \"extraCantrip\", cantripBonus: 1 },", to: "flags: { eaAutomation: \"extraCantrip\" }," },
  { name: "Extra Cantrip is not repeatable", file: C, from: "  classFeat(\"EXTRA CANTRIP\", {\n    repeatable: true,", to: "  classFeat(\"EXTRA CANTRIP\", {" },
  { name: "Lightning Rod's compound prerequisite is not read", file: C, from: "flags: { eaAutomation: \"lightningRod\", compoundSkillPrerequisites: true },", to: "flags: { eaAutomation: \"lightningRod\" }," },
  { name: "Spellthread claims full automation", file: C, from: "\"Spellthread\": { level: \"C\",", to: "\"Spellthread\": { level: \"B\"," },
  { name: "Mana Bound's card says partly", file: C, from: "classFeat(\"MANA BOUND\", {\n    flags: { eaAutomation: \"manaBound\" },\n    automation: `${AUTO}", to: "classFeat(\"MANA BOUND\", {\n    flags: { eaAutomation: \"manaBound\" },\n    automation: `${PART}" },
  { name: "Lightning Rod's card forgets Q127", file: C, from: "as electricity damage with no save (Q127)", to: "as electricity damage with no save" },
  { name: "Piercing Insight is graded D in the deferred list", file: C, from: "\"Piercing Insight\": { file: \"tools/content/block5-d.mjs\", level: \"C\",", to: "\"Piercing Insight\": { file: \"tools/content/block5-d.mjs\", level: \"D\"," },
  // The five deferred cards
  { name: "Q94 undone on Pulse's card", file: B5A, from: "It reaches learned and innate casts; not a charged item's spell", to: "It reaches innate and item casts too; not a charged item's spell" },
  { name: "Echo's card forgets the half damage (Q75)", file: B5B, from: "takes half the damage, rounded down, and the spell's other effects. The core's limits", to: "takes the damage and the spell's other effects. The core's limits" },
  { name: "Piercing Insight's card forgets the GM", file: B5D, from: "*the GM applies it* to the detection", to: "*it is applied* to the detection" },
  { name: "Spell Surge loses its Focus trait", file: B1, from: "((f) => { f.system.traits = \"Focus\"; return f; })(generalFeat(\"SPELL SURGE\", {", to: "((f) => f)(generalFeat(\"SPELL SURGE\", {" },
  { name: "Resonant Harmony is graded D again", file: B5A, from: "\"Resonant Harmony\": { level: \"B\",", to: "\"Resonant Harmony\": { level: \"D\"," },
  // The numbers
  { name: "Focused Spell costs 2 PP", file: A, from: "export const FOCUSED_PP = 3;", to: "export const FOCUSED_PP = 2;" },
  { name: "Subconscious Casting costs 4 PP", file: A, from: "export const SUBCONSCIOUS_PP = 6;", to: "export const SUBCONSCIOUS_PP = 4;" },
  { name: "Echo costs 1 PP", file: A, from: "export const ECHO_PP = 2;", to: "export const ECHO_PP = 1;" },
  { name: "Steelbinding reaches 60 ft", file: A, from: "export const STEEL_FEET = 30;", to: "export const STEEL_FEET = 60;" },
  { name: "Thunderclap Aura reaches 20 ft", file: A, from: "export const THUNDERCLAP_FEET = 10;", to: "export const THUNDERCLAP_FEET = 20;" },
  { name: "Lightning Rod's splash reaches 20 ft", file: A, from: "export const SPLASH_FEET = 10;", to: "export const SPLASH_FEET = 20;" },
  { name: "Mana Bound is −10", file: A, from: "export const MANA_BOUND_MODIFIER = -20;", to: "export const MANA_BOUND_MODIFIER = -10;" },
  { name: "Lightning Rod's save is −1", file: A, from: "export const LIGHTNING_ROD_SAVE = -2;", to: "export const LIGHTNING_ROD_SAVE = -1;" },
  { name: "Spellthread Mastery weaves no third", file: A, from: "export const threadCapacity = (mastery) => (mastery ? 2 : 1);", to: "export const threadCapacity = (mastery) => 1;" },
  { name: "Pact Channeler's 14th-level dice never come", file: A, from: "export const pactDice = (level) => (int(level) >= 14 ? \"4d6\" : \"2d6\");", to: "export const pactDice = (level) => \"2d6\";" },
  { name: "Fey's penalty stays −1", file: A, from: "export const pactFeyPenalty = (level) => (int(level) >= 14 ? 2 : 1);", to: "export const pactFeyPenalty = (level) => 1;" },
  // The readings
  { name: "Arcane Fencer takes a two-handed grip", file: A, from: "|| !ctx.weaponUuid || ctx.twoHanded === true) return false;", to: "|| !ctx.weaponUuid) return false;" },
  { name: "Arcane Fencer takes a Two-Handed weapon", file: A, from: "  return !/\\btwo-handed\\b/i.test(String(weapon.system?.traits ?? \"\"));", to: "  return true;" },
  { name: "Arcane Fencer is not capped at the caster level", file: A, from: "export const fencerMax = (casterLevel, pool) => Math.max(0, Math.min(int(casterLevel), int(pool)));", to: "export const fencerMax = (casterLevel, pool) => Math.max(0, int(pool));" },
  { name: "Arcane Fencer's bonus is circumstance", file: A, from: "[{ label: \"Arcane Fencer\", value: int(pp), type: \"status\" }]", to: "[{ label: \"Arcane Fencer\", value: int(pp), type: \"circumstance\" }]" },
  { name: "Arcane Fencer spends no PP", file: A, from: "    await actor.update({ \"system.resources.pp.value\": poolOf(actor) - pp });\n    return { modifiers", to: "    return { modifiers" },
  { name: "Conduit Mastery cuts a Rod of the Magi draw", file: A, from: "  if (norm(ctx.reason) === \"ppsource\") return null;\n  return { reduction: 1", to: "  return { reduction: 1" },
  { name: "Conduit Mastery's minimum is 0", file: A, from: "return { reduction: 1, minimum: 1, label: \"Conduit Mastery\" };", to: "return { reduction: 1, minimum: 0, label: \"Conduit Mastery\" };" },
  { name: "Dual Channel answers a Failure", file: A, from: "[\"fumble\", \"blunder\"].includes(norm(ctx.degree));", to: "[\"fumble\", \"blunder\", \"failure\"].includes(norm(ctx.degree));" },
  { name: "Dual Channel rolls no depletion", file: A, from: "      if (!released || dualChannelRollsReleased(ctx)) await h().rollItemDepletion(ctx.actor, item);", to: "      if (false) await h().rollItemDepletion(ctx.actor, item);" },
  { name: "Dual Channel rolls the released item twice", file: A, from: "      if (!released || dualChannelRollsReleased(ctx)) await h()", to: "      if (true) await h()" },
  { name: "Dual Channel never rolls a wielder-paid release", file: A, from: "export const dualChannelRollsReleased = (ctx = {}) => ctx.paidBy === \"wielder\" || int(ctx.ppSpent) === 0;", to: "export const dualChannelRollsReleased = (ctx = {}) => false;" },
  { name: "the riders ignore the cast's own Save DC", file: A, from: "  if (ctx.saveDC !== null && ctx.saveDC !== undefined && Number.isFinite(Number(ctx.saveDC)) && Number(ctx.saveDC) > 0) return int(ctx.saveDC);\n", to: "" },
  { name: "Echo cancels the cast silently again", file: A, from: "includes(element)) return { lines: [`Echo of the Ancestors: this cast's damage", to: "includes(element)) return { cancel: true, lines: [`Echo of the Ancestors: this cast's damage" },
  { name: "Lightning Rod cancels the cast silently again", file: A, from: "    : { lines: [\"Lightning Rod: this cast deals no electricity damage", to: "    : { cancel: true, lines: [\"Lightning Rod: this cast deals no electricity damage" },
  { name: "Lightning Rod marks without electricity", file: A, from: "  if (!electric) return { lines: [...lines, \"Lightning Rod: the spell dealt no electricity damage — nothing is marked.\"] };\n", to: "" },
  { name: "Piercing Insight spends no Focus use", file: A, from: "  for (const o of chosen) if (o.focusItem) await spendUse(o.focusItem);\n", to: "" },
  { name: "Piercing Insight offers a spent Focus option", file: A, from: "      if (!feat || usesLeft(feat) <= 0) continue;", to: "      if (!feat) continue;" },
  { name: "Piercing Insight offers discounts", file: A, from: "if (o.source !== \"core\" && (PIERCING_LEFT_OUT.has(norm(o.key)) || (!int(o.ppCost) && !o.focus))) continue;", to: "if (false) continue;" },
  { name: "Resonant Conduit with one item", file: A, from: "Array.from(ctx.wielded ?? []).length >= 2", to: "Array.from(ctx.wielded ?? []).length >= 1" },
  { name: "Resonant Conduit never stamps the day", file: A, from: "  await actor.setFlag(MODULE_ID, RESONANT_CONDUIT_FLAG, true);\n", to: "" },
  { name: "Resonant Conduit's day never returns", file: A, from: "  if (actor?.getFlag?.(MODULE_ID, RESONANT_CONDUIT_FLAG)) await actor.unsetFlag(MODULE_ID, RESONANT_CONDUIT_FLAG);", to: "  void actor;" },
  { name: "Weave Infusion's depletion has no disadvantage", file: A, from: "depletionBias: \"disadvantage\", label: \"Weave Infusion", to: "depletionBias: \"\", label: \"Weave Infusion" },
  { name: "Weave Infusion refuses an empty item", file: A, from: "{ ownPP: true, allowEmpty: true, depletionBias", to: "{ ownPP: true, allowEmpty: false, depletionBias" },
  { name: "Metamagic Conduit allows nothing", file: A, from: "? { allowed: true, label: \"Metamagic Conduit\" } : null)", to: "? { allowed: false, label: \"Metamagic Conduit\" } : null)" },
  { name: "Mana Bound eases a Blunder", file: A, from: "  if (ctx.blunder) return null;\n  if (norm(ctx.check?.type) !== \"spellcraft\") return null;", to: "  if (norm(ctx.check?.type) !== \"spellcraft\") return null;" },
  { name: "Mana Bound eases a skill release", file: A, from: "  if (norm(ctx.check?.type) !== \"spellcraft\") return null;\n  return { modifier", to: "  return { modifier" },
  { name: "Extra Cantrip's spacing not checked", file: A, from: "  return int(copyIndex) < allowed ? \"\" :", to: "  return true ? \"\" :" },
  { name: "Extra Cantrip chooses from any tradition", file: A, from: "{ ppCost: 0, ...(tradition ? { tradition } : {}), note:", to: "{ ppCost: 0, note:" },
  { name: "Focused Spell reaches innate casts", file: A, from: "  scope: { innate: false, item: false },\n  applies: (ctx) => Boolean(ctx.rollsCheck)", to: "  applies: (ctx) => Boolean(ctx.rollsCheck)" },
  { name: "Focused Spell gives nothing", file: A, from: "effects: { checkBias: \"advantage\", lines:", to: "effects: { lines:" },
  { name: "Lightning Rod's splash rounds up", file: A, from: "  const half = Math.floor(count / 2);", to: "  const half = Math.ceil(count / 2);" },
  { name: "Lightning Rod's −2 never automatic", file: A, from: "    auto: Boolean(metalArmour), oneShot: true, when: { checkTypes: [\"save\"], traits: [\"electricity\"] }", to: "    auto: false, oneShot: true, when: { checkTypes: [\"save\"], traits: [\"electricity\"] }" },
  { name: "Lightning Rod splashes the marked creature", file: A, from: "tokens().filter((t) => t !== markedToken && t.actor !== actor &&", to: "tokens().filter((t) => t.actor !== actor &&" },
  { name: "Lightning Rod splashes allies", file: A, from: " && !allies(t.document?.disposition, me?.document?.disposition ?? 1) && (feetBetween(markedToken, t)", to: " && (feetBetween(markedToken, t)" },
  { name: "Lightning Rod's own cast splashes its new mark", file: A, from: "  if (ctx.spellData && LIGHTNING_HANDLED.has(ctx.spellData)) return;\n", to: "" },
  { name: "Lightning Rod triggers on any spell", file: A, from: "if (!mark || !ctx.cast || ctx.threaded || !hasTrait(ctx.spellData?.traits, \"electricity\")) return;", to: "if (!mark || !ctx.cast || ctx.threaded) return;" },
  { name: "Lightning Rod's mark never ends", file: A, from: "  await endMark(mark);\n  return lines;", to: "  return lines;" },
  { name: "Lightning Rod's caster mark leaves the −2 behind", file: A, from: "  const target = await fromUuidAsync(effect.flags?.[MODULE_ID]?.markedEffect);\n  await deleteIfPresent(target);\n}", to: "}" },
  { name: "Thunderclap Aura counts 1d6 a PP", file: A, from: "  const n = Math.floor(int(totalPP) / 2);", to: "  const n = int(totalPP);" },
  { name: "Thunderclap Aura's save is Reflex", file: A, from: "save: \"fortitude\", basic: true, dc, scope: \"area\"", to: "save: \"reflex\", basic: true, dc, scope: \"area\"" },
  { name: "Thunderclap Aura on a failed cast", file: A, from: "async function thunderclapAfter(ctx) {\n  if (!ctx.cast) return null;", to: "async function thunderclapAfter(ctx) {" },
  { name: "Thunderclap Aura opens on Fire", file: A, from: "applies: (ctx) => hasTrait(ctx.traits, \"air\") || hasTrait(ctx.traits, \"electricity\"),", to: "applies: (ctx) => hasTrait(ctx.traits, \"fire\") || hasTrait(ctx.traits, \"electricity\")," },
  { name: "the spell's save DC forgets the ability", file: A, from: "  return 10 + Math.max(0, int(totalPP)) + int(ability) + (highMagic ? 2 : 0);", to: "  return 10 + Math.max(0, int(totalPP)) + (highMagic ? 2 : 0);" },
  { name: "an innate cast's DC is not its innate save DC", file: A, from: "  if (innateDC !== null && innateDC !== undefined && Number.isFinite(Number(innateDC))) return int(innateDC);\n", to: "" },
  { name: "Steelbinding's Success immobilises", file: A, from: "  if (d === \"success\") return [{ key: \"slowed\", value: 1, ...clock }];", to: "  if (d === \"success\") return [{ key: \"immobilised\", ...clock }];" },
  { name: "Steelbinding's Critical slows", file: A, from: "  if (d === \"heroic\" || d === \"critical\") return [];", to: "  if (d === \"heroic\") return [];" },
  { name: "Steelbinding lasts 1 round boundary", file: A, from: "const clock = inCombat ? { expiresRound: int(round) + 2 }", to: "const clock = inCombat ? { expiresRound: int(round) + 1 }" },
  { name: "Steelbinding's save is Reflex", file: A, from: "type: \"save\", subject: \"fortitude\", label: `Steelbinding", to: "type: \"save\", subject: \"reflex\", label: `Steelbinding" },
  { name: "Steelbinding drops no weapon on a Blunder", file: A, from: "    if (weapon && t.actor.isOwner) {\n      await weapon.update({ \"system.equipped\": false });", to: "    if (weapon && t.actor.isOwner) {" },
  { name: "Steelbinding ignores the armour", file: A, from: "t.actor !== actor && wearsMetalArmour(t.actor.items) && (!me", to: "t.actor !== actor && (!me" },
  { name: "metal armour need not be worn", file: A, from: "i?.type === \"armour\" && i.system?.equipped && /\\bmetal\\b/i", to: "i?.type === \"armour\" && /\\bmetal\\b/i" },
  { name: "Spellthread's Partial stays a Partial", file: A, from: "  if (d === \"partial\") return { degree: \"failure\"", to: "  if (d === \"partialx\") return { degree: \"failure\"" },
  { name: "Spellthread's Failure stays a Failure", file: A, from: "  if (d === \"failure\") return { degree: \"fumble\"", to: "  if (d === \"failurex\") return { degree: \"fumble\"" },
  { name: "Spellthread saves PP as normal", file: A, from: "apDelta: Math.max(0, longest - int(primaryAP)), savingStep: 1,", to: "apDelta: Math.max(0, longest - int(primaryAP)), savingStep: 0," },
  { name: "Spellthread's woven PP are metamagic, not base", file: A, from: "  const basePPAdd = woven.reduce((n, s) => n + Math.max(0, int(s?.system?.ppCost)), 0);", to: "  const basePPAdd = 0;" },
  { name: "Spellthread takes the shorter time", file: A, from: "  const longest = Math.max(int(primaryAP), ...woven.map((s) => int(s?.system?.castAP)));", to: "  const longest = int(primaryAP);" },
  { name: "Spellthread ignores the tradition", file: A, from: "    if (!unbound && !sameTradition(s.system?.tradition, ctx.spellData?.tradition ?? ctx.tradition)) continue;\n", to: "" },
  { name: "Spellthread weaves cantrips", file: A, from: "s.system?.innate || int(s.system?.ppCost) <= 0) continue;", to: "s.system?.innate) continue;" },
  { name: "Spellthread resolves on a failure", file: A, from: "  if (!ctx.cast || ctx.refunded || !SUCCESSES.includes(norm(ctx.degree))) return { lines:", to: "  if (ctx.refunded) return { lines:" },
  { name: "Spellthread's woven spell is cast afresh", file: A, from: "await h().castSpell(ctx.actor, spell, { thread: { check: ctx.check, degree: norm(ctx.degree), primaryUuid: ctx.spell?.uuid ?? \"\" } });", to: "await h().castSpell(ctx.actor, spell, {});" },
  { name: "Echo at full damage", file: A, from: "damageFactor: 0.5, label: \"Echo of the Ancestors\"", to: "damageFactor: 1, label: \"Echo of the Ancestors\"" },
  { name: "Echo on any element", file: A, from: "    return Boolean(element) && damaging(ctx) && [...(ctx.damageTypes ?? []).slice(0, 1), ...elementalTypesOf(ctx.actor)].map(norm).includes(element);", to: "    return damaging(ctx);" },
  { name: "Echo may pick a creature already targeted", file: A, from: "t.actor !== actor && !chosen.has(t.id) && (range", to: "t.actor !== actor && (range" },
  { name: "Echo is not a Focus option", file: A, from: "ppCost: ECHO_PP, focus: true, needsSpell: true,", to: "ppCost: ECHO_PP, needsSpell: true," },
  { name: "Pulse gives +2", file: A, from: "effects: { saveDC: [{ value: 1, type: \"untyped\", label: \"Resonant Pulse\" }]", to: "effects: { saveDC: [{ value: 2, type: \"untyped\", label: \"Resonant Pulse\" }]" },
  { name: "Pulse on a spell without a save", file: A, from: "  applies: (ctx) => hasSave(ctx.defence),\n  effects: { saveDC", to: "  applies: () => true,\n  effects: { saveDC" },
  { name: "Harmony shares with a distant ally", file: A, from: "allies(t.document?.disposition, me.document?.disposition) && (feetBetween(me, t) ?? Infinity) <= 5);", to: "allies(t.document?.disposition, me.document?.disposition));" },
  { name: "Harmony on any spell", file: A, from: "  applies: (ctx) => selfOnly(ctx),", to: "  applies: () => true," },
  { name: "Spell Surge's save bonus is untyped", file: A, from: "saveDC: [{ value: 2, type: \"class\", label: \"Spell Surge\" }]", to: "saveDC: [{ value: 2, type: \"untyped\", label: \"Spell Surge\" }]" },
  { name: "Spell Surge's fumble has no disadvantage", file: A, from: "  const base = { fumbleBias: \"disadvantage\", resonanceBias: \"disadvantage\" };", to: "  const base = { resonanceBias: \"disadvantage\" };" },
  { name: "Spell Surge ×2", file: A, from: "case \"range\": return { ...base, rangeFactor: 1.5,", to: "case \"range\": return { ...base, rangeFactor: 2," },
  { name: "Spell Surge offers the range on Touch", file: A, from: "if (rangeFeet && !/^touch/.test(norm(ctx.range)))", to: "if (rangeFeet)" },
  { name: "Unfettered Mastery is not a Quicken", file: A, from: "ppCost: 0, focus: true, kind: \"quicken\",", to: "ppCost: 0, focus: true," },
  { name: "Unfettered Mastery off High Magic", file: A, from: "  applies: (ctx) => Boolean(ctx.highMagic) && int(ctx.castAP) > 1,", to: "  applies: (ctx) => int(ctx.castAP) > 1," },
  { name: "Subconscious Casting is offered in the dialog", file: A, from: "ppCost: SUBCONSCIOUS_PP, preset: true,", to: "ppCost: SUBCONSCIOUS_PP," },
  { name: "Subconscious Casting casts a 2 AP spell", file: A, from: "int(s.system?.castAP) === 1 && /^(self|touch)\\b/", to: "int(s.system?.castAP) <= 2 && /^(self|touch)\\b/" },
  { name: "Subconscious Casting casts at range", file: A, from: "int(s.system?.castAP) === 1 && /^(self|touch)\\b/.test(norm(s.system?.range))", to: "int(s.system?.castAP) === 1" },
  { name: "Subconscious Casting pays AP", file: A, from: "await h().castSpell(actor, spell, { apPaid: true, metamagic: { preset: [{ key: MM.subconscious }] } });", to: "await h().castSpell(actor, spell, { metamagic: { preset: [{ key: MM.subconscious }] } });" },
  { name: "Subconscious Casting without its +6", file: A, from: "await h().castSpell(actor, spell, { apPaid: true, metamagic: { preset: [{ key: MM.subconscious }] } });", to: "await h().castSpell(actor, spell, { apPaid: true });" },
  { name: "Subconscious Casting spends Focus on a Partial", file: A, from: "  const paid = Boolean(result) && !result.refunded && degree !== \"partial\";", to: "  const paid = Boolean(result);" },
  { name: "Subconscious Casting never spends its Focus", file: A, from: "  if (paid) await spendUse(feat);\n", to: "" },
  { name: "Subconscious Casting with no use left", file: A, from: "return Boolean(feat) && usesLeft(feat) > 0 && subconsciousSpells", to: "return Boolean(feat) && subconsciousSpells" },
  { name: "Sensory Spell gives +1", file: A, from: "export const SENSORY_BONUS = 2;", to: "export const SENSORY_BONUS = 1;" },
  { name: "Sensory Spell's bonus is never spent", file: A, from: "scope: \"your next Deception, Intimidate or Perform check this turn\", auto: true, oneShot: true,", to: "scope: \"your next Deception, Intimidate or Perform check this turn\", auto: true," },
  { name: "Sensory Spell's bonus on a failed cast", file: A, from: "async function sensoryAfter(ctx) {\n  if (!ctx.cast) return null;", to: "async function sensoryAfter(ctx) {" },
  { name: "Pact Channeler's Demonic adds no fire", file: A, from: "...(damaging(ctx) ? { addedDamage: [{ dice, type: \"fire\", label: \"Pact Channeler\" }] } : {})", to: "" },
  { name: "Pact Channeler's Draconic adds to any pool", file: A, from: "const mods = types[0] === pact.energy ? { damageDice: dice } : types[1] === pact.energy ? { secondaryDice: dice } : null;", to: "const mods = { damageDice: dice };" },
  { name: "Pact Channeler's Fey on any save", file: A, from: "      const will = /will/.test(norm(ctx.defence));", to: "      const will = true;" },
  { name: "Pact Channeler's Void asks no save", file: A, from: "  after: (ctx) => (pactOf(ctx.actor?.items)?.patron === \"void\" ? voidAfter(ctx) : null)", to: "  after: () => null" },
  { name: "Void's Flat-Footed on a Success", file: A, from: "conditions: { failure: flat, fumble: flat }", to: "conditions: { success: flat, failure: flat, fumble: flat }" },
  { name: "Elemental Pact's air is fire", file: A, from: "export const ELEMENT_ENERGY = Object.freeze({ air: \"electricity\",", to: "export const ELEMENT_ENERGY = Object.freeze({ air: \"fire\"," },
  { name: "Draconic Pact offered before its type", file: A, from: "(!['draconic', 'elemental'].includes(pact.patron) || Boolean(pact.energy))".replace(/'/g, "\""), to: "true" },
  { name: "Versatile Binder rolls Fortitude whatever the spell", file: A, from: "const save = (norm(ctx.spellData?.defence).match(/fortitude|reflex|will/) ?? [\"will\"])[0];", to: "const save = \"fortitude\";" },
  { name: "Piercing Insight spends no PP", file: A, from: "  if (pp) await actor.update({ \"system.resources.pp.value\": poolOf(actor) - pp });", to: "" },
  { name: "Piercing Insight overspends", file: A, from: "  if (pp > poolOf(actor)) { warn(", to: "  if (false) { warn(" },
  { name: "Piercing Insight on any action", file: A, from: "!actor || ![\"senseMagicBroad\", \"senseMagicFocused\"].includes(key) ||", to: "!actor ||" },
  // RETIRED (lead, 0.9.0): Spell Surge's load-time migration was removed (it would alter world data); verify-block6-lead pins its absence.
  { name: "G9: Pact Channeler open to all", file: A, from: "  [FEAT.pact]: (actor) => (pactOf(actor?.items) ? null :", to: "  [FEAT.pact]: (actor) => (true ? null :" },
  // Registration
  { name: "no metamagic registered", file: A, from: "  for (const [key, spec] of Object.entries(METAMAGIC_B6_D)) api.registerMetamagic?.(key, spec, moduleId);\n", to: "" },
  { name: "the charged-item rules are not registered", file: A, from: "  for (const [key, rule] of Object.entries(CHARGED_RULES_B6_D)) api.registerChargedItemRule?.(key, rule, moduleId);\n", to: "" },
  { name: "the eligibility checks are not registered", file: A, from: "  for (const [name, check] of Object.entries(ELIGIBILITY_B6_D)) api.registerFeatEligibility?.(name, check, moduleId);\n", to: "" },
  { name: "Mana Bound is not registered", file: A, from: "  api.registerFumbleModifier?.(\"manaBound\", manaBound, moduleId);\n", to: "" },
  { name: "Spellthread's remap is not registered", file: A, from: "  api.registerCastDegreeRemap?.(\"spellthread\", threadRemap, moduleId);\n", to: "" },
  { name: "Arcane Fencer is not registered", file: A, from: "  api.registerCheckReaction?.(\"arcaneFencer\", arcaneFencer, moduleId);\n", to: "" },
  { name: "Subconscious Casting's offer is not registered", file: A, from: "  api.registerUnconsciousOffer?.(\"subconsciousCasting\", subconsciousOffer, moduleId);\n", to: "" },
  { name: "Subconscious Casting's step is not registered", file: A, from: "  api.registerReactionStep?.(SUBCONSCIOUS_STEP, subconsciousStep, moduleId);\n", to: "" },
  { name: "Extra Cantrip's Use is not registered", file: A, from: "  for (const [name, entry] of Object.entries(AUTOMATIONS_B6_D)) api.registerFeatAutomation(name, entry, moduleId);\n", to: "" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block6d.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block6d: verify-block6d already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block6d: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block6d: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
