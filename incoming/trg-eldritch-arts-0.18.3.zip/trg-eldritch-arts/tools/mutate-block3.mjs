#!/usr/bin/env node
/**
 * mutate-block3 — the mutation half of verify-block3. Each mutation breaks
 * one printed number, one reading or one wire of Block 3a; verify-block3 must
 * fail on every one. Files are restored after each run, and on any exit.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block3.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block3.mjs"), S = f("tools", "content", "block3-spells.mjs"), A = f("module", "block3-automations.mjs"),
  REG = f("module", "registration.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), MANIFEST = f("module.json"), T2 = f("module", "block2-automations.mjs");

const MUTATIONS = [
  // A — the classes
  { name: "a table column is read one to the right", file: C, from: "    col(row, \"bonus feats\"), col(row, \"caster level\"), col(row, \"pp\"), col(row, \"bsb\")", to: "    col(row, \"bonus feats\"), col(row, \"pp\"), col(row, \"pp\"), col(row, \"bsb\")" },
  { name: "the Witch's merged BAB/BDB column is not read", file: C, from: "    col(row, \"bab\", \"bab/bdb\"), col(row, \"bdb\", \"bab/bdb\"),", to: "    col(row, \"bab\", \"bab/bdb\"), col(row, \"bab\"),", },
  { name: "the Archmage memorises four cantrips", file: C, from: "  cantripsPerDay: 3, cantripsKnown: 6, spellBookFirstPicks: 6,", to: "  cantripsPerDay: 4, cantripsKnown: 6, spellBookFirstPicks: 6," },
  { name: "the Archmage's book grows by two", file: C, from: "classMagic: { traditions: \"any\", bookPerLevel: 1, cantripBook: true }", to: "classMagic: { traditions: \"any\", bookPerLevel: 2, cantripBook: true }" },
  { name: "the Archmage cannot use a focus", file: C, from: "  flags: { highMagicCaster: true, highMagicFocus: true, classMagic:", to: "  flags: { highMagicCaster: true, classMagic:" },
  { name: "the Sorcerer's first pick is a fixed PP 2", file: C, from: "    repertoire: { firstPicks: 1, firstPickExact: false, pickFrom: 3, pickStep: 2, swapFrom: 99 },", to: "    repertoire: { firstPicks: 1, pickFrom: 3, pickStep: 2, swapFrom: 99 }," },
  { name: "the Sorcerer is given swaps the book does not print", file: C, from: "firstPicks: 1, firstPickExact: false, pickFrom: 3, pickStep: 2, swapFrom: 99", to: "firstPicks: 1, firstPickExact: false, pickFrom: 3, pickStep: 2, swapFrom: 5" },
  { name: "the birthright track starts at 1st", file: C, from: "tracks: [{ key: \"birthright\", label: \"Birthright\", firstPicks: 0, pickFrom: 2,", to: "tracks: [{ key: \"birthright\", label: \"Birthright\", firstPicks: 1, pickFrom: 2," },
  { name: "the Witch's High Magic is Ethereal and Verdant only again (the 4 Nov 2026 ruling undone)", file: C, from: "    highMagicCaster: true,\n    repertoire: { firstPicks: 2,", to: "    highMagicCaster: [\"ethereal\", \"verdant\"],\n    repertoire: { firstPicks: 2," },
  { name: "the Witch's card still says Ethereal and Verdant only", file: C, from: "Every spell you cast is High Magic, whatever its tradition (Graham's ruling, 4 November 2026)", to: "Only Ethereal and Verdant spells, and your hexes, are High Magic (Graham's ruling, 4 November 2026)" },
  { name: "the Witch's second spell waits until 3rd", file: C, from: "repertoire: { firstPicks: 2, firstPickExact: false, pickFrom: 2, pickStep: 1, swapFrom: 99 },\n    classMagic: { traditions: [\"ethereal\", \"verdant\"] }", to: "repertoire: { firstPicks: 2, firstPickExact: false, pickFrom: 3, pickStep: 1, swapFrom: 99 },\n    classMagic: { traditions: [\"ethereal\", \"verdant\"] }" },
  { name: "Chapter 6's wealth is not read", file: C, from: "  for (const r of rows.slice(2)) for (let i = 0; i + 1 < r.cells.length; i += 2) if (r.cells[i]) out[r.cells[i]] = Number(r.cells[i + 1]);", to: "" },
  { name: "Scribe Scroll is not granted", file: C, from: "  grantedFeats: \"1: Scribe Scroll\",", to: "  grantedFeats: \"\"," },
  // B — the birthrights
  { name: "Q15 undone: Storm keeps the printed Orb of Electricity", file: C, from: "  \"Orb of Electricity (0)\": Object.freeze({ name: \"Orb Of Lightning\",", to: "  \"Orb of Electricity (0x)\": Object.freeze({ name: \"Orb Of Lightning\"," },
  { name: "the magical ability is the second key ability", file: C, from: "  const first = /^(\\w+)/.exec(keyLine)[1];", to: "  const first = /, (\\w+)/.exec(keyLine)[1];" },
  { name: "the birthright's specialist spell is not granted", file: C, from: "  const granted = [...(specialist ? [`1: ${specialist}`] : []), ...spells.map((s) => `${s.level}: ${s.name}`)].join(\", \");", to: "  const granted = spells.map((s) => `${s.level}: ${s.name}`).join(\", \");" },
  { name: "the Wild's track is no tradition at all", file: C, from: "      classMagic: { ability: ABILITY_KEY[first], tradition: tradition === \"any\" ? \"\" : tradition, tracks: { birthright: tradition } },", to: "      classMagic: { ability: ABILITY_KEY[first], tradition: tradition === \"any\" ? \"\" : tradition, tracks: { birthright: tradition === \"any\" ? \"\" : tradition } }," },
  { name: "the bonus skills are not class skills", file: C, from: "      classSkills: [skills[1], skills[2]],", to: "      classSkills: [skills[1]]," },
  { name: "the Arcanum may not use a focus", file: C, from: "      ...(name === \"Arcanum\" ? { highMagicFocus: true } : {})", to: "" },
  { name: "Eternity's Death State is +1", file: C, from: "[{ key: \"system.combat.deathState\", mode: 2, value: \"2\", priority: 20 }]", to: "[{ key: \"system.combat.deathState\", mode: 2, value: \"1\", priority: 20 }]" },
  { name: "Darkness arrives at 1st", file: C, from: "grantedSpells: \"5: Darkness\"", to: "grantedSpells: \"1: Darkness\"" },
  // C — the spells
  { name: "a specialist spell is not specialist", file: S, from: "specialist = true", to: "specialist = false" },
  // D — the rules
  { name: "Raw Power raises an unwarped casting", file: A, from: "  if (!ctx.highMagic || !ctx.warped) return 0;", to: "  if (!ctx.highMagic) return 0;" },
  { name: "Ley Bond answers a low magic casting", file: A, from: "  if (!ctx.highMagic || !ctx.rollsCheck) return null;\n  if (!leyBondHeld(ctx.actor)) return null;", to: "  if (!ctx.rollsCheck) return null;\n  if (!leyBondHeld(ctx.actor)) return null;" },
  { name: "the Archmage reaches no other class's spells", file: A, from: "  if (className(actor) === \"archmage\") return true;", to: "" },
  { name: "a birthright's own spells are not its own", file: A, from: "  if (tags.includes(key)) return true;", to: "" },
  { name: "Umbral's shadow trait is not read", file: A, from: "    return access.traits.some((t) => traits.includes(t));", to: "    return false;" },
  { name: "the Soulbound Familiar's HP is the master's Charisma", file: A, from: "  return { label: \"Soulbound Familiar\", hp: int(mirror.level), saves: int(mirror.abilities?.charisma), type: \"class\" };", to: "  return { label: \"Soulbound Familiar\", hp: int(mirror.abilities?.charisma), saves: int(mirror.abilities?.charisma), type: \"class\" };" },
  { name: "a hex every two levels", file: A, from: "export const hexesOwed = (level) => (int(level) >= 1 ? 1 + Math.floor(int(level) / 3) : 0);", to: "export const hexesOwed = (level) => (int(level) >= 1 ? 1 + Math.floor(int(level) / 2) : 0);" },
  { name: "Q19 undone: one Wild spell at 1st", file: A, from: "export const WILD_SPELL_LADDER = Object.freeze([[1, 0], [1, 2], [3, 4],", to: "export const WILD_SPELL_LADDER = Object.freeze([[1, 2], [3, 4]," },
  { name: "the d20 table is read off by one", file: A, from: "export const WILD_TRADITIONS = Object.freeze([[1, 5, \"arcane\"], [6, 10, \"divinity\"],", to: "export const WILD_TRADITIONS = Object.freeze([[1, 6, \"arcane\"], [7, 10, \"divinity\"]," },
  { name: "a PP 1 spell surges", file: A, from: "int(natural) === 13 && int(basePP) >= 2;", to: "int(natural) === 13 && int(basePP) >= 1;" },
  { name: "Q20 undone: the surge's level is the caster level", file: A, from: "  const level = area ? int(area.level) : int(spellData?.ppCost);", to: "  const level = area ? int(area.level) : levelOf(actor);" },
  { name: "Power Recovery's Success rounds down", file: A, from: "success: Math.ceil(cl / 2)", to: "success: Math.floor(cl / 2)" },
  // G — the Foundry side
  { name: "a hex above your level is offered", file: A, from: " && int(e.system?.ppCost) <= levelOf(actor));", to: ");" },
  { name: "the familiar has no Base DR 2", file: A, from: "    changes: [{ key: \"system.combat.naturalArmourBase.natural\", mode: 4, value: \"2\", priority: 20 }]", to: "    changes: []" },
  { name: "a killed familiar severs nothing", file: A, from: "  if (await h().isDead(actor)) await onFamiliarLost(actor, `${actor.name} has been killed.`);", to: "" },
  { name: "Severed Bond does not fatigue", file: A, from: "  await h().applyConditionTagsTo(actor, [{ key: \"fatigued\", value: 2 }]);", to: "" },
  { name: "a severed bond is remade outside daily preparation", file: A, from: "      if (item.getFlag(MODULE_ID, SEVERED)) return warn(", to: "      if (false) return warn(" },
  { name: "Verdant Communion regains no PP", file: A, from: "    if (pp && pool) await actor.update({ \"system.resources.pp.value\": Math.min(int(pool.max), int(pool.value) + pp) });", to: "" },
  { name: "Verdant Communion is not once a day", file: A, from: "    if (Number.isFinite(left)) await item.update({ \"system.usesValue\": left - 1 });", to: "" },
  { name: "yesterday's Wild specialist stays", file: A, from: "  if (old.length) await actor.deleteEmbeddedDocuments(\"Item\", old.map((i) => i.id));\n  const mine = known(actor);\n  // A CLASS'S", to: "  const mine = known(actor);\n  // A CLASS'S" },
  { name: "the Wild's daily spell may be a hex", file: A, from: "e.system?.specialist && !e.flags?.[SYSTEM_ID]?.eaHex && int(e.system?.ppCost) === 1", to: "e.system?.specialist && int(e.system?.ppCost) === 1" },
  { name: "the claws attack with BAB", file: A, from: "    flags: { [SYSTEM_ID]: { attackBase: \"bsb\" }, [MODULE_ID]: { [CLAW_FLAG]: true } }", to: "    flags: { [SYSTEM_ID]: {}, [MODULE_ID]: { [CLAW_FLAG]: true } }" },
  { name: "the dragon type is never asked", file: A, from: "    if (br && !dragonTypeOf(actor)) {", to: "    if (false) {" },
  { name: "THE REVIEW'S DEFECT: Wild rows counted, not matched", file: A, from: "    const owed = wildSpellsOwed(level).filter(([at, pp]) => !have.has(`${at}:${pp}`));", to: "    const owed = wildSpellsOwed(level).filter((row, i) => i >= have.size);" },
  { name: "a new bond leaves the severed bond's fatigue", file: A, from: "  if (left > 0) await actor.toggleStatusEffect(\"fatigued\", { value: left, force: true });\n  else await actor.toggleStatusEffect(\"fatigued\", { active: false });", to: "" },
  { name: "THE REVIEW'S DEFECT: a dead familiar is rebonded", file: A, from: "  if (familiar && (await h().isDead(familiar))) {\n    await card(", to: "  if (false) {\n    await card(" },
  { name: "a Use on a dead familiar offers its menu", file: A, from: "    if (familiar && (await h().isDead(familiar))) return warn(", to: "    if (false) return warn(" },
  { name: "THE REVIEW'S DEFECT: an ordinary spell is opened", file: A, from: "  if (!spell?.system?.specialist || spell?.flags?.[SYSTEM_ID]?.eaHex) return false;", to: "  if (spell?.flags?.[SYSTEM_ID]?.eaHex) return false;" },
  { name: "a hex is opened to the feat", file: A, from: "  if (!spell?.system?.specialist || spell?.flags?.[SYSTEM_ID]?.eaHex) return false;", to: "  if (!spell?.system?.specialist) return false;" },
  // E — registration
  { name: "the classes are not registered", file: REG, from: "  for (const [name, spec] of Object.entries(CLASS_REGISTRATIONS)) api.registerClass?.(name, structuredClone(spec), moduleId);", to: "" },
  { name: "Raw Power is not registered", file: REG, from: "  api.registerCastCapModifier?.(\"rawPower\", rawPowerRaise, moduleId);", to: "" },
  { name: "the familiar modifier is not registered", file: REG, from: "  api.registerFamiliarModifier?.(\"soulboundFamiliar\", soulboundModifier, moduleId);", to: "" },
  { name: "Wild Power's PP is not registered", file: REG, from: "  api.registerPPGrant?.(\"Wild Power\", { perLevel: 1, label: \"Wild Power (+1 PP per level)\", types: [\"ability\"] }, moduleId);", to: "" },
  { name: "the Sorcerer's wealth is the Archmage's", file: REG, from: "[\"Sorcerer\", 0, [\"Simple\"], [], []]", to: "[\"Sorcerer\", 1, [\"Simple\"], [], []]" },
  { name: "Ley Bond's gate is Block 2's again", file: REG, from: "  api.registerSpellCheckGate?.(\"leyLineConnection\", leyBondGate, moduleId);", to: "  api.registerSpellCheckGate?.(\"leyLineConnection\", async () => null, moduleId);" },
  // H — hooks and versions
  { name: "the settled hook is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB3(ctx)", to: "Hooks.on(\"trgPrimeSpellSettledX\", (ctx) => { void (ctx)" },
  { name: "the system version is not required", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.679.0\";" },
  { name: "the module version is not raised", file: MANIFEST, from: "\"version\": \"0.18.3\"", to: "\"version\": \"0.4.0\"" },
  // 0.5.1 — found in the live test of 0.5.0
  { name: "the severed bond's fatigue is a string tag again", file: A, from: "await h().applyConditionTagsTo(actor, [{ key: \"fatigued\", value: 2 }]);", to: "await h().applyConditionTagsTo(actor, [\"fatigued 2\"]);" },
  { name: "Hexes takes one a Use again", file: A, from: "    while (hexesHeld() < owed) {", to: "    if (hexesHeld() < owed) {" },
  { name: "the printed item is a spell adder again", file: C, from: "the mile-and-24-hours separation — tick it with Use (Q25).\"\n].join(\" \"));", to: "the mile-and-24-hours separation — tick it with Use (Q25).\"\n].join(\" \"), { flags: { spellAdder: 1 } });" },
  { name: "a severed bond keeps its spell adder", file: A, from: "  const live = isSoulboundTo(familiar, actor) && !item.getFlag(MODULE_ID, SEVERED);", to: "  const live = isSoulboundTo(familiar, actor);" },
  { name: "the adder is never taken away", file: A, from: "  if (!live && flagged !== undefined && flagged !== null) await item.unsetFlag(SYSTEM_ID, \"spellAdder\");", to: "" },
  { name: "the bond never sets the adder", file: A, from: "  if (live && Number(flagged) !== 1) await item.setFlag(SYSTEM_ID, \"spellAdder\", 1);", to: "" },
  { name: "a 0.5.0 Witch is not trued up", file: A, from: "  for (const actor of game.actors ?? []) if (soulboundItem(actor) && actsFor(actor)) await syncSoulboundAdder(actor);", to: "" },
  { name: "ranges read the drawn centre again", file: f("module", "block1-automations.mjs"), from: "    const measured = canvas.grid.measurePath([tokenCentre(a), tokenCentre(b)]).distance;", to: "    const measured = canvas.grid.measurePath([{ x: a.center.x, y: a.center.y }, { x: b.center.x, y: b.center.y }]).distance;" },
  { name: "the source centre ignores the token's size", file: f("module", "block1-automations.mjs"), from: "    return { x: at.x + (Math.max(1, Number(s.width ?? 1)) * size) / 2, y: at.y + (Math.max(1, Number(s.height ?? 1)) * size) / 2 };", to: "    return { x: at.x, y: at.y };" },
  { name: "Gale Step measures from the drawn centre again", file: A, from: "    const from = tokenCentre(token);", to: "    const from = { x: token.center.x, y: token.center.y };" },
  { name: "a refused Gale Step still cards", file: A, from: "    if (now.x === was.x && now.y === was.y) return warn(\"Gale Step: the teleport was refused (see the notice), so nothing is spent.\");", to: "" },
  { name: "a familiar's death is asked only when its HP changes", file: A, from: "export async function onActorUpdatedB3(actor) {\n  await onFamiliarMaybeDiedB3(actor);\n}", to: "export async function onActorUpdatedB3(actor, change) {\n  if (!foundry.utils.hasProperty(change ?? {}, \"system.resources.hp\")) return;\n  await onFamiliarMaybeDiedB3(actor);\n}" },
  { name: "a familiar's death by Dying is not asked", file: A, from: "  if (await h().isDead(actor)) await onFamiliarLost(actor, `${actor.name} has been killed.`);\n}\nexport async function onActorUpdatedB3", to: "  void actor;\n}\nexport async function onActorUpdatedB3" },
  { name: "the effect hooks are not wired", file: SCRIPT, from: "for (const hook of [\"createActiveEffect\", \"updateActiveEffect\"]) {", to: "for (const hook of []) {" },
  { name: "the slain hook is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeCreatureSlain\", (ctx) => { onFamiliarMaybeDiedB3(ctx?.victim)", to: "Hooks.on(\"trgPrimeCreatureSlainX\", (ctx) => { onFamiliarMaybeDiedB3(ctx?.victim)" },
  { name: "a renewed bond says nothing", file: A, from: "      await card(actor, \"Soulbound Familiar\", [line(`After an hour of meditation your bond with <strong>${esc(familiar.name)}</strong> is renewed.`), ...lifted]);", to: "" },
  { name: "the renewed bond keeps its fatigue", file: A, from: "      const lifted = await liftSeveredFatigue(actor, item);\n      await syncSoulboundAdder(actor);\n      await card(", to: "      const lifted = [];\n      await syncSoulboundAdder(actor);\n      await card(" },
  { name: "a second word of the death severs again", file: A, from: "  if (!item || item.getFlag(MODULE_ID, SEVERED) || SEVERING.has(actor.id)) return;", to: "  if (!item || SEVERING.has(actor.id)) return;" },
  { name: "no guard against one death told three times", file: A, from: "  if (!item || item.getFlag(MODULE_ID, SEVERED) || SEVERING.has(actor.id)) return;\n  SEVERING.add(actor.id);", to: "  if (!item || item.getFlag(MODULE_ID, SEVERED)) return;" },
  { name: "the new bond deletes the whole Fatigued effect", file: A, from: "  const left = Math.max(0, value - owed);", to: "  const left = 0;" },
  { name: "a 0.5.0 severed bond takes 2 fatigue off anyway", file: A, from: "  const owed = Number(severed.fatigue ?? 0);", to: "  const owed = Number(severed.fatigue ?? 2);" },
  { name: "the sever records no fatigue", file: A, from: "{ why, at: Number(game.time?.worldTime ?? 0), fatigue: 2 }", to: "{ why, at: Number(game.time?.worldTime ?? 0) }" },
  { name: "any familiar is a spell adder", file: A, from: "  const live = isSoulboundTo(familiar, actor) && !item.getFlag", to: "  const live = Boolean(familiar) && !item.getFlag" },
  { name: "a forced d100 is ignored", file: T2, from: "forcedTotal >= 1 && forcedTotal <= 100 ? { total: forcedTotal, roll: null } :", to: "false ? null :" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block3.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block3: verify-block3 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block3: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block3: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
