#!/usr/bin/env node
/**
 * verify-block5a — Eldritch Arts 0.8.0 (Block 5, group A, on TRG Prime
 * 3.683.0): the 18 Aetherial racial feats and the 9 for other races.
 *
 *   A  every feat against the book: name, race, traits, prerequisites, uses,
 *      the printed text and the automation paragraph, the docs' table
 *   B  the data: effects, conditionals, auras, declarations, grants
 *   C  the core, run with the content: conditionals and the light axis, the
 *      ally auras, the light source, magical terrain, Unbound's spare,
 *      prerequisites (C1), the Quiliesh's races, Focus uses, the Dispel
 *      factor, the dying waiver, the cantrip filter
 *   D  the pure rules
 *   E  registration
 *   F  the Foundry side with fakes: every Use, reaction and hook
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block5a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y) and the placeable keep the OLD
 * position; the document's `_source` and `change` carry the NEW one.
 */
function placeEnd(doc, change) {
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
}
async function moveV14(token, change, handler, ...rest) {
  placeEnd(token.document, change);
  return handler(token.document, change, ...rest);
}


const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";

/* ----------------------------------------------------------------- */
/* Fakes                                                                */
/* ----------------------------------------------------------------- */
const cards = [];
const answers = [];
const reactorAnswers = [];
const asked = [];
const calls = { replace: [], chooseSpell: [], resolveAction: [], spendReaction: [], armMove: [], light: [], conditions: [], stance: [], casts: [] };
let moved = { feet: 0, apOnMovement: 0 };
let dispelDegree = "success";
let reactionRefused = "";
let stanceEnters = true;
const STEPS = {};
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async (title, label, options) => { helpers.lastOptions = options; return answers.length ? answers.shift() : null; },
  createEffectsOn: async (target, list) => target.createEmbeddedDocuments("ActiveEffect", list),
  itemUsesMax: (item) => { const n = Number(String(item.system?.usesPerDay ?? "").trim()); if (n > 0) return n; return /\bfocus\b/i.test(String(item.system?.traits ?? "")) ? 1 : null; },
  itemUsesRemaining: (item) => Number(item.system?.usesValue ?? 0),
  replaceFeatEffect: async (actor, item, data, opts = {}) => {
    calls.replace.push({ item: item.name, data, opts });
    actor.effects = actor.effects.filter((e) => e.flags?.[SYS]?.featSource !== item.id);
    data.flags ??= {}; data.flags[SYS] = { ...(data.flags[SYS] ?? {}), featSource: item.id, ...(opts.dailyPrep ? { dailyPrep: true } : {}) };
    return (await actor.createEmbeddedDocuments("ActiveEffect", [data]))[0];
  },
  chooseSpell: async (actor, item, spec) => { calls.chooseSpell.push(spec); return true; },
  askReactor: async (actor, q) => { asked.push({ actor: actor.name, title: q.title, step: q.step, data: q.data }); const a = reactorAnswers.length ? reactorAnswers.shift() : "yes"; if (a !== "yes") return { answer: a, result: null }; return { answer: a, result: await STEPS[q.step](actor, a, q.data) }; },
  spendReaction: async (actor, label) => { calls.spendReaction.push([actor.name, label]); return true; },
  reactionRefusal: async () => reactionRefused,
  isDead: async () => false,
  skillActions: [{ key: "dispel", name: "Dispel", apCost: "1" }],
  resolveAction: async (actor, action, opts) => { calls.resolveAction.push({ actor: actor.name, action, opts }); return { outcome: { degree: { key: dispelDegree, label: dispelDegree } } }; },
  movementThisTurn: async () => ({ ...moved }),
  armMove: async (actor, leg, label) => { calls.armMove.push({ actor: actor.name, leg, label }); return true; },
  refreshTokenLight: async (actor) => { calls.light.push(actor.name); },
  applyConditionTags: async (actor, tags, opts) => { calls.conditions.push({ actor: actor.name, tags, opts }); },
  enterShadowStance: async (actor, opts) => { calls.stance.push({ actor: actor.name, opts }); return stanceEnters; },
  castSpell: async (actor, spell, options) => { calls.casts.push({ actor: actor.name, spell: spell.name, innate: spell.system?.innate, flags: spell.flags?.[SYS], options, targets: [...(globalThis.game.user.targets ?? [])].map((t) => t.id) }); return "cast"; }
};
globalThis.Hooks = { on() { return 1; }, off() {}, callAll() {}, once() {} };
globalThis.foundry = { applications: { api: { DialogV2: { confirm: async () => true } } }, utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => "r1", deepClone: (x) => JSON.parse(JSON.stringify(x)), fromUuid: async (u) => uuidMap.get(u) ?? null } };
globalThis.ui = { notifications: { warn: (t) => cards.push({ warn: t }), info() {}, error() {} } };
globalThis.Item = { implementation: class { constructor(d) { Object.assign(this, JSON.parse(JSON.stringify(d))); } } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };
const uuidMap = new Map();

let nextId = 0;
function makeItem(data, parent) {
  const it = { ...JSON.parse(JSON.stringify(data)), id: data._id ?? `i${++nextId}`, parent };
  it.flags = it.flags ?? {};
  it.getFlag = (scope, key) => it.flags?.[scope]?.[key];
  it.setFlag = async (scope, key, v) => { (it.flags[scope] ??= {})[key] = v; };
  it.unsetFlag = async (scope, key) => { delete it.flags?.[scope]?.[key]; };
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  return it;
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a };
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.delete = async () => { a.effects = a.effects.filter((x) => x !== e); };
  return e;
}
function makeActor(name, { level = 5, items = [], pp = 10, ap = 3, hp = 10, classBonus = 2 } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: true, effects: [], flags: {}, items: [], documentName: "Actor", conditions: new Set() };
  a.system = { identity: { level, classBonus }, resources: { pp: { value: pp }, ap: { value: ap }, hp: { value: hp } }, combat: { movement: { land: { total: 30 } } }, skills: {}, specialistSkills: {}, magic: { spellcraft: { dc: 17 } } };
  a.items = Object.assign(items.map((d) => makeItem(d, a)), { get(id) { return this.find((i) => i.id === id); } });
  a.getFlag = (scope, key) => a.flags?.[scope]?.[key];
  a.setFlag = async (scope, key, v) => { (a.flags[scope] ??= {})[key] = v; };
  a.unsetFlag = async (scope, key) => { delete a.flags?.[scope]?.[key]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, list) => {
    if (type === "Item") { const made = list.map((d) => makeItem(d, a)); a.items.push(...made); if (!a.items.get) a.items.get = function (id) { return this.find((i) => i.id === id); }; return made; }
    const made = list.map((d) => makeEffect(d, a)); a.effects.push(...made); return made;
  };
  a.deleteEmbeddedDocuments = async (type, ids) => { a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.hasCondition = (k) => a.conditions.has(k);
  a.testUserPermission = () => true;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
function makeToken(id, actor, { x = 0, y = 0, disposition = 1 } = {}) {
  const t = { id, name: actor.name, actor, center: { x, y }, w: 100, h: 100, isTargeted: false };
  t.document = { actor, disposition, width: 1, height: 1, _source: { x: x - 50, y: y - 50, width: 1, height: 1 }, update: async (u) => { if (!refuseTeleport) Object.assign(t.document._source, u); } };
  t.setTarget = (on) => { t.isTargeted = on; if (on) game.user.targets.add(t); else game.user.targets.delete(t); };
  actor.token = t;
  return t;
}
let refuseTeleport = false;
let clicked = null;
globalThis.game = {
  trgPrime: { modules: { helpers } }, user: { id: "u1", isGM: true, targets: new Set() }, users: { activeGM: null, filter: () => [] },
  combat: null, actors: [], packs: [], time: { worldTime: 0 }, settings: { get: () => null }, system: { id: "trg-prime", version: "3.683.0" }
};
// 5 ft a square of 100 px.
globalThis.canvas = {
  tokens: { placeables: [] }, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }), getSnappedPoint: (p) => ({ x: Math.round(p.x / 100) * 100, y: Math.round(p.y / 100) * 100 }) },
  stage: { on: (ev, fn) => { if (clicked) fn({ data: { getLocalPosition: () => clicked } }); }, off() {} }
};
const startCombat = (actor, { round = 1, turn = 0, others = [] } = {}) => {
  const turns = [{ actor, actorId: actor.id }, ...others.map((o) => ({ actor: o, actorId: o.id }))];
  game.combat = { id: "c1", started: true, round, turn, combatants: turns, turns, combatant: turns[turn] };
};

const C = await import(new URL("./content/block5-a.mjs", import.meta.url));
const auto = await import(new URL("../module/block5a-automations.mjs", import.meta.url));
Object.assign(STEPS, { [auto.ECHO_STEP]: auto.STEPS_B5_A.echoStep, [auto.ASCENDANCE_STEP]: auto.STEPS_B5_A.ascendanceStep, [auto.VEIL_STEP]: auto.STEPS_B5_A.veilStep });
const F = Object.fromEntries(C.FEATS_B5_A.map((f) => [f.name, f]));
const fl = (name) => F[name].flags[SYS];

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
const LIST = {
  "AETHERIAL CONCORD": ["Aetherial", "Focus", "", ""], "AETHERIAL SCHOLAR": ["Aetherial", "", "", ""], "ASTRAL CROSSING": ["Aetherial", "Focus, Translocation", "Level 10, Astral Step", ""],
  "ASTRAL DRIFT": ["Aetherial", "", "", ""], "ASTRAL STEP": ["Aetherial", "Focus, Teleportation", "Level 5, Astral Drift", ""], "CHRONAL AWARENESS": ["Aetherial", "", "Nerathis Heritage", ""],
  "CHRONAL ECHO": ["Aetherial", "Focus, Insight", "Level 5, Chronal Awareness", ""], "RADIANT BULWARK": ["Aetherial", "", "Level 5, Radiant Presence", ""], "RADIANT PRESENCE": ["Aetherial", "", "Caelari Heritage", ""],
  "RESONANT ASCENDANCE": ["Aetherial", "Focus, Metamagic", "Level 10, Resonant Harmony", ""], "RESONANT HARMONY": ["Aetherial", "Focus, Metamagic", "Level 5, Resonant Pulse", ""], "RESONANT PULSE": ["Aetherial", "Focus, Metamagic", "", ""],
  "SKYBORNE AGILITY": ["Aetherial", "", "Aeralis Heritage", ""], "SKYBORNE WALTZ": ["Aetherial", "Focus", "Level 5, Skyborne Agility", ""], "STARSEER’S INTUITION": ["Aetherial", "", "Astryn Heritage", ""],
  "STARSEER’S SIGHT": ["Aetherial", "", "Level 5, Starseer’s Intuition", ""], "VEIL OF DUSK": ["Aetherial", "Focus", "Level 5, Veil of Silence", ""], "VEIL OF SILENCE": ["Aetherial", "", "Umbryth Heritage", ""],
  "ANCESTRAL REVERIE": ["Elf", "", "", ""], "ENDLESS ADAPTATION": ["Human", "", "", "1"], "FEYBLOOD GLAMOUR": ["Gnome", "", "", ""], "MOONLIGHT PRECISION": ["Elf", "", "", ""],
  "QUILIESH": ["Human", "Heritage", "", ""], "RELENTLESS WILL": ["Human", "", "", "1"], "SHADOW’S DISCIPLINE": ["Kornargon", "", "", ""], "UNBOUND": ["Ascendan", "", "Level 1 only", ""],
  "VEIL OF HONOUR": ["Kornargon", "Focus", "Level 5", ""]
};
{
  const racial = new Map(book.sections.racialFeats.map((f) => [f.name, f]));
  const { titleCase: titled } = await import(new URL("./content/block5-common.mjs", import.meta.url));
  equal("A twenty-seven feats: the eighteen Aetherial and the nine for other races, in the book's names", C.FEATS_B5_A.map((f) => f.name), Object.keys(LIST).map(titled));
  equal("A …eighteen Aetherial, nine others", [C.AETHERIAL_FEATS.length, C.OTHER_RACE_FEATS.length], [18, 9]);
  for (const [key, [race, traits, prereq, uses]] of Object.entries(LIST)) {
    const f = F[titled(key)];
    const b = racial.get(key);
    ok(`A ${f?.name}: the book has it`, Boolean(f && b));
    if (!f || !b) continue;
    equal(`A ${f.name}: racial, its race, traits, prerequisites, uses`, [f.type, f.system.category, f.system.sourceRace, f.system.traits, f.system.prerequisites, f.system.usesPerDay], ["feat", "Racial", race, traits, prereq, uses]);
    equal(`A ${f.name}: the prerequisite is the book's`, f.system.prerequisites, b.fields?.Prerequisites ?? "");
    ok(`A ${f.name}: the card prints the book's text`, b.lines.every((l) => f.system.description.includes(l.slice(0, 60))));
    ok(`A ${f.name}: the card says what is automated`, /\*(Automated|Partly automated|Not yet automated|Granted|A Human Heritage feat)/.test(f.system.description) || /<em>(Automated|Partly automated|Not yet automated|Granted|A Human Heritage feat)/.test(f.system.description));
    equal(`A ${f.name}: Block 5 and its book line`, [f.flags[SYS].eaBlock, f.flags[SYS].eaBookLine], [5, b.line]);
  }
  ok("A the race lives in sourceRace, never in traits", C.FEATS_B5_A.every((f) => !/\b(Aetherial|Elf|Human|Gnome|Kornargon|Ascendan)\b/.test(f.system.traits)));
  equal("A the Veils keep \"of\" lower case, as the core's names (the lead's titleCase)", ["VEIL OF DUSK", "VEIL OF SILENCE", "VEIL OF HONOUR"].map((k) => F[titled(k)]?.name), ["Veil of Dusk", "Veil of Silence", "Veil of Honour"]);
  ok("A the curly apostrophe is kept, so Starseer’s Sight's prerequisite names its feat", F["Starseer’s Sight"].system.prerequisites.endsWith(F["Starseer’s Intuition"].name));
  equal("A the docs' table: every feat, by its item's name", Object.keys(C.AUTOMATION_B5_A), C.FEATS_B5_A.map((f) => f.name));
  equal("A …graded A 14, B 10, C 1, D 2", ["A", "B", "C", "D"].map((l) => Object.values(C.AUTOMATION_B5_A).filter((r) => r.level === l).length), [14, 12, 1, 0]);
  // Block 6 (0.9.0, block6d) built the two METAMAGIC options (Q66), and Q94 corrected Pulse's card: no item casts.
  ok("A the two METAMAGIC feats are Block 6's options now, graded B (Q66)", ["Resonant Pulse", "Resonant Harmony"].every((n) => /Automated \(0\.9\.0, TRG Prime 3\.684\.0\):(\*|<\/em>)? an option in the spell's own/.test(F[n].system.description) && C.AUTOMATION_B5_A[n].level === "B"));
  ok("A Resonant Pulse's card follows Q94: learned and innate casts, not a charged item's spell", /learned and innate casts; not a charged item's spell/.test(F["Resonant Pulse"].system.description) && /Q94/.test(F["Resonant Pulse"].system.description) && !/reaches innate and item casts too/.test(F["Resonant Pulse"].system.description));
  ok("A Unbound's card cites Q59 and Quiliesh's Q60 and Q58", /Q59/.test(F.Unbound.system.description) && /Q60/.test(F.Quiliesh.system.description) && /Q58/.test(F.Quiliesh.system.description));
}

/* ----------------------------------------------------------------- */
/* B — the data                                                        */
/* ----------------------------------------------------------------- */
{
  const changes = (n) => F[n].effects.flatMap((e) => e.changes);
  equal("B Aetherial Scholar: +1 racial Arcana and Occultism", changes("Aetherial Scholar"), [{ key: "system.skills.arcana.racial", mode: 2, value: "1", priority: 20 }, { key: "system.skills.occultism.racial", mode: 2, value: "1", priority: 20 }]);
  equal("B Chronal Awareness: +20 racial initiative, Swift Reflexes' key", changes("Chronal Awareness"), [{ key: "system.combat.initiative.race", mode: 0, value: "20", priority: 20 }]);
  equal("B Feyblood Glamour: +1 racial Deception and Perform", changes("Feyblood Glamour").map((c) => [c.key, c.value]), [["system.skills.deception.racial", "1"], ["system.skills.perform.racial", "1"]]);
  equal("B Starseer’s Intuition: +1 racial Sense Motive", changes("Starseer’s Intuition").map((c) => [c.key, c.value]), [["system.skills.senseMotive.racial", "1"]]);
  equal("B Quiliesh: +1 racial Arcana and Occultism, Forbidden Magic granted", [changes("Quiliesh").map((c) => [c.key, c.value]), F.Quiliesh.system.grantedAbilities], [[["system.skills.arcana.racial", "1"], ["system.skills.occultism.racial", "1"]], "Forbidden Magic"]);
  equal("B Skyborne Waltz and Veil of Dusk: Feather Fall and Darkness, granted innate", [[F["Skyborne Waltz"].system.grantedSpells, fl("Skyborne Waltz").grantInnate], [F["Veil of Dusk"].system.grantedSpells, fl("Veil of Dusk").grantInnate]], [["Feather Fall", true], ["Darkness", true]]);
  equal("B Astral Drift declares the magical kind of terrain relief (C16)", fl("Astral Drift").ignoresDifficultTerrain, "magical");
  equal("B Unbound declares that High Magic spares its Forbidden Magic (Q59)", fl("Unbound").forbiddenSparesHighMagic, true);
  const auraOf = (n) => fl(n).auras[0];
  equal("B Radiant Presence: an ally aura of 10 ft, +1 circumstance to saves vs fear, auto and tick", [auraOf("Radiant Presence").kind, auraOf("Radiant Presence").radius, auraOf("Radiant Presence").allyEffect.conditionals.map((c) => [c.value, c.type, c.auto, c.when])],
    ["ally", 10, [[1, "circumstance", true, { checkTypes: ["save"], traits: ["fear"] }], [1, "circumstance", false, { checkTypes: ["save"], not: { traits: ["fear"] } }]]]);
  equal("B Radiant Bulwark: an ally aura of 10 ft, +1 circumstance DB", [auraOf("Radiant Bulwark").kind, auraOf("Radiant Bulwark").radius, auraOf("Radiant Bulwark").allyEffect.changes], ["ally", 10, [{ key: "system.combat.defence.circumstance", value: "1" }]]);
  const conds = (n) => fl(n).conditionals.map((c) => [c.kind, c.value ?? null, c.type ?? null, c.auto, c.when]);
  equal("B Veil of Silence: +2 racial Stealth and Reflex at light 5 or less (Q61)", conds("Veil of Silence"), [["modifier", 2, "race", true, { checkTypes: ["skill"], subjects: ["stealth"], lightLevels: { max: 5 } }], ["modifier", 2, "race", true, { checkTypes: ["save"], subjects: ["reflex"], lightLevels: { max: 5 } }]]);
  equal("B Moonlight Precision: +1 racial ranged attacks and Spellcraft at light 5 and 6", conds("Moonlight Precision"), [["modifier", 1, "race", true, { checkTypes: ["attack"], attackModes: ["ranged"], lightLevels: [5, 6] }], ["modifier", 1, "race", true, { checkTypes: ["spellcraft"], lightLevels: [5, 6] }]]);
  equal("B Starseer’s Intuition: +1 racial Spellcraft for Insight spells", conds("Starseer’s Intuition"), [["modifier", 1, "race", true, { checkTypes: ["spellcraft"], traits: ["insight"] }]]);
  equal("B Starseer’s Sight: advantage on saves vs mental, auto and tick", conds("Starseer’s Sight"), [["advantage", null, null, true, { checkTypes: ["save"], traits: ["mental"] }], ["advantage", null, null, false, { checkTypes: ["save"], not: { traits: ["mental"] } }]]);
  equal("B the module's own flags are ea-prefixed", C.FEATS_B5_A.flatMap((f) => Object.keys(f.flags[SYS]).filter((k) => !["eaBlock", "eaBookLine", "eaAutomation", "conditionals", "auras", "grantInnate", "ignoresDifficultTerrain", "forbiddenSparesHighMagic"].includes(k))), []);
}

/* ----------------------------------------------------------------- */
/* C — the core, run with the content                                  */
/* ----------------------------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
{
  const cond = await quiet(() => import(sys("module", "conditionals.mjs")));
  const norm = (n, i) => cond.normaliseConditional(fl(n).conditionals[i], { name: n }, i);
  const silenceS = norm("Veil of Silence", 0), silenceR = norm("Veil of Silence", 1);
  equal("C Veil of Silence's Stealth row: light 1 and 5 yes, 6 no, no token no (Q61)", [1, 5, 6, null].map((l) => cond.matchesCheck(silenceS, { checkType: "skill", subject: "stealth", lightLevel: l })), [true, true, false, false]);
  equal("C …its Reflex row: a Reflex save at 4, not a Will save, not at 7", [cond.matchesCheck(silenceR, { checkType: "save", subject: "reflex", lightLevel: 4 }), cond.matchesCheck(silenceR, { checkType: "save", subject: "will", lightLevel: 4 }), cond.matchesCheck(silenceR, { checkType: "save", subject: "reflex", lightLevel: 7 })], [true, false, false]);
  const moonA = norm("Moonlight Precision", 0), moonS = norm("Moonlight Precision", 1);
  equal("C Moonlight Precision: a ranged attack at 5 and 6, not 4 or 7, not melee; Spellcraft at 6", [cond.matchesCheck(moonA, { checkType: "attack", attackMode: "ranged", lightLevel: 5 }), cond.matchesCheck(moonA, { checkType: "attack", attackMode: "ranged", lightLevel: 6 }), cond.matchesCheck(moonA, { checkType: "attack", attackMode: "ranged", lightLevel: 4 }), cond.matchesCheck(moonA, { checkType: "attack", attackMode: "ranged", lightLevel: 7 }), cond.matchesCheck(moonA, { checkType: "attack", attackMode: "melee", lightLevel: 5 }), cond.matchesCheck(moonS, { checkType: "spellcraft", lightLevel: 6 })], [true, true, false, false, false, true]);
  equal("C …the rows are racial bonuses to the core, automatic", [moonA.type, moonA.auto, silenceS.type], ["race", true, "race"]);
  const star = norm("Starseer’s Intuition", 0);
  equal("C Starseer’s Intuition: an Insight spell's Spellcraft, not an Evocation's, not a skill", [cond.matchesCheck(star, { checkType: "spellcraft", traits: "Insight, Mental" }), cond.matchesCheck(star, { checkType: "spellcraft", traits: "Evocation" }), cond.matchesCheck(star, { checkType: "skill", traits: "Insight" })], [true, false, false]);
  const sight = [norm("Starseer’s Sight", 0), norm("Starseer’s Sight", 1)];
  equal("C Starseer’s Sight: auto on a mental source, the tick otherwise", [cond.matchesCheck(sight[0], { checkType: "save", traits: "Mental" }), cond.matchesCheck(sight[1], { checkType: "save", traits: "Mental" }), cond.matchesCheck(sight[1], { checkType: "save", traits: "" }), sight[0].auto, sight[1].auto], [true, false, true, true, false]);
  const ca = await quiet(() => import(sys("module", "creature-auras.mjs")));
  const aura = (n) => ca.aurasOf([{ id: "f", name: n, type: "feat", flags: F[n].flags }], 5)[0];
  const rp = aura("Radiant Presence"), rb = aura("Radiant Bulwark");
  equal("C the core reads both auras: ally, 10 ft, their effects", [rp?.kind, rp?.radius, rp?.allyEffect?.conditionals?.length, rb?.kind, rb?.allyEffect?.changes], ["ally", 10, 2, "ally", [{ key: "system.combat.defence.circumstance", value: "1", type: "custom", priority: 20 }]]);
  const fear = cond.normaliseConditional(rp.allyEffect.conditionals[0], { name: "Radiant Presence" }, 0);
  ok("C …Radiant Presence's row matches a save against fear, not a skill", cond.matchesCheck(fear, { checkType: "save", traits: "Fear, Mental" }) && !cond.matchesCheck(fear, { checkType: "skill", traits: "Fear" }));
  const aae = await import(sys("module", "ally-aura-effects.mjs"));
  const emitters = [{ id: "E", name: "E", centreFeet: { x: 0, y: 0 }, widthFeet: 5, disposition: 1, auras: [rb] }];
  const subjects = [{ id: "E", centreFeet: { x: 0, y: 0 }, widthFeet: 5, disposition: 1 }, { id: "A", centreFeet: { x: 10, y: 0 }, widthFeet: 5, disposition: 1 }, { id: "B", centreFeet: { x: 20, y: 0 }, widthFeet: 5, disposition: 1 }];
  const w = aae.wantedAllyGrants({ subjects, emitters });
  equal("C Radiant Bulwark: an ally 10 ft away carries it, one 20 ft away does not, the emitter not (\"allies\")", [w.get("A")?.length ?? 0, w.get("B")?.length ?? 0, w.get("E")?.length ?? 0], [1, 0, 0]);

  const ls = await import(sys("module", "light-sources.mjs"));
  capi.resetModuleRegistry();
  equal("C Radiant Presence's light registers with the core", capi.registerLightSources([{ ...auto.RADIANT_LIGHT }], "test", Object.keys(ls.LIGHT_SOURCES)), 1);
  equal("C …and raises the light 2 steps (Dim 5 → 7), on the actor's effect", [ls.isLightSourceKey(auto.RADIANT_LIGHT.key), ls.applyLightSource(5, auto.RADIANT_LIGHT.key), ls.lightSourceKeysOn({ effects: [{ flags: { [SYS]: { lightSource: auto.RADIANT_LIGHT.key } } }], items: [] })], [true, 7, [auto.RADIANT_LIGHT.key]]);
  ok("C …the content's key is the registered one", C.RADIANT_LIGHT_KEY === auto.RADIANT_LIGHT.key);
  capi.resetModuleRegistry();

  const pf = await quiet(() => import(sys("module", "combat", "passive-feats.mjs")));
  const drifter = { items: [{ name: "Astral Drift", flags: F["Astral Drift"].flags }], effects: [] };
  equal("C Astral Drift eases magical difficult terrain only (C16)", [pf.terrainReliefName(drifter, null, { magicalTerrain: true }), pf.terrainReliefName(drifter, null, { magicalTerrain: false })], ["Astral Drift", null]);

  const hm = await quiet(() => import(sys("module", "magic", "high-magic.mjs")));
  const fm = { name: "Forbidden Magic", type: "ability", system: { active: true }, flags: { [SYS]: { forbiddenTraditions: "divinity, verdant", beneficialTraditionSave: "divinity, verdant" } } };
  const asc = { items: [fm], effects: [] }, unbound = { items: [fm, { name: "Unbound", type: "feat", system: {}, flags: F.Unbound.flags }], effects: [] };
  equal("C Unbound: the core spares its Forbidden Magic against High Magic, not without it (Q58, Q59)", [hm.forbiddenSparesHighMagic(unbound), hm.forbiddenSparesHighMagic(asc), hm.spellSaveTraditions(asc, { tradition: "arcane" }, { highMagic: true }), hm.spellSaveTraditions(unbound, { tradition: "arcane" }, { highMagic: true }), hm.spellSaveTraditions(unbound, { tradition: "divinity" }, { highMagic: false })],
    [true, false, "arcane, divinity, ethereal, verdant", "arcane, ethereal", "divinity"]);

  const pr = await quiet(() => import(sys("module", "prerequisites.mjs")));
  const stats = (level, heritage) => ({ level, knownHeritages: new Set(["nerathis", "caelari", "aeralis", "astryn", "umbryth"].map(pr.heritageNameKey)), heritageNames: new Set(heritage ? [pr.heritageNameKey(heritage)] : []) });
  equal("C the heritage feats are gated by the core (C1, Q57): a Nerathis yes, a Caelari no",
    [pr.meetsParseablePrerequisites(F["Chronal Awareness"].system.prerequisites, stats(1, "Nerathis")), pr.meetsParseablePrerequisites(F["Chronal Awareness"].system.prerequisites, stats(1, "Caelari")), pr.meetsParseablePrerequisites(F["Veil of Silence"].system.prerequisites, stats(1, "Umbryth"))], [true, false, true]);
  equal("C …and Unbound at 1st level only", [pr.meetsParseablePrerequisites(F.Unbound.system.prerequisites, stats(1)), pr.meetsParseablePrerequisites(F.Unbound.system.prerequisites, stats(2))], [true, false]);
  const known = new Set(C.FEATS_B5_A.map((f) => pr.prerequisiteNameKey(f.name)));
  equal("C …a named prerequisite chain (Starseer’s Sight, Veil of Dusk) reads the feat, curly ’ and all",
    [pr.meetsParseablePrerequisites(F["Starseer’s Sight"].system.prerequisites, { level: 5, knownNames: known, ownedNames: new Set([pr.prerequisiteNameKey("Starseer’s Intuition")]) }), pr.meetsParseablePrerequisites(F["Starseer’s Sight"].system.prerequisites, { level: 5, knownNames: known, ownedNames: new Set() }), pr.meetsParseablePrerequisites(F["Veil of Dusk"].system.prerequisites, { level: 5, knownNames: known, ownedNames: new Set([pr.prerequisiteNameKey("Veil of Silence")]) })], [true, false, true]);

  const fe = await quiet(() => import(sys("module", "feats.mjs")));
  capi.resetModuleRegistry();
  auto.registerBlock5A(new Proxy({}, { get: (_, k) => (typeof capi[k] === "function" ? (...a) => capi[k](...a) : () => {}) }), "test");
  equal("C the Quiliesh's effective races: Human, Quiliesh, Ascendan (registerHeritageRaceGrant, Q60)", fe.effectiveRaces("Human", ["Quiliesh"]), "Human, Quiliesh, Ascendan");
  const dm = await import(sys("module", "combat", "dispel-modifiers.mjs"));
  const offers = await dm.offeredDispelModifiers({ presetDispel: { eaResonantAscendance: "feat1" } });
  const setup = { pp: 7, ...dm.combinedDispelModifiers(dm.appliedDispelOffers(offers, [])) };
  equal("C Resonant Ascendance's Dispel: half the declared PP, rounded up, whatever the degree, never a quarter (Q63); its Focus use", [offers.length, setup.ppFactor, setup.focusItemIds, ["success", "critical", "failure"].map((d) => dm.dispelPPPaid(d, setup).pp), dm.dispelCounteractValue(setup)], [1, 0.5, ["feat1"], [4, 4, 4], 7]);
  equal("C …and nothing for another Dispel", (await dm.offeredDispelModifiers({ presetDispel: { effectValue: 3 } })).length, 0);
  ok("C the check reaction, cast reaction, dying modifier and steps reach the core's registry", capi.registeredCheckReactions().some((r) => r.key === "chronalecho") && capi.registeredCastReactions().length === 1 && capi.registeredDyingRecoveryModifiers().some((r) => r.key === "relentlesswill") && [auto.ECHO_STEP, auto.ASCENDANCE_STEP, auto.VEIL_STEP].every((s) => capi.registeredReactionStep(s)));
  equal("C …with nothing the core refused", capi.registrationProblems().length, 0);
  const ds = await quiet(() => import(sys("module", "combat", "death-state.mjs")));
  const human = makeActor("ZZ Dying Human", { items: [F["Relentless Will"]] });
  equal("C the core's dying modifier asks Relentless Will: nothing unmarked", (await ds.dyingRecoveryModifiersFor(capi.registeredDyingRecoveryModifiers(), { actor: human })).noFatigue, false);
  await human.createEmbeddedDocuments("ActiveEffect", [{ name: "x", flags: { [MOD]: { source: auto.RELENTLESS_ARMED } } }]);
  const waived = await ds.dyingRecoveryModifiersFor(capi.registeredDyingRecoveryModifiers(), { actor: human });
  equal("C …marked, the fatigue is waived, and the card says so (C8)", [waived.noFatigue, waived.key, /Relentless Will/.test(waived.lines[0] ?? "")], [true, "relentlesswill", true]);
  capi.resetModuleRegistry();

  const uses = await import(sys("module", "uses.mjs"));
  equal("C the Focus feats have one use each (the core's default); Endless Adaptation and Relentless Will one a day", C.FEATS_B5_A.filter((f) => /Focus/.test(f.system.traits)).map((f) => uses.focusDefaultUses(f.system, "feat")).concat([F["Endless Adaptation"].system.usesValue, F["Relentless Will"].system.usesValue]), [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]);
  const fw = await quiet(() => import(sys("module", "feats-workflow.mjs")));
  const pool = [["Light", "divinity", 0], ["Mage Hand", "arcane", 0], ["Ghost Sound", "ethereal, arcane", 0], ["Shocking Grasp", "arcane", 1], ["Thorns", "verdant", 0]].map(([name, tradition, pp]) => ({ name, system: { tradition, ppCost: pp } }));
  helpers.chooseSpell = async (actor, item, spec) => { calls.chooseSpell.push(spec); return pool.filter(fw.backgroundSpellFilter(spec)).map((s) => s.name); };
  const picked = await auto.AUTOMATIONS_B5_A.Quiliesh.use(makeActor("ZZ Q"), { name: "Quiliesh" });
  equal("C Quiliesh's Use offers the Arcane and Ethereal cantrips only, cast with Spellcraft (not innate)", [picked, Boolean(calls.chooseSpell.at(-1).innate)], [["Mage Hand", "Ghost Sound"], false]);
}

/* ----------------------------------------------------------------- */
/* D — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  equal("D Aetherial Concord: a Success+ cast, not refunded, not an item's", [{ cast: true }, { cast: false }, { cast: true, refunded: true }, { cast: true, itemCast: true }, { cast: true, innate: true }].map(auto.concordDue), [true, false, false, false, true]);
  equal("D …its row: +2 circumstance, a save or a skill check, automatic, spent", auto.concordConditionals().map((c) => [c.value, c.type, c.auto, c.oneShot, c.when.checkTypes]), [[2, "circumstance", true, true, ["save", "skill"]]]);
  const combat = { id: "c", round: 2, turn: 1 };
  equal("D Astral Crossing: out of combat any time; in it, its own turn, before any AP", [auto.crossingRefusal({ inCombat: false }), auto.crossingRefusal({ inCombat: true, ownTurn: false, combat }), auto.crossingRefusal({ inCombat: true, ownTurn: true, combat }), auto.crossingRefusal({ inCombat: true, ownTurn: true, combat, apStamp: { combatId: "c", round: 2, turn: 1 } }), auto.crossingRefusal({ inCombat: true, ownTurn: true, combat, apStamp: { combatId: "c", round: 1, turn: 1 } })].map(Boolean), [false, true, false, true, false]);
  equal("D Astral Drift: 3 AP on movement", [2, 3, 4].map((ap) => auto.driftStepDue({ apOnMovement: ap })), [false, true, true]);
  equal("D Skyborne Agility: 15 feet; Shadow's Discipline: 10", [[10, 15].map((f) => auto.skyborneDue({ feet: f })), [5, 10].map((f) => auto.shadowHideDue({ feet: f }))], [[false, true], [false, true]]);
  equal("D Endless Adaptation (Q65): not a class skill, class bonus + 2; already one, +2", [auto.endlessAdaptationBonus({ isClassSkill: false, classBonus: 3 }), auto.endlessAdaptationBonus({ isClassSkill: true, classBonus: 3 })], [5, 2]);
  equal("D …its row: that skill only, class, automatic, spent", auto.endlessAdaptationConditionals("stealth", 5).map((c) => [c.value, c.type, c.auto, c.oneShot, c.when]), [[5, "class", true, true, { checkTypes: ["skill"], subjects: ["stealth"] }]]);
  equal("D Ancestral Reverie: +2 racial on the skill", auto.reverieChanges("perception"), [{ key: "system.skills.perception.racial", type: "add", value: "2", priority: 20 }]);
  equal("D Shadow's Discipline: +2 racial Reflex", auto.shadowDisciplineChanges(), [{ key: "system.combat.saves.reflex.racial", type: "add", value: "2", priority: 20 }]);
  equal("D Relentless Will: advantage on the next save, spent", auto.relentlessConditionals().map((c) => [c.kind, c.auto, c.oneShot, c.when]), [["advantage", true, true, { checkTypes: ["save"] }]]);
  const me = { name: "me" }, foe = { name: "foe" };
  equal("D Chronal Echo: a hit on its owner by another", [auto.chronalEchoWants({ type: "attack", succeeded: true, target: me, actor: foe }), auto.chronalEchoWants({ type: "attack", succeeded: false, target: me, actor: foe }), auto.chronalEchoWants({ type: "save", succeeded: true, target: me, actor: foe }), auto.chronalEchoWants({ type: "attack", succeeded: true, target: me, actor: me })], [true, false, false, false]);
  equal("D Veil of Honour: a melee Strike's damage, its striker known", [{ amount: 3, sourceUuid: "x", context: { kind: "strike", melee: true } }, { amount: 3, sourceUuid: "x", context: { kind: "strike", melee: false } }, { amount: 3, sourceUuid: "x", context: { kind: "spell" } }, { amount: 0, sourceUuid: "x", context: { kind: "strike", melee: true } }, { amount: 3, context: { kind: "strike", melee: true } }].map(auto.veilOfHonourWants), [true, false, false, false, false]);
  equal("D Resonant Ascendance's offer: its own Dispel only, half, Focus", [auto.ascendanceDispelOffer({ presetDispel: { eaResonantAscendance: "i1" } }), auto.ascendanceDispelOffer({ presetDispel: {} }), auto.ascendanceDispelOffer({})].map((o) => o && [o.ppFactor, o.focus, o.itemId]), [[0.5, true, "i1"], null, null]);
  equal("D the reach: Concord 30, Ascendance 30, the Step 5", [auto.CONCORD_FEET, auto.ASCENDANCE_FEET, auto.STEP_FEET], [30, 30, 5]);
  const cfg = await quiet(() => import(sys("module", "config.mjs")));
  const intWis = Object.entries(cfg.SKILLS).filter(([, s]) => ["intelligence", "wisdom"].includes(s.ability)).map(([k]) => k).sort();
  equal("D Ancestral Reverie offers exactly the core's Intelligence and Wisdom skills", auto.REVERIE_SKILLS.map(([k]) => k).sort(), intWis);
  equal("D Endless Adaptation offers every core skill", auto.ALL_SKILLS.map(([k]) => k).sort(), Object.keys(cfg.SKILLS).sort());
  equal("D Shadow Stance and Dying are read as the core writes them", [auto.isShadowStance({ name: "Shadow Stance" }), auto.isShadowStance({ name: "Shadow Stance", disabled: true }), auto.isDyingEffect({ statuses: new Set(["dying"]) }), auto.isDyingEffect({ statuses: ["unconscious"] })], [true, false, true, false]);
}

/* ----------------------------------------------------------------- */
/* E — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const got = { autos: {}, grants: [], lights: [], check: [], cast: [], dispel: [], dying: [], steps: [] };
  const api = new Proxy({}, { get: (_, k) => ({
    registerFeatAutomation: (n, e) => { got.autos[n] = e; }, registerHeritageRaceGrant: (n, r) => got.grants.push([n, r]),
    registerLightSources: (l) => got.lights.push(l), registerCheckReaction: (n, s) => got.check.push([n, s]), registerCastReaction: (n, f) => got.cast.push([n, f]),
    registerDispelModifier: (n, s) => got.dispel.push([n, s]), registerDyingRecoveryModifier: (n, f) => got.dying.push([n, f]), registerReactionStep: (n, f) => got.steps.push([n, f])
  })[k] ?? (() => {}) });
  auto.registerBlock5A(api, MOD);
  equal("E the Uses, by the items' names", Object.keys(got.autos), ["Aetherial Scholar", "Astral Crossing", "Astral Step", "Ancestral Reverie", "Endless Adaptation", "Quiliesh"]);
  ok("E …each a feat of this group", Object.keys(got.autos).every((n) => F[n] && typeof got.autos[n].use === "function"));
  equal("E the Quiliesh opens the Ascendan's racial feats (Q60)", got.grants, [["Quiliesh", ["Ascendan"]]]);
  equal("E Radiant Presence's light: 2 steps, 10 ft", got.lights.map((l) => l.map((x) => [x.key, x.steps, x.radiusFeet])), [[["radiantPresence", 2, 10]]]);
  ok("E Chronal Echo (after), Resonant Ascendance (cast and Dispel), Relentless Will (dying), three steps",
    got.check[0]?.[0] === "chronalEcho" && typeof got.check[0][1].after === "function" && got.cast[0]?.[0] === "resonantAscendance" && got.dispel[0]?.[0] === "resonantAscendance" && got.dying[0]?.[1] === auto.relentlessWaiver && got.steps.map(([n]) => n).join() === [auto.ECHO_STEP, auto.ASCENDANCE_STEP, auto.VEIL_STEP].join());
  const src = fs.readFileSync(path.join(ROOT, "module", "block5a-automations.mjs"), "utf8");
  ok("E the hook handlers the lead wires are exported", ["onSpellSettledB5A", "onTokenMovedB5A", "onActionResolvedB5A", "onDailyPreparationB5A", "onDamageAppliedB5A", "onItemCreatedB5A", "onItemDeletedB5A", "onReadyB5A", "onEffectCreatedB5A", "onEffectDeletedB5A", "onActorUpdatedB5A"].every((n) => typeof auto[n] === "function" && new RegExp(`Hooks\\.(on|once)\\("[A-Za-z]+"[^)]*\\)[^\\n]*\\n(?:[^\\n]*\\n){0,6}?export async function ${n}\\(`).test(src)));
}

/* ----------------------------------------------------------------- */
/* F — the Foundry side, with fakes                                    */
/* ----------------------------------------------------------------- */
const item = (name, extra = {}) => ({ ...JSON.parse(JSON.stringify(F[name])), _id: `id-${name}`, ...extra });
const withUse = (name, n = 1) => item(name, { system: { ...F[name].system, usesValue: n } });
const lastCard = () => cards.at(-1);
{
  // Aetherial Concord.
  const caster = makeActor("ZZ Caelari", { items: [withUse("Aetherial Concord")] });
  const ally = makeActor("ZZ Ally"), far = makeActor("ZZ Far Ally"), foe = makeActor("ZZ Foe");
  const tc = makeToken("tc", caster, { x: 0, y: 0 }), ta = makeToken("ta", ally, { x: 500, y: 0 }), tf = makeToken("tf", far, { x: 800, y: 0 }), tx = makeToken("tx", foe, { x: 100, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tc, ta, tf, tx];
  await auto.onSpellSettledB5A({ actor: caster, cast: false });
  equal("F Aetherial Concord: nothing on a failed cast", ally.effects.length, 0);
  answers.push("ta");
  await auto.onSpellSettledB5A({ actor: caster, cast: true });
  equal("F …a Success offers the allies within 30 ft only (not 40 ft, not a foe)", helpers.lastOptions?.map(([id]) => id), ["ta"]);
  const e = ally.effects[0];
  equal("F …the chosen ally's one-shot +2, to the end of its next turn; the Focus use spent", [e?.flags?.[MOD]?.source, e?.flags?.[SYS]?.conditionals?.[0]?.value, e?.flags?.[SYS]?.conditionals?.[0]?.oneShot, Boolean(e?.flags?.[SYS]?.spellEffectEnd), caster.items[0].system.usesValue], ["aetherialConcord", 2, true, true, 0]);
  helpers.lastOptions = null;
  await auto.onSpellSettledB5A({ actor: caster, cast: true });
  equal("F …not again with its use spent", [helpers.lastOptions, ally.effects.length], [null, 1]);
  caster.items[0].system.usesValue = 1; answers.push(null);
  await auto.onSpellSettledB5A({ actor: caster, cast: true });
  equal("F …declining spends nothing", caster.items[0].system.usesValue, 1);
  helpers.lastOptions = null;
  await auto.onSpellSettledB5A({ actor: caster, cast: true, itemCast: true });
  equal("F …an item's spell is not asked", helpers.lastOptions, null);
  canvas.tokens.placeables = [];

  // Aetherial Scholar.
  const sch = makeActor("ZZ Scholar", { items: [item("Aetherial Scholar")] });
  await auto.AUTOMATIONS_B5_A["Aetherial Scholar"].use(sch, sch.items[0]);
  ok("F Aetherial Scholar: with no Astral Lore, it says so", /no Astral Lore/.test(cards.at(-1)?.warn ?? ""));
  sch.system.specialistSkills = { astralLore1: { label: "Astral Lore" }, other: { label: "Spell Lore" } };
  await auto.AUTOMATIONS_B5_A["Aetherial Scholar"].use(sch, sch.items[0]);
  equal("F …it writes +2 racial on Astral Lore's slot", sch.effects.at(-1)?.changes, [{ key: "system.specialistSkills.astralLore1.racial", type: "add", value: "2", priority: 20 }]);

  // Astral Crossing.
  const cr = makeActor("ZZ Crosser", { items: [item("Astral Crossing")] });
  const other = makeActor("ZZ Other");
  startCombat(cr, { others: [other] });
  await auto.AUTOMATIONS_B5_A["Astral Crossing"].use(cr, cr.items[0]);
  const inc = cr.effects[0];
  equal("F Astral Crossing: incorporeal, to the start of the next turn", [inc?.flags?.[SYS]?.grantedTraits, inc?.flags?.[SYS]?.conditionExpiresRound, inc?.flags?.[MOD]?.endsAtTurnStart?.round], [["incorporeal"], 3, 2]);
  cr.effects = [];
  cr.flags[SYS] = { apSpentRound: { combatId: "c1", round: 1, turn: 0 } };
  await auto.AUTOMATIONS_B5_A["Astral Crossing"].use(cr, cr.items[0]);
  ok("F …refused once AP has been spent this turn", cr.effects.length === 0 && /before you have spent any AP/.test(cards.at(-1)?.warn ?? ""));
  cr.flags[SYS] = {};
  game.combat.turn = 1; game.combat.combatant = game.combat.turns[1];
  await auto.AUTOMATIONS_B5_A["Astral Crossing"].use(cr, cr.items[0]);
  ok("F …and on another's turn", cr.effects.length === 0 && /own turn/.test(cards.at(-1)?.warn ?? ""));
  game.combat = null;

  // Astral Step: land speed 30; 1 AP.
  const st = makeActor("ZZ Stepper", { items: [item("Astral Step")] });
  const ts = makeToken("ts", st, { x: 50, y: 50 });
  startCombat(st);
  clicked = { x: 650, y: 50 };
  const res = await auto.AUTOMATIONS_B5_A["Astral Step"].use(st, st.items[0]);
  equal("F Astral Step: teleports within its land speed (30 ft), 1 AP (Q62)", [res, ts.document._source.x, st.system.resources.ap.value], [true, 600, 2]);
  clicked = { x: 1450, y: 50 };
  await auto.AUTOMATIONS_B5_A["Astral Step"].use(st, st.items[0]);
  ok("F …not beyond it, and no AP for a refused teleport", st.system.resources.ap.value === 2 && /you may teleport up to 30 feet/.test(cards.at(-1)?.warn ?? ""));
  refuseTeleport = true; clicked = { x: 450, y: 50 };
  await auto.AUTOMATIONS_B5_A["Astral Step"].use(st, st.items[0]);
  ok("F …nor for one the core refused", st.system.resources.ap.value === 2);
  refuseTeleport = false; clicked = null;
  game.combat = null;

  // Chronal Echo.
  const ner = makeActor("ZZ Nerathis", { items: [withUse("Chronal Echo")] });
  const orc = makeActor("ZZ Orc");
  const echo = auto.REACTIONS_B5_A.chronalEcho;
  equal("F Chronal Echo: nothing on a miss", await echo.after({ type: "attack", succeeded: false, actor: orc, target: ner }), null);
  const out = await echo.after({ type: "attack", succeeded: true, actor: orc, target: ner, total: 22 });
  equal("F …a hit asks its owner, spends the reaction and the use, and the attacker rerolls", [out?.reroll, asked.at(-1)?.actor, calls.spendReaction.at(-1), ner.items[0].system.usesValue], [true, "ZZ Nerathis", ["ZZ Nerathis", "Chronal Echo"], 0]);
  equal("F …not again until Refocus", await echo.after({ type: "attack", succeeded: true, actor: orc, target: ner }), null);
  ner.items[0].system.usesValue = 1; reactorAnswers.push("no");
  equal("F …declined, nothing spent", [await echo.after({ type: "attack", succeeded: true, actor: orc, target: ner }), ner.items[0].system.usesValue], [null, 1]);
  reactionRefused = "reaction spent";
  equal("F …not asked when the core refuses the reaction", [await echo.after({ type: "attack", succeeded: true, actor: orc, target: ner }), ner.items[0].system.usesValue], [null, 1]);
  reactionRefused = "";

  // Resonant Ascendance.
  const ra = makeActor("ZZ Resonant", { items: [withUse("Resonant Ascendance")] });
  ra.system.skills.powerManipulation = { ranks: 3 };
  const mage = makeActor("ZZ Mage");
  const tr = makeToken("tr", ra, { x: 0, y: 0 }), tm = makeToken("tm", mage, { x: 600, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tr, tm];
  const offer = auto.REACTIONS_B5_A.resonantAscendance;
  dispelDegree = "success";
  const stop = await offer({ actor: mage, token: tm, spell: { name: "Fireball", uuid: "Item.fireball" }, pp: 6 });
  const call = calls.resolveAction.at(-1);
  equal("F Resonant Ascendance: a cast within 30 ft asks, rolls the core's Dispel at no AP, marked for the half, and stops it on a Success",
    [stop?.stop, call?.action?.apCost, call?.opts?.presetDispel, calls.spendReaction.at(-1)], [true, "0", { effectValue: 6, dc: 17, what: "Fireball", casterUuid: "Actor.ZZ Mage", spellUuid: "Item.fireball", counterSpell: true, eaResonantAscendance: "id-Resonant Ascendance" }, ["ZZ Resonant", "Resonant Ascendance"]]);
  helpers.spendReaction = async () => false;
  equal("F …a reaction the core will not spend does not undo the rolled Dispel (review)", (await offer({ actor: mage, token: tm, spell: { name: "Fireball", uuid: "Item.fireball" }, pp: 6 }))?.stop, true);
  helpers.spendReaction = async (actor, label) => { calls.spendReaction.push([actor.name, label]); return true; };
  dispelDegree = "failure";
  equal("F …a failed Dispel does not stop it", (await offer({ actor: mage, token: tm, spell: { name: "Fireball" }, pp: 6 }))?.stop, false);
  tm.center = { x: 800, y: 0 }; tm.document._source.x = 750; const n0 = calls.resolveAction.length;
  await offer({ actor: mage, token: tm, spell: { name: "Fireball" }, pp: 6 });
  equal("F …not at 40 ft", calls.resolveAction.length, n0);
  tm.center = { x: 600, y: 0 }; tm.document._source.x = 550; ra.system.skills.powerManipulation.ranks = 0;
  await offer({ actor: mage, token: tm, spell: { name: "Fireball" }, pp: 6 });
  equal("F …not untrained in Power Manipulation (Dispel is Trained)", calls.resolveAction.length, n0);
  ra.system.skills.powerManipulation.ranks = 3; ra.items[0].system.usesValue = 0;
  const a0 = asked.length;
  await offer({ actor: mage, token: tm, spell: { name: "Fireball" }, pp: 6 });
  equal("F …not asked with its Focus use spent", [calls.resolveAction.length, asked.length], [n0, a0]);
  ra.items[0].system.usesValue = 1; ra.conditions.add("blinded");
  await offer({ actor: mage, token: tm, spell: { name: "Fireball" }, pp: 6 });
  equal("F …not when it cannot see the casting (Q28)", calls.resolveAction.length, n0);
  ra.conditions.clear();
  await offer({ actor: ra, token: tr, spell: { name: "Shield" }, pp: 2 });
  equal("F …not its own casting", calls.resolveAction.length, n0);
  canvas.tokens.placeables = [];

  // Veil of Honour.
  const kor = makeActor("ZZ Kornargon", { items: [withUse("Veil of Honour"), { _id: "ss", name: "Shadow Stance", type: "ability", system: { traits: "Open, Stance" } }] });
  const brute = makeActor("ZZ Brute");
  const tk = makeToken("tk", kor, { x: 0, y: 0 }), tb = makeToken("tb", brute, { x: 100, y: 0, disposition: -1 });
  canvas.tokens.placeables = [tk, tb];
  game.packs = [{ collection: "trg-prime.spells", documentName: "Item", getIndex: async () => new Map([["d1", { _id: "d1", name: "Daze", system: { ppCost: 0 } }]]), getDocument: async () => ({ toObject: () => ({ _id: "d1", name: "Daze", type: "spell", system: { ppCost: 0, traits: "Cantrip, Mental", usesPerDay: "", range: "30 feet" }, flags: {} }) }) }];
  await auto.onDamageAppliedB5A({ actor: kor, amount: 4, sourceUuid: brute.uuid, context: { kind: "strike", melee: false } });
  equal("F Veil of Honour: a ranged Strike asks nothing", asked.filter((q) => q.step === auto.VEIL_STEP).length, 0);
  await auto.onDamageAppliedB5A({ actor: kor, amount: 4, sourceUuid: brute.uuid, context: { kind: "strike", melee: true } });
  const cast = calls.casts.at(-1);
  equal("F …a melee Strike: reaction and Focus spent, Shadow Stance entered at 0 AP without Open (C19), an innate Daze at the attacker at no AP",
    [calls.spendReaction.at(-1), kor.items[0].system.usesValue, calls.stance.at(-1)?.opts, cast?.spell, cast?.innate, cast?.options, cast?.targets, cast?.flags?.innateOnce], [["ZZ Kornargon", "Veil of Honour"], 0, { apCost: 0, ignoreOpen: true }, "Daze", true, { apPaid: true, presetTargets: true }, ["tb"], true]);
  equal("F …and the user's targets are put back", [...game.user.targets].map((t) => t.id), []);
  kor.items[0].system.usesValue = 1; const nStance = calls.stance.length, nAsk = asked.length;
  await auto.onDamageAppliedB5A({ actor: kor, amount: 4, sourceUuid: brute.uuid, context: { kind: "strike", melee: true } });
  equal("F …a Strike's second packet asks once", asked.length, nAsk);
  await new Promise((r) => setTimeout(r, 2100));
  kor.effects.push(makeEffect({ name: "Shadow Stance", flags: { [SYS]: { featStance: true } } }, kor));
  game.combat = { id: "c1", started: true, round: 3, turn: 0, combatants: [], turns: [], combatant: null };
  await auto.onDamageAppliedB5A({ actor: kor, amount: 4, sourceUuid: brute.uuid, context: { kind: "strike", melee: true } });
  equal("F …already in the stance: Concealed renewed to the start of the next turn, not re-entered", [calls.stance.length, calls.conditions.at(-1)?.tags?.[0]?.key, calls.conditions.at(-1)?.opts?.expiresRound], [nStance, "concealed", 4]);
  game.combat = null;
  canvas.tokens.placeables = [];

  // Relentless Will.
  const hu = makeActor("ZZ Human", { items: [withUse("Relentless Will")] });
  const dying = (await hu.createEmbeddedDocuments("ActiveEffect", [{ name: "Dying", statuses: ["dying"], flags: {} }]))[0];
  await auto.onEffectCreatedB5A(dying);
  equal("F Relentless Will: the first Dying today marks it and spends the day's use", [auto.relentlessWaiver({ actor: hu })?.noFatigue, hu.items[0].system.usesValue], [true, 0]);
  hu.effects = hu.effects.filter((x) => x !== dying);
  await auto.onEffectDeletedB5A(dying);
  const adv = hu.effects.find((x) => x.flags?.[MOD]?.source === "relentlessWill");
  equal("F …leaving it above 0 HP: the mark goes, advantage on the next save for 1 minute", [auto.relentlessWaiver({ actor: hu }), adv?.flags?.[SYS]?.conditionals?.[0]?.kind, adv?.flags?.[SYS]?.spellEffectEnd], [null, "advantage", 60]);
  hu.effects = [];
  const dying2 = (await hu.createEmbeddedDocuments("ActiveEffect", [{ name: "Dying", statuses: ["dying"], flags: {} }]))[0];
  await auto.onEffectCreatedB5A(dying2);
  equal("F …a second Dying that day is not marked", auto.relentlessWaiver({ actor: hu }), null);
  const hu2 = makeActor("ZZ Human 2", { items: [withUse("Relentless Will")], hp: 0 });
  const d3 = (await hu2.createEmbeddedDocuments("ActiveEffect", [{ name: "Dying", statuses: ["dying"], flags: {} }]))[0];
  await auto.onEffectCreatedB5A(d3);
  hu2.effects = hu2.effects.filter((x) => x !== d3);
  await auto.onEffectDeletedB5A(d3);
  equal("F …leaving it at 0 HP waits; healed above 0, the advantage", [hu2.effects.some((x) => x.flags?.[MOD]?.source === "relentlessWill")], [false]);
  hu2.system.resources.hp.value = 3;
  await auto.onActorUpdatedB5A(hu2, { system: { resources: { hp: { value: 3 } } } });
  equal("F …(the advantage arrives, the wait goes)", [hu2.effects.some((x) => x.flags?.[MOD]?.source === "relentlessWill"), hu2.effects.some((x) => x.flags?.[MOD]?.source === auto.RELENTLESS_PENDING)], [true, false]);

  // Shadow's Discipline.
  const sd = makeActor("ZZ Disciple", { items: [item("Shadow’s Discipline")] });
  const stance = (await sd.createEmbeddedDocuments("ActiveEffect", [{ name: "Shadow Stance", flags: { [SYS]: { featStance: true } } }]))[0];
  await auto.onEffectCreatedB5A(stance);
  equal("F Shadow's Discipline: the stance brings +2 racial Reflex", sd.effects.find((x) => x.flags?.[MOD]?.source === "shadowsDiscipline")?.changes, auto.shadowDisciplineChanges());
  sd.effects = sd.effects.filter((x) => x !== stance);
  await auto.onEffectDeletedB5A(stance);
  equal("F …and its end takes it", sd.effects.length, 0);
  const plain = makeActor("ZZ Plain Kornargon");
  const st2 = (await plain.createEmbeddedDocuments("ActiveEffect", [{ name: "Shadow Stance", flags: {} }]))[0];
  await auto.onEffectCreatedB5A(st2);
  equal("F …nothing without the feat", plain.effects.length, 1);

  // Movement: Skyborne Agility, Astral Drift, Shadow's Discipline's Hide line.
  const mv = makeActor("ZZ Aeralis", { items: [item("Skyborne Agility"), item("Astral Drift")] });
  const tmv = makeToken("tmv", mv);
  startCombat(mv);
  moved = { feet: 10, apOnMovement: 1 };
  await moveV14(tmv, { x: 100 }, auto.onTokenMovedB5A, {}, "u1");
  equal("F Skyborne Agility: nothing at 10 ft", mv.effects.length, 0);
  moved = { feet: 15, apOnMovement: 2 };
  await moveV14(tmv, { x: 200 }, auto.onTokenMovedB5A, {}, "u2");
  equal("F …another user's move is that user's to read", mv.effects.length, 0);
  await moveV14(tmv, { x: 200 }, auto.onTokenMovedB5A, {}, "u1");
  const sky = mv.effects.find((x) => x.flags?.[MOD]?.source === "skyborneAgility");
  equal("F …15 ft on its turn: +2 circumstance DB to the start of the next turn", [sky?.changes, sky?.flags?.[SYS]?.conditionExpiresRound], [[{ key: "system.combat.defence.circumstance", type: "custom", value: "2", priority: 20 }], 3]);
  equal("F Astral Drift: no Step before 3 AP on movement", calls.armMove.length, 0);
  moved = { feet: 30, apOnMovement: 3 };
  await moveV14(tmv, { x: 300 }, auto.onTokenMovedB5A, {}, "u1");
  equal("F …at 3, the free Step armed: 5 ft, land, no reactions (C17); Skyborne once", [calls.armMove.at(-1)?.leg, mv.effects.filter((x) => x.flags?.[MOD]?.source === "skyborneAgility").length], [{ maxFeet: 5, speedKey: "land", provokes: false, note: "Astral Drift: a free Step" }, 1]);
  await auto.onActionResolvedB5A({ actor: mv, action: { key: "sneak", traits: "Movement" } });
  equal("F …once a turn", calls.armMove.length, 1);
  game.combat.round = 2;
  await auto.onActionResolvedB5A({ actor: mv, action: { key: "strike", traits: "Attack" } });
  equal("F …a non-movement action is not counted", calls.armMove.length, 1);
  await auto.onActionResolvedB5A({ actor: mv, action: { key: "sneak", traits: "Movement" } });
  equal("F …a Movement-trait action is (a new turn)", calls.armMove.length, 2);
  game.combat.turns.push({ actor: plain, actorId: plain.id }); game.combat.turn = 1; game.combat.combatant = game.combat.turns[1]; game.combat.round = 5;
  await moveV14(tmv, { x: 400 }, auto.onTokenMovedB5A, {}, "u1");
  equal("F …nothing on another's turn", calls.armMove.length, 2);
  const kd = makeActor("ZZ Hider", { items: [item("Shadow’s Discipline")] });
  kd.effects.push(makeEffect({ name: "Shadow Stance", flags: {} }, kd));
  const tkd = makeToken("tkd", kd);
  startCombat(kd);
  moved = { feet: 10, apOnMovement: 1 };
  const nc = cards.length;
  await moveV14(tkd, { y: 100 }, auto.onTokenMovedB5A, {}, "u1");
  ok("F Shadow's Discipline: 10 ft in the stance, the Hide card, saying Lesser Cover is the GM's", cards.length === nc + 1 && /Hide/.test(lastCard()?.lines?.[0] ?? "") && /Lesser Cover/.test(lastCard()?.lines?.[1] ?? ""));
  game.combat = null;

  // Ancestral Reverie.
  const elf = makeActor("ZZ Elf", { items: [item("Ancestral Reverie")] });
  answers.push("athletics");
  await auto.onDailyPreparationB5A({ actor: elf });
  equal("F Ancestral Reverie: a Strength skill is not taken", elf.effects.length, 0);
  answers.push("perception");
  await auto.onDailyPreparationB5A({ actor: elf });
  equal("F …at daily preparation, the chosen skill +2 racial, swept at the next", [elf.effects[0]?.changes, calls.replace.at(-1)?.opts], [auto.reverieChanges("perception"), { dailyPrep: true }]);
  answers.push("occultism");
  await auto.AUTOMATIONS_B5_A["Ancestral Reverie"].use(elf, elf.items[0]);
  equal("F …the Use replaces the pick", elf.effects.map((x) => x.changes[0].key), ["system.skills.occultism.racial"]);

  // Endless Adaptation.
  const hum = makeActor("ZZ Adapter", { items: [withUse("Endless Adaptation")], classBonus: 3 });
  hum.system.skills = { stealth: { isClassSkill: false }, athletics: { isClassSkill: true } };
  answers.push("stealth");
  await auto.AUTOMATIONS_B5_A["Endless Adaptation"].use(hum, hum.items[0]);
  const row = hum.effects[0]?.flags?.[SYS]?.conditionals?.[0];
  equal("F Endless Adaptation: not a class skill, class bonus 3 + 2, its next Stealth check; the day's use", [row?.value, row?.type, row?.when?.subjects, row?.oneShot, hum.items[0].system.usesValue, calls.replace.at(-1)?.opts], [5, "class", ["stealth"], true, 0, { dailyPrep: true }]);
  answers.push("athletics");
  await auto.AUTOMATIONS_B5_A["Endless Adaptation"].use(hum, hum.items[0]);
  ok("F …once a day", /today's use is spent/.test(cards.at(-1)?.warn ?? ""));
  hum.items[0].system.usesValue = 1; answers.push("athletics");
  await auto.AUTOMATIONS_B5_A["Endless Adaptation"].use(hum, hum.items[0]);
  equal("F …a class skill takes +2 (Q65)", hum.effects[0]?.flags?.[SYS]?.conditionals?.[0]?.value, 2);

  // Radiant Presence's light.
  const cae = makeActor("ZZ Caelari Light");
  const [rpItem] = await cae.createEmbeddedDocuments("Item", [item("Radiant Presence")]);
  await auto.onItemCreatedB5A(rpItem);
  equal("F Radiant Presence: an actor effect carries the light, and the token's glow is refreshed", [cae.effects.map((x) => x.flags?.[SYS]?.lightSource), calls.light.at(-1)], [["radiantPresence"], "ZZ Caelari Light"]);
  await auto.onItemCreatedB5A(rpItem);
  equal("F …once", cae.effects.length, 1);
  cae.items = [];
  await auto.onItemDeletedB5A(rpItem);
  equal("F …and it goes with the feat", cae.effects.length, 0);
  const old = makeActor("ZZ Old Caelari", { items: [item("Radiant Presence")] });
  game.actors = [old];
  await auto.onReadyB5A();
  equal("F …at ready, an actor that had the feat before 0.8.0 is lit", old.effects.map((x) => x.flags?.[SYS]?.lightSource), ["radiantPresence"]);
}

console.log(`verify-block5a: ${checks} checks, ${failures.length} failure(s).`);
for (const f of failures) console.log(`  ✗ ${f}`);
process.exit(failures.length ? 1 : 0);
