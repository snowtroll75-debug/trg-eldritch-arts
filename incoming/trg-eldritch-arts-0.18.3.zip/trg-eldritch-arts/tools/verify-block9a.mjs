#!/usr/bin/env node
/**
 * verify-block9a — Eldritch Arts 0.13.0 (Block 9a, on TRG Prime 3.688.0): the
 * 24 catalysts, the four catalyst feats and the ten special materials
 * (docs/ELDRITCH_ARTS_BLOCK9_AUDIT.md §3.2.1–3.2.3; Graham, 13 November 2026:
 * "Go with your recommendation for all questions and proceed" — Q185–Q210,
 * H19–H25).
 *
 *   A  every catalyst against the book: name, price, level, rarity, the printed
 *      entry and table row, the automation note and its key; the pack
 *   B  the data through the REAL core's readers: every catalyst's answer
 *      through `cleanCastItemAnswer` and the fold; the ten materials through
 *      `registerMaterial`, item-quality, rune-declarations and rune-damage
 *   C  the pure rules (module/block9a-rules.mjs)
 *   D  registration
 *   E  the Foundry side with fakes: the offers, the answers, the settle (the
 *      backlash, Catalyst Affinity, Mastery and Conservation), Blood-etched
*      the catalysts in a ritual, Bloodglass's shatter, Sunbronze's light
 *   F  the wiring
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block9a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

/* ----------------------------------------------------------------- */
/* Fakes                                                               */
/* ----------------------------------------------------------------- */
const cards = [], warns = [], damaged = [], tags = [], recurring = [], saves = [], lightRefreshed = [];
let rolls = [];
let dialogPick = null;
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  applyTypedDamage: async (a, o) => { damaged.push({ target: a.name, amount: o.amount, type: o.type }); return { applied: o.amount }; },
  applyConditionTagsTo: async (a, list) => { tags.push(...list.map((t) => ({ target: a.name, ...t }))); },
  addRecurringDamage: async (a, amount, type) => { recurring.push({ target: a.name, amount, type }); },
  levelDC: (l) => 14 + Number(l ?? 0),
  basicSaveHit: async (o) => { saves.push({ target: o.target?.name, save: o.save, dc: o.dc, amount: o.amount, type: o.type }); return { line: `${o.target?.name}: Failure` }; },
  refreshTokenLight: async (a) => { lightRefreshed.push(a.name); }
};
const formulas = [];
globalThis.Roll = class { constructor(f) { this.formula = String(f); formulas.push(this.formula); } async evaluate() { this.total = rolls.length ? rolls.shift() : 1; return this; } };
globalThis.Hooks = { on() {}, once() {}, off() {}, call() { return true; }, callAll() {} };
globalThis.foundry = { applications: { api: { DialogV2: { wait: async (cfg) => (typeof dialogPick === "function" ? dialogPick(cfg) : dialogPick), prompt: async () => null } }, ux: {} }, utils: { setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o) } };
globalThis.ui = { notifications: { warn: (t) => warns.push(t), info() {}, error() {} } };
globalThis.ChatMessage = { getSpeaker: () => ({}), create: async (d) => d };
globalThis.canvas = { tokens: { placeables: [] }, dimensions: { distance: 5 }, grid: { measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) } };
globalThis.game = { trgPrime: { modules: { helpers } }, user: { id: "gm", isGM: true }, combat: null, actors: [], time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: SYS, version: "3.688.1" } };
game.users = Object.assign([game.user], { activeGM: game.user });

let nextId = 0;
function makeItem(actor, data) {
  const it = { id: `i${++nextId}`, parent: actor, flags: {}, ...JSON.parse(JSON.stringify(data)) };
  it.getFlag = (s, k) => it.flags?.[s]?.[k];
  it.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(it, k, v); };
  it.delete = async () => { actor.items.splice(actor.items.indexOf(it), 1); };
  return it;
}
function makeActor(name, { level = 5, ap = 3, feats = [], owner = true } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name}`, isOwner: owner, documentName: "Actor", effects: [], flags: { [SYS]: {}, [MOD]: {} } };
  a.system = { identity: { level }, resources: { ap: { value: ap }, pp: { value: 30 } } };
  a.items = [];
  a.items.get = (id) => a.items.find((i) => i.id === id) ?? null;
  for (const f of feats) a.items.push(makeItem(a, { type: "feat", name: f }));
  a.getFlag = (s, k) => a.flags?.[s]?.[k];
  a.setFlag = async (s, k, v) => { (a.flags[s] ??= {})[k] = JSON.parse(JSON.stringify(v)); };
  a.unsetFlag = async (s, k) => { delete a.flags?.[s]?.[k]; };
  a.update = async (u) => { for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, docs) => { const made = docs.map((d) => { const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a }; e.getFlag = (s, k) => e.flags?.[s]?.[k]; return e; }); a.effects.push(...made); return made; };
  a.deleteEmbeddedDocuments = async (type, ids) => { a.effects = a.effects.filter((e) => !ids.includes(e.id)); };
  a.testUserPermission = () => owner;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  return a;
}
function makeToken(actor, x = 0, y = 0) {
  const t = { id: `t-${actor.name}`, actor, document: { x, y, width: 1, height: 1 } };
  Object.defineProperty(t, "center", { get: () => ({ x: t.document.x + 50, y: t.document.y + 50 }) });
  actor.token = t;
  canvas.tokens.placeables.push(t);
  return t;
}
const reset = () => { for (const l of [formulas, cards, warns, damaged, tags, recurring, saves, lightRefreshed]) l.length = 0; rolls = []; dialogPick = null; game.combat = null; canvas.tokens.placeables = []; };

const C = await import(new URL("./content/block9a.mjs", import.meta.url));
const R = await import(new URL("../module/block9a-rules.mjs", import.meta.url));
const A = await quiet(() => import(new URL("../module/block9a-automations.mjs", import.meta.url)));
const D5 = await import(new URL("./content/block5-d.mjs", import.meta.url));
const { PACKS } = await import(new URL("./content/packs.mjs", import.meta.url));
const api = await import(sys("module", "module-api.mjs"));
const ci = await import(sys("module", "magic", "cast-items.mjs"));
const mm = await import(sys("module", "magic", "module-metamagic.mjs")).catch(() => null);
const iq = await import(sys("module", "item-quality.mjs"));
const rd = await import(sys("module", "rune-damage.mjs"));
const rdecl = await import(sys("module", "rune-declarations.mjs"));

const byName = Object.fromEntries(C.CATALYST_ITEMS.map((d) => [d.name, d]));
const catalyst = (actor, name, qty = 1) => { const it = makeItem(actor, { ...byName[name], system: { ...byName[name].system, quantity: qty } }); actor.items.push(it); return it; };

/* ================================================================== A */
{
  const rows = book.sections.catalysts.rows.filter((r) => r.cells[0] && !["CATALYSTS", "Catalyst"].includes(r.cells[0]));
  equal("A 24 catalysts, in the table's order", C.CATALYST_ITEMS.map((d) => d.name), rows.map((r) => r.cells[0]));
  equal("A every one a consumable, quantity 1, one use", C.CATALYST_ITEMS.every((d) => d.type === "consumable" && d.system.quantity === 1 && d.system.uses.max === 1), true);
  equal("A prices and levels as the table prints them", C.CATALYST_ITEMS.map((d) => [d.system.price, d.system.itemLevel]), rows.map((r) => [Number(r.cells[1].replace(/[^\d.]/g, "")), Number(r.cells[2])]));
  const rarity = (n) => book.sections.catalystEntries.find((e) => e.name === n.toUpperCase()).traits[0];
  equal("A the rarity is a trait (Uncommon, Rare; Spell Incense is Common)", C.CATALYST_ITEMS.map((d) => d.system.traits), C.CATALYST_ITEMS.map((d) => ["Consumable", { COMMON: "", UNCOMMON: "Uncommon", RARE: "Rare" }[rarity(d.name)]].filter(Boolean).join(" ")));
  for (const d of C.CATALYST_ITEMS) {
    const e = book.sections.catalystEntries.find((x) => x.name === d.name.toUpperCase());
    const desc = d.system.description;
    ok(`A ${d.name}: the printed Effect, Backlash and flavour`, desc.includes(e.fields.Effect.replace(/</g, "&lt;")) && desc.includes(e.fields.Backlash.split(" ").slice(0, 4).join(" ")) && desc.includes(e.lines[0].slice(0, 40)));
    ok(`A ${d.name}: the table row and the automation note`, /<em>Table:<\/em>/.test(desc) && /<em>Automated \(0\.13\.1, TRG Prime 3\.688\.1\)( — in part)?:<\/em>/.test(desc));
    equal(`A ${d.name}: its module flag is its rules key`, d.flags[MOD].catalyst, R.catalystKey(d.name));
  }
  equal("A the grades (A · B · C)", ["A", "B", "C"].map((g) => Object.values(C.CATALYST_NOTES).filter((n) => n.grade === g).length), [21, 2, 1]);
  equal("A only Eclipse Resin is in part", C.CATALYST_ITEMS.filter((d) => /in part/.test(d.system.description)).map((d) => d.name), ["Eclipse Resin"]);
  ok("A Vellum's card names the ritual's primary and not the cast prompt", /Offered to a ritual's primary, before the ritual check/.test(byName["Blood-etched Vellum"].system.description) && !/TRG Prime asks which catalyst/.test(byName["Blood-etched Vellum"].system.description));
  ok("A Dragonbone's card gives the ruling (M10) and its Fumble-only backlash", /M10/.test(byName["Dragonbone Dust"].system.description) && /Fumble or Blunder only/.test(byName["Dragonbone Dust"].system.description));
  equal("A ids are stable and unique", new Set(C.CATALYST_ITEMS.map((d) => d._id)).size, 24);
  const pack = PACKS.find((p) => p.name === "ea-consumables");
  equal("A the pack: ea-consumables, extending the core's consumables, the 24", [pack?.label, pack?.extends, pack?.docs.length], ["Eldritch Arts: Consumables", "consumables", 24]);
  const manifest = JSON.parse(read("module.json"));
  const mp = manifest.packs.find((p) => p.name === "ea-consumables");
  equal("A module.json ships it, in the folder", [mp?.path, mp?.type, mp?.flags?.[SYS]?.extends, manifest.packFolders[0].packs.includes("ea-consumables")], ["packs/ea-consumables", "Item", "consumables", true]);
  // The feats.
  const feat = (n) => D5.FEATS_B5_D.find((f) => f.name === n);
  for (const n of ["Catalyst Affinity", "Catalyst Conservation", "Catalyst Mastery"]) ok(`A ${n}: automated in 0.13.0, grade A`, /Automated \(0\.13\.0, TRG Prime 3\.688\.0\)/.test(feat(n).system.description) && D5.AUTOMATION_B5_D[n].level === "A");
  ok("A Catalyst Crafting: a card that says why, grade D", /Not automated:/.test(feat("Catalyst Crafting").system.description) && /fixed list of item types/.test(feat("Catalyst Crafting").system.description) && D5.AUTOMATION_B5_D["Catalyst Crafting"].level === "D");
  ok("A Affinity's card gives Q191's reading", /Q191/.test(feat("Catalyst Affinity").system.description) && /Stunned 3 becomes Stunned 2/.test(feat("Catalyst Affinity").system.description));
}

/* ================================================================== B */
{
  api.resetModuleRegistry?.();
  const facts = { castPP: 4, totalPP: 4, damage: { formula: "2d8", type: "fire" }, defence: "reflex", attack: true, tradition: "arcane", traditions: ["arcane"], traits: ["Fire", "Essence", "Illusion", "Healing"], inCombat: true, rangeScales: true, durationScales: false, spellData: { range: "60 feet" }, choice: "range" };
  for (const [key, spec] of Object.entries(R.CATALYSTS)) {
    if (spec.ritualOnly) continue;
    const raw = spec.answer(facts);
    const clean = ci.cleanCastItemAnswer(raw);
    const kept = Object.keys(raw).filter((k) => k !== "lines" && k !== "note");
    ok(`B ${spec.name}: its answer survives the core's cleaning (${kept.join(", ") || "lines only"})`, kept.every((k) => clean[k] !== undefined && JSON.stringify(clean[k]) !== "{}" && JSON.stringify(clean[k]) !== "[]"), JSON.stringify({ raw, clean }));
  }
  equal("B Leydust and Spell Incense: a check modifier, typed item", [ci.cleanCastItemAnswer(R.CATALYSTS.leydust.answer({})).checkModifiers, ci.cleanCastItemAnswer(R.CATALYSTS.spellIncense.answer({})).checkModifiers], [[{ label: "Leydust", value: 2, type: "item" }], [{ label: "Spell Incense", value: 1, type: "item" }]]);
  equal("B the Shard: 1 PP off, at least 1 (payment only, Q93/Q189)", ci.cleanCastItemAnswer(R.CATALYSTS.resonantCrystalShard.answer({ castPP: 3 })).discount?.pp, 1);
  equal("B the Bead: +2 to the attack", ci.cleanCastItemAnswer(R.CATALYSTS.chainedObsidianBead.answer({})).attack, 2);

  // THE MATERIALS, through the real core.
  for (const key of Object.keys(R.MATERIALS_9A)) ok(`B ${key}: registered`, api.registerMaterial(key, R.materialRegistration(key), MOD) === true);
  equal("B the ten join the picker where the book says (weapons: not Eversmoke Cloth)",
    [iq.applicableMaterials("weapon").filter((m) => R.MATERIALS_9A[m.key]).map((m) => m.key).length, iq.applicableMaterials("armour").filter((m) => R.MATERIALS_9A[m.key]).length, iq.applicableMaterials("weapon").some((m) => m.key === "eversmokeCloth")], [9, 10, false]);
  equal("B their level deltas", Object.keys(R.MATERIALS_9A).map((k) => iq.computeEffectiveLevel(1, "standard", k) - 1), [2, 2, 2, 3, 2, 4, 4, 3, 3, 5]);
  const ash = iq.computeArmourModifiers("standard", "ashbone", []);
  equal("B Ashbone armour (Q193): ACP −1, Max Dex +1, Speed penalty −5, half the weight", [ash.acpDelta, ash.maxDexBonus, ash.speedPenaltyDelta, ash.weightPercent], [1, 1, 5, -50]);
  equal("B Ashbone and Graveiron overcome as silver", [iq.materialDefenceWord("ashbone"), iq.materialDefenceWord("graveiron")], ["silver", "silver"]);
  equal("B Bloodglass and Bloodwood weapons: Serrated, Keen", [iq.computeWeaponModifiers("standard", "bloodglass", []).grantedTraits, iq.computeWeaponModifiers("standard", "bloodwood", []).grantedTraits], [["Serrated"], ["Keen"]]);
  const mail = (material) => ({ type: "armour", name: "Mail", system: { material, equipped: true, runes: "", category: "medium" } });
  const blade = (material, damage = "1d8") => ({ type: "weapon", name: "Blade", system: { material, equipped: true, damage, runes: "" } });
  const shield = (material) => ({ type: "shield", name: "Shield", system: { material, equipped: true, runes: "" } });
  const conds = (item) => rdecl.runeDeclaredBonuses(item, [item]).conditionals.map((c) => [c.value, c.auto, c.when?.traits ?? c.when?.subjects ?? null]);
  equal("B Bloodglass armour: +1 item vs essence (by itself); a Bloodglass weapon: none", [conds(mail("bloodglass")), conds(blade("bloodglass"))], [[[1, true, ["essence"]]], []]);
  equal("B Graveiron armour: +1 to Fortitude saves, a tick (disease, paralysis, soul drain are not traits)", conds(mail("graveiron")), [[1, false, ["fortitude"]]]);
  equal("B Sunbronze armour: +1 Will vs Fear and Enchantment (charm, Graham's ruling), by itself", conds(mail("sunbronze")), [[1, true, ["fear", "enchantment"]]]);
  equal("B Starion and Veilglass: armour and shields both", [conds(mail("starion")).length, conds(shield("starion")).length, conds(mail("veilglass"))[0]?.[0], conds(shield("veilglass"))[0]?.[0], conds(blade("veilglass")).length], [1, 1, 2, 2, 0]);
  equal("B Veilglass (Q194): Teleportation or Translocation by itself, planar or possession a tick", conds(mail("veilglass")), [[2, true, ["teleportation", "translocation"]], [2, false, null]]);
  equal("B Starion armour and shields 20% lighter (the shield's weight reads weightPercent)", [iq.computeArmourModifiers("standard", "starion", []).weightPercent, iq.computeShieldModifiers("standard", "starion", []).weightPercent], [-20, -20]);
  ok("B what is left to the table is the sheet's note (H20 `note`)", ["bloodglass", "nightsteel", "sunbronze", "veilglass", "eversmokeCloth"].every((k) => /\S/.test(api.registeredMaterial(k)?.note ?? "")) && api.registeredMaterial("tairneach").note === undefined);
  equal("B Tairneach armour: saves; a Tairneach weapon: the critical's electricity", [conds(mail("tairneach")), rdecl.activeDeclaredRunesOn(blade("tairneach"), []).map((e) => e.declares.strikeRider?.damageType)], [[[1, true, ["electricity", "sonic"]]], ["electricity"]]);
  equal("B Nightsteel and Eversmoke armour: the Stealth tick (Eversmoke's Hide advantage is the cloaks' and robes', not the armour's)", [conds(mail("nightsteel"))[0]?.[1], conds(mail("eversmokeCloth")).length], [false, 1]);
  equal("B Bloodwood: a focus tick on the weapon (stave, bow), none on armour", [conds(blade("bloodwood")).length, conds(mail("bloodwood")).length], [1, 0]);
  const undead = { details: { creatureType: "undead" } };
  const ghost = { details: { traits: "Incorporeal" } };
  const dice = (m, t, dmg) => rd.runeDamageFor(blade(m, dmg), { target: t }).filter((r) => r.applies).map((r) => r.dice);
  equal("B against undead: Graveiron +1, Sunbronze a die of the weapon's own", [dice("graveiron", undead), dice("sunbronze", undead, "1d10")], [["1"], ["1d10"]]);
  equal("B Veilglass against the incorporeal; Starion against the eternal", [dice("veilglass", ghost), dice("starion", { details: { traits: "Eternal" } }, "1d6")], [["1d8"], ["1d6"]]);
  equal("B Nightsteel: the core's extra die", iq.computeWeaponModifiers("standard", "nightsteel", []).extraDice, 1);
  equal("B Veilglass doubles HP, Nightsteel and Starion +50%", ["veilglass", "nightsteel", "starion"].map((k) => [R.MATERIALS_9A[k].hpMultiplier ?? null, R.MATERIALS_9A[k].hpPercent ?? null]), [[2, null], [null, 50], [null, 50]]);
  equal("B no module key leaks to the core (card, shatter, shieldLight)", Object.keys(R.MATERIALS_9A).filter((k) => ["card", "shatter", "shieldLight"].some((x) => x in R.materialRegistration(k))), []);
}

/* ================================================================== C */
{
  const cat = R.CATALYSTS;
  equal("C backlash: Failure, Fumble, Blunder; not Success", ["success", "partial", "failure", "fumble", "blunder"].map((d) => R.backlashDue(cat.leydust, d)), [false, false, true, true, true]);
  equal("C Mastery waives a Failure only", ["failure", "fumble", "blunder"].map((d) => R.backlashDue(cat.leydust, d, { mastery: true })), [false, true, true]);
  equal("C Dragonbone: a Fumble or Blunder only (M10)", ["failure", "fumble", "blunder"].map((d) => R.backlashDue(cat.dragonboneDust, d)), [false, true, true]);
  equal("C Affinity: damage −2 × level (to 0), rounds −1 (to 1), Stunned 3 → 2", [R.affinityDamage(13, 5), R.affinityDamage(4, 5), R.affinityRounds(3), R.affinityRounds(1), R.affinityCondition({ key: "stunned", value: 3 }).value], [3, 0, 2, 1, 2]);
  equal("C Conservation: 15 or better keeps; never on a Fumble or Blunder", [R.conservationKeeps(15, "failure"), R.conservationKeeps(14, "success"), R.conservationKeeps(20, "fumble"), R.conservationKeeps(20, "blunder")], [true, false, false, false]);
  equal("C Vellum's bleeding: the PP, at most 10 (Q202)", [R.vellumBleeding(4), R.vellumBleeding(14)], [4, 10]);
  equal("C Bloodglass's shatter: 1d6 per 2 item levels", [R.shatterDice(1), R.shatterDice(5), R.shatterDice(8)], ["", "2d6", "4d6"]);
  equal("C per 2 PP rounds down", [R.perTwo({ castPP: 1 }), R.perTwo({ castPP: 5 })], [0, 2]);
  equal("C destroyed (not broken) at a negative HP of half its maximum, rounded up", [R.itemDestroyed(0, 20), R.itemDestroyed(-9, 20), R.itemDestroyed(-10, 20), R.itemDestroyed(-3, 5), R.itemDestroyed(-2, 5), R.itemDestroyed(-50, 0)], [false, false, true, true, false, false]);
  equal("C a warp's type change: Frozen Marrow and Void Ash are not offered (their change would not stand)", [cat.frozenMarrowShard.applies({ damage: { formula: "2d6", type: "fire" }, spellData: { damage: { type: "acid" } } }), cat.voidAsh.applies({ damage: { formula: "2d6", type: "acid" }, spellData: { damage: { type: "acid" } } })], [false, true]);
  equal("C Ashen Lotus with no damage type: fire for a Fire spell, else essence", [cat.ashenLotusBloom.answer({ traits: ["Fire"], damage: {} }).ignoreResistance, cat.ashenLotusBloom.answer({ traits: ["Essence"], damage: {} }).ignoreResistance], [["fire"], ["essence"]]);
  const ctx = (o) => ({ castPP: 4, damage: { formula: "2d6", type: "fire" }, traits: [], tradition: "", ...o });
  equal("C the offers' predicates",
    [cat.arcanitePowder.applies(ctx({ tradition: "arcane" })), cat.arcanitePowder.applies(ctx({ tradition: "divinity" })),
      cat.ashenLotusBloom.applies(ctx({ traits: ["Fire"] })), cat.ashenLotusBloom.applies(ctx({ traits: ["Cold"] })),
      cat.phoenixFeatherAsh.applies(ctx({ traits: ["Healing"] })), cat.moonveilDust.applies(ctx({ traits: ["Shadow"], defence: "will" })),
      cat.moonveilDust.applies(ctx({ traits: ["Shadow"] })), cat.resonantCrystalShard.applies(ctx({ castPP: 1 })),
      cat.chainedObsidianBead.applies(ctx({ attack: false })), cat.sandsOfTheHourglass.applies(ctx({ inCombat: false })), cat.cindersOfTheFirstFlame.applies(ctx({ damage: { formula: "" } }))],
    [true, false, true, false, true, true, false, false, false, false, false]);
  equal("C the dice: Cinders step, Dragonbone a die of the spell's, Glimmercoal 1d6 per 2 PP",
    [cat.cindersOfTheFirstFlame.answer(ctx()).dieStep, cat.dragonboneDust.answer(ctx()).mods.damageDice, cat.glimmercoal.answer(ctx()).addedDamage[0].dice], [1, "1d6", "2d6"]);
  equal("C the Vellum fits a ritual and nothing else", [cat.bloodEtchedVellum.applies({ ritual: true }), cat.bloodEtchedVellum.applies({})], [true, false]);
  equal("C Starpetal: range or duration ×1.5, as chosen", [cat.starpetalOil.answer({ choice: "range" }).rangeFactor, cat.starpetalOil.answer({ choice: "duration" }).durationFactor], [1.5, 1.5]);
}

/* ================================================================== D */
{
  const regs = [];
  const fakeApi = new Proxy({}, { get: (t, k) => (...args) => { regs.push([k, ...args]); return true; } });
  A.registerBlock9a(fakeApi, MOD);
  equal("D the cast item: catalyst, with offers, apply and settle", regs.filter((r) => r[0] === "registerCastItemOption").map((r) => [r[1], r[2].label, typeof r[2].offers, typeof r[2].apply, typeof r[2].settle, r[3]]), [["catalyst", "Catalyst", "function", "function", "function", MOD]]);
  equal("D no ritual rules of its own: the Vellum is a cast item, asked of a ritual's primary (TRG Prime 3.688.1)", regs.filter((r) => r[0] === "registerRitualRules").length, 0);
  equal("D the ten materials", regs.filter((r) => r[0] === "registerMaterial").map((r) => r[1]), Object.keys(R.MATERIALS_9A));
  equal("D Sunbronze's light: +1 step to Dim Light, 10 feet, magical, drawn dim only (found live)", regs.filter((r) => r[0] === "registerLightSources").map((r) => r[1].map((l) => [l.key, l.steps, l.cap, l.radiusFeet, l.magical, l.dimFeet, l.brightFeet])), [[["sunbronzeShield", 1, 5, 10, true, 10, 0]]]);
  api.resetModuleRegistry?.();
  ok("D the real core accepts every registration", (() => { let all = true; const real = { registerCastItemOption: api.registerCastItemOption, registerRitualRules: api.registerRitualRules, registerMaterial: api.registerMaterial, registerLightSources: (e, m) => api.registerLightSources(e, m, []) > 0 }; const wrap = new Proxy(real, { get: (t, k) => (...a) => { const r = t[k](...a); if (r === false) all = false; return r; } }); A.registerBlock9a(wrap, MOD); return all; })());
}

/* ================================================================== E */
{
  reset();
  const mage = makeActor("Mage", { level: 5 });
  catalyst(mage, "Leydust", 2);
  catalyst(mage, "Arcanite Powder");
  catalyst(mage, "Blood-etched Vellum");
  catalyst(mage, "Starpetal Oil");
  mage.items.push(makeItem(mage, { type: "consumable", name: "Potion", system: { quantity: 1 } }));
  const base = { actor: mage, castPP: 4, totalPP: 4, damage: { formula: "2d6", type: "fire" }, tradition: "divinity", traditions: ["divinity"], traits: [], spellData: { range: "30 feet", duration: "1 minute" } };
  let offers = await A.catalystOffers(base);
  equal("E offers: only the catalysts that fit (Leydust; Starpetal, range and duration both timed); never the Vellum; a hint each", offers.map((o) => [o.label, Boolean(o.hint)]), [["Leydust", true], ["Starpetal Oil", true]]);
  offers = await A.catalystOffers({ ...base, tradition: "arcane", traditions: ["arcane"] });
  ok("E an Arcane spell: Arcanite Powder too", offers.some((o) => o.label === "Arcanite Powder"));
  // Starpetal: asked when both scale; taken when one does; cancelled when the prompt is closed.
  const star = mage.items.find((i) => i.name === "Starpetal Oil");
  dialogPick = "duration";
  equal("E Starpetal: asked, duration", (await A.catalystApply({ ...base, item: star })).durationFactor, 1.5);
  dialogPick = null;
  equal("E Starpetal: the prompt closed cancels", (await A.catalystApply({ ...base, item: star })).cancel, true);
  equal("E Starpetal: range alone needs no prompt", (await A.catalystApply({ ...base, item: star, spellData: { range: "30 feet", duration: "instantaneous" } })).rangeFactor, 1.5);
  equal("E apply: a non-catalyst cancels", (await A.catalystApply({ ...base, item: mage.items.find((i) => i.name === "Potion") })).cancel, true);

  // THE SETTLE: Leydust, a Failure: 2 × 1d6 force (4 PP), Affinity off.
  const ley = mage.items.find((i) => i.name === "Leydust");
  rolls = [7];
  let out = await A.catalystSettle({ ...base, item: ley, degree: "failure", cast: false });
  equal("E Leydust on a Failure: 2d6 force to the caster (per 2 PP)", [damaged.map((d) => [d.target, d.amount, d.type]), formulas], [[["Mage", 7, "force"]], ["2d6"]]);
  equal("E …and it is not kept, and no flat check is rolled (no Conservation)", [out.keep, out.lines.some((l) => /Conservation/.test(l))], [false, false]);
  reset();
  const spent = catalyst(mage, "Leydust", 0);
  ok("E a catalyst with none left is not offered", !(await A.catalystOffers(base)).some((o) => o.itemId === spent.id));
  mage.items.splice(mage.items.indexOf(spent), 1);
  reset();
  out = await A.catalystSettle({ ...base, item: ley, degree: "success", cast: true });
  equal("E on a Success: no backlash", [damaged.length, tags.length, out.keep], [0, 0, false]);

  // CATALYST AFFINITY: −2 × level from the damage, −1 round, Stunned 3 → 2.
  reset();
  const adept = makeActor("Adept", { level: 2, feats: ["Catalyst Affinity"] });
  const shard = catalyst(adept, "Resonant Crystal Shard");
  rolls = [11, 3]; // piercing 2d6 = 11, force 2d6 = 3
  await A.catalystSettle({ ...base, actor: adept, item: shard, degree: "failure" });
  equal("E Affinity: −4 (level 2) off the backlash, across its rows", damaged.map((d) => [d.amount, d.type]), [[7, "piercing"], [3, "force"]]);
  reset();
  const phial = catalyst(adept, "Stormglass Phial");
  await A.catalystSettle({ ...base, actor: adept, item: phial, degree: "fumble" });
  equal("E Affinity: Stunned 3 becomes Stunned 2", tags.map((t) => [t.key, t.value]), [["stunned", 2]]);
  reset();
  game.combat = { started: true, round: 3, combatants: [{ actor: adept }] };
  const sands = catalyst(adept, "Sands of the Hourglass");
  rolls = [3];
  out = await A.catalystSettle({ ...base, actor: adept, item: sands, degree: "failure", cast: true });
  equal("E Sands: +1 AP in combat; Slowed 1 for 1d4 − 1 rounds (Affinity), on the round clock (one further: Slowed bites at turn start)", [adept.system.resources.ap.value, tags.map((t) => [t.key, t.value, t.expiresRound])], [4, [["slowed", 1, 6]]]);
  ok("E …and the card says so", out.lines.some((l) => /3 − 1, Catalyst Affinity/.test(l)));
  reset();
  const cinders = catalyst(adept, "Cinders of the First Flame");
  rolls = [6];
  await A.catalystSettle({ ...base, actor: adept, item: cinders, degree: "failure" });
  equal("E Affinity on Cinders' recurring fire (HP damage, Q191): 6 − 4", recurring.map((r) => [r.amount, r.type]), [[2, "fire"]]);
  reset();
  game.combat = { started: true, round: 3, combatants: [{ actor: adept }] };
  const marrow = catalyst(adept, "Frozen Marrow Shard");
  rolls = [1];
  await A.catalystSettle({ ...base, actor: adept, item: marrow, degree: "failure" });
  equal("E Slowed 1 for 1 round runs a round further on the clock, so it costs its AP once (review)", tags.filter((t) => t.key === "slowed").map((t) => t.expiresRound), [5]);
  game.combat = null;
  reset();
  const ap0 = adept.system.resources.ap.value;
  await A.catalystSettle({ ...base, actor: adept, item: sands, degree: "success", cast: true });
  equal("E Sands out of combat: no AP", adept.system.resources.ap.value, ap0);

  // CATALYST MASTERY and CONSERVATION.
  reset();
  const master = makeActor("Master", { level: 5, feats: ["Catalyst Affinity", "Catalyst Mastery", "Catalyst Conservation"] });
  const soil = catalyst(master, "Grave Soil");
  rolls = [16];
  out = await A.catalystSettle({ ...base, actor: master, item: soil, degree: "failure" });
  equal("E Mastery: no backlash on a Failure; Conservation's 16 keeps it", [damaged.length + tags.length + master.effects.length, out.keep, out.lines.some((l) => /Catalyst Mastery/.test(l)), out.lines.some((l) => /DC 15 flat check — <strong>16<\/strong>/.test(l))], [0, true, true, true]);
  reset();
  rolls = [4, 20];
  out = await A.catalystSettle({ ...base, actor: master, item: soil, degree: "fumble" });
  equal("E a Fumble: backlash (Frightened 1 and −2 Spellcraft, one roll of 1d6 − 1); always consumed, no flat check rolled", [tags.map((t) => [t.key, t.value]), master.effects.map((e) => e.name), out.keep, out.lines.some((l) => /always consumes/.test(l)), rolls.length], [[["frightened", 1]], ["Grave Soil backlash: −2 to Spellcraft checks"], false, true, 1]);
  ok("E the two share the roll, and Affinity takes its round from both (4 − 1)", tags[0].expiresTime === 1000 + 6 * 3 && master.effects[0].flags[SYS].spellEffectEnd === 1000 + 6 * 3, JSON.stringify([tags[0], master.effects[0].flags]));

  // THE REST OF THE BACKLASH SHAPES.
  reset();
  const plain = makeActor("Plain", { level: 3 });
  const s = (n) => catalyst(plain, n);
  await A.catalystSettle({ ...base, actor: plain, item: s("Ashen Lotus Bloom"), degree: "failure" });
  await A.catalystSettle({ ...base, actor: plain, item: s("Celestial Dewdrop"), degree: "failure" });
  rolls = [3];
  await A.catalystSettle({ ...base, actor: plain, item: s("Cinders of the First Flame"), degree: "failure" });
  rolls = [5];
  await A.catalystSettle({ ...base, actor: plain, item: s("Void Ash"), degree: "failure" });
  equal("E Soul Drain 1 per PP; Blinded 1 minute; recurring fire; Void Ash 1d4 per 2 PP", [tags.filter((t) => t.key === "soulDrain").map((t) => t.value), tags.find((t) => t.key === "blinded")?.expiresTime, recurring.map((r) => [r.amount, r.type])], [[4, 5], 1060, [[3, "fire"]]]);
  reset();
  out = await A.catalystSettle({ ...base, actor: plain, item: s("Starpetal Oil"), degree: "failure" });
  ok("E Starpetal's misfire is a card for the GM (Q190)", out.lines.some((l) => /half strength/.test(l) && /Applied by the GM/.test(l)));
  reset();
  await A.catalystSettle({ ...base, actor: plain, item: s("Frozen Marrow Shard"), degree: "success", cast: true });
  const fizzle = makeActor("Fizzle");
  await A.catalystSettle({ ...base, actor: fizzle, item: s("Frozen Marrow Shard"), degree: "success", cast: false });
  equal("E …the Marrow's DR only once the spell is cast", fizzle.effects.length, 0);
  equal("E Frozen Marrow: +1 DR until the end of the next turn, once cast", plain.effects.map((e) => [e.name, e.changes[0].key, e.changes[0].value]), [["Frozen Marrow Shard: +1 DR", "system.combat.dr.other", "1"]]);
  reset();
  plain.effects = [];
  await A.catalystSettle({ ...base, actor: plain, item: s("Incense of Stillness"), degree: "blunder" });
  equal("E Incense: disadvantage on Spellcraft checks for 1 minute (an effect with its conditional)", plain.effects.map((e) => [e.flags[SYS].conditionals[0].kind, e.flags[SYS].conditionals[0].when.checkTypes, e.flags[SYS].spellEffectEnd]), [["disadvantage", ["spellcraft"], 1060]]);

  // BLOOD-ETCHED VELLUM, and the rest, in a ritual (TRG Prime 3.688.1 asks a ritual's primary; Graham's ruling on Q186).
  reset();
  const cult = makeActor("Cultist", { level: 4 });
  const vel = catalyst(cult, "Blood-etched Vellum", 3);
  catalyst(cult, "Leydust");
  const ritualCtx = { ...base, actor: cult, ritual: true, castPP: 7, totalPP: 7, attack: false };
  equal("E a ritual's primary is offered the Vellum and the catalysts that fit; a cast that is not a ritual, never the Vellum",
    [(await A.catalystOffers(ritualCtx)).map((o) => o.label), (await A.catalystOffers({ ...ritualCtx, ritual: false })).map((o) => o.label)], [["Blood-etched Vellum", "Leydust"], ["Leydust"]]);
  catalyst(cult, "Resonant Crystal Shard");
  catalyst(cult, "Starpetal Oil");
  const timed = { spellData: { range: "touch", duration: "1 hour" } };
  equal("E a ritual variant (its PP substituted) is not offered the Shard; one claiming Duration unaltered is not offered Starpetal's stretch (review)",
    [(await A.catalystOffers({ ...ritualCtx, ...timed })).map((o) => o.label).filter((l) => /Shard|Starpetal/.test(l)),
      (await A.catalystOffers({ ...ritualCtx, ...timed, variant: "sacrifice" })).map((o) => o.label).filter((l) => /Shard|Starpetal/.test(l)),
      (await A.catalystOffers({ ...ritualCtx, ...timed, durationUnaltered: true })).map((o) => o.label).filter((l) => /Shard|Starpetal/.test(l))],
    [["Resonant Crystal Shard", "Starpetal Oil"], ["Starpetal Oil"], ["Resonant Crystal Shard"]]);
  // A MUNDANE RITUAL'S TRADITION-SKILL CHECK (Graham, 15 November 2026: "Drop them"): a catalyst that names
  // a Spellcraft check is not offered; the Vellum and the rest still are. TRG Prime 3.692.0 passes `checkSkill`.
  equal("E a ritual checked by a tradition skill: Leydust and the Vellum (each names a Spellcraft check) dropped; a Spellcraft ritual keeps both",
    [(await A.catalystOffers({ ...ritualCtx, checkSkill: "occultism" })).map((o) => o.label).filter((l) => /Vellum|Leydust/.test(l)), (await A.catalystOffers({ ...ritualCtx, checkSkill: "" })).map((o) => o.label).filter((l) => /Vellum|Leydust/.test(l))],
    [[], ["Blood-etched Vellum", "Leydust"]]);
  ok("E …and an embedded one (a Catalyst-runed shield) is dropped there too: its filter asks the same",
    /if \(!spec \|\| \(spec\.ritualOnly && !ctx\.ritual\)\) return false;\n\s*if \(!R\.catalystFitsCheck\(key, facts\)\) return false;/.test(read("module", "block9a-automations.mjs")));
  equal("E the catalysts that name a Spellcraft check, and nothing else, are dropped there",
    [R.SPELLCRAFT_CHECK_CATALYSTS.slice().sort(), R.catalystFitsCheck("leydust", { checkSkill: "arcana" }), R.catalystFitsCheck("bloodEtchedVellum", { checkSkill: "arcana" }), R.catalystFitsCheck("starpetalOil", { checkSkill: "arcana" }), R.catalystFitsCheck("leydust", {})],
    [["arcanitePowder", "bloodEtchedVellum", "incenseOfStillness", "leydust", "sanctifiedMyrrh", "spellIncense", "verdantSap", "whisperglassShard"], false, false, true, true]);
  for (const n of ["Resonant Crystal Shard", "Starpetal Oil"]) cult.items.splice(cult.items.indexOf(cult.items.find((i) => i.name === n)), 1);
  equal("E the Vellum: +2 item to the ritual check", ci.cleanCastItemAnswer(await A.catalystApply({ ...ritualCtx, item: vel })).checkModifiers, [{ label: "Blood-etched Vellum", value: 2, type: "item" }]);
  let got = await A.catalystSettle({ ...ritualCtx, item: vel, degree: "failure", cast: false });
  equal("E its ritual fails: Bleeding 7 (the PP as cast)", [tags.map((t) => [t.key, t.value]), got.keep], [[["bleeding", 7]], false]);
  reset();
  got = await A.catalystSettle({ ...ritualCtx, item: vel, degree: "partial", cast: false });
  equal("E a Partial: no backlash", tags.length, 0);
  const adeptCult = makeActor("Adept Cultist", { level: 2, feats: ["Catalyst Affinity"] });
  const vel2 = catalyst(adeptCult, "Blood-etched Vellum");
  await A.catalystSettle({ ...ritualCtx, actor: adeptCult, item: vel2, degree: "fumble", castPP: 9 });
  equal("E Catalyst Affinity cuts the Bleeding (HP damage, Q191): 9 − 4", tags.map((t) => [t.target, t.key, t.value]), [["Adept Cultist", "bleeding", 5]]);

  // BLOODGLASS, DESTROYED.
  reset();
  const knight = makeActor("Knight");
  const foe = makeActor("Foe");
  const far = makeActor("Far");
  const near10 = makeActor("TenFeet");
  makeToken(knight, 0, 0); makeToken(foe, 100, 0); makeToken(far, 400, 0); makeToken(near10, 200, 0);
  const glass = makeItem(knight, { type: "armour", name: "Bloodglass Plate", system: { material: "bloodglass", itemLevel: 6, hp: { value: 0, max: 20 } } });
  glass.setFlag = async (sc, k, v) => { (glass.flags[sc] ??= {})[k] = v; };
  glass.unsetFlag = async (sc, k) => { delete glass.flags?.[sc]?.[k]; };
  knight.items.push(glass);
  await A.onItemChangedB9a(glass, { system: { hp: { value: 0 } } });
  equal("E at 0 HP it is broken, not destroyed: no shatter (review)", saves.length, 0);
  rolls = [11];
  glass.system.hp.value = -10;
  await A.onItemChangedB9a(glass, { system: { hp: { value: -10 } } });
  equal("E destroyed (−10 of 20): 3d6 piercing to every creature within 5 feet, basic Reflex at the item's Level DC", [saves.map((x) => [x.target, x.save, x.dc, x.amount, x.type]), formulas], [[["Knight", "reflex", 20, 11, "piercing"], ["Foe", "reflex", 20, 11, "piercing"]], ["3d6"]]);
  saves.length = 0;
  await A.onItemChangedB9a(glass, { system: { hp: { value: -12 } } });
  equal("E …once: a further hit does not shatter it again", saves.length, 0);
  await A.onItemChangedB9a(glass, { system: { hp: { value: 5 } } });
  await A.onItemChangedB9a(glass, { name: "x" });
  equal("E repaired, the mark goes (it may shatter again); not on another change", [saves.length, glass.flags[MOD]?.shattered9a], [0, undefined]);
  game.user.isGM = false;
  await A.onItemChangedB9a(glass, { system: { hp: { value: -10 } } });
  equal("E only the acting GM rolls it", saves.length, 0);
  game.user.isGM = true;

  // SUNBRONZE, HELD.
  reset();
  const paladin = makeActor("Paladin");
  const sb = makeItem(paladin, { type: "shield", name: "Sunbronze Shield", system: { material: "sunbronze", equipped: true, hp: { value: 10 } } });
  paladin.items.push(sb);
  await A.onItemAddedOrRemovedB9a(sb);
  equal("E a Sunbronze shield held: its light effect, the token's light refreshed", [paladin.effects.map((e) => e.flags[SYS].lightSource), lightRefreshed], [["sunbronzeShield"], ["Paladin"]]);
  await A.onItemChangedB9a(sb, { system: { equipped: true } });
  equal("E …once", paladin.effects.length, 1);
  sb.system.equipped = false;
  await A.onItemChangedB9a(sb, { system: { equipped: false } });
  equal("E unequipped: the light goes", paladin.effects.length, 0);
  sb.system.equipped = true;
  sb.system.material = "";
  await A.onItemChangedB9a(sb, { system: { material: "" } });
  equal("E a shield of another material: no light", paladin.effects.length, 0);
}

/* ================================================================== F */
{
  const reg = read("module", "registration.mjs");
  const entry = read("scripts", "eldritch-arts.mjs");
  ok("F registration calls registerBlock9a after 8b", /registerBlock8b\(api, moduleId\);[\s\S]*registerBlock9a\(api, moduleId\);/.test(reg) && /import \{ registerBlock9a \} from "\.\/block9a-automations\.mjs";/.test(reg));
  ok("F the entry script hooks the items and ready (the Vellum is a cast item: nothing on trgPrimeSpellSettled)", !/onSpellSettledB9a/.test(entry) && /Hooks\.on\("updateItem", \(item, change\) => \{ onItemChangedB9a\(item, change\)/.test(entry) && /Hooks\.on\("createItem", \(item\) => \{ onItemAddedOrRemovedB9a/.test(entry) && /Hooks\.on\("deleteItem", \(item\) => \{ onItemAddedOrRemovedB9a/.test(entry) && /Hooks\.once\("ready", \(\) => \{ onReadyB9a\(\)/.test(entry));
  const manifest = JSON.parse(read("module.json"));
  equal("F the manifest: 0.15.0 on TRG Prime 3.690.0; the script asks for 3.690.0", [manifest.version, manifest.relationships.systems[0].compatibility.minimum, /REQUIRED_SYSTEM = "3\.694\.0"/.test(entry), manifest.download.includes("v0.18.3")], ["0.18.3", "3.694.0", true, true]);
}

if (failures.length) { for (const f of failures) console.log(`  ✗ ${f}`); console.log(`verify-block9a: ${checks} checks, ${failures.length} failure(s).`); process.exit(1); }
console.log(`verify-block9a: ${checks} checks, 0 failure(s).`);
