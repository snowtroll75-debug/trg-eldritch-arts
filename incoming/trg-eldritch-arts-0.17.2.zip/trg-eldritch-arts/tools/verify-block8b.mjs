#!/usr/bin/env node
/**
 * verify-block8b — Eldritch Arts 0.12.0 (Block 8b, on TRG Prime 3.687.0): the
 * second half of Chapter 8's Grimoire, second part — the ten rituals and the
 * seven High Magic spells tied to Chapter 7 (docs/ELDRITCH_ARTS_BLOCK8_AUDIT.md
 * §3.2, §4.2 and §4.4; Graham, 8 November 2026, 17:22: "As recommended" —
 * Q170–Q182, H13–H16). Also 0.12.0's one-writer-per-GM-account change.
 *
 *   A  every spell against the book: name, PP, traits, tradition, uncommon,
 *      the printed text (its Cost a field now), the grade and its card, the key
 *   B  the data through the core's own readers: the warps, the PP lock (Q170),
 *      the storm row (H16), the ritual rules (H13, H14) in the REAL core's
 *      registry and its answers, the object targets, the areas left to the module
 *   C  the pure rules (module/block8b-rules.mjs)
 *   D  registration
 *   E  the Foundry side with fakes: the ten rituals by degree, their Cost and
 *      casters' damage, the memberships, the GM's buttons; Chaos Shield in
 *      Block 2's table roll; Leyline Anchor's discount and tap gate; Mimic
 *      Spell's reaction, imprint, PP below 0 and end; Soul Confluence's pool and
 *      backlash; Storm of Unmaking's fumble; Veilfracture; Alter Corpse; the writer
 *   F  the wiring
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block8b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;
const sent = [];

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }
const quiet = async (fn) => { const e = console.error, w = console.warn; console.error = () => {}; console.warn = () => {}; try { return await fn(); } finally { console.error = e; console.warn = w; } };
const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const SYS = "trg-prime", MOD = "trg-eldritch-arts";
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const readCore = (...p) => fs.readFileSync(path.join(SYSTEM_ROOT, ...p), "utf8");
const tick = () => new Promise((r) => setTimeout(r, 0));

/* ----------------------------------------------------------------- */
/* Fakes (before any import that reads them)                          */
/* ----------------------------------------------------------------- */
const cards = [], messages = [], warns = [], answers = [];
const calls = { checks: [], effects: [], conditions: [], ended: [], crits: [], saves: [], tables: [], arrivals: [] };
const degreeFor = new Map();
let teleportFails = false, nextClick = [], dialogPick = null;
const pending = [];
let gmSide = 0;
const flush = async () => { while (pending.length) { const job = pending.shift(); gmSide++; try { await job(); } finally { gmSide--; } } };
const guard = (doc, what = "update") => { if (doc && doc.isOwner === false && !gmSide) throw new Error(`User Player lacks permission to ${what} ${doc.uuid ?? doc.name}`); };
const uuidMap = new Map();
const hookList = new Map();
const fired = [];
let nextId = 0;

const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => (answers.length ? answers.shift() : null),
  rollCheck: async (cfg) => {
    const d = degreeFor.get(cfg.actor?.name) ?? "failure";
    const [key, margin] = Array.isArray(d) ? d : [d, d === "failure" ? -5 : 2];
    calls.checks.push({ actor: cfg.actor?.name, type: cfg.type, subject: cfg.subject, dc: cfg.dc, sourceUuid: cfg.sourceUuid ?? "", modifiers: cfg.modifiers });
    return { outcome: { degree: { key, label: key }, total: 10, margin } };
  },
  createEffectsOn: async (target, list) => { calls.effects.push({ target: target.name, list }); gmSide++; try { return await target.createEmbeddedDocuments("ActiveEffect", list); } finally { gmSide--; } },
  applyConditionTagsTo: async (target, tags, options = {}) => {
    calls.conditions.push({ target: target.name, tags, options });
    for (const t of tags) { const was = target.conditions.rawValues.get(t.key) ?? 0; const adds = ["injured", "bleeding", "fatigued", "soulDrain"].includes(t.key); target.conditions.rawValues.set(t.key, adds ? was + Number(t.value ?? 1) : Math.max(was, Number(t.value ?? 1))); }
  },
  endSpellOf: async (caster, castId) => {
    calls.ended.push({ caster: caster.name, castId });
    const entries = Array.from(caster.flags?.[SYS]?.activeSpells ?? []);
    if (!entries.some((e) => e.id === castId)) return null;
    caster.flags[SYS].activeSpells = entries.filter((e) => e.id !== castId);
    const gone = caster.effects.filter((e) => e.flags?.[SYS]?.castId === castId);
    caster.effects = caster.effects.filter((e) => !gone.includes(e));
    for (const e of gone) for (const fn of hookList.get("deleteActiveEffect") ?? []) await fn(e);
    return { id: castId };
  },
  rollCriticalInjury: async (attacker, o) => { calls.crits.push({ attacker: attacker?.name, target: o.targetActor?.name, severity: o.severity, type: o.damageType, ...(o.attackBonus !== undefined ? { attackBonus: o.attackBonus } : {}) }); },
  isDead: async (actor) => Number(actor?.conditions?.rawValues?.get?.("dying") ?? 0) > 5,
  markTurnTable: async (target, row, o) => { calls.tables.push({ target: target.name, row, margin: o.margin, dc: o.dc }); return { marked: true, rounds: 2, line: `${target.name} is insane` }; },
  basicSaveHit: async (o) => { calls.saves.push({ target: o.target?.name, save: o.save, dc: o.dc, formula: o.formula, type: o.type }); return { line: "<strong>Failure</strong>: 9 sonic", degree: "failure" }; },
  regionContains: async (region, p) => regionHas(region, p),
  teleportationFails: async () => teleportFails,
  teleportationArrives: async (caster, spell, moved) => { calls.arrivals.push({ caster: caster?.name, spell: spell?.name, moved: moved.map((m) => m.name) }); return ["Teleported — Spatial Awareness"]; },
  itemUsesMax: () => null, itemUsesRemaining: () => 0
};
// THE REAL CORE'S CONTROL REGISTER (H12), its hook captured.
const CRW = await import(sys("module", "magic", "control-register-workflow.mjs"));
Object.assign(helpers, {
  recordControlled: (...a) => CRW.recordControlled(...a), releaseControlled: (...a) => CRW.releaseControlled(...a),
  controlledOf: async (a) => CRW.controlledOf(a), controlledCreature: (e) => CRW.controlledCreature(e)
});

const rolls = [];
globalThis.Roll = class { constructor(f) { this.formula = String(f); } async evaluate() { this.total = rolls.length ? rolls.shift() : 1; return this; } };
globalThis.Hooks = { on(name, fn) { if (!hookList.has(name)) hookList.set(name, []); hookList.get(name).push(fn); return fn; }, off() {}, once(name, fn) { return Hooks.on(name, fn); }, call() { return true }, callAll(name, payload) { fired.push({ name, payload }); } };
globalThis.foundry = {
  applications: { api: { DialogV2: { wait: async (cfg) => (typeof dialogPick === "function" ? dialogPick(cfg) : dialogPick), confirm: async () => true, prompt: async () => null } }, ux: {} },
  utils: { getProperty: (o, p) => p.split(".").reduce((a, k) => a?.[k], o), setProperty: (o, p, v) => { const ks = p.split("."); let at = o; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); at[ks.at(-1)] = v; }, hasProperty: () => false, mergeObject: (a, b) => Object.assign(a ?? {}, b ?? {}), isNewerVersion: () => false, escapeHTML: (s) => String(s), randomID: () => `id${++nextId}`, deepClone: (x) => JSON.parse(JSON.stringify(x)), fromUuid: async (u) => uuidMap.get(u) ?? null }
};
globalThis.fromUuidSync = (u) => uuidMap.get(u) ?? null;
globalThis.fromUuid = async (u) => uuidMap.get(u) ?? null;
globalThis.ui = { notifications: { warn: (t) => { warns.push(t); }, info: () => ({ id: 1 }), error() {}, remove() {} } };
globalThis.CONST = { GRID_SNAPPING_MODES: { TOP_LEFT_CORNER: 1 }, REGION_VISIBILITY: { LAYER: 0, GAMEMASTER: 1, ALWAYS: 2 } };
const blocked = new Set();
globalThis.CONFIG = { statusEffects: [], specialStatusEffects: {}, Canvas: { polygonBackends: { sight: { testCollision: (a, b) => blocked.has(`${Math.round(b.x)},${Math.round(b.y)}`) } } } };
globalThis.window = { addEventListener() {}, removeEventListener() {} };
globalThis.ChatMessage = { getSpeaker: () => ({}), create: async (d) => { messages.push(d); return d; } };

function setFlagPath(obj, dotted, value) {
  const ks = dotted.split(".");
  if (ks.at(-1).startsWith("-=")) { let at = obj; for (const k of ks.slice(0, -1)) at = (at[k] ??= {}); delete at[ks.at(-1).slice(2)]; return; }
  globalThis.foundry.utils.setProperty(obj, dotted, value);
}
function makeEffect(d, a) {
  const e = { ...JSON.parse(JSON.stringify(d)), id: `e${++nextId}`, parent: a, disabled: false };
  e.flags = e.flags ?? {};
  e.getFlag = (s, k) => e.flags?.[s]?.[k];
  e.setFlag = async (s, k, v) => { guard(a); (e.flags[s] ??= {})[k] = JSON.parse(JSON.stringify(v)); };
  e.update = async (u) => { guard(a); for (const [k, v] of Object.entries(u)) setFlagPath(e, k, v); };
  e.delete = async () => { guard(a, "delete"); a.effects = a.effects.filter((x) => x !== e); for (const fn of hookList.get("deleteActiveEffect") ?? []) await fn(e); };
  return e;
}
function makeActor(name, { level = 5, cap = 10, pp = 30, hpMax = 24, str = 2, size = "medium", type = "", traits = "", owner = true } = {}) {
  const a = { name, id: `a-${name}`, uuid: `Actor.${name.replace(/\s/g, "")}`, isOwner: owner, effects: [], flags: { [SYS]: {}, [MOD]: {} }, documentName: "Actor", img: `${name}.png` };
  a.system = { identity: { level, size }, traits, resources: { pp: { value: pp }, hp: { value: hpMax, max: hpMax } }, attributes: { strength: { total: str } }, encumbrance: { max: 0 }, magic: { controlLevels: cap }, combat: { deathState: 5, saves: { will: { total: 2 } } } };
  a.items = type ? [{ type: "creature-type", name: type }] : [];
  a.conditions = { rawValues: new Map() };
  a.getConditionValue = (k) => a.conditions.rawValues.get(k) ?? 0;
  a.hasCondition = (k) => (a.conditions.rawValues.get(k) ?? 0) > 0;
  a.getFlag = (s, k) => a.flags?.[s]?.[k];
  a.setFlag = async (s, k, v) => { guard(a); (a.flags[s] ??= {})[k] = JSON.parse(JSON.stringify(v)); };
  a.unsetFlag = async (s, k) => { guard(a); delete a.flags?.[s]?.[k]; };
  a.update = async (u) => { guard(a); for (const [k, v] of Object.entries(u)) globalThis.foundry.utils.setProperty(a, k, v); };
  a.createEmbeddedDocuments = async (type, docs) => { guard(a, "create in"); const made = docs.map((d) => makeEffect(d, a)); a.effects.push(...made); return made; };
  a.deleteEmbeddedDocuments = async (type, ids) => {
    guard(a, "delete in");
    const gone = a.effects.filter((e) => ids.includes(e.id));
    a.effects = a.effects.filter((e) => !ids.includes(e.id));
    for (const e of gone) for (const fn of hookList.get("deleteActiveEffect") ?? []) await fn(e);
  };
  a.toggleStatusEffect = async (k, o = {}) => { if (o.active === false) a.conditions.rawValues.delete(k); else a.conditions.rawValues.set(k, Number(o.value ?? 1)); };
  a.testUserPermission = () => owner;
  a.getActiveTokens = () => (a.token ? [a.token] : []);
  uuidMap.set(a.uuid, a);
  return a;
}
const scene = { id: "s1", regions: [] };
function makeToken(actor, { x = 0, y = 0, disposition = 1, width = 1 } = {}) {
  const t = { id: `t-${actor.name}`, name: actor.name, actor };
  t.document = { actor, disposition, width, height: width, x, y, hidden: false, uuid: `Scene.s1.Token.t-${actor.name}`, parent: scene, _source: { x, y, width, height: width }, size: actor.system.identity.size, texture: { src: `${actor.name}.png` } };
  t.document.update = async (u, o) => { Object.assign(t.document, u); Object.assign(t.document._source, u); t.lastUpdateOptions = o; return t.document; };
  t.document.object = t;
  Object.defineProperty(t, "center", { get: () => ({ x: t.document.x + 50 * t.document.width, y: t.document.y + 50 * t.document.width }) });
  actor.token = t;
  uuidMap.set(t.document.uuid, t.document);
  canvas.tokens.placeables.push(t);
  return t;
}
/*
 * A MOVE AS FOUNDRY V14 HANDS IT TO updateToken (0.11.2; logged live on
 * 14.367): the document's getters (x, y, regions) and the placeable still hold
 * the OLD position; its `_source` and `change` carry the new. The hook runs on
 * that; the getters catch up only afterwards (unless the hook itself moved the
 * token — the rift's own teleport).
 */
async function moveV14(doc, change, options = {}) {
  const from = { x: doc.x, y: doc.y };
  doc._source = { ...(doc._source ?? { x: doc.x ?? 0, y: doc.y ?? 0, width: doc.width ?? 1, height: doc.height ?? 1 }), ...change };
  const out = await A.onTokenMovedB8b(doc, change, options);
  if (doc.x === from.x && doc.y === from.y) Object.assign(doc, change);
  return out;
}
function regionHas(region, p) {
  for (const s of region?.shapes ?? []) {
    if (s.type === "rectangle" && p.x >= s.x && p.x < s.x + s.width && p.y >= s.y && p.y < s.y + s.height) return true;
    if (s.type === "ellipse" && Math.hypot(p.x - s.x, p.y - s.y) <= s.radiusX) return true;
  }
  return false;
}
scene.createEmbeddedDocuments = async (type, docs) => docs.map((d) => {
  const r = { ...JSON.parse(JSON.stringify(d)), id: `r${++nextId}`, parent: scene };
  r.uuid = `Scene.s1.Region.${r.id}`;
  r.update = async (u) => { for (const [k, v] of Object.entries(u)) setFlagPath(r, k, v); };
  r.delete = async () => { scene.regions = scene.regions.filter((x) => x !== r); uuidMap.delete(r.uuid); };
  r.setFlag = async (s, k, v) => { (r.flags[s] ??= {})[k] = v; };
  scene.regions.push(r);
  uuidMap.set(r.uuid, r);
  return r;
});
scene.deleteEmbeddedDocuments = async (type, ids) => { scene.regions = scene.regions.filter((r) => !ids.includes(r.id)); };
globalThis.canvas = {
  stage: { on(evt, fn) { const at = nextClick.shift(); queueMicrotask(() => fn({ data: { getLocalPosition: () => at } })); }, off() {} },
  tokens: { placeables: [], controlled: [] }, scene, dimensions: { distance: 5, size: 100 },
  grid: { size: 100, measurePath: ([a, b]) => ({ distance: Math.hypot(b.x - a.x, b.y - a.y) / 20 }) }
};
globalThis.game = {
  socket: { emit: (channel, data) => { sent.push(data); if (game.user.isGM) pending.push(async () => { await B7.onBlock7Socket(data); await A.onBlock8bSocket(data); }); }, on() {} },
  trgPrime: { modules: { helpers } }, user: { id: "gm", isGM: true, targets: new Set() }, combat: null, actors: [], packs: [],
  time: { worldTime: 1000 }, settings: { get: () => null }, system: { id: SYS, version: "3.687.0" }
};
game.users = Object.assign([game.user], { activeGM: game.user });
const reset = () => { cards.length = 0; messages.length = 0; warns.length = 0; answers.length = 0; for (const k of Object.keys(calls)) calls[k].length = 0; degreeFor.clear(); canvas.tokens.placeables = []; canvas.tokens.controlled = []; scene.regions = []; fired.length = 0; nextClick = []; dialogPick = null; teleportFails = false; blocked.clear(); game.time.worldTime = 1000; game.user.isGM = true; game.users.activeGM = game.user; };


// TOKEN DOCUMENTS CARRY THEIR ID, as Foundry's do.
{ const mk = makeToken; makeToken = (a, o) => { const t = mk(a, o); t.document.id = t.id; return t; }; }
// THE HELPERS 8b ADDS.
const purse = new Map();
const steps = new Map();
const lightCalls = [], stormCalls = [], healed = [], reduced = [], damaged = [], asks = [], reactionsSpent = [];
let askAnswer = "yes";
Object.assign(helpers, {
  levelDC: (l) => 10 + Number(l ?? 0),
  goldOf: async (a) => purse.get(a?.name) ?? 0,
  deductGold: async (a, gp) => { const have = purse.get(a?.name) ?? 0; if (have < gp) return { paid: false, shortfallGP: gp - have }; purse.set(a.name, have - gp); return { paid: true, shortfallGP: 0 }; },
  healActor: async (a, n) => { healed.push({ target: a.name, amount: n }); return n; },
  reduceCondition: async (a, key, by = 1) => { const from = a.getConditionValue(key); const to = Math.max(0, from - by); reduced.push({ target: a.name, key, from, to }); if (to) a.conditions.rawValues.set(key, to); else a.conditions.rawValues.delete(key); return { from, to, floor: 0 }; },
  placeLightCircles: async (a, spec) => { lightCalls.push(spec); const [r] = await scene.createEmbeddedDocuments("Region", [{ name: spec.name, shapes: [{ type: "circle", x: 700, y: 700, radius: 100 }], flags: {} }]); return [r.id]; },
  placeStorm: async (a, row, opts) => { stormCalls.push({ caster: a.name, row, opts }); return { regionId: "storm1", lines: ["the storm's 1d6 — 3"] }; },
  askReactor: async (reactor, q) => { asks.push({ reactor: reactor.name, title: q.title, step: q.step, data: q.data }); const fn = steps.get(q.step); return fn ? { result: await fn(reactor, typeof askAnswer === "function" ? askAnswer(q) : askAnswer, q.data) } : null; },
  spendReaction: async (a, label) => { reactionsSpent.push({ actor: a.name, label }); return true; },
  reactionRefusal: async () => "",
  applyTypedDamage: async (a, o) => { damaged.push({ target: a.name, amount: o.amount, type: o.type }); return { applied: o.amount }; },
  basicSaveHit: async (o) => { calls.saves.push({ target: o.target?.name, save: o.save, dc: o.dc, formula: o.formula, amount: o.amount, type: o.type }); return { line: "<strong>Failure</strong>", degree: "failure" }; }
});
canvas.scene.regions = scene.regions;
Object.defineProperty(canvas.scene, "tokens", { get: () => canvas.tokens.placeables.map((t) => t.document) });
scene.regions.get = function (id) { return this.find((r) => r.id === id) ?? null; };
game.scenes = [scene];
const reset8b = () => { reset(); scene.regions.get = function (id) { return this.find((r) => r.id === id) ?? null; }; canvas.scene.regions = scene.regions; purse.clear(); for (const l of [lightCalls, stormCalls, healed, reduced, damaged, asks, reactionsSpent, sent, rolls]) l.length = 0; askAnswer = "yes"; game.user.targets = new Set(); game.combat = null; };

const C = await import(new URL("./content/block8b-spells.mjs", import.meta.url));
const R = await import(new URL("../module/block8b-rules.mjs", import.meta.url));
const W = await import(new URL("../module/writer.mjs", import.meta.url));
const A = await quiet(() => import(new URL("../module/block8b-automations.mjs", import.meta.url)));
const B7 = await quiet(() => import(new URL("../module/block7-automations.mjs", import.meta.url)));
const B2 = await quiet(() => import(new URL("../module/block2-automations.mjs", import.meta.url)));
const T7 = await import(new URL("../module/chapter7-tables.mjs", import.meta.url));
const S = Object.fromEntries(C.SPELLS_B8B.map((s) => [s.name, s]));
for (const fn of [A.onEffectDeletedB8b]) Hooks.on("deleteActiveEffect", fn);
// A REGISTERED API, so the reaction steps can be asked.
const regs = [];
const fakeApi = new Proxy({}, { get: (t, k) => (...args) => { regs.push([k, ...args]); if (k === "registerReactionStep") steps.set(args[0], args[1]); return true; } });
A.registerBlock8b(fakeApi, MOD);
{
  const GC = await import(sys("module", "gm-connection.mjs")).catch(() => null);
  if (GC?.gmConnectionReady) await GC.gmConnectionReady();
}

/* A spell item, as a sheet holds it. */
const item = (name, extra = {}) => { const s = S[name]; const it = { ...JSON.parse(JSON.stringify(s)), id: `i-${s._id}`, uuid: `Compendium.${MOD}.ea-spells.Item.${s._id}`, ...extra }; it._stats = { compendiumSource: it.uuid }; it.getFlag = (sc, k) => it.flags?.[sc]?.[k]; uuidMap.set(it.uuid, it); return it; };
const entryFor = (actor, name, id = `cast-${name}`) => { actor.flags[SYS].activeSpells = [...(actor.flags[SYS].activeSpells ?? []), { id, name }]; return id; };
const settle = (actor, name, extra = {}) => A.onSpellSettledB8b({ actor, spell: item(name), spellData: S[name].system, degree: "success", cast: true, refunded: false, ritual: false, castPP: S[name].system.ppCost, ppSpent: S[name].system.ppCost, saveDC: 20, warpMods: {}, castOptions: [], metamagic: [], ...extra });
const ritual = async (actor, name, degree, extra = {}) => settle(actor, name, { ritual: true, degree, cast: !["failure", "fumble", "blunder"].includes(degree), ...extra });
const plan = (actor, name, { secondaries = [], participants = [], targetLevel = null } = {}) => { actor.flags[MOD][R.RITUAL_PLAN_FLAG] = { key: S[name].flags[SYS].eaGrimoire, spell: item(name).uuid, secondaries: secondaries.map((a) => a.uuid), participants: participants.map((a) => a.uuid), targetLevel, at: 1000 }; };
const lastCard = () => cards.at(-1);
const text = (c) => (c?.lines ?? []).join(" ");
const msgText = () => messages.map((m) => m.content).join(" ");

/* ----------------------------------------------------------------- */
/* A — the book                                                        */
/* ----------------------------------------------------------------- */
{
  const audit = read("docs", "ELDRITCH_ARTS_BLOCK8_AUDIT.md");
  const rows = [...audit.matchAll(/^\| \d+ \| ([^|]+) \| \d+ \| \d+ \| [^|]+ \| [^|]+ \| [A-D] \| [A-D] \| 8b \|$/gm)].map((m) => m[1].trim());
  equal("A the 17 are the audit's 8b, in the book's names", C.SPELLS_B8B.map((s) => s.name).sort(), rows.sort());
  equal("A …17 of them", [C.SPELLS_B8B.length, rows.length], [17, 17]);
  const auditGrade = Object.fromEntries([...audit.matchAll(/^\| \d+ \| ([^|]+) \| \d+ \| \d+ \| [^|]+ \| [^|]+ \| [A-D] \| ([A-D]) \| 8b \|$/gm)].map((m) => [m[1].trim(), m[2]]));
  const grim = new Map(book.grimoire.map((e) => [e.name, e]));
  for (const [i, name] of C.BLOCK8B_NAMES.entries()) {
    const s = C.SPELLS_B8B[i], b = grim.get(name);
    ok(`A ${s.name}: in the book`, Boolean(b));
    if (!b) continue;
    equal(`A ${s.name}: PP, type, uncommon`, [s.system.ppCost, s.type, s.system.availability], [b.pp, "spell", "uncommon"]);
    equal(`A ${s.name}: tradition as printed (High Magic prints none)`, s.system.tradition, String(b.fields.Tradition ?? "").trim().toLowerCase());
    ok(`A ${s.name}: traits as printed`, s.system.traits.split(", ").map((t) => t.toUpperCase()).join(" ") === b.traits.join(" "));
    ok(`A ${s.name}: the card prints the book's text`, b.lines.every((l) => s.system.description.replace(/<[^>]+>/g, "").includes(l.replace(/\*\*/g, "").replace(/\*/g, "").replace(/^- /, "").slice(0, 40))));
    if (b.fields.Cost) ok(`A ${s.name}: its Cost is on the card (a field from 0.12.0)`, s.system.description.includes(`<strong>Cost</strong> ${b.fields.Cost}`));
    const g = C.SPELL_AUTOMATION_B8B[s.name].grade;
    equal(`A ${s.name}: the audit's grade (${auditGrade[s.name]})`, g, auditGrade[s.name]);
    const opens = /<em>(Automated, with a choice|Automated|Partly automated|Not automated)/.exec(s.system.description)?.[1];
    equal(`A ${s.name}: its card opens with its grade (${g})`, opens, { A: "Automated", B: "Automated, with a choice", C: "Partly automated", D: "Not automated" }[g]);
    if (g === "C") ok(`A ${s.name}: the card names what is by hand`, /By hand:|by hand/.test(s.system.description));
    equal(`A ${s.name}: its key`, s.flags[SYS].eaGrimoire, C.SPELL_AUTOMATION_B8B[s.name].key);
  }
  equal("A grades (the audit's §9): rituals 6 B and 4 C; High Magic 1 A, 4 B, 1 C, 1 D", ["A", "B", "C", "D"].map((l) => Object.values(C.SPELL_AUTOMATION_B8B).filter((r) => r.grade === l).length), [1, 10, 5, 1]);
  equal("A the ten rituals carry the Ritual trait; the seven High Magic spells Highmagic", [C.SPELLS_B8B.filter((s) => /\bRitual\b/.test(s.system.traits)).map((s) => s.flags[SYS].eaGrimoire).sort(), C.SPELLS_B8B.filter((s) => /Highmagic/.test(s.system.traits)).length], [[...R.RITUAL_KEYS].sort(), 8]);
  equal("A every ritual is a utility spell with no core save and no core effect but a note (its rungs are the module's)", R.RITUAL_KEYS.map((k) => C.SPELLS_B8B.find((s) => s.flags[SYS].eaGrimoire === k)).map((s) => [s.system.category, s.system.defence, s.system.effects.map((e) => e.kind)]), R.RITUAL_KEYS.map(() => ["utility", "", ["note"]]));
  equal("A the objects: Alter Corpse and Leyline Anchor aim at no creature; Rite of Binding Oath and Soul Confluence take their creatures from the module (targetsObject: the core asks for none — found live)", C.SPELLS_B8B.filter((s) => s.flags[SYS].targetsObject).map((s) => s.name).sort(), ["Alter Corpse", "Leyline Anchor", "Rite of Binding Oath", "Soul Confluence"]);
  equal("A the areas the module draws print no template of the core's", ["Army of the Grave", "Call of the Ancestors", "Concord of Stone", "Elemental Convergence", "Eternal Invocation", "Rite of Echoed Shadows", "Sun’s Benediction", "Veil Severing", "Soul Confluence", "Veilfracture"].map((n) => S[n].system.area), Array(10).fill(""));
  equal("A Chaos Shield and Storm of Unmaking keep theirs (the core's emanation; the storm's template)", [S["Chaos Shield"].system.area, S["Storm of Unmaking"].system.area, S["Storm of Unmaking"].system.range], ["30-foot emanation", "60-foot radius", "200 feet"]);
  ok("A no card claims Automated for a C or D", Object.entries(C.SPELL_AUTOMATION_B8B).every(([n, r]) => !["C", "D"].includes(r.grade) || !/<em>Automated/.test(S[n].system.description)));
  equal("A keys are unique", new Set(C.SPELLS_B8B.map((s) => s.flags[SYS].eaGrimoire)).size, 17);
}

/* ----------------------------------------------------------------- */
/* B — the data, through the core's own readers                       */
/* ----------------------------------------------------------------- */
{
  const WP = await quiet(() => import(sys("module", "magic", "spell-warp.mjs")));
  const AS = await quiet(() => import(sys("module", "magic", "active-spells.mjs")));
  const unread = [];
  for (const s of C.SPELLS_B8B) for (const [i, w] of s.system.warps.entries()) for (const k of Object.keys(w.mods ?? {})) if (JSON.stringify(WP.aggregateWarpSelection([w], { "warp-0": 1 }).mods[k]) === JSON.stringify(WP.aggregateWarpSelection([], {}).mods[k])) unread.push(`${s.name} #${i} ${k}`);
  equal("B every warp mod key is read by the core's aggregator", unread, []);
  equal("B every printed warp is built, in order", C.SPELLS_B8B.map((s) => s.system.warps.length), C.BLOCK8B_NAMES.map((n) => book.grimoire.find((e) => e.name === n).lines.filter((l) => /^\*\*\+\d+ PP:?\*\*/.test(l)).length));
  const sun = WP.aggregateWarpSelection(S["Sun’s Benediction"].system.warps, { "warp-0": 2, "warp-1": 1, "warp-3": 1 }).mods;
  equal("B Sun's Benediction's warps reach the cast: the count, and which options", [sun.bonusValue, sun.unlocks], [2, [R.UNLOCK.sunInjured, R.UNLOCK.sunLong]]);
  const oath = WP.aggregateWarpSelection(S["Rite of Binding Oath"].system.warps, { "warp-0": 3, "warp-1": 2 }).mods;
  equal("B Rite of Binding Oath: three more creatures, +2d6", [oath.extraTargets, oath.damageDice], [3, "2d6"]);
  equal("B Q170: Eternal Invocation's \"permanent until dispelled\" locks; Army and Concord's permanent options lock; a month or a day does not",
    [AS.ppLockCondition(S["Eternal Invocation"].system.duration), AS.ppLockCondition(WP.aggregateWarpSelection(S["Army of the Grave"].system.warps, { "warp-1": 1 }).mods.durationText), AS.ppLockCondition(WP.aggregateWarpSelection(S["Concord of Stone"].system.warps, { "warp-1": 1 }).mods.durationText), AS.ppLockCondition(S["Concord of Stone"].system.duration), AS.ppLockCondition(S["Rite of Echoed Shadows"].system.duration)],
    ["unlimited", "unlimited", "unlimited", null, null]);
  const ST = await quiet(() => import(sys("module", "magic", "storm.mjs")));
  const storm = ST.normaliseStorm(S["Storm of Unmaking"].system.effects.find((e) => e.kind === "storm"));
  const table = book.grimoire.find((e) => e.name === "STORM OF UNMAKING").lines.filter((l) => /^\| \d /.test(l)).map((l) => l.split("|").map((c) => c.trim()).filter(Boolean));
  equal("B Storm of Unmaking, as the core's storm reads it (H16): rolled, at the turn start, the book's six in order", [storm?.pick, storm?.strikes, storm?.follow, storm?.modes.map((m) => [m.label, m.formula, m.save])], ["roll", "turnStart", false, table.map(([, t, d, sv]) => [t, d, sv.toLowerCase()])]);
  equal("B …every mode a basic save, its die 1d6", [storm?.modes.every((m) => m.basic), ST.stormDie(storm)], [true, "1d6"]);
  equal("B …no cast save of its own and no base damage (\"varies\"): the storm rolls them", [S["Storm of Unmaking"].system.category, S["Storm of Unmaking"].system.defence, S["Storm of Unmaking"].system.baseDamage], ["save", "", ""]);
  // THE RITUAL RULES IN THE REAL CORE'S REGISTRY (H13, H14).
  const API = await quiet(() => import(sys("module", "module-api.mjs")));
  const RR = await quiet(() => import(sys("module", "magic", "ritual-rules.mjs")));
  API.resetModuleRegistry();
  ok("B the core takes the ritual rules (partialCasts and minSecondaries are its 3.687.0 keys)", API.registerRitualRules(A.RULES_KEY_8B, { fields: A.ritualFields8b, prepare: A.prepareRitual8b, partialCasts: A.ritualPartialCasts8b, minSecondaries: A.ritualMinSecondaries8b }, MOD) === true);
  const ask = async (name) => [await RR.ritualPartialCasts({ spell: item(name) }), await RR.ritualAloneAllowed({ spell: item(name) })];
  equal("B H13: every one of the ten's Partials casts; H14: only Elemental Convergence, Essence Reforging and Eternal Invocation alone (Q172)",
    await Promise.all(["Army of the Grave", "Elemental Convergence", "Essence Reforging", "Eternal Invocation", "Sun’s Benediction", "Veil Severing"].map(ask)),
    [[true, false], [true, true], [true, true], [true, true], [true, false], [true, false]]);
  equal("B …and nothing for a spell that is not one of the ten (Storm of Unmaking, a core spell)", [await ask("Storm of Unmaking"), [await RR.ritualPartialCasts({ spell: { name: "Clone", flags: {} } }), await RR.ritualAloneAllowed({ spell: { name: "Clone", flags: {} } })]], [[false, false], [false, false]]);
  API.resetModuleRegistry();
  const CASTING = await quiet(() => import(sys("module", "magic", "casting.mjs")));
  equal("B the core casts such a Partial for no PP (H13)", CASTING.castingOutcome("partial", { basePP: 14, castsPartial: true }), { cast: true, ppSpent: 0, fumbleRoll: false, fumbleModifier: 0 });
  const RATE = await quiet(() => import(sys("module", "rest", "rest-rate.mjs")));
  equal("B Eternal Invocation's member effect reaches the core's rest rates (H15): doubled, halved", [RATE.restRatesOf([{ flags: { [SYS]: { restRate: { hp: 2, pp: 2 } } } }]).hp, RATE.restRatesOf([{ flags: { [SYS]: { restRate: { hp: 0.5, pp: 0.5 } } } }]).pp], [2, 0.5]);
  equal("B the core's aligned traits are this module's copy (aligned.mjs, creature-traits.mjs)", [readCore("module", "aligned.mjs").includes('export const ALIGNED_TRAITS = Object.freeze(["balance", "chaos", "evil", "good", "order"]);'), /good: "evil",\s*evil: "good",\s*chaos: "order",\s*order: "chaos"/.test(readCore("module", "creature-traits.mjs"))], [true, true]);
  equal("B the core's spans are this module's (a month 30 days, a year 365)", [readCore("module", "afflictions.mjs").includes("month: 2592000"), readCore("module", "afflictions.mjs").includes("year: 31536000"), R.SPAN.month, R.SPAN.year], [true, true, 2592000, 31536000]);
}

/* ----------------------------------------------------------------- */
/* C — the pure rules                                                  */
/* ----------------------------------------------------------------- */
{
  const D7 = ["heroic", "critical", "success", "partial", "failure", "fumble", "blunder"];
  equal("C m42's table, for a ritual printing all six (Sun's Benediction)", D7.map((d) => R.ritualRung(R.RITUALS.sunsBenediction, d)), ["critical", "critical", "success", "partial", "failure", "fumble", "blunder"]);
  equal("C …for one printing no Success and no Fumble (Concord: the base; M38)", D7.map((d) => R.ritualRung(R.RITUALS.concordOfStone, d)), ["critical", "critical", "success", "partial", "failure", "failure", "blunder"]);
  equal("C …no Partial (Elemental Convergence: the Failure, Q171)", D7.map((d) => R.ritualRung(R.RITUALS.elementalConvergence, d)), ["critical", "critical", "success", "failure", "failure", "fumble", "blunder"]);
  equal("C …a Heroic printed (Veil Severing)", D7.map((d) => R.ritualRung(R.RITUALS.veilSevering, d)), ["heroic", "critical", "success", "partial", "failure", "fumble", "blunder"]);
  equal("C …no ladder (M45: Essence Reforging keeps its Fumble and Blunder for the backlash)", D7.map((d) => R.ritualRung(R.RITUALS.essenceReforging, d)), ["works", "works", "works", "fails", "fails", "fumble", "blunder"]);
  equal("C m42: a Blunder where only a Fumble is printed reads as the Fumble (no ritual prints that, so a spec stands in)", [R.ritualRung({ printed: ["fumble"] }, "blunder"), R.ritualRung({ printed: [] }, "blunder")], ["fumble", "failure"]);
  equal("C the casters' damage, as printed", ["armyOfTheGrave", "callOfTheAncestors", "concordOfStone", "elementalConvergence", "riteOfBindingOath", "sunsBenediction", "veilSevering"].map((k) => ["failure", "fumble", "blunder"].map((r) => R.casterHit(R.RITUALS[k], R.ritualRung(R.RITUALS[k], r))?.formula)),
    [["2d10", "4d10", "8d10"], ["1d6", "2d6", "4d6"], ["2d6", "2d6", "8d6"], ["2d6", "4d6", "8d6"], ["2d6", "4d6", "8d6"], ["1d6", "2d6", "4d6"], ["4d6", "8d6", "12d6"]]);
  equal("C …whose: every caster, Concord's the primary (M38); its type and save", [R.casterHit(R.RITUALS.concordOfStone, "failure").who, R.casterHit(R.RITUALS.callOfTheAncestors, "failure").type, R.casterHit(R.RITUALS.elementalConvergence, "failure").save, R.casterHit(R.RITUALS.elementalConvergence, "failure").type, R.casterHit(R.RITUALS.sunsBenediction, "success")], ["primary", "mental", "reflex", "chosen", null]);
  equal("C the Costs (Q174): flat, per PP as cast, per target level, none in gold",
    [R.ritualCostGP(R.RITUALS.callOfTheAncestors), R.ritualCostGP(R.RITUALS.concordOfStone, { castPP: 12 }), R.ritualCostGP(R.RITUALS.essenceReforging, { targetLevel: 7 }), R.ritualCostGP(R.RITUALS.essenceReforging, {}), R.ritualCostGP(R.RITUALS.eternalInvocation), R.ritualCostGP(R.RITUALS.elementalConvergence), R.ritualCostGP(R.RITUALS.armyOfTheGrave, { castPP: 20 }), R.corpsesFor(21)],
    [200, 1200, 1400, null, 10000, null, null, 10]);
  equal("C Army of the Grave (Q175): one per corpse, levels to the PP, halved with the option, level 0 free",
    [R.armyFits({ levels: [4, 4, 4, 4, 4], castPP: 20 }).ok, R.armyFits({ levels: [5, 5, 5, 6], castPP: 20 }).ok, R.armyFits({ levels: [5, 5, 5, 6], castPP: 20, halfLevels: true }).total, R.armyFits({ levels: Array(11).fill(0), castPP: 20 }).ok, R.armyFits({ levels: Array(10).fill(0), castPP: 20 }).ok, R.armyFits({ levels: [], castPP: 20 }).ok],
    [true, false, 9, false, true, false]);
  equal("C …half rise on a Partial (rounded down); none on a failure; its durations", [R.armyControlled(7, "partial"), R.armyControlled(7, "success"), R.armyControlled(7, "failure"), R.armyDuration("critical", []), R.armyDuration("success", [R.UNLOCK.armyPermanent]), R.armyDuration("partial", [R.UNLOCK.armyPermanent]), R.armyDuration("failure", [R.UNLOCK.armyPermanent])], [3, 7, 0, "1 month", "permanent", "1 day", ""]);
  equal("C Call of the Ancestors: 3 questions, +1 a warp, at most 10", [R.ancestorQuestions(0), R.ancestorQuestions(2), R.ancestorQuestions(20)], [3, 5, 10]);
  equal("C Concord of Stone's shape by rung", [R.concordShape("critical", []), R.concordShape("success", [R.UNLOCK.concordDouble]), R.concordShape("partial", [R.UNLOCK.concordPermanent]), R.concordShape("success", [R.UNLOCK.concordPermanent]).duration],
    [{ radius: 120, dr: 10, duration: "6 months" }, { radius: 240, dr: 5, duration: "1 month" }, { radius: 120, dr: 2, duration: "1 week" }, "permanent"]);
  equal("C Elemental Convergence: 500 ft (1 mile), 1d6 (2d6 on a Critical)", [R.convergenceRadius([]), R.convergenceRadius([R.UNLOCK.convergenceMile]), R.convergenceDice("critical"), R.convergenceDice("success")], [500, 5280, "2d6", "1d6"]);
  equal("C Essence Reforging's backlash: 1d8 per target level", [R.reforgingBacklash(7), R.reforgingBacklash(0)], ["7d8", "1d8"]);
  equal("C Eternal Invocation (m107): shared, opposed, neither",
    [R.alignedRelation(["Good", "Order"], ["humanoid", "good"]), R.alignedRelation(["good"], ["evil"]), R.alignedRelation(["good"], ["chaos"]), R.alignedRelation(["balance"], ["evil"]), R.alignedRelation([], ["evil"]), R.alignedRelation(["order"], ["chaos", "order"])],
    ["shared", "opposed", "none", "none", "none", "opposed"]);
  equal("C Rite of Binding Oath's terms by rung", [R.oathTerms("critical", "1d6"), R.oathTerms("partial"), R.oathTerms("fumble").bound, R.oathMax(2)],
    [{ duration: "1 year", formula: "2d6 + 1d6", double: true, bound: "all" }, { duration: "1 month", formula: "2d6", double: false, bound: "half" }, "none", 12]);
  equal("C Rite of Echoed Shadows' shape by rung (the +4 PP option's week; a Partial's hour stands)", [R.echoShape("critical"), R.echoShape("partial", "1 week"), R.echoShape("success", "1 week"), R.echoEntityLevel(12)],
    [{ radius: 300, penalty: -4, duration: "1 day" }, { radius: 30, penalty: -2, duration: "1 hour" }, { radius: 60, penalty: -2, duration: "1 week" }, 16]);
  equal("C Sun's Benediction's terms",
    [R.sunTerms("critical", { bought: 1, unlocks: [R.UNLOCK.sunLong, R.UNLOCK.sunTwenty] }), R.sunTerms("partial").half, R.sunTerms("partial").reduce, R.sunTerms("partial").blessing, R.sunTerms("failure").heals, R.sunTerms("success", { unlocks: [R.UNLOCK.sunInjured] }).conditions.at(-1)],
    [{ formula: "5d8 + 7", half: false, reduce: 2, conditions: ["dazed", "fatigued", "sickened", "weakened"], max: 20, blessing: "1 month", heals: true }, true, 0, "", false, "injured"]);
  equal("C Veil Severing's durations, and with the +2 PP option", ["heroic", "critical", "success", "partial"].map((r) => [R.veilDuration(r, []), R.veilDuration(r, [R.UNLOCK.veilLong])]),
    [["1 year", "permanent"], ["1 month", "1 year"], ["1 week", "1 month"], ["1 day", "1 week"]]);
  equal("C spans: a month, a week, permanent, nothing", [R.spanSeconds("6 months"), R.spanSeconds("1 week"), R.spanSeconds("permanent until dispelled"), R.spanSeconds("varies")], [15552000, 604800, Infinity, 0]);
  equal("C Chaos Shield: 30 ft (60), the two rolls (cancelling Wild Power's disadvantage), the half", [R.chaosRadius(""), R.chaosRadius("60-foot emanation"), R.chaosRolls({ shielded: true }), R.chaosRolls({ shielded: true, disadvantage: true }), R.chaosRolls({}), R.shieldedDamage(9)], [30, 60, 2, 1, 1, 4]);
  equal("C Leyline Anchor: 1 PP off a High Magic spell inside, never below 1 (Q179)", [R.anchorDiscount({ highMagic: true, inside: true, totalPP: 6 }), R.anchorDiscount({ highMagic: true, inside: true, totalPP: 1 }), R.anchorDiscount({ highMagic: false, inside: true, totalPP: 6 }), R.anchorDiscount({ highMagic: true, inside: false, totalPP: 6 })], [-1, 0, 0, 0]);
  equal("C Mimic Spell: the casting DC (M48), its holds, the cap, the backlash, the shortfall",
    [R.mimicDC(9), R.mimicHold("critical", []), R.mimicHold("success", []), R.mimicHold("success", [R.UNLOCK.mimicHold]), R.mimicHold("critical", [R.UNLOCK.mimicHold]).seconds, R.mimicHold("failure", []), R.mimicAllowed(9, 8), R.mimicAllowed(10, 8), R.mimicBacklash(6), R.mimicShortfall(3, 8), R.mimicShortfall(9, 8)],
    [23, { kind: "time", seconds: 60, freeChoice: true }, { kind: "nextTurn", seconds: 12, freeChoice: false }, { kind: "time", seconds: 60, freeChoice: false }, 600, null, true, false, "6d6", 5, 0]);
  equal("C Soul Confluence (Q181): the pool, what it takes, the backlash", [R.confluencePool([3, 2, -1]), R.confluencePool([-2, -3]), R.confluenceTake(10, 4), R.confluenceTake(3, 8), R.confluenceBacklash(60), R.confluenceBacklash(11)],
    [20, 0, { taken: 4, pool: 6, rest: 0 }, { taken: 3, pool: 0, rest: 5 }, 5, 0]);
  equal("C Veilfracture: 10 ft per 2 caster levels (at least 10)", [R.portalWidth(9), R.portalWidth(1), R.portalWidth(12)], [40, 10, 60]);
}

/* ----------------------------------------------------------------- */
/* D — registration                                                    */
/* ----------------------------------------------------------------- */
{
  const names = regs.map((r) => `${r[0]}:${r[1]}`);
  equal("D what 8b registers", names, [`registerRitualRules:${A.RULES_KEY_8B}`, "registerDeferredTeleport:eaVeilSevering", "registerCastReaction:eaMimicSpell", `registerReactionStep:${A.MIMIC_STEP}`, `registerReactionStep:${A.NULLIFY_STEP}`, "registerCastRefusal:eaMimicSpellSheet", "registerCastPPSource:eaMimicBelowZero", "registerCastCostModifier:eaLeylineAnchor", "registerDamageShare:eaSoulConfluence"]);
  const rules = regs.find((r) => r[0] === "registerRitualRules")[2];
  equal("D the ritual rules: fields, prepare, partialCasts, minSecondaries", Object.keys(rules).sort(), ["fields", "minSecondaries", "partialCasts", "prepare"]);
  const teleport = regs.find((r) => r[1] === "eaVeilSevering")[2];
  equal("D Veil Severing's teleport is deferred (it moves nobody at the cast); nothing else's", [teleport({ spell: item("Veil Severing") }), teleport({ spell: item("Veilfracture") })], [true, false]);
  equal("D Mimic Spell is never cast from the sheet", [Boolean(A.mimicSheetRefusal({ spell: item("Mimic Spell") })), A.mimicSheetRefusal({ spell: item("Soul Confluence") })], [true, null]);
}

/* ----------------------------------------------------------------- */
/* E — the Foundry side                                                */
/* ----------------------------------------------------------------- */

/* E1 the ritual dialog and plan */
{
  reset8b();
  const pri = makeActor("Primary", { level: 9 }), sec = makeActor("Second", { level: 4 }), friend = makeActor("Friend", { level: 3 });
  for (const [a, x] of [[pri, 0], [sec, 100], [friend, 200]]) makeToken(a, { x });
  const html = await A.ritualFields8b({ actor: pri, spell: item("Sun’s Benediction"), spellData: S["Sun’s Benediction"].system });
  ok("E1 the dialog ticks secondaries (no variant here) and participants, by name", /name="eaSecondary-a-Second"/.test(html) && /name="eaParticipant-a-Friend"/.test(html) && !/eaSecondary-a-Primary/.test(html));
  const oathHtml = await A.ritualFields8b({ actor: pri, spell: item("Rite of Binding Oath"), spellData: S["Rite of Binding Oath"].system });
  ok("E1 Rite of Binding Oath's dialog ticks its participants too: they are its sworn (found live)", /name="eaParticipant-/.test(oathHtml), oathHtml.slice(0, 300));
  ok("E1 …and nothing for a spell that is not one of the ten", (await A.ritualFields8b({ actor: pri, spell: item("Chaos Shield") })) === "");
  purse.set("Primary", 100);
  const short = await A.prepareRitual8b({ actor: pri, spell: item("Sun’s Benediction"), form: { "eaSecondary-a-Second": "on" }, basePP: 4, secondaryCount: 1 });
  ok("E1 a short purse refuses before the roll (Q174): 250 gp", /250 gp/.test(short?.refused ?? ""), JSON.stringify(short));
  purse.set("Primary", 300);
  const miscount = await A.prepareRitual8b({ actor: pri, spell: item("Sun’s Benediction"), form: {}, basePP: 4, secondaryCount: 1 });
  ok("E1 a secondary entered but not ticked is refused (they share what follows)", /1 entered, 0 ticked/.test(miscount?.refused ?? ""));
  const good = await A.prepareRitual8b({ actor: pri, spell: item("Sun’s Benediction"), form: { "eaSecondary-a-Second": "on", "eaParticipant-a-Friend": "on" }, basePP: 4, secondaryCount: 1 });
  equal("E1 the plan: who, the spell; the gold not yet taken", [good?.refused, pri.flags[MOD][R.RITUAL_PLAN_FLAG]?.secondaries, pri.flags[MOD][R.RITUAL_PLAN_FLAG]?.participants, purse.get("Primary")], [undefined, [sec.uuid], [friend.uuid], 300]);
  const noTarget = await A.prepareRitual8b({ actor: pri, spell: item("Essence Reforging"), form: {}, basePP: 14, secondaryCount: 0 });
  ok("E1 Essence Reforging wants its one target first (its level sets the Cost)", /target the one creature/.test(noTarget?.refused ?? ""));
  game.user.targets = new Set([friend.token]);
  purse.set("Primary", 500);
  const essence = await A.prepareRitual8b({ actor: pri, spell: item("Essence Reforging"), form: {}, basePP: 14, secondaryCount: 0 });
  ok("E1 …200 gp × its level (3): 600, more than the 500 held", /600 gp/.test(essence?.refused ?? ""), JSON.stringify(essence));
  equal("E1 H13/H14 answers", [A.ritualPartialCasts8b({ spell: item("Veil Severing") }), A.ritualMinSecondaries8b({ spell: item("Veil Severing") }), A.ritualMinSecondaries8b({ spell: item("Eternal Invocation") }), A.ritualPartialCasts8b({ spell: item("Storm of Unmaking") })], [true, null, 0, false]);
}

/* E2 Sun's Benediction */
{
  reset8b();
  const pri = makeActor("Primary", { level: 9 }), sec = makeActor("Second", { level: 4 }), friend = makeActor("Friend", { level: 3 }), far = makeActor("Far", { level: 2 });
  makeToken(pri, { x: 0 }); makeToken(sec, { x: 100 }); makeToken(friend, { x: 200 }); makeToken(far, { x: 2000 });
  friend.conditions.rawValues.set("weakened", 2); friend.conditions.rawValues.set("dazed", 1);
  purse.set("Primary", 300);
  plan(pri, "Sun’s Benediction", { secondaries: [sec], participants: [friend, far] });
  rolls.push(9, 9, 9);
  answers.push("weakened");
  await quiet(() => ritual(pri, "Sun’s Benediction", "success", { warpMods: { bonusValue: 1 } }));
  equal("E2 Success: each participant within 30 ft regains 3d8 + 4 (one warp), the far one not", healed.map((x) => [x.target, x.amount]), [["Primary", 9], ["Second", 9], ["Friend", 9]]);
  equal("E2 …lowers its chosen condition by 2 (one warp)", reduced.map((r) => [r.target, r.key, r.from, r.to]), [["Friend", "weakened", 2, 0]]);
  ok("E2 …and is blessed: +2 status to saves against fear, 1 hour", ["Primary", "Second", "Friend"].every((n) => [pri, sec, friend].find((a) => a.name === n).effects.some((e) => e.flags[MOD].source === "sunBlessing8b" && e.flags[SYS].conditionals[0].value === 2 && e.flags[SYS].conditionals[0].when.traits[0] === "fear" && e.flags[SYS].spellEffectEnd === 1000 + 3600)));
  equal("E2 the Cost is taken (250 gp), whatever the degree", purse.get("Primary"), 50);
  ok("E2 the plan is spent", !pri.flags[MOD][R.RITUAL_PLAN_FLAG]);
  reset8b();
  for (const a of [pri, sec]) { a.effects = []; a.token = null; }
  makeToken(pri); makeToken(sec, { x: 100 });
  purse.set("Primary", 300);
  plan(pri, "Sun’s Benediction", { secondaries: [sec] });
  rolls.push(9, 9);
  await quiet(() => ritual(pri, "Sun’s Benediction", "partial"));
  equal("E2 Partial: half healing only (9 → 4), no condition, no blessing", [healed.map((x) => x.amount), reduced.length, pri.effects.filter((e) => e.flags[MOD].source === "sunBlessing8b").length], [[4, 4], 0, 0]);
  reset8b();
  purse.set("Primary", 300);
  makeToken(pri); makeToken(sec, { x: 100 });
  plan(pri, "Sun’s Benediction", { secondaries: [sec] });
  entryFor(pri, "Sun’s Benediction");
  await quiet(() => ritual(pri, "Sun’s Benediction", "blunder"));
  equal("E2 Blunder: no healing; every caster 4d6 essence, basic Fortitude at its own level DC (C3)", [healed.length, calls.saves.map((s) => [s.target, s.formula, s.type, s.save, s.dc])], [0, [["Primary", "4d6", "essence", "fortitude", 19], ["Second", "4d6", "essence", "fortitude", 14]]]);
  equal("E2 …and the cast is ended; the Cost still taken", [calls.ended.length, purse.get("Primary")], [1, 50]);
  reset8b();
  makeToken(pri);
  plan(pri, "Sun’s Benediction");
  await quiet(() => ritual(pri, "Sun’s Benediction", "success", { refunded: true }));
  equal("E2 a refunded casting takes no Cost and does nothing", [purse.get("Primary") ?? 0, healed.length, /stopped before it settled/.test(text(lastCard()))], [0, 0, true]);
}

/* E3 Concord of Stone, Rite of Echoed Shadows, Veil Severing: Regions and members */
{
  reset8b();
  const pri = makeActor("Primary", { level: 9 }), ally = makeActor("Ally", { level: 3 }), foe = makeActor("Foe", { level: 3 });
  makeToken(pri, { x: 0, disposition: 1 }); makeToken(ally, { x: 300, disposition: 1 }); makeToken(foe, { x: 400, disposition: -1 });
  purse.set("Primary", 2000);
  plan(pri, "Concord of Stone");
  entryFor(pri, "Concord of Stone");
  await quiet(() => ritual(pri, "Concord of Stone", "critical", { castPP: 10 }));
  const concord = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "concordOfStone");
  equal("E3 Concord, Critical: a 120-ft Region on the site, DR 10 labelled, 6 months; 100 gp × 10 PP taken", [concord?.flags[MOD][R.AREA8B_FLAG].radius, concord?.flags[MOD][R.AREA8B_FLAG].dr, concord?.flags[MOD][R.AREA8B_FLAG].until, /DR 10/.test(concord?.name), purse.get("Primary")], [120, 10, 1000 + 15552000, true, 1000]);
  const db = (a) => a.effects.find((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === concord.id);
  equal("E3 …the caster and its ally inside: +2 circumstance to DB; the foe not", [db(pri)?.changes?.[0], Boolean(db(ally)), Boolean(db(foe))], [{ key: "system.combat.defence.circumstance", type: "custom", value: "2", priority: 20 }, true, false]);
  await moveV14(ally.token.document, { x: 5000 });
  equal("E3 …the ally walks out: its bonus goes (the move's end read from the change)", Boolean(db(ally)), false);
  game.time.worldTime = 1000 + 2592000;
  pri.flags[SYS].activeSpells = [];
  await A.onWorldTimeB8b();
  ok("E3 …the core's 1-month entry ending does not cut a Critical's 6 months short (not cast-bound)", scene.regions.includes(concord));
  game.time.worldTime = 1000 + 15552000;
  await A.onWorldTimeB8b();
  await A.onRegionDeletedB8b(concord);
  equal("E3 …at 6 months the Region goes, its cast is ended, and the members' effects with it", [scene.regions.includes(concord), calls.ended.some((e) => e.castId === "cast-Concord of Stone") || !pri.flags[SYS].activeSpells.length, Boolean(db(pri))], [false, true, false]);
  reset8b();
  for (const a of [pri, ally, foe]) { a.effects = []; a.token = null; }
  makeToken(pri, { x: 0, disposition: 1 }); makeToken(ally, { x: 100, disposition: 1 }); makeToken(foe, { x: 5000, disposition: -1 });
  purse.set("Primary", 100);
  plan(pri, "Rite of Echoed Shadows", { participants: [ally] });
  await quiet(() => ritual(pri, "Rite of Echoed Shadows", "success", { warpMods: { unlocks: [R.UNLOCK.echoInvisible] } }));
  const echo = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "riteOfEchoedShadows");
  const inEcho = (a) => a.effects.find((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === echo.id);
  equal("E3 Echoed Shadows: 60 ft, 1 day; participants inside — advantage on Stealth and invisible (+6 PP)", [echo?.flags[MOD][R.AREA8B_FLAG].radius, echo?.flags[MOD][R.AREA8B_FLAG].until, inEcho(ally)?.statuses, inEcho(ally)?.flags[SYS].conditionals[0].when], [60, 1000 + 86400, ["invisible"], { checkTypes: ["skill"], subjects: ["stealth"] }]);
  await moveV14(foe.token.document, { x: 200 });
  const pen = foe.effects.find((e) => e.flags[MOD].source === "echoPenalty8b");
  equal("E3 …an enemy's first entry: −2 circumstance to attacks, 1 minute", [pen?.flags[SYS].conditionals[0].value, pen?.flags[SYS].conditionals[0].when.checkTypes, pen?.flags[SYS].spellEffectEnd], [-2, ["attack"], 1060]);
  await moveV14(foe.token.document, { x: 5000 }); await moveV14(foe.token.document, { x: 200 });
  equal("E3 …its second entry is not a first", foe.effects.filter((e) => e.flags[MOD].source === "echoPenalty8b").length, 1);
  const friend = makeActor("Passerby", { level: 2 }); makeToken(friend, { x: 9000, disposition: 1 });
  await moveV14(friend.token.document, { x: 200 });
  equal("E3 …an ally of the caster entering (not a participant) takes no penalty", friend.effects.filter((e) => e.flags[MOD].source === "echoPenalty8b").length, 0);
  await moveV14(ally.token.document, { x: 9000 });
  equal("E3 …a participant leaving with the +6 PP option: its echo goes, and 4d6 essence (basic Fortitude)", [Boolean(inEcho(ally)), calls.saves.at(-1)?.formula, calls.saves.at(-1)?.target], [false, "4d6", "Ally"]);
  reset8b();
  plan(pri, "Rite of Echoed Shadows");
  await quiet(() => ritual(pri, "Rite of Echoed Shadows", "blunder", { castPP: 12 }));
  ok("E3 Echoed Shadows' Blunder: the entity's level is the PP + 4 (16), a card", /level <strong>16<\/strong>/.test(text(lastCard())));
  reset8b();
  makeToken(pri);
  purse.set("Primary", 2000);
  plan(pri, "Veil Severing");
  await quiet(() => ritual(pri, "Veil Severing", "heroic", { warpMods: { unlocks: [R.UNLOCK.veilLong] } }));
  const veil = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "veilSevering");
  equal("E3 Veil Severing, Heroic with the +2 PP option: a permanent portal, 30 ft; 2,000 gp", [veil?.flags[MOD][R.AREA8B_FLAG].until, veil?.flags[MOD][R.AREA8B_FLAG].radius, purse.get("Primary")], [null, 30, 0]);
}

/* E4 Elemental Convergence: an owner's element */
{
  reset8b();
  const pri = makeActor("Primary", { level: 9 }), other = makeActor("Other", { level: 3 });
  makeToken(pri, { x: 0 }); makeToken(other, { x: 300 });
  plan(pri, "Elemental Convergence");
  answers.push("fire", "cold");
  await quiet(() => ritual(pri, "Elemental Convergence", "critical"));
  await flush();
  const zone = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "elementalConvergence");
  const part = (a, p) => a.effects.find((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === zone.id && e.flags[MOD].part === p);
  const fx = (a) => part(a, "resistance");
  equal("E4 the zone: 500 ft, 24 hours, following the caster", [zone?.flags[MOD][R.AREA8B_FLAG].radius, zone?.flags[MOD][R.AREA8B_FLAG].until, zone?.flags[MOD][R.AREA8B_FLAG].followTokenId], [500, 1000 + 86400, pri.token.document.id]);
  equal("E4 each creature's chosen element: resistance, and a 2d6 (Critical) rider on any Strike — two effects, the rider its own (the review)", [fx(pri)?.changes?.[0]?.value, fx(pri)?.flags[SYS]?.strikeRider ?? null, part(pri, "rider")?.flags[SYS].strikeRider, part(pri, "rider")?.changes?.length ?? 0], [", fire", null, { label: "Elemental Convergence (fire)", dice: "2d6", damageType: "fire", scope: "any", once: false }, 0]);
  ok("E4 the GM's client asked for a creature it acts for (no owner connected): cold", fx(other)?.flags[MOD].element === "cold" && part(other, "rider")?.flags[MOD].element === "cold", JSON.stringify(other.effects.map((e) => e.name)));
  await part(other, "rider").update({ disabled: true });
  await moveV14(other.token.document, { x: 20000 });
  ok("E4 leaving switches it off (kept, not re-asked)", fx(other)?.disabled === true && part(other, "rider")?.disabled === true && fx(other)?.flags[MOD].zoneOff === true && !part(other, "rider")?.flags[MOD].zoneOff);
  await moveV14(other.token.document, { x: 300 });
  ok("E4 coming back switches on what the zone switched off; the rider its owner turned off stays off (\"can choose\")", fx(other)?.disabled === false && part(other, "rider")?.disabled === true);
  await part(other, "rider").update({ disabled: false });
  await moveV14(other.token.document, { x: 20000 }); await moveV14(other.token.document, { x: 300 });
  ok("E4 …switched back on by its owner, it goes and comes with the zone", part(other, "rider")?.disabled === false);
  // ASKED ONCE (the review): a creature whose player is connected is asked on the player's client; moves meanwhile do not ask again.
  const player = { id: "zzPlayer", name: "Player", active: true, isGM: false };
  const pc = makeActor("Pc", { level: 3 }); pc.testUserPermission = (u, lvl) => u === player && lvl === "OWNER";
  makeToken(pc, { x: 20000 });
  game.users.push(player);
  sent.length = 0;
  await moveV14(pc.token.document, { x: 300 }); await moveV14(pc.token.document, { x: 400 }); await moveV14(pc.token.document, { x: 500 });
  equal("E4 a player's creature: asked on its player's client, once though it moves three times", [sent.filter((d) => d.task === "convergenceElement").map((d) => d.actorUuid), part(pc, "resistance") ?? null, A.answersFor(pc)], [[pc.uuid], null, false]);
  game.users.pop();
  equal("E4 answersFor: with no player connected, any tab of the active GM's account", A.answersFor(pc), true);
  answers.push("acid", "cold");
  await quiet(() => Promise.all([A.INTERNALS_B8B.OWNER_TASKS.convergenceElement(pc, { regionUuid: zone.uuid, dice: "2d6" }), A.INTERNALS_B8B.OWNER_TASKS.convergenceElement(pc, { regionUuid: zone.uuid, dice: "2d6" })]));
  equal("E4 a second answer, given while the first was being chosen (two tabs), is ignored: one element, two effects", pc.effects.filter((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === zone.id).map((e) => e.flags[MOD].element), ["acid", "acid"]);
  reset8b();
  plan(pri, "Elemental Convergence");
  answers.push("acid");
  await quiet(() => ritual(pri, "Elemental Convergence", "partial"));
  equal("E4 a Partial is its Failure (m42, Q171): the primary, alone, takes 2d6 of the element it chose, basic Reflex", calls.saves.map((s) => [s.target, s.formula, s.type, s.save]), [["Primary", "2d6", "acid", "reflex"]]);
}

/* E5 Rite of Binding Oath and the GM's button */
{
  reset8b();
  const pri = makeActor("Primary", { level: 9 }), a1 = makeActor("Oathkeeper", { level: 3 }), a2 = makeActor("Oathbreaker", { level: 3 });
  makeToken(pri); makeToken(a1, { x: 100 }); makeToken(a2, { x: 200 });
  purse.set("Primary", 300);
  // THE PARTICIPANTS ARE ITS TARGETS (found live): a targeted creature is not one; the caster and the ticked are.
  game.user.targets = new Set([a2.token]);
  plan(pri, "Rite of Binding Oath", { participants: [a1, a2] });
  await quiet(() => ritual(pri, "Rite of Binding Oath", "critical", { saveDC: 21, warpMods: { damageDice: "1d6" } }));
  const sworn = (a) => a.effects.find((e) => e.flags[MOD].source === "oath8b");
  equal("E5 Critical: the caster and both ticked participants sworn for a year; the oath's damage 2d6 + 1d6, doubled", [Boolean(sworn(pri)), Boolean(sworn(a1)), sworn(a2)?.flags[MOD].oath8b.formula, sworn(a2)?.flags[MOD].oath8b.double, sworn(a2)?.flags[SYS].spellEffectEnd], [true, true, "2d6 + 1d6", true, 1000 + 31536000]);
  ok("E5 the GM's card has Oath broken for each", (msgText().match(/data-ea8b="oathBroken"/g) ?? []).length === 3);
  rolls.push(7);
  await quiet(() => A.onCardButton8b("oathBroken", pri.uuid, a2.uuid));
  equal("E5 Oath broken: 7 doubled to 14 essence, basic Fortitude at the cast's DC 21; disadvantage on all rolls for 24 hours; the oath gone",
    [calls.saves.at(-1)?.dc, calls.saves.at(-1)?.type, calls.saves.at(-1)?.amount, a2.effects.find((e) => e.flags[MOD].source === "oathBreaker8b")?.flags[SYS].conditionals[0].kind, Boolean(sworn(a2))], [21, "essence", 14, "disadvantage", false]);
  game.user.isGM = false;
  await quiet(() => A.onCardButton8b("oathBroken", pri.uuid, a1.uuid));
  ok("E5 a player cannot press it", Boolean(sworn(a1)) && warns.some((w) => /only the GM/.test(w)));
  game.user.isGM = true;
  reset8b();
  for (const a of [pri, a1, a2]) a.effects = [];
  game.user.targets = new Set();
  makeToken(pri); makeToken(a1, { x: 100 }); makeToken(a2, { x: 200 });
  purse.set("Primary", 300);
  plan(pri, "Rite of Binding Oath", { participants: [a1, a2] });
  let asked = 0;
  dialogPick = () => { asked += 1; return [a1.id]; };
  await quiet(() => ritual(pri, "Rite of Binding Oath", "partial"));
  ok("E5 Partial: nobody is sworn on the caster's client, nor asked there; the GM's card has the choice (the review)", !sworn(a1) && !sworn(a2) && asked === 0 && /data-ea8b="oathChoose"/.test(msgText()) && pri.flags[MOD].oathPending8b?.keep === 1);
  await quiet(() => A.onCardButton8b("oathChoose", pri.uuid, pri.flags[MOD].oathPending8b.id));
  equal("E5 Partial: half (one of three, rounded down), the GM's pick, for a month", [Boolean(sworn(a1)), Boolean(sworn(a2)), Boolean(sworn(pri)), sworn(a1)?.flags[SYS].spellEffectEnd, asked], [true, false, false, 1000 + 2592000, 1]);
  reset8b();
  for (const a of [pri, a1, a2]) a.effects = [];
  makeToken(pri);
  purse.set("Primary", 300);
  plan(pri, "Rite of Binding Oath", { participants: [] });
  const solo = await quiet(() => ritual(pri, "Rite of Binding Oath", "success", { saveDC: 21 }));
  ok("E5 with no participant ticked, the caster alone is sworn (a caster takes part, Q173)", Boolean(sworn(pri)) && !sworn(a1), JSON.stringify(solo ?? null));
  ok("E5 …and the oath-broken card follows; the choice is spent", /data-ea8b="oathBroken"/.test(msgText()) && !pri.flags[MOD].oathPending8b);
  await quiet(() => A.onCardButton8b("oathChoose", pri.uuid, "stale"));
  ok("E5 a spent choice warns", warns.some((w) => /already been chosen/.test(w)));
}

/* E6 Army of the Grave and the GM's button */
{
  reset8b();
  const pri = makeActor("Necro", { level: 19, cap: 40 }), z = [1, 2, 3].map((i) => makeActor(`Zombie${i}`, { level: 6, type: "Undead" }));
  const ghoul = makeActor("Ghoul", { level: 4, type: "Undead" }), wolf = makeActor("Wolf", { level: 1, type: "Animal" });
  for (const a of [ghoul, ...z]) a.system.details = { traits: "Undead" };
  makeToken(pri); z.forEach((a, i) => makeToken(a, { x: 100 * (i + 1) })); makeToken(ghoul, { x: 500 }); makeToken(wolf, { x: 600 });
  plan(pri, "Army of the Grave");
  entryFor(pri, "Army of the Grave");
  await quiet(() => ritual(pri, "Army of the Grave", "success", { castPP: 20 }));
  ok("E6 Success: the card names 10 corpses (one per 2 PP) and the GM's button", /10 intact corpses/.test(text(lastCard())) && /data-ea8b="raiseUndead"/.test(msgText()));
  const rec = pri.flags[MOD].army8b;
  canvas.tokens.controlled = [wolf.token];
  await quiet(() => A.onCardButton8b("raiseUndead", pri.uuid, rec.id));
  ok("E6 a creature without the undead trait is refused", warns.some((w) => /only undead/.test(w)) && pri.flags[MOD].army8b);
  canvas.tokens.controlled = [...z.map((a) => a.token), ghoul.token];
  await quiet(() => A.onCardButton8b("raiseUndead", pri.uuid, rec.id));
  ok("E6 levels 6+6+6+4 = 22 over the 20 PP are refused", warns.some((w) => /22, more than the 20 PP/.test(w)));
  canvas.tokens.controlled = [...z.map((a) => a.token)];
  await quiet(() => A.onCardButton8b("raiseUndead", pri.uuid, rec.id));
  const entries = await CRW.controlledOf(pri);
  equal("E6 three level-6 zombies (18 of 20): recorded in the REAL core's control register as undead, for a week", [entries.length, entries.map((e) => e.source), z.every((a) => a.effects.some((e) => e.flags[MOD].source === "armyRaised8b" && e.flags[SYS].spellEffectEnd === 1000 + 604800))], [3, ["undead", "undead", "undead"], true]);
  await quiet(() => A.onCardButton8b("raiseUndead", pri.uuid, rec.id));
  ok("E6 the button is spent once pressed", warns.some((w) => /already been raised/.test(w)));
  reset8b();
  pri.flags[SYS] = {};
  makeToken(pri); z.forEach((a, i) => makeToken(a, { x: 100 * (i + 1) }));
  plan(pri, "Army of the Grave");
  await quiet(() => ritual(pri, "Army of the Grave", "partial", { castPP: 24, warpMods: { unlocks: [R.UNLOCK.armyHalf] } }));
  canvas.tokens.controlled = z.map((a) => a.token);
  dialogPick = () => [z[0].token.id];
  for (const a of z) a.effects = [];
  await quiet(() => A.onCardButton8b("raiseUndead", pri.uuid, pri.flags[MOD].army8b.id));
  equal("E6 Partial (and halved levels): one of three controlled for a day, the other two hostile", [z.map((a) => a.token.document.disposition), z[0].effects.some((e) => e.flags[SYS].spellEffectEnd === 1000 + 86400)], [[1, -1, -1], true]);
  const halfEntries = await CRW.controlledOf(pri);
  equal("E6 the +4 PP option halves only the count: the control register holds its one entry at its full level, 6 (the review)", [halfEntries.length, halfEntries[0]?.level], [1, 6]);
  const raised = z[0].effects.find((e) => e.flags[MOD].source === "armyRaised8b");
  const before6 = (await CRW.controlledOf(pri)).length;
  await quiet(() => raised.delete());
  equal("E6 its effect gone (expired, deleted), its control entry is released", [(await CRW.controlledOf(pri)).length, before6 - 1], [before6 - 1, before6 - 1]);
  reset8b();
  makeToken(pri);
  const sec = makeActor("Acolyte", { level: 5 }); makeToken(sec, { x: 100 });
  plan(pri, "Army of the Grave", { secondaries: [sec] });
  await quiet(() => ritual(pri, "Army of the Grave", "fumble"));
  equal("E6 Fumble: all rise uncontrolled; every caster 4d10 essence", calls.saves.map((s) => [s.target, s.formula]), [["Necro", "4d10"], ["Acolyte", "4d10"]]);
}

/* E7 Call of the Ancestors, Essence Reforging, Eternal Invocation */
{
  reset8b();
  const pri = makeActor("Seer", { level: 9 }), p = makeActor("Kin", { level: 2 });
  makeToken(pri); makeToken(p, { x: 100 });
  purse.set("Seer", 200);
  plan(pri, "Call of the Ancestors", { participants: [p] });
  answers.push(p.id);
  await quiet(() => ritual(pri, "Call of the Ancestors", "critical", { warpMods: { bonusValue: 2 } }));
  const fav = p.effects.find((e) => e.flags[MOD].source === "ancestorsFavour8b");
  equal("E7 Call, Critical: 5 questions; the chosen participant's advantage on one check within 24 hours (ticked, once)", [/up to 5 questions/.test(text(lastCard())), fav?.flags[SYS].conditionals[0].kind, fav?.flags[SYS].conditionals[0].oneShot, fav?.flags[SYS].conditionals[0].auto, fav?.flags[SYS].spellEffectEnd], [true, "advantage", true, false, 1000 + 86400]);
  reset8b();
  const target = makeActor("Cursed", { level: 4 });
  makeToken(pri); makeToken(target, { x: 100 });
  const curse = (await target.createEmbeddedDocuments("ActiveEffect", [{ name: "Wolf curse", origin: "Item.curse", flags: {} }]))[0];
  uuidMap.set("Item.curse", { system: { ppCost: 10 } });
  game.user.targets = new Set([target.token]);
  plan(pri, "Essence Reforging", { targetLevel: 4 });
  answers.push("remove", curse.id);
  purse.set("Seer", 800);
  await quiet(() => ritual(pri, "Essence Reforging", "success", { castPP: 14 }));
  ok("E7 Essence Reforging, Remove: the curse (PP 10 ≤ 14) on the GM's card; 800 gp (200 × 4) taken", /data-ea8b="reforgeRemove"/.test(msgText()) && purse.get("Seer") === 0);
  await quiet(() => A.onCardButton8b("reforgeRemove", pri.uuid, `${target.uuid}|${curse.id}`));
  ok("E7 …the GM's press removes it", !target.effects.includes(curse));
  reset8b();
  makeToken(pri); makeToken(target, { x: 100 });
  game.user.targets = new Set([target.token]);
  plan(pri, "Essence Reforging", { targetLevel: 4 });
  entryFor(pri, "Essence Reforging");
  await quiet(() => ritual(pri, "Essence Reforging", "blunder"));
  equal("E7 Essence Reforging, Blunder: it fails (M45); 4d8 force to you and the target; its entry ended", [damaged.map((d) => [d.target, d.type]), calls.ended.length], [[["Seer", "force"], ["Cursed", "force"]], 1]);
  reset8b();
  makeToken(pri); makeToken(target, { x: 100 });
  plan(pri, "Essence Reforging");
  await quiet(() => ritual(pri, "Essence Reforging", "partial"));
  ok("E7 …a Partial does not work (no ladder), no backlash", damaged.length === 0 && /fails/.test(text(lastCard())));
  reset8b();
  const priest = makeActor("Priest", { level: 19 }); priest.system.details = { traits: "Humanoid, Good" };
  const saint = makeActor("Saint", { level: 3 }); saint.system.details = { traits: "Good" };
  const fiend = makeActor("Fiend", { level: 3 }); fiend.system.details = { traits: "Evil" };
  const beast = makeActor("Beast", { level: 3 });
  makeToken(priest); makeToken(saint, { x: 100 }); makeToken(fiend, { x: 200 }); makeToken(beast, { x: 300 });
  purse.set("Priest", 10000);
  plan(priest, "Eternal Invocation");
  entryFor(priest, "Eternal Invocation");
  await quiet(() => ritual(priest, "Eternal Invocation", "success"));
  const reach = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "eternalInvocation");
  const mark = (a) => a.effects.find((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === reach?.id);
  equal("E7 Eternal Invocation: the flame placed (a light), the mile's reach centred on it, permanent; 10,000 gp", [lightCalls.length, reach?.flags[MOD][R.AREA8B_FLAG].centre, reach?.flags[MOD][R.AREA8B_FLAG].until, purse.get("Priest")], [1, { x: 700, y: 700 }, null, 0]);
  equal("E7 …sharing Good: doubled rest (H15), advantage on crafting and Spellcraft, a save tick", [mark(saint)?.flags[SYS].restRate, mark(saint)?.flags[SYS].conditionals.map((c) => [c.kind, c.auto])], [{ hp: 2, pp: 2, label: "Eternal Invocation" }, [["advantage", true], ["advantage", true], ["advantage", false]]]);
  equal("E7 …opposed (Evil): halved, and disadvantage; neither: nothing", [mark(fiend)?.flags[SYS].restRate.hp, mark(fiend)?.flags[SYS].conditionals[1].kind, mark(fiend)?.flags[SYS].conditionals[1].when, Boolean(mark(beast))], [0.5, "disadvantage", { checkTypes: ["spellcraft"] }, false]);
  priest.flags[SYS].activeSpells = [];
  await A.onWorldTimeB8b();
  ok("E7 …dispelled (its cast gone), the reach goes with it (cast-bound)", !scene.regions.includes(reach));
}

/* E8 Chaos Shield in Block 2's Wild Surge */
{
  reset8b();
  const shield = makeActor("Warden", { level: 9, pp: 10 }), ally = makeActor("Surger", { level: 5 }), foe = makeActor("Enemy", { level: 5 });
  makeToken(shield, { x: 0, disposition: 1 }); makeToken(ally, { x: 100, disposition: 1 }); makeToken(foe, { x: 200, disposition: -1 });
  entryFor(shield, "Chaos Shield", "cs1");
  await quiet(() => settle(shield, "Chaos Shield", { warpMods: { areaOverride: "60-foot emanation" } }));
  const marker = shield.effects.find((e) => e.flags[MOD].source === R.CHAOS_SHIELD_FLAG);
  equal("E8 the shield: a 60-ft aura (warped), ended with its cast", [marker?.flags[MOD][R.CHAOS_SHIELD_FLAG].radius, marker?.flags[SYS].castId], [60, "cs1"]);
  const found = await A.chaosShieldFor(ally);
  equal("E8 a surge by an ally inside: shielded, an ally; the allies inside are the warden and the surger", [Boolean(found), found?.ally, [...found.members].sort()], [true, true, [ally.uuid, shield.uuid].sort()]);
  askAnswer = "yes";
  const out = await quiet(() => B2.rollTable(ally, { table: T7.WILD_SURGE, column: "e", title: "Wild Surge", level: 4, expiry: null, source: "wildSurge", radiusFeet: 20 }));
  equal("E8 nullified: the warden's reaction and 2 PP, the table not rolled", [out?.nullified, reactionsSpent.map((r) => r.actor), shield.system.resources.pp.value, rolls.length], [true, ["Warden"], 8, 0]);
  const again = await quiet(() => B2.rollTable(ally, { table: T7.WILD_SURGE, column: "e", title: "Wild Surge", level: 4, expiry: null, source: "wildSurge", radiusFeet: 20, forcedTotal: 70 }));
  ok("E8 once per round: a second surge is not nullified", !again?.nullified && warns.some((w) => /already used/.test(w)));
  askAnswer = "no";
  marker.flags[MOD][R.CHAOS_SHIELD_FLAG].used = null;
  rolls.push(30, 80);
  answers.push("80");
  const picked = await quiet(() => B2.rollTable(ally, { table: T7.WILD_SURGE, column: "e", title: "Wild Surge", level: 4, expiry: null, source: "wildSurge", radiusFeet: 20 }));
  equal("E8 not nullified: rolled twice (30, 80), the surger takes 80", picked?.roll, 80);
  const row = T7.WILD_SURGE.find((r) => r.e?.kind === "damage" && r.e.save && r.e.radius && r.e.includeSelf);
  calls.saves.length = 0;
  rolls.push(9);
  await quiet(() => B2.rollTable(ally, { table: T7.WILD_SURGE, column: "e", title: "Wild Surge", level: 4, expiry: null, source: "wildSurge", radiusFeet: 40, forcedTotal: row.min }));
  const byName = Object.fromEntries(calls.saves.map((s) => [s.target, s]));
  equal(`E8 a damage row with a save (d100 ${row.min}, 1d10 force rolled 9): every save at its own level DC −2; allies inside take half (4), the enemy all 9`,
    ["Surger", "Warden", "Enemy"].map((n) => [byName[n]?.dc, byName[n]?.amount]), [[13, 4], [17, 4], [13, 9]]);
  shield.flags[SYS].activeSpells = [];
  equal("E8 the shield's cast ended: no shield", await A.chaosShieldFor(ally), null);
}

/* E9 Leyline Anchor */
{
  reset8b();
  const anc = makeActor("Anchorer", { level: 9 }), rival = makeActor("Rival", { level: 9 }), near = makeActor("Nearby", { level: 5 });
  anc.system.magic.casterLevelValue = 9; rival.system.magic.casterLevelValue = 9; near.system.magic.casterLevelValue = 5;
  const layman = makeActor("Layman", { level: 5 });
  makeToken(anc, { x: 0 }); makeToken(near, { x: 500 }); makeToken(rival, { x: 20000 }); makeToken(layman, { x: 600 });
  const [ley] = await scene.createEmbeddedDocuments("Region", [{ name: "Old Road", shapes: [{ type: "rectangle", x: 1000, y: 0, width: 100, height: 100 }], behaviors: [{ type: `${MOD}.leyLine`, system: { level: 6 } }], flags: {} }]);
  const AR = await import(new URL("../module/areas.mjs", import.meta.url));
  const realWithin = AR.leyLinesWithin;
  entryFor(anc, "Leyline Anchor", "la1");
  answers.push("0");
  await quiet(() => settle(anc, "Leyline Anchor", { saveDC: 22, warpMods: { durationText: "1 hour" } }));
  const zone = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "leylineAnchor");
  if (zone) {
    equal("E9 the anchor: the line anchored, 300 ft following the caster, 1 hour, DC 22 kept", [zone.flags[MOD][R.AREA8B_FLAG].anchored, zone.flags[MOD][R.AREA8B_FLAG].radius, zone.flags[MOD][R.AREA8B_FLAG].followTokenId, zone.flags[MOD][R.AREA8B_FLAG].until, zone.flags[MOD][R.AREA8B_FLAG].saveDC], [ley.id, 300, anc.token.document.id, 4600, 22]);
    ok("E9 casters within 300 ft: +1 circumstance to Spellcraft and Power Recovery", [anc, near].every((a) => { const f = a.effects.find((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === zone.id); return f && f.flags[SYS].conditionals.some((c) => c.when.checkTypes?.[0] === "spellcraft" && c.value === 1 && c.type === "circumstance") && f.flags[SYS].conditionals.some((c) => c.when.actions?.[0] === "powerRecovery"); }), JSON.stringify(near.effects.map((e) => e.name)));
    equal("E9 …a creature with no caster level within it gains nothing", layman.effects.some((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === zone.id), false);
    equal("E9 the discount (Q179): a High Magic spell inside 1 PP off, floor 1; outside, or not High Magic, none",
      [(await A.anchorCostCut({ actor: near, highMagic: true, totalPP: 8 }))?.ppDelta, await A.anchorCostCut({ actor: rival, highMagic: true, totalPP: 8 }), await A.anchorCostCut({ actor: near, highMagic: false, spellData: { traits: "Fire" }, totalPP: 8 }), await A.anchorCostCut({ actor: near, highMagic: true, totalPP: 1 })], [-1, null, null, null]);
    game.combat = { started: true, id: "c1", round: 1, combatants: [{ actor: rival }] };
    rival.system.resources.ap = { value: 4 };
    degreeFor.set("Rival", "failure");
    const gate = await quiet(() => A.anchorTapGate(rival, ley.id, "Tap Ley Line", 1));
    equal("E9 a rival's Tap: Power Manipulation against DC 27 (22 + 5); a failure stops it and spends its 1 AP", [calls.checks.at(-1)?.subject, calls.checks.at(-1)?.dc, /attempt stops/.test(gate?.refused ?? ""), rival.system.resources.ap.value], ["powerManipulation", 27, true, 3]);
    degreeFor.set("Rival", "success");
    equal("E9 …a success taps it; the anchorer's own Tap is not asked", [await quiet(() => A.anchorTapGate(rival, ley.id, "Tap Ley Line", 1)), await A.anchorTapGate(anc, ley.id, "Tap Ley Line", 1)], [null, null]);
    game.combat = null;
  } else ok("E9 the anchor's zone was made", false, JSON.stringify(cards.slice(-2)));
  void realWithin;
  ok("E9 Block 2's Tap and Channel ask the gate after the line is chosen", /const l = chosen\.pick;\n\s*\/\/ AN ANCHORED LINE[\s\S]*?anchorTapGate\(actor, l\.region\.id, "Tap Ley Line", 1\)/.test(read("module", "block2-automations.mjs")) && /anchorTapGate\(actor, l\.region\.id, "Channel Ley Line", 0\)/.test(read("module", "block2-automations.mjs")));
}

/* E10 Mimic Spell */
{
  reset8b();
  const caster = makeActor("Caster", { level: 9 }), mimic = makeActor("Mimic", { level: 9, pp: 20 }), far = makeActor("Faraway", { level: 9, pp: 20 });
  mimic.system.magic.casterLevelValue = 8; far.system.magic.casterLevelValue = 8;
  mimic.items.push(item("Mimic Spell")); far.items.push(item("Mimic Spell"));
  mimic.createEmbeddedDocuments = (orig => async (type, docs) => { if (type === "Item") { const made = docs.map((d, i) => ({ ...d, id: `imp${i}`, flags: d.flags })); mimic.items.push(...made); return made; } return orig(type, docs); })(mimic.createEmbeddedDocuments);
  mimic.deleteEmbeddedDocuments = (orig => async (type, ids) => { if (type === "Item") { mimic.items = mimic.items.filter((i) => !ids.includes(i.id)); return; } return orig(type, ids); })(mimic.deleteEmbeddedDocuments);
  mimic.items.get = (id) => mimic.items.find((i) => i.id === id);
  makeToken(caster, { x: 0 }); makeToken(mimic, { x: 500 }); makeToken(far, { x: 5000 });
  const fireball = { name: "Fireball", uuid: "Item.fireball", system: { ppCost: 6, traits: "Fire" }, flags: {}, toObject() { return { name: "Fireball", type: "spell", system: { ppCost: 6, traits: "Fire", specialist: true }, flags: {} }; } };
  uuidMap.set(fireball.uuid, fireball);
  degreeFor.set("Mimic", "critical");
  mimic.system.magic.spellcraft = { total: 13, checkModifiers: [{ label: "BSB and tradition ability", value: 13, type: "untyped" }] };
  askAnswer = "hold";
  const r = await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: fireball, castPP: 9 }));
  equal("E10 never stops the cast; offered to the one within 60 ft who sees it", [r, asks.map((a) => a.reactor)], [null, ["Mimic"]]);
  equal("E10 the check carries the sheet's Spellcraft (found live: it rolled +0)", calls.checks.at(-1)?.modifiers, [{ label: "BSB and tradition ability", value: 13, type: "untyped" }]);
  equal("E10 Critical, held: Spellcraft against DC 23 (9 PP as cast); 4 + 2 PP spent; a reaction", [calls.checks.at(-1)?.type, calls.checks.at(-1)?.dc, mimic.system.resources.pp.value, reactionsSpent.map((x) => x.actor)], ["spellcraft", 23, 14, ["Mimic"]]);
  const imprint = mimic.items.find((i) => i.flags?.[MOD]?.[R.MIMIC_FLAG]);
  const hold = mimic.effects.find((e) => e.flags[MOD].source === "mimicHold8b");
  equal("E10 the imprint: the spell as a copy, no longer specialist (Q180); held 10 minutes", [imprint?.name, imprint?.system.specialist, imprint?.flags[MOD][R.MIMIC_FLAG].castPP, imprint?.flags[MOD][R.MIMIC_FLAG].freeChoice, hold?.flags[SYS].spellEffectEnd], ["Fireball", false, 9, true, 1600]);
  const offer = await A.mimicPPSource.offer({ actor: mimic, spell: imprint, ppPool: 3, payable: 9 });
  equal("E10 short of PP, it offers the 6 below 0, at 5 Soul Drain each", offer?.max, 6);
  mimic.conditions.rawValues.set("soulDrain", 4);
  const settled = await A.mimicPPSource.settle({ actor: mimic, spell: imprint }, { drawn: 6, paid: 6 });
  equal("E10 …settled: 30 Soul Drain, passed as the increment (the core adds it; the review) — 4 to 34", [calls.conditions.at(-1)?.tags?.[0], /30 Soul Drain<\/strong> \(Soul Drain 34\)/.test(settled?.lines?.[0] ?? "")], [{ key: "soulDrain", value: 30 }, true]);
  mimic.conditions.rawValues.delete("soulDrain");
  equal("E10 a spell that is no imprint is offered nothing", await A.mimicPPSource.offer({ actor: mimic, spell: fireball, ppPool: 0, payable: 9 }), null);
  const before = cards.length;
  await A.onSpellSettledB8b({ actor: mimic, spell: imprint, cast: true, refunded: false, degree: "success" });
  ok("E10 cast, the imprint and its hold are gone — and nothing says it dissipated uncast", !mimic.items.includes(imprint) && !mimic.effects.includes(hold) && !cards.slice(before).some((c) => /dissipates/.test(text(c))));
  reset8b();
  makeToken(caster); makeToken(mimic, { x: 500 });
  mimic.system.resources.pp.value = 20;
  const big = { ...fireball, uuid: "Item.big", toObject: fireball.toObject };
  uuidMap.set(big.uuid, big);
  degreeFor.set("Mimic", "success"); askAnswer = "yes";
  const asked0 = asks.length;
  await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: big, castPP: 10 }));
  equal("E10 M48: not offered for 10 PP over its maximum of 9 (caster level 8 + 1) — it could never imprint (found live)", asks.length, asked0);
  await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: big, castPP: 9 }));
  equal("E10 …at its maximum, offered", asks.length, asked0 + 1);
  const rite = { name: "Concord of Stone", uuid: "Item.rite", system: { ppCost: 8, traits: "Alteration, Earth, Ritual, Utility" }, flags: {}, toObject() { return { name: "Concord of Stone", type: "spell", system: this.system, flags: {} }; } };
  uuidMap.set(rite.uuid, rite);
  await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: rite, castPP: 8 }));
  equal("E10 Q8: not offered for a Ritual spell", asks.length, asked0 + 1);
  await quiet(() => A.mimicStep(mimic, "yes", { spellUuid: big.uuid, spellName: "Fireball", castPP: 10, casterName: "Caster", casterUuid: caster.uuid }));
  ok("E10 …and the step itself still refuses an imprint over the maximum (M48)", /maximum PP per cast/.test(text(lastCard())) && !mimic.items.some((i) => i.flags?.[MOD]?.[R.MIMIC_FLAG] && i.name === "Fireball" && i.flags[MOD][R.MIMIC_FLAG].castPP === 10));
  reset8b();
  makeToken(caster); makeToken(mimic, { x: 500 });
  mimic.system.resources.pp.value = 20;
  degreeFor.set("Mimic", "fumble");
  await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: fireball, castPP: 6 }));
  equal("E10 Fumble: 6d6 essence, basic Will at its own level DC (C3)", [calls.saves.at(-1)?.formula, calls.saves.at(-1)?.save, calls.saves.at(-1)?.dc, calls.saves.at(-1)?.target], ["6d6", "will", 19, "Mimic"]);
  reset8b();
  makeToken(caster); makeToken(mimic, { x: 500 });
  mimic.system.resources.pp.value = 20;
  askAnswer = "no";
  await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: fireball, castPP: 6 }));
  equal("E10 with sight and PP it is offered (declined here)", asks.length, 1);
  asks.length = 0;
  blocked.add(`${Math.round(caster.token.center.x)},${Math.round(caster.token.center.y)}`);
  await quiet(() => A.mimicReaction({ actor: caster, token: caster.token, spell: fireball, castPP: 6 }));
  equal("E10 it must see the caster: a wall between, nothing offered", asks.length, 0);
}

/* E11 Soul Confluence */
{
  reset8b();
  const lead = makeActor("Lead", { level: 9 }), ally = makeActor("Link", { level: 5, owner: false }), stranger = makeActor("Stranger", { level: 5 });
  lead.system.attributes.constitution = { total: 3 }; ally.system.attributes.constitution = { total: 2 };
  makeToken(lead, { x: 0 }); makeToken(ally, { x: 100 }); makeToken(stranger, { x: 150, disposition: -1 });
  entryFor(lead, "Soul Confluence", "sc1");
  dialogPick = (cfg) => { ok("E11 only allies within 30 ft are offered (the enemy is not)", /Link/.test(cfg.content) && !/Stranger/.test(cfg.content)); return [ally.uuid]; };
  await quiet(() => settle(lead, "Soul Confluence"));
  const marker = lead.effects.find((e) => e.flags[MOD].source === R.CONFLUENCE_FLAG);
  equal("E11 the pool: (3 + 2) × 5 = 25; both linked, +2 status to Will", [marker?.flags[MOD][R.CONFLUENCE_FLAG].pool, [lead, ally].every((a) => a.effects.some((e) => e.flags[MOD].source === "confluenceLink8b" && e.flags[SYS].conditionals[0].when.subjects[0] === "will"))], [25, true]);
  marker.isOwner = true;
  const first = await A.confluenceShare(ally, 10);
  equal("E11 the linked ally's 10 damage comes off the pool (15 left)", [first?.taken, marker.flags[MOD][R.CONFLUENCE_FLAG].pool], [10, 15]);
  marker.isOwner = false;
  lead.isOwner = false; game.users.activeGM = null;
  const refused = await quiet(() => A.confluenceShare(ally, 5));
  equal("E11 a write that cannot be made (no GM to relay it) takes nothing (the review)", [refused, marker.flags[MOD][R.CONFLUENCE_FLAG].pool], [null, 15]);
  lead.isOwner = true; game.users.activeGM = game.user;
  const second = await A.confluenceShare(lead, 20);
  equal("E11 …20 more: the pool takes its last 15", [second?.taken, marker.flags[MOD][R.CONFLUENCE_FLAG].pool], [15, 0]);
  marker.flags[MOD][R.CONFLUENCE_FLAG].pool = 15;
  equal("E11 a stale pool (a relayed write not yet landed) is not drawn on again: this client's own last pool counts", await A.confluenceShare(lead, 5), null);
  marker.flags[MOD][R.CONFLUENCE_FLAG].pool = 0;
  equal("E11 an empty pool, or a creature not linked, takes nothing", [await A.confluenceShare(lead, 5), await A.confluenceShare(stranger, 5)], [null, null]);
  game.time.worldTime = 1000 + 60;
  lead.conditions.rawValues.set("soulDrain", 2);
  rolls.push(12, 9);
  await quiet(() => marker.delete());
  await flush();
  equal("E11 the end after 10 rounds: 5d6 Soul Drain each; the links undone", [calls.conditions.filter((c) => c.tags[0].key === "soulDrain").map((c) => [c.target, c.tags[0].value]), [lead, ally].map((a) => a.effects.filter((e) => e.flags[MOD].source === "confluenceLink8b").length)], [[["Lead", 12], ["Link", 9]], [0, 0]]);
  ok("E11 the increment is passed; the card names the total (2 + 12 = 14)", cards.some((c) => /Lead: <strong>12 Soul Drain<\/strong> \(Soul Drain 14\)/.test(text(c))));
  ok("E11 Block 7's relay may take the pool down, never up, and delete the links", B7.flagChangeAllowed("soulConfluence8b", { pool: 15, participants: ["a"] }, { pool: 5, participants: ["a"] }) && !B7.flagChangeAllowed("soulConfluence8b", { pool: 5, participants: ["a"] }, { pool: 15, participants: ["a"] }) && !B7.flagChangeAllowed("soulConfluence8b", { pool: 15, participants: ["a"] }, { pool: 5, participants: ["b"] }) && B7.OWN_SOURCES.includes("confluenceLink8b"));
}

/* E12 Storm of Unmaking, Veilfracture, Alter Corpse */
{
  reset8b();
  const st = makeActor("Stormcaller", { level: 19 }); st.system.magic.spellcraft = { dc: 29 };
  st.system.magic.castingAbility = "intelligence"; st.system.attributes.intelligence = { total: 5 };
  makeToken(st);
  await quiet(() => settle(st, "Storm of Unmaking", { cast: false, degree: "fumble" }));
  equal("E12 Storm of Unmaking's Fumble: the core raises the storm on you (H16) — 60 ft, following, your Save DC, 1 minute, rolled at the turn start",
    [stormCalls[0]?.opts.radiusFeet, stormCalls[0]?.opts.follow, stormCalls[0]?.opts.dc, stormCalls[0]?.opts.seconds, stormCalls[0]?.row.pick, stormCalls[0]?.row.strikes, stormCalls[0]?.row.follow], [60, true, 20, 60, "roll", "turnStart", true]);
  stormCalls.length = 0;
  await quiet(() => settle(st, "Storm of Unmaking", { cast: false, degree: "blunder", saveDC: 0, castPP: 9 }));
  equal("E12 …with no Save DC carried: TRG Prime's spellSaveDC, 10 + 9 PP + 5 = 24 — not the sheet's Spellcraft DC (29), nor 29 + the PP (found live twice)", [stormCalls[0]?.opts.dc, /Save DC \(24: 10 \+ the PP cast \+ your casting ability\)/.test(text(lastCard()))], [24, true]);
  equal("E12 failedCastSaveDC: the cast's own Save DC first", [A.failedCastSaveDC(st, { saveDC: 31, castPP: 9 }), A.failedCastSaveDC(st, { castPP: 20 }), A.failedCastSaveDC(st, { ppSpent: 4 })], [31, 35, 19]);
  await quiet(() => settle(st, "Storm of Unmaking", { degree: "success" }));
  equal("E12 …a success raises nothing of the module's (the core's storm row does)", stormCalls.length, 1);
  reset8b();
  const vf = makeActor("Riftcaller", { level: 9 }); vf.system.magic.casterLevelValue = 9; vf.system.magic.spellcraft = { dc: 21 };
  const bystander = makeActor("Bystander", { level: 3 });
  makeToken(vf); makeToken(bystander, { x: 100 });
  entryFor(vf, "Veilfracture", "vf1");
  nextClick = [{ x: 300, y: 300 }];
  await quiet(() => settle(vf, "Veilfracture"));
  const rift = scene.regions.find((r) => r.flags[MOD]?.[R.AREA8B_FLAG]?.key === "veilfracture");
  equal("E12 Veilfracture: a rift 40 ft wide (caster level 9), bound to its cast", [rift?.shapes[0].width, rift?.flags[MOD][R.AREA8B_FLAG].castBound], [800, true]);
  vf.flags[SYS].activeSpells = [];
  await A.onWorldTimeB8b();
  ok("E12 …the sustain ends, the rift goes", !scene.regions.includes(rift));
  vf.system.magic.castingAbility = "intelligence"; vf.system.attributes.intelligence = { total: 4 };
  await quiet(() => settle(vf, "Veilfracture", { cast: false, degree: "blunder", saveDC: 0, castPP: 10 }));
  ok("E12 a Blunder's Save DC: 10 + 10 PP + 4 = 24, not the sheet's 21 (found live: 35 for a Save DC of 25)", vf.flags[MOD].veilfracture8b.dc === 24 && /Save DC \(24: 10 \+ the PP cast/.test(msgText()));
  ok("E12 a Blunder: the GM's card", /data-ea8b="veilfracturePull"/.test(msgText()));
  canvas.tokens.controlled = [bystander.token];
  rolls.push(3);
  degreeFor.set("Riftcaller", "success"); degreeFor.set("Bystander", "fumble");
  await quiet(() => A.onCardButton8b("veilfracturePull", vf.uuid, vf.flags[MOD].veilfracture8b.id));
  equal("E12 …pressed: 1d4 = 3 (one selected), Reflex against DC 24 for both; the Fumble lost there",
    [calls.checks.filter((c) => c.type === "save").map((c) => [c.actor, c.subject, c.dc]), /lost there/.test(text(lastCard()))], [[["Riftcaller", "reflex", 24], ["Bystander", "reflex", 24]], true]);
  reset8b();
  const ac = makeActor("Necromancer", { level: 3 });
  answers.push("restore");
  await quiet(() => settle(ac, "Alter Corpse"));
  ok("E12 Alter Corpse: the use chosen, on the card", /Restore/.test(text(lastCard())));
}

/* E13 the writer (0.12.0): one tab of the GM account writes */
{
  reset8b();
  let elected = true;
  W.setCoreElection(() => elected);
  equal("E13 the active GM's elected tab acts; the same account's other tab does not, but may press a button", [W.isActingGM(), (elected = false, W.isActingGM()), W.isActiveGMAccount()], [true, false, true]);
  const r1 = makeActor("Zoner", { level: 5 }); makeToken(r1);
  const [zone] = await scene.createEmbeddedDocuments("Region", [{ name: "Z", shapes: [{ type: "circle", x: 50, y: 50, radius: 100 }], flags: { [MOD]: { [R.AREA8B_FLAG]: { key: "concordOfStone", casterUuid: r1.uuid, centre: { x: 50, y: 50 }, radius: 60, side: 1, until: null } } } }]);
  equal("E13 …so the other tab writes no membership", await A.syncMembers(zone), 0);
  elected = true;
  equal("E13 …the elected tab does", await A.syncMembers(zone), 1);
  W.setCoreElection(null);
  game.user.isGM = false;
  equal("E13 a player is never the acting GM", [W.isActingGM(), W.isActiveGMAccount()], [false, false]);
  game.user.isGM = true;
  const sites = ["effects-clock.mjs", "block1-automations.mjs", "block2-automations.mjs", "block3-automations.mjs", "block3b-automations.mjs", "block4-automations.mjs", "block5b-automations.mjs", "block5c-automations.mjs", "block6b1-automations.mjs", "block7-automations.mjs", "block8a-automations.mjs", "block8b-automations.mjs"];
  equal("E13 every module writer asks it: no file keeps its own account-only test", sites.filter((f) => /activeGM === (globalThis\.)?game\.user|activeGM !== game\.user|activeGM\?\.id !== game\.user\.id|activeGM\.id !== game\.user\.id/.test(read("module", f))), []);
  ok("E13 …each imports it", sites.filter((f) => f !== "block8b-automations.mjs").every((f) => /import \{ isActingGM(, isActiveGMAccount)? \} from "\.\/writer\.mjs";/.test(read("module", f))));
  ok("E13 Block 8a's bind button takes any tab of the GM's account", /if \(globalThis\.game\?\.user\?\.isGM && !isActiveGMAccount\(\)\) return warn\("Eldritch Arts: another GM is the acting GM; that GM binds the creature\."\);/.test(read("module", "block8a-automations.mjs")));
  ok("E13 the entry script reads the core's election at init", /Hooks\.once\("init", \(\) => \{ loadCoreElection\(\); \}\);/.test(read("scripts", "eldritch-arts.mjs")));
}

/* E14 the review's fixes: a Region's creation, one sync at a time, a cast ended, the socket */
{
  reset8b();
  const pri = makeActor("Warder", { level: 9 }), ally = makeActor("Shieldmate", { level: 3 });
  makeToken(pri, { x: 0, disposition: 1 }); makeToken(ally, { x: 100, disposition: 1 });
  const rec = { key: "concordOfStone", castId: "", until: null, dr: 5, side: 1, members: {}, centre: { x: 50, y: 50 }, radius: 120, casterUuid: pri.uuid, sceneId: scene.id };
  const [zone] = await scene.createEmbeddedDocuments("Region", [{ name: "Concord (a player's cast)", shapes: [{ type: "circle", x: 50, y: 50, radius: 2400 }], flags: { [MOD]: { [R.AREA8B_FLAG]: rec } } }]);
  const db = (a) => a.effects.filter((e) => e.flags[MOD]?.[R.AURA8B_FLAG] === zone.id).length;
  await A.onRegionCreatedB8b(zone);
  equal("E14 a membership Region created (a player's cast, whose own sync does nothing): the acting GM's createRegion hook gives its first members", [db(pri), db(ally)], [1, 1]);
  for (const a of [pri, ally]) a.effects = [];
  // A SLOW SERVER: each creation lands a tick later, so overlapping syncs would each pass the check.
  const slow = (a) => { const orig = a.createEmbeddedDocuments; a.createEmbeddedDocuments = async (t, d) => { await tick(); await tick(); return orig(t, d); }; return () => { a.createEmbeddedDocuments = orig; }; };
  const undo = [slow(pri), slow(ally)];
  await Promise.all([A.syncMembers(zone), A.syncMembers(zone), A.onRegionCreatedB8b(zone)]);
  undo.forEach((u) => u());
  equal("E14 three syncs at once, on a slow server: one effect each (one at a time per Region)", [db(pri), db(ally)], [1, 1]);
  W.setCoreElection(() => false);
  for (const a of [pri, ally]) a.effects = [];
  equal("E14 …not on a tab that is not the acting GM's", [await A.onRegionCreatedB8b(zone), db(pri)], [0, 0]);
  W.setCoreElection(null);
  const bound = { key: "leylineAnchor", castBound: true, castId: "cast9", until: null, members: {}, centre: { x: 0, y: 0 }, radius: 300, casterUuid: pri.uuid, sceneId: scene.id };
  const [anchor] = await scene.createEmbeddedDocuments("Region", [{ name: "Anchor", shapes: [{ type: "circle", x: 0, y: 0, radius: 6000 }], flags: { [MOD]: { [R.AREA8B_FLAG]: bound } } }]);
  pri.flags[SYS].activeSpells = [{ id: "cast9", name: "Leyline Anchor" }];
  ok("E14 a cast-bound Region stands while its cast does", A.areas8b("leylineAnchor").includes(anchor) && A.castStands(bound));
  equal("E14 an actor update that leaves its cast standing removes nothing", await A.onActorUpdatedB8b(pri, { flags: { [SYS]: { activeSpells: pri.flags[SYS].activeSpells } } }), 0);
  pri.flags[SYS].activeSpells = [];
  ok("E14 its cast dismissed: the Region no longer counts at once", !A.areas8b("leylineAnchor").includes(anchor) && !A.castStands(bound));
  equal("E14 …an unrelated update removes nothing; the activeSpells update removes it (the acting GM)", [await A.onActorUpdatedB8b(pri, { name: "x" }), await A.onActorUpdatedB8b(pri, { flags: { [SYS]: { activeSpells: [] } } }), scene.regions.includes(anchor), scene.regions.includes(zone)], [0, 1, false, true]);
  ally.conditions.rawValues.set("weakened", 3); ally.conditions.rawValues.set("dazed", 1);
  equal("E14 the socket takes no \"reduce\" any more: a condition is lowered only by its owner's own choice", [await A.onBlock8bSocket({ action: "eaBlock8b", kind: "reduce", actorUuid: ally.uuid, key: "weakened", by: 3 }), ally.getConditionValue("weakened")], [false, 3]);
  answers.push("weakened");
  await quiet(() => A.INTERNALS_B8B.OWNER_TASKS.sunCondition(ally, { conditions: ["weakened", "dazed"], by: 2, label: "Sun’s Benediction", askId: "ask1" }));
  answers.push("weakened");
  await quiet(() => A.INTERNALS_B8B.OWNER_TASKS.sunCondition(ally, { conditions: ["weakened", "dazed"], by: 2, label: "Sun’s Benediction", askId: "ask1" }));
  equal("E14 Sun's owner task: the creature's own condition, its choice, lowered once though answered twice", [ally.getConditionValue("weakened"), ally.getConditionValue("dazed"), answers.length], [1, 1, 0]);
  ally.conditions.rawValues.delete("dazed");
  ally.conditions.rawValues.set("sickened", 2); ally.conditions.rawValues.set("doomed", 2);
  await quiet(() => A.INTERNALS_B8B.OWNER_TASKS.sunCondition(ally, { conditions: ["sickened", "doomed"], by: 9, askId: "ask2" }));
  equal("E14 …only a printed condition (doomed, present, is not one): the one printed is lowered without a question", [ally.getConditionValue("sickened"), ally.getConditionValue("doomed"), answers.length], [0, 2, 0]);
}

{
  ok("E15 Block 7's Argent Reversal carries the sheet's Spellcraft too (found live with Mimic Spell)",
    /const modifiers = Array\.isArray\(sc\.checkModifiers\) && sc\.checkModifiers\.length \? sc\.checkModifiers : \[\{ label: "Spellcraft", value: Number\(sc\.total \?\? 0\) \|\| 0, type: "untyped" \}\];\n\s*const check = await h\(\)\.rollCheck\(\{ actor, type: "spellcraft", label: `\$\{actor\.name\} — Argent Reversal \(Spellcraft\)`, dc: int\(data\?\.dc\), modifiers \}\);/.test(read("module", "block7-automations.mjs")));
  equal("E15 spellcraftModifiers: the sheet's own, else its total", [A.spellcraftModifiers({ system: { magic: { spellcraft: { total: 7 } } } }), A.spellcraftModifiers({ system: { magic: { spellcraft: { total: 7, checkModifiers: [{ label: "X", value: 9, type: "untyped" }] } } } })], [[{ label: "Spellcraft", value: 7, type: "untyped" }], [{ label: "X", value: 9, type: "untyped" }]]);
}

/* ----------------------------------------------------------------- */
/* F — the wiring                                                      */
/* ----------------------------------------------------------------- */
{
  const script = read("scripts", "eldritch-arts.mjs");
  for (const [hook, fn] of [["trgPrimeSpellSettled", "onSpellSettledB8b"], ["updateToken", "onTokenMovedB8b"], ["updateWorldTime", "onWorldTimeB8b"], ["createRegion", "onRegionCreatedB8b"], ["updateActor", "onActorUpdatedB8b"], ["deleteRegion", "onRegionDeletedB8b"], ["deleteActiveEffect", "onEffectDeletedB8b"]]) {
    ok(`F ${fn} is wired on ${hook}`, new RegExp(`Hooks\\.on\\("${hook}", \\([^)]*\\) => \\{ ${fn}\\(`).test(script));
  }
  ok("F the card buttons and the socket are registered at ready", /Hooks\.once\("ready", \(\) => \{ registerBlock8bCards\(\); registerBlock8bSocket\(\); \}\);/.test(script));
  ok("F registration calls registerBlock8b", /registerBlock8b\(api, moduleId\);/.test(read("module", "registration.mjs")));
  const manifest = JSON.parse(read("module.json"));
  equal("F the manifest: 0.15.0 on TRG Prime 3.690.0; the entry script asks for 3.690.0", [manifest.version, manifest.relationships.systems[0].compatibility.minimum, /REQUIRED_SYSTEM = "3\.694\.0"/.test(script), manifest.download.includes("v0.17.2")], ["0.17.2", "3.694.0", true, true]);
  const packs = await import(new URL("./content/packs.mjs", import.meta.url));
  const spells = packs.PACKS.find((p) => p.name === "ea-spells").docs;
  equal("F the spells pack holds the 17 (130 in all)", [C.SPELLS_B8B.every((s) => spells.includes(s)), spells.length], [true, 130]);
  const dir = path.join(ROOT, "packs-source", "ea-spells");
  const built = fs.readdirSync(dir).map((f) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8")));
  if (process.env.EA_MUTATING !== "1") equal("F packs-source is the build (run build-packs)", C.SPELLS_B8B.every((s) => JSON.stringify(built.find((b) => b._id === s._id)?.system ?? null) === JSON.stringify(s.system) && JSON.stringify(built.find((b) => b._id === s._id)?.flags ?? null) === JSON.stringify(s.flags)), true);
  const b2 = read("module", "block2-automations.mjs");
  ok("F Block 2's table roll asks the shield once, at the top, and hands it to the rerolls and the rows", /if \(table === WILD_SURGE && depth === 0 && !shield\) \{\n\s*const \{ shieldSurge \} = await import\("\.\/block8b-automations\.mjs"\);/.test(b2) && /depth: 1, shield \}/.test(b2) && /const ctx = \{ level, text, title, expiry, source, radiusFeet, ppLost, shield \};/.test(b2) && /label: ctx\.title, shield: ctx\.shield \?\? null \}/.test(b2));
  ok("F …and its damage row lowers the DC for all and halves for allies inside", /dc: ownLevelDC\(target\) \+ int\(shield\?\.dcStep\)/.test(b2) && /if \(shielded && amount !== null\) amount = Math\.floor\(Math\.max\(0, int\(amount\)\) \/ 2\);/.test(b2));
  ok("F Block 3a's Wild Power: within an ally's shield, one roll (the two cancel)", /if \(\(await chaosShieldFor\(actor\)\)\?\.ally\) return rollTable\(actor, \{ \.\.\.common, cancels: true \}\);/.test(read("module", "block3-automations.mjs")));
  const core = readCore("module", "module-api-workflow.mjs");
  ok("F the core this needs (TRG Prime 3.687.0): placeStorm and the light circles on the module API; the ritual rules' two keys", /placeStorm: async/.test(core) && /placeLightCircles: async/.test(core) && /"partialCasts", "minSecondaries"/.test(readCore("module", "module-api.mjs")));
}

if (failures.length) {
  console.log(`verify-block8b: ${checks} checks, ${failures.length} failure(s).`);
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exitCode = 1;
} else console.log(`verify-block8b: ${checks} checks, 0 failure(s).`);
