#!/usr/bin/env node
/**
 * mutate-block3b — the mutation half of verify-block3b. Each mutation breaks
 * one reading or one wire of Block 3b's reactions; verify-block3b must fail on
 * every one. Files are restored after each run, and on any exit.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block3b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const A = f("module", "block3b-automations.mjs"), REG = f("module", "registration.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"),
  MANIFEST = f("module.json"), S = f("tools", "content", "block3-spells.mjs"), C = f("tools", "content", "block3.mjs");

const MUTATIONS = [
  // A — the readings
  { name: "Q30: the immunity never lapses", file: A, from: "  return Number(record?.[norm(hex)] ?? -Infinity) > Number(now);", to: "  return record?.[norm(hex)] !== undefined;" },
  { name: "Q30: a day's immunity", file: A, from: "export const HEX_IMMUNITY_SECONDS = 3600;", to: "export const HEX_IMMUNITY_SECONDS = 86400;" },
  { name: "the lapsed immunities are kept", file: A, from: "  const kept = Object.fromEntries(Object.entries(record ?? {}).filter(([, until]) => Number(until) > Number(now)));", to: "  const kept = { ...(record ?? {}) };" },
  { name: "Q28: a neutral token is an enemy", file: A, from: "  return (x === 1 && y === -1) || (x === -1 && y === 1);", to: "  return x !== y;" },
  { name: "Q28: a neutral token is an ally", file: A, from: "  return (x === 1 || x === -1) && x === y;", to: "  return x === y;" },
  { name: "Phase Familiar's warp is never read", file: A, from: "  return int(warpPP) >= 10\n", to: "  return false\n" },
  { name: "Phase Familiar forgets precision", file: A, from: "    : { resist: \"all\", immune: [\"precision\"], scope };", to: "    : { resist: \"all\", scope };" },
  { name: "Phase Familiar's spell cover is one packet", file: A, from: "  const scope = kind === \"spell\" || kind === \"weapon\" ? \"cast\" : \"instance\";", to: "  const scope = kind === \"weapon\" ? \"cast\" : \"instance\";" },
  { name: "Phase Familiar's strike cover is its first packet (review)", file: A, from: "  const scope = kind === \"spell\" || kind === \"weapon\" ? \"cast\" : \"instance\";", to: "  const scope = kind === \"spell\" ? \"cast\" : \"instance\";" },
  { name: "Resist Magic's spell cover is its first packet's types (review)", file: A, from: "    ? { resist: \"all\", scope: \"cast\" }", to: "    ? { resist: Array.from(ctx?.types ?? []), scope: \"cast\" }" },
  { name: "Resist Magic's other magic lasts the cast", file: A, from: "    : { resist: Array.from(ctx?.types ?? []), scope: \"instance\" };", to: "    : { resist: Array.from(ctx?.types ?? []), scope: \"cast\" };" },
  { name: "Eternity is offered on a minor critical (review)", file: A, from: "  return String(bias ?? \"normal\") !== \"disadvantage\";", to: "  return true;" },
  { name: "Eternity's worth is not asked (review)", file: A, from: "  if (!eternityWorthOffering(ctx.bias)) return null;\n", to: "" },
  { name: "Q32: a weapon's damage is magic enough", file: A, from: "  if (!ctx || ctx.kind === \"weapon\") return false;", to: "  if (!ctx) return false;" },
  { name: "Q32: any typed damage counts", file: A, from: "  return ctx.kind === \"spell\" || Boolean(ctx.magical);", to: "  return true;" },
  { name: "Q35: a creature's own critical counts", file: A, from: "  return Boolean(ctx?.target) && ctx.target !== ctx.attacker;", to: "  return Boolean(ctx?.target);" },
  // B, C — the rerolls
  { name: "Q29: an exploded die is rerolled", file: A, from: "    wants: (c) => c.succeeded && !c.exploded", to: "    wants: (c) => c.succeeded" },
  { name: "Missed Chance meets a failure", file: A, from: "    wants: (c) => c.succeeded && !c.exploded", to: "    wants: () => true" },
  { name: "Second Chance meets a success", file: A, from: "  after: (ctx) => rerollHex(ctx, { hex: \"Second Chance\", relation: allies, wants: (c) => c.failed })", to: "  after: (ctx) => rerollHex(ctx, { hex: \"Second Chance\", relation: allies, wants: () => true })" },
  { name: "Second Chance is cast at enemies", file: A, from: "relation: allies, wants: (c) => c.failed })", to: "relation: enemies, wants: (c) => c.failed })" },
  { name: "the target's immunity is not read", file: A, from: "  if (immuneTo(hexRecord(ctx.actor), hex, worldNow())) return null;\n  for (const witchToken", to: "  for (const witchToken" },
  { name: "the target is not made immune", file: A, from: "    if (!q?.result?.cast) continue;\n    await markImmune(ctx.actor, hex);", to: "    if (!q?.result?.cast) continue;" },
  { name: "the Witch rerolls her own check", file: A, from: "    if (witchToken === ctx.token || witch === ctx.actor) continue;", to: "" },
  { name: "the reach is not measured", file: A, from: "    if (!within(witchToken, ctx.token, REACH_FEET[norm(hex)])) continue;", to: "" },
  { name: "Missed Chance reaches 60 ft", file: A, from: "\"missed chance\": 30,", to: "\"missed chance\": 60," },
  { name: "a Witch not ready is asked", file: A, from: "    if (await readiness(witch, spell)) continue;", to: "" },
  { name: "Q28: a blinded Witch is ready", file: A, from: "  if (actor.hasCondition?.(\"blinded\")) return \"blinded\";", to: "" },
  { name: "the PP are not checked", file: A, from: "  if (pp && spell && int(actor.system?.resources?.pp?.value) < int(spell.system?.ppCost)) return \"not enough PP\";", to: "" },
  { name: "the core's refusal is not read", file: A, from: "  if (refused) return refused;", to: "" },
  { name: "a cast that failed still rerolls", file: A, from: "    if (!q?.result?.cast) continue;\n    await markImmune(ctx.actor, hex);\n    return { reroll: true", to: "    await markImmune(ctx.actor, hex);\n    return { reroll: true" },
  { name: "the hex is cast at nobody", file: A, from: "      data: { spellId: spell.id, targetTokenIds: [ctx.token.id] }", to: "      data: { spellId: spell.id, targetTokenIds: [] }" },
  // D — Prophetic Warning
  { name: "Q31: a check with no DC is offered", file: A, from: "    if (ctx.dc === null || ctx.dc === undefined) return null;", to: "" },
  { name: "Q31: the setting is not read", file: A, from: "    if (!promptOn()) return null;", to: "" },
  { name: "Prophetic Warning gives no advantage", file: A, from: "    return { advantage: true, label: \"Prophetic Warning\",", to: "    return { advantage: false, label: \"Prophetic Warning\"," },
  { name: "the Witch is not made immune to her own", file: A, from: "    if (!q?.result?.cast) return null;\n    await markImmune(actor, \"Prophetic Warning\");", to: "    if (!q?.result?.cast) return null;" },
  { name: "a sheet cast arms nothing", file: A, from: "  await h().addPendingModifier?.(actor, {", to: "  await (async () => null)?.(actor, {" },
  { name: "the armed advantage lasts for ever", file: A, from: "    scope: \"your next attack check, saving throw or skill check\", oneShot: true, auto: true,", to: "    scope: \"your next attack check, saving throw or skill check\", oneShot: false, auto: true," },
  { name: "a failed sheet cast still arms", file: A, from: "  if (!actor?.isOwner || norm(ctx?.spell?.name) !== \"prophetic warning\" || !ctx?.cast) return;", to: "  if (!actor?.isOwner || norm(ctx?.spell?.name) !== \"prophetic warning\") return;" },
  { name: "the offered cast arms a second advantage", file: A, from: "  if (data?.prophetic) offered.add(actor.id);", to: "" },
  // E — Phase Familiar
  { name: "the familiar's master is not found", file: A, from: "  const masterId = familiar?.system?.familiar?.masterId ?? familiar?.flags?.[MODULE_ID]?.soulbound?.masterId;", to: "  const masterId = familiar?.system?.familiar?.masterId;" },
  { name: "Phase Familiar reaches any distance", file: A, from: "  if (!famToken || !witchToken || !within(witchToken, famToken, REACH_FEET[\"phase familiar\"])) return null;", to: "  if (!famToken || !witchToken) return null;" },
  { name: "Phase Familiar's failed cast still grants", file: A, from: "  if (!q?.result?.cast) return null;\n  const answer = phaseAnswer", to: "  const answer = phaseAnswer" },
  // F — Resist Magic
  { name: "Resist Magic spends no reaction", file: A, from: "  if (!q?.result?.spent) return null;\n  const answer = resistMagicAnswer(ctx);", to: "  const answer = resistMagicAnswer(ctx);" },
  { name: "Resist Magic's answer is not used", file: A, from: "    ...answer,\n    line: ctx.kind === \"spell\"", to: "    resist: ctx.types, scope: \"instance\",\n    line: ctx.kind === \"spell\"" },
  { name: "Resist Magic without the ability", file: A, from: "  if (!owned(actor, \"Resist Magic\", [\"ability\"]) || !resistMagicApplies(ctx) || !ctx.types?.length) return null;", to: "  if (!resistMagicApplies(ctx) || !ctx.types?.length) return null;" },
  // G — Disrupting Magic
  { name: "an ally's casting is offered", file: A, from: "    if (allies(side(reactorToken), side(casterToken))) continue;", to: "" },
  { name: "Disrupting Magic reaches any distance", file: A, from: "    if (!within(reactorToken, casterToken, REACH_FEET[\"disrupting magic\"])) continue;", to: "" },
  { name: "the Dispel is not opened on the spell's PP", file: A, from: "      data: { effectValue: int(ctx.pp), dc, spellName: ctx.spell?.name ?? \"\", casterUuid", to: "      data: { effectValue: 0, dc, spellName: ctx.spell?.name ?? \"\", casterUuid" },
  { name: "the Dispel costs AP", file: A, from: "  const check = await h().resolveAction(actor, { ...dispel, apCost: \"0\" },", to: "  const check = await h().resolveAction(actor, { ...dispel }," },
  { name: "Disrupting Magic spends no reaction", file: A, from: "  if (!(await h().spendReaction?.(actor, \"Disrupting Magic\", { traits: \"Utility, Warding\" }))) return { rolled: false };", to: "" },
  { name: "the reaction is spent before the Dispel is rolled (review)", file: A, from: "  if (await h().reactionRefusal?.(actor, \"Utility, Warding\")) return { rolled: false };", to: "  if (!(await h().spendReaction?.(actor, \"Disrupting Magic\", { traits: \"Utility, Warding\" }))) return { rolled: false };" },
  { name: "Disrupting Magic ignores casting refusals (review)", file: A, from: "    if (await h().castRefusal?.(reactor, spell)) continue;\n", to: "" },
  { name: "Disrupting Magic asks its own 1 PP", file: A, from: "    if (await readiness(reactor, spell, { pp: false })) continue;", to: "    if (await readiness(reactor, spell)) continue;" },
  { name: "the first failed disrupter ends the asking (review)", file: A, from: "    said.push(`${reactor.name}'s <strong>Disrupting Magic</strong> (${esc(q.result.degree)}) fails to stop ${esc(ctx.spell?.name ?? \"the spell\")}.`);", to: "    return { stop: false, line: `${reactor.name}'s <strong>Disrupting Magic</strong> (${esc(q.result.degree)}) fails to stop ${esc(ctx.spell?.name ?? \"the spell\")}.` };" },
  { name: "a Partial dispels", file: A, from: "  return { rolled: true, degree: check.outcome.degree.label ?? degree, dispelled: [\"heroic\", \"critical\", \"success\"].includes(degree) };", to: "  return { rolled: true, degree: check.outcome.degree.label ?? degree, dispelled: degree !== \"failure\" };" },
  { name: "a dispel does not stop the cast", file: A, from: "      return { stop: true, line: said.join(\"<br>\") };", to: "      return { stop: false, line: said.join(\"<br>\") };" },
  { name: "Prophetic Warning is cast at the user's targets (live)", file: A, from: "      data: { spellId: spell.id, targetTokenIds: ctx.token?.id ? [ctx.token.id] : [], prophetic: true }", to: "      data: { spellId: spell.id, targetTokenIds: [], prophetic: true }" },
  { name: "an untrained creature is asked to disrupt (live)", file: A, from: "    if (!canDispel(reactor)) continue;\n", to: "" },
  { name: "the ranks are not read", file: A, from: "  if (int(actor?.system?.skills?.powerManipulation?.ranks) >= 1) return true;", to: "" },
  { name: "a disabled effect's exemption counts", file: A, from: "...Array.from(actor?.appliedEffects ?? []).filter((e) => !e?.disabled)]", to: "...Array.from(actor?.appliedEffects ?? [])]" },
  { name: "any untrained action exempts Dispel", file: A, from: "    return keys.map((k) => String(k ?? \"\").trim().toLowerCase()).includes(\"dispel\");", to: "    return keys.length > 0 && Boolean(declared);" },
  { name: "a Fixated creature is asked to disrupt (review)", file: A, from: "    if (reactor.hasCondition?.(\"fixated\")) continue;\n", to: "" },
  { name: "the self token is the asker's only (review)", file: A, from: "    const own = data?.prophetic ? actor.getActiveTokens?.()?.[0]?.id ?? null : null;", to: "    const own = null;" },
  { name: "every reaction cast is aimed at the caster", file: A, from: "    const own = data?.prophetic ? actor.getActiveTokens?.()?.[0]?.id ?? null : null;", to: "    const own = actor.getActiveTokens?.()?.[0]?.id ?? null;" },
  // K — the hour's immunity on a creature this client does not own (review)
  { name: "an unowned creature is written here (review)", file: A, from: "    if (actor.isOwner) {\n      await actor.setFlag", to: "    if (true) {\n      await actor.setFlag" },
  { name: "the GM is not asked", file: A, from: "    game.socket?.emit?.(SOCKET, { action: \"hexImmunity\", actorUuid: actor.uuid, hex: String(hex) });", to: "" },
  { name: "no GM is not said", file: A, from: "    if (!game?.users?.activeGM) {", to: "    if (false) {" },
  { name: "any client writes the request", file: A, from: "  if (!isActingGM()) return false;\n  const actor = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(data.actorUuid);", to: "  const actor = await (globalThis.foundry?.utils?.fromUuid ?? globalThis.fromUuid)?.(data.actorUuid);" } /* RE-ANCHORED 0.12.0 (the writer) */,
  { name: "any request is written", file: A, from: "  if (data?.action !== \"hexImmunity\" || !data.actorUuid || !data.hex) return false;", to: "" },
  { name: "the listener is never set", file: SCRIPT, from: "Hooks.once(\"ready\", () => registerBlock3bSocket());", to: "" },
  { name: "the listener is on another channel", file: A, from: "export const SOCKET = `module.${MODULE_ID}`;", to: "export const SOCKET = `system.${MODULE_ID}`;" },
  // H — Eternity Resilience
  { name: "Conviction past the round's limit", file: A, from: "  if (!state?.ok) return null;", to: "" },
  { name: "Eternity Resilience without the ability", file: A, from: "  if (!eternityApplies(ctx) || !owned(actor, \"Eternity Resilience\", [\"ability\"])) return null;", to: "  if (!eternityApplies(ctx)) return null;" },
  // J — registration, setting, cards, versions
  { name: "Missed Chance is not registered", file: A, from: "  api.registerCheckReaction?.(\"missedChance\", missedChance, moduleId);", to: "" },
  { name: "the steps are not registered", file: A, from: "  api.registerReactionStep?.(CAST_STEP, castStep, moduleId);", to: "" },
  { name: "the setting is per client again (review)", file: A, from: "    scope: \"world\", config: true, type: Boolean, default: true", to: "    scope: \"client\", config: true, type: Boolean, default: true" },
  { name: "Block 3b is not registered", file: REG, from: "  registerBlock3b(api, moduleId);", to: "" },
  { name: "the setting is never registered", file: SCRIPT, from: "Hooks.once(\"init\", () => { registerAreaTypes(); registerBlock3bSettings(); });", to: "Hooks.once(\"init\", () => { registerAreaTypes(); });" },
  { name: "the sheet cast is not heard", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB3b(ctx)", to: "Hooks.on(\"trgPrimeSpellSettledX\", (ctx) => { onSpellSettledB3b(ctx)" },
  { name: "a card still waits", file: S, from: "    text: \"*Automated (0.6.0, TRG Prime 3.681.0):* when an enemy within 30 feet hits", to: "    text: \"*Waits for Block 3b (TRG Prime 3.681.0):* when an enemy within 30 feet hits" },
  { name: "Resist Magic's card still waits", file: C, from: "${note(\"*Automated (0.6.0, TRG Prime 3.681.0):* when a spell (cast from anything)", to: "${note(\"*Waits for Block 3b (TRG Prime 3.681.0):* when a spell (cast from anything)" },
  { name: "the system version is not required", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.680.0\";" },
  { name: "the module version is not raised", file: MANIFEST, from: "\"version\": \"0.17.2\"", to: "\"version\": \"0.6.0\"" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });
function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block3b.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}
const results = [];
try {
  if (!run()) { console.error("mutate-block3b: verify-block3b already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block3b: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block3b: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
