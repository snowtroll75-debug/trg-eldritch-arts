#!/usr/bin/env node
/**
 * mutate-block2b — the mutation half of verify-block2b. Each mutation breaks
 * one printed number, one reading or one wire of Block 2b; verify-block2b
 * must fail on every one. Files are restored after each run, and on any exit.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block2b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const ACT = f("module", "block2b-actions.mjs"), A = f("module", "block2b-automations.mjs"), REG = f("module", "registration.mjs"),
  SCRIPT = f("scripts", "eldritch-arts.mjs"), MANIFEST = f("module.json");

const MUTATIONS = [
  // A — the book
  { name: "Borrow Spell is untrained", file: ACT, from: "    proficiency: \"trained\",\n", to: "" },
  { name: "Borrow Spell is Moderate", file: ACT, from: "    difficulty: \"easy\",", to: "    difficulty: \"medium\"," },
  { name: "a circle is Hard", file: ACT, from: "    difficulty: \"medium\",", to: "    difficulty: \"hard\"," },
  { name: "the trickery check is against Sense Motive DC", file: ACT, from: "    against: \"skillDC:deception\",", to: "    against: \"skillDC:senseMotive\"," },
  { name: "the trickery's Partial is dropped", file: ACT, from: "      partial: \"The target identifies the tradition of the spell.\",\n", to: "" },
  { name: "the material table's 7 PP costs 500", file: A, from: "[0, 30, 60, 100, 150, 250, 400, 600, 900,", to: "[0, 30, 60, 100, 150, 250, 400, 500, 900," },
  // B — the pure rules
  { name: "THE GAP: Divinity spells have no ritual skill", file: A, from: "divinity: \"religion\", ", to: "" },
  { name: "a Highmagic spell has only its own skill", file: A, from: "  if (highMagicSpell) return [\"arcana\", \"religion\", \"occultism\", \"nature\"];\n", to: "" },
  { name: "THE DEFECT: an untrained primary may lead", file: A, from: "  const trained = keys.filter((k) => int(skills?.[k]?.ranks) > 0);", to: "  const trained = keys.slice();" },
  { name: "the worst trained skill is chosen", file: A, from: "  return trained.reduce((a, b) => (int(skills[b]?.total) > int(skills[a]?.total) ? b : a));", to: "  return trained.reduce((a, b) => (int(skills[b]?.total) < int(skills[a]?.total) ? b : a));" },
  { name: "beyond 20 PP is paid as 20", file: A, from: "n >= MATERIAL_COSTS.length ? null : MATERIAL_COSTS[n]", to: "n >= MATERIAL_COSTS.length ? MATERIAL_COSTS[20] : MATERIAL_COSTS[n]" },
  { name: "communal is not +50%", file: A, from: "  const total = Math.ceil(Math.max(0, int(pp)) * 1.5);", to: "  const total = Math.max(0, int(pp));" },
  { name: "communal rounds down", file: A, from: "  const total = Math.ceil(Math.max(0, int(pp)) * 1.5);", to: "  const total = Math.floor(Math.max(0, int(pp)) * 1.5);" },
  { name: "the remainder is lost", file: A, from: "  return Array.from({ length: n }, (_, i) => base + (i < total % n ? 1 : 0));", to: "  return Array.from({ length: n }, () => base);" },
  { name: "rare materials are not held to −2…−10", file: A, from: "  if (rare) push(\"Rare or consecrated materials\", -Math.max(2, rare));", to: "  if (rare) push(\"Rare or consecrated materials\", -rare);" },
  { name: "the ground's sign is reversed", file: A, from: "  if (form.ground === \"aligned\") push(\"Ground aligned with the creature's tradition\", -4);", to: "  if (form.ground === \"aligned\") push(\"Ground aligned with the creature's tradition\", 4);" },
  { name: "a true name eases the circle by 2", file: A, from: "  if (form.trueName) push(\"You know its True Name\", -5);", to: "  if (form.trueName) push(\"You know its True Name\", -2);" },
  { name: "assistants are not capped at −4", file: A, from: "  push(\"Secondary casters assisting\", -Math.min(4, Math.max(0, int(form.assistants))));", to: "  push(\"Secondary casters assisting\", -Math.max(0, int(form.assistants)));" },
  { name: "meticulous care takes no longer", file: A, from: "  return care === \"meticulous\" ? base * 2 : base;", to: "  return base;" },
  { name: "Void Chalk changes nothing", file: A, from: "Math.max(3600 * Math.max(1, int(casterLevel)), voidChalk ? 86400 : 0);", to: "3600 * Math.max(1, int(casterLevel));" },
  { name: "a Critical circle gives +2", file: A, from: "CIRCLE_CHECK = Object.freeze({ critical: 4,", to: "CIRCLE_CHECK = Object.freeze({ critical: 2," },
  { name: "Q8 undone: any compendium's spell is Eldritch Arts'", file: A, from: "  return String(item._stats?.compendiumSource ?? item.sourceId ?? \"\").startsWith(`Compendium.${MODULE_ID}.`);", to: "  return String(item._stats?.compendiumSource ?? item.sourceId ?? \"\").startsWith(\"Compendium.\");" },
  // C — the ritual
  { name: "the variants are offered to anyone", file: A, from: "  return skill ? VARIANTS.map((v) => ({ ...v })) : [];", to: "  return VARIANTS.map((v) => ({ ...v }));" },
  { name: "the primary is offered as their own secondary", file: A, from: "  const seen = new Set([actor?.id]);", to: "  const seen = new Set();" },
  { name: "the Ritual Censor's −1 is lost", file: A, from: "    out.dcRows.push({ label: \"Ritual Censor\", value: -1 });\n", to: "" },
  { name: "the Ritualist weapon's −1 is lost", file: A, from: "  if (form.eaRitualist && weapon) out.dcRows.push({ label: `${weapon.name} (Ritualist)`, value: -1 });", to: "" },
  { name: "0.16.1: the Chalkboard adds to a variant's skill check", file: A, from: "    if (variant) goodsLine(\"Runestone Chalkboard\");\n    else out.modifiers", to: "    out.modifiers" },
  { name: "0.16.1: the Bowl adds to a variant's skill check", file: A, from: "    if (variant) goodsLine(\"Bloodscribe’s Bowl\");\n    else out.modifiers", to: "    out.modifiers" },
  { name: "the Chalkboard is an item bonus (no stacking with the Bowl)", file: A, from: "out.modifiers.push({ label: \"Runestone Chalkboard\", value: 1, type: \"untyped\" });", to: "out.modifiers.push({ label: \"Runestone Chalkboard\", value: 1, type: \"item\" });" },
  { name: "Q13 undone: a primary Ritual Expert counts once", file: A, from: "  const primaryExpert = countsAsTwo(actor) ? 1 : 0;", to: "  const primaryExpert = 0;" },
  { name: "the variant's DC is not Very Hard", file: A, from: "  out.dc = { value: h().levelDC(L) + 5,", to: "  out.dc = { value: h().levelDC(L)," },
  { name: "communal goes ahead with no one to pay", file: A, from: "  if (variant === \"communal\" && !secondaries.length) return", to: "  if (false) return" },
  { name: "material beyond the table goes ahead", file: A, from: "  if (variant === \"material\" && materialCost(pp) === null) return", to: "  if (false) return" },
  { name: "the plan is not kept", file: A, from: "  await setPlan(actor, { variant, secondaries: secondaries.map((a) => a.uuid), spell: spell?.uuid ?? \"\", at: now() }, RITUAL_FLAG);", to: "" },
  { name: "M30 undone: a Ritual spell is capped", file: A, from: "export const ritualLiftsCap = ({ spell } = {}) => isEldritchArtsSpell(spell) && hasTrait(spell?.system, \"ritual\");", to: "export const ritualLiftsCap = () => false;" },
  { name: "Q8 undone: a Ritual spell may be cast normally", file: A, from: "  if (ritual || !isEldritchArtsSpell(spell) || !hasTrait(spell?.system, \"ritual\")) return null;", to: "  return null;" },
  { name: "THE DEFECT: vital damage is reduced by defences", file: A, from: "type: \"essence\", ignoreDefences: true });", to: "type: \"essence\" });" },
  { name: "vital: the secondaries take d8 too", file: A, from: "    for (const s of secondaries) await hit(s, \"d4\");", to: "    for (const s of secondaries) await hit(s, \"d8\");" },
  { name: "material: the Success's cost whatever the degree", file: A, from: "    const gp = materialCost(pp);", to: "    const gp = materialCost(pp * 2);" },
  { name: "a short purse is debited", file: A, from: "lines.push(line(paid.paid ?", to: "lines.push(line(true ?" },
  { name: "communal takes more than a secondary has", file: A, from: "      const take = Math.min(have, shares[i]);", to: "      const take = shares[i];" },
  { name: "another module's variant is paid for", file: A, from: "  if (String(ctx.ritualVariant ?? \"\").startsWith(`${RULES_KEY}:`)) {", to: "  if (ctx.ritualVariant) {" },
  // D — circles, true names, trickery, borrow
  { name: "the circle's rows do not move the DC", file: A, from: "  const dc = h().levelDC(level) + rows.reduce((s, r) => s + r.value, 0);", to: "  const dc = h().levelDC(level);" },
  { name: "an old circle stays beside the new", file: A, from: "  for (const old of Array.from(actor.effects ?? []).filter((e) => e.getFlag?.(MODULE_ID, \"circle\"))) await old.delete();", to: "" },
  { name: "the circle lasts a minute", file: A, from: "    expiry: forSeconds(seconds)\n", to: "    expiry: forSeconds(60)\n" },
  { name: "every spell takes the circle's bonus", file: A, from: "  if (!hasTrait(spellData, \"summons\")) return null;\n  const e = circleEffect(actor);", to: "  const e = circleEffect(actor);" },
  { name: "the circle's bonus is untyped", file: A, from: "value, type: \"circumstance\" }] : [], lines };", to: "value, type: \"untyped\" }] : [], lines };" },
  { name: "Q12 undone: Ward Twine adds nothing", file: A, from: "    const dc = (c?.degree === \"critical\" ? 2 : 0) + (c?.wardTwine ? 1 : 0);\n    if (!dc) return null;", to: "    const dc = (c?.degree === \"critical\" ? 2 : 0);\n    if (!dc) return null;" },
  { name: "the binding is a tick, not required", file: A, from: "c.wardTwine ? \"Ward Twine +1\" : \"\"].filter(Boolean).join(\"; \"), required: true };", to: "c.wardTwine ? \"Ward Twine +1\" : \"\"].filter(Boolean).join(\"; \"), required: false };" },
  { name: "a true name is +2", file: A, from: "  apply: () => ({ saveDC: 4,", to: "  apply: () => ({ saveDC: 2," },
  { name: "a true name is offered on any spell", file: A, from: "  offer: ({ spellData, innate, itemCast } = {}) => (innate || itemCast || !hasTrait(spellData, \"summons\") ? null", to: "  offer: ({ spellData, innate, itemCast } = {}) => (innate || itemCast ? null" },
  { name: "THE DEFECT: a creature that failed its save is made hostile", file: A, from: "  const saved = (ctx.saveResults ?? []).filter((r) => r.saved && r.target);", to: "  const saved = (ctx.saveResults ?? []).filter((r) => r.target);" },
  { name: "hostility without the name invoked", file: A, from: "  if ((ctx.castOptions ?? []).includes(\"truename\")) await trueNameHostility(actor, ctx);", to: "  await trueNameHostility(actor, ctx);" },
  { name: "Spell Trickery is +1", file: A, from: "    return { castingDC: 2, label: \"Spell Trickery\",", to: "    return { castingDC: 1, label: \"Spell Trickery\"," },
  { name: "Spell Trickery is offered on a ritual's casting", file: A, from: "  offer: ({ ritual, innate, itemCast } = {}) => (ritual || innate || itemCast ? null", to: "  offer: ({ ritual, innate, itemCast } = {}) => (innate || itemCast ? null" },
  { name: "anyone may borrow", file: A, from: "  if (!(await h().keepsSpellbook(actor))) return", to: "  if (false) return" },
  { name: "a known spell is offered to borrow", file: A, from: " && !known.has(norm(i.name)) && !locks.has(norm(i.name));", to: " && !locks.has(norm(i.name));" },
  { name: "the lender is never asked for", file: A, from: "  const lenderId = lenders.length === 1 ? lenders[0].id : await h().chooseFromList(", to: "  const lenderId = lenders[0].id ?? await h().chooseFromList(" },
  { name: "Borrow's DC is not the learning DC", file: A, from: "  const dc = await h().learnSpellDC(spell);", to: "  const dc = 20;" },
  { name: "a borrowed spell arrives prepared", file: A, from: "    data.system = { ...data.system, prepared: false, innate: false };", to: "    data.system = { ...data.system, prepared: true, innate: false };" },
  { name: "a borrowed spell eats the free ladder", file: A, from: "spellBookPick: true, learnedExtra: true,", to: "spellBookPick: true, learnedExtra: false," },
  { name: "a failure bars nothing", file: A, from: "  await actor.setFlag(MODULE_ID, BORROW_FLAG, locks);", to: "" },
  { name: "the borrowed spell stays after a new day", file: A, from: "  if (borrowed.length) await actor.deleteEmbeddedDocuments(\"Item\", borrowed.map((i) => i.id));", to: "" },
  { name: "the bar never lifts", file: A, from: "  if (borrowLocks(actor).length) await actor.unsetFlag(MODULE_ID, BORROW_FLAG);", to: "" },
  // The review's fixes (2 November 2026)
  { name: "REVIEW: the incense is free", file: A, from: "    if (int(await h().goldOf(actor)) < 5) return", to: "    if (false) return" },
  { name: "REVIEW: the incense is never taken", file: A, from: "  const paid = await h().deductGold(actor, 5);", to: "  const paid = { paid: true };" },
  // 0.13.2 (Graham, 13 Nov 2026): taken when the rite is settled, not when it is prepared.
  { name: "0.13.2: the incense taken at preparation again", file: A, from: "      await actor.setFlag(MODULE_ID, CENSOR_FLAG, { spell: spell?.uuid ?? \"\", at: now() });", to: "      await actor.setFlag(MODULE_ID, CENSOR_FLAG, { spell: spell?.uuid ?? \"\", at: now() }); await h().deductGold(actor, 5);" },
  { name: "0.13.2: the Censor never marked", file: A, from: "    if (burning) {", to: "    if (false) {" },
  { name: "0.13.2: a stale mark not cleared by a ritual without the Censor", file: A, from: "    } else if (actor?.getFlag?.(MODULE_ID, CENSOR_FLAG)) {", to: "    } else if (false) {" },
  { name: "0.13.2: the mark kept after settling (paid twice)", file: A, from: "  await actor.unsetFlag(MODULE_ID, CENSOR_FLAG);\n  if (String(mark.spell", to: "  if (String(mark.spell" },
  { name: "0.13.2: another spell's rite takes it", file: A, from: "  if (String(mark.spell ?? \"\") !== String(spell?.uuid ?? \"\")) return { lines: [] };", to: "" },
  { name: "0.13.2: a variant's Censor not marked", file: A, from: "  await setPlan(actor, { variant, secondaries: secondaries.map((a) => a.uuid), spell: spell?.uuid ?? \"\", at: now() }, RITUAL_FLAG);\n  await markIncense();", to: "  await setPlan(actor, { variant, secondaries: secondaries.map((a) => a.uuid), spell: spell?.uuid ?? \"\", at: now() }, RITUAL_FLAG);" },
  { name: "0.13.2: a short purse at the rite reported as paid", file: A, from: "  return { lines: [paid?.paid\n", to: "  return { lines: [true\n" },
  { name: "0.13.2: the settling not registered", file: REG, from: "liftsCap: ritualLiftsCap, settled: ritualSettled }", to: "liftsCap: ritualLiftsCap }" },
  { name: "REVIEW: Ritual Experts are a free number", file: A, from: "  const experts = Math.max(0, Math.min(int(secondaryCount), int(form.eaRitualExperts)));", to: "  const experts = Math.max(0, Math.min(6, int(form.eaRitualExperts)));" },
  { name: "REVIEW: a secondary entered need not be ticked", file: A, from: "  if ((variant === \"vital\" || variant === \"communal\") && secondaries.length !== int(secondaryCount)) {", to: "  if (false) {" },
  { name: "REVIEW: the purse is checked after the roll", file: A, from: "    if (have < need) return { ...out, refused: `the material sacrifice", to: "    if (false) return { ...out, refused: `the material sacrifice" },
  { name: "REVIEW: another's PP may be promised", file: A, from: "    if (notMine.length) return", to: "    if (false) return" },
  { name: "REVIEW: the secondaries' PP are not counted first", file: A, from: "    if (have < need) return { ...out, refused: `the communal offering", to: "    if (false) return { ...out, refused: `the communal offering" },
  { name: "REVIEW: a refunded cast still pays", file: A, from: "    if (ctx.refunded) await clearPlan(actor, RITUAL_FLAG);\n    else await paySubstitute(actor, ctx);", to: "    await paySubstitute(actor, ctx);" },
  { name: "REVIEW: a specialist spell has no tradition skill", file: A, from: "const ritualTraditionData = (actor, spellData) => (String(spellData?.tradition ?? \"\").trim() ? spellData : { ...spellData, tradition: actor?.system?.magic?.tradition ?? \"\" });", to: "const ritualTraditionData = (actor, spellData) => spellData;" },
  { name: "REVIEW: a monster's spell-like may be borrowed", file: A, from: "!isBorrowed(i) && !i.system?.innate && ", to: "!isBorrowed(i) && " },
  { name: "REVIEW: an item's spell may be borrowed", file: A, from: " && !i.flags?.[SYSTEM_ID]?.itemCast && ", to: " && " },
  { name: "REVIEW: anyone lends", file: A, from: "    if (await h().keepsSpellbook(a)) lenders.push(a);", to: "    lenders.push(a);" },
  { name: "REVIEW: the copy stays innate", file: A, from: "    data.system = { ...data.system, prepared: false, innate: false };", to: "    data.system = { ...data.system, prepared: false };" },
  { name: "REVIEW: the lender's signature comes along", file: A, from: "    for (const k of [\"signatureSpell\", \"spellEffectRune\", \"grantedBy\", \"itemCast\", \"bookOfNotationsPick\"]) delete own[k];", to: "" },
  // E — the wiring
  { name: "the ritual rules are not registered", file: REG, from: "  api.registerRitualRules?.(RULES_KEY,", to: "  void (RULES_KEY," },
  // From 0.8.0 Block 5's Masked Caster re-registers this key, wrapping Block 2b's option, so removing
  // Block 2b's line alone leaves the key; Block 2b's registration is held by its key instead.
  { name: "Block 2b registers Spell Trickery as something else", file: REG, from: "  api.registerCastOption?.(\"spellTrickery\", spellTrickeryOption, moduleId);\n", to: "  api.registerCastOption?.(\"spellTricks\", spellTrickeryOption, moduleId);\n" },
  { name: "the settled casting is not heard", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB2b(ctx)", to: "Hooks.on(\"trgPrimeSpellSettledX\", (ctx) => { onSpellSettledB2b(ctx)" },
  { name: "the module still expects 3.678.0", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.678.0\";" },
  { name: "the manifest's version is 0.3.0", file: MANIFEST, from: "\"version\": \"0.17.2\",", to: "\"version\": \"0.3.0\"," }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block2b.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block2b: verify-block2b already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block2b: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block2b: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
