#!/usr/bin/env node
/**
 * mutate-block9b — the mutation half of verify-block9b. Each mutation breaks
 * one printed number, one ruling, one reading or one wire of Block 9b
 * (0.14.0: the 34 runes and the 9 specific items); verify-block9b must fail
 * on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block9b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "block9b-rules.mjs"), A = f("module", "block9b-automations.mjs"), A9 = f("module", "block9a-automations.mjs"), C = f("tools", "content", "block9b.mjs"),
  SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), MANIFEST = f("module.json");

const MUTATIONS = [
  // A — the book
  { name: "Aegisflow II at level 15", file: R, from: "tiers: T([8, 4200], [14, 36000]),", to: "tiers: T([8, 4200], [15, 36000])," },
  { name: "Arcanum Seal III's price", file: R, from: "tiers: T([5, 1250], [10, 8000], [15, 55000]),", to: "tiers: T([5, 1250], [10, 8000], [15, 50000])," },
  { name: "Comfort's level", file: R, from: "on: [\"armour\"], traits: \"Alteration, Invested\", level: 5, price: 1250,", to: "on: [\"armour\"], traits: \"Alteration, Invested\", level: 6, price: 1250," },
  { name: "Wildbane's shield price", file: R, from: "level: 11, armourPrice: 11000, shieldPrice: 7700,", to: "level: 11, armourPrice: 11000, shieldPrice: 7000," },
  { name: "Mindpiercer IV's price", file: R, from: "[14, 25000], [18, 130000]),", to: "[14, 25000], [18, 120000])," },
  { name: "Luminous's shield prices", file: R, from: "shieldPrices: [550, 1400, 3000],", to: "shieldPrices: [550, 1400, 4200]," },
  // B — what they declare
  { name: "Aegisflow II shares half", file: R, from: "declares: { uncoveredDR: { share: [0.5, 1] } },", to: "declares: { uncoveredDR: { share: [0.5, 0.5] } }," },
  { name: "Astral Echoes on a 66 (UM 66 or 100)", file: R, from: "exceptFaces: [66, 100] } },", to: "exceptFaces: [100] } }," },
  { name: "Binding Sigils' penalties as bonuses", file: R, from: "declares: { controlSaveModifier: [-2, -4, -6] },", to: "declares: { controlSaveModifier: [2, 4, 6] }," },
  { name: "Bound Circle against conjured only (Q197)", file: R, from: "when: { sourceTraits: [\"conjured\", \"summoned\"] } }] },", to: "when: { sourceTraits: [\"conjured\"] } }] }," },
  { name: "Ley Binding against every attack", file: R, from: "when: { attackKinds: [\"spell\"] } }] },", to: "when: { attackKinds: [\"spell\", \"weapon\"] } }] }," },
  { name: "Comfort without its Max Dex", file: R, from: "declares: { maxDexBonus: 1, sleepAdvantage: true },", to: "declares: { sleepAdvantage: true }," },
  { name: "Soul Warding resists force", file: R, from: "declares: { resistances: [\"essence\"] },", to: "declares: { resistances: [\"force\"] }," },
  { name: "Swiftbind's full suit +2", file: R, from: "declares: { donAP: { light: 1, medium: 2, heavy: 3, fullExtra: 1 } },", to: "declares: { donAP: { light: 1, medium: 2, heavy: 3, fullExtra: 2 } }," },
  { name: "Aetherfang bypasses immunity's word too", file: R, from: "declares: { ignoreResistance: [\"bludgeoning\", \"piercing\", \"slashing\", \"physical\"] },", to: "declares: { ignoreResistance: [\"piercing\", \"slashing\"] }," },
  { name: "Gravitas's FDC +1", file: R, from: "declares: { fumbleDCModifier: 2 },", to: "declares: { fumbleDCModifier: 1 }," },
  { name: "Summoner's Brand +1 control level", file: R, from: "      controlLevelBonus: 2,", to: "      controlLevelBonus: 1," },
  { name: "Pyrebrand's tiers as d6", file: R, from: "energy: { type: \"fire\", tiers: [{ dice: \"1d4\" }, { dice: \"2d4\" }, { dice: \"3d4\" }] },", to: "energy: { type: \"fire\", tiers: [{ dice: \"1d6\" }, { dice: \"2d6\" }, { dice: \"3d6\" }] }," },
  { name: "Sanguine on any melee weapon", file: R, from: "usage: { melee: true, damage: [\"slashing\"], text: \"any slashing melee weapon\" },", to: "usage: { melee: true, text: \"any slashing melee weapon\" }," },
  { name: "Leybound's die not asked of the module", file: A, from: "    if (upper === \"LEYBOUND\") reg.declares = { ...reg.declares, extraBaseDie: { when: leyboundWhen } };", to: "" },
  // C — the rules
  { name: "Aetherfang: a minor critical rolls nothing", file: R, from: "const steps = { minor: 1, serious: 2, deadly: 3 }", to: "const steps = { minor: 0, serious: 2, deadly: 3 }" },
  { name: "Nullflow's ±1 a step", file: R, from: "export const nullflowModifier = (runeLevel, spellPP) => 2 * (", to: "export const nullflowModifier = (runeLevel, spellPP) => 1 * (" },
  { name: "Veil at 25% exactly", file: R, from: "Number(hp) < 0.25 * Number(max);", to: "Number(hp) <= 0.25 * Number(max);" },
  { name: "Veil on a minor critical", file: R, from: "const crit = [\"serious\", \"deadly\"].includes(", to: "const crit = [\"minor\", \"serious\", \"deadly\"].includes(" },
  { name: "Chrono starts at Medium", file: R, from: "export const CHRONO_STEPS = freeze([[\"easy\", \"Easy\", -2], ", to: "export const CHRONO_STEPS = freeze([" },
  { name: "Warpflare's ley line +2", file: R, from: "const r = Math.trunc(Number(roll) || 0) + (nearLine ? 1 : 0);", to: "const r = Math.trunc(Number(roll) || 0) + (nearLine ? 2 : 0);" },
  { name: "Warpflare's surge at level 10", file: R, from: "export const WARPFLARE_SURGE_LEVEL = 9;", to: "export const WARPFLARE_SURGE_LEVEL = 10;" },
  { name: "Sanguine 1d4 on any hit", file: R, from: "export const sanguineBleed = (natural) => (Math.trunc(Number(natural) || 0) === 20 ? \"1d4\" : \"1\");", to: "export const sanguineBleed = () => \"1d4\";" },
  { name: "Renewal's tier not read", file: R, from: "* byTier([1, 2, 3], tier);", to: "* 1;" },
  { name: "Spellguard at +2 (M79)", file: R, from: "export const SPELLGUARD_DC_STEP = 1;", to: "export const SPELLGUARD_DC_STEP = 2;" },
  { name: "the Casting DC at 1 per PP", file: R, from: "export const castingDCOf = (pp) => 10 + Math.floor(Math.max(0, Number(pp) || 0) * 1.5);", to: "export const castingDCOf = (pp) => 10 + Math.max(0, Number(pp) || 0);" },
  // D — the workflows
  { name: "the old Quickbind not read as Swiftbind", file: R, from: "level: 6, price: 2000, aliases: [\"Quickbind\"],", to: "level: 6, price: 2000," },
  { name: "the Catalyst rune on armour", file: A, from: "return r && shield?.type === \"shield\" ? R.byTier(", to: "return r ? R.byTier(" },
  { name: "an embedded catalyst used today offered again", file: A, from: "      if (!c?.key || used.includes(String(i))) return;", to: "      if (!c?.key) return;" },
  { name: "an embedded catalyst consumed", file: A, from: "out.push({ itemId: shield.id, slot: String(i), consume: false,", to: "out.push({ itemId: shield.id, slot: String(i), consume: true," },
  { name: "a shield not wielded offers its catalysts", file: A, from: "items(actor).filter((i) => i.type === \"shield\" && i.system?.equipped && catalystSlots(i))", to: "items(actor).filter((i) => i.type === \"shield\" && catalystSlots(i))" },
  { name: "Luminous takes the weakest", file: A, from: "reduce((m, x) => Math.max(m, R.byTier(R.RUNES_9B.LUMINOUS.lightSteps, x.tier)), 0);", to: "reduce((m, x) => Math.max(m, 1), 0);" },
  { name: "Summoner's Brand on any spell", file: A, from: "  if (!/\\bsummons\\b/.test(traits)) return 0;", to: "" },
  { name: "Nullflare's suppression never ends", file: A, from: "return Boolean(rec && Number(globalThis.game?.time?.worldTime ?? 0) < Number(rec.until));", to: "return Boolean(rec);" },
  { name: "the GM writes any effect", file: A, from: "  if (op.kind === \"createEffect\") return OWN_SOURCES.includes(op.data?.flags?.[MODULE_ID]?.source);", to: "  if (op.kind === \"createEffect\") return true;" },
  { name: "the GM deletes any effect", file: A, from: "  if (op.kind === \"deleteEffect\") return typeof op.effectId === \"string\" && op.nullflare === true;", to: "  if (op.kind === \"deleteEffect\") return typeof op.effectId === \"string\";" },
  // E — the packs
  { name: "a rune's tiers as one document", file: C, from: "  return tiers.map((t, i) => {", to: "  return tiers.slice(0, 1).map((t, i) => {" },
  { name: "Ritualist's Edge at level 11", file: R, from: "type: \"weapon\", base: \"Dagger\", level: 10, price: 7602,", to: "type: \"weapon\", base: \"Dagger\", level: 11, price: 7602," },
  { name: "Whispering Hollow's Max Dex with Comfort folded in", file: R, from: "stats: { penalty: -2, maxDexBonus: 7, dr: 4, db: 3, hp: 135 },", to: "stats: { penalty: -2, maxDexBonus: 8, dr: 4, db: 3, hp: 135 }," },
  { name: "Gravemeld not Graveiron", file: R, from: "weight: 31, material: \"graveiron\", quality: \"master\",", to: "weight: 31, material: \"\", quality: \"master\"," },
  { name: "Shadeskin without its Perception", file: R, from: "runes: \"Potency II, Shadow II, Veil II\", perception: -1,", to: "runes: \"Potency II, Shadow II, Veil II\"," },
  // F — the wiring
  { name: "the runes not registered", file: A, from: "  api.registerRunes?.(runeRegistrations9b(), moduleId);", to: "" },
  { name: "Nullflow not registered", file: A, from: "  api.registerCastReaction?.(\"eaNullflow\", nullflowReaction, moduleId);", to: "" },
  { name: "the weapon runes not on the Strike", file: SCRIPT, from: "Hooks.on(\"trgPrimeStrikeResolved\", (ctx) => { onStrikeResolvedB9b(ctx)", to: "Hooks.on(\"trgPrimeStrikeResolvedX\", (ctx) => { onStrikeResolvedB9b(ctx)" },
  { name: "the fumble drawbacks not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeWeaponFumble\", (ctx) => { onWeaponFumbleB9b(ctx)", to: "Hooks.on(\"trgPrimeWeaponFumbleX\", (ctx) => { onWeaponFumbleB9b(ctx)" },
  { name: "Block 9b not registered", file: REG, from: "  registerBlock9b(api, moduleId);", to: "" },
  { name: "9a offers no embedded catalyst", file: A9, from: "    out.push(...embeddedCatalystOffers(ctx.actor, (key) => {", to: "    void (embeddedCatalystOffers, ((key) => {" },
  { name: "an embedded catalyst meets Conservation", file: A9, from: "    if (shield) await embedded.markEmbeddedUsed(shield, slot);", to: "    if (shield) await embedded.markEmbeddedUsed(shield, slot);\n    await conservation(actor, ctx.degree, lines);" },
  { name: "Pyrebrand's surge whether or not it is active", file: A, from: "runeState?.[`${key(\"PYREBRAND\")}Active`]", to: "runeState?.[`${key(\"PYREBRAND\")}`]" },
  { name: "Tether as often as you hit", file: A, from: "if (r.upper === \"TETHER\" && oncePerRound(weapon, r.upper) && await ask(", to: "if (r.upper === \"TETHER\" && await ask(" },
  { name: "Veil's use not spent", file: A, from: "  await spendUse(item, \"VEIL\");", to: "" },
  { name: "Chrono's point buys anything", file: A, from: "system: { quickenedFor: [\"strike\"] }", to: "system: {}" },
  { name: "Wildbane not on the surge", file: f("module", "block2-automations.mjs"), from: "    shieldLines.push(...await wildbaneLines(actor));", to: "" },
  { name: "Chrono's press sets nothing (no duration)", file: R, from: "state: \"eaChrono\", durationSeconds: 86400,", to: "state: \"eaChrono\"," },
  { name: "Essencebreaker offers a category", file: R, from: "export const DAMAGE_TYPES = freeze([\"acid\",", to: "export const DAMAGE_TYPES = freeze([\"mundane\", \"acid\"," },
  { name: "Veil asked twice for one blow", file: A, from: "    if (!R.veilTriggers({ hp: Number(hp.value), max: Number(hp.max) })) await offerVeil(", to: "    await offerVeil(" },
  { name: "Nullflare takes the module's own effect", file: A, from: "!e.disabled && !e.flags?.[MODULE_ID]?.source && originSpell(e)", to: "!e.disabled && originSpell(e)" },
  { name: "Sanguine's count carries between encounters", file: A, from: "const idle = (rec.combatId === combatId ? int(rec.idle) : 0) + 1;", to: "const idle = int(rec.idle) + 1;" },
  { name: "Block 9b's packs not built", file: f("tools", "content", "packs.mjs"), from: "BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);", to: "BLOCK9A_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);" },
  { name: "Chrono's end leaves the core's timer", file: A, from: "  const stopped = await coreApi()?.stopItemTimer?.(actor, weapon, CHRONO_STATE());", to: "  const stopped = false;" },
  { name: "becoming Fatigued does not end Chrono", file: A, from: "  const fatigue = isFatiguedEffect(effect);", to: "  const fatigue = false;" },
  { name: "any condition ends Chrono", file: A, from: "const isFatiguedEffect = (effect) => effect?.flags", to: "const isFatiguedEffect = (effect) => true || effect?.flags" },
  { name: "an idle Chrono is ended too", file: A, from: "runeOn(i, \"CHRONO\") && chronoRunning(i))) {", to: "runeOn(i, \"CHRONO\"))) {" },
  { name: "Fatigued at the turn's end does not end Chrono", file: A, from: "      if (actor.hasCondition?.(\"fatigued\")) {\n        await endChrono(actor, weapon, FATIGUED_ENDS);", to: "      if (actor.hasCondition?.(\"fatigued\")) {\n        void FATIGUED_ENDS;" },
  { name: "a refused press's timer is kept", file: A, from: "    if (weapon) await coreApi()?.stopItemTimer?.(actor, weapon, CHRONO_STATE());\n    return;", to: "    void weapon;\n    return;" },
  { name: "any rune's timer is stopped while Fatigued", file: A, from: "  const chronoTimer = Boolean(timer && timer.state === CHRONO_STATE());", to: "  const chronoTimer = Boolean(timer);" },
  { name: "a rested wielder's Chrono timer is stopped", file: A, from: "  if (!actor?.hasCondition?.(\"fatigued\")) return;\n  const { actsFor }", to: "  const { actsFor }" },
  { name: "the timer watcher not hooked", file: SCRIPT, from: "Hooks.on(\"createActiveEffect\", (effect) => { onChronoTimerCreatedB9b(effect)", to: "Hooks.on(\"createActiveEffectX\", (effect) => { onChronoTimerCreatedB9b(effect)" },
  { name: "the version is not raised", file: MANIFEST, from: "\"version\": \"0.17.2\",", to: "\"version\": \"0.13.2\"," }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block9b.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block9b: verify-block9b already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block9b: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block9b: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
