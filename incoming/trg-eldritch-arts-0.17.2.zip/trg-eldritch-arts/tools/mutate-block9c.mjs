#!/usr/bin/env node
/**
 * mutate-block9c — the mutation half of verify-block9c. Each mutation breaks
 * one printed number, one ruling, one reading or one wire of Block 9c
 * (0.15.0: the orbs, rods and staves, and Spellhold's store); verify-block9c
 * must fail on every one. Files are restored after each run, and on any exit.
 * It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block9c.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "block9c-rules.mjs"), A = f("module", "block9c-automations.mjs"), A9 = f("module", "block9a-automations.mjs"), C = f("tools", "content", "block9c.mjs"),
  PK = f("tools", "content", "packs.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), MANIFEST = f("module.json");

const MUTATIONS = [
  // A, B — the book and the rules
  { name: "Verdant Heart at level 12", file: R, from: "name: \"Orb of the Verdant Heart\", level: 13,", to: "name: \"Orb of the Verdant Heart\", level: 12," },
  { name: "an orb's PP not its level × 3", file: R, from: "name: \"Orb of Shifting Currents\", level: 4, price: 750, pp: 12,", to: "name: \"Orb of Shifting Currents\", level: 4, price: 750, pp: 10," },
  { name: "the ley bonus +2 from 8", file: R, from: "  return l >= 17 ? 3 : l >= 9 ? 2 : 1;", to: "  return l >= 17 ? 3 : l >= 8 ? 2 : 1;" },
  { name: "the ley bonus never +3", file: R, from: "  return l >= 17 ? 3 : l >= 9 ? 2 : 1;", to: "  return l >= 9 ? 2 : 1;" },
  { name: "Channel Ley Line not a ley-line check", file: R, from: "export const LEY_ACTIONS = Object.freeze([\"leySense\", \"tapLeyLine\", \"channelLeyLine\"]);", to: "export const LEY_ACTIONS = Object.freeze([\"leySense\", \"tapLeyLine\"]);" },
  { name: "the ley bonus gated on the PP", file: R, from: "  scope: \"Ley Sense, Tap Ley Line and Channel Ley Line, while held\", when: { actions: [...LEY_ACTIONS] }, auto: true\n});", to: "  scope: \"Ley Sense, Tap Ley Line and Channel Ley Line, while held\", when: { actions: [...LEY_ACTIONS] }, auto: true, minItemPP: 3\n});" },
  { name: "the abilities' floor at 2 PP", file: R, from: "export const ORB_ABILITY_MIN_PP = 3;", to: "export const ORB_ABILITY_MIN_PP = 2;" },
  { name: "Emberlight's adder for every spell", file: R, from: "{ kind: \"spellAdder\", value: 1, spellTraits: [\"fire\"], minItemPP: ORB_ABILITY_MIN_PP, label: \"Orb of Emberlight\" }", to: "{ kind: \"spellAdder\", value: 1, minItemPP: ORB_ABILITY_MIN_PP, label: \"Orb of Emberlight\" }" },
  { name: "the Whispering Veil's Hide +1", file: R, from: "{ kind: \"modifier\", value: 2, type: \"item\", label: \"Orb of the Whispering Veil\"", to: "{ kind: \"modifier\", value: 1, type: \"item\", label: \"Orb of the Whispering Veil\"" },
  { name: "Spellcraft Easy on an orb", file: R, from: "    key: \"spellcraft\", label: \"Spellcraft\", skill: \"spellcraft\", difficulty: \"hard\",", to: "    key: \"spellcraft\", label: \"Spellcraft\", skill: \"spellcraft\", difficulty: \"easy\"," },
  { name: "High Magic's step not stacked", file: R, from: "    dcParts: highMagic ? [{ label: \"High Magic\", value: 2 }] : [],", to: "    dcParts: []," },
  { name: "the orb's Spellcraft ignores the cap", file: R, from: "    available: pp <= cap && int(ctx.casterLevel) > 0,", to: "    available: int(ctx.casterLevel) > 0," },
  { name: "a High Magic spell by its own tradition's skill", file: R, from: "  const traditions = highMagic ? [...new Set([\"arcane\", ...(own && skills[own] ? [own] : [])])] : spellTraditions;", to: "  const traditions = spellTraditions;" },
  { name: "the skill path Hard", file: R, from: "      skill, difficulty: \"veryHard\", dcParts: [],", to: "      skill, difficulty: \"hard\", dcParts: []," },
  { name: "the skill path without Use Magic Device", file: R, from: "    if (!ctx.hasUseMagicDevice) reasons.push(\"you do not have Use Magic Device\");", to: "" },
  { name: "the flare on any breaking row", file: R, from: "  return Boolean(row?.breaks) && int(row?.min) === 41 && int(row?.max) === 65;", to: "  return Boolean(row?.breaks);" },
  { name: "Ley Resonance's cost rounded down", file: R, from: "export function leyResonanceRodCost(paid, rate) { return Math.ceil(", to: "export function leyResonanceRodCost(paid, rate) { return Math.floor(" },
  { name: "Ley Resonance at 30 feet", file: R, from: "export const LEY_RESONANCE_FEET = 60;", to: "export const LEY_RESONANCE_FEET = 30;" },
  { name: "Binding Seal on any spell", file: R, from: "export function isSummons(traits) { return /\\bsummons?\\b/i.test(String(traits ?? \"\")); }", to: "export function isSummons(traits) { return true; }" },
  { name: "Spellhold III holds 20", file: R, from: "export const SPELLHOLD_CAPACITY = Object.freeze([6, 12, 24, 40]);", to: "export const SPELLHOLD_CAPACITY = Object.freeze([6, 12, 20, 40]);" },
  { name: "Focused Spell III to 8", file: R, from: "metamagic: { kind: \"focusedspell\", maxPP: 12, cost: 2 }", to: "metamagic: { kind: \"focusedspell\", maxPP: 8, cost: 2 }" },
  { name: "Tesra'Anvir's adder for arcane only", file: R, from: "wondrous: [{ kind: \"spellAdder\", value: 4, requiresArcaneOrHighMagicCaster: true,", to: "wondrous: [{ kind: \"spellAdder\", value: 4, requiresArcaneCaster: true," },
  { name: "Tesra'Anvir's quicken at 2 PP", file: R, from: "metamagic: { kind: \"quicken\", maxPP: 99, cost: 8 },", to: "metamagic: { kind: \"quicken\", maxPP: 99, cost: 2 }," },
  { name: "Eidothrix for every school", file: R, from: "when: { checkTypes: [\"spellcraft\"], traits: [\"translocation\"] }, auto: true }],", to: "when: { checkTypes: [\"spellcraft\"] }, auto: true }]," },
  // C — the registrations
  { name: "the orb recharges naturally", file: A, from: "    label: \"Orb\", warp: \"staff\", naturalRecharge: false, rechargeItemPP: 4,", to: "    label: \"Orb\", warp: \"staff\", naturalRecharge: true, rechargeItemPP: 4," },
  { name: "the orb not warped", file: A, from: "    label: \"Orb\", warp: \"staff\", naturalRecharge: false, rechargeItemPP: 4,", to: "    label: \"Orb\", warp: \"none\", naturalRecharge: false, rechargeItemPP: 4," },
  { name: "Recharge Item at 2 PP on an orb", file: A, from: "    label: \"Orb\", warp: \"staff\", naturalRecharge: false, rechargeItemPP: 4,", to: "    label: \"Orb\", warp: \"staff\", naturalRecharge: false, rechargeItemPP: 2," },
  { name: "two orbs may be invested", file: A, from: "  api.registerOneInvestedTraits?.([\"orb\"], moduleId);", to: "" },
  { name: "Ley Resonance not a source", file: A, from: "  api.registerCastPPSource?.(\"eaLeyResonance\", LEY_RESONANCE_SOURCE, moduleId);", to: "" },
  // D — the workflows
  { name: "the orb's ladder with the core's cap ignored", file: A, from: "casterCap: maxPPPerCast(int(ctx.casterLevel))", to: "casterCap: 0" },
  { name: "the flare breaks the orb", file: A, from: "  await item.update({ \"system.uses\": 0 });\n  const level", to: "  await item.update({ \"system.hp.max\": 1, \"system.hp.value\": 0 });\n  const level" },
  { name: "the flare's radius 10", file: A, from: "source: \"wildSurge\", radiusFeet: R.FLARE_RADIUS,", to: "source: \"wildSurge\", radiusFeet: 10," }, // RE-ANCHORED 0.15.1
  { name: "a Critical Tap on any Tap", file: A, from: "  if (action?.key !== \"tapLeyLine\" || degree !== \"critical\" || !actor?.isOwner) return;", to: "  if (action?.key !== \"tapLeyLine\" || !actor?.isOwner) return;" },
  { name: "a Critical Tap with an orb at 2 PP", file: A, from: "    if (int(item.system?.uses) < R.ORB_ABILITY_MIN_PP) {", to: "    if (false) {" },
  { name: "See Invisible not warped", file: A, from: "{ kind: \"avoidanceSight\", sight: \"seeInvisible\", level: \"concealed\" }, { sightLevel: \"clear\" });", to: "{ kind: \"avoidanceSight\", sight: \"seeInvisible\", level: \"concealed\" }, {});" },
  { name: "See Invisible for 1 minute", file: A, from: "system: { spellBuff: true, [spec.flag]: spec.level }, expiry: forSeconds(600)", to: "system: { spellBuff: true, [spec.flag]: spec.level }, expiry: forSeconds(60)" },
  { name: "Fast Healing 1", file: A, from: "    system: { fastHealing: 2 }, expiry: forSeconds(60)", to: "    system: { fastHealing: 1 }, expiry: forSeconds(60)" },
  { name: "the socket writes anything", file: A, from: "  return op.kind === \"createEffect\" && op.data?.flags?.[MODULE_ID]?.source === \"verdantHeart9c\" && int(op.data?.flags?.[SYSTEM_ID]?.fastHealing) === 2;", to: "  return op.kind === \"createEffect\";" },
  { name: "a rod not invested still offered", file: A, from: "  if (!rod || !rod.system?.invested) return null;", to: "  if (!rod) return null;" },
  { name: "the round's Rod not asked", file: A, from: "  if (await h().rodUseRefusal?.(actor)) return null;", to: "" },
  { name: "a rod not held still counts", file: A, from: "const held = (item) => Boolean(item?.system?.equipped) && !broken(item);", to: "const held = (item) => !broken(item);" },
  { name: "rod powers on an item cast", file: A, from: "const casts = (ctx) => !(ctx.innate || ctx.itemCast || ctx.stored || ctx.ritual);", to: "const casts = (ctx) => !(ctx.innate || ctx.stored || ctx.ritual);" },
  { name: "Binding Seal lowers the DC by 2", file: A, from: "      return { castingDC: -1, label: rod.name,", to: "      return { castingDC: -2, label: rod.name," },
  { name: "Soul's Echo +1", file: A, from: "      return { saveDCTarget: { traits: [\"undead\"], value: 2 },", to: "      return { saveDCTarget: { traits: [\"undead\"], value: 1 }," },
  { name: "Soul's Echo on every target", file: A, from: "      return { saveDCTarget: { traits: [\"undead\"], value: 2 },", to: "      return { saveDC: 2, saveDCTarget: { traits: [\"undead\"], value: 2 }," },
  { name: "Soul's Echo offered without a save", file: A, from: "      if (!casts(ctx) || !R.hasSave(ctx.spell?.system?.defence)) return null;", to: "      if (!casts(ctx)) return null;" },
  { name: "a refunded cast pays", file: A, from: "  if (!taken.length || refunded || !actor.isOwner) return;", to: "  if (!taken.length || !actor.isOwner) return;" },
  { name: "an option not taken still pays", file: A, from: "    if (!keys.has(norm(OPTION_KEYS[p.power]))) continue;", to: "" }, // RE-ANCHORED (review)
  { name: "the rod pays twice", file: A, from: "  const taken = pending.get(actor.uuid) ?? [];\n  pending.delete(actor.uuid);", to: "  const taken = pending.get(actor.uuid) ?? [];" },
  { name: "the rod pays 2 PP", file: A, from: "    lines.push(line(await h().spendFromRod(actor, rod, 1, { reason: R.ROD_POWERS[p.power] })));", to: "    lines.push(line(await h().spendFromRod(actor, rod, 2, { reason: R.ROD_POWERS[p.power] })));" },
  { name: "a held spell's rods not paid", file: A, from: "  return settleRodPowers({ actor: ctx.actor, castOptions: ctx.castOptions ?? ctx.record?.castOptions, castPP: ctx.record?.pp, held: true });", to: "  return null;" }, // RE-ANCHORED (review)
  { name: "Ley Resonance beyond the cast", file: A, from: "    const max = Math.min(R.leyResonanceMax(rod.system?.uses, rate), int(ctx.payable ?? ctx.totalPP));", to: "    const max = R.leyResonanceMax(rod.system?.uses, rate);" },
  { name: "Ley Resonance's rod pays nothing", file: A, from: "    const said = await h().spendFromRod(actor, rod, cost, { reason: \"Ley Resonance\" });", to: "    const said = \"\";" },
  { name: "Catalyst Flow at 1 PP", file: A, from: "  lines.push(await h().spendFromRod(actor, rod, 2, { reason: \"Catalyst Flow\" }));", to: "  lines.push(await h().spendFromRod(actor, rod, 1, { reason: \"Catalyst Flow\" }));" },
  { name: "Catalyst Flow without asking", file: A, from: "  if (choice !== \"yes\") return false;", to: "" },
  { name: "Catalyst Flow before Conservation", file: A9, from: "  if (!keep) {\n    const { catalystFlowKeeps }", to: "  if (true) {\n    const { catalystFlowKeeps }" },
  { name: "Catalyst Flow not asked", file: A9, from: "    keep = await catalystFlowKeeps(actor, spec.name, lines);", to: "" },
  { name: "Spellhold only on a runes field", file: A, from: "item?.flags?.[SYSTEM_ID]?.chargedItem?.weaponForm?.runes].filter(Boolean);\n  for (const field of fields)", to: "].filter(Boolean);\n  for (const field of fields)" },
  { name: "Spellhold's store without the investor", file: A, from: "  if (!item.system?.equipped || !item.system?.invested) return warn(", to: "  if (!item.system?.equipped) return warn(" },
  { name: "a full store still arms", file: A, from: "    if (used >= capacity) return warn(`${item.name} is full (${used} of ${capacity} PP).`);", to: "" },
  { name: "release free", file: A, from: "  return h().releaseHeldSpell(actor, item, choice, { ap: \"1\",", to: "  return h().releaseHeldSpell(actor, item, choice, { ap: \"free\"," },
  { name: "stored spells never fade", file: A, from: "    const n = await h().clearHeldSpells(item);", to: "    const n = 0;" },
  { name: "the sheet button twice", file: A, from: "  if (controls.some((c) => c?.action === \"eaSpellhold\")) return;", to: "" },
  // E — the pack
  { name: "an orb recharges a PP a day", file: C, from: "Object.entries(ORBS_9C).map(([upper, spec]) => chargedItem(upper, spec, \"orbs\", { kind: \"orb\", recharge: null }))", to: "Object.entries(ORBS_9C).map(([upper, spec]) => chargedItem(upper, spec, \"orbs\", { kind: \"orb\", recharge: 1 }))" },
  { name: "an orb is a staff", file: C, from: "chargedItem(upper, spec, \"orbs\", { kind: \"orb\",", to: "chargedItem(upper, spec, \"orbs\", { kind: \"staff\"," },
  { name: "the wondrous abilities not on the item", file: C, from: "      ...(spec.wondrous?.length ? { wondrous: { abilities: spec.wondrous.map((a) => ({ ...a })) } } : {}),", to: "" },
  { name: "the conditionals not on the item", file: C, from: "      ...(spec.conditionals?.length ? { conditionals: spec.conditionals.map((c) => ({ ...c, when: { ...c.when } })) } : {})", to: "" },
  { name: "the rod's metamagic not on the item", file: C, from: "        ...(spec.metamagic ? { metamagic: { ...spec.metamagic } } : {})", to: "" },
  { name: "an item's book name not flagged", file: C, from: "    [MODULE_ID]: { charged9c: upper }", to: "    [MODULE_ID]: {}" },
  { name: "the automated note dropped", file: C, from: "spec.note ? md(`*Automated (${STAMP}):* ${spec.note}`) : \"\"", to: "\"\"" },
  { name: "the pack not built", file: PK, from: "BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);", to: "BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);" },
  { name: "the pack not declared", file: MANIFEST, from: "      \"name\": \"ea-charged-items\",", to: "      \"name\": \"ea-charged-itemz\"," },
  // REVIEW — one Rod a cast, and only the powers a cast took
  { name: "REVIEW: a second rod's power taken", file: A, from: "  return other ? `${rod?.name ?? \"That rod\"} is not used", to: "  return false ? `${rod?.name ?? \"That rod\"} is not used" },
  { name: "REVIEW: the same rod counted as another", file: A, from: "find((p) => p?.rodId && p.rodId !== rod?.id);", to: "find((p) => p?.rodId);" },
  { name: "REVIEW: Soul's Echo skips the one-rod test", file: A, from: "      if (!rod) return { label: \"Soul's Echo\", lines: [] };\n      const refused = refusedByOtherRod(ctx.actor, rod, ctx);\n      if (refused)", to: "      if (!rod) return { label: \"Soul's Echo\", lines: [] };\n      const refused = refusedByOtherRod(ctx.actor, rod, ctx);\n      if (false)" },
  { name: "REVIEW: a stale power outlives its cast", file: A, from: "const freshCast = (actor) => { if (actor?.uuid) pending.delete(actor.uuid); };", to: "const freshCast = () => {};" },
  { name: "REVIEW: a held cast pays every pending power", file: A, from: "    if (!keys.has(norm(OPTION_KEYS[p.power]))) continue;", to: "    if (!held && !keys.has(norm(OPTION_KEYS[p.power]))) continue;" },
  { name: "REVIEW: the held hook's options not read", file: A, from: "castOptions: ctx.castOptions ?? ctx.record?.castOptions, castPP: ctx.record?.pp, held: true", to: "castOptions: [], castPP: ctx.record?.pp, held: true" },
  { name: "RULING: Wild Surges says it waits for a held spell's release", file: A, from: "${ctx.holding ? \"as the spell is stored\" : \"once the spell resolves\"}", to: "once the spell resolves" },
  { name: "RE-REVIEW: a woven settle clears the first spell's powers", file: A, from: "  if (ctx.threaded || ctx.held) return;\n  return settleRodPowers(", to: "  return settleRodPowers(" },
  { name: "RE-REVIEW: Ley Resonance not counted as the cast's Rod", file: A, from: "...coreRods(ctx), ...leyDrawn(ctx), ...(pending.get(actor.uuid) ?? [])], rod);", to: "...coreRods(ctx), ...(pending.get(actor.uuid) ?? [])], rod);" }, // RE-ANCHORED 0.15.2
  { name: "RE-REVIEW: Ley Resonance counted though it drew nothing", file: A, from: "&& int(d?.drawn) > 0);", to: ");" },
  { name: "LIVE TEST: a refused hold window still says \"cast it now\"", file: A, from: "    if (!armed) return null;\n    await card(", to: "    await card(" },
  { name: "REVIEW 0.15.1: the flare's effects never expire", file: A, from: "radiusFeet: R.FLARE_RADIUS,\n    // AN EXPIRY, AS EVERY OTHER WILD SURGE HAS (0.15.1, review): 1 round per area level.\n    expiry: forSeconds(6 * Math.max(1, level)) });", to: "radiusFeet: R.FLARE_RADIUS });" },
  { name: "REVIEW 0.15.1: the rod's surge never expires", file: A, from: "radiusFeet: 5 * level, expiry: forSeconds(6 * level) });", to: "radiusFeet: 5 * level });" },
  { name: "0.15.2: the core's rods not read", file: A, from: "otherRodRefusal([...coreRods(ctx), ...leyDrawn(ctx),", to: "otherRodRefusal([...leyDrawn(ctx)," },
  { name: "0.15.2: a power offered beside the core's rod", file: A, from: "return rod && !otherRodRefusal(coreRods(ctx), rod) ? { label: `${rod.name}: casting DC −1", to: "return rod ? { label: `${rod.name}: casting DC −1" },
  { name: "0.15.2: the Binding Seal not named to TRG Prime", file: A, from: "return { castingDC: -1, label: rod.name, rodItemId: rod.id, rodName: rod.name,", to: "return { castingDC: -1, label: rod.name," },
  { name: "0.15.2: Ley Resonance offered beside the core's rod", file: A, from: "    if (otherRodRefusal(coreRods(ctx), rod)) return null;", to: "" },
  { name: "0.15.2: Ley Resonance not named as a rod", file: A, from: "max, rodItemId: rod.id, rodName: rod.name };", to: "max };" },
  // F — the wiring
  { name: "the Critical Tap not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeActionResolved\", (ctx) => { onActionResolvedB9c(", to: "Hooks.on(\"trgPrimeActionResolvedX\", (ctx) => { onActionResolvedB9c(" },
  { name: "the settled spell not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB9c(ctx)", to: "Hooks.on(\"trgPrimeSpellSettledX\", (ctx) => { onSpellSettledB9c(ctx)" },
  { name: "the held spell not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellHeld\", (ctx) => { onSpellHeldB9c(ctx)", to: "Hooks.on(\"trgPrimeSpellHeldX\", (ctx) => { onSpellHeldB9c(ctx)" },
  { name: "the daily preparation not hooked", file: SCRIPT, from: "Hooks.on(\"trgPrimeDailyPreparation\", (ctx) => { onDailyPreparationB9c(ctx)", to: "Hooks.on(\"trgPrimeDailyPreparationX\", (ctx) => { onDailyPreparationB9c(ctx)" },
  { name: "not registered", file: REG, from: "  registerBlock9c(api, moduleId);", to: "" },
  { name: "the module asks for 3.689.0", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.689.0\";" },
  { name: "the manifest's minimum 3.689.0", file: MANIFEST, from: "\"minimum\": \"3.694.0\"", to: "\"minimum\": \"3.689.0\"" },
  { name: "the version is not raised", file: MANIFEST, from: "\"version\": \"0.17.2\",", to: "\"version\": \"0.15.0\"," }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block9c.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block9c: verify-block9c already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block9c: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block9c: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
