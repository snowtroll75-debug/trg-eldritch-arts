#!/usr/bin/env node
/**
 * mutate-block10b — the mutation half of verify-block10b. Each mutation breaks
 * one printed number, one ruling, one reading or one wire of Block 10a
 * (0.17.1: the sentient-item roll tables and the rules reference journal);
 * verify-block10b must fail on every one. Files are restored after each run,
 * and on any exit. It rewrites files in place: run it on a copy of the tree.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block10b.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const B = f("tools", "content", "block10b.mjs"), X = f("tools", "content", "extract-book.mjs"), BP = f("tools", "build-packs.mjs"), MANIFEST = f("module.json"), PK = f("tools", "content", "packs.mjs");

const MUTATIONS = [
  { name: "Q219 Senses rolled as printed (d6)", file: B, from: "export const ROLLED_AS = Object.freeze({ \"Sentient Item: Senses\": \"1d8\" });", to: "export const ROLLED_AS = Object.freeze({});" },
  { name: "a result's range off by one", file: B, from: "  return [a, Number.isFinite(b) ? b : a];", to: "  return [a, Number.isFinite(b) ? b : a + 1];" },
  { name: "a result's text reworded", file: B, from: "_id: stableId(`tables:${name}:${i}`), type: \"text\", name: r.text,", to: "_id: stableId(`tables:${name}:${i}`), type: \"text\", name: r.text.toLowerCase()," },
  { name: "the quirks named Aligned Trait", file: B, from: "[\"ALIGNED TRAIT\", \"d20\", \"Sentient Item: Quirks\"]", to: "[\"ALIGNED TRAIT\", \"d20\", \"Sentient Item: Aligned Trait (d20)\"]" },
  { name: "the mental arrays dropped", file: B, from: "export const ALL_TABLES = [...SENTIENT_TABLES.slice(0, 6), MENTAL_ARRAYS, ...SENTIENT_TABLES.slice(6)];", to: "export const ALL_TABLES = [...SENTIENT_TABLES];" },
  { name: "the arrays' Wis column shown as Cha", file: B, from: "text: `Int +${r.cells[1]}, Wis +${r.cells[2]}, Cha +${r.cells[3]}.", to: "text: `Int +${r.cells[1]}, Wis +${r.cells[3]}, Cha +${r.cells[3]}." },
  { name: "a table without replacement", file: B, from: "formula, replacement: true, displayRoll: true,", to: "formula, replacement: false, displayRoll: true," },
  { name: "a page's bold lost", file: B, from: "  .replace(/\\*\\*([^*]+?)\\*\\*/g, \"<strong>$1</strong>\")", to: "" },
  { name: "the tables not rendered", file: B, from: "    if (l.startsWith(\"|\")) {", to: "    if (false) {" },
  { name: "the bullets dropped", file: B, from: "    if (/^- /.test(l)) { if (rows) flush(); list ??= []; list.push(l.slice(2)); continue; }", to: "    if (/^- /.test(l)) continue;" },
  { name: "the design page not after Sentient Items", file: B, from: "  pages.splice(pages.findIndex((p) => p.name === \"Sentient Items\") + 1, 0, {", to: "  pages.push({" },
  { name: "the table links name a wrong pack", file: B, from: "@UUID[Compendium.${MODULE_ID}.ea-tables.RollTable.${t._id}]", to: "@UUID[Compendium.${MODULE_ID}.ea-rules.RollTable.${t._id}]" },
  { name: "the automation notes dropped", file: B, from: "${PAGE_NOTES[p.title] ? `\\n<p><em>${esc(PAGE_NOTES[p.title])}</em></p>` : \"\"}", to: "" },
  { name: "the planes page stops short", file: X, from: "    page(\"Planes of Existence\", PLANES, INDEX)", to: "    page(\"Planes of Existence\", PLANES, INDEX - 40)" },
  { name: "the sentient page runs into the tables", file: X, from: "    page(\"Sentient Items\", SENT, TABLES),", to: "    page(\"Sentient Items\", SENT, TABLES + 40)," },
  { name: "RollTables keyed as items", file: BP, from: "  if (type === \"RollTable\") {", to: "  if (false) {" },
  { name: "the tables pack not in the folder", file: MANIFEST, from: "        \"ea-relics\",\n        \"ea-tables\",", to: "        \"ea-relics\"," },
  { name: "the journal not shipped", file: PK, from: "BLOCK10_PACKS, BLOCK10B_PACKS);", to: "BLOCK10_PACKS);" },
  { name: "every result weighted 1", file: B, from: "      weight: rangeOf(r.range)[1] - rangeOf(r.range)[0] + 1, range:", to: "      weight: 1, range:" },
  { name: "a blank line ends a list", file: B, from: "    if (!l || l === \"<!-- -->\") continue;", to: "    if (!l || l === \"<!-- -->\") { if (list) flush(); continue; }" },
  { name: "a result's text printed twice", file: B, from: "type: \"text\", name: r.text, description: \"\", img:", to: "type: \"text\", name: r.text, description: esc(r.text), img:" },
  { name: "every page title shown", file: B, from: "    title: { show: !opensWithHeading(p.lines), level: 1 },", to: "    title: { show: true, level: 1 }," },
  { name: "the design page's title hidden", file: B, from: "title: { show: true, level: 1 }, text: { format: 1, content: designPage() }", to: "title: { show: false, level: 1 }, text: { format: 1, content: designPage() }" },
  { name: "a heading not recognised by its # marks", file: B, from: "  return /^#{1,3}\\s*\\S/.test(first) ||", to: "  return false ||" },
  { name: "the version not raised", file: MANIFEST, from: "\"version\": \"0.17.2\",", to: "\"version\": \"0.17.1\"," }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block10b.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block10b: verify-block10b already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block10b: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block10b: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
