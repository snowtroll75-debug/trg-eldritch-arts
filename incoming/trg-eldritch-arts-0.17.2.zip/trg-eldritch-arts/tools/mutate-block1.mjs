#!/usr/bin/env node
/**
 * mutate-block1 — the mutation half of verify-block1. Each mutation breaks
 * one printed rule, one proposal, one row the system reads or one wire of
 * Block 1; verify-block1 must fail on every one. Files are restored after
 * each run, and on any exit.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block1.mjs
 *
 * The printed text is read from the book extract, never typed, so the
 * mutations go at what is authored: the readings, the rows, the decisions
 * and the wiring. The core's Block 1 seams have their own pair in the
 * system (verify/mutate-ea-block1-core).
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const C = f("tools", "content", "block1.mjs"), A = f("module", "block1-automations.mjs"), ACT = f("module", "block1-actions.mjs");
const REG = f("module", "registration.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), MANIFEST = f("module.json"), PACKS = f("tools", "content", "packs.mjs");

const MUTATIONS = [
  // A — the book, as read
  { name: "the Nyrinn's effect is the printed line (the size table counted twice)", file: C, from: "effectModifiers: \"Str -1, Con -1, Dex +2, Cha +2\",", to: "effectModifiers: \"Str -3, Con -1, Dex +4, Cha +2\"," },
  { name: "the Scaelyn's effect forgets the size table", file: C, from: "effectModifiers: \"Con -1, Dex +1, Int +2\",", to: "effectModifiers: \"Str -1, Con -1, Dex +2, Int +2\"," },
  { name: "the Wyrmdral keeps the Scaelyn's size", file: C, from: "    effects: [sizeOverride(\"medium\")],", to: "    effects: []," },
  { name: "the Wyrmdral's line is added to the Scaelyn's, not instead", file: C, from: "effectModifiers: \"Str +1, Dex -2, Con +1, Int -1, Cha +1\",", to: "effectModifiers: \"Str +1, Dex -1, Int +1, Cha +1\"," },
  { name: "Astryn resists essence", file: C, from: "    effects: [resist(\"force\")] }),", to: "    effects: [resist(\"essence\")] })," },
  { name: "the Tidemarked's element is fire", file: C, from: "emberkin(\"TIDEMARKED\", \"cold\",", to: "emberkin(\"TIDEMARKED\", \"fire\"," },
  { name: "the Tidemarked speaks Ignic", file: C, from: "Tidemarked: Object.freeze({ damageType: \"cold\", language: \"Aqualis\" })", to: "Tidemarked: Object.freeze({ damageType: \"cold\", language: \"Ignic\" })" },
  { name: "Vel-tharis's aura stays at 5 ft", file: C, from: "flags: { ...innate(), eaNullAuraFeet: 10 } }),", to: "flags: { ...innate(), eaNullAuraFeet: 5 } })," },
  { name: "Zhal-vryn surcharges 2 PP", file: C, from: "flags: { ...innate(), eaCastSurcharge: 1 } }),", to: "flags: { ...innate(), eaCastSurcharge: 2 } })," },
  { name: "Ironmuk holds its breath three times as long", file: C, from: "creatureAbility: { derives: { breathMultiplier: 2 } }", to: "creatureAbility: { derives: { breathMultiplier: 3 } }" },
  { name: "Wisperfin's Stealth is +1", file: C, from: "racialSkillEffect(id, n, [\"Stealth\"], 2)", to: "racialSkillEffect(id, n, [\"Stealth\"], 1)" },
  { name: "Dustscale burrows 15 ft", file: C, from: "otherSpeed(\"burrow\", 10)", to: "otherSpeed(\"burrow\", 15)" },
  { name: "Natural Armour is DR 2", file: C, from: "effects: [baseDR(1, \"Natural Armour\")]", to: "effects: [baseDR(2, \"Natural Armour\")]" },
  { name: "the Arcane Wayfarer's wealth is 1", file: C, from: "\"Arcane Wayfarer\": 2,", to: "\"Arcane Wayfarer\": 1," },
  { name: "Orb of Water's secondary is 1d4", file: C, from: "SPELLS[0].system.secondaryDamage = { formula: \"1\", type: \"cold\" };", to: "SPELLS[0].system.secondaryDamage = { formula: \"1d4\", type: \"cold\" };" },
  { name: "Orb of Water's secondary does not climb", file: C, from: "damageDice: \"1d6\", secondary: 1, saveDC: 0", to: "damageDice: \"1d6\", secondary: 0, saveDC: 0" },
  { name: "B1-12 undone: Brace kept in the trait line", file: C, from: "    if (t === \"Brace\") continue; // B1-12\n", to: "" },
  { name: "the Nyrinn's weapons lose their racial note", file: C, from: "Aetherial: \"Aetherial\", Nyrinn: \"Nyrinn\" });", to: "Aetherial: \"Aetherial\" });" },
  { name: "Umbryth resists essence (v1.4)", file: C, from: "    effects: [resist(\"cold\")] }),\n  // EMBERKIN", to: "    effects: [resist(\"essence\")] }),\n  // EMBERKIN" },
  { name: "Esoteric Insight rerolls a fumble only (v1.4)", file: C, from: "degrees: [\"failure\", \"fumble\", \"blunder\"], label: \"Esoteric Insight\"", to: "label: \"Esoteric Insight\"" },
  { name: "Esoteric Insight rerolls a partial success too", file: C, from: "degrees: [\"failure\", \"fumble\", \"blunder\"], label: \"Esoteric Insight\"", to: "degrees: [\"partial\", \"failure\", \"fumble\", \"blunder\"], label: \"Esoteric Insight\"" },
  { name: "Null Aura declares no beneficial-spell save", file: C, from: "beneficialSpellSave: { label: \"Null Aura\", otherCastersOnly: true }", to: "beneficialSpellSaveX: { label: \"Null Aura\", otherCastersOnly: true }" },
  { name: "Null Aura disrupts the Nyrinn's own spells", file: C, from: "beneficialSpellSave: { label: \"Null Aura\", otherCastersOnly: true }", to: "beneficialSpellSave: { label: \"Null Aura\", otherCastersOnly: false }" },
  { name: "Spirit Binder's missing-row note comes back", file: C, from: "export const WEALTH_NOT_PRINTED = Object.freeze([]);", to: "export const WEALTH_NOT_PRINTED = Object.freeze([\"Spirit Binder\"]);" },
  { name: "Spirit Binder's wealth is 1", file: C, from: "\"Shadowed Seer\": -1, \"Spirit Binder\": 0,", to: "\"Shadowed Seer\": -1, \"Spirit Binder\": 1," },
  { name: "the Ley Sense ladder's 1 round is -2", file: ACT, from: "Object.freeze({ key: \"round\", label: \"1 round\", modifier: -5, apCost: \"1 round\" }),\n    Object.freeze({ key: \"action\", label: \"1 AP\", modifier: -10", to: "Object.freeze({ key: \"round\", label: \"1 round\", modifier: -2, apCost: \"1 round\" }),\n    Object.freeze({ key: \"action\", label: \"1 AP\", modifier: -10" },
  { name: "Focused Ley Sense loses its 0 AP rung", file: ACT, from: "    Object.freeze({ key: \"free\", label: \"0 AP\", modifier: -10, apCost: \"0\" })\n", to: "" },
  { name: "Quickbind needs 4 ranks", file: ACT, from: "    requirement: \"skills.powerManipulation.ranks\",\n    minRanks: 5,", to: "    requirement: \"skills.powerManipulation.ranks\",\n    minRanks: 4," },
  { name: "a Ley Sense outcome is retyped", file: ACT, from: "success: \"You detect the nearest ley line within 500 feet and its direction.\",", to: "success: \"You detect the nearest ley line within 50 feet and its direction.\"," },
  // B — what the system reads
  { name: "Aetherial Resonance is +2", file: C, from: "{ spellDCBonus: { label: \"Aetherial Resonance\", value: 1, type: \"race\" } }", to: "{ spellDCBonus: { label: \"Aetherial Resonance\", value: 2, type: \"race\" } }" },
  { name: "Elemental Surge adds Constitution", file: C, from: "valueFrom: \"charisma\", type: \"race\"", to: "valueFrom: \"constitution\", type: \"race\"" },
  { name: "Null Aura is the core's Spell Resilience by name (Spell Penetration would reach it)", file: C, from: "spellResilience: { label: \"Null Aura\", type: \"untyped\" }", to: "spellResilience: true" },
  { name: "Spell Penetration lowers by 1", file: C, from: "spellResilienceReduction: { value: 2,", to: "spellResilienceReduction: { value: 1," },
  { name: "Esoteric Insight's reroll is on every skill", file: C, from: "reaction: false, subjects: [\"arcana\", \"occultism\"], degrees:", to: "reaction: false, degrees:" },
  { name: "Esoteric Insight's reroll is a reaction", file: C, from: "fumbleReroll: { checkTypes: [\"skill\"], reaction: false,", to: "fumbleReroll: { checkTypes: [\"skill\"], reaction: true," },
  { name: "Focused Ley Sense names another feat", file: ACT, from: "timeLadderByFeat: { \"Focused Ley Sense\": FOCUSED_TIME_LADDER },", to: "timeLadderByFeat: { \"Focused Ley Sight\": FOCUSED_TIME_LADDER }," },
  { name: "Wyrmdral's row is on every spell", file: A, from: "spellDCBonus: { label: \"Wyrmdral\", value: 1, type: \"untyped\", traits: [element] }", to: "spellDCBonus: { label: \"Wyrmdral\", value: 1, type: \"untyped\" }" },
  // D — the decisions
  { name: "Null Aura reaches 10 ft for everyone", file: A, from: "  return Math.max(5, fromHeritage) + bonus;", to: "  return Math.max(10, fromHeritage) + bonus;" },
  { name: "Magic Drain's Success gives it all", file: A, from: "energy: Math.min(cap, Math.floor(total / 2)) };", to: "energy: Math.min(cap, total) };" },
  { name: "Memory Recall's Heroic is +4", file: A, from: "  if (k === \"heroic\") return 8;", to: "  if (k === \"heroic\") return 4;" },
  { name: "the Critical suggestion lasts an hour", file: A, from: "  if (k === \"critical\") return 1800;", to: "  if (k === \"critical\") return 3600;" },
  { name: "Lingual Casting needs Linguistics ≥ PP", file: A, from: "if (ranks(\"linguistics\") < pp + 2)", to: "if (ranks(\"linguistics\") < pp)" },
  { name: "Lingual Casting is Hard", file: A, from: "difficulty: \"veryHard\", dcAdjustment: 5,", to: "difficulty: \"hard\", dcAdjustment: 2," },
  { name: "overlapping auras: the smallest", file: A, from: "(b.classBonus > a.classBonus ? b : a)", to: "(b.classBonus < a.classBonus ? b : a)" },
  { name: "the gate raises an innate spell's roll", file: A, from: "if (!ctx.rollsCheck || ctx.itemCast || ctx.innate) return null;", to: "if (!ctx.rollsCheck || ctx.itemCast) return null;" },
  { name: "the gate is a bonus", file: A, from: "value: -best.classBonus, type: \"untyped\"", to: "value: best.classBonus, type: \"untyped\"" },
  { name: "Ley Sense's Failure locks it for an hour", file: A, from: "await lock(actor, key, 600);", to: "await lock(actor, key, 3600);" },
  { name: "Mysterious Script is once a day", file: A, from: "await lock(actor, key, 7 * 86400);", to: "await lock(actor, key, 86400);" },
  { name: "a Hypnotism Failure locks nothing", file: A, from: "    case \"hypnotismSuggestion\": {\n      if (k === \"failure\" && targetActor) await lock(actor, hypnotismLockKey(targetActor), 86400);\n", to: "    case \"hypnotismSuggestion\": {\n" },
  { name: "Quickbind may be checked twice a day", file: A, from: "if (int(item.getFlag(MODULE_ID, \"quickbindDay\")) === day + 1)", to: "if (false)" },
  { name: "Ethereal Form lasts 10 minutes", file: A, from: "      system: { grantedTraits: [\"incorporeal\"] },\n      expiry: forSeconds(60)", to: "      system: { grantedTraits: [\"incorporeal\"] },\n      expiry: forSeconds(600)" },
  { name: "Elemental Symbiosis lays no weakness", file: A, from: "  if (!element || ownEffects(actor, \"symbiosisWeakness\").length) return;", to: "  return;" },
  { name: "the energy lasts 1 round per PP drained", file: A, from: "expiry: forSeconds(60 * minutes)", to: "expiry: forSeconds(6 * minutes)" },
  { name: "the energy's bonus is circumstance", file: A, from: "value: 1, type: \"race\", label: \"Magic Drain\"", to: "value: 1, type: \"circumstance\", label: \"Magic Drain\"" },
  { name: "Vir-ellian Release is a Reflex save", file: A, from: "save: \"will\", basic: true, dc,", to: "save: \"reflex\", basic: true, dc," },
  { name: "Vir-ellian Release reaches 35 ft", file: A, from: "(feetBetween(me, t) ?? 99) <= 30)", to: "(feetBetween(me, t) ?? 99) <= 35)" },
  { name: "Glyphweave's cantrip is not innate (v1.4)", file: A, from: "ppCost: 0, innate: true, note: \"Glyphweave:", to: "ppCost: 0, note: \"Glyphweave:" },
  { name: "daily preparation invites a new Glyphweave pick", file: A, from: "  if (!owned(actor, \"Innate Magic\", [\"ability\"])) return;", to: "  if (!owned(actor, \"Innate Magic\", [\"ability\"]) && !Array.from(actor.items ?? []).some((i) => i.type === \"heritage\" && norm(i.name) === \"glyphweave\")) return;" },
  { name: "Innate Magic's pick is innate", file: A, from: "ppCost: 0, note: \"Innate Magic (Scaelyn)", to: "ppCost: 0, innate: true, note: \"Innate Magic (Scaelyn)" },
  { name: "Wanderer's Instinct's advantage is never spent", file: A, from: "auto: false, oneShot: true, when: { checkTypes: [\"skill\"], subjects: [\"survival\"] }", to: "auto: false, when: { checkTypes: [\"skill\"], subjects: [\"survival\"] }" },
  { name: "Elemental Affinity's copies may share an element", file: A, from: "const open = AFFINITY_ELEMENTS.filter((e) => !taken.has(e));", to: "const open = AFFINITY_ELEMENTS.slice();" },
  // Found in review
  { name: "THE DEFECT: Null Aura's row lowers a spell attack against DB", file: A, from: "value: -best.classBonus, type: \"untyped\", castingOnly: true }", to: "value: -best.classBonus, type: \"untyped\" }" },
  { name: "a Partial Ley Sense locks nothing (the raw degree)", file: A, from: "  const k = printedDegree(SKILL_ACTIONS.find((a) => a.key === key), degree);", to: "  const k = norm(degree);" },
  { name: "Magic Drain's choices are not asked before the roll", file: A, from: "    await actor.setFlag(MODULE_ID, DRAIN_PLAN_FLAG, { what, to });\n", to: "" },
  { name: "the drain plan is never cleared", file: A, from: "  if (plan) await actor.unsetFlag?.(MODULE_ID, DRAIN_PLAN_FLAG);\n", to: "" },
  { name: "another's item is changed from this client", file: A, from: "    if (target?.isOwner !== false && target) {", to: "    if (target) {" },
  { name: "the energy lasts a minute per energy, not per PP drained", file: A, from: "  const minutes = Math.max(1, result.drained);", to: "  const minutes = Math.max(1, energy);" },
  { name: "the DB bonus is untyped again", file: A, from: "[{ key: \"system.combat.defence.racial\", mode: 0, value: \"1\", priority: 20 }]", to: "[{ key: \"system.combat.defence.other\", mode: 2, value: \"1\", priority: 20 }]" },
  { name: "Quickbind skips Invest Item's rules", file: A, from: "      if (refused) { await card(actor, \"Quickbind\", [line(`<em>${esc(item.name)} cannot be invested: ${esc(refused)}.</em>`)]); return; }\n", to: "" },
  { name: "Wanderer's Instinct is pre-ticked on every Survival check", file: A, from: "— tick it on that check\", auto: false, oneShot: true,", to: "— tick it on that check\", auto: true, oneShot: true," },
  { name: "the turn clock has no backstop", file: f("module", "effects-clock.mjs"), from: "return { system: { spellEffect: true, spellEffectEnd: Math.trunc(Number(now?.worldTime ?? 0)) + 12 }, module: { combatId, [TURN_END_FLAG]", to: "return { system: {}, module: { combatId, [TURN_END_FLAG]" },
  // Registration and wiring
  { name: "the Nyrinn's Power Points are 0", file: REG, from: "Nyrinn: -1, Scaelyn: 1 });", to: "Nyrinn: 0, Scaelyn: 1 });" },
  { name: "the Emberkin may take Dracoris", file: REG, from: "Emberkin: Object.freeze([\"Component Savant\", \"Self Aware\"]),", to: "Emberkin: Object.freeze([\"Component Savant\", \"Self Aware\", \"Dracoris\"])," },
  { name: "Adept makes a weapon Martial", file: REG, from: "Adept: Object.freeze({ categoryAs: \"Simple\",", to: "Adept: Object.freeze({ categoryAs: \"Martial\"," },
  { name: "the surcharge is not registered", file: REG, from: "  api.registerCastSurcharge?.(\"zhalVryn\", zhalVrynSurcharge, moduleId);\n", to: "" },
  { name: "the release path is not registered", file: REG, from: "  api.registerReleasePath?.(\"lingualCasting\", lingualCastingPath, moduleId);\n", to: "" },
  { name: "the attempt hook is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeActionAttempt\", (ctx) => onActionAttemptB1(ctx));", to: "" },
  { name: "the effect-ended hook is not wired", file: SCRIPT, from: "Hooks.on(\"deleteActiveEffect\", (effect) => { onEffectDeletedB1(effect)", to: "Hooks.on(\"deleteItem\", (effect) => { onEffectDeletedB1(effect)" },
  { name: "the module still expects 3.676.1", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.676.1\";" },
  { name: "the module still reminds the GM of Null Aura (the 0.1.x hook)", file: SCRIPT, from: "Hooks.on(\"deleteCombat\", (combat) => { onCombatDeleted(combat)", to: "Hooks.on(\"trgPrimeSpellCast\", (ctx) => onSpellCastB1(ctx));\nHooks.on(\"deleteCombat\", (combat) => { onCombatDeleted(combat)" },
  { name: "the weapons pack extends gear", file: C, from: "extends: \"weapons\", docs: WEAPONS", to: "extends: \"gear\", docs: WEAPONS" },
  { name: "the manifest's version is below 0.2.0", file: MANIFEST, from: "\"version\": \"0.17.2\",", to: "\"version\": \"0.1.1\"," },
  { name: "the manifest accepts TRG Prime 3.676.1", file: MANIFEST, from: "\"minimum\": \"3.694.0\"", to: "\"minimum\": \"3.676.1\"" },
  { name: "0.1.1's defect: no pack folder", file: MANIFEST, from: "\"packFolders\": [", to: "\"packFoldersX\": [" },
  { name: "a pack is left out of the folder", file: MANIFEST, from: "        \"ea-weapons\",\n        \"ea-gear\",\n", to: "        \"ea-weapons\",\n" },
  { name: "the Block 1 packs are not shipped", file: PACKS, from: "export const PACKS = merged(BLOCK1_PACKS, BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK6_PACKS, BLOCK7_PACKS, BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);", to: "export const PACKS = merged(BLOCK1_PACKS.slice(1), BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK6_PACKS, BLOCK7_PACKS, BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);" }
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block1.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: process.env }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block1: verify-block1 already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block1: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block1: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
