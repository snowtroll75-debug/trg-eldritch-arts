#!/usr/bin/env node
/**
 * mutate-block8a — the mutation half of verify-block8a. Each mutation breaks
 * one printed number, one reading, one ruling, one client guard or one wire of
 * Block 8a (0.11.0); verify-block8a must fail on every one. Files are
 * restored after each run, and on any exit. It rewrites files in place: run
 * it on a copy of the tree.
 *
 * verify-block8a is run with EA_MUTATING=1, which skips its packs-source parity
 * check, so a content mutation is caught by a check of its own meaning.
 *
 *   TRG_PRIME_ROOT=../trpg-prime EA_BOOK_MD=… node tools/mutate-block8a.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const f = (...p) => path.join(ROOT, ...p);
const R = f("module", "block8a-rules.mjs"), A = f("module", "block8a-automations.mjs"), C = f("tools", "content", "block8a-spells.mjs"),
  B3S = f("tools", "content", "block3-spells.mjs"), ST = f("tools", "content", "symbol-text.mjs"), D6 = f("module", "block6d-automations.mjs"),
  B2 = f("module", "block2-automations.mjs"), B2B = f("module", "block2b-automations.mjs"), B7 = f("module", "block7-automations.mjs"),
  T7 = f("module", "chapter7-tables.mjs"), SCRIPT = f("scripts", "eldritch-arts.mjs"), REG = f("module", "registration.mjs"), MANIFEST = f("module.json"), PACKS = f("tools", "content", "packs.mjs"), B6CD = f("tools", "content", "block6-d.mjs"),
  TMV = f("module", "token-moves.mjs"), B1M = f("module", "block1-automations.mjs"), AREAS = f("module", "areas.mjs");

const MUTATIONS = [
  // the book's numbers
  { name: "Animal Binding binds level 2", file: R, from: "animalBinding: freeze({ name: \"Animal Binding\", type: \"animal\", max: 1 }),", to: "animalBinding: freeze({ name: \"Animal Binding\", type: \"animal\", max: 2 }),"},
  { name: "Entity Binding binds an elemental", file: R, from: "entityBinding: freeze({ name: \"Entity Binding\", type: \"aberration\", max: 8 }),", to: "entityBinding: freeze({ name: \"Entity Binding\", type: \"elemental\", max: 8 }),"},
  { name: "the range is 60 feet", file: R, from: "export const BINDING_RANGE_FEET = 30;", to: "export const BINDING_RANGE_FEET = 60;" },
  { name: "the warp has a ceiling", file: R, from: "(BINDINGS[key]?.max ?? 0) + Math.max(0, int(warpBonus));", to: "(BINDINGS[key]?.max ?? 0) + Math.min(1, Math.max(0, int(warpBonus)));" },
  { name: "Q169: the loyal bonus is +1", file: R, from: "export const LOYAL_BONUS = 2;", to: "export const LOYAL_BONUS = 1;" },
  // the ladders (m42)
  { name: "m42: a Partial is free", file: R, from: "    partial: [\"partial\", \"failure\"], failure:", to: "    partial: [\"partial\", \"success\"], failure:" },
  { name: "m42: a Blunder reads Failure, not Fumble", file: R, from: "blunder: [\"blunder\", \"fumble\", \"failure\"]", to: "blunder: [\"blunder\", \"failure\"]" },
  { name: "m42: a Heroic reads Success", file: R, from: "heroic: [\"heroic\", \"critical\", \"success\"]", to: "heroic: [\"heroic\", \"success\"]" },
  { name: "a Fumble circle no longer makes it hostile", file: R, from: "  if (circleFumble) return \"hostile\";\n", to: "" },
  { name: "Q168: a free creature counts against control levels", file: R, from: "export const bindingControls = (outcome) => outcome === \"bound\" || outcome === \"loyal\";", to: "export const bindingControls = (outcome) => outcome !== \"hostile\";" },
  { name: "the true name triggers on a Partial", file: R, from: "export const trueNameHostile = (degree) => succeeded(degree);", to: "export const trueNameHostile = (degree) => succeeded(degree) || norm(degree) === \"partial\";" },
  { name: "the level is not checked", file: R, from: "  if (int(level) > int(maxLevel)) return", to: "  if (false) return" },
  { name: "the trait is not checked", file: R, from: "  if (!traits.has(spec.type)) return", to: "  if (false) return" },
  { name: "the caster may bind itself", file: R, from: "  if (isCaster) return `${spec.name} cannot bind its caster.`;\n", to: "" },
  { name: "Symbol of Pain's Fumble is injured 3", file: R, from: "failure: freeze({ hold: 2 }), fumble: freeze({ hold: 4 })", to: "failure: freeze({ hold: 2 }), fumble: freeze({ hold: 3 })" },
  { name: "Symbol of Weakness's Partial is weakened 1", file: R, from: "partial: freeze({ hold: 2 }), failure: freeze({ hold: 4 }), fumble: freeze({ hold: 6 })", to: "partial: freeze({ hold: 1 }), failure: freeze({ hold: 4 }), fumble: freeze({ hold: 6 })" },
  { name: "Symbol of Fear's fleeing lasts 2 rounds", file: R, from: "failure: freeze({ conditions: freeze([cond(\"frightened\", 4), cond(\"fleeing\", null, { rounds: 1 })]) }),", to: "failure: freeze({ conditions: freeze([cond(\"frightened\", 4), cond(\"fleeing\", null, { rounds: 2 })]) })," },
  { name: "Symbol of Death's Failure is a serious critical", file: R, from: "failure: freeze({ critical: freeze({ severity: \"deadly\", damageType: \"essence\" }) })", to: "failure: freeze({ critical: freeze({ severity: \"serious\", damageType: \"essence\" }) })" },
  { name: "injured keeps the higher (it adds)", file: R, from: "curse: true, held: \"injured\", adds: true,", to: "curse: true, held: \"injured\", adds: false," },
  { name: "an equal result replaces", file: R, from: "  if (n <= h) return { apply: 0,", to: "  if (n < h) return { apply: 0," },
  { name: "the hold's share is not counted", file: R, from: "contributed: Math.max(0, int(contributed)) + (after - c), worse: true };", to: "contributed: Math.max(0, int(contributed)), worse: true };" },
  { name: "m135: the hold's distance is 30 feet", file: R, from: "export const SYMBOL_HOLD_FEET = 60;", to: "export const SYMBOL_HOLD_FEET = 30;" },
  { name: "m135: the hour never stops", file: R, from: "  return running ? \"stop\" : \"unchanged\";", to: "  return \"unchanged\";" },
  { name: "the glow lasts 1 minute", file: R, from: "export const SYMBOL_GLOW_SECONDS = 600;", to: "export const SYMBOL_GLOW_SECONDS = 60;" },
  { name: "Insanity: a Partial is a success", file: R, from: "export const insanityFails = (degree) => [\"partial\", \"failure\", \"fumble\", \"blunder\"].includes(norm(degree));", to: "export const insanityFails = (degree) => [\"failure\", \"fumble\", \"blunder\"].includes(norm(degree));" },
  { name: "the rift's warp adds nothing", file: R, from: "  return extra ? `${3 + int(extra[1])}d8` : RIFT_DICE;", to: "  return RIFT_DICE;" },
  { name: "the archway bears 5 × the allowance", file: R, from: "export const ARCHWAY_LOAD_FACTOR = 10;", to: "export const ARCHWAY_LOAD_FACTOR = 5;" },
  { name: "a Tiny creature triggers the riserune", file: R, from: "export const RISERUNE_SIZES = freeze([\"small\",", to: "export const RISERUNE_SIZES = freeze([\"tiny\", \"small\"," },
  { name: "the riserune stores 4", file: R, from: "export const RISERUNE_TRIGGERS = 3;", to: "export const RISERUNE_TRIGGERS = 4;" },
  { name: "a year is a month", file: R, from: "  if (/year/.test(t)) return 365 * 86400;", to: "  if (/year/.test(t)) return 30 * 86400;" },
  { name: "Ley Line Effects reach a dominated creature", file: R, from: "export const SUMMONED_SOURCES = freeze([\"bound\", \"conjured\"]);", to: "export const SUMMONED_SOURCES = freeze([\"bound\", \"conjured\", \"dominated\"]);" },
  // the content
  { name: "a Binding is a save spell (the core's cast save)", file: C, from: "    key, grade: \"B\", category: \"utility\", defence: \"\",\n    effects: [note(`${b.name}: once the cast", to: "    key, grade: \"B\", category: \"save\", defence: \"Will\",\n    effects: [note(`${b.name}: once the cast" },
  { name: "a Binding's warp buys nothing", file: C, from: "    warpMods: [{ bonusValue: 1 }],\n    what: `the GM places", to: "    warpMods: [{}],\n    what: `the GM places" },
  { name: "a Symbol of Pain is a save spell", file: C, from: "\"SYMBOL OF PAIN\": { key: \"symbolOfPain\", grade: \"B\", category: \"utility\", defence: \"\",", to: "\"SYMBOL OF PAIN\": { key: \"symbolOfPain\", grade: \"B\", category: \"save\", defence: \"Fortitude\"," },
  { name: "Arcane Pouch targets a creature", file: C, from: "    key: \"arcanePouch\", grade: \"C\", category: \"utility\", targetsObject: true,", to: "    key: \"arcanePouch\", grade: \"C\", category: \"utility\"," },
  { name: "Arcane Pouch's bonus is +2", file: R, from: "export const POUCH_CONCEAL_BONUS = 1;", to: "export const POUCH_CONCEAL_BONUS = 2;" },
  { name: "Wall of Sand's sections have 25 HP", file: C, from: "sections: { size: 5, db: 0, hardness: 5, hp: 20 } },", to: "sections: { size: 5, db: 0, hardness: 5, hp: 25 } }," },
  { name: "Wall of Sand blocks movement", file: C, from: "block: { move: \"none\", sight: \"limited\", light: \"none\", sound: \"none\" }, unobstructed: true, sections: { size: 5, db: 0, hardness: 5, hp: 20 }", to: "block: { move: \"normal\", sight: \"limited\", light: \"none\", sound: \"none\" }, unobstructed: true, sections: { size: 5, db: 0, hardness: 5, hp: 20 }" },
  { name: "Argent Mark's permanent warp is a year", file: C, from: "warpMods: [{ durationText: \"1 month\" }, { durationText: \"1 year\" }, { durationText: \"permanent\" }],", to: "warpMods: [{ durationText: \"1 month\" }, { durationText: \"1 year\" }, { durationText: \"1 year\" }]," },
  { name: "Harmonic Rift's damage warp is dropped", file: C, from: "    warpMods: [{ damageDice: \"1d8\" }, { durationText: \"10 minutes\" }],", to: "    warpMods: [{}, { durationText: \"10 minutes\" }]," },
  { name: "Farsight's card claims automation", file: C, from: "    key: \"farsight\", grade: \"D\",", to: "    key: \"farsight\", grade: \"C\"," },
  { name: "Symbol of Death is not keyed (not rebuilt)", file: B3S, from: "    category: \"utility\", defence: \"\", key: \"symbolOfDeath\",", to: "    category: \"utility\", defence: \"\"," },
  { name: "Symbol of Fear's card is the 0.5.0 one", file: B3S, from: "    text: symbolText(\"symbolOfFear\"),", to: "    text: \"*Not automated:* by hand.\"," },
  { name: "the 22 are not in the pack", file: PACKS, from: "export const PACKS = merged(BLOCK1_PACKS, BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK6_PACKS, BLOCK7_PACKS, BLOCK8A_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);", to: "export const PACKS = merged(BLOCK1_PACKS, BLOCK3_PACKS, BLOCK4_PACKS, BLOCK5_PACKS, BLOCK6_PACKS, BLOCK7_PACKS, BLOCK8B_PACKS, BLOCK9A_PACKS, BLOCK9B_PACKS, BLOCK9C_PACKS, BLOCK10_PACKS, BLOCK10B_PACKS);" },
  // the Bindings
  { name: "the settled record forgets the cast's id", file: A, from: "    key, spellName: ctx.spell?.name ?? spec.name, castId: entry?.id ?? \"\",", to: "    key, spellName: ctx.spell?.name ?? spec.name, castId: \"\"," },
  { name: "the record forgets the warps", file: A, from: "    maxLevel: R.bindingMaxLevel(key, ctx.warpMods?.bonusValue), type: spec.type,", to: "    maxLevel: R.bindingMaxLevel(key, 0), type: spec.type," },
  { name: "the GM card is not whispered", file: A, from: "label: binder ? \"Roll its Will save\" : \"Bind the selected creature\" }], { gm: true });", to: "label: binder ? \"Roll its Will save\" : \"Bind the selected creature\" }], {});" },
  { name: "the save is rolled at DC 0", file: A, from: "subject: \"will\", dc: rec.saveDC, label: `${creature.name} — Will (DC ${rec.saveDC})`, subtitle: `${rec.spellName}: resisting the binding`", to: "subject: \"will\", dc: 0, label: `${creature.name} — Will (DC ${rec.saveDC})`, subtitle: `${rec.spellName}: resisting the binding`" },
  { name: "the refusal is not asked", file: A, from: "  if (refusal) return warn(`Eldritch Arts: ${refusal}`);\n", to: "" },
  { name: "a second press binds again", file: A, from: "  if (rec.state !== \"pending\") return warn(", to: "  if (false) return warn(" },
  { name: "the entry is not \"bound\"", file: A, from: "level: int(creature.system?.identity?.level), source: \"bound\", castId: rec.castId,", to: "level: int(creature.system?.identity?.level), source: \"conjured\", castId: rec.castId," },
  { name: "the entry names no module", file: A, from: "data: { module: MODULE_ID, key: rec.key, recordId: rec.id } });", to: "data: { key: rec.key, recordId: rec.id } });" },
  { name: "a loyal creature gets no +2", file: A, from: "    system: outcome === \"loyal\" ? { conditionals:", to: "    system: false ? { conditionals:" },
  { name: "a Critical does not end the spell", file: A, from: "    await endBindingCast(caster, marker, next);\n    return next;\n  }\n  if (outcome === \"free\")", to: "    return next;\n  }\n  if (outcome === \"free\")" },
  { name: "the true name is ignored", file: A, from: "  if (rec.trueName && R.trueNameHostile(degree)) {", to: "  if (false) {" },
  { name: "the end does not release the entry", file: A, from: "  if (rec.entryId && (await h().controlledOf(caster)).some((e) => e?.id === rec.entryId)) await h().releaseControlled(caster, rec.entryId, { reason: \"ended\" });", to: "" },
  { name: "the end leaves the bound effect", file: A, from: "  if (creature && ids.length) await writeOn(creature, { kind: \"deleteEffects\", ids });", to: "" },
  { name: "the end runs on every client", file: A, from: "  if (!caster || caster.documentName !== \"Actor\" || !actsFor(caster)) return null;", to: "  if (!caster || caster.documentName !== \"Actor\") return null;" },
  { name: "a free creature's end says nothing", file: A, from: "  if (rec.state === \"free\") { await card(caster, rec.spellName, [line(`${esc(rec.spellName)} ends: ${returns}.`)]); return \"free\"; }", to: "  if (rec.state === \"free\") return \"free\";" },
  { name: "Versatile Binder's creature is returned, not released", file: A, from: "  const returns = rec.binder ? `${who} is released where it stands (Q168)`", to: "  const returns = false ? `${who} is released where it stands (Q168)`" },
  { name: "the overflow filter answers any release", file: A, from: "  if (reason !== \"overflow\" || entry?.data?.module !== MODULE_ID || !controller) return null;", to: "  if (entry?.data?.module !== MODULE_ID || !controller) return null;" },
  { name: "the overflow filter answers another module's", file: A, from: "  if (reason !== \"overflow\" || entry?.data?.module !== MODULE_ID || !controller) return null;", to: "  if (reason !== \"overflow\" || !controller) return null;" },
  { name: "a broken binding does not end", file: A, from: "  await marker.setFlag(MODULE_ID, R.BINDING_FLAG, rec);\n  await endBindingCast(controller, marker, rec);", to: "  await marker.setFlag(MODULE_ID, R.BINDING_FLAG, rec);" },
  { name: "Versatile Binder's choice is not taken", file: A, from: "  const binder = (ctx.metamagic ?? []).includes(\"versatilebinder\") ? takeBinderChoice(actor) : \"\";", to: "  const binder = \"\";" },
  { name: "Versatile Binder rolls its own save again", file: D6, from: "  if (isBinding(String(ctx.spell?.flags?.[SYSTEM_ID]?.eaGrimoire ?? \"\"))) {", to: "  if (false) {" },
  { name: "a player presses the GM's button", file: A, from: "  if (spec.gm && !user?.isGM) return warn(", to: "  if (false) return warn(" },
  { name: "anyone presses the caster's button", file: A, from: "  if (spec.owner && !caster.isOwner) return warn(", to: "  if (false) return warn(" },
  // the Symbols
  { name: "a symbol is carved at any distance", file: A, from: "  if (feet === null || feet > R.TOUCH_FEET) { await card(actor, ctx.spell?.name, [line(`<em>That is", to: "  if (false) { await card(actor, ctx.spell?.name, [line(`<em>That is" },
  { name: "the symbol is shown to the players", file: A, from: "    name: `${rec.spellName} (symbol)`, color: \"#7a1f9a\", visibility: regionVisibility(\"GAMEMASTER\"),", to: "    name: `${rec.spellName} (symbol)`, color: \"#7a1f9a\", visibility: regionVisibility(\"ALWAYS\")," },
  { name: "walls do not block line of sight", file: A, from: "!sightBlocked(point, mover && t.document === mover.doc ? docCentre(mover.at) : tokenCentre(t)));", to: "true);" },
  { name: "the GM's untick is ignored", file: A, from: "callback: (event, button) => list.filter((t, i) => button.form?.elements?.[`t${i}`]?.checked) }", to: "callback: (event, button) => list }" },
  { name: "the fear carries no traits", file: A, from: "      await h().applyConditionTagsTo(creature, tags, { sourceTraits: rec.traits });", to: "      await h().applyConditionTagsTo(creature, tags, {});" },
  { name: "fleeing has no end", file: A, from: "...(c.rounds ? { expiresTime: worldNow() + 6 * c.rounds,", to: "...(false ? { expiresTime: worldNow() + 6 * c.rounds," },
  { name: "the critical is serious", file: A, from: "severity: rung.critical.severity, damageType: rung.critical.damageType, attackBonus: rec.saveDC });", to: "severity: \"serious\", damageType: rung.critical.damageType, attackBonus: rec.saveDC });" },
  { name: "a death does not fade the symbol", file: A, from: "  if (spec.fadesOnDeath && slain.length) {", to: "  if (false) {" },
  { name: "Insanity is not core Insanity", file: A, from: "      const marked = await h().markTurnTable(creature, \"insanity\", { margin: check?.outcome?.margin ?? null,", to: "      const marked = await h().markTurnTable(creature, \"insanity\", { margin: null," },
  { name: "the hold holds nothing", file: A, from: "heldConditions: { keys: [spec.held], values: { [spec.held]: step.contributed }, endWith: true, label: spec.name }", to: "heldConditions: { keys: [], values: { [spec.held]: step.contributed }, endWith: true, label: spec.name }" },
  { name: "the hold is not Remove Curse's (no traits)", file: A, from: "endWith: true, label: spec.name }, sourceTraits: rec.traits, counteractAs:", to: "endWith: true, label: spec.name }, counteractAs:" },
  { name: "the held condition carries the curse's traits", file: A, from: "  await h().applyConditionTagsTo(creature, [{ key: spec.held, label: spec.held, value: step.apply }], {});", to: "  await h().applyConditionTagsTo(creature, [{ key: spec.held, label: spec.held, value: step.apply }], { sourceTraits: rec.traits });" },
  { name: "a far creature's hour waits for a move", file: A, from: "  const far = token ? (feetFromPointDoc({ x: rec.x, y: rec.y }, token.document ?? token) ?? 0) > R.SYMBOL_HOLD_FEET : false;", to: "  const far = false;" },
  { name: "a worse flash makes a second hold", file: A, from: "  if (hold) await hold.update({ name,", to: "  if (false) await hold.update({ name," },
  { name: "the glow is kept by any client", file: A, from: "  if (!isActingGM()) return 0;\n  let changed = 0;\n  // EVERY SCENE", to: "  let changed = 0;\n  // EVERY SCENE" },
  { name: "the glow never lapses", file: A, from: "    if (R.glowLapsed(rec.lastSeen, t)) {", to: "    if (false) {" },
  { name: "the curse's hour is kept by any client", file: A, from: "  if (!actor || !doc || !actsFor(actor)) return 0;", to: "  if (!actor || !doc) return 0;" },
  // the utilities
  { name: "Arcane Pouch: a new casting keeps the last", file: A, from: "  if (older.length) await actor.deleteEmbeddedDocuments(\"ActiveEffect\", older);", to: "" },
  { name: "the archway's far square is kept", file: A, from: "    if (feet === null || feet > R.ARCHWAY_RANGE_FEET) { warn(", to: "    if (false) { warn(" },
  { name: "the archway's HP is the current HP", file: A, from: "  const hp = int(actor.system?.resources?.hp?.max);", to: "  const hp = int(actor.system?.resources?.hp?.value) - 1;" },
  { name: "Argent Mark lasts forever", file: A, from: "expiry: seconds ? forSeconds(seconds) : null", to: "expiry: null" },
  { name: "Blood Biography: a Success does not block", file: R, from: "export const bloodBlocked = (degree) => succeeded(degree);", to: "export const bloodBlocked = (degree) => [\"heroic\", \"critical\"].includes(norm(degree));" },
  { name: "Blood Biography can be answered twice", file: A, from: "  delete all[id];\n  await caster.setFlag(MODULE_ID, PENDING_FLAG, all);", to: "  await caster.setFlag(MODULE_ID, PENDING_FLAG, all);" },
  { name: "a rift opening beyond 500 ft is kept", file: A, from: "    if (feet === null || feet > R.RIFT_RANGE_FEET) { warn(", to: "    if (false) { warn(" },
  { name: "a second teleport this turn succeeds", file: A, from: "    if (await h().teleportationFails(actor)) {", to: "    if (false) {" },
  { name: "the arrival is a passage too (ping-pong)", file: A, from: "  if (options?.eaRift) return null;\n", to: "" },
  { name: "an ally takes the sonic", file: A, from: "    if (caster && enemiesBySide(casterSide, doc.disposition)) {", to: "    if (caster) {" },
  { name: "the rift asks no teleport card", file: A, from: "    if (caster) lines.push(...(await h().teleportationArrives(caster, spell, [actor]) ?? []));", to: "" },
  { name: "the riserune ignores its limit", file: A, from: "    if (rec.records.length >= R.RISERUNE_TRIGGERS) continue;", to: "" },
  { name: "the riserune is replayed from anywhere", file: A, from: "  if (!me || (feetFromPoint({ x: rec.x, y: rec.y }, me) ?? Infinity) > R.TOUCH_FEET) return warn(", to: "  if (false) return warn(" },
  { name: "the module's Regions never end", file: A, from: "    const gone = Array.from(sc?.regions ?? []).filter((r) => areaRecord(r) && Number(areaRecord(r).until) <= worldNow()).map((r) => r.id);", to: "    const gone = [];" },
  { name: "the deferred teleports are not registered", file: A, from: "  api.registerDeferredTeleport?.(\"eaArcanePouch\",", to: "  api.registerDeferredTeleportX?.(\"eaArcanePouch\"," },
  // Ley Line Effects 25–27
  { name: "row 25 is manual again", file: T7, from: "e: { kind: \"summons\", row: { kind: \"cond\"", to: "e: { kind: \"manual\", row: { kind: \"cond\"" },
  { name: "the summons case applies to the caster", file: B2, from: "        out.push(...await applyRow(creature, spec.row, ctx));", to: "        out.push(...await applyRow(actor, spec.row, ctx));" },
  // the wiring
  { name: "the settled cast is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeSpellSettled\", (ctx) => { onSpellSettledB8a(ctx)", to: "Hooks.on(\"trgPrimeSpellCast\", (ctx) => { onSpellSettledB8a(ctx)" },
  { name: "the release hook is not wired", file: SCRIPT, from: "Hooks.on(\"trgPrimeControlReleased\", (payload) => { onControlReleasedB8a(payload)", to: "Hooks.on(\"trgPrimeControlFreed\", (payload) => { onControlReleasedB8a(payload)" },
  { name: "the buttons are not wired", file: SCRIPT, from: "Hooks.once(\"ready\", () => registerBlock8aCards());", to: "" },
  { name: "Block 8a is not registered", file: REG, from: "  registerBlock8a(api, moduleId);\n", to: "" },
  { name: "the module asks for 3.685.1 again", file: SCRIPT, from: "export const REQUIRED_SYSTEM = \"3.694.0\";", to: "export const REQUIRED_SYSTEM = \"3.685.1\";" },
  { name: "the manifest accepts 3.685.1", file: MANIFEST, from: "\"minimum\": \"3.694.0\"", to: "\"minimum\": \"3.685.1\"" },
  { name: "Block 2b posts its circle card for a Binding too", file: B2B, from: "  if (ctx.cast && !ctx.refunded && !binding && hasTrait(", to: "  if (ctx.cast && !ctx.refunded && hasTrait(" },
  { name: "the relay will not delete a bound effect", file: B7, from: "\"bouncyBody\", \"bound8a\", \"confluenceLink8b\"]);", to: "\"bouncyBody\", \"confluenceLink8b\"]);" },
  { name: "Versatile Binder stays graded C", file: B6CD, from: '"Versatile Binder": { level: "B",', to: '"Versatile Binder": { level: "C",' },
  { name: "Versatile Binder's card keeps the 0.9.0 prefix", file: B6CD, from: "    automation: `${AUTO8A} ${WARP} on a spell with the Summons trait", to: "    automation: `${PART} ${WARP} on a spell with the Summons trait" },
  { name: "Symbol of Death's critical has no attack bonus (DC 10)", file: A, from: ", attackBonus: rec.saveDC });", to: ");" },
  { name: "a dismissed symbol still flashes", file: A, from: "  if (!castStands(caster, rec.castId)) {\n    await region.delete?.();", to: "  if (false) {\n    await region.delete?.();" },
  { name: "a cast with an id always stands", file: A, from: "const castStands = (caster, castId) => !castId || ", to: "const castStands = (caster, castId) => true || " },
  { name: "the sweep ignores the active spells' change", file: A, from: "  if (!flags || !(\"activeSpells\" in flags || \"-=activeSpells\" in flags)) return 0;", to: "  if (!flags || true) return 0;" },
  { name: "the sweep runs on every GM's client", file: A, from: "  if (!isActingGM() || !caster) return 0;\n  let n = 0;\n  for (const scene of allScenes()) {\n    const gone = symbolRegions(scene)", to: "  if (!caster) return 0;\n  let n = 0;\n  for (const scene of allScenes()) {\n    const gone = symbolRegions(scene)" },
  { name: "a symbol with no cast never stands", file: A, from: "const castStands = (caster, castId) => !castId || ", to: "const castStands = (caster, castId) => " },
  { name: "the sweep looks only at the canvas's scene", file: A, from: "const allScenes = () => { const list = Array.from(globalThis.game?.scenes ?? []); return list.length ? list : [globalThis.canvas?.scene].filter(Boolean); };", to: "const allScenes = () => [globalThis.canvas?.scene].filter(Boolean);" },
  { name: "the sweep is not wired", file: SCRIPT, from: "Hooks.on(\"updateActor\", (actor, change) => { onActorUpdatedB8a(actor, change).catch(warnB8a(\"a dismissed symbol\")); });", to: "" },
  { name: "the glow skips a scene with no one on it", file: A, from: "    if (!viewed && Array.from(region.parent?.tokens ?? []).length) continue;", to: "    if (!viewed) continue;" },
  { name: "every scene is read as the canvas's", file: A, from: "    const viewed = !region.parent || region.parent === globalThis.canvas?.scene;", to: "    const viewed = true;" },
  { name: "the rift needs a placeable", file: A, from: "  if (!doc || !actor || !actsFor(actor)) return null;\n  // A MOVE STILL UNDER WAY", to: "  if (!doc?.object || !actor || !actsFor(actor)) return null;\n  // A MOVE STILL UNDER WAY" },
  { name: "the hour needs a placeable", file: A, from: "  const pos = at;\n  if (!actor || !doc || !actsFor(actor)) return 0;", to: "  const pos = at;\n  if (!actor || !doc?.object || !actsFor(actor)) return 0;" },
  { name: "the document's distance ignores its size", file: A, from: "  const reach = ((Math.max(1, Number(doc.width ?? 1)) - 1) / 2) * distance;\n  return Math.max(0, Math.round(Number(measured) - reach));", to: "  return Math.max(0, Math.round(Number(measured)));" },
  { name: "a missing measurePath reads as 0 ft", file: A, from: "  if (measured === null || measured === undefined || !Number.isFinite(Number(measured))) measured =", to: "  if (!Number.isFinite(Number(measured))) measured =" },
  { name: "expiry looks only at the canvas's scene", file: A, from: "  for (const sc of scene ? [scene] : allScenes()) {", to: "  for (const sc of [scene ?? globalThis.canvas?.scene]) {" },
  { name: "any GM binds", file: A, from: "  if (globalThis.game?.user?.isGM && !isActiveGMAccount()) return warn(\"Eldritch Arts: another GM is the acting GM; that GM binds the creature.\");\n", to: "" },
  { name: "no claim before the save", file: A, from: "  if (claimedBindings.has(rec.id)) return warn(", to: "  if (false) return warn(" },
  { name: "Wall of Sand offers only the length", file: C, from: "    splitWarp: { index: 1, choices: [", to: "    splitWarpOff: { index: 1, choices: [" },
  { name: "Wall of Sand's height choice raises nothing", file: C, from: "mods: { wallHeight: 5 } }", to: "mods: {} }" },
  { name: "the rift lands on the canvas's grid", file: A, from: "    const g = sceneGridOf(doc.parent).size;\n    const dest = {", to: "    const g = gridPx();\n    const dest = {" },
  { name: "a stale claim is never taken over", file: A, from: "  if (rec.state === \"binding\" && R.claimIsStale(", to: "  if (false && R.claimIsStale(" },
  { name: "a taken-over claim is not said", file: A, from: "  const lines = [...(tookOver ? [", to: "  const lines = [...(false ? [" },
  { name: "the claim names nobody", file: A, from: "claim: { user: String(globalThis.game?.user?.id ?? \"\"), at: Date.now() } });", to: "claim: { user: \"\", at: Date.now() } });" },
  { name: "a connected claimer is always stale", file: R, from: "  if (!isActive(String(claim.user))) return true;", to: "  return true;" },
  { name: "a claim never ages", file: R, from: "  return Number(now) - Number(claim.at ?? 0) > BINDING_CLAIM_STALE_MS;", to: "  return false;" },
  { name: "the claim ages in one minute", file: R, from: "export const BINDING_CLAIM_STALE_MS = 120000;", to: "export const BINDING_CLAIM_STALE_MS = 60000;" },
  { name: "the rift trusts the stale doc.regions again", file: A, from: "    const inside = await h().regionContains(region, docCentre(pos));", to: "    const inside = Boolean(doc.regions?.has?.(region)) || await h().regionContains(region, docCentre(pos));" },
  { name: "the rift's save line is escaped again", file: A, from: "${hit?.line ?? \"\"}`);", to: "${esc(hit?.line ?? \"\")}`);" },
  { name: "the rift passes mid-move", file: A, from: "  if (Array.isArray(pending) && pending.length) return null;\n", to: "" },
  { name: "the rift reads the document's stale position", file: A, from: "    const inside = await h().regionContains(region, docCentre(pos));", to: "    const inside = await h().regionContains(region, docCentre(doc));" },
  { name: "Riserune reads the document's stale position", file: A, from: "    const feet = feetFromPointDoc({ x: rec.x, y: rec.y }, at ?? doc);", to: "    const feet = feetFromPointDoc({ x: rec.x, y: rec.y }, doc);" },
  { name: "the curse's hour reads the document's stale position", file: A, from: "feetFromPointDoc({ x: at.x, y: at.y }, pos ?? doc) : Infinity;", to: "feetFromPointDoc({ x: at.x, y: at.y }, doc) : Infinity;" },
  { name: "the glow reads the mover's old square", file: A, from: "mover && t.document === mover.doc ? docCentre(mover.at) : tokenCentre(t)", to: "tokenCentre(t)" },
  { name: "a refused rift move still passes", file: A, from: "    if (!moved) {\n      await card(actor, \"Harmonic Rift\"", to: "    if (false) {\n      await card(actor, \"Harmonic Rift\"" },
  { name: "V14's _movement record is not read", file: A, from: "(options?.movement?.[doc.id] ?? options?._movement?.[doc.id])?.pending?.waypoints", to: "options?.movement?.[doc.id]?.pending?.waypoints" },
  { name: "a refused update that resolves with the document passes", file: A, from: " && Number(doc._source?.x) === dest.x && Number(doc._source?.y) === dest.y;", to: ";" },
  { name: "block1's tokenCentre reads doc.x, not _source", file: B1M, from: "  const s = d?._source ?? (d && Number.isFinite(Number(d.x)) && Number.isFinite(Number(d.y)) ? d : null);", to: "  const s = d && Number.isFinite(Number(d.x)) && Number.isFinite(Number(d.y)) ? d : null;" },
  { name: "block1's tokenCentre skips the document", file: B1M, from: "  const s = d?._source ?? (d && Number.isFinite(Number(d.x)) && Number.isFinite(Number(d.y)) ? d : null);", to: "  const s = d?._source ?? null;" },
  { name: "areas.mjs reads the document, not _source", file: AREAS, from: "  const src = doc?._source ?? (doc?.toObject ? doc.toObject() : doc);", to: "  const src = doc;" },
  { name: "the end position skips _source", file: TMV, from: "  const pick = (k, fallback) => Number(c[k] ?? s[k] ?? doc?.[k] ?? fallback);", to: "  const pick = (k, fallback) => Number(c[k] ?? doc?.[k] ?? fallback);" },
  { name: "the end position prefers _source to change", file: TMV, from: "  const pick = (k, fallback) => Number(c[k] ?? s[k] ?? doc?.[k] ?? fallback);", to: "  const pick = (k, fallback) => Number(s[k] ?? c[k] ?? doc?.[k] ?? fallback);" },
];

const originals = new Map();
for (const m of MUTATIONS) if (!originals.has(m.file)) originals.set(m.file, fs.readFileSync(m.file, "utf8"));
const restore = () => { for (const [file, text] of originals) fs.writeFileSync(file, text); };
process.on("SIGINT", () => { restore(); process.exit(130); });
process.on("SIGTERM", () => { restore(); process.exit(143); });

function run() {
  try { execFileSync(process.execPath, [f("tools", "verify-block8a.mjs")], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, EA_MUTATING: "1" } }); return true; }
  catch { return false; }
}

const results = [];
try {
  if (!run()) { console.error("mutate-block8a: verify-block8a already fails on an unmodified tree."); process.exit(2); }
  for (const m of MUTATIONS) {
    const original = originals.get(m.file);
    const n = original.split(m.from).length - 1;
    if (n !== 1) { results.push({ name: m.name, state: n ? `ANCHOR AMBIGUOUS (${n})` : "ANCHOR MISSING" }); continue; }
    fs.writeFileSync(m.file, original.replace(m.from, m.to));
    const survived = run();
    fs.writeFileSync(m.file, original);
    results.push({ name: m.name, state: survived ? "SURVIVED" : "caught" });
  }
} finally { restore(); }
const bad = results.filter((r) => r.state !== "caught");
for (const r of results) console.log(`  ${r.state === "caught" ? "caught  " : r.state.padEnd(8)}  ${r.name}`);
console.log(bad.length ? `\nmutate-block8a: FAILED — ${bad.length} of ${results.length} not caught.` : `\nmutate-block8a: OK — all ${results.length} mutations caught, tree restored.`);
if (bad.length) process.exitCode = 1;
