#!/usr/bin/env node
/**
 * verify-block9c — Eldritch Arts 0.15.0 (Block 9c, on TRG Prime 3.690.0):
 * Chapter 9's five orbs, nine rods and five staves, and the Spellhold rune's
 * store, against the book (book-text.json) and Graham's rulings (the Block 9
 * audit, Q203, Q207–Q210; Spellhold, "Yes build it", 14 November 2026).
 *
 *   A  the book: every orb, rod and staff has rules, and the pack is built
 *      from them (tools/content/block9c.mjs checks each figure)
 *   B  the pure rules
 *   C  the registrations with TRG Prime
 *   D  the workflows, against stubs
 *   E  the pack
 *   F  the wiring
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block9c.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const CORE = process.env.TRG_PRIME_ROOT ? path.resolve(process.env.TRG_PRIME_ROOT) : path.resolve(ROOT, "..", "trpg-prime");
let checks = 0;
const failures = [];
const ok = (label, cond, detail = "") => { checks += 1; if (!cond) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); };
const equal = (label, a, e) => ok(label, JSON.stringify(a) === JSON.stringify(e), `expected ${JSON.stringify(e)}, got ${JSON.stringify(a)}`);
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");
const strip = (src) => src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");

// The automations import TRG Prime's own modules by route, as they do in Foundry.
globalThis.foundry = { utils: { getRoute: (p) => pathToFileURL(path.join(CORE, String(p).replace(/^systems\/trg-prime\//, ""))).href }, applications: { api: { DialogV2: {} } } };
globalThis.game = { time: { worldTime: 1000 }, user: { targets: new Set(), isGM: true }, combat: null, actors: [], settings: { get: () => null } };
const api = await import(path.join(CORE, "module", "module-api.mjs"));
const R = await import(path.join(ROOT, "module", "block9c-rules.mjs"));
const A = await import(path.join(ROOT, "module", "block9c-automations.mjs"));
const BOOK = JSON.parse(read("tools", "content", "book-text.json"));
const C = await import(path.join(ROOT, "tools", "content", "block9c.mjs"));
const auto = strip(read("module", "block9c-automations.mjs"));

/* ================================================================== A */
equal("A the book prints 5 orbs, 9 rods and 5 staves, every one with rules",
  [BOOK.sections.orbs.length, BOOK.sections.rods.length, BOOK.sections.staves.length,
    BOOK.sections.orbs.every((e) => R.ORBS_9C[e.name]), BOOK.sections.rods.every((e) => R.RODS_9C[e.name]), BOOK.sections.staves.every((e) => R.STAVES_9C[e.name])],
  [5, 9, 5, true, true, true]);
equal("A the pack holds all 19, each checked against its entry as it was built", C.CHARGED_ITEMS_9C.length, 19);
equal("A Verdant Heart at level 13, 39 PP and 25,000 gp, as printed (Q207)", [R.ORBS_9C["ORB OF THE VERDANT HEART"].level, R.ORBS_9C["ORB OF THE VERDANT HEART"].pp, R.ORBS_9C["ORB OF THE VERDANT HEART"].price], [13, 39, 25000]);
equal("A an orb's PP is its level × 3 (L9341)", Object.values(R.ORBS_9C).map((o) => o.pp === o.level * 3), [true, true, true, true, true]);
equal("A Tesra'Anvir as printed (m186: level 18, 180,000 gp)", [R.STAVES_9C["TESRA’ANVIR - ARCANE"].level, R.STAVES_9C["TESRA’ANVIR - ARCANE"].price], [18, 180000]);

/* ================================================================== B */
equal("B the ley-line bonus by the orb's level: +1 to 8, +2 to 16, +3 from 17", [1, 8, 9, 16, 17, 20].map(R.orbLeyBonus), [1, 1, 2, 2, 3, 3]);
equal("B …each orb's own, as printed (+1, +2, +1, +2, +1)", Object.values(R.ORBS_9C).map((o) => o.conditionals[0].value), [1, 2, 1, 2, 1]);
equal("B the bonus reaches Ley Sense, Tap and Channel Ley Line, held, whatever the PP (Q207)",
  Object.values(R.ORBS_9C).map((o) => [o.conditionals[0].when.actions, o.conditionals[0].type, o.conditionals[0].auto, o.conditionals[0].minItemPP ?? null]),
  Object.values(R.ORBS_9C).map(() => [["leySense", "tapLeyLine", "channelLeyLine"], "item", true, null]));
equal("B the 'at least 3 PP' abilities carry the floor (Emberlight's resistance and fire adder, Shifting Currents' Acrobatics, Whispering Veil's Hide)",
  [R.ORBS_9C["ORB OF EMBERLIGHT"].wondrous.map((a) => [a.kind, a.minItemPP]), R.ORBS_9C["ORB OF SHIFTING CURRENTS"].wondrous.map((a) => [a.skill, a.value, a.minItemPP]), R.ORBS_9C["ORB OF THE WHISPERING VEIL"].conditionals.slice(1).map((c) => [c.when.actions, c.value, c.minItemPP])],
  [[["resistance", 3], ["spellAdder", 3]], [["acrobatics", 1, 3]], [[["hide"], 2, 3]]]);
equal("B Emberlight's adder is for fire spells", R.ORBS_9C["ORB OF EMBERLIGHT"].wondrous[1].spellTraits, ["fire"]);
{
  const ctx = { spellPPCost: 6, casterLevel: 5, casterCap: 6, casterTradition: "verdant", skillRanks: { arcana: 6, nature: 3 }, hasUseMagicDevice: true, traditionSkills: { arcane: "arcana", verdant: "nature", divinity: "religion", ethereal: "occultism" } };
  const plain = R.orbReleaseOptions({ ...ctx, spellTradition: "divinity", spellTraits: "Evocation" });
  equal("B the orb's ladder: Spellcraft Hard with no tradition asked (m170), the spell's own skill Very Hard",
    plain.map((o) => [o.key, o.difficulty, o.available, o.dcParts]), [["spellcraft", "hard", true, []], ["tradition:divinity", "veryHard", false, []]]);
  ok("B …a skill's ranks below the PP are said", /religion ranks \(0\) are below the spell's 6 PP/.test(plain[1].reason));
  const hm = R.orbReleaseOptions({ ...ctx, spellTradition: "arcane", spellTraits: "Highmagic, Evocation" });
  equal("B a High Magic spell: Spellcraft's DC +2 more (M81), and Arcana or your own tradition's skill (M80)",
    hm.map((o) => [o.key, o.dcParts.map((p) => p.value), o.available]), [["spellcraft", [2], true], ["tradition:arcane", [], true], ["tradition:verdant", [], false]]);
  equal("B a spell above your cap, or no caster level, is not Spellcraft's", [R.orbReleaseOptions({ ...ctx, spellPPCost: 7 })[0].available, R.orbReleaseOptions({ ...ctx, casterLevel: 0 })[0].available], [false, false]);
  equal("B no Use Magic Device, no skill path", R.orbReleaseOptions({ ...ctx, hasUseMagicDevice: false, spellTradition: "arcane", spellTraits: "" })[1].available, false);
}
equal("B the flare is the 41–65 row only", [R.isFlareRow({ min: 41, max: 65, breaks: true }), R.isFlareRow({ min: 1, max: 10, kind: "explode" }), R.isFlareRow({ min: 41, max: 65 }), R.isFlareRow({ min: 66, max: 90, breaks: true })], [true, false, false, false]);
equal("B Ley Resonance: rate 2 near a line; the most a cast draws; the rod's share rounded up",
  [R.leyResonanceRate(true), R.leyResonanceRate(false), R.leyResonanceMax(10, 2), R.leyResonanceRodCost(7, 2), R.leyResonanceRodCost(7, 1), R.LEY_RESONANCE_FEET], [2, 1, 20, 4, 7, 60]);
equal("B Binding Seal reads Summons; Soul's Echo a save", [R.isSummons("Conjuration, Summons"), R.isSummons("Summon"), R.isSummons("Evocation"), R.hasSave("Will"), R.hasSave("")], [true, true, false, true, false]);
equal("B Spellhold's room by tier: 6, 12, 24, 40", [1, 2, 3, 4, 9].map(R.spellholdCapacity), [6, 12, 24, 40, 40]);
equal("B the rods: Focused Spell's module metamagic up to 4/8/12, Quickening II's quicken to 8, each 2 PP",
  ["ROD OF FOCUSED SPELL I", "ROD OF FOCUSED SPELL II", "ROD OF FOCUSED SPELL III", "ROD OF QUICKENING II"].map((u) => [R.RODS_9C[u].metamagic.kind, R.RODS_9C[u].metamagic.maxPP, R.RODS_9C[u].metamagic.cost]),
  [["focusedspell", 4, 2], ["focusedspell", 8, 2], ["focusedspell", 12, 2], ["quicken", 8, 2]]);
equal("B the module's powers", ["ROD OF LEY RESONANCE", "ROD OF THE BINDING SEAL", "ROD OF THE CATALYST FLOW", "ROD OF SOUL’S ECHO", "ROD OF WILD SURGES"].map((u) => R.RODS_9C[u].power), ["leyResonance", "bindingSeal", "catalystFlow", "soulsEcho", "wildSurges"]);
equal("B Tesra'Anvir: a +4 adder for an arcane or High Magic caster; Quicken for 8 PP, no PP limit (R18)",
  [R.STAVES_9C["TESRA’ANVIR - ARCANE"].wondrous[0], R.STAVES_9C["TESRA’ANVIR - ARCANE"].metamagic],
  [{ kind: "spellAdder", value: 4, requiresArcaneOrHighMagicCaster: true, label: "Tesra’Anvir – Arcane" }, { kind: "quicken", maxPP: 99, cost: 8 }]);
equal("B Eidothrix: +1 item to Spellcraft for a Translocation spell", R.STAVES_9C.EIDOTHRIX.conditionals[0].when, { checkTypes: ["spellcraft"], traits: ["translocation"] });

/* ================================================================== C */
api.resetModuleRegistry();
const registered = { castOptions: [], sources: [] };
A.registerBlock9c({
  registerChargedKind: api.registerChargedKind, registerOneInvestedTraits: api.registerOneInvestedTraits,
  registerCastOption: (k, spec) => { registered.castOptions.push(k); return api.registerCastOption(k, spec); },
  registerCastPPSource: (k, spec) => { registered.sources.push(k); return api.registerCastPPSource(k, spec); }
}, "trg-eldritch-arts");
const orbKind = api.registeredChargedKind("orb");
equal("C the Orb is a charged kind: warped as a staff (Q210), no natural recharge, Recharge Item at 4 PP, its own ladder and depletion",
  [orbKind?.warp, orbKind?.naturalRecharge, orbKind?.rechargeItemPP, orbKind?.releaseOptions === A.orbReleaseOptions, orbKind?.depletion === A.orbDepletion], ["staff", false, 4, true, true]);
equal("C …one invested at a time (H25)", api.registeredOneInvestedTraits(), ["orb"]);
equal("C the rods' casting options and Ley Resonance's PP", [registered.castOptions, registered.sources], [["eaBindingSeal", "eaSoulsEcho", "eaWildSurges"], ["eaLeyResonance"]]);

/* ================================================================== D */
const spent = [];
const cards = [];
let rodRefusal = "";
let chosen = "yes";
const calls = [];
globalThis.game.trgPrime = { modules: { helpers: {
  line: (t) => t, postCard: async (_a, title, lines) => { cards.push([title, lines.join(" ")]); },
  rodUseRefusal: async () => rodRefusal,
  spendFromRod: async (_a, rod, pp, opts) => { spent.push([rod.name, pp, opts?.reason]); return `${rod.name} pays ${pp} PP.`; },
  chooseFromList: async () => chosen,
  heldSpellsIn: async (item) => item.flags["trg-prime"]?.heldSpells ?? [],
  armHold: async (actor, item, opts) => { calls.push(["armHold", item.name, opts]); return true; },
  releaseHeldSpell: async (actor, item, id, opts) => { calls.push(["release", item.name, id, opts]); return { cast: true }; },
  clearHeldSpells: async (item) => { const n = (item.flags["trg-prime"]?.heldSpells ?? []).length; item.flags["trg-prime"].heldSpells = []; return n; }
} } };
globalThis.ui = { notifications: { warn: () => {} } };
const rod = (upper, extra = {}) => ({ id: upper.replace(/\W/g, ""), name: R.RODS_9C[upper].name, system: { equipped: true, invested: true, uses: 10, hp: { value: 0, max: 0 } }, flags: { "trg-eldritch-arts": { charged9c: upper }, "trg-prime": {} }, ...extra });
const actorWith = (...its) => ({ uuid: "Actor.a", name: "Ava", isOwner: true, items: Object.assign(its, { get: (id) => its.find((i) => i.id === id) }) });
{
  const seal = rod("ROD OF THE BINDING SEAL");
  const ava = actorWith(seal);
  const O = A.ROD_OPTIONS_9C;
  const summons = { actor: ava, spell: { system: { traits: "Conjuration, Summons", defence: "" } } };
  ok("D Binding Seal is offered on a Summons spell with the rod held and invested", Boolean(await O.eaBindingSeal.offer(summons)));
  equal("D …not on another spell, an item's or a stored cast, nor with the round's Rod used",
    [await O.eaBindingSeal.offer({ ...summons, spell: { system: { traits: "Evocation" } } }), await O.eaBindingSeal.offer({ ...summons, itemCast: true }), await O.eaBindingSeal.offer({ ...summons, stored: true }), await (async () => { rodRefusal = "only one Rod may be used each round"; const r = await O.eaBindingSeal.offer(summons); rodRefusal = ""; return r; })()],
    [null, null, null, null]);
  seal.system.equipped = false;
  equal("D …nor with the rod not held", await O.eaBindingSeal.offer(summons), null);
  seal.system.equipped = true; seal.system.invested = false;
  equal("D …nor with it not invested", await O.eaBindingSeal.offer(summons), null);
  seal.system.invested = true;
  const applied = await O.eaBindingSeal.apply(summons);
  equal("D taken: casting DC −1", [applied.castingDC, applied.label], [-1, "Rod of the Binding Seal"]);
  spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["eabindingseal"], refunded: false, castPP: 4 });
  equal("D …paid 1 PP from the rod once the cast is settled", spent, [["Rod of the Binding Seal", 1, "Binding Seal"]]);
  await O.eaBindingSeal.apply(summons); spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["eabindingseal"], refunded: true });
  equal("D …nothing for a refunded cast", spent, []);
  await O.eaBindingSeal.apply(summons); spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: [], refunded: false });
  equal("D …nothing when the option was not in the cast's list", spent, []);
  await O.eaBindingSeal.apply(summons); spent.length = 0;
  await A.onSpellHeldB9c({ actor: ava, record: { pp: 4 }, castOptions: ["eaBindingSeal"] });
  equal("D …and paid when the spell is held instead", spent, [["Rod of the Binding Seal", 1, "Binding Seal"]]);
  spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["eabindingseal"], refunded: false });
  equal("D …once only", spent, []);
  // REVIEW: a held cast pays only the powers it took.
  await O.eaBindingSeal.apply(summons); spent.length = 0;
  await A.onSpellHeldB9c({ actor: ava, record: { pp: 4 }, castOptions: [] });
  equal("D (review) a held cast that did not take it pays nothing", spent, []);
  // REVIEW: a cast called off after its options leaves nothing for the next.
  await O.eaBindingSeal.apply(summons);
  await O.eaBindingSeal.offer(summons); spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["eabindingseal"], refunded: false });
  equal("D (review) a new cast's offers drop an earlier cast's unpaid power", spent, []);
}
{
  // REVIEW: "only one Rod may be used each round" — two rods' powers on one cast.
  const seal = rod("ROD OF THE BINDING SEAL"), echo = rod("ROD OF SOUL’S ECHO");
  const ava = actorWith(seal, echo);
  const O = A.ROD_OPTIONS_9C;
  const ctx = { actor: ava, spell: { system: { traits: "Summons", defence: "Will" } } };
  await O.eaBindingSeal.offer(ctx);
  const first = await O.eaBindingSeal.apply(ctx);
  const second = await O.eaSoulsEcho.apply(ctx);
  equal("D (review) the second rod's power is refused, with the reason", [first.castingDC, second.saveDCTarget ?? null, /only one Rod may be used each round/.test(second.lines[0] ?? "")], [-1, null, true]);
  spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["eaBindingSeal", "eaSoulsEcho"], refunded: false });
  equal("D (review) …and only the first rod pays", spent, [["Rod of the Binding Seal", 1, "Binding Seal"]]);
  {
    const surges = rod("ROD OF WILD SURGES"); const bob = actorWith(surges);
    const label = async (holding) => (await O.eaWildSurges.offer({ actor: bob, spell: { system: {} }, holding }))?.label ?? "";
    equal("D (ruling) Wild Surges on a spell being held says it surges as the spell is stored", [/as the spell is stored/.test(await label(true)), /once the spell resolves/.test(await label(false))], [true, true]);
  }
  // RE-REVIEW: a woven spell's settle does not clear the first spell's power.
  await O.eaBindingSeal.offer(ctx); await O.eaBindingSeal.apply(ctx);
  await A.onSpellSettledB9c({ actor: ava, castOptions: [], refunded: false, threaded: true });
  spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["eaBindingSeal"], refunded: false });
  equal("D (re-review) Spellthread's woven settle leaves the first spell's rod power to be paid", spent, [["Rod of the Binding Seal", 1, "Binding Seal"]]);
  // 0.15.2 (TRG Prime 3.691.0): the core's rods this cast, and naming ours to it.
  {
    const seal2 = rod("ROD OF THE BINDING SEAL"); const cara = actorWith(seal2);
    const coreCtx = { actor: cara, spell: { system: { traits: "Summons" } }, rodsThisCast: [{ itemId: "magi1", name: "Rod of the Magi" }] };
    equal("D (0.15.2) a rod power is not offered beside the core's rod this cast", await O.eaBindingSeal.offer(coreCtx), null);
    const refusedCore = await O.eaBindingSeal.apply(coreCtx);
    equal("D (0.15.2) …nor applied, with the reason", [refusedCore.castingDC ?? null, /Rod of the Magi already is/.test(refusedCore.lines?.[0] ?? "")], [null, true]);
    const own = { actor: cara, spell: { system: { traits: "Summons" } }, rodsThisCast: [] };
    await O.eaBindingSeal.offer(own); const took = await O.eaBindingSeal.apply(own);
    equal("D (0.15.2) a power taken names its rod to TRG Prime", [took.rodItemId, took.rodName], [seal2.id, seal2.name]);
    const ley2 = rod("ROD OF LEY RESONANCE"); const dana = actorWith(ley2);
    equal("D (0.15.2) Ley Resonance is not offered beside the core's rod", await A.LEY_RESONANCE_SOURCE.offer({ actor: dana, payable: 4, rodsThisCast: [{ itemId: "x", name: "Rod of Extend" }] }), null);
    const leyOffer = await A.LEY_RESONANCE_SOURCE.offer({ actor: dana, payable: 4 });
    equal("D (0.15.2) …and names itself as a rod when offered", [leyOffer?.rodItemId, leyOffer?.rodName], [ley2.id, ley2.name]);
    await A.LEY_RESONANCE_SOURCE.settle({ actor: dana }, { paid: 0 });
  }
  equal("D (review) the refusal is pure", [A.otherRodRefusal([{ rodId: "a", rodName: "Rod A" }], { id: "a", name: "Rod A" }), A.otherRodRefusal([], { id: "b" })], ["", ""]);
}
{
  const echo = rod("ROD OF SOUL’S ECHO");
  const ava = actorWith(echo);
  const O = A.ROD_OPTIONS_9C;
  equal("D Soul's Echo is offered on a spell with a save, not on one without", [Boolean(await O.eaSoulsEcho.offer({ actor: ava, spell: { system: { defence: "Will" } } })), await O.eaSoulsEcho.offer({ actor: ava, spell: { system: { defence: "" } } })], [true, null]);
  const applied = await O.eaSoulsEcho.apply({ actor: ava, spell: { system: { defence: "Will" } } });
  equal("D …taken: +2 to every undead target's Save DC, and to no one else's", [applied.saveDCTarget, Object.keys(applied).sort()], [{ traits: ["undead"], value: 2 }, ["label", "lines", "rodItemId", "rodName", "saveDCTarget"]]); // + the rod named to TRG Prime (0.15.2)
  spent.length = 0;
  await A.onSpellSettledB9c({ actor: ava, castOptions: ["easoulsecho"], refunded: false });
  equal("D …paid 1 PP", spent, [["Rod of Soul’s Echo", 1, "Soul's Echo"]]);
}
{
  // RE-REVIEW: the Rod of Ley Resonance, once it paid part of the cast, is the cast's Rod.
  const ley = rod("ROD OF LEY RESONANCE"), seal = rod("ROD OF THE BINDING SEAL");
  const ava = actorWith(ley, seal);
  await A.LEY_RESONANCE_SOURCE.offer({ actor: ava, payable: 4 });
  const ctx = { actor: ava, spell: { system: { traits: "Summons" } }, ppSources: [{ key: "eaLeyResonance", label: "Ley", drawn: 2 }] };
  await A.ROD_OPTIONS_9C.eaBindingSeal.offer(ctx);
  const got = await A.ROD_OPTIONS_9C.eaBindingSeal.apply(ctx);
  equal("D (re-review) a power on another rod is refused once Ley Resonance paid", [got.castingDC ?? null, /only one Rod/.test(got.lines?.[0] ?? "")], [null, true]);
  const ctx0 = { ...ctx, ppSources: [{ key: "eaLeyResonance", label: "Ley", drawn: 0 }] };
  await A.ROD_OPTIONS_9C.eaBindingSeal.offer(ctx0);
  equal("D (re-review) …not when it drew nothing", (await A.ROD_OPTIONS_9C.eaBindingSeal.apply(ctx0)).castingDC, -1);
  await A.LEY_RESONANCE_SOURCE.settle({ actor: ava }, { paid: 0 });
}
{
  const ley = rod("ROD OF LEY RESONANCE");
  const ava = actorWith(ley);
  const offer = await A.LEY_RESONANCE_SOURCE.offer({ actor: ava, payable: 6 });
  equal("D Ley Resonance away from a line: draw up to the cast's PP, the rod's PP at 1", offer.max, 6);
  ley.system.uses = 3;
  equal("D …or the rod's PP, if fewer", (await A.LEY_RESONANCE_SOURCE.offer({ actor: ava, payable: 6 })).max, 3);
  spent.length = 0;
  const settled = await A.LEY_RESONANCE_SOURCE.settle({ actor: ava }, { paid: 3 });
  equal("D …paid by the rod as drawn", [spent, settled.lines.length], [[["Rod of Ley Resonance", 3, "Ley Resonance"]], 1]);
  ley.system.uses = 0;
  equal("D an empty rod is not offered", await A.LEY_RESONANCE_SOURCE.offer({ actor: ava, payable: 6 }), null);
}
ok("D near a ley line the rate is 2, read within 60 feet", /const near = Boolean\(await leyLineWithin\(actor, R\.LEY_RESONANCE_FEET\)\);\n\s*const rate = R\.leyResonanceRate\(near\);/.test(auto) && /const cost = R\.leyResonanceRodCost\(paid, memo\.rate\);/.test(auto));
{
  const flow = rod("ROD OF THE CATALYST FLOW");
  const ava = actorWith(flow);
  const lines = [];
  spent.length = 0; chosen = "yes";
  equal("D Catalyst Flow: 2 PP from the rod keeps the catalyst", [await A.catalystFlowKeeps(ava, "Dewdrop", lines), spent], [true, [["Rod of the Catalyst Flow", 2, "Catalyst Flow"]]]);
  chosen = "no"; spent.length = 0;
  equal("D …declined, it is spent and the rod pays nothing", [await A.catalystFlowKeeps(ava, "Dewdrop", []), spent], [false, []]);
  equal("D …no rod, nothing asked", await A.catalystFlowKeeps(actorWith(), "Dewdrop", []), false);
  chosen = "yes";
}
ok("D the catalyst's settle asks the rod only once Conservation has not kept it (Q209)",
  /let keep = await conservation\(actor, ctx\.degree, lines\);\n[\s\S]{0,200}?if \(!keep\) \{\n\s*const \{ catalystFlowKeeps \} = await import\("\.\/block9c-automations\.mjs"\);\n\s*keep = await catalystFlowKeeps\(actor, spec\.name, lines\);/.test(read("module", "block9a-automations.mjs")));
{
  // The orb's ladder reads TRG Prime's own table and cap.
  const options = await A.orbReleaseOptions({ spellPPCost: 6, spellTradition: "arcane", spellTraits: "", casterLevel: 5, casterTradition: "arcane", skillRanks: { arcana: 6 }, hasUseMagicDevice: true });
  equal("D the orb's ladder with TRG Prime's caster cap and tradition skills", options.map((o) => [o.key, o.skill, o.available]), [["spellcraft", "spellcraft", true], ["tradition:arcane", "arcana", true]]);
  equal("D a row other than 41–65 is TRG Prime's", await A.orbDepletion({ actor: {}, item: { system: {} }, row: { min: 1, max: 10 } }), null);
  ok("D the flare: the orb emptied, not broken, a Wild Surge at its level in 20 feet",
    /await item\.update\(\{ "system\.uses": 0 \}\);[\s\S]{0,300}?await rollTable\(actor, \{ table: WILD_SURGE, column: "e", title: `\$\{item\.name\} — Resonant Flare`, level, source: "wildSurge", radiusFeet: R\.FLARE_RADIUS,\n\s*expiry: forSeconds\(6 \* Math\.max\(1, level\)\) \}\);\n\s*return \{ replaces: true,/.test(auto)); // RE-ANCHORED 0.15.1 (review: an expiry, as every other wild surge has)
  ok("D (0.15.1) the Rod of Wild Surges' surge expires too, and both read the table from its own file",
    /title: `\$\{rod\.name\} — Wild Surge`, level, source: "wildSurge", radiusFeet: 5 \* level, expiry: forSeconds\(6 \* level\) \}\);/.test(auto)
    && (auto.match(/const \{ WILD_SURGE \} = await import\("\.\/chapter7-tables\.mjs"\);/g) ?? []).length === 2 && !/WILD_SURGE \} = await import\("\.\/block2/.test(auto));
}
{
  const made = [];
  const orb = (upper, uses) => ({ id: "o", name: R.ORBS_9C[upper].name, system: { equipped: true, invested: true, uses, hp: { value: 0, max: 0 } }, flags: { "trg-eldritch-arts": { charged9c: upper }, "trg-prime": {} } });
  const actor = (o) => ({ uuid: "Actor.b", name: "Bel", isOwner: true, items: [o], createEmbeddedDocuments: async (_t, data) => { made.push(...data); return data; } });
  cards.length = 0;
  await A.onActionResolvedB9c({ actor: actor(orb("ORB OF THE SHATTERED VEILS", 3)), action: { key: "tapLeyLine" }, degree: "critical" });
  equal("D a Critical Tap with Shattered Veils at 3 PP: See Invisible, warped to see clearly, for 10 minutes",
    [made.length, made[0]?.flags?.["trg-prime"]?.seeInvisible, made[0]?.flags?.["trg-prime"]?.spellEffectEnd], [1, "clear", 1600]);
  made.length = 0;
  await A.onActionResolvedB9c({ actor: actor(orb("ORB OF THE SHATTERED VEILS", 2)), action: { key: "tapLeyLine" }, degree: "critical" });
  equal("D …at 2 PP it does not work, and says so", [made.length, /2 PP or less/.test(cards.at(-1)?.[1] ?? "")], [0, true]);
  await A.onActionResolvedB9c({ actor: actor(orb("ORB OF THE SHATTERED VEILS", 9)), action: { key: "tapLeyLine" }, degree: "success" });
  await A.onActionResolvedB9c({ actor: actor(orb("ORB OF THE SHATTERED VEILS", 9)), action: { key: "channelLeyLine" }, degree: "critical" });
  equal("D …only a Critical, only Tap Ley Line", made.length, 0);
  await A.onActionResolvedB9c({ actor: actor(orb("ORB OF THE VERDANT HEART", 9)), action: { key: "tapLeyLine" }, degree: "critical" });
  equal("D Verdant Heart: Fast Healing 2 for 1 minute (on its bearer, with no token for allies)", [made.length, made[0]?.flags?.["trg-prime"]?.fastHealing, made[0]?.flags?.["trg-prime"]?.spellEffectEnd], [1, 2, 1060]);
  equal("D the socket writes only Verdant Heart's Fast Healing 2", [A.writeAllowed9c({ kind: "createEffect", data: made[0] }), A.writeAllowed9c({ kind: "createEffect", data: { flags: { "trg-eldritch-arts": { source: "verdantHeart9c" }, "trg-prime": { fastHealing: 9 } } } }), A.writeAllowed9c({ kind: "deleteEffect" })], [true, false, false]);
}
{
  const staff = (runes, extra = {}) => ({ id: "s", name: "Old Staff", parent: null, isOwner: true, documentName: "Item", system: { equipped: true, invested: true, runes, ...extra }, flags: { "trg-prime": { heldSpells: [] } } });
  equal("D Spellhold read off a staff's runes, or a charged staff's weapon form", [await A.spellholdOn(staff("Potency I, Spellhold II")), await A.spellholdOn({ system: {}, flags: { "trg-prime": { chargedItem: { weaponForm: { runes: "Spellhold IV" } } } } }), await A.spellholdOn(staff("Potency I"))], [{ tier: 2 }, { tier: 4 }, null]);
  const s = staff("Spellhold II");
  s.parent = { uuid: "Actor.c", name: "Cy", isOwner: true, items: [s] };
  calls.length = 0; chosen = "store";
  await A.openSpellhold(s);
  equal("D Store opens TRG Prime's hold window with the tier's room", calls, [["armHold", "Old Staff", { capacityPP: 12, label: "Old Staff (Spellhold II)" }]]);
  s.flags["trg-prime"].heldSpells = [{ id: "h1", spellName: "Fire Bolt", pp: 4, degreeLabel: "Success", total: 18, attack: true, saveDC: 0 }];
  calls.length = 0; chosen = "h1";
  await A.openSpellhold(s);
  equal("D Release is a Command (1 AP)", calls, [["release", "Old Staff", "h1", { ap: "1", label: "Old Staff (Spellhold II)" }]]);
  s.system.invested = false; calls.length = 0;
  await A.openSpellhold(s);
  equal("D …only by the staff's investor, held", calls, []);
  s.system.invested = true;
  s.flags["trg-prime"].heldSpells = [{ id: "h1", pp: 12 }]; calls.length = 0; chosen = "store";
  await A.openSpellhold(s);
  equal("D a full store opens no window", calls, []);
  s.flags["trg-prime"].heldSpells = [{ id: "h1" }, { id: "h2" }]; cards.length = 0;
  await A.onDailyPreparationB9c({ actor: s.parent });
  equal("D the stored spells fade at daily preparation", [s.flags["trg-prime"].heldSpells, /2 stored spells fade/.test(cards.at(-1)?.[1] ?? "")], [[], true]);
  const controls = [];
  A.onHeaderControlsB9c({ document: s }, controls);
  A.onHeaderControlsB9c({ document: s }, controls);
  A.onHeaderControlsB9c({ document: staff("Potency I") }, controls);
  equal("D the sheet offers Spellhold once, on a staff that has it", controls.map((c) => c.action), ["eaSpellhold"]);
}

/* ================================================================== E */
const docs = C.CHARGED_ITEMS_9C;
const of = (name) => docs.find((d) => d.name === name);
equal("E each item's kind, PP and recharge (orbs none: they do not recharge naturally)",
  ["Orb of Emberlight", "Rod of Ley Resonance", "Darkstaff"].map((n) => [of(n).flags["trg-prime"].chargedItem.kind, of(n).flags["trg-prime"].chargedItem.maximumPP, of(n).flags["trg-prime"].chargedItem.recharge, of(n).system.uses, of(n).system.itemLevel]),
  [["orb", 24, 0, 24, 8], ["rod", 10, 1, 10, 5], ["staff", 14, 2, 14, 7]]);
ok("E every item is gear, held in one hand, invested by trait, and names its book entry",
  docs.every((d) => d.type === "gear" && d.system.heldHands === 1 && /\bInvested\b/.test(d.system.traits) && d.flags["trg-eldritch-arts"].charged9c));
ok("E every orb carries the Orb trait", docs.filter((d) => d.flags["trg-prime"].chargedItem.kind === "orb").every((d) => /\bOrb\b/.test(d.system.traits)));
equal("E the orbs' and staves' abilities on the item (wondrous and conditionals)",
  [of("Orb of Emberlight").flags["trg-prime"].wondrous.abilities.length, of("Orb of the Whispering Veil").flags["trg-prime"].conditionals.length, of("Eidothrix").flags["trg-prime"].conditionals.length, of("Tesra’Anvir – Arcane").flags["trg-prime"].wondrous.abilities[0].value, of("Tesra’Anvir – Arcane").flags["trg-prime"].chargedItem.metamagic.cost],
  [2, 2, 1, 4, 8]);
ok("E every description is the book's, and says what is automated", docs.every((d) => /\*\*Spells\*\*|\*\*Effect\*\*/.test(d.system.description) || /Effect/.test(d.system.description)) && docs.every((d) => /Automated \(0\.15\.0/.test(d.system.description)));
const manifest = JSON.parse(read("module.json"));
equal("E the pack is declared, extending Charged Items, in the folder", [manifest.packs.find((p) => p.name === "ea-charged-items")?.flags?.["trg-prime"]?.extends, manifest.packFolders[0].packs.includes("ea-charged-items")], ["charged-items", true]);
const P = await import(path.join(ROOT, "tools", "content", "packs.mjs"));
equal("E …and built, all 19", P.PACKS.find((p) => p.name === "ea-charged-items")?.docs?.map((d) => d.name), C.CHARGED_ITEMS_9C.map((d) => d.name));

/* ================================================================== F */
const script = read("scripts", "eldritch-arts.mjs");
ok("F the hooks: a Critical Tap (its resolved degree), a settled and a held spell, daily preparation, the sheet, the socket",
  ['Hooks.on("trgPrimeActionResolved", (ctx) => { onActionResolvedB9c({ ...ctx, degree: ctx?.resolvedDegree ?? ctx?.degree })', 'Hooks.on("trgPrimeSpellSettled", (ctx) => { onSpellSettledB9c(ctx)', 'Hooks.on("trgPrimeSpellHeld", (ctx) => { onSpellHeldB9c(ctx)',
    'Hooks.on("trgPrimeDailyPreparation", (ctx) => { onDailyPreparationB9c(ctx)', 'onHeaderControlsB9c(app, controls)', 'Hooks.once("ready", () => { onReadyB9c(); });'].every((h) => script.includes(h)));
ok("F registered with the rest", /registerBlock9c\(api, moduleId\);/.test(read("module", "registration.mjs")));
ok("D (live test, 0.15.1) a refused hold window posts no \"cast it now\" card",
  /const armed = await h\(\)\.armHold\(actor, item, \{ capacityPP: capacity, label: `\$\{item\.name\} \(\$\{label\}\)` \}\);\n\s*if \(!armed\) return null;\n\s*await card\(/.test(auto));
equal("F the manifest: 0.15.2 on TRG Prime 3.691.0; the script asks for 3.691.0",
  [manifest.version, manifest.relationships.systems[0].compatibility.minimum, /REQUIRED_SYSTEM = "3\.694\.0"/.test(script), manifest.download.includes("v0.17.2")], ["0.17.2", "3.694.0", true, true]);

delete globalThis.game.trgPrime;
if (failures.length) { for (const f of failures) console.log(`  ✗ ${f}`); }
console.log(`verify-block9c: ${checks} checks, ${failures.length} failure(s).`);
if (failures.length) process.exit(1);
