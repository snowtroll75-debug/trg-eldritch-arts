#!/usr/bin/env node
/**
 * verify-block6-lead — the lead's wiring of Block 6 (0.9.0), checked:
 * the six groups' registrations reach the core's real registry with nothing
 * refused; the 23 archetypes are registered as the build-time list says; every
 * hook handler the groups export is wired, in the order two of them need; the
 * packs carry every archetype and class feat the book prints; Block 2's
 * ley-line code calls Leyline Weaver's ladder and lays Ley-Etched Symbol's
 * marker only for its owner; and nothing alters world data at load (Spell
 * Surge's copies are not rewritten; a Warlock without this block's Xithra
 * feats is not synced).
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block6-lead.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), "utf8");

let failures = 0, checks = 0;
const ok = (name, cond, detail = "") => { checks += 1; if (!cond) { failures += 1; console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ""}`); } };
const equal = (name, got, want) => ok(name, JSON.stringify(got) === JSON.stringify(want), `expected ${JSON.stringify(want)}, got ${JSON.stringify(got)}`);
const quiet = async (fn) => { const w = console.warn, l = console.log; console.warn = () => {}; console.log = () => {}; try { return await fn(); } finally { console.warn = w; console.log = l; } };

// Just enough Foundry for the automation files to import.
globalThis.Hooks ??= { on() { return 1; }, once() { return 1; }, off() {}, callAll() {} };
globalThis.foundry ??= { utils: { deepClone: (x) => structuredClone(x), isNewerVersion: () => false, mergeObject: (a, b) => ({ ...a, ...b }) } };
globalThis.game ??= { user: { isGM: true, targets: new Set() }, users: { activeGM: null }, actors: [], settings: { get: () => null } };
globalThis.ui ??= { notifications: { warn() {}, error() {}, info() {} } };
globalThis.CONFIG ??= {};

/* A — the archetypes ------------------------------------------------ */
const reg = await quiet(() => import("../module/registration.mjs"));
const common = await import("./content/block6-common.mjs");
const b6a = await import("./content/block6-a.mjs");
equal("A the runtime archetype list is the book's 23", [...reg.ARCHETYPES_B6].sort(), [...common.EA_ARCHETYPE_NAMES].sort());
equal("A …and their options are group A's (High Mage, Birthrager: the Sorcerer's Adept feats, Q100)", JSON.parse(JSON.stringify(reg.ARCHETYPE_OPTIONS_B6)), JSON.parse(JSON.stringify(b6a.ARCHETYPE_OPTIONS_B6_A)));
ok("A the core's own Runemage is not registered (it would duplicate the core's gate)", !reg.ARCHETYPES_B6.includes("Runemage"));

/* B — the real registry --------------------------------------------- */
const capi = await import(sys("module", "module-api.mjs"));
capi.resetModuleRegistry();
const api = new Proxy({}, { get: (_, k) => (typeof capi[k] === "function" ? (...a) => capi[k](...a) : () => {}) });
await quiet(() => reg.registerContent(api, "trg-eldritch-arts"));
equal("B every registration of every block is taken, with nothing refused", capi.registrationProblems(), []);
const archetypes = capi.registeredArchetypeNames().map((n) => String(n).toLowerCase());
ok("B all 23 archetypes reach the core", reg.ARCHETYPES_B6.every((n) => archetypes.includes(n.toLowerCase())), JSON.stringify(archetypes));
equal("B High Mage opens the Sorcerer (Adept) feats", [capi.registeredArchetype("High Mage")?.classGrants, capi.registeredArchetype("High Mage")?.tierGrants], [["Sorcerer"], ["Adept"]]);
const mm = capi.registeredMetamagic().flatMap((m) => [m.feats].flat().map(String));
// Piercing Insight is not an option of its own: it applies your metamagic to
// Sense Magic (verify-block6d holds it).
ok("B the metamagic of Block 5's deferred options is registered (Echo, Pulse, Harmony, Spell Surge)",
  ["Echo of the Ancestors", "Resonant Pulse", "Resonant Harmony", "Spell Surge"].every((n) => mm.includes(n)), JSON.stringify(mm));
ok("B …and the class feats' (Pact Channeler, Spellthread, Steelbinding, Ley-Etched Symbol)", ["Pact Channeler", "Spellthread", "Steelbinding", "Ley-Etched Symbol"].every((n) => mm.includes(n)), JSON.stringify(mm));
const regSrc = read("module", "registration.mjs");
ok("B Block 6 registers after Block 5 (6B2 replaces Block 3's Gale Step; 6D registers Block 5's metamagic)",
  regSrc.indexOf("registerBlock5D(api, moduleId);") > 0 && regSrc.indexOf("registerBlock5D(api, moduleId);") < regSrc.indexOf("registerBlock6A(api, moduleId);")
  && ["6A", "6B1", "6B2", "6C", "6D", "6E"].every((g) => regSrc.includes(`registerBlock${g}(api, moduleId);`)));

/* C — the hooks ------------------------------------------------------- */
const script = read("scripts", "eldritch-arts.mjs");
equal("C the module asks for TRG Prime 3.688.0", script.match(/REQUIRED_SYSTEM = "([^"]+)"/)?.[1], "3.694.0"); // RE-PINNED 0.12.0, 0.14.0
const helpersNotHooks = new Set(["leylineWeaverTap", "leylineWeaverRung", "layLeyBenefitMarker", "refreshFamiliarRange"]);
const unwired = [];
for (const g of ["a", "b1", "b2", "c", "d", "e"]) {
  const src = read("module", `block6${g}-automations.mjs`);
  for (const [, name] of src.matchAll(/^export async function ((?:on|refresh)[A-Za-z0-9]+)/gm)) {
    if (helpersNotHooks.has(name)) continue;
    if (!new RegExp(`Hooks\\.(on|once)\\([^\\n]*\\b${name}\\(`).test(script)) unwired.push(name);
  }
}
equal("C every hook handler the six groups export is wired", unwired, []);
ok("C 6E's createItem runs after Block 4's (it writes Xithra's offer last)", script.indexOf("onItemCreatedB4(item)") > 0 && script.indexOf("onItemCreatedB4(item)") < script.indexOf("onItemCreatedB6E(item)"));
ok("C 6B1's action handler runs after Block 2b's (it reads Block 2's plan synchronously)", script.indexOf("onActionResolvedB2b(ctx)") > 0 && script.indexOf("onActionResolvedB2b(ctx)") < script.indexOf("onActionResolvedB6B1(ctx)"));

/* D — nothing alters world data at load -------------------------------- */
const d = await quiet(() => import("../module/block6d-automations.mjs"));
ok("D Spell Surge's copies already on sheets are not rewritten at load", d.onReadyB6D === undefined && !/onReadyB6D/.test(script));
const eSrc = read("module", "block6e-automations.mjs");
ok("D the load-time refresh is the familiar's range only (no Xithra or Pact Ascendant rewrite)", typeof (await import("../module/block6e-automations.mjs")).refreshAllB6E === "undefined" && /Hooks\.on\("canvasReady", \(\) => \{ refreshFamiliarsB6E\(\)/.test(script) && !/refreshAllB6E/.test(script));
void eSrc;
{
  const e = await quiet(() => import("../module/block6e-automations.mjs"));
  const updates = [];
  const xithra = { id: "x", type: "spell", name: "Xithra", system: { range: "30 feet", damage: { formula: "1d6" }, baseDamage: "1d6", effects: [] }, flags: {}, update: async (u) => updates.push(u), getFlag: () => null };
  const warlock = { name: "W", isOwner: true, type: "character", items: [xithra], effects: [], flags: {}, getFlag: () => null, system: {} };
  globalThis.game.actors = [warlock];
  await quiet(() => e.refreshFamiliarsB6E().catch(() => null));
  equal("D …run: loading a world with a Warlock writes nothing to his Xithra", updates, []);
  globalThis.game.actors = [];
}

/* E — the packs ------------------------------------------------------- */
const packs = await import("./content/packs.mjs");
const want = [...common.bookNames("archetype"), ...common.bookNames("class")].map(common.titleCase).sort();
equal("E the feats pack carries every archetype and class feat the book prints, once", packs.FEATS_B6.map((f) => f.name).sort(), want);
const featsPack = packs.PACKS.find((p) => p.name === "ea-feats");
equal("E …and all 237 of Chapter 5's feats", featsPack.docs.length, 237);
const b1 = await import("./content/block6-b1.mjs"), b2 = await import("./content/block6-b2.mjs");
const names = (n) => new Set(packs.PACKS.find((p) => p.name === n).docs.map((x) => x.name));
ok("E the archetypes' abilities are in the abilities pack", [...b1.ABILITIES_B6_B1, ...b2.ABILITIES_B6_B2].every((x) => names("ea-abilities").has(x.name)));
ok("E …and their spells in the spells pack", [...b1.SPELLS_B6_B1, ...b2.SPELLS_B6_B2].every((x) => names("ea-spells").has(x.name)));
// THE SPELL IMAGE (0.9.1): icons/svg/holy-symbol.svg is not in Foundry V14.
// A school's spell takes the core's own picture for that school (as the core's
// spells pack does), any other the core sheet's default for a spell.
const spellDocs = packs.PACKS.find((p) => p.name === "ea-spells").docs;
const allDocs = packs.PACKS.flatMap((p) => p.docs.flatMap((d) => [d, ...(d.items ?? [])]));
ok("E no document uses holy-symbol.svg, which V14 does not ship", allDocs.every((d) => !/holy-symbol/.test(String(d.img ?? ""))), allDocs.filter((d) => /holy-symbol/.test(String(d.img ?? ""))).map((d) => d.name).join(", "));
const schoolOf = (d) => ["alteration", "enchantment", "insight", "invocation", "shadow", "soul", "translocation", "warding"].find((s) => String(d.system?.traits ?? "").toLowerCase().split(/[,;]/).map((t) => t.trim()).includes(s));
equal("E every spell's image: its school's core picture, else icons/svg/book.svg",
  spellDocs.filter((d) => d.img !== (schoolOf(d) ? `systems/trg-prime/assets/spells/${schoolOf(d)}.svg` : "icons/svg/book.svg")).map((d) => `${d.name}: ${d.img}`), []);
ok("E …and every core picture named is in the core", spellDocs.filter((d) => d.img.startsWith("systems/trg-prime/")).every((d) => fs.existsSync(path.join(SYSTEM_ROOT, d.img.replace(/^systems\/trg-prime\//, "")))));
// 0.10.0 (Block 7) adds 42 spells: 38 with a school, 4 without (Chronoweave, Dragon’s Breath, Leyline Burst, Memory Eclipse).
// 0.11.0 (Block 8a) adds 22, every one with a school.
// 0.12.0 (Block 8b) adds 17: 10 with a school, 7 without (Essence Reforging and six High Magic spells).
equal("E …both kinds are used (91 by school, 39 the book)", [spellDocs.filter((d) => d.img.startsWith("systems/")).length, spellDocs.filter((d) => d.img === "icons/svg/book.svg").length], [91, 39]);
// FOUNDRY'S OWN ICONS (review, 0.9.1). No Foundry V14 install is on the
// harness, so a Foundry `icons/` path cannot be looked up on disk. What can be
// confirmed is that each one any pack document (or its embedded items and
// effects) names is one the core itself uses in its own code — the core runs
// on V14 and its live tests load those images (book.svg is its sheet's default
// spell image, ITEM_ICONS in sheets/actor-sheet.mjs). A path the core never
// names is unconfirmed, and fails here.
const coreSrc = (() => { const out = []; const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else if (/\.m?js$/.test(e.name)) out.push(fs.readFileSync(p, "utf8")); } }; walk(path.join(SYSTEM_ROOT, "module")); return out.join("\n"); })();
const foundryIcons = [...new Set(packs.PACKS.flatMap((p) => p.docs.flatMap((d) => [d, ...(d.items ?? []), ...(d.effects ?? [])])).map((d) => String(d.img ?? "")).filter((s) => s.startsWith("icons/")))].sort();
equal("E every Foundry icon a pack names is one the core's own code uses (V14's, as the core loads it)", foundryIcons.filter((i) => !coreSrc.includes(`"${i}"`)), []);
ok("E …icons/svg/book.svg is the core sheet's own default spell image", /spell:\s*"icons\/svg\/book\.svg"/.test(fs.readFileSync(path.join(SYSTEM_ROOT, "module", "sheets", "actor-sheet.mjs"), "utf8")));

/* F — Block 2's ley-line code ------------------------------------------ */
const b2src = read("module", "block2-automations.mjs");
const tap = b2src.slice(b2src.indexOf('if (own.key === "tapLeyLine") {'), b2src.indexOf('if (own.key === "channelLeyLine") {'));
ok("F Tap Ley Line asks Leyline Weaver's ladder first (Q113)",
  tap.indexOf("weaver.leylineWeaverTap(actor, { degree: k, level: L, title })") > 0 && tap.indexOf("weaver.leylineWeaverTap(") < tap.indexOf('if (k === "critical") return leyBenefits('));
ok("F …and marks the benefit when the ladder answers", /if \(rung\) await markLeyBenefit\(actor, \{ level: L,/.test(tap));
ok("F the ley benefits lay Ley-Etched Symbol's marker (N6)", /const out = await rollTable\(actor, \{ table: LEY_LINE_EFFECTS, column: "e"[^\n]*\n\s*await markLeyBenefit\(actor, \{ level, name: title, expiry \}\);/.test(b2src));
ok("F …only for a character who owns Ley-Etched Symbol", /async function markLeyBenefit\(actor, \{ level, name, expiry \}\) \{\n\s*if \(!Array\.from\(actor\?\.items \?\? \[\]\)\.some\(\(i\) => i\?\.type === "feat" && String\(i\.name \?\? ""\)\.trim\(\)\.toLowerCase\(\) === "ley-etched symbol"\)\) return;/.test(b2src));

/* G — the module's own version ------------------------------------------ */
const manifest = JSON.parse(read("module.json"));
equal("G module.json: 0.13.0 on TRG Prime 3.688.0", [manifest.version, manifest.relationships?.systems?.[0]?.compatibility?.minimum], ["0.17.2", "3.694.0"]); // RE-PINNED 0.12.0

console.log(`verify-block6-lead: ${checks} checks, ${failures} failure(s).`);
if (failures) process.exitCode = 1;
