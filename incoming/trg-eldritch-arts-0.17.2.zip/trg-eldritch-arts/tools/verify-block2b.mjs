#!/usr/bin/env node
/**
 * verify-block2b — Eldritch Arts Block 2b (0.4.0): Chapter 7's mundane
 * rituals, summoning circles and true names; Chapter 4's Spell Trickery and
 * Borrow Spell; on TRG Prime 3.679.0's ritual rules and casting options.
 *
 *   TRG_PRIME_ROOT=../trpg-prime node tools/verify-block2b.mjs
 *
 *   A  The book: the three actions' rows and text, the material table and the
 *      circle modifiers, read from the extract (tools/content/book-text.json).
 *   B  The pure rules: the ritual skills, training, the material costs, the
 *      communal shares, the circle's rows, minutes and duration.
 *   C  The ritual on fakes: variants, fields, the plan (Q5, Q9–Q11, Q13), the
 *      Ritual-trait refusal and cap (Q8, M30), the substitute paid.
 *   D  Circles, true names, Spell Trickery and Borrow Spell on fakes.
 *   E  The system's own registry and its ritual rules, end to end with the
 *      module's answers; the wiring and the versions.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SYSTEM_ROOT = path.resolve(process.env.TRG_PRIME_ROOT ?? path.resolve(ROOT, "..", "trpg-prime"));
const sys = (...p) => new URL(`file://${path.join(SYSTEM_ROOT, ...p)}`).href;

let checks = 0;
const failures = [];
function ok(label, condition, detail = "") { checks += 1; if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ""}`); }
function equal(label, actual, expected) { ok(label, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`); }

const book = JSON.parse(fs.readFileSync(path.join(ROOT, "tools", "content", "book-text.json"), "utf8"));
const CH7 = book.chapter7;
const CH4 = book.chapter4;

// The fakes.
let worldTime = 1000;
const cards = [];
const calls = { createEffectsOn: [], basicSaveHit: [], deductGold: [] };
const answers = [];
let purseShort = 0;
let purse = 1000;
let keepsBook = true;
const noBook = new Set();
const helpers = {
  line: (t) => t,
  postCard: async (actor, title, lines) => { cards.push({ actor: actor?.name, title, lines }); },
  chooseFromList: async () => answers.shift() ?? null,
  createEffectsOn: async (target, list) => { calls.createEffectsOn.push({ target: target.name, list }); return target.createEmbeddedDocuments("ActiveEffect", list); },
  levelDC: (level) => Number(level) + 14,
  basicSaveHit: async (spec) => { calls.basicSaveHit.push({ target: spec.target.name, save: spec.save, dc: spec.dc, formula: spec.formula, type: spec.type, ignoreDefences: spec.ignoreDefences }); return { line: `${spec.target.name} saves` }; },
  deductGold: async (actor, gp) => { calls.deductGold.push([actor.name, gp]); return purseShort ? { paid: false, shortfallGP: purseShort } : { paid: true, shortfallGP: 0 }; },
  goldOf: async () => purse,
  learnSpellDC: async (spell) => 20 + 2 * Math.max(0, Math.ceil(Number(spell.system?.ppCost ?? 0) / 2) - 1),
  keepsSpellbook: async (a) => keepsBook && !noBook.has(a?.name)
};
const worldActors = [];
globalThis.game = { trgPrime: { modules: { helpers } }, time: { get worldTime() { return worldTime; } }, combat: null, user: { isGM: true }, users: { activeGM: null }, actors: Object.assign(worldActors, { get: (id) => worldActors.find((a) => a.id === id) ?? null }) };
const tokens = [];
globalThis.canvas = { tokens: { placeables: tokens } };
globalThis.fromUuidSync = (uuid) => worldActors.find((a) => a.uuid === uuid) ?? worldActors.flatMap((a) => a.items).find((i) => i.uuid === uuid) ?? null;
globalThis.ui = { notifications: { warn: (t) => { warnings.push(t); } } };
const warnings = [];
let dialogAnswer = null;
globalThis.foundry = { applications: { api: { DialogV2: { prompt: async () => dialogAnswer } }, ux: { FormDataExtended: class { constructor() { this.object = {}; } } } } };

const actions = await import("../module/block2b-actions.mjs");
const auto = await import("../module/block2b-automations.mjs");
const reg = await import("../module/registration.mjs");
const api = await import(sys("module", "module-api.mjs"));
const ritualRules = await import(sys("module", "magic", "ritual-rules.mjs"));
const castOptions = await import(sys("module", "magic", "cast-options.mjs"));

function makeActor(name, extra = {}) {
  const actor = { name, id: name, uuid: `Actor.${name}`, isOwner: true, flags: {}, effects: [], items: [], system: { identity: { level: 4 }, resources: { pp: { value: 10, max: 20 } }, skills: { arcana: { ranks: 2, total: 9 }, religion: { ranks: 0, total: 3 }, nature: { ranks: 1, total: 6 }, occultism: { ranks: 0, total: 1 }, deception: { dc: 17 } }, magic: { casterLevelValue: 5, tradition: "arcane" } }, ...extra };
  actor.items.get = (id) => actor.items.find((i) => i.id === id);
  actor.getFlag = (s, k) => actor.flags?.[s]?.[k];
  actor.setFlag = async (s, k, v) => { actor.flags[s] ??= {}; actor.flags[s][k] = v; };
  actor.unsetFlag = async (s, k) => { delete actor.flags?.[s]?.[k]; };
  actor.update = async (diff) => { for (const [k, v] of Object.entries(diff)) { const keys = k.split("."); let o = actor; while (keys.length > 1) { const kk = keys.shift(); o[kk] ??= {}; o = o[kk]; } o[keys[0]] = v; } };
  actor.createEmbeddedDocuments = async (type, list) => list.map((d) => {
    const doc = { id: `${type === "Item" ? "i" : "e"}${actor.items.length + actor.effects.length + 1}`, parent: actor, ...structuredClone(d) };
    doc.getFlag = (s, k) => doc.flags?.[s]?.[k];
    doc.delete = async () => { actor.effects = actor.effects.filter((e) => e !== doc); };
    (type === "Item" ? actor.items : actor.effects).push(doc);
    return doc;
  });
  actor.deleteEmbeddedDocuments = async (type, ids) => {
    if (type === "Item") { for (const id of ids) { const i = actor.items.findIndex((x) => x.id === id); if (i >= 0) actor.items.splice(i, 1); } }
    else actor.effects = actor.effects.filter((e) => !ids.includes(e.id));
  };
  worldActors.push(actor);
  return actor;
}
const item = (actor, data) => { const i = { id: `x${actor.items.length + 1}`, uuid: `${actor.uuid}.Item.x${actor.items.length + 1}`, parent: actor, flags: {}, system: {}, ...data }; i.getFlag = (s, k) => i.flags?.[s]?.[k]; i.toObject = () => structuredClone({ ...i, parent: undefined, getFlag: undefined, toObject: undefined }); actor.items.push(i); return i; };
const place = (actor) => tokens.push({ actor, name: actor.name });
const MOD = "trg-eldritch-arts";

/* ------------------------------------------------------------------ *
 * A. The book
 * ------------------------------------------------------------------ */
const rowsOf = (lines) => {
  const out = {};
  for (const l of lines) { const m = /^\*\*(Heroic|Critical|Success|Partial|Failure|Fumble|Blunder)\*\* (.*)$/.exec(l); if (m) out[m[1].toLowerCase()] = m[2]; }
  return out;
};
const nonEmpty = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v));
const act = (k) => actions.SKILL_ACTIONS.find((a) => a.key === k);
equal("A Borrow Spell: every printed degree, as printed", nonEmpty(act("borrowSpell").outcomes), rowsOf(CH4["BORROW SPELL"].lines));
ok("A Borrow Spell: its paragraph, Trained Only, the four skills, Easy", act("borrowSpell").description.startsWith(CH4["BORROW SPELL"].lines[2])
  && CH4["BORROW SPELL"].lines[1] === "**Skills** (Trained Only) Arcana, Nature, Occultism or Religion"
  && act("borrowSpell").proficiency === "trained" && act("borrowSpell").skills.join() === "arcana,nature,occultism,religion" && act("borrowSpell").difficulty === "easy"
  && /Easy \(DC -2\)/.test(CH4["BORROW SPELL"].lines[2]));
equal("A See Through Spell Trickery: Spell Trickery's seven printed results", nonEmpty(act("seeThroughSpellTrickery").outcomes), rowsOf(CH4["SPELL TRICKERY"].lines));
ok("A …against the caster's Deception DC with Sense Motive or a tradition skill, as printed",
  /must make either a Sense Motive or Tradition based skill check against your Deception DC/.test(CH4["SPELL TRICKERY"].lines[1])
  && act("seeThroughSpellTrickery").against === "skillDC:deception" && act("seeThroughSpellTrickery").skills.join() === "senseMotive,arcana,nature,occultism,religion"
  && act("seeThroughSpellTrickery").outcomesApplied === false);
ok("A Spell Trickery's +2 is printed", /increase the DC of your casting check by 2/.test(CH4["SPELL TRICKERY"].lines[1]));
const SUMM = CH7.summoning.paragraphs.map((p) => p.text);
const circleRows = {};
for (const t of SUMM) { const m = /^\*\*(Critical|Success|Failure|Fumble)\*\* (.*)$/.exec(t); if (m) circleRows[m[1].toLowerCase()] = m[2]; }
equal("A Inscribe Summoning Circle: the four printed results", nonEmpty(act("inscribeSummoningCircle").outcomes), circleRows);
ok("A …its paragraph and duration, the four skills, Moderate", SUMM.filter((t) => /^Crafting a summoning circle|^Circles last 1 hour/.test(t)).every((t) => act("inscribeSummoningCircle").description.includes(t))
  && act("inscribeSummoningCircle").difficulty === "medium" && /Moderate \(\+0\)/.test(SUMM.join(" ")) && act("inscribeSummoningCircle").skills.join() === "occultism,arcana,nature,religion");
const mat = CH7.rituals.materials.rows.filter((r) => /^\d+$/.test(r.cells[0])).map((r) => [Number(r.cells[0]), Number(r.cells[1].replace(/,/g, ""))]);
equal("A the material table is the printed one, 1 to 20 PP", auto.MATERIAL_COSTS.slice(1).map((gp, i) => [i + 1, gp]), mat);
const mods = Object.fromEntries(CH7.summoning.modifiers.rows.slice(2).map((r) => [r.cells[0].split(" (")[0], r.cells[1]]));
equal("A the circle modifiers as printed", [mods["Using rare or consecrated materials"], mods["Using improvised or poor-quality materials"], mods["Circle inscribed on ground aligned with creature’s tradition"], mods["Circle inscribed on ground opposed to creature’s tradition"], mods["Caster knows the creature’s True Name"], mods["Circle prepared in haste"], mods["Circle prepared with meticulous care"], mods["Secondary casters assist in inscribing the circle"], mods["Circle inscribed with blood sacrifice"], mods["Circle disrupted or damaged during ritual"]],
  ["-2 to -10 (GM Discretion", "+2 to +5", "-4", "+4", "-5", "+5", "-2", "–1 per assistant (max –4)", "varies", "+10 or automatic failure"]);
const RIT = CH7.rituals.paragraphs.map((p) => p.text).join(" ");
ok("A the variant's rules as printed: training, the three sacrifices, the check",
  /Any character trained in Arcana \(Arcane\), Religion \(Divine\), Occultism \(Ethereal\), or Nature \(Verdant\) may serve as the primary caster, even with 0 Caster Level\/PP\./.test(RIT)
  && /takes 1d8 essence damage \(basic Fort\) per PP that has been substituted\. All secondary casters takes 1d4 essence damage \(basic Fort\) per PP/.test(RIT)
  && /bypasses all DR, Resistance and Immunity/.test(RIT) && /increased by 50%, and this cost is then split amongst the secondary casters/.test(RIT)
  && /This check is considered to be Very Hard \(DC \+5\) level-based DC equal to the wielder's level\./.test(RIT.replace(/’/g, "'")));
ok("A true names as printed: +4 Save DC, permanently hostile on a success", SUMM.some((t) => /increases the Save DC of your spell by \+4\. If the creature gets a success or greater on its saving throw however \(after the modifier\), it becomes permanently hostile towards you\./.test(t)));

/* ------------------------------------------------------------------ *
 * B. The pure rules
 * ------------------------------------------------------------------ */
equal("B the ritual skill for each tradition; all four for a Highmagic spell; none for no tradition",
  [auto.ritualSkillsFor({ tradition: "arcane" }), auto.ritualSkillsFor({ tradition: "divinity" }), auto.ritualSkillsFor({ tradition: "Arcane, Verdant" }), auto.ritualSkillsFor({ tradition: "" }, { highMagicSpell: true }), auto.ritualSkillsFor({ tradition: "" })],
  [["arcana"], ["religion"], ["arcana", "nature"], ["arcana", "religion", "occultism", "nature"], []]);
const sk = { arcana: { ranks: 2, total: 9 }, nature: { ranks: 1, total: 11 }, religion: { ranks: 0, total: 20 } };
equal("B the best skill the primary is TRAINED in", [auto.bestTrainedSkill(sk, ["arcana", "nature"]), auto.bestTrainedSkill(sk, ["religion"]), auto.bestTrainedSkill(sk, ["arcana", "religion"])], ["nature", null, "arcana"]);
equal("B material cost by PP; beyond 20 is the GM's", [auto.materialCost(1), auto.materialCost(5), auto.materialCost(20), auto.materialCost(21), auto.materialCost(0)], [30, 250, 110000, null, 0]);
equal("B communal: +50% rounded up, split evenly, the remainder to the first", [auto.communalShares(5, 2), auto.communalShares(4, 3), auto.communalShares(3, 2), auto.communalShares(3, 0)], [[4, 4], [2, 2, 2], [3, 2], []]);
equal("B the circle's rows from the dialog", auto.circleDCRows({ rare: "6", poor: "0", ground: "opposed", trueName: true, care: "meticulous", assistants: "7", blood: "animal", disrupted: true }),
  [{ label: "Rare or consecrated materials", value: -6 }, { label: "Ground opposed to the creature's tradition", value: 4 }, { label: "You know its True Name", value: -5 }, { label: "Prepared with meticulous care", value: -2 }, { label: "Secondary casters assisting", value: -4 }, { label: "Blood sacrifice (animal)", value: -2 }, { label: "Circle disrupted or damaged", value: 10 }]);
equal("B …a rare or poor value is held to the printed range", [auto.circleDCRows({ rare: 1 }), auto.circleDCRows({ rare: 40 }), auto.circleDCRows({ poor: 9 })], [[{ label: "Rare or consecrated materials", value: -2 }], [{ label: "Rare or consecrated materials", value: -10 }], [{ label: "Improvised or poor materials", value: 5 }]]);
equal("B a circle takes 10 minutes × level, double with care; lasts 1 hour per CL, 24 hours in Void Chalk if longer",
  [auto.circleMinutes(3), auto.circleMinutes(3, "meticulous"), auto.circleSeconds(5), auto.circleSeconds(5, true), auto.circleSeconds(30, true)], [30, 60, 18000, 86400, 108000]);
equal("B the circle's bonus by degree", auto.CIRCLE_CHECK, { critical: 4, success: 2, failure: -2, fumble: 0 });
equal("B an Eldritch Arts spell: our compendium or our flag; a core spell is not", [auto.isEldritchArtsSpell({ _stats: { compendiumSource: "Compendium.trg-eldritch-arts.ea-spells.Item.x" } }), auto.isEldritchArtsSpell({ flags: { [MOD]: { spell: true } } }), auto.isEldritchArtsSpell({ _stats: { compendiumSource: "Compendium.trg-prime.spells.Item.clone" } })], [true, true, false]);

/* ------------------------------------------------------------------ *
 * C. The ritual
 * ------------------------------------------------------------------ */
const primary = makeActor("Primary");
place(primary);
const sec1 = makeActor("Sec1"); place(sec1);
const sec2 = makeActor("Sec2"); place(sec2);
const arcaneSpell = { name: "Ward of Ages", uuid: "Spell.ward", system: { tradition: "arcane", traits: "Abjuration", ppCost: 3 } };
equal("C the three variants are offered to a primary trained in the spell's skill", (await auto.ritualVariants({ actor: primary, spellData: arcaneSpell.system })).map((v) => v.key), ["vital", "material", "communal"]);
const untrained = makeActor("Untrained", { system: { identity: { level: 4 }, skills: { arcana: { ranks: 0 } }, magic: {} } });
equal("C …and none to one who is not", await auto.ritualVariants({ actor: untrained, spellData: arcaneSpell.system }), []);
const fields = await auto.ritualFields({ actor: primary, spellData: arcaneSpell.system });
ok("C the fields name the secondaries on the scene, not the primary, and ask for Ritual Experts", /eaSecondary-Sec1/.test(fields) && /eaSecondary-Sec2/.test(fields) && !/eaSecondary-Primary/.test(fields) && /name="eaRitualExperts"/.test(fields));
ok("C …and no goods row for goods not carried", !/eaCensor|eaChalkboard|eaBowl|eaRitualist/.test(fields));
item(primary, { name: "Ritual Censor", type: "gear" });
item(primary, { name: "Runestone Chalkboard", type: "gear" });
item(primary, { name: "Bloodscribe’s Bowl", type: "gear" });
item(primary, { name: "Claidheamh Dubh", type: "weapon", system: { traits: "Deadly, Hand & a Half, Keen, Ritualist" } });
const fields2 = await auto.ritualFields({ actor: primary, spellData: arcaneSpell.system });
ok("C carried goods are offered as ticks", ["eaCensor", "eaChalkboard", "eaBowl", "eaRitualist"].every((n) => fields2.includes(`name="${n}"`)));

const plain = await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { eaCensor: true, eaRitualist: true, eaChalkboard: true, eaBowl: true, eaRitualExperts: "2" }, variant: "", basePP: 3, secondaryCount: 3 });
equal("C paying PP: the goods' rows, the experts' seats, no DC or skill of its own",
  [plain.dcRows, plain.modifiers, plain.seats, plain.dc ?? null, plain.skill ?? null],
  [[{ label: "Ritual Censor", value: -1 }, { label: "Claidheamh Dubh (Ritualist)", value: -1 }], [{ label: "Runestone Chalkboard", value: 1, type: "untyped" }, { label: "Bloodscribe’s Bowl (blood offered)", value: 1, type: "untyped" }], 2, null, null]);
item(primary, { name: "Ritual Expert", type: "feat" });
equal("C a primary with Ritual Expert counts as two (Q13)", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: {}, variant: "" })).seats, 1);
calls.deductGold.length = 0;
const vital = await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true }, variant: "vital", basePP: 3, ppOver: 1, secondaryCount: 1 });
equal("C a variant: the tradition skill, the level DC Very Hard (+5)", [vital.skill, vital.dc], [{ key: "arcana", label: "Arcana" }, { value: 4 + 14 + 5, label: "Level DC (level 4), Very Hard +5" }]);
equal("C …and the plan kept for the payment", primary.getFlag(MOD, "ritualPlan"), { variant: "vital", secondaries: ["Actor.Sec1"], spell: "Spell.ward", at: 1000 });
{
  // 0.16.1 (Graham, 15 November 2026): the Chalkboard and the Bowl add to the primary's Spellcraft check only.
  const goods = await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true, eaChalkboard: true, eaBowl: true }, variant: "vital", basePP: 3, ppOver: 1, secondaryCount: 1 });
  equal("C a variant (a tradition-skill check): the Chalkboard and the Bowl add nothing, and the card says so",
    [goods.modifiers, goods.lines.filter((l) => /not added/.test(l)).length], [[], 2]);
}
// The review's fixes (2 November 2026).
equal("C the Censor's incense is taken once the ritual is set (5 gp), not before", calls.deductGold, []);
calls.deductGold.length = 0;
const censed = await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { eaCensor: true }, variant: "", basePP: 3, secondaryCount: 1 });
// 0.13.2 (Graham, 13 Nov 2026): marked when ticked, taken when the rite is settled —
// the core still refuses after preparing (no secondary, the overcast limit).
equal("C …ticked: marked for this spell, nothing taken yet", [calls.deductGold, primary.getFlag(MOD, "ritualCensor"), censed.lines.includes("Ritual Censor: 5 gp of incense burns in the rite.")], [[], { spell: "Spell.ward", at: 1000 }, true]);
equal("C …taken when the rite is settled, once", [(await auto.ritualSettled({ actor: primary, spell: arcaneSpell })).lines, calls.deductGold, primary.getFlag(MOD, "ritualCensor") ?? null, (await auto.ritualSettled({ actor: primary, spell: arcaneSpell })).lines, calls.deductGold.length],
  [["Ritual Censor: 5 gp of incense is consumed in the rite (taken from the purse)."], [["Primary", 5]], null, [], 1]);
calls.deductGold.length = 0;
await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { eaCensor: true }, variant: "", basePP: 3, secondaryCount: 1 });
await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: {}, variant: "", basePP: 3, secondaryCount: 1 });
equal("C …a ritual refused after its preparation, then one without the Censor: the mark is cleared, nothing taken", [primary.getFlag(MOD, "ritualCensor") ?? null, (await auto.ritualSettled({ actor: primary, spell: arcaneSpell })).lines, calls.deductGold], [null, [], []]);
await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { eaCensor: true }, variant: "", basePP: 3, secondaryCount: 1 });
purseShort = 3;
await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { eaCensor: true }, variant: "", basePP: 3, secondaryCount: 1 });
equal("C …a purse emptied before the rite settles: nothing taken, the debt on the card", (await auto.ritualSettled({ actor: primary, spell: arcaneSpell })).lines,
  ["Ritual Censor: 5 gp of incense is owed — the purse is short by 3 gp. Nothing was deducted; the GM settles it."]);
purseShort = 0;
calls.deductGold.length = 0;
await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { eaCensor: true }, variant: "", basePP: 3, secondaryCount: 1 });
equal("C …another spell's rite does not take it, and clears the stale mark", [(await auto.ritualSettled({ actor: primary, spell: { uuid: "Spell.other" } })).lines, calls.deductGold, primary.getFlag(MOD, "ritualCensor") ?? null], [[], [], null]);
calls.deductGold.length = 0;
purse = 3;
equal("C …and a short purse refuses the tick", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: { eaCensor: true }, variant: "", basePP: 3, secondaryCount: 1 })).refused, "the Ritual Censor's incense costs 5 gp, and the purse is short: untick it");
calls.deductGold.length = 0;
equal("C …a refused variant costs no incense", [(await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: {}, variant: "material", basePP: 3, secondaryCount: 1 })).refused, calls.deductGold], ["the material sacrifice for 3 PP is 100 gp, and Primary has 3 gp", []]);
purse = 1000;
equal("C no more Ritual Experts than secondaries entered", (await auto.prepareRitual({ actor: untrained, spellData: arcaneSpell.system, form: { eaRitualExperts: "4" }, variant: "", secondaryCount: 1 })).seats, 1);
equal("C vital: each secondary entered must be ticked", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true }, variant: "vital", basePP: 3, secondaryCount: 2 })).refused, "tick each secondary caster taking part (2 entered, 1 ticked)");
sec2.isOwner = false;
equal("C communal: a secondary not yours is refused before the roll", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true, "eaSecondary-Sec2": true }, variant: "communal", basePP: 3, secondaryCount: 2 })).refused, "Sec2: not yours to take PP from (the GM may lead it)");
sec2.isOwner = true;
sec1.system.resources.pp.value = 2; sec2.system.resources.pp.value = 1;
equal("C communal: the secondaries' PP must cover it before the roll", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true, "eaSecondary-Sec2": true }, variant: "communal", basePP: 3, secondaryCount: 2 })).refused, "the communal offering for 3 PP is 5 PP, and the secondaries hold 3");
const specialistSpell = { name: "Arcane Signature", system: { tradition: "", specialist: true, traits: "" } };
equal("C a specialist spell takes the caster's tradition for its skill", (await auto.ritualVariants({ actor: primary, spellData: specialistSpell.system })).length, 3);
equal("C an untrained primary is refused a variant", (await auto.prepareRitual({ actor: untrained, spellData: arcaneSpell.system, form: {}, variant: "vital" })).refused, "the primary caster must be trained in Arcana");
equal("C communal needs a named secondary", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: {}, variant: "communal", basePP: 3, secondaryCount: 1 })).refused, "tick the secondary casters who pay the communal offering");
equal("C material beyond 20 PP is refused", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: {}, variant: "material", basePP: 18, ppOver: 4 })).refused, "the material sacrifice table stops at 20 PP (this ritual is 22)");
ok("C the material plan says the Success's cost", (await auto.prepareRitual({ actor: primary, spellData: arcaneSpell.system, form: {}, variant: "material", basePP: 3, ppOver: 2 })).lines.some((l) => /a Success: 250 gp/.test(l)));

const eaRitual = { name: "Binding Rite", system: { traits: "Ritual, Conjuration", tradition: "ethereal" }, _stats: { compendiumSource: "Compendium.trg-eldritch-arts.ea-spells.Item.b" } };
const coreClone = { name: "Clone", system: { traits: "Ritual" }, _stats: { compendiumSource: "Compendium.trg-prime.spells.Item.c" } };
equal("C Q8: an Eldritch Arts Ritual spell is refused outside a ritual; inside one, or Clone, is not",
  [Boolean(auto.ritualSpellRefusal({ spell: eaRitual, ritual: false })), auto.ritualSpellRefusal({ spell: eaRitual, ritual: true }), auto.ritualSpellRefusal({ spell: coreClone, ritual: false })], [true, null, null]);
equal("C M30: its ritual is not capped; Clone's still is", [auto.ritualLiftsCap({ spell: eaRitual }), auto.ritualLiftsCap({ spell: coreClone })], [true, false]);

// The substitute, paid once settled (Q11).
{
  cards.length = 0; calls.basicSaveHit.length = 0;
  await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true }, variant: "vital", basePP: 3, secondaryCount: 1 });
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: `${MOD}:vital`, ppSubstituted: 2, castOptions: [], saveResults: [] });
  equal("C vital: the primary 2d8, the named secondary 2d4, basic Fortitude against their own level DC, nothing reducing it",
    calls.basicSaveHit.map((c) => [c.target, c.formula, c.save, c.dc, c.type, c.ignoreDefences]), [["Primary", "2d8", "fortitude", 18, "essence", true], ["Sec1", "2d4", "fortitude", 18, "essence", true]]);
  equal("C …and the plan is spent", primary.getFlag(MOD, "ritualPlan"), undefined);
  calls.deductGold.length = 0;
  await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: {}, variant: "material", basePP: 4 });
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: `${MOD}:material`, ppSubstituted: 2, castOptions: [], saveResults: [] });
  equal("C material: the gold for the PP the degree spent (a Failure's half: 2 PP, 60 gp)", calls.deductGold, [["Primary", 60]]);
  purseShort = 12;
  await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: {}, variant: "material", basePP: 4 });
  // (The purse was checked before the roll; a GM's change since is said, not taken.)
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: `${MOD}:material`, ppSubstituted: 4, castOptions: [], saveResults: [] });
  ok("C a short purse is said, not taken", cards.at(-1).lines.some((l) => /short by 12 gp\. Nothing was deducted/.test(l)));
  purseShort = 0;
  sec1.system.resources.pp.value = 10; sec2.system.resources.pp.value = 3;
  await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true, "eaSecondary-Sec2": true }, variant: "communal", basePP: 5, secondaryCount: 2 });
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: `${MOD}:communal`, ppSubstituted: 5, castOptions: [], saveResults: [] });
  equal("C communal: 5 PP + 50% = 8, split 4 and 4; a secondary short pays what they have", [sec1.system.resources.pp.value, sec2.system.resources.pp.value], [6, 0]);
  ok("C …and the shortfall is said", cards.at(-1).lines.some((l) => /Sec2 pays <strong>3 PP<\/strong> of 4 \(short by 1\)/.test(l)));
  const before = cards.length;
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: "", ppSubstituted: 0, castOptions: [], saveResults: [] });
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: "other-module:vital", ppSubstituted: 3, castOptions: [], saveResults: [] });
  equal("C nothing is paid for a ritual paid in PP, or another module's variant", cards.length, before);
  calls.basicSaveHit.length = 0;
  await auto.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true }, variant: "vital", basePP: 3, secondaryCount: 1 });
  await auto.onSpellSettledB2b({ actor: primary, spell: arcaneSpell, ritualVariant: `${MOD}:vital`, ppSubstituted: 3, refunded: true, castOptions: [], saveResults: [] });
  equal("C a refunded cast pays no sacrifice, and its plan is cleared", [calls.basicSaveHit.length, primary.getFlag(MOD, "ritualPlan")], [0, undefined]);
}

/* ------------------------------------------------------------------ *
 * D. Circles, true names, Spell Trickery, Borrow Spell
 * ------------------------------------------------------------------ */
const summoner = makeActor("Summoner");
const summonSpell = { name: "Call Fiend", system: { traits: "Conjuration, Summons", tradition: "ethereal" } };
item(summoner, { name: "Ward Twine", type: "gear" });
dialogAnswer = { level: "5", ground: "aligned", care: "meticulous", wardTwine: true };
const circleDC = await auto.resolveCircleDC({ actor: summoner });
equal("D the circle's DC: the creature's level DC and the table's rows", circleDC.dc, 5 + 14 - 4 - 2);
ok("D …each row named", /Creature level 5 DC, Ground aligned with the creature's tradition -4, Prepared with meticulous care -2/.test(circleDC.label));
cards.length = 0;
await auto.onActionResolvedB2b({ actor: summoner, action: { key: "inscribeSummoningCircle" }, degree: "heroic" });
const circle = summoner.effects.find((e) => e.flags?.[MOD]?.circle);
equal("D a Heroic reads as the printed Critical; the circle is an effect for 1 hour per caster level, Ward Twine kept",
  [circle?.flags?.[MOD]?.circle, circle?.flags?.["trg-prime"]?.spellEffectEnd], [{ degree: "critical", level: 5, wardTwine: true, voidChalk: false }, 1000 + 5 * 3600]);
ok("D …and the card gives its time and duration", cards.at(-1).lines.some((l) => /<strong>100 minutes<\/strong> to draw, and lasts <strong>5 hours \(1 per caster level\)<\/strong>/.test(l)));
equal("D a Summons spell's casting check takes the circle's +4 circumstance; another spell nothing",
  [await auto.summoningCircleGate({ actor: summoner, spellData: summonSpell.system }), await auto.summoningCircleGate({ actor: summoner, spellData: arcaneSpell.system })],
  [{ modifiers: [{ label: "Summoning circle (critical)", value: 4, type: "circumstance" }], lines: [] }, null]);
equal("D the Critical's −2 to resist binding and Ward Twine's +1 are a required option: +3 Save DC (Q12)",
  [auto.circleBindingOption.offer({ actor: summoner, spellData: summonSpell.system })?.required, auto.circleBindingOption.offer({ actor: summoner, spellData: summonSpell.system })?.label, auto.circleBindingOption.apply({ actor: summoner }).saveDC, auto.circleBindingOption.offer({ actor: summoner, spellData: arcaneSpell.system })], [true, "Summoning circle: +3 Save DC", 3, null]);
dialogAnswer = { level: "2" };
await auto.resolveCircleDC({ actor: summoner });
await auto.onActionResolvedB2b({ actor: summoner, action: { key: "inscribeSummoningCircle" }, degree: "blunder" });
equal("D a new circle replaces the old; a Blunder reads as the Fumble", summoner.effects.filter((e) => e.flags?.[MOD]?.circle).map((e) => e.flags[MOD].circle.degree), ["fumble"]);
ok("D a Fumble's circle says so on the casting", (await auto.summoningCircleGate({ actor: summoner, spellData: summonSpell.system })).lines[0].includes("arrives hostile and unbound"));
cards.length = 0;
await auto.onSpellSettledB2b({ actor: summoner, spellData: summonSpell.system, spell: summonSpell, cast: true, refunded: false, castOptions: [], saveResults: [] });
ok("D …and when the summoning succeeds, the creature arrives hostile and unbound", cards.some((c) => c.lines.some((l) => /hostile and unbound/.test(l))));
dialogAnswer = { level: "3" };
await auto.resolveCircleDC({ actor: summoner });
await auto.onActionResolvedB2b({ actor: summoner, action: { key: "inscribeSummoningCircle" }, degree: "partial" });
equal("D a Partial reads as the printed Failure: −2", (await auto.summoningCircleGate({ actor: summoner, spellData: summonSpell.system })).modifiers[0].value, -2);
dialogAnswer = null;
equal("D no answer, no circle", (await auto.resolveCircleDC({ actor: summoner })).refused, "no circle drawn.");

// True names.
equal("D a true name is offered on a Summons spell only, +4 Save DC",
  [Boolean(auto.trueNameOption.offer({ spellData: summonSpell.system })), auto.trueNameOption.offer({ spellData: arcaneSpell.system }), auto.trueNameOption.offer({ spellData: summonSpell.system, itemCast: true }), auto.trueNameOption.apply().saveDC], [true, null, null, 4]);
const fiend = makeActor("Fiend");
const imp = makeActor("Imp");
cards.length = 0; calls.createEffectsOn.length = 0;
await auto.onSpellSettledB2b({ actor: summoner, spell: summonSpell, spellData: { traits: "" }, castOptions: ["truename"], saveResults: [{ target: fiend, degree: "success", saved: true }, { target: imp, degree: "failure", saved: false }] });
equal("D a creature that saves anyway is permanently hostile to you; one that failed is not",
  calls.createEffectsOn.map((c) => [c.target, c.list[0].name, c.list[0].flags[MOD].hostileTo]), [["Fiend", "Permanently hostile to Summoner", "Actor.Summoner"]]);
const n = calls.createEffectsOn.length;
await auto.onSpellSettledB2b({ actor: summoner, spell: summonSpell, spellData: { traits: "" }, castOptions: [], saveResults: [{ target: fiend, degree: "success", saved: true }] });
equal("D …and without the name invoked, nothing", calls.createEffectsOn.length, n);

// Spell Trickery.
equal("D Spell Trickery: offered to a cast with the prompt, not to a ritual's; +2 casting DC",
  [Boolean(auto.spellTrickeryOption.offer({})), auto.spellTrickeryOption.offer({ ritual: true }), auto.spellTrickeryOption.apply({ actor: primary }).castingDC], [true, null, 2]);
ok("D …the card gives the Deception DC and names the observer's action", /Deception DC <strong>17<\/strong> \(the See Through Spell Trickery action/.test(auto.spellTrickeryOption.apply({ actor: primary }).lines[0]));

// Borrow Spell.
const wizard = makeActor("Wizard");
const lender = makeActor("Lender");
item(wizard, { name: "Magic Missile", type: "spell", system: { ppCost: 2 } });
item(lender, { name: "Magic Missile", type: "spell", system: { ppCost: 2 } });
item(lender, { name: "Fireball", type: "spell", system: { ppCost: 6, prepared: true } });
keepsBook = false;
equal("D Borrow Spell: only a spellbook caster", (await auto.resolveBorrowDC({ actor: wizard })).refused, "only a spellcaster who prepares spells from a spellbook may borrow one.");
keepsBook = true;
// One lender: not asked whose book, only which spell.
answers.push(lender.items.find((i) => i.name === "Fireball").id);
const bdc = await auto.resolveBorrowDC({ actor: wizard });
equal("D …against the DC to learn it (the Easy step is the action's)", [bdc.dc, bdc.label], [24, "the DC to learn Fireball (6 PP)"]);
cards.length = 0;
await auto.onActionResolvedB2b({ actor: wizard, action: { key: "borrowSpell" }, degree: "critical" });
const borrowed = wizard.items.find((i) => i.name === "Fireball");
equal("D a Critical reads as Success: the spell joins the book, borrowed and unprepared, kept out of the free ladder",
  [Boolean(borrowed), borrowed?.system?.prepared, borrowed?.flags?.["trg-prime"]?.spellBookPick, borrowed?.flags?.["trg-prime"]?.learnedExtra, borrowed?.flags?.[MOD]?.borrowed?.from], [true, false, true, true, "Actor.Lender"]);
equal("D a spell already known (Magic Missile) or borrowed is not offered; no other spell: refused", (await auto.resolveBorrowDC({ actor: wizard })).refused, "no other caster's spellbook holds a spell you do not already know (or one you may try again today).");
item(lender, { name: "Haste", type: "spell", system: { ppCost: 6 } });
answers.push(lender.items.find((i) => i.name === "Haste").id);
await auto.resolveBorrowDC({ actor: wizard });
await auto.onActionResolvedB2b({ actor: wizard, action: { key: "borrowSpell" }, degree: "fumble" });
equal("D a Failure (or worse) bars that spell until the next preparation", [wizard.items.some((i) => i.name === "Haste"), wizard.getFlag(MOD, "borrowLocks")], [false, ["Haste"]]);
ok("D …so it is not offered again today", /no other caster's spellbook/.test((await auto.resolveBorrowDC({ actor: wizard })).refused ?? ""));
await auto.onDailyPreparationB2b({ actor: wizard });
equal("D a new day: the borrowed spell leaves the book, the bar lifts", [wizard.items.some((i) => i.name === "Fireball"), wizard.getFlag(MOD, "borrowLocks"), wizard.items.some((i) => i.name === "Magic Missile")], [false, undefined, true]);

// Two books to borrow from: asked whose.
{
  const w2 = makeActor("Wizard2");
  const l2 = makeActor("Lender2");
  item(l2, { name: "Light", type: "spell", system: { ppCost: 0 } });
  const asked = [];
  const real = helpers.chooseFromList;
  helpers.chooseFromList = async (title, prompt, list) => { asked.push([prompt, list.map((x) => x[1])]); return real(); };
  answers.push("Lender2", l2.items[0].id);
  const got = await auto.resolveBorrowDC({ actor: w2 });
  // And from the first lender, the known spell (Magic Missile) is not offered.
  answers.push("Lender", null);
  await auto.resolveBorrowDC({ actor: wizard });
  helpers.chooseFromList = real;
  equal("D with several books, whose is asked first, then which spell", [asked.slice(0, 2).map((a) => a[0]), got.label], [["Whose spellbook?", "Which of Lender2's spells?"], "the DC to learn Light (0 PP)"]);
  equal("D …and a spell you already know is not offered", asked[3]?.[1], ["Fireball (6 PP)", "Haste (6 PP)"]);
  await w2.unsetFlag(MOD, "block2bPlan");
  worldActors.splice(worldActors.indexOf(l2), 1);
}
// "Another caster's spellbook" (review): not a monster's spell-likes, not an item's spell; the copy is the borrower's own.
{
  const w3 = makeActor("Wizard3");
  const monster = makeActor("Monster");
  noBook.add("Monster");
  item(monster, { name: "Cone of Cold", type: "spell", system: { ppCost: 10 } });
  const sage = makeActor("Sage");
  item(sage, { name: "Spell-like Blast", type: "spell", system: { ppCost: 4, innate: true } });
  item(sage, { name: "Scroll's Gift", type: "spell", system: { ppCost: 2 }, flags: { "trg-prime": { itemCast: { consumed: false } } } });
  item(sage, { name: "Slow", type: "spell", system: { ppCost: 6 }, flags: { "trg-prime": { signatureSpell: true, spellEffectRune: "x", grantedBy: { sourceName: "Sage's class" }, effectsDeclared: true } } });
  for (const a of [lender, wizard]) { a._hold = a.items.splice(0); a._hold.get = () => null; }
  const asked = [];
  const real = helpers.chooseFromList;
  helpers.chooseFromList = async (title, prompt, list) => { asked.push(list.map((x) => x[1])); return real(); };
  answers.push(sage.items.find((i) => i.name === "Slow").id);
  const got = await auto.resolveBorrowDC({ actor: w3 });
  helpers.chooseFromList = real;
  equal("D only a book caster lends, and only book entries: no innate spell-like, no item's spell", asked, [["Slow (6 PP)"]]);
  equal("D …the DC is Slow's", got.label, "the DC to learn Slow (6 PP)");
  await auto.onActionResolvedB2b({ actor: w3, action: { key: "borrowSpell" }, degree: "success" });
  const copy = w3.items.find((i) => i.name === "Slow");
  equal("D the copy is the borrower's: not innate, the lender's signature, rune and grant left behind, the rest kept",
    [copy?.system?.innate, copy?.flags?.["trg-prime"]?.signatureSpell, copy?.flags?.["trg-prime"]?.spellEffectRune, copy?.flags?.["trg-prime"]?.grantedBy?.sourceName, copy?.flags?.["trg-prime"]?.effectsDeclared], [false, undefined, undefined, "Borrow Spell", true]);
  for (const a of [lender, wizard]) { a.items.push(...a._hold); delete a._hold; }
  for (const a of [w3, monster, sage]) worldActors.splice(worldActors.indexOf(a), 1);
}


/* ------------------------------------------------------------------ *
 * E. The system's registry, end to end; the wiring
 * ------------------------------------------------------------------ */
api.resetModuleRegistry();
reg.registerContent({
  registerSourcebook: api.registerSourcebook, registerRacialPP: api.registerRacialPP, registerFeatAccess: api.registerFeatAccess,
  registerTraits: api.registerTraits, registerWeaponTraitRule: api.registerWeaponTraitRule, registerSkillActions: api.queueSkillActions,
  registerFeatAutomation: api.queueFeatAutomation, registerSpellCheckGate: api.registerSpellCheckGate,
  registerCastSurcharge: api.registerCastSurcharge, registerReleasePath: api.registerReleasePath,
  registerHighMagicRules: api.registerHighMagicRules, registerCastRefusal: api.registerCastRefusal, registerCastDegreeRemap: api.registerCastDegreeRemap,
  registerResonanceSuppressor: api.registerResonanceSuppressor, registerEffectSuppressor: api.registerEffectSuppressor,
  registerRitualRules: api.registerRitualRules, registerCastOption: api.registerCastOption
}, MOD);
equal("E the system's registry took everything without a problem", api.registrationProblems(), []);
const R0 = () => api.moduleRegistry();
equal("E the ritual rules settle the rite (0.13.2: the Censor's incense)", R0().ritualRules?.get?.(MOD)?.settled === auto.ritualSettled, true);
const queued2b = api.queuedSkillActions().filter((a) => actions.SKILL_ACTIONS.some((x) => x.key === a.key));
equal("E the three actions are queued, each keeping its own DC where it has one", queued2b.map((a) => [a.key, typeof a.resolveDC]), [["inscribeSummoningCircle", "function"], ["borrowSpell", "function"], ["seeThroughSpellTrickery", "undefined"]]);
const keysOf = (m) => Array.from(m?.keys?.() ?? []);
const R = api.moduleRegistry();
equal("E registered: the ritual rules, the Ritual-spell refusal, the circle's gate, three casting options",
  // Block 5 (0.8.0) adds its own ritual rules key and Runic Stabiliser's option; verify-block5d holds them.
  // Block 6 (0.9.0) adds Sanguine Channel's and Runic Overload's options; verify-block6a and 6b2 hold them.
  // Block 9a 0.13.0 added Blood-etched Vellum's (eaCatalystRitual); 0.13.1 removed it (the Vellum is a cast item). Excluded either way.
  [keysOf(R.ritualRules).filter((k) => !/block5/.test(k) && k !== "eacatalystritual"), keysOf(R.castRefusals).includes("ritualspells"), keysOf(R.spellCheckGates).includes("summoningcircle"), keysOf(R.castOptions).filter((k) => !["runicstabiliser", "sanguinechannel", "earunicoverload", "eabindingseal", "easoulsecho", "eawildsurges"].includes(k))], // + Block 9c's rods (0.15.0); verify-block9c holds them
  // Block 8b (0.12.0) adds its own ritual rules key (the ten rituals: H13, H14); verify-block8b holds it.
  [[MOD, `${MOD}-8b`], true, true, ["summoningcircle", "truename", "spelltrickery"]]);
// The system's ritual rules, asked as the ritual asks them.
const variantsNow = await ritualRules.ritualVariantsFor({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system });
equal("E the system offers the variants, keyed by the module", variantsNow.map((v) => v.key), [`${MOD}:vital`, `${MOD}:material`, `${MOD}:communal`]);
const planNow = await ritualRules.prepareRitual({ actor: primary, spell: arcaneSpell, spellData: arcaneSpell.system, form: { "eaSecondary-Sec1": true, eaCensor: true }, variant: `${MOD}:vital`, basePP: 3, ppOver: 0, secondaryCount: 1 });
equal("E …a variant with the Censor ticked marks the incense too, for the rite to take (0.13.2)", primary.getFlag(MOD, "ritualCensor"), { spell: "Spell.ward", at: 1000 });
await primary.unsetFlag(MOD, "ritualCensor");
equal("E …and its plan: the module's DC and skill, the Censor's row, Ritual Expert's seat",
  [planNow.variant, planNow.dc, planNow.skill, planNow.dcRows, planNow.seats, planNow.refused], [`${MOD}:vital`, { value: 23, label: "Level DC (level 4), Very Hard +5" }, { key: "arcana", label: "Arcana" }, [{ label: "Ritual Censor", value: -1 }], 1, ""]);
equal("E the system lifts the cap for an Eldritch Arts Ritual spell only", [await ritualRules.ritualCapLifted({ spell: eaRitual }), await ritualRules.ritualCapLifted({ spell: coreClone })], [true, false]);
const offered = await castOptions.offeredCastOptions({ actor: primary, spell: summonSpell, spellData: summonSpell.system, innate: false, itemCast: false, ritual: false });
equal("E the system offers true name and Spell Trickery on a Summons spell", offered.map((o) => o.key), ["truename", "spelltrickery"]);
const applied = await castOptions.appliedCastOptions({ actor: primary }, ["truename", "spelltrickery"]);
equal("E …and applies them: +4 Save DC, +2 casting DC", [applied.saveDC, applied.castingDC], [4, [{ label: "Spell Trickery", value: 2 }]]);
api.resetModuleRegistry();

const script = fs.readFileSync(path.join(ROOT, "scripts", "eldritch-arts.mjs"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "module.json"), "utf8"));
const systemJson = JSON.parse(fs.readFileSync(path.join(SYSTEM_ROOT, "system.json"), "utf8"));
ok("E the hooks: the actions resolved, the casting settled, a new day",
  /Hooks\.on\("trgPrimeActionResolved", \(ctx\) => \{ onActionResolvedB2b\(ctx\)/.test(script) && /Hooks\.on\("trgPrimeSpellSettled", \(ctx\) => \{ onSpellSettledB2b\(ctx\)/.test(script) && /Hooks\.on\("trgPrimeDailyPreparation", \(ctx\) => \{ onDailyPreparationB2b\(ctx\)/.test(script));
const atLeast = (v, min) => { const a = String(v).split(".").map(Number), b = String(min).split(".").map(Number); for (let i = 0; i < 3; i++) { if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0); } return true; };
ok("E versions: module 0.4.0 or later, needing TRG Prime 3.679.0 or later", atLeast(manifest.version, "0.4.0") && atLeast(/REQUIRED_SYSTEM = "([\d.]+)"/.exec(script)?.[1], "3.679.0") && atLeast(manifest.relationships.systems[0].compatibility.minimum, "3.679.0"));
ok("E the system at TRG_PRIME_ROOT is 3.679.0 or later", atLeast(systemJson.version, "3.679.0"), systemJson.version);

if (failures.length) {
  console.log(`verify-block2b: ${checks} checks, ${failures.length} failure(s).`);
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exitCode = 1;
} else {
  console.log(`verify-block2b: ${checks} checks, 0 failure(s).`);
}
