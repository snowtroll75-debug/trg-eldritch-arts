# TRG Prime: Eldritch Arts

The *Eldritch Arts* sourcebook (v1.6) as a companion module for the **TRG Prime** system on Foundry VTT 14.

The module adds the following:
- **High Magic.**
- **Races:** four new races (Aetherial, Emberkin, Nyrinn, Scaelyn) and their heritages.
- **Backgrounds:** twelve.
- **Classes:** five (Archmage, Sorcerer, Spellblade, Warlock, Witch), with birthrights, paths and bonded souls.
- **Skill actions:** the new ones from the book.
- **Feats:** racial, archetype, class and general.
- **Gear:** exotic weapons, special materials, goods and catalysts.
- **Magic:** ley lines, wild magic and magic suppression areas, rituals and summoning circles.
- **The Grimoire**, magic items and relics.

It works as an extension of TRG Prime. The content arrives through the system's own compendium federation, under the **Eldritch Arts** sourcebook in every picker. Mechanics are automated through the system's module API, and there is no separate character sheet.

## Status

**0.15.0: Blocks 1–9, on book v1.6 with Graham's rulings.** Chapter 2's races, heritages and backgrounds; Chapter 4's skill actions; Chapter 6's exotic weapons and goods; High Magic and Chapter 7's areas, rituals, summoning circles and true names; the five classes, their specialist spells and reactions; Chapter 5's racial, general, archetype and class feats and the module's metamagic; the first half of Chapter 8's Grimoire (42 spells, Block 7; `docs/RELEASE_NOTES_0.10.0.md`, with 0.10.1's live-test fixes in `docs/RELEASE_NOTES_0.10.1.md`); Block 8a's 22 Grimoire spells: the eight Bindings, the Symbols and the utilities (`docs/RELEASE_NOTES_0.11.0.md`, with the live-test fixes in `docs/RELEASE_NOTES_0.11.1.md` and `docs/RELEASE_NOTES_0.11.2.md`); and Block 8b's 17: the ten rituals and the High Magic spells tied to Chapter 7 (`docs/RELEASE_NOTES_0.12.0.md`). The whole Grimoire is built. Block 9a adds Chapter 6's 24 catalysts, the four catalyst feats and the ten special materials (`docs/RELEASE_NOTES_0.13.0.md`, `docs/RELEASE_NOTES_0.13.1.md`). Block 9b adds Chapter 9's 34 runes and 9 specific items (`docs/RELEASE_NOTES_0.14.0.md`, `docs/RELEASE_NOTES_0.14.1.md`), and Block 9c its 5 orbs, 9 rods and 5 staves and Spellhold's store (`docs/RELEASE_NOTES_0.15.0.md`). Block 9b adds Chapter 9's 34 runes and 9 specific items (`docs/RELEASE_NOTES_0.14.0.md`, `docs/RELEASE_NOTES_0.14.1.md`), and Block 9c its 5 orbs, 9 rods and 5 staves and Spellhold's store (`docs/RELEASE_NOTES_0.15.0.md`). The rest follows the block plan in `docs/PROGRESS.md`. Every item says on its card what is automated and what is not. The feature inventory is `docs/ELDRITCH_ARTS_IMPLEMENTATION_MATRIX.md`, and the rulebook audit is `docs/ELDRITCH_ARTS_RULES_AUDIT.md`.

## Requirements

- Foundry VTT 14.
- TRG Prime **3.686.0** or later. Several features need the core additions listed in `docs/ELDRITCH_ARTS_CORE_DEPENDENCIES.md`, and each block states the system version it needs.

## Installing

In Foundry, use **Add-on Modules → Install Module**, enter the manifest URL below, and enable the module in your TRG Prime world:

```
https://raw.githubusercontent.com/snowtroll75-debug/trg-eldritch-arts/main/module.json
```

The repository `snowtroll75-debug/trg-eldritch-arts` has to be created before the manifest URL works. Until then, install from a release zip.

## Building from source

```
npm install
node tools/content/extract-book.mjs <ea.md> <ea-sidebars.md>   # cut the book into tools/content/book-text.json
npm run docs                                  # regenerate the matrix and automation report
npm run build:packs                           # compile packs from tools/content
npm run build                                 # ../trg-eldritch-arts-<version>.zip
TRG_PRIME_ROOT=../trpg-prime node tools/verify-block1.mjs   # the Block 1 harness
TRG_PRIME_ROOT=../trpg-prime node tools/mutate-block1.mjs   # …and its mutations
```

Here `ea.md` is the pandoc cut of the book: `pandoc -t gfm --wrap=none TRG_Prime_Eldritch_Arts_1_4.docx`, with `<img>` tags stripped. pandoc drops Word text boxes, so `ea-sidebars.md` holds the 36 sidebars recovered from the docx XML (`word/document.xml`), each headed `## SIDEBAR n: TITLE (after Lnnnn)`. Harnesses read the system from `TRG_PRIME_ROOT`.
